/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 * 
 * @author nirav.modi
 * @Use 
 * 		To revive Tender
 */
@Component
public class SPReviveTender extends StoredProcedure {

	@Autowired
	@Qualifier("dataSource")
	public void init(BasicDataSource factory) {
		setDataSource(factory);
	}

	private static final String SPROC_NAME = "apptender.P_ReviveTender";

	public SPReviveTender() {
		super.setSql(SPROC_NAME);
		this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_CreatedBy", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_AssignUserId", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_isDocRequire", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_clientId", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_eventCount", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_isFormRequire", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_isDateRequire", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_isEvaluateBidderReq", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_isTOCRevive", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_isTECRevive", Types.INTEGER));
	}

	/**
	 * Method use to revive tender
	 * 
	 * @param tenderId
	 * @param createdBy
	 * @return {@code Map<String,Object>}
	 * @throws Exception
	 */
	public Map<String, Object> executeProcedure(int tenderId, int createdBy,int userId,int isDocRevive,int clientId,int eventCount,int isFormRequire,int isDateRequire,int isEvaluateBidderRevive,int isTOCRevive,int isTECRevive) throws Exception {
		Map inParams = new HashMap();
		inParams.put("@V_TenderId", tenderId);
		inParams.put("@V_CreatedBy", createdBy);
		inParams.put("@V_AssignUserId", userId);
		inParams.put("@V_isDocRequire", isDocRevive);
		inParams.put("@V_clientId", clientId);
		inParams.put("@V_eventCount", eventCount);
		inParams.put("@V_isFormRequire", isFormRequire);
		inParams.put("@V_isDateRequire", isDateRequire);
		inParams.put("@V_isEvaluateBidderReq", isEvaluateBidderRevive);
		inParams.put("@V_isTOCRevive", isTOCRevive);
		inParams.put("@V_isTECRevive", isTECRevive);
		
		
		this.compile();

		return execute(inParams);
	}
}
