/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblCommitteeUser;
import java.util.List;

/**
 *
 * @author shreyansh.shah
 */
public interface TblCommitteeUserDao  {

    public void addTblCommitteeUser(TblCommitteeUser tblCommitteeUser);

    public void deleteTblCommitteeUser(TblCommitteeUser tblCommitteeUser);

    public void updateTblCommitteeUser(TblCommitteeUser tblCommitteeUser);

    public List<TblCommitteeUser> getAllTblCommitteeUser();

    public List<TblCommitteeUser> findTblCommitteeUser(Object... values) throws Exception;

    public List<TblCommitteeUser> findByCountTblCommitteeUser(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCommitteeUserCount();

    public void saveUpdateAllTblCommitteeUser(List<TblCommitteeUser> tblCommitteeUsers);
}
