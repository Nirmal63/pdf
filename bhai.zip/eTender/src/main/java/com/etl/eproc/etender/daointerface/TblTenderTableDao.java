package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderTable;
import java.util.List;

public interface TblTenderTableDao  {

    public void addTblTenderTable(TblTenderTable tblTenderTable);

    public void deleteTblTenderTable(TblTenderTable tblTenderTable);

    public void updateTblTenderTable(TblTenderTable tblTenderTable);

    public List<TblTenderTable> getAllTblTenderTable();

    public List<TblTenderTable> findTblTenderTable(Object... values) throws Exception;

    public List<TblTenderTable> findByCountTblTenderTable(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderTableCount();

    public void saveUpdateAllTblTenderTable(List<TblTenderTable> tblTenderTables);
}