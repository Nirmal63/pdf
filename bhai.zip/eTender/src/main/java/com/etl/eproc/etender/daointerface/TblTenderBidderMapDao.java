package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.etender.model.TblTenderBidderMap;
import java.util.List;

public interface TblTenderBidderMapDao  {

    public void addTblTenderBidderMap(TblTenderBidderMap tblTenderBidderMap);

    public void deleteTblTenderBidderMap(TblTenderBidderMap tblTenderBidderMap);

    public void updateTblTenderBidderMap(TblTenderBidderMap tblTenderBidderMap);

    public List<TblTenderBidderMap> getAllTblTenderBidderMap();

    public List<TblTenderBidderMap> findTblTenderBidderMap(Object... values) throws Exception;

    public List<TblTenderBidderMap> findByCountTblTenderBidderMap(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblTenderBidderMapCount();

    public void saveUpdateAllTblTenderBidderMap(List<TblTenderBidderMap> tblTenderBidderMaps);
}