/**
 *
 * @author hiral
 */
package com.etl.eproc.advertise.daoimpl;

import com.etl.eproc.advertise.model.TblAdvertiseTenderMap;
import com.etl.eproc.advertise.daointerface.TblAdvertiseTenderMapDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

@Repository @Transactional
public class TblAdvertiseTenderMapImpl extends AbcAbstractClass<TblAdvertiseTenderMap> implements TblAdvertiseTenderMapDao {

   
    @Override
    public void addTblAdvertiseTenderMap(TblAdvertiseTenderMap tblAdvertiseTenderMap){
        super.addEntity(tblAdvertiseTenderMap);
    }

    @Override
    public void deleteTblAdvertiseTenderMap(TblAdvertiseTenderMap tblAdvertiseTenderMap) {
        super.deleteEntity(tblAdvertiseTenderMap);
    }

    @Override
    public void updateTblAdvertiseTenderMap(TblAdvertiseTenderMap tblAdvertiseTenderMap) {
        super.updateEntity(tblAdvertiseTenderMap);
    }

    @Override
    public List<TblAdvertiseTenderMap> getAllTblAdvertiseTenderMap() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAdvertiseTenderMap> findTblAdvertiseTenderMap(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAdvertiseTenderMapCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAdvertiseTenderMap> findByCountTblAdvertiseTenderMap(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAdvertiseTenderMap(List<TblAdvertiseTenderMap> tblAdvertiseTenderMaps){
        super.updateAll(tblAdvertiseTenderMaps);
    }
}
