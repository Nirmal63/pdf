/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

/**
 *
 * @author Darshan Shah
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblAnswerDao;
import com.etl.eproc.common.daointerface.TblQuestionDao;
import com.etl.eproc.common.model.TblAnswer;
import com.etl.eproc.common.model.TblQuestion;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.etender.daointerface.TblPreBidReportDao;
import com.etl.eproc.etender.model.TblPreBidReport;
import com.etl.eproc.etender.model.TblTender;

@Service
public class PrebidService {

    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    @Autowired
    private TblAnswerDao tblAnswerDao;
    @Autowired
    private TblPreBidReportDao tblPreBidReportDao;
    @Autowired
    private TblQuestionDao tblQuestionDao;

    private static final String QUESTION_ID="questionId";
    private static final String ANSWER_ID="answerId";
    /**
     *
     * @param userId
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getMyQuestions(int userId, int tenderId) throws Exception {
	List<Object[]> list = null;
	Map<String, Object> var = new HashMap<String, Object>();
	var.put("userId", userId);
	var.put("tenderId", tenderId);
	list = hibernateQueryDao.createNewQuery("select tblquestion.createdOn, tblquestion.questionText from TblQuestion tblquestion where tblquestion.userId=:userId and tblquestion.objectId=:tenderId", var);
	return list;
    }

    /**
     *
     * @param userId
     * @param tenderId
     * @param isAllQusAns
     * @return
     * @throws Exception
     */
    public List<Object[]> getQuestionAnswers(int userId, int userTypeId, int tenderId, boolean isAllQusAns) throws Exception {
	Map<String, Object> var = new HashMap<String, Object>();
	var.put("tenderId", tenderId);
	StringBuilder strQuery = new StringBuilder();
       strQuery.append("select tblquestion.questionText, tblquestion.createdOn, isNull(tblanswer.answerText,'-') ,tbluserdetail.userName , ")
        .append("tblanswer.createdOn, tblquestion.cstatus, tblquestion.objectId, tblquestion.parentQuestionId,  tblquestion.tblSubModule.subModuleId, ")
        .append("tblquestion.moduleType, tbluserdetail.tblUserLogin.userId, tblanswer.tblUserDetail.userDetailId, (select isNull(tblQuestion.questionText,'') ")
        .append("from TblQuestion tblQuestion where tblquestion.parentQuestionId = tblQuestion.questionId and tblquestion.parentQuestionId != 0),tblquestion.questionId  ")
        .append("from  TblQuestion tblquestion left join  tblquestion.tblAnswer tblanswer left join  tblanswer.tblUserDetail tbluserdetail ")
        .append("where  tblquestion.objectId=:tenderId and ((tblquestion.parentQuestionId = 0 and tblquestion.cstatus != 3) ")
        .append("or tblquestion.parentQuestionId != 0) and tblquestion.tblSubModule.subModuleId = 31  order by tblquestion.createdOn desc");
	if(!isAllQusAns){
            strQuery.delete(0, strQuery.length());
	    var.put("userId", userId);
	    if(userTypeId == 3 || userTypeId == 1) {
            strQuery.append("select tblquestion.questionText, tblquestion.createdOn, isNull(tblanswer.answerText,'-'), tbluserdetail.userName , ")
                    .append("tblanswer.createdOn, tblquestion.cstatus,  tblquestion.objectId, tblquestion.parentQuestionId,  ")
                    .append("tblquestion.tblSubModule.subModuleId, tblquestion.moduleType, tbluserdetail.tblUserLogin.userId, ")
                    .append("tblanswer.tblUserDetail.userDetailId, (select isNull(tblQuestion.questionText,'') ")
                    .append("from TblQuestion tblQuestion ")
                    .append("where tblquestion.parentQuestionId = tblQuestion.questionId and tblquestion.parentQuestionId != 0),tblquestion.questionId ")
                    .append("from  TblQuestion tblquestion inner join tblquestion.tblAnswer tblanswer ")
                    .append("with tblanswer.tblUserLogin.userId=:userId left join  tblanswer.tblUserDetail tbluserdetail ")
                    .append("where  tblquestion.objectId=:tenderId and ((tblquestion.parentQuestionId = 0 and tblquestion.cstatus != 3) ")
                    .append("or tblquestion.parentQuestionId != 0) and tblquestion.tblSubModule.subModuleId = 31 order by tblquestion.createdOn desc");
	    } else if (userTypeId == 2) {
            strQuery.append("select tblquestion.questionText, tblquestion.createdOn, isNull(tblanswer.answerText,'-') ,tbluserdetail.userName , ")
                    .append("tblanswer.createdOn, tblquestion.cstatus, tblquestion.objectId, tblquestion.parentQuestionId,  ")
                    .append("tblquestion.tblSubModule.subModuleId, tblquestion.moduleType, tbluserdetail.tblUserLogin.userId, ")
                    .append("tblanswer.tblUserDetail.userDetailId,  (select isNull(tblQuestion.questionText,'') ")
                    .append("from TblQuestion tblQuestion where tblquestion.parentQuestionId = tblQuestion.questionId and tblquestion.parentQuestionId != 0),tblquestion.questionId ")
                    .append("from  TblQuestion tblquestion left join  tblquestion.tblAnswer tblanswer left join  tblanswer.tblUserDetail tbluserdetail ")
                    .append("where  tblquestion.objectId=:tenderId ")
                    .append("and ((tblquestion.parentQuestionId = 0 and tblquestion.cstatus != 3 and tblquestion.tblUserLogin.userId=:userId) ")
                    .append("or (tblquestion.parentQuestionId != 0  and tblquestion.parentQuestionId in (select tblQuestion1.questionId ")
                    .append("from TblQuestion tblQuestion1 where tblQuestion1.tblUserLogin.userId=:userId))) and tblquestion.tblSubModule.subModuleId = 31 order by tblquestion.createdOn desc");
	    }
	}
		return hibernateQueryDao.createNewQuery(strQuery.toString(), var);
    }

    /**
     *
     * @param tblanswer
     * @return
     * @throws Exception
     */
    public boolean addTblAnswer(TblAnswer tblanswer) throws Exception {
	boolean bSuccess = false;
	tblAnswerDao.saveOrUpdateTblAnswer(tblanswer);
	bSuccess = true;
	return bSuccess;

    }

    /**
     *
     * @return @throws Exception
     */
    public List<TblAnswer> getAnswerList() throws Exception {

	List<TblAnswer> list = null;
	list = tblAnswerDao.getAllTblAnswer();
	return list;
    }

    /**
     *
     * @param tblprebidreport
     * @return
     * @throws Exception
     */
    public boolean addTblPreBidReport(TblPreBidReport tblprebidreport) throws Exception {
	boolean bSuccess = false;
	tblPreBidReportDao.saveOrUpdateTblPreBidReport(tblprebidreport);
	bSuccess = true;
	return bSuccess;

    }

    /**
     *
     * @return @throws Exception
     */
    public List<TblPreBidReport> getPreBidReportList() throws Exception {

	List<TblPreBidReport> list = null;
	list = tblPreBidReportDao.getAllTblPreBidReport();
	return list;
    }

    /**
     *
     * @param tblquestion
     * @return
     * @throws Exception
     */
    public boolean addTblQuestion(TblQuestion tblquestion) throws Exception {
	boolean bSuccess = false;
	tblQuestionDao.saveOrUpdateTblQuestion(tblquestion);
	bSuccess = true;
	return bSuccess;

    }

    /**
     *
     * @return @throws Exception
     */
    public List<TblQuestion> getQuestionList() throws Exception {

	List<TblQuestion> list = null;
	list = tblQuestionDao.getAllTblQuestion();
	return list;
    }

    /**
     *
     * @param questionId
     * @return
     * @throws Exception
     */
    public int updateTblQuestionById(int questionId, Integer cstatus) throws Exception {
	int cnt = 0;
	Map<String, Object> var = new HashMap<String, Object>();
	var.put(QUESTION_ID, questionId);
	var.put("cstatus", cstatus);
	cnt = hibernateQueryDao.updateDeleteNewQuery("update  TblQuestion tblquestion set cstatus=:cstatus  where tblquestion.questionId=:questionId", var);
	return cnt;
    }
    
    

   /**
     * 
     * @param cstatus
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getUnAnswerdQuestionList(int cstatus,int tenderId) throws Exception{
        List<Object[]> list = null; 
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("cstatus",cstatus);
        var.put("tenderId",tenderId);
        list = hibernateQueryDao.createNewQuery("select tblquestion.questionId,tblquestion.parentQuestionId,tblquestion.questionText,tblquestion.createdOn from TblQuestion tblquestion where tblquestion.cstatus=:cstatus and tblquestion.objectId=:tenderId and tblquestion.tblSubModule.subModuleId=31",var);                
        return list;        

    }

    /**
     *
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<TblPreBidReport> getPreBidReportByTenderId(int tenderId) throws Exception {
	List<TblPreBidReport> list = null;
	list = tblPreBidReportDao.findTblPreBidReport("tblTender", Operation_enum.EQ, new TblTender(tenderId));
	return list;

    }
     
    
        /**
     * 
     * @param remarks
     * @param approvedBy
     * @param prebidReportId
     * @return
     * @throws Exception 
     */
    public boolean approvePrebidReport(String remarks,int approvedBy,int prebidReportId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("remarks",remarks);
        var.put("approvedBy",approvedBy);
        var.put("prebidReportId",prebidReportId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblPreBidReport set cstatus=1 , approvedBy=:approvedBy , approvedOn=getutcdate() , remark=:remarks where prebidReportId=:prebidReportId",var);        
        return cnt!=0;

    }
    
    /**
     * 
     * @param questionId
     * @return
     * @throws Exception 
     */
    public  TblQuestion getQuestionById(int questionId) throws Exception{
            List<TblQuestion> list = null;        
        list = tblQuestionDao.findTblQuestion(QUESTION_ID,Operation_enum.EQ,questionId);                
            return (list!=null && !list.isEmpty()) ? list.get(0) : null;            

    }
    
        /**
     * 
     * @param questionId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getQuestionAnswerByQuestionId(int questionId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(QUESTION_ID,questionId);
        list = hibernateQueryDao.createNewQuery("select tblquestion.questionText, tblquestion.createdOn, tblanswer.answerText, tblanswer.createdOn, tblanswer.answerId, tblquestion.questionId ,tblquestion.isManDocReq,tblanswer.cstatus,tblSeekClarification.responseEndDate from  TblQuestion tblquestion  left join  tblquestion.tblAnswer tblanswer,TblSeekClarification tblSeekClarification where tblquestion.questionId=:questionId and tblSeekClarification.clarificationId=tblquestion.parentId",var);                
        return list;        

    }
        /**
     * 
     * @param questionId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getQuestionAnswerByQuestionId(int questionId,int userType) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(QUESTION_ID,questionId);
        if(userType == 1) {
            list = hibernateQueryDao.createNewQuery("select tblquestion.questionText, tblquestion.createdOn, tblanswer.answerText, tblanswer.createdOn, tblanswer.answerId, tblquestion.questionId  from  TblQuestion tblquestion  left join  tblquestion.tblAnswer tblanswer with tblanswer.cstatus = 1 where tblquestion.questionId=:questionId",var);                
        } else {
            list = hibernateQueryDao.createNewQuery("select tblquestion.questionText, tblquestion.createdOn, tblanswer.answerText, tblanswer.createdOn, tblanswer.answerId, tblquestion.questionId  from  TblQuestion tblquestion  left join  tblquestion.tblAnswer tblanswer where tblquestion.questionId=:questionId",var);                
        }
        return list;        

    }
    
    public List<SelectItem> getAnswerOptions(String futureRelease) throws Exception{
	List<SelectItem> answerOptions = new ArrayList<SelectItem>();
	answerOptions.add(new SelectItem("Reply", 1));
	answerOptions.add(new SelectItem("Hold", 2));
	if (futureRelease.equalsIgnoreCase("true")) {
	    answerOptions.add(new SelectItem("Rephrase", 3));
	}
	return answerOptions;
    }
    /**
    * author Lipi Shah
    * @param tblquestion
    * @return
    * @throws Exception
    */
   public boolean addTblQuestion(List<TblQuestion> tblquestionLst) throws Exception {
	boolean bSuccess = false;
	tblQuestionDao.saveUpdateAllTblQuestion(tblquestionLst);
	bSuccess = true;
	return bSuccess;

   }
    
   /**
    *author Priyanka Dalwadi
    *@return
    *@throws
    */
   
   public  List<Object[]>  getAnswerById(int questionId) throws Exception{
	   List<Object[]> list = null;
       Map<String, Object> var = new HashMap<String, Object>();
       var.put(QUESTION_ID,questionId);
       list = hibernateQueryDao.createNewQuery("select tblanswer.answerId, tblanswer.tblUserLogin.userId, tblanswer.answerText from TblAnswer tblanswer where tblanswer.tblQuestion.questionId=:questionId",var);                
       return list;
}
   /**
    *author Priyanka Dalwadi
    *@return
    *@throws
    * */
   
   public boolean updateTblAnswerById(int answerId, String answerText) throws Exception {
		int cnt = 0;
		Map<String, Object> var = new HashMap<String, Object>();
		var.put(ANSWER_ID, answerId);
		var.put("answerText", answerText);
		cnt = hibernateQueryDao.updateDeleteNewQuery("update TblAnswer tblanswer set answerText=:answerText  where tblanswer.answerId=:answerId", var);
		if(cnt >0)
			return true;
		else 
			return false;
	    }
}
