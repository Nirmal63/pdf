/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblOfficerDocMapping;
import com.etl.eproc.common.model.TblOfficerDocument;
import com.etl.eproc.common.model.TblQuestion;
import com.etl.eproc.common.model.TblSubModule;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.MessageQueueService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidations;
import com.etl.eproc.common.utility.DateUtils;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.etender.model.TblBroadCastQuestionMapping;
import com.etl.eproc.etender.model.TblClarificationBroadCast;
import com.etl.eproc.etender.model.TblSeekClarification;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.CommitteeFormationService;
import com.etl.eproc.etender.services.PrebidService;
import com.etl.eproc.etender.services.SeekClarificationService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderFormService;
import com.etl.eproc.etender.model.TblTenderReevaluation;

/**
 *
 * @author shreyansh.shah
 */
@Controller
@RequestMapping("/etender")
public class TenderSeekClarificationController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private PrebidService prebidService;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private SeekClarificationService seekClarificationService;
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private CommitteeFormationService committeeFormationService;
    @Autowired
    private CommonValidations commonValidations;
    @Autowired
    private ClientService clientService;
    @Autowired
    private MessageQueueService messageQueueService;
    @Autowired
    private ReloadableResourceBundleMessageSource messageSource;
    @Autowired
    private DateUtils dateUtils;
    
    @Value("#{projectProperties['officer.docstatus.approve']?:1}")
    private int officerDocStatusApprove;

    private static final int CLARIFICATION_MODULE_TYPE = 2;
    private static final String ENVELOPE_ID = "envelopeId";
    private static final String COMPANY_ID = "companyId";
    private static final String TENDER_ID = "tenderId";
    private static final String CONFIG_TYPE = "configType";
    private static final String ENVELOPE_TYPE = "envelopeType";
    private static final String ISEVAL_DONE = "isEvalDone";
    private static final String SORT_ORDER = "sortOrder";
    private static final String HDENVELOPE_TYPE = "hdEnvelopeType";
    private static final String HDSORT_ORDER = "hdSortOrder";
    private static final String HDCONFIG_TYPE = "hdConfigType";
    private static final String HDISEVAL_DONE = "hdIsEvalDone";
    private static final String OPER_TYPE = "operType";
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    
    @Value("#{etenderAuditTrailProperties['getSeekClarification']}")
    private String getSeekClarification;
    @Value("#{etenderAuditTrailProperties['getEditSeekClarification']}")
    private String getEditSeekClarification;
    @Value("#{etenderAuditTrailProperties['postSeekClarification']}")
    private String postSeekClarification;
    @Value("#{etenderAuditTrailProperties['postEditSeekClarification']}")
    private String postEditSeekClarification;
    @Value("#{etenderAuditTrailProperties['qualifiedBiddersList']}")
    private String qualifiedBiddersList;
    @Value("#{etenderAuditTrailProperties['getConfigureDates']}")
    private String getConfigureDates;
    @Value("#{etenderAuditTrailProperties['getEditConfigureDates']}")
    private String getEditConfigureDates;
    @Value("#{etenderAuditTrailProperties['getReconfigureConfigureDates']}")
    private String getReconfigureConfigureDates;
    @Value("#{etenderAuditTrailProperties['postConfigureDates']}")
    private String postConfigureDates;
    @Value("#{etenderAuditTrailProperties['postEditConfigureDates']}")
    private String postEditConfigureDates;
    @Value("#{etenderAuditTrailProperties['postReconfigureConfigureDates']}")
    private String postReconfigureConfigureDates;
    @Value("#{etenderAuditTrailProperties['viewBuyerQueriesList']}")
    private String viewBuyerQueriesList;
    @Value("#{etenderAuditTrailProperties['viewDetailQuery']}")
    private String viewDetailQuery;
    @Value("#{etenderAuditTrailProperties['postPublishQuery']}")
    private String postPublishQuery;
    
    @Value("#{tenderlinkProperties['bid_evaluation_configure']?:342}")
    private int configureClarificationLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_seek_clarification']?:343}")
    private int seekClarificationLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_edit_seek_clarification']?:346}")
    private int editClarificateDateLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_re_configure_seek_clarification']?:365}")
    private int reconfigureClarificateDateLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_view_seek_clarification']?:348}")
    private int viewClarificateDateLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_post_query']?:349}")
    private int clarificatePostQueryLinkId;
    @Value("#{tenderlinkProperties['bidder_reply']?:350}")
    private int bidderReplyLinkId; 
    @Value("#{tenderlinkProperties['bid_evaluation_edit_query']?:366}")
    private int editQueryLinkId; 
    @Value("#{tenderlinkProperties['bid_evaluation_view_query']?:367}")
    private int viewQueryLinkId; 
    @Value("#{tenderlinkProperties['bid_evaluation_update_seek_clarification']?:363}")
    private int updateClarificationLinkId; 
    @Value("#{tenderlinkProperties['bid_evaluation_view_seek_clarification_dashboard']?:364}")
    private int viewClarificationLinkId; 
    @Value("#{tenderlinkProperties['bid_evaluation_publish_seek_clarification']?:379}")
    private int publishClarificationLinkId; 
    
    @Value("#{etenderProperties['bid_evaluation_submoduleId']?:33}")
    private int seekClarificationSubModuleId;
    @Value("#{linkProperties['report_clarification_buyer_reportid']?:39}")
    private int clarificationBuyerReportid;
    @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
    private String queueName;
    @Value("#{etenderProperties['seeks_clarification_templateId']?:46}")
    private String seekClarificationTemplateId;
    @Value("#{tenderlinkProperties['publishBroadCastClarification']?:828}")
    private int publishBroadCastClarificationLinkId;
    @Value("#{tenderlinkProperties['configureBroadCastClarification']?:827}")
    private int configureBroadCastClarificationLinkId;
    @Value("#{etenderAuditTrailProperties['getBroadcastClarification']}")
    private String getBroadcastClarificationRemarks;
    @Value("#{tenderlinkProperties['publish_broadcast']?:824}")
    private int publishBroadcastListLinkId;
    @Value("#{tenderlinkProperties['broadcast_clarification']?:823}")
    private int broadcastClarificationLinkId;
    @Value("#{etenderAuditTrailProperties['getBroadcast']}")
    private String getBroadcastRemarks;
    @Value("#{etenderAuditTrailProperties['getBroadcastPage']}")
    private String getBroadcastPage;
    @Value("#{etenderAuditTrailProperties['saveBroadcastClarification']}")
    private String saveBroadcastClarificationRemarks;
    @Value("#{etenderAuditTrailProperties['postBroadcastClarification']}")
    private String postBroadcastClarificationRemarks;
    @Value("#{projectProperties['rci_client_ids']}")
    private String rciClientIds;
        /**
     * To view create seek clarification page
     *
     * @Author Shreyansh.shah
     * @param tenderId
     * @param questionId
     * @param modelMap
     * @param request
     * @return
     */
        @RequestMapping(value = "/buyer/createSeekClarificationQueryView/{tenderId}/{envelopeId}/{companyId}/{questionId}/{clarificationId}/{envelopeType}/{sortOrder}/{isEvalDone}/{configType}/{enc}", method = RequestMethod.GET)
    public String createSeekClarificationQueryView(@PathVariable(TENDER_ID) int tenderId,@PathVariable(ENVELOPE_ID) int envelopeId,@PathVariable(COMPANY_ID) int companyId, @PathVariable("questionId") int questionId,@PathVariable("clarificationId") int clarificationId,@PathVariable(ENVELOPE_TYPE) int envelopeType,@PathVariable(SORT_ORDER) int sortOrder,@PathVariable(ISEVAL_DONE) String isEvalDone,@PathVariable(CONFIG_TYPE) int configType, ModelMap modelMap, HttpServletRequest request) {
        try {
            int eventId = 0;
            List<Object[]> eventIdlist = commonService.getEventIdFromLinkId(clarificatePostQueryLinkId);
            if (eventIdlist != null && !eventIdlist.isEmpty()) {
                eventId = (Integer) eventIdlist.get(0)[1];
            }
            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, abcUtility.getSessionClientId(request));
            int allowedSize = 0;
            StringBuilder allowedExt = new StringBuilder();
            if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
                allowedSize = lstDocUploadConf.get(0).getMaxSize();
                allowedExt.append(lstDocUploadConf.get(0).getType());
                modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
            }
            int index = allowedExt.toString().indexOf(",");
            allowedExt.insert(index + 1, "*.");
            while (index >= 0) {
                index = allowedExt.toString().indexOf(",", index + ",".length());
                allowedExt.insert(index + 1, "*.");
            }
            if(questionId!=0) {
            TblQuestion tblQuestion = prebidService.getQuestionById(questionId);
            modelMap.addAttribute("query", tblQuestion.getQuestionText());
            modelMap.addAttribute("isManDocReq", tblQuestion.getIsManDocReq());
            }
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> configureDateList=  seekClarificationService.getConfigureDateData(tenderId, envelopeId, companyId);
            modelMap.addAttribute("allowedExt", allowedExt);
            modelMap.addAttribute("allowedSize", allowedSize/1024);
            modelMap.addAttribute("cStatusDoc", 5);
            modelMap.addAttribute("linkId", clarificatePostQueryLinkId);
            modelMap.addAttribute("objectIdNew", questionId);
            modelMap.addAttribute("cStatusDocView", officerDocStatusApprove);
            modelMap.addAttribute("questionId", questionId);
            modelMap.addAttribute("allowFileExist","Y");
            if(configureDateList!=null && !configureDateList.isEmpty()) {
            	Object[] listData = configureDateList.get(0);   
             	if(listData[2]!=null){
            	listData[2] = AbcUtility.reverseReplaceSpecialChars(listData[2].toString());
             	}
                modelMap.addAttribute("configureDateList",listData);
            }
            //Add mandatory doc selection - start
            List<SelectItem> lstYesNo = new ArrayList<SelectItem>();
            lstYesNo.add(new SelectItem(messageSource.getMessage("fields_tender_yes", null, LocaleContextHolder.getLocale()), "1"));
            lstYesNo.add(new SelectItem(messageSource.getMessage("fields_tender_no", null, LocaleContextHolder.getLocale()), "0"));
            modelMap.addAttribute("isDocReqlst", lstYesNo);
            modelMap.addAttribute("isSaveBtnEnable",commonService.isRCIClient(rciClientIds,abcUtility.getSessionClientId(request)));
            //end
            return "/etender/buyer/CreateSeekClarificationQuery";
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), questionId != 0 ? editQueryLinkId :  clarificatePostQueryLinkId, questionId != 0 ? getEditSeekClarification : getSeekClarification, tenderId, questionId);
        }
    }

    /**
     * To Submit query created by buyer Author Shreyansh shah
     * @param request
     * @param modelMap
     * @param redirectAttributes
     * @param tenderId
     * @return
     */
    @RequestMapping(value = "/buyer/postQuery", method = RequestMethod.POST)
    public String postQuery(HttpServletRequest request, ModelMap modelMap, RedirectAttributes redirectAttributes, @RequestParam("hdTenderId") int tenderId,@RequestParam("hdEnvelopeId") int envelopeId,@RequestParam("hdCompanyId") int companyId) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        boolean isSuccess = false;
        Map<String, Object> mailParams = new HashMap<String, Object>();
        int questionStatus = CommonUtility.checkValue(request.getParameter("txtQueryStatus"));
        int questionId = Integer.parseInt(request.getParameter("hdQuestionId"));
        int envelopeType = CommonUtility.checkValue(request.getParameter(HDENVELOPE_TYPE));
        int sortOrder = CommonUtility.checkValue(request.getParameter(HDSORT_ORDER));
        int configType = CommonUtility.checkValue(request.getParameter(HDCONFIG_TYPE)); 
        String isEvalDone = CommonUtility.checkNull(request.getParameter(HDISEVAL_DONE));
        int linkId = clarificatePostQueryLinkId;
        String auditMsg = postSeekClarification;
        String redirectMsg="";
        TblQuestion tblQuestion = new TblQuestion();
        if(questionStatus==0)
        {
        	redirectMsg = "msg_clarification_savequery_sucess";
        }
        else
        {
        	redirectMsg = "msg_clarification_updatequery_sucess";
        }
        String errorMsg="redirect_failure_common";
        List<Object> lstLoginId = null;
        try {
            String strQuery = CommonUtility.checkNull(request.getParameter("rtfQuery"));
            String eventType=StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
    		String tenderBrief=StringUtils.hasLength(request.getParameter("hdTenderBrief")) ? request.getParameter("hdTenderBrief") : "";
            int sessionUserId = abcUtility.getSessionUserId(request);
            if (sessionUserId != 0 && !strQuery.equals("")) {
                List<Object[]> configureDateList = seekClarificationService.getConfigureDateData(tenderId, envelopeId, companyId);
                int clarificationId = CommonUtility.checkValue(request.getParameter("hdClarificationId"));
                if (configureDateList != null && !configureDateList.isEmpty() && commonValidations.compareWithSysDate(conversionService.convert(configureDateList.get(0)[1], Date.class)) > 0) {
                    errorMsg = "msg_seek_clarification_time_over";
                } else {
                    if (questionId != 0) {
                        tblQuestion.setQuestionId(questionId);
                        tblQuestion.setCreatedOn(commonService.getServerDateTime());
                        linkId = editQueryLinkId;
                        auditMsg = postEditSeekClarification;
                    }
                    tblQuestion.setModuleType(CLARIFICATION_MODULE_TYPE);
                    tblQuestion.setParentQuestionId(0);
                    tblQuestion.setTblSubModule(new TblSubModule(seekClarificationSubModuleId));
                    tblQuestion.setCstatus(questionStatus);
                    tblQuestion.setQuestionText(strQuery);
                    tblQuestion.setObjectId(tenderId);
                    tblQuestion.setTblUserLogin(new TblUserLogin(sessionUserId));
                    tblQuestion.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
                    tblQuestion.setUserTypeId(abcUtility.getSessionUserTypeId(request));
                    tblQuestion.setParentId(clarificationId);
                    tblQuestion.setIsManDocReq(Integer.parseInt(request.getParameter("selIsMandatoryAll")));
                    tblQuestion.setCreatedOn(commonService.getServerDateTime());
                    isSuccess = prebidService.addTblQuestion(tblQuestion);
                    if (isSuccess) {
                        String txtHidDocIds = CommonUtility.checkNull(request.getParameter("txtHidDocIds"));
                        if (!"".equalsIgnoreCase(txtHidDocIds)) {
                            fileUploadService.updateOfficerDocsObjectId(txtHidDocIds, tblQuestion.getQuestionId());
                        }
                        if (questionStatus == 1) {
                            String userId = seekClarificationService.getUserIdClarificationId(clarificationId).toString();
                            auditMsg = postPublishQuery;
                            redirectMsg = "msg_clarification_postquery_sucess";
                            String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/responseQueryView/" + tenderId + "/"+ envelopeId+"/"+ companyId+"/"+envelopeType+"/"+sortOrder+"/"+isEvalDone+"/"+configType+"/"+tblQuestion.getQuestionId());
                            String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>";
                            MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
                            messageConfigDatabean.setQueueName(queueName);
                            messageConfigDatabean.setTemplateId(Integer.parseInt(seekClarificationTemplateId));
                            messageConfigDatabean.setUserId(abcUtility.getSessionUserId(request));
                            messageConfigDatabean.setClientId(abcUtility.getSessionClientId(request));
                            messageConfigDatabean.setObjectId(tenderId);
                            messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
                            messageConfigDatabean.setContextPath(request.getContextPath());
                            lstLoginId =committeeFormationService.getUserIdfromTECMembers(tenderId);
                            Set set = new HashSet(lstLoginId);
                            String CCEmailIds = set.toString().replace("[", "").replace("]", "");
                            messageConfigDatabean.setCc(CCEmailIds);
                            mailParams.put("EventType", eventType);
                            mailParams.put("EventId", tenderId);
                            mailParams.put("tenderId", tenderId);
                            mailParams.put("EventBrief", tenderBrief);
                            mailParams.put("Query", strQuery);
                            mailParams.put("DepName", tenderCommonService.getDeptNameByTenderId(tenderId));
                            mailParams.put("ResponseEndDate", CommonUtility.convertTimezoneToClientTimezone(configureDateList.get(0)[1]));
                            mailParams.put("link", hrefStr);
                            int clientId = abcUtility.getSessionClientId(request);
                            String DomainName="<a href=\"#\" onClick=\"viewMailLinkDetails(' " + clientService.getClientNameById (clientId) + " ');\">"+clientService.getClientNameById (clientId)+"</a>";
                            mailParams.put("URL", DomainName);
                            mailParams.put("DomainName", DomainName);
                            List<Object[]> bidderDatails = seekClarificationService.getLstCompanyName(clientId, String.valueOf(companyId));
                            for (Object[] loginIds : bidderDatails) {
                                mailParams.put("to", loginIds[1]);
                                mailParams.put("CompanyName", loginIds[0]);
                                messageConfigDatabean.setParamMap(mailParams);
                                messageQueueService.sendMessage(messageConfigDatabean);
                            }
                            linkId = publishClarificationLinkId;
                        }
                    }
                }
                StringBuilder redirectUrl = new StringBuilder();
                redirectUrl.append("redirect:/etender/buyer/viewClarificationQueries/").append(tenderId).append("/").append(envelopeId)
                .append("/").append(companyId).append("/").append(envelopeType).append("/").append(sortOrder).append("/")
                .append(isEvalDone).append("/").append(configType).append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
                retVal =  redirectUrl.toString();
            }
        } catch (Exception ex) {
            retVal = exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId ,auditMsg, tenderId, tblQuestion.getQuestionId());
        }
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectMsg : errorMsg);
        return retVal;
    }

    /**
     * To Display list of qualified bidders to post query
     * @param tenderId
     * @param envelopeId
     * @param envelopeType
     * @param sortOrder
     * @param isEvalDone
     * @param configType  1-Configure seek calrification, 2- Update Seek clarification, 3- view seek clarification
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/buyer/bidderwiseclaficationlist/{tenderId}/{envelopeId}/{envelopeType}/{sortOrder}/{isEvalDone}/{configType}/{enc}", method = RequestMethod.GET)
    public String bidderWiseClaricationList(@PathVariable(TENDER_ID) int tenderId, @PathVariable(ENVELOPE_ID) int envelopeId,@PathVariable(ENVELOPE_TYPE) int envelopeType,@PathVariable(SORT_ORDER) int sortOrder,@PathVariable(ISEVAL_DONE) String isEvalDone,@PathVariable(CONFIG_TYPE) int configType,HttpServletRequest request, ModelMap modelMap) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> bidderList = seekClarificationService.getEvaluateBidderList(tenderId, envelopeId, envelopeType, sortOrder);
            modelMap.addAttribute("currentDate", commonService.getServerDateTime());
            if(bidderList != null && bidderList.size() > 0) {
                modelMap.addAttribute("bidderList", bidderList);
            }
            int isReEvaluationReq = 0;
          	isReEvaluationReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isReEvaluationReq").toString());
          	if( isReEvaluationReq==1 && isEvalDone.equals("true")){
          		Integer[] ctatus={0};
          		List<TblTenderReevaluation> tblTenderreevaluation = tenderFormService.getTblTenderRevaluationStatusByEnvelopeId(tenderId,envelopeId, ctatus);
          		if(tblTenderreevaluation!=null && !tblTenderreevaluation.isEmpty() ){
          			modelMap.addAttribute("isEvalDone", false);
          		}else{
          			modelMap.addAttribute("isEvalDone", true);
          		}
          	}
            //Upload Document Start - Change Request #21416
            int eventId = 0;
            List<Object[]> eventIdlist = commonService.getEventIdFromLinkId(clarificatePostQueryLinkId);
            if (eventIdlist != null && !eventIdlist.isEmpty()) {
                eventId = (Integer) eventIdlist.get(0)[1];
            }
            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, abcUtility.getSessionClientId(request));
            int allowedSize = 0;
            StringBuilder allowedExt = new StringBuilder();
            if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
                allowedSize = lstDocUploadConf.get(0).getMaxSize();
                allowedExt.append(lstDocUploadConf.get(0).getType());
                modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
            }
            int index = allowedExt.toString().indexOf(",");
            allowedExt.insert(index + 1, "*.");
            while (index >= 0) {
                index = allowedExt.toString().indexOf(",", index + ",".length());
                allowedExt.insert(index + 1, "*.");
            }
//  			fileUploadService.getOfficerDocDetailsForRemove(0, linkId);
            modelMap.addAttribute("allowedExt", allowedExt);
            modelMap.addAttribute("allowedSize", allowedSize/1024);
            modelMap.addAttribute("cStatusDoc", 5);
            modelMap.addAttribute("linkId", clarificatePostQueryLinkId);
            modelMap.addAttribute("objectId", 0);
            modelMap.addAttribute("cStatusDocView", officerDocStatusApprove);
            modelMap.addAttribute("allowFileExist","Y");
            modelMap.addAttribute("isSaveBtnEnable",commonService.isRCIClient(rciClientIds,abcUtility.getSessionClientId(request)));
            //End
            
            List<SelectItem> lstYesNo = new ArrayList<SelectItem>();
            lstYesNo.add(new SelectItem(messageSource.getMessage("fields_tender_yes", null, LocaleContextHolder.getLocale()), "1"));
            lstYesNo.add(new SelectItem(messageSource.getMessage("fields_tender_no", null, LocaleContextHolder.getLocale()), "0"));
            modelMap.addAttribute("isDocReqlst", lstYesNo);
            
        } catch (Exception ex) { 
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), configType == 1 ? configureClarificationLinkId : configType == 2 ? updateClarificationLinkId : viewClarificationLinkId , qualifiedBiddersList, tenderId, 0);
        }
        return "/etender/buyer/SeekClarificationBidderList";
    }
    /**
     * To view of broadcast clarification 
     * @author Lipi Shah
     * @return 
     */
    @RequestMapping(value = "/buyer/bidderwisebraodcastview/{tenderId}/{clariBroadCastId}/{enc}", method = RequestMethod.GET)
    public String bidderwiseBraodcastView(@PathVariable(TENDER_ID) int tenderId,@PathVariable("clariBroadCastId") int clariBroadCastId,HttpServletRequest request, ModelMap modelMap) {
        try {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	List<Object[]> bidderList = seekClarificationService.getBroadcastBidders(clariBroadCastId);
            if(bidderList != null && bidderList.size() > 0) {
            	modelMap.addAttribute("bidderList", bidderList);
            }
            
        } catch (Exception ex) { 
            return exceptionHandlerService.writeLog(ex);
        } finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), configType == 1 ? configureClarificationLinkId : configType == 2 ? updateClarificationLinkId : viewClarificationLinkId , qualifiedBiddersList, tenderId, 0);
        	  auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), broadcastClarificationLinkId, getBroadcastClarificationRemarks, tenderId, 0);
        }
        return "/etender/buyer/bidderwiseBraodcastView";
    }
    /**
     * To view configure Date for seek clarification 
     * @Author Shreyansh shah
     * @param tenderId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/buyer/configuredate/{tenderId}/{envelopeId}/{companyId}/{userDetailsId}/{envelopeType}/{sortOrder}/{isEvalDone}/{configType}/{enc}", method = RequestMethod.GET)
    public String configureDate(@PathVariable(TENDER_ID) int tenderId,@PathVariable(ENVELOPE_ID) int envelopeId,@PathVariable(COMPANY_ID) int companyId,@PathVariable("userDetailsId") int userDetailsId,@PathVariable(ENVELOPE_TYPE) int envelopeType,@PathVariable(SORT_ORDER) int sortOrder,@PathVariable(ISEVAL_DONE) String isEvalDone,@PathVariable(CONFIG_TYPE) int configType, HttpServletRequest request, ModelMap modelMap) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            TblCompany tblCompany= seekClarificationService.getCompanyById(companyId);
            modelMap.addAttribute("companyName", tblCompany.getCompanyName());
            modelMap.addAttribute(OPER_TYPE, "create");
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), seekClarificationLinkId, getConfigureDates, tenderId, 0);
        }
        return "/etender/buyer/ConfigureSeekClarificationDate";
    }
    
     /**
     * To view configure Date for seek clarification 
     * @Author Shreyansh shah
     * @param tenderId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/buyer/editconfiguredate/{tenderId}/{envelopeId}/{companyId}/{userDetailsId}/{envelopeType}/{sortOrder}/{isEvalDone}/{configType}/{enc}", method = RequestMethod.GET)
    public String editConfigureDate(@PathVariable(TENDER_ID) int tenderId,@PathVariable(ENVELOPE_ID) int envelopeId,@PathVariable(COMPANY_ID) int companyId,@PathVariable("userDetailsId") int userDetailsId,@PathVariable(ENVELOPE_TYPE) int envelopeType,@PathVariable(SORT_ORDER) int sortOrder,@PathVariable(ISEVAL_DONE) String isEvalDone,@PathVariable(CONFIG_TYPE) int configType ,HttpServletRequest request, ModelMap modelMap) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> list = seekClarificationService.getConfigureDateData(tenderId, envelopeId, companyId);
            if(list != null && !list.isEmpty()) {
                modelMap.addAttribute("clarificationList", list.get(0));
            }
            modelMap.addAttribute("currentDate", commonService.getServerDateTime());
            modelMap.addAttribute(OPER_TYPE, "Edit");
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editClarificateDateLinkId, getEditConfigureDates, tenderId, 0);
        }
        return "/etender/buyer/ConfigureSeekClarificationDate";
    }

    /**
     * To post seekclarification configure date.
     * Author Shreyansh shah
     * @param request
     * @param modelMap
     * @param redirectAttributes
     * @param tenderId
     * @return 
     */
    @RequestMapping(value = "/buyer/postConfigureDate", method = RequestMethod.POST)
    public String saveConfigureDate(HttpServletRequest request, ModelMap modelMap, RedirectAttributes redirectAttributes, @RequestParam("hdTenderId") int tenderId,@RequestParam("hdEnvelopeId") int envelopeId,@RequestParam("hdCompanyId") int companyId) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        int questionId = 0;
        boolean isSuccess = false;
        TblSeekClarification tblSeekClarification = null;
        String clarificationId = request.getParameter("hdClarificationId");
        String editOrReconfig = StringUtils.hasLength(request.getParameter("hdDateConfig")) ? request.getParameter("hdDateConfig") : null;
        String responseEndDate = request.getParameter("txtResponseEndDate");
        int envelopeType = StringUtils.hasLength(request.getParameter(HDENVELOPE_TYPE)) ? Integer.parseInt(request.getParameter(HDENVELOPE_TYPE)) : 0;
        int sortOrder = StringUtils.hasLength(request.getParameter(HDSORT_ORDER)) ? Integer.parseInt(request.getParameter(HDSORT_ORDER)) : 0;
        int configType = StringUtils.hasLength(request.getParameter(HDCONFIG_TYPE)) ? Integer.parseInt(request.getParameter(HDCONFIG_TYPE)) : 0;
        String isEvalDone = StringUtils.hasLength(request.getParameter(HDISEVAL_DONE)) ? request.getParameter(HDISEVAL_DONE) : "";
        int editOrReconfigLinkId = seekClarificationLinkId;
        String editOrReconfigAuditTrail = postConfigureDates;
        String redirectMsg = "msg_clarification_date_sucess";
        try {
            if(abcUtility.getSessionUserId(request) != 0 && responseEndDate != null) {
                tblSeekClarification = new TblSeekClarification();
                    //seekClarificationService.updateOldConfigureDate(Integer.parseInt(clarificationId));
                int userDetailsId = StringUtils.hasLength(request.getParameter("hdUserDetailsId")) ? Integer.parseInt(request.getParameter("hdUserDetailsId")) : 0;
                tblSeekClarification.setTblTender(new TblTender(tenderId));
                tblSeekClarification.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
                tblSeekClarification.setTblCompany(new TblCompany(companyId));
                tblSeekClarification.setResponseEndDate(conversionService.convert(responseEndDate, Date.class));
                tblSeekClarification.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                tblSeekClarification.setTblUserDetail(new TblUserDetail(userDetailsId));
                tblSeekClarification.setIsActive(1);
                isSuccess = seekClarificationService.addTblSeekClarification(tblSeekClarification,clarificationId);
                if(isSuccess) {
                    StringBuilder redirectUrl = new StringBuilder();
                    if(editOrReconfig != null) {
                    editOrReconfigLinkId = editOrReconfig.equals("Edit") ? editClarificateDateLinkId : reconfigureClarificateDateLinkId;
                    editOrReconfigAuditTrail = editOrReconfig.equals("Edit") ? postEditConfigureDates : postReconfigureConfigureDates;
                    redirectMsg = editOrReconfig.equals("Edit") ? "msg_clarification_date_edit_sucess" : "msg_clarification_date_reconfigure_sucess";                        
                    redirectUrl.append("redirect:/etender/buyer/bidderwiseclaficationlist/").append(tenderId).append("/").append(envelopeId)
                            .append("/").append(envelopeType).append("/").append(sortOrder).append("/").append(isEvalDone).append("/")
                            .append(configType).append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
                        retVal = redirectUrl.toString();
                    } else {
                        redirectUrl.delete(0, redirectUrl.length());
                        redirectUrl.append("redirect:/etender/buyer/createSeekClarificationQueryView/").append(tenderId).append("/").append(envelopeId)
                        .append("/").append(companyId).append("/").append(questionId).append("/").append(tblSeekClarification.getClarificationId())
                        .append("/").append(envelopeType).append("/").append(sortOrder).append("/").append(isEvalDone).append("/").append(configType)
                        .append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));        
                        retVal = redirectUrl.toString();
                    }
                }
            }
        } catch (Exception ex) {
            retVal = exceptionHandlerService.writeLog(ex);
        } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editOrReconfigLinkId,editOrReconfigAuditTrail, tenderId, tblSeekClarification.getClarificationId());
        }
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectMsg : CommonKeywords.ERROR_MSG_KEY.toString());
        return retVal;
    }

    /**
     * View list of queries and response posted by bidder
     * @Author Shreyansh shah
     * @param tenderId
     * @param userId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/buyer/viewClarificationQueries/{tenderId}/{envelopeId}/{companyId}/{envelopeType}/{sortOrder}/{isEvalDone}/{configType}/{enc}", method = RequestMethod.GET)
    public String viewClarificationQueries(@PathVariable(TENDER_ID) int tenderId,@PathVariable(ENVELOPE_ID) int envelopeId,@PathVariable(COMPANY_ID) int companyId,@PathVariable(ENVELOPE_TYPE) int envelopeType,@PathVariable(SORT_ORDER) int sortOrder,@PathVariable(ISEVAL_DONE) String isEvalDone,@PathVariable(CONFIG_TYPE) int configType, HttpServletRequest request, ModelMap modelMap) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> list = seekClarificationService.getConfigureDateData(tenderId, envelopeId, companyId);
            if(list != null && !list.isEmpty()) {	
            	Object[] listData = list.get(0);   
             	if(listData[2]!=null){
            	listData[2] = AbcUtility.reverseReplaceSpecialChars(listData[2].toString());
             	}
                modelMap.addAttribute("configureDateList",listData);
            }
            modelMap.addAttribute("currentDate", commonService.getServerDateTime());
            modelMap.addAttribute("reportId", clarificationBuyerReportid);
            modelMap.addAttribute("editStatus", "1");
            reportGeneratorService.getReportConfigDetails(clarificationBuyerReportid, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewClarificateDateLinkId, viewBuyerQueriesList, tenderId, 0);
        }
        return "/etender/common/ViewSeekClarificationQueries";
    }

    /**
     * To view query and response in details
     * @Author Shreyansh shah
     * @param questionId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/buyer/viewQuestionAnswer/{tenderId}/{questionId}/{companyId}/{envelopeId}/{enc}", method = RequestMethod.GET)
    public String viewQuestionAnswer(@PathVariable("tenderId") int tenderId,@PathVariable("questionId") int questionId, @PathVariable(COMPANY_ID) int companyId,@PathVariable("envelopeId") int envelopeId,HttpServletRequest request, ModelMap modelMap) {
        try {
             int answerId = 0;
            List<Object[]> questionAnswer = prebidService.getQuestionAnswerByQuestionId(questionId,1);
            if(questionAnswer != null && !questionAnswer.isEmpty()) {
                modelMap.addAttribute("questionAns", questionAnswer.get(0));
                answerId =  questionAnswer.get(0)[4] != null ? Integer.parseInt(questionAnswer.get(0)[4].toString()) : 0;
            }
            List<Object[]> bidderDocList = null;
            if(answerId != 0) {
                bidderDocList = fileUploadService.getBidderDocsWithChildId(answerId, abcUtility.getSessionClientId(request), bidderReplyLinkId, 1,0,"0",envelopeId);
            }
            if(clientService.getCompanyNamebySeekclarification(tenderId,companyId)!=null)
            {
            	modelMap.addAttribute("CompanyName", clientService.getCompanyNamebySeekclarification(tenderId,companyId));
            }
            modelMap.addAttribute("cStatusDocView", officerDocStatusApprove);
            modelMap.addAttribute("questionLinkId", clarificatePostQueryLinkId);
            modelMap.addAttribute("answerLinkId", bidderReplyLinkId);
            modelMap.addAttribute("isReadOnly", "Y");
            modelMap.addAttribute("buyerDocList", fileUploadService.getOfficerDocs(questionId, abcUtility.getSessionClientId(request), clarificatePostQueryLinkId, 1));
            modelMap.addAttribute("bidderDocList", bidderDocList);
            modelMap.addAttribute("isPopUp","Y");
            modelMap.addAttribute("reportId", clarificationBuyerReportid);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewQueryLinkId, viewDetailQuery, tenderId, 0);
        }
        return "/etender/common/ViewSeekClarificationQueAns";
    }
    
     /**
     * To view configure Date for seek clarification 
     * @Author Shreyansh shah
     * @param tenderId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/buyer/reconfiguredate/{tenderId}/{envelopeId}/{companyId}/{userDetailsId}/{envelopeType}/{sortOrder}/{isEvalDone}/{configType}/{enc}", method = RequestMethod.GET)
    public String reconfiguredate(@PathVariable(TENDER_ID) int tenderId,@PathVariable(ENVELOPE_ID) int envelopeId,@PathVariable(COMPANY_ID) int companyId,@PathVariable("userDetailsId") int userDetailsId,@PathVariable(ENVELOPE_TYPE) int envelopeType,@PathVariable(SORT_ORDER) int sortOrder,@PathVariable(ISEVAL_DONE) String isEvalDone,@PathVariable(CONFIG_TYPE) int configType ,HttpServletRequest request, ModelMap modelMap) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> list = seekClarificationService.getConfigureDateData(tenderId, envelopeId, companyId);
            if(list != null && !list.isEmpty()) {
                modelMap.addAttribute("clarificationList", list.get(0));
            }
            modelMap.addAttribute(OPER_TYPE, "Reconfig");
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), reconfigureClarificateDateLinkId, getReconfigureConfigureDates, tenderId, 0);
        }
        return "/etender/buyer/ConfigureSeekClarificationDate";
    }
      
    /**
     * To configure seek clarification broadcast
     * @Author Lipi Shah
     * @return 
     */
    @RequestMapping(value="/buyer/broadcastbidderclarifications",method= RequestMethod.POST)
    public String broadcastBidderClarifications(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String userDetailsId[];
            boolean isSuccess = false;
            boolean isFlag=false;
            int tenderId = 0;
            int questionStatus = 0;
            String redirectMsg="";
            String retVal = REDIRECT_SESSION_EXPIRED;
            try {
            	if (abcUtility.getSessionUserId(request) != 0) {
	                userDetailsId = request.getParameterValues("UserDetailsIds");//CompanyId@@UserDetailsId
	                tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))?Integer.parseInt(request.getParameter("hdTenderId")):0;
	                int envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId"))?Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
	                String docMapIds = StringUtils.hasLength(request.getParameter("txtHidDocIds"))? request.getParameter("txtHidDocIds") :"";
	                questionStatus = StringUtils.hasLength(request.getParameter("txtQueryStatus"))?Integer.parseInt(request.getParameter("txtQueryStatus")):0;
	                String strQuery = StringUtils.hasLength(request.getParameter("rtfQuery"))?request.getParameter("rtfQuery"):"";
	                String eventType=StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
	                String tenderBrief=StringUtils.hasLength(request.getParameter("hdTenderBrief")) ? request.getParameter("hdTenderBrief") : "";
	                int envelopeType = StringUtils.hasLength(request.getParameter(HDENVELOPE_TYPE)) ? Integer.parseInt(request.getParameter(HDENVELOPE_TYPE)) : 0;
			        int sortOrder = StringUtils.hasLength(request.getParameter(HDSORT_ORDER)) ? Integer.parseInt(request.getParameter(HDSORT_ORDER)) : 0;
			        int configType = StringUtils.hasLength(request.getParameter(HDCONFIG_TYPE)) ? Integer.parseInt(request.getParameter(HDCONFIG_TYPE)) : 0;
			        String isEvalDone = StringUtils.hasLength(request.getParameter(HDISEVAL_DONE)) ? request.getParameter(HDISEVAL_DONE) : "";
			        List<TblSeekClarification> tblSeekClarificationList = new ArrayList<TblSeekClarification>();
		        	List<TblQuestion> tblQuestionList = new ArrayList<TblQuestion>();
		        	List<TblBroadCastQuestionMapping> tblBroadCastQuestionMappingList = new ArrayList<TblBroadCastQuestionMapping>();
		        	TblClarificationBroadCast tblClarificationBroadCast = new TblClarificationBroadCast();
		        	Map<String, Object> mailParams = new HashMap<String, Object>();
		        	int questionIDD=0;
//		        	List<TblClarificationBroadCast> tblClarificationBroadCastLst = new ArrayList<TblClarificationBroadCast>();
		        	List<Object> lstLoginId = null;
		        	int clarificationBroadCastId = 0;
		        	String clarificationId = null;
		        	tblClarificationBroadCast.setTblTender(new TblTender(tenderId));
                	tblClarificationBroadCast.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
                	tblClarificationBroadCast.setQuestionText(strQuery);
                	tblClarificationBroadCast.setCstatus(questionStatus);
                	tblClarificationBroadCast.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                	tblClarificationBroadCast.setCreatedOn(commonService.getServerDateTime());
                	if(questionStatus == 1){//publish case
                		tblClarificationBroadCast.setPublishedBy(abcUtility.getSessionUserDetailId(request));
                		tblClarificationBroadCast.setPublishedOn(commonService.getServerDateTime());
                	}
                	 if(questionStatus == 1){
                		 redirectMsg="msg_clarifications";
                	 }
                	 else{
                		 redirectMsg = "msg_clarification_savequery_sucess";
                	 }
                	isSuccess = seekClarificationService.addTblClarificationBroadCast(tblClarificationBroadCast);//tender wise entry
                	List<Object[]> lstResoponseDate = new ArrayList<Object[]>();
			        if (isSuccess && userDetailsId != null) {
			        	for (int count = 0; count < userDetailsId.length; count++) {
			        		int companyId = Integer.parseInt(userDetailsId[count].split("@@")[0]);
			        		int userDetailId = Integer.parseInt(userDetailsId[count].split("@@")[1]);
			        		clarificationBroadCastId = tblClarificationBroadCast.getClariBroadCastId();
                        	tblSeekClarificationList = seekClarificationService.getSeekClarificationDtls(tenderId,envelopeId,companyId);
                        	if(questionStatus!=0)
                        	{
                        		if (commonValidations.compareWithSysDate(conversionService.convert(request.getParameter("txtResponseEndDate_"+companyId), Date.class)) > 0)
                        		{
                        			isFlag=true;
                        			break;                        		
                        		}
                        	}
                        	if(tblSeekClarificationList == null || tblSeekClarificationList.size() == 0){
                        		clarificationId = null;
	                            TblSeekClarification tblSeekClarification = new TblSeekClarification();
	                            tblSeekClarification.setTblTender(new TblTender(tenderId));
	                            tblSeekClarification.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
	                            tblSeekClarification.setTblCompany(new TblCompany(companyId));
	                            tblSeekClarification.setTblUserDetail(new TblUserDetail(userDetailId));
	                            tblSeekClarification.setResponseEndDate(conversionService.convert(request.getParameter("txtResponseEndDate_"+companyId), Date.class));
	                            tblSeekClarification.setCreatedBy(abcUtility.getSessionUserDetailId(request));
	                            tblSeekClarification.setIsActive(1);//remove column
//	                            tblSeekClarificationList.add(tblSeekClarification);//bidder wise
	                            seekClarificationService.addTblSeekClarification(tblSeekClarification,clarificationId);//add SeekClarification
	                            clarificationId = String.valueOf(tblSeekClarification.getClarificationId());
                        	}else{
                        		clarificationId = String.valueOf(tblSeekClarificationList.get(0).getClarificationId());
                        	}
                        	List<Object[]> configureDateList=  seekClarificationService.getConfigureDateData(tenderId, envelopeId, companyId);
                        	lstResoponseDate.add(new Object[]{configureDateList.get(0)[1],companyId});
                        	TblQuestion tblQuestion = new TblQuestion();
        	        		tblQuestion.setModuleType(CLARIFICATION_MODULE_TYPE);
        	        		tblQuestion.setParentQuestionId(0);
        	        		tblQuestion.setTblSubModule(new TblSubModule(seekClarificationSubModuleId));
        	        		tblQuestion.setCstatus(questionStatus);
        	        		tblQuestion.setQuestionText(strQuery);
        	        		tblQuestion.setObjectId(tenderId);
        	        		tblQuestion.setTblUserLogin(new TblUserLogin(abcUtility.getSessionUserId(request)));
        	        		tblQuestion.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
        	        		tblQuestion.setUserTypeId(abcUtility.getSessionUserTypeId(request));
        	        		tblQuestion.setParentId(Integer.parseInt(clarificationId));//seek clarification id
        	        		tblQuestion.setIsManDocReq(Integer.parseInt(request.getParameter("selIsMandatoryAll_"+companyId)));
        	        		tblQuestionList.add(tblQuestion);//
                    }
                }
			    if(isFlag==true)
			    {
			    	isSuccess=false;
			    	String errorMsg = "msg_seek_clarification_time_over";
            		StringBuilder redirectUrl = new StringBuilder();
                    redirectUrl.append("redirect:/etender/buyer/bidderwiseclaficationlist/").append(tenderId).append("/").append(envelopeId)
                                .append("/").append(envelopeType).append("/").append(sortOrder).append("/").append(isEvalDone).append("/")
                                .append(configType).append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
                    retVal = redirectUrl.toString();
                    redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectMsg : errorMsg);
        			return retVal;
        			
			    }
//	        	isSuccess = seekClarificationService.addTblSeekClarification(tblSeekClarificationList);
		        if(isSuccess && tblQuestionList != null && !tblQuestionList.isEmpty()){
		        	isSuccess = prebidService.addTblQuestion(tblQuestionList);//add Question
                	for(TblQuestion question : tblQuestionList){
                		TblBroadCastQuestionMapping tblBroadCastQuestionMapping = new TblBroadCastQuestionMapping();
                    	tblBroadCastQuestionMapping.setTblClarificationBroadCast(new TblClarificationBroadCast(clarificationBroadCastId));
                    	tblBroadCastQuestionMapping.setTblQuestion(new TblQuestion(question.getQuestionId()));
                    	questionIDD=question.getQuestionId();
                    	tblBroadCastQuestionMappingList.add(tblBroadCastQuestionMapping);
                	}
		        }
		        if(isSuccess && tblBroadCastQuestionMappingList != null && !tblBroadCastQuestionMappingList.isEmpty()){
		        	isSuccess = seekClarificationService.addTblBroadCastQuestionMapping(tblBroadCastQuestionMappingList);//add mapping
		        }
		        if(questionStatus==1 && lstResoponseDate!= null && !lstResoponseDate.isEmpty()){
		        	
		        	lstLoginId =committeeFormationService.getUserIdfromTECMembers(tenderId);
		        	Set set = new HashSet(lstLoginId);
		        	MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
                    messageConfigDatabean.setQueueName(queueName);
                    messageConfigDatabean.setTemplateId(Integer.parseInt(seekClarificationTemplateId));
                    messageConfigDatabean.setUserId(abcUtility.getSessionUserId(request));
                    messageConfigDatabean.setClientId(abcUtility.getSessionClientId(request));
                    messageConfigDatabean.setObjectId(tenderId);
                    messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
                    messageConfigDatabean.setContextPath(request.getContextPath());
                    String CCEmailIds = set.toString().replace("[", "").replace("]", "");
                    messageConfigDatabean.setCc(CCEmailIds);
                    mailParams.put("EventType", eventType);
                    mailParams.put("EventId", tenderId);
                    mailParams.put("tenderId", tenderId);
	                mailParams.put("EventBrief", tenderBrief);
	                mailParams.put("Query", strQuery);
	                mailParams.put("DepName", tenderCommonService.getDeptNameByTenderId(tenderId));
	                int clientId = abcUtility.getSessionClientId(request);
	                String DomainName="<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + clientService.getClientNameById (clientId) + " ');\">"+clientService.getClientNameById (clientId)+"</a>";
                    mailParams.put("DomainName", DomainName);
	                for(int i=0;i<lstResoponseDate.size();i++)
		        	{
	                	mailParams.put("ResponseEndDate", CommonUtility.convertTimezoneToClientTimezone(lstResoponseDate.get(i)[0]));
		                List<Object[]> bidderDatails = seekClarificationService.getLstCompanyName(clientId, String.valueOf(lstResoponseDate.get(i)[1]));
	                	mailParams.put("to", bidderDatails.get(0)[1]);
	                    mailParams.put("CompanyName", bidderDatails.get(0)[0]);
	                    TblQuestion tblQuestion = new TblQuestion();
	                    String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/responseQueryView/" + tenderId + "/"+ envelopeId+"/"+ lstResoponseDate.get(i)[1].toString()+"/"+envelopeType+"/"+sortOrder+"/"+isEvalDone+"/"+configType+"/"+questionIDD);
			        	String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>";
			        	mailParams.put("link", hrefStr);
	                    messageConfigDatabean.setParamMap(mailParams);
	                    messageQueueService.sendMessage(messageConfigDatabean);
		        	}
		        }
		        if (StringUtils.hasLength(docMapIds)) {
		        	int queCnt = 0;
		        	int officerDocId =0;
		        	for(TblQuestion question : tblQuestionList){
		        		if(queCnt ==0){
		        			fileUploadService.updateOfficerDocsObjectId(docMapIds,question.getQuestionId(), 1);
		        		}else{
		        			TblOfficerDocMapping tblOfficerDocMapping = new TblOfficerDocMapping();
		        			String newdocMapIds [] = {};
		        			if(docMapIds.contains(",")){
		        				newdocMapIds = docMapIds.split(",");
		        			}else{
		        				officerDocId = fileUploadService.getOfficerDocId(Integer.parseInt(docMapIds));//single doc
		        				tblOfficerDocMapping.setTblOfficerDocument(new TblOfficerDocument((officerDocId)));
		        			}
		        			if(newdocMapIds.length > 0){
		        				for(String docMapId : newdocMapIds){
		        					tblOfficerDocMapping = new TblOfficerDocMapping();
				        			tblOfficerDocMapping.setApprovedBy(abcUtility.getSessionUserDetailId(request));
				        			tblOfficerDocMapping.setApprovedOn(commonService.getServerDateTime());
				        			tblOfficerDocMapping.setCstatus(1);
				        			tblOfficerDocMapping.setMappedBy(abcUtility.getSessionUserId(request));
				        			tblOfficerDocMapping.setMappedOn(commonService.getServerDateTime());
				        			tblOfficerDocMapping.setChildId(0);
				        			tblOfficerDocMapping.setTblLink(new TblLink(clarificatePostQueryLinkId));
				        			tblOfficerDocMapping.setObjectId(question.getQuestionId());
		        					tblOfficerDocMapping.getOfficerDocMappingId();
		        					officerDocId = fileUploadService.getOfficerDocId(Integer.parseInt(docMapId));
		        					tblOfficerDocMapping.setTblOfficerDocument(new TblOfficerDocument((officerDocId)));
		        					fileUploadService.addOfficerDocMapping(tblOfficerDocMapping);
		        				}
		        			}else{
		        				tblOfficerDocMapping.setApprovedBy(abcUtility.getSessionUserDetailId(request));
			        			tblOfficerDocMapping.setApprovedOn(commonService.getServerDateTime());
			        			tblOfficerDocMapping.setCstatus(1);
			        			tblOfficerDocMapping.setMappedBy(abcUtility.getSessionUserId(request));
			        			tblOfficerDocMapping.setMappedOn(commonService.getServerDateTime());
			        			tblOfficerDocMapping.setChildId(0);
			        			tblOfficerDocMapping.setTblLink(new TblLink(clarificatePostQueryLinkId));
			        			tblOfficerDocMapping.setObjectId(question.getQuestionId());
		        				fileUploadService.addOfficerDocMapping(tblOfficerDocMapping);
		        			}
		        		}
		        		queCnt++;
		        	}
				}
                StringBuilder redirectUrl = new StringBuilder();
                redirectUrl.append("redirect:/etender/buyer/bidderwiseclaficationlist/").append(tenderId).append("/").append(envelopeId)
                            .append("/").append(envelopeType).append("/").append(sortOrder).append("/").append(isEvalDone).append("/")
                            .append(configType).append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
                retVal = redirectUrl.toString();
            }
        } catch (Exception ex) {
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), (questionStatus == 1 ? publishBroadCastClarificationLinkId : configureBroadCastClarificationLinkId), (questionStatus == 1 ? postBroadcastClarificationRemarks : saveBroadcastClarificationRemarks), tenderId, 0);
        }
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectMsg : CommonKeywords.ERROR_MSG_KEY.toString());
        return retVal;
    }
    /**
     * To get list of seek clarification broadcast
     * @Author Lipi Shah
     * @return 
     */
    @RequestMapping(value = "/buyer/getbroadcastclarification/{tenderId}/{envelopeId}/{envelopeType}/{sortOrder}/{isEvalDone}/{configType}/{enc}", method = RequestMethod.GET)
    public String getBroadcastClarification(@PathVariable(TENDER_ID) int tenderId,@PathVariable(ENVELOPE_ID) int envelopeId,@PathVariable(ENVELOPE_TYPE) int envelopeType,@PathVariable(SORT_ORDER) int sortOrder,@PathVariable(ISEVAL_DONE) String isEvalDone,@PathVariable(CONFIG_TYPE) int configType,HttpServletRequest request, ModelMap modelMap) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("broadcastdtls", seekClarificationService.getBoradcastClarificationDtls(tenderId, envelopeId));
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), publishBroadcastListLinkId, getBroadcastPage, tenderId, 0);
        }
        return "/etender/buyer/BroadCastDtls";
    }
    
    /**
     * Publish list of seek clarification broadcast
     * @Author Lipi Shah
     * @return 
     */
    @RequestMapping(value = "/buyer/publishbroadcastclarification", method = RequestMethod.POST)
    public String publishBroadcastClarification(HttpServletRequest request, ModelMap modelMap, RedirectAttributes redirectAttributes) {
    	String retVal = REDIRECT_SESSION_EXPIRED;
    	boolean isSuccess =false;
    	boolean isFlag =false;
    	String errorMsg ="";
    	int tenderId = CommonUtility.checkValue(request.getParameter("hdTenderId"));
        try {
        	int envelopeType = StringUtils.hasLength(request.getParameter(HDENVELOPE_TYPE)) ? Integer.parseInt(request.getParameter(HDENVELOPE_TYPE)) : 0;
	        int sortOrder = StringUtils.hasLength(request.getParameter(HDSORT_ORDER)) ? Integer.parseInt(request.getParameter(HDSORT_ORDER)) : 0;
	        int configType = StringUtils.hasLength(request.getParameter(HDCONFIG_TYPE)) ? Integer.parseInt(request.getParameter(HDCONFIG_TYPE)) : 0;
	        String isEvalDone = StringUtils.hasLength(request.getParameter(HDISEVAL_DONE)) ? request.getParameter(HDISEVAL_DONE) : "";
        	int envelopeId = CommonUtility.checkValue(request.getParameter("hdEnvelopeId"));
            String eventType=StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
    		String tenderBrief=StringUtils.hasLength(request.getParameter("hdTenderBrief")) ? request.getParameter("hdTenderBrief") : "";
        	String clariBroadCastId[] = request.getParameterValues("BroadcastIds");
        	Integer clariBroadCastIds[] = new Integer[clariBroadCastId.length];
        	int i = 0;
        	List<Object[]> responseEndDateandCompayDetails=new ArrayList<Object[]>();
        	for(String idVal : clariBroadCastId){
        		clariBroadCastIds[i] = Integer.parseInt(idVal);
        		responseEndDateandCompayDetails.addAll(seekClarificationService.getResponseEndDateandCompayDetails(clariBroadCastIds[i]));
        		i++;
        	}
        	for(int j=0;j<responseEndDateandCompayDetails.size();j++)
        		{
	        		Date temp_Date=dateUtils.convertStringtoDate(responseEndDateandCompayDetails.get(j)[3].toString(),"yyyy-MM-dd HH:mm:ss.SS");
	        		String temp_StrDate=dateUtils.convertStringtoDate(temp_Date,"yyyy-MM-dd HH:mm:ss");
	        		Date finalDate=dateUtils.convertStringtoDate(temp_StrDate,"yyyy-MM-dd HH:mm:ss");
	        		if (responseEndDateandCompayDetails != null && !responseEndDateandCompayDetails.isEmpty() && commonValidations.compareWithSysDate(finalDate)>0) {
        				isFlag=true;
        				break;
                    }
        		}
        	if(isFlag==true)
        	{
        		isSuccess=false;
        		errorMsg = "msg_seek_clarification_time_over";
        		StringBuilder redirectUrl = new StringBuilder();
                redirectUrl.append("redirect:/etender/buyer/getbroadcastclarification/").append(tenderId).append("/").append(envelopeId)
                            .append("/").append(envelopeType).append("/").append(sortOrder).append("/").append(isEvalDone).append("/")
                                .append(configType).append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
                retVal = redirectUrl.toString();
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), publishBroadcastListLinkId, getBroadcastRemarks, tenderId, 0);
                redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_clarification_postquery_sucess" : errorMsg);
    			return retVal;
        	}
        	else
        	{
        		List<TblClarificationBroadCast> tblClarificationBroadCastList= seekClarificationService.getBoradcastClarificationDtls(tenderId, envelopeId);
            	TblClarificationBroadCast tblClarificationBroadCast = null; 
            	int isBoradClari = 0;
            	List<String> query = new ArrayList<String>();
            	for(int j=0;j<tblClarificationBroadCastList.size();j++){
            		tblClarificationBroadCast = new TblClarificationBroadCast();
            		tblClarificationBroadCast = tblClarificationBroadCastList.get(j);
            		isBoradClari = StringUtils.hasLength(request.getParameter("chkIsBoradClariAll_"+tblClarificationBroadCast.getClariBroadCastId())) ? Integer.parseInt(request.getParameter("chkIsBoradClariAll_"+tblClarificationBroadCast.getClariBroadCastId())) : 0;
            		if(isBoradClari == 1){
            			query.add(tblClarificationBroadCast.getQuestionText());
            		}
            	}
            	List<Object> lstLoginId = null;
            	isSuccess = seekClarificationService.updateBoradcastClarification(clariBroadCastIds);
            	lstLoginId =committeeFormationService.getUserIdfromTECMembers(tenderId);
            	Set set = new HashSet(lstLoginId);
            	MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
                messageConfigDatabean.setQueueName(queueName);
                messageConfigDatabean.setTemplateId(Integer.parseInt(seekClarificationTemplateId));
                messageConfigDatabean.setUserId(abcUtility.getSessionUserId(request));
                messageConfigDatabean.setClientId(abcUtility.getSessionClientId(request));
                messageConfigDatabean.setObjectId(tenderId);
                messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
                messageConfigDatabean.setContextPath(request.getContextPath());
                String CCEmailIds = set.toString().replace("[", "").replace("]", "");
                messageConfigDatabean.setCc(CCEmailIds);
                Map<String, Object> mailParams = new HashMap<String, Object>();
                mailParams.put("EventType", eventType);
                mailParams.put("EventId", tenderId);
                mailParams.put("tenderId", tenderId);
                mailParams.put("EventBrief", tenderBrief);
                mailParams.put("DepName", tenderCommonService.getDeptNameByTenderId(tenderId));
                int clientId = abcUtility.getSessionClientId(request);
                String DomainName="<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + clientService.getClientNameById (clientId) + " ');\">"+clientService.getClientNameById (clientId)+"</a>";
                mailParams.put("DomainName", DomainName);
                for(int m=0;m<responseEndDateandCompayDetails.size();m++)
            	{
                	mailParams.put("ResponseEndDate", CommonUtility.convertTimezoneToClientTimezone(responseEndDateandCompayDetails.get(m)[3]));
                	mailParams.put("Query", responseEndDateandCompayDetails.get(m)[4]);
                    List<Object[]> bidderDatails = seekClarificationService.getLstCompanyName(clientId, String.valueOf(responseEndDateandCompayDetails.get(m)[1]));
                	mailParams.put("to", bidderDatails.get(0)[1]);
                    mailParams.put("CompanyName", bidderDatails.get(0)[0]);
                    String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/responseQueryView/" + tenderId + "/"+ envelopeId+"/"+ responseEndDateandCompayDetails.get(m)[1].toString()+"/"+envelopeType+"/"+sortOrder+"/"+isEvalDone+"/"+configType+"/"+responseEndDateandCompayDetails.get(m)[5].toString());
    	        	String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>";
    	        	mailParams.put("link", hrefStr);
                    messageConfigDatabean.setParamMap(mailParams);
                    messageQueueService.sendMessage(messageConfigDatabean);
                    StringBuilder redirectUrl = new StringBuilder();
                    redirectUrl.append("redirect:/etender/buyer/getbroadcastclarification/").append(tenderId).append("/").append(envelopeId)
                                .append("/").append(envelopeType).append("/").append(sortOrder).append("/").append(isEvalDone).append("/")
                                    .append(configType).append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
                    retVal = redirectUrl.toString();
            	}
        	}
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), publishBroadcastListLinkId, getBroadcastRemarks, tenderId, 0);
        }
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_clarification_postquery_sucess" : CommonKeywords.ERROR_MSG_KEY.toString());
        return retVal;
    }
    
    /**
     * View list of queries and response posted by bidder
     * @Author Khurshid
     * @param tenderId
     * @param userId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/buyer/viewReportClarificationQueries/{tenderId}/{envelopeId}/{companyId}/{envelopeType}/{sortOrder}/{isEvalDone}/{configType}/{enc}", method = RequestMethod.GET)
    public String viewReportClarificationQueries(@PathVariable(TENDER_ID) int tenderId,@PathVariable(ENVELOPE_ID) int envelopeId,@PathVariable(COMPANY_ID) int companyId,@PathVariable(ENVELOPE_TYPE) int envelopeType,@PathVariable(SORT_ORDER) int sortOrder,@PathVariable(ISEVAL_DONE) String isEvalDone,@PathVariable(CONFIG_TYPE) int configType, HttpServletRequest request, ModelMap modelMap) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> list = seekClarificationService.getConfigureDateData(tenderId, envelopeId, companyId);
            if(list != null && !list.isEmpty()) {	
            	Object[] listData = list.get(0);   
             	if(listData[2]!=null){
            	listData[2] = AbcUtility.reverseReplaceSpecialChars(listData[2].toString());
             	}
                modelMap.addAttribute("configureDateList",listData);
            }
            modelMap.addAttribute("currentDate", commonService.getServerDateTime());
            modelMap.addAttribute("reportId", clarificationBuyerReportid);
            modelMap.addAttribute("editStatus", "0");
            reportGeneratorService.getReportConfigDetails(clarificationBuyerReportid, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewClarificateDateLinkId, viewBuyerQueriesList, tenderId, 0);
        }
        return "/etender/common/ViewSeekClarificationQueries";
    }
    
    
    /**
     * get detailed documents for Seek clarification response by bidder
     * @param tenderId
     * @param parentId
     * @param companyId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/ajax/getclarificationDocDetails", method = RequestMethod.POST)
    public String getclarificationDocDetails(@RequestParam("txttenderId") int tenderId,@RequestParam("txtcompanyId") int companyId,HttpServletRequest request,ModelMap modelMap) {
        String returnStr=REDIRECT_SESSION_EXPIRED;
        try {
            if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            	List<Object[]> singleUserDocumentDetailsfinal=new LinkedList<Object[]>();
            	if(companyId!=0){
                    List<Object[]> singleClarificationDoclist = seekClarificationService.getDocDetails(tenderId, companyId);
                    if(null != singleClarificationDoclist && !singleClarificationDoclist.isEmpty() && ((Byte)singleClarificationDoclist.get(0)[2]!=0)){
                     for(Object[] ansQuestionIdArray : singleClarificationDoclist){
                        List<Object[]> singleUserDocumentDetails =seekClarificationService.getBidderClarificationDocsLink((Integer) ansQuestionIdArray[0],abcUtility.getSessionClientId(request),""+bidderReplyLinkId,1,companyId,(Integer) ansQuestionIdArray[1]);
                        if(singleUserDocumentDetails!=null && !singleUserDocumentDetails.isEmpty()){
                        	singleUserDocumentDetailsfinal.addAll(singleUserDocumentDetails);
                        	}  
                     	}
                    }
                     modelMap.addAttribute("singleUserDocumentDetails",singleUserDocumentDetailsfinal);
                     returnStr = "/common/ClarificationAnsDocHistory";
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } 
        finally {
        	 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewClarificateDateLinkId, viewBuyerQueriesList, tenderId, 0);
        }
        return returnStr;
    }
    
}
