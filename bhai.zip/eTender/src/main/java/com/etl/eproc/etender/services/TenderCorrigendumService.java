/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import org.jsoup.Jsoup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblCorrigendumViewHistoryDao;
import com.etl.eproc.common.daostoredprocedure.SpKeywordOperation;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientCPPPConfig;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblCorrigendumViewHistory;
import com.etl.eproc.common.model.TblCurrency;
import com.etl.eproc.common.model.TblEventPayment;
import com.etl.eproc.common.model.TblPaymentType;
import com.etl.eproc.common.model.TblProcess;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.etender.daointerface.TblCorrigendumDao;
import com.etl.eproc.etender.daointerface.TblCorrigendumDetailDao;
import com.etl.eproc.etender.daointerface.TblTenderCurrencyDao;
import com.etl.eproc.etender.daointerface.TblTenderEnvelopeDao;
import com.etl.eproc.etender.daointerface.TblTenderFormDao;
import com.etl.eproc.etender.daointerface.TblTenderProxyBidDao;
import com.etl.eproc.etender.databean.TenderCorrigendumDetailDtBean;
import com.etl.eproc.etender.model.TblCommittee;
import com.etl.eproc.etender.model.TblCorrigendum;
import com.etl.eproc.etender.model.TblCorrigendumDetail;
import com.etl.eproc.etender.model.TblEnvelope;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderColumn;
import com.etl.eproc.etender.model.TblTenderCurrency;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderProxyBid;
import com.etl.eproc.etender.model.TblTenderTable;

/**
 *
 * @author urja
 */
@Service
public class TenderCorrigendumService {

    @Autowired
    private TblCorrigendumDao tblCorrigendumDao;
    @Autowired
    private TblCorrigendumDetailDao tblCorrigendumDetailDao;    
    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    @Autowired
    private EventCreationService eventCreationService;
    @Autowired
    private TblTenderFormDao tblTenderFormDao;   
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private TblTenderEnvelopeDao tblTenderEnvelopeDao;
    @Autowired
    private TblTenderCurrencyDao tblTenderCurrencyDao;
    @Autowired
    private ClientService clientService;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private TblTenderProxyBidDao tblTenderProxyBidDao;
    @Autowired
	private CommitteeFormationService committeeFormationService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private CommonService commonService;
    @Autowired
    private TblCorrigendumViewHistoryDao tblCorrigendumViewHistoryDao;
    
    @Value("#{tenderlinkProperties['tender_corrigendum_pending']}")
    private int tenderCorrigendumPending;
    @Value("#{tenderlinkProperties['corrigendum_upload']}")
    private int corrigendumUpload;
    private  static final String OBJECTID = "objectId";
    @Autowired
    private SpKeywordOperation spKeywordOperation;
    @Value("#{projectProperties['tender.eventid']?:63}")
    private int tenderEventId;
  

    /**
     * @author urja
     * @param tblCorrigendum
     * @return
     * @throws Exception
     */
    public boolean createCorrigendum(TblCorrigendum tblCorrigendum) throws Exception {
//        tblCorrigendumDao.addTblCorrigendum(tblCorrigendum);
    	tblCorrigendumDao.saveOrUpdateTblCorrigendum(tblCorrigendum);
        return true;
    }

    /**
     * @author urja
     * @param corrigendumText
     * @param tenderId
     * @param corrigendumId
     * @return
     * @throws Exception
     */
    public void updateCorrigendum(String corrigendumText, int tenderId, int corrigendumId) throws Exception {        
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("corrigendumText", corrigendumText);
        var.put("tenderId", tenderId);
        var.put("corrigendumId", corrigendumId);
        hibernateQueryDao.updateDeleteNewQuery("update TblCorrigendum set corrigendumText=:corrigendumText where objectId=:tenderId and corrigendumId=:corrigendumId", var);;
   }

    /**
     * @author urja
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<TblCorrigendum> getPendingCorrigendumByTenderId(int tenderId) throws Exception {
        return tblCorrigendumDao.findTblCorrigendum(OBJECTID, Operation_enum.EQ, tenderId, "cstatus", Operation_enum.IN, new Object[]{0, 3});
    }

    /**
     * @author urja
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<TblCorrigendum> getAllCorrigendumByTenderId(int tenderId) throws Exception {
        return tblCorrigendumDao.findTblCorrigendum(OBJECTID, Operation_enum.EQ, tenderId, "corrigendumId", Operation_enum.ORDERBY, Operation_enum.DESC);
    }

    /**
     * @author priyanka.dalwadi
     * @param corrigendumId
     * @return
     * @throws Exception
     */
    public List<TblCorrigendum> getCorrigendumByCorrigendumId(int corrigendumId) throws Exception {
        return tblCorrigendumDao.findTblCorrigendum("corrigendumId", Operation_enum.EQ, corrigendumId,"corrigendumId", Operation_enum.ORDERBY, Operation_enum.DESC);
    }
    /**
     * @author urja
     * @param corrigendumId
     * @return
     * @throws Exception
     */
    public List<TblCorrigendumDetail> getCorrigendumDetailByTenderId(int corrigendumId) throws Exception {
        return tblCorrigendumDetailDao.findTblCorrigendumDetail("tblCorrigendum.corrigendumId", Operation_enum.EQ, corrigendumId);
    }

    /**
     * Create for Bug: 20577	
     * @author bharat 
     * @param corrigendumId
     * @return
     * @throws Exception
     */
    public List<TblCorrigendumDetail> getCorrigendumDetailWithProcessId(int corrigendumId) throws Exception {
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put("corrigendumId", corrigendumId);
         List<TblCorrigendumDetail> tblCorrigendumDetailList = new ArrayList<TblCorrigendumDetail>(); 
    	 List<Object[]> list= hibernateQueryDao.createNewQuery("select actionType, corrigendumDetailId,createdBy,createdOn,fieldLabel,fieldName,newValue,objectId,oldValue,tblCorrigendumDetail.tblProcess.processId,tblCorrigendumDetail.tblCorrigendum.corrigendumId from TblCorrigendumDetail tblCorrigendumDetail where tblCorrigendumDetail.tblCorrigendum.corrigendumId=:corrigendumId", var);;
	    	 if(list != null && !list.isEmpty())
	    	 {
	    		 for(Object[] object : list){
	    		 TblCorrigendumDetail tblCorrigendumDetail = new TblCorrigendumDetail();
	    		 tblCorrigendumDetail.setActionType(object[0] != null && !object[0].equals("") ? Integer.parseInt(object[0].toString()) : 0);
	    		 tblCorrigendumDetail.setCorrigendumDetailId(object[1] != null && !object[1].equals("") ? Integer.parseInt(object[1].toString()) : 0);
	    		 tblCorrigendumDetail.setCreatedBy(object[2] != null && !object[2].equals("") ? Integer.parseInt(object[2].toString()) : 0);
//	    		 tblCorrigendumDetail.setCreatedOn((Date) object[3]);
	    		 tblCorrigendumDetail.setFieldLabel(object[4] != null && !object[4].equals("") ? object[4].toString() : "");
	    		 tblCorrigendumDetail.setFieldName(object[5] != null && !object[5].equals("") ? object[5].toString() : "");
	    		 tblCorrigendumDetail.setNewValue(object[6] != null && !object[6].equals("") ? object[6].toString() : "");
	    		 tblCorrigendumDetail.setObjectId(object[7] != null && !object[7].equals("") ? Integer.parseInt(object[7].toString()) : 0);
	    		 tblCorrigendumDetail.setOldValue(object[8] != null && !object[8].equals("") ? object[8].toString() : "");
	    		 tblCorrigendumDetail.setTblProcess(new TblProcess(object[9] != null && !object[9].equals("") ? Integer.parseInt(object[9].toString()) : 0));
	    		 tblCorrigendumDetail.setTblCorrigendum(new TblCorrigendum(object[10] != null && !object[10].equals("") ? Integer.parseInt(object[10].toString()) : 0));
	    		 tblCorrigendumDetailList.add(tblCorrigendumDetail);
	    	 }
    	 }
	    	 return tblCorrigendumDetailList;
    }
    
    /**
     * @author urja
     * @param corrigendumId
     * @return
     * @throws Exception
     */
    public List<TenderCorrigendumDetailDtBean> getCorrigendumDetailForEditByTenderId(int corrigendumId) throws Exception {
        List<TenderCorrigendumDetailDtBean> resultList = new ArrayList<TenderCorrigendumDetailDtBean>();

        List<TblCorrigendumDetail> corrigendumDetailst = tblCorrigendumDetailDao.findTblCorrigendumDetail("tblCorrigendum.corrigendumId", Operation_enum.EQ, corrigendumId, "actionType", Operation_enum.NE, 3);
        if (corrigendumDetailst != null) {
            for (int i = 0; i < corrigendumDetailst.size(); i++) {
                TenderCorrigendumDetailDtBean tenderCorrigendumDtBean = new TenderCorrigendumDetailDtBean();
                tenderCorrigendumDtBean.setFieldName(corrigendumDetailst.get(i).getFieldName());
                tenderCorrigendumDtBean.setFieldLabel(corrigendumDetailst.get(i).getFieldLabel());
                if (corrigendumDetailst.get(i).getTblProcess().getProcessId()!=2) {
                    if (corrigendumDetailst.get(i).getNewValue() != null && !corrigendumDetailst.get(i).getNewValue().equals("") && corrigendumDetailst.get(i).getNewValue().contains("::")) {
                        String newValue[] = corrigendumDetailst.get(i).getNewValue().split("::");
                        tenderCorrigendumDtBean.setNewValue(newValue[1]);
                    } else {
                        tenderCorrigendumDtBean.setNewValue(corrigendumDetailst.get(i).getNewValue());
                    }
                } else {
                    List<TblTenderCurrency> lstTenderCurr = tblTenderCurrencyDao.findTblTenderCurrency("tenderCurrencyId", Operation_enum.EQ, corrigendumDetailst.get(i).getObjectId());
                    if (lstTenderCurr != null) {
                        //tenderCorrigendumDtBean.setNewValue(String.valueOf(lstTenderCurr.get(0).getTblCurrency().getCurrencyId()));
                        tenderCorrigendumDtBean.setObjectId(corrigendumDetailst.get(i).getObjectId());
                        tenderCorrigendumDtBean.setProcessId(corrigendumDetailst.get(i).getTblProcess().getProcessId());
                    }
                }
                resultList.add(tenderCorrigendumDtBean);
            }
        }
        return resultList;
    }

    /**
     * @author urja
     * @param objectId
     * @return
     */
    public int getPendingCorrigendumId(int objectId) {
        int corrigendumId = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("objectId", objectId);
        var.put("tender_corrigendum_pending", tenderCorrigendumPending);
        List<Object> corrigendumIdList = hibernateQueryDao.singleColQuery("select corrigendumId from TblCorrigendum where objectId=:objectId and cstatus=:tender_corrigendum_pending", var);
        if (corrigendumIdList != null && corrigendumIdList.size() > 0) {
            corrigendumId = Integer.valueOf(corrigendumIdList.get(0).toString());
        }
        return corrigendumId;
    }

   
    /**
     * @author VIPULP
     * @param corrigendumId
     * @return {@code List<Object[]>}
     */
    public List<Object[]> getTenderCorrigendumDtls(int corrigendumId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("corrigendumId", corrigendumId);

        query.append("select tblcorrigendumdetail.objectId,")
                .append("concat('Tbl',substring(tblprocess.tableName,locate('_',tblprocess.tableName)+1,length(tblprocess.tableName))),")
                .append(" case when tblcorrigendumdetail.actionType=1 then 'insert' when tblcorrigendumdetail.actionType=2 then 'update' ")
                .append(" when tblcorrigendumdetail.actionType=3 then 'cancel' end,tblcorrigendumdetail.fieldName,")
                .append(" case when tblcorrigendumdetail.newValue like'%::%' then ")
                .append(" substring(tblcorrigendumdetail.newValue,locate('::',tblcorrigendumdetail.newValue)+2,length(tblcorrigendumdetail.newValue)) ")
                .append(" else tblcorrigendumdetail.newValue end,")
                .append(" tblcorrigendumdetail.createdBy,")
                .append(" tblcorrigendumdetail.createdOn")
                .append(" from TblCorrigendumDetail tblcorrigendumdetail ")
                .append(" inner join tblcorrigendumdetail.tblProcess tblprocess ")
                .append(" where tblcorrigendumdetail.tblCorrigendum.corrigendumId=:corrigendumId")
                .append(" order by tblcorrigendumdetail.tblProcess.processId,tblcorrigendumdetail.actionType");

        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    public boolean isFieldValueChangedCorrigendumDetail(int corrigendumId,String fieldName){
    	
    	boolean response = false;
    	StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("corrigendumId", corrigendumId);
        var.put("fieldName", fieldName);
        
        query.append("select tblcorrigendumdetail.objectId,tblcorrigendumdetail.fieldName,tblcorrigendumdetail.oldValue,tblcorrigendumdetail.newValue");
        query.append(" from TblCorrigendumDetail tblcorrigendumdetail ");
        query.append(" where tblcorrigendumdetail.tblCorrigendum.corrigendumId=:corrigendumId AND tblcorrigendumdetail.fieldName=:fieldName ");
        List<Object[]> list =  hibernateQueryDao.createNewQuery(query.toString(), var);
        if(list.size() > 0){
        	String oldValue = list.get(0)[2].toString();
        	String newValue = list.get(0)[3].toString();
        	if(!oldValue.equals(newValue)){
        		response = true;
        	}
        }
        return response;
    }
    /**
     * @author VIPULP
     * @param corrigendumId
     * @return {@code List<Object>}
     */
    public List<Object> getCorrigendumProcessTbls(int corrigendumId) throws Exception {
        
    	StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        query=new StringBuilder("select processId from TblProcess where processName=:processName and tableName='appuser.tbl_OfficerDocMapping'");
     	var.put("processName", "TenderNoticeDocument");
     	int processId=0;
     	List<Object[]> tblProcessId=hibernateQueryDao.createNewQuery(query.toString(),var);
     	if(tblProcessId!=null && !tblProcessId.isEmpty() && tblProcessId.size()>0)
     		processId=Integer.parseInt(String.valueOf(tblProcessId.get(0)));
     	var.clear();
     	
        var.put("corrigendumId", corrigendumId);
        var.put("processId",processId);
        query=new StringBuilder();
        query.append("select distinct ")
                .append(" case when tblcorrigendumdetail.tblProcess.processId=1 then 'TblTender' ")
                .append(" when tblcorrigendumdetail.tblProcess.processId=2 then 'TblTenderCurrency' ")
                .append(" when tblcorrigendumdetail.tblProcess.processId=3 then 'TblTenderEnvelope' ")
                .append(" when tblcorrigendumdetail.tblProcess.processId=4 then 'TblTenderForm' ")
                .append(" when tblcorrigendumdetail.tblProcess.processId=10 then 'TblEventPayment' ")
                .append(" when tblcorrigendumdetail.tblProcess.processId=:processId then 'TblOfficerDocMapping' end ")
                .append(" from TblCorrigendumDetail tblcorrigendumdetail ")
                .append(" where tblcorrigendumdetail.tblCorrigendum.corrigendumId=:corrigendumId");

        return hibernateQueryDao.singleColQuery(query.toString(), var);
    }

    /**
     * @author VIPULP
     * @param queries
     * @param tblCorrigendum
     * @param params
     * @return int
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public int executeCorrigendumDtlsQueries(List<String> queries, Map<String,Map<String,Object>> queryFields,TblCorrigendum tblCorrigendum, String keyWordTxt,Map<String,Object> paramValue, int... params) throws Exception {
        int cnt = 0;
        /** start publish committee **/
        List<Object[]> lists=commonService.getClientConfiguration(params[3]);
        boolean isTOCPublishWithTender=lists!=null && !lists.isEmpty() ? lists.get(0)[2].toString().equals("1") ? true : false : false;
        boolean isTECPublishWithTender=lists!=null && !lists.isEmpty() ? lists.get(0)[3].toString().equals("1") ? true : false : false;
        boolean isBiddingFormPublishWithTender=lists!=null && !lists.isEmpty() ? lists.get(0)[4].toString().equals("1") ? true : false : false;
        boolean isEnvelopePublished=tenderFormService.getTenderEnvelopeByOpeningDateStatus(params[1], 1);
        TblCommittee committee=committeeFormationService.getPeningCommittee(params[1],1,0,0);
        TblCommittee approvedCommittee=null;       
        boolean flag=false;
        if(committee!=null && isEnvelopePublished){
        	if(isTOCPublishWithTender){
        		flag=true;
        	}else if(!isTOCPublishWithTender){
        		approvedCommittee=committeeFormationService.getPeningCommittee(params[1],1,1,1);
        		if(approvedCommittee!=null){
        			flag=true;
        		}
        	}
        	if(flag){	
	        	Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("tenderId", params[1]);					
				String encryptUrlStr = encryptDecryptUtils.encrypt("etender/buyer/viewcommittee/"+params[1]+"/"+1+"/"+0);					 
		        String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
		        paramMap.put("link", hrefStr);
	        	committeeFormationService.publishCommittee(tblCorrigendum.getRemarks(), committee.getTblClient().getClientId(), tblCorrigendum.getPublishedBy(), committee.getCommitteeId(), 1, params[1], 0, params[2], paramMap);
        	}
        }
        flag=false;
        committee=committeeFormationService.getPeningCommittee(params[1],2,0,0);
        approvedCommittee=null;
        if(committee!=null && isEnvelopePublished){
        	if(isTECPublishWithTender){
        		flag=true;
        	}else if(!isTECPublishWithTender){
        		approvedCommittee=committeeFormationService.getPeningCommittee(params[1],2,1,1);
        		if(approvedCommittee!=null){
        			flag=true;
        		}
        	}
        	if(flag){	
	        	Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("tenderId", params[1]);					
				String encryptUrlStr = encryptDecryptUtils.encrypt("etender/buyer/viewcommittee/"+params[1]+"/"+2+"/"+0);					 
		        String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
		        paramMap.put("link", hrefStr);
	        	committeeFormationService.publishCommittee(tblCorrigendum.getRemarks(), committee.getTblClient().getClientId(), tblCorrigendum.getPublishedBy(), committee.getCommitteeId(), 2, params[1], 0, params[2], paramMap);
        	}
        }
        /** end publish committee **/
        
        if (queries != null && !queries.isEmpty()) {
            for (String query : queries) {
            	if(query.contains("update TblTender set"))
            	{
            		if(queryFields!= null)
            		{
            			if(!queryFields.isEmpty() && queryFields.size()>0)
                		{
                			for (Map.Entry<String, Map<String,Object>> entry : queryFields.entrySet())
                    		{
                    			if(entry.getKey().equalsIgnoreCase("tblTender"))
                    			{
                    				Map<String,Object> tblTender = entry.getValue();
                    				cnt += hibernateQueryDao.updateDeleteNewQuery(query, tblTender);
                    			}
                    		}	
                		}	
            		}
            	}
            	else
            	{
            		cnt += hibernateQueryDao.updateDeleteNewQuery(query, null);	
            	}
                
            }
        }
        
        // PT #38371  ** Start Here **
        List<TblCorrigendumDetail> corrigendumDtlforPayType = getCorrigendumDetailWithProcessId(tblCorrigendum.getCorrigendumId());
        for (TblCorrigendumDetail tblCorrigendumDetail : corrigendumDtlforPayType) {
        	
        	if(tblCorrigendumDetail.getTblProcess().getProcessId() == 10 || tblCorrigendumDetail.getTblProcess().getProcessId() == 1 ){
        		if(tblCorrigendumDetail.getFieldName().contains("isDocfeesApplicable") && tblCorrigendumDetail.getNewValue().contains("label_notrequired::0")) {
        			updateEventPaymentType(tblCorrigendum.getObjectId(),1 ,3);
        		}
        		else if(tblCorrigendumDetail.getFieldName().contains("DocFeesPaymentType")) {
	        		List<TblEventPayment> tblEventPayments=new ArrayList<TblEventPayment>();
	        		String payType[]=tblCorrigendumDetail.getNewValue().split(",");
	        		for (String type : payType) {
	        			TblEventPayment tblEventPayment=new TblEventPayment();
                		tblEventPayment.setObjectId(tblCorrigendum.getObjectId());
                		tblEventPayment.setTblClient(new TblClient(params[3]));
                		tblEventPayment.setTblPaymentType(new TblPaymentType(commonService.getPaymentTypeDetail(type.trim()).getPaymentTypeId()));
                		tblEventPayment.setPaymentFor(1);  // 1 For DocFees
                		tblEventPayment.setModuleId(3);
                		tblEventPayment.setIsActive(1);
                		tblEventPayment.setCreatedBy(tblCorrigendum.getPublishedBy());
                		tblEventPayments.add(tblEventPayment);
					}
	        	    updateEventPaymentType(tblCorrigendum.getObjectId(),1 ,3);
	        	   eventCreationService.addTenderPaymentType(tblEventPayments);
	        		
	        	}
        		
        		if(tblCorrigendumDetail.getFieldName().contains("isSecurityfeesApplicable") && tblCorrigendumDetail.getNewValue().contains("label_notrequired::0")) {
        			updateEventPaymentType(tblCorrigendum.getObjectId(),10 ,3);
        		}else if(tblCorrigendumDetail.getFieldName().contains("SecurityFeesPaymentType")) {
	        		List<TblEventPayment> tblEventPayments=new ArrayList<TblEventPayment>();
	        		String payType[]=tblCorrigendumDetail.getNewValue().split(",");
	        		for (String type : payType) {
	        			TblEventPayment tblEventPayment=new TblEventPayment();
                		tblEventPayment.setObjectId(tblCorrigendum.getObjectId());
                		tblEventPayment.setTblClient(new TblClient(params[3]));
                		tblEventPayment.setTblPaymentType(new TblPaymentType(commonService.getPaymentTypeDetail(type.trim()).getPaymentTypeId()));
                		tblEventPayment.setPaymentFor(10);  // 10 For Security Fees      
                		tblEventPayment.setModuleId(3);
                		tblEventPayment.setIsActive(1);
                		tblEventPayment.setCreatedBy(tblCorrigendum.getPublishedBy());
                		tblEventPayments.add(tblEventPayment);
	        		}
	        		updateEventPaymentType(tblCorrigendum.getObjectId(),10 ,3);
		        	eventCreationService.addTenderPaymentType(tblEventPayments);
	        	}
        		
        		if(tblCorrigendumDetail.getFieldName().contains("isEMDApplicable") && tblCorrigendumDetail.getNewValue().contains("label_notrequired::0")) {
        			updateEventPaymentType(tblCorrigendum.getObjectId(),2 ,3);
        		} else if(tblCorrigendumDetail.getFieldName().contains("EMDPaymentType")) {
	        		List<TblEventPayment> tblEventPayments=new ArrayList<TblEventPayment>();
	        		String payType[]=tblCorrigendumDetail.getNewValue().split(",");
	        		for (String type : payType) {
	        			TblEventPayment tblEventPayment=new TblEventPayment();
	        			tblEventPayment.setObjectId(tblCorrigendum.getObjectId());
	        			tblEventPayment.setTblClient(new TblClient(params[3]));
	        			tblEventPayment.setTblPaymentType(new TblPaymentType(commonService.getPaymentTypeDetail(type.trim()).getPaymentTypeId()));
                		tblEventPayment.setPaymentFor(2); // 2 For EMD
                		tblEventPayment.setModuleId(3);
                		tblEventPayment.setIsActive(1);
                		tblEventPayment.setCreatedBy(tblCorrigendum.getPublishedBy());
                		tblEventPayments.add(tblEventPayment);
                		
	        		}
	        		updateEventPaymentType(tblCorrigendum.getObjectId(),2 ,3);
		        	eventCreationService.addTenderPaymentType(tblEventPayments);
	        	}
        		
        		if(tblCorrigendumDetail.getFieldName().contains("isRegistrationCharges") && tblCorrigendumDetail.getNewValue().contains("label_notrequired::0")) {
        			updateEventPaymentType(tblCorrigendum.getObjectId(),8 ,3);
        		} else if(tblCorrigendumDetail.getFieldName().contains("RegistrationChargesPaymentTypes")) {
	        		List<TblEventPayment> tblEventPayments=new ArrayList<TblEventPayment>();
	        		String payType[]=tblCorrigendumDetail.getNewValue().split(",");
	        		for (String type : payType) {
	        			TblEventPayment tblEventPayment=new TblEventPayment();
	        			tblEventPayment.setObjectId(tblCorrigendum.getObjectId());
	        			tblEventPayment.setTblClient(new TblClient(params[3]));
	        			tblEventPayment.setTblPaymentType(new TblPaymentType(commonService.getPaymentTypeDetail(type.trim()).getPaymentTypeId()));
                 		tblEventPayment.setPaymentFor(8);  // 8 For Participation Fees
                 		tblEventPayment.setModuleId(3);
                 		tblEventPayment.setIsActive(1);
                 		tblEventPayment.setCreatedBy(tblCorrigendum.getPublishedBy());
                 		tblEventPayments.add(tblEventPayment);
	        		}
	        		updateEventPaymentType(tblCorrigendum.getObjectId(),8 ,3);
		        	eventCreationService.addTenderPaymentType(tblEventPayments);
	        	}
        	}
        }
        
        // **** END Here ****

        StringBuilder query = new StringBuilder();
        query.append("update TblCorrigendum set ")
                .append(" remarks='").append(tblCorrigendum.getRemarks()).append("',")
                .append(" publishedOn='").append(tblCorrigendum.getPublishedOn()).append("',")
                .append(" publishedBy=").append(tblCorrigendum.getPublishedBy()).append(",")
                .append(" cstatus=").append(tblCorrigendum.getCstatus())
                .append(" where corrigendumId=").append(tblCorrigendum.getCorrigendumId());

        if (hibernateQueryDao.updateDeleteNewQuery(query.toString(), null) != 0) {
            query.delete(0, query.length());
            query.append("update TblTender set corrigendumCount=").append(params[0]).append(" where tenderId=").append(params[1]);

            cnt += hibernateQueryDao.updateDeleteNewQuery(query.toString(), null);

            query.delete(0, query.length());
            query.append("update TblOfficerDocMapping set cstatus=1,")
                    .append(" approvedOn='").append(tblCorrigendum.getPublishedOn()).append("',")
                    .append(" approvedBy=").append(tblCorrigendum.getPublishedBy())
                    .append(" where cstatus=0 and tblLink.linkId=182 and objectId=").append(tblCorrigendum.getCorrigendumId());

            cnt += hibernateQueryDao.updateDeleteNewQuery(query.toString(), null);
            
            if (StringUtils.hasLength(keyWordTxt)) {
               List<LinkedHashMap<String, Object>> list = spKeywordOperation.executeProcedure(keyWordTxt, params[1], tenderEventId, 1);
            }
        }
        List<TblCorrigendumDetail> corrigendumDtlforForm = getCorrigendumDetailWithProcessId(tblCorrigendum.getCorrigendumId());
        List<Integer> addedformIds = new ArrayList<Integer>();
        if(corrigendumDtlforForm!=null && !corrigendumDtlforForm.isEmpty()){
        	for (int i = 0; i < corrigendumDtlforForm.size(); i++) {
				if(corrigendumDtlforForm.get(i).getTblProcess().getProcessId() == 4 && corrigendumDtlforForm.get(i).getActionType() == 1){
					addedformIds.add(corrigendumDtlforForm.get(i).getObjectId());
				}
			}
        }
        
        if(addedformIds != null && !addedformIds.isEmpty())
        {
        	List<Object[]> cellValues = tenderFormService.getProxyColumnData(tblCorrigendum.getObjectId(),addedformIds);
        	List<TblTenderProxyBid>lstTblTenderProxyBid = new ArrayList<TblTenderProxyBid>();
        	TblTenderProxyBid tblTenderProxyBid = null;
        	List<Object[]> bidderConformation = tenderCommonService.getTenderBidderDetail(tblCorrigendum.getObjectId(), 1); // get all bidder detail who agree to T&C
        	
        	if(cellValues!=null && !cellValues.isEmpty())
        	{
        		if(bidderConformation  != null && !bidderConformation.isEmpty()){
        			for(Object[] conObject : bidderConformation){
		        		for(int i=0; i<cellValues.size(); i++){
			        		tblTenderProxyBid = new TblTenderProxyBid();
			        		tblTenderProxyBid.setTblTender(new TblTender(tblCorrigendum.getObjectId()));
			        		tblTenderProxyBid.setTblTenderTable(new TblTenderTable((Integer)cellValues.get(i)[0]));
			        		tblTenderProxyBid.setTblTenderColumn(new TblTenderColumn((Integer)cellValues.get(i)[1]));
			        		tblTenderProxyBid.setTblTenderCell(new TblTenderCell((Integer)cellValues.get(i)[2]));
			        		tblTenderProxyBid.setRowId((Short)cellValues.get(i)[3]);
			        		tblTenderProxyBid.setTblCompany(new TblCompany(Integer.parseInt(conObject[1].toString())));
			        		tblTenderProxyBid.setCellValue("1");
			        		tblTenderProxyBid.setIpAddress(paramValue.get("ipAddress").toString());
			        		tblTenderProxyBid.setIsUpdatedFrom(1);
			        		tblTenderProxyBid.setCreatedBy(Integer.parseInt(conObject[2].toString()));
			        		lstTblTenderProxyBid.add(tblTenderProxyBid);
		        		}
	        		}
        			if(lstTblTenderProxyBid != null && !lstTblTenderProxyBid.isEmpty()){
        				tblTenderProxyBidDao.saveUpdateAllTblTenderProxyBid(lstTblTenderProxyBid);
        			}
	        	}
        	}	
        }
        if(((!isBiddingFormPublishWithTender) && isEnvelopePublished) || (isBiddingFormPublishWithTender)){  /*Changes Bug Id#29658 and Related Bug Id#28802 */
        /*** Code to call procedure for negotiation l1 h1 report  last parameter o for publish tender if Corrigendum it is 1**/
	        TblTender tblTender = eventCreationService.getTenderMaster((Integer) paramValue.get("objectId"));
	        tenderFormService.executeSPforGenerateL1Report(tblTender.getTenderId(), tblTender.getTenderResult(), (Integer)  paramValue.get("userDetailId"),1,0);
	        if(tblTender.getIsNegotiationAllowed() != 0)
	        	tenderFormService.executeSPforGenerateL1Report(tblTender.getTenderId(), tblTender.getTenderResult(), (Integer)  paramValue.get("userDetailId"),1,1);
	        if(tblTender.getIsWeightageEvaluationRequired() == 1)
	        	tenderFormService.executeSPforGenerateL1Report(tblTender.getTenderId(), tblTender.getTenderResult(), (Integer)  paramValue.get("userDetailId"),1,2);
	        if(tblTender.getTenderResult() == 1 && tblTender.getIsRebateForm() == 1)
	        	tenderFormService.executeSPforGenerateL1Report(tblTender.getTenderId(), tblTender.getTenderResult(), (Integer)  paramValue.get("userDetailId"),1,4);
        }
        return cnt;
    }

       
    /**
     * @author urja
     * @param tenderId
     * @return
     */
    public int deletePendingCurrencyByTenderId(int tenderId) {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("pending", 0);
        int cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderCurrency where isActive=:pending and tenderId=:tenderId", var);

        return cnt;
    }
    /**
     * @author urja
     * @param currencyId
     * @return
     * @throws Exception
     */
    public String getCurrencyNameById(int tenderCurrencyId, int tenderId) throws Exception {
        String result = "";
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        List<TblTenderCurrency> lstTenderCurr = tblTenderCurrencyDao.findTblTenderCurrency("tblTender.tenderId", Operation_enum.EQ, tenderId, "tenderCurrencyId", Operation_enum.EQ, tenderCurrencyId);
        if (lstTenderCurr != null && lstTenderCurr.size() > 0) {           
                var.put("currencyId", lstTenderCurr.get(0).getTblCurrency().getCurrencyId());
                list = hibernateQueryDao.singleColQuery("select lang" + WebUtils.getCookie(eventCreationService.getServletRequest(), "locale").getValue() + " from  TblCurrency where currencyId=:currencyId", var);
                    }

        if (list != null) {
            result = list.get(0).toString();
        }
        return result;
    }

    /**
     * @author urja
     * @param userId
     * @param corrigendumId
     * @param formId
     * @throws Exception
     */
    public void cancelFormCorrigendumById(int userDetailId, int corrigendumId, int formId) throws Exception {
        if (corrigendumId != 0) {
            TblProcess tblProcess = new TblProcess(4);
            TblCorrigendum tblCorrigendum = new TblCorrigendum(corrigendumId);
            TblCorrigendumDetail tblCorrigendumDetail = new TblCorrigendumDetail();
            tblCorrigendumDetail.setActionType(3);
            tblCorrigendumDetail.setCreatedBy(userDetailId);
            tblCorrigendumDetail.setFieldLabel("");
            tblCorrigendumDetail.setFieldName("");
            tblCorrigendumDetail.setOldValue("");
            tblCorrigendumDetail.setNewValue("");
            tblCorrigendumDetail.setObjectId(formId);
            tblCorrigendumDetail.setTblProcess(tblProcess);
            tblCorrigendumDetail.setTblCorrigendum(tblCorrigendum);
            tblCorrigendumDetailDao.addTblCorrigendumDetail(tblCorrigendumDetail);
        }
    }

    /**
     * @author urja
     * @param formId
     * @return
     * @throws Exception
     */
    public String getFormNameById(int formId) throws Exception {
        List<TblTenderForm> list = null;
        list = tblTenderFormDao.findTblTenderForm("formId", Operation_enum.EQ, formId);
        return (list != null && !list.isEmpty()) ? list.get(0).getFormName() : null;
    }
    /**
     * 
     * @param envelopeId
     * @return
     * @throws Exception 
     */
    public String getEnvelopeNameById(int envelopeId) throws Exception {
        List<TblTenderEnvelope> list = null;
        list = tblTenderEnvelopeDao.findTblTenderEnvelope("envelopeId", Operation_enum.EQ, envelopeId);
        return (list != null && !list.isEmpty()) ? list.get(0).getEnvelopeName() : null;
    }

    /**
     * @author urja
     * @param tenderId
     * @return
     * @throws Exception
     */
    public int getApproveCorrigendumLegnthByTenderId(int tenderId) throws Exception {
        int result = 0;
        List<TblCorrigendum> list = null;
        list = tblCorrigendumDao.findTblCorrigendum(OBJECTID, Operation_enum.EQ, tenderId, "cstatus", Operation_enum.EQ, 1);
        if (list != null) {
            result = list.size();
        }
        return result;
    }

    /**
     * @author urja
     * @param tenderId
     * @return
     * @throws Exception
     */
    public int isIAgreeByTenderId(int tenderId) throws Exception {
        int result = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        List<Object> list = hibernateQueryDao.getSingleColQuery("select bidConfirmationId from TblTenderBidConfirmation where tenderId=:tenderId", var);
        if (list != null) {
            result = list.size();
        }
        return result;
    }
      /**
     * 
     * @param tblCorrigendumDetails
     * @param corrigendumId
     * @param currencyOldList
     * @param currencyNewList
     * @param baseCurrency
     * @param oldEnvList
     * @param envType
     * @param formType
     * @param bidOpeningDate
     * @param objectId
     * @param userDetailId
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public void saveCorrigendumData(List<TblCorrigendumDetail> tblCorrigendumDetails, int corrigendumId, List<String> currencyOldList, List<String> currencyNewList, int baseCurrency, List<Integer> oldEnvList, int envType, String[] formType, String bidOpeningDate, int objectId, int userDetailId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        List<Integer> processIds=new ArrayList<Integer>();
        processIds.add(1);
        processIds.add(2);
        processIds.add(10);
        var.put("corrigendumId", corrigendumId);
        var.put("processId",processIds);
        
        /*** Delete TblCorrigendumDetail old details by corrigendumId **/
        hibernateQueryDao.updateDeleteNewQuery("delete from TblCorrigendumDetail tblCorrigendumDetail where tblCorrigendumDetail.tblCorrigendum.corrigendumId=:corrigendumId and processId IN (:processId)", var);
        
        /*** Delete TblTender Currency old details by where c status =0  and tender id = objectId**/
        Map<String, Object> tenderCurrencyVar = new HashMap<String, Object>();
        tenderCurrencyVar.put("objectId", objectId);
        hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderCurrency tblTenderCurrency where tblTenderCurrency.tblTender.tenderId=:objectId and tblTenderCurrency.isActive=0",tenderCurrencyVar);
        
        tblCorrigendumDetailDao.saveUpdateAllTblCorrigendumDetail(tblCorrigendumDetails);
        //Currency
        /*** Code insert value for TblTenderCurrency and TblCorrigendumDetail for currency Bug #17449**/
        addTendeCurrencyOnCorrigendum(currencyNewList, objectId, corrigendumId, userDetailId);  
        
        //Envelope
       // addCorrigendumEnvelop(objectId, envType, oldEnvList, userDetailId, formType, bidOpeningDate);/* CR #28151 - Need to restrict configuration of new envelopes through corrigendum*/
        
    }
    
    /**
     * @author krunal.patel
     * @param currencyNewList
     * @param objectId
     * @param corrigendumId
     * @param userDetailId
     * @throws Exception 
     */
   public void addTendeCurrencyOnCorrigendum(List<String> currencyNewList,int objectId,int corrigendumId,int userDetailId){
	   
	   TblTenderCurrency tblTenderCurrency = null;
       TblCorrigendumDetail tblCorrigendumDetail = null;
       List<TblCorrigendumDetail> tblCorrigendumDetailList = new ArrayList<TblCorrigendumDetail>();
         for (int i = 0; i < currencyNewList.size(); i++) {
       	  
        	 /*** Code to set TblTenderCurrency value and save **/
       	  	 tblTenderCurrency = new TblTenderCurrency();
             tblTenderCurrency.setTblTender(new TblTender(objectId));
             tblTenderCurrency.setTblCurrency(new TblCurrency(Integer.valueOf(currencyNewList.get(i).toString())));  
             tblTenderCurrency.setExchangeRate(new BigDecimal("0.0"));
             tblTenderCurrency.setIsDefault(0);
             tblTenderCurrency.setIsActive(0);
             tblTenderCurrencyDao.saveOrUpdateTblTenderCurrency(tblTenderCurrency);
             
             
             /*** Code to set TblCorrigendumDetail value and save **/
              tblCorrigendumDetail = new TblCorrigendumDetail();
              tblCorrigendumDetail.setTblCorrigendum(new TblCorrigendum(corrigendumId));
              tblCorrigendumDetail.setTblProcess(new TblProcess(2));// For TblTenderCurrency
              tblCorrigendumDetail.setObjectId(tblTenderCurrency.getTenderCurrencyId());
              tblCorrigendumDetail.setFieldName("");
              tblCorrigendumDetail.setFieldLabel("");
              tblCorrigendumDetail.setOldValue("");
              tblCorrigendumDetail.setNewValue("");
              tblCorrigendumDetail.setActionType(1);// For new insert
              tblCorrigendumDetail.setCreatedBy(userDetailId);
              tblCorrigendumDetailList.add(tblCorrigendumDetail);
         }
         	tblCorrigendumDetailDao.saveUpdateAllTblCorrigendumDetail(tblCorrigendumDetailList);
   }
    
    
    
    /**
     * 
     * @param tenderId
     * @param envType
     * @param oldEnvId
     * @param userDetailId
     * @param formType
     * @param openingDate
     * @throws Exception 
     */
    public void addCorrigendumEnvelop(int tenderId, int envType, List<Integer> oldEnvId, int userDetailId, String[] formType, String openingDate) throws Exception {
        TblTender tblTender = new TblTender(tenderId);
        int corrigendumId = getPendingCorrigendumId(tenderId);
        int counter = 0;
        if (removePendingEnvelopForCorrigendum(tenderId, corrigendumId, formType)) {
            if (formType != null) {
                for (int i = 0; i < formType.length; i++) {
                    if (!oldEnvId.contains(Integer.valueOf(formType[i]))) {
                        TblTenderEnvelope tblTenderEnvelope = new TblTenderEnvelope();
                        tblTenderEnvelope.setEnvelopeName(eventCreationService.getEnvelopeNameById(Integer.valueOf(formType[i])));
                        tblTenderEnvelope.setTblTender(tblTender);
                        TblEnvelope tblEnvelope = new TblEnvelope();
                        tblEnvelope.setEnvId(Integer.valueOf(formType[i]));
                        if (envType == 1) {
                            tblTenderEnvelope.setOpeningDate(conversionService.convert(openingDate, Date.class));
                        }
                        tblTenderEnvelope.setNoOfFormsReq(0);
                        tblTenderEnvelope.setMinOpeningMember(0);
                        tblTenderEnvelope.setMinEvaluator(0);
                        tblTenderEnvelope.setIsOpened(0);
                        tblTenderEnvelope.setIsEvaluated(0);
                        tblTenderEnvelope.setCreatedBy(userDetailId);
                        tblTenderEnvelope.setCstatus(4);
                        tblTenderEnvelope.setTblEnvelope(tblEnvelope);
                        tblTenderEnvelope.setRemark("");
                        tblTenderEnvelopeDao.saveOrUpdateTblTenderEnvelope(tblTenderEnvelope);

                        TblProcess tblProcess = new TblProcess(3);
                        TblCorrigendum tblCorrigendum = new TblCorrigendum(corrigendumId);
                        TblCorrigendumDetail tblCorrigendumDetail = new TblCorrigendumDetail();
                        tblCorrigendumDetail.setActionType(1);
                        tblCorrigendumDetail.setCreatedBy(userDetailId);
                        tblCorrigendumDetail.setFieldLabel("");
                        tblCorrigendumDetail.setFieldName("");
                        tblCorrigendumDetail.setOldValue("");
                        tblCorrigendumDetail.setNewValue("");
                        tblCorrigendumDetail.setObjectId(tblTenderEnvelope.getEnvelopeId());
                        tblCorrigendumDetail.setTblProcess(tblProcess);
                        tblCorrigendumDetail.setTblCorrigendum(tblCorrigendum);
                        tblCorrigendumDetailDao.saveOrUpdateTblCorrigendumDetail(tblCorrigendumDetail);
                        counter++;
                    }
                }
                if (counter > 0) {
                    List<Integer> lstEnvelopeId = new ArrayList<Integer>();
                    lstEnvelopeId = eventCreationService.getEnvelopeIdList(tenderId);
                    for (int j = 0; j < lstEnvelopeId.size(); j++) {
                        eventCreationService.updateEnvelopeSortOrder(lstEnvelopeId.get(j), tblTender.getTenderId(), j + 1);
                    }
                }
            }
        }
    }
    /**
     * 
     * @param tenderId
     * @param corrigendumId
     * @param formType
     * @return 
     */
    public boolean removePendingEnvelopForCorrigendum(int tenderId, int corrigendumId, String[] formType) {
        StringBuilder strCorrigendumQuery = new StringBuilder();
        StringBuilder strQuery = new StringBuilder();
        List<Integer> envIds = new ArrayList<Integer>();
        if (formType != null) {
            for (int i = 0; i < formType.length; i++) {
                envIds.add(Integer.valueOf(formType[i]));
            }
        }

        Map<String, Object> parameters = new HashMap<String, Object>();

        parameters.put("tenderId", tenderId);
        parameters.put("cstatus", 4);
        if (envIds.size() > 0) {
            parameters.put("envIds", envIds);
        }
        strQuery.append("Delete from TblTenderEnvelope where tblTender.tenderId=:tenderId and cstatus = :cstatus");
        if (envIds.size() > 0) {
            strQuery.append(" and envId NOT IN (:envIds)");
        }
        hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(), parameters);
        List<Integer> tenderIds = new ArrayList<Integer>();
        if (envIds.size() > 0) {
            Map<String, Object> var = new HashMap<String, Object>();
            var.put("tenderId", tenderId);
            var.put("envIds", envIds);
            List<Object> list = hibernateQueryDao.getSingleColQuery("select envelopeId from TblTenderEnvelope where tenderId=:tenderId and envId IN (:envIds)", var);

            if (list != null) {
                for (int i = 0; i < list.size(); i++) {
                    tenderIds.add(Integer.valueOf(list.get(i).toString()));
                }
            }
        }

        Map<String, Object> corrigendumParameters = new HashMap<String, Object>();

        corrigendumParameters.put("corrigendumId", corrigendumId);
        corrigendumParameters.put("processId", 3);
        if (tenderIds.size() > 0) {
            corrigendumParameters.put("tenderIds", tenderIds);
        }
        strCorrigendumQuery.append("Delete from TblCorrigendumDetail  where tblCorrigendum.corrigendumId=:corrigendumId and processId = :processId");
        if (tenderIds.size() > 0) {
            strCorrigendumQuery.append(" and objectId NOT IN (:tenderIds)");
        }
        hibernateQueryDao.updateDeleteNewQuery(strCorrigendumQuery.toString(), corrigendumParameters);
        return true;
    }
    /**
     * 
     * @param tenderId
     * @return 
     */
    public List<Object[]> getCorrigendumFormType(int tenderId) {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        String query = "select tblenvelope.envId,tblenvelope.lang" + WebUtils.getCookie(eventCreationService.getServletRequest(), "locale").getValue() + ",tbltenderenvelope.envelopeId from TblEnvelope tblenvelope left join tblenvelope.tblTenderEnvelope tbltenderenvelope where tbltenderenvelope.tblTender.tenderId=:tenderId and tbltenderenvelope.cstatus in (0,1)";
        return hibernateQueryDao.createNewQuery(query, var);
    }
    /**
     * 
     * @param tenderId
     * @return 
     */
    public List<Object[]> getPendingCorrigendumFormType(int tenderId) {

        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        String query = "select tblenvelope.envId,tblenvelope.lang" + WebUtils.getCookie(eventCreationService.getServletRequest(), "locale").getValue() + ",tbltenderenvelope.envelopeId from TblEnvelope tblenvelope left join tblenvelope.tblTenderEnvelope tbltenderenvelope where tbltenderenvelope.tblTender.tenderId=:tenderId and tbltenderenvelope.cstatus =4";
        return hibernateQueryDao.createNewQuery(query, var);
    }
    /**
     * 
     * @param tenderId 
     */
    public void deletePendingEnvelopByTenderId(int tenderId) {
        StringBuilder strQuery = new StringBuilder();
        Map<String, Object> parameters = new HashMap<String, Object>();

        parameters.put("tenderId", tenderId);
        parameters.put("cstatus", 4);
        List<Object> corrEnvlopeIds = hibernateQueryDao.singleColQuery("SELECT envelopeId FROM TblTenderEnvelope tblTenderEnvelope WHERE tblTenderEnvelope.tblTender.tenderId=:tenderId and cstatus=:cstatus", parameters);
        if(corrEnvlopeIds!=null && !corrEnvlopeIds.isEmpty()){
	        parameters = new HashMap<String, Object>();
	        parameters.put("envelopeId", corrEnvlopeIds);
	        strQuery.append(" DELETE FROM TblCommitteeEnvelope WHERE tblTenderEnvelope.envelopeId IN (:envelopeId)");
	        hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(), parameters);
	        
	        strQuery.delete(0, strQuery.length());
	        strQuery.append(" DELETE FROM TblCommitteeUser WHERE childId IN (:envelopeId)");
	        hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(), parameters);
        }
        
        strQuery.delete(0, strQuery.length());
        /* Comment to Resolve Issue #38967
//        strQuery.append(" SELECT tblTenderForm.formId FROM TblRebateForm tblRebateForm");
//        strQuery.append(" INNER JOIN tblRebateForm.tblTenderForm tblTenderForm");
//        strQuery.append(" WHERE tblTenderForm.tblTender.tenderId=:tenderId AND tblTenderForm.cstatus=:cstatus");
//        parameters = new HashMap<String, Object>();
//        parameters.put("cstatus", 0);
//        parameters.put("tenderId", tenderId);
//        List<Object> rebateFormIds = hibernateQueryDao.singleColQuery(strQuery.toString(),parameters);
//        if(rebateFormIds!=null && !rebateFormIds.isEmpty()){
//	        parameters = new HashMap<String, Object>();
//	        parameters.put("formId", rebateFormIds);
//	        strQuery.delete(0, strQuery.length());
//	        strQuery.append(" DELETE FROM TblRebateForm WHERE tblTenderForm.formId IN (:formId)");
//	        hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(), parameters);
//        }
//        strQuery.delete(0, strQuery.length());
 *  	  Comment to Resolve Issue #38967
 */
        parameters = new HashMap<String, Object>();
        parameters.put("tenderId", tenderId);
        parameters.put("cstatus", 4);
        strQuery.append("Delete from TblTenderEnvelope where tblTender.tenderId=:tenderId and cstatus = :cstatus)");
        hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(), parameters);
    }
    /**
     * 
     * @param corrigendumId 
     */
    public void deletePendingCorrigendumDocumentByTenderId(int corrigendumId) {
        StringBuilder docMappingQuery = new StringBuilder();
        StringBuilder docQuery = new StringBuilder();
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("corrigendumId", corrigendumId);
        parameters.put("linkId", corrigendumUpload);
        List<Object> officerDocMappingList = hibernateQueryDao.singleColQuery("select tblOfficerDocument.officerDocId from TblOfficerDocMapping where objectId=:corrigendumId and linkId=:linkId", parameters);
        docMappingQuery.append("Delete from TblOfficerDocMapping where objectId=:corrigendumId and linkId=:linkId)");
        hibernateQueryDao.updateDeleteNewQuery(docMappingQuery.toString(), parameters);
        for (int i = 0; i < officerDocMappingList.size(); i++) {
            Map<String, Object> officerDoc = new HashMap<String, Object>();
            officerDoc.put("officerDocId", officerDocMappingList.get(i));
            docQuery.append("Delete from TblOfficerDocument where officerDocId=:officerDocId");
            hibernateQueryDao.updateDeleteNewQuery(docQuery.toString(), officerDoc);
        }
    }
    /**
     * 
     * @param tenderId
     * @return 
     */
    public boolean deletePendingCorrigendum(int tenderId) {
        boolean flag = false;
        int corrigendumId = getPendingCorrigendumId(tenderId);
        if (corrigendumId > 0) {
            Map<String, Object> var = new HashMap<String, Object>();
            var.put("corrigendumId", corrigendumId);
            deletePendingFormByFormId(corrigendumId);
            String strCorrigendumDetailDocsQuery = "delete from  TblOfficerDocMapping  where officerDocMappingId in (Select objectId from TblCorrigendumDetail where tblCorrigendum.corrigendumId=:corrigendumId and oldValue='Pending' and fieldName='AddNoticeDocument')";
            String strCorrigendumDetailQuery = "delete from  TblCorrigendumDetail  where tblCorrigendum.corrigendumId=:corrigendumId";
            String strCorrigendumQuery = "delete from  TblCorrigendum  where corrigendumId=:corrigendumId";
            hibernateQueryDao.updateDeleteNewQuery(strCorrigendumDetailDocsQuery, var);
            hibernateQueryDao.updateDeleteNewQuery(strCorrigendumDetailQuery, var);
            hibernateQueryDao.updateDeleteNewQuery(strCorrigendumQuery, var);
            deletePendingCurrencyByTenderId(tenderId);
            deletePendingEnvelopByTenderId(tenderId);
            deletePendingCorrigendumDocumentByTenderId(corrigendumId);
            flag = true;
        }
        return flag;
    }
    
    /**
     * Delete form when corrigendum is deleted.
     * @author Priyanka
     * @param corrigendumId
     */
    
    private void deletePendingFormByFormId(int corrigendumId) {
		// TODO Auto-generated method stub
    	List<Object> formIdList = new ArrayList<Object>(); 
    	List<Object> tableIdList = new ArrayList<Object>(); 
    	Map<String, Object> var = new HashMap<String, Object>();
    	var.put("corrigendumId", corrigendumId);
    	List<Object> lst = hibernateQueryDao.getSingleColQuery("select objectId from TblCorrigendumDetail where tblCorrigendum.corrigendumId=:corrigendumId and tblProcess.processId=4 and actionType = 1", var);
        if (lst != null && !lst.isEmpty()) {
        	for(Object formIds : lst)
        	{
        		formIdList.add(formIds);
        	}
                var.clear();
                var.put("formId",formIdList);
                hibernateQueryDao.updateDeleteNewQuery("delete from TblRebateForm where tblTenderForm.formId in (:formId)", var);
                List<Object> tableIdLists = hibernateQueryDao.getSingleColQuery("select tbltenderTable.tableId from TblTenderTable tbltenderTable where tbltenderTable.tblTenderForm.formId in (:formId)", var);
                if (tableIdLists != null && !tableIdLists.isEmpty()) {
                	for(Object tableIds : tableIdLists)
                	{
                		tableIdList.add(tableIds);
                	}
                }
                var.clear();
                var.put("tableId",tableIdList);
                hibernateQueryDao.updateDeleteNewQuery("delete from TblItemBidderMap tblitemBidderMap where tblitemBidderMap.tblTenderTable.tableId in (:tableId)", var);
        	var.clear();
        	var.put("formId", formIdList);
        	String strCorrigendumQuery = "delete from  TblTenderForm  where formId in (:formId)";
            hibernateQueryDao.updateDeleteNewQuery(strCorrigendumQuery, var);
        }
	}
    /**
     * 
     * @param formId
     * @param userDetailId
     * @param tenderId 
     */
    public void insertCorrigendumNewForm(int formId, int userDetailId, int tenderId,int isBiddingFormPublishWithTender) {
        TblProcess tblProcess = new TblProcess(4);
        int corrigendumId = getPendingCorrigendumId(tenderId);
        if (corrigendumId > 0) {
            TblCorrigendum tblCorrigendum = new TblCorrigendum(corrigendumId);

            TblCorrigendumDetail tblCorrigendumDetail = new TblCorrigendumDetail();

            tblCorrigendumDetail.setActionType(1);
            tblCorrigendumDetail.setCreatedBy(userDetailId);
            tblCorrigendumDetail.setFieldLabel("");
            tblCorrigendumDetail.setFieldName("");
            tblCorrigendumDetail.setOldValue("");
            tblCorrigendumDetail.setNewValue("");
            tblCorrigendumDetail.setObjectId(formId);

            tblCorrigendumDetail.setTblProcess(tblProcess);
            tblCorrigendumDetail.setTblCorrigendum(tblCorrigendum);

            tblCorrigendumDetailDao.addTblCorrigendumDetail(tblCorrigendumDetail);
        }
    }

    /**
     *
     * @param query
     * @param clientId
     * @return
     */
    public List<Object[]> generateListFmQuery(String query, int clientId) {
        query = query.replaceAll("\\+@LangId", WebUtils.getCookie(eventCreationService.getServletRequest(), "locale").getValue());
        Map<String, Object> var = null;
        if (query.contains("@ClientId")) {
            var = new HashMap<String, Object>();
            var.put("clientId", clientId);
            query = query.replaceAll("@ClientId", ":clientId");
        }
        return hibernateQueryDao.createNewQuery(query, var);
    }

    /**
     * @author VIPULP
     * @param corrigendumId
     * @return String
     */
    public String getCorrigendumDtlKeywordTxt(int corrigendumId) {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("corrigendumId", corrigendumId);
        String keyWordTxt = null;
        List<Object> lst = hibernateQueryDao.getSingleColQuery("select newValue from TblCorrigendumDetail where tblCorrigendum.corrigendumId=:corrigendumId and fieldName='keywordText'", var);
        if (!lst.isEmpty()) {
            keyWordTxt = (String) lst.get(0);
        }
        return keyWordTxt;
    }

    public boolean isCorrigendumPublished(int tenderId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        count = hibernateQueryDao.countForNewQuery("TblCorrigendum tblcorrigendum ", "tblcorrigendum.corrigendumId ", "tblcorrigendum.objectId=:tenderId and  tblcorrigendum.cstatus=1", var);
        return count != 0;
    }
    /** This method is to check the corrigendum pending.
     * @auther Mitesh
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public boolean isCorrigendumPending(int tenderId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        count = hibernateQueryDao.countForNewQuery("TblCorrigendum tblcorrigendum ", "tblcorrigendum.corrigendumId ", "tblcorrigendum.objectId=:tenderId and  tblcorrigendum.cstatus=0", var);
        return count != 0;
    }

    public boolean isCanelCurrency(int currId, int tenderId) throws Exception {
        long count = 0;
        int tenderCurrencyId = 0;
        Map<String, Object> currencyVar = new HashMap<String, Object>();
        currencyVar.put("tenderId", tenderId);
        currencyVar.put("currencyId", currId);
        List<Object> lst = hibernateQueryDao.getSingleColQuery("select tenderCurrencyId from TblTenderCurrency where tenderId=:tenderId and currencyId=:currencyId and isActive=1 and isDefault=1", currencyVar);
        if (!lst.isEmpty()) {
            tenderCurrencyId = (Integer) lst.get(0);
        }
        if (tenderCurrencyId != 0) {
            Map<String, Object> var = new HashMap<String, Object>();
            var.put("tenderCurrencyId", tenderCurrencyId);
            count = hibernateQueryDao.countForNewQuery("TblCorrigendumDetail tblcorrigendumdetail ", "tblcorrigendumdetail.corrigendumDetailId ", "tblcorrigendumdetail.objectId=:tenderCurrencyId and tblcorrigendumdetail.actionType=3", var);
        }
        return count != 0;
    }
    
    /**
     * 
     * @author bharat
     * @param corrigendumId
     * @param formId
     */
    public void deleteFormEntryFromCorrigendum(int corrigendumId, int formId) {
		Map<String, Object> corrigendumParameters = new HashMap<String, Object>();
		corrigendumParameters.put("corrigendumId", corrigendumId);
		corrigendumParameters.put("formId", formId);
		hibernateQueryDao.updateDeleteNewQuery("delete from TblCorrigendumDetail tblCorrigendumDetail where tblCorrigendumDetail.tblCorrigendum.corrigendumId=:corrigendumId and objectId=:formId", corrigendumParameters);
	}
    /**This method is used for the update minMandForms with the original mandatory forms is organize form not configured.
     * @auther Mitesh
     * @param tenderId
     * @param corrigendumId
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public void updateMinMandatoryFormsIfnotOrganize(int tenderId,int corrigendumId) throws Exception{ long flagCount=0;
    List<Object[]> list = null;
    Map<String, Object> var = new HashMap<String, Object>();
    //check if organize form configured.
         var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         StringBuilder query = new StringBuilder();
         query.append("select COUNT(tbltenderform.formId),tbltenderform.tblTenderEnvelope.envelopeId,tbltenderform.tblTenderEnvelope.minFormsReqForBidding from ");
         query.append(" TblTenderForm tbltenderform  where tbltenderform.isMandatory=1 and tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus=1 ");
         query.append(" group by tbltenderform.tblTenderEnvelope.envelopeId,tbltenderform.tblTenderEnvelope.minFormsReqForBidding");
         list = hibernateQueryDao.createNewQuery(query.toString(), var);
         if(list!=null && !list.isEmpty()){
             for (Object[] objects : list) {
             	  TblTenderEnvelope tblTenderEnvelope = tenderCommonService.getTenderEnvelopeById(Integer.valueOf(objects[1].toString()));
             	  int envId = tblTenderEnvelope.getTblEnvelope().getEnvId();
             	  var = new HashMap<String, Object>();
                   var.put("envelopeId",objects[1]);
             	  long totalformCount = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm", "tblTenderForm.formId", "tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.cstatus=1", var);
             	 long formCount = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm", "tblTenderForm.formId", "tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.isMandatory=1 and tblTenderForm.cstatus in (0,1)", var);
             	  if(envId!=5){
             		 var.clear();
                     var = new HashMap<String, Object>();
                     var.put("corrigendumId",corrigendumId);
                     List<Object[]> CorrigendumDetailList = hibernateQueryDao.createNewQuery("select objectId,oldValue,newValue,fieldName,actionType,tblProcess.processId from TblCorrigendumDetail tblcorrigendumdetail where tblcorrigendumdetail.tblCorrigendum.corrigendumId=:corrigendumId and tblcorrigendumdetail.tblProcess.processId in (4) and tblcorrigendumdetail.actionType in (1,3)", var);
                     if(CorrigendumDetailList != null && !CorrigendumDetailList.isEmpty()){
                   	  for(Object[] object : CorrigendumDetailList ){
                   		  if(((Integer)object[4] == 3 || (Integer)object[4] == 1) && (Integer)object[5] == 4){
                   			  var.clear();
                   			  var = new HashMap<String, Object>();
                   			  var.put("envelopeId",objects[1]);
                   			  var.put("minFormsReqForBidding",formCount);
                   			  hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minFormsReqForBidding=:minFormsReqForBidding where envelopeId=:envelopeId", var);
                   		  }
                   	   }
                   	  }
                   var.clear();
                   var = new HashMap<String, Object>();
                   var.put("corrigendumId",corrigendumId);
                   var.put("processId",3); //TblTenderEnvelope
                   var.put("actionType",2); // update.
                   List<Object[]> tblCorrigendumDetailList = hibernateQueryDao.createNewQuery("select objectId,oldValue,newValue,fieldName from TblCorrigendumDetail tblcorrigendumdetail where tblcorrigendumdetail.tblCorrigendum.corrigendumId=:corrigendumId and tblcorrigendumdetail.tblProcess.processId=:processId and tblcorrigendumdetail.actionType=:actionType", var);
                   if(tblCorrigendumDetailList != null && !tblCorrigendumDetailList.isEmpty()){
                 	  for(Object[] object : tblCorrigendumDetailList ){
                 		   int envelopeId = (Integer)object[0];
                 		   if(("minFormsReqforBidding".equalsIgnoreCase(object[3].toString())) && (Integer.parseInt(object[2].toString()))<=totalformCount && (Integer.parseInt(objects[1].toString())==(Integer)object[0]) ) {
                 			   var.clear();
                 			   var = new HashMap<String, Object>();
                 			   var.put("envelopeId",envelopeId);
                 			   var.put("minFormsReqforBidding",Integer.parseInt(object[2].toString()));
                 			   hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minFormsReqforBidding=:minFormsReqforBidding where envelopeId=:envelopeId", var);
                 		   }
                 	  }
                   }
                   
               	 }
               	 else{
               		var.clear();
               		var = new HashMap<String, Object>();
                    var.put("envelopeId",objects[1]);	  
              		long mandatoryCount = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm", "tblTenderForm.formId", "tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.isMandatory=1 and tblTenderForm.cstatus in (1,0) and tblTenderForm.isPriceBid=1", var);
               		var.clear();
                    var = new HashMap<String, Object>();
                    var.put("corrigendumId",corrigendumId);
                    List<Object[]> CorrigendumDetailList = hibernateQueryDao.createNewQuery("select objectId,oldValue,newValue,fieldName,actionType,tblProcess.processId from TblCorrigendumDetail tblcorrigendumdetail where tblcorrigendumdetail.tblCorrigendum.corrigendumId=:corrigendumId and tblcorrigendumdetail.tblProcess.processId in (4) and tblcorrigendumdetail.actionType in (1,3)", var);
                    if(CorrigendumDetailList != null && !CorrigendumDetailList.isEmpty()){
                  	  for(Object[] object : CorrigendumDetailList ){
                  		  if(((Integer)object[4] == 3 || (Integer)object[4] == 1) && (Integer)object[5] == 4){
                  			  var.clear();
                  			  var = new HashMap<String, Object>();
                  			  var.put("envelopeId",objects[1]);
                  			  var.put("minFormsReqForBidding",mandatoryCount);
                  			  hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minFormsReqForBidding=:minFormsReqForBidding where envelopeId=:envelopeId", var);
                  		  }
                  	   }
                  	  }
                      var.clear();
                      var = new HashMap<String, Object>();
                      var.put("corrigendumId",corrigendumId);
                      var.put("processId",3); //TblTenderEnvelope
                      var.put("actionType",2); // update.
                      List<Object[]> tblCorrigendumDetailList = hibernateQueryDao.createNewQuery("select objectId,oldValue,newValue,fieldName from TblCorrigendumDetail tblcorrigendumdetail where tblcorrigendumdetail.tblCorrigendum.corrigendumId=:corrigendumId and tblcorrigendumdetail.tblProcess.processId=:processId and tblcorrigendumdetail.actionType=:actionType", var);
                      if(tblCorrigendumDetailList != null && !tblCorrigendumDetailList.isEmpty()){
                    	  for(Object[] object : tblCorrigendumDetailList ){
                    		   int envelopeId = (Integer)object[0];
                    		 Map<String, Object> map = new HashMap<String, Object>();
                    		 map.put("envelopeId",objects[1]);
                    	  long totalpricebidformCount = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm", "tblTenderForm.formId", "tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.cstatus=1 and tblTenderForm.isPriceBid=1", map);
                    		if(("minFormsReqforBidding".equalsIgnoreCase(object[3].toString())) && (Integer.parseInt(object[2].toString()))<=totalpricebidformCount && (Integer.parseInt(objects[1].toString())==(Integer)object[0]) ) {
               			   var.clear();
               			   var = new HashMap<String, Object>();
               			   var.put("envelopeId",envelopeId);
               			   var.put("minFormsReqforBidding",Integer.parseInt(object[2].toString()));
               			   hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minFormsReqforBidding=:minFormsReqforBidding where envelopeId=:envelopeId", var);
               		   }
                    	  }
                      }
                      var.clear();
                      var = new HashMap<String, Object>();
                		var.put("envelopeId",objects[1]);
                		mandatoryCount = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm", "tblTenderForm.formId", "tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.isMandatory=1 and tblTenderForm.cstatus in (0,1) and tblTenderForm.isPriceBid=0", var);
                      var.clear();
                      var = new HashMap<String, Object>();
                      var.put("corrigendumId",corrigendumId);
                      List<Object[]> CorrigendumDetail = hibernateQueryDao.createNewQuery("select objectId,oldValue,newValue,fieldName,actionType,tblProcess.processId from TblCorrigendumDetail tblcorrigendumdetail where tblcorrigendumdetail.tblCorrigendum.corrigendumId=:corrigendumId and tblcorrigendumdetail.tblProcess.processId in (4) and tblcorrigendumdetail.actionType in (1,3)", var);
                      if(CorrigendumDetail != null && !CorrigendumDetail.isEmpty()){
                    	  for(Object[] object : CorrigendumDetail ){
                    		  if(((Integer)object[4] == 3 || (Integer)object[4] == 1) && (Integer)object[5] == 4){
                    			  var.clear();
                    			  var = new HashMap<String, Object>();
                    			  var.put("envelopeId",objects[1]);
                    			  var.put("minTechFormsReqforBidding",mandatoryCount);
                    			  hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minTechFormsReqforBidding=:minTechFormsReqforBidding where envelopeId=:envelopeId", var);
                    		  }
                    	   }
                    	  }
               		 Map<String, Object> map = new HashMap<String, Object>();
               		 map.put("envelopeId",objects[1]); 
                   	 long totaltechnicalformCount = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm", "tblTenderForm.formId", "tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.cstatus=1 and tblTenderForm.isPriceBid=0", map);
               		
               		 var.clear();
                      var = new HashMap<String, Object>();
                      var.put("corrigendumId",corrigendumId);
                      var.put("processId",3); //TblTenderEnvelope
                      var.put("actionType",2); // update.
                      tblCorrigendumDetailList = hibernateQueryDao.createNewQuery("select objectId,oldValue,newValue,fieldName from TblCorrigendumDetail tblcorrigendumdetail where tblcorrigendumdetail.tblCorrigendum.corrigendumId=:corrigendumId and tblcorrigendumdetail.tblProcess.processId=:processId and tblcorrigendumdetail.actionType=:actionType", var);
                      if(tblCorrigendumDetailList != null && !tblCorrigendumDetailList.isEmpty()){
                    	  for(Object[] object : tblCorrigendumDetailList ){
                    		   int envelopeId = (Integer)object[0];
                    			if(("minTechFormsReqforBidding".equalsIgnoreCase(object[3].toString())) && (Integer.parseInt(object[2].toString())<=totaltechnicalformCount) && (Integer.parseInt(objects[1].toString())==(Integer)object[0]) ) {
               			   var.clear();
               			   var = new HashMap<String, Object>();
               			   var.put("envelopeId",envelopeId);
               			   var.put("minTechFormsReqforBidding",Integer.parseInt(object[2].toString()));
               			   hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minTechFormsReqforBidding=:minTechFormsReqforBidding where envelopeId=:envelopeId", var);
               		   }
                    	  }
                      }
               		
               	 }
             }
         }
        
 }
    private int Integer(Object object) {
		// TODO Auto-generated method stub
		return 0;
	}

	/** This method is used to get all mandatory forms by envelopeId
     * @auther Mitesh
     * @param envelopeId
     * @param isMandatory
     * @return
     * @throws Exception 
     */
     public long getAllFormsMandatoryCountByEnvelopeId(int envelopeId,int isMandatory) throws Exception{    
    	long mandatoryCount=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId",envelopeId);
        var.put("cstatus",1);
        if(isMandatory!=0){
            var.put("isMandatory",isMandatory);
        }
        mandatoryCount = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm", "tblTenderForm.formId", "tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.cstatus=:cstatus"+(isMandatory!=0 ? " and tblTenderForm.isMandatory=:isMandatory" : ""), var);
        return mandatoryCount;
    }
     /** This method is to get corrigendumDetails by the tenderId.
      * @auther Mitesh
      * @param tenderId
      * @return
      * @throws Exception 
      */
      public List<Object[]> getCorrigendumDetailsByTenderId(int tenderId) throws Exception{ 
    	List<Object> list = null;
        List<Object[]> list1 = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append("select tblcorrigendum.corrigendumId from TblCorrigendum tblcorrigendum where tblcorrigendum.objectId=:tenderId and tblcorrigendum.cstatus=0");
        list = hibernateQueryDao.getSingleColQuery(query.toString(), var);
        if(list!=null && list.size()>0)
        {
            Object temp=list.get(0);
            var = new HashMap<String, Object>();
            var.put("objectId",tenderId);
            var.put("corrigendumId",Integer.parseInt(temp.toString()));
            query = new StringBuilder();
            query.append("select tblcorrigendumdetail.corrigendumDetailId,tblcorrigendumdetail.objectId,tblcorrigendumdetail.tblProcess.processId,tblcorrigendumdetail.actionType,");//3
            query.append("(select tbltenderform.tblTenderEnvelope.envelopeId from TblTenderForm tbltenderform where tbltenderform.formId=tblcorrigendumdetail.objectId)");//4
            query.append(" from TblCorrigendum tblcorrigendum ");
            query.append(" inner join  tblcorrigendum.tblCorrigendumDetail tblcorrigendumdetail ");
            query.append(" with tblcorrigendumdetail.tblProcess.processId=4 and tblcorrigendumdetail.actionType in (1,3) ");
            query.append(" where tblcorrigendum.objectId=:objectId and tblcorrigendumdetail.tblCorrigendum.corrigendumId=:corrigendumId");
            list1 = hibernateQueryDao.createNewQuery(query.toString(), var);
        }
        return list1;
    }
	
	/**
     * 
     * @param tblTender
     * @param tenderId
     * @param corrtype
     * @param corrstatus
     * @param corrigendumId
     * @param remarks
     * @param tenderRefno
     * @return
	 * @throws Exception 
     */
    public void toCoreTender2Cppp(int clientId, TblTender tblTender,int tenderId,String corrtype,String corrstatus,int corrigendumId,String remarks,String tenderRefno) throws Exception
    {	
    	List<TblClientCPPPConfig> clientCppConfigList = clientService.getCPPPDetailsByClient(clientId);
		
		if(clientCppConfigList != null && !clientCppConfigList.isEmpty() && clientCppConfigList.size() == 1)   // only if cppp configuration are available for particular client
		{
			TblClientCPPPConfig tblClientCPPPConfig = new TblClientCPPPConfig();
			tblClientCPPPConfig = (TblClientCPPPConfig)clientCppConfigList.get(0);
	    	
			String tenderCpppUrlViewCorr = tblClientCPPPConfig.getUrl() + "/etender/viewcorrigendum/"+ tblTender.getTenderId();
	  	  	//System.out.println("core url :"+ tblClientCPPPConfig.getUrl());
	  	  	int cnt=0;
	  	  	int ncharsIndex[] = {0,1,2,3};
	  	  	List<Object[]> list = null;
	  	  	StringBuilder strQuery = new StringBuilder(); 
	  	  	strQuery.append("select TDEPT.city as c0,TU.userName as c1,TDEPT.deptName as c2,TDEPT.address as c3,TST.cppStateId as c4 ") 
	  	  			.append(" from apptender.tbl_Tender TA inner join appclient.tbl_Department TDEPT on TA.deptId = TDEPT.deptId ") 
	  	  			.append(" inner join appuser.tbl_Officer TOF on TA.officerId=TOF.userId ") 
	  	  			.append(" inner join appuser.tbl_UserLogin TU on TOF.userId=TU.userId inner join appmaster.tbl_State TST on TDEPT.stateId=TST.stateId ")
	  	  			.append(" where TA.tenderId = ").append(tenderId);
	    	
	  	  	list =  hibernateQueryDao.createSQLQuery(strQuery.toString(), null, ncharsIndex, 5);
	    	if(list!=null && !list.isEmpty()){
	    		strQuery.delete(0, strQuery.length()); 
	  		  	strQuery.append(" INSERT INTO corrtend2cppp( corr_id , corr_date , xml_user_id, tender_refno, tid , corr_type , corr_status , tender_title , tender_desc , prequalification") 
		  		    .append(" , tender_location , tender_pincode , tia_details , tia_address , product_subcategory , return_url , remarks , currency ")
		  			.append(" , tender_fee , tender_value , emd , published_date , prebid_date , docsale_download_startdate , docsale_download_enddate , bid_submission_startdate") 
		  			.append(" , bid_submission_enddate , bid_opening_date , prod_id , tender_type , tender_category , form_contract , tender_sector , tender_state ")
		  	        .append(" ) VALUES(").append(corrigendumId).append(",")
		  	        .append("getdate(),'").append(replaceSpecialCharAndHtmlTags(tblClientCPPPConfig.getXml_user_id())).append("','").append(replaceSpecialCharAndHtmlTags(tenderRefno)).append("',").append(tenderId).append(",'")
		  	        .append(corrtype).append("','").append(corrstatus).append("','").append(replaceSpecialCharAndHtmlTags(tblTender.getTenderBrief().replace("—","&#8212;").replace("*", "&#42;"))).append("','").append(replaceSpecialCharAndHtmlTags(tblTender.getTenderDetail().replace("-","&#8212;").replace("*", "&#42;"))).append("','")
		  	        .append(tblTender.getPrequalification()).append("','").append(replaceSpecialCharAndHtmlTags(list.get(0)[0].toString())).append("',").append("null").append(",'").append(replaceSpecialCharAndHtmlTags(list.get(0)[1]+","+list.get(0)[2])).append("','")
		  	        .append(replaceSpecialCharAndHtmlTags(list.get(0)[3].toString())).append("','").append(tblTender.getKeywordText()).append("','").append(replaceSpecialCharAndHtmlTags(tenderCpppUrlViewCorr)).append("','").append(remarks).append("',")
		  	        .append(tblTender.getCurrencyId()==0?0:tblTender.getCurrencyId()).append(",'")
		  	        .append(tblTender.getDocumentFee()).append("','")
		  	        .append("0").append("','")
		  	        .append(tblTender.getEmdAmount()).append("',")
		  	        .append(convertDateFormateToIstForCPPP(convertDateToStringForCPPP(tblTender.getPublishedOn()))).append(",")
		  	        .append(convertDateFormateToIstForCPPP(convertDateToStringForCPPP(tblTender.getPreBidStartDate()))).append(",")
		  	        .append(convertDateFormateToIstForCPPP(convertDateToStringForCPPP(tblTender.getDocumentStartDate()))).append(",")
		  	        .append(convertDateFormateToIstForCPPP(convertDateToStringForCPPP(tblTender.getDocumentEndDate()))).append(",")
		  	        .append(convertDateFormateToIstForCPPP(convertDateToStringForCPPP(tblTender.getSubmissionStartDate()))).append(",")
		  	        .append(convertDateFormateToIstForCPPP(convertDateToStringForCPPP(tblTender.getSubmissionEndDate()))).append(",")
		  	        .append(convertDateFormateToIstForCPPP(convertDateToStringForCPPP(tblTender.getOpeningDate()))).append(",")
		  	        .append(tblTender.getProductId()==0?0:tblTender.getProductId()).append(",")
		  	        .append(tblTender.getTenderMode() == 3 ? 2 :tblTender.getTenderMode()).append(",")
		  	        .append(tblTender.getTblProcurementNature()!=null?tblTender.getTblProcurementNature().getProcurementNatureId():0).append(",")
		  	        .append(tblTender.getFormContract()==0?0:tblTender.getFormContract()).append(",")
		  	        .append(tblTender.getTenderSector()==0?0:tblTender.getTenderSector()).append(",'").append(list.get(0)[4]).append("')");
	  			 
	  	  	}
	  	 cnt =  hibernateQueryDao.updateDeleteSQLQuery(strQuery.toString(), null);
		}
    }
    
    /**
     * @author janak
     * @param date
     * @return
     */
    private String convertDateToStringForCPPP(Date date)
    {
  	String reportDate=""; 
  	if(date!=null){
      	Format df = new SimpleDateFormat("yyyy-MM-dd HH:mm");
      	reportDate = df.format(date);
      	reportDate = "'"+reportDate+"'";
  	}else{reportDate="null";}
  	return reportDate;	
    }
    
    /**
     * @author janak
     * @param date
     * @return
   * @throws ParseException 
     */
    private String convertDateFormateToIstForCPPP(String date) throws ParseException
    {
  	  String reportedDate="";
  	  if(!date.equalsIgnoreCase("null")){
  		  date = date.replace("'", "").trim();
  		  DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
  		  Date newDate = sdf.parse(date);
  		  sdf.setTimeZone(TimeZone.getTimeZone("GMT+5:30"));
      	  reportedDate="'"+sdf.format(newDate)+"'";
  	  }else{
  		  reportedDate="null";
  	  }
  	return reportedDate;	
    }
    
    private String replaceSpecialCharAndHtmlTags(String repHtmlSpeChar)
    {
    	org.jsoup.nodes.Document doc = Jsoup.parse(repHtmlSpeChar); 
    	String replaced =  doc.text().replaceAll("[^a-zA-Z0-9%&?=\\[\\]/():;,._\\s@#-]", " ");
    	return replaced;
    }
    /* used to get count whether bidding form change in corrigendum
     * @return
     * @throws Exception 
     */
    public boolean getPendingCorrigendumDetails(int tenderId,List<Integer> processId) throws Exception{ 
    	 List<Object[]> list = null;
    	 StringBuilder query = new StringBuilder();
    	 Map<String, Object> var = new HashMap<String, Object>();
    	 var = new HashMap<String, Object>();
         var.put("objectId",tenderId);
         var.put("processId",processId);
         query = new StringBuilder();
         query.append("SELECT tblcorrigendumdetail.corrigendumDetailId,tblcorrigendumdetail.objectId,tblcorrigendumdetail.tblProcess.processId,tblcorrigendumdetail.actionType");
         query.append(" FROM TblCorrigendum tblcorrigendum ");
         query.append(" INNER JOIN  tblcorrigendum.tblCorrigendumDetail tblcorrigendumdetail ");
         query.append(" WITH tblcorrigendumdetail.tblProcess.processId IN (:processId)");
         query.append(" WHERE tblcorrigendum.objectId=:objectId AND tblcorrigendum.cstatus=0");
         list = hibernateQueryDao.createNewQuery(query.toString(), var);
         return list!=null && !list.isEmpty() ? true : false;
    }

	public int isMin1FormMappedAfterCorrigendum(int tenderId,int processId1,int processId2) {
		Map<String, Object> var = new HashMap<String, Object>();
	      List<Object[]> list = null;
	      StringBuffer sb = new StringBuffer();
	      sb.append(" select  COUNT(1) , 1 FROM(SELECT count(CASE WHEN TF.cstatus = 1 or TF.cstatus = 0  THEN 1 END) - ");
	      sb.append(" count((CASE WHEN TF.cstatus = 1 AND CD.actionType = 3 THEN 1  END)) status,TE.envId");
	      sb.append(" FROM apptender.tbl_TenderEnvelope TE ");
	      sb.append(" LEFT JOIN apptender.tbl_TenderForm TF ON TE.envelopeId=TF.envelopeId and TE.minFormsReqForBidding>=0 and TF.isMandatory=1");
	      sb.append(" LEFT JOIN apptender.tbl_Corrigendum CM ON CM.objectId = TF.tenderId AND CM.cstatus=0 AND CM.processId = "+processId1+" ");
	      sb.append(" LEFT JOIN apptender.tbl_CorrigendumDetail CD ON CM.corrigendumId = CD.corrigendumId AND CD.processId =  "+processId2+" ");
	      sb.append(" AND CD.objectId = TF.formId ");
	      sb.append(" LEFT JOIN (SELECT TS.formId, COUNT(1) sorCount FROM apptender.tbl_TenderSOR TS GROUP BY TS.formId) TS ON TS.formId = TF.formId");
	      sb.append(" WHERE TF.tenderId = "+tenderId+" group by TE.envId) A where A.status=0");

	      list = hibernateQueryDao.createSQLQuery(sb.toString(), var);
	      String isMin1FormMappedAfterCorrigendum  = list.get(0)[0].toString();
	      int a = Integer.parseInt(isMin1FormMappedAfterCorrigendum) ;
	      return a;
	}   
	
	/**
   	 * Corrigendum update Event Payment Mode Type
   	 * @author Hira Chaudhary
   	 * @param int tenderId
   	 * @param int moduleId
   	 * @throws Exception
   	 */
    private int updateEventPaymentType(int tenderId,int payFor,int moduleId) {
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId", tenderId);
         var.put("payFor", payFor);
         var.put("moduleId", moduleId);
         return hibernateQueryDao.updateDeleteNewQuery("update TblEventPayment tbleventPayment  set tbleventPayment.isActive=0 where tbleventPayment.objectId = :tenderId and paymentFor=:payFor and tbleventPayment.moduleId=:moduleId", var);
 	}
    
    public int getCorrigendumDetailPaymentMode(int corrigendumId,String fieldName) {
    	int PayModeNewValue=0;
    	List<Object> listNewValue = null;
    	Map<String, Object> var = new HashMap<String, Object>();
    	var.put("corrigendumId", corrigendumId);
    	var.put("fieldName", fieldName);
    	listNewValue = hibernateQueryDao.getSingleColQuery("select newValue from TblCorrigendumDetail where tblCorrigendum.corrigendumId=:corrigendumId and fieldName=:fieldName", var);
    	if (listNewValue != null && !listNewValue.isEmpty()) {
    		PayModeNewValue = Integer.parseInt(listNewValue.get(0).toString().split("::")[1]);
        }	
    	return PayModeNewValue;
	}
    /**
   	 * Corrigendum update Event Payment Mode Type
   	 * @author Vijay Valaganath
   	 * @param int tenderId
   	 * @param int moduleId
   	 * @throws Exception
   	 */
    public List<Object[]> getPaymentTypeForEvent(int tenderId, int cstatus, int payfor,int moduleId)throws Exception {
    	List<Object[]> corrigendumIdList = null;
    	Map<String, Object> var = new HashMap<String, Object>();
		var.put("tenderId", tenderId);
		var.put("moduleId", moduleId);
		var.put("payfor", payfor);	        
         corrigendumIdList = hibernateQueryDao.createQuery("select tblpaymenttype.paymentTypeId , tblpaymenttype.lang" + WebUtils.getCookie(eventCreationService.getServletRequest(), "locale").getValue() + " from TblPayment tblpayment inner join tblpayment.tblPaymentType tblpaymenttype where tblpayment.objectId=:tenderId and tblpayment.tblModule.moduleId=:moduleId and tblpayment.paymentFor=:payfor group by tblpaymenttype.paymentTypeId , tblpaymenttype.lang" + WebUtils.getCookie(eventCreationService.getServletRequest(), "locale").getValue() + "", var);
		return corrigendumIdList;
	}
    /**
     * @author anjali
     * Check whether there is any corrigendum published or not and bidder has viewed it once or not
  	 * @param tenderId
  	 * @param corrigendumId
  	 * @param companyId
  	 * @return
  	 * @throws Exception
  	*/
    public boolean isCorrigendumViewHistoryPending(int tenderId,int corrigendumId,int companyId) throws Exception{
		boolean flag = false;
    	if(corrigendumId!=0){
    	  int count=0;
    	  StringBuilder query = new StringBuilder();
	      Map<String, Object> var = new HashMap<String, Object>();
	      var.put("tenderId", tenderId);
	      var.put("companyId", companyId);
	      var.put("corrigendumId",corrigendumId);
    	  query.append("select count(tblcorrigendumviewhistory.cstatus) from TblCorrigendumViewHistory tblcorrigendumviewhistory where ");
    	  query.append("tblcorrigendumviewhistory.corrigendumId=:corrigendumId and tblcorrigendumviewhistory.objectId=:tenderId ");
    	  query.append("and tblcorrigendumviewhistory.tblCompany.companyId=:companyId and tblcorrigendumviewhistory.cstatus=1");
    	  List<Object> list = hibernateQueryDao.singleColQuery(query.toString(), var);
	      if(list != null && !list.isEmpty()){
	    	count = Integer.parseInt(list.get(0).toString());
	    	 if(count==0){
	    		flag = true;
	    	   }
	        }
    	  }
		return flag;
	}
    /**
     * @author anjali
     * Insert data into TblCorrigendumViewHistory schema once bidder views corrigendum once
  	 * @param tenderId
  	 * @param corrigendumId
  	 * @param bidderId
  	 * @param companyId
  	 * @param serverDateAndTime
  	 * @return
  	 * @throws Exception
  	*/
    public void insertCorrigendumViewHistory(int tenderId,int corrigendumId,int bidderId,int companyId,Date serverDateAndTime) throws Exception{
    	if(corrigendumId!=0){
    	TblCorrigendumViewHistory tblActionViewHistory = new TblCorrigendumViewHistory();
    	tblActionViewHistory.setCorrigendumId(corrigendumId);
    	tblActionViewHistory.setObjectId(tenderId);
    	tblActionViewHistory.setTblCompany(new TblCompany(companyId));
    	tblActionViewHistory.setAcceptedBy(bidderId);
    	tblActionViewHistory.setViewedOn(serverDateAndTime);
    	tblActionViewHistory.setCstatus(1);
    	tblCorrigendumViewHistoryDao.saveOrUpdateTblCorrigendumViewHistory(tblActionViewHistory);
    	}
	}
    /**
     * @author anjali
     * Get latest published corrigendum for corresponding tender
  	 * @param tenderId
  	 * @return
  	 * @throws Exception
  	*/
    public int getCorrigendumId(int tenderId) throws Exception{
    	int corrigendumId = 0;
	    Map<String, Object> var = new HashMap<String, Object>();
	    var.put("objectId", tenderId);
	    List<Object> list = hibernateQueryDao.singleColQuery("select corrigendumId from TblCorrigendum where objectId=:objectId and cstatus = 1 order by createdOn desc",var);
	    if(list!=null && !list.isEmpty()){
	     corrigendumId = Integer.parseInt(list.get(0).toString());	
	    }
    	return corrigendumId;
    }
    
    /**
     * @author anjali
     * Get count of total no of corrigendum published for corresponding tender
  	 * @param tenderId
  	 * @param corrigendumId
  	 * @return
  	 * @throws Exception
  	*/
    public long getTotalCorrigendumPublished(int tenderId,int corrigendumId) throws Exception{
    	long count = 0;
	    Map<String, Object> var = new HashMap<String, Object>();
	    var.put("objectId", tenderId);
	    var.put("corrigendumId",corrigendumId);
	    count = hibernateQueryDao.countForNewQuery("TblCorrigendum","corrigendumId","corrigendumId<=:corrigendumId and objectId=:objectId and cstatus = 1",var);
    	return count;
    }
    /** This method is to check whether form is already cancelled using corrigendum or not
     * @auther anjali
     * @param corrigendumId
     * @param formId
     * @return
     * @throws Exception 
     */
    public boolean isFormCancelled(int corrigendumId,int formId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("corrigendumId", corrigendumId);
        var.put("objectId",formId);
        count = hibernateQueryDao.countForNewQuery("TblCorrigendumDetail tblCorrigendumDetail ", "tblCorrigendumDetail.corrigendumDetailId ", "tblCorrigendumDetail.tblCorrigendum.corrigendumId=:corrigendumId and  tblCorrigendumDetail.objectId=:objectId and tblCorrigendumDetail.actionType=3", var);
        return count != 0;
    }
    
    /** This method will revert back notice documents modification done after corrigendum prepare
     * CR : 24441
     * @auther anish bhavnani
     * @param corrigendumId
     * @return
     * @throws Exception 
     */
    public boolean revertNoticeDocumentsChanges(TblCorrigendum tblCorrigendum) throws Exception {/*
        long count = 0;
        int corrigendumId=tblCorrigendum.getCorrigendumId();
        Map<String, Object> var = new HashMap<String, Object>();
        Map<String, Object> var2 = new HashMap<String, Object>();
        if(corrigendumId!=0){
            var.put("corrigendumId", corrigendumId);
            var2.put("objectId", tblCorrigendum.getObjectId());
        	StringBuilder query=new StringBuilder("Select officerDocMappingCorrgendumId,CorrgendumId,officerDocMappingId,officerDocId,objectId,linkId,childId,mappedOn,mappedBy,approvedOn,approvedBy,cancelledOn,cancelledBy,cstatus from appuser.tbl_OfficerDocMappingAfterCorrigendum where CorrgendumId=:corrigendumId  order by officerDocMappingId asc");
        	StringBuilder query2=new StringBuilder("Select officerDocMappingId,officerDocId,objectId,linkId,childId,mappedOn,mappedBy,approvedOn,approvedBy,cancelledOn,cancelledBy,cstatus from appuser.tbl_OfficerDocMapping where objectId=:objectId");
        	List<Object[]> docsList=hibernateQueryDao.nativeSQLQuery(query2.toString(), var2);
        	List<Object[]> corrigendumList=hibernateQueryDao.nativeSQLQuery(query.toString(), var);
        	Set<Integer> docsMappingId=new HashSet<Integer>();
        	if(corrigendumList!=null && !corrigendumList.isEmpty()){
        		Map<String, Object> var1 = null;
        		StringBuilder query1=new StringBuilder();
        		int compare=0;
        			for(Object[] docs:docsList){
        				compare=0;
        				for(Object[] obj:corrigendumList){
        					if(Integer.parseInt(docs[0].toString())==Integer.parseInt(obj[2].toString())){
        					query1=new StringBuilder();
        					if(compare>0)
        						break;
        					compare++;
        					query1.append("UPDATE appuser.Tbl_OfficerDocMapping SET "
        							+ "cstatus=:cstatus,mappedBy=:mappedBy"
        							+ ",objectId=:objectId,linkId=:tblLink,cancelledBy=:cancelledBy"
        							+ ",officerDocId=:officerDocId,approvedBy=:approvedBy");
        					
        					var1=new HashMap<String, Object>();
        					var1.put("cstatus",Integer.parseInt(obj[13].toString()));
        					var1.put("mappedBy",Integer.parseInt(obj[8].toString()));
        					if(obj[7]!=null){
        						query1.append(",mappedOn=:mappedOn");
        						var1.put("mappedOn",obj[7].toString());
        					}
        					else
        						query1.append(",mappedOn=NULL");
        					var1.put("objectId",tblCorrigendum.getObjectId());
        					var1.put("docMappingId",Integer.parseInt(docs[0].toString()));
        					var1.put("tblLink",Integer.parseInt(obj[5].toString()));
        					var1.put("officerDocId",Integer.parseInt(obj[3].toString()));
        					var1.put("approvedBy",Integer.parseInt(obj[10].toString()));
        					if(obj[9]!=null){
        						query1.append(",approvedOn=:approvedOn");
        						var1.put("approvedOn",obj[9].toString());
        					}
        					else
        						query1.append(",approvedOn=NULL");
        					var1.put("cancelledBy",Integer.parseInt(obj[12].toString()));
        					if(obj[11]!=null){
        						query1.append(",cancelledOn=:cancelledOn");
        						var1.put("cancelledOn",obj[11].toString());
        					}
        					else
        						query1.append(",cancelledOn=NULL");
        					var1.put("childId",Integer.parseInt(obj[6].toString()));
        					var1.put("tenderId",tblCorrigendum.getObjectId());
        							query1.append(",childId=:childId WHERE officerDocMappingId in (:docMappingId) and objectId in (:tenderId)");
        					count= hibernateQueryDao.updateDeleteSQLNewQuery(query1.toString(), var1);
        				}
        			}
        		}
            	var1=new HashMap<String, Object>();
            	query1=new StringBuilder();
//            	var1.put("docsMappingId",docsMappingId);
            	var1.put("createdOn",tblCorrigendum.getCreatedOn());
            	var1.put("objectId",tblCorrigendum.getObjectId());
        		query1.append("Delete from TblOfficerDocMapping where objectId in (:objectId) and officerDocMappingId in (:docsMappingId)");
//            	query1.append("Delete from TblOfficerDocMapping where objectId in (:objectId) and mappedOn>=(:createdOn)");
            	query2=new StringBuilder("Select officerDocMappingId,cstatus,mappedOn from appuser.Tbl_OfficerDocMapping where objectId=:objectId  and mappedOn>(:createdOn)");
            	docsList=hibernateQueryDao.nativeSQLQuery(query2.toString(), var1);
            	for(Object[] docs:docsList){
            		String input = docs[2].toString();
                    SimpleDateFormat parser = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date date = parser.parse(input);
                    if(date.after(tblCorrigendum.getCreatedOn()))
                    	docsMappingId.add(Integer.parseInt(docs[0].toString()));            		
            	}
            	var1.remove("createdOn");
            	var1.put("docsMappingId",docsMappingId);
        		int delcount=hibernateQueryDao.updateDeleteNewQuery(query1.toString(), var1);
        		count=count==0?delcount:(count+delcount);
        	}
        }
        return count != 0;
    */
    	return true;
    	}
}
