package com.etl.eproc.etender.daointerface;

/**
 *
 * @author TaherT
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderAuditTrail;
import java.util.List;

public interface TblTenderAuditTrailDao  {

    public void addTblTenderAuditTrail(TblTenderAuditTrail tblTenderAuditTrail);

    public void deleteTblTenderAuditTrail(TblTenderAuditTrail tblTenderAuditTrail);

    public void updateTblTenderAuditTrail(TblTenderAuditTrail tblTenderAuditTrail);

    public List<TblTenderAuditTrail> getAllTblTenderAuditTrail();

    public List<TblTenderAuditTrail> findTblTenderAuditTrail(Object... values) throws Exception;

    public List<TblTenderAuditTrail> findByCountTblTenderAuditTrail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderAuditTrailCount();

    public void saveUpdateAllTblTenderAuditTrail(List<TblTenderAuditTrail> tblTenderAuditTrails);
}
