package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblConsortiumDetail;
import java.util.List;

public interface TblConsortiumDetailDao  {

    public void addTblConsortiumDetail(TblConsortiumDetail tblConsortiumDetail);

    public void deleteTblConsortiumDetail(TblConsortiumDetail tblConsortiumDetail);

    public void updateTblConsortiumDetail(TblConsortiumDetail tblConsortiumDetail);

    public List<TblConsortiumDetail> getAllTblConsortiumDetail();

    public List<TblConsortiumDetail> findTblConsortiumDetail(Object... values) throws Exception;

    public List<TblConsortiumDetail> findByCountTblConsortiumDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblConsortiumDetailCount();

    public void saveUpdateAllTblConsortiumDetail(List<TblConsortiumDetail> tblConsortiumDetails);
}