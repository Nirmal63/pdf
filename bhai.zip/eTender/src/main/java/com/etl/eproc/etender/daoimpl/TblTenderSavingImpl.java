package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderSavingDao;
import com.etl.eproc.etender.model.TblTenderSaving;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderSavingImpl extends AbcAbstractClass<TblTenderSaving> implements TblTenderSavingDao {

 

    @Override
    public void addTblTenderSaving(TblTenderSaving tblTenderSaving){
        super.addEntity(tblTenderSaving);
    }

    @Override
    public void deleteTblTenderSaving(TblTenderSaving tblTenderSaving) {
        super.deleteEntity(tblTenderSaving);
    }

    @Override
    public void updateTblTenderSaving(TblTenderSaving tblTenderSaving) {
        super.updateEntity(tblTenderSaving);
    }

    @Override
    public List<TblTenderSaving> getAllTblTenderSaving() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderSaving> findTblTenderSaving(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderSavingCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderSaving> findByCountTblTenderSaving(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderSaving(List<TblTenderSaving> tblTenderSavings){
        super.updateAll(tblTenderSavings);
    }
}
