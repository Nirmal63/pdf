package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderSaving;

import java.util.List;

public interface TblTenderSavingDao  {

    public void addTblTenderSaving(TblTenderSaving tblTenderSaving);

    public void deleteTblTenderSaving(TblTenderSaving tblTenderSaving);

    public void updateTblTenderSaving(TblTenderSaving tblTenderSaving);

    public List<TblTenderSaving> getAllTblTenderSaving();

    public List<TblTenderSaving> findTblTenderSaving(Object... values) throws Exception;

    public List<TblTenderSaving> findByCountTblTenderSaving(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderSavingCount();

    public void saveUpdateAllTblTenderSaving(List<TblTenderSaving> tblTenderSavings);
}