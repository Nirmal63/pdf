package com.etl.eproc.advertise.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.advertise.model.TblAdvertiseDigitalSignHistory;
import java.util.List;

public interface TblAdvertiseDigitalSignHistoryDao  {

    public void addTblAdvertiseDigitalSignHistory(TblAdvertiseDigitalSignHistory tblAdvertiseDigitalSignHistory);

    public void deleteTblAdvertiseDigitalSignHistory(TblAdvertiseDigitalSignHistory tblAdvertiseDigitalSignHistory);

    public void updateTblAdvertiseDigitalSignHistory(TblAdvertiseDigitalSignHistory tblAdvertiseDigitalSignHistory);

    public List<TblAdvertiseDigitalSignHistory> getAllTblAdvertiseDigitalSignHistory();

    public List<TblAdvertiseDigitalSignHistory> findTblAdvertiseDigitalSignHistory(Object... values) throws Exception;

    public List<TblAdvertiseDigitalSignHistory> findByCountTblAdvertiseDigitalSignHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAdvertiseDigitalSignHistoryCount();

    public void saveUpdateAllTblAdvertiseDigitalSignHistory(List<TblAdvertiseDigitalSignHistory> tblAdvertiseDigitalSignHistors);
}