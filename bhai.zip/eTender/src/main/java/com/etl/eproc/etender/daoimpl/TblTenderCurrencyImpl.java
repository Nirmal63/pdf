/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

/**
 *
 * @author taher.tinwala
 */

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderCurrencyDao;
import com.etl.eproc.etender.model.TblTenderCurrency;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderCurrencyImpl extends AbcAbstractClass<TblTenderCurrency> implements TblTenderCurrencyDao {

 
    @Override
    public void addTblTenderCurrency(TblTenderCurrency tblTenderCurrency){
        super.addEntity(tblTenderCurrency);
    }

    @Override
    public void deleteTblTenderCurrency(TblTenderCurrency tblTenderCurrency) {
        super.deleteEntity(tblTenderCurrency);
    }

    @Override
    public void updateTblTenderCurrency(TblTenderCurrency tblTenderCurrency) {
        super.updateEntity(tblTenderCurrency);
    }

    @Override
    public List<TblTenderCurrency> getAllTblTenderCurrency() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderCurrency> findTblTenderCurrency(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderCurrencyCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderCurrency> findByCountTblTenderCurrency(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderCurrency(List<TblTenderCurrency> tblTenderCurrencys){
        super.updateAll(tblTenderCurrencys);
    }

	@Override
	public void saveOrUpdateTblTenderCurrency(TblTenderCurrency tblTenderCurrency) {
		super.saveOrUpdateEntity(tblTenderCurrency);	
	}
}

