package com.etl.eproc.etender.daoimpl;

/*
 
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblBidderItemsDao;
import com.etl.eproc.etender.model.TblBidderItems;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblBidderItemsImpl extends AbcAbstractClass<TblBidderItems> implements TblBidderItemsDao {

   

    @Override
    public void addTblBidderItems(TblBidderItems tblBidderItems){
        super.addEntity(tblBidderItems);
    }

    @Override
    public void deleteTblBidderItems(TblBidderItems tblBidderItems) {
        super.deleteEntity(tblBidderItems);
    }

    @Override
    public void updateTblBidderItems(TblBidderItems tblBidderItems) {
        super.updateEntity(tblBidderItems);
    }

    @Override
    public List<TblBidderItems> getAllTblBidderItems() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBidderItems> findTblBidderItems(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBidderItemsCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBidderItems> findByCountTblBidderItems(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBidderItems(List<TblBidderItems> tblBidderItemss){
        super.updateAll(tblBidderItemss);
    }
}
