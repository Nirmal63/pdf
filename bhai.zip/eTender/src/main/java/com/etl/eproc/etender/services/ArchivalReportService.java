package com.etl.eproc.etender.services;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;
import org.springframework.web.servlet.View;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.controller.DynamicReportController;
import com.etl.eproc.etender.controller.TenderOpenController;
import com.etl.eproc.etender.controller.TenderReportController;
import com.etl.eproc.etender.daointerface.TblDynReportDao;
import com.etl.eproc.etender.model.TblDynReport;
import com.googlecode.htmlcompressor.compressor.HtmlCompressor;


@Service
public class ArchivalReportService {
	
	private Map<Integer, ClientBean> clientBeanMap = new HashMap<Integer, ClientBean>();
	private SessionBean sessionBean = null;
	
    @Autowired
    private ViewResolver viewResolver;
	@Autowired 
	private TenderOpenController tenderOpenController;
	@Autowired
    private DynamicReportController dynamicReportController;
	@Autowired
	private TenderReportController tenderReportController;
    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    @Autowired
    private TblDynReportDao tblDynReportDao;
    @Autowired
    private LoginService loginService;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private ArchivalExceptionHandlerService archivalExceptionHandlerService;
    
    @Value("#{projectProperties['archive.userId']?:1}")
    private int userId;
    @Value("#{linkProperties['marketplace_linkId']?:3361}")
    private int marketPlaceLinkId;
    private @Value("#{projectProperties['archive.database.server']}")
    String archiveDatabaseServer;
	
    @PostConstruct
	private void setInitData(){
    	List<Object> clientIds = hibernateQueryDao.singleColQuery("select tblClient.clientId from TblClient tblClient where tblClient.isActive=1", null);
    	for (Object clientId : clientIds) {
    		clientBeanMap.put((Integer)clientId, getClientBean((Integer)clientId));
		}
	}
    
	public void setSessionBeanAndClientBean(int clientId, HttpServletRequest request) {
		sessionBean = getSessionBean(clientBeanMap.get(clientId), userId);
		HttpSession session = request.getSession();
        session.setAttribute("clientObject", clientBeanMap.get(clientId));
        session.setAttribute("sessionObject", sessionBean);
    }
	
	public void removeSessionBeanAndClientBean(HttpServletRequest request) {
		HttpSession session = request.getSession();
        session.removeAttribute("clientObject");
        session.removeAttribute("sessionObject");
    }    
	
	public ClientBean getClientBean(int clientId) {
		ClientBean clientBean = null;
		try {
			Map<String, Object> var = new HashMap<String, Object>();
			var.put("clientId", clientId);
			List<Object[]> list1 = hibernateQueryDao.createNewQuery("select tblclient.clientId, tblclient.isDualCerti, tblclient.isPkiEnabled, tblclient.wordConversionFormat,tbltimezone.value,tbltimezone.abbreviation,tblclient.isPasswordEncryptionReq,tblclient.isSsoEnabled,tblclient.archieveContext,isnull(tblsector.tableName,''), tblclient.isConcurrentLogin,tblclient.isDIYClient,tblclient.showAccessDetail,tblclient.isOnlinePayment,tblclient.isCaptchaConfigured,tblclient.isloginLinkConfigured,tblclient.isCalendarConfigured,tblclient.isDcVerificationRequired,tblclient.isHomePageRequire,tblclient.homePageTypeId,tblclient.listingStyle,tblclient.searchPanelType,tblclient.isShowCompanyLogo,tblclient.logoLocation,tblclient.isEventStatusListing,tblclient.isGSTRequired,isnull(tblclientsector.tblSector.sectorId,0) ,tblclient.businessTieup, tblclient.isSigner, tblclient.autoInvoiceDocFee, tblclient.autoInvoiceEventRegFee, tblclient.autoInvoiceRegFee,tblclient.isAllowExternalUserToViewReport from  TblClient tblclient  inner join  tblclient.tblTimeZone tbltimezone left join tblclient.tblClientSector tblclientsector left join tblclientsector.tblSector tblsector where tblclient.clientId=:clientId and tblclient.isActive=1", var);
			if (list1 != null && !list1.isEmpty()) {
				List<Object> clientModuleIds = hibernateQueryDao.singleColQuery("select tblclientmodule.tblModule.moduleId From TblClientModule tblclientmodule where tblclientmodule.tblClient.clientId=:clientId and tblclientmodule.isActive=1", var);;
				StringBuilder modules = new StringBuilder();
				modules.append(",");
				for(Object clientModuleId:clientModuleIds) {
					modules.append(clientModuleId).append(",");
				}
				List<Object[]> clientInfo = hibernateQueryDao.createNewQuery("select d.deptName,tblclient.domainName from TblDepartment d inner join d.tblClient tblclient where tblclient.clientId=:clientId and d.deptId=tblclient.deptId", var);;
				if (clientInfo != null && !clientInfo.isEmpty()) {
					clientBean = new ClientBean((Integer) list1.get(0)[0], (Integer) list1.get(0)[1], (Integer) list1.get(0)[2], (Integer) list1.get(0)[3], list1.get(0)[4].toString(), list1.get(0)[5].toString(),(Integer) list1.get(0)[6],modules.toString(),(Integer)list1.get(0)[7]==1?true:false,list1.get(0)[8].toString(),clientInfo.get(0)[0].toString()+":"+clientInfo.get(0)[1].toString(), list1.get(0)[9].toString(), (Integer)list1.get(0)[10],(Integer)list1.get(0)[11],(Integer) list1.get(0)[12],(Integer) list1.get(0)[13],(Integer) list1.get(0)[15],(Integer) list1.get(0)[16],(Integer) list1.get(0)[17],(Integer) list1.get(0)[18],(Integer) list1.get(0)[19],(Integer) list1.get(0)[20],(Integer) list1.get(0)[21],(Integer) list1.get(0)[22],(Integer) list1.get(0)[23],(Integer) list1.get(0)[24],(Integer) list1.get(0)[25],(Integer) list1.get(0)[26],(Integer) list1.get(0)[27], (Integer) list1.get(0)[28], (Integer) list1.get(0)[29], (Integer) list1.get(0)[30], (Integer) list1.get(0)[31], (Integer)list1.get(0)[32]);
					clientBean.setClientInfo(clientInfo.get(0)[0].toString() + ":" + clientInfo.get(0)[1].toString());
				}
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return clientBean;
	}
	
	public SessionBean getSessionBean(ClientBean clientBean, int userId) {
		SessionBean sessionBean = null;
		try {
			sessionBean = new SessionBean();
			int clientId = clientBean.getClientId();
			TblUserLogin tblUserLogin = loginService.getUserDetailById(userId);
			sessionBean.setUserName(tblUserLogin.getLoginId());
	        sessionBean.setFullName(tblUserLogin.getUserName());
	        sessionBean.setUserId(tblUserLogin.getUserId());
	        sessionBean.setUserTypeId(1);
	        sessionBean.setIsAbcUser(sessionBean.getUserTypeId() == 1);
	        sessionBean.setUserDetailId(loginService.getUserDetailId(sessionBean.getUserId(), sessionBean.getUserTypeId() == 3 ? clientId : sessionBean.getUserTypeId() == 2 ? 0 : -1));
	        List<Object[]> lstObj = loginService.getLstLoginDtIpAddrById(sessionBean.getUserId(), clientId);
	        if (lstObj != null && lstObj.size() > 0) {
	            for (int i = 0; i < lstObj.size(); i++) {
	                Object[] object = lstObj.get(i);
	                sessionBean.setLastLoginDateTime((Date) object[0]);
	                sessionBean.setIpAddress(String.valueOf(object[1]));
	            }
	        }
	        List<Object[]> timeZone = loginService.getUserTimeZone(sessionBean.getUserId());
	        if (timeZone != null && !timeZone.isEmpty()) {
	            if(sessionBean.getUserTypeId() == 1) {
	                sessionBean.setTimeZoneOffset(clientBean.getTimeZone());
	                sessionBean.setTimeZoneAbbr(clientBean.getTimeZoneAbbr());                                                                                    
	            } else {
	                sessionBean.setTimeZoneOffset(timeZone.get(0)[0].toString());
	                sessionBean.setTimeZoneAbbr(timeZone.get(0)[1].toString());
	            }
	        }
	        if (sessionBean.getUserTypeId() != 2) {
	            if (sessionBean.isIsAbcUser()) {
	                clientId = 0;
	            }
	            List<Object[]> depDesigList = loginService.getDeptNDesigId(sessionBean.getUserId(), clientId);
	            if (!depDesigList.isEmpty()) {
	                sessionBean.setDeptId((Integer) depDesigList.get(0)[0]);
	                sessionBean.setDesignationId((Integer) depDesigList.get(0)[1]);
	                if (sessionBean.getUserTypeId() != 2) {
	                    StringBuilder right = new StringBuilder();
	                    List<Object> rights = loginService.getUserRights(sessionBean.getDesignationId());
	                    for (Object link : rights) {
	                        right.append(",").append(link);
	                    }
	                    boolean hasAccessEmarketPlace = loginService.hasAccessOfEmarketPlaceDashboard(clientBean.getClientId(), sessionBean.getUserId());
	                    if(hasAccessEmarketPlace) {//do change
	                    	right.append("," +marketPlaceLinkId);
	                    }
	                    right.append(",");
	                    sessionBean.setRights(right.toString());
	                }
	            }
	        }
	        sessionBean.setTrackLoginId(-1);
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return sessionBean;
	}
	
	public Object[] getArchiveDetails(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder query  = new StringBuilder();
        query.append(" SELECT archiveDataId,clientId,reportArchiveStatus,generatedReports,reportFailedAttempts ");
        query.append(" FROM "+archiveDatabaseServer+".apparchive.Tbl_ArchiveData ");
        query.append(" WHERE tenderId=:tenderId ");
  		List<Object[]> list = hibernateQueryDao.createSQLQuery(query.toString(), var);
        return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
	
	public boolean updateArchiveData(int archiveDataId, int reportArchiveStatus, int generatedReports, int reportFailedAttempts) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("archiveDataId", archiveDataId);
        var.put("reportArchiveStatus", reportArchiveStatus);
        var.put("generatedReports", generatedReports);
        var.put("reportFailedAttempts", reportFailedAttempts);
        StringBuilder query  = new StringBuilder();
        query.append(" UPDATE "+archiveDatabaseServer+".apparchive.Tbl_ArchiveData SET reportArchiveStatus=:reportArchiveStatus,generatedReports=:generatedReports,reportFailedAttempts=:reportFailedAttempts WHERE archiveDataId=:archiveDataId");
  		int count = hibernateQueryDao.updateDeleteSQLQuery(query.toString(), var);
  		if(count != 0) {
  			insertArchiveDataHistory(archiveDataId);
  		}
  		return (count != 0) ? true : false;
	}
	
	public boolean insertArchiveDataHistory(int archiveDataId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("archiveDataId", archiveDataId);
        StringBuilder query  = new StringBuilder();
        query.append(" INSERT INTO "+archiveDatabaseServer+".apparchive.Tbl_ArchiveDataHistory (archiveDataId,docArchiveStatus,reportArchiveStatus,generatedReport,isFor,createdOn)");
        query.append(" SELECT archiveDataId,0,reportArchiveStatus,generatedReports,2,GETDATE() ");
        query.append(" FROM "+archiveDatabaseServer+".apparchive.Tbl_ArchiveData ");
        query.append(" WHERE archiveDataId=:archiveDataId ");
  		int count = hibernateQueryDao.updateDeleteSQLQuery(query.toString(), var);
  		return (count != 0) ? true : false;
	}
	
	public List<Object[]> getArchiveFormDetails(int archiveDataId, int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("archiveDataId", archiveDataId);
        var.put("tenderId", tenderId);
        StringBuilder query  = new StringBuilder();
        query.append(" SELECT tblArchiveFormDetail.formDetailId,tblArchiveFormDetail.envelopeId,tblArchiveFormDetail.formId,tblArchiveFormDetail.individualReportStatus,tblArchiveFormDetail.comparativeReportStatus,bidCountDetails.bidCount ");
        query.append(" FROM "+archiveDatabaseServer+".apparchive.Tbl_ArchiveFormDetail tblArchiveFormDetail ");
        query.append(" INNER JOIN "+archiveDatabaseServer+".apparchive.Tbl_ArchiveTenderDetail tblArchiveTenderDetail ON tblArchiveTenderDetail.tenderDetailId=tblArchiveFormDetail.tenderDetailId ");
        query.append(" INNER JOIN ( ");
        query.append("  SELECT tblTenderForm.formId,COUNT(DISTINCT tblTenderBidDetail.bidDetailId) AS bidCount ");
        query.append("  From apptender.tbl_TenderForm tblTenderForm");
        query.append("  INNER JOIN apptender.tbl_TenderTable tblTenderTable ON tblTenderTable.formId=tblTenderForm.formId ");
        query.append("  LEFT JOIN apptenderbid.tbl_TenderBid tblTenderBid ON tblTenderBid.formId=tblTenderForm.formId ");
        query.append("  LEFT JOIN apptenderbid.tbl_TenderBidMatrix tblTenderBidMatrix ON tblTenderBidMatrix.bidId=tblTenderBid.bidId AND tblTenderBidMatrix.tableId=tblTenderTable.tableId ");
        query.append("  LEFT JOIN apptenderresult.tbl_TenderBidDetail tblTenderBidDetail ON tblTenderBidDetail.bidTableId=tblTenderBidMatrix.bidTableId ");
        query.append("  WHERE tblTenderForm.tenderId=:tenderId");
        query.append("  GROUP BY tblTenderForm.formId ");
        query.append(" ) bidCountDetails ON bidCountDetails.formId=tblArchiveFormDetail.formId ");
        query.append(" WHERE tblArchiveTenderDetail.archiveDataId=:archiveDataId AND tblArchiveTenderDetail.eventId=:tenderId ");
  		List<Object[]> list = hibernateQueryDao.createSQLQuery(query.toString(), var);
        return (list != null && !list.isEmpty()) ? list : null;
    }
	
	public boolean updateIndividualReportDetails(int formDetailId, String individualReportHtml) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("formDetailId", formDetailId);
        var.put("individualReportHtml", individualReportHtml);
        StringBuilder query  = new StringBuilder();
        query.append(" UPDATE "+archiveDatabaseServer+".apparchive.Tbl_ArchiveFormDetail SET individualReportStatus=1,individualReportHtml=:individualReportHtml WHERE formDetailId=:formDetailId");
  		int count = hibernateQueryDao.updateDeleteSQLQuery(query.toString(), var);
  		return (count != 0) ? true : false;
	}
	
	public boolean updateComparativeReportDetails(int formDetailId, String comparativeReportHtml) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("formDetailId", formDetailId);
        var.put("comparativeReportHtml", comparativeReportHtml);
        StringBuilder query  = new StringBuilder();
        query.append(" UPDATE "+archiveDatabaseServer+".apparchive.Tbl_ArchiveFormDetail SET comparativeReportStatus=1,comparativeReportHtml=:comparativeReportHtml WHERE formDetailId=:formDetailId");
  		int count = hibernateQueryDao.updateDeleteSQLQuery(query.toString(), var);
  		return (count != 0) ? true : false;
	}
	
	public boolean updateL1ReportDetails(int archiveDataId, int tenderId, String l1ReportHtml) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("archiveDataId", archiveDataId);
        var.put("tenderId", tenderId);
        var.put("l1ReportHtml", l1ReportHtml);
        StringBuilder query  = new StringBuilder();
        query.append(" UPDATE "+archiveDatabaseServer+".apparchive.Tbl_ArchiveTenderDetail SET l1ReportHtml=:l1ReportHtml WHERE archiveDataId=:archiveDataId AND eventId=:tenderId");
  		int count = hibernateQueryDao.updateDeleteSQLQuery(query.toString(), var);
  		return (count != 0) ? true : false;
	}
	
	public boolean updateAuditTrialReportDetails(int archiveDataId, int tenderId, String auditTrialReportHtml) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("archiveDataId", archiveDataId);
        var.put("tenderId", tenderId);
        var.put("auditTrialReportHtml", auditTrialReportHtml);
        StringBuilder query  = new StringBuilder();
        query.append(" UPDATE "+archiveDatabaseServer+".apparchive.Tbl_ArchiveTenderDetail SET auditTrialReportHtml=:auditTrialReportHtml WHERE archiveDataId=:archiveDataId AND eventId=:tenderId");
  		int count = hibernateQueryDao.updateDeleteSQLQuery(query.toString(), var);
  		return (count != 0) ? true : false;
	}
	
	public boolean updateArchiveFormDetails(int formDetailId, String columnName, int status) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("formDetailId", formDetailId);
        var.put("status", status);
        StringBuilder query  = new StringBuilder();
        query.append(" UPDATE "+archiveDatabaseServer+".apparchive.Tbl_ArchiveFormDetail SET "+columnName+"=:status WHERE formDetailId=:formDetailId");
  		int count = hibernateQueryDao.updateDeleteSQLQuery(query.toString(), var);
  		return (count != 0) ? true : false;
	}
	
	public Document cleanDocument(Document document) {
		document.select("script,img,.removedata,.removeDIV,.go-back").remove();
		document.select("a").unwrap();
		return document;
	}
	
	public boolean generateIndividualReport(int archiveDataId, int tenderId, List<Object[]> archiveFormDetailsList, ModelMap modelMap, HttpServletRequest request, HttpServletResponse response, HttpSession session,RedirectAttributes redirectAttributes) {
		boolean isSuccess = false;
		int operation = 1, commiteeType = 1;
		try {
			if(archiveFormDetailsList != null && !archiveFormDetailsList.isEmpty()) {
				for (Object[] archiveFormDetails : archiveFormDetailsList) {
					int formDetailId = (Integer)archiveFormDetails[0];
					int envelopeId = (Integer)archiveFormDetails[1];
					int formId = (Integer)archiveFormDetails[2];
					int individualReportStatus = Integer.parseInt(archiveFormDetails[3].toString());
					int bidCount  = Integer.parseInt(archiveFormDetails[5].toString());
					if(individualReportStatus == 0 && bidCount > 0) {
						ModelMap newModelMap = (ModelMap)modelMap.clone();
						String view = tenderOpenController.showTenderOpeningIndividualReport(tenderId, envelopeId, formId, operation, commiteeType, newModelMap, request, session,redirectAttributes);
						if(newModelMap.get("Exception") == null) {
							HtmlCompressor compressor = new HtmlCompressor();
							MockHttpServletResponse mockResp = new MockHttpServletResponse();
							View resolvedView = viewResolver.resolveViewName(view, request.getLocale());
							resolvedView.render(newModelMap, request, mockResp);
		
							Document doc = cleanDocument(Jsoup.parse(mockResp.getContentAsString()));
							String individualReportHtml = compressor.compress(doc.select("div#dataDiv").html());
							isSuccess = updateIndividualReportDetails(formDetailId, individualReportHtml);
							if(!isSuccess) {
								break;
							}
						} else {
							throw (Exception) newModelMap.get("Exception");
						}
					} else if(bidCount == 0) {
						isSuccess = updateArchiveFormDetails(formDetailId, "individualReportStatus", 2);
					}
				}
			}
		} catch (Exception e) {
			isSuccess = false;
			archivalExceptionHandlerService.writeLog(archiveDataId, 1, 3, e);
		}
		return isSuccess;
	}
	
	public boolean generateComparativeReport(int archiveDataId, int tenderId, List<Object[]> archiveFormDetailsList, ModelMap modelMap, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		boolean isSuccess = false;
		int operation = 1, commiteeType = 1;
		try {
			if(archiveFormDetailsList != null && !archiveFormDetailsList.isEmpty()) {
				for (Object[] archiveFormDetails : archiveFormDetailsList) {
					int formDetailId = (Integer)archiveFormDetails[0];
					int envelopeId = (Integer)archiveFormDetails[1];
					int formId = (Integer)archiveFormDetails[2];
					int comparativeReportStatus = Integer.parseInt(archiveFormDetails[4].toString());
					int bidCount  = Integer.parseInt(archiveFormDetails[5].toString());
					if(comparativeReportStatus == 0 && bidCount > 0) {
						ModelMap newModelMap = (ModelMap)modelMap.clone();
						String view = tenderOpenController.showTenderOpeningVerticalComparativeReport(tenderId, envelopeId, formId, operation, commiteeType, newModelMap, request, session);
						if(newModelMap.get("Exception") == null) {
							HtmlCompressor compressor = new HtmlCompressor();
							MockHttpServletResponse mockResp = new MockHttpServletResponse();
							View resolvedView = viewResolver.resolveViewName(view, request.getLocale());
							resolvedView.render(newModelMap, request, mockResp);
							
							Document doc = cleanDocument(Jsoup.parse(mockResp.getContentAsString()));
							String comparativeReportHtml = compressor.compress(doc.select("div#pdfContains").html());
							isSuccess = updateComparativeReportDetails(formDetailId, comparativeReportHtml);
							if(!isSuccess) {
								break;
							}
						} else {
							throw (Exception) newModelMap.get("Exception");
						}
					} else if(bidCount == 0) {
						isSuccess = updateArchiveFormDetails(formDetailId, "comparativeReportStatus", 2);
					}
				}
			}
		} catch (Exception e) {
			isSuccess = false;
			archivalExceptionHandlerService.writeLog(archiveDataId, 2, 3, e);
		}
		return isSuccess;
	}
	
	public boolean generateL1Report(int archiveDataId, int tenderId, ModelMap modelMap, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		boolean isSuccess = false;
		int reportFor = 1, tabId = 9;
		try {
			List<TblDynReport> tblDynReportList = tblDynReportDao.findTblDynReport("tblTender.tenderId",Operation_enum.EQ,tenderId, "reportFor",Operation_enum.EQ,reportFor, "reportOn",Operation_enum.IN,new Object[] {1,2,8});
			if(tblDynReportList != null && !tblDynReportList.isEmpty()) {
				int reportId = tblDynReportList.get(0).getReportId();
				ModelMap newModelMap = (ModelMap)modelMap.clone();
				String view = dynamicReportController.generateDynamicReport(tenderId, reportId, reportFor, tabId, newModelMap, request);	
				if(newModelMap.get("Exception") == null) {
					HtmlCompressor compressor = new HtmlCompressor();
					MockHttpServletResponse mockResp = new MockHttpServletResponse();
					View resolvedView = viewResolver.resolveViewName(view, request.getLocale());
					resolvedView.render(newModelMap, request, mockResp);
					
					Document doc = cleanDocument(Jsoup.parse(mockResp.getContentAsString()));
					String l1ReportHtml = compressor.compress(doc.select("div#PrintOrPdf_WFFILE").html());
					isSuccess = updateL1ReportDetails(archiveDataId, tenderId, l1ReportHtml);
				} else {
					throw (Exception) newModelMap.get("Exception");
				}
			}
		} catch (Exception e) {
			isSuccess = false;
			archivalExceptionHandlerService.writeLog(archiveDataId, 3, 3, e);
		}
		return isSuccess;
	}
	
	public boolean generateAuditTrialReport(int archiveDataId, int tenderId, ModelMap modelMap, HttpServletRequest request, HttpServletResponse response, HttpSession session) {
		boolean isSuccess = false;
		int operationType = 1, reportType = 2;
		try {
			ModelMap newModelMap = (ModelMap)modelMap.clone();
			String view = tenderReportController.getTenderAuditTrialReport(tenderId, operationType, reportType, newModelMap, request, session);		
			if(newModelMap.get("Exception") == null) {
				HtmlCompressor compressor = new HtmlCompressor();
				MockHttpServletResponse mockResp = new MockHttpServletResponse();
				View resolvedView = viewResolver.resolveViewName(view, request.getLocale());
				resolvedView.render(newModelMap, request, mockResp);
				
				Document doc = cleanDocument(Jsoup.parse(mockResp.getContentAsString()));
				String auditTrialReportHtml = compressor.compress(doc.select("div#temp").html());
				isSuccess = updateAuditTrialReportDetails(archiveDataId, tenderId, auditTrialReportHtml);
			} else {
				throw (Exception) newModelMap.get("Exception");
			}
		} catch (Exception e) {
			isSuccess = false;
			archivalExceptionHandlerService.writeLog(archiveDataId, 4, 3, e);
		}
		return isSuccess;
	}
}
