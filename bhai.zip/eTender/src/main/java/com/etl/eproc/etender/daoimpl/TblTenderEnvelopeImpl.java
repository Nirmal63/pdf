package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderEnvelopeDao;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderEnvelopeImpl extends AbcAbstractClass<TblTenderEnvelope> implements TblTenderEnvelopeDao {


    @Override
    public void addTblTenderEnvelope(TblTenderEnvelope tblTenderEnvelope) {
        super.addEntity(tblTenderEnvelope);
    }

    @Override
    public void deleteTblTenderEnvelope(TblTenderEnvelope tblTenderEnvelope) {
        super.deleteEntity(tblTenderEnvelope);
    }

    @Override
    public void updateTblTenderEnvelope(TblTenderEnvelope tblTenderEnvelope) {
        super.updateEntity(tblTenderEnvelope);
    }

    @Override
    public List<TblTenderEnvelope> getAllTblTenderEnvelope() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderEnvelope> findTblTenderEnvelope(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderEnvelopeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderEnvelope> findByCountTblTenderEnvelope(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderEnvelope(List<TblTenderEnvelope> tblTenderEnvelopes) {
        super.updateAll(tblTenderEnvelopes);
    }

	@Override
	public void saveOrUpdateTblTenderEnvelope(TblTenderEnvelope tblTenderEnvelope) {
		super.saveOrUpdateEntity(tblTenderEnvelope);
	}
}