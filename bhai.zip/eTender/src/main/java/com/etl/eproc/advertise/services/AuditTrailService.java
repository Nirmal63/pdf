/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.advertise.services;

import com.etl.eproc.advertise.daointerface.TblAdvertiseAuditTrailDao;
import com.etl.eproc.advertise.daointerface.TblAdvertiseDigitalSignHistoryDao;
import com.etl.eproc.advertise.model.TblAdvertiseAuditTrail;
import com.etl.eproc.advertise.model.TblAdvertiseDigitalSignHistory;
import com.etl.eproc.common.model.TblAuditTrail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

/**
 *
 * @author hiral
 */
@Service("AdvertiseAuditTrailService")
public class AuditTrailService {
    @Autowired
    private TblAdvertiseAuditTrailDao tblAdvertiseAuditTrailDao;
    @Autowired
    private TblAdvertiseDigitalSignHistoryDao tblAdvertiseDigitalSignHistoryDao;
    
    public void makeAuditTrail(Object audit, int linkId, String remarks, Integer advertiseId,Integer objectId,String... remarkSign) {
		RequestContextHolder.getRequestAttributes().setAttribute("helpLinkId", linkId, RequestAttributes.SCOPE_REQUEST);// To use to generate help content.
		if (audit != null && audit instanceof TblAuditTrail) {
			TblAuditTrail auditMasterAdmin = (TblAuditTrail) audit;
			TblAdvertiseAuditTrail auditMaster = new TblAdvertiseAuditTrail();
			auditMaster.setPageUrl(auditMasterAdmin.getPageUrl());
			auditMaster.setTblTrackLogin(auditMasterAdmin.getTblTrackLogin());
			auditMaster.setRemark(remarks != null ? remarks : "");
			auditMaster.setLinkId(linkId);
			auditMaster.setAdvertiseId(advertiseId==null ? 0 : advertiseId);
			auditMaster.setObjectId(objectId==null ? 0 : objectId);
			tblAdvertiseAuditTrailDao.addTblAdvertiseAuditTrail(auditMaster);                
			if (remarkSign != null && remarkSign.length!=0) {
				TblAdvertiseDigitalSignHistory signHistory = new TblAdvertiseDigitalSignHistory();
				signHistory.setRemark(remarkSign[0]);
				if (remarkSign.length == 2) {
					signHistory.setSignText(remarkSign[1]);
				}                
				signHistory.setTblAdvertiseAuditTrail(auditMaster);
				tblAdvertiseDigitalSignHistoryDao.addTblAdvertiseDigitalSignHistory(signHistory);
			}
		}
	}
}
