/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author dipal
 */
@Component
public class SPBidderListForDecryption extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderresult.P_BidderListForDecryption";

    public SPBidderListForDecryption() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_EnvelopeId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_FormId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_SessionUserId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_Flag", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_BidderIds", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_RebetId", Types.VARCHAR));
    }


     public Map<String,Object> executeProcedure(int tenderId, int envelopeId, int fomrId, int sessionUserId, int flag, String bidderIds,int rebeteId) throws Exception
    {
        Map inParams = new HashMap();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_EnvelopeId", envelopeId);
        inParams.put("@V_FormId", fomrId);
        inParams.put("@V_SessionUserId", sessionUserId);
        inParams.put("@V_Flag", flag);
        inParams.put("@V_BidderIds", bidderIds);
        inParams.put("@V_RebetId", rebeteId);
        this.compile();
        return execute(inParams);
    }
}
