/**
 * 
 */
package com.etl.eproc.etender.services;

import java.util.List;
import java.util.logging.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.springframework.stereotype.Component;

import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.model.TblClientCPPPConfig;
import com.etl.eproc.common.services.ExceptionHandlerService;

/**
 * @author janak
 * @since 16 apr 2015
 *
 */
@Component
public class Tender2CpppTaskExecutor implements Job {

	/* (non-Javadoc)
	 * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
	 */
	private static final Logger logger = Logger.getLogger(Tender2CpppTaskExecutor.class.toString());
	
	@Override
	public void execute(JobExecutionContext context) throws JobExecutionException {

		ExceptionHandlerService exceptionHandlerService=null;
		Drupal_RestClient drupal_RestClient = null;
		HibernateQueryDao hibernateQueryDao = null;
		TblClientCPPPConfig tblClientCPPPConfig = null;
		String tenderCPPP_ipAddress = null;
		try {
			exceptionHandlerService = (ExceptionHandlerService) context.getScheduler().getContext().get("exceptionHandlerService");
			drupal_RestClient =  (Drupal_RestClient) context.getScheduler().getContext().get("drupal_RestClient");
			hibernateQueryDao =  (HibernateQueryDao) context.getScheduler().getContext().get("hibernateQueryDao");
			tenderCPPP_ipAddress =  (String) context.getScheduler().getContext().get("tenderCPPP_ipAddress");
			if(drupal_RestClient.isCpppAvailable(tenderCPPP_ipAddress))
			{	
				StringBuilder clientCPPPConfig = new StringBuilder(); 
	            clientCPPPConfig.append(" SELECT DISTINCT TCCC.cppp_Id, TCCC.clientId, TCCC.xml_user_id, TCCC.username, TCCC.password, TCCC.url FROM appclient.tbl_ClientCPPPConfig TCCC ");
	            clientCPPPConfig.append(" RIGHT JOIN  ( ");
		            clientCPPPConfig.append(" SELECT TC.xml_user_id as xml_user_id  FROM dbo.tenders2cppp TC ");
		            clientCPPPConfig.append(" UNION ");
		            clientCPPPConfig.append(" SELECT CTC.xml_user_id as xml_user_id  FROM dbo.corrtend2cppp CTC ");
		            clientCPPPConfig.append(" ) as unionXmlUsers ");
	            clientCPPPConfig.append(" ON unionXmlUsers.xml_user_id = TCCC.xml_user_id ");
	            List<Object[]> lst =  hibernateQueryDao.createSQLQuery(clientCPPPConfig.toString(), null);
	            tblClientCPPPConfig = new TblClientCPPPConfig();
	            if(lst!=null && !lst.isEmpty()){
	        		for (int i = 0; i < lst.size(); i++) {
	        			tblClientCPPPConfig.setCppp_Id((Integer)lst.get(i)[0]);
	        			tblClientCPPPConfig.setXml_user_id((String)lst.get(i)[2]);
	        			tblClientCPPPConfig.setUsername((String)lst.get(i)[3]);
	        			tblClientCPPPConfig.setPassword((String)lst.get(i)[4]);
	        			tblClientCPPPConfig.setUrl((String)lst.get(i)[5]);
	        			drupal_RestClient.Main(tblClientCPPPConfig.getXml_user_id().toString(), tblClientCPPPConfig.getUsername().toString(),tblClientCPPPConfig.getPassword().toString()); 
					}
	        	}
			}
	 } catch (Exception e) {
     	e.printStackTrace();
         exceptionHandlerService.writeLog(e);
     }

	}

}
