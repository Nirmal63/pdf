package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.etender.model.TblTenderSOR;
import java.util.List;

public interface TblTenderSORDao  {

    public void addTblTenderSOR(TblTenderSOR tblTenderSOR);

    public void deleteTblTenderSOR(TblTenderSOR tblTenderSOR);

    public void updateTblTenderSOR(TblTenderSOR tblTenderSOR);

    public List<TblTenderSOR> getAllTblTenderSOR();

    public List<TblTenderSOR> findTblTenderSOR(Object... values) throws Exception;

    public List<TblTenderSOR> findByCountTblTenderSOR(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblTenderSORCount();

    public void saveUpdateAllTblTenderSOR(List<TblTenderSOR> tblTenderSORs);
}