/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author dipal
 */
@Component
public class SPGetTenderMisReport extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "appreport.P_TenderMisReport";

    public SPGetTenderMisReport() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_ClientId", Types.SMALLINT));
        this.declareParameter(new SqlParameter("@V_EventId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_OfficerId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_DeptId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_ReferenceNo", Types.VARCHAR));
        
        this.declareParameter(new SqlParameter("@V_PublishDateOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_PublishDateFrom", Types.DATE));
        this.declareParameter(new SqlParameter("@V_PublishDateTo", Types.DATE));
        
        this.declareParameter(new SqlParameter("@V_EstimatedValueOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_EstimatedValueFrom", Types.DOUBLE));
        this.declareParameter(new SqlParameter("@V_EstimatedValueTo", Types.DOUBLE));
        
        this.declareParameter(new SqlParameter("@V_SubmissionEndDateOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_SubmissionEndDateFrom", Types.DATE));
        this.declareParameter(new SqlParameter("@V_SubmissionEndDateTo", Types.DATE));
        
        this.declareParameter(new SqlParameter("@V_TypeOfContract", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_BiddingAccess", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_BiddingType", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_Status", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_TimeZoneOffset", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_ConversionValue", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_LangId", Types.TINYINT));//to be added
        
        //this.declareParameter(new SqlParameter("@V_IsShowSrNo", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowDepartment", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowEventID", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowReferenceNo", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowEstimatedValue", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowEMD", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowDocFees", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowBiddingAccess", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowPreBidAllowed", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowTypeOfContract", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowBiddingType", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowSubmissionEndDate", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowPublishDate", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowopeningDate", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowNoOfMappedBidders", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowNoOfBiddersFS", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowPQEnvelopeOpenedOn", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowNoOfQualifiedBiddersInPQEnvelope", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowDocFeesEMDEnvelopeOpenedOn", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowNoOfQualifiedBiddersInDocFeesEMDEnvelope", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowTechicalEnvelopeOpenedOn", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowNoOfQualifiedBiddersInTechnicalEnvelope", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowPriceBidEnvelopeOpenedOn", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowNoOfQualifiedBiddersInPriceBidEnvelope", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowTechnoCommercialEnvelopeOpenedOn", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowNoOfQualifiedBiddersInTechnoCommercialEnvelope", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowNameOfTenderOwner", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowEmailIdOfTenderOwner", Types.BIT));
        
        this.declareParameter(new SqlParameter("@V_RecordsPerPage", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_PageNo", Types.INTEGER));
        
        this.declareParameter(new SqlOutParameter("@V_TotalPages", Types.INTEGER));
        this.declareParameter(new SqlOutParameter("@V_TotalRecords", Types.INTEGER));
        //this.declareParameter(new SqlOutParameter("@v_tabCountDetails", Types.VARCHAR));
        
    }

    /**
     * Method use for call store procedure for get Individual, Comparative, Bidder wise abstract report details.
     * @param tenderId
     * @param reportTypeId
     * @return {@code Map<String,Object>}
     * @throws Exception 
     */
    public Map<String,Object> executeProcedure(int clientId,int eventId,int officerId,int departmentId,String refNo,int publishDateOperator,Date eventPubDateFrom,Date eventPubDateTo,int estOpFrom,double estValFrom,double estValTo,int submissionEndDateOperator,Date bidSubDateFrom,Date bidSubDateTo,int typeOfContract,int biddingAccess,int biddingType,int status,String timeZoneOffset,int conversionValue,int langId,List<Short> showHide,int recordPerPage,int pageNo) throws Exception
    {
        Map inParams = new HashMap();        
        inParams.put("@V_ClientId",clientId);
        inParams.put("@V_EventId",eventId);
        inParams.put("@V_OfficerId",officerId);
        inParams.put("@V_DeptId", departmentId);
        inParams.put("@V_ReferenceNo",refNo);
        inParams.put("@V_PublishDateOperator",publishDateOperator);
        inParams.put("@V_PublishDateFrom",eventPubDateFrom);
        inParams.put("@V_PublishDateTo", eventPubDateTo);
        inParams.put("@V_EstimatedValueOperator", estOpFrom);
        inParams.put("@V_EstimatedValueFrom", estValFrom);
        inParams.put("@V_EstimatedValueTo",estValTo );
        inParams.put("@V_SubmissionEndDateOperator",submissionEndDateOperator);
        inParams.put("@V_SubmissionEndDateFrom",bidSubDateFrom);
        inParams.put("@V_SubmissionEndDateTo", bidSubDateTo);
        inParams.put("@V_TypeOfContract", typeOfContract);
        inParams.put("@V_BiddingAccess", biddingAccess);
        inParams.put("@V_BiddingType",biddingType);
        inParams.put("@V_Status",status );
        
        inParams.put("@V_TimeZoneOffset", timeZoneOffset);
        inParams.put("@V_ConversionValue", conversionValue);
        inParams.put("@V_LangId", langId);
        if(showHide.size()>0){                              
            //inParams.put("@V_IsShowSrNo", showHide.get(0));  
            inParams.put("@V_ShowDepartment", showHide.get(1));         
            inParams.put("@V_ShowEventID", showHide.get(2));
            inParams.put("@V_ShowReferenceNo", showHide.get(3));
            inParams.put("@V_ShowEstimatedValue", showHide.get(4));
            inParams.put("@V_ShowEMD", showHide.get(5));
            inParams.put("@V_ShowDocFees", showHide.get(6));
            inParams.put("@V_ShowBiddingAccess", showHide.get(7));
            inParams.put("@V_ShowPreBidAllowed", showHide.get(8));
            
            inParams.put("@V_ShowTypeOfContract", showHide.get(9));  
            inParams.put("@V_ShowBiddingType", showHide.get(10));         
            inParams.put("@V_ShowSubmissionEndDate", showHide.get(11));
            inParams.put("@V_ShowPublishDate", showHide.get(12));
            inParams.put("@V_ShowopeningDate", showHide.get(13));
            inParams.put("@V_ShowNoOfMappedBidders", showHide.get(14));
            inParams.put("@V_ShowNoOfBiddersFS", showHide.get(15));
            inParams.put("@V_ShowPQEnvelopeOpenedOn", showHide.get(16));
            inParams.put("@V_ShowNoOfQualifiedBiddersInPQEnvelope", showHide.get(17));
            
            inParams.put("@V_ShowDocFeesEMDEnvelopeOpenedOn", showHide.get(18));  
            inParams.put("@V_ShowNoOfQualifiedBiddersInDocFeesEMDEnvelope", showHide.get(19));         
            inParams.put("@V_ShowTechicalEnvelopeOpenedOn", showHide.get(20));
            inParams.put("@V_ShowNoOfQualifiedBiddersInTechnicalEnvelope", showHide.get(21));
            inParams.put("@V_ShowPriceBidEnvelopeOpenedOn", showHide.get(22));
            inParams.put("@V_ShowNoOfQualifiedBiddersInPriceBidEnvelope", showHide.get(23));
            inParams.put("@V_ShowTechnoCommercialEnvelopeOpenedOn", showHide.get(24));
            inParams.put("@V_ShowNoOfQualifiedBiddersInTechnoCommercialEnvelope", showHide.get(25));
            inParams.put("@V_ShowNameOfTenderOwner", showHide.get(26));
            inParams.put("@V_ShowEmailIdOfTenderOwner", showHide.get(27));
        }
        
        inParams.put("@V_RecordsPerPage", recordPerPage);
        inParams.put("@V_PageNo", pageNo);
        this.compile();
        return execute(inParams);
    }
}

