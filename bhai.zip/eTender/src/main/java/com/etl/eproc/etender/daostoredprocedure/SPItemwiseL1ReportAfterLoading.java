/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author Manoj Gadhavi
 */
@Component
public class SPItemwiseL1ReportAfterLoading extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderresult.P_ItemwiseL1ReportAfterLoading";

    public SPItemwiseL1ReportAfterLoading() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_ReportType", Types.INTEGER));
    }

    /**
     * Method use for call store procedure generate Itemwise l1 report after loading
     * @param tenderId
     * @return {@code Map<String,Object>}
     * @throws Exception 
     */
    public Map<String,Object> executeProcedure(int tenderId,int reportType) throws Exception
    {
        Map inParams = new HashMap();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_ReportType", reportType);
        this.compile();

        return execute(inParams);
    }
}


