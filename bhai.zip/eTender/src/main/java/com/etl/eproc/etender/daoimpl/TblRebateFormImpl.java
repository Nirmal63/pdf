package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblRebateForm;
import com.etl.eproc.etender.daointerface.TblRebateFormDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblRebateFormImpl extends AbcAbstractClass<TblRebateForm> implements TblRebateFormDao {

  

    @Override
    public void addTblRebateForm(TblRebateForm tblRebateForm){
        super.addEntity(tblRebateForm);
    }

    @Override
    public void deleteTblRebateForm(TblRebateForm tblRebateForm) {
        super.deleteEntity(tblRebateForm);
    }

    @Override
    public void updateTblRebateForm(TblRebateForm tblRebateForm) {
        super.updateEntity(tblRebateForm);
    }

    @Override
    public List<TblRebateForm> getAllTblRebateForm() {
        return super.getAllEntity();
    }

    @Override
    public List<TblRebateForm> findTblRebateForm(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblRebateFormCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblRebateForm> findByCountTblRebateForm(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblRebateForm(List<TblRebateForm> tblRebateForms){
        super.updateAll(tblRebateForms);
    }
}
