/**
 * 
 */
package com.etl.eproc.etender.services;

import java.util.List;

import javax.annotation.PostConstruct;

import org.quartz.CronScheduleBuilder;
import org.quartz.JobBuilder;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.impl.StdSchedulerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.model.TblClientCPPPConfig;
import com.etl.eproc.common.services.ExceptionHandlerService;

/**
 * @author janak
 * Created On : April 15, 2015
 *
 */
@Component
public class Tender2CpppSchedulerService {
	
	 @Autowired
	 private ExceptionHandlerService exceptionHandlerService;
	 
	 @Autowired
	 Drupal_RestClient  drupal_RestClient;
	 
	 @Autowired
	 HibernateQueryDao hibernateQueryDao;
	 
	 
	 @Value("#{projectProperties['tenderCPPP_ipAddress']}")
	 private String tenderCPPP_ipAddress;
	 
	 @PostConstruct()
	 public void initialize() {
		 try {
	            JobDetail jDetail;

	            Scheduler scheduler = new StdSchedulerFactory().getScheduler();
	            // pass all the autowired objects to user in cronSchedule method
	            scheduler.getContext().put("exceptionHandlerService", exceptionHandlerService);
	            scheduler.getContext().put("drupal_RestClient", drupal_RestClient);
	            scheduler.getContext().put("hibernateQueryDao", hibernateQueryDao);
	            scheduler.getContext().put("tenderCPPP_ipAddress", tenderCPPP_ipAddress);
	            
	            jDetail = JobBuilder.newJob(Tender2CpppTaskExecutor.class).withIdentity("Tender2Cppp","Tender2CpppGroup").build();
	            Trigger trigger = TriggerBuilder.newTrigger().withIdentity("cronTrigger").withSchedule(CronScheduleBuilder.cronSchedule("0 0 0 1/1 * ? *")).build();   // run on every day at mid-night 12:00 AM
//	            Trigger trigger = TriggerBuilder.newTrigger().withIdentity("cronTrigger").withSchedule(CronScheduleBuilder.cronSchedule("0 0/2 * * * ?")).build();     // on every alternate min
	            scheduler.start();
	            scheduler.scheduleJob(jDetail, trigger);
	                    
	        } catch (Exception ex) {            
	            exceptionHandlerService.writeLog(ex);
	        }
	 }
}
