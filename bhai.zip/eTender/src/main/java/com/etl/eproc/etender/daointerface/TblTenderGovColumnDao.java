/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblTenderGovColumn;
import java.util.List;

/**
 *
 * @author taher.tinwala
 */
public interface TblTenderGovColumnDao  {

    public void addTblTenderGovColumn(TblTenderGovColumn tblTenderGovColumn);

    public void deleteTblTenderGovColumn(TblTenderGovColumn tblTenderGovColumn);

    public void updateTblTenderGovColumn(TblTenderGovColumn tblTenderGovColumn);

    public List<TblTenderGovColumn> getAllTblTenderGovColumn();

    public List<TblTenderGovColumn> findTblTenderGovColumn(Object... values) throws Exception;

    public List<TblTenderGovColumn> findByCountTblTenderGovColumn(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderGovColumnCount();

    public void saveUpdateAllTblTenderGovColumn(List<TblTenderGovColumn> tblTenderGovColumns);
}
