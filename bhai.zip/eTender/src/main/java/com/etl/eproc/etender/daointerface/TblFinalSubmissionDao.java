package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblFinalSubmission;
import java.util.List;

public interface TblFinalSubmissionDao  {

    public void addTblFinalSubmission(TblFinalSubmission tblFinalSubmission);

    public void deleteTblFinalSubmission(TblFinalSubmission tblFinalSubmission);

    public void updateTblFinalSubmission(TblFinalSubmission tblFinalSubmission);

    public List<TblFinalSubmission> getAllTblFinalSubmission();

    public List<TblFinalSubmission> findTblFinalSubmission(Object... values) throws Exception;

    public List<TblFinalSubmission> findByCountTblFinalSubmission(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFinalSubmissionCount();

    public void saveUpdateAllTblFinalSubmission(List<TblFinalSubmission> tblFinalSubmissions);
}