/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblSeekClarification;
import java.util.List;

/**
 *
 * @author shreyansh.shah
 */

public interface TblSeekClarificationDao  {

    public void addTblSeekClarification(TblSeekClarification tblSeekClarification);

    public void deleteTblSeekClarification(TblSeekClarification tblSeekClarification);

    public void updateTblSeekClarification(TblSeekClarification tblSeekClarification);

    public List<TblSeekClarification> getAllTblSeekClarification();

    public List<TblSeekClarification> findTblSeekClarification(Object... values) throws Exception;

    public List<TblSeekClarification> findByCountTblSeekClarification(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblSeekClarificationCount();

    public void saveUpdateAllTblSeekClarification(List<TblSeekClarification> tblSeekClarifications);
}