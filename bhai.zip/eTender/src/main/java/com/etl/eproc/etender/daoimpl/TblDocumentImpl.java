package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblDocument;
import com.etl.eproc.common.daointerface.TblDocumentDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblDocumentImpl extends AbcAbstractClass<TblDocument> implements TblDocumentDao {

   

    @Override
    public void addTblDocument(TblDocument tblDocument){
        super.addEntity(tblDocument);
    }

    @Override
    public void deleteTblDocument(TblDocument tblDocument) {
        super.deleteEntity(tblDocument);
    }

    @Override
    public void updateTblDocument(TblDocument tblDocument) {
        super.updateEntity(tblDocument);
    }

    @Override
    public List<TblDocument> getAllTblDocument() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDocument> findTblDocument(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDocumentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDocument> findByCountTblDocument(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDocument(List<TblDocument> tblDocuments){
        super.updateAll(tblDocuments);
    }
}
