package com.etl.eproc.etender.databean;



/**
 * @author urja
 */
public class TenderFormCorrigendumDtBean {

	private String formName;       
        private String action;        

    public String getFormName() {
        return formName;
    }

    public void setFormName(String formName) {
        this.formName = formName;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

   
}