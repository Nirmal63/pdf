package com.etl.eproc.etender.controller;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.SocketException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellReference;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.convert.ConversionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.databean.BidderRegistrationDataBean;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblOfficerDocMapping;
import com.etl.eproc.common.model.TblOfficerDocument;
import com.etl.eproc.common.model.TblSmboq;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.model.TblVendorCodeMapping;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidations;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.databean.GetExcelDataBean;
import com.etl.eproc.etender.databean.SpaceMatrixDtBean;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.SMClientTenderService;

/**
 * @author vivek.rajyaguru
 *
 */
/**
 * @author pranav.gandharva
 *
 */
@Controller
public class SMController {
	@Autowired
	private MessageSource messageSource;
	@Value("#{projectProperties['doc_upload_path']}")
	private String docUploadPath;
	@Value("#{etenderAuditTrailProperties['postSAPDocumentUpload']}")
	private String postSAPDocumentUpload;
	@Value("#{etenderAuditTrailProperties['getSAPDocumentUpload']}")
	private String getSAPDocumentUpload;
	@Value("#{etenderAuditTrailProperties['manageSapBoq']}")
	private String manageSapBoqAudit;
	@Value("#{tenderlinkProperties['upload_sap_boq']?:3356}")
	private int uploadSapBoq;
	@Value("#{tenderlinkProperties['manage_sap_boq']?:3357}")
	private int manageSapBoq;
	@Value("#{tenderlinkProperties['sap_boq_event']?:262}")
	private int sapBoqEvent;
	@Value("#{tenderlinkProperties['manage_sap_boq_reportId']?:130}")
	private int manageSapBoqReportId;
	@Value("#{etenderAuditTrailProperties['deleteSapBoqFile']}")
	private String deleteSapBoqFile;
	@Value("#{etenderAuditTrailProperties['createRfpFromSap']}")
	private String createRfpFromSap;
	@Value("#{projectProperties['sm_sap_boq_excel_total_columns']?:19}")
	private int smSapBoqExcelTotalColumns;
	@Value("#{projectProperties['sm_sap_boq_excel_skip_rows']?:1}")
	private int smSapBoqExcelSkipRows;
	@Value("#{tenderlinkProperties['project_report_linkId']?:4427}")
	private int projectReportLink;
	@Value("#{etenderAuditTrailProperties['viewProjctReport']}")
	private String viewProjctReport; 
	@Value("#{etenderAuditTrailProperties['searchProjectReport']}")
	private String searchProjectReport;
	@Value("#{projectProperties['record_per_pages']?:10}")
    private int recordPerPage;
	@Value("#{tenderlinkProperties['manage_material_master']?:141}")
	private int manageMaterialMaster;
	@Value("#{tenderlinkProperties['material_master_link']?:4499}")
	private int manageMaterialMasterLink;
	@Value("#{etenderAuditTrailProperties['viewMaterialMaster']}")
	private String viewMaterialMasters;
	@Value("#{linkProperties['manage_bidder_field_value']?:161}")
	private int manageBidderFieldValueId;
	@Value("#{projectProperties['userhistory.actiontype.edit']?:2}")
	private int userHistoryEdit;
	@Value("#{linkProperties['manage_bidder_register_bidder']?:24}")
	private int registrationLinkId;
	@Value(value="#{adminAuditTrailProperties['poststatetimezonedata']}")
	private String updateStateAndTimezone;
	@Value(value="#{adminAuditTrailProperties['bidderregistrationpage']}")
	private String viewRegistrationPage;
	@Value("#{projectProperties['sync_material_requesturl']}")
	private String manualSyncUrl;
	
//	msg_bidder_data_updated
//	private String 
	@Autowired
	private CommonValidators commonValidators;
	@Autowired
	private ConversionService conversionService;
	@Autowired
	DynamicFieldService dynamicFieldService;
	@Autowired
	private ClientService clientService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private AuditTrailService auditTrailService;
	@Autowired
	private com.etl.eproc.common.services.AuditTrailService commonAuditService;
	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private CommonValidations commonValidations;
	@Autowired
	private SMClientTenderService smClientTenderService;
	@Autowired
	private ReportGeneratorService reportGeneratorService;
	@Autowired
	private FileUploadService fileUploadService;
	@Autowired
	private ManageBidderService manageBidderService;
	@Autowired
	private ModelToSelectItem modelToSelectItem;
	private static final String RESULTSET_1= "#result-set-1";
	private static final String RESULTSET_2= "#result-set-2";
	private static final String RESULTSET_3= "#result-set-3";
	private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";

	/**
	 * @author vivek.rajyaguru
	 * @param request
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/etender/buyer/uploadsapboq/{enc}", method = RequestMethod.GET)
	public String uploadSAPBOQDOCS(HttpServletRequest request, ModelMap modelMap) {
		int clientId = 0;
		String retVal = "redirect:/sessionexpired";
		try {
			SessionBean sessionBean = (SessionBean) request.getSession()
					.getAttribute(CommonKeywords.SESSION_OBJ.toString());
			if (sessionBean != null && (abcUtility.getSessionUserTypeId(request) == 1
					|| abcUtility.getSessionUserTypeId(request) == 3)) {
				clientId = abcUtility.getSessionClientId(request);
				List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(sapBoqEvent, clientId);
				int allowedSize = 0;
				StringBuilder allowedExt = new StringBuilder();
				if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
					allowedSize = lstDocUploadConf.get(0).getMaxSize();
					allowedExt.append(lstDocUploadConf.get(0).getType());
					modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
				}
				int index = allowedExt.toString().indexOf(",");
				allowedExt.insert(index + 1, "*.");
				while (index >= 0) {
					index = allowedExt.toString().indexOf(",", index + ",".length());
					allowedExt.insert(index + 1, "*.");
				}

				modelMap.addAttribute("allowedExt", allowedExt);
				modelMap.addAttribute("allowedSize", allowedSize / 1024);
				modelMap.addAttribute("linkId", uploadSapBoq);
				modelMap.addAttribute("cStatusDoc", 0); // officerDocStatusPending
				retVal = "etender/buyer/UploadSAPBoq";
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), uploadSapBoq,
					getSAPDocumentUpload, 0, 0);
		}
		return retVal;
	}

	/**
	 * @author vivek.rajyaguru
	 * @param redirectAttributes
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/etender/buyer/submituploadsapboq", method = RequestMethod.POST)
	public String submituploadsapboq(RedirectAttributes redirectAttributes, HttpServletRequest request) {
		String documentName = null;
		boolean isValidate = true;
		int clientId = 0;
		StringBuilder result = new StringBuilder();
		Integer objectId = 0;
		int auditTrialObjectId = 0;
		String downloadDocPath = "";
		String retVal = "redirect:/sessionexpired";
		Map<String, String> projectIds = new HashMap<String, String>();
		Map<String, String> projectNames = new HashMap<String, String>();
		Set<String> materialGroupId = new HashSet<String>();

		try {
			SessionBean sessionBean = null;
			int userId = 0;
			sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
			if (sessionBean != null && (abcUtility.getSessionUserTypeId(request) == 1
					|| abcUtility.getSessionUserTypeId(request) == 3)) {
				userId = abcUtility.getSessionUserId(request);
				String fileDesc = null;
				clientId = abcUtility.getSessionClientId(request);
				String allowFileExist = "y";
				List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(sapBoqEvent, clientId);
				TblDocUploadConf tblDocUploadConf = lstDocUploadConf.get(0);
				File file = null;
				File tmpDir = null;
				long fileSize = 0;
				String fileName = "";
				long fileMaxSize = 0;
				String fileExtensions = null;
				if (!lstDocUploadConf.isEmpty()) {
					fileMaxSize = lstDocUploadConf.get(0).getMaxSize() * 1024;
					fileExtensions = lstDocUploadConf.get(0).getType();
				}

				DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
				fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
				ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
				List<FileItem> uploadItems = uploadHandler.parseRequest(request);

				if (uploadItems.get(1).getFieldName().equals("txtDocDesc")) {
					fileDesc = uploadItems.get(1).getString();
					if (fileDesc == null || "".equalsIgnoreCase(fileDesc.trim())) {
						result.append(
								messageSource.getMessage("msg_docbrief_empty", null, LocaleContextHolder.getLocale()));
						isValidate = false;
					}
				}
				if (isValidate) {
					for (FileItem item : uploadItems) {
						if (!item.isFormField()) {
							fileSize = item.getSize();
							if (item.getName().lastIndexOf("\\") != -1) {
								fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1,
										item.getName().length());
							} else {
								fileName = item.getName();
							}
							documentName = new String(fileName);
							if (StringUtils.hasLength(fileName)) {
								if (fileSize == 0) {
									result.append(messageSource.getMessage("msg_validation_filewithzerokb", null,
											LocaleContextHolder.getLocale()));
									isValidate = false;
									break;
								}
								if (!checkFileSize(fileSize, fileMaxSize)) {
									result.append(messageSource.getMessage("msg_filesizeexceeds",
											new Object[] { fileMaxSize / (1024 * 1024) },
											LocaleContextHolder.getLocale()));
									isValidate = false;
									break;
								}
								if (!checkFileExn(fileName, fileExtensions)) {
									StringBuilder allowedExt = new StringBuilder();
									if (!lstDocUploadConf.isEmpty()) {
										allowedExt.append(lstDocUploadConf.get(0).getType());
									}
									int index = allowedExt.toString().indexOf(",");
									allowedExt.insert(index + 1, "*.");
									while (index >= 0) {
										index = allowedExt.toString().indexOf(",", index + ",".length());
										allowedExt.insert(index + 1, "*.");
									}

									result.append(messageSource.getMessage("msg_acceptablefiletypes",
											new Object[] { allowedExt }, LocaleContextHolder.getLocale()));

									isValidate = false;
									break;
								} else {
									/*
									 * if destination directory not exist then
									 * create it
									 */
									isDirExists(docUploadPath.split(":")[0] + ":\\\\",
											docUploadPath.substring(3, docUploadPath.length())
													+ tblDocUploadConf.getPath());

									StringBuilder tmpDirPath = new StringBuilder();
									tmpDirPath.append(docUploadPath).append(tblDocUploadConf.getPath());
									tmpDir = new File(tmpDirPath.append("\\")
											.append(userId + "_" + request.getSession().getId()).toString());
									downloadDocPath = tblDocUploadConf.getPath();
									if (!tmpDir.isDirectory()) {
										tmpDir.mkdirs();
									}
									file = new File(tmpDir, fileName);
									if (abcUtility.ValidationForFileExist(file)) {
										result.append(messageSource.getMessage("msg_fileexists", null,
												LocaleContextHolder.getLocale()));
										if (allowFileExist.equalsIgnoreCase("y")) {
											fileName = fileName.replace(".", "_" + commonService.getServerDateTime()
													.toString().replace(":", "_").replace(".", "_") + ".");
											file = new File(tmpDir, fileName);
										} else {
											isValidate = false;
											break;
										}
									}
									item.write(file);

								}
							}
						}
					}
				}
				if (isValidate && file.exists()) {
					int ext = fileName.lastIndexOf('.');
					String lst = fileName.substring(ext + 1);
					boolean isXls = "xls".equalsIgnoreCase(lst);
					Iterator<Row> rows = null;
					int rowPosition = 0;
					int rowsToSkip = smSapBoqExcelSkipRows;
					int totalNoOfRows = 0;
					int noOfColumns = 0;
					FileInputStream fileInputStream = new FileInputStream(file);
					if (isXls) {
						HSSFWorkbook workBook = new HSSFWorkbook(new POIFSFileSystem(fileInputStream));
						HSSFSheet sheet = workBook.getSheetAt(0);
						rows = sheet.rowIterator();
						totalNoOfRows = sheet.getPhysicalNumberOfRows();
						noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
					} else {
						XSSFWorkbook workBook = new XSSFWorkbook(fileInputStream);
						XSSFSheet sheet = workBook.getSheetAt(0);
						rows = sheet.rowIterator();
						totalNoOfRows = sheet.getPhysicalNumberOfRows();
						noOfColumns = sheet.getRow(0).getPhysicalNumberOfCells();
					}
					HashMap<String, List<String>> errorMap = new HashMap<String, List<String>>();
					List<String> cellValidationError = new ArrayList<String>();
					List<String> cellNotProperFormat = new ArrayList<String>();
					List<String> cellEmpty = new ArrayList<String>();
					boolean cellError = false;
					try {
						rowLoopLabel: 
							if (noOfColumns == smSapBoqExcelTotalColumns) {
							for (int i = 0; i < totalNoOfRows; i++) {
								rowPosition++;
								Row row = rows.next();
								if (row != null) {
									Iterator<Cell> cellIterator = row.cellIterator();
									if (rowPosition > rowsToSkip) {
										for (int j = 0; j < smSapBoqExcelTotalColumns; j++) {
											if (cellIterator.hasNext()) {
												Cell cell = cellIterator.next();
												if ((j != 5 || j != 6 || j != 7 || j != 14 || j != 15)) {
													if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK
															&& StringUtils.hasLength(cell.toString().trim())) {
														// Read Cell Value
														try {
															Object objectValue = null;
															switch (cell.getCellType()) {
															case Cell.CELL_TYPE_STRING:
																objectValue = cell.getStringCellValue();
																break;
															case Cell.CELL_TYPE_NUMERIC:
																objectValue = NumberToTextConverter
																		.toText(cell.getNumericCellValue());
																break;
															}
															result.append(checkCellValueProperFormat(j, objectValue));
															if (!(result.toString().equals("false"))) {
																cellValidationError.add(result.toString() + " "
																		+ messageSource.getMessage(
																				"msg_cell_not_proper_format",
																				new Object[] { isXls ? CellReference
																						.convertNumToColString(j)
																						: org.apache.poi.ss.util.CellReference
																								.convertNumToColString(
																										j),
																						rowPosition },
																				LocaleContextHolder.getLocale()));
																isValidate = false;
																cellError = true;
																// break
																// rowLoopLabel;
															} else {
																if (j == 0) {// projectId
																	projectIds.put("projectId",
																			String.valueOf(objectValue));
																} else if (j == 1) {// Project
																					// Name
																	projectNames.put("projectName",
																			String.valueOf(objectValue));
																} else if (j == 11) {
																	materialGroupId.add(String.valueOf(objectValue));
																}
															}
														} catch (Exception e) {
															isValidate = false;
															cellError = true;
															cellNotProperFormat.add(messageSource.getMessage(
																	"msg_column_cell_not_proper_format",
																	new Object[] { isXls
																			? CellReference.convertNumToColString(j)
																			: org.apache.poi.ss.util.CellReference
																					.convertNumToColString(j),
																			rowPosition },
																	LocaleContextHolder.getLocale()));
															// break
															// rowLoopLabel;
														}
													} else {
														isValidate = false;
														cellError = true;
														// errorString.append(messageSource.getMessage("msg_column_empty",
														// null,
														// LocaleContextHolder.getLocale())+"
														// ");
														cellEmpty.add(messageSource
																.getMessage("msg_cell_not_proper_format", new Object[] {
																		isXls ? CellReference.convertNumToColString(j)
																				: org.apache.poi.ss.util.CellReference
																						.convertNumToColString(j),
																		rowPosition },
																		LocaleContextHolder.getLocale()));
														// break rowLoopLabel;
													}
													if (result.length() > 0) {
														result = null;
														result = new StringBuilder();
													}
												}
											}
										}
									}
								} else {
									isValidate = false;
									result.append(messageSource.getMessage("msg_row_empty",
											new Object[] { rowPosition }, LocaleContextHolder.getLocale()));
									break rowLoopLabel;
								}
							}
						} else {
							isValidate = false;
							result.append(messageSource.getMessage("msg_excel_incomplete_file", null,
									LocaleContextHolder.getLocale()));
						}
					} catch (Exception e) {
						isValidate = false;
						result.append(messageSource.getMessage("msg_excel_read_failed", new Object[] { rowPosition },
								LocaleContextHolder.getLocale()));
						exceptionHandlerService.writeLog(e);
					}
					if ((rowPosition == 0 || rowPosition == 1) && isValidate) {
						isValidate = false;
						result.append(messageSource.getMessage("msg_excel_incomplete_file", null,
								LocaleContextHolder.getLocale()));
					}

					fileInputStream.close();
					if (isValidate) {
						TblOfficerDocument tblOfficerDocument = new TblOfficerDocument();
						tblOfficerDocument.setDocName(fileName);
						documentName = new String(fileName);
						tblOfficerDocument.setTblClient(new TblClient(clientId));
						tblOfficerDocument.setOfficerFolderId(1);
						tblOfficerDocument.setDescription(fileDesc);
						tblOfficerDocument.setFileSize((int) fileSize);
						tblOfficerDocument.setCreatedBy(userId);
						tblOfficerDocument.setCstatus(1);
						tblOfficerDocument.setIsEncryptionReq(tblDocUploadConf.getIsEncryptionReq());
						TblOfficerDocMapping tblOfficerDocMapping = new TblOfficerDocMapping();
						tblOfficerDocMapping.setTblLink(new TblLink(uploadSapBoq));
						tblOfficerDocMapping.setMappedBy(userId);
						tblOfficerDocMapping.setCstatus(0);
						tblOfficerDocMapping.setMappedBy(userId);
						tblOfficerDocMapping.setChildId(0);
						TblSmboq tblSmboq = new TblSmboq();
						tblSmboq.setProjectId(AbcUtility.replaceSpecialChars(projectIds.get("projectId").toString()));
						tblSmboq.setProjectName(
								AbcUtility.replaceSpecialChars(projectNames.get("projectName").toString()));
						tblSmboq.setRfpCnt(materialGroupId.size());
						tblSmboq.setCreatedBy(abcUtility.getSessionUserDetailId(request));
						tblSmboq.setTblClient(new TblClient(clientId));
						tblSmboq.setCstatus(0);
						isValidate = smClientTenderService.addTblSmBoqAndOfficeDocDetail(tblOfficerDocument,
								tblOfficerDocMapping, tblSmboq, downloadDocPath);
						if (isValidate) {
							tmpDir.renameTo(new File(tmpDir.getParentFile() + "\\" + tblSmboq.getSmboqId()));
							redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),
									"msg_tender_docuploadsuccessfully");
							retVal = "redirect:/" + "etender/buyer/managesapboq"
									+ encryptDecryptUtils.generateRedirect("etender/buyer/managesapboq", request);
						} else {
							file.delete();
							redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), messageSource
									.getMessage("redirect_failure_common", null, LocaleContextHolder.getLocale()));
							retVal = "redirect:/" + "etender/buyer/uploadsapboq"
									+ encryptDecryptUtils.generateRedirect("etender/buyer/uploadsapboq", request);
						}
					} else {
						file.delete();
						if (result.length() > 0) {
							redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), result);
						}
						if (cellError) {
							errorMap.put("0", cellValidationError);
							errorMap.put("1", cellNotProperFormat);
							errorMap.put("2", cellEmpty);
							redirectAttributes.addFlashAttribute("errorMap", errorMap);
							redirectAttributes.addFlashAttribute("cellError", cellError);
						}
						retVal = "redirect:/" + "etender/buyer/uploadsapboq"
								+ encryptDecryptUtils.generateRedirect("etender/buyer/uploadsapboq", request);
					}

				} else {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), result);
					retVal = "redirect:/" + "etender/buyer/uploadsapboq"
							+ encryptDecryptUtils.generateRedirect("etender/buyer/uploadsapboq", request);
				}
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), uploadSapBoq,
					postSAPDocumentUpload + " (" + documentName + ")", objectId, auditTrialObjectId, "");
		}
		return retVal;
	}

	/**
	 * to check the file size
	 * 
	 * @param fielSize
	 * @param maxFileSize
	 * @return
	 */
	private boolean checkFileSize(long fielSize, long maxFileSize) {
		boolean chextn = false;
		if (maxFileSize > fielSize) {
			chextn = true;
		} else {
			chextn = false;
		}
		return chextn;
	}

	/**
	 * to check file extention
	 * 
	 * @param fileName
	 * @param allowExtensions
	 * @return
	 */
	private boolean checkFileExn(String fileName, String allowExtensions) {
		boolean chextn = false;
		int j = fileName.lastIndexOf('.');
		String lst = fileName.substring(j + 1);
		String str = allowExtensions;
		String[] str1 = str.split(",");
		for (int i = 0; i < str1.length; i++) {
			if (str1[i].trim().equalsIgnoreCase(lst)) {
				chextn = true;
			}
		}
		return chextn;
	}

	private void isDirExists(String drive, String rpath) {
		String[] tpath = rpath.split("\\\\");
		StringBuilder path = new StringBuilder();
		path.append(drive);

		for (int i = 0; i < tpath.length; i++) {
			path.append("\\").append(tpath[i]);

			File f = new File(path.toString());

			if (!f.isDirectory()) {
				f.mkdirs();
			}
		}
	}

	/**
	 * @author vivek.rajyaguru
	 * @param index
	 * @param obj
	 * @return
	 */
	private String checkCellValueProperFormat(int index, Object obj) {
		String valid = "false";
		switch (index) {
		case 0:
		case 1:
			// Project Id,Project Name
			if (!commonValidations.validateLength(String.valueOf(obj), 500)
					|| !commonValidations.isTenderBrief(String.valueOf(obj))) {
				valid = messageSource.getMessage("msg_js_allow_max", null, LocaleContextHolder.getLocale()) + " 500 "
						+ messageSource.getMessage("msg_js_common_referenceno", null, LocaleContextHolder.getLocale());
			}
			break;
		case 2:
			// BOQ Type
			if (!commonValidations.validateLength(String.valueOf(obj), 100)) {
				valid = messageSource.getMessage("msg_all_character_allowed", new Object[] { 100 },
						LocaleContextHolder.getLocale());
			}
			break;
	   case 9:
			// UOM
			if (!commonValidations.validateLength(String.valueOf(obj), 2000)) {
				valid = messageSource.getMessage("msg_all_character_allowed", new Object[] { 2000 },
						LocaleContextHolder.getLocale());
			}
			break;	
		case 4:	
		case 8:
		case 16:
		case 17:	
			// BOQ No,Material Code,PR No,PR Item
			if (!commonValidations.validateLength(String.valueOf(obj), 15)
					|| !commonValidations.isDigits(String.valueOf(obj))) {
				valid = messageSource.getMessage("msg_only_numeric_allowed", new Object[] { 15 },
						LocaleContextHolder.getLocale());
			}
			break;
		case 10:
		case 12:
			// Decription,Package Description
			if (!commonValidations.validateLength(String.valueOf(obj), 10000)) {
				valid = messageSource.getMessage("msg_all_character_allowed", new Object[] { 10000 },
						LocaleContextHolder.getLocale());
			}
			break;
		case 11:
			// Material Group Id
			if (!commonValidations.validateLength(String.valueOf(obj), 2)
					|| !commonValidations.isDigits(String.valueOf(obj))) {
				valid = messageSource.getMessage("msg_only_numeric_allowed", new Object[] { 2 },
						LocaleContextHolder.getLocale());
			}
			break;
		case 13:
			if (!commonValidations.validateLength(String.valueOf(obj), 15)
					|| !commonValidations.isAllMoney(String.valueOf(obj))) {
				valid = messageSource.getMessage("msg_sap_boq_allnumber", new Object[] { 15, 5 },
						LocaleContextHolder.getLocale());
			}
			break;
		}
		return valid;
	}

	/**
	 * 
	 * @author vivek.rajyaguru
	 * @param modelMap
	 * @param req
	 * @return
	 */
	@RequestMapping(value = "/etender/buyer/managesapboq/{enc}", method = RequestMethod.GET)
	public String getSpendReportDtls(ModelMap modelMap, HttpServletRequest req) {
		String retVal = "redirect:/sessionexpired";
		int userTypeId = abcUtility.getSessionUserTypeId(req);
		int userId = abcUtility.getSessionUserId(req);
		try {
			if (userTypeId == 3 || userTypeId == 1) {
				modelMap.addAttribute("reportId", manageSapBoqReportId);
				reportGeneratorService.getReportConfigDetails(manageSapBoqReportId, modelMap);
				retVal = "etender/buyer/ManageSapBoq";
			}
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageSapBoq,
					manageSapBoqAudit, 0, userId);
		}
		return retVal;
	}

	/**
	 * @author vivek.rajyaguru
	 * @param modelMap
	 * @param officerDocMappingId
	 * @param objectId
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/etender/buyer/deletesapboqfile/{officerDocMappingId}/{objectId}/{enc}", method = RequestMethod.GET)
	public String deleteSapBoqFile(ModelMap modelMap, @PathVariable("officerDocMappingId") int officerDocMappingId,
			@PathVariable("objectId") int objectId, HttpServletRequest request, RedirectAttributes redirectAttributes) {
		String retVal = "redirect:/sessionexpired";
		int userTypeId = abcUtility.getSessionUserTypeId(request);
		int userId = abcUtility.getSessionUserId(request);
		String redirectMessage = "";
		boolean delFlag = false;
		try {
			if (userTypeId == 3 || userTypeId == 1) {
				if (smClientTenderService.getFileStatus(objectId, 1)) {
					List<Object[]> tblOfficerDocument = fileUploadService
							.getOfficerDocDetailsForRemove(officerDocMappingId);
					String filePath = docUploadPath + tblOfficerDocument.get(0)[3].toString();
					filePath = filePath.replace("\\", "\\\\");
					filePath += "\\" + tblOfficerDocument.get(0)[2].toString();
					File file = new File(filePath);
					file = abcUtility.CheckDirExist(file);
					if(file.exists()){
						delFlag = deleteFile(file.getPath());
					}
					if (delFlag) {
						smClientTenderService.updateTblSmBoq(objectId, abcUtility.getSessionUserDetailId(request), 2);
						delFlag = fileUploadService.updateOfficerDocDetailsForRemove(officerDocMappingId, 2);
					}

					if (delFlag) {
						redirectMessage = "msg_tender_docrejectsuccessfully";
					} else {
						redirectMessage = "redirect_failure_common";
					}
				} else {
					redirectMessage = "msg_rfp_alreday_processed";
				}
				retVal = "redirect:/etender/buyer/managesapboq"
						+ encryptDecryptUtils.generateRedirect("etender/buyer/managesapboq", request);
				redirectAttributes.addFlashAttribute(
						delFlag ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),
						redirectMessage);
			}
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageSapBoq,
					deleteSapBoqFile, 0, userId);
		}
		return retVal;
	}

	/**
	 * @param filePath
	 * @return
	 */
	public boolean deleteFile(String filePath) {
		boolean flg = false;
		try {
			File f = new File(filePath);
			if (f.delete()) {
				flg = true;
			}

		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		}
		return flg;
	}
    
	/**
	 * @author pranav.gandharva
	 * @param modelMap
	 * @param req
	 * @return
	 */
	@RequestMapping(value = "/etender/buyer/manageMaterialMasters/{enc}",method = RequestMethod.GET)
	private String manageMasters(ModelMap modelMap,HttpServletRequest req){
		String retVal = "redirect:/sessionexpired";
		SessionBean sessionBean = (SessionBean) req.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
		int userTypeId = abcUtility.getSessionUserTypeId(req);
		int userId = abcUtility.getSessionUserId(req);
		try {
			if (null != sessionBean && userTypeId == 3 || userTypeId == 1) {
				retVal = "etender/buyer/manageMaterialMaster";
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		finally{
			auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageMaterialMasterLink, viewMaterialMasters, 0, userId);
		}
		
		return retVal;
	}
	@RequestMapping(value = "/etender/buyer/reportgenerator/manageMaterialMasters" ,method = RequestMethod.POST)
	public void searchFromMaterialMaster(HttpServletRequest req , HttpServletResponse res , ModelMap modelMap) throws Exception{
		try {
		String industrialSector   = StringUtils.hasLength(req.getParameter("txtindusSector")) ? req.getParameter("txtindusSector") : null;
		String materialType   = StringUtils.hasLength(req.getParameter("txtmaterialType")) ? req.getParameter("txtmaterialType") : null;
		String plant  = StringUtils.hasLength(req.getParameter("txtplant")) ? req.getParameter("txtplant") : null; 
		String purchGrp  = StringUtils.hasLength(req.getParameter("txtpurchGrp")) ? req.getParameter("txtpurchGrp") : null;
		String itemCategory  = StringUtils.hasLength(req.getParameter("txtitemCatGrp")) ? req.getParameter("txtitemCatGrp") : null;
		String materialNumber = StringUtils.hasLength(req.getParameter("txtmaterialNumber")) ? req.getParameter("txtmaterialNumber") : null;
		int pageNo = StringUtils.hasLength(req.getParameter("txtpageNo")) ? Integer.parseInt(req.getParameter("txtpageNo")) : 1; 
		int colspan = 1;
		List<Short> showHide = new ArrayList<Short>();
		StringBuilder materialMasterHtml = new StringBuilder();
			
		showHide.add(Short.valueOf("1"));
		 if(req.getParameter("isPDF") == null){
			 
			 if (Integer.valueOf(req.getParameter("mateNumber")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("indusSector")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("materialType")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("plant")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("salesOrg")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("dstCh")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("matDesc")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("baseUnit")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("matrialGrp")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("itemGrp")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("weight")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("classType")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("materClass")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("char1")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("char2")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("char3")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("char4")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("char5")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("char6")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("charVal1")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("charVal2")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("charVal3")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("charVal4")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("charVal5")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("charVal6")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("tax1")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("tax2")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("tax3")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("tax4")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("tax5")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("tax6")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("tax7")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("tax8")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("accAssign")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("itemCatGrp")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("availCheck")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("transportGrp")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("loadingGrp")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("hsn")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("sales")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("purchGrp")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("manifactPart")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("valuationClass")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("priceControl")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("priceUnit")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("movinAvg")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 if (Integer.valueOf(req.getParameter("poText")) == 1) {
				 showHide.add(Short.valueOf("1"));
				 colspan++;
			 } else {
				 showHide.add(Short.valueOf("0"));
			 }
			 
		 }
		Map<String,Object> materialMaster = null;
	    if(req.getParameter("isPDF")!=null && req.getParameter("isPDF").equalsIgnoreCase("yes")){
	    	for(int i=0 ; i<48 ;i++){
	    		showHide.add(Short.valueOf("1"));
	    	}
	    	materialMaster = smClientTenderService.getMaterialMaster(industrialSector, materialType ,plant, itemCategory, purchGrp, materialNumber, -1 , pageNo);
		}else{
			materialMaster = smClientTenderService.getMaterialMaster(industrialSector, materialType ,plant, itemCategory, purchGrp, materialNumber, recordPerPage , pageNo);
		}
			  
		ArrayList<LinkedHashMap<String, Object>> dispPageDetail = (ArrayList<LinkedHashMap<String, Object>>) materialMaster.get("#result-set-2");
		ArrayList<LinkedHashMap<String, Object>> masters = (ArrayList<LinkedHashMap<String, Object>>) materialMaster.get("#result-set-1");
		int totalPages = 0; 
		int totalRecords = 0;
		if(dispPageDetail != null){
	         for(LinkedHashMap<String, Object> data:dispPageDetail){
	        	 totalPages = Integer.parseInt(data.get("TotalPages").toString());
                 if (totalPages == 0){
                     totalPages = 1;
                 }
                 totalRecords = (Integer) data.get("TotalRecords");
               
	         }
	    }
		 
		    materialMasterHtml.append("<tr><th class='a-left'>");
		    materialMasterHtml.append(messageSource.getMessage("lbl_sr_no", null, LocaleContextHolder.getLocale())+"</th>");
			materialMasterHtml.append(showHide.get(1) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_material_number", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(2) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_indus_sector", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(3) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_material_type", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(4) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_plant", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(5) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_sales_org", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(6) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_dst_channel", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(7) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_material_disc", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(8) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_base", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(9) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_material_grp", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(10) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_item_grp", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(11) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_weight", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(12) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_class_type", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(13) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_material_class", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(14) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char1", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(15) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char2", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(16) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char3", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(17) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char4", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(18) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char5", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(19) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char6", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(20) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char1_val", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(21) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char2_val", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(22) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char3_val", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(23) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char4_val", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(24) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char5_val", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(25) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_char6_val", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(26) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_tax1class", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(27) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_tax2class", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(28) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_tax3class", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(29) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_tax4class", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(30) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_tax5class", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(31) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_tax6class", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(32) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_tax7class", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(33) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_tax8class", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(34) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_acc_assign", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(35) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_itemcat_grp", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(36) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_avail_check", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(37) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_transportation_grp", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(38) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_loading_grp", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(39) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_hsn", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(40) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_sales", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(41) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_purch_grp", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(42) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_manifact_part", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(43) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_valuation_class", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(44) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_price_control", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(45) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_price_unit", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(46) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_movin_avg", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append(showHide.get(47) == 1 ? "<th class='a-left'>"+messageSource.getMessage("lbl_potext", null, LocaleContextHolder.getLocale())+"</th>" : "");
			materialMasterHtml.append("</tr>");
		
		if(masters != null && !masters.isEmpty()){
			for(LinkedHashMap<String, Object> objects :masters){
				    	materialMasterHtml.append("<tr><td class='a-left'>");
				    	materialMasterHtml.append(objects.get("srNo")+"</td>");
					    materialMasterHtml.append(showHide.get(1) == 1 ? "<td class='a-left'>"+objects.get("materialNumber")+"</td>" : "");
						materialMasterHtml.append(showHide.get(2) == 1 ? "<td class='a-left'>"+objects.get("industrialSector")+"</td>" : "");
						materialMasterHtml.append(showHide.get(3) == 1 ? "<td class='a-left'>"+objects.get("materialType")+"</td>" : "");
						materialMasterHtml.append(showHide.get(4) == 1 ? "<td class='a-left'>"+objects.get("plant")+"</td>" : "");
						materialMasterHtml.append(showHide.get(5) == 1 ? "<td class='a-left'>"+objects.get("salesOrg")+"</td>" : "");
						materialMasterHtml.append(showHide.get(6) == 1 ? "<td class='a-left'>"+objects.get("distrChannel")+"</td>" : "");
						materialMasterHtml.append(showHide.get(7) == 1 ? "<td class='a-left'>"+objects.get("materialDescription")+"</td>" : "");
						materialMasterHtml.append(showHide.get(8) == 1 ? "<td class='a-left'>"+objects.get("baseUnit")+"</td>" : "");
						materialMasterHtml.append(showHide.get(9) == 1 ? "<td class='a-left'>"+objects.get("materialGroup")+"</td>" : "");
						materialMasterHtml.append(showHide.get(10) == 1 ? "<td class='a-left'>"+objects.get("itemcategorygroup")+"</td>" : "");
						materialMasterHtml.append(showHide.get(11) == 1 ? "<td class='a-left'>"+objects.get("weightUnit")+"</td>" : "");
						materialMasterHtml.append(showHide.get(12) == 1 ? "<td class='a-left'>"+objects.get("ClassType")+"</td>" : "");
						materialMasterHtml.append(showHide.get(13) == 1 ? "<td class='a-left'>"+objects.get("materialClass")+"</td>" : "");
						materialMasterHtml.append(showHide.get(14) == 1 ? "<td class='a-left'>"+objects.get("Characteristic1")+"</td>" : "");
						materialMasterHtml.append(showHide.get(15) == 1 ? "<td class='a-left'>"+objects.get("Characteristic2")+"</td>" : "");
						materialMasterHtml.append(showHide.get(16) == 1 ? "<th class='a-left'>"+objects.get("Characteristic3")+"</td>" : "");
						materialMasterHtml.append(showHide.get(17) == 1 ? "<td class='a-left'>"+objects.get("Characteristic4")+"</td>" : "");
						materialMasterHtml.append(showHide.get(18) == 1 ? "<td class='a-left'>"+objects.get("Characteristic5")+"</td>" : "");
						materialMasterHtml.append(showHide.get(19) == 1 ? "<td class='a-left'>"+objects.get("Characteristic6")+"</td>" : "");
						materialMasterHtml.append(showHide.get(20) == 1 ? "<td class='a-left'>"+objects.get("CharacteristicValue1")+"</td>" : "");
						materialMasterHtml.append(showHide.get(21) == 1 ? "<td class='a-left'>"+objects.get("CharacteristicValue2")+"</td>" : "");
						materialMasterHtml.append(showHide.get(22) == 1 ? "<td class='a-left'>"+objects.get("CharacteristicValue3")+"</td>" : "");
						materialMasterHtml.append(showHide.get(23) == 1 ? "<td class='a-left'>"+objects.get("CharacteristicValue4")+"</td>" : "");
						materialMasterHtml.append(showHide.get(24) == 1 ? "<td class='a-left'>"+objects.get("CharacteristicValue5")+"</td>" : "");
						materialMasterHtml.append(showHide.get(25) == 1 ? "<td class='a-left'>"+objects.get("CharacteristicValue6")+"</td>" : "");
						materialMasterHtml.append(showHide.get(26) == 1 ? "<td class='a-left'>"+objects.get("taxClass1")+"</td>" : "");
						materialMasterHtml.append(showHide.get(27) == 1 ? "<td class='a-left'>"+objects.get("taxClass2")+"</td>" : "");
						materialMasterHtml.append(showHide.get(28) == 1 ? "<td class='a-left'>"+objects.get("taxClass3")+"</td>" : "");
						materialMasterHtml.append(showHide.get(29) == 1 ? "<td class='a-left'>"+objects.get("taxClass4")+"</td>" : "");
						materialMasterHtml.append(showHide.get(30) == 1 ? "<td class='a-left'>"+objects.get("taxClass5")+"</td>" : "");
						materialMasterHtml.append(showHide.get(31) == 1 ? "<td class='a-left'>"+objects.get("taxClass6")+"</td>" : "");
						materialMasterHtml.append(showHide.get(32) == 1 ? "<td class='a-left'>"+objects.get("taxClass7")+"</td>" : "");
						materialMasterHtml.append(showHide.get(33) == 1 ? "<td class='a-left'>"+objects.get("taxClass8")+"</td>" : "");
						materialMasterHtml.append(showHide.get(34) == 1 ? "<td class='a-left'>"+objects.get("accAssigntGroup")+"</td>" : "");
						materialMasterHtml.append(showHide.get(35) == 1 ? "<td class='a-left'>"+objects.get("itemCatGroup")+"</td>" : "");
						materialMasterHtml.append(showHide.get(36) == 1 ? "<td class='a-left'>"+objects.get("AvailCheck")+"</td>" : "");
						materialMasterHtml.append(showHide.get(37) == 1 ? "<td class='a-left'>"+objects.get("transportationGroup")+"</td>" : "");
						materialMasterHtml.append(showHide.get(38) == 1 ? "<td class='a-left'>"+objects.get("loadingGroup")+"</td>" : "");
						materialMasterHtml.append(showHide.get(39) == 1 ? "<td class='a-left'>"+objects.get("hsnCode")+"</td>" : "");
						materialMasterHtml.append(showHide.get(40) == 1 ? "<td class='a-left'>"+objects.get("salesText")+"</td>" : "");
						materialMasterHtml.append(showHide.get(41) == 1 ? "<td class='a-left'>"+objects.get("purchasingGroup")+"</td>" : "");
						materialMasterHtml.append(showHide.get(42) == 1 ? "<td class='a-left'>"+objects.get("manufacturingPartNumber")+"</td>" : "");
						materialMasterHtml.append(showHide.get(43) == 1 ? "<td class='a-left'>"+objects.get("valuationClass")+"</td>" : "");
						materialMasterHtml.append(showHide.get(44) == 1 ? "<td class='a-left'>"+objects.get("priceControlIndicator")+"</td>" : "");
						materialMasterHtml.append(showHide.get(45) == 1 ? "<td class='a-left'>"+objects.get("priceUnit")+"</td>" : "");
						materialMasterHtml.append(showHide.get(46) == 1 ? "<td class='a-left'>"+objects.get("movingAvgPrice")+"</td>" : "");
						materialMasterHtml.append(showHide.get(47) == 1 ? "<td class='a-left'>"+objects.get("POtext")+"</td>" : "");
						materialMasterHtml.append("</tr>"); 
			}
			
		}else {
			materialMasterHtml.append("<tr>");
			materialMasterHtml.append("<td colspan='").append(colspan).append("' id='noRecordFound' value='noRecordFound' height='30' class='t-align-center v-a-middle'>").append(messageSource.getMessage("empty_records", null, LocaleContextHolder.getLocale())).append("</td>");
			materialMasterHtml.append("</tr>");
		}
		materialMasterHtml.append("<input type=\"hidden\" id=\"totalPages\" value=\"");
		materialMasterHtml.append(totalPages);
		materialMasterHtml.append( "\">");
		materialMasterHtml.append("<input type=\"hidden\" name=\"totalRecords\" id=\"totalRecords\" value=\"");
		materialMasterHtml.append(totalRecords);
		materialMasterHtml.append("\">");
	
		res.getWriter().write(materialMasterHtml.toString().trim());
				
		}catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
				
	}
	
	
	/**
	 * @author pranav.gandharva
	 * @param request
	 * @param redirectAttributes
	 * @param officerDocMappingId
	 * @param objectId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/etender/buyer/createrfp/{officerDocMappingId}/{objectId}/{enc}", method = RequestMethod.GET)
	private String createRfpBoq(HttpServletRequest request, RedirectAttributes redirectAttributes,
			@PathVariable("officerDocMappingId") int officerDocMappingId, @PathVariable("objectId") int objectId)
			throws Exception {
		int userId = abcUtility.getSessionUserId(request);
		String retVal = "redirect:/sessionexpired";
		SessionBean sessionBean = (SessionBean) request.getSession()
				.getAttribute(CommonKeywords.SESSION_OBJ.toString());
		if (null != sessionBean) {
			boolean success = false;
			boolean cstatus = smClientTenderService.getFileStatus(objectId, 2);
			String errorMessage = "";
			List<Object[]> tblOfficerDocument = fileUploadService.getOfficerDocDetailsForRemove(officerDocMappingId);
			String filePath = docUploadPath + tblOfficerDocument.get(0)[3].toString();
			filePath = filePath.replace("\\", "\\\\");
			filePath += "\\" + tblOfficerDocument.get(0)[2].toString();
			Iterator<Row> rows = null;
			SpaceMatrixDtBean spDtBean = new SpaceMatrixDtBean();
			File file = new File(filePath);
			int ext = file.getName().lastIndexOf('.');
			String lst = file.getName().substring(ext + 1);
			boolean isXls = "xls".equalsIgnoreCase(lst);
			file = abcUtility.CheckDirExist(file);
			FileInputStream input = null;
			if(file.exists()){
				input = new FileInputStream(file);
				if (isXls) {
					HSSFWorkbook workBook = new HSSFWorkbook(new POIFSFileSystem(input));
					HSSFSheet sheet = workBook.getSheetAt(0);
					rows = sheet.rowIterator();
				} else {
					XSSFWorkbook workBook = new XSSFWorkbook(input);
					XSSFSheet sheet = workBook.getSheetAt(0);
					rows = sheet.rowIterator();
				}
			}
			DataFormatter formatter = new DataFormatter();
			List<GetExcelDataBean> listToAdd = new ArrayList<GetExcelDataBean>();
			try {
				if (null != rows) {
					while (rows.hasNext()) {
						GetExcelDataBean dtbean = new GetExcelDataBean();
						Row row = rows.next();
						if (row.getRowNum() == 0) {
							continue;
						}
						Iterator<Cell> cell = row.cellIterator();
						loopOnRow:
							while (cell.hasNext()) {
							Cell cells = cell.next();
							switch (cells.getCellType()) {
							case Cell.CELL_TYPE_BLANK:
								continue loopOnRow;
							case Cell.CELL_TYPE_STRING:
								dtbean.setbOQDescription(String.valueOf(row.getCell(3)));
								dtbean.setbOQType(String.valueOf(row.getCell(2)));
								dtbean.setCustomerName(String.valueOf(row.getCell(7)));
								dtbean.setDescription(String.valueOf(row.getCell(10)));
								dtbean.setPackageDescription(String.valueOf(row.getCell(12)));
								dtbean.setProjectID(String.valueOf(row.getCell(0)));
								dtbean.setProjectName(String.valueOf(row.getCell(1)));
								break;
							case Cell.CELL_TYPE_NUMERIC:
								dtbean.setbOQNo(NumberToTextConverter.toText(row.getCell(4).getNumericCellValue()));
								dtbean.setbOQItem(String.valueOf(row.getCell(5)));
								dtbean.setCustomerNo(String.valueOf(row.getCell(6)));
								dtbean.setMaterial(NumberToTextConverter.toText(row.getCell(8).getNumericCellValue()));
								dtbean.setUoM(String.valueOf(row.getCell(9)));
								dtbean.setMaterialGroup(
										Integer.valueOf(formatter.formatCellValue(row.getCell(11)).toString()));
								dtbean.setQtyInBOQ(String.valueOf(row.getCell(13)));
								dtbean.setSalesPrice(String.valueOf(row.getCell(14)));
								dtbean.setAmountInBOQ(String.valueOf(row.getCell(15)));
								dtbean.setPlantCode(formatter.formatCellValue(row.getCell(18)).toString());
								dtbean.setPrNo(NumberToTextConverter.toText(row.getCell(16).getNumericCellValue()));
								dtbean.setPrItem(NumberToTextConverter.toText(row.getCell(17).getNumericCellValue()));
								break;

							}

						}
						listToAdd.add(dtbean);
						Collections.sort(listToAdd);
					}
				}
				HashSet<Integer> sets = new HashSet<Integer>();

				for (int i = 0; i < listToAdd.size(); i++) {
					sets.add(listToAdd.get(i).getMaterialGroup());
				}
				Map<Integer, ArrayList<String>> map = spDtBean.getMapForColumnValues();
				for (Integer material : sets) {
					spDtBean = new SpaceMatrixDtBean();
					map = new HashMap<Integer, ArrayList<String>>();
					ArrayList<String> unitOfMeasure = new ArrayList<String>();
					ArrayList<String> description = new ArrayList<String>();
					ArrayList<String> addMaterial = new ArrayList<String>();
					ArrayList<String> boqType = new ArrayList<String>();
					ArrayList<String> prNo = new ArrayList<String>();
					ArrayList<String> qtyInBoq = new ArrayList<String>();
					ArrayList<String> prItem = new ArrayList<String>();
					ArrayList<String> boqNo = new ArrayList<String>();
					for (int j = 0; j < listToAdd.size(); j++) {
						if (material == listToAdd.get(j).getMaterialGroup()) {
							spDtBean.getTblSmboqdtls().setTblsmboq(new TblSmboq(objectId));
							spDtBean.getTblSmboqdtls().setMaterialgroupId(material);
							unitOfMeasure.add(listToAdd.get(j).getUoM());
							description.add(listToAdd.get(j).getDescription());
							addMaterial.add(smClientTenderService.getMaterialDescriptionByPlant(listToAdd.get(j).getMaterial(),listToAdd.get(j).getPlantCode()));
							prNo.add(listToAdd.get(j).getPrNo());
							boqType.add(listToAdd.get(j).getbOQType());
							qtyInBoq.add(listToAdd.get(j).getQtyInBOQ());
							prItem.add(listToAdd.get(j).getPrItem());
							boqNo.add(listToAdd.get(j).getbOQNo());
							map.put(7, unitOfMeasure);
							map.put(3, description);
							map.put(2, addMaterial);
							map.put(4, boqType);
							map.put(0, prNo);
							map.put(6, qtyInBoq);
							map.put(1, prItem);
							map.put(5, boqNo);
							spDtBean.getTblTender().setTenderNo(listToAdd.get(j).getProjectID());
							spDtBean.getTblTender().setTenderBrief(listToAdd.get(j).getPackageDescription());
							spDtBean.getTblTenderForm().setFormName(listToAdd.get(j).getPackageDescription());
							spDtBean.getTblTenderTable().setTableName(AbcUtility.reverseReplaceSpecialChars(listToAdd.get(j).getPackageDescription()));

						}

					}
					spDtBean.setMapForColumnValues(map);
					errorMessage = CommonKeywords.ERROR_MSG_KEY.toString();
					if (cstatus) {
						success = smClientTenderService.setAllSpaceMatrixData(spDtBean, request,objectId,sessionBean);
					} else {
						errorMessage = "msg_rfp_alreday_processed";
					}
				}
			} catch (Exception e) {
				exceptionHandlerService.writeLog(e);
			} finally {
				if(input!=null){
					input.close();
				}
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
						manageSapBoq, createRfpFromSap, 0, 0);

			}
			if (success) {
				redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_event_create");
				return "redirect:/etender/buyer/getrfpdetails/"+objectId
						+ encryptDecryptUtils.generateRedirect("etender/buyer/getrfpdetails/"+objectId, request);
			} else {
				redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), errorMessage);
				return "redirect:/etender/buyer/managesapboq"
						+ encryptDecryptUtils.generateRedirect("etender/buyer/managesapboq", request);
			}
		} else {
			return retVal;
		}
	}

	/**
	 * @author pranav.gandharva
	 * @param smboqId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/etender/buyer/getrfpdetails/{ObjectId}/{enc}", method = RequestMethod.GET)
	public String getRfpDettails(@PathVariable("ObjectId") int smboqId, Model model, HttpServletRequest request)
			throws Exception {
		String retVal = "redirect:/sessionexpired";
		SessionBean sessionBean = (SessionBean) request.getSession()
				.getAttribute(CommonKeywords.SESSION_OBJ.toString());
		if (null != sessionBean) {
			List<Object[]> objects = smClientTenderService.getSapBoqDetails(smboqId);
			model.addAttribute("rfpdetails", objects);
			retVal = "/etender/buyer/ViewRfpDetails";
		}

		return retVal;
	}
	
    /**
     * @author pranav.gandharva
     * @param map
     * @param request
     * @return
     */
    @RequestMapping(value = "etender/common/getProjectReport/{enc}", method = RequestMethod.GET)
    public String getProjectReport(ModelMap map,HttpServletRequest request){
    	SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
    	String retVal = "redirect:/sessionexpired";
    	int userTypeId = abcUtility.getSessionUserTypeId(request);
    	int userId = abcUtility.getSessionUserId(request);
    		try {
    			if (null != sessionBean && userTypeId == 3 || userTypeId == 1) {
    				map.addAttribute("selNumOperation", getSearch4Numeric());
                    retVal = "/etender/common/ProjectReport";		
    		  }
    	}catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}finally{
    	 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), projectReportLink, viewProjctReport, 0, userId);
    	}
    	    
    	return retVal;
    }
    
    /**
     * @author pranav.gandharva
     * @param map
     * @param request
     * @param session
     * @return
     * @throws Exception
     */
    @RequestMapping(value="etender/buyer/searchprojectreport",method=RequestMethod.POST)
    public String searchProjectReport(ModelMap map,HttpServletRequest request,HttpSession session) throws Exception{
    	SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
    	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    	String page= "redirect:/sessionexpired";
    	
    	try{
    	if(sessionBean != null){
    		
    		int eventId= StringUtils.hasLength(request.getParameter("txtEventId")) ? Integer.parseInt(request.getParameter("txtEventId")) : 0;
    		String projectId= StringUtils.hasLength(request.getParameter("txtprojectId")) ? request.getParameter("txtprojectId").replace("-", "&#45;") : null;
    		String comapanyName= StringUtils.hasLength(request.getParameter("cmpname")) ? request.getParameter("cmpname") : null;
    		String responsibleUser= StringUtils.hasLength(request.getParameter("responsibleuser")) ? request.getParameter("responsibleuser") : null;
    		int dateOperation= StringUtils.hasLength(request.getParameter("selNumOpPublishDateFrom")) ? Integer.parseInt(request.getParameter("selNumOpPublishDateFrom")) : 0;
    		Date publishDatefrom= StringUtils.hasLength(request.getParameter("PublishDateFrom")) ? CommonUtility.getDateObj(request.getParameter("PublishDateFrom")) : null;
    		Date publishDateTo= StringUtils.hasLength(request.getParameter("PublishDateTo")) ? CommonUtility.getDateObj(request.getParameter("PublishDateTo")) : null;
    		int pageNo= StringUtils.hasLength(request.getParameter("txtPageNo")) ? Integer.parseInt(request.getParameter("txtPageNo")) : 0;
    		List<Short> showHide = new ArrayList<Short>();
    		Map<String,Object> reportData=smClientTenderService.getProjectReport(eventId,projectId,comapanyName,responsibleUser,clientBean.getClientId(),dateOperation,publishDatefrom,publishDateTo,recordPerPage,pageNo);
    	    ArrayList<LinkedHashMap<String, Object>> formDetail=(ArrayList<LinkedHashMap<String, Object>>) reportData.get(RESULTSET_1);
    	    ArrayList<LinkedHashMap<String, Object>> dispPageDetail=(ArrayList<LinkedHashMap<String, Object>>) reportData.get(RESULTSET_2);
    	    ArrayList<LinkedHashMap<String, Object>> bidderDetails=(ArrayList<LinkedHashMap<String, Object>>) reportData.get(RESULTSET_3);
    	    HashMap< String, Object> unitRate = new  HashMap<String, Object>();
    	    HashMap< String, Object> totalRate = new  HashMap<String, Object>();
    	    int colspan = 1; 
    	    
    	    showHide.add(Short.valueOf("1"));
    	    if (request.getParameter("chkprojId") != null) {
    	    	showHide.add(Short.valueOf("1"));
                colspan++;
             } else {
            	 showHide.add(Short.valueOf("0"));
             }
    	     if (request.getParameter("chkeveId") != null) {
    	    	showHide.add(Short.valueOf("1"));
                colspan++;
             } else {
            	 showHide.add(Short.valueOf("0"));
             }
    	     if (request.getParameter("chkresponsibleUser") != null) {
    	    	showHide.add(Short.valueOf("1"));
                colspan++;
             } else {
            	 showHide.add(Short.valueOf("0"));
             }
    	     if (request.getParameter("chkboqType") != null) {
    	    	showHide.add(Short.valueOf("1"));
                colspan++;
             } else {
            	 showHide.add(Short.valueOf("0"));
             }
    	     if (request.getParameter("chkmaterialGrp") != null) {
     	    	showHide.add(Short.valueOf("1"));
                colspan++;
              } else {
             	 showHide.add(Short.valueOf("0"));
              }
    	     if (request.getParameter("chkprNo") != null) {
     	    	showHide.add(Short.valueOf("1"));
                colspan++;
              } else {
             	showHide.add(Short.valueOf("0"));
              }
    	     if (request.getParameter("chkprItem") != null) {
     	    	showHide.add(Short.valueOf("1"));
                colspan++;
              } else {
             	showHide.add(Short.valueOf("0"));
              }
    	     if (request.getParameter("chkitemName") != null) {
     	    	showHide.add(Short.valueOf("1"));
                colspan++;
              } else {
             	 showHide.add(Short.valueOf("0"));
              }
    	     if (request.getParameter("chkdescript") != null) {
     	    	showHide.add(Short.valueOf("1"));
                colspan++;
              } else {
             	showHide.add(Short.valueOf("0"));
              }
    	     if (request.getParameter("chkboqNo") != null) {
     	    	showHide.add(Short.valueOf("1"));
                colspan++;
              } else {
             	showHide.add(Short.valueOf("0"));
              }
    	     if (request.getParameter("chkqtyBoq") != null) {
    	    	showHide.add(Short.valueOf("1"));
                colspan++;
             } else {
            	showHide.add(Short.valueOf("0"));
             }
    	     if (request.getParameter("chkuom") != null) {
     	    	showHide.add(Short.valueOf("1"));
                 colspan++;
             } else {
             	showHide.add(Short.valueOf("0"));
             }
             if (request.getParameter("chkeventDate") != null) {
      	    	showHide.add(Short.valueOf("1"));
                colspan++;
             } else {
              	 showHide.add(Short.valueOf("0"));
             }
    	      
    	    	for(LinkedHashMap<String, Object> bidDet:bidderDetails){
            			unitRate.put(bidDet.get("eventId")+"_"+bidDet.get("rowid")+"_"+bidDet.get("companyid"), bidDet.get("UnitRate"));
            			totalRate.put(bidDet.get("eventId")+"_"+bidDet.get("rowid")+"_"+bidDet.get("companyid"), bidDet.get("Netamount"));
    	    	}
    	    	map.put("mapBidderUnitRate", unitRate);
        	    map.put("mapBidderTotalRate", totalRate); 
    	    	
    	    if(dispPageDetail != null){
    	         for(LinkedHashMap<String, Object> data:dispPageDetail){
    	        	 int totalPages = Integer.parseInt(data.get("TotalPages").toString());
                     if (totalPages == 0){
                         totalPages = 1;
                     }
                     map.addAttribute("totalRecords", data.get("TotalRecords"));
                     map.addAttribute("totalPages", totalPages);
    	         }
    	    }
    	    ModelMap bidderMap= new ModelMap();
    	    ArrayList<Object> compList = new ArrayList<Object>();
    	    for(LinkedHashMap<String, Object> details:bidderDetails){
    	    	bidderMap.put("$"+details.get("companyId"), details);
    	    }
    	    for (String string : bidderMap.keySet()) {
    	    	compList.add(bidderMap.get(string));
    	    }
    	    map.put("compList", compList);
    	    
    	    Map<String,Object> pdfreportData=smClientTenderService.getProjectReport(eventId,projectId,comapanyName,responsibleUser,clientBean.getClientId(),dateOperation,publishDatefrom,publishDateTo,-1,pageNo);
    	    ArrayList<LinkedHashMap<String, Object>> pdfformDetail=(ArrayList<LinkedHashMap<String, Object>>) pdfreportData.get(RESULTSET_1);
    	    ArrayList<LinkedHashMap<String, Object>> pdfbidderDetails=(ArrayList<LinkedHashMap<String, Object>>) pdfreportData.get(RESULTSET_3);
    	    
    	    unitRate = new HashMap<String, Object>();
    	    totalRate= new HashMap<String, Object>();
    	    
    	    for(LinkedHashMap<String, Object> bidDet:pdfbidderDetails){
    			unitRate.put(bidDet.get("eventId")+"_"+bidDet.get("rowid")+"_"+bidDet.get("companyid"), bidDet.get("UnitRate"));
    			totalRate.put(bidDet.get("eventId")+"_"+bidDet.get("rowid")+"_"+bidDet.get("companyid"), bidDet.get("Netamount"));
    	     }
    	    map.put("pdfmapBidderUnitRate", unitRate);
    	    map.put("pdfmapBidderTotalRate", totalRate); 
    	    
    	    bidderMap= new ModelMap();
    	    compList = new ArrayList<Object>();
    	    for(LinkedHashMap<String, Object> details:pdfbidderDetails){
    	    	bidderMap.put("$"+details.get("companyId"), details);
    	    }
    	    for (String string : bidderMap.keySet()) {
    	    	compList.add(bidderMap.get(string));
    	    }
    	    map.put("pdfcompList", compList);
    	    
    	    map.put("colspan", colspan);
    	    map.put("showHide", showHide);
    	    map.addAttribute("selNumOperation", getSearch4Numeric());
    	    map.addAttribute("pageNo", pageNo);
    	    map.put("pdfformDetail", pdfformDetail);
    	    map.put("pdfbidderDetails", pdfbidderDetails);
    	    map.put("formDetail", formDetail);
    	    map.put("bidderDetails", bidderDetails);
    	    page="/etender/common/ProjectReport";
    	}
    	}catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}finally{
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), projectReportLink, searchProjectReport, 0, 0);
    	}
    		    	
    	return page;
   }
		
    /**
     * @author pranav.gandharva
     * @param userId
     * @param clientId
     * @param bidderRegistrationDataBean
     * @param request
     * @param map
     * @return
     */
    @RequestMapping(value = "/bidderregistrationforsm",params = {"clientId","userId"} , method = RequestMethod.GET)
	public String get(@RequestParam("userId") int userId , @RequestParam("clientId") int clientId ,@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean,HttpServletRequest request,ModelMap map) {
    	String editPage = null;
    	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
         try {            
        	 
        	 smClientTenderService.updateVendorStatus(1,9,userId,clientId);
        	 List<Object[]> editBidderData = manageBidderService.viewBidderProfile(userId, clientId, false);
        	 bidderRegistrationDataBean.setTxtFullName(editBidderData.get(0)[0].toString());
         	 bidderRegistrationDataBean.setTxtCompanyName(editBidderData.get(0)[1].toString());
         	 bidderRegistrationDataBean.setTxtaAddress(editBidderData.get(0)[2].toString());
         	 bidderRegistrationDataBean.setSelCountry((Integer)editBidderData.get(0)[3]);
         	 bidderRegistrationDataBean.setSelState(editBidderData.get(0)[4].toString());
         	 bidderRegistrationDataBean.setTxtCity(editBidderData.get(0)[5].toString());
         	 bidderRegistrationDataBean.setTxtPhone(editBidderData.get(0)[6].toString());
         	 bidderRegistrationDataBean.setTxtMobileNo(editBidderData.get(0)[7].toString());
         	 bidderRegistrationDataBean.setTxtWebsite(editBidderData.get(0)[8].toString());
         	 bidderRegistrationDataBean.setTxtEmailId(editBidderData.get(0)[9].toString());
         	 bidderRegistrationDataBean.setHdBidderId((Integer)editBidderData.get(0)[11]);
         	 bidderRegistrationDataBean.setHdCompanyId((Integer)editBidderData.get(0)[12]);
         	 bidderRegistrationDataBean.setSelTimezone((Integer)editBidderData.get(0)[15]);
         	 bidderRegistrationDataBean.setSelHintQue(editBidderData.get(0)[16].toString());
         	 bidderRegistrationDataBean.setTxtHintAns(editBidderData.get(0)[17].toString());
         	 bidderRegistrationDataBean.setTxtAlternateLoginId(editBidderData.get(0)[20]!=null ? editBidderData.get(0)[20].toString() : "");
         	 
         	TblVendorCodeMapping tblVendorCodeMapping = manageBidderService.getVendorCode(userId,clientId);
        	if(tblVendorCodeMapping!=null){
        		bidderRegistrationDataBean.setTxtVendorCode(tblVendorCodeMapping.getVendorCode());
        	}else{
        		bidderRegistrationDataBean.setTxtVendorCode("");
        	}
         	 
         	 List<Object[]> editUserKeywords = manageBidderService.getBidderKeywords(userId);
         	 if(editUserKeywords != null && !editUserKeywords.isEmpty()) {
        		 StringBuilder bidderKeywords = new StringBuilder();
        		 for (int i=0; i<editUserKeywords.size(); i++) {
        			bidderKeywords.append(editUserKeywords.get(i)).append(",");
        		 }
        		 bidderRegistrationDataBean.setTxtaBusCatKeywords(bidderKeywords.toString().substring(0, bidderKeywords.length()-1));
        	 }
         	 
           	 String langId=WebUtils.getCookie(request, "locale").getValue();
        	 map.put("isManDocsReq", clientService.getMandocRequired(abcUtility.getSessionClientId(request)));
 			 map.put("timezoneList", modelToSelectItem.convertListIntoSelectItemList(commonService.getTimeZoneList(), "timeZoneId", "lang"+langId));
 			 map.put("hintQueList",modelToSelectItem.convertListIntoSelectItemList(commonService.getHintQuestionList(), "hintQuestionId", "lang"+langId));
 			 map.put("countryList", modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId));
 			 map.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(bidderRegistrationDataBean.getSelCountry()), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
         	 map.addAttribute("clientId",clientId);
         	 map.addAttribute("objectId", userId);
         	 map.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(manageBidderFieldValueId, clientId, userId));
     
        	if(abcUtility.isModuleAssignToClient(request,9)){  // Module Assign Spend Analysis 
				map.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
             }else{
            	map.put("isCategoryAllow",0);
             }
        	
        	if(map.get("isCategoryAllow").equals(1))
            {	
        		List<Object[]> listselectedCategory  = commonService.getCategoryIdList(userId,registrationLinkId);
            	map.put("selectedCategory",listselectedCategory);
            }

         } catch (Exception e) {
             exceptionHandlerService.writeLog(e);
         } finally {
        	 commonAuditService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), registrationLinkId, viewRegistrationPage, ipAddress, userId, 0);
         }
        editPage = "bidderRegistrationForSm";
    	return editPage;
	}
    
    @RequestMapping(value="/updateBidderRegistrationForSm", method=RequestMethod.POST)
    private String editBidderProfile(@ModelAttribute("bidderRegistrationDataBean") BidderRegistrationDataBean bidderRegistrationDataBean, BindingResult result, HttpServletRequest request, HttpSession session, ModelMap map, RedirectAttributes redirectAttributes){
    	int userId=0;
     	SessionBean sessionBean = null;
		int clientId = abcUtility.getSessionClientId(request);
    	String resultPage=null;
    	boolean success = false;
    	String selectedCategory[] = null;
    	String isCategoryAllow  = "0";
    	ClientBean clientBean = null;
    	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    	try{
    		clientBean = (ClientBean) (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString())!=null ? request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) : null);
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                 sessionBean = (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
            } else if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
                 sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
            }
            session.setAttribute(CommonKeywords.SESSION_OBJ.toString(),sessionBean);
            
    		bidderRegistrationDataBean.setCommonValidators(commonValidators);
			selectedCategory = request.getParameterValues("txtCategory");
			isCategoryAllow = request.getParameter("hdIsCategoryAllow");
			List<Object> busCatKeywords = null;
			bidderRegistrationDataBean.validate(result, false, false, true, 1);
			bidderRegistrationDataBean.setQuickRegister(false);
			userId=bidderRegistrationDataBean.getHdBidderId();
			int bidderId = 0;
    				
    		if(isCategoryAllow != null && isCategoryAllow.equals("1") && selectedCategory != null){
    			busCatKeywords = commonService.getKeywordNamesByIds(selectedCategory);
    			bidderRegistrationDataBean.setTxtaBusCatKeywords(abcUtility.converObjectArrayToCommas(busCatKeywords));
    		}
    		
			if(result.hasErrors()) {
				String langId=WebUtils.getCookie(request, "locale").getValue();
				map.put("timezoneList", modelToSelectItem.convertListIntoSelectItemList(commonService.getTimeZoneList(), "timeZoneId", "lang"+langId));
				map.put("countryList", modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId));
				map.put("hintQueList",modelToSelectItem.convertListIntoSelectItemList(commonService.getHintQuestionList(), "hintQuestionId", "lang"+langId));
				if(bidderRegistrationDataBean.getSelCountry() != 0) {
					map.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(bidderRegistrationDataBean.getSelCountry()), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
				}
	        	
	        	map.put("editProfileByBidder", true);
	        	if(abcUtility.isModuleAssignToClient(request,9)){   
					map.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
	             }else{
	            	map.put("isCategoryAllow",0);
	             }
	        	if(map.get("isCategoryAllow").equals(1))
	            {
	        		List<Object[]> listselectedCategory  = commonService.getCategoryIdList(bidderId,registrationLinkId);
	            	map.put("selectedCategory",listselectedCategory);
	            }
	        	map.addAttribute("clientId",clientId);
	        	map.addAttribute("objectId", userId);
	        	map.addAttribute("linkId", manageBidderFieldValueId);
				success=false;
				resultPage = "bidderRegistrationForSm";
			} else {
				String pageName = getDeafultListringPageName(clientId, userId, map,request);
				TblUserLogin tblUserLogin = null;
				TblUserDetail tblUserDetail = bidderRegistrationDataBean._toTblUserDetail(abcUtility.getSessionUserId(request));
				success = true;
				if(success){
					success = manageBidderService.updateBidderRegistration(false,1, " ", bidderRegistrationDataBean, tblUserLogin,tblUserDetail, bidderRegistrationDataBean._toTblCompany(clientId), bidderRegistrationDataBean._toTblUserHistory(userHistoryEdit, clientId), bidderRegistrationDataBean.getTxtaBusCatKeywords(), false, abcUtility.getSessionUserId(request),true,clientId);
			    	success = smClientTenderService.updateVendorStatus(0, 9, userId, clientId);
				}
				if(success){
					success = dynamicFieldService.addDynamicFieldValueProcess(dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request),clientId,manageBidderFieldValueId,userId,userId);
				}
				if(success){
					if(abcUtility.isModuleAssignToClient(request,9) && isCategoryAllow != null && isCategoryAllow.equals("1")){
                    	commonService.insertUpdateCategory("edit",userId,selectedCategory,registrationLinkId);
                    }
                     
                }
				
                resultPage="redirect:/"+pageName + encryptDecryptUtils.generateRedirect(pageName, request);
                
                redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_bidder_data_updated" : CommonKeywords.ERROR_MSG_KEY.toString());
			}
    	}
    	catch(Exception e){
    		resultPage = exceptionHandlerService.writeLog(e);
    	}
    	finally{
    		commonAuditService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), registrationLinkId, updateStateAndTimezone, ipAddress, userId, 0);
    	}
    	return resultPage;
    }
   @RequestMapping(value = "/etender/buyer/manualSyncMaterialMaster",method = RequestMethod.POST) 
   @ResponseBody
   public String manualCosumeMaterialMasters(){
    String msg = ""; 	
    try {
        URL url = new URL(manualSyncUrl);
        HttpURLConnection huc = (HttpURLConnection) url.openConnection();
        huc.setRequestProperty("accept", "*/*");
        huc.setRequestMethod("GET");
        huc.connect();
        msg = huc.getResponseMessage();
    } catch (Exception e) {
    	exceptionHandlerService.writeLog(e);
    } 
    return msg;
}
    
    private String getDeafultListringPageName(int clientId, int userId, ModelMap map,HttpServletRequest request) throws Exception{
   	 List<Object> moduleIds = clientService.getDefaultModuleId(clientId);
   	 String defModuleId =  moduleIds.get(0).toString();
   	 String pageName="";
   	 ClientBean clientBean = (ClientBean) (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString())!=null ? request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) : null);
   	 
   	 if("3".equalsIgnoreCase(defModuleId)){  		/* Tender */
   		 pageName="etender/bidder/tenderlisting/0";
   	 }
   	 else if("5".equalsIgnoreCase(defModuleId)) 	/* Auction */
   	 {
   		 if(clientBean.getIsDIYClient() == 1)
   		 {
   			 pageName="eauction/bidder/quickauctionlisting";
   		 }else{
   			 pageName="eauction/bidder/auctionlisting";
   		 }
   		 
   	 }
   	 else 
   	 {
   		 pageName="common/bidder/viewbidderprofile/"+userId;
   		 map.addAttribute("isDeafaultPage", true);
   	 }
   	 return pageName;
    }
    
    public List<SelectItem> getSearch4Numeric() {
        List<SelectItem> items = new ArrayList<SelectItem>();
        items.add(new SelectItem("equal", 1));
        items.add(new SelectItem("not equal", 2));
        items.add(new SelectItem("less", 3));
        items.add(new SelectItem("less or equal", 4));
        items.add(new SelectItem("greater", 5));
        items.add(new SelectItem("greater or equal", 6));
        items.add(new SelectItem("between", 7));
        return items;
    } 
}
