package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblNegotiationSORRemarks;
import java.util.List;

public interface TblNegotiationSORRemarksDao  {

    public void addTblNegotiationSORRemarks(TblNegotiationSORRemarks tblNegotiationSORRemarks);

    public void deleteTblNegotiationSORRemarks(TblNegotiationSORRemarks tblNegotiationSORRemarks);

    public void updateTblNegotiationSORRemarks(TblNegotiationSORRemarks tblNegotiationSORRemarks);

    public List<TblNegotiationSORRemarks> getAllTblNegotiationSORRemarks();

    public List<TblNegotiationSORRemarks> findTblNegotiationSORRemarks(Object... values) throws Exception;

    public List<TblNegotiationSORRemarks> findByCountTblNegotiationSORRemarks(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNegotiationSORRemarksCount();

    public void saveUpdateAllTblNegotiationSORRemarks(List<TblNegotiationSORRemarks> tblNegotiationSORRemarkss);
}