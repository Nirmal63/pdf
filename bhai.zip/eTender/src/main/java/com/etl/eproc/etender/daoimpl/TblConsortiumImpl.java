/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblConsortiumDao;
import com.etl.eproc.etender.model.TblConsortium;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository @Transactional
public class TblConsortiumImpl extends AbcAbstractClass<TblConsortium> implements TblConsortiumDao {


    @Override
    public void addTblConsortium(TblConsortium tblConsortium){
        super.addEntity(tblConsortium);
    }

    @Override
    public void deleteTblConsortium(TblConsortium tblConsortium) {
        super.deleteEntity(tblConsortium);
    }

    @Override
    public void updateTblConsortium(TblConsortium tblConsortium) {
        super.updateEntity(tblConsortium);
    }

    @Override
    public List<TblConsortium> getAllTblConsortium() {
        return super.getAllEntity();
    }

    @Override
    public List<TblConsortium> findTblConsortium(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblConsortiumCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblConsortium> findByCountTblConsortium(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblConsortium(List<TblConsortium> tblConsortiums){
        super.updateAll(tblConsortiums);
    }
}

