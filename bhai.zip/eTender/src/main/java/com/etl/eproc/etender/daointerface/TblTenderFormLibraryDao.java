package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderFormLibrary;
import java.util.List;

public interface TblTenderFormLibraryDao  {

    public void addTblTenderFormLibrary(TblTenderFormLibrary tblTenderFormLibrary);

    public void deleteTblTenderFormLibrary(TblTenderFormLibrary tblTenderFormLibrary);

    public void updateTblTenderFormLibrary(TblTenderFormLibrary tblTenderFormLibrary);

    public List<TblTenderFormLibrary> getAllTblTenderFormLibrary();

    public List<TblTenderFormLibrary> findTblTenderFormLibrary(Object... values) throws Exception;

    public List<TblTenderFormLibrary> findByCountTblTenderFormLibrary(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderFormLibraryCount();

    public void saveUpdateAllTblTenderFormLibrary(List<TblTenderFormLibrary> tblTenderFormLibrarys);

	public void deleteAllTblTenderFormLibrary(List<TblTenderFormLibrary> tblTenderFormLibraryList);
}