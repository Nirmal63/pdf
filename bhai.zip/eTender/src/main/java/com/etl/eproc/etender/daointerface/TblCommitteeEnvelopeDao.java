package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblCommitteeEnvelope;
import java.util.List;

public interface TblCommitteeEnvelopeDao  {

    public void addTblCommitteeEnvelope(TblCommitteeEnvelope tblCommitteeEnvelope);

    public void deleteTblCommitteeEnvelope(TblCommitteeEnvelope tblCommitteeEnvelope);

    public void updateTblCommitteeEnvelope(TblCommitteeEnvelope tblCommitteeEnvelope);

    public List<TblCommitteeEnvelope> getAllTblCommitteeEnvelope();

    public List<TblCommitteeEnvelope> findTblCommitteeEnvelope(Object... values) throws Exception;

    public List<TblCommitteeEnvelope> findByCountTblCommitteeEnvelope(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCommitteeEnvelopeCount();

    public void saveUpdateAllTblCommitteeEnvelope(List<TblCommitteeEnvelope> tblCommitteeEnvelopes);
}