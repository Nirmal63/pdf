package com.etl.eproc.etender.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderReportDetailDao;
import com.etl.eproc.etender.model.TblTenderReportDetail;

/**
*
* @author Nihar
*/
@Repository @Transactional
public class TblTenderReportDetailImpl extends AbcAbstractClass<TblTenderReportDetail> implements TblTenderReportDetailDao {

   @Override
   public void addTblTenderReportDetail(TblTenderReportDetail tblTenderReportDetail){
       super.addEntity(tblTenderReportDetail);
   }

   @Override
   public void deleteTblTenderReportDetail(TblTenderReportDetail tblTenderReportDetail) {
       super.deleteEntity(tblTenderReportDetail);
   }

   @Override
   public void updateTblTenderReportDetail(TblTenderReportDetail tblTenderReportDetail) {
       super.updateEntity(tblTenderReportDetail);
   }

   @Override
   public List<TblTenderReportDetail> getAllTblTenderReportDetail() {
       return super.getAllEntity();
   }

   @Override
   public List<TblTenderReportDetail> findTblTenderReportDetail(Object... values) throws Exception {
       return super.findEntity(values);
   }

   @Override
   public long getTblTenderReportDetailCount() {
       return super.getEntityCount();
   }

   @Override
   public List<TblTenderReportDetail> findByCountTblTenderReportDetail(int firstResult, int maxResult, Object... values) throws Exception {
       return super.findByCountEntity(firstResult, maxResult, values);
   }

   @Override
   public void saveUpdateAllTblTenderReportDetail(List<TblTenderReportDetail> tblTenderReportDetails){
       super.updateAll(tblTenderReportDetails);
   }
}

