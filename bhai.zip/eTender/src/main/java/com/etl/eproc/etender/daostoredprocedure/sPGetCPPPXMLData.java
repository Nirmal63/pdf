/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author Hira Chaudhary
 */
@Component
public class sPGetCPPPXMLData extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptender.P_GetCPPPXMLTenderData";

    public sPGetCPPPXMLData() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_CPPPTypeId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_ClientId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_TenderId", Types.VARCHAR));
    }

    
    /**
     * @param clientId
     * @param typeId
     * @param eventIds
     * @return
     * @throws Exception
     */
    public Map<String,Object> executeProcedure(int clientId, int typeId, String eventIds) throws Exception
    {
    	Map inParams = new HashMap();
        inParams.put("@V_CPPPTypeId", typeId);
        inParams.put("@V_ClientId", clientId);
        inParams.put("@V_TenderId", eventIds);
        this.compile();
        return execute(inParams);
    }
}

