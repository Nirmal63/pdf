/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.daointerface.TblAdvancePurchaseOrderDao;
import com.etl.eproc.common.model.TblAdvancePurchaseOrder;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblNegotiationSummary;
import com.etl.eproc.common.model.TblOfficerDocMapping;
import com.etl.eproc.common.model.TblOfficerDocument;
import com.etl.eproc.common.model.TblPaymentITSDetail;
import com.etl.eproc.common.model.TblPurchaseOrder;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.InvoiceDocServie;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.NegotiationService;
import com.etl.eproc.common.services.QuestionAnswerService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.services.WorkflowService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.databean.TenderOpenProcessDTBean;
import com.etl.eproc.etender.model.TblCommittee;
import com.etl.eproc.etender.model.TblCorrigendum;
import com.etl.eproc.etender.model.TblDynReport;
import com.etl.eproc.etender.model.TblDynReportFormMap;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderReevaluation;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.CommitteeFormationService;
import com.etl.eproc.etender.services.DynamicReportService;
import com.etl.eproc.etender.services.EventBidSubmissionService;
import com.etl.eproc.etender.services.EventCreationService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderCorrigendumService;
import com.etl.eproc.etender.services.TenderFormService;
import com.etl.eproc.etender.services.TenderOpenService;
import com.etl.eproc.etender.services.TenderReportService;

/**
 *
 * @author vipul
 */
@Controller
@RequestMapping("/etender/buyer")
public class TenderDashboardController {
    @Autowired
    private TenderCorrigendumService tenderCorrigendumService;
    @Autowired
    private TenderOpenService tenderOpenService;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private CommonService commonService;
    @Autowired
    private CommitteeFormationService committeeFormationService;
    @Autowired
    private DynamicReportService dynamicReportService;
    @Autowired
    private ClientService clientService;
//    @Autowired
//    private TenderCorrigendumService tenderCorrigendumService;
//    @Autowired
//    private PrebidService prebidService;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private MessageSource messageSource; 
    @Autowired
    private EventCreationService eventCreationService;
    @Autowired
    private NegotiationService negotiationService; 
    @Autowired
	private ReportGeneratorService reportGeneratorService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private QuestionAnswerService questionAnswerService;
    @Autowired
    private TenderReportService tenderReportService;
    @Autowired
	private DynamicFieldService dynamicFieldService;
    
    @Autowired
	private TblAdvancePurchaseOrderDao tblAdvancePurchaseOrderDao;
    @Autowired
    private WorkflowService workflowService; 
    @Autowired
    private InvoiceDocServie invoiceDocServie;
    @Autowired
    private LoginService loginService;
    @Autowired
    private EventBidSubmissionService eventBidSubmissionService;
    @Value("#{clientProperties['cgClient']}")
    private String cgClient;
    @Value("#{projectProperties['idfc_client_id']}")   
    private String idfcClientId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_view']?:220}")
    private int viewCommitteeLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_delete_doc']?:243}")
    private int deletePrebidDocLinkId; 
    @Value("#{tenderlinkProperties['pre_bid_meeting_upload']?:216}")
    private int uploadPrebidDocLinkId;
    @Value("#{etenderProperties['bid_opening_submoduleId']?:32}")
    private int bidOpeningSubModuleId;
    @Value("#{etenderProperties['bid_evaluation_submoduleId']?:33}")
    private int bidEvaluationSubModuleId;
    @Value("#{etenderProperties['notice_submoduleId']?:26}")
    private int noticeSubModuleId;
    @Value("#{etenderProperties['corrigendum_submoduleId']?:27}")
    private int corrigendumSubModuleId;
    @Value("#{etenderProperties['biddingForms_submoduleId']?:28}")
    private int biddingFormsSubModuleId;
    @Value("#{tenderlinkProperties['bid_opening_view']?:224}")
    private int bidOpeningViewLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_view']?:207}")
    private int bidEvaluationViewLinkId;
    @Value("#{tenderlinkProperties['view_purchase_requestor_contact_details']?:1135}")
    private int purchaseRequestorDetails;
    @Value("#{tenderlinkProperties['tender_dashboard']?:213}")
    private int buyerEventDashboardLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_upload']?:175}")
    private int noticeDocumentUploadLinkId;
    /*@Value("#{projectProperties['officer.docstatus.cancel']?:3}")
	private int officerDocStatusCancel;*/
    @Value("#{tenderlinkProperties['bidding_form_create_mandatory_docs']?:317}")
    private int createFormDocuLinkId;
    @Value("#{etenderAuditTrailProperties['postajaxTenderDashboardContentNIT']}")
    private String postajaxTenderDashboardContentNIT;
    @Value("#{etenderAuditTrailProperties['getEventDashboard']}")
    private String getEventDashboard;
    @Value("#{etenderAuditTrailProperties['postajaxTenderDashboardContentBF']}")
    private String postajaxTenderDashboardContentBF;
    @Value("#{etenderAuditTrailProperties['postajaxTenderDashboardContentPB']}")
    private String postajaxTenderDashboardContentPB;
    @Value("#{etenderAuditTrailProperties['postajaxTenderDashboardContentCORRG']}")
    private String postajaxTenderDashboardContentCORRG;
    @Value("#{etenderAuditTrailProperties['postajaxTenderDashboardContentTO']}")
    private String postajaxTenderDashboardContentTO;
    @Value("#{etenderAuditTrailProperties['postajaxTenderDashboardContentEB']}")
    private String postajaxTenderDashboardContentEB;
    @Value("#{etenderAuditTrailProperties['postajaxTenderDashboardContentREP']}")
    private String postajaxTenderDashboardContentREP;
    @Value("#{etenderAuditTrailProperties['getResultSharingForOpening']}")
    private String getResultSharingForOpening;
    @Value("#{etenderAuditTrailProperties['getResultSharingForEvaluation']}")
    private String getResultSharingForEvaluation;
    @Value("#{tenderlinkProperties['bid_opening_configure_result_sharing']?:400}")
    private int openConfigureResultSharingLinkId;
    @Value("#{tenderlinkProperties['bid_opening_edit_result_sharing']?:401}")
    private int openEditResultSharingLinkId;
    @Value("#{tenderlinkProperties['bid_opening_view_result_sharing']?:402}")
    private int openViewResultSharingLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_configure_result_sharing']?:403}")
    private int evalConfigureResultSharingLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_edit_result_sharing']?:404}")
    private int evalEditResultSharingLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_view_result_sharing']?:405}")
    private int evalViewResultSharingLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_brd_upload']?:518}")
    private int brdUploadDocumentId;
    @Value("#{tenderlinkProperties['notice_and_document_brd_re_generate']?:517}")
    private int regenerateTenderBrd;
    @Value("#{tenderlinkProperties['notice_and_document_create_auction']?:176}")
    private int convertToAuction;
    @Value("#{auctionAuditTrailProperties['success_convertToAuctionFromSealBid']}")
    private String createAuctionSuccessAuditMessage;
    @Value("#{auctionAuditTrailProperties['Fail_convertToAuctionFromSealBid']}")
    private String createAuctionFailAuditMessage;
    @Value("#{auctionAuditTrailProperties['success_getPriceBidForm']}")
    private String getPriceBidFormSuccessAuditMessage;
    @Value("#{auctionAuditTrailProperties['Fail_getPriceBidForm']}")
    private String getPriceBidFormFailAuditMessage;
    @Value("#{tenderlinkProperties['tender_create_tender']?:212}")
    private int tendercreationlink;
    
    @Value("#{linkProperties['itemwise_tender_negotiation_report']?:71}")
	private int itemwiseNegotiationReportId;
    @Value("#{tenderlinkProperties['notice_and_document_estimated_value']?:675}")
    private int estimatedValue;
    
    @Value("#{linkProperties['grandtotal_tender_negotiation_report']?:72}")
    private int grantotalNegotiationReportId;
    
    @Value("#{tenderlinkProperties['negotiation_negotiation_process_invite_for_negotiation']?:602}")
    private int negotiation_negotiation_process_invite_for_negotiation;
    @Value("#{tenderlinkProperties['bid_withdrawn_count']?:3297}")
    private String bidWithdrawnCount;
    
    @Value("#{tenderlinkProperties['negotiation_negotiation_process_start_chat']?:604}")
    private int negotiation_officer_start_chat;
    @Value("#{auctionAuditTrailProperties['estimatedvaluesuccess']}")
    private String estimatedValueSuccessAuditMessage;
    @Value("#{auctionAuditTrailProperties['estimatedvaluefail']}")
    private String estimatedValueFailAuditMessage;
    @Value("#{projectProperties['pki_eventspecific']?:2}")
    private int pkiEventSpecific;
    
    @Value("#{tenderlinkProperties['notice_and_document_upload']?:175}")
    private int uploadTenderDocLinkId;
    @Value("#{projectProperties['doc_upload_path']}")
	private String docUploadPath;
    @Value("#{auclinkProperties['document_upload']?:123}")
    private int documentUpload;
    @Value("#{linkProperties['po_process']?:7}")
    private int poProcessId;
    @Value("#{etenderProperties['negotiation_submoduleId']?:47}")
    private int negotiation_submoduleId;
    @Value("#{etenderAuditTrailProperties['negotiation_tab']}")
    private String negotiation_tab;
    @Value("#{tenderlinkProperties['offline_negotiation_process_in_workflow']?:1148}")
    private int offline_negotiation_process_in_workflow;
    @Value("#{projectProperties['rci_client_ids']}")
    private String rciClientIds;
    
    
    @Value("#{projectProperties['prebidmeeting_id']?:31}")
	private int prebidMeetingId;
	@Value("#{projectProperties['bidopening_id']?:32}")
	private int bidOpeningId;
	@Value("#{projectProperties['bidevaluation_id']?:33}")
	private int bidEvaluationId;
	
	@Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentNEGEvent']}")
	private String postajaxBiddingTenderDashboardContentNEGEvent;
	@Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentAPOEvent']}")
	private String postajaxBiddingTenderDashboardContentAPOEvent;
	@Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentPOEvent']}")
	private String postajaxBiddingTenderDashboardContentPOEvent;
	
	@Value("#{tenderlinkProperties['result_sharing_event']?:297}")
	private int resultSharingEvent;
	
    @Value("#{linkProperties['po_submoduleId']?:61}")
    private int poSubModuleId;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContract']}")
	private String postajaxBiddingTenderDashboardContract;
    
    private static final String LINK_ID= "linkId"; 
    private static final String OPTYPE= "opType"; 
    private static final String VALIDATE_TENDER_LINKS= "validateTenderLinks";
    private static final String RESULT_SET_1= "#result-set-1";
    private static final String RESULT_SET_5= "#result-set-5";
    private static final String REPORT_CONFIG_COUNT= "reportConfigCount"; 
    private static final String SHARE_BIDDER_STATUS= "shareBidderStatus"; 
    private static final String SHARE_CLARIFICATION_REPORT= "shareClarificationReport";  
    private static final String SHARE_EVALUATION_REPORT= "shareEvaluationReport";  
    
    private static final int TAB_NIT_DOCUMENT = 1;
    private static final int TAB_BIDDING_FORMS = 2;
    private static final int TAB_PREBID = 3;
    private static final int TAB_CORRIGENDUM = 4;
    private static final int TAB_TENDER_OPENING = 7;
    private static final int TAB_EVALUATE_BID = 8;
    private static final int TAB_REPORT = 9;
    private static final int TAB_LOI = 10;
    private static final int TAB_Negotiation = 11;
    private static final int TAB_QUESTIONANSWER = 12;
    private static final int TAB_PO = 14;
    private static final int TAB_APO = 13;
    private static final int TAB_PAYMENT = 15;
    private static final int TAB_COMMUNICATION = 16;
    private static final int TAB_CONTRACT = 17;
    private static final int CONTRACT_MODULEID=13;
    
    @Value("#{etenderProperties['tender_opened_status']?:4}")
    private int TENDER_OPENED_STATUS;
    @Value("#{etenderProperties['tender_completed_status']?:5}")
    private int TENDER_COMPLETED_STATUS;
    
    /**
     * @param tenderId
     * @param tabId
     * @param modelMap
     * @param request
     * @return to view
     */
    @RequestMapping(value = "/tenderdashboard/{tenderId}/{tabId}/{enc}", method = RequestMethod.GET)
    public String tenderDashboard(@PathVariable("tenderId") int tenderId, @PathVariable("tabId") int tabId, ModelMap modelMap, HttpServletRequest request) {
    	String retVal="etender/buyer/TenderDashboard";
	try {
		TblTender tblTender = tenderCommonService.getTenderById(tenderId);
		 modelMap.addAttribute("isEDraw",tblTender.getIsEDraw());
        ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        if(clientBean.getIsPkiEnabled()==pkiEventSpecific && tblTender.getIsCertRequired() ==1){
        	SessionBean sessionBean=(SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
        	if(!sessionBean.isEventSpecVerify()){
    			retVal="common/buyer/attacheventspeccerti/etender,buyer,tenderdashboard,"+tenderId+","+tabId;
    			retVal="redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
			}else{
                int designationId = 0;
                if(sessionBean != null){
                    designationId = sessionBean.getDesignationId();
                }
            int moduleId=3;
            int val=0;
		    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
		    List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isPreBidMeeting,preBidMode,cstatus,isEvaluationRequired,submissionMode");
	        if(tenderDetails!=null && !tenderDetails.isEmpty()){
	            modelMap.addAttribute("isPrebidMeeting", tenderDetails.get(0)[0]);
	            modelMap.addAttribute("preBidMode", tenderDetails.get(0)[1]);
	            modelMap.addAttribute("tenderStatus", tenderDetails.get(0)[2]);
	            modelMap.addAttribute("isEvaluationRequired", tenderDetails.get(0)[3]);
	            modelMap.addAttribute("submissionMode", tenderDetails.get(0)[4]);
	        }
	        if(Integer.valueOf(modelMap.get("brdMode").toString())==1){
	           val = commonService.isBRDExist(regenerateTenderBrd, abcUtility.getSessionClientId(request), moduleId, tenderId);
	           modelMap.addAttribute("displayReGenerate",commonService.isDisplayRegenerate(moduleId, tenderId));
	        }
	        else{
	            modelMap.addAttribute("displayReGenerate",0);
	        }
	        modelMap.put("isDisplayCreate", val);
	        modelMap.addAttribute("moduleId", 3);
	        modelMap.addAttribute("brdLinkId", regenerateTenderBrd);
	        modelMap.put("cstatus",commonService.getStatus(tenderId, moduleId));
	        modelMap.put("isNegotiationAllow",negotiationService.getisNegotiationAllowedOfficcerSide(moduleId, tenderId,tblTender.getIsNegotiationAllowed()));
	        modelMap.put("loginUserid", abcUtility.getSessionUserId(request));
	        modelMap.put("pageFrom",request.getParameter("pageFrom"));
	        
	        Map<String,String> tabRightsMap = new HashMap<String, String>();
	        List<Object[]> lstSubmodule = commonService.isLinkRightsDone(designationId, 3);
	        if(!lstSubmodule.isEmpty()){
	            for (Object[] subModule : lstSubmodule) {
	                tabRightsMap.put(subModule[0].toString(),subModule[1].toString());
	            }
	        }
	        List<Object[]> lstQADetails = tenderCommonService.getTenderFields(tenderId, "isQuestionAnswer,questionAnswerStartDate,questionAnswerEndDate,createdBy");
	        //Change Request #22284 Start
	        boolean isQAOfficerAllowed = false;
	        List<String> field = new ArrayList<String>();
			field.add("isQuestionAnswer");
			field.add("isQueAnsOfficer");
			List<Object[]> lstClientConfigFields = commonService.getClientConfigurationFields(abcUtility.getSessionClientId(request),tblTender.getTblEventType().getEventTypeId(),field);
			if (lstClientConfigFields != null) {
                for (int i = 0; i < lstClientConfigFields.size(); i++) {
                	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isQueAnsOfficer") && Integer.parseInt(lstClientConfigFields.get(i)[4].toString()) == 1){
                		isQAOfficerAllowed=true;
                    }
                }
            }
			modelMap.addAttribute("isQAOfficerAllowed", isQAOfficerAllowed);
			//End
	        boolean isQaAllowed=questionAnswerService.getIsQaAllowed(3,tenderId,abcUtility.getSessionUserId(request),abcUtility.getSessionClientId(request),abcUtility.getSessionUserTypeId(request),lstQADetails,abcUtility.getSessionUserDetailId(request),isQAOfficerAllowed,modelMap);
            modelMap.addAttribute("isQaAllowed", isQaAllowed);
            modelMap.addAttribute("createdBy", lstQADetails.size() > 0 ? lstQADetails.get(0)[3].toString():"");
	        modelMap.addAttribute("tabRightsMap", tabRightsMap);
	        //System.out.println("tenderDetails = map value---->" +tabRightsMap.values());
	        boolean isAPOAllow=false;
            boolean isPOAllow=false;
            boolean isPOPaymentTab = false;
            List<Object[]> listCMS=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
            if (listCMS != null) {
                for (int i = 0; i < listCMS.size(); i++) {
                	if(listCMS.get(i)[0].toString().equalsIgnoreCase("12")){
                		isAPOAllow=true;                		 
                    }
                	if(listCMS.get(i)[0].toString().equalsIgnoreCase("13")){
                		isPOAllow=true;                		 
                    }
                }
            }
            boolean isRCIClient = false;
            isRCIClient = commonService.isRCIClient(rciClientIds,abcUtility.getSessionClientId(request));
            if(isRCIClient){
            List<Object[]> list = invoiceDocServie.getPOListForPayment(tenderId, abcUtility.getSessionClientId(request), loginService.getCompanyId(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request)));
                    for (Object[] lst : list) {
                        Integer.parseInt(lst[0].toString());
                        if (Integer.parseInt(lst[1].toString()) == 1 || Integer.parseInt(lst[1].toString()) == 3) {
                            isPOPaymentTab = true;
                        }
                    }
            }
            
            //By Dipak For Contract Tab
            boolean isContractTab = false;
            List<Object[]> getBidderAckList=null;
            if(isAPOAllow && isPOAllow) {
            	getBidderAckList = commonService.getBidderAckFromPOList(tenderId,3);
            }else if(isPOAllow) {
            	getBidderAckList = commonService.getBidderAckFromPOList(tenderId,1);
            }
            //Used to check contract module is purchase or not.
            List<Object[]> getdefaultConfigList=clientService.getEventTypeIdForDefaultConfg(abcUtility.getSessionClientId(request),CONTRACT_MODULEID);
            if(getBidderAckList!=null && getBidderAckList.size()>0 && getdefaultConfigList!=null && getdefaultConfigList.size()>0)
            {
            	isContractTab=true;
            }
            //End
            
            
            modelMap.addAttribute("isRCIClient", isRCIClient);
            modelMap.addAttribute("isPOPaymentTab", isPOPaymentTab);
            modelMap.addAttribute("isAPOAllow",isAPOAllow);
            modelMap.addAttribute("isPOAllow",isPOAllow);
            modelMap.addAttribute("isNegotiationOfflineOnline",tblTender.getIsNegotiationAllowed());
            modelMap.addAttribute("isContractTab",isContractTab);
        }
        }else{
            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
                int designationId = 0;
                if(sessionBean != null){
                    designationId = sessionBean.getDesignationId();
                }
            int moduleId=3;
            int val=0;
		    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
		    List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isPreBidMeeting,preBidMode,cstatus,isEvaluationRequired,submissionMode");
	        if(tenderDetails!=null && !tenderDetails.isEmpty()){
	            modelMap.addAttribute("isPrebidMeeting", tenderDetails.get(0)[0]);
	            modelMap.addAttribute("preBidMode", tenderDetails.get(0)[1]);
	            modelMap.addAttribute("tenderStatus", tenderDetails.get(0)[2]);
	            modelMap.addAttribute("isEvaluationRequired", tenderDetails.get(0)[3]);
	            modelMap.addAttribute("submissionMode", tenderDetails.get(0)[4]);
	        }
	        if(Integer.valueOf(modelMap.get("brdMode").toString())==1){
	           val = commonService.isBRDExist(regenerateTenderBrd, abcUtility.getSessionClientId(request), moduleId, tenderId);
	           modelMap.addAttribute("displayReGenerate",commonService.isDisplayRegenerate(moduleId, tenderId));
	        }
	        else{
	            modelMap.addAttribute("displayReGenerate",0);
	        }
	        modelMap.put("isDisplayCreate", val);
	        modelMap.addAttribute("moduleId", 3);
	        modelMap.addAttribute("brdLinkId", regenerateTenderBrd);
	        modelMap.put("cstatus",commonService.getStatus(tenderId, moduleId));
	        modelMap.put("isNegotiationAllow",negotiationService.getisNegotiationAllowedOfficcerSide(moduleId, tenderId,tblTender.getIsNegotiationAllowed()));
	        modelMap.put("loginUserid", abcUtility.getSessionUserId(request));
	        modelMap.put("pageFrom",request.getParameter("pageFrom"));
	        
	        Map<String,String> tabRightsMap = new HashMap<String, String>();
	        List<Object[]> lstSubmodule = commonService.isLinkRightsDone(designationId, 3);
	        if(!lstSubmodule.isEmpty()){
	            for (Object[] subModule : lstSubmodule) {
	                tabRightsMap.put(subModule[0].toString(),subModule[1].toString());
	            }
	        }
	        //@Jaynam
            List<Object[]> lstQADetails = tenderCommonService.getTenderFields(tenderId, "isQuestionAnswer,questionAnswerStartDate,questionAnswerEndDate,createdBy");
	        //Change Request #22284 Start
	        boolean isQAOfficerAllowed = false;
            List<String> field = new ArrayList<String>();
			field.add("isQuestionAnswer");
			field.add("isQueAnsOfficer");
       		List<Object[]> lstClientConfigFields = commonService.getClientConfigurationFields(abcUtility.getSessionClientId(request),tblTender.getTblEventType().getEventTypeId(),field);
            if (lstClientConfigFields != null) {
                for (int i = 0; i < lstClientConfigFields.size(); i++) {
                	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isQueAnsOfficer") && Integer.parseInt(lstClientConfigFields.get(i)[4].toString()) == 1){
                		isQAOfficerAllowed=true;
                    }
                }
            }
            modelMap.addAttribute("isQAOfficerAllowed", isQAOfficerAllowed);
            //End
            boolean isQaAllowed=questionAnswerService.getIsQaAllowed(3,tenderId,abcUtility.getSessionUserId(request),abcUtility.getSessionClientId(request),abcUtility.getSessionUserTypeId(request),lstQADetails,abcUtility.getSessionUserDetailId(request),isQAOfficerAllowed,modelMap);
            modelMap.addAttribute("isQaAllowed", isQaAllowed);
            modelMap.addAttribute("createdBy", lstQADetails.size() > 0 ? lstQADetails.get(0)[3].toString():"");
          
            modelMap.addAttribute("tabRightsMap", tabRightsMap);
	        //System.out.println("tenderDetails = map value---->" +tabRightsMap.values());
            boolean isAPOAllow=false;
            boolean isPOAllow=false;
            boolean isPOPaymentTab = false;
            List<Object[]> listCMS=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
            if (listCMS != null) {
                for (int i = 0; i < listCMS.size(); i++) {
                	if(listCMS.get(i)[0].toString().equalsIgnoreCase("12")){
                		isAPOAllow=true;                		 
                    }
                	if(listCMS.get(i)[0].toString().equalsIgnoreCase("13")){
                		isPOAllow=true;                		 
                    }
                }
            }
            boolean isRCIClient = false;
            isRCIClient = commonService.isRCIClient(rciClientIds,abcUtility.getSessionClientId(request));
            if(isRCIClient){
            List<Object[]> list = invoiceDocServie.getPOListForPayment(tenderId, abcUtility.getSessionClientId(request), loginService.getCompanyId(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request)));
                    for (Object[] lst : list) {
                        Integer.parseInt(lst[0].toString());
                        if (Integer.parseInt(lst[1].toString()) == 1 || Integer.parseInt(lst[1].toString()) == 3) {
                            isPOPaymentTab = true;
                        }
                    }
            }
            //By Dipak For Contract Tab
            boolean isContractTab = false;
            List<Object[]> getBidderAckList=null;
            if(isAPOAllow && isPOAllow) {
            	getBidderAckList = commonService.getBidderAckFromPOList(tenderId,3);
            }else if(isPOAllow) {
            	getBidderAckList = commonService.getBidderAckFromPOList(tenderId,1);
            }
            //Used to check contract module is purchase or not.
            List<Object[]> getdefaultConfigList=clientService.getEventTypeIdForDefaultConfg(abcUtility.getSessionClientId(request),CONTRACT_MODULEID);
            if(getBidderAckList!=null && getBidderAckList.size()>0 && getdefaultConfigList!=null && getdefaultConfigList.size()>0)
            {
            	isContractTab=true;
            }
            //End
            
            modelMap.addAttribute("isRCIClient", isRCIClient);
            modelMap.addAttribute("isPOPaymentTab", isPOPaymentTab);
            modelMap.addAttribute("isAPOAllow",isAPOAllow);
            modelMap.addAttribute("isPOAllow",isPOAllow);
            modelMap.addAttribute("isNegotiationOfflineOnline",tblTender.getIsNegotiationAllowed());
            modelMap.addAttribute("isContractTab",isContractTab);
        }
        
       Integer [] fieldId={1119,1120,1121,1122,1123}; 
       List<Object[]> dataList = eventCreationService.getClientConfigurationFields(abcUtility.getSessionClientId(request),Integer.parseInt(modelMap.get("eventTypeId").toString()),Arrays.asList(fieldId));;
       modelMap.addAttribute("isReportTabVisible",true);
       SessionBean sessionBean=(SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
       if(dataList!=null && !dataList.isEmpty()) {
	       if(Integer.parseInt(dataList.get(0)[4].toString())==1 && !(sessionBean.isIsAbcUser())) {
	    	   if(!((abcUtility.getSessionUserId(request) == Integer.parseInt(modelMap.get("eventOfficerId").toString())) || (abcUtility.getSessionUserId(request) == Integer.parseInt(modelMap.get("assignUserId").toString())))) {
	    		   List<Object[]> list=tenderCommonService.getEnvelopeListFromMappedOfficer(tenderId, abcUtility.getSessionUserId(request));
	    		   if(list.isEmpty()) {
	    			   modelMap.addAttribute("isReportTabVisible",false);
	    		   }
	    	   }
	       }
       }
        
        Date submissionStartDate= tblTender.getSubmissionStartDate();
        Date currentDate= commonService.getServerDateTime();
        if(submissionStartDate !=  null){
        	modelMap.addAttribute("isCommunicationAllowed",currentDate.after(submissionStartDate));
        }
        boolean isUserisAutorizeToViewReports = true;
        if(clientBean.getIsAllowExternalUserToViewReport()==1){
    		isUserisAutorizeToViewReports = commonService.chkUserIsAurizedToViewReport(tenderId, tblTender.getTblEventType().getEventTypeId(), 1, abcUtility.getSessionUserId(request));
        }else{
        	isUserisAutorizeToViewReports = true;
        }
		modelMap.addAttribute("isUserisAutorizeToViewReports", isUserisAutorizeToViewReports);
	} catch (Exception e) {
	    exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), buyerEventDashboardLinkId, getEventDashboard, tenderId, 0);
	}
	return retVal;
    }

    /**
     * @param tenderId
     * @param tabId
     * @param request
     * @param modelMap
     * @return ajax jsp
     */
    @SuppressWarnings("unchecked")
    @RequestMapping(value = "/tenderdashboardcontent", method = RequestMethod.POST)
    public String tenderDashboardContent(@RequestParam("hdTenderId") int tenderId, @RequestParam("txtTabId") int tabId, @RequestParam(value="txtOptionalParam",required=false) Integer txtOptionalParam, HttpServletRequest request, ModelMap modelMap,HttpSession httpSession) {
    	String auditMsg = null;
    	int linkId = buyerEventDashboardLinkId;
    	 ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    	try {
    		int moduleId = 3; // Tender Module
    		if (abcUtility.getSessionUserId(request)!=0) {
    			 Integer [] fieldId={1119,1120,1121,1122,1123};
                 List<Object[]>  dataList =null;
    			Map<String, Object> dataMap = null;
    			List<Object[]> lstObj =null;
    			int isRegretUpdate = 0;
    			TblNegotiationSummary tbl=null;
    			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    			int isNegotiationAllow=0;
    			TblTender tblTender = tenderCommonService.getTenderById(tenderId);
    			isNegotiationAllow=negotiationService.getisNegotiationAllowedOfficcerSide(moduleId, tenderId,tblTender.getIsNegotiationAllowed());
    	        int committeId = tenderCommonService.getActiveCommittee(tenderId,1);
    			boolean isTOCConsentGiven = false;
				if(committeId!=0){
					isTOCConsentGiven = tenderCommonService.consentGivenOrNot(committeId);
					modelMap.addAttribute("TOCConsentGiven", isTOCConsentGiven);//TOC
				}
				
		        Date currentDate= commonService.getServerDateTime();
		        Date submitEndDate= tblTender.getSubmissionEndDate();
		        Date publishDate= tblTender.getPublishedOn();
		        boolean livetender=false;
		        if(submitEndDate!=null && publishDate!=null)
		        	 livetender=commonService.getServerDateTime().after(publishDate);
		        modelMap.addAttribute("tenderLive",livetender);
		        List<TblCorrigendum> tblvorrigendumobj=tenderCorrigendumService.getAllCorrigendumByTenderId(tenderId);
		        boolean corrigendumpublish=false;
		        if(!tblvorrigendumobj.isEmpty())
		        	corrigendumpublish=tblvorrigendumobj.get(0).getCstatus()==0?true:false;
		        modelMap.addAttribute("corrigendumpublish",corrigendumpublish);
				boolean isMVPVertical = clientService.isClientMVPVertical(clientBean != null ?  clientBean.getClientId() : 0 , 7);
		        modelMap.addAttribute("isMVPVertical",isMVPVertical);
		        modelMap.addAttribute("letestCstatusEncodeDecodeHistory", commonService.getLetestCstatusEncodeDecodeHistory(tenderId));
		        List<Object[]>  eventDetails = tenderCommonService.getTenderFields(tenderId, "isEncodedForNegotiation,isEncodedForTechnical");
		        modelMap.addAttribute("isEncodedForNegotiation",eventDetails.get(0)[0].toString());
		        modelMap.addAttribute("isEncodedForTechnical",eventDetails.get(0)[1].toString());
    			switch (tabId) {
    			case TAB_NIT_DOCUMENT:
    				auditMsg = postajaxTenderDashboardContentNIT;
    				Integer tenderMode = 0;
    				int docUploadSize=fileUploadService.getOfficerDocs(tenderId, abcUtility.getSessionClientId(request), 175, -3).size(); // here -3 for approve and pending docs only 
    				modelMap.addAttribute("objectId", tenderId);//For Document
    				modelMap.addAttribute("isDocUploadedForTender", docUploadSize > 0 ? "Y" : "N");
    				modelMap.addAttribute(LINK_ID, noticeDocumentUploadLinkId); //For Document
                                modelMap.addAttribute("brdLinkId", regenerateTenderBrd);
                                List<LinkedHashMap<String, Object>> lstTemplate=commonService.getBRDDetails(3,regenerateTenderBrd,tenderId,abcUtility.getSessionClientId(request),abcUtility.getCookieDateFormatConversionValue(request));
                                int isArchive=tenderCommonService.isEventArchive(tenderId);
                                modelMap.addAttribute("isArchive", isArchive);
                                modelMap.addAttribute("lstTemplate", lstTemplate);
    				modelMap.addAttribute("cStatusDoc", -1);//For Document
    				modelMap.addAttribute("isReadOnly", "Y");//For Document
    				modelMap.addAttribute(VALIDATE_TENDER_LINKS, (List<Map<String,Object>>) tenderCommonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, noticeSubModuleId, abcUtility.getSessionUserId(request)).get(RESULT_SET_1));
                                modelMap.addAttribute("pendingFileCountForBrd", commonService.getPendingFileCountForBrd(tenderId,regenerateTenderBrd));
                                List<Object[]> tenderDtl = tenderCommonService.getTenderFields(tenderId, "assignUserId,tenderId,publishedOn,cstatus,tenderMode");
                                if(tenderDtl!=null && !tenderDtl.isEmpty()){
                                    modelMap.addAttribute("assignUserId", tenderDtl.get(0)[0]);
                                    modelMap.addAttribute("cstatus", tenderDtl.get(0)[3]);
                                    tenderMode = (Integer) tenderDtl.get(0)[4];
                                    if((Integer.parseInt(tenderDtl.get(0)[3].toString()) == 1 || Integer.parseInt(tenderDtl.get(0)[3].toString()) == 3) && tenderCommonService.isEventArchive(tenderId) == 0){
                                    	List<Object[]> crrieDetails = tenderFormService.getTenderModeofCorriegendum(tenderId);
                                    	if(crrieDetails != null && !crrieDetails.isEmpty()){
                                    		tenderMode = Integer.parseInt(crrieDetails.get(0)[0].toString()); 
                                    	}
                                    }
                                }
                                modelMap.addAttribute("tenderModeNew",tenderMode);
                                modelMap.addAttribute("isEvaluationCompleteForAnyEnv", tenderCommonService.isEvaluationCompleteForAllEnv(tenderId));
                                modelMap.addAttribute("isBidderMappedForTender", tenderCommonService.isBiddermappedByTenderId(tenderId));
                                boolean isPCFEnable = true;
                                int clientId = abcUtility.getSessionClientId(request);
                                isPCFEnable = commonService.isRCIClient(rciClientIds,clientId) == true ? false : true;
                            	modelMap.addAttribute("isPCFEnable",isPCFEnable);
                            	modelMap.addAttribute("publishedDate",tenderDtl.get(0)[2]);
                            	modelMap.addAttribute("createAuctionMsg",getMessageCreateAuction(tenderId));
                            	modelMap.addAttribute("advancedformulaCount",tenderCommonService.advanceFormulaCount(tenderId));
                            	boolean isMilestoneCreated = commonService.checkMilestoneCreated(tenderId,3);
                            	modelMap.addAttribute("isMilestoneCreated", isMilestoneCreated);
                            	List<SelectItem> actionList = new ArrayList<SelectItem>();
                            	List<SelectItem> actionListForPrice = new ArrayList<SelectItem>();
                            	List<SelectItem> actionListFroBidderMasking = new ArrayList<SelectItem>();
                    			actionList.add(new SelectItem("Copy All the Item",1));
                    			actionList.add(new SelectItem("Copy Items in which  bid  has been received",0));
                    			actionListForPrice.add(new SelectItem("Set H1/L1 Price as Start Price for the auction",1));
                    			actionListForPrice.add(new SelectItem("Exclude H1/L1 Bidder",2));
                    			if((1 == tblTender.getIsEncodedName()) ||(1 ==tblTender.getIsEncodedForTechnical())) {
                    				actionListForPrice.add(new SelectItem("Bidder masking",3));
                    			}
                    			modelMap.addAttribute("actionList", actionList);
                    			modelMap.addAttribute("actionListForPrice", actionListForPrice);
                    			 boolean isPriceBidOpen = tenderCommonService.isPriceBidOpen(tenderId);
                                 if(isPriceBidOpen){	//Decryption is pending for approved bidder or if not evaluation done then still decryption is pending for TenderOpen table (0,1 case)
                                 	isPriceBidOpen = dynamicReportService.checkIsDecryptedAllApprovedBidderByTenderId(tenderId);
                                 }
                                 modelMap.addAttribute("isPriceBidOpen", isPriceBidOpen);
                                 List<TblPaymentITSDetail> isPaymentITSDetailAdded = commonService.getPaymentITSDetailByObjectId(tenderId,3,-1); //get all record 
                                 if(isPaymentITSDetailAdded!=null && !isPaymentITSDetailAdded.isEmpty()){
                                	 if(isPaymentITSDetailAdded.get(0).getIsActive()==1){
                                		 modelMap.addAttribute("isPaymentITSDetailSend",true);
                                	 }else{
                                		 modelMap.addAttribute("isPaymentITSDetailSend",false);
                                	 }
                                	 modelMap.addAttribute("isPaymentITSDetailAdded", true);
                                 }else{
                                	 modelMap.addAttribute("isPaymentITSDetailAdded",false);
                                 }	 
                             	 modelMap.addAttribute("bidderMapping", tblTender.getBidderMapping());
                             	 int eventAssignUserId = (Integer) modelMap.get("assignUserId");
          	          		  	 int eventDeptOfficer = (Integer) modelMap.get("eventOfficerId");
          	          		  	 modelMap.addAttribute("isTenderOwner", (abcUtility.getSessionUserId(request)==eventAssignUserId || abcUtility.getSessionUserId(request)==eventDeptOfficer)? true : false);
                             	 break;

    			case TAB_BIDDING_FORMS:
    				auditMsg = postajaxTenderDashboardContentBF;
    				modelMap.addAttribute(VALIDATE_TENDER_LINKS, (List<Map<String,Object>>) tenderCommonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, biddingFormsSubModuleId, abcUtility.getSessionUserId(request)).get(RESULT_SET_1));
    				List<Object[]> tenderDetail= tenderCommonService.getTenderFields(tenderId, "sorVariation,assignUserId,cstatus");
    				if(tenderDetail!=null && !tenderDetail.isEmpty()){
    					BigDecimal sorVariation = (BigDecimal)tenderDetail.get(0)[0];
    					int assignUserId=(Integer)tenderDetail.get(0)[1];
    					modelMap.addAttribute("isSorLinkDisplay",sorVariation.compareTo(new BigDecimal(0.00))==1 && assignUserId==abcUtility.getSessionUserId(request));
                                        modelMap.addAttribute("tenderStatus", (Integer)tenderDetail.get(0)[2]);
    				}
    				if(((Integer)tenderDetail.get(0)[2] == 0 || (Integer)tenderDetail.get(0)[2] == 3 || tenderCommonService.isCorrgendumPrepare(tenderId) == true) && tenderCommonService.isEventLive(tenderId) == 1){
    					modelMap.addAttribute("isCopyLinkShow", "true"); //Bug Id: #31913
    				}
    				Map<String, Object> map= tenderCommonService.getTenderBiddingForm(tenderId,createFormDocuLinkId);
    				List<LinkedHashMap<String, Object>> formList =(List<LinkedHashMap<String, Object>>) map.get(RESULT_SET_1);
    				int cancelCount = 0;
    				int priceBidFormCnt = 0;
					for(LinkedHashMap<String, Object> a : formList){
						if(Integer.parseInt(a.get("isPriceBid").toString()) == 1){
							if(Integer.parseInt(a.get("status").toString()) == 4){
								cancelCount++;
							}
							priceBidFormCnt++;
						}
					}
					modelMap.addAttribute("isAllPriceBidFormCancelled",cancelCount == priceBidFormCnt ? false : true);
    				modelMap.addAttribute("tenderFormLst",map.get(RESULT_SET_1));
    				modelMap.addAttribute("tenderEnvelopeLst", map.get("#result-set-2"));
    				modelMap.addAttribute("tenderFormStatusDetail",  map.get("#result-set-3"));
    				if("1".equals(modelMap.get("isMandatoryDocument").toString())){
    					modelMap.addAttribute("tblDocumentList",  map.get("#result-set-4"));
    				}
    				if("1".equals(modelMap.get("isWeightageEvaluationRequired").toString()) && "1".equals(modelMap.get("tenderResult").toString())){
    					modelMap.addAttribute("isWeightageEvaluationRequiredAndIsEvaluationStarted", tenderFormService.isEvaluationStartedForWeightageEvaluation(tenderId));
    				}
                    modelMap.addAttribute("isCorrigendumPending", tenderCorrigendumService.getPendingCorrigendumId(tenderId)!=0);
//                    modelMap.addAttribute("isPublishEnvLinkShown",tenderFormService.getStatusForPublishEnv(tenderId));
                    
                    modelMap.addAttribute("isFinalSubmissionDone", eventBidSubmissionService.isFinalSubmissionDone(tenderId)); //Bug Id: #29994
    				break;

    			case TAB_PREBID:
    				auditMsg = postajaxTenderDashboardContentPB;
    				int committeeId= 0;
    				List<Map<String,Object>> validateLinks = (List<Map<String,Object>>) tenderCommonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, 31, abcUtility.getSessionUserId(request)).get(RESULT_SET_1);
    				for(Map<String,Object> lst : validateLinks) {
    					if(lst.get(LINK_ID).equals(viewCommitteeLinkId) && lst.get("remark").equals("Success") && lst.get("cstatus").equals(1)) {
    						committeeId =  Integer.parseInt(lst.get("objectId").toString());
    					}
    					if(lst.get(LINK_ID).equals(deletePrebidDocLinkId) && !lst.get("remark").equals("Success")) {
    						modelMap.addAttribute("isReadOnly", "Y");                   
    					}
    				}
    				List<Object[]> lstPrebidObjArray = tenderCommonService.getTenderPrebidDetailByTenderId(tenderId);
    				List<Object[]> comitteeMembers = committeeFormationService.getAllCommitteeMemberDetails(committeeId);
    				modelMap.addAttribute("comitteeMembers",comitteeMembers);
    				modelMap.addAttribute("preBidObj", lstPrebidObjArray);
    				modelMap.addAttribute("currentDate", commonService.getServerDateTime());
    				modelMap.addAttribute(LINK_ID, uploadPrebidDocLinkId);
    				modelMap.addAttribute("objectId", tenderId);
    				modelMap.addAttribute("cStatusDocView", 1);                    
    				modelMap.addAttribute("cStatusDoc", 5);                    
    				modelMap.addAttribute("validateLinks", validateLinks);
    				break;

    			case TAB_CORRIGENDUM:
    				auditMsg = postajaxTenderDashboardContentCORRG;
    				List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "cstatus,submissionStartDate");
    		        if(tenderDetails!=null && !tenderDetails.isEmpty()){
    		        	int status=(Integer)tenderDetails.get(0)[0];
    		            modelMap.addAttribute("tenderStatus", status);
    		            Date submissionEndDate=(Date)modelMap.get("endDateOfsubmission");
    		            Date submissionStartDate=(Date)tenderDetails.get(0)[1];
    		            modelMap.addAttribute("isTenderArchive", (status==1 && currentDate.after(submissionEndDate)));//cstatus 1 and UTC date > Submission End Date
    		            modelMap.addAttribute("isTenderLive",(status==1 && currentDate.after(submissionStartDate) && currentDate.before(submissionEndDate)));//cstatus 1 and UTC date > Submission start Date
    		            TblCommittee tblCommittee = committeeFormationService.getPeningCommittee(tenderId,1,0,0);
    		            modelMap.addAttribute("isTOCChange",tblCommittee!=null ? true : false);
    		            tblCommittee = committeeFormationService.getPeningCommittee(tenderId,2,0,0);
    		            modelMap.addAttribute("isTECChange",tblCommittee!=null ? true : false);
    		            List<Integer> processIds = new ArrayList<Integer>();
    		            processIds.add(3);
    		            processIds.add(4);
    		            boolean isEnvelopePublished=tenderFormService.getTenderEnvelopeByOpeningDateStatus(tenderId, 1);
    		            modelMap.addAttribute("isBiddingFormChange",isEnvelopePublished ? tenderCorrigendumService.getPendingCorrigendumDetails(tenderId,processIds) : false);    		            
    		        }
    				modelMap.addAttribute(VALIDATE_TENDER_LINKS, (List<Map<String,Object>>) tenderCommonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, corrigendumSubModuleId, abcUtility.getSessionUserId(request)).get(RESULT_SET_1));
    				break;

    			case TAB_TENDER_OPENING:
    				auditMsg = postajaxTenderDashboardContentTO;
    				boolean isCommitteePublished=false;
    				if(txtOptionalParam!=null && (txtOptionalParam==1 || txtOptionalParam==2)){//Use for result sharing :txtOptionalParam==1 for Configure or Update, 2 for View
    					auditMsg=getResultSharingForOpening;
    					modelMap.addAttribute("txtOptionalParam", txtOptionalParam);
    					modelMap.addAttribute("isEvaluationReq",modelMap.get("isEvaluationRequired"));
    					modelMap.addAttribute("criteriaList",tenderCommonService.getResultSharingCriteria(true));
    					modelMap.addAttribute("envelopeList",tenderFormService.getTenderEnvelopeForPublish(tenderId,true));
    					List<Object[]> formDetalisList =tenderOpenService.getTenderFormForResultShare(tenderId);
    					modelMap.addAttribute("formDetalisList",formDetalisList);
    					modelMap.addAttribute("yesNoList", commonService.getYesNo());
    					List<Object[]> reportData=tenderOpenService.getShareReports(tenderId);
    					
    					List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(resultSharingEvent, clientBean.getClientId());
						if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty() && txtOptionalParam == 1) {
							int allowedSize = 0;
			          	    StringBuilder allowedExt = new StringBuilder();
		          			allowedSize = lstDocUploadConf.get(0).getMaxSize();
		          			allowedExt.append(lstDocUploadConf.get(0).getType());
		          			int index = allowedExt.toString().indexOf(",");
			          	    allowedExt.insert(index + 1, "*.");
			          	    while (index >= 0) {
			          			index = allowedExt.toString().indexOf(",", index + ",".length());
			          			allowedExt.insert(index + 1, "*.");
			          	    }

			          	    modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
			          	    modelMap.addAttribute("allowedExt", allowedExt);
			          	    modelMap.addAttribute("allowedSize", allowedSize/1024);
			          	    modelMap.addAttribute("tenderId", tenderId);
			          	    modelMap.addAttribute("cStatusDoc", 0); //office upload doc status pending
		          	    }
		          	    
		          	    if(reportData!=null && !reportData.isEmpty() && formDetalisList!=null && !formDetalisList.isEmpty()){
    						Object[] reportDetail=reportData.get(0);
    						modelMap.addAttribute("shareReportsData",reportDetail);

							List<Integer> objectIds = new ArrayList<Integer>();
					    	objectIds.add(tenderId);
							List<Integer> linkIds = new ArrayList<Integer>();
					    	linkIds.add(openConfigureResultSharingLinkId);
					    	linkIds.add(openEditResultSharingLinkId);
							List<Object[]> lstOfficerResultdocList =fileUploadService.getOfficerAllDocs(objectIds, abcUtility.getSessionClientId(request),  linkIds, 1);
	    					modelMap.put("lstOfficerResultdocList", lstOfficerResultdocList);
	    					modelMap.put("tenderId", tenderId);
	    					
    						if(txtOptionalParam==2){//In View Case show label field instead of input type
    							setViewDataForReportConfit(modelMap,reportDetail,tabId);
    							modelMap.addAttribute(OPTYPE,"view");
    							linkId=openViewResultSharingLinkId;
    						}else{
    							modelMap.addAttribute(OPTYPE,"update");
    							linkId=openEditResultSharingLinkId;
    							modelMap.addAttribute("linkId",linkId);
    						}

    						List<Object[]> formReportsData=tenderOpenService.getShareReportDetailsByReportId((Integer)reportData.get(0)[7]);
    						List<List<SelectItem>> formChartList= new ArrayList<List<SelectItem>>();
    						if(formReportsData!=null && !formReportsData.isEmpty() ){
    							for(Object[] formReport: formReportsData){
    								for(Object[] formDetail: formDetalisList){
    									if(formDetail[0].toString().equals(formReport[4].toString())){
    										List<SelectItem> criteriaList = new ArrayList<SelectItem>();
    										if((Integer)formReport[0] ==1){//Individual
    											criteriaList.add(new SelectItem(messageSource.getMessage("label_indivi_chrt", null, LocaleContextHolder.getLocale()),1,1));
    										}else {
    											criteriaList.add(new SelectItem(messageSource.getMessage("label_indivi_chrt", null, LocaleContextHolder.getLocale()),1));
    										} 
    										if((Integer)formReport[1] ==1){//Comparative
    											criteriaList.add(new SelectItem(messageSource.getMessage("label_cmp_chrt", null, LocaleContextHolder.getLocale()),2,1));
    										}else {
    											criteriaList.add(new SelectItem(messageSource.getMessage("label_cmp_chrt", null, LocaleContextHolder.getLocale()),2));
    										}
    										if((Integer)formReport[2] ==1){//document
    											criteriaList.add(new SelectItem(messageSource.getMessage("field_sup_doc",  null, LocaleContextHolder.getLocale()),3,1));
    										}else{
    											criteriaList.add(new SelectItem(messageSource.getMessage("field_sup_doc",  null, LocaleContextHolder.getLocale()),3));
    										}
    										formChartList.add(criteriaList);
    									}
    								}
    							}
    						}
    						modelMap.addAttribute("chartList", formChartList);
    						modelMap.addAttribute("formReportsData", formReportsData);
    					}else{
    						linkId=openConfigureResultSharingLinkId;
    						modelMap.addAttribute("chartList", tenderOpenService.getChartList());
    						modelMap.addAttribute("linkId",linkId);
    					}
    				}else{
    					
    					boolean isCorrigendumPrepare=false;
    					int isOpeningByCommittee=(Integer) modelMap.get("isOpeningByCommittee");
    					int eventTypeId = (Integer)modelMap.get("eventTypeId");
    					int showBidDetail =0;
    					if(isOpeningByCommittee==0){//Opening by committee = No
    						showBidDetail =  (Integer) tenderCommonService.getTenderField(tenderId, "showBidDetail");
    					}
						/*
						 * showBidDetail = 1 : For Before bid date & time
						 * showBidDetail = 2 : For After  bid date & time
						 */
    					modelMap.addAttribute("isBidDisplayBeforeOpening",showBidDetail==1);
    					if(isOpeningByCommittee==1){
    						List<Map<String,Object>> validateTenderLinks = (List<Map<String,Object>>) tenderCommonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, bidOpeningSubModuleId, abcUtility.getSessionUserId(request)).get(RESULT_SET_1);
    						modelMap.addAttribute(VALIDATE_TENDER_LINKS, validateTenderLinks);
    						for(Map<String,Object> lst : validateTenderLinks) {
    							if(lst.get(LINK_ID).equals(bidOpeningViewLinkId) && "1".equals(lst.get("cstatus").toString())) {
    								isCommitteePublished=true;
    							}
    						}
    						if(Integer.parseInt(modelMap.get("isWorkflowRequired").toString()) == 1 && Integer.parseInt(modelMap.get("envelopeType").toString()) == 2){
	    						/* Changes Added for Configure Date Workflow through ValidateContract Rule # 31144 */
	    						List<Map<String,Object>> validateContractLinks = (List<Map<String,Object>>) commonService.validateContractRules(abcUtility.getSessionClientId(request), tenderId, bidOpeningSubModuleId, abcUtility.getSessionUserId(request),0,eventTypeId).get("#result-set-1");
	    						modelMap.addAttribute("validateConfigureDateLinks", validateContractLinks);
    						}else{
    							modelMap.addAttribute("validateConfigureDateLinks", null);
    						}
//    						
	    						/* Changes Added for TOC Report  ValidateContract Rule # 19684 */
	    						List<Map<String,Object>> validateContractLinks = (List<Map<String,Object>>) commonService.validateContractRules(abcUtility.getSessionClientId(request), tenderId, bidOpeningSubModuleId, abcUtility.getSessionUserId(request),0,eventTypeId).get("#result-set-1");
	    						modelMap.addAttribute("validateTOCReportLinks", validateContractLinks);

    						
    						if(isCommitteePublished){
    							setDataForOpeningOrResultTab(tenderId,isOpeningByCommittee,modelMap,dataMap,abcUtility.getSessionUserId(request));
                                int isTwoStageOpening = (Integer) modelMap.get("isTwoStageOpening");
                                if(isTwoStageOpening==1){
                                	modelMap.addAttribute("isOpeningRemarksShow", getUserRoleStatus(tenderId,1,abcUtility.getSessionUserId(request),modelMap));
                                }
    						}
    						isCorrigendumPrepare=tenderCommonService.isCorrgendumPrepare(tenderId);
    						modelMap.addAttribute("isCorrigendumPrepare",isCorrigendumPrepare);
    						modelMap.addAttribute("isOpenedEnvelopeId",tenderOpenService.getOpenedEnvelopId(tenderId));
    					}else{
    						setDataForOpeningOrResultTab(tenderId,isOpeningByCommittee,modelMap,dataMap,abcUtility.getSessionUserId(request));
    						boolean isUserisAutorizeToViewReports = true;
    				        if(clientBean.getIsAllowExternalUserToViewReport()==1){
        						isUserisAutorizeToViewReports = commonService.chkUserIsAurizedToViewReport(tenderId, eventTypeId, 1, abcUtility.getSessionUserId(request)); 
    				        }else{
    				        	isUserisAutorizeToViewReports = true;
    				        }
    						modelMap.addAttribute("isUserisAutorizeToViewReports", isUserisAutorizeToViewReports);
    					}
    				}
					List<Object[]> firstEnvelopeDetails = tenderCommonService.getFirstEnvelopeId(tenderId);
					Byte isFirstEnvelopeOpened=0;
					Integer userId = 0,openingCommitteeId = 0,evalutaionCommitteeId = 0;
					boolean isCommitteeUser=false,isUserHasRights=false,showTocNoteLink=false,isCreator=false,memberCertExpired=true,memberCertRevoked=true;
					if(firstEnvelopeDetails!=null && !firstEnvelopeDetails.isEmpty())
					{
						for(Object[] selectedEnvelopeDetails : firstEnvelopeDetails)
						{
							isFirstEnvelopeOpened = (Byte)selectedEnvelopeDetails[1];
						}
					}
					userId = abcUtility.getSessionUserId(request);
					openingCommitteeId = tenderCommonService.getOpeningCommittee(tenderId,1);
					int latestCommitteeId = tenderFormService.getLatestCommitteeId(tenderId, 1);
					if(modelMap.get("openingDate")!=null){
						List<Object[]> userCertiStatus = committeeFormationService.getCommUserCertStatus(!isCommitteePublished ? latestCommitteeId : openingCommitteeId, clientBean.getIsDualCerti(),modelMap.get("openingDate").toString(),1);//1-individual TOC
						if(userCertiStatus!=null && !userCertiStatus.isEmpty()){
							for(Object[] obj : userCertiStatus){
								if(obj[4].toString().equals("true") && Integer.parseInt(obj[10].toString())==0){
									memberCertExpired = false;
								}
								if(obj[6].toString().equals("true") && Integer.parseInt(obj[10].toString())==0){
									memberCertRevoked = false;
								}
							}
						}
					}
					modelMap.addAttribute("memberCertExpired", memberCertExpired);
					modelMap.addAttribute("memberCertRevoked", memberCertRevoked);
					evalutaionCommitteeId = tenderCommonService.getOpeningCommittee(tenderId,2);
					List<Object[]> tocUsers= committeeFormationService.getCommitteeUserDetails(tenderId,openingCommitteeId);
					List<Object[]> tecUsers= committeeFormationService.getCommitteeUserDetails(tenderId,evalutaionCommitteeId);
					List<Object[]> tenderCreatorList = tenderCommonService.getTenderFields(tenderId, "tenderId,createdBy,officerId");
					if(tenderCreatorList!=null && !tenderCreatorList.isEmpty())
					{
						for(Object[] tenderCreator : tenderCreatorList)
						{
							Integer userDetailId = (Integer)tenderCreator[1];
							Integer officerId =  (Integer) tenderCreator[2];
							TblUserDetail userDetail = commonService.getUserDetailById(userDetailId);
							if(userDetail!=null)
							{
								if(userDetail.getTblUserLogin().getUserId()!=0)
								{
									if(userId.equals(userDetail.getTblUserLogin().getUserId()) || userId.equals(officerId))
									{
										isCreator = true;
										break;
									}	
								}
							}
						}
					}
					if(tocUsers!=null && !tocUsers.isEmpty())
					{
						for(Object[] committeeUser : tocUsers)
						{
							Integer selectedCommitteeUser=(Integer)committeeUser[3];
							if(selectedCommitteeUser.equals(userId))
							{
								isCommitteeUser=true;
								break;
							}
						}
					}
					if(!isCommitteeUser)
					{
						if(tecUsers!=null && !tecUsers.isEmpty())
						{
							for(Object[] committeeUser : tecUsers)
							{
								Integer selectedCommitteeUser=(Integer)committeeUser[3];
								if(selectedCommitteeUser.equals(userId))
								{
									isCommitteeUser=true;
									break;
								}
							}
						}
					}
					isUserHasRights = CommonUtility.showLink("2299");	
					int isTwoStageOpen = (Integer) modelMap.get("isTwoStageOpening");
					if(isTwoStageOpen==1)
					{
						if(isFirstEnvelopeOpened == 1)
						{
							if(isCommitteeUser || isCreator || isUserHasRights)
							{
								showTocNoteLink=true;
							}
						}
					}
				    modelMap.addAttribute("showTocNoteLink",showTocNoteLink);
				    modelMap.addAttribute("isUserHasRightsForBidWithdrawnLink",CommonUtility.showLink(bidWithdrawnCount));
    				modelMap.addAttribute("openingCommitteeId",tenderCommonService.getOpeningCommittee(tenderId,1));
    				int isOpeningYes = (Integer) modelMap.get("isOpeningByCommittee"),isBidWithdrawal = (Integer) tenderCommonService.getTenderField(tenderId, "isBidWithdrawal"),bidWithdrawalCnt = 0,isNoOfBidderShow = 0;
    				List<Object> customParameterFields = tenderFormService.getCustomParameterFieldValues(abcUtility.getSessionClientId(request), moduleId, (Integer) modelMap.get("eventTypeId"));
    				isNoOfBidderShow = customParameterFields != null && !customParameterFields.isEmpty() ? (Integer) customParameterFields.get(0) : 0;
    				boolean isShowBidWithdrawnCount = isOpeningYes == 1 && isBidWithdrawal == 1 && isNoOfBidderShow == 1 ? true : false;
//    				modelMap.addAttribute("isShowBidWithdrawnCount",isShowBidWithdrawnCount);
    				if(isShowBidWithdrawnCount){
    					bidWithdrawalCnt = tenderFormService.getBidWithdrawalCount(tenderId,(Integer)modelMap.get("isConsortiumAllowed"));
    					modelMap.addAttribute("bidWithdrawalCnt",bidWithdrawalCnt);
    				}
    			  boolean isShowBidRegrettedCount=false;
                  int bidRegrettedCnt;
                  int showWithdrawnBidCount=(Integer) tenderCommonService.getTenderField(tenderId, "showNoOfWithdrawnbid");
                  int showRegrettedBidCount=(Integer) tenderCommonService.getTenderField(tenderId, "showNoOfRegrettedbid");

                  if(showWithdrawnBidCount==0)
                	  isShowBidWithdrawnCount=false;
                  if(showWithdrawnBidCount!=0)
                  {
                      if(showWithdrawnBidCount==1)
                      {
                      isShowBidWithdrawnCount=true;
                      bidWithdrawalCnt = eventBidSubmissionService.getBidWithdrawalCount(tenderId,(Integer)modelMap.get("isConsortiumAllowed"));
                      modelMap.addAttribute("bidWithdrawalCnt",bidWithdrawalCnt);
                      }
                      else
                      {
                          Date submissionStartDate=(Date) tenderCommonService.getTenderField(tenderId, "submissionStartDate");
                          if(submissionStartDate != null && submissionStartDate.before(commonService.getServerDateTime())){
                              isShowBidWithdrawnCount=true;
                              bidWithdrawalCnt = tenderFormService.getBidWithdrawalCount(tenderId,(Integer)modelMap.get("isConsortiumAllowed"));
                              modelMap.addAttribute("bidWithdrawalCnt",bidWithdrawalCnt);
                          }
                      }
                  }
                  if(showRegrettedBidCount!=0)
                  {
                      if(showRegrettedBidCount==1)
                      {
                          isShowBidRegrettedCount=true;
                          bidRegrettedCnt = eventBidSubmissionService.getBidRegrettedCount(tenderId,(Integer)modelMap.get("isConsortiumAllowed"));
                          modelMap.addAttribute("bidRegrettedCnt",bidRegrettedCnt);
                      }
                      else
                      {
                          Date submissionStartDate=(Date) tenderCommonService.getTenderField(tenderId, "submissionStartDate");
                          if(submissionStartDate != null && submissionStartDate.before(commonService.getServerDateTime())){
                              isShowBidRegrettedCount=true;
                              bidRegrettedCnt = eventBidSubmissionService.getBidRegrettedCount(tenderId,(Integer)modelMap.get("isConsortiumAllowed"));
                              modelMap.addAttribute("bidRegrettedCnt",bidRegrettedCnt);
                          }
                      }
                  }
                  modelMap.addAttribute("isShowBidWithdrawnCount",isShowBidWithdrawnCount);
                  modelMap.addAttribute("isShowBidRegrettedCount",isShowBidRegrettedCount);
                  boolean isAnyEnvelopeOpened = false;
                  
                  if(tenderCommonService.isAnyEnvelopeOpened(tenderId)){
                	  isAnyEnvelopeOpened= true;
                  }
                  modelMap.addAttribute("isAnyEnvelopeOpened",isAnyEnvelopeOpened);
                  modelMap.addAttribute("letestCstatusEncodeDecodeHistory", commonService.getLetestCstatusEncodeDecodeHistory(tenderId));
                  modelMap.addAttribute("isEnvelopedOpened", commonService.isEnvelopedOpened(tenderId));
                  dataList = eventCreationService.getClientConfigurationFields(abcUtility.getSessionClientId(request),Integer.parseInt(modelMap.get("eventTypeId").toString()),Arrays.asList(fieldId));
                  if(dataList!=null && !dataList.isEmpty()) {
                	  modelMap.addAttribute("isEnvelopeWiseCommittee",Integer.parseInt(dataList.get(0)[4].toString()) == 0 ? false : true);
                  }else {
                	  modelMap.addAttribute("isEnvelopeWiseCommittee",false);
                  }
                  modelMap.addAttribute("isEDraw",tblTender.getIsEDraw());
                  
    			  break;

    			case TAB_EVALUATE_BID:
    				auditMsg = postajaxTenderDashboardContentEB;
    				if(txtOptionalParam!=null && (txtOptionalParam==1 || txtOptionalParam==2)){//Use for result sharing :txtOptionalParam==1 for Configure or Update 2 for View
    					auditMsg=getResultSharingForEvaluation;
    					modelMap.addAttribute("txtOptionalParam", txtOptionalParam);
    					modelMap.addAttribute("criteriaList",tenderCommonService.getResultSharingCriteria(false));
    					List<Object[]> reportData= tenderOpenService.getShareReports(tenderId);
    					if(reportData!=null && !reportData.isEmpty()){
    						Object[] reportDetail=reportData.get(0);
    						modelMap.addAttribute("shareReportsData",reportDetail);

    						if(txtOptionalParam==2){//In View Case show label field instead of input type
    							setViewDataForReportConfit(modelMap,reportDetail,tabId);
    							modelMap.addAttribute(OPTYPE,"view");
    							linkId=evalViewResultSharingLinkId;
    						}else{
    							modelMap.addAttribute(OPTYPE,"update");
    							linkId=evalEditResultSharingLinkId;
    						}
    					}else{
    						linkId=evalConfigureResultSharingLinkId;
    					}
    				}else{
    					int resultSharing=0;
    					int isOpeningByCommittee=(Integer) modelMap.get("isOpeningByCommittee");
    					isCommitteePublished=false;
    					int eventTypeId = (Integer)modelMap.get("eventTypeId");
    					int showBidDetail =0;
    					if(isOpeningByCommittee==0){//Opening by committee = No
    						showBidDetail= (Integer) tenderCommonService.getTenderField(tenderId, "showBidDetail");
    					}
						/*
						 * showBidDetail = 1 : For Before bid date & time
						 * showBidDetail = 2 : For After  bid date & time
						 */
    					modelMap.addAttribute("isBidDisplayBeforeOpening",showBidDetail==1/* && envelopeType==1*/);
    					if(isOpeningByCommittee == 1){// Tender only open by Committee member and Evaluation by Committee member  
    						List<Map<String,Object>> validateTenderLinks = (List<Map<String,Object>>) tenderCommonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, bidEvaluationSubModuleId, abcUtility.getSessionUserId(request)).get(RESULT_SET_1);
    						modelMap.addAttribute(VALIDATE_TENDER_LINKS, validateTenderLinks);
    						List<Map<String,Object>> validateContractLinks = (List<Map<String,Object>>) commonService.validateContractRules(abcUtility.getSessionClientId(request), tenderId, bidEvaluationSubModuleId, abcUtility.getSessionUserId(request),0,eventTypeId).get("#result-set-1");
    						modelMap.addAttribute("validateTECReportLinks", validateContractLinks);
    						for(Map<String,Object> lst : validateTenderLinks) {
    							if(lst.get(LINK_ID).equals(bidEvaluationViewLinkId) && "1".equals(lst.get("cstatus").toString())) {
    								isCommitteePublished=true;
    							}
    						}
    					}
    					int isTwoStageOpening = (Integer) modelMap.get("isTwoStageOpening");
    					int isTwoStageEvaluation = (Integer) modelMap.get("isTwoStageEvaluation");
    					if(isOpeningByCommittee==0 || isCommitteePublished){// Tender open without Committee member
    						setDataForEvaluationTab(tenderId,modelMap, resultSharing,isOpeningByCommittee, dataMap,abcUtility.getSessionUserDetailId(request),abcUtility.getSessionUserId(request));
                                                //List<Object[]> committeeDetails = committeeFormationService.getCommitteeDetails(tenderId, 2, 1);
                                             				modelMap.addAttribute("evaluationCommitteeId",tenderFormService.getCommitteeId(tenderId));
					                            List<Object[]> loadingFactorList = tenderFormService.getLoadingFactor(tenderId);
					                            modelMap.addAttribute("isPriceBidForm",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[0].toString()) : 0);
					                            modelMap.addAttribute("isEncNotRequire",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[1].toString()) : 0);
					                            modelMap.addAttribute("isLoadingFactor",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[2].toString()) : 0);
					                            modelMap.addAttribute("isAutoLoadingTotal",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[3].toString()) : 0);
					                            modelMap.addAttribute("isUnitRateAfterLoading",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[4].toString()) : 0);
					                            
					                            boolean isGenerateReport = true;
					                            int isLoadingFactor = !loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[2].toString()) : 0;
					                            if(isLoadingFactor!=0){
					                            	isGenerateReport = isGenerateReportForLoading(tenderId, modelMap);
					                            }
					                            modelMap.addAttribute("isGenerateReport", isGenerateReport);
    					}
                        if(isTwoStageEvaluation==1){
                        	modelMap.addAttribute("isEvaluationRemarksShow", getUserRoleStatus(tenderId,2,abcUtility.getSessionUserId(request),modelMap));
                        }
                        if(isTwoStageOpening==1 ){
                        	modelMap.addAttribute("isOpeningRemarksDone", getEvaluationStatus(tenderId,2,abcUtility.getSessionUserId(request)));
                        }
    				}
    				//Bug #23217 - start
    				int TECId = tenderCommonService.getActiveCommittee(tenderId,2);
    				if(TECId!=0){
    					modelMap.addAttribute("TECConsentGiven", tenderCommonService.consentGivenOrNot(TECId));//TEC
    				}
    				modelMap.addAttribute("tenderFormWeightagecount", tenderFormService.getTenderFormCount(tenderId));
    				modelMap.addAttribute("purchaseReqDetails",dynamicFieldService.getDynFieldListByLinkId(tendercreationlink,abcUtility.getSessionClientId(request),tenderId));
    				modelMap.addAttribute("estDetails",tenderCommonService.getTenderFields(tenderId, "tenderValue,decimalValueUpto"));
    				modelMap.addAttribute("isBidderEvaluationLinkShow",tenderFormService.checkIsEvaluationDone(tenderId,(Integer) modelMap.get("envelopeType")));
					modelMap.addAttribute("isBidderWeightageLinkShow",tenderFormService.checkIsWeightageStart(tenderId));
					modelMap.addAttribute("isWorkflowRejected",workflowService.getWorkFlowStatus(1181, tenderId, 4));
					int isEvaluationByCommittee = (Integer) modelMap.get("isEvaluationByCommittee"),isEvaluationRequired = (Integer) modelMap.get("isEvaluationRequired");
					if(isEvaluationByCommittee == 1 || (isEvaluationByCommittee == 0 && isEvaluationRequired == 1))
						setEvaluationStatus(tenderId,modelMap);
					
				      dataList = eventCreationService.getClientConfigurationFields(abcUtility.getSessionClientId(request),Integer.parseInt(modelMap.get("eventTypeId").toString()),Arrays.asList(fieldId));
	                  if(dataList!=null && !dataList.isEmpty()) {
	                	  modelMap.addAttribute("isEnvelopeWiseCommittee",Integer.parseInt(dataList.get(0)[4].toString()) == 0 ? false : true);
	                  }else {
	                	  modelMap.addAttribute("isEnvelopeWiseCommittee",false);
	                  }
    				break;

    			case TAB_REPORT:
                            int isDocfeesApplicable = 0;
                            boolean isEmdDocFeesConfigured= false;
                            boolean isItemWisePaymentReportApplicable = false;
                            Integer tenderResult = 0;
                            int isEMDApplicable = 0;
                            List<Object[]> l = tenderCommonService.getTenderFields(tenderId, "isDocfeesApplicable,isEMDApplicable");
                            if (!l.isEmpty()) {
                                Object[] tenderData = l.get(0);
                                isDocfeesApplicable = Integer.parseInt(tenderData[0].toString());
                                isEMDApplicable = Integer.parseInt(tenderData[1].toString());
                            }
                            modelMap.addAttribute("isDocfeesApplicable", isDocfeesApplicable);
                            modelMap.addAttribute("isEMDApplicable", isEMDApplicable);
    				List<TblDynReport> dynReportList=dynamicReportService.getDynReportByTenderId(tenderId);
    				modelMap.addAttribute("reportList",dynReportList);
    				//Object[] reportIdList=new Object[dynReportList.size()];
    				/*int cnt=0;
    				List<HashMap<String,Object>> conditionReportList=new ArrayList<HashMap<String,Object>>();
    				HashMap<String,Object> reportMap=new HashMap<String, Object>();
    				for(TblDynReport tblDynReport : dynReportList){
    					List<TblDynReportColumn> columnList=dynamicReportService.getDynReportColumnByReportId(tblDynReport.getReportId(), 2);
    					List<TblDynReportFormula> dynReportFormulas=dynamicReportService.getDynReportFormula(tblDynReport.getReportId(),0);
    					reportMap.put("isFormulaGenerated", columnList.size() != 0 && columnList.size() == dynReportFormulas.size() ? true : false);
    					conditionReportList.add(reportMap);
    					reportMap=new HashMap<String, Object>();
    				}
    				modelMap.addAttribute("conditionReportList", conditionReportList);*/
    				List<Object[]> data=dynamicReportService.isEvaluationDone(tenderId);
    				//List<TblDynReportColumn> columnList=dynamicReportService.getDynReportColumnByReportId(reportId, 1);
    				boolean isOpeningDateLapsed = false;
    				boolean isClosingDateLapsed = false;
    				//Bug #23251
    				Date closingDate=(Date)tenderCommonService.getTenderField(tenderId, "submissionEndDate");
    				if(closingDate != null && closingDate.before(commonService.getServerDateTime())){
    					isClosingDateLapsed = true;
    				}
    				modelMap.addAttribute("isClosingDateLapsed", isClosingDateLapsed);
    				//End
    				
    				Date openingDate=(Date)tenderCommonService.getTenderField(tenderId, "openingDate");
    				if(data != null && !data.isEmpty()){
    					modelMap.addAttribute("isEvaluationDone", data.get(0)[0]);
    				}
    				if(openingDate != null && openingDate.before(commonService.getServerDateTime())){
    					isOpeningDateLapsed = true;
    				}
    		                modelMap.addAttribute("isOpeningDateLapsed", isOpeningDateLapsed);
    				//Project Task #20848 - Added By Lipi shah
    				boolean isManualReportsConfig = tenderReportService.isManualReportsConfig(tenderId);
    				modelMap.addAttribute("isManualReportsConfig", isManualReportsConfig);
    				if(isManualReportsConfig){
    					boolean isReportExits = tenderReportService.isOverRuleReportExits(tenderId,1);
    					modelMap.addAttribute("isReportExits", isReportExits);
    					if(isReportExits){
    						modelMap.addAttribute("isReportPublished", tenderReportService.isOverRuleReportExits(tenderId,2));
    					}
    				}
    				//End
    				auditMsg = postajaxTenderDashboardContentREP;
                                modelMap.addAttribute("priceBidFormCount", tenderFormService.getPriceBidFormCount(tenderId));
                                
                                modelMap.addAttribute("evaluationCommitteeId",tenderFormService.getCommitteeId(tenderId));
                                List<Object[]> loadingFactorList = tenderFormService.getLoadingFactor(tenderId);
                                modelMap.addAttribute("isPriceBidForm",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[0].toString()) : 0);
                                modelMap.addAttribute("isEncNotRequire",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[1].toString()) : 0);
                                modelMap.addAttribute("isLoadingFactor",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[2].toString()) : 0);
                                modelMap.addAttribute("isAutoLoadingTotal",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[3].toString()) : 0);
                                modelMap.addAttribute("isUnitRateAfterLoading",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[4].toString()) : 0);
                                
                                boolean isGenerateReport = true;
                                int isLoadingFactor = !loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[2].toString()) : 0;
                                if(isLoadingFactor!=0){
                                	isGenerateReport = isGenerateReportForLoading(tenderId, modelMap);
                                	if(modelMap.get("cstatus") != null && (Integer)modelMap.get("cstatus") != 0){
    	                                modelMap.addAttribute("isManagementReport", isGenerateReport);
    	                                modelMap.addAttribute("isItemWiseL1ReportAfterLoading", isGenerateReport);
                                    }
                                }
                                modelMap.addAttribute("isGenerateReport", isGenerateReport);
                                
                                 isPriceBidOpen = tenderCommonService.isPriceBidOpen(tenderId);
                                if(isPriceBidOpen){	//Decryption is pending for approved bidder or if not evaluation done then still decryption is pending for TenderOpen table (0,1 case)
                                	isPriceBidOpen = dynamicReportService.checkIsDecryptedAllApprovedBidderByTenderId(tenderId);
                                	 int isReEvaluationReq = (Integer) modelMap.get("isReEvaluationReq");
                                     if(isReEvaluationReq == 1 && !isPriceBidOpen){
                                         Integer[] ctatus={0,1};
                                         List<TblTenderReevaluation> getTblTenderReevaluation = tenderFormService.getTblTenderEnvelopeRevaluationStatusByTenderId(tenderId,ctatus);
                                         if(getTblTenderReevaluation!=null && !getTblTenderReevaluation.isEmpty()){
                                        	 isPriceBidOpen = true;
                                         }
                                     }
                                }
                                modelMap.addAttribute("isPriceBidOpen", isPriceBidOpen);
                                /*int isItemwiseWinner=(Integer)tenderCommonService.getTenderField(tenderId, "isItemwiseWinner");
                                if(isItemwiseWinner==1){
                                	modelMap.addAttribute("isNegotiatedL1Created", negotiationService.isNegotiatedL1Created(tenderId));
                                }else if(isItemwiseWinner==0){*/ /*Block commented because of changes bug Id:#32202 (below method used for both itemwise and grandtotal wise)*/
                                	modelMap.addAttribute("isNegotiatedL1Created", negotiationService.isNegotiatedL1CreatedForGrandTotal(tenderId));
                                /*}*/ 
                                	List<Object[]> columnTypes = tenderCommonService.getTenderColumnType(tenderId);
                                	for(int i=0;i<columnTypes.size();i++)
                                	{
                                		Byte columnType =  (Byte)columnTypes.get(i)[0];
                                		if(columnType == 9 || columnType ==10 || columnType ==11 || columnType ==18 || columnType ==31  || columnType ==32)
                                		{
                                			isEmdDocFeesConfigured=true;
                                		}
                                	}
                                	
                    if(modelMap.get("tenderResult")!=null)
                    {
                    	tenderResult = (Integer) modelMap.get("tenderResult");
                    }
					
					List<Object[]> tenderData = tenderCommonService.getTenderFields(tenderId, "isOpeningByCommittee,isEvaluationByCommittee");
					boolean isReadyToOpen = false;					
					if(tenderData!=null || !tenderData.isEmpty())
					{
						Integer isOpeningByCommittee = (Integer) tenderData.get(0)[0];
						if(isOpeningByCommittee.equals(0))
	                    {
	                    	if(isOpeningDateLapsed)
	                        {
	                        	isReadyToOpen = true;
	                        }	
	                    }
	                    else
	                    {
	                    	if(tenderCommonService.isAnyEnvelopeOpened(tenderId))
	                    	{
	                    		isReadyToOpen = true;
	                    	}
	                    }
					}
                    
                    
                    if(tenderResult.equals(2) && isEmdDocFeesConfigured && isReadyToOpen)
                    {
                    	isItemWisePaymentReportApplicable = true;
                    }

                    modelMap.addAttribute("isItemWisePaymentReportApplicable",isItemWisePaymentReportApplicable);
                    if("1".equals(modelMap.get("isWeightageEvaluationRequired").toString()) && "1".equals(modelMap.get("tenderResult").toString())){
    					modelMap.addAttribute("isWeightageEvaluationRequiredAndIsEvaluationStarted", tenderFormService.isWeightageEvaluationAndEvaluationStarted(tenderId));
    				}
                    /* APO - Po changes start*/
                    boolean isDirectContractPO = false;
                    boolean isDirectContractAPO = false;
                    List<Object[]> listContract=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
    	            if (listContract != null) {
    	                for (int i = 0; i < listContract.size(); i++) {
    	                	if(listContract.get(i)[0].toString().equalsIgnoreCase("12")){
    	                		isDirectContractAPO=true;                		 
    	                    }
    	                	if(listContract.get(i)[0].toString().equalsIgnoreCase("13")){
    	                		isDirectContractPO=true;                		 
    	                    }
    	                }
    	            }
    	            boolean contractCreated = true;
    	            if(isDirectContractAPO){
    	            	TblAdvancePurchaseOrder tblAdvancePurchaseOrder =  commonService.getTblAdvancePurchaseOrderByObject(tenderId);
    	            	if(tblAdvancePurchaseOrder!=null){
    	            		contractCreated = false;
    	            	}
    	            }else if(isDirectContractPO){
    	            	TblPurchaseOrder tblPurchaseOrder =  commonService.getTblPurchaseOrderByObject(tenderId);
    	            	if(tblPurchaseOrder!=null){
    	            		contractCreated = false;
    	            	}
    	            }
    	            modelMap.addAttribute("contractCreated",contractCreated);
                     /*  end*/
    	            
    	            /*Start Changes Bug Id:30595*/
    	            if(dynReportList != null && !dynReportList.isEmpty()){
    	            	List<TblDynReportFormMap> formMapSize=dynamicReportService.getDynReporFormMaptById(dynReportList.get(0).getReportId());
    	            	modelMap.addAttribute("isFormMap", (formMapSize != null && !formMapSize.isEmpty()) ? true : false );
    	            }
    	            /*End Changes Bug Id:30595*/
    	            
    	            /*Start Changes CR Id:31157*/
    	            	tbl  = negotiationService.askForNegotiation(tenderId,negotiation_negotiation_process_invite_for_negotiation);
	    	            lstObj = tenderCommonService.getTenderFields(tenderId,"officerId");
	    				if(lstObj!=null && !lstObj.isEmpty()){
	    					modelMap.addAttribute("eventOfficerId", lstObj.get(0));
	    				}
						modelMap.addAttribute("loginUserId", abcUtility.getSessionUserId(request));
						if(tbl != null && !tbl.getUserDetailId().equals("") && tbl.getIsLetterPublished() != 0)
						{
							isRegretUpdate = 2; // view regret letter
						}else if(tbl != null && !tbl.getUserDetailId().equals(""))
						{
							isRegretUpdate = 1; // update regret letter
						}
	    				modelMap.addAttribute("isRegretUpdate",isRegretUpdate);
	    				modelMap.addAttribute("negotiationLinkId", negotiation_negotiation_process_invite_for_negotiation);
    				/*Start Changes CR Id: 	31157*/
	    				 clientBean = (ClientBean) httpSession.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	    				clientId= clientBean.getClientId();
	    		        boolean iscgClient = CommonUtility.isClientConditionExistInProperty(cgClient,clientId);
	    				if(iscgClient)
	    				{
	    				int isOpeningByCommittee=(Integer) modelMap.get("isOpeningByCommittee");
	    				int eventTypeId = (Integer)modelMap.get("eventTypeId");
	    				isCommitteePublished = false;
	    				boolean isCorrigendumPrepare=false;
	    				if(isOpeningByCommittee==1)
							{
	    						List<Map<String,Object>> validateTenderLinks = (List<Map<String,Object>>) tenderCommonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, bidOpeningSubModuleId, abcUtility.getSessionUserId(request)).get(RESULT_SET_1);
	    						modelMap.addAttribute(VALIDATE_TENDER_LINKS, validateTenderLinks);
	    						for(Map<String,Object> lst : validateTenderLinks) {
	    							if(lst.get(LINK_ID).equals(bidOpeningViewLinkId) && "1".equals(lst.get("cstatus").toString())) {
	    								isCommitteePublished=true;
	    							}
	    						}
	    						if(Integer.parseInt(modelMap.get("isWorkflowRequired").toString()) == 1 && Integer.parseInt(modelMap.get("envelopeType").toString()) == 2){
		    						/* Changes Added for Configure Date Workflow through ValidateContract Rule # 31144 */
		    						List<Map<String,Object>> validateContractLinks = (List<Map<String,Object>>) commonService.validateContractRules(abcUtility.getSessionClientId(request), tenderId, bidOpeningSubModuleId, abcUtility.getSessionUserId(request),0,eventTypeId).get("#result-set-1");
		    						modelMap.addAttribute("validateConfigureDateLinks", validateContractLinks);
	    						}else{
	    							modelMap.addAttribute("validateConfigureDateLinks", null);
	    						}
//	    						
		    						/* Changes Added for TOC Report  ValidateContract Rule # 19684 */
		    						List<Map<String,Object>> validateContractLinks = (List<Map<String,Object>>) commonService.validateContractRules(abcUtility.getSessionClientId(request), tenderId, bidOpeningSubModuleId, abcUtility.getSessionUserId(request),0,eventTypeId).get("#result-set-1");
		    						modelMap.addAttribute("validateTOCReportLinks", validateContractLinks);

	    						
	    						if(isCommitteePublished)
								{
	    							setDataForOpeningOrResultTab(tenderId,isOpeningByCommittee,modelMap,dataMap,abcUtility.getSessionUserId(request));
	                                int isTwoStageOpening = (Integer) modelMap.get("isTwoStageOpening");
	                                if(isTwoStageOpening==1)
									{
	                                	modelMap.addAttribute("isOpeningRemarksShow", getUserRoleStatus(tenderId,1,abcUtility.getSessionUserId(request),modelMap));
	                                }
	    						}
	    						isCorrigendumPrepare=tenderCommonService.isCorrgendumPrepare(tenderId);
	    						modelMap.addAttribute("isCorrigendumPrepare",isCorrigendumPrepare);
	    						modelMap.addAttribute("isOpenedEnvelopeId",tenderOpenService.getOpenedEnvelopId(tenderId));
	    					}
							else
							{
	    						setDataForOpeningOrResultTab(tenderId,isOpeningByCommittee,modelMap,dataMap,abcUtility.getSessionUserId(request));
	    					}
	    				}
	    			 modelMap.addAttribute("isTenderToAuctionArchived",commonService.checkAuctionIsArchivedAndNotCancelled(tenderId,0,modelMap));
	    			 modelMap.addAttribute("isRestofEventMoneyCofigured",tenderCommonService.isRestofEventCongfigured(tenderId, 0, 9, 2));
	    			
	    			 if(Integer.parseInt(modelMap.get("isSORApplicable").toString()) == 1 &&  Integer.parseInt(modelMap.get("tenderResult").toString()) == 2){
	    				   modelMap.addAttribute("isSORInserted",tenderFormService.compareTenderSorAndTenderFormCounts(tenderId));
	    			 }else{
	    				 modelMap.addAttribute("isSORInserted",1);
	    			 }
	    			 
    				break;
    			case TAB_LOI:
    			
    				List<Object[]> winningBiddersList = tenderCommonService.getLoiBidderList(tenderId, abcUtility.getSessionClientId(request));
    				//List<Object[]> loiStatus = commonService.getLoiStatus(eventId, companyId)
    				StringBuilder str = new StringBuilder();
    				str.append("-1,");
    				for(Object[] obj : winningBiddersList){
    					str.append(obj[1].toString());
    					str.append(",");
    					
    				}
    				str.append("-1");
    				lstObj = tenderCommonService.getLoiList(str.toString(), tenderId, abcUtility.getSessionClientId(request));
    				if(lstObj!=null && !lstObj.isEmpty()){
    					modelMap.addAttribute("winningBiddersList", lstObj);
    				}
    				break;
    			case TAB_PO:
    				// Show audit msg for po/wo while clicking po/wo tab.Bug #33053 By Jitendra.
					auditMsg = postajaxBiddingTenderDashboardContentPOEvent;
    				modelMap.addAttribute("objectId",tenderId);
    				modelMap.addAttribute("clientId",abcUtility.getSessionClientId(request));
	            	 modelMap.addAttribute("idfcClientId",idfcClientId);
    				int poType=Integer.valueOf(tenderCommonService.getTenderField(tenderId, "POType").toString());
    				modelMap.addAttribute("poType",poType); // 0-Offline,1-Online 
    				boolean isDirectPO=true;
		            List<Object[]> listCMS=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
		            if (listCMS != null) {
		                for (int i = 0; i < listCMS.size(); i++) {
		                	if(listCMS.get(i)[0].toString().equalsIgnoreCase("12")){
		                		isDirectPO=false;                		 
		                    }
		                }
		            }
    				modelMap.addAttribute("isDirectPO",isDirectPO);
    				if(isDirectPO){
    					boolean isReportCreatedForPO=false;
    		             List<SelectItem> reportList = new ArrayList<SelectItem>();
    		             long priceBidFormCount = tenderFormService.getPriceBidFormCount(tenderId);
                         if(priceBidFormCount > 0){
	    		             TblPurchaseOrder tblPurchaseOrder = commonService.getTblPurchaseOrderByObject(tenderId);
	                         if(tblPurchaseOrder!=null){
	                         	int reportId = tblPurchaseOrder.getTblDynReport().getReportId();
	                         	String reportName = dynamicReportService.getDynReportById(reportId).getReportName();
	                         	modelMap.addAttribute("reportId", reportId);
	                         	reportList.add(new SelectItem(reportName,reportId));
	                         	isReportCreatedForPO=true;
	                         }else{
		                         List<TblDynReport> dynReports = dynamicReportService.getDynReport(tenderId);
		                         if(dynReports!=null && !dynReports.isEmpty()){
		                        	 isReportCreatedForPO=true;
		                        	 reportList.add(new SelectItem("--Please Select--",0,0));
			                         for (TblDynReport tblDynReport : dynReports) {
			                         	reportList.add(new SelectItem(tblDynReport.getReportName(),tblDynReport.getReportId()));
									 }
			                         modelMap.addAttribute("reportId",httpSession.getAttribute("reportId"));
			                         modelMap.addAttribute("reportList", reportList);
		                         }
	                         }
                         }
                         modelMap.addAttribute("isReportCreated", isReportCreatedForPO);
                         modelMap.addAttribute("reportList", reportList);
    				}else{
    					modelMap.addAttribute("reportId",httpSession.getAttribute("reportId"));
    	            	List<Object[]> amendList=null;
    	            	List<Object[]> list=commonService.getAPOListByObjectIdForPO(tenderId,abcUtility.getSessionClientId(request),moduleId,poType);
    	            	modelMap.addAttribute("apoList",list);
//    	            	if(poType==1){
    	            		int reportId = 0;
    	            		if(list!=null && !list.isEmpty()){
    	            			reportId = (list.get(0)[6]!=null) ? Integer.parseInt(list.get(0)[6].toString()) : 0;
    	            			modelMap.addAttribute("reportId",reportId);
    	            		}
//    	            		list=commonService.getPOListByObjectId(tenderId, abcUtility.getSessionClientId(request), moduleId,0,poType,0,isDirectPO);
//    	            		list=commonService.getOnlinePOListByObjectId(reportId);
    	            		if(reportId!=0)
    	            			modelMap.addAttribute("validatePOLinks", commonService.validateContractRules(abcUtility.getSessionClientId(request), tenderId, poSubModuleId, abcUtility.getSessionUserId(request),reportId,3).get("#result-set-1"));
    	            		int assignUserId = (Integer) modelMap.get("assignUserId");
    	            		int officerId = (Integer) modelMap.get("eventOfficerId");
    	            		modelMap.addAttribute("isEventCreator",(commonService.isAbcUser(request)) ? true : (abcUtility.getSessionUserId(request)==assignUserId || abcUtility.getSessionUserId(request)==officerId)? true : false);
//    	            	}
//    	            	else
    	            		list=commonService.getPOListByObjectId(tenderId, abcUtility.getSessionClientId(request), moduleId,0,poType,0,isDirectPO);
    	            	modelMap.addAttribute("poList",list);
    	            	amendList = commonService.getAmendmentListById(poProcessId,tenderId,abcUtility.getSessionClientId(request),moduleId,poType);
    	            	modelMap.addAttribute("amendList",amendList);
    	            	List<Object[]> listAmendment = null;
    	            	listAmendment = commonService.getAmendmentCountDtls("PO",tenderId);
    	            	 Map<Integer,Integer> amendCountMap = new HashMap<Integer, Integer>();
    	 	            if(listAmendment!=null){
    	 	            	for(Object[] obj : listAmendment){
    	 	            		amendCountMap.put(Integer.parseInt(obj[0].toString()), Integer.parseInt(obj[1].toString()));
    	 	            	}
    	 	            }
    	 	            modelMap.addAttribute("amendCountMap",amendCountMap);
    	            	
    				}
    				modelMap.addAttribute("isEventCancelled",commonService.isEventCancelled(tenderId,170));
    				modelMap.addAttribute("isWorkflowRequired",(Integer) modelMap.get("isWorkflowRequired"));
					modelMap.addAttribute("tenderCstatus",(Integer) modelMap.get("cstatus"));
					modelMap.addAttribute("letestCstatusEncodeDecodeHistory", commonService.getLetestCstatusEncodeDecodeHistory(tenderId));
    				break;
    			case TAB_APO:
    						// Show audit msg for apo/loi while clicking apo/loi tab.Bug #33053 By Jitendra.
    						auditMsg = postajaxBiddingTenderDashboardContentAPOEvent;
    						modelMap.addAttribute("isEventCancelled",commonService.isEventCancelled(tenderId,170));
    						modelMap.addAttribute("isWorkflowRequired",(Integer) modelMap.get("isWorkflowRequired"));
    						modelMap.addAttribute("tenderCstatus",(Integer) modelMap.get("cstatus"));
                            List<SelectItem> reportList = new ArrayList<SelectItem>(); 
                            boolean isReportCreatedForAPO=false;
                            long priceBidFormCount = tenderFormService.getPriceBidFormCount(tenderId);
                            if(priceBidFormCount > 0){
	                            TblAdvancePurchaseOrder tblAdvancePurchaseOrder = commonService.getTblAdvancePurchaseOrderByObject(tenderId);
	                            if(tblAdvancePurchaseOrder!=null){
	                            	int reportId = tblAdvancePurchaseOrder.getTblDynReport().getReportId();
	                            	String reportName = dynamicReportService.getDynReportById(reportId).getReportName();
	                            	modelMap.addAttribute("reportId", reportId);
	                            	reportList.add(new SelectItem(reportName,reportId));
	                            	isReportCreatedForAPO=true;
	                            }else{
		                            List<TblDynReport> dynReports = dynamicReportService.getDynReport(tenderId);
		                            if(dynReports!=null && !dynReports.isEmpty()){
		                            	isReportCreatedForAPO=true;
			                           	 reportList.add(new SelectItem("--Please Select--",0,0));
			   	                         for (TblDynReport tblDynReport : dynReports) {
			   	                         	reportList.add(new SelectItem(tblDynReport.getReportName(),tblDynReport.getReportId()));
			   							 }
		                            }
	                            }
                            }
                            modelMap.addAttribute("isReportCreated", isReportCreatedForAPO);
                            modelMap.addAttribute("reportList", reportList);
                            modelMap.addAttribute("tenderId", tenderId);
                            modelMap.addAttribute("moduleId",moduleId);
    				break;
                        case TAB_PAYMENT:
                            modelMap.addAttribute("objectId", tenderId);
                            modelMap.addAttribute("userType", abcUtility.getSessionUserTypeId(request));
                            modelMap.addAttribute("lstInvoice", invoiceDocServie.getInvoiceList(tenderId, loginService.getCompanyId(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request)),abcUtility.getSessionClientId(request)));
                            break;
    			
    			case TAB_Negotiation:
    				// Show audit msg for negotiation while clicking negotiation tab.Bug #33053 By Jitendra.
    				auditMsg = postajaxBiddingTenderDashboardContentNEGEvent;	
    				if(tblTender.getIsNegotiationAllowed() == 1){	
	    				if (isNegotiationAllow == 1) {
							tbl  = negotiationService.askForNegotiation(tenderId,negotiation_negotiation_process_invite_for_negotiation);
							if(tbl == null || tbl.getCstatus() != 2){
								List<Object[]> committeeDisplayDetail =  negotiationService.getCommitteeNameAndConsentDetail(moduleId,tenderId,abcUtility.getSessionClientId(request));
			    				modelMap.addAttribute("committeeDisplayDetail", committeeDisplayDetail);
			    				int reportId = 0;
			    				if(modelMap.containsKey("tenderResult")){
			    					if(modelMap.get("tenderResult").equals(1)){
			    						reportId = grantotalNegotiationReportId;
			    				
			    					}else if(modelMap.get("tenderResult").equals(2)){
			    						reportId = itemwiseNegotiationReportId;
			    					}
			    				}
			    				
			    				int isNegotiationClosed=  negotiationService.isNegotiationClosed(tenderId,negotiation_negotiation_process_invite_for_negotiation);
			    				int isAllowCloseNegotiationLink =  negotiationService.isAllowCloseNegotiation(negotiation_negotiation_process_invite_for_negotiation,tenderId);
			    				modelMap.addAttribute("isAllowCloseNegotiationLink", isAllowCloseNegotiationLink);
			    				modelMap.addAttribute("negotiationStartChatLinkId", negotiation_officer_start_chat);
			    				modelMap.addAttribute("reportId", reportId);
			    				modelMap.addAttribute("grandOrItemWiseResult", modelMap.get("tenderResult"));
			    				modelMap.addAttribute("isNegotiationClosed",isNegotiationClosed);
			    				reportGeneratorService.getReportConfigDetails(reportId, modelMap);
			    			}
							lstObj = tenderCommonService.getTenderFields(tenderId,"officerId");
		    				if(lstObj!=null && !lstObj.isEmpty()){
		    					modelMap.addAttribute("eventOfficerId", lstObj.get(0));
		    				}
							modelMap.addAttribute("loginUserId", abcUtility.getSessionUserId(request));
							if(tbl != null && !tbl.getUserDetailId().equals("") && tbl.getIsLetterPublished() != 0)
							{
								isRegretUpdate = 2; // view regret letter
							}else if(tbl != null && !tbl.getUserDetailId().equals(""))
							{
								isRegretUpdate = 1; // update regret letter
							}
		    				modelMap.addAttribute("isRegretUpdate",isRegretUpdate);
		    				int flag=tbl != null ? tbl.getCstatus() : 0; //Start CR : 25886
		    				if(flag==0){
		    					 List<Object[]> loadingFactorListForNegotiationAllow = tenderFormService.getLoadingFactor(tenderId);
		                         modelMap.addAttribute("isPriceBidForm",!loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[0].toString()) : 0);
		                         modelMap.addAttribute("isEncNotRequire",!loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[1].toString()) : 0);
		                         modelMap.addAttribute("isLoadingFactor",!loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[2].toString()) : 0);
		                         modelMap.addAttribute("isAutoLoadingTotal",!loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[3].toString()) : 0);
		                         modelMap.addAttribute("isUnitRateAfterLoading",!loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[4].toString()) : 0);
		                         
		                         boolean isLoadingFactorForNegotiationAllow = true;
		                         int isLoadingFactorForNegotiation = !loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[2].toString()) : 0;
		                         if(isLoadingFactorForNegotiation!=0){
		                        	 isLoadingFactorForNegotiationAllow = isGenerateReportForLoading(tenderId, modelMap);
		                        }
		                         modelMap.addAttribute("isLoadingFactorForNegotiationAllow", isLoadingFactorForNegotiationAllow);
		                         
		                    }
		    				modelMap.addAttribute("askForNegotiation",flag);  //End CR : 25886
							modelMap.addAttribute("negotiationSummaryId", tbl != null ? tbl.getNegotiationSummaryId() : 0);
							modelMap.addAttribute("negotiationLinkId", negotiation_negotiation_process_invite_for_negotiation);
							if(tblTender.getIsFinalPriceSheetReq()==1){
								boolean isFinalPriceSheetSubmitted=negotiationService.isFinalPriceSheetSubmitted(tenderId);
								modelMap.addAttribute("isFinalPriceSheetSubmitted", isFinalPriceSheetSubmitted);
							}
							modelMap.addAttribute("isFinalPriceSheetReq", tblTender.getIsFinalPriceSheetReq());
					        modelMap.addAttribute("priceBidDataForNegotiation", negotiationService.priceBidDataForNegotiation(tenderId));
						}
    				}else if(tblTender.getIsNegotiationAllowed() == 2){
    					auditMsg=postajaxBiddingTenderDashboardContentNEGEvent;
    					if (isNegotiationAllow == 1) {
							tbl  = negotiationService.askForNegotiation(tenderId,negotiation_negotiation_process_invite_for_negotiation);
							modelMap.addAttribute("isL1H1Created", tenderCommonService.isL1H1Generated(tenderId));
							if(tbl == null || tbl.getCstatus() != 2){
								List<Object[]> committeeDisplayDetail =  negotiationService.getCommitteeNameAndConsentDetail(moduleId,tenderId,abcUtility.getSessionClientId(request));
			    				modelMap.addAttribute("committeeDisplayDetail", committeeDisplayDetail);
			    				lstObj = tenderCommonService.getTenderFields(tenderId,"officerId,assignUserId");
			    				if(lstObj!=null && !lstObj.isEmpty()){
			    					modelMap.addAttribute("eventOfficerId", lstObj.get(0)[0]);
			    					modelMap.addAttribute("assignUserId", lstObj.get(0)[1]);
			    				}
			    				if(null!=committeeDisplayDetail && !committeeDisplayDetail.isEmpty()){
			    					int isApproved=(Integer) committeeDisplayDetail.get(0)[12];
			    					if(isApproved==1 || isApproved==3)
			    						modelMap.addAttribute("iscommitteePublish",true);
			    					
			    					for (Object[] objects : committeeDisplayDetail) {
										if(objects[5]!=null && abcUtility.getSessionUserId(request)==(Integer)objects[8]){
											modelMap.addAttribute("isCommitteUser",true);
										}
			    					}
			    				}
							}
							
							modelMap.addAttribute("isNegotiationClosed",negotiationService.isNegotiationClosed(tenderId,negotiation_negotiation_process_invite_for_negotiation));
							int flag=tbl != null ? tbl.getCstatus() : 0; //Start CR : 25886
		    				if(flag==0){
		    					 List<Object[]> loadingFactorListForNegotiationAllow = tenderFormService.getLoadingFactor(tenderId);
		                         modelMap.addAttribute("isPriceBidForm",!loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[0].toString()) : 0);
		                         modelMap.addAttribute("isEncNotRequire",!loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[1].toString()) : 0);
		                         modelMap.addAttribute("isLoadingFactor",!loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[2].toString()) : 0);
		                         modelMap.addAttribute("isAutoLoadingTotal",!loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[3].toString()) : 0);
		                         modelMap.addAttribute("isUnitRateAfterLoading",!loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[4].toString()) : 0);
		                         
		                         boolean isLoadingFactorForNegotiationAllow = true;
		                         int isLoadingFactorForNegotiation = !loadingFactorListForNegotiationAllow.isEmpty() ? Integer.parseInt(loadingFactorListForNegotiationAllow.get(0)[2].toString()) : 0;
		                         if(isLoadingFactorForNegotiation!=0){
		                        	 isLoadingFactorForNegotiationAllow = isGenerateReportForLoading(tenderId, modelMap);
		                        }
		                         modelMap.addAttribute("isLoadingFactorForNegotiationAllow", isLoadingFactorForNegotiationAllow);
		                       }
		    				modelMap.addAttribute("askForNegotiation",flag);  //End CR : 25886
							modelMap.addAttribute("negotiationSummaryId", tbl != null ? tbl.getNegotiationSummaryId() : 0);
							modelMap.addAttribute("priceBidDataForNegotiation", negotiationService.priceBidDataForNegotiation(tenderId));
							modelMap.addAttribute("grandOrItemWiseResult", modelMap.get("tenderResult"));
							modelMap.addAttribute("negotiationLinkId", negotiation_negotiation_process_invite_for_negotiation);
							modelMap.addAttribute("isCheckRevisedDetail", negotiationService.isCheckRevisedDetail(tenderId, negotiation_negotiation_process_invite_for_negotiation));
						}
					}
    				modelMap.addAttribute("isNegotiatedL1Created", negotiationService.isNegotiatedL1CreatedForGrandTotal(tenderId));
    				modelMap.addAttribute(VALIDATE_TENDER_LINKS, (List<Map<String,Object>>) tenderCommonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, negotiation_submoduleId, abcUtility.getSessionUserId(request)).get(RESULT_SET_1));
    				dataMap = tenderOpenService.getTenderOpeningDetails(tenderId,1);
    		    	if (dataMap != null && !dataMap.isEmpty()) {
    		            TenderOpenProcessDTBean openProcessDTBean = new TenderOpenProcessDTBean();
    		            openProcessDTBean.setEnvelopeList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-2"));
    		    		openProcessDTBean.setVerifyList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-4"));
    		    		modelMap.addAttribute("openProcessDTBean", openProcessDTBean);
    		    	}
    				break;
    			case TAB_COMMUNICATION:
    				List<Integer> list = new ArrayList<Integer>();
    				list.add(3);
    				list.add(6);
    				List<SelectItem> selSubModule = getSubModulSelectItemForCommunication(abcUtility.getSessionClientId(request),list,abcUtility.getSessionUserTypeId(request));
    				modelMap.addAttribute("selSubModule", selSubModule);
    				modelMap.addAttribute("eventId", tenderId);
    				modelMap.addAttribute("createdBy", abcUtility.getSessionUserId(request));
    				modelMap.addAttribute("moduleType", 4);
    				commonService.commontenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    				List<SelectItem> selBidder =  getBidderSelectItem(tenderId,(Integer)modelMap.get("tenderMode"));
    				modelMap.addAttribute("selBidder", selBidder);
    				modelMap.addAttribute("userType", abcUtility.getSessionUserTypeId(request));
    				if(abcUtility.getSessionUserTypeId(request) == 1){
    					modelMap.addAttribute("questions", questionAnswerService.getQuestionsForOfficer(tenderId));
    				}else{
    					modelMap.addAttribute("questions", questionAnswerService.getQuestionsForBidder(tenderId,abcUtility.getSessionUserId(request)));
    				}
    				
    				int linkid = 1182;
    				clientId = abcUtility.getSessionClientId(request);
    				List<Object[]> eventIdlist = commonService.getEventIdFromLinkId(linkid);
    	            int eventIdNew = 0;
    				if(eventIdlist!=null && !eventIdlist.isEmpty()){
    					eventIdNew = Integer.parseInt(eventIdlist.get(0)[1].toString());
    	            }
    	            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventIdNew, clientId);
    	            int allowedSize = 0;
    	            StringBuilder allowedExt = new StringBuilder();
    	            if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
    	                allowedSize = lstDocUploadConf.get(0).getMaxSize();
    	                allowedExt.append(lstDocUploadConf.get(0).getType());
    	                modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
    	            }
    	            int index = allowedExt.toString().indexOf(",");
    	            allowedExt.insert(index + 1, "*.");
    	            while (index >= 0) {
    	                index = allowedExt.toString().indexOf(",", index + ",".length());
    	                allowedExt.insert(index + 1, "*.");
    	            }
    	            modelMap.addAttribute("linkId", linkid);
    	            modelMap.addAttribute("allowedExt", allowedExt);
    	            modelMap.addAttribute("allowedSize", allowedSize/1024);
    	            modelMap.addAttribute("cStatusDoc", 0);
    	            modelMap.addAttribute("cStatusDocView", 0); 
    	            modelMap.addAttribute("showCreatedBy", 0); 
    	         //   modelMap.addAttribute("isReadonly",1);
    	            modelMap.addAttribute("objectIdNew",0);
    	            
    	            
    	            modelMap.addAttribute("cStatusDoc", 5);
    	            modelMap.addAttribute("cStatusDocView", 1);
    	            modelMap.addAttribute("allowFileExist","Y");
    				break;
    			case TAB_CONTRACT:
    				boolean isAPOAllow=false;
    				boolean isPOAllow=false;
    				auditMsg = postajaxBiddingTenderDashboardContract;
    				List<Object[]> listCMS1=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
    	            if (listCMS1!= null) {
    	                for (int i = 0; i < listCMS1.size(); i++) {
    	                	if(listCMS1.get(i)[0].toString().equalsIgnoreCase("12")){
    	                		isAPOAllow=true;                		 
    	                    }
    	                	if(listCMS1.get(i)[0].toString().equalsIgnoreCase("13")){
    	                		isPOAllow=true;                		 
    	                    }
    	                }
    	            }
    	            List<Object[]> lstAckBidderFromPO =null;
    	            if(isAPOAllow && isPOAllow) {
    	            	lstAckBidderFromPO = commonService.getBidderAckFromPOList(tenderId,3);
    	            }else if(isPOAllow) {
    	            	lstAckBidderFromPO = commonService.getBidderAckFromPOList(tenderId,1);
    	            }
    				modelMap.addAttribute("lstAckBidderFromPO",lstAckBidderFromPO);
    				break;
    			
    			}
    					modelMap.addAttribute("tabId", tabId);
                        modelMap.addAttribute("objectId", tenderId);
                        modelMap.addAttribute("moduleId", moduleId);
                        modelMap.addAttribute("isNegotiationAllow",isNegotiationAllow);
                        modelMap.put("loginUserid",abcUtility.getSessionUserId(request));
                        modelMap.put("isRebateAvail", negotiationService.isEventAvailInTblNegotiationSummary(tenderId));
                        modelMap.addAttribute("isNegotiationOfflineOnline",tblTender.getIsNegotiationAllowed());
                        modelMap.addAttribute("isTenderOpened",tblTender.getEvaluationstatus());
                        modelMap.addAttribute("isUploadRefDocAllowed",tblTender.getIsUploadRefDocAllowed());
    					modelMap.addAttribute("letestCstatusEncodeDecodeHistory", commonService.getLetestCstatusEncodeDecodeHistory(tenderId));
    					modelMap.addAttribute("isEncodedForPrice",tblTender.getIsEncodedName());
    					modelMap.addAttribute("isEncodedForTechnical",tblTender.getIsEncodedForTechnical());
    					modelMap.addAttribute("tenderMode",tblTender.getTenderMode());
    					modelMap.addAttribute("isTenderArchive",eventBidSubmissionService.isTenderArchive(tenderId));
    				   
    		} else {
    			modelMap.addAttribute("sessionExpired", true);
    		}
    	} catch (Exception e) {
    		exceptionHandlerService.writeLog(e);
    	} finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditMsg, tenderId, 0);
    	}
    	return "/etender/buyer/TenderDashboardContent";
    }
    
    public String getMessageCreateAuction(int tenderId) throws Exception{
    	String response = "msg_bidder_finalsubmission_mapped_confirm";
    	
    	int lastEvaluatedEnvelopeId = 0;
    	int preLastEvaluatedEnvelopeId = 0;
    	int lastEvaluatedEnvelopeEvaluationCount = 0;
    	int preLastEvaluatedEnvelopeEvaluationCount = 0;
    	
    	TblTenderEnvelope tblTenderEnvelope = tenderFormService.getTblTenderEnvelopeByTenderId(tenderId);
    	if(tblTenderEnvelope != null){
    		lastEvaluatedEnvelopeId = tblTenderEnvelope.getEnvelopeId();
    	}
    	if(lastEvaluatedEnvelopeId != 0){
    		TblTenderEnvelope tblTenderEnvelope1 = tenderFormService.getTblTenderEnvelopeByTenderIdAndEnvelopeId(tenderId,lastEvaluatedEnvelopeId);
    		if(tblTenderEnvelope1 != null){
    			preLastEvaluatedEnvelopeId = tblTenderEnvelope1.getEnvelopeId();
        	}
    		List<Object> list = tenderFormService.getTblBidderApprovalDetailCountByTenderId(tenderId,lastEvaluatedEnvelopeId);
    		if(list != null && list.size() > 0){
    			lastEvaluatedEnvelopeEvaluationCount = Integer.parseInt(list.get(0).toString());
    		}
    		List<Object> list1 = tenderFormService.getTblFinalSubmissionCountByTenderId(tenderId);
    		if(list1 != null && list1.size() > 0){
    			preLastEvaluatedEnvelopeEvaluationCount = Integer.parseInt(list1.get(0).toString());
    		}
    		if(preLastEvaluatedEnvelopeId != 0){
    			response = "msg_qualified_bidder_mapped_confirm";
    		}else{
    			if(lastEvaluatedEnvelopeEvaluationCount == preLastEvaluatedEnvelopeEvaluationCount){
        			response = "msg_qualified_bidder_mapped_confirm";
        		}
    		}
    		
    	}
    	return response;
    }
    
    /** For CR #24688 By Keval soni **/
    /**
     @author keval.soni
     @param tenderId
     @param modelMap
     */
    private void setEvaluationStatus(int tenderId,ModelMap modelMap) throws Exception{
    	List<Object[]> envList = tenderFormService.getAllEnvelopeTypeByTenderId(tenderId);
    	long finalSubmissionCnt = 0;
    	if((Integer)modelMap.get("isConsortiumAllowed") !=1){
    	 finalSubmissionCnt = tenderFormService.getCountofFinalSubmission(tenderId);
    	}
    	List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isTwoStageEvaluation,envelopeType,isReEvaluationReq,isWeightageEvaluationRequired");
   		int isTwoStageEvaluation = 0,envelopType = 0, isReEvaluationReq=0,isWeightageEvaluationRequired = 0;
   		if(tenderDetails != null && !tenderDetails.isEmpty()){
   			isTwoStageEvaluation = Integer.parseInt(tenderDetails.get(0)[0].toString());
   			envelopType = Integer.parseInt(tenderDetails.get(0)[1].toString());
   			isReEvaluationReq = Integer.parseInt(tenderDetails.get(0)[2].toString());
   			isWeightageEvaluationRequired = Integer.parseInt(tenderDetails.get(0)[3].toString());
   		}
   		Map<Integer,String> evaluationStatusMap = new HashMap<Integer, String>();
   		Map<Integer,String> reEvaluationStatusMap = new HashMap<Integer, String>();
                Map<Integer,Integer> isReEvaluationReqMap = new HashMap<Integer, Integer>();
   		int evaluationDoneEnv = 0,previousEnvId = 0,pervEvaluationDoneEnv = -1;
   		if((Integer)modelMap.get("isConsortiumAllowed") !=1){
		 for(Object[] tenderEnvelop : envList){
			 if(pervEvaluationDoneEnv != 0 && finalSubmissionCnt != 0){
				evaluationDoneEnv = tenderFormService.isEnvelopeWiseEvaluationDone(tenderId,(Integer)tenderEnvelop[0],finalSubmissionCnt,envelopType == 2 ? previousEnvId : -1);
			 }
			 else{
				evaluationDoneEnv = 0;
			 }
			 List<Object> lstEvaluationDateAndTime =eventCreationService.getOfficerEvaluationDateAndTime(tenderId,(Integer)tenderEnvelop[0]);
			 if(isTwoStageEvaluation==1){
				 	evaluationStatusMap.put((Integer)tenderEnvelop[0], (lstEvaluationDateAndTime!=null && !lstEvaluationDateAndTime.isEmpty())?lstEvaluationDateAndTime.get(0).toString():"Pending");	 
			 }else{
				 	evaluationStatusMap.put((Integer)tenderEnvelop[0], evaluationDoneEnv == 0 ? "Pending" : (lstEvaluationDateAndTime!=null && !lstEvaluationDateAndTime.isEmpty())?lstEvaluationDateAndTime.get(0).toString():"");
			 }
			 
			 previousEnvId = (Integer)tenderEnvelop[0];
			 pervEvaluationDoneEnv = evaluationDoneEnv;
		 }
   		}
   		else if((Integer)modelMap.get("isConsortiumAllowed") == 1){
   			for(Object[] tenderEnvelop : envList){
   			 finalSubmissionCnt =  tenderFormService.getCountofFinalSubmissionWithConsortiumEnvelopeWise(tenderId,(Integer)tenderEnvelop[0],(Integer)tenderEnvelop[1]);
   			 if(pervEvaluationDoneEnv != 0 && finalSubmissionCnt != 0){	
   			     evaluationDoneEnv = tenderFormService.isEnvelopeWiseEvaluationDoneWithConsortium(tenderId,(Integer)tenderEnvelop[0],finalSubmissionCnt,(Integer)tenderEnvelop[1]); 
   			 }else{
   				evaluationDoneEnv = 0;
   			 }
   			 List<Object> lstEvaluationDateAndTime =eventCreationService.getOfficerEvaluationDateAndTime(tenderId,(Integer)tenderEnvelop[0]);
   			 evaluationStatusMap.put((Integer)tenderEnvelop[0], evaluationDoneEnv == 0 ? "Pending" : (lstEvaluationDateAndTime!=null && !lstEvaluationDateAndTime.isEmpty())?lstEvaluationDateAndTime.get(0).toString():"");
   			 previousEnvId = (Integer)tenderEnvelop[0];
   			 pervEvaluationDoneEnv = evaluationDoneEnv;
   		 }
   		}
		 previousEnvId = 0;
		 Map <Integer,Boolean> bidderweightageEnvelopewise = new HashMap<Integer,Boolean>(); 
		 if(isReEvaluationReq==1){
			 for(Object[] tenderEnvelop : envList){
				 boolean bidderweightageCheck =  false;
				 Integer[] ctatus={1};
	       		List<TblTenderReevaluation> tblTenderreevaluation = tenderFormService.getTblTenderRevaluationStatusByEnvelopeId(tenderId,(Integer)tenderEnvelop[0], ctatus);
				 List<Object> lstEvaluationDateAndTime =eventCreationService.getOfficerEvaluationDateAndTime(tenderId,(Integer)tenderEnvelop[0]);
				 if(tblTenderreevaluation!=null && !tblTenderreevaluation.isEmpty() ){
					 reEvaluationStatusMap.put((Integer)tenderEnvelop[0], (lstEvaluationDateAndTime!=null && !lstEvaluationDateAndTime.isEmpty())?lstEvaluationDateAndTime.get(0).toString():"");
		       		}
				 if(isWeightageEvaluationRequired==1 && (Integer)tenderEnvelop[0] != previousEnvId && previousEnvId != 0){
					 bidderweightageCheck = tenderFormService.getBidderWeightageScoreOfApprovedBidderId(tenderId,(Integer)tenderEnvelop[0],previousEnvId);
					 if(bidderweightageCheck){
						 bidderweightageCheck=true;
						 bidderweightageEnvelopewise.put((Integer)tenderEnvelop[0], bidderweightageCheck);
					 }else{
						 bidderweightageEnvelopewise.put((Integer)tenderEnvelop[0], false);
					 }
				 }else{
					 bidderweightageEnvelopewise.put((Integer)tenderEnvelop[0], false);
				 }
				 previousEnvId = (Integer)tenderEnvelop[0];
			 }
			 modelMap.addAttribute("bidderWeightageNotConfigured", bidderweightageEnvelopewise);
			 modelMap.addAttribute("reEvaluationStatusMap", reEvaluationStatusMap);
                        Integer[] ctatus={0,1};
                        List<TblTenderReevaluation> getTblTenderReevaluation = tenderFormService.getTblTenderEnvelopeRevaluationStatusByTenderId(tenderId,ctatus);
                        if(getTblTenderReevaluation!=null && !getTblTenderReevaluation.isEmpty()){
                           for(TblTenderReevaluation data : getTblTenderReevaluation){
                                isReEvaluationReqMap.put(data.getTblTenderEnvelope().getEnvelopeId(), data.getCstatus());
                           }
                           modelMap.addAttribute("isReEvaluationReqMap", isReEvaluationReqMap); //key=envelopeId, value=cstatus
                        }
		 }
   		modelMap.addAttribute("evaluationStatusMap", evaluationStatusMap);
    }
    private List<SelectItem> getBidderSelectItem(int eventId,int tenderMode) throws Exception{
		List<SelectItem> selBidder = new ArrayList<SelectItem>(); 
		if(tenderMode == 1){
			List<Object[]> TblTenderBidConfirmationByTenderId = questionAnswerService.getTblTenderBidConfirmationByTenderId(eventId);
			for (Object[] objects : TblTenderBidConfirmationByTenderId) {
				selBidder.add(new SelectItem(objects[1],objects[0]));	
			}
		}else {
			List<Object[]> TblTenderBidConfirmationByTenderId = questionAnswerService.getTblTenderBidderMapByTenderId(eventId);
			for (Object[] objects : TblTenderBidConfirmationByTenderId) {
				selBidder.add(new SelectItem(objects[1],objects[0]));	
			}
		}
		return selBidder;
	}
    private List<SelectItem> getSubModulSelectItemForCommunication(int clientId, List<Integer> moduleType,int userType) throws Exception {
		List<SelectItem> selSubModule = new ArrayList<SelectItem>(); // SubmoduleType
		List<Object[]> subModuleListData = questionAnswerService.getSubModule(clientId,moduleType);
     	for (Object[] objects : subModuleListData) {
     		/*if(userType == 2) {
     			if(Integer.parseInt(objects[0].toString()) != prebidMeetingId) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
     			if(Integer.parseInt(objects[0].toString()) != 60) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     		if(Integer.parseInt(objects[0].toString()) != 61) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     	} else {
	     		if(Integer.parseInt(objects[0].toString()) != prebidMeetingId) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     	}*/
     		if(Integer.parseInt(objects[0].toString()) != 31) {
     			selSubModule.add(new SelectItem(objects[1],objects[0]));
     		}
		}
		return selSubModule;
	}

    @SuppressWarnings("unchecked")
    private void setDataForOpeningOrResultTab(int tenderId,int isOpeningByCommittee,ModelMap modelMap, Map<String, Object> dataMap,int userDetailId) throws Exception{
    	int resultSharing=0;
        int formId=0;
        List<Object[]> lstEnvelope = tenderFormService.getTenderEnvelopeList(tenderId);
        Map<Integer, Boolean> isBidderBidWithLoadingFactor = new HashMap<Integer, Boolean>();
        Map<Integer, Boolean> configCalLoadingMap = new HashMap<Integer, Boolean>();
        boolean isCommitteePublished = tenderFormService.getPendingCommittee(tenderId,2,0);
        int openedEnvCount = 0;
        boolean isTOCConsentGivenForAllEnvelope = true;
        for (int i=0;i<lstEnvelope.size();i++) {
            int timeLapsed = Integer.parseInt(lstEnvelope.get(i)[4].toString());
            int envelopeId = Integer.parseInt(lstEnvelope.get(i)[2].toString());
            int envelopeOpened = Integer.parseInt(lstEnvelope.get(i)[3].toString());
            if(envelopeOpened==1){
          	  modelMap.addAttribute("envelopeIdTOCReport", envelopeId);
            }
            if(envelopeOpened==0){
            	isTOCConsentGivenForAllEnvelope = false;
            	  modelMap.addAttribute("isTOCConsentGivenForAllEnvelope", isTOCConsentGivenForAllEnvelope );
              }
            int minOpeningMember = Integer.parseInt(lstEnvelope.get(i)[6].toString());
            int minEvaluatedMember = Integer.parseInt(lstEnvelope.get(i)[7].toString());
            if(timeLapsed==1){
                if(minOpeningMember==0 && envelopeOpened==0 && minEvaluatedMember==0){
                    //case for auto opening as well as auto evaluation
                    tenderFormService.autoOpeningEvaluation(tenderId,envelopeId,userDetailId,"fromAuto",isCommitteePublished);
                }else if(minOpeningMember==0 && minEvaluatedMember!=0){
                    //case for auto opening and manual evaluation
                    tenderFormService.autoOpeningEvaluation(tenderId,envelopeId,userDetailId,"fromOpeningTab",isCommitteePublished);
                }
                openedEnvCount++;
            }
        }
        
        //If:- When evaluation & OpeningCommittee is not required and opening date lapsed then update tender status to completed TAB.
        //Else : When evaluation is required and opening date lapsed then update tender status to OPENEND TAB
        if(Integer.parseInt(modelMap.get("isEvaluationRequired").toString()) == 0 && isOpeningByCommittee == 0 && openedEnvCount > 0){
        	eventCreationService.updateTenderEvalutionStatus(tenderId, TENDER_COMPLETED_STATUS);
        }else if(Integer.parseInt(modelMap.get("isEvaluationRequired").toString()) == 1 && isOpeningByCommittee == 0 && openedEnvCount > 0){
        	List<Object[]>	obj= tenderFormService.getAllEnvelopWiseEvaluationDone(tenderId);
            if(obj != null && obj.get(0)[0].equals(obj.get(0)[1])){}else{
            	eventCreationService.updateTenderEvalutionStatus(tenderId, TENDER_OPENED_STATUS);
            }
        }
        
    	dataMap = tenderOpenService.getTenderOpeningDetails(tenderId,1);
    	if (dataMap != null && !dataMap.isEmpty()) {
                TenderOpenProcessDTBean openProcessDTBean = new TenderOpenProcessDTBean();
    		List<LinkedHashMap<String, Object>> tenderDetailList= (List<LinkedHashMap<String, Object>>) dataMap.get(RESULT_SET_1);
    		openProcessDTBean.setTenderDetailsList(tenderDetailList);
                openProcessDTBean.setEnvelopeList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-2"));
                
                if (dataMap.get("#result-set-2") != null) { // Envelope detail
                    Map<Integer, Integer> isEnvelopeOpenDecryptMap = new HashMap<Integer, Integer>();
                    List<LinkedHashMap<String, Object>> lstEnvelopeDetail = (ArrayList<LinkedHashMap<String, Object>>) dataMap.get("#result-set-2");
                    Map<Integer, Boolean> consortiumSecondaryBidReceivedMap =  new HashMap<Integer, Boolean>();
                    for (LinkedHashMap<String, Object> lstEnv : lstEnvelopeDetail) {
                        int timeLapsed = Integer.parseInt(lstEnv.get("timeLapsed").toString());
                        //int sortOrder = Integer.parseInt(lstEnv.get("sortOrder").toString());
                        int isEnvelopeDecryptAndOpen = 1;
                        if (dataMap.get("#result-set-4") != null) {
                            List<LinkedHashMap<String, Object>> lstVerifyformDetail = (ArrayList<LinkedHashMap<String, Object>>) dataMap.get("#result-set-4");
                            
                            if(lstVerifyformDetail.size()>0){
                                for (LinkedHashMap<String, Object> lstVerifyForm : lstVerifyformDetail) {
                                    if (Integer.parseInt(lstEnv.get("envelopeId").toString()) == Integer.parseInt(lstVerifyForm.get("envelopeId").toString()) && Integer.parseInt(lstVerifyForm.get("cstatus").toString()) != 2) {
                                        if ((!(Integer.parseInt(lstVerifyForm.get("finalCount").toString()) <= Integer.parseInt(lstVerifyForm.get("openCount").toString())))) {
                                            isEnvelopeDecryptAndOpen=0;
                                            break;
                                        }
                                        if(modelMap.get("isConsortiumAllowed").toString().equals("1"))
                                        {
                                        	if(lstVerifyForm.get("isMandatory").toString().equals("0"))
                                            {
                                        		boolean partnerFlag = tenderOpenService.getCountOfBidByFormId(Integer.parseInt(lstVerifyForm.get("formId").toString()));
                                        		consortiumSecondaryBidReceivedMap.put(Integer.parseInt(lstVerifyForm.get("formId").toString()), partnerFlag);
                                            }
                                        	else
                                        	{
                                        		consortiumSecondaryBidReceivedMap.put(Integer.parseInt(lstVerifyForm.get("formId").toString()), false);
                                        	}
                                        }
                                    }
                                    
                                }
                              
                            }else{
                                isEnvelopeDecryptAndOpen=0;
                            }
                            if(isEnvelopeDecryptAndOpen==1 && timeLapsed == 1){
                                modelMap.addAttribute("isRegretLinkAllow", true);
                            }
                            /*if(sortOrder == 1 && isEnvelopeDecryptAndOpen==1  && timeLapsed == 1){
                                modelMap.addAttribute("isFirstEnvDecrypt", true);
                            }*/
                        }else{
                            isEnvelopeDecryptAndOpen=0;
                        }
                        isEnvelopeOpenDecryptMap.put(Integer.parseInt(lstEnv.get("envelopeId").toString()), isEnvelopeDecryptAndOpen);
                    }
                    modelMap.addAttribute("consortiumSecondaryBidReceivedMap", consortiumSecondaryBidReceivedMap);
                    modelMap.addAttribute("isEnvelopeOpenDecryptMap", isEnvelopeOpenDecryptMap);
                    if(isEnvelopeOpenDecryptMap.containsValue(1)){
                        modelMap.addAttribute("isAtleastOneEnvelopeDecrypted", true);
                    }
                }
    		openProcessDTBean.setBidderDetailList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-3"));
    		openProcessDTBean.setVerifyList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-4"));
                
                Map<Integer,Integer> multFillingCountMap = new HashMap<Integer, Integer>();
                for(int i=0;i<openProcessDTBean.getVerifyList().size();i++){
                    formId = Integer.parseInt(openProcessDTBean.getVerifyList().get(i).toString().split(",")[1].split("=")[1].toString());
                    multFillingCountMap.put(formId,tenderCommonService.getMulTableFillingCount(formId));
                }
                modelMap.addAttribute("multFillingCountMap", multFillingCountMap);
                
    		if(tenderDetailList!=null && !tenderDetailList.isEmpty()){
    			resultSharing=(Short) tenderDetailList.get(0).get("resultSharing");
    		}
    		if(isOpeningByCommittee==1){
    			openProcessDTBean.setTenderReportDetailsList((List<LinkedHashMap<String, Object>>) dataMap.get(RESULT_SET_5));
    			openProcessDTBean.setCommitteeMemeberList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-6"));
    			if(resultSharing==2 ){//Only For Manual Result sharing configuration
    				List<LinkedHashMap<String, Object>> reportConfigList =(List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-7");
    				if(reportConfigList !=null && !reportConfigList.isEmpty()){
    					openProcessDTBean.setReportConfigurationCount((Integer)reportConfigList.get(0).get(REPORT_CONFIG_COUNT));
    				}
    			}
    		}else{
    			if(resultSharing==2 ){//Only For Manual Result sharing configuration
    				List<LinkedHashMap<String, Object>> reportConfigList =(List<LinkedHashMap<String, Object>>) dataMap.get(RESULT_SET_5);
    				if(reportConfigList !=null && !reportConfigList.isEmpty()){
    					openProcessDTBean.setReportConfigurationCount((Integer)reportConfigList.get(0).get(REPORT_CONFIG_COUNT));
    				}
    			}
    		}
    		modelMap.addAttribute("openProcessDTBean", openProcessDTBean);
    		modelMap.addAttribute("rejectedBidderMap",tenderFormService.getRejectedBidderAppDtls(tenderId));
    	}
        int isReEvaluationReq = (Integer) modelMap.get("isReEvaluationReq");
        Map<Integer,Integer> isReEvaluationReqMap = new HashMap<Integer, Integer>();
        if(isReEvaluationReq == 1){
            Integer[] ctatus={0,1};
            List<TblTenderReevaluation> getTblTenderReevaluation = tenderFormService.getTblTenderEnvelopeRevaluationStatusByTenderId(tenderId,ctatus);
            if(getTblTenderReevaluation!=null && !getTblTenderReevaluation.isEmpty()){
               for(TblTenderReevaluation data : getTblTenderReevaluation){
                    isReEvaluationReqMap.put(data.getTblTenderEnvelope().getEnvelopeId(), data.getCstatus());
               }
               modelMap.addAttribute("isReEvaluationReqMap", isReEvaluationReqMap); //key=envelopeId, value=cstatus
            }
        }
    	 //get the lodingFactor map
        StringBuffer commaSepList= new StringBuffer();
        List<Object[]> companyFormMap=tenderFormService.getCompanyFormDetails(tenderId);
        if(companyFormMap!=null && companyFormMap.size()>0){
            for (Object[] objects : companyFormMap) {
               commaSepList.append(objects[0].toString()+"-"+objects[1].toString()+",");
            }
            modelMap.addAttribute("lodingCompanyForm", commaSepList.deleteCharAt(commaSepList.length()-1));
        }
        
        List<Object[]> loadingFactorList = tenderFormService.getLoadingFactor(tenderId);
        modelMap.addAttribute("isPriceBidForm",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[0].toString()) : 0);
        modelMap.addAttribute("isEncNotRequire",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[1].toString()) : 0);
        modelMap.addAttribute("isLoadingFactor",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[2].toString()) : 0);
        modelMap.addAttribute("isAutoLoadingTotal",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[3].toString()) : 0);
        modelMap.addAttribute("isUnitRateAfterLoading",!loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[4].toString()) : 0);
        
     // isGenerateReport
        boolean isGenerateReport = true;
        boolean isNegotiationAllowedAndIsStarted = false;
        int isLoadingFactor = !loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[2].toString()) : 0;
        if(isLoadingFactor!=0){
        	if (dataMap != null && !dataMap.isEmpty() && dataMap.get("#result-set-3") != null) {
    			List<LinkedHashMap<String, Object>> lstBidder = (ArrayList<LinkedHashMap<String, Object>>) dataMap.get("#result-set-3");
    			 for (LinkedHashMap<String, Object> lstBidder1 : lstBidder) {
					 int cmpId = Integer.parseInt(lstBidder1.get("companyId").toString());
                     isBidderBidWithLoadingFactor.put(cmpId, tenderFormService.isBidderBidWithLoadingFactor(tenderId,cmpId)!=null?true:false);
                     
                     List<Object[]> approvedBidderLoadingForms = tenderFormService.getApprovedFormsBeforeAfterLoading(tenderId, cmpId);
                	 List<Object[]> loadingProcessedForm = tenderFormService.getLoadingFactorProcessDetail(tenderId,0,cmpId);
                	 if(approvedBidderLoadingForms  != null && !approvedBidderLoadingForms.isEmpty())
                		 configCalLoadingMap.put(cmpId, approvedBidderLoadingForms.size()==loadingProcessedForm.size() ? true : false);
                	 else
                		 configCalLoadingMap.put(cmpId, false);
    			 }
    			 modelMap.addAttribute("configCalLoadingMap", configCalLoadingMap);
                 modelMap.addAttribute("isBidderBidWithLoadingFactor", isBidderBidWithLoadingFactor);
    		}
        	isNegotiationAllowedAndIsStarted = negotiationService.isNegotiationAllowedAndNegotiationStarted(tenderId,negotiation_negotiation_process_invite_for_negotiation);
        	isGenerateReport =  isGenerateReportForLoading(tenderId,modelMap);
        }
        modelMap.put("isNegotiationAllowedAndIsStarted", isNegotiationAllowedAndIsStarted);
        modelMap.addAttribute("isGenerateReport", isGenerateReport);
    }
    
    public boolean isGenerateReportForLoading(int tenderId, ModelMap modelMap) throws Exception
    {
    	 boolean isGenerateReport = true;
    	List<Object[]> lstEnvelope = tenderFormService.getTenderEnvelopeList(tenderId);
    	int priceBidEnvId = 0;
        for (int i=0;i<lstEnvelope.size();i++) {
            int envelopeId = Integer.parseInt(lstEnvelope.get(i)[2].toString());
            int envId = Integer.parseInt(lstEnvelope.get(i)[8].toString());
            if(envId==4 || envId==5)
            	priceBidEnvId = envelopeId;
        }
        List<Object[]> lstBidder = tenderFormService.getTenderOpeningBidderDetails(tenderId);
        Set<Integer> loadingCompanySet = new HashSet<Integer>();
        if (lstBidder != null && !lstBidder.isEmpty()) {
        	 for(int i=0;i<lstBidder.size();i++){
				 int cmpId = Integer.parseInt(lstBidder.get(i)[2].toString());
                 if((lstBidder.get(i)[9] !=null && (Integer.parseInt(lstBidder.get(i)[9].toString())==1) || lstBidder.get(i)[9] == null) && Integer.parseInt(lstBidder.get(i)[3].toString()) == priceBidEnvId && (Integer.parseInt(modelMap.get("envelopeType").toString())==2))
            		 loadingCompanySet.add(cmpId);
			 }
		}
        List<Object[]> lstLoadingBeforForms = tenderFormService.getLoadingBeforeFormsMultipleSingleCase(tenderId,loadingCompanySet);
        List<Object[]> lstLoadingAfterForms = tenderFormService.getLoadingProgressForms(tenderId);
        boolean isBidderBiddedInLoading = tenderFormService.isBidderBidWithLoadingFactor(tenderId,0)!=null;
        if(lstLoadingBeforForms.size()!=lstLoadingAfterForms.size() || (lstLoadingBeforForms.size()==0 && isBidderBiddedInLoading)){
            isGenerateReport = false;
        }
        if(!lstLoadingBeforForms.isEmpty() && !lstLoadingAfterForms.isEmpty() && lstLoadingBeforForms.size()==lstLoadingAfterForms.size()){
            for(int i=0;i<lstLoadingBeforForms.size();i++){
                int cmpCount1 = Integer.parseInt(lstLoadingBeforForms.get(i)[1].toString());
                int cmpCount2 = Integer.parseInt(lstLoadingAfterForms.get(i)[1].toString());
                if(cmpCount1!=cmpCount2){
                    isGenerateReport=false;
                    break;
                }
            }
        }
       return isGenerateReport;
    }
    
    public int companyCount(int currentEnvId, List<Object[]> lst) {
        int cmpCount = 0;
        if (!lst.isEmpty()) {
            for (int i = 0; i < lst.size(); i++) {
                int envId = Integer.parseInt(lst.get(i)[0].toString());
                if (envId == currentEnvId) {
                    int totalBidder = Integer.parseInt(lst.get(i)[1].toString());
                    int totalPrevEligibleBidder = Integer.parseInt(lst.get(i)[2].toString());
                    int totalCurrentEligibleBidder = Integer.parseInt(lst.get(i)[3].toString());
                    if (totalCurrentEligibleBidder != 0) {
                        cmpCount = totalCurrentEligibleBidder;
                        break;
                    }else if (totalPrevEligibleBidder != 0) {
                        cmpCount = totalPrevEligibleBidder;
                        break;
                    } else {
                        cmpCount = totalBidder;
                        break;
                    }
                }
            }
        }
        //System.out.println("cmpCount ===================================> " + cmpCount);
        return cmpCount;
    }

    @SuppressWarnings("unchecked")
    private void setDataForEvaluationTab(int tenderId,ModelMap modelMap, int resultSharing,int isOpeningByCommittee, Map<String, Object> dataMap,int userDetailId,Integer userId) throws Exception {
        List<Object[]> lstEnvelope = tenderFormService.getTenderEnvelopeList(tenderId);
        int technicalEnvelopeId = 0;
        int askToLevel = 0;
        Map<Integer,Integer> reworkIForRemarkMap = new HashMap<Integer, Integer>();
        Map<Integer,Boolean> isRemarkLinkShowMap = new HashMap<Integer, Boolean>();
        Map<Integer,Boolean> isRemarkEvaluateLinkShowMap = new HashMap<Integer, Boolean>();
        List<Object[]> envWiseBidderEligibility = new ArrayList<Object[]>();
        dataMap = tenderOpenService.getTenderOpeningDetails(tenderId,2);
        boolean isCommitteePublished = tenderFormService.getPendingCommittee(tenderId,2,0);
       
        boolean isTECConsentGivenForAllEnvelope = true;
        for (int i=0;i<lstEnvelope.size();i++) {
            int timeLapsed = Integer.parseInt(lstEnvelope.get(i)[4].toString());
            int envelopeId = Integer.parseInt(lstEnvelope.get(i)[2].toString());
            int envelopeOpened = Integer.parseInt(lstEnvelope.get(i)[3].toString());
            int envelopeEvaluated = Integer.parseInt(lstEnvelope.get(i)[5].toString());
            if(envelopeOpened==1){
            	  modelMap.addAttribute("envelopeIdTECReport", envelopeId);
              }
            if(envelopeEvaluated==0){
            	isTECConsentGivenForAllEnvelope = false;
            	  modelMap.addAttribute("isTECConsentGivenForAllEnvelope", isTECConsentGivenForAllEnvelope );
              }
            int minOpeningMember = Integer.parseInt(lstEnvelope.get(i)[6].toString());
            int minEvaluatedMember = Integer.parseInt(lstEnvelope.get(i)[7].toString());
            int envId = Integer.parseInt(lstEnvelope.get(i)[0].toString());
            int isOpened = Integer.parseInt(lstEnvelope.get(i)[3].toString());
            
            if (dataMap != null && !dataMap.isEmpty()) {
                List<LinkedHashMap<String, Object>> lstBidder = (ArrayList<LinkedHashMap<String, Object>>) dataMap.get("#result-set-3");
                int currentTotalBidder = 0;
                int prevTotalEligibleBidder = 0;
                int currentTotalEligibleBidder = 0;
                if (!lstBidder.isEmpty()) {
                    for (LinkedHashMap<String, Object> lstBidder1 : lstBidder) {
                        if (envelopeId == Integer.parseInt(lstBidder1.get("envelopeId").toString())) {
                            currentTotalBidder++;
                            if (lstBidder1.get("isApproved") != null && !lstBidder1.get("isApproved").equals("null") && StringUtils.hasLength(lstBidder1.get("isApproved").toString())) {
                                if (Integer.parseInt(lstBidder1.get("isApproved").toString()) == 1) {
                                    currentTotalEligibleBidder++;
                                }
                            }
                        }
                    }
                }
                //System.out.println("currentTotalBidder = " + currentTotalBidder);
                envWiseBidderEligibility.add(new Object[]{envelopeId, currentTotalBidder, prevTotalEligibleBidder, currentTotalEligibleBidder});
                int prevRecord = envWiseBidderEligibility.size() - 2;
                if (prevRecord >= 0) {
                    Object[] prevEnv = envWiseBidderEligibility.get(prevRecord);
                    Object[] currEnv = envWiseBidderEligibility.get(prevRecord+1);
                    currEnv[2]=prevEnv[3];
                    envWiseBidderEligibility.add(prevRecord+1, currEnv);
                }
            }
            List<Object[]> lstUserRole = tenderFormService.getUserRole(tenderId,envelopeId,userId,2);
        	int encLevel = (lstUserRole!=null && !lstUserRole.isEmpty()) ? Integer.parseInt(lstUserRole.get(0)[0].toString()) : 0;//
            int userRole = (lstUserRole!=null && !lstUserRole.isEmpty() && lstUserRole.get(0)[1]!=null) ? Integer.parseInt(lstUserRole.get(0)[1].toString()) : 0;
            int officerId = (lstUserRole!=null && !lstUserRole.isEmpty()) ? Integer.parseInt(lstUserRole.get(0)[2].toString()) : 0;
            if(encLevel==1 && userRole == 2){
                askToLevel = 1;
            }else if(encLevel==1 && userRole == 1){
                askToLevel = 2;
            }else if(encLevel==2 && userRole == 2){
                askToLevel = 3;
            }else if(encLevel==2 && userRole == 1){
                askToLevel = 4;
            }
            if(userId == officerId){
                modelMap.addAttribute("loginUserRole", askToLevel);
            }
            if(envId==4){
                modelMap.addAttribute("isPriceBidFormDecrypted", tenderFormService.isPriceBidFormDecrypted(tenderId,envelopeId));
               
            }else if (envId==3){
                technicalEnvelopeId = envelopeId;                
            }
            if(timeLapsed==1){
                //case for auto opening as well as auto evaluation
                if(minEvaluatedMember==0 && envelopeEvaluated==0 && minOpeningMember==0){
                    tenderFormService.autoOpeningEvaluation(tenderId,envelopeId,userDetailId,"fromAuto",isCommitteePublished);
                }else if(minEvaluatedMember==0 && envelopeEvaluated==0 && isOpened==1){
                    	tenderFormService.autoOpeningEvaluation(tenderId,envelopeId,userDetailId,"fromEvaluatioTab",isCommitteePublished);
                }
            }
            isRemarkLinkShowMap.put(envelopeId,tenderFormService.showEvaluationRemark(userId,envelopeId,askToLevel,2,tenderId));
            isRemarkEvaluateLinkShowMap.put(envelopeId,tenderFormService.getEvaluationRemarkCount(envelopeId,userId,2)!=0);
            modelMap.addAttribute("isEvaluateRemarkWise", tenderFormService.getEvaluationRemarkCount(envelopeId,userId,2)!=0);
            reworkIForRemarkMap.put(envelopeId,tenderFormService.getReworkId(0, envelopeId, userId));
        }//end of envelope loop
        modelMap.addAttribute("askLevel", askToLevel);
        modelMap.addAttribute("isRemarkLinkShowMap", isRemarkLinkShowMap);
        modelMap.addAttribute("isRemarkEvaluateLinkShowMap", isRemarkEvaluateLinkShowMap);
        modelMap.addAttribute("reworkIForRemarkMap", reworkIForRemarkMap);
    	dataMap = tenderOpenService.getTenderOpeningDetails(tenderId,2);
        int formId=0;
        int companyCount=0;
        Map<Integer,Integer> isItemWiseLinkShowMap = new HashMap<Integer, Integer>();
        Map<Integer,Integer> reworkIdMap = new HashMap<Integer, Integer>();
        
    	if (dataMap != null && !dataMap.isEmpty()) {
    		TenderOpenProcessDTBean openProcessDTBean = new TenderOpenProcessDTBean();
    		List<LinkedHashMap<String, Object>> tenderDetailList= (List<LinkedHashMap<String, Object>>) dataMap.get(RESULT_SET_1);
    		openProcessDTBean.setTenderDetailsList(tenderDetailList);
    		openProcessDTBean.setEnvelopeList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-2"));
    		openProcessDTBean.setBidderDetailList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-3"));
    		openProcessDTBean.setVerifyList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-4"));
                 if(dataMap.get("#result-set-3") !=null){ // Tender bid 
                    List<LinkedHashMap<String, Object>> lstBidder = (ArrayList<LinkedHashMap<String, Object>>) dataMap.get("#result-set-3");
                     for(LinkedHashMap<String, Object> lstBidder1 : lstBidder) {
                        if(Integer.parseInt(lstBidder1.get("envelopeId").toString())==technicalEnvelopeId){
                            //int cmpId = Integer.parseInt(lstBidder1.get("companyId").toString());
                            companyCount++;
                        }
                     }
                    for(LinkedHashMap<String, Object> lstBidder1 : lstBidder) {
                        if(Integer.parseInt(lstBidder1.get("envelopeId").toString())==technicalEnvelopeId){
                            int cmpId = Integer.parseInt(lstBidder1.get("companyId").toString());
                            isItemWiseLinkShowMap.put(cmpId,tenderFormService.showItemSelection(userId, technicalEnvelopeId, askToLevel, cmpId,tenderId,companyCount(technicalEnvelopeId,envWiseBidderEligibility)));
                            reworkIdMap.put(cmpId,tenderFormService.getReworkId(cmpId, technicalEnvelopeId, userId));
                        }
                    }
                    modelMap.addAttribute("isItemWiseLinkShowMap", isItemWiseLinkShowMap);
                    modelMap.addAttribute("reworkIdMap", reworkIdMap);
                    if (askToLevel == 4) {
                        List<Object> userLst = new ArrayList<Object>();
                        userLst.add(userId);
                        List<Object[]> lstEvaluateItemBidder = tenderFormService.getDistinctBidderItems(tenderId, userLst);
                        if (lstEvaluateItemBidder != null && !lstEvaluateItemBidder.isEmpty() && companyCount(technicalEnvelopeId,envWiseBidderEligibility) == lstEvaluateItemBidder.size()) {
                            boolean isEvaluateItemWise = true;
                            for (int k = 0; k < lstEvaluateItemBidder.size(); k++) {
                                int count = Integer.parseInt(lstEvaluateItemBidder.get(k)[1].toString());
                                if (count == 0) {
                                    isEvaluateItemWise = false;
                                    break;
                                }
                            }
                            modelMap.addAttribute("isEvaluateItemWise", isEvaluateItemWise);
                        } else {
                            modelMap.addAttribute("isEvaluateItemWise", false);
                        }
                    }
                    
                     if(askToLevel==4){
                            List<Object[]> loadingFactorList = tenderFormService.getLoadingFactor(tenderId);
                            boolean isLoadingFormDone = true;
                            int isLoadingFactor = !loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[2].toString()) : 0;
                            if(isLoadingFactor!=0){
                                List<Object[]> lstLoadingBeforForms = tenderFormService.getLoadingBeforeForms(tenderId);
                                List<Object[]> lstLoadingAfterForms = tenderFormService.getLoadingProgressForms(tenderId);
                                if(lstLoadingBeforForms.size()!=lstLoadingAfterForms.size()){
                                    isLoadingFormDone = false;
                                }
                                if(!lstLoadingBeforForms.isEmpty() && !lstLoadingAfterForms.isEmpty() && lstLoadingBeforForms.size()==lstLoadingAfterForms.size()){
                                    for(int i=0;i<lstLoadingBeforForms.size();i++){
                                        int cmpCount1 = Integer.parseInt(lstLoadingBeforForms.get(i)[1].toString());
                                        int cmpCount2 = Integer.parseInt(lstLoadingAfterForms.get(i)[1].toString());
                                        if(cmpCount1!=cmpCount2){
                                            isLoadingFormDone=false;
                                            break;
                                        }
                                    }
                                }
                            }
                            modelMap.addAttribute("isLoadingFormDone", isLoadingFormDone);
                        }
                 }
                 //Bug Id 32348 
                 if (dataMap.get("#result-set-4") != null) {
                     List<LinkedHashMap<String, Object>> lstVerifyformDetail = (ArrayList<LinkedHashMap<String, Object>>) dataMap.get("#result-set-4");
                     Map<Integer, Boolean> consortiumSecondaryBidReceivedMap = new HashMap<Integer, Boolean>();
                     if(lstVerifyformDetail.size()>0){
                         for (LinkedHashMap<String, Object> lstVerifyForm : lstVerifyformDetail) {
                                 if(modelMap.get("isConsortiumAllowed").toString().equals("1"))
                                 {
                                 	if(lstVerifyForm.get("isMandatory").toString().equals("0"))
                                     {
                                 		boolean partnerFlag = tenderOpenService.getCountOfBidByFormId(Integer.parseInt(lstVerifyForm.get("formId").toString()));
                                 		consortiumSecondaryBidReceivedMap.put(Integer.parseInt(lstVerifyForm.get("formId").toString()), partnerFlag);
                                     }
                                 	else
                                 	{
                                 		consortiumSecondaryBidReceivedMap.put(Integer.parseInt(lstVerifyForm.get("formId").toString()), false);
                                 	}
                                 }
                         }
                         modelMap.addAttribute("consortiumSecondaryBidReceivedMap", consortiumSecondaryBidReceivedMap);
                     }
                 }
                 //Bug Id 32348
                Map<Integer,Integer> multFillingCountMap = new HashMap<Integer, Integer>();
                for(int i=0;i<openProcessDTBean.getVerifyList().size();i++){
                    formId = Integer.parseInt(openProcessDTBean.getVerifyList().get(i).toString().split(",")[1].split("=")[1].toString());
                    multFillingCountMap.put(formId,tenderCommonService.getMulTableFillingCount(formId));
                    //System.out.println("form id = " +Integer.parseInt(openProcessDTBean.getVerifyList().get(i).toString().split(",")[1].split("=")[1].toString()));
                }
                modelMap.addAttribute("multFillingCountMap", multFillingCountMap);
                
    		if(tenderDetailList!=null && !tenderDetailList.isEmpty()){
    			resultSharing=(Short) tenderDetailList.get(0).get("resultSharing");
    		}
    		if(isOpeningByCommittee==1){
    			openProcessDTBean.setTenderReportDetailsList((List<LinkedHashMap<String, Object>>) dataMap.get(RESULT_SET_5));
    			openProcessDTBean.setCommitteeMemeberList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-6"));
    			if(resultSharing==2 ){//Only For Manual Result sharing configuration
    				List<LinkedHashMap<String, Object>> reportConfigList =(List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-7");
    				if(reportConfigList !=null && !reportConfigList.isEmpty()){
    					openProcessDTBean.setReportConfigurationCount((Integer)reportConfigList.get(0).get(REPORT_CONFIG_COUNT));
    				}
    			}
    		}else{
    			if(resultSharing==2 ){//Only For Manual Result sharing configuration
    				List<LinkedHashMap<String, Object>> reportConfigList =(List<LinkedHashMap<String, Object>>) dataMap.get(RESULT_SET_5);
    				if(reportConfigList !=null && !reportConfigList.isEmpty()){
    					openProcessDTBean.setReportConfigurationCount((Integer)reportConfigList.get(0).get(REPORT_CONFIG_COUNT));
    				}
    			}
    		}
    		modelMap.addAttribute("openProcessDTBean", openProcessDTBean);
    		boolean isWeightageEvaluationRequired = Integer.parseInt(modelMap.get("isWeightageEvaluationRequired").toString())==1;
    		boolean isGrandTotalWiseTenderResult = Integer.parseInt(modelMap.get("tenderResult").toString())==1;
    		if(isWeightageEvaluationRequired && isGrandTotalWiseTenderResult)
    		{
				int isTwoStageEvaluation = (Integer) modelMap.get("isTwoStageEvaluation");
    			boolean isWeightageEvaluationConfigDone = true;
    			List<Object[]> tenderEnvelopeList=tenderFormService.getTenderEnvelopeListForWeightageScore(tenderId,1);
    			List<Integer> envelopeIdsList = new ArrayList<Integer>();
    			Map<Integer,Boolean> isEnvelopeWeightageConfigMap = new HashMap<Integer, Boolean>();
    			if(tenderEnvelopeList != null && ! tenderEnvelopeList.isEmpty()){
    				BigDecimal envTotMarks = new BigDecimal(0);
    	    		for (Object[] tenderEnvelope : tenderEnvelopeList) {
    	    			int envelopeId = Integer.parseInt(tenderEnvelope[0].toString());
    	    			envelopeIdsList.add(envelopeId);
    	    			isEnvelopeWeightageConfigMap.put(envelopeId, tenderFormService.getBidderweightageScoreCount(tenderId, envelopeId,isTwoStageEvaluation==1 ? userId : 0));
    	    				envTotMarks = envTotMarks.add(new BigDecimal(tenderEnvelope[9] != null ? tenderEnvelope[9].toString() : "0".toString()));
    				}
    	    		int isAllEnvsTotMarks100 = envTotMarks.compareTo(new BigDecimal(100));
    	    		if(isAllEnvsTotMarks100 == 0){				// all Envelope Scoring Marks should be 100
    	    			List<Object[]> tenderWeightageMarksFormList = tenderFormService.getWeightageTotalMarksForAllForm(tenderId,envelopeIdsList);
    	    			if(tenderWeightageMarksFormList != null && !tenderWeightageMarksFormList.isEmpty())
    	    			{
    	    				for (Object[] tenderWeightageMarksForm : tenderWeightageMarksFormList) {
    	    					BigDecimal formTotMarks = new BigDecimal(tenderWeightageMarksForm[1].toString());
    	    					int isFormsTotMarks100 = formTotMarks.compareTo(new BigDecimal(100));  // all forms of envelope scoring Marks should be 100
    	    					if(isFormsTotMarks100 != 0)
    	    						isWeightageEvaluationConfigDone = false;
    	    				}
    	    			}
    	    		}
    	    		else{
    	    			isWeightageEvaluationConfigDone = false;
    	    		}
        		 }
    			modelMap.put("isEnvelopeWeightageConfigMap", isEnvelopeWeightageConfigMap);
    			modelMap.put("isWeightageEvaluationConfigDone", isWeightageEvaluationConfigDone);
    			modelMap.put("isWeightageEvaluationForReConfig", tenderFormService.getWeightageEvaluationForReConfig(tenderId));
    		}
    		modelMap.addAttribute("rejectedBidderMap",tenderFormService.getRejectedBidderAppDtls(tenderId));
    	}
	}

	/**
     * Use For To set data in View Case of report configuration
     * @author nirav.modi
     * @param modelMap 
     * @param reportDetail 
     * @param tabId
     * @param txtOptionalParam
     */
	private void setViewDataForReportConfit(ModelMap modelMap, Object[] reportDetail, int tabId) {
		if(reportDetail!=null && reportDetail.length>0){
			if(tabId==7){//Only for opening tab
				if((Integer)reportDetail[0]==1){//shareReport For All Bidder
					modelMap.addAttribute("shareReport",messageSource.getMessage("field_all_bidder", null, LocaleContextHolder.getLocale()));
				}else if((Integer)reportDetail[0]==2){//shareReport For Qualified Bidder
					modelMap.addAttribute("shareReport",messageSource.getMessage("field_qul_bidder", null, LocaleContextHolder.getLocale()));
				}else if((Integer)reportDetail[0]==3){//shareReport For Participated Bidder
					modelMap.addAttribute("shareReport",messageSource.getMessage("field_part_bidder", null, LocaleContextHolder.getLocale()));
				}else if((Integer)reportDetail[0]==4){//shareReport For All Registered Users
					modelMap.addAttribute("shareReport",messageSource.getMessage("field_all_registered_users", null, LocaleContextHolder.getLocale()));
				}
				
				if((Integer)reportDetail[1]==1){//showResultBeforeLogin
					modelMap.addAttribute("showResultBeforeLogin",messageSource.getMessage("label_yes", null, LocaleContextHolder.getLocale()));
				}else{
					modelMap.addAttribute("showResultBeforeLogin",messageSource.getMessage("label_no", null, LocaleContextHolder.getLocale()));
				}
				
				if((Integer)reportDetail[2]==1){//showL1Report
					modelMap.addAttribute("showL1Report",messageSource.getMessage("label_yes", null, LocaleContextHolder.getLocale()));
				}else{
					modelMap.addAttribute("showL1Report",messageSource.getMessage("label_no", null, LocaleContextHolder.getLocale()));
				}
			}else if (tabId==8){//For evaluation tab
				if((Integer)reportDetail[4]==1){//shareBidderStatus For All Bidder
					modelMap.addAttribute(SHARE_BIDDER_STATUS,messageSource.getMessage("field_all_bidder", null, LocaleContextHolder.getLocale()));
				}else if((Integer)reportDetail[4]==2){//shareBidderStatus For Qualified Bidder
					modelMap.addAttribute(SHARE_BIDDER_STATUS,messageSource.getMessage("field_qul_bidder", null, LocaleContextHolder.getLocale()));
				}else if((Integer)reportDetail[4]==3){//shareBidderStatus For Participated Bidder
					modelMap.addAttribute(SHARE_BIDDER_STATUS,messageSource.getMessage("field_part_bidder", null, LocaleContextHolder.getLocale()));
				}else{//do not share
					modelMap.addAttribute(SHARE_BIDDER_STATUS,messageSource.getMessage("field_not_share", null, LocaleContextHolder.getLocale()));
				}
				
				if((Integer)reportDetail[5]==1){//shareClarificationReport For All Bidder
					modelMap.addAttribute(SHARE_CLARIFICATION_REPORT,messageSource.getMessage("field_all_bidder", null, LocaleContextHolder.getLocale()));
				}else if((Integer)reportDetail[5]==2){//shareClarificationReport For Qualified Bidder
					modelMap.addAttribute(SHARE_CLARIFICATION_REPORT,messageSource.getMessage("field_qul_bidder", null, LocaleContextHolder.getLocale()));
				}else if((Integer)reportDetail[5]==3){//shareClarificationReport For Participated Bidder
					modelMap.addAttribute(SHARE_CLARIFICATION_REPORT,messageSource.getMessage("field_part_bidder", null, LocaleContextHolder.getLocale()));
				}else{//shareBidderStatus do not share
					modelMap.addAttribute(SHARE_CLARIFICATION_REPORT,messageSource.getMessage("field_not_share", null, LocaleContextHolder.getLocale()));
				}
				
				if((Integer)reportDetail[6]==1){//shareEvaluationReport For All Bidder
					modelMap.addAttribute(SHARE_EVALUATION_REPORT,messageSource.getMessage("field_all_bidder", null, LocaleContextHolder.getLocale()));
				}else if((Integer)reportDetail[6]==2){//shareEvaluationReport For Qualified Bidder
					modelMap.addAttribute(SHARE_EVALUATION_REPORT,messageSource.getMessage("field_qul_bidder", null, LocaleContextHolder.getLocale()));
				}else if((Integer)reportDetail[6]==3){//shareEvaluationReport For Participated Bidder
					modelMap.addAttribute(SHARE_EVALUATION_REPORT,messageSource.getMessage("field_part_bidder", null, LocaleContextHolder.getLocale()));
				}else{//shareEvaluationReport do not share
					modelMap.addAttribute(SHARE_EVALUATION_REPORT,messageSource.getMessage("field_not_share", null, LocaleContextHolder.getLocale()));
				}
			}
		}
	}
	
	/**
	 * @author SULABH
	 * @param objectId
	 * @param moduleId
	 * @param modelMap
	 * @param request
	 * @return
	 */
	
	@RequestMapping(value="/updateEstimatedValue/{moduleId}/{objectId}/{enc}",method = RequestMethod.GET)
    public String updateEstimatedValue(@PathVariable("objectId")int objectId,@PathVariable("moduleId")int moduleId,ModelMap modelMap,HttpServletRequest request){
    	int clientId=abcUtility.getSessionClientId(request);
    	String auditMsg="";
      	try{   
      		modelMap.addAttribute("objectId", objectId);
      		modelMap.addAttribute("moduleId", moduleId);
      		tenderCommonService.tenderSummary(objectId, modelMap, clientId);
      		modelMap.addAttribute("estimatedValue", commonService.getField("TblTender", "prevEstimatedValue", "tenderId", objectId));
      		modelMap.addAttribute("decimalValueUpto", commonService.getField("TblTender", "decimalValueUpto", "tenderId", objectId));
      		auditMsg=estimatedValueSuccessAuditMessage;
      	}catch(Exception e){
      		auditMsg=estimatedValueFailAuditMessage;
			return exceptionHandlerService.writeLog(e);
      	}finally{
      		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), estimatedValue, auditMsg, objectId, 0);
      	}
      	   return "etender/buyer/UpdateEstimatedValue";
    }
	
	/**
	 * @author SULABH
	 * @param modelMap
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/updateEstValue",method=RequestMethod.POST)
	public String updateEstValue(ModelMap modelMap,HttpServletRequest request,RedirectAttributes redirectAttributes){
		int tenderId=0;
		String pageUrl="";
		boolean isSuccess=false;
		String auditMsg="";
		try{
			String moduleId=request.getParameter("hdmoduleId")!=null?request.getParameter("hdmoduleId"):"0";
			tenderId=Integer.parseInt(request.getParameter("hdobjectId"));
			String estimatedValue=request.getParameter("txtEstimatedValue");
			if(commonService.updateTableField("TblTender", "prevEstimatedValue ", "tenderId", tenderId, estimatedValue)){
				isSuccess=true;
			}
			auditMsg=estimatedValueSuccessAuditMessage;
			pageUrl="common/negotiation/buyer/uploadfinalsummarysheet/"+tenderId+"/" + moduleId;
			redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_success_estimatedValue" : CommonKeywords.ERROR_MSG_KEY.toString());
		}catch(Exception e){
			auditMsg=estimatedValueFailAuditMessage;
			return exceptionHandlerService.writeLog(e);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), estimatedValue, auditMsg, tenderId, 0);
		}
		return "redirect:/"+pageUrl+encryptDecryptUtils.generateRedirect(pageUrl, request);
	}
	
	/**
	 * To get Form List to convert seal bid to auction
	 * @author SULABH
	 * @param tenderId
	 * @param modelMap
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/getpricebidform",method = RequestMethod.POST)
	public String getPriceBidFormList(ModelMap modelMap,HttpServletRequest request,RedirectAttributes redirectAttributes){
		int clientId=0;
		int createdBy=0;
		int formId=0;
		boolean isSuccess=false;
		String returnUrl="";
        String auditMsg="";
        boolean isServerSideValidate=true;
        int tenderId=StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
    	int isDocRevive=StringUtils.hasLength(request.getParameter("txtIsDocRevive")) ? Integer.parseInt(request.getParameter("txtIsDocRevive")) : 0;
    	int isDumpAllItem=StringUtils.hasLength(request.getParameter("txtReviveAllItem")) ? Integer.parseInt(request.getParameter("txtReviveAllItem")) : 0;
    	int isAuctionStartPriceSelected=StringUtils.hasLength(request.getParameter("txtisAuctionStartPriceSelected")) ? Integer.parseInt(request.getParameter("txtisAuctionStartPriceSelected")) : 0;
    	int isBidderRankExcluded=StringUtils.hasLength(request.getParameter("txtisBidderRankExcluded")) ? Integer.parseInt(request.getParameter("txtisBidderRankExcluded")) : 0;
    	int isBidderEncodedSelected=StringUtils.hasLength(request.getParameter("txtisBidderEncodedSelected")) ? Integer.parseInt(request.getParameter("txtisBidderEncodedSelected")) : 0;
    	
		try{
			clientId=abcUtility.getSessionClientId(request);
			createdBy=abcUtility.getSessionUserId(request);
			List<Object[]> list=tenderFormService.getTenderPriceBidForm(tenderId);
			String ipAddress=request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
			if(isAuctionStartPriceSelected==1 || isBidderRankExcluded==1) {
				isServerSideValidate =tenderCommonService.isL1H1Generated(tenderId);
			}	
			if(!isServerSideValidate) {
				auditMsg=createAuctionFailAuditMessage;
				redirectAttributes.addFlashAttribute("errorMsg","Fail_convertToAuctionFromSealBid");
				returnUrl ="redirect:/etender/buyer/tenderdashboard/"+tenderId+"/"+1+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/"+1, request);
			}else {
			if(list.size()==0){
				auditMsg=getPriceBidFormSuccessAuditMessage;
				tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
				modelMap.addAttribute("tenderId", tenderId);
				modelMap.addAttribute("priceBidFormList", list);
				modelMap.addAttribute("isDocRevive", isDocRevive);
				returnUrl="etender/buyer/ConvertRfqToAuction";
				
				}else if(list.size()==1){
					formId=Integer.parseInt(list.get(0)[0].toString());
					Map<String, Object> lst=null;
					if(isDumpAllItem==0){
						 lst=tenderCommonService.createAuctionFromSealBid(tenderId, formId, clientId, createdBy,ipAddress,isDumpAllItem,isAuctionStartPriceSelected,isBidderRankExcluded,isBidderEncodedSelected);
					}else{
						lst=tenderCommonService.createAuctionFromSealBid(tenderId, formId, clientId, createdBy,ipAddress,isDumpAllItem,isAuctionStartPriceSelected,isBidderRankExcluded,isBidderEncodedSelected);
					}
					
					 int auctionId=Integer.parseInt(lst.get("@V_newAuctionid").toString());
					 if(auctionId!=0){
						 isSuccess=true;
						 auditMsg=createAuctionSuccessAuditMessage;
						 
						 //Start :: Code added to dump tender documents to auction
						 List<Object[]> tenderDocs=fileUploadService.getOfficerDocs(tenderId, clientId, uploadTenderDocLinkId, -3);
						 if(!tenderDocs.isEmpty() && isDocRevive == 1){
							 String donloadDocPath="";
							 List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(46, clientId); // For auction
				             TblDocUploadConf tblDocUploadConf=lstDocUploadConf.get(0);
				             StringBuilder tmpDirPath=new StringBuilder();
	                    	 tmpDirPath.append(docUploadPath).append(tblDocUploadConf.getPath());
	        	             String fileDir = "";
	                        if (tblDocUploadConf.getIsDynamicPath() ==1) {
	                             fileDir = String.valueOf(auctionId);
	                             donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                         }else {
	                             donloadDocPath=tblDocUploadConf.getPath();
	                         }
	                         for(int i=tenderDocs.size()-1;i>=0;i--){
	                        	 int userId=abcUtility.getSessionUserId(request);
	                        	 Object[] data=tenderDocs.get(i);
	                        	 TblOfficerDocument tblOfficerDocument = new TblOfficerDocument();
		                         tblOfficerDocument.setDocName(data[1].toString());
		                         tblOfficerDocument.setTblClient(new TblClient(clientId));
		                         tblOfficerDocument.setOfficerFolderId(1);
		                         tblOfficerDocument.setPath(donloadDocPath);
		                         tblOfficerDocument.setDescription(data[2].toString());
		                         tblOfficerDocument.setFileSize((Integer)data[3]);
		                         tblOfficerDocument.setCreatedBy(userId);
		                         tblOfficerDocument.setCstatus(1);
		                         tblOfficerDocument.setIsEncryptionReq(tblDocUploadConf.getIsEncryptionReq());
		                         TblOfficerDocMapping tblOfficerDocMapping = new TblOfficerDocMapping();
	                             tblOfficerDocMapping.setObjectId(auctionId);
	                             tblOfficerDocMapping.setTblLink(new TblLink(documentUpload));
	                             tblOfficerDocMapping.setMappedBy(userId);
	                             tblOfficerDocMapping.setCstatus(0);
	                             tblOfficerDocMapping.setMappedBy(userId);
	                             fileUploadService.addOfficerDocument(tblOfficerDocument,tblOfficerDocMapping);
	                         }
	                         List<TblDocUploadConf> lstDocUploadConfTender = commonService.getDocUploadConf(57, clientId); // For Tender
	                         String oldPath=docUploadPath+lstDocUploadConfTender.get(0).getPath()+"\\"+tenderId;
	                         String newPath=docUploadPath+tblDocUploadConf.getPath()+"\\"+auctionId;
	                         File fp = new File(oldPath);
	                         List<File> file = abcUtility.CheckDirLengthForCopy(fp);
	                         if(file!=null && !file.isEmpty()){
	                            for (File filepath : file) {
	                            	if(filepath.exists()){
	                            		commonService.copyDirectory(filepath,new File(newPath));
	                            	}
	                            }
	                         }
	                         List<Object[]> cancelDoc=fileUploadService.getOfficerDocs(tenderId, clientId, uploadTenderDocLinkId, 3);
	                         if(!cancelDoc.isEmpty()){
	                         	String cancelDocPath=newPath;
	                         	File f=null;
	                         	for(Object[] doc : cancelDoc){
	                         		f=new File(cancelDocPath+"\\"+doc[1]);
	                         		if(f.exists()){
	                         			f.delete();
	                         		}
	                         	}
	                         }
						 }
						//End :: Code added to dump tender documents to auction
						 
						 returnUrl ="redirect:/eauction/auctioneer/auctiondashboard/"+auctionId+"/"+1+encryptDecryptUtils.generateRedirect("eauction/auctioneer/auctiondashboard/"+auctionId+"/"+1, request);
					 }else{
						 auditMsg=createAuctionFailAuditMessage;
						 returnUrl ="redirect:/etender/buyer/tenderdashboard/"+tenderId+"/"+1+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/"+1, request);
					 }
					 redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_create_auction" : CommonKeywords.ERROR_MSG_KEY.toString());
					}else{
					auditMsg=getPriceBidFormSuccessAuditMessage;
					tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
					modelMap.addAttribute("tenderId", tenderId);
					modelMap.addAttribute("priceBidFormList", list);
					modelMap.addAttribute("isDocRevive", isDocRevive);
					modelMap.addAttribute("isDumpAllItem", isDumpAllItem);
					modelMap.addAttribute("isAuctionStartPriceSelected", isAuctionStartPriceSelected);
					modelMap.addAttribute("isBidderRankExcluded", isBidderRankExcluded);
					modelMap.addAttribute("isBidderEncodedSelected", isBidderEncodedSelected);
					returnUrl="etender/buyer/ConvertRfqToAuction";
				}
			}
		}catch(Exception e){
			auditMsg=getPriceBidFormFailAuditMessage;
			return exceptionHandlerService.writeLog(e);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), convertToAuction, auditMsg,tenderId,0);
		}
		return returnUrl;
	}
	
	/**
	 * @author SULABH
	 * @param modelMap
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	
	@RequestMapping(value="/createAuction",method=RequestMethod.POST)
	public String createAuctionFromSealedBid(ModelMap modelMap,HttpServletRequest request,RedirectAttributes redirectAttributes){
		int clientId=0;
		int tenderId=0;
		int createdBy=0;
		int formId=0;
		boolean isSuccess=false;
		String returnUrl="";
		String auditMsg="";
		int isDocRevive=StringUtils.hasLength(request.getParameter("txtIsDocRevive")) ? Integer.parseInt(request.getParameter("txtIsDocRevive")) : 0;
		int isDumpAllItem=StringUtils.hasLength(request.getParameter("txtReviveAllItem")) ? Integer.parseInt(request.getParameter("txtReviveAllItem")) : 0;
		int isAuctionStartPriceSelected=StringUtils.hasLength(request.getParameter("txtisAuctionStartPriceSelected")) ? Integer.parseInt(request.getParameter("txtisAuctionStartPriceSelected")) : 0;
    	int isBidderRankExcluded=StringUtils.hasLength(request.getParameter("txtisBidderRankExcluded")) ? Integer.parseInt(request.getParameter("txtisBidderRankExcluded")) : 0;
    	int isBidderEncodedSelected=StringUtils.hasLength(request.getParameter("txtisBidderEncodedSelected")) ? Integer.parseInt(request.getParameter("txtisBidderEncodedSelected")) : 0;
		try{
			 clientId=abcUtility.getSessionClientId(request);
			 createdBy=abcUtility.getSessionUserId(request);
			 String ipAddress=request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
			 tenderId=request.getParameter("hdTenderId")!=null? Integer.parseInt(request.getParameter("hdTenderId")):0;
			 formId=request.getParameter("rdPriceBidForm")!=null? Integer.parseInt(request.getParameter("rdPriceBidForm")):0;
			 Map<String, Object> list=tenderCommonService.createAuctionFromSealBid(tenderId, formId, clientId, createdBy,ipAddress,isDumpAllItem,isAuctionStartPriceSelected,isBidderRankExcluded,isBidderEncodedSelected);
			 int auctionId=Integer.parseInt(list.get("@V_newAuctionid").toString());
			 if(auctionId!=0){
				 isSuccess=true;
				 auditMsg=createAuctionSuccessAuditMessage;
				 
				//Start :: Code added to dump tender documents to auction
				 List<Object[]> tenderDocs=fileUploadService.getOfficerDocs(tenderId, clientId, uploadTenderDocLinkId, -3);
				 if(!tenderDocs.isEmpty() && isDocRevive==1){
					 String donloadDocPath="";
					 List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(46, clientId); // For auction
		             TblDocUploadConf tblDocUploadConf=lstDocUploadConf.get(0);
		             StringBuilder tmpDirPath=new StringBuilder();
                	 tmpDirPath.append(docUploadPath).append(tblDocUploadConf.getPath());
    	             String fileDir = "";
                    if (tblDocUploadConf.getIsDynamicPath() ==1) {
                         fileDir = String.valueOf(auctionId);
                         donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
                     }else {
                         donloadDocPath=tblDocUploadConf.getPath();
                     }
                     for(int i=tenderDocs.size()-1;i>=0;i--){
                    	 int userId=abcUtility.getSessionUserId(request);
                    	 Object[] data=tenderDocs.get(i);
                    	 TblOfficerDocument tblOfficerDocument = new TblOfficerDocument();
                         tblOfficerDocument.setDocName(data[1].toString());
                         tblOfficerDocument.setTblClient(new TblClient(clientId));
                         tblOfficerDocument.setOfficerFolderId(1);
                         tblOfficerDocument.setPath(donloadDocPath);
                         tblOfficerDocument.setDescription(data[2].toString());
                         tblOfficerDocument.setFileSize((Integer)data[3]);
                         tblOfficerDocument.setCreatedBy(userId);
                         tblOfficerDocument.setCstatus(1);
                         tblOfficerDocument.setIsEncryptionReq(tblDocUploadConf.getIsEncryptionReq());
                         TblOfficerDocMapping tblOfficerDocMapping = new TblOfficerDocMapping();
                         tblOfficerDocMapping.setObjectId(auctionId);
                         tblOfficerDocMapping.setTblLink(new TblLink(documentUpload));
                         tblOfficerDocMapping.setMappedBy(userId);
                         tblOfficerDocMapping.setCstatus(0);
                         tblOfficerDocMapping.setMappedBy(userId);
                         fileUploadService.addOfficerDocument(tblOfficerDocument,tblOfficerDocMapping);
                     }
                     List<TblDocUploadConf> lstDocUploadConfTender = commonService.getDocUploadConf(57, clientId); // For Tender
                     String oldPath=docUploadPath+lstDocUploadConfTender.get(0).getPath()+"\\"+tenderId;
                     String newPath=docUploadPath+tblDocUploadConf.getPath()+"\\"+auctionId;
                     File fp = new File(oldPath);
                     List<File> file = abcUtility.CheckDirLengthForCopy(fp);
                     if(file!=null && !file.isEmpty()){
                         for (File filepath : file) {
                         	if(filepath.exists()){
                         		commonService.copyDirectory(filepath,new File(newPath));
                         	}
                         }
                     }
                     List<Object[]> cancelDoc=fileUploadService.getOfficerDocs(tenderId, clientId, uploadTenderDocLinkId, 3);
                     if(!cancelDoc.isEmpty()){
                     	String cancelDocPath=newPath;
                     	File f=null;
                     	for(Object[] doc : cancelDoc){
                     		f=new File(cancelDocPath+"\\"+doc[1]);
                     		if(f.exists()){
                     			f.delete();
                     		}
                     	}
                     }
				 }
				//End :: Code added to dump tender documents to auction
				 
				 returnUrl ="redirect:/eauction/auctioneer/auctiondashboard/"+auctionId+"/"+1+encryptDecryptUtils.generateRedirect("eauction/auctioneer/auctiondashboard/"+auctionId+"/"+1, request);
			 }else{
				 auditMsg=createAuctionFailAuditMessage;
				 returnUrl ="redirect:/etender/buyer/tenderdashboard/"+tenderId+"/"+1+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/"+1, request);
			 }
		    	redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_create_auction" : CommonKeywords.ERROR_MSG_KEY.toString());
		}catch(Exception e){
			auditMsg=createAuctionFailAuditMessage;
			returnUrl ="redirect:/etender/buyer/tenderdashboard/"+tenderId+"/"+1+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/"+1, request);
			return exceptionHandlerService.writeLog(e);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), convertToAuction, auditMsg,tenderId,0);
		}
		return returnUrl;
	}
	private String isRemarkLinkShowStatus(int tenderId,int envelopeId,int committeeType,int encryptionLevel,int officerId,int orgUserRoleId,int isDecryptor) throws Exception{
		String isRemarkLinkShow = "true";
		int userRoleId = 2;
		if(encryptionLevel==1 || encryptionLevel==0){
			userRoleId = 1;
		}
		int isCPRemarks = 0;
		if(committeeType==2){
			isCPRemarks = orgUserRoleId!=2 ? 1 : 0;
		}
		List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "decryptorRequired,encryptionLevel");
		List<Object[]> remarksList = tenderFormService.getRemarks(tenderId,0,committeeType,envelopeId,userRoleId,isCPRemarks,(Integer) tenderFields.get(0)[0] > 0 && (Integer)tenderFields.get(0)[1] == 2 ? 3 : -1);		
		if(encryptionLevel==0 && remarksList!=null && !remarksList.isEmpty()){
			int remarkGivenCount = remarksList.size();
			int memberCount = tenderFormService.getCommCountMemLevelWise(tenderId,envelopeId,committeeType,2,encryptionLevel,isDecryptor);
				List<Object[]> officerRemarksList = tenderFormService.getRemarks(tenderId,officerId,committeeType,envelopeId,2,orgUserRoleId==1 ? 1 : 0,-1);
				if(officerRemarksList!=null && !officerRemarksList.isEmpty()){
					isRemarkLinkShow = "view";
				}else{
					if(orgUserRoleId==1){
						if(remarkGivenCount==memberCount){
							isRemarkLinkShow = "true";
						}else{
							isRemarkLinkShow = "Remarks from member's is pending";	
						}
					}else{
						isRemarkLinkShow = "true";
					}
				}
		}else{
			if((orgUserRoleId==1) && encryptionLevel==0){//check chairperson that all member remarks are submitted or not - noone is submitted remarks
				List<Object[]> memRemarksList = tenderFormService.getRemarks(tenderId,0,committeeType,envelopeId,orgUserRoleId,0,-1);
				int memberCount = tenderFormService.getCommCountMemLevelWise(tenderId,envelopeId,committeeType,orgUserRoleId+1,encryptionLevel,isDecryptor);
				List<Object[]> officerRemarksList = tenderFormService.getRemarks(tenderId,officerId,committeeType,envelopeId,2,orgUserRoleId==2 ? 1 : 0,-1);
				int remarkGivenCount = memRemarksList.size();
				if(officerRemarksList!=null && !officerRemarksList.isEmpty()){
					isRemarkLinkShow = "view";
				}else{
					if(remarkGivenCount==memberCount){
						isRemarkLinkShow = "true";
					}else{
						if(committeeType==1){
							isRemarkLinkShow = "Remarks from member's is pending";
						}else{
							isRemarkLinkShow = " Evaluation from member is pending";
						}//	"all members remarks pending"
					}
				}
			}else if((orgUserRoleId==1 ||orgUserRoleId==2) && encryptionLevel==1){
				List<Object[]> memRemarksList =null;
				if(orgUserRoleId==2){
					memRemarksList = tenderFormService.getRemarks(tenderId,officerId,committeeType,envelopeId,orgUserRoleId,0,-1);
					if(memRemarksList!=null && !memRemarksList.isEmpty()){
						isRemarkLinkShow = "view";
					}else{
						isRemarkLinkShow = "true";
					}
				}else{
					memRemarksList = tenderFormService.getRemarks(tenderId,0,committeeType,envelopeId,orgUserRoleId,0,-1);
					int memberCount = tenderFormService.getCommCountMemLevelWise(tenderId,envelopeId,committeeType,2,encryptionLevel,isDecryptor);
					int remarkGivenCount = memRemarksList.size();
					if(remarkGivenCount==memberCount){
						List<Object[]> officerRemarksList = new ArrayList<Object[]>();
						if(orgUserRoleId==1){
							officerRemarksList = tenderFormService.getRemarks(tenderId,0,committeeType,envelopeId,2,1,-1);
//						}else{
//							officerRemarksList = tenderFormService.getRemarks(tenderId,0,committeeType,envelopeId,1,0);
						}
						if(officerRemarksList!=null && !officerRemarksList.isEmpty()){
							isRemarkLinkShow = "view";
						}else{
							isRemarkLinkShow = "true";
						}	
					}else{
						if(committeeType==1){
							isRemarkLinkShow = "Remarks from member's is pending";
						}else{
							isRemarkLinkShow = " Evaluation from member is pending";
						}
					}
				}
			}else if(orgUserRoleId==3){
				List<Object[]> officerList = tenderFormService.getRemarks(tenderId,0,committeeType,envelopeId,2,1,-1);
//				int memberCount = tenderFormService.getCommCountMemLevelWise(tenderId,envelopeId,committeeType,2,1,isDecryptor);
				int memberCount = tenderFormService.getCommCountMemLevelWise(tenderId,envelopeId,committeeType,1,1,isDecryptor);//1st level cp remarks count
				int remarkGivenCount = officerList.size();
				if(remarkGivenCount==memberCount){
					List<Object[]> officerRemarksList = tenderFormService.getRemarks(tenderId,officerId,committeeType,envelopeId,orgUserRoleId,0,-1);
					if(officerRemarksList!=null && !officerRemarksList.isEmpty()){
						isRemarkLinkShow = "view";
					}else{
						isRemarkLinkShow = "true";
					}	
				}else{
					if(committeeType==1){
						isRemarkLinkShow = "Remarks from member's is pending";
					}else{
						isRemarkLinkShow = " Evaluation is pending from Level 1";
					}
				}
			}else if(orgUserRoleId==4){
				List<Object[]> memRemarksList = tenderFormService.getRemarks(tenderId,0,committeeType,envelopeId,2,1,-1);
				//int memberCount = tenderFormService.getCommCountMemLevelWise(tenderId,envelopeId,committeeType,2,1,isDecryptor);
				int memberCount = tenderFormService.getCommCountMemLevelWise(tenderId,envelopeId,committeeType,1,1,isDecryptor);
				int remarkGivenCount = memRemarksList.size();
				if(remarkGivenCount==memberCount){
					List<Object[]> officerRemarksList = tenderFormService.getRemarks(tenderId,0,committeeType,envelopeId,3,0,-1);
					memberCount = tenderFormService.getCommCountMemLevelWise(tenderId,envelopeId,committeeType,2,2,isDecryptor);
					remarkGivenCount = officerRemarksList.size();
					if(officerRemarksList!=null && !officerRemarksList.isEmpty() && remarkGivenCount==memberCount){
						List<Object[]> cpRemarks = tenderFormService.getRemarks(tenderId,0,committeeType,envelopeId,orgUserRoleId,1,-1);
						if(cpRemarks!=null && !cpRemarks.isEmpty()){
							isRemarkLinkShow = "view";
						}else{
							isRemarkLinkShow = "true";
						}
					}else{
						if(committeeType==1){
							isRemarkLinkShow = "Remarks from member's is pending";
						}else{
							isRemarkLinkShow = " Evaluation from member is pending";
						}
					}
				}else{
					if(committeeType==1){
						isRemarkLinkShow = "Remarks from member's is pending";
					}else{
						isRemarkLinkShow = " Evaluation is pending from Level 1";
					}
				}
			}
		}
		return isRemarkLinkShow;
	}
	
	private Map<Integer,Boolean> getEvaluationStatus(int tenderId,int committeeType,int officerId) throws Exception {
		List<Object[]> lstEnvelope = tenderFormService.getTenderEnvelopeList(tenderId);
		Map<Integer,Boolean> evalutionLinkMap = new HashMap<Integer, Boolean>();
		int envelopeId = 0;
		for (int i=0 ; i<lstEnvelope.size() ; i++) {
            envelopeId = Integer.parseInt(lstEnvelope.get(i)[2].toString());
            boolean isCPRemarks =  tenderFormService.getCountForCPRemarks(tenderId,envelopeId,1);
            evalutionLinkMap.put(envelopeId, isCPRemarks);
		}
		return evalutionLinkMap;
	}
	
	private Map<Integer, String> isRemarkLinkShowBidderWiseStatus(int tenderId,int envelopeId,int encryptionLevel,int officerId,int orgUserRoleId,List<Integer> bidderIdList,ModelMap modelMap){
		Map<Integer, String> linkMap=new HashMap<Integer, String>();
		List<Integer> evaluatedBidderIds=new ArrayList<Integer>();
		List<Integer> chkOfficeForNextLevel=new ArrayList<Integer>();
		List<Integer> chkEvaluatedOfficeForNextLevel=new ArrayList<Integer>();
		int totalEvaluateCnt = 0;
		evaluatedBidderIds=tenderFormService.getBiddersForShowLink(tenderId,envelopeId,encryptionLevel,officerId,orgUserRoleId);
 		if(orgUserRoleId==1 || orgUserRoleId==2)
		{
			if(evaluatedBidderIds.size()!=0){
				for(int i=0;i<bidderIdList.size();i++){
					if(evaluatedBidderIds.contains(bidderIdList.get(i))){
						linkMap.put(bidderIdList.get(i), "view");
					}else{
						linkMap.put(bidderIdList.get(i), "true");
					}
				}
			}else{
				if(orgUserRoleId==1){
					for(int i=0;i<bidderIdList.size();i++){
						linkMap.put(bidderIdList.get(i), "true");
					}
				}else{
					evaluatedBidderIds.clear();
					evaluatedBidderIds=null;
					evaluatedBidderIds=tenderFormService.getBiddersForShowLink(tenderId,envelopeId,encryptionLevel,0,1);
					chkOfficeForNextLevel = tenderFormService.getCommitteeUserForNextLevel(tenderId,encryptionLevel,envelopeId);//chk for Multiple Member for same level
					chkEvaluatedOfficeForNextLevel = tenderFormService.getEvaluatedOfficeForNextLevel(tenderId,envelopeId,1);//chk for Multiple Member for same level
					totalEvaluateCnt = chkOfficeForNextLevel.size() * bidderIdList.size();
					if(bidderIdList.size()==evaluatedBidderIds.size() && totalEvaluateCnt == chkEvaluatedOfficeForNextLevel.size()){
						for(int i=0;i<bidderIdList.size();i++){
							linkMap.put(bidderIdList.get(i), "true");
						}
					}else{
						linkMap.put(-1, " Evaluation from member is pending");
					}
				}
			}
		}else{
 			if(orgUserRoleId==3){
 				if(evaluatedBidderIds.size()!=0){
 					for(int i=0;i<bidderIdList.size();i++){
 						if(evaluatedBidderIds.contains(Integer.parseInt(bidderIdList.get(i).toString()))){
 							linkMap.put(bidderIdList.get(i), "view");
 						}else{
 							linkMap.put(bidderIdList.get(i), "true");
 						}
 					}
 				}else{
 					evaluatedBidderIds.clear();
					evaluatedBidderIds=null;
					evaluatedBidderIds=tenderFormService.getBiddersForShowLink(tenderId,envelopeId,encryptionLevel,0,2);
					if(bidderIdList.size()==evaluatedBidderIds.size()){
						for(int i=0;i<bidderIdList.size();i++){
							linkMap.put(bidderIdList.get(i), "true");
						}
					}else{
						linkMap.put(-1, " Evaluation is pending from Level 1");
					}
 				}
			}else{
 				if(evaluatedBidderIds.size()!=0){
 					for(int i=0;i<bidderIdList.size();i++){
 						if(evaluatedBidderIds.contains(Integer.parseInt(bidderIdList.get(i).toString()))){
 							linkMap.put(bidderIdList.get(i), "view");
 						}else{
 							linkMap.put(bidderIdList.get(i), "true");
 						}
 					}
 				}else{
 					evaluatedBidderIds.clear();
					evaluatedBidderIds=null;
					evaluatedBidderIds=tenderFormService.getBiddersForShowLink(tenderId,envelopeId,encryptionLevel,0,3);
					chkOfficeForNextLevel = tenderFormService.getCommitteeUserForNextLevel(tenderId,encryptionLevel,envelopeId);
					chkEvaluatedOfficeForNextLevel = tenderFormService.getEvaluatedOfficeForNextLevel(tenderId,envelopeId,3);
					totalEvaluateCnt = chkOfficeForNextLevel.size() * bidderIdList.size();
					if(bidderIdList.size()==evaluatedBidderIds.size() && totalEvaluateCnt == chkEvaluatedOfficeForNextLevel.size()){
						for(int i=0;i<bidderIdList.size();i++){
							linkMap.put(bidderIdList.get(i), "true");
						}
					}else{
						if(evaluatedBidderIds.size()!=0){
							linkMap.put(-1, " Evaluation from member is pending");
						}else{
							evaluatedBidderIds.clear();
							evaluatedBidderIds=null;
							evaluatedBidderIds=tenderFormService.getBiddersForShowLink(tenderId,envelopeId,encryptionLevel,0,2);
							chkOfficeForNextLevel.clear();chkEvaluatedOfficeForNextLevel.clear();
							chkOfficeForNextLevel=null;chkEvaluatedOfficeForNextLevel=null;
							chkOfficeForNextLevel = tenderFormService.getCommitteeUserForNextLevel(tenderId,encryptionLevel,envelopeId);
							chkEvaluatedOfficeForNextLevel = tenderFormService.getEvaluatedOfficeForNextLevel(tenderId,envelopeId,1);
							totalEvaluateCnt = chkOfficeForNextLevel.size() * bidderIdList.size();
							if(bidderIdList.size()==evaluatedBidderIds.size() && totalEvaluateCnt == chkEvaluatedOfficeForNextLevel.size()){
								linkMap.put(-1, " Evaluation from member is pending");
							}else{
								linkMap.put(-1, " Evaluation is pending from Level 1");
							}
						}
					}
 				}
 			}
 		}
 		 modelMap.put("BidderWiseLink", linkMap);
 		 return linkMap;
	}
	private Map<Integer,String> getUserRoleStatus(int tenderId,int committeeType,int officerId,ModelMap modelMap) throws Exception {
  		int envelopeId = 0;
  		int encryptionLevel=0;
		int userRoleId=0;
		int isDecryptor= 0 ;
		String isLinkShow = "false";
		int orgUserRoleId = 0;
		int envId=0;
		int tenderResult = (Integer) modelMap.get("tenderResult");
		Map<Integer,String> openingLinkMap = new HashMap<Integer, String>();
		boolean isOnlyOneEnvelop = tenderFormService.isOnlyOneEnvelopBuTenderId(tenderId);
		List<Integer> rejectdBidder=new ArrayList<Integer>();
		List<Object[]> evaluatedEvlopeData=new ArrayList<Object[]>();
		if(isOnlyOneEnvelop){
			evaluatedEvlopeData=tenderFormService.getBidderIdForOnlyOneEnvelop(tenderId);
		}else{
			evaluatedEvlopeData=tenderFormService.getApprovalDetlsOfTechnicalEnvlop(tenderId,0,0,0);
		}
		int evaluatedEnvlope =0;
		int tenderEncryptionLevel = (Integer) modelMap.get("encryptionLevel");
        Map<Integer, String> linkMap=new HashMap<Integer, String>();
  		List<Object[]> lstEnvelope = tenderFormService.getTenderEnvelopeList(tenderId);
        for (int i=0 ; i<lstEnvelope.size() ; i++) {
        	envId = Integer.parseInt(lstEnvelope.get(i)[0].toString());
            envelopeId = Integer.parseInt(lstEnvelope.get(i)[2].toString());
            List<Object[]> userRoleList=tenderFormService.getUserRoleId(tenderId,envelopeId,committeeType,officerId);
            if(userRoleList!=null && !userRoleList.isEmpty()){
	            encryptionLevel = Integer.parseInt(userRoleList.get(0)[1].toString());
	        	userRoleId = Integer.parseInt(userRoleList.get(0)[0].toString());
	        	isDecryptor = Integer.parseInt(userRoleList.get(0)[3].toString());
	        	if(committeeType == 1 && tenderEncryptionLevel == 2 && isDecryptor == 0){
	        		isDecryptor = 1;//Decryptor is set as per client configuration(CR-28398)
	        	}
            }
        	//0 for Not Set, 1 for Grand Total, 2 for Itemwise,3 for Lotwise
            if(committeeType == 2 && (envId==4 || envId==5)){
            	if(encryptionLevel==0){
            		orgUserRoleId=userRoleId == 1 ? 2 : 1;
            	}else if(encryptionLevel==1){
                	orgUserRoleId=userRoleId == 1 ? 2 : 1;
                }else{
                	orgUserRoleId=userRoleId == 1 ? 4 : 3;
                }
            	List<Integer> bidderIdList=new ArrayList<Integer>();
            	for (int j=0;j<evaluatedEvlopeData.size();j++) {
            		if(Integer.parseInt(evaluatedEvlopeData.get(j)[1].toString())==1){
            			isLinkShow = "true";//in one envelope if opening remarks done then show "Evaluate Bidder" link
            			bidderIdList.add(Integer.parseInt(evaluatedEvlopeData.get(j)[0].toString()));
            		}
            		else{
            			if((Integer) modelMap.get("envelopeType")==1 && Integer.parseInt(evaluatedEvlopeData.get(j)[1].toString())!=3){
            				bidderIdList.add(Integer.parseInt(evaluatedEvlopeData.get(j)[0].toString()));
            				isLinkShow = "true";
            			}
            			rejectdBidder.add(Integer.parseInt(evaluatedEvlopeData.get(j)[0].toString()));
            		}
        		}
            	linkMap=isRemarkLinkShowBidderWiseStatus(tenderId,envelopeId,encryptionLevel,officerId,orgUserRoleId,bidderIdList,modelMap);
            	if (tenderResult == 1){
            		if((Integer) modelMap.get("envelopeType")==1)
            			evaluatedEnvlope = evaluatedEvlopeData.size();
            		else 
            			evaluatedEnvlope = bidderIdList.size();
            		
            		List<Object> lstBidderEvaluted = tenderFormService.getTenderEvaluatedBidders(envelopeId,officerId);
            		if(lstBidderEvaluted.size() == evaluatedEnvlope){
            			modelMap.put("priceEnvEvaluted", true);
            		}else{
            			modelMap.put("priceEnvEvaluted", false);
            		}
            	}
            }
            else{
            	 if(userRoleList!=null && !userRoleList.isEmpty()){
            		 if(isDecryptor==1){
            			 encryptionLevel = 0; 
            		 }
                 	if(encryptionLevel==0){
                 		if(userRoleId==2){
                 			orgUserRoleId = userRoleId;
                 			isLinkShow = isRemarkLinkShowStatus(tenderId,envelopeId,committeeType,encryptionLevel,officerId,orgUserRoleId,isDecryptor);
                 		}else if(userRoleId==1){
                 			orgUserRoleId = userRoleId;
                 			isLinkShow = isRemarkLinkShowStatus(tenderId,envelopeId,committeeType,encryptionLevel,officerId,orgUserRoleId,isDecryptor);
                 		}
                 	}else if(encryptionLevel!=0){
         				if(encryptionLevel==1 && userRoleId==2){//member - level 1
         					orgUserRoleId = userRoleId;
         					isLinkShow = isRemarkLinkShowStatus(tenderId,envelopeId,committeeType,encryptionLevel,officerId,orgUserRoleId,isDecryptor);
         				}else if(encryptionLevel==1 && userRoleId==1){//chairperson - level 1
         					orgUserRoleId = userRoleId;
         					isLinkShow = isRemarkLinkShowStatus(tenderId,envelopeId,committeeType,encryptionLevel,officerId,orgUserRoleId,isDecryptor);
         				}else if(encryptionLevel==2 && userRoleId==2){//member - level 2
         					orgUserRoleId = userRoleId;
         					isLinkShow = isRemarkLinkShowStatus(tenderId,envelopeId,committeeType,encryptionLevel,officerId,3,isDecryptor);
         				}else if(encryptionLevel==2 && userRoleId==1){//chairperson - level 2
         					orgUserRoleId = userRoleId;
         					isLinkShow = isRemarkLinkShowStatus(tenderId,envelopeId,committeeType,encryptionLevel,officerId,4,isDecryptor);
         				}
                 	}
                 }
            }
            if(linkMap.containsKey(-1)){
            	 openingLinkMap.put(envelopeId, linkMap.get(-1));
            }else{
            	 openingLinkMap.put(envelopeId, isLinkShow);
            }
            modelMap.put("rejectedBidder", rejectdBidder);
            modelMap.put("evaluatedTechnicalEvlopeData", evaluatedEvlopeData);
        }
  	  return openingLinkMap;
     }
	
	@RequestMapping(value = "isGeneratedL1Report", method = RequestMethod.POST)
    @ResponseBody
    public String isGeneratedL1Report(@RequestParam("tenderId") int tenderId,HttpServletRequest request) {
        String resultString = null;
        try {
        	resultString = String.valueOf(tenderCommonService.isL1H1Generated(tenderId));        	
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }        
        return resultString;
    }
}

