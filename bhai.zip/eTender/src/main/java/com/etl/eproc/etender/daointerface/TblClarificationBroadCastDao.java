package com.etl.eproc.etender.daointerface;

/**
* @author Lipi Shah
*/

import java.util.List;


import com.etl.eproc.etender.model.TblClarificationBroadCast;

public interface TblClarificationBroadCastDao  {

    public void addTblClarificationBroadCast(TblClarificationBroadCast tblClarificationBroadCast);

    public void deleteTblClarificationBroadCast(TblClarificationBroadCast tblClarificationBroadCast);

    public void updateTblClarificationBroadCast(TblClarificationBroadCast tblClarificationBroadCast);

    public List<TblClarificationBroadCast> getAllTblClarificationBroadCast();

    public List<TblClarificationBroadCast> findTblClarificationBroadCast(Object... values) throws Exception;

    public List<TblClarificationBroadCast> findByCountTblClarificationBroadCast(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClarificationBroadCastCount();

    public void saveUpdateAllTblClarificationBroadCast(List<TblClarificationBroadCast> tblClarificationBroadCasts);
}