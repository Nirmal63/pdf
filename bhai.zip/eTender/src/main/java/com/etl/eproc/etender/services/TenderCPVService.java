package com.etl.eproc.etender.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.etender.daointerface.TblTenderBidderCPVDao;
import com.etl.eproc.etender.daointerface.TblTenderCPVDao;
import com.etl.eproc.etender.daointerface.TblTenderDao;
import com.etl.eproc.etender.model.TblTenderBidderCPV;
import com.etl.eproc.etender.model.TblTenderCPV;

/**
 * 
 * @author Priyanka
 *
 */
@Service
public class TenderCPVService {

	@Autowired
	private HibernateQueryDao hibernateQueryDao;
	@Autowired
	private TblTenderCPVDao tblTenderCPVImpl;
	@Autowired
	private TblTenderBidderCPVDao tblTenderBidderCPVImpl;
	@Autowired
	private JdbcTemplate jdbcTemplate;
	@Autowired
	private TblTenderDao tblTenderDao;

	private static final String TENDERID = "tenderId";

		/**
	 * This method return rowIds with keyword of particular tender 
	 * @author Priyanka
	 * @param tenderId
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> getTenderIdTblTenderCPV(int tenderId) throws Exception {
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("tenderId", tenderId);
		StringBuilder query = new StringBuilder();	
		query.append("select tbltendercpv.tenderCpvId, tbltendercpv.tblTender.tenderId, tbltendercpv.keyword from TblTenderCPV tbltendercpv where tblTender.tenderId=:tenderId order by tbltendercpv.tenderCpvId ");
		return hibernateQueryDao.createNewQuery(query.toString(), var);
	}

	/**
	 * @author priyanka
	 * @param tblTenderCPVLst
	 * @param tblTenderBidderCPVList
	 * @return
	 * @throws Exception
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
	public boolean addCPVCode(List<TblTenderCPV> tblTenderCPVLst,List<TblTenderBidderCPV> tblTenderBidderCPVList,int tenderId,int operation) throws Exception{
		 if(operation==1){
			 if(deleteTenderCPVCode(tenderId)){
				 deleteTenderBidderCPVCode(tenderId);
			 }
		 }else if(operation==0){
		 tblTenderCPVImpl.saveUpdateAllTblTenderCPV(tblTenderCPVLst);
		 tblTenderBidderCPVImpl.saveUpdateAllTblTenderBidderCPV(tblTenderBidderCPVList);
		 }
		 return true;
	}
	
	/**
	 * @author priyanka
	 * @param tenderId
	 * @return
	 * @throws Exception
	 */
	public boolean deleteTenderCPVCode(int tenderId)throws Exception{
	
		 boolean bSuccess = false;
	        StringBuilder delTenderCPV = new StringBuilder();
	        Map<String, Object> parameters = new HashMap<String, Object>();
	        parameters.put(TENDERID, tenderId);
	        delTenderCPV.append("Delete from TblTenderCPV where tblTender.tenderId=:tenderId");
	        int i = hibernateQueryDao.updateDeleteNewQuery(delTenderCPV.toString(), parameters);
	        if (i > 0) {
	            bSuccess = true;
	        }
	        return bSuccess;
	}	
	
	/**
	 * @author priyanka
	 * @param tenderId
	 * @return
	 * @throws Exception
	 */
	public boolean deleteTenderBidderCPVCode(int tenderId)throws Exception{
		
		 boolean bSuccess = false;
	        StringBuilder delTenderBidderCPV=new StringBuilder();
	        Map<String, Object> parameters = new HashMap<String, Object>();
	        parameters.put(TENDERID, tenderId);
	        delTenderBidderCPV.append("Delete from TblTenderBidderCPV where tenderId=:tenderId");
	        int i = hibernateQueryDao.updateDeleteNewQuery(delTenderBidderCPV.toString(), parameters);
	        if (i > 0) {
	            bSuccess = true;
	        }
	        return bSuccess;
	}
	
	/**
	 * 
     * @author Priyanka
     * @param tenderId
     * @param domainName
     * @return
     * @throws Exception
     */
    public List<Object []> gettenderIdToSaveTenderCPVCode(int tenderId,String domainName, int deptId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();     
        var.put("domainName",domainName);
        var.put("deptId",deptId);
        StringBuilder query = new StringBuilder();
        query.append("select tbltender.tenderId,tbltender.tenderId from TblTender tbltender ");       
        query.append("inner join tbltender.tblFinalSubmission tblfinalsubmission  ");
        query.append("inner join tbltender.tblDepartment tbldepartment ");
        query.append("inner join tbldepartment.tblClient tblclient ");
        query.append("left join tbltender.tblTenderCPV tbltendercpv ");
        query.append("where tbltendercpv.tblTender.tenderId IS NULL and tbltender.isDemoTender=0  ");
        query.append("and tblclient.domainName=:domainName and tbldepartment.deptId=:deptId ");
        query.append("ORDER BY tblclient.domainName ASC , tbldepartment.deptName ASC, tbltender.tenderId DESC");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    /*PT #38423*/
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
	public boolean addClassificationKeywords(List<TblTenderCPV> tblTenderCPVLst) throws Exception{
    	tblTenderCPVImpl.saveUpdateAllTblTenderCPV(tblTenderCPVLst);
		 return true;
	}
}
