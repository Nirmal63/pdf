/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblRebateDetailDao;
import com.etl.eproc.etender.model.TblRebateDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblRebateDetailImpl extends AbcAbstractClass<TblRebateDetail> implements TblRebateDetailDao {


    @Override
    public void addTblRebateDetail(TblRebateDetail tblRebateDetail) {
        super.addEntity(tblRebateDetail);
    }

    @Override
    public void deleteTblRebateDetail(TblRebateDetail tblRebateDetail) {
        super.deleteEntity(tblRebateDetail);
    }

    @Override
    public void updateTblRebateDetail(TblRebateDetail tblRebateDetail) {
        super.updateEntity(tblRebateDetail);
    }

    @Override
    public List<TblRebateDetail> getAllTblRebateDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblRebateDetail> findTblRebateDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblRebateDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblRebateDetail> findByCountTblRebateDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblRebateDetail(List<TblRebateDetail> tblRebateDetails) {
        super.updateAll(tblRebateDetails);
    }
}
