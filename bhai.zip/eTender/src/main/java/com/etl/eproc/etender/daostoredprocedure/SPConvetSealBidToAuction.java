package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 * To convert SealedBid to Auction
 * @author SULABH
 */

@Component
public class SPConvetSealBidToAuction extends StoredProcedure{

	@Autowired
	@Qualifier("dataSource")
	
	public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
	
	private static final String SPROC_NAME = "appauction.P_ConvertToAuction";
	public SPConvetSealBidToAuction() {
		super.setSql(SPROC_NAME);
		this.declareParameter(new SqlParameter("@V_oldTenderId", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_CreatedBy", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_clientId", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_tenderFormId", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_ClientIp", Types.VARCHAR));
		this.declareParameter(new SqlOutParameter("@V_newAuctionid", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_isDumpAllItems", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_isBidderEncodedSelected", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_isBidderRankExcluded", Types.INTEGER));
		this.declareParameter(new SqlParameter("@V_isAuctionStartPriceSelected", Types.INTEGER));
		
	}
	
	public Map<String, Object> executeStoredProcedure(int tenderId,int formId,int clientId,int createdBy,String ipAddress,int isDumpAllItem,int isAuctionStartPriceSelected,int isBidderRankExcluded,int isBidderEncodedSelected)throws Exception {
		Map<String, Object> inParams=new HashMap<String, Object>();
		inParams.put("@V_oldTenderId", tenderId);
		inParams.put("@V_CreatedBy", createdBy);
 		inParams.put("@V_clientId", clientId);
		inParams.put("@V_tenderFormId", formId);
		inParams.put("@V_ClientIp", ipAddress);
		inParams.put("@V_isDumpAllItems", isDumpAllItem);
		inParams.put("@V_isBidderEncodedSelected", isBidderEncodedSelected);
		inParams.put("@V_isBidderRankExcluded", isBidderRankExcluded);
		inParams.put("@V_isAuctionStartPriceSelected", isAuctionStartPriceSelected);
		
		this.compile();
		return execute(inParams);
	}
}
