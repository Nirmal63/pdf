package com.etl.eproc.etender.databean;

import java.util.List;

import com.etl.eproc.common.utility.SelectItem;

public class TenderGoverningColumnDtBean {
	
	private String formId;
	private String formName;
	private List<String> tableName;
	private List<String> selectedValList;
	private List<List<SelectItem>> govCols;
	public String getFormId() {
		return formId;
	}
	public void setFormId(String formId) {
		this.formId = formId;
	}
	public String getFormName() {
		return formName;
	}
	public void setFormName(String formName) {
		this.formName = formName;
	}
	public List<String> getTableName() {
		return tableName;
	}
	public void setTableName(List<String> tableName) {
		this.tableName = tableName;
	}
	public List<List<SelectItem>> getGovCols() {
		return govCols;
	}
	public void setGovCols(List<List<SelectItem>> govCols) {
		this.govCols = govCols;
	}
	public List<String> getSelectedValList() {
		return selectedValList;
	}
	public void setSelectedValList(List<String> selectedValList) {
		this.selectedValList = selectedValList;
	}
	
}
