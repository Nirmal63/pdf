package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

@Component
public class SPManageMaterialMaster extends StoredProcedure{
	
	@Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    
    private static final String SPROC_NAME = "appsap.P_ManageMaterial";

	public SPManageMaterialMaster() {
		super.setSql(SPROC_NAME);
		
		this.declareParameter(new SqlParameter("@V_Plant", Types.NVARCHAR));
        this.declareParameter(new SqlParameter("@V_industrialSector", Types.NVARCHAR));
        this.declareParameter(new SqlParameter("@V_materialType", Types.NVARCHAR));
        this.declareParameter(new SqlParameter("@V_ItemCategory", Types.NVARCHAR));
        this.declareParameter(new SqlParameter("@V_PurchasingGroup", Types.NVARCHAR)); 
        this.declareParameter(new SqlParameter("@V_MaterialNumber", Types.NVARCHAR));
        this.declareParameter(new SqlParameter("@V_RecordsPerPage", Types.INTEGER)); 
        this.declareParameter(new SqlParameter("@V_PageNo", Types.INTEGER)); 
       
	}
	 public Map<String,Object> executeProcedure(String industrialSector,String materialType ,String plant ,String itemCategory,String purchGrp,String materialNumber,int recordsPerPage,int pageNo) throws Exception {
	        Map<String, Object> inParams = new HashMap<String, Object>();
	        inParams.put("@V_Plant", plant);
	        inParams.put("@V_industrialSector", industrialSector);
	        inParams.put("@V_materialType", materialType);
	        inParams.put("@V_ItemCategory", itemCategory);
	        inParams.put("@V_PurchasingGroup", purchGrp);
	        inParams.put("@V_MaterialNumber", materialNumber);
	        inParams.put("@V_RecordsPerPage", recordsPerPage);
	        inParams.put("@V_PageNo", pageNo);
	        	        
	        this.compile();
	        return execute(inParams);
	    }


}
