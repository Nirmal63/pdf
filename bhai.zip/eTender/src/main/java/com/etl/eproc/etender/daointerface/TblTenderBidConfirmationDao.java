package com.etl.eproc.etender.daointerface;

import java.util.List;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderBidRegression;
import com.etl.eproc.etender.model.TblTenderBidConfirmation;

public interface TblTenderBidConfirmationDao  {

    public void addTblTenderBidConfirmation(TblTenderBidConfirmation tblTenderBidConfirmation);

    public void deleteTblTenderBidConfirmation(TblTenderBidConfirmation tblTenderBidConfirmation);

    public void updateTblTenderBidConfirmation(TblTenderBidConfirmation tblTenderBidConfirmation);

    public List<TblTenderBidConfirmation> getAllTblTenderBidConfirmation();

    public List<TblTenderBidConfirmation> findTblTenderBidConfirmation(Object... values) throws Exception;

    public List<TblTenderBidConfirmation> findByCountTblTenderBidConfirmation(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderBidConfirmationCount();

    public void saveUpdateAllTblTenderBidConfirmation(List<TblTenderBidConfirmation> tblTenderBidConfirmations);
    
   // public void addTblTenderRegretBidConfirmation(TblTenderBidRegression tblTenderBidRegression);
}