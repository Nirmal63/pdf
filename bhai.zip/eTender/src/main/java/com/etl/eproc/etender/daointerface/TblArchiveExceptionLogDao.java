package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblArchiveExceptionLog;
import java.util.List;

public interface TblArchiveExceptionLogDao  {

    public void addTblArchiveExceptionLog(TblArchiveExceptionLog tblArchiveExceptionLog);

    public void deleteTblArchiveExceptionLog(TblArchiveExceptionLog tblArchiveExceptionLog);

    public void updateTblArchiveExceptionLog(TblArchiveExceptionLog tblArchiveExceptionLog);

    public List<TblArchiveExceptionLog> getAllTblArchiveExceptionLog();

    public List<TblArchiveExceptionLog> findTblArchiveExceptionLog(Object... values) throws Exception;

    public List<TblArchiveExceptionLog> findByCountTblArchiveExceptionLog(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblArchiveExceptionLogCount();

    public void saveUpdateAllTblArchiveExceptionLog(List<TblArchiveExceptionLog> tblArchiveExceptionLogs);
    
/*  public void saveOrUpdateTblArchiveExceptionLog(TblArchiveExceptionLog tblArchiveExceptionLog); */
}