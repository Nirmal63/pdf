/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.advertise.daointerface.TblAdvertiseDao;
import com.etl.eproc.advertise.daointerface.TblAdvertiseDetailDao;
import com.etl.eproc.advertise.daointerface.TblAdvertiseTenderMapDao;
import com.etl.eproc.advertise.model.TblAdvertise;
import com.etl.eproc.advertise.model.TblAdvertiseDetail;
import com.etl.eproc.advertise.model.TblAdvertiseTenderMap;
import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.etender.daointerface.TblCorrigendumDao;
import com.etl.eproc.etender.daointerface.TblCorrigendumDetailDao;
import com.etl.eproc.etender.model.TblCorrigendum;
import com.etl.eproc.etender.model.TblCorrigendumDetail;

/**
 *
 * @author hiral
 */
@Service
public class AdvertiseService {
    @Autowired
    private HibernateQueryDao hibernateQueryDao;    
    @Autowired
    private TblAdvertiseTenderMapDao tblAdvertiseTenderMapDao;
    @Autowired
    private TblAdvertiseDao tblAdvertiseDao;
    @Autowired
    private TblAdvertiseDetailDao tblAdvertiseDetailDao;
    @Autowired
    private TblCorrigendumDao tblCorrigendumDao;
    @Autowired
    private TblCorrigendumDetailDao tblCorrigendumDetailDao;

    /**
     * author : heeral.soni
     * @param tblAdvertise
     * @param tblAdvertiseTenderMap
     * used to insert data for advertise
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addAdvertise(TblAdvertise tblAdvertise,List<TblAdvertiseTenderMap> tblAdvertiseTenderMap,int advertiseId) throws Exception{
        boolean bSuccess = false;             
        tblAdvertiseDao.saveOrUpdateTblAdvertise(tblAdvertise);
        if(advertiseId!=0){
            deleteTblAdvertiseTenderMap(advertiseId);
        }else{
            updateAdvertiseNo(tblAdvertise.getAdvertiseId());
        }
        tblAdvertiseTenderMapDao.saveUpdateAllTblAdvertiseTenderMap(tblAdvertiseTenderMap);
        bSuccess=true;        
        return bSuccess;
    }
    
	/**
	 * @author mitesh
	 * @param advertiseId
	 * @return
	 * @throws Exception
	 */
	public  TblAdvertise getAdvertiseDetailId(int advertiseId) throws Exception{
	       List<TblAdvertise> list = null;     
	       list = tblAdvertiseDao.findTblAdvertise("advertiseId",Operation_enum.EQ,advertiseId);                
	       return list != null && !list.isEmpty() ? list.get(0) : null;
	   }
	
	/**
     * @author mitesh
     * @param advertiseId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getAdvertiseDates(int advertiseId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("advertiseId",advertiseId);
        list = hibernateQueryDao.createNewQuery("select tbladvertisetendermap.tblTender.tenderId, tbladvertise.documentStartDate," +
        		" tbladvertise.documentEndDate, tbladvertise.submissionEndDate, tbladvertise.openingDate,tbladvertise.corrigendumText, tbladvertise.submissionStartDate" +
        		" from TblAdvertise tbladvertise inner join tbladvertise.tblAdvertiseTenderMap tbladvertisetendermap where tbladvertisetendermap.tblAdvertise.advertiseId=:advertiseId",var);                
        return list;        

    }
   
  /**
   * @author mitesh
   * @param advertiseId
   * @param tenderIds
   * @param documentStartDate
   * @param documentEndDate
   * @param submissionEndDate
   * @param openingDate
   * @param isExtended
   * @param tblAdvertiseDetails
   * @param tblcorrigendumsList
   * @param tblCorrigendumDetailsList
   * @return
   * @throws Exception
   */
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
    public boolean publishAdvertise(int advertiseId,Object[] tenderIds,String documentStartDate,String documentEndDate,String submissionStartDate,String submissionEndDate,String openingDate,int isExtended,List<TblAdvertiseDetail> tblAdvertiseDetails,List<TblCorrigendum> tblcorrigendumsList,List<TblCorrigendumDetail> tblCorrigendumDetailsList,int publishedBy) throws Exception{
    	//1) insert the advertise details.
    	tblAdvertiseDetailDao.saveUpdateAllTblAdvertiseDetail(tblAdvertiseDetails);
    	//2) update the cstatus
    	int result = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("advertiseId", advertiseId);
       /* var.put("publishedOn", publishedOn);*/
        var.put("publishedBy", publishedBy);
        var.put("cstatus", 1);
    	StringBuffer query=new StringBuffer();
    	query.append("update TblAdvertise tblAdvertise set ");
    	query.append("tblAdvertise.cstatus=:cstatus,tblAdvertise.publishedOn=getUTCDate(),tblAdvertise.publishedBy=:publishedBy ");
    	query.append("where tblAdvertise.advertiseId=:advertiseId and tblAdvertise.cstatus=0");
    	  
        result = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
        //3) if isExtended is 0 then update date in tender only.
        if(result!=0){
            if(isExtended==0){
        	var = new HashMap<String, Object>();
                var.put("tenderIds", tenderIds);
                var.put("documentStartDate", documentStartDate);
                var.put("documentEndDate", documentEndDate);
                var.put("submissionEndDate", submissionEndDate);
                var.put("openingDate", openingDate);
                var.put("submissionStartDate", submissionStartDate);
                query = new StringBuffer();
                query.append("update TblTender Tbltender set ");
                query.append("Tbltender.documentStartDate=:documentStartDate,Tbltender.documentEndDate=:documentEndDate,Tbltender.submissionEndDate=:submissionEndDate,Tbltender.openingDate=:openingDate,Tbltender.submissionStartDate=:submissionStartDate ");
                query.append("where Tbltender.tenderId in (:tenderIds)");           
                result = hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);            
            }else{//4) if isExtended is 1 then insert into tbl_Corrigendum & tbl_CorrigendumDetail
        	tblCorrigendumDao.saveUpdateAllTblCorrigendum(tblcorrigendumsList);
        	tblCorrigendumDetailDao.saveUpdateAllTblCorrigendumDetail(tblCorrigendumDetailsList);
            }
        }        
        return result!=0;
     }

    /**
     * 
     * @param tenderIds
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderDates(Object[] tenderIds) throws Exception{
     	 List<Object[]> list = null;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderIds",tenderIds);
         list = hibernateQueryDao.createNewQuery("select tbltender.tenderId,tbltender.documentEndDate, tbltender.submissionEndDate, tbltender.openingDate,tbltender.submissionStartDate from TblTender tbltender where tbltender.tenderId in (:tenderIds)",var);                
         return list != null && !list.isEmpty() ? list : null;   
    }
     /**
     * 
     * @param clientId
     * @return
     * @throws Exception 
     */
    /*public String getAdvertiseNo(int clientId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
//        var.put("clientId",clientId);
        String advertiseNo="";
        List<Object> list = hibernateQueryDao.getSingleColQuery("select ISNULL(MAX(tbladvertise.advertiseId),0) from TblAdvertise tbladvertise",var);                
        if(!list.isEmpty()){
            advertiseNo="ADV"+((Integer)list.get(0)+1);
        }
        return advertiseNo;
    }*/

    /**
     * author : heeral.soni
     * used to get advertise type
     * @return List<SelectItem>
     */
    public List<SelectItem> getAdvertiseType() throws Exception {
        List<SelectItem> advertiseTypeList = new ArrayList<SelectItem>();
        advertiseTypeList.add(new SelectItem("Main", "1"));
        advertiseTypeList.add(new SelectItem("Ward", "2"));
        return advertiseTypeList;
    }
    
    /**
     * @author dipika
     *  get list of TblAdvertise data
     * @return List<Object[]>
     * @throws Exception
     */
    public List<TblAdvertiseDetail> getAdvertiseDetails(int advertiseId) throws Exception {
        List<TblAdvertiseDetail> list = null;
        list=tblAdvertiseDetailDao.findTblAdvertiseDetail("tblAdvertise.advertiseId",Operation_enum.EQ,advertiseId);
        return list;
    }
    
    /**
     * @author dipika
     *  get list of TblAdvertiseTenderMap data
     * @return List<Object[]>
     * @throws Exception
     */
    public List<Object[]> getAdvertiseTenderMapDetails(int advertiseId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("advertiseId", advertiseId);
        
        StringBuffer query=new StringBuffer();
        query.append("select  tblAdvertisetendermap.tblTender.tenderId,tblAdvertisetendermap.tblTender.tenderNo,tblAdvertisetendermap.tblTender.tblDepartment.deptName,tblAdvertisetendermap.tblTender.tenderBrief ");
        query.append(" ,tblAdvertisetendermap.tblTender.documentFee,tblAdvertisetendermap.tblTender.tenderValue,tblAdvertisetendermap.tblTender.emdAmount,tblAdvertisetendermap.tblTender.projectDuration,tblAdvertisetendermap.tblTender.decimalValueUpto");
        query.append(" from TblAdvertiseTenderMap tblAdvertisetendermap");
        query.append(" where tblAdvertisetendermap.tblAdvertise.advertiseId=:advertiseId ");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);
        return list;
    }
     /**
     * author : heeral.soni
     * used to delee data from TblAdvertiseTenderMap
     * @return
     * @throws Exception 
     */
     public boolean deleteTblAdvertiseTenderMap(int advertiseId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("advertiseId",advertiseId);
        int cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblAdvertiseTenderMap tbladvertisetendermap where tbladvertisetendermap.tblAdvertise.advertiseId=:advertiseId",var);        
        return cnt!=0;
    }
     
     /**
     * author : heeral.soni
     * used to update advertise NO after successfull insert
     * @return
     * @throws Exception 
     */
     public boolean updateAdvertiseNo(int advertiseId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("advertiseNo","ADV"+advertiseId);
        var.put("advertiseId",advertiseId);
        int cnt = hibernateQueryDao.updateDeleteNewQuery("update TblAdvertise set advertiseNo=:advertiseNo where advertiseId=:advertiseId",var);        
        return cnt!=0;
    }
     
     
     /**
      * @author nirav.prajapati
      * @return List<Object[]>
      * @throws Exception
      */
     public List<Object[]> getAdvertiseByTender(int tenderId) throws Exception {
         List<Object[]> list = null;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId", tenderId);
         StringBuffer query=new StringBuffer();
         query.append("select tblAdvertise.advertiseId,tblAdvertise.advertiseNo,tblAdvertise.advertiseType,tblAdvertise.corrigendumText,tblAdvertise.documentStartDate, ");
         query.append(" tblAdvertise.documentEndDate,tblAdvertise.openingDate,tblAdvertise.submissionEndDate,tblAdvertise.isExtended ");
         query.append(" from TblAdvertiseTenderMap tblAdvertiseTenderMap inner join tblAdvertiseTenderMap.tblAdvertise tblAdvertise");
         query.append(" where tblAdvertiseTenderMap.tblTender.tenderId=:tenderId and tblAdvertise.cstatus = 1 order by tblAdvertise.createdOn ");
         list = hibernateQueryDao.createNewQuery(query.toString(),var);
         return list;
     }
     
     

     /**
      * @author nirav.prajapati
      * @return List<Object[]>
      * @throws Exception
      */
     public List<Object[]> getAdvertiseByAdvertiseIds(String advertiseIds) throws Exception {
         List<Object[]> list = null;
         Map<String, Object> var = new HashMap<String, Object>();
         StringBuffer query=new StringBuffer();
         query.append("select tblAdvertise.advertiseId,tblAdvertiseDetail.paperName,tblAdvertiseDetail.advertiseDate,tblAdvertiseDetail.advertiseNo");
         query.append(" from TblAdvertiseDetail tblAdvertiseDetail");
         query.append(" where tblAdvertise.advertiseId in (").append(advertiseIds).append(") order by tblAdvertise.createdOn ");
         list = hibernateQueryDao.createNewQuery(query.toString(),var);
         return list;
     }

     
     /**
      * @author Nikhil jani CR :24795
      * Method Overridden by Nikhil jani
      * TO get tenders mapped with Particular AdvertisementIds
      *  get list of TblAdvertiseTenderMap data
      * @return List<Object[]>
      * @throws Exception
      */
     public List<Object[]> getAdvertiseTenderMap(List<Object> advertiseNo) throws Exception {
         List<Object[]> list = null;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("advertiseNo", advertiseNo);
         
         StringBuffer query=new StringBuffer();
         query.append("select  tblAdvertisetendermap.tblTender.tenderId,tblAdvertisetendermap.tblTender.tenderNo,tblAdvertisetendermap.tblTender.tblDepartment.deptName,tblAdvertisetendermap.tblTender.tenderBrief ");
         query.append(" ,tblAdvertisetendermap.tblTender.documentFee,tblAdvertisetendermap.tblTender.tenderValue,tblAdvertisetendermap.tblTender.emdAmount,tblAdvertisetendermap.tblTender.projectDuration,tblAdvertisetendermap.tblTender.decimalValueUpto,tblAdvertisetendermap.tblAdvertise.advertiseNo,tblAdvertisetendermap.tblAdvertise.advertiseId");
         query.append(" from TblAdvertiseTenderMap tblAdvertisetendermap");
         query.append(" where tblAdvertisetendermap.tblAdvertise.advertiseNo in (:advertiseNo) ");
         list = hibernateQueryDao.createNewQuery(query.toString(),var);
         return list;
     }
     
     
     /**
     * @author vivek.rajyaguru
     * @param advertiseId
     * @param linkId
     * @param clientId
     * @return
     */
    public List<Object[]> getUploadedAdvertisementDocumentDetail(int advertiseId,int linkId,int clientId,int cstatus)throws Exception{
    	  List<Object[]> list = null;
          Map<String, Object> var = new HashMap<String, Object>();
          var.put("objectId", advertiseId);
          var.put("linkId", linkId);
          var.put("clientId", clientId);
          var.put("cstatus", cstatus);
          StringBuffer query=new StringBuffer();
          query.append("select tblOfficerDocument.officerFolderId,tblOfficerDocument.docName,tblOfficerDocument.path,tblOfficerDocument.description,tblOfficerDocument.fileSize,tblOfficerDocument.isEncryptionReq, ");
          query.append(" tblOfficerDocument.cstatus,tblOfficerDocument.createdBy,tblOfficerDocument.officerDocId ");
          query.append(" from TblOfficerDocMapping tblOfficerDocMapping INNER JOIN ");
          query.append(" tblOfficerDocMapping.tblOfficerDocument tblOfficerDocument ");
          query.append(" where  tblOfficerDocMapping.objectId=:objectId and tblOfficerDocument.tblClient=:clientId and tblOfficerDocMapping.tblLink=:linkId and tblOfficerDocMapping.cstatus=:cstatus");
          list = hibernateQueryDao.createNewQuery(query.toString(),var);
          return list;
    	 
     }

    /**
     * @author Nikhil Jani
     **/
    
     public int updateAdvertise(List<Object> advertiseNo) throws Exception{
     	//1) insert the advertise details.
     	//tblAdvertiseDetailDao.saveUpdateAllTblAdvertiseDetail(tblAdvertiseDetails);
     	//2) update the cstatus
     	int result = 0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("advertiseNo", advertiseNo);
         var.put("cstatus",1);
     	StringBuffer query=new StringBuffer();
     	query.append("update TblAdvertise tblAdvertise set ");
     	query.append("tblAdvertise.cstatus=0,tblAdvertise.publishedBy=0,tblAdvertise.publishedOn=null ");
     	query.append("where tblAdvertise.advertiseNo in (:advertiseNo) and tblAdvertise.cstatus=:cstatus ");
     	  
         result = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
         
         return result;
}
     
     /**
      * @author Nikhil Jani For Bug 30027
      **/
     public int updateDocStatusForMoveToPending(List<Integer> advIdsList,int linkId)
     {
    	 int result = 0;
    	  Map<String, Object> var = new HashMap<String, Object>();
          var.put("advertiseId", advIdsList);
          var.put("linkId", linkId);
          var.put("cstatus", 0);
          
          StringBuffer query=new StringBuffer();
          query.append("update TblOfficerDocMapping tblOfficerDocMapping set cstatus=:cstatus  where objectId in (:advertiseId) and tblOfficerDocMapping.tblLink.linkId=:linkId and cstatus in (0,1) ");
          result= hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
          return result;
     }
     
     /**
      * @author Nikhil Jani
      **/
     public int updateOfficerDocMappingobjectId(Object [] officerDocIds,int advertiseId,int linkId) throws Exception {
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("advertiseId", advertiseId);
         var.put("officerDocIds", officerDocIds);
         var.put("linkId", linkId);
         
         StringBuffer query=new StringBuffer();
         query.append("update TblOfficerDocMapping set objectId=:advertiseId where officerDocMappingId in (:officerDocIds) and tblLink.linkId=:linkId ");
         return hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
     }
     
     /**
      * @author Nikhil Jani
      **/
     public int updateDocStatus(int advertiseId,int linkId)
     {
    	  Map<String, Object> var = new HashMap<String, Object>();
          var.put("advertiseId", advertiseId);
          var.put("linkId", linkId);
          var.put("cstatus", 1);
          
          StringBuffer query=new StringBuffer();
          query.append("update TblOfficerDocMapping tblOfficerDocMapping set cstatus=:cstatus  where objectId=:advertiseId  and tblOfficerDocMapping.tblLink.linkId=:linkId and cstatus in (0,1) ");
          return hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
     }
     
     /**
     * @author vivek.rajyaguru
     * @param officerDocIds
     * @param officerDocMappingIds
     * @param linkId
     * @throws Exception
     */
     public int deleteOfficeDoc(Object[] officerDocIds,int clientId)throws Exception{
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put("officerDocIds", officerDocIds);
         var.put("clientId", clientId);
         return  hibernateQueryDao.updateDeleteNewQuery("delete TblOfficerDocument tblOfficerDocument where officerDocId in (:officerDocIds) and tblOfficerDocument.tblClient=:clientId",var);
    }
    
     /**
      * author : nikhil.jani
      * used to delet data from TblAdvertiseTenderMap
      * @return
      * @throws Exception 
      */
      public int deleteTblAdvertiseTenderMapWhileMoveToPending(List<Integer> advIdsList) throws Exception{
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("advertiseId", advIdsList);
         int cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblAdvertiseTenderMap tbladvertisetendermap where tbladvertisetendermap.tblAdvertise.advertiseId in (:advertiseId)",var);        
         return cnt;
     }
      
      /**
       * author : nikhil.jani
       * used to delet data from TblAdvertiseDetail
       * @return
       * @throws Exception 
       */
       public int deleteTblAdvertiseDetailsWhileMoveToPending(List<Integer> advIdsList) throws Exception{
          Map<String, Object> var = new HashMap<String, Object>();
          var.put("advertiseId", advIdsList);
          int cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblAdvertiseDetail tbladvertisedetail where tbladvertisedetail.tblAdvertise.advertiseId in (:advertiseId)",var);        
          return cnt;
      }

}
