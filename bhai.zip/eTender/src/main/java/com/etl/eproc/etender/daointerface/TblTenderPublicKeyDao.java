package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderPublicKey;

import java.util.List;

public interface TblTenderPublicKeyDao  {

    public void addTblTenderPublicKey(TblTenderPublicKey tblTenderPublicKey);

    public void deleteTblTenderPublicKey(TblTenderPublicKey tblTenderPublicKey);

    public void updateTblTenderPublicKey(TblTenderPublicKey tblTenderPublicKey);

    public List<TblTenderPublicKey> getAllTblTenderPublicKey();

    public List<TblTenderPublicKey> findTblTenderPublicKey(Object... values) throws Exception;

    public List<TblTenderPublicKey> findByCountTblTenderPublicKey(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderPublicKeyCount();

    public void saveUpdateAllTblTenderPublicKey(List<TblTenderPublicKey> tblTenderPublicKeys);
}