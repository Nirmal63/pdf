/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.io.File;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.model.TblCentralizedCommittee;
import com.etl.eproc.common.model.TblCentralizedCommitteeUser;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblCurrency;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblEventPayment;
import com.etl.eproc.common.model.TblEventType;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblModule;
import com.etl.eproc.common.model.TblPaymentType;
import com.etl.eproc.common.model.TblProcurementNature;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.MessageQueueService;
import com.etl.eproc.common.services.NegotiationService;
import com.etl.eproc.common.services.WorkflowService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SendGCMNotification;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.daointerface.TblItemBidderMapDao;
import com.etl.eproc.etender.daointerface.TblTenderMapBidderHistoryDao;
import com.etl.eproc.etender.databean.TenderDtBean;
import com.etl.eproc.etender.databean.TenderPublishBean;
import com.etl.eproc.etender.model.TblCancelRequest;
import com.etl.eproc.etender.model.TblCommittee;
import com.etl.eproc.etender.model.TblCommitteeEnvelope;
import com.etl.eproc.etender.model.TblCommitteeUser;
import com.etl.eproc.etender.model.TblDynReport;
import com.etl.eproc.etender.model.TblEncodeDecodeHistory;
import com.etl.eproc.etender.model.TblEnvelope;
import com.etl.eproc.etender.model.TblEventCompletion;
import com.etl.eproc.etender.model.TblItemBidderMap;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBidderCPV;
import com.etl.eproc.etender.model.TblTenderBidderMap;
import com.etl.eproc.etender.model.TblTenderCPV;
import com.etl.eproc.etender.model.TblTenderCurrency;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderMapBidderHistory;
import com.etl.eproc.etender.model.TblTenderTable;
import com.etl.eproc.etender.model.TblTenderWiseBudgetDetails;
import com.etl.eproc.etender.services.AdvertiseService;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.CommitteeFormationService;
import com.etl.eproc.etender.services.DynamicReportService;
import com.etl.eproc.etender.services.EventBidderMapService;
import com.etl.eproc.etender.services.EventCreationService;
import com.etl.eproc.etender.services.TenderCPVService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderFormService;
import com.etl.eproc.etender.services.TenderOpenService;

/**
 *
 * @author vanita
 */
@Controller
public class EventCreationController {

	@Autowired
	private TenderFormService tenderFormService;
    @Autowired
    private ReloadableResourceBundleMessageSource messageSource;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private SendGCMNotification sendGCMNotification;
    @Autowired
    private CommonService commonService;
    @Autowired
    private EventCreationService eventCreationService;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private CommonValidators commonValidators;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private WorkflowService workflowService;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private MessageQueueService messageQueueService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private TenderOpenService tenderOpenService;
    @Autowired
    DynamicReportService dynamicReportService; 
    @Autowired
	private CommitteeFormationService committeeFormationService;
    @Autowired
    private EventBidderMapService eventBidderMapService;
    @Autowired
    DynamicFieldService dynamicFieldService;
    @Autowired 
    private AdvertiseService advertiseService;
    @Autowired
	private NegotiationService negotiationService;
    @Autowired
	private TenderCPVService tenderCPVService;
    @Autowired
    private EventCreationService eventCompletionService;
    @Autowired
    private TblItemBidderMapDao itemBidderMapDao;
    @Autowired
    private TblTenderMapBidderHistoryDao tblTenderMapBidderHistoryDao;
    
    @Value("#{projectProperties['serverside.validation']?:true}")
    private boolean serverSideValidation;
    private static final String SESSIONOBJECT = "sessionObject";
    @Value("#{tenderlinkProperties['tender_create_tender']?:212}")
    private int tendercreationlink;
    @Value("#{tenderlinkProperties['notice_and_document_cancel']?:170}")    
    private int tenderCancelLink;
    @Value("#{tenderlinkProperties['notice_and_document_cancel_eventid']?:75}")    
    private int tenderCancelEventId;
    @Value("#{etenderAuditTrailProperties['getEventNotice']}")
    private String getEventNotice;
    @Value("#{etenderAuditTrailProperties['postEventNotice']}")
    private String postEventNotice;
    @Value("#{etenderAuditTrailProperties['getEditEventNotice']}")
    private String getEditEventNotice;
    @Value("#{etenderAuditTrailProperties['postEditEventNotice']}")
    private String postEditEventNotice;
    @Value("#{projectProperties['tender.eventid']?:63}")
    private int tenderEventId;
    @Value("#{tenderlinkProperties['notice_and_document_view']?:163}")
    private int tenderviewlink;
    @Value("#{etenderAuditTrailProperties['getviewtendernotice']}")
    private String getviewtendernotice;
    @Value("#{projectProperties['pki_enable']?:1}")
    private int pkiEnable;
    @Value("#{projectProperties['pki_eventspecific']?:2}")
    private int pkiEventSpecific;
    @Value("#{tenderlinkProperties['notice_and_document_publish']?:169}")
    private int tenderPublishLink;
    @Value("#{tenderlinkProperties['notice_and_document_edit']?:167}")
    private int tenderupdatelink;
    @Value("#{tenderlinkProperties['event_selection']?:362}")
    private int eventselectionlink;
    @Value("#{tenderlinkProperties['notice_and_document_edit_business_rule']?:248}")
    private int editBusinessRuleLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_view_business_rule']?:254}")
    private int viewBusinessRuleLinkId;
    @Value("#{etenderAuditTrailProperties['getpublishtender']}")
    private String getpublishtender;
    @Value("#{etenderAuditTrailProperties['postpublishtender']}")
    private String postpublishtender;
    @Value("#{etenderAuditTrailProperties['getViewBusinessRule']}")
    private String getViewBusinessRuleAudit;
    @Value("#{etenderAuditTrailProperties['getEditBusinessRule']}")
    private String getEditBusinessRuleAudit;
    @Value("#{etenderAuditTrailProperties['postEditBusinessRule']}")
    private String postEditBusinessRuleAudit;
    @Value("#{etenderAuditTrailProperties['getcanceltender']}")
    private String getCancelTender;
    @Value("#{etenderAuditTrailProperties['postcanceltender']}")
    private String postCancelTender;
    @Value("#{etenderAuditTrailProperties['getselectevent']}")
    private String getselectevent;
    @Value("#{etenderAuditTrailProperties['getemddocdetail']}")
    private String getemddocdetail;
    @Value("#{etenderAuditTrailProperties['postemddocdetail']}")
    private String postemddocdetail;
    @Value("#{etenderAuditTrailProperties['postencodedecodebiddername']}")
    private String postencodedecodebiddername;
    @Value("#{etenderAuditTrailProperties['getencodedecodebiddername']}")
    private String getencodedecodebiddername;
    @Value("#{etenderAuditTrailProperties['getencodebiddername']}")
    private String getencodebiddername;
    @Value("#{etenderAuditTrailProperties['getdecodebiddername']}")
    private String getdecodebiddername;
    @Value("#{etenderAuditTrailProperties['getTenderReviveRemark']}")
    private String getTenderReviveRemark;
    @Value("#{tenderlinkProperties['notice_and_document_revive']?:171}")
    private int reviveTenderLinkId;
    @Value("#{tenderlinkProperties['create_emd_tenderwise']?:455}")
    private int createEmdTenderWiseLinkId;
    @Value("#{tenderlinkProperties['edit_emd_tenderwise']?:456}")
    private int editEmdTenderWiseLinkId;
    @Value("#{tenderlinkProperties['view_emd_tenderwise']?:457}")
    private int viewEmdTenderWiseLinkId;
    @Value("#{linkProperties['encode_bidder_name']?:453}")
    private int encodeBidderNameLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_brd_re_generate']?:517}")
	private int regenerateTenderBrd;
    @Value("#{tenderlinkProperties['notice_and_document_upload']?:175}")
    private int uploadTenderDocLinkId;
     @Value("#{etenderProperties['publish_tender_templateId']?:45}")
    private String publishTenderTemplateId;
     @Value("#{etenderProperties['send_remainder_mail_templateId']?:207}")
     private String sendRemainderMailTemplateId;
     @Value("#{etenderProperties['remainder_mail_event_compl_templateId']?:210}")
     private String remainderMailEventComplTemplateId;     
     @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
    private String queueName;
    @Value("#{projectProperties['doc_upload_path']}")
    private String docUploadPath;
    @Value("#{tenderlinkProperties['notice_and_document_process_in_workflow']?:196}")
    private int noticeAndDocumentsWFLinkId;
    @Value("#{projectProperties['idfc_email_cc']}")   
    private String idfcEmailCC;
    @Value("#{projectProperties['idfc_client_id']}")   
    private String idfcClientId;
    @Value("#{projectProperties['rci_client_ids']}")
    private String rciClientIds;
    @Value("#{clientProperties['bob_client_id']}")
    private String bobClientId;
    @Value("#{advertiselinkProperties['upload_document']?:2287}")
    private int uploadDocLinkId;
    @Value("#{projectProperties['event_mail_bcc']}")
    private String eventMailBCC;
    @Value("#{projectProperties['mvp_sector']?:7}")
    private int mvpSectorId;
    @Value("#{etenderProperties['notify_bidder_for_open_event']?:269}")
    private String notifyBidderMailTemplateId;
    @Value("#{linkProperties['manage_bidder_register_bidder']?:24}")
	private int registrationLinkId;
    @Value("#{etenderAuditTrailProperties['getEventCompletedPageFromNoticeTab']}")
    private String getEventCompletedPageFromNoticeTab;
    @Value("#{tenderlinkProperties['eventCompletedLinkId']?:3368}")
    private int eventCompletedLinkId;
    @Value("#{linkProperties['hide_registration_link']?:3355}")
    private int hideRegistrationLinkId;
    @Value("#{etenderAuditTrailProperties['postEventCompletedPageFromNoticeTab']}")
    private String postEventCompletedPageFromNoticeTab;
    @Value("#{clientProperties['crawl_ipaddresses']}")
   	private String[] crawlIpAddress;
    private static final String CREATE = "create";
    private static final String EDIT = "edit";
    private static final String TENDERID = "tenderId";
    private static final String PUBLICKEY = "publicKey";
    private static final String SKPSIGNTEXT = "skpSignText";
    private static final String VIEW = "view";
    private static final String EVENTTYPEID = "eventTypeId";
    private static final String OPTYPE = "opType";
    private static final String REDIRECTDASHBOARD = "redirect:/etender/buyer/tenderdashboard/";
    private static final String DASHBOARD = "etender/buyer/tenderdashboard/";
    private static final String USERTYPE = "userType";
    private static final String TBLTENDER = "tblTender";
    private static final String RESULTSET_1= "#result-set-1";
    private static final String RESULTSET_2= "#result-set-2";
    private static final String RESULTSET_3= "#result-set-3";
    private static final String RESULTSET_4= "#result-set-4";
    private static final String RESULTSET_5= "#result-set-5";
    private static final String RESULTSET_6= "#result-set-6";
    private static final String RESULTSET_7= "#result-set-7";
    private static final String RESULTSET_8= "#result-set-8";
    private static final String RESULTSET_9= "#result-set-9";
    private static final String RESULTSET_10= "#result-set-10";
    private static final String RESULTSET_12= "#result-set-12";
    private static final String RESULTSET_13= "#result-set-13";
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    
     /**
     * autor : heeral.soni
     * access emd doc fees age
     * @param modelMap
     * @param request
     * @return String
     */
    @RequestMapping(value = "/etender/buyer/getemddocfeesdetails/{tenderId}/{enc}", method = RequestMethod.GET)
    public String getEmdDocFeesDetails(ModelMap modelMap,@PathVariable(TENDERID) int tenderId, HttpServletRequest request) {
        try {
            modelMap.addAttribute(OPTYPE, CREATE);
            modelMap.addAttribute("tenderId", tenderId);
            List<Object[]> lst = tenderCommonService.getTenderFields(tenderId, "emdPaymentMode,docFeePaymentMode");
            if (!lst.isEmpty()) {
                modelMap.addAttribute("emdPaymentMode", lst.get(0)[0]);
                modelMap.addAttribute("docFeePaymentMode", lst.get(0)[1]);
            }
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEmdTenderWiseLinkId, getemddocdetail, tenderId, 0);
        }
        return "/etender/buyer/AddEmdDocFeesDetail";
    }
    
     /**
     * autor : heeral.soni
     * insert emd doc fees details
     * @param modelMap
     * @param request
     * @return String
     */
    
    @RequestMapping(value = "/etender/buyer/addemddocfeesdetails", method = RequestMethod.POST)
    public String addEmdDocFeesDetails(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
        String retVal = null;
        int hdTenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;            
        try {
            TblTenderWiseBudgetDetails tblTenderWiseBudgetDetails = new TblTenderWiseBudgetDetails();
            
            int hdBudgetId = StringUtils.hasLength(request.getParameter("hdBudgetId")) ? Integer.parseInt(request.getParameter("hdBudgetId")) : 0;                                
            String emdBudgetCode = StringUtils.hasLength(request.getParameter("txtEmdBudget")) ? request.getParameter("txtEmdBudget") : " ";
            String emdDeptCode = StringUtils.hasLength(request.getParameter("txtEmdDept")) ? request.getParameter("txtEmdDept") : " ";
            String emdFunctionCode = StringUtils.hasLength(request.getParameter("txtEmdFunction")) ? request.getParameter("txtEmdFunction") : " ";
            String docBudgetCode = StringUtils.hasLength(request.getParameter("txtDocBudget")) ? request.getParameter("txtDocBudget") : " ";
            String docDeptCode = StringUtils.hasLength(request.getParameter("txtDocDept")) ? request.getParameter("txtDocDept") : " ";
            String docFunctionCode = StringUtils.hasLength(request.getParameter("txtDocFunction")) ? request.getParameter("txtDocFunction") : " ";
            
            if(hdBudgetId!=0){
                tblTenderWiseBudgetDetails.setBudgetId(Integer.parseInt(request.getParameter("hdBudgetId")));
            }
            tblTenderWiseBudgetDetails.setCreatedBy(abcUtility.getSessionUserDetailId(request));
            tblTenderWiseBudgetDetails.setDocBudgetCode(docBudgetCode);
            tblTenderWiseBudgetDetails.setDocFuncCode(docFunctionCode);
            tblTenderWiseBudgetDetails.setEmdBudgetCode(emdBudgetCode);
            tblTenderWiseBudgetDetails.setEmdDeptCode(emdDeptCode);
            tblTenderWiseBudgetDetails.setEmdFuncCode(emdFunctionCode);
            tblTenderWiseBudgetDetails.setDocDeptCode(docDeptCode);
            tblTenderWiseBudgetDetails.setTblTender(new TblTender(hdTenderId));
            boolean isInserted = eventCreationService.addTblTenderWiseBudgetDetails(tblTenderWiseBudgetDetails);
            //if(hdBudgetId!=0){
                redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? "msg_emddoc_success" : CommonKeywords.ERROR_MSG_KEY.toString());
            /*}else{
                redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? "msg_emddoc_success" : CommonKeywords.ERROR_MSG_KEY.toString());
            }*/          
            retVal = REDIRECTDASHBOARD + hdTenderId + "/1" + encryptDecryptUtils.generateRedirect(DASHBOARD + hdTenderId + "/1", request);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEmdTenderWiseLinkId, postemddocdetail, hdTenderId, 0);
        }
        return retVal;
    }
    
    /**
     * autor : heeral.soni
     * view and edit emd doc fees age
     * @param modelMap
     * @param request
     * @return String
     */
    @RequestMapping(value = "/etender/buyer/viewemddocfeesdetails/{tenderId}/{opType}/{enc}", method = RequestMethod.GET)
    public String viewEmdDocFeesDetails(ModelMap modelMap,@PathVariable(TENDERID) int tenderId,@PathVariable("opType") String opType, HttpServletRequest request){
        int linkId = 0;
    try {   
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("tblTenderWiseBudgetDetails", tenderCommonService.getTenderWiseBudgetDetailsByTenderId(tenderId));
            List<Object[]> lst = tenderCommonService.getTenderFields(tenderId, "emdPaymentMode,docFeePaymentMode");
            if (!lst.isEmpty()) {
                modelMap.addAttribute("emdPaymentMode", lst.get(0)[0]);
                modelMap.addAttribute("docFeePaymentMode", lst.get(0)[1]);
            }
            modelMap.addAttribute(OPTYPE,opType);
            if(opType.equalsIgnoreCase("edit")){
                linkId = editEmdTenderWiseLinkId;
            }else{
                linkId = viewEmdTenderWiseLinkId;
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getemddocdetail, tenderId, 0);
        }
        return "/etender/buyer/AddEmdDocFeesDetail";
    }

    
    /**
     * get page for select event
     *
     * @param modelMap
     * @param request
     * @return String
     */
    @RequestMapping(value = "/etender/buyer/geteventtype/{eventId}/{enc}", method = RequestMethod.GET)
    public String selectEvent(@PathVariable("eventId")int eventId,TenderDtBean tenderDtBean,ModelMap modelMap, HttpServletRequest request) {
        int clientId = 0;
        int eventTypeId = 0;
        Map<String, Object> configParam = null;
        Map<String, Object> hideConfigParam = null;
        String retVal = "/etender/buyer/EventTypeSelection";
//        TenderDtBean tenderDtBean = new TenderDtBean();
        try {
            clientId = abcUtility.getSessionClientId(request);
            List<Object[]> eventType = eventCreationService.getEventType(clientId);
            modelMap.addAttribute("eventType", eventType);
            if(eventType.size() == 1) {
                eventTypeId = Integer.parseInt(eventType.get(0)[0].toString());
                clientId = abcUtility.getSessionClientId(request);
                createTenderModelMap(modelMap, request, eventTypeId, clientId);
                configParam = (Map<String, Object>) modelMap.get("configParam");
                hideConfigParam = (Map<String, Object>) modelMap.get("hideConfigParam");
                modelMap.addAttribute("eventName", eventType.get(0)[1]);
                modelMap.addAttribute("eventName", eventType.get(0)[1]);
                eventCreationService.setCustConfigTenderData(tenderDtBean, configParam, hideConfigParam);
                modelMap.addAttribute("clientId",clientId);
                modelMap.addAttribute("isOnlinePayment",clientService.getClientById(clientId).getIsOnlinePayment());
				modelMap.addAttribute("objectId", 0);
				modelMap.addAttribute("linkId", tendercreationlink);
				int isGSTRequired = (Integer)clientService.getClientField(clientId, "isGSTRequired");
				modelMap.addAttribute("isGSTRequired", isGSTRequired);
				Map<String, Object> dynFieldMap = dynamicFieldService.setDynamicField(tendercreationlink, clientId, 0);
				if(Integer.parseInt(dynFieldMap.get("fieldDetailsListSize").toString()) == 0){
					modelMap.addAttribute("isDynFieldSize", 0);
				}
            	modelMap.addAttribute("dynFieldMap", dynFieldMap);
                retVal = "/etender/buyer/CreateTender";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), eventselectionlink, getselectevent, 0, 0);
        }
        return retVal;
    }

    /**
     * submit and redirect createTender page TenderDtBean is ModelAttribute
     *
     * @param tenderDtBean
     * @param modelMap
     * @param request
     * @return String
     */
    @RequestMapping(value = "/etender/buyer/createevent", method = RequestMethod.POST)
    public String createEvent(TenderDtBean tenderDtBean, ModelMap modelMap, HttpServletRequest request) {
        int clientId = 0;
        int eventTypeId = 0;
        Map<String, Object> configParam = null;
        Map<String, Object> hideConfigParam = null;
        String retVal = "redirect:/sessionexpired";
        int indentId = StringUtils.hasLength(request.getParameter("hdIndentId")) ? Integer.parseInt(request.getParameter("hdIndentId")) : 0;
        List<Object[]> indentDataList = null;
        try {
            if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
                if (request.getParameter("txtEventType") != null) {
                    eventTypeId = Integer.parseInt(request.getParameter("txtEventType"));
                }
                clientId = abcUtility.getSessionClientId(request);
                modelMap.addAttribute("eventName", commonService.getEventType(eventTypeId).get(0));
                modelMap.addAttribute("isOnlinePayment",clientService.getClientById(clientId).getIsOnlinePayment());
                createTenderModelMap(modelMap, request, eventTypeId, clientId);
                configParam = (Map<String, Object>) modelMap.get("configParam");
                hideConfigParam = (Map<String, Object>) modelMap.get("hideConfigParam");
                eventCreationService.setCustConfigTenderData(tenderDtBean, configParam, hideConfigParam);
                modelMap.addAttribute("isCPPPRequire", clientService.checkCPPPRequireOrNot(clientId));
                modelMap.addAttribute("isCPPPConfigure",clientService.checkCPPPConfigureOrNot(clientId));
            	if(indentId != 0){
                	indentDataList = commonService.getIndentDetailForTender(indentId);
                	if(indentDataList != null && ! indentDataList.isEmpty()){
                    	modelMap.addAttribute("indentData",indentDataList != null && !indentDataList.isEmpty() ? indentDataList.get(0) : null);
                    }
                }
            	modelMap.addAttribute("clientId",clientId);
				modelMap.addAttribute("objectId", 0);
				modelMap.addAttribute("linkId", tendercreationlink);
				Map<String, Object> dynFieldMap = dynamicFieldService.setDynamicField(tendercreationlink, clientId, 0);
				if(Integer.parseInt(dynFieldMap.get("fieldDetailsListSize").toString()) == 0){
					modelMap.addAttribute("isDynFieldSize", 0);
				}
				modelMap.addAttribute("dynFieldMap", dynFieldMap);
                modelMap.addAttribute("isOnlinePayment",clientService.getClientById(clientId).getIsOnlinePayment());
                int isGSTRequired = (Integer)clientService.getClientField(clientId, "isGSTRequired");
				modelMap.addAttribute("isGSTRequired", isGSTRequired);
                
                retVal = "/etender/buyer/CreateTender";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tendercreationlink, getEventNotice, 0, 0);
        }
        return retVal;
    }

    /**
     * get configuration data at admin side
     *
     * @param ModelMap modelMap
     * @param int clientId
     * @param int eventTypeId
     * @param String event
     */
    public void getCustomConfigData(ModelMap modelMap, int clientId, int eventTypeId, String event) throws Exception {
        Map<String, Object> configParam = new HashMap<String, Object>();
        Map<String, Object> hideConfigParam = new HashMap<String, Object>();
        List<SelectItem> lst = null;
        Map<String, Object> labelMap = new HashMap<String, Object>();
        Map<String, Object> valueMap = new HashMap<String, Object>();
        String data = "";
        List<Object[]> lstClientConfigFields = eventCreationService.getClientConfigurationFields(clientId, eventTypeId);
        if (lstClientConfigFields != null) {
            for (int i = 0; i < lstClientConfigFields.size(); i++) {
                if ((Integer) lstClientConfigFields.get(i)[0] == 1) {
                    if (lstClientConfigFields.get(i)[4] != null) {
                        configParam.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[4].toString());
                    } else {
                        configParam.put(lstClientConfigFields.get(i)[3].toString(), data);
                    }
                } else {
                    if (lstClientConfigFields.get(i)[4] != null) {
                        hideConfigParam.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[4].toString());
                    } else {
                        hideConfigParam.put(lstClientConfigFields.get(i)[3].toString(), data);
                    }
                }
                labelMap.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[6].toString());
                if (Integer.parseInt(lstClientConfigFields.get(i)[1].toString()) == 2) {
                    if (StringUtils.hasLength(lstClientConfigFields.get(i)[7].toString())) {
                        if (!event.equals(VIEW)) {
                            valueMap.put(lstClientConfigFields.get(i)[3].toString(), generateList(lstClientConfigFields.get(i)[7].toString()));
                        } else {
                            valueMap.put(lstClientConfigFields.get(i)[3].toString(), generateDataMap(lstClientConfigFields.get(i)[7].toString()));
                        }
                    } else if (StringUtils.hasLength(lstClientConfigFields.get(i)[5].toString())) {
                        lst = abcUtility.convert(commonService.getExecuteQuery(lstClientConfigFields.get(i)[5].toString(), clientId));
                        valueMap.put(lstClientConfigFields.get(i)[3].toString(), lst);
                    }
                } else {
                    valueMap.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[7].toString());
                }
            }
        }
        modelMap.addAttribute("hideConfigParam", hideConfigParam);
        modelMap.addAttribute("configParam", configParam);
        modelMap.addAttribute("labelMap", labelMap);
        modelMap.addAttribute("valueMap", valueMap);
        modelMap.addAttribute("selPaymentMode", clientService.getPaymentMode());
        modelMap.addAttribute("isWorkflowReq", eventCreationService.isWorkflowReq(clientId));
    }

    /**
     * redirect edit screen of tender TenderDtBean is modelAttribute,tenderId
     * PathVariable,eventTypeId PathVariable
     *
     * @param TenderDtBean tenderDtBean
     * @param int tenderId
     * @param int eventTypeId
     * @param ModelMap modelMap
     * @param HttpServletRequest request
     * @return String
     */
    @RequestMapping(value = "/etender/buyer/edittender/{tenderId}/{eventTypeId}/{enc}", method = RequestMethod.GET)
    public String updateTender(@ModelAttribute TenderDtBean tenderDtBean, @PathVariable(TENDERID) int tenderId, @PathVariable(EVENTTYPEID) int eventTypeId, ModelMap modelMap, HttpServletRequest request) {
        try {
            updateTenderModelMap(tenderDtBean, modelMap, request, tenderId, eventTypeId, "no");
            modelMap.addAttribute("eventName", commonService.getEventType(eventTypeId).get(0));
            int clientId = abcUtility.getSessionClientId(request);
            modelMap.addAttribute("clientId",clientId);
            modelMap.addAttribute("isOnlinePayment",clientService.getClientById(clientId).getIsOnlinePayment());
			modelMap.addAttribute("objectId", tenderId);
			modelMap.addAttribute("linkId", tendercreationlink);
			Map<String, Object> dynFieldMap = dynamicFieldService.setDynamicField(tendercreationlink, clientId, tenderId);
			if(Integer.parseInt(dynFieldMap.get("fieldDetailsListSize").toString()) == 0){
				modelMap.addAttribute("isDynFieldSize", 0);
			}
        	modelMap.addAttribute("dynFieldMap", dynFieldMap);
            modelMap.addAttribute("isCPPPRequire", clientService.checkCPPPRequireOrNot(clientId));
            modelMap.addAttribute("isCPPPConfigure",clientService.checkCPPPConfigureOrNot(clientId));
            int isGSTRequired = (Integer)clientService.getClientField(clientId, "isGSTRequired");
            modelMap.addAttribute("isGSTRequired", isGSTRequired);
        	if(abcUtility.isModuleAssignToClient(request,9)){
	        	modelMap.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
	        	if(modelMap.get("isCategoryAllow").equals(1)){
	            	List<Object[]> selectedCategory = commonService.getCategoryIdList(tenderId,tendercreationlink);
	            	modelMap.put("selectedCategory",selectedCategory);
	        	}
        	}else{
        		modelMap.put("isCategoryAllow",0);
        	}
		    
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tendercreationlink, getEditEventNotice, tenderId, 0);
        }
        return "/etender/buyer/CreateTender";
    }

    /**
     * set create parameter Model Map
     *
     * @param tenderDtBean
     * @param modelMap
     * @param request
     * @param eventTypeId
     * @param tenderId
     * @param clientId
     * @return String
     */
    public void createTenderModelMap(ModelMap modelMap, HttpServletRequest request, int eventTypeId, int clientId) throws Exception {
        getCustomConfigData(modelMap, clientId, eventTypeId, CREATE);
        modelMap.addAttribute(OPTYPE, CREATE);
        modelMap.addAttribute(EVENTTYPEID, eventTypeId);
        
        boolean isMVPVertical = clientService.isClientMVPVertical(clientId, mvpSectorId);
        List<SelectItem> formType = new ArrayList<SelectItem>();
        if(isMVPVertical){
        	List<Object[]> list = eventCreationService.getFormTypeForMVPVertical(0);
        	if(list != null && !list.isEmpty()){
        		for(Object[] obj : list){
        			formType.add(new SelectItem(obj[1], obj[0], obj[0]));
        		}
        	}
        }else{
        	formType = abcUtility.convert(eventCreationService.getFormType(0));
        }
        modelMap.addAttribute("formType", formType);
        modelMap.addAttribute("tenderCurrencySel", abcUtility.convert(commonService.getCurrencyList(clientId)));
        modelMap.addAttribute("tenderCurrency", abcUtility.convertSelected(eventCreationService.getTenderCurrencyList(clientId,0)));
        modelMap.addAttribute(OPTYPE, CREATE);
        int isPki = abcUtility.getSessionIsPkiEnabled(request);
        modelMap.addAttribute("isPki", isPki);
        List<SelectItem> officer = new ArrayList<SelectItem>();
        officer.add(new SelectItem("Select officer", 0));
        modelMap.put("officer", officer);
        List<SelectItem> displayOfficerName= new ArrayList<SelectItem>();
        displayOfficerName.add(new SelectItem(messageSource.getMessage("label_show", null, LocaleContextHolder.getLocale()), "1"));
        displayOfficerName.add(new SelectItem(messageSource.getMessage("label_hide", null, LocaleContextHolder.getLocale()), "0"));
        modelMap.put("displayOfficerName", displayOfficerName);
        List<SelectItem> lstYesNo = new ArrayList<SelectItem>();
        lstYesNo.add(new SelectItem(messageSource.getMessage("fields_tender_yes", null, LocaleContextHolder.getLocale()), "1"));
        lstYesNo.add(new SelectItem(messageSource.getMessage("fields_tender_no", null, LocaleContextHolder.getLocale()), "0"));
        modelMap.addAttribute("isCertRequire", lstYesNo);
        /*** Check Tender is going in Work flow process or not **/
        modelMap.addAttribute("workFlowYesNo",0);
        
        if(abcUtility.isModuleAssignToClient(request,9)){
    		modelMap.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
    	}else{
    		modelMap.put("isCategoryAllow",0);
    	}
        /*** Check Brd mode condition **/
        Map configParam = (Map<String, Object>) modelMap.get("configParam");
        Map hideConfigParam = (Map<String, Object>) modelMap.get("hideConfigParam");
    	if(configParam.containsKey("brdMode")){
    		modelMap.put("brdMode",configParam.get("brdMode"));	
    	}else if(hideConfigParam.containsKey("brdMode")){
    		modelMap.put("brdMode",hideConfigParam.get("brdMode"));
    	}
    	
	  int isOnlinePayment = clientService.getClientById(clientId).getIsOnlinePayment();
      if (isOnlinePayment != 0 ){
      	
      	int objectId=0;
      	int moduleId=3;
      	List<Object[]> clientPayType =  clientService.getClientEventPaymentType(clientId, 0, 0, 0 ,moduleId);
          modelMap.addAttribute("clientPayType",clientPayType);
      	
      	List<Object[]> modeOfPayment = clientService.getClientEventPaymentType(clientId, objectId, isOnlinePayment, 0, moduleId);
          List<SelectItem> selModeOfPayment = abcUtility.convert(modeOfPayment);
          modelMap.addAttribute("selDocModeOfPayment", selModeOfPayment);
          modelMap.addAttribute("selSecModeOfPayment", selModeOfPayment);
          modelMap.addAttribute("selEmdModeOfPayment", selModeOfPayment);
          
          List<Object[]> regModeOfPayment = clientService.getClientEventPaymentType(clientId, objectId, isOnlinePayment, 8, moduleId);
          List<SelectItem> selRegModeOfPayment = abcUtility.convert(regModeOfPayment);
          modelMap.addAttribute("selRegModeOfPayment", selRegModeOfPayment);
      }
    }

    /**
     * set update parameter Model Map
     *
     * @param tenderDtBean
     * @param modelMap
     * @param request
     * @param eventTypeId
     * @param tenderId
     * @return String
     */
    public void updateTenderModelMap(TenderDtBean tenderDtBean, ModelMap modelMap, HttpServletRequest request, int tenderId, int eventTypeId, String validate) throws Exception {
        int clientId = 0;
        TblTender tblTender = null;
        List<Object> lstTenderDetail = eventCreationService.getTenderDetail(tenderId);
        clientId = abcUtility.getSessionClientId(request);
        tblTender = (TblTender) lstTenderDetail.get(0);
        getCustomConfigData(modelMap, clientId, eventTypeId, EDIT);
        modelMap.addAttribute(EVENTTYPEID, eventTypeId);
        
        boolean isMVPVertical = clientService.isClientMVPVertical(clientId, mvpSectorId);
        List<SelectItem> formType = null;
        if(isMVPVertical){
        	formType = abcUtility.convertSelected(eventCreationService.getFormTypeForMVPVertical(tenderId));
        }else{
        	formType = abcUtility.convertSelected(eventCreationService.getFormType(tenderId));
        }
        modelMap.addAttribute("formType", formType);
        List<SelectItem> displayOfficerName= new ArrayList<SelectItem>();
        displayOfficerName.add(new SelectItem(messageSource.getMessage("label_show", null, LocaleContextHolder.getLocale()), "1"));
        displayOfficerName.add(new SelectItem(messageSource.getMessage("label_hide", null, LocaleContextHolder.getLocale()), "0"));
        modelMap.put("displayOfficerName", displayOfficerName);
        modelMap.addAttribute("tenderCurrencySel", abcUtility.convert(commonService.getCurrencyList(clientId)));
        modelMap.addAttribute("tenderCurrency", abcUtility.convertSelected(eventCreationService.getTenderCurrencyList(clientId,tenderId)));
        
        modelMap.addAttribute(OPTYPE, EDIT);
        modelMap.addAttribute(TENDERID, tenderId);
        tenderDtBean.setSeldisplayOfficerName(tblTender.getDisplayOfficerName());
        int isPki = abcUtility.getSessionIsPkiEnabled(request);
        modelMap.addAttribute("isPki", isPki);
        List<SelectItem> lstYesNo = new ArrayList<SelectItem>();
        lstYesNo.add(new SelectItem(messageSource.getMessage("fields_tender_yes", null, LocaleContextHolder.getLocale()), "1"));
        lstYesNo.add(new SelectItem(messageSource.getMessage("fields_tender_no", null, LocaleContextHolder.getLocale()), "0"));
        modelMap.addAttribute("isCertRequire", lstYesNo);
        if ("no".equalsIgnoreCase(validate) && tblTender != null) {
            tenderDtBean.setTxtTenderNo(tblTender.getTenderNo());
            tenderDtBean.setTxtParentDepartment(tblTender.getTblDepartment().getDeptId());
            tenderDtBean.setSelDeptOfficial(tblTender.getOfficerId());
            tenderDtBean.setTxtaTenderBrief(tblTender.getTenderBrief());
            tenderDtBean.setRtfTenderDetail(tblTender.getTenderDetail());
            //tenderDtBean.setTxtaKeyword(commonService.getKeywords(tenderId, tenderEventId));
            tenderDtBean.setTxtaKeyword(tblTender.getKeywordText());
            tenderDtBean.setSelEnvelopeType(tblTender.getEnvelopeType());
            tenderDtBean.setTxtValidityPeriod(Integer.toString(tblTender.getValidityPeriod()));
            tenderDtBean.setSelProcurementNatureId(tblTender.getTblProcurementNature().getProcurementNatureId());
            tenderDtBean.setSelDownloadDocument(tblTender.getDownloadDocument());
            tenderDtBean.setTxtTenderValue(tblTender.getTenderValue().toString());
            tenderDtBean.setSelIsSplitPOAllowed(tblTender.getIsSplitPOAllowed());
            tenderDtBean.setSelIsItemwiseWinner(tblTender.getIsItemwiseWinner());
            tenderDtBean.setSelSubmissionMode(tblTender.getSubmissionMode());
            tenderDtBean.setSelTenderMode(tblTender.getTenderMode());
            tenderDtBean.setSelBiddingType(tblTender.getBiddingType());
            if (eventCreationService.getTenderBaseCurrency(tenderId) != null) {
                tenderDtBean.setSelCurrencyId(Integer.parseInt(eventCreationService.getTenderBaseCurrency(tenderId)));
            }
            tenderDtBean.setSelIsConsortiumAllowed(tblTender.getIsConsortiumAllowed());
            tenderDtBean.setSelIsBidWithdrawal(tblTender.getIsBidWithdrawal());
            tenderDtBean.setSelBiddingVariant(tblTender.getBiddingVariant());
            tenderDtBean.setSelIsPreBidMeeting(tblTender.getIsPreBidMeeting());
            tenderDtBean.setSelPreBidMode(tblTender.getPreBidMode());
            tenderDtBean.setTxtaPreBidAddress(tblTender.getPreBidAddress());
            tenderDtBean.setTxtaDocumentSubmission(tblTender.getDocumentSubmission());
            tenderDtBean.setSelIsWorkflowRequired(tblTender.getIsWorkflowRequired());
            tenderDtBean.setSelWorkflowType(tblTender.getWorkflowTypeId());
            tenderDtBean.setSelIsQuestionAnswer(tblTender.getIsQuestionAnswer());
            tenderDtBean.setTxtOtherProcNature(tblTender.getOtherProcurementNature());
            if (tblTender.getDocumentStartDate() != null) {
                tenderDtBean.setTxtDocumentStartDate(tblTender.getDocumentStartDate().toString());
            }
            if (tblTender.getDocumentEndDate() != null) {
                tenderDtBean.setTxtDocumentEndDate(tblTender.getDocumentEndDate().toString());
            }
            if (tblTender.getSubmissionStartDate() != null) {
                tenderDtBean.setTxtSubmissionStartDate(tblTender.getSubmissionStartDate().toString());
            }
            if (tblTender.getSubmissionEndDate() != null) {
                tenderDtBean.setTxtSubmissionEndDate(tblTender.getSubmissionEndDate().toString());
            }
            if (tblTender.getPreBidStartDate() != null) {
                tenderDtBean.setTxtPreBidStartDate(tblTender.getPreBidStartDate().toString());
            }
            if (tblTender.getOpeningDate() != null) {
                tenderDtBean.setTxtBidOpenDate(tblTender.getOpeningDate().toString());
            }
            if (tblTender.getQuestionAnswerStartDate() != null) {
                tenderDtBean.setTxtQuestionAnswerStartDate(tblTender.getQuestionAnswerStartDate().toString());
            }
            if (tblTender.getQuestionAnswerEndDate() != null) {
                tenderDtBean.setTxtQuestionAnswerEndDate(tblTender.getQuestionAnswerEndDate().toString());
            }
            if (tblTender.getEmdSubmissionEndDate() != null) {
                tenderDtBean.setTxtEmdSubmissionEndDate(tblTender.getEmdSubmissionEndDate().toString());
            }
            tenderDtBean.setSignedPdfRequired(tblTender.getSignedPdfRequired());
            tenderDtBean.setSelIsDocfeesApplicable(tblTender.getIsDocfeesApplicable());
            tenderDtBean.setSelDocFeePaymentMode(tblTender.getDocFeePaymentMode());
            
            //PT: 20681
            tenderDtBean.setTxtRegistrationCharges(tblTender.getRegistrationCharges());//PT: 20681
            tenderDtBean.setSelRegistrationChargesMode(tblTender.getRegistrationChargesMode());
            tenderDtBean.setSelIsRegistrationCharges(tblTender.getIsRegistrationCharges());
            
            if (StringUtils.hasLength(tblTender.getDocumentFee())) {
                BigDecimal txtDocumentFees = new BigDecimal(tblTender.getDocumentFee());
                tenderDtBean.setTxtDocumentFee((txtDocumentFees.setScale(tblTender.getDecimalValueUpto(), 2)).toString());
            }

            tenderDtBean.setTxtaDocFeePaymentAddress(tblTender.getDocFeePaymentAddress());
            tenderDtBean.setSelIsSecurityfeesApplicable(tblTender.getIsSecurityfeesApplicable());
            tenderDtBean.setSelSecFeePaymentMode(tblTender.getSecFeePaymentMode());
            if (StringUtils.hasLength(tblTender.getSecurityFee())) {
                BigDecimal txtSecurityFees = new BigDecimal(tblTender.getSecurityFee());
                tenderDtBean.setTxtSecurityFee((txtSecurityFees.setScale(tblTender.getDecimalValueUpto(), 2)).toString());
            }
            tenderDtBean.setTxtaSecFeePaymentAddress(tblTender.getSecFeePaymentAddress());
            tenderDtBean.setSelEmdPaymentMode(tblTender.getEmdPaymentMode());
            if (StringUtils.hasLength(tblTender.getEmdAmount())) {
                BigDecimal txtEmdAmt = new BigDecimal(tblTender.getEmdAmount());
                tenderDtBean.setTxtEmdAmount((txtEmdAmt.setScale(tblTender.getDecimalValueUpto(), 2)).toString());
            }
            if (StringUtils.hasLength(tblTender.getMinEmdAmt())) {
                BigDecimal txtMinEmdAmt = new BigDecimal(tblTender.getMinEmdAmt());
                tenderDtBean.setTxtMinEmdAmt((txtMinEmdAmt.setScale(tblTender.getDecimalValueUpto(), 2)).toString());
            }
            if (StringUtils.hasLength(tblTender.getMaxEmdAmt())) {
                BigDecimal txtMaxEmdAmt = new BigDecimal(tblTender.getMaxEmdAmt());
                tenderDtBean.setTxtMaxEmdAmt((txtMaxEmdAmt.setScale(tblTender.getDecimalValueUpto(), 2)).toString());
            }
            tenderDtBean.setTxtaEmdPaymentAddress(tblTender.getEmdPaymentAddress());
            tenderDtBean.setTxtProjectDuration(tblTender.getProjectDuration());
            tenderDtBean.setSelIsEMDApplicable(tblTender.getIsEMDApplicable());
            tenderDtBean.setSelDecimalValueUpto(tblTender.getDecimalValueUpto());
            tenderDtBean.setSelEventType(tblTender.getTblEventType().getEventTypeId());
            if (tblTender.getPreBidEndDate() != null) {
                tenderDtBean.setTxtPreBidEndDate(tblTender.getPreBidEndDate().toString());
            }
            tenderDtBean.setSelIsCertRequired(tblTender.getIsCertRequired());
            //CPPP Changes
            tenderDtBean.setTxtaPrequalification(tblTender.getPrequalification());
            tenderDtBean.setSelProduct(tblTender.getProductId());
            tenderDtBean.setSelFormContract(tblTender.getFormContract());
            tenderDtBean.setSelTenderSector(tblTender.getTenderSector());
            tenderDtBean.setSelTaxType(tblTender.getTaxType());
            if(modelMap.containsKey("configParam") && ((Map<String, Object>) modelMap.get("configParam")).containsKey("cgst")){
            	Map<String, Object> configParam = (Map<String, Object>) modelMap.get("configParam");
            	if(configParam.containsKey("cgst")) 
	            {
            		tenderDtBean.setHdCgst(Integer.parseInt(configParam.get("cgst").toString()));
	            }
            }
            if(modelMap.containsKey("configParam") && ((Map<String, Object>) modelMap.get("configParam")).containsKey("sgst")){
            	Map<String, Object> configParam = (Map<String, Object>) modelMap.get("configParam");
            	if(configParam.containsKey("sgst")) 
	            {
            		tenderDtBean.setHdSgst(Integer.parseInt(configParam.get("sgst").toString()));
	            }
            }
            if(modelMap.containsKey("configParam") && ((Map<String, Object>) modelMap.get("configParam")).containsKey("igst")){
            	Map<String, Object> configParam = (Map<String, Object>) modelMap.get("configParam");
            	if(configParam.containsKey("igst")) 
	            {
            		tenderDtBean.setHdIgst(Integer.parseInt(configParam.get("igst").toString()));
	            }
            }
            
            /*** Check Tender is going in Work flow process or not **/
            modelMap.addAttribute("workFlowYesNo", workflowService.checkEntryTblWorkflow(tblTender.getTblEventType().getEventTypeId(),tenderId,noticeAndDocumentsWFLinkId,tenderId));
            
            /*** Check Brd mode condition **/
            modelMap.put("brdMode",tblTender.getBrdMode());	
            
        }else{//Condition for abc:date conversion in case server side validation fire then set old value to all input which come form edit screen 
        	modelMap.addAttribute("dateConversion", "NO");
        }

        //bug: 19150 set value from tender table instead of default value of configParam for edit.
        if(modelMap.containsKey("configParam") && ((Map<String, Object>) modelMap.get("configParam")).containsKey("isPastEvent")){//Bug: 19150
        	   Map<String, Object> configParam = (Map<String, Object>) modelMap.get("configParam");
	            if(configParam.containsKey("isPastEvent")) 
	            {
	            	configParam.put("isPastEvent",tblTender.getIsPastEvent());
	            	tenderDtBean.setIsPastEvent(tblTender.getIsPastEvent());
	            }
            
        }else if(modelMap.containsKey("hideConfigParam") && ((Map<String, Object>) modelMap.get("hideConfigParam")).containsKey("isPastEvent")){//Bug: 19150
                Map<String, Object> hideConfigParam = (Map<String, Object>) modelMap.get("hideConfigParam");
	            if(hideConfigParam.containsKey("isPastEvent"))
	            {
	            	hideConfigParam.put("isPastEvent",tblTender.getIsPastEvent());
	            	tenderDtBean.setIsPastEvent(tblTender.getIsPastEvent());
	            }
            }
        tenderDtBean.setCstatus(tblTender.getCstatus());
        if(abcUtility.isModuleAssignToClient(request,9)){
    		modelMap.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
    	}else{
    		modelMap.put("isCategoryAllow",0);
    	}
        
        if (clientService.getClientById(clientId).getIsOnlinePayment() != 0 ){
        	
        	int moduleId=3;
        	List<Object[]> clientPayType =  clientService.getClientEventPaymentType(clientId, 0, 0, 0, moduleId);
            modelMap.addAttribute("clientPayType",clientPayType);
        	
            List<Object[]> docModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getDocFeePaymentMode(), 1, moduleId);
            List<SelectItem> selDocModeOfPayment = abcUtility.convertSelected(docModeOfPayment);
            modelMap.addAttribute("selDocModeOfPayment", selDocModeOfPayment);
            
    		List<Object[]> secModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getSecFeePaymentMode(), 10, moduleId);
            List<SelectItem> selSecModeOfPayment = abcUtility.convertSelected(secModeOfPayment);
            modelMap.addAttribute("selSecModeOfPayment", selSecModeOfPayment);
        
    		List<Object[]> emdModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getEmdPaymentMode(), 2, moduleId);
            List<SelectItem> selEmdModeOfPayment = abcUtility.convertSelected(emdModeOfPayment);
            modelMap.addAttribute("selEmdModeOfPayment", selEmdModeOfPayment);
        
    		List<Object[]> regModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getRegistrationChargesMode(), 8, moduleId);
            List<SelectItem> selRegModeOfPayment = abcUtility.convertSelected(regModeOfPayment);
            modelMap.addAttribute("selRegModeOfPayment", selRegModeOfPayment);
        
        }
        
    }

    /**
     * create tender on submit and redirect on view page and edit tender and
     * redirect on tender dashboard TenderDtBean is ModelAttribute and perform
     * server side validation for textarea and textbox field
     *
     * @param TenderDtBean tenderDtBean
     * @param RedirectAttributes redirectAttributes
     * @param HttpServletRequest request
     * @param BindingResult bindingResult
     * @param ModelMap modelMap
     * @return String
     */
    @RequestMapping(value = "/etender/buyer/addtender", method = RequestMethod.POST)
    public String addTender(@ModelAttribute TenderDtBean tenderDtBean, RedirectAttributes redirectAttributes, HttpServletRequest request, BindingResult bindingResult, ModelMap modelMap) {
    	boolean success = true;
        TblTender tblTender = new TblTender();
        TblTenderCurrency tblTenderCurrency = null;
        List<TblTenderCurrency> tblTenderCurrencys = null;
        TblTenderEnvelope tblTenderEnvelope = null;
        TblEnvelope tblEnvelope = null;
        List<TblTenderEnvelope> lstTenderEnvelope = new ArrayList<TblTenderEnvelope>();
        String auditMessage = null;
        String retVal = "redirect:/sessionexpired";
        String redirectMessage = null;
        int linkid = 0;
        TblProcurementNature tblProcurementNature = new TblProcurementNature();
        TblDepartment tblDepartment = new TblDepartment();
        TblTenderCurrency tblTenderCurrency1 = null;
        TblCurrency tblCurrency = new TblCurrency();
        int clientId = 0;
        int userId = 0;
        TblEventType tblEventType = new TblEventType();
        Map<String, Object> configParam = new HashMap<String, Object>();
        boolean validationflag = true;
        Map<String, Object> configParam1 = new HashMap<String, Object>();
        Map<String, Object> hideConfigParam = new HashMap<String, Object>();
        int tenderId = 0;
        int eventTypeId = 0;
        String opType = null;
        int userDetailId = 0;
        String selectedCategory[];
        boolean tenderPublishChk=false;
        int isItemWiseWinner = 0;
        int isCentralizedTOCRequired = 0;
        int isCentralizedTECRequired = 0;
        int centralizedCommitteeType = 0;
        boolean isWorkflowReq = true;
        //Bug Id #26620: When Officer Change Item wise L1/H1 it have to remove old mapped bidder
        int oldTenderResult=0;
        int oldTenderMode=0;
        List<TblEventPayment> tblEventPayments=new ArrayList<TblEventPayment>();
        try {
        	tenderId = tenderDtBean.getHdTenderId();
            eventTypeId = tenderDtBean.getHdEventTypeId();
            opType = tenderDtBean.getHdOpType();
            if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
            	int indentId = StringUtils.hasLength(request.getParameter("hdIndentId")) ? Integer.parseInt(request.getParameter("hdIndentId")) : 0;
                String data = null;
                userId = abcUtility.getSessionUserId(request);
                userDetailId = abcUtility.getSessionUserDetailId(request);
                clientId = abcUtility.getSessionClientId(request);
                int isGSTRequired = (Integer)clientService.getClientField(clientId, "isGSTRequired");
                isWorkflowReq = eventCreationService.isWorkflowReq(clientId);
                List<Object[]> lstClientConfigFields = eventCreationService.getClientConfigurationFields(clientId, eventTypeId);
                if (lstClientConfigFields != null) {
                    for (int i = 0; i < lstClientConfigFields.size(); i++) {
                        if (lstClientConfigFields.get(i)[4] != null) {
                            configParam.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[4].toString());
                            if (EDIT.equals(opType)) {
                            	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isPastEvent"))
                            	{
                            		configParam.put("isPastEvent",tenderDtBean.getIsPastEvent());
                            	}
                            }
                            if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isNextEnvOpeningDateAuto"))
                        	{
                            	tblTender.setIsNextEnvOpeningDateAuto(Integer.parseInt(lstClientConfigFields.get(i)[4].toString()));
                        	}
                            if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("nextEnvOpeningDateSetAfter"))
                        	{
                            	tblTender.setNextEnvOpeningDateSetAfter(Integer.parseInt(lstClientConfigFields.get(i)[4].toString()));
                        	}
                        } else {
                            configParam.put(lstClientConfigFields.get(i)[3].toString(), data);
                        }
                    }
                }
                if (CREATE.equals(opType)) {
                    auditMessage = postEventNotice;
                    linkid = tendercreationlink;
                    tenderPublishChk=true;
                } else {
                    auditMessage = postEditEventNotice;
                    linkid = tenderupdatelink;
                    tblTender = eventCreationService.getTenderMaster(tenderId);
                    oldTenderResult=tblTender.getTenderResult();
                	oldTenderMode=tblTender.getTenderMode();
                    
                    /*** Code to check multiple browser entry at edit time if tender is all ready publish then not edit and message return to user**/
                    tenderPublishChk = (tblTender.getCstatus()!=1);
                    if(tenderPublishChk && tblTender.getIsWorkflowRequired()==1 && EDIT.equals(opType)){
                    	tenderPublishChk = (tblTender.getCstatus()!=3);
                    }
                }
             // Bug: 19666 if Download document is after payment then Document fees should be Allow and mode of payment should be online.
                if(tenderDtBean.getSelDownloadDocument() == 3 && (tenderDtBean.getSelIsDocfeesApplicable() != 1 || tenderDtBean.getSelIsDocfeesApplicable() != 2 || tenderDtBean.getSelDocFeePaymentMode() != 1 || tenderDtBean.getSelDocFeePaymentMode() != 2)) 
            	{
                	tenderDtBean.setSelIsDocfeesApplicable(1);
                	tenderDtBean.setSelDocFeePaymentMode(1);
            	}
                if (serverSideValidation) {
                    if (lstClientConfigFields != null) {
                        for (int i = 0; i < lstClientConfigFields.size(); i++) {
                            if ((Integer) lstClientConfigFields.get(i)[0] == 1) {
                                if (lstClientConfigFields.get(i)[4] != null) {
                                    configParam1.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[4].toString());
                                    if (EDIT.equals(opType)) { //bug: 19150 set value from bean instead of default value of configParam for edit.
                                    	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isPastEvent"))
                                    	{
                                    		configParam1.put("isPastEvent",tenderDtBean.getIsPastEvent());
                                    	}
                                    }
                                } else {
                                    configParam1.put(lstClientConfigFields.get(i)[3].toString(), data);
                                }
                            } else {
                                if (lstClientConfigFields.get(i)[4] != null) {
                                    hideConfigParam.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[4].toString());
                                    if (EDIT.equals(opType)) {  //bug: 19150 set value from bean instead of default value of configParam for edit.
                                    	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isPastEvent"))
                                    	{
                                    		configParam1.put("isPastEvent",tenderDtBean.getIsPastEvent()); // because server side validation is based on configParam1 value. 
                                    	}
                                    }
                                } else {
                                    hideConfigParam.put(lstClientConfigFields.get(i)[3].toString(), data);
                                }
                            }
                        }
                    }
                    tenderDtBean.setClientBean((ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()));
                    tenderDtBean.setCommonValidators(commonValidators);
                    tenderDtBean.setConversionService(conversionService);
                    tenderDtBean.setConfigParam1(configParam1);
                    tenderDtBean.setHideConfigParam(hideConfigParam);
                    tenderDtBean.validateBean(bindingResult);
                    if (bindingResult.hasErrors()) {
                        validationflag = false;
                    } else {
                        validationflag = true;
                    }
                }
                if(!validationflag){
                	modelMap.addAttribute("clientId",clientId);
     				modelMap.addAttribute("objectId", 0);
     				modelMap.addAttribute("linkId", tendercreationlink);
     				Map<String, Object> dynFieldMap = dynamicFieldService.setDynamicField(tendercreationlink, clientId, 0);
     				if(Integer.parseInt(dynFieldMap.get("fieldDetailsListSize").toString()) == 0){
     					modelMap.addAttribute("isDynFieldSize", 0);
     				}
                 	modelMap.addAttribute("dynFieldMap", dynFieldMap);
                }
                if (validationflag && tenderPublishChk) {
                    String currIdList = request.getParameter("txtCommaSepCur");
                    selectedCategory = request.getParameterValues("txtCategory");
                    StringTokenizer stcurrIdList = null;

                    if (StringUtils.hasLength(currIdList)) {
                        stcurrIdList = new StringTokenizer(currIdList, ",");
                    }
                    if (StringUtils.hasLength(tenderDtBean.getTxtTenderNo())
                            && StringUtils.hasLength(tenderDtBean.getTxtaTenderBrief())
                            && StringUtils.hasLength(tenderDtBean.getRtfTenderDetail())
                            //&& StringUtils.hasLength(tenderDtBean.getTxtaKeyword())
                            ) {
                        tblDepartment.setDeptId(tenderDtBean.getTxtParentDepartment());
                        if(tenderDtBean.getSelIsItemwiseWinner() == 1){
                            tblTender.setTenderResult(2);
                            isItemWiseWinner = 1;
                        }else if(tenderDtBean.getSelIsItemwiseWinner() == 0){
                            tblTender.setTenderResult(1);
                            isItemWiseWinner = 0;
                        } else if(tenderDtBean.getSelIsItemwiseWinner() == 2){ //Lot wise
                            tblTender.setTenderResult(3);
                            isItemWiseWinner = 2;
                        }
                        tblTender.setTblDepartment(tblDepartment);
                        tblTender.setOfficerId(tenderDtBean.getSelDeptOfficial());
                        String referenceNo = tblTender.getTenderNo();
                        tblTender.setTenderNo(tenderDtBean.getTxtTenderNo());
                        tblTender.setTenderBrief(tenderDtBean.getTxtaTenderBrief());
                        tblTender.setCstatus(0);
                        tblTender.setIsRegretAllow(0);
                        if (CREATE.equalsIgnoreCase(opType)) {
                            tblTender.setCreatedBy(userDetailId);
                            tblTender.setAssignUserId(userId);
                        }else{
                        	 tblTender.setAssignUserId(tblTender.getAssignUserId());
                        }
                        tblTender.setUpdatedBy(userDetailId);
                        if(!"".equals(tenderDtBean.getTxtaKeyword())){
                        	tblTender.setKeywordText(tenderDtBean.getTxtaKeyword());
                        }
                        
                        if (opType.equals(CREATE)) {
                            if (configParam.containsKey("isOpeningByCommittee") && configParam.get("isOpeningByCommittee") != null) {
                                tblTender.setIsOpeningByCommittee(Integer.parseInt(configParam.get("isOpeningByCommittee").toString()));
                            } else {
                                tblTender.setIsOpeningByCommittee(tenderDtBean.getIsOpeningByCommittee());
                            }
                            if (configParam.containsKey("displayOfficerName") && configParam.get("displayOfficerName") != null) {
                                tblTender.setDisplayOfficerName(Integer.parseInt(configParam.get("displayOfficerName").toString()));
                            } else {
                                tblTender.setDisplayOfficerName(tenderDtBean.getSeldisplayOfficerName());
                            }
                            if (configParam.containsKey("isPartialFillingAllowed") && configParam.get("isPartialFillingAllowed") != null) {
                                tblTender.setIsPartialFillingAllowed(Integer.parseInt(configParam.get("isPartialFillingAllowed").toString()));
                            } else {
                            	tblTender.setIsPartialFillingAllowed(tenderDtBean.getIsPartialFillingAllowed());
                            }
                            if (configParam.containsKey("isEvaluationByCommittee") && configParam.get("isEvaluationByCommittee") != null) {
                                tblTender.setIsEvaluationByCommittee(Integer.parseInt(configParam.get("isEvaluationByCommittee").toString()));
                            }
                            if (configParam.containsKey("multiLevelEvaluationReq") && configParam.get("multiLevelEvaluationReq") != null) {
                                tblTender.setMultiLevelEvaluationReq(Integer.parseInt(configParam.get("multiLevelEvaluationReq").toString()));
                            }
                            if (configParam.containsKey("isUploadRefDocAllowed") && configParam.get("isUploadRefDocAllowed") != null) {
                                tblTender.setIsUploadRefDocAllowed(Integer.parseInt(configParam.get("isUploadRefDocAllowed").toString()));
                            }
                            if (configParam.containsKey("forHomePage") && configParam.get("forHomePage") != null) {
                                tblTender.setForHomePage(Integer.parseInt(configParam.get("forHomePage").toString()));
                            } else {
                                /**
                                 * * Start Condition check if tenderMode is 1
                                 * than forHome page is 1 else *
                                 */
                                if (tenderDtBean.getSelTenderMode() == 1) {
                                    tblTender.setForHomePage(tenderDtBean.getForHomePage());
                                } else {
                                    tblTender.setForHomePage(0);
                                }
                                /**
                                 * * End Condition check if tenderMode is 1
                                 * than forHome page is 1 else *
                                 */
                            }
                            /**
                             * * Start Check condition for isWorkFlow &
                             * biddingVariant*
                             */
                            if (configParam.containsKey("isWorkflowReq") && configParam.get("isWorkflowReq") != null) {
                            	if(isWorkflowReq == true){
                            		tblTender.setIsWorkflowRequired(Integer.parseInt(configParam.get("isWorkflowReq").toString()));
                            	}else{
                            		tblTender.setIsWorkflowRequired(0);
                            	}
                            } else {
                            	if(isWorkflowReq == true){
                            		tblTender.setIsWorkflowRequired(tenderDtBean.getSelIsWorkflowRequired());
                            	}else{
                            		tblTender.setIsWorkflowRequired(0);
                            	}
                                
                            }
                            if (configParam.containsKey("biddingVariant") && configParam.get("biddingVariant") != null) {
                                tblTender.setBiddingVariant(Integer.parseInt(configParam.get("biddingVariant").toString()));
                            } else {
                                tblTender.setBiddingVariant(tenderDtBean.getSelBiddingVariant());
                            }
                            /**
                             * * End Check condition for isWorkFlow &
                             * biddingVariant*
                             */
                            if (configParam.containsKey("isEncodedName") && configParam.get("isEncodedName") != null) {
                                tblTender.setIsEncodedName(Integer.parseInt(configParam.get("isEncodedName").toString()));
                            } else {
                                tblTender.setIsEncodedName(tenderDtBean.getIsEncodedName());
                            }
                            if (configParam.containsKey("isEncodedForTechnical") && configParam.get("isEncodedForTechnical") != null) {
                                tblTender.setIsEncodedForTechnical(Integer.parseInt(configParam.get("isEncodedForTechnical").toString()));
                            } else {
                                tblTender.setIsEncodedForTechnical(tenderDtBean.getIsEncodedForTechnical());
                            }
                            if (configParam.containsKey("isEncodedForNegotiation") && configParam.get("isEncodedForNegotiation") != null) {
                                tblTender.setIsEncodedForNegotiation(Integer.parseInt(configParam.get("isEncodedForNegotiation").toString()));
                            } else {
                                tblTender.setIsEncodedForNegotiation(tenderDtBean.getIsEncodedForNegotiation());
                            }
                            if (configParam.containsKey("displayEncDeclnk") && configParam.get("displayEncDeclnk") != null) {
                                tblTender.setDisplayEncDeclnk(Integer.parseInt(configParam.get("displayEncDeclnk").toString()));
                            } else {
                                tblTender.setDisplayEncDeclnk(tenderDtBean.getDisplayEncDeclnk());
                            }                            
                            if (configParam.containsKey("isMandatoryDocument") && configParam.get("isMandatoryDocument") != null) {
                                tblTender.setIsMandatoryDocument(Integer.parseInt(configParam.get("isMandatoryDocument").toString()));
                            } else {
                                tblTender.setIsMandatoryDocument(tenderDtBean.getIsMandatoryDocument());
                            }
                            if (configParam.containsKey("isEncDocumentOnly") && configParam.get("isEncDocumentOnly") != null) {
                                tblTender.setIsEncDocumentOnly(Integer.parseInt(configParam.get("isEncDocumentOnly").toString()));
                            } else {
                                tblTender.setIsEncDocumentOnly(tenderDtBean.getIsEncDocumentOnly());
                            }
                            if (configParam.containsKey("isSORApplicable") && configParam.get("isSORApplicable") != null) {
                                tblTender.setIsSORApplicable(Integer.parseInt(configParam.get("isSORApplicable").toString()));
                            } 
                            if (configParam.containsKey("sorVariation") && configParam.get("sorVariation") != null) {
                                tblTender.setSorVariation(new BigDecimal(configParam.get("sorVariation").toString()));
                            } else {
                                tblTender.setSorVariation(tenderDtBean.getSorVariation());
                            }

                            if(isItemWiseWinner==1 || isItemWiseWinner == 2){ // Grand total or Lot wise
                            	 tblTender.setIsRebateForm(0);
                            }else{
                            	if (configParam.containsKey("isRebateForm") && configParam.get("isRebateForm") != null) {
                                    tblTender.setIsRebateForm(Integer.parseInt(configParam.get("isRebateForm").toString()));
                                } else {
                                    tblTender.setIsRebateForm(tenderDtBean.getIsRebateForm());
                                }	
                            }
                            if (configParam.containsKey("isNegotiationAllowed") && configParam.get("isNegotiationAllowed") != null) {
                                tblTender.setIsNegotiationAllowed(Integer.parseInt(configParam.get("isNegotiationAllowed").toString()));
                            } else {
                                tblTender.setIsNegotiationAllowed(tenderDtBean.getIsNegotiationAllowed());
                            }
                            if (configParam.containsKey("isReEvaluationReq") && configParam.get("isReEvaluationReq") != null) {
                                    tblTender.setIsReEvaluationReq(Integer.parseInt(configParam.get("isReEvaluationReq").toString()));
                            }
                            if (configParam.containsKey("isFinalPriceSheetReq") && configParam.get("isFinalPriceSheetReq") != null) {
                                tblTender.setIsFinalPriceSheetReq(Integer.parseInt(configParam.get("isFinalPriceSheetReq").toString()));
                            } else {
                                tblTender.setIsFinalPriceSheetReq(tenderDtBean.getIsFinalPriceSheetReq());
                            }
                            if (configParam.containsKey("decryptorRequired") && configParam.get("decryptorRequired") != null) {
                                tblTender.setDecryptorRequired(Integer.parseInt(configParam.get("decryptorRequired").toString()));
                            } else {
                                tblTender.setDecryptorRequired(tenderDtBean.getDecryptorRequired());
                            }
                            if (configParam.containsKey("isDisplayClarificationDoc") && configParam.get("isDisplayClarificationDoc") != null) {
                                tblTender.setIsDisplayClarificationDoc(Integer.parseInt(configParam.get("isDisplayClarificationDoc").toString()));
                            } else {
                                tblTender.setIsDisplayClarificationDoc(tenderDtBean.getIsDisplayClarificationDoc());
                            }
                            if (configParam.containsKey("isCreateAuction") && configParam.get("isCreateAuction") != null) {
                                tblTender.setIsCreateAuction(Integer.parseInt(configParam.get("isCreateAuction").toString()));
                            } else {
                                tblTender.setIsCreateAuction(tenderDtBean.getIsCreateAuction());
                            }
                            if (configParam.containsKey("encryptionLevel") && configParam.get("encryptionLevel") != null) {
                                tblTender.setEncryptionLevel(Integer.parseInt(configParam.get("encryptionLevel").toString()));
                            } else {
                                tblTender.setEncryptionLevel(tenderDtBean.getEncryptionLevel());
                            }
                            int isPki = abcUtility.getSessionIsPkiEnabled(request);
                            if (isPki == 2) {
                                tblTender.setIsCertRequired(tenderDtBean.getSelIsCertRequired());
                            } else {
                                tblTender.setIsCertRequired(isPki);
                            }
                            if (configParam.containsKey("resultSharing") && configParam.get("resultSharing") != null) {
                                tblTender.setResultSharing(Integer.parseInt(configParam.get("resultSharing").toString()));
                            } else {
                                tblTender.setResultSharing(tenderDtBean.getResultSharing());
                            }
                            if (configParam.containsKey("isPastEvent") && configParam.get("isPastEvent") != null) {
                                tblTender.setIsPastEvent(Integer.parseInt(configParam.get("isPastEvent").toString()));
                            }
                            if (configParam.containsKey("showBidDetail") && configParam.get("showBidDetail") != null) {
                                tblTender.setShowBidDetail(Integer.parseInt(configParam.get("showBidDetail").toString()));
                            }
                            
                            /*** Code to set default value for 3 columns isEMDByBidder,isProcessingFeeByBidder,isDocumentFeeByBidder from client configuration **/
                            if (configParam.containsKey("isEMDByBidder") && configParam.get("isEMDByBidder") != null) {
                                tblTender.setIsEMDByBidder(Integer.parseInt(configParam.get("isEMDByBidder").toString()));
                            }
                            /*** Code to set default value for 2 columns isRestOfEventMoney,isParticipationFeesBy from client configuration **/
                            if (configParam.containsKey("isRestOfEventMoney") && configParam.get("isRestOfEventMoney") != null) {
                                tblTender.setIsRestOfEventMoney(Integer.parseInt(configParam.get("isRestOfEventMoney").toString()));
                            }
                            if (configParam.containsKey("isParticipationFeesBy") && configParam.get("isParticipationFeesBy") != null) {
                                tblTender.setIsParticipationFeesBy(Integer.parseInt(configParam.get("isParticipationFeesBy").toString()));
                            }
                            if (configParam.containsKey("isProcessingFeeByBidder") && configParam.get("isProcessingFeeByBidder") != null) {
                                tblTender.setIsProcessingFeeByBidder(Integer.parseInt(configParam.get("isProcessingFeeByBidder").toString()));
                            }
                            if (configParam.containsKey("isDocumentFeeByBidder") && configParam.get("isDocumentFeeByBidder") != null) {
                                tblTender.setIsDocumentFeeByBidder(Integer.parseInt(configParam.get("isDocumentFeeByBidder").toString()));
                            }
                            if (configParam.containsKey("isEvaluationRequired") && configParam.get("isEvaluationRequired") != null) {
                                tblTender.setIsEvaluationRequired(Integer.parseInt(configParam.get("isEvaluationRequired").toString()));
                            }
                            if (configParam.containsKey("isWeightageEvaluationRequired") && configParam.get("isWeightageEvaluationRequired") != null) {
                                tblTender.setIsWeightageEvaluationRequired(Integer.parseInt(configParam.get("isWeightageEvaluationRequired").toString()));
                            }
                            
                            if (configParam.containsKey("decimalValueUpto") && configParam.get("decimalValueUpto") != null) {
                            	tblTender.setDecimalValueUpto(Integer.parseInt(configParam.get("decimalValueUpto").toString()));
                            }
                            //PT:21539
                            if (configParam.containsKey("isItemSelectionPageRequired") && configParam.get("isItemSelectionPageRequired") != null) {
                                tblTender.setIsItemSelectionPageRequired(Integer.parseInt(configParam.get("isItemSelectionPageRequired").toString()));
                                if(isItemWiseWinner == 0) // If notice is grandtotal wise then it is not applicable.
                                {
                                	tblTender.setIsItemSelectionPageRequired(0);
                                }
                            }
                            if (configParam.containsKey("isDemoTender") && configParam.get("isDemoTender") != null) {
                                tblTender.setIsDemoTender(Integer.parseInt(configParam.get("isDemoTender").toString()));
                            }
                            if (configParam.containsKey("showNoOfBidders") && configParam.get("showNoOfBidders") != null) {
                                tblTender.setShowNoOfBidders(Integer.parseInt(configParam.get("showNoOfBidders").toString()));
                            }
                            
                            if (configParam.containsKey("workflowForBidOpening") && configParam.get("workflowForBidOpening") != null) {
                                tblTender.setWorkflowForBidOpening(Integer.parseInt(configParam.get("workflowForBidOpening").toString()));
                            }
                            if (configParam.containsKey("workflowForNegotiation") && configParam.get("workflowForNegotiation") != null) {
                                tblTender.setWorkflowForNegotiation(Integer.parseInt(configParam.get("workflowForNegotiation").toString()));
                            }
                            
                            /*** Code to set BRD mode 0 for not require in case tender mode is open else set from default configuration **/ 
                            if (tenderDtBean.getSelTenderMode() == 1 && !commonService.isRCIClient(rciClientIds, clientId)) {
                            	tblTender.setBrdMode(0);
                            }
                            else{
                            	if (configParam.containsKey("brdMode") && configParam.get("brdMode") != null) {
                                    tblTender.setBrdMode(Integer.parseInt(configParam.get("brdMode").toString()));
                                }	
                            }
                            // Bug:19243 if stage is multiple then evaluation is require.
                        	if(tenderDtBean.getSelEnvelopeType() == 2) 
                        	{
                        		tblTender.setIsEvaluationRequired(1);	// set to yes.
                        	}
                        	// Project Task #20850   Default Config and Business Rule @jaynam
                        	if (configParam.containsKey("showResultOnHomePage") && configParam.get("showResultOnHomePage") != null) {
                        		tblTender.setShowResultOnHomePage(Integer.parseInt(configParam.get("showResultOnHomePage").toString()));
                        	} else {
                        		tblTender.setShowResultOnHomePage(tenderDtBean.getShowResultOnHomePage());
                        	}
                        	if (configParam.containsKey("winningReportMode") && configParam.get("winningReportMode") != null) {
                        		tblTender.setWinningReportMode(Integer.parseInt(configParam.get("winningReportMode").toString()));
                        	} else {
                        		tblTender.setWinningReportMode(tenderDtBean.getWinningReportMode());
                        	}
                        	if (configParam.containsKey("isReworkRequired") && configParam.get("isReworkRequired") != null) {
                                tblTender.setIsReworkRequired((Integer.parseInt(configParam.get("isReworkRequired").toString())));
                            }
                        	if (configParam.containsKey("isCentralizedTOCRequired") && configParam.get("isCentralizedTOCRequired") != null) {
                        		isCentralizedTOCRequired = (Integer.parseInt(configParam.get("isCentralizedTOCRequired").toString()));
                        		tblTender.setIsCentralizedTOCRequired(Integer.parseInt(configParam.get("isCentralizedTOCRequired").toString()));
                            }
                        	if (configParam.containsKey("isCentralizedTECRequired") && configParam.get("isCentralizedTECRequired") != null) {
                        		isCentralizedTECRequired = (Integer.parseInt(configParam.get("isCentralizedTECRequired").toString()));
                        		tblTender.setIsCentralizedTECRequired(Integer.parseInt(configParam.get("isCentralizedTECRequired").toString()));
                            }
                        	//22806
                        	if (configParam.containsKey("isTwoStageEvaluation") && configParam.get("isTwoStageEvaluation") != null) {
                        		tblTender.setIsTwoStageEvaluation(Integer.parseInt(configParam.get("isTwoStageEvaluation").toString()));
                            }
                        	if (configParam.containsKey("isTwoStageOpening") && configParam.get("isTwoStageOpening") != null) {
                        		tblTender.setIsTwoStageOpening(Integer.parseInt(configParam.get("isTwoStageOpening").toString()));
                            }
                        	if (configParam.containsKey("POType") && configParam.get("POType") != null) {
                        		tblTender.setPOType((Integer.parseInt(configParam.get("POType").toString())));
                            }
                        	if (configParam.containsKey("workflowForTOC") && configParam.get("workflowForTOC") != null) {
                                tblTender.setWorkflowForTOC(Integer.parseInt(configParam.get("workflowForTOC").toString()));
                            }
                        	if (configParam.containsKey("workflowForTEC") && configParam.get("workflowForTEC") != null) {
                                tblTender.setWorkflowForTEC(Integer.parseInt(configParam.get("workflowForTEC").toString()));
                            }
                        	if (configParam.containsKey("showNoOfRegrettedbid") && configParam.get("showNoOfRegrettedbid") != null) {
                                tblTender.setShowNoOfRegrettedbid(Integer.parseInt(configParam.get("showNoOfRegrettedbid").toString()));
                            }
                        	if (configParam.containsKey("showNoOfWithdrawnbid") && configParam.get("showNoOfWithdrawnbid") != null) {
                                tblTender.setShowNoOfWithdrawnbid(Integer.parseInt(configParam.get("showNoOfWithdrawnbid").toString()));
                            }  
                        	if (configParam.containsKey("isItemwiseRegretAllowed") && configParam.get("isItemwiseRegretAllowed") != null) {
                                tblTender.setIsItemwiseRegretAllowed(Integer.parseInt(configParam.get("isItemwiseRegretAllowed").toString()));
                                if(isItemWiseWinner == 0) // If notice is grandtotal wise then it is not applicable.
                                {
                                	//tblTender.setIsItemwiseRegretAllowed(0);
                                }
                            }
                        	if (configParam.containsKey("bidderMapping") && configParam.get("bidderMapping") != null) {
                                tblTender.setBidderMapping(Integer.parseInt(configParam.get("bidderMapping").toString()));
                            } 
                            //CPPP Changes
                            	tblTender.setTenderSector(tenderDtBean.getSelTenderSector());
                            	tblTender.setFormContract(tenderDtBean.getSelFormContract());	
                            	tblTender.setProductId(tenderDtBean.getSelProduct());	
                            	tblTender.setPrequalification(tenderDtBean.getTxtaPrequalification());	
                         /*** --- For CR Id : 51268 and PT : 51630 Start --- ***/   	
                         if (configParam.containsKey("isResultSharingDurationRequired") && configParam.get("isResultSharingDurationRequired") != null) {
                                    tblTender.setIsResultSharingDurationRequired(Integer.parseInt(configParam.get("isResultSharingDurationRequired").toString()));
                             } else {
                                    tblTender.setIsResultSharingDurationRequired(tenderDtBean.getIsResultSharingDurationRequired());
                          }
                          if (configParam.containsKey("resultSharingDuration") && configParam.get("resultSharingDuration") != null) {
                                tblTender.setResultSharingDuration(Integer.parseInt(configParam.get("resultSharingDuration").toString()));
                          } else {
                                tblTender.setResultSharingDuration(tenderDtBean.getResultSharingDuration());
                          }
                         /*** --- For CR Id : 51268 and PT : 51630 End --- ***/
                          if (configParam.containsKey("isCorrPublishbyCommittee") && configParam.get("isCorrPublishbyCommittee") != null) {
                              tblTender.setIsCorrPublishbyCommittee(Integer.parseInt(configParam.get("isCorrPublishbyCommittee").toString()));
                          } else {
                              tblTender.setIsCorrPublishbyCommittee(tenderDtBean.getIsCorrPublishbyCommittee());
                          }
                            /*** End Code **/
                        }
                        else if(opType.equals(EDIT))/*** Start Code to set condition at edit time some fields which not set by edit business rule screen **/
                        {
                        	if (tenderDtBean.getSelTenderMode() == 1 && !commonService.isRCIClient(rciClientIds, clientId)) {
                            	tblTender.setBrdMode(0);
                            }
                        	if(isItemWiseWinner==1 || isItemWiseWinner == 2){ // Grand total or Lot wise
                           	 tblTender.setIsRebateForm(0);
                        	}
                        	int isPki = abcUtility.getSessionIsPkiEnabled(request);
                            if (isPki == 2) {
                                tblTender.setIsCertRequired(tenderDtBean.getSelIsCertRequired());
                            } else {
                                tblTender.setIsCertRequired(isPki);
                            }
                            tblTender.setProductId(tenderDtBean.getSelProduct());
                        	tblTender.setPrequalification(tenderDtBean.getTxtaPrequalification());
                        	tblTender.setFormContract(tenderDtBean.getSelFormContract());
                        	tblTender.setTenderSector(tenderDtBean.getSelTenderSector());
                            tblTender.setDisplayOfficerName(tenderDtBean.getSeldisplayOfficerName());
                        }
                        tblTender.setTenderDetail(tenderDtBean.getRtfTenderDetail());
                        tblTender.setBiddingType(tenderDtBean.getSelBiddingType());
                        tblTender.setEnvelopeType(tenderDtBean.getSelEnvelopeType());
                        tblProcurementNature.setProcurementNatureId(tenderDtBean.getSelProcurementNatureId());
                        if (tenderDtBean.getSelProcurementNatureId() == 5) {
                            tblTender.setOtherProcurementNature(tenderDtBean.getTxtOtherProcNature());
                        } else {
                            tblTender.setOtherProcurementNature("");
                        }
                        tblTender.setTblProcurementNature(tblProcurementNature);
                        int oldWorkflowTypeId = tblTender.getWorkflowTypeId();
                        tblTender.setWorkflowTypeId(tblTender.getIsWorkflowRequired()==1 && tenderDtBean.getSelWorkflowType()==0?tblTender.getWorkflowTypeId():tenderDtBean.getSelWorkflowType());
                        tblTender.setDownloadDocument(tenderDtBean.getSelDownloadDocument());
                        tblTender.setRemark("");
                        tblTender.setUpdatedOn(commonService.getServerDateTime());
                        if (StringUtils.hasLength(tenderDtBean.getTxtTenderValue())) {
                            tblTender.setTenderValue(new BigDecimal(tenderDtBean.getTxtTenderValue()).setScale(tenderDtBean.getSelDecimalValueUpto(), 2));
                        } else {
                            tblTender.setTenderValue(BigDecimal.ZERO);
                        }
                        if (StringUtils.hasLength(tenderDtBean.getTxtValidityPeriod())) {
                            tblTender.setValidityPeriod(Integer.parseInt(tenderDtBean.getTxtValidityPeriod()));
                        } else {
                            tblTender.setValidityPeriod(0);
                        }
                        tblTender.setIsSplitPOAllowed(tenderDtBean.getSelIsSplitPOAllowed());
                        tblTender.setIsItemwiseWinner(tenderDtBean.getSelIsItemwiseWinner());
                        if(tblTender.getIsItemwiseWinner() == 0) // If notice is grandtotal wise then it is not applicable.
                        {
                        	tblTender.setIsItemSelectionPageRequired(0);
                        }
                        if(tblTender.getIsItemwiseWinner() == 0) // If notice is grandtotal wise then it is not applicable.
                        {
                        	//tblTender.setIsItemwiseRegretAllowed(0);
                        }
                        tblTender.setSubmissionMode(tenderDtBean.getSelSubmissionMode());
                        tblTender.setBiddingVariant(tenderDtBean.getSelBiddingVariant());
                        if(tblTender.getBiddingVariant() == 2) // bug: 19108 // if variant is for sell then rebate value will be 0.
                        {
                        	tblTender.setIsRebateForm(0); 
                        }
                        tblTender.setTenderMode(tenderDtBean.getSelTenderMode());
                        tblEventType.setEventTypeId(eventTypeId);
                        tblTender.setTblEventType(tblEventType);
                        if (StringUtils.hasLength(tenderDtBean.getTxtProjectDuration())) {
                            tblTender.setProjectDuration(tenderDtBean.getTxtProjectDuration());
                        } else {
                            tblTender.setProjectDuration("0");
                        }
                        if (tblTender.getSubmissionMode() == 2) {
                            tblTender.setDocumentSubmission(tenderDtBean.getTxtaDocumentSubmission());
                        } else {
                            tblTender.setDocumentSubmission("");
                        }
                        tblTender.setIsConsortiumAllowed(tenderDtBean.getSelIsConsortiumAllowed());
                        tblTender.setIsBidWithdrawal(tenderDtBean.getSelIsBidWithdrawal());
                        tblTender.setIsPreBidMeeting(tenderDtBean.getSelIsPreBidMeeting());
                        if (tblTender.getIsPreBidMeeting() == 1) {
                            tblTender.setPreBidStartDate(conversionService.convert(tenderDtBean.getTxtPreBidStartDate(), Date.class));
                            tblTender.setPreBidEndDate(conversionService.convert(tenderDtBean.getTxtPreBidEndDate(), Date.class));
                            tblTender.setPreBidMode(tenderDtBean.getSelPreBidMode());
                            if (tblTender.getPreBidMode() == 2) {
                                tblTender.setPreBidAddress(tenderDtBean.getTxtaPreBidAddress());
                            } else {
                                tblTender.setPreBidAddress("");
                            }
                        } else {
                            tblTender.setPreBidAddress("");
                            tblTender.setPreBidMode(2);
                        }
                        tblTender.setIsQuestionAnswer(tenderDtBean.getSelIsQuestionAnswer());
                        if (tblTender.getIsQuestionAnswer() == 1) {
                            tblTender.setQuestionAnswerStartDate(conversionService.convert(tenderDtBean.getTxtQuestionAnswerStartDate(), Date.class));
                            tblTender.setQuestionAnswerEndDate(conversionService.convert(tenderDtBean.getTxtQuestionAnswerEndDate(), Date.class));
                        }
                        if(isWorkflowReq == true){
                        	if(oldWorkflowTypeId != tenderDtBean.getSelWorkflowType()){
                        		eventCreationService.deleteWorkflowConfiguration(tenderId);
                        	}
                        	if(opType.equals(EDIT)){
	                        	if(!referenceNo.equals(tenderDtBean.getTxtTenderNo())){
	                    			eventCreationService.updateWorkflowReferenceNo(tenderId,tenderDtBean.getTxtTenderNo());
	                    		}
                        	}
                    		tblTender.setIsWorkflowRequired(tenderDtBean.getSelIsWorkflowRequired());
                    	}else{
                    		tblTender.setIsWorkflowRequired(0);
                    	}
                        
                        if((tenderDtBean.getTxtDocumentStartDate() != "" && tenderDtBean.getTxtDocumentStartDate() != null) || tenderDtBean.getHdIsDateValidationAllow() == 0){
                        	tblTender.setDocumentStartDate(conversionService.convert(tenderDtBean.getTxtDocumentStartDate(), Date.class));	
                        }
                        if((tenderDtBean.getTxtDocumentEndDate() != "" && tenderDtBean.getTxtDocumentEndDate() != null) || tenderDtBean.getHdIsDateValidationAllow() == 0){
                        	tblTender.setDocumentEndDate(conversionService.convert(tenderDtBean.getTxtDocumentEndDate(), Date.class));	
                        }
                        if(tenderDtBean.getTxtEmdSubmissionEndDate() != "" && tenderDtBean.getTxtEmdSubmissionEndDate() != null){
                        	tblTender.setEmdSubmissionEndDate(conversionService.convert(tenderDtBean.getTxtEmdSubmissionEndDate(), Date.class));
                        }else{
                        	tblTender.setEmdSubmissionEndDate(conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class));
                        }
                        tblTender.setSubmissionStartDate(conversionService.convert(tenderDtBean.getTxtSubmissionStartDate(), Date.class));
                        tblTender.setSubmissionEndDate(conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class));
                        tblTender.setOpeningDate(conversionService.convert(tenderDtBean.getTxtBidOpenDate(), Date.class));
                        tblTender.setIsDocfeesApplicable(tenderDtBean.getSelIsDocfeesApplicable());
                        
                        //PT: 20681
                        tblTender.setRegistrationCharges(tenderDtBean.getTxtRegistrationCharges());//PT: 20681
                        tblTender.setRegistrationChargesMode(tenderDtBean.getSelRegistrationChargesMode());
                        tblTender.setIsRegistrationCharges(tenderDtBean.getSelIsRegistrationCharges());
                        if(tblTender.getIsRegistrationCharges()==0){
                        	tblTender.setRegistrationChargesMode(0);
                        	tblTender.setRegistrationCharges("");
                        }
                        if (tblTender.getIsRegistrationCharges() == 2) {
                            	tblTender.setRegistrationCharges(new BigDecimal(0).setScale(tenderDtBean.getSelDecimalValueUpto(), 2).toString());
                        }
                        if (tblTender.getIsDocfeesApplicable() == 1 || tblTender.getIsDocfeesApplicable() == 2) {
                            tblTender.setDocFeePaymentMode(tenderDtBean.getSelDocFeePaymentMode());
                            if(tblTender.getIsDocfeesApplicable() == 2){
                            	tblTender.setDocumentFee(new BigDecimal(0).setScale(tenderDtBean.getSelDecimalValueUpto(), 2).toString());
                            }else{
                            	tblTender.setDocumentFee(new BigDecimal(tenderDtBean.getTxtDocumentFee()).setScale(tenderDtBean.getSelDecimalValueUpto(), 2).toString());
                            }
                            
                            if (tblTender.getDocFeePaymentMode() == 2) {
                                tblTender.setDocFeePaymentAddress(tenderDtBean.getTxtaDocFeePaymentAddress());
                            } else {
                                tblTender.setDocFeePaymentAddress("");
                            }
                        } else {
                            tblTender.setDocumentFee("");
                            tblTender.setDocFeePaymentAddress("");
                            tblTender.setDocFeePaymentMode(0);
                        }
                        tblTender.setIsSecurityfeesApplicable(tenderDtBean.getSelIsSecurityfeesApplicable());
                        if (tblTender.getIsSecurityfeesApplicable() == 1) {
                            tblTender.setSecurityFee(new BigDecimal(tenderDtBean.getTxtSecurityFee()).setScale(tenderDtBean.getSelDecimalValueUpto(), 2).toString());
                            tblTender.setSecFeePaymentMode(tenderDtBean.getSelSecFeePaymentMode());
                            if (tblTender.getSecFeePaymentMode() == 2) {
                                tblTender.setSecFeePaymentAddress(tenderDtBean.getTxtaSecFeePaymentAddress());
                            } else {
                                tblTender.setSecFeePaymentAddress("");
                            }
                        } else {
                            tblTender.setSecurityFee("");
                            tblTender.setSecFeePaymentMode(0);
                            tblTender.setSecFeePaymentAddress("");
                        }
                        tblTender.setIsEMDApplicable(tenderDtBean.getSelIsEMDApplicable());
                        if (tblTender.getIsEMDApplicable() == 1 || tblTender.getIsEMDApplicable() == 2 || tblTender.getIsEMDApplicable() == 3) {
                        	
                        	if( tblTender.getIsEMDApplicable() == 2){  
                        		tblTender.setEmdAmount(new BigDecimal(0).setScale(tenderDtBean.getSelDecimalValueUpto(), 2).toString());
                        		tblTender.setMinEmdAmt("");
                                tblTender.setMaxEmdAmt("");
                        	}else if( tblTender.getIsEMDApplicable() == 3){
                        		tblTender.setMinEmdAmt(new BigDecimal(tenderDtBean.getTxtMinEmdAmt()).setScale(tenderDtBean.getSelDecimalValueUpto(), 2).toString());
                        		tblTender.setMaxEmdAmt(new BigDecimal(tenderDtBean.getTxtMaxEmdAmt()).setScale(tenderDtBean.getSelDecimalValueUpto(), 2).toString());
                        		tblTender.setEmdAmount("");
                        	}else{
                        		tblTender.setEmdAmount(new BigDecimal(tenderDtBean.getTxtEmdAmount()).setScale(tenderDtBean.getSelDecimalValueUpto(), 2).toString());
                        		tblTender.setMinEmdAmt("");
                                tblTender.setMaxEmdAmt("");
                        	}
                        	
                            tblTender.setEmdPaymentMode(tenderDtBean.getSelEmdPaymentMode());
                            if (tblTender.getEmdPaymentMode() == 2) {
                                tblTender.setEmdPaymentAddress(tenderDtBean.getTxtaEmdPaymentAddress());
                            } else {
                                tblTender.setEmdPaymentAddress("");
                            }
                        } else {
                            tblTender.setEmdPaymentMode(0);
                            tblTender.setEmdAmount("");
                            tblTender.setMinEmdAmt("");
                            tblTender.setMaxEmdAmt("");
                            tblTender.setEmdPaymentAddress("");
                        }
                        tblTender.setCurrencyId(tenderDtBean.getSelCurrencyId());
                         //CR #52114
                        
                        	tblTender.setIsGSTRequired(isGSTRequired);
                        	tblTender.setTaxType(tenderDtBean.getSelTaxType());
                            tblTender.setCgst(tenderDtBean.getHdCgst());
                            tblTender.setSgst(tenderDtBean.getHdSgst());
                            tblTender.setIgst(tenderDtBean.getHdIgst());
                        
                    } else {
                        success = false;
                    }
                    tblCurrency.setCurrencyId(tenderDtBean.getSelCurrencyId());
                    tblTenderCurrency = new TblTenderCurrency();
                    tblTenderCurrency.setTblTender(tblTender);
                    tblTenderCurrency.setTblCurrency(tblCurrency);
                    tblTenderCurrency.setIsDefault(1);
                    tblTenderCurrency.setIsActive(1);
                    tblTenderCurrency.setExchangeRate(BigDecimal.ONE);
                    if (stcurrIdList != null && tblTender.getBiddingType() == 2) {
                        tblTenderCurrencys = new ArrayList<TblTenderCurrency>();
                        while (stcurrIdList.hasMoreTokens()) {
                            String selCurId = stcurrIdList.nextToken();
                            if (Integer.parseInt(selCurId) != tenderDtBean.getSelCurrencyId()) {
                                tblCurrency = new TblCurrency();
                                tblCurrency.setCurrencyId(Integer.parseInt(selCurId));
                                tblTenderCurrency1 = new TblTenderCurrency();
                                tblTenderCurrency1.setTblTender(tblTender);
                                tblTenderCurrency1.setTblCurrency(tblCurrency);
                                tblTenderCurrency1.setIsDefault(0);
                                tblTenderCurrency1.setExchangeRate(BigDecimal.ZERO);
                                tblTenderCurrency1.setIsActive(1);
                                tblTenderCurrencys.add(tblTenderCurrency1);
                            }
                        }
                    }
                    if (tenderDtBean.getSelFormType() != null) {
                    	if(tblTender.getIsItemwiseWinner() != 0){ 	// Bug: 19464 if price bid or techno commerce envelop is selected then winner selection is based on create\edit other wise grand total wise.
                        	boolean isGrandTotalWiseWinner = true;
	                    	for (int i = 0; i < tenderDtBean.getSelFormType().length; i++) {
	                    	
	                    		if(tenderDtBean.getSelFormType()[i].equals("4") || tenderDtBean.getSelFormType()[i].equals("5")) 
	                    		{
	                    			isGrandTotalWiseWinner = false;
	                    		}
	                    	}
	                    	if(isGrandTotalWiseWinner)
	                    	{
	                    		tblTender.setIsItemwiseWinner(0);
	                    	}
                    	}
                        for (int i = 0; i < tenderDtBean.getSelFormType().length; i++) {
                            tblTenderEnvelope = new TblTenderEnvelope();
                            tblTenderEnvelope.setEnvelopeName(eventCreationService.getEnvelopeNameById(Integer.parseInt(tenderDtBean.getSelFormType()[i])));
                            tblTenderEnvelope.setTblTender(tblTender);
                            tblEnvelope = new TblEnvelope();
                            tblEnvelope.setEnvId(Integer.parseInt(tenderDtBean.getSelFormType()[i]));
                            if (tenderDtBean.getSelEventType() == 2) {
                                tblTenderEnvelope.setOpeningDate(conversionService.convert(tenderDtBean.getTxtBidOpenDate(), Date.class));
                            }
                            tblTenderEnvelope.setSortOrder(i + 1);
                            tblTenderEnvelope.setNoOfFormsReq(0);
                            tblTenderEnvelope.setMinOpeningMember(0);
                            tblTenderEnvelope.setMinEvaluator(0);
                            tblTenderEnvelope.setIsOpened(0);
                            tblTenderEnvelope.setIsEvaluated(0);
                            tblTenderEnvelope.setCreatedBy(userDetailId);
                            tblTenderEnvelope.setCstatus(1);
                            tblTenderEnvelope.setTblEnvelope(tblEnvelope);
                            tblTenderEnvelope.setRemark("");
                            lstTenderEnvelope.add(tblTenderEnvelope);
                            
                        }
                    } else {
                        success = false;
                    }
                    
                    tblTender.setOfficerUserDetailId(commonService.getUserDetailIdFromUserId(tblTender.getOfficerId(),clientId));
                    if (CREATE.equals(opType) && success) {
                    	boolean isMVPVertical = clientService.isClientMVPVertical(clientId, mvpSectorId);
                    	Map<String,Integer> proceParam = new HashMap<String, Integer>();
                    	proceParam.put("indentId",indentId);
                    	proceParam.put("linkId",1);//for tender static
                    	proceParam.put("isMVPVertical", isMVPVertical == true ? 1 : 0);
                    	proceParam.put("clientId", clientId);
                    	proceParam.put("userDetailId", userDetailId);
                    	proceParam.put("moduleId", 3);
                        success = eventCreationService.addTenderAllDetails(tblTender, tblTenderCurrency, tblTenderCurrencys, tenderDtBean, lstTenderEnvelope,proceParam);
                    } else {
                        List<Integer> lstFormEnv = new ArrayList<Integer>();
                        String txtRmvForm = tenderDtBean.getTxtRmvFormList();
                        StringTokenizer stRmvForm = null;
                        if (StringUtils.hasLength(txtRmvForm)) {
                            stRmvForm = new StringTokenizer(txtRmvForm, ",");
                        }
                        if (stRmvForm != null) {
                            while (stRmvForm.hasMoreTokens()) {
                                lstFormEnv.add(Integer.parseInt(stRmvForm.nextToken()));
                            }
                        }
                        
                        boolean isMVPVertical = clientService.isClientMVPVertical(clientId, mvpSectorId);
                        Map<String,Integer> proceParam = new HashMap<String, Integer>();
                        proceParam.put("isMVPVertical", isMVPVertical == true ? 1 : 0);
                    	proceParam.put("clientId", clientId);
                    	proceParam.put("userDetailId", userDetailId);
                    	proceParam.put("moduleId", 3);
                    	proceParam.put("oldTenderResult", oldTenderResult);
                        success = eventCreationService.updateTenderAllDetails(tblTender, tblTenderCurrency, tblTenderCurrencys, tenderDtBean, lstTenderEnvelope, lstFormEnv, proceParam);
                        if(success){
                        	//Start Bug Id #26620: When Officer Change Item wise L1/H1 it have to remove old mapped bidder
                        	if((oldTenderResult != tblTender.getTenderResult() || oldTenderMode !=  tblTender.getTenderMode()) && (oldTenderMode==2 || oldTenderMode==3 || oldTenderMode==4)){
                        		eventBidderMapService.deleteMappedBidder(tenderId,oldTenderResult);
                        	}
                        	//End Bug Id #26620: When Officer Change Item wise L1/H1 it have to remove old mapped bidder
                            success = eventCreationService.updateTenderFormEncryptionReq(tblTender.getTenderId(), tblTender.getIsCertRequired());
                        }
                    }
                    //Start : Change Request #21427
                    if(success){
                    	if(isCentralizedTOCRequired == 1){
                    		centralizedCommitteeType = 1;
                    		success = setCommitteeDetailsFromCentralized(clientId,tblTender,centralizedCommitteeType,lstTenderEnvelope,userDetailId);
                    	}
                    	if(isCentralizedTECRequired == 1){
                    		centralizedCommitteeType = 2;
                    		success = setCommitteeDetailsFromCentralized(clientId,tblTender,centralizedCommitteeType,lstTenderEnvelope,userDetailId);
                    	}
                    }
                   //End : Change Request #21427
                  //Start : Change Request #22742 For RCI
                   if(success){
                    	success = dynamicFieldService.addDynamicFieldValueProcess(dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request),clientId,tendercreationlink,tblTender.getTenderId(),userId);
                    }
                   //End : Change Request #22742
                    if (success) {
                        if (EDIT.equals(opType)) {
                        	if(abcUtility.isModuleAssignToClient(request,9)){
                        		commonService.insertUpdateCategory(opType,tenderId,selectedCategory,tendercreationlink);
                        	}
                            redirectMessage = "msg_update_tender";
                            retVal = REDIRECTDASHBOARD + tenderId + "/1" + encryptDecryptUtils.generateRedirect(DASHBOARD + tenderId + "/1", request);
                        } else {
                        	if(abcUtility.isModuleAssignToClient(request,9)){
                        		commonService.insertUpdateCategory(opType,tblTender.getTenderId(),selectedCategory,tendercreationlink);
                        	}
                            redirectMessage = "msg_create_tender";
                            retVal = "redirect:/etender/buyer/viewtender/" + tblTender.getTenderId() + encryptDecryptUtils.generateRedirect("etender/buyer/viewtender/" + tblTender.getTenderId(), request);
                        }
                    } else {
                        if (CREATE.equals(opType)) {
                            redirectMessage = CommonKeywords.ERROR_MSG_KEY.toString();
                            retVal = "redirect:/etender/buyer/tenderlisting/" + encryptDecryptUtils.generateRedirect("etender/buyer/tenderlisting/", request);
                        } else {
                            redirectMessage = CommonKeywords.ERROR_MSG_KEY.toString();
                            retVal = "redirect:/etender/buyer/tenderlisting/" + encryptDecryptUtils.generateRedirect("etender/buyer/tenderlisting/", request);
                        }
                    }
                    
                  //Start : PT #38371
                    if(success){
                    	int moduleId = 3;
                    	if (tblTender.getIsDocfeesApplicable() != 0) {
                    		String docPaymentTypes[] = tenderDtBean.getSelDocFeePaymentType();
                    		for (String docPType : docPaymentTypes) {
                        		TblEventPayment tblEventPayment=new TblEventPayment();
                        		tblEventPayment.setObjectId(tblTender.getTenderId());
                        		tblEventPayment.setTblClient(new TblClient(clientId));
                        		tblEventPayment.setTblPaymentType(new TblPaymentType(Integer.parseInt(docPType)));
                        		tblEventPayment.setPaymentFor(1);  // 1 For DocFees
                        		tblEventPayment.setModuleId(moduleId);
                        		tblEventPayment.setIsActive(1);
                        		tblEventPayment.setCreatedBy(userId);
                        		tblEventPayments.add(tblEventPayment);
                        	}
                    	}
                    	
                    	if (tblTender.getIsSecurityfeesApplicable() != 0) {
                    		
                    		String secPaymentTypes[] = tenderDtBean.getSelsecPaymentType(); //request.getParameterValues("selsecPaymentType");
                        	for (String secPType : secPaymentTypes) {
                        		TblEventPayment tblEventPayment=new TblEventPayment();
                        		tblEventPayment.setObjectId(tblTender.getTenderId());
                        		tblEventPayment.setTblClient(new TblClient(clientId));
                        		tblEventPayment.setTblPaymentType(new TblPaymentType(Integer.parseInt(secPType)));
                        		tblEventPayment.setPaymentFor(10);  // 10 For Security Fees
                        		tblEventPayment.setModuleId(moduleId);
                        		tblEventPayment.setIsActive(1);
                        		tblEventPayment.setCreatedBy(userId);
                        		tblEventPayments.add(tblEventPayment);
                        	}
                    	}
                    	
                    	if (tblTender.getIsEMDApplicable() != 0) {
                    		
                    		String emdPaymentTypes[] = tenderDtBean.getSelemdPaymentType(); //request.getParameterValues("selemdPaymentType");
                        	for (String emdPType : emdPaymentTypes) {
                        		TblEventPayment tblEventPayment=new TblEventPayment();
                        		tblEventPayment.setObjectId(tblTender.getTenderId());
                        		tblEventPayment.setTblClient(new TblClient(clientId));
                        		tblEventPayment.setTblPaymentType(new TblPaymentType(Integer.parseInt(emdPType)));
                        		tblEventPayment.setPaymentFor(2); // 2 For EMD
                        		tblEventPayment.setModuleId(moduleId);
                        		tblEventPayment.setIsActive(1);
                        		tblEventPayment.setCreatedBy(userId);
                        		tblEventPayments.add(tblEventPayment);
                        	}
                    	}
                    	
                    	if (tblTender.getIsRegistrationCharges() != 0) {
                    		
                    		String regFeesPaymentTypes[] = tenderDtBean.getSelregPaymentType(); ///request.getParameterValues("selregPaymentType");
                         	for (String regFeesPType : regFeesPaymentTypes) {
                         		TblEventPayment tblEventPayment=new TblEventPayment();
                         		tblEventPayment.setObjectId(tblTender.getTenderId());
                         		tblEventPayment.setTblClient(new TblClient(clientId));
                         		tblEventPayment.setTblPaymentType(new TblPaymentType(Integer.parseInt(regFeesPType)));
                         		tblEventPayment.setPaymentFor(8);  // 8 For Reg/Participation Fees
                         		tblEventPayment.setModuleId(moduleId);
                         		tblEventPayment.setIsActive(1);
                         		tblEventPayment.setCreatedBy(userId);
                         		tblEventPayments.add(tblEventPayment);
                         	}
                    	}
                    	
                    	if (EDIT.equals(opType)) {
                    		eventCreationService.updateEventPaymentType(tblTender.getTenderId(),moduleId);
                    	}
                    	eventCreationService.addTenderPaymentType(tblEventPayments);
                    }
                  //End : PT #38371
                    
                } else {
                	
                	if(!tenderPublishChk){// If tender is all ready publish then not edit and redirect to dash board
                		if(tblTender.getCstatus()==3){
                			redirectMessage = "msg_validation_edit_notice";
                		}else{
                		redirectMessage = "msg_event_not_edit_after_publish";
                		}
                        retVal = REDIRECTDASHBOARD + tenderId + "/1" + encryptDecryptUtils.generateRedirect(DASHBOARD + tenderId + "/1", request);
                	}else{
                		if (CREATE.equals(opType)) {
                            createTenderModelMap(modelMap, request, eventTypeId, clientId);
                        } else {
                            updateTenderModelMap(tenderDtBean, modelMap, request, tenderId, eventTypeId, "yes");
                        }
                        modelMap.addAttribute("isOnlinePayment",clientService.getClientById(clientId).getIsOnlinePayment());
                        retVal = "/etender/buyer/CreateTender";	
                	}
                }
            }
        } catch (Exception e) {
            success = false;
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkid, auditMessage, tenderId, 0);
        }
        if (success) {
            redirectAttributes.addFlashAttribute(success ? !tenderPublishChk ? CommonKeywords.ERROR_MSG.toString() : CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), redirectMessage);
        }
        return retVal;
    }
    /**
	 * author Lipi Shah
	 * used for set committee details from centralized TOC/TEC comm. 
	 * @return
	 */
    private boolean setCommitteeDetailsFromCentralized(int clientId,TblTender tblTender,int centralizedCommitteeType,List<TblTenderEnvelope> lstTenderEnvelope,int userDetailId) throws Exception{
    		boolean success = false;
    		TblCentralizedCommittee tblCentralizedCommittee= committeeFormationService.getCentralizedCommitteeDetails(centralizedCommitteeType,clientId);
    		if(tblCentralizedCommittee!=null){
    			TblCommittee tblCommittee = new TblCommittee();
        		tblCommittee.setCommitteeName(tblCentralizedCommittee.getCentralizedCommitteeName());
        		int committeeType = tblCentralizedCommittee.getCentralizedCommitteeType();
        		tblCommittee.setCommitteeType(committeeType);
        		tblCommittee.setTblClient(new TblClient(clientId));
    			tblCommittee.setTblTender(tblTender);
    			tblCommittee.setIsStandard(0);
    			tblCommittee.setRemarks("");
    			tblCommittee.setCreatedBy(userDetailId);
    			tblCommittee.setIsActive(1);
    			//22806
    			boolean isTwoStageEvaluation = false;
    			boolean isTwoStageOpening = false;
    			if(committeeType==2){
    				isTwoStageEvaluation = tblTender.getIsTwoStageEvaluation() == 1 ? true : false;
    			}else if(committeeType==1){
    				isTwoStageOpening = tblTender.getIsTwoStageOpening() == 1 ? true : false;
    			}
				List<TblCentralizedCommitteeUser> committeeUsers = committeeFormationService.getCentralizedCommitteeUsers(tblCentralizedCommittee.getCentralizedCommitteeId(),1);
				List<TblCommitteeUser> tblCommitteeUserList = new ArrayList<TblCommitteeUser>();
				if(committeeUsers!=null && !committeeUsers.isEmpty()){
					for (TblCentralizedCommitteeUser users : committeeUsers) {
						TblCommitteeUser tblCommitteeUser = new TblCommitteeUser();
						tblCommitteeUser.setTblCommittee(tblCommittee);
						tblCommitteeUser.setTblUserLogin(new TblUserLogin(users.getTblUserLogin().getUserId()));
						tblCommitteeUser.setTblUserDetail(new TblUserDetail(users.getTblUserDetail().getUserDetailId()));
						tblCommitteeUser.setChildId(0);
						tblCommitteeUser.setIsDecryptor(0);
						tblCommitteeUser.setEncryptionLevel(0);
						tblCommitteeUser.setRemarks("");
						tblCommitteeUser.setCreatedBy(userDetailId);
						tblCommitteeUser.setIsApproved(0);
						if(isTwoStageOpening){
							tblCommitteeUser.setUserRoleId(users.getUserRoleId());
						}else if(isTwoStageEvaluation){
							tblCommitteeUser.setUserRoleId(users.getUserRoleId());
						}else{
							tblCommitteeUser.setUserRoleId(0);
						}
						tblCommitteeUserList.add(tblCommitteeUser);
					}
				}
				List<TblCommitteeEnvelope> tblCommitteeEnvelopes = new ArrayList<TblCommitteeEnvelope>();
				for(TblTenderEnvelope envelopes: lstTenderEnvelope){
					TblCommitteeEnvelope committeeEnvelope = new TblCommitteeEnvelope();
					committeeEnvelope.setMinMemberApproval(0);
					committeeEnvelope.setTblCommittee(tblCommittee);
					committeeEnvelope.setTblTenderEnvelope(envelopes);
					tblCommitteeEnvelopes.add(committeeEnvelope);
				}
				success = committeeFormationService.addCommittee(tblCommittee, tblCommitteeUserList, tblCommitteeEnvelopes, committeeType, 0);
    		}else{
    			success = true;//IscentralizedTOC yes bt centralized committee not created
    		}
			return success;
    }

    /**
     * generate List<SelectItem> for get value from tbl_Field for fill combo at
     * CreateTender.jsp page
     *
     * @param String data
     * @return List<SelectItem>
     */
    public List<SelectItem> generateList(String data) {
        String[] dataOne = data.split("~");
        List<SelectItem> dataList = new ArrayList<SelectItem>();
        for (String tempData : dataOne) {
            String[] dataTwo = tempData.split("::");
            dataList.add(new SelectItem(messageSource.getMessage(dataTwo[0], null, LocaleContextHolder.getLocale()), dataTwo[1]));
        }
        return dataList;
    }

    /**
     * generate Map for get value from tbl_Field for view value at
     * viewTender.jsp page
     *
     * @param String data
     * @return Map<Integer, String>
     */
    public Map<Integer, String> generateDataMap(String data) {
        String[] dataOne = data.split("~");
        Map<Integer, String> dataMap = new HashMap<Integer, String>();
        for (String tempData : dataOne) {
            String[] dataTwo = tempData.split("::");
            dataMap.put(Integer.parseInt(dataTwo[1]), messageSource.getMessage(dataTwo[0], null, LocaleContextHolder.getLocale()));
        }
        return dataMap;
    }

    /**
     * ajax call for get officer from department
     *
     * @param deptId
     * @return String
     */
    @RequestMapping(value = "/etender/buyer/ajax/getdepartmentofficer", method = RequestMethod.POST)
    @ResponseBody
    public String getDepartmentOfficer(@RequestParam("deptId") String deptId, HttpServletRequest request) {
        String retVal = null;
        try {
            if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
                retVal = encryptDecryptUtils.getOptions("selDeptOfficial", abcUtility.convert(eventCreationService.getDepartmentOfficer(Integer.parseInt(deptId), abcUtility.getSessionClientId(request))), true, "", messageSource.getMessage("auc_please_selectmsg", null, LocaleContextHolder.getLocale()));
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return retVal;
    }

    /**
     * view Tender and tenderId is pathVariable
     *
     * @param Integer tenderId
     * @param ModelMap modelMap
     * @param HttpServletRequest request
     * @return to String
     */
    @RequestMapping(value = {"/etender/buyer/viewtender/{tenderId}/{enc}", "/etender/bidder/viewtender/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String viewTender(@PathVariable(TENDERID) Integer tenderId, ModelMap modelMap, HttpServletRequest request) {
        return viewTenderDetails(tenderId, 0, modelMap, request);
    }
    
    /**
     * This method is used to view reference tender details
     * @author jitendra
     * @param Integer tenderId
     * @param ModelMap modelMap
     * @param HttpServletRequest request
     * @return to String
     */
    @RequestMapping(value = {"/etender/buyer/viewReferenceTender/{tenderId}/{isReference}/{enc}"}, method = RequestMethod.GET)
    public String viewReferenceTender(@PathVariable(TENDERID) Integer tenderId, @PathVariable("isReference") int isReference, ModelMap modelMap, HttpServletRequest request) {
        return viewTenderDetails(tenderId, isReference, modelMap, request);
    }
    
    /**
     * The common method to view tender details
     * @author jitendra
     * @param tenderId
     * @param isReference
     * @param modelMap
     * @param request
     * @return
     */
    private String viewTenderDetails(Integer tenderId, int isReference, ModelMap modelMap, HttpServletRequest request){
    	try {
            int clientId = abcUtility.getSessionClientId(request);
            int userTypeId=0;
            modelMap.addAttribute(USERTYPE, abcUtility.getSessionUserTypeId(request));
            modelMap.addAttribute("isWorkFlow", 0);
            if(isReference==1){
            	modelMap.addAttribute("isReference", isReference);
            }
            int isGSTRequired = (Integer)tenderCommonService.getTenderField(tenderId, "isGSTRequired");
            modelMap.addAttribute("isGSTRequired", isGSTRequired);
            eventCreationService.tenderView(tenderId, modelMap, clientId);
            TblTender tblTender = (TblTender) modelMap.get(TBLTENDER);
            getCustomConfigData(modelMap, clientId, tblTender.getTblEventType().getEventTypeId(), VIEW);
            //PT:20193
            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            if(clientBean.getIsPkiEnabled()==pkiEventSpecific){
            	modelMap.addAttribute("isPkiEventSpecific", true);
            }
            modelMap.addAttribute("linkId", regenerateTenderBrd);
    		modelMap.addAttribute("isReadOnly", "Y");
    		//modelMap.addAttribute("isAuctionDocDownload", "Y");
    		modelMap.addAttribute("objectId",tenderId);
                 modelMap.addAttribute("isAuctionDocDownload","Y");
                 modelMap.addAttribute("eventName", commonService.getEventType(tblTender.getTblEventType().getEventTypeId()).get(0));
    		userTypeId=abcUtility.getSessionUserTypeId(request);
    		
    		/*** Start Code to view document approve and cancel both side officer and bidder **/
    		modelMap.addAttribute("cStatusDoc", -2);
    		
//    		if(userTypeId == 2){
//    			modelMap.addAttribute("cStatusDoc", -2);
//    		}else{
//    			modelMap.addAttribute("cStatusDoc", 3);
//    		}
    		/*** End Code to view document approve and cancel both side officer and bidder **/
    		
			if(abcUtility.isModuleAssignToClient(request,9)){
            	modelMap.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
            	if(modelMap.get("isCategoryAllow").equals(1)){
            		modelMap.addAttribute("categoryNameList", commonService.getCategoryNameList(tenderId,tendercreationlink));
            		modelMap.addAttribute("eventTypeId", tblTender.getTblEventType().getEventTypeId());
            	}
        	}else{
        		modelMap.put("isCategoryAllow",0);
        	}
			//Change Request #19581
            if(tblTender.getTblEventType().getEventTypeId() != 5){
            	modelMap.addAttribute("eventBannerContacts",eventCreationService.eventBannerContactList(clientId));
            }
            List<Object[]> configureThemeList = clientService.getConfiguredThemeData(clientId);
            if(configureThemeList!=null && !configureThemeList.isEmpty()){
                if(configureThemeList.get(0)[0]!=null){
                    modelMap.addAttribute("selectedthemeId", configureThemeList.get(0)[0]);    
                }
            }
            modelMap.addAttribute("isSystemGeneratedTenderDoc", tblTender.getIsSystemGeneratedTenderDoc());
            modelMap.addAttribute("isCPPPRequire", clientService.checkCPPPRequireOrNot(clientId));
            modelMap.addAttribute("isCPPPConfigure",clientService.checkCPPPConfigureOrNot(clientId));
            modelMap.addAttribute("checkpricebid",eventCreationService.checkpricebidform(tenderId)!=0);
            modelMap.addAttribute("isOnlinePayment",clientService.getClientById(clientId).getIsOnlinePayment());
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderviewlink, getviewtendernotice, tenderId, 0);
        }
        return "/etender/buyer/ViewTenderDetails";
    }
    
    /**
     * view Tender dixit
     *
     * @param enc
     * @param tenderId
     * @param abcStatus
     * @param showBtn
     * @return to String
     */
    @RequestMapping(value = {"/etender/buyer/viewwftender/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String viewWFTender(@PathVariable(TENDERID) Integer tenderId, ModelMap modelMap, HttpServletRequest request) {
        try {
            int clientId = abcUtility.getSessionClientId(request);
            modelMap.addAttribute(USERTYPE, abcUtility.getSessionUserTypeId(request));
            modelMap.addAttribute("isWorkFlow", 1);
            eventCreationService.tenderView(tenderId, modelMap, clientId);
            TblTender tblTender = (TblTender) modelMap.get(TBLTENDER);           
            getCustomConfigData(modelMap, clientId, tblTender.getTblEventType().getEventTypeId(), VIEW);
            modelMap.addAttribute("documentList", fileUploadService.getOfficerDocs(tenderId, clientId, 175,-1));
            modelMap.addAttribute("linkId", 175);
    		modelMap.addAttribute("objectId",tenderId);
    		modelMap.addAttribute("cStatusDoc", -1);
    		//Change Request #19581
    		if(tblTender.getTblEventType().getEventTypeId() != 5){
            	modelMap.addAttribute("eventBannerContacts",eventCreationService.eventBannerContactList(clientId));
            	
            }
    		List<Object[]> configureThemeList = clientService.getConfiguredThemeData(clientId);
            if(configureThemeList!=null && !configureThemeList.isEmpty()){
                if(configureThemeList.get(0)[0]!=null){
                    modelMap.addAttribute("selectedthemeId", configureThemeList.get(0)[0]);    
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderviewlink, getviewtendernotice, tenderId, 0);
        }
        return "/etender/buyer/ViewTenderDetails";
    }

    /**
     * view Tender for Home page have tenderid as path variable this is for home
     * page so encription decription not required
     *
     * @param Integer tenderId
     * @param ModelMap modelMap
     * @param HttpServletRequest request
     * @return to String
     */
    @RequestMapping(value = "/viewtender/{tenderId}", method = RequestMethod.GET)
    public String viewTenderHomePage(@PathVariable(TENDERID) Integer tenderId, ModelMap modelMap, HttpServletRequest request) {
        try {
        	boolean isCrwalIp = false;
        	boolean crawlingPage = false;
        	int clientId = abcUtility.getSessionClientId(request);
        	
        	List<Object[]>  domainName = tenderCommonService.getDomainNamebyTenderId(tenderId);
        	int crossClientId = Integer.parseInt(domainName.get(0)[0].toString());
        	
        	if(crossClientId != clientId) {
        		return  "redirect:/";
        	}
        	String crawling = request.getParameter("crawlingPage");
        	if(crawling!=null) {
        		if(crawling.equals("123")) {
            		crawlingPage = true;
            		modelMap.addAttribute("crawlingPage", crawlingPage);
        		}
        	}
        	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
        	for(String validIp :  crawlIpAddress){
        		if(validIp.equals(ipAddress)){
        			isCrwalIp = true;
        			modelMap.addAttribute("isCrwalIp", isCrwalIp);
        		}
        	}
        	    List<Integer> sector = new ArrayList<Integer>();
				sector.add(1);
				sector.add(2);
				List<Object> drtClient = clientService.getClientFromSector(sector ,clientId); 
				if(drtClient.isEmpty() && !isCrwalIp){	// IF CLIENT IS NOT DRT THEN IT WILL CHECK BELOW CONDITION CURRENT TENDER IS OF SAME CLEINT 
	            	boolean allowTenderView  = commonService.isTenderView(tenderId ,clientId);
	            	if(!allowTenderView) { // IF TENDER IS OF NOT SAME CLIENT THEN FORWARD TO HOME PAGE
		            	return  "redirect:/";
	            	}
	            }
        	
            /*modelMap.addAttribute(USERTYPE, 0);*/
            modelMap.addAttribute(USERTYPE, abcUtility.getSessionUserTypeId(request));
            modelMap.addAttribute("isWorkFlow", 0);
            
            /*** Code to get document before login **/
            modelMap.addAttribute("linkId", regenerateTenderBrd);
    		modelMap.addAttribute("isReadOnly", "Y");
    		modelMap.addAttribute("objectId",tenderId);
            modelMap.addAttribute("isAuctionDocDownload","Y");
            /*** End Code to get document before login **/
            
            /*** Start Code to view document approve and cancel both side officer and bidder **/
            modelMap.addAttribute("cStatusDoc", -2);
            
            eventCreationService.tenderView(tenderId, modelMap, clientId);
            TblTender tblTender = (TblTender) modelMap.get(TBLTENDER);
            getCustomConfigData(modelMap, clientId, tblTender.getTblEventType().getEventTypeId(), VIEW);
            modelMap.addAttribute("eventName", commonService.getEventType(tblTender.getTblEventType().getEventTypeId()).get(0));
            //Change Request #19581
            if(tblTender.getTblEventType().getEventTypeId() != 5){
            	modelMap.addAttribute("eventBannerContacts",eventCreationService.eventBannerContactList(clientId));
            }
            List<Object[]> configureThemeList = clientService.getConfiguredThemeData(clientId);
            if(configureThemeList!=null && !configureThemeList.isEmpty()){
                if(configureThemeList.get(0)[0]!=null){
                    modelMap.addAttribute("selectedthemeId", configureThemeList.get(0)[0]);    
                }
            }
            int ShowAccessDetail=abcUtility.getAccessDetail(request);
			if(ShowAccessDetail==1){
            int visitorCount=commonService.getVisitorDetail(request);
    		modelMap.addAttribute("visitorCount",visitorCount);
			}
			modelMap.addAttribute("isCPPPRequire", clientService.checkCPPPRequireOrNot(clientId));
            modelMap.addAttribute("isCPPPConfigure",clientService.checkCPPPConfigureOrNot(clientId));
            if(abcUtility.isModuleAssignToClient(request,9)){
            	modelMap.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
            	if(modelMap.get("isCategoryAllow").equals(1)){
            		modelMap.addAttribute("categoryNameList", commonService.getCategoryNameList(tenderId,tendercreationlink));
            		modelMap.addAttribute("eventTypeId", tblTender.getTblEventType().getEventTypeId());
            	}
        	}else{
        		modelMap.put("isCategoryAllow",0);
        	}
            modelMap.addAttribute("isRegistrationLinkHidden", clientService.isRegistrationLinkHidden(clientId, hideRegistrationLinkId, 1));
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderviewlink, getviewtendernotice, tenderId, 0);
        }
        return "/etender/buyer/ViewTenderDetails";
    }

    /**
     * publish tender tenderPublishBean is modelAttribute , PathVariable
     * tenderId,pathVariable eventTypeId
     *
     * @param TenderPublishBean tenderPublishBean
     * @param Integer tenderId
     * @param Integer eventTypeId
     * @param ModelMap modelMap
     * @param RedirectAttributes redirectAttributes
     * @param HttpServletRequest request
     * @return to String
     */
    @RequestMapping(value = "/etender/buyer/publishtender/{eventTypeId}/{tenderId}/{enc}", method = RequestMethod.GET)
    public String publishTender(@ModelAttribute TenderPublishBean tenderPublishBean, @PathVariable(TENDERID) Integer tenderId, @PathVariable(EVENTTYPEID) Integer eventTypeId, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        SessionBean sessionBean = null;
        try {
            int clientId = abcUtility.getSessionClientId(request);
            sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            if (sessionBean != null && clientBean != null) {
                modelMap.addAttribute(USERTYPE, abcUtility.getSessionUserTypeId(request));
                int isGSTRequired = (Integer)tenderCommonService.getTenderField(tenderId, "isGSTRequired");
                modelMap.addAttribute("isGSTRequired", isGSTRequired);
                getCustomConfigData(modelMap, clientId, eventTypeId, VIEW);
                eventCreationService.tenderView(tenderId, modelMap, clientId);
                TblTender tblTender = (TblTender) modelMap.get(TBLTENDER);
                if (tblTender.getPreBidEndDate() != null) {
                    tenderPublishBean.setTxtPreBidEndDate(tblTender.getPreBidEndDate().toString());
                }
                if (tblTender.getPreBidStartDate() != null) {
                    tenderPublishBean.setTxtPreBidStartDate(tblTender.getPreBidStartDate().toString());
                }
                if (tblTender.getDocumentStartDate() != null) {
                    tenderPublishBean.setTxtDocumentStartDate(tblTender.getDocumentStartDate().toString());
                }
                if (tblTender.getDocumentEndDate() != null) {
                    tenderPublishBean.setTxtDocumentEndDate(tblTender.getDocumentEndDate().toString());
                }
                if (tblTender.getSubmissionStartDate() != null) {
                    tenderPublishBean.setTxtSubmissionStartDate(tblTender.getSubmissionStartDate().toString());
                }
                if (tblTender.getSubmissionEndDate() != null) {
                    tenderPublishBean.setTxtSubmissionEndDate(tblTender.getSubmissionEndDate().toString());
                }
                if (tblTender.getOpeningDate() != null) {
                    tenderPublishBean.setTxtBidOpenDate(tblTender.getOpeningDate().toString());
                }
                if (tblTender.getQuestionAnswerEndDate() != null) {
                    tenderPublishBean.setTxtQuestionAnswerEndDate(tblTender.getQuestionAnswerEndDate().toString());
                }
                if (tblTender.getQuestionAnswerStartDate() != null) {
                    tenderPublishBean.setTxtQuestionAnswerStartDate(tblTender.getQuestionAnswerStartDate().toString());
                }
                if(tblTender.getEmdSubmissionEndDate() != null){
                	tenderPublishBean.setTxtEmdSubmissionEndDate(tblTender.getEmdSubmissionEndDate().toString());
                }else if(tblTender.getSubmissionEndDate() != null){
                	tenderPublishBean.setTxtEmdSubmissionEndDate(tblTender.getSubmissionEndDate().toString());
                }
                int isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
                modelMap.put("isCertRequired", isCertRequired);
                String certIds[] = null;
                if (clientBean.getIsPkiEnabled() == pkiEnable || (clientBean.getIsPkiEnabled() == pkiEventSpecific && isCertRequired == 1)) {
                    certIds = sessionBean.getCertId().split(",");
                    if (certIds != null && certIds.length != 0) {
                        modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                    }
                }
                modelMap.addAttribute("brdMode", tblTender.getBrdMode());
                modelMap.addAttribute("moduleId", 3);
                modelMap.addAttribute("linkIdRegenerate", regenerateTenderBrd);
                if(tblTender.getBrdMode() == 1){
                	List<LinkedHashMap<String, Object>> lstTemplate=commonService.getBRDDetails(3,regenerateTenderBrd,tenderId,clientId,abcUtility.getCookieDateFormatConversionValue(request));
                	modelMap.addAttribute("lstTemplate", lstTemplate);
                }
                
                if(abcUtility.isModuleAssignToClient(request,9)){
                	modelMap.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
                	if(modelMap.get("isCategoryAllow").equals(1)){
                		modelMap.addAttribute("categoryNameList", commonService.getCategoryNameList(tenderId,tendercreationlink));
                		modelMap.addAttribute("eventTypeId", tblTender.getTblEventType().getEventTypeId());
                	}
            	}else{
            		modelMap.put("isCategoryAllow",0);
            	}
                
                /*** For documents **/
                modelMap.addAttribute("linkId", uploadTenderDocLinkId);
        		modelMap.addAttribute("isReadOnly", "Y");
        		modelMap.addAttribute("isAuctionDocDownload", "Y");
        		modelMap.addAttribute("objectId", tenderId);
        		modelMap.addAttribute("cStatusDoc", -1);
        		modelMap.addAttribute("isOnlinePayment",clientService.getClientById(clientId).getIsOnlinePayment());
        		modelMap.addAttribute("checkpricebid",eventCreationService.checkpricebidform(tenderId)!=0);
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderPublishLink, getpublishtender, tenderId, 0);

        }
        return "/etender/buyer/PublishTender";
    }

    /**
     * to get cancel tender page
     *
     * @param tenderId
     * @param eventTypeId
     * @param modelMap
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "/etender/buyer/canceltender/{tenderId}/{eventTypeId}/{enc}", method = RequestMethod.GET)
    public String cancelTender(@PathVariable(TENDERID) Integer tenderId, @PathVariable(EVENTTYPEID) Integer eventTypeId, ModelMap modelMap, HttpServletRequest request) {
        try {
            int clientId = abcUtility.getSessionClientId(request);
            modelMap.addAttribute(USERTYPE, abcUtility.getSessionUserTypeId(request));
            getCustomConfigData(modelMap, clientId, eventTypeId, VIEW);
            eventCreationService.tenderView(tenderId, modelMap, clientId);
            
            
            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(tenderCancelEventId, clientId);
            int allowedSize = 0;
    	    StringBuilder allowedExt = new StringBuilder();
    	    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
    			allowedSize = lstDocUploadConf.get(0).getMaxSize();
    			allowedExt.append(lstDocUploadConf.get(0).getType());
    			modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
    	    }
    	    int index = allowedExt.toString().indexOf(",");
    	    allowedExt.insert(index + 1, "*.");
    	    while (index >= 0) {
    			index = allowedExt.toString().indexOf(",", index + ",".length());
    			allowedExt.insert(index + 1, "*.");
    	    }

    	    modelMap.addAttribute("allowedExt", allowedExt);
    	    modelMap.addAttribute("allowedSize", allowedSize/1024);
    	    
    	    List<Integer> lstLink=new ArrayList<Integer>();
            lstLink.add(tenderCancelLink);
    	    modelMap.addAttribute("linkId", lstLink);
    	    modelMap.addAttribute("isTenderDocDownload", "Y");
    	    int isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
    	    modelMap.addAttribute("isCertRequired", isCertRequired);
    	    String certIds[] = null;
    	    if (abcUtility.getSessionIsPkiEnabled(request) == pkiEnable || (abcUtility.getSessionIsPkiEnabled(request) == pkiEventSpecific && isCertRequired == 1)) {
                certIds = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
                if (certIds != null && certIds.length != 0) {
                    modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                }
            }

        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderCancelLink, getCancelTender, tenderId, 0);
        }
        return "/etender/buyer/CancelTender";
    }

    @RequestMapping(value = "/etender/buyer/submitcanceltender", method = RequestMethod.POST)
    public String submitCancelTender(ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/sessionexpired";
        int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
        int eventTypeId = StringUtils.hasLength(request.getParameter("hdEventTypeId")) ? Integer.parseInt(request.getParameter("hdEventTypeId")) : 0;
        int isWorkFlowRequired = StringUtils.hasLength(request.getParameter("hdIsWorkFlowRequired")) ? Integer.parseInt(request.getParameter("hdIsWorkFlowRequired")) : -1;
        String remarks = StringUtils.hasText(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") : "";
        String tenderBrief = StringUtils.hasText(request.getParameter("hdTenderBrief")) ? request.getParameter("hdTenderBrief") : "";
        String departmentName= StringUtils.hasText(request.getParameter("hdDepartmentName")) ? request.getParameter("hdDepartmentName") : "";
        boolean result = false;
        TblCancelRequest tblCancelRequest = new TblCancelRequest();
        boolean isContractAccpeted = true;
        int isCertRequired=0;
        try {
            int userId = abcUtility.getSessionUserId(request);
            int clientId = abcUtility.getSessionClientId(request);
            isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
            if (userId != 0) {
                if ("".equals(remarks)) {
                    retVal = "redirect:/etender/buyer/canceltender/" + tenderId + "/" + eventTypeId + encryptDecryptUtils.generateRedirect("etender/buyer/canceltender/" + tenderId + "/" + eventTypeId, request);
                }else if(commonService.checkCMSDefaultConfg(clientId, 12) && commonService.getCountAcceptContract(tenderId,"APO",1)!=0){/*if apo configured at client and created then update*/
            		retVal = "redirect:/etender/buyer/canceltender/" + tenderId + "/" + eventTypeId + encryptDecryptUtils.generateRedirect("etender/buyer/canceltender/" + tenderId + "/" + eventTypeId, request);
            		isContractAccpeted = false;
                }else if(isContractAccpeted && commonService.checkCMSDefaultConfg(clientId, 13)&& commonService.getCountAcceptContract(tenderId,"PO",1)!=0){/*if po configured at client and created then update*/
                	retVal = "redirect:/etender/buyer/canceltender/" + tenderId + "/" + eventTypeId + encryptDecryptUtils.generateRedirect("etender/buyer/canceltender/" + tenderId + "/" + eventTypeId, request);
                	isContractAccpeted = false;
                }else {
                	remarks = remarks.replace("&#xa;"," ").replace("&#45;","-").replace("&#43;","-");
                    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                    fileUploadService.updateOfficerDocDetail(tenderId,tenderCancelLink, 1); //Update Document cstatus to 1 in tbl_OfficerDocument table
                    tblCancelRequest.setObjectId(tenderId);
                    tblCancelRequest.setRemark(remarks);
                    tblCancelRequest.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                    tblCancelRequest.setCstatus(0);
                    tblCancelRequest.setTblLink(new TblLink(tenderCancelLink));
                    result = eventCreationService.addCancelRequest(tblCancelRequest, isWorkFlowRequired);
                    if (result) {
                    	if(isWorkFlowRequired == 0){
                        Map<String, Object> dataMap = new HashMap<String, Object>();
                        dataMap.put("EventId", tenderId);
                        dataMap.put("ReferenceNo", modelMap.get("tenderNo"));
                        dataMap.put("EventType", commonService.getEventNameFromEventId(eventTypeId).get(0).toString());
                        dataMap.put("EventBrief", tenderBrief);
                        dataMap.put("DepartmentName", departmentName);
                        dataMap.put("CancellationRemarks", remarks);
                        
                        if(Integer.parseInt(idfcClientId) == clientId){
	                        StringBuilder ccEmailIds = new StringBuilder();
	                        int officerId =  (Integer) tenderCommonService.getTenderField(tenderId, "officerId");
	                        String deptOfficerLogin = "";
	                        List<TblUserLogin> list = commonService.getUserLoginById(officerId);
	                        if(list!=null && !list.isEmpty()){
	                        	deptOfficerLogin = list.get(0).getLoginId();
	                        }
	                        ccEmailIds.append(idfcEmailCC).append(",").append(deptOfficerLogin);
	                        dataMap.put("cc", ccEmailIds);
                        }
                        String encryptUrlStr = encryptDecryptUtils.encrypt("etender/buyer/viewtender/"+tenderId);
                        String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                        dataMap.put("link", hrefStr);
                        dataMap.put("SubDomainName",clientService.getClientNameByClientId(abcUtility.getSessionClientId(request)));
                        mailContentUtillity.dynamicMailGeneration("53", ""+userId, String.valueOf(tenderId), dataMap, "");
                        retVal = REDIRECTDASHBOARD + tenderId + "/1" + encryptDecryptUtils.generateRedirect(DASHBOARD + tenderId + "/1", request);
                        String notificationMsg = "Event ID: " + tenderId + " has been Cancelled";
                   	 	tenderCommonService.sendMobileNotification(3,  notificationMsg, tenderId,0,abcUtility.getSessionClientId(request));
                    	}else{
                    		retVal = REDIRECTDASHBOARD + tenderId + "/1" + encryptDecryptUtils.generateRedirect(DASHBOARD + tenderId + "/1", request);
                            String notificationMsg = "Event ID: " + tenderId + " has been Cancelled";
                       	 	tenderCommonService.sendMobileNotification(3,  notificationMsg, tenderId,0,abcUtility.getSessionClientId(request));
                    	}
                    	} else {
                        retVal = "redirect:/etender/buyer/canceltender/" + tenderId + "/" + eventTypeId + encryptDecryptUtils.generateRedirect("etender/buyer/canceltender/" + tenderId + "/" + eventTypeId, request);
                    }
                }
                redirectAttributes.addFlashAttribute(result ? CommonKeywords.SUCCESS_MSG.toString() :  CommonKeywords.ERROR_MSG.toString() , result ? "msg_success_tendercancel" : isContractAccpeted ? CommonKeywords.ERROR_MSG_KEY.toString() : "msg_error_contract_accepted");
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            if ((abcUtility.getSessionIsPkiEnabled(request) == 1) || (abcUtility.getSessionIsPkiEnabled(request) == pkiEventSpecific && isCertRequired == 1)) {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderCancelLink, postCancelTender, tenderId, tblCancelRequest.getCancelRequestId(), remarks, request.getParameter("skpSignText"));
            } else {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderCancelLink, postCancelTender, tenderId, tblCancelRequest.getCancelRequestId());
            }
        }
        return retVal;
    }

    /**
     * add publish tender
     *
     * @param enc
     * @param tenderId
     * @return to String
     */
    @RequestMapping(value = "/etender/buyer/addpublishtender", method = RequestMethod.POST)
    public String addPublishTender(@ModelAttribute TenderPublishBean tenderPublishBean, RedirectAttributes redirectAttributes, HttpServletRequest request,HttpServletResponse response) {
        SessionBean sessionBean = null;
        int isCertRequired = 0;
        String redirectMessage = null;
        int clientId = abcUtility.getSessionClientId(request);
        int userId = abcUtility.getSessionUserId(request);
        boolean success = true;
        boolean isServersideValidte=true;
        String retVal = null;
        int isDualCert = 0;
        int userDetailId = 0;
        int brdMode = 0;
        int tenderMode = 0;
        int tenderId = 0;
        /*PT #38423 : start*/
        List<TblTenderCPV> tblTenderCPVList = new ArrayList<TblTenderCPV>();
		TblTenderCPV tblTenderCPV = null;
		String cpvCodeChar[]; 
		TblTender tblTender = null;
		String cpvCode = null; 
		int deptId = 0;
		int buyerId = 0;
		List<Map<String,Object>> validateTenderLinks=null;
		String remarks = "";
		/*PT #38423 : End*/
        try {
        	String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
            tenderId = CommonUtility.checkValue(request.getParameter("hdTenderId"));
        	brdMode = (Integer) tenderCommonService.getTenderField(tenderId, "brdMode");
            tenderMode = CommonUtility.checkValue(request.getParameter("hdTenderMode"));
            userDetailId = abcUtility.getSessionUserDetailId(request);
            sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            isDualCert = clientBean.getIsDualCerti();
            isCertRequired = StringUtils.hasLength(request.getParameter("hdIsCertRequired")) ? Integer.parseInt(request.getParameter("hdIsCertRequired")) : 0;
            validateTenderLinks=(List<Map<String,Object>>)commonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, 26, abcUtility.getSessionUserId(request),tenderPublishLink).get(RESULTSET_1);
            remarks = request.getParameter("txtaRemarks");
            if (sessionBean != null) {
                if (StringUtils.hasLength(tenderPublishBean.getTxtaRemarks())) {
                	Map<String,Object>  paymentAllow =tenderCommonService.verifyTenderPaymentConfig(tenderId, clientId);
                	if(paymentAllow!=null && !paymentAllow.isEmpty() && !(Boolean)paymentAllow.get("result")){
                		isServersideValidte=false;
                		redirectMessage= paymentAllow.get("errMsg").toString();
                	}else if(tenderFormService.getNoOfEncryptedPriceBidForm(tenderId)!=0 && isCertRequired==1){
                		 int isBiddingFormPublishWithTender = 0;
             	                List<Object[]> clientConfigList=commonService.getClientConfigurations(clientId);
             	                if(!clientConfigList.isEmpty() && clientConfigList.size()>0){
             	                    isBiddingFormPublishWithTender = Integer.parseInt(clientConfigList.get(0)[3].toString());
             	                }
             	                if(isBiddingFormPublishWithTender==1){
             	                	isServersideValidte=false;
                            		redirectMessage= "msg_pricebid_encryption_required";
             	                }
                	}else if(!validateTenderLinks.get(0).get("remark").toString().equals("Success")){
                		isServersideValidte=false;
                		redirectMessage = validateTenderLinks.get(0).get("remark").toString();
                	}
                    success =(isServersideValidte)?eventCreationService.updateTenderForPublish(tenderId, tenderPublishBean, clientId, userId, isDualCert, userDetailId):false;
                    if (success) {
                    	try{
                      	   if ( clientService.checkCPPPConfigureOrNot(clientId) && clientService.checkCPPPRequireOrNot(clientId) && eventCreationService.addTendersToCppp(clientId, tenderId)) {
                      		   //drupal_RestClient.Main(); on new cron implementation 
                             }
                      	}catch(Exception ex){
                      		return exceptionHandlerService.writeLog(ex);
                         }
//                        mailContentUtillity.dynamicMailGeneration("45", "0", String.valueOf(tenderId), null, "");
                    	boolean isRCIClient = commonService.isRCIClient(rciClientIds, clientId);
                        if(tenderMode != 1) {
                            String tenderBrief = StringUtils.hasLength(request.getParameter("txtaTenderBrief")) ? request.getParameter("txtaTenderBrief") : "";
                            String tenderNo = StringUtils.hasLength(request.getParameter("txtTenderNo")) ? request.getParameter("txtTenderNo") : "";
                            int eventType = StringUtils.hasLength(request.getParameter("hdEventTypeId")) ? Integer.parseInt(request.getParameter("hdEventTypeId")) : 0;
                            MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
                            String startDate = "";
                            String endDate = "";
                            String departmentName ="";
                            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "submissionStartDate,submissionEndDate");
                            if(tenderFields!=null && !tenderFields.isEmpty()){
                            	startDate = CommonUtility.convertTimezone(tenderFields.get(0)[0].toString());           	
                            	endDate = CommonUtility.convertTimezone(tenderFields.get(0)[1].toString());
                            }
                            Map<String, Object> mailParams = new HashMap<String, Object>();
                            mailParams.put("EventType", commonService.getEventNameFromEventId(eventType).get(0).toString());
                            mailParams.put("EventBrief", tenderBrief);
                            mailParams.put("EventId", tenderId);
                            mailParams.put("ReferenceNo", tenderNo);
                            mailParams.put("startDate", startDate);
                            mailParams.put("endDate", endDate);
                            String domainName = clientService.getClientNameById(clientId);
                            mailParams.put("website", domainName);
                            mailParams.put("contactus", "<a href=\"/contactus"+"\">"+domainName+"</a>");
                            mailParams.put("SubDomainName",clientService.getClientNameByClientId(abcUtility.getSessionClientId(request)));
                            mailParams.put("DepartmentName", commonService.getDepartmentNameByTenderId(tenderId).toString());
                            messageConfigDatabean.setQueueName(queueName);
                            messageConfigDatabean.setTemplateId(Integer.parseInt(publishTenderTemplateId));
                            messageConfigDatabean.setUserId(abcUtility.getSessionUserId(request));
                            messageConfigDatabean.setClientId(abcUtility.getSessionClientId(request));
                            messageConfigDatabean.setObjectId(tenderId);
                            messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
                            messageConfigDatabean.setContextPath(request.getContextPath());
                            boolean isMarkCCRequired =(Integer.parseInt(commonService.getClientAlertConfig(tenderPublishLink, clientId).get(0)[3].toString())==1) ? true : false;
                            if(isMarkCCRequired){
                            	StringBuilder ccEmailIds = new StringBuilder();
	                            int officerId =  (Integer) tenderCommonService.getTenderField(tenderId, "officerId");
	                            String deptOfficerLogin = "";
	                            List<TblUserLogin> list = commonService.getUserLoginById(officerId);
	                            if(list!=null && !list.isEmpty()){
	                            	deptOfficerLogin = list.get(0).getLoginId();
	                            }
	                            
	                            if(Integer.parseInt(idfcClientId) == clientId){
	                            	mailParams.put("ReferenceNo", AbcUtility.reverseReplaceSpecialChars(tenderBrief));
	                            	ccEmailIds.append(idfcEmailCC).append(",").append(deptOfficerLogin);
	                            }		                        
	                            ccEmailIds.append(deptOfficerLogin);
	                            messageConfigDatabean.setCc(ccEmailIds.toString());
                            }
                            
                            // PT #34914 By Jitendra. Add BCC Email ID in publish event mail if tender mode is limited or proprietary or nomination.
                            messageConfigDatabean.setBcc(eventMailBCC);
                            
                            messageConfigDatabean.setParamMap(mailParams);
                            messageQueueService.sendMessage(messageConfigDatabean);
                        }
                        
                        
                        	 String notificationMsg = "Event ID: " + tenderId + " is published";
                        	 tenderCommonService.sendMobileNotification(3,  notificationMsg, tenderId,0,abcUtility.getSessionClientId(request));
                        
                        int brdModeHidden=StringUtils.hasLength(request.getParameter("hdBrdMode")) ? Integer.parseInt(request.getParameter("hdBrdMode")) : 0;
                        if(brdModeHidden == 1){
                        	commonService.pdfGeneration(response,request);
                        	fileUploadService.approvePendingOfficerDoc(tenderId,regenerateTenderBrd);
                        }
                        
                        /*Start - Send invition mail (BRD)*/
                        if(brdMode==1 && !isRCIClient){
                        	success = eventCreationService.inviteBiddersForParticipation(tenderId, abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request), 
                        			request.getRequestURL().toString (), request.getContextPath().toString(),false,clientBean.getTimeZoneAbbr() );
                        }
                        /*End - Send invition mail (BRD)*/
                        /*PT #38423 : start*/
                        tblTender = eventCreationService.getTenderMaster(tenderId);
                		cpvCode = tblTender.getKeywordText();
                		TblClient tblClient = clientService.getClientById(clientBean.getClientId());
                		if(tblTender != null && cpvCode != null && tblClient != null && tblClient.getCategoryType() == 1 && tblTender.getIsDemoTender() == 0){
	                		deptId = tblTender.getTblDepartment().getDeptId();		
	            			buyerId = tblTender.getOfficerId();
	            			if (cpvCode.contains(",")) {
	            				cpvCodeChar = cpvCode.split(",");
	            				for (int k = 0; k < cpvCodeChar.length; k++) {
	            					tblTenderCPV = new TblTenderCPV();
	            					tblTenderCPV.setTblTender(new TblTender(tenderId));
	            					tblTenderCPV.setCpvCode("");
	            					tblTenderCPV.setKeyword(cpvCodeChar[k].trim());
	            					tblTenderCPV.setTblUserLogin(new TblUserLogin(buyerId));
	            					tblTenderCPV.setIsDummyOfficer(0);
	            					tblTenderCPV.setDomainId(clientId);
	            					tblTenderCPV.setDeptId(deptId);				
	            					tblTenderCPVList.add(tblTenderCPV);
	            				}
	            			} else {
	            				tblTenderCPV = new TblTenderCPV();
	            				tblTenderCPV.setTblTender(new TblTender(tenderId));
	            				tblTenderCPV.setCpvCode("");
	            				tblTenderCPV.setKeyword(cpvCode.trim());
	            				tblTenderCPV.setTblUserLogin(new TblUserLogin(buyerId));
	            				tblTenderCPV.setIsDummyOfficer(0);
	            				tblTenderCPV.setDomainId(clientId);
	            				tblTenderCPV.setDeptId(deptId);				
	            				tblTenderCPVList.add(tblTenderCPV);
	            			}
	        				tenderCPVService.addClassificationKeywords(tblTenderCPVList);
                		}
                		/*PT #38423 : End*/
                    }
                }
                
            }
            
            if (success) {
            	int isEncodedName=0;
            	int isEncodedForTechnical=0;
            	int isEncodedForNegotiation=0;
            	List<Object[]> tenderFieldsForEncodeDecodeBidderName = tenderCommonService.getTenderFields(tenderId, "isEncodedName,isEncodedForTechnical,isEncodedForNegotiation");
            	if(tenderFieldsForEncodeDecodeBidderName != null && !tenderFieldsForEncodeDecodeBidderName.isEmpty()){
            		isEncodedName=Integer.parseInt(tenderFieldsForEncodeDecodeBidderName.get(0)[0].toString());
            		isEncodedForTechnical=Integer.parseInt(tenderFieldsForEncodeDecodeBidderName.get(0)[1].toString());
            		isEncodedForNegotiation=Integer.parseInt(tenderFieldsForEncodeDecodeBidderName.get(0)[2].toString());
            		if(isEncodedName == 1 || isEncodedForTechnical == 1 || isEncodedForNegotiation == 1){
            			TblEncodeDecodeHistory tblEncodeDecodeHistory = new TblEncodeDecodeHistory();
            			tblEncodeDecodeHistory.setTblTender(new TblTender(tenderId));
                        tblEncodeDecodeHistory.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                        tblEncodeDecodeHistory.setCstatus(1); // 1 for encode biddername                 
                        success = eventCreationService.addTblEncodeDecodeHistory(tblEncodeDecodeHistory);
            		}
            	}
            }
            //if whole event bidder mapped than bidder mapped in itemwise tender before adding bidding form (#64223) Rinju
            int bidderMapping = 0;
            int tenderResult = 0;
            int mapBidderId = 0;
            int companyId = 0;
            int createdBy = 0;
            int bidderUserDetailId = 0;
            if(success){
            	List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "bidderMapping,tenderResult");
            	if(tenderFields!=null && !tenderFields.isEmpty()){
                  bidderMapping = (Integer) tenderFields.get(0)[0];
                  tenderResult = (Integer) tenderFields.get(0)[1];
            	}
            	if(bidderMapping == 0 && tenderResult == 2 && tenderMode == 2){
            		List<Object[]> mappedBidderLst = eventBidderMapService.getTenderBidderMap(tenderId);
            		List<Object> tableIdList = tenderFormService.getPriceBidTableLstByTenderId(tenderId);
            		for (Object[] mappedBidderLsts : mappedBidderLst) {
            			mapBidderId = (Integer) mappedBidderLsts[0];
            			companyId = (Integer) mappedBidderLsts[1];
            			bidderUserDetailId = (Integer) mappedBidderLsts[2];
            			createdBy = (Integer) mappedBidderLsts[3];
            			for(Object tableIds : tableIdList){
            						List<Object[]> tenderTableList = tenderFormService.getTenderTableDetails((Integer)tableIds);
            						int noOfRows = (Integer) tenderTableList.get(0)[6];
            						int hasGTRows = (Integer) tenderTableList.get(0)[9];
            						List<Object[]> itemList = eventCreationService.getItemBidderMapByTableidAndMapibidderid((Integer)tableIds,mapBidderId);
            						for(int i=1; i<=(noOfRows-hasGTRows); i++){
            							if(!itemList.contains(i)){
            								TblItemBidderMap tblItemBidderMap = new TblItemBidderMap();
        	          	      	            tblItemBidderMap.setTblTenderBidderMap(new TblTenderBidderMap(mapBidderId));
        	          	      		        tblItemBidderMap.setTblTenderTable(new TblTenderTable((Integer)tableIds));
        	          	      	            tblItemBidderMap.setRowId(i);
        	          	      	            tblItemBidderMap.setIpAddress(ipAddress);
        	          	      	            tblItemBidderMap.setCreatedBy(userDetailId);
        	          	      	            itemBidderMapDao.addTblItemBidderMap(tblItemBidderMap);
        	          	      	                  
        	          	      	            TblTenderMapBidderHistory tblTenderMapBidderHistory = new TblTenderMapBidderHistory();
        	          	      	            tblTenderMapBidderHistory.setTblTender(new TblTender(tenderId));
        	          	      	            tblTenderMapBidderHistory.setTblUserDetail(new TblUserDetail(bidderUserDetailId));
        	          	      	            tblTenderMapBidderHistory.setCreatedBy(userDetailId);
        	          	      	            tblTenderMapBidderHistory.setIsMapped(1);
        	          	      	            tblTenderMapBidderHistory.setTblCompany(new TblCompany(companyId));
        	          	      	            tblTenderMapBidderHistory.setTableId((Integer)tableIds);
        	          	      	            tblTenderMapBidderHistory.setRowId(i);
        	          	      	            tblTenderMapBidderHistoryDao.addTblTenderMapBidderHistory(tblTenderMapBidderHistory);
            						}
                						
                				}
            			}
            		}
            	}
            	
            }
          //END
           
            if (success) {
                redirectMessage = "msg_tender_publish_success";
            }else if(isServersideValidte){
            	redirectMessage = CommonKeywords.ERROR_MSG_KEY.toString();
            }
            retVal = REDIRECTDASHBOARD + tenderId + "/1" + encryptDecryptUtils.generateRedirect(DASHBOARD + tenderId + "/1", request);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            int pki = abcUtility.getSessionIsPkiEnabled(request);
            if (pki == pkiEnable || (pki == pkiEventSpecific && isCertRequired == 1)) {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderPublishLink, postpublishtender, tenderId, 0,remarks, request.getParameter(SKPSIGNTEXT) != null ? request.getParameter(SKPSIGNTEXT) : "");
            } else {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderPublishLink, postpublishtender, tenderId, 0, "");
            }
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), redirectMessage);
        return retVal;
    }

    /**
     * @author purvesh view page for business rule for edit.
     *
     * @param enc
     * @param tenderId
     * @param modelMap
     * @param request
     * @return to String
     */
    @RequestMapping(value = "/etender/buyer/viewbusinessrule/{tenderId}/{enc}", method = RequestMethod.GET)
    public String viewBusinessRule(@PathVariable(TENDERID) Integer tenderId, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "/etender/buyer/ViewBusinessRule";
        try {
            int clientId = abcUtility.getSessionClientId(request);
            tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
            int eventTypeId =  (Integer) tenderCommonService.getTenderField(tenderId, "tblEventType.eventTypeId");
            int tenderMode =  (Integer) tenderCommonService.getTenderField(tenderId, "tenderMode");
            modelMap.addAttribute("tenderMode", tenderMode);
            generateComponentMap(modelMap, eventTypeId, clientId, tenderId, VIEW);

        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewBusinessRuleLinkId, getViewBusinessRuleAudit, tenderId, 0);
        }
        return retVal;
    }

    /**
     * @author purvesh show page for business rule for edit.
     *
     * @param enc
     * @param tenderId
     * @param modelMap
     * @param request
     * @return to String
     */
    @RequestMapping(value = "/etender/buyer/showeditbusinessrule/{tenderId}/{enc}", method = RequestMethod.GET)
    public String showEditBusinessRule(@PathVariable(TENDERID) Integer tenderId, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "/etender/buyer/BusinessRule";
        List<Object[]> tenderFields = null;
        try {
            int clientId = abcUtility.getSessionClientId(request);
            tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
            tenderFields = tenderCommonService.getTenderFields(tenderId, "envelopeType,tenderMode,isItemwiseWinner,biddingVariant,tenderResult,isPartialFillingAllowed,isCertRequired,isDocfeesApplicable,isEMDApplicable,isRegistrationCharges");
            int eventTypeId =  (Integer) tenderCommonService.getTenderField(tenderId, "tblEventType.eventTypeId");
            if(tenderFields!=null && !tenderFields.isEmpty()){
            	modelMap.put("tenderFields", tenderFields);
            }
            int tenderMode =  (Integer) tenderCommonService.getTenderField(tenderId, "tenderMode");
            modelMap.addAttribute("tenderMode", tenderMode);
           	generateComponentMap(modelMap, eventTypeId, clientId, tenderId, EDIT);
           	
        } catch (Exception e) {
            retVal = exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editBusinessRuleLinkId, getEditBusinessRuleAudit, tenderId, 0);
        }
        return retVal;
    }

    private void generateComponentMap(ModelMap modelMap, int eventTypeId, int clientId, int tenderId, String event) throws Exception {
        modelMap.addAttribute("getYesNo", commonService.getYesNo());
        List<Object[]> dataList=null;
        if(Integer.parseInt(modelMap.get("cstatus").toString())>0 && event.equals(EDIT)) {
        	Integer [] fieldId={31,116,165,215,265,1095,1096,1097,1098,1099,1100,1101,1102,1103,1104,1155,1156,1157,1158,1159,1160};
            dataList = eventCreationService.getBusinessRuleFields(clientId, eventTypeId,Arrays.asList(fieldId));
        }else {
        	dataList = eventCreationService.getBusinessRuleFields(clientId, eventTypeId);
        }
        List<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
        String columns = "";
        Map<String, Object> dataMap = null;
        for (Object[] dataTemp : dataList) {
            dataMap = new HashMap<String, Object>();
            dataMap.put("fieldLabel", dataTemp[6]);
            dataMap.put("fieldGroupId", dataTemp[2]);
            dataMap.put("fieldVal", dataTemp[4]);
            dataMap.put("defaultVal", dataTemp[8]);
            if (dataTemp[7] != null && !dataTemp[7].toString().equals("")) {
                if (!event.equals(VIEW)) {
                    dataMap.put("controlValue", generateList(dataTemp[7].toString()));
                } else {
                    dataMap.put("controlValue", generateDataMap(dataTemp[7].toString()));
                }
            } else if (dataTemp[7].toString().isEmpty() && "2".equals(dataTemp[1].toString())) {
                dataMap.put("controlValue", abcUtility.convert(commonService.getExecuteQuery(dataTemp[5].toString(), clientId)));
            }
            dataMap.put("controlType", dataTemp[1]);
            dataMap.put("isShown", dataTemp[0]);
            dataMap.put("field", dataTemp[3]);
            dataMap.put("hasDefaultValue", dataTemp[13]);
            dataMap.put("customParamId", dataTemp[9]);
            dataMap.put(EVENTTYPEID, dataTemp[10]);
            dataMap.put("fieldId", dataTemp[11]);
            dataMap.put("fieldName", dataTemp[12]);
            if (!"".equalsIgnoreCase(columns)) {
                columns += "," + dataTemp[12];
            } else {
                columns += dataTemp[12];
            }
            dataMap.put("description", dataTemp[14]);
            data.add((HashMap<String, Object>) dataMap);
        }
        modelMap.addAttribute("columns", columns);
        modelMap.addAttribute("biddingCount", eventCreationService.biddingCount(tenderId));
        
        List<Object[]> tenderData = tenderCommonService.getTenderFields(tenderId, columns);
        modelMap.addAttribute("tenderData", tenderData);
        modelMap.addAttribute("defConfigData", data);

    }

    
    /**
     * update business rule.
     *
     * @author purvesh
     * @param enc
     * @param modelMap
     * @param request
     * @return to String
     */
    @RequestMapping(value = "/etender/buyer/editbusinessrule", method = RequestMethod.POST)
    public String updateBusinessRule(ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        int tenderId = 0;
        int size = 0;
        String columns = null;
        String redirectUrl = "etender/buyer/showeditbusinessrule/";
        String retVal = "redirect:/sessionexpired";
        String paramPaired = null;
        Map<String, Object> var = new HashMap<String, Object>();
        try {
            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            if (sessionBean != null) {
                tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
                int multiLevelEvaluationReq = StringUtils.hasLength(request.getParameter("hdMultiLevelEvaluationReq")) ? Integer.parseInt(request.getParameter("hdMultiLevelEvaluationReq")) : 0;
                int isWeightageEvaluationRequired = StringUtils.hasLength(request.getParameter("hdisWeightageEvaluationRequired")) ? Integer.parseInt(request.getParameter("hdisWeightageEvaluationRequired")) : 0;
                int isPartialFillingAllowed = StringUtils.hasLength(request.getParameter("hdPartialFillingAllowed")) ? Integer.parseInt(request.getParameter("hdPartialFillingAllowed")) : 0;
                columns = StringUtils.hasLength(request.getParameter("hdColumns")) ? request.getParameter("hdColumns") : null;
                size = StringUtils.hasLength(request.getParameter("hdSize")) ? Integer.parseInt(request.getParameter("hdSize")) : 0;
                if (tenderId != 0 && columns != null && size != 0) {
                    retVal = REDIRECTDASHBOARD + tenderId + "/1" + encryptDecryptUtils.generateRedirect(DASHBOARD + tenderId + "/1", request); // For Success
                    String[] colsName = columns.split(",");
                    paramPaired = "";
                    for (int i = 0; i < size; i++) {
                        int controlType = StringUtils.hasLength(request.getParameter("hdControlType_" + i)) ? Integer.parseInt(request.getParameter("hdControlType_" + i)) : 0;
                        String value = controlType != 1 ? request.getParameter("selFieldVal_" + i) : request.getParameter("txtFieldVal_" + i);
                        if (!"".equalsIgnoreCase(paramPaired)) {
                            paramPaired += ",tblTender." + colsName[i] + "=:" + colsName[i];
                        } else {
                            paramPaired += "tblTender." + colsName[i] + "=:" + colsName[i];
                        }
                        var.put(colsName[i], value);
                    }
                    
                    success = eventCreationService.updateBusinessRule(var, paramPaired, tenderId);
                    
                    if(success){	  
                        Object isMandatoryDocument = tenderCommonService.getTenderField(tenderId,"isMandatoryDocument");
                        if(isMandatoryDocument!=null){
                        if(Integer.parseInt(isMandatoryDocument.toString()) == 0){
                           eventCreationService.deleteTenderDocument(tenderId);
                          }	
                        }
                    }
                    
                    if(success) {
                    	List<Object[]> eventDetails =tenderCommonService.getTenderFields(tenderId, "isEncodedName,isEncodedForNegotiation,isEncodedForTechnical,cstatus");
                    	if(Integer.parseInt(eventDetails.get(0)[3].toString())>0) {
                    		boolean flag=false;
	                    	if(Integer.parseInt(eventDetails.get(0)[0].toString())==1 || Integer.parseInt(eventDetails.get(0)[1].toString())==1 || Integer.parseInt(eventDetails.get(0)[2].toString())==1) 
	                    	{	
	                    		TblEncodeDecodeHistory tblEncodeDecodeHistory=new TblEncodeDecodeHistory();
	                        	tblEncodeDecodeHistory.setTblTender(new TblTender(tenderId));
	                        	tblEncodeDecodeHistory.setCreatedBy(abcUtility.getSessionUserDetailId(request));
	                    		tblEncodeDecodeHistory.setCstatus(1); //encoded
	                    		flag=eventCreationService.addTblEncodeDecodeHistory(tblEncodeDecodeHistory);
	                    	}else {
	                    		int cStatus=commonService.getLetestCstatusEncodeDecodeHistory(tenderId);
	                    		if(cStatus>0) {
	                    			TblEncodeDecodeHistory tblEncodeDecodeHistory=new TblEncodeDecodeHistory();
	                            	tblEncodeDecodeHistory.setTblTender(new TblTender(tenderId));
	                            	tblEncodeDecodeHistory.setCreatedBy(abcUtility.getSessionUserDetailId(request));
	                    			tblEncodeDecodeHistory.setCstatus(2); //decoded
	                    			flag=eventCreationService.addTblEncodeDecodeHistory(tblEncodeDecodeHistory);
	                    		}
	                    	}
	                    	if(flag) {
		                    	List<Object> listReportIds=null;
		                		//@V_ReportOn = 1 (GT L1/H1)
		        			    //@V_ReportOn = 3 (GT Nego. L1)
		        				//@V_ReportOn = 7 (Rebate L1 Report)
		        				//@V_ReportOn = 6 Manual Report
		        				//@V_ReportOn = 2 (Itemwise L1/H1
		            			//@V_ReportOn = 4 (Itemwise Nego. L1)
		        				Integer[] reportOns= {1,2,3,4,6,7};
		        				listReportIds=dynamicReportService.getDynReport(tenderId,Arrays.asList(reportOns));
		                		if(listReportIds!=null && !listReportIds.isEmpty()) {
		                			dynamicReportService.deleteTblDynReportCellIds(listReportIds);
		                		}
	                    	}
                    	}
                    }
                    
                    // Delete evaluation committee if multiLevelEvaluationReq value is changed. Bharat
                    /*if(var != null && var.containsKey("multiLevelEvaluationReq")){
	                    if(!var.get("multiLevelEvaluationReq").equals(multiLevelEvaluationReq+""))
	                    {
	                    	eventCreationService.deleteEvaluationCommittee(tenderId);
	                    }
                    }*/ //BUG #29795 By Keval soni
                    // Delete weightage evaluation configuration from the tender level
                    if(var != null && var.containsKey("isWeightageEvaluationRequired")){
	                    if(!var.get("isWeightageEvaluationRequired").equals(isWeightageEvaluationRequired+""))
	                    {
	                    	eventCreationService.deleteWeightageEvaluationConfiguration(tenderId);
	                    }
                    }
                    if(var != null && var.containsKey("isPartialFillingAllowed")){
	                    if(!var.get("isPartialFillingAllowed").equals(isPartialFillingAllowed+""))
	                    {
	                    	int tenderResult = StringUtils.hasLength(request.getParameter("hdTenderResult")) ? Integer.parseInt(request.getParameter("hdTenderResult")) : 0;
	                    	if(tenderResult==1)
	                    		eventCreationService.updatePartialFiilingTenderTableConfiguration(tenderId);
	                    }
                    }
                    
                }
                if (!success) {
                    retVal = "redirect:/" + redirectUrl + tenderId + encryptDecryptUtils.generateRedirect(redirectUrl + tenderId, request);
                }
                redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_edit_br" : CommonKeywords.ERROR_MSG_KEY.toString());
            }

        } catch (Exception e) {
            retVal = exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editBusinessRuleLinkId, postEditBusinessRuleAudit, tenderId, 0);
        }
        return retVal;
    }
    
    /**
     * @author nirav.modi
     * @param formId
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/etender/buyer/revivetender", method = RequestMethod.POST)                       
    public String reviveTender(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes){
    	String retVal="";
    	String retUrl="";
    	boolean success=false;
    	String newTenderIdStr="";
    	int tenderId=StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
    	int isDocRevive=StringUtils.hasLength(request.getParameter("txtIsDocRevive")) ? Integer.parseInt(request.getParameter("txtIsDocRevive")) : 0;
    	int reviveCount=StringUtils.hasLength(request.getParameter("txtReviveCount")) ? Integer.parseInt(request.getParameter("txtReviveCount")) : 1;
    	int isEnvFormRevive=StringUtils.hasLength(request.getParameter("txtIsEnvFormRevive")) ? Integer.parseInt(request.getParameter("txtIsEnvFormRevive")) : 0;
    	int isImpDateRevive=StringUtils.hasLength(request.getParameter("txtIsImpDateRevive")) ? Integer.parseInt(request.getParameter("txtIsImpDateRevive")) : 0;
    	int isEvaluateBidderRevive=StringUtils.hasLength(request.getParameter("txtEvalBidderRevive")) ? Integer.parseInt(request.getParameter("txtEvalBidderRevive")) : 0;
    	int isTECRevive=StringUtils.hasLength(request.getParameter("txtTECRevive")) ? Integer.parseInt(request.getParameter("txtTECRevive")) : 0;
    	int isTOCRevive=StringUtils.hasLength(request.getParameter("txtTOCRevive")) ? Integer.parseInt(request.getParameter("txtTOCRevive")) : 0;
    	try{
    		SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
    		ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    		if(sessionBean.getUserDetailId()!=0 && sessionBean.getUserId()!=0){
    			
    			if(clientBean.getClientModules().contains("10")){//for advertise module
    				newTenderIdStr=tenderFormService.reviveTender(tenderId, sessionBean.getUserDetailId(),sessionBean.getUserId(),isDocRevive,abcUtility.getSessionClientId(request),reviveCount,isEnvFormRevive,isImpDateRevive,isEvaluateBidderRevive,isTOCRevive,isTECRevive);
    			}else{
    				newTenderIdStr=tenderFormService.reviveTender(tenderId, sessionBean.getUserDetailId(),sessionBean.getUserId(),isDocRevive,abcUtility.getSessionClientId(request),reviveCount,isEnvFormRevive,isImpDateRevive,isEvaluateBidderRevive,isTOCRevive,isTECRevive);
    			}	
    			String tenderIds [] = newTenderIdStr.split(",");
    			for (String newTenderId : tenderIds) {
    				newTenderId=newTenderId.trim(); 
    				if(isDocRevive == 1){
    	    			List<TblDocUploadConf> lstDocConf=commonService.getDocUploadConf(57, abcUtility.getSessionClientId(request));// here 57 is eventId
    	                String path="";
    	                if(lstDocConf!=null && !lstDocConf.isEmpty())
    	                {
    	                    path=lstDocConf.get(0).getPath();
    	                }
    	                if(path!=null && StringUtils.hasLength(path))
                        {
                            path=docUploadPath+path;
                            File fp = new File(path+"\\"+tenderId);
                            List<File> file = abcUtility.CheckDirLengthForCopy(fp);
                            boolean bool = false;
                            if(file!=null && !file.isEmpty()){
	                            for (File filepath : file) {
	                            	if(filepath.exists()){
	                            		bool=commonService.copyDirectory(filepath,new File(path+"\\"+newTenderId));
	                            	}
	                            }
                            }
                            if(!bool){
                            	fileUploadService.updateOfficerDocDetails(Integer.parseInt(newTenderId),2);
                            }
                        }
        			}
    		/*changes for bidding form issue
    		TblTender tblTender=new TblTender(Integer.parseInt(newTenderId));
    		int IsItemwiseWinner=tblTender.getIsItemwiseWinner();
    		if (IsItemwiseWinner == 0) {
    			int tenderIdForBiddinForm=Integer.parseInt(newTenderId);
    			int formId=tenderFormService.getFormId(tenderIdForBiddinForm);
    			success=tenderFormService.deleteFormulaGTWise(formId);
    			success=tenderFormService.updateHasGTRow(formId);
    				}*/
    				success=Integer.parseInt(newTenderId.trim())!=0?true:false;
        			retVal=success? retUrl+"redirect:/etender/buyer/tenderdashboard/"+newTenderId.trim()+"/1" : retUrl+"redirect:/etender/buyer/tenderdashboard/"+tenderId+"/1";
        			retVal=retVal+encryptDecryptUtils.generateRedirect(retVal.substring(retVal.indexOf("/")+1,retVal.length()).toString(), request);
				}
    			
    		}else{
    			retVal ="redirect:/sessionexpired";
    		}
    	}
    	catch(Exception ex){
//    		retVal.setLength(0);
//    		retVal.append(exceptionHandlerService.writeLog(ex));
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), reviveTenderLinkId,getTenderReviveRemark, tenderId, 0);
    	}
    	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_revive" : CommonKeywords.ERROR_MSG_KEY.toString());
    	return retVal.toString();
    }
    /**
     * @author heeral.soni
     * @param modelMap
     * @param request
     * get encode decode tender list
     * @return
     */
    @RequestMapping(value = "/etender/buyer/encodedecodebidder/{status}/{tenderId}/{endDate}/{openDate}/{enc}", method = RequestMethod.GET)
    public String getEncodeDecodeBidder(ModelMap modelMap, @PathVariable("status") int status,@PathVariable("tenderId") int tenderId,@PathVariable("endDate") String endDate,@PathVariable("openDate") String openDate,HttpServletRequest request) {
        try {
            if(!"null".equalsIgnoreCase(endDate)){
                endDate = encryptDecryptUtils.decrypt(endDate);
                modelMap.addAttribute("endDate", endDate);
            }
            if(!"null".equalsIgnoreCase(openDate)){
                openDate = encryptDecryptUtils.decrypt(openDate);
                modelMap.addAttribute("openDate", openDate);
            }         
            modelMap.addAttribute("status", status);
            modelMap.addAttribute("lstEncodeDecodeTender",eventCreationService.getEncodeDecodeTender(abcUtility.getSessionClientId(request),tenderId,endDate,openDate,status));
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),encodeBidderNameLinkId, getencodedecodebiddername, 0, 0);
        }
        return "common/admin/EncodeDecodeTender";
    }
    
    /**
     * @author heeral.soni
     * @param modelMap
     * @param request
     * search encode decode tender list
     * @return
     */
    @RequestMapping(value = "/etender/buyer/searchencodedecodebidder", method = RequestMethod.POST)
    public String searchEncodeDecodeBidder(HttpServletRequest request,ModelMap modelMap) {
        String retVal = null;
        try {
                int tenderId = StringUtils.hasLength(request.getParameter("txtEventId")) ? Integer.parseInt(request.getParameter("txtEventId")) : 0;
                String endDate = StringUtils.hasLength(request.getParameter("txtBidEndDate")) ? CommonUtility.convertUtcTimezone(request.getParameter("txtBidEndDate")) : null;
                String openDate = StringUtils.hasLength(request.getParameter("txtBidOpenDate")) ? CommonUtility.convertUtcTimezone(request.getParameter("txtBidOpenDate")) : null;
                int status = StringUtils.hasLength(request.getParameter("txtStatus")) ? Integer.parseInt(request.getParameter("txtStatus")) : null;
                retVal = "etender/buyer/encodedecodebidder/" +status +"/" +tenderId + "/" +encryptDecryptUtils.encrypt(endDate) + "/" +encryptDecryptUtils.encrypt(openDate) ;
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),encodeBidderNameLinkId, getencodedecodebiddername, 0, 0);
        }
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    @RequestMapping(value = "/etender/buyer/clearencodedecodeevent", method = RequestMethod.POST)
    public String clearEncoDedecodeEvent(HttpServletRequest request,ModelMap modelMap) {
        String retVal = null;
        try {
                retVal = "etender/buyer/encodedecodebidder/0/0/null/null" ;
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),encodeBidderNameLinkId, getencodedecodebiddername, 0, 0);
        }
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    /**
     * @author heeral.soni
     * @param modelMap
     * @param request
     * insert/update encode decode tender list
     * @return
     */
    @RequestMapping(value = "/etender/buyer/updateencodedecodetender", method = RequestMethod.POST)
    public String updateEncodeDecodeTender(HttpServletRequest request,ModelMap modelMap,RedirectAttributes redirectAttributes) {
        String retVal = null;
        int status = StringUtils.hasLength(request.getParameter("txtDecodeStatus")) ? Integer.parseInt(request.getParameter("txtDecodeStatus")) : null;
        int decodeStatus = status == 1 ? 0 : 1;
        boolean isInserted = false;
        try {
            String[] decodeTenderList = request.getParameterValues("chkTenderId");
            String updateTenderIds = "";
            if(decodeTenderList!=null && decodeTenderList.length!=0){
                List<TblEncodeDecodeHistory> tblEncodeDecodeHistorys = new ArrayList<TblEncodeDecodeHistory>();
                for(int i=0;i<decodeTenderList.length;i++){
                        updateTenderIds += decodeTenderList[i].toString() + ",";
                        TblEncodeDecodeHistory tblEncodeDecodeHistory = new TblEncodeDecodeHistory();
                        tblEncodeDecodeHistory.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                        if(status == 1){
                            tblEncodeDecodeHistory.setCstatus(2); // 2 for decode biddername                 
                        }else{
                            tblEncodeDecodeHistory.setCstatus(1); // 1 for encode bidder name              
                        }
                        tblEncodeDecodeHistory.setTblTender(new TblTender(Integer.parseInt(decodeTenderList[i].toString())));
                        tblEncodeDecodeHistorys.add(tblEncodeDecodeHistory);
                }
                isInserted = eventCreationService.updateTenderEncodedName(updateTenderIds.substring(0, updateTenderIds.lastIndexOf(",")), tblEncodeDecodeHistorys,decodeStatus);
            }
            if(status == 1){
                redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? "msg_decodetender" : CommonKeywords.ERROR_MSG_KEY.toString());
            }else{
                redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? "msg_encodetender" : CommonKeywords.ERROR_MSG_KEY.toString());
            }
            retVal = "etender/buyer/encodedecodebidder/" +status +"/0/null/null" ;
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),encodeBidderNameLinkId, postencodedecodebiddername, 0, 0);
        }
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    /**
     * Method use for get request of Bidder wise abstract Report for Tender Opening Process.
     * @author sulabh
     * @param tenderId
     * @param envelopeId
     * @param formId
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */ 
    @RequestMapping(value = "/bidderwisereport/{tenderId}/{envelopeId}/{bidderConsId}/{enc}", method = RequestMethod.GET)
    public String showBidderWiseAbstractReport(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("bidderConsId") String bidderConsId,ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
         int bidderId = 0;
        int consortiumId =0;
        int operation = 2;
    try {
    	
                tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                modelMap.addAttribute("operation",operation);
                modelMap.addAttribute("bidderId",bidderId);
                modelMap.addAttribute("onHomePage",true);
                   bidderId = Integer.parseInt(encryptDecryptUtils.decrypt(bidderConsId));
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                 if(operation == 2 && (request.getParameter("hdisPrintPriview")==null || request.getParameter("hdisPrintPriview").equalsIgnoreCase("0")))
                {
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
                Map<String,Object> outMap= tenderOpenService.getBidderWiseReportDetail(tenderId,envelopeId,bidderId,consortiumId);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender cell - Filled by Officer
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }
                    if(outMap.get(RESULTSET_5) !=null) // Tender bidder 
                    {
                        modelMap.addAttribute("lstCompanyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }
                    if(outMap.get(RESULTSET_6) !=null) // Tender bid 
                    {
                        modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                    }
                     if(outMap.get(RESULTSET_7) !=null) // Tender Form bidded multiple time 
                    {
                        modelMap.addAttribute("lstFormBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                    }
                    
                    if(outMap.get(RESULTSET_8) !=null) // Tender Table bidded multiple time by add row
                    {
                        modelMap.addAttribute("lstTableBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                    }   
                    
                    if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                    }
                    if(outMap.get(RESULTSET_10) !=null) // Upload Document details
                    {
                        modelMap.addAttribute("lstDocumentDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                    }
                    if(outMap.get(RESULTSET_12) !=null) // Tender Proxy column Details
                    {
                        modelMap.addAttribute("lstTenderProxyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_12) );
                    }
                    if(outMap.get(RESULTSET_13) !=null) // Item wise bidder Mapping Details
                    {
                        modelMap.addAttribute("lstItemWiseBidderMapDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_13) );
                    }

                    
                }
                page = "/etender/common/TenderOpeningBiderWiseReport";
    } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
    } finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderOpeningBidderWiseAbstractReport, tenderId, bidderId);
    }
        return page;
    }


    /**
     * @author sulabh
     * @param modelMap
     * @param strTenderId
     * @param request
     * @return
     */
    		
    @RequestMapping(value = "/bidderwiseenvelope/{tenderId}", method = RequestMethod.GET)
    public String bidderWiseTenderEnvelope(ModelMap modelMap,@PathVariable("tenderId")String strTenderId,HttpServletRequest request) {
    	try{
    		//int tenderId=Integer.parseInt(encryptDecryptUtils.decrypt(strTenderId));
    		int tenderId=Integer.parseInt(strTenderId);
    		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		modelMap.addAttribute("tenderId", tenderId);
    		modelMap.addAttribute("envelopeList", commonService.getTenderEnvelope(tenderId));
    		modelMap.addAttribute("bidderList", commonService.getEnvelopeWiseBidder(tenderId));
    	}catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}finally{
    		//auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderOpeningBidderWiseAbstractReport, tenderId, bidderId);
    	}
    	return "/advertise/EnvelopeWiseBidderDetails";
    }
 
    /**
     * @author nirav.prajapati
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value="/generatedynamicreport/{tenderId}",method= RequestMethod.GET)
    public String generateDynamicReport(@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request) {
    	List<Object[]> advDtl = null;
    	List<Object[]> officerDtl = null;
    	List<Object[]> reportDtl = null;
    	int dynReportId = 0;
        try {
        	
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            advDtl=eventCreationService.getAdvertiseByTenderForL1Report(tenderId);
            officerDtl=eventCreationService.getOfficerByTenderId(tenderId);
            reportDtl = eventCreationService.getDynReportIdByTenderId(tenderId);
            if(advDtl != null && !advDtl.isEmpty()){
            	modelMap.put("advertiseNo", advDtl.get(0)[1]);
            	modelMap.put("advertiseDate", CommonUtility.convertTimezone(advDtl.get(0)[6]));
            	modelMap.put("isAdvDtlReq",true);
            }if(officerDtl !=null && !officerDtl.isEmpty())
            {
            	modelMap.put("officerName", officerDtl.get(0)[0]);
            	modelMap.put("officerDesignation", officerDtl.get(0)[1]);
            }
            if(reportDtl !=null && !reportDtl.isEmpty())
            {
            	dynReportId = (Integer)reportDtl.get(0)[0];
            }	
            Map<String,Object> dynamicReport = dynamicReportService.getDynamicL1H1Report(dynReportId,tenderId,abcUtility.getSessionUserId(request));
            if(dynamicReport != null && !dynamicReport.isEmpty()) {
                modelMap.addAttribute("reportColumnList", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-3"));
                modelMap.addAttribute("reportColumnHeaderList", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-2"));
                modelMap.addAttribute("reportFormHeader", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-1") );
                modelMap.addAttribute("reportHeader", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-4") );
                modelMap.addAttribute("onHomePage",true);
            }
            
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), dynamicL1H1ReportLinkId, reportFor == 1 ? viewDynamicL1Report : viewDynamicH1Report, tenderId, reportId);
        }
        return "/etender/common/DynamicL1H1Report";
    }
    /**
     * @author Lipi Shah
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value="etender/buyer/sendremaindermail/{tenderId}/{enc}",method= RequestMethod.GET)
    public String sendRemainderMail(@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	String retVal = "redirect:/sessionexpired";
    	boolean isSuccess = false;
    	try {
    		String tenderBrief = "";
            String tenderNo = "";
            int officerId = 0 ;
            int eventTypeId = 0;
            String startDate = "";
            String endDate = "";
            MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
            Map<String, Object> mailParams = new HashMap<String, Object>();
            int clientId = abcUtility.getSessionClientId(request);
            int tenderMode = 0;
            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "tenderBrief,tenderNo,officerId,tblEventType.eventTypeId,submissionStartDate,submissionEndDate,tenderMode");
            if(tenderFields!=null && !tenderFields.isEmpty()){
            	tenderBrief = tenderFields.get(0)[0].toString();
            	tenderNo  = tenderFields.get(0)[1].toString();
            	officerId = Integer.parseInt(tenderFields.get(0)[2].toString());
            	eventTypeId = Integer.parseInt(tenderFields.get(0)[3].toString());
            	startDate = CommonUtility.convertTimezone(tenderFields.get(0)[4].toString());           	
            	endDate = CommonUtility.convertTimezone(tenderFields.get(0)[5].toString());
            	tenderMode = Integer.parseInt(tenderFields.get(0)[6].toString());
            }
            mailParams.put("EventType", commonService.getEventNameFromEventId(eventTypeId).get(0).toString());            
            mailParams.put("EventId", tenderId);
            mailParams.put("EventBrief", AbcUtility.reverseReplaceSpecialChars(tenderBrief));
            mailParams.put("ReferenceNo", tenderNo);
            mailParams.put("startDate", startDate);
            mailParams.put("endDate", endDate);
            
            String clientName = clientService.getClientNameByClientId(clientId);
            String domainName =  clientService.getClientNameById(clientId);
            mailParams.put("ClientName",clientName);
            mailParams.put("contactus", "<a href=\"/contactus"+"\">"+domainName+"</a>");
            mailParams.put("website", domainName);
            
            messageConfigDatabean.setQueueName(queueName);
            messageConfigDatabean.setTemplateId(Integer.parseInt(sendRemainderMailTemplateId));
            messageConfigDatabean.setUserId(abcUtility.getSessionUserId(request));
            messageConfigDatabean.setClientId(clientId);
            messageConfigDatabean.setObjectId(tenderId);
            messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
            messageConfigDatabean.setContextPath(request.getContextPath());
            if(Integer.parseInt(idfcClientId) == clientId){
                StringBuilder ccEmailIds = new StringBuilder();
                String deptOfficerLogin = "";
                List<TblUserLogin> list = commonService.getUserLoginById(officerId);
                if(list!=null && !list.isEmpty()){
                	deptOfficerLogin = list.get(0).getLoginId();
                }
                ccEmailIds.append(idfcEmailCC).append(",").append(deptOfficerLogin);
                messageConfigDatabean.setCc(ccEmailIds.toString());
            }
            
            // PT #34914 By Jitendra. Add BCC Email ID in send reminder mail if tender mode is limited or proprietary or nomination.
            if(tenderMode == 2 || tenderMode == 3 || tenderMode == 4){
            	messageConfigDatabean.setBcc(eventMailBCC);
            }
            
            messageConfigDatabean.setParamMap(mailParams);
            isSuccess = messageQueueService.sendMessage(messageConfigDatabean);
            redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_reminder_mail_success" : CommonKeywords.ERROR_MSG_KEY.toString());
    	} catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), dynamicL1H1ReportLinkId, reportFor == 1 ? viewDynamicL1Report : viewDynamicH1Report, tenderId, reportId);
        }
    	retVal = REDIRECTDASHBOARD + tenderId + "/1" + encryptDecryptUtils.generateRedirect(DASHBOARD + tenderId + "/1", request);
        return retVal;
    }
    /**
     * @author Lipi Shah
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value="etender/buyer/remmailforeventcompletion/{tenderId}/{enc}",method= RequestMethod.GET)
    public String remMailForEventCompletion(@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	String retVal = "redirect:/sessionexpired";
    	boolean isSuccess = false;
    	try {
            String tenderNo = "";
            int officerId = 0 ;
            int eventTypeId = 0;
            String tenderBrief = "";
            MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
            Map<String, Object> mailParams = new HashMap<String, Object>();
            int clientId = abcUtility.getSessionClientId(request);
            
            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "tenderNo,officerId,tblEventType.eventTypeId,tenderBrief");
            if(tenderFields!=null && !tenderFields.isEmpty()){
            	tenderNo  = tenderFields.get(0)[0].toString();
            	officerId = Integer.parseInt(tenderFields.get(0)[1].toString());
            	eventTypeId = Integer.parseInt(tenderFields.get(0)[2].toString());
            	tenderBrief = tenderFields.get(0)[3].toString();
            }
            mailParams.put("EventType", commonService.getEventNameFromEventId(eventTypeId).get(0).toString());            
            mailParams.put("EventId", tenderId);
            mailParams.put("ReferenceNo", tenderNo);
            mailParams.put("EventBrief", tenderBrief);
            
            String clientName = clientService.getClientNameByClientId(clientId);
            mailParams.put("ClientName",clientName);
            
            String domainName =  clientService.getClientNameById(clientId);
            mailParams.put("website", domainName);
            mailParams.put("contactus", "<a href=\"/contactus"+"\">"+domainName+"</a>");
            messageConfigDatabean.setQueueName(queueName);
            messageConfigDatabean.setTemplateId(Integer.parseInt(remainderMailEventComplTemplateId));
            messageConfigDatabean.setUserId(abcUtility.getSessionUserId(request));
            messageConfigDatabean.setClientId(clientId);
            messageConfigDatabean.setObjectId(tenderId);
            messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
            messageConfigDatabean.setContextPath(request.getContextPath());
            if(Integer.parseInt(idfcClientId) == clientId){
            	mailParams.put("ReferenceNo", AbcUtility.reverseReplaceSpecialChars(tenderBrief));
                StringBuilder ccEmailIds = new StringBuilder();
                String deptOfficerLogin = "";
                List<TblUserLogin> list = commonService.getUserLoginById(officerId);
                if(list!=null && !list.isEmpty()){
                	deptOfficerLogin = list.get(0).getLoginId();
                }
                ccEmailIds.append(idfcEmailCC).append(",").append(deptOfficerLogin);
                messageConfigDatabean.setCc(ccEmailIds.toString());
            }
            messageConfigDatabean.setParamMap(mailParams);
            isSuccess = messageQueueService.sendMessage(messageConfigDatabean);
            redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_reminder_mail__event_compl_success" : CommonKeywords.ERROR_MSG_KEY.toString());
    	} catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), dynamicL1H1ReportLinkId, reportFor == 1 ? viewDynamicL1Report : viewDynamicH1Report, tenderId, reportId);
        }
    	retVal = REDIRECTDASHBOARD + tenderId + "/1" + encryptDecryptUtils.generateRedirect(DASHBOARD + tenderId + "/1", request);
        return retVal;
    }
    private void getAdvertiseDetails(ModelMap modelMap,int advertiseId) throws Exception{
    	modelMap.addAttribute("tblAdvertise",advertiseService.getAdvertiseDetailId(advertiseId));
    	modelMap.addAttribute("advertiseDetails",advertiseService.getAdvertiseDetails(advertiseId));
    	modelMap.addAttribute("lstAdvertiseTenderMap",advertiseService.getAdvertiseTenderMapDetails(advertiseId));
    }
    @RequestMapping(value = "/viewAdvertiseDetail/{advertiseId}", method = RequestMethod.GET)
    public String viewAdvertiseHomePage(@PathVariable("advertiseId") int advertiseId, ModelMap modelMap,HttpServletRequest request) {
        try {
        	getAdvertiseDetails(modelMap,advertiseId);
        	modelMap.addAttribute("objectIdNew", advertiseId);
			 modelMap.addAttribute("linkId", uploadDocLinkId);
			 int userTypeId=abcUtility.getSessionUserTypeId(request);
			    if(userTypeId == 2){
			    	modelMap.addAttribute("cStatusDoc", -2);
				    modelMap.addAttribute("cStatusDocView", -2);
			    }else{
				    modelMap.addAttribute("cStatusDoc", -1);
				    modelMap.addAttribute("cStatusDocView", -1);
			    }
			 modelMap.addAttribute("isReadOnly","Y");
			 modelMap.addAttribute("isTenderDocDownload", "Y");
        } catch (Exception e) {
            //exceptionHandlerService.writeLog(e);
        } finally {
        	//auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderviewlink, viewAdvertiseDetails, advertiseId, 0);
      }
        return "/advertise/ViewAdvertiseDetail";
    }
    
    /**
     * @author pooja.kakkad
     * @param tenderId
     * @param cstatus
     * @param request 
     * @return
     */
    
    @RequestMapping(value = "/etender/buyer/encodedecodebiddername/{tenderId}/{cstatus}/{linkId}/{enc}", method = RequestMethod.GET)
    public String encodeDecodeBidderName(ModelMap modelMap,@PathVariable("tenderId") int tenderId, @PathVariable("cstatus") int cstatus,@PathVariable("linkId") int linkId,HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	String retVal = "etender/buyer/tenderdashboard/"+tenderId+"/7";
        SessionBean sessionBean=request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
        boolean isSuccess = false;
        int isEncodedName=0;
        String flashMsg="";
        String auditMsg="";
    	try {
        	if(sessionBean != null){
        		List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "isEncodedName,tenderId");
        		if(tenderFields != null && !tenderFields.isEmpty()){
        			isEncodedName= Integer.parseInt(tenderFields.get(0)[0].toString());
        		}
        		TblEncodeDecodeHistory tblEncodeDecodeHistory = new TblEncodeDecodeHistory();
    			tblEncodeDecodeHistory.setTblTender(new TblTender(tenderId));
                tblEncodeDecodeHistory.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                if(cstatus != 0){
                	tblEncodeDecodeHistory.setCstatus(cstatus==1 ? 2 : 1); // 1 for encode bidder name  ,2 for decode bidder Name  
                }else{
                	tblEncodeDecodeHistory.setCstatus(isEncodedName==0 ? 1 : 2); // 1 for encode bidder name  ,2 for decode bidder Name  
                }
                           
                isSuccess = eventCreationService.addTblEncodeDecodeHistory(tblEncodeDecodeHistory);
                
                if(isSuccess) {
                		List<Object> listReportIds=null;
                		//@V_ReportOn = 1 (GT L1/H1)
        			    //@V_ReportOn = 3 (GT Nego. L1)
        				//@V_ReportOn = 7 (Rebate L1 Report)
        				//@V_ReportOn = 6 Manual Report
        				//@V_ReportOn = 2 (Itemwise L1/H1
            			//@V_ReportOn = 4 (Itemwise Nego. L1)
        				Integer[] reportOns= {1,2,3,4,6,7};
        				listReportIds=dynamicReportService.getDynReport(tenderId,Arrays.asList(reportOns));
                		if(listReportIds!=null && !listReportIds.isEmpty()) {
                			dynamicReportService.deleteTblDynReportCellIds(listReportIds);
                		}
                }
            }
        	
        	
        	if(linkId == 4513) { //encode bidder
        		flashMsg="msg_encode_decode_bidder_name_submit_success";
        		auditMsg=getencodebiddername;
        	}else {   //decode bidder
        		flashMsg="msg_decode_bidder_name_submit_success";
        		auditMsg=getdecodebiddername;
        	}
        	
        	if(isSuccess){
        		 redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? flashMsg : CommonKeywords.ERROR_MSG_KEY.toString());
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, auditMsg, 0, 0);
        }
    	return "redirect:/"+retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    /**
     * @author meghna
     * @param tenderId
     * @param request 
     * @return
     */
    @RequestMapping(value="etender/buyer/notifybidder/{tenderId}/{enc}",method= RequestMethod.GET)
    public String notifyBidder(@PathVariable("tenderId") int tenderId,HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	String retVal = "redirect:/sessionexpired";
    	boolean isSuccess = false;
    	try {
    		String tenderBrief = "";
            String tenderNo = "";
            int eventTypeId = 0;
            String startDate = "";
            String endDate = "";
            String keywordText = "";
            MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
            Map<String, Object> mailParams = new HashMap<String, Object>();
            int clientId = abcUtility.getSessionClientId(request);
            int tenderMode = 0;
            List<Object[]> bidderDetails =null;
            List<Object[]> categoryDetails =null;
            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "tenderBrief,tenderNo,tblEventType.eventTypeId,submissionStartDate,submissionEndDate,tenderMode,keywordText");
            int isCategoryAllow = commonService.isCategoryAllow(abcUtility.getSessionClientId(request));
            if(tenderFields!=null && !tenderFields.isEmpty()){
            	tenderBrief = tenderFields.get(0)[0].toString();
            	tenderNo  = tenderFields.get(0)[1].toString();
            	eventTypeId = Integer.parseInt(tenderFields.get(0)[2].toString());
            	startDate = CommonUtility.convertTimezone(tenderFields.get(0)[3].toString());           	
            	endDate = CommonUtility.convertTimezone(tenderFields.get(0)[4].toString());
            	tenderMode = Integer.parseInt(tenderFields.get(0)[5].toString());
            	if(tenderFields.get(0)[6]!=null){
            		keywordText = tenderFields.get(0)[6].toString();
            	}
            }
            if(keywordText==""){
            	keywordText = commonService.getCategoryNameList(tenderId,tendercreationlink);
            }
            if(isCategoryAllow==1)
            {
            	bidderDetails = eventCreationService.getBidderDetailByKeyword(keywordText,clientId,registrationLinkId); 
            	if(bidderDetails != null && !bidderDetails.isEmpty()){
            		List<Integer> userIdList=new ArrayList<Integer>();
            		for(Object[] Objects : bidderDetails) {
            			userIdList.add(Integer.parseInt(Objects[1].toString()));
            		}
            		categoryDetails = eventCreationService.getCategoryNameListByUserId(userIdList,registrationLinkId);
            	}
            }else{
            	bidderDetails =  eventCreationService.getCompanyDetailsByKeyword(keywordText,clientId);
            }
            if(bidderDetails != null && !bidderDetails.isEmpty()){
            	mailParams.put("EventType", commonService.getEventNameFromEventId(eventTypeId).get(0).toString());            
            	mailParams.put("EventBrief", AbcUtility.reverseReplaceSpecialChars(tenderBrief));
            	mailParams.put("ReferenceNo", tenderNo);
            	mailParams.put("startDate", startDate);
            	mailParams.put("endDate", endDate);
            	mailParams.put("tenderId", tenderId);
            	String DomainName="<a href=\"#\" onClick=\"viewMailLinkDetails(' " + clientService.getClientNameById (clientId) + " ');\">"+clientService.getClientNameById (clientId)+"</a>";
            	mailParams.put("domainName", DomainName);
            	messageConfigDatabean.setQueueName(queueName);
            	messageConfigDatabean.setTemplateId(Integer.parseInt(notifyBidderMailTemplateId));
            	messageConfigDatabean.setUserId(abcUtility.getSessionUserId(request));
            	messageConfigDatabean.setClientId(clientId);
            	messageConfigDatabean.setObjectId(tenderId);
            	messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
            	messageConfigDatabean.setContextPath(request.getContextPath());

            	messageConfigDatabean.setParamMap(mailParams);
            	if(isCategoryAllow==1)
                {
            		if(categoryDetails != null && !categoryDetails.isEmpty()){
            			for(Object[] bidderObject : bidderDetails) {
            				for(Object[] categoryObject:categoryDetails){
            					if(bidderObject[1].equals(categoryObject[0])){
            						mailParams.put("to", bidderObject[0]);
            						mailParams.put("category", categoryObject[1]);
            						isSuccess = messageQueueService.sendMessage(messageConfigDatabean);
            					}
            				}
            			}
            		}
                }else{
                	for(Object[] Objects : bidderDetails) {
                		mailParams.put("to", Objects[0]);
                		mailParams.put("category", Objects[1]);
                		isSuccess = messageQueueService.sendMessage(messageConfigDatabean);
                	}
                }
            	redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_notifybidder_mail_success" : CommonKeywords.ERROR_MSG_KEY.toString());
            }
    	} catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
        }
    	retVal = REDIRECTDASHBOARD + tenderId + "/1" + encryptDecryptUtils.generateRedirect(DASHBOARD + tenderId + "/1", request);
        return retVal;
    }
    
    @RequestMapping(value = {"/etender/buyer/eventCompleted/{tenderId}/{enc}", "/etender/bidder/eventCompleted/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String eventCompleted(@PathVariable(TENDERID) Integer tenderId, ModelMap modelMap, HttpServletRequest request) {
    	String tenderBrief = "";
       /* int tenderId = 0;*/
        String eventType = "";
        String startDate = "";
        String endDate = "";
        String currentDate = "";
        String tenderNo = "";
    	modelMap.addAttribute("isWorkFlow", 0);
    	try {
    		
    		List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "tenderBrief,tenderId,tblEventType.lang1,submissionEndDate,tenderNo,GETUTCDATE()");
    		if(tenderFields!=null && !tenderFields.isEmpty()){
            	tenderBrief = tenderFields.get(0)[0].toString();
            	tenderId  = Integer.parseInt(tenderFields.get(0)[1].toString());
            	eventType = tenderFields.get(0)[2].toString();
            	if(tenderFields.get(0)[3]!=null){
            		endDate = CommonUtility.convertTimezone(tenderFields.get(0)[3].toString());
            	}
            	tenderNo = tenderFields.get(0)[4].toString();
            	if(tenderFields.get(0)[5]!=null){
            		currentDate = CommonUtility.convertTimezone(tenderFields.get(0)[5].toString());
            	}
            }
    		
    		String userLoginId = "";
    		Object[] obj=clientService.getClientFields(abcUtility.getSessionClientId(request),"domainName,deptId,clientName");
    		
    		
    		int eventId = 0;
    		List<Object[]> eventCompletionFieldList = commonService.getEventCompletionFields(tenderId, 3, "eventCompletionId,cstatus");
    		if(eventCompletionFieldList!=null && !eventCompletionFieldList.isEmpty()){
    			eventId = Integer.parseInt(eventCompletionFieldList.get(0)[0].toString()) ;
   		 	}
    		
    		int userId = 0;
    		if(eventId == 0)
    		{
    			userId =  abcUtility.getSessionUserId(request);
    		}
    		else
    		{
    			userId = Integer.parseInt(commonService.getEventCompletionFields(tenderId, 3, "tblEventCompletion.tblUserLoginByPublishedBy.userId,cstatus").get(0)[0].toString());
    		}
    		
    		String userName = commonService.getUserName(userId);
    		 List<TblUserLogin> list = commonService.getUserLoginById(userId);
    		 if(list!=null && !list.isEmpty()){
    		 	 userLoginId = list.get(0).getLoginId();
    		 }
    		 
    		 int deptId = 0;
    		 String deptName ="";
    		 String desigName="";
    		 boolean flag = commonService.checkifSuperAdminOrNot(abcUtility.getSessionClientId(request), userId);
    		 if(flag)
    		 {
    			 List<Object> deptLst = commonService.getDepartmentIdByOfficerId(userId);
                 deptId = !(deptLst.isEmpty())?Integer.parseInt(deptLst.get(0).toString()):0;
                 
                 List<Object> deptLstName = commonService.getDepartmentNameByOfficerId(userId);
                 deptName = !(deptLstName.isEmpty())?String.valueOf(deptLstName.get(0).toString()):"";
                 
                 List<Object> desigLstName = commonService.getDesignationNameByOfficerId(userId);
                 desigName = !(desigLstName.isEmpty())?String.valueOf(desigLstName.get(0).toString()):"";
    		 }
    		 else
    		 {
    			 desigName = commonService.getDesignationNameByuserId(userId, abcUtility.getSessionClientId(request));
    			 deptName = commonService.getDepartmentNameByuserId(userId, abcUtility.getSessionClientId(request));
    			 List<Object> deptLst = commonService.getDepartmentNameByUserId(userId,abcUtility.getSessionClientId(request));
                 deptId = !(deptLst.isEmpty())?Integer.parseInt(deptLst.get(0).toString()):0;
    		 }
    		 //Created on date from completed Event
    		 String createdOn = (CommonUtility.convertTimezone(commonService.getCreatedDateofEventCompletion(tenderId, 3)))!=null ? CommonUtility.convertTimezone(commonService.getCreatedDateofEventCompletion(tenderId, 3)):"";
    		 String toContent = commonService.getToContentofEventCompletion(tenderId, 3);
             
            long count = commonService.eventCompletionCount(tenderId,3);
            if(count==0)
            {
            	modelMap.addAttribute("showButton", 1);
            	modelMap.addAttribute("endDate", " ");
            	modelMap.addAttribute("toContent", "");
            }
            else
            {
            	modelMap.addAttribute("showButton", 0);
            	modelMap.addAttribute("endDate", createdOn);
            	modelMap.addAttribute("toContent", toContent);
            }
			modelMap.addAttribute("domainName", obj[0]);
    		modelMap.addAttribute("tenderBrief", tenderBrief);
    		modelMap.addAttribute("tenderId", tenderId);
    		modelMap.addAttribute("eventType", eventType);
    		//modelMap.addAttribute("endDate", endDate);
    		
    		modelMap.addAttribute("deptName", deptName);
    		modelMap.addAttribute("desigName", desigName);
    		
    		modelMap.addAttribute("userName", userName);
    		modelMap.addAttribute("userLoginId", userLoginId);
    		modelMap.addAttribute("deptId", deptId);
    		modelMap.addAttribute("moduleId", 3);
    		modelMap.addAttribute("clientName", obj[2]);
    		modelMap.addAttribute("tenderNo", tenderNo);
    		
    		
    		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),eventCompletedLinkId, getEventCompletedPageFromNoticeTab, tenderId,0);
		}
        return "/etender/buyer/EventCompleted";
    }
    
    @RequestMapping(value = "/etender/buyer/addeventcompleteddetails", method = RequestMethod.POST)
    public String addEventCompletedDetails(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	String retUrl="";
    	String retVal = "";
    	String tenderid = StringUtils.hasLength(request.getParameter("hdtenderid")) ? request.getParameter("hdtenderid") : "";
    	
    	String eventCompletionDetails = StringUtils.hasLength(request.getParameter("hdcompid")) ? request.getParameter("hdcompid") : "";
    	String toContent = StringUtils.hasLength(request.getParameter("txttoContent")) ? request.getParameter("txttoContent") : "";
    	String eventCompletionDetails1 = StringUtils.hasLength(request.getParameter("hdcompid1")) ? request.getParameter("hdcompid1") : "";
    	String eventCompletionDetails2 = StringUtils.hasLength(request.getParameter("hdcompid2")) ? request.getParameter("hdcompid2") : "";
    	String eventCompletionDetails3 = StringUtils.hasLength(request.getParameter("hdcompid3")) ? request.getParameter("hdcompid3") : "";
    	
    	TblEventCompletion eventCompletion = new TblEventCompletion();
    	
    	eventCompletion.setObjectId(Integer.parseInt(tenderid));
    	eventCompletion.setTblModuleByModuleId(new TblModule(3));
    	eventCompletion.setCstatus(1);
    	//String deptStr = request.getParameter("hddeptId").toString();
    	if(Integer.parseInt(request.getParameter("hddeptId"))!=0)
    	{
    		eventCompletion.setTblDepartment(new TblDepartment(Integer.parseInt(request.getParameter("hddeptId"))));
    	}
    	else
    	{
    		eventCompletion.setTblDepartment(null);
    	}
    	
    	eventCompletion.setCreatedDate(new Date());
    	eventCompletion.setTblUserLoginByCreatedBy(new TblUserLogin(abcUtility.getSessionUserId(request)));
    	eventCompletion.setTblUserLoginByPublishedBy(new TblUserLogin(abcUtility.getSessionUserId(request)));
    	eventCompletion.setPublishedDate(new Date());
    	
    	eventCompletion.setMessageContent(eventCompletionDetails+toContent+eventCompletionDetails1+eventCompletionDetails2+eventCompletionDetails3);
    	eventCompletion.setToContent(toContent);
    	
    	try {
    		
    		
    		int eventId = 0;
    		List<Object[]> eventCompletionFieldList = commonService.getEventCompletionFields(Integer.parseInt(tenderid), 3, "eventCompletionId,cstatus");
    		if(eventCompletionFieldList!=null && !eventCompletionFieldList.isEmpty()){
    			eventId = Integer.parseInt(eventCompletionFieldList.get(0)[0].toString()) ;
   		 	}
    		boolean isInserted = false;
    		if(eventId == 0)
    		{
    			isInserted = commonService.addEventCompletionTable(eventCompletion);
    		}
    		else
    		{
    			eventCompletion.setEventCompletionId(eventId);
    			isInserted = commonService.updateEventCompletionTable(eventCompletion);
    		}
			
			redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? "msg_complete_cancel" : CommonKeywords.ERROR_MSG_KEY.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),eventCompletedLinkId, postEventCompletedPageFromNoticeTab, Integer.parseInt(tenderid),0);
		}
    	retVal= retUrl+"redirect:/etender/buyer/tenderdashboard/"+Integer.parseInt(tenderid)+"/1";
		retVal=retVal+encryptDecryptUtils.generateRedirect(retVal.substring(retVal.indexOf("/")+1,retVal.length()).toString(), request);
    	return retVal.toString();
    }
    /**For hide goback link
     * @author suresh.k
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/etender/buyer/viewtenderdetail/{tenderId}/{enc}", method = RequestMethod.GET)
    public String viewTenderForReport(@PathVariable(TENDERID) Integer tenderId, ModelMap modelMap, HttpServletRequest request) {
        modelMap.addAttribute("isReport",0);
    	return viewTenderDetails(tenderId, 0, modelMap, request);
        
    }
}
  