/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author dipal
 */
@Component
public class SPTenderOpeningReport extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderresult.P_TenderOpeningReport";

    public SPTenderOpeningReport() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_EnvelopeId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_BidderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_ConsortiumId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_FormId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_ReportTypeId", Types.INTEGER));
    }

    /**
     * Method use for call store procedure for get Individual, Comparative, Bidder wise abstract report details.
     * @param tenderId
     * @param envelopeId
     * @param bidderId
     * @param formId
     * @param reportTypeId
     * @return {@code Map<String,Object>}
     * @throws Exception 
     */
    public Map<String,Object> executeProcedure(int tenderId, int envelopeId, int bidderId, int consortiumId,int formId, int reportTypeId) throws Exception
    {
        Map inParams = new HashMap();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_EnvelopeId", envelopeId);
        inParams.put("@V_BidderId", bidderId);
        inParams.put("@V_ConsortiumId", consortiumId);
        inParams.put("@V_FormId", formId);
        inParams.put("@V_ReportTypeId", reportTypeId);
        this.compile();

        return execute(inParams);
    }
}
