package com.etl.eproc.etender.databean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.etl.eproc.common.controller.DepartmentController;
import com.etl.eproc.common.model.TblCurrency;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblEventType;
import com.etl.eproc.common.model.TblProcurementNature;
import com.etl.eproc.common.model.TblSmboqdtls;
import com.etl.eproc.etender.daointerface.TblRebateDao;
import com.etl.eproc.etender.model.TblEnvelope;
import com.etl.eproc.etender.model.TblRebate;
import com.etl.eproc.etender.model.TblRebateForm;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderColumn;
import com.etl.eproc.etender.model.TblTenderCurrency;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderFormula;
import com.etl.eproc.etender.model.TblTenderRebate;
import com.etl.eproc.etender.model.TblTenderTable;

public class SpaceMatrixDtBean {
	private TblTender tblTender = new TblTender();
	private TblDepartment tblDepartment = new TblDepartment();
	private TblProcurementNature tblProcurementNature = new TblProcurementNature();
	private TblEventType tblEventType = new TblEventType();
	private TblCurrency tblCurrency = new TblCurrency();
	private TblTenderCurrency tblTenderCurrency;
	private List<TblTenderEnvelope> lstTenderEnvelope = new ArrayList<TblTenderEnvelope>();
	private TblTenderForm tblTenderForm = new TblTenderForm();
	private TblTenderTable tblTenderTable = new TblTenderTable();
	private Map<Integer, String> getColumnValues = new HashMap<Integer, String>();
	private List<TblTenderColumn> tenderColumns = new ArrayList<TblTenderColumn>();
	private List<TblTenderCell> tenderCells = new ArrayList<TblTenderCell>();
	private List<TblTenderFormula> tblTenderFormula = new ArrayList<TblTenderFormula>();
	private TblRebate tblRebate = new TblRebate();
	private TblRebateForm tblRebateForm = new TblRebateForm();
	private Map<Integer,ArrayList<String>> mapForColumnValues= new HashMap<Integer, ArrayList<String>>();
    private TblSmboqdtls tblSmboqdtls = new TblSmboqdtls();
	
	public TblDepartment getTblDepartment() {
		return tblDepartment;
	}

	public void setTblDepartment(TblDepartment tblDepartment) {
		this.tblDepartment = tblDepartment;
	}

	public TblProcurementNature getTblProcurementNature() {
		return tblProcurementNature;
	}

	public void setTblProcurementNature(TblProcurementNature tblProcurementNature) {
		this.tblProcurementNature = tblProcurementNature;
	}

	public TblEventType getTblEventType() {
		return tblEventType;
	}

	public void setTblEventType(TblEventType tblEventType) {
		this.tblEventType = tblEventType;
	}

	public TblCurrency getTblCurrency() {
		return tblCurrency;
	}

	public void setTblCurrency(TblCurrency tblCurrency) {
		this.tblCurrency = tblCurrency;
	}

	public TblTenderCurrency getTblTenderCurrency() {
		return tblTenderCurrency;
	}

	public void setTblTenderCurrency(TblTenderCurrency tblTenderCurrency) {
		this.tblTenderCurrency = tblTenderCurrency;
	}

	public List<TblTenderEnvelope> getLstTenderEnvelope() {
		return lstTenderEnvelope;
	}

	public void setLstTenderEnvelope(List<TblTenderEnvelope> lstTenderEnvelope) {
		this.lstTenderEnvelope = lstTenderEnvelope;
	}

	public TblTender getTblTender() {
		return tblTender;
	}

	public void setTblTender(TblTender tblTender) {
		this.tblTender = tblTender;
	}

	public TblTenderForm getTblTenderForm() {
		return tblTenderForm;
	}

	public void setTblTenderForm(TblTenderForm tblTenderForm) {
		this.tblTenderForm = tblTenderForm;
	}

	public TblTenderTable getTblTenderTable() {
		return tblTenderTable;
	}

	public void setTblTenderTable(TblTenderTable tblTenderTable) {
		this.tblTenderTable = tblTenderTable;
	}

	public Map<Integer, String> getGetColumnValues() {
		return getColumnValues;
	}

	public void setGetColumnValues(Map<Integer, String> getColumnValues) {
		this.getColumnValues = getColumnValues;
	}

	public List<TblTenderColumn> getTenderColumns() {
		return tenderColumns;
	}

	public void setTenderColumns(List<TblTenderColumn> tenderColumns) {
		this.tenderColumns = tenderColumns;
	}

	public List<TblTenderCell> getTenderCells() {
		return tenderCells;
	}

	public void setTenderCells(List<TblTenderCell> tenderCells) {
		this.tenderCells = tenderCells;
	}

	public List<TblTenderFormula> getTblTenderFormula() {
		return tblTenderFormula;
	}

	public void setTblTenderFormula(List<TblTenderFormula> tblTenderFormula) {
		this.tblTenderFormula = tblTenderFormula;
	}

	public TblRebate getTblRebate() {
		return tblRebate;
	}

	public void setTblRebate(TblRebate tblRebate) {
		this.tblRebate = tblRebate;
	}

	public TblRebateForm getTblRebateForm() {
		return tblRebateForm;
	}

	public void setTblRebateForm(TblRebateForm tblRebateForm) {
		this.tblRebateForm = tblRebateForm;
	}
    public Map<Integer, ArrayList<String>> getMapForColumnValues() {
		return mapForColumnValues;
	}
    public void setMapForColumnValues(Map<Integer, ArrayList<String>> mapForColumnValues) {
		this.mapForColumnValues = mapForColumnValues;
	}
	public TblSmboqdtls getTblSmboqdtls() {
		return tblSmboqdtls;
	}
	public void setTblSmboqdtls(TblSmboqdtls tblSmboqdtls) {
		this.tblSmboqdtls = tblSmboqdtls;
	}
}
