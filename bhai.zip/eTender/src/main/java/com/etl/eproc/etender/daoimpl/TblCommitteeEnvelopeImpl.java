package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblCommitteeEnvelopeDao;
import com.etl.eproc.etender.model.TblCommitteeEnvelope;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author bhavin.patel
 */
@Repository @Transactional
public class TblCommitteeEnvelopeImpl extends AbcAbstractClass<TblCommitteeEnvelope> implements TblCommitteeEnvelopeDao {

    

    @Override
    public void addTblCommitteeEnvelope(TblCommitteeEnvelope tblCommitteeEnvelope){
        super.addEntity(tblCommitteeEnvelope);
    }

    @Override
    public void deleteTblCommitteeEnvelope(TblCommitteeEnvelope tblCommitteeEnvelope) {
        super.deleteEntity(tblCommitteeEnvelope);
    }

    @Override
    public void updateTblCommitteeEnvelope(TblCommitteeEnvelope tblCommitteeEnvelope) {
        super.updateEntity(tblCommitteeEnvelope);
    }

    @Override
    public List<TblCommitteeEnvelope> getAllTblCommitteeEnvelope() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCommitteeEnvelope> findTblCommitteeEnvelope(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCommitteeEnvelopeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCommitteeEnvelope> findByCountTblCommitteeEnvelope(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCommitteeEnvelope(List<TblCommitteeEnvelope> tblCommitteeEnvelopes){
        super.updateAll(tblCommitteeEnvelopes);
    }
}