package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.etender.model.TblTenderFormula;
import java.util.List;

public interface TblTenderFormulaDao  {

    public void addTblTenderFormula(TblTenderFormula tblTenderFormula);

    public void deleteTblTenderFormula(TblTenderFormula tblTenderFormula);

    public void updateTblTenderFormula(TblTenderFormula tblTenderFormula);

    public List<TblTenderFormula> getAllTblTenderFormula();

    public List<TblTenderFormula> findTblTenderFormula(Object... values) throws Exception;

    public List<TblTenderFormula> findByCountTblTenderFormula(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblTenderFormulaCount();

    public void saveUpdateAllTblTenderFormula(List<TblTenderFormula> tblTenderFormulas);
}