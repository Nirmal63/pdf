package com.etl.eproc.etender.databean;

public class EvaluateBiddersDataBean {

	private String companyName;
	private String bidderApprovalId;
	private String remarks;
	private String isApproved;
	private String bidderIds;
	private String encodedName; //Changes done to show encoded bidder name for Bug #50576
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getBidderApprovalId() {
		return bidderApprovalId;
	}
	public void setBidderApprovalId(String bidderApprovalId) {
		this.bidderApprovalId = bidderApprovalId;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getIsApproved() {
		return isApproved;
	}
	public void setIsApproved(String isApproved) {
		this.isApproved = isApproved;
	}
	public String getBidderIds() {
		return bidderIds;
	}
	public void setBidderIds(String bidderIds) {
		this.bidderIds = bidderIds;
	}
	public String getEncodedName() {
		return encodedName;
	}
	public void setEncodedName(String encodedName) {
		this.encodedName = encodedName;
	}
    
	
	}
