package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblRebate;
import com.etl.eproc.etender.daointerface.TblRebateDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblRebateImpl extends AbcAbstractClass<TblRebate> implements TblRebateDao {

   

    @Override
    //@Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
    public void addTblRebate(TblRebate tblRebate){
        super.addEntity(tblRebate);
    }

    @Override
    public void deleteTblRebate(TblRebate tblRebate) {
        super.deleteEntity(tblRebate);
    }

    @Override
    public void updateTblRebate(TblRebate tblRebate) {
        super.updateEntity(tblRebate);
    }

    @Override
    public List<TblRebate> getAllTblRebate() {
        return super.getAllEntity();
    }

    @Override
    public List<TblRebate> findTblRebate(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblRebateCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblRebate> findByCountTblRebate(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblRebate(List<TblRebate> tblRebates){
        super.updateAll(tblRebates);
    }
}
