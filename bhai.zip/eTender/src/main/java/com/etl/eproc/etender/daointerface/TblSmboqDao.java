package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblSmboq;

import java.util.List;

public interface TblSmboqDao  {

    public void addTblsmboq(TblSmboq tblsmboq);

    public void deleteTblsmboq(TblSmboq tblsmboq);

    public void updateTblsmboq(TblSmboq tblsmboq);

    public List<TblSmboq> getAllTblsmboq();

    public List<TblSmboq> findTblsmboq(Object... values) throws Exception;

    public List<TblSmboq> findByCountTblsmboq(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblsmboqCount();

    public void saveUpdateAllTblsmboq(List<TblSmboq> tblsmboqs);
}