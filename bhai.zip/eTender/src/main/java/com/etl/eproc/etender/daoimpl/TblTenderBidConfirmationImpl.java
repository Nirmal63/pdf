package com.etl.eproc.etender.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderBidConfirmationDao;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblTenderBidConfirmation;
import com.etl.eproc.etender.model.TblTenderBidRegression;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderBidConfirmationImpl extends AbcAbstractClass<TblTenderBidConfirmation> implements TblTenderBidConfirmationDao {

   

    @Override
    public void addTblTenderBidConfirmation(TblTenderBidConfirmation tblTenderBidConfirmation){
        super.addEntity(tblTenderBidConfirmation);
    }

    @Override
    public void deleteTblTenderBidConfirmation(TblTenderBidConfirmation tblTenderBidConfirmation) {
        super.deleteEntity(tblTenderBidConfirmation);
    }

    @Override
    public void updateTblTenderBidConfirmation(TblTenderBidConfirmation tblTenderBidConfirmation) {
        super.updateEntity(tblTenderBidConfirmation);
    }

    @Override
    public List<TblTenderBidConfirmation> getAllTblTenderBidConfirmation() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderBidConfirmation> findTblTenderBidConfirmation(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderBidConfirmationCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderBidConfirmation> findByCountTblTenderBidConfirmation(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderBidConfirmation(List<TblTenderBidConfirmation> tblTenderBidConfirmations){
        super.updateAll(tblTenderBidConfirmations);
    }
    /**
     * Added by Dhananjay to enable Regret button functionality on 18-08-2017
     */
	/*@Override
	public void addTblTenderRegretBidConfirmation(TblTenderBidRegression tblTenderBidRegression) {
		  //super.addEntity(tblTenderBidRegression);
		
		getHibernateTemplate().save(tblTenderBidRegression);
		
	}*/
}
