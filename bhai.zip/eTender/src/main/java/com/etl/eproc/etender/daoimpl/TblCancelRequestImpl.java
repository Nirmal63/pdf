package com.etl.eproc.etender.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblCancelRequestDao;
import com.etl.eproc.etender.model.TblCancelRequest;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblCancelRequestImpl extends AbcAbstractClass<TblCancelRequest> implements TblCancelRequestDao {

    
    @Override
    public void addTblCancelRequest(TblCancelRequest tblCancelRequest){
        super.addEntity(tblCancelRequest);
    }

    @Override
    public void deleteTblCancelRequest(TblCancelRequest tblCancelRequest) {
        super.deleteEntity(tblCancelRequest);
    }

    @Override
    public void updateTblCancelRequest(TblCancelRequest tblCancelRequest) {
        super.updateEntity(tblCancelRequest);
    }

    @Override
    public List<TblCancelRequest> getAllTblCancelRequest() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCancelRequest> findTblCancelRequest(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCancelRequestCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCancelRequest> findByCountTblCancelRequest(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCancelRequest(List<TblCancelRequest> tblCancelRequests){
        super.updateAll(tblCancelRequests);
    }
}

