package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblTenderWiseBudgetDetails;
import com.etl.eproc.etender.daointerface.TblTenderWiseBudgetDetailsDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderWiseBudgetDetailsImpl extends AbcAbstractClass<TblTenderWiseBudgetDetails> implements TblTenderWiseBudgetDetailsDao {


    @Override
    public void addTblTenderWiseBudgetDetails(TblTenderWiseBudgetDetails tblTenderWiseBudgetDetails){
        super.addEntity(tblTenderWiseBudgetDetails);
    }

    @Override
    public void deleteTblTenderWiseBudgetDetails(TblTenderWiseBudgetDetails tblTenderWiseBudgetDetails) {
        super.deleteEntity(tblTenderWiseBudgetDetails);
    }

    @Override
    public void updateTblTenderWiseBudgetDetails(TblTenderWiseBudgetDetails tblTenderWiseBudgetDetails) {
        super.updateEntity(tblTenderWiseBudgetDetails);
    }

    @Override
    public List<TblTenderWiseBudgetDetails> getAllTblTenderWiseBudgetDetails() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderWiseBudgetDetails> findTblTenderWiseBudgetDetails(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderWiseBudgetDetailsCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderWiseBudgetDetails> findByCountTblTenderWiseBudgetDetails(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderWiseBudgetDetails(List<TblTenderWiseBudgetDetails> tblTenderWiseBudgetDetailss){
        super.updateAll(tblTenderWiseBudgetDetailss);
    }

	@Override
	public void saveOrUpdateTblTenderWiseBudgetDetails(TblTenderWiseBudgetDetails tbltenderwisebudgetdetails) {
		super.saveOrUpdateEntity(tbltenderwisebudgetdetails);
	}
}
