package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblTenderReportDetail;
import java.util.List;

public interface TblTenderReportDetailDao  {

    public void addTblTenderReportDetail(TblTenderReportDetail tblTenderReportDetail);

    public void deleteTblTenderReportDetail(TblTenderReportDetail tblTenderReportDetail);

    public void updateTblTenderReportDetail(TblTenderReportDetail tblTenderReportDetail);

    public List<TblTenderReportDetail> getAllTblTenderReportDetail();

    public List<TblTenderReportDetail> findTblTenderReportDetail(Object... values) throws Exception;

    public List<TblTenderReportDetail> findByCountTblTenderReportDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderReportDetailCount();

    public void saveUpdateAllTblTenderReportDetail(List<TblTenderReportDetail> tblTenderReportDetails);
}