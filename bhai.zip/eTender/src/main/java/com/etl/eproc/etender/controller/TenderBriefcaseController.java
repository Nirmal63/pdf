/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblBidderDocFolder;
import com.etl.eproc.common.model.TblBidderDocMapping;
import com.etl.eproc.common.model.TblBidderDocument;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblExemptionCertConf;
import com.etl.eproc.common.model.TblExemptionCertificate;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.FileEncryptDecryptUtil;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.TenderBriefcaseService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderFormService;
/**
 *
 * @author Nihar
 */
@Controller
public class TenderBriefcaseController {

    @Autowired
    private TenderBriefcaseService tenderBriefcaseService;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private FileEncryptDecryptUtil fileEncryptDecryptUtil;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private TenderFormService tenderFormService;
        
    @Value("#{projectProperties['bidder.docstatus.approve']?:1}")
    private int bidderDocStatusApprove;
    @Value("#{projectProperties['bidder.docstatus.reject']?:2}")
	private int bidderDocStatusReject;
    @Value("#{adminAuditTrailProperties['get_uploaded_exemption_cert']}")
        private String getUploadedExemptionCertificate;
        
        @Value("#{adminAuditTrailProperties['get_exemption_cert_detail']}")
        private String getExemptionCertDetail;
        
        @Value("#{adminAuditTrailProperties['post_exemption_cert_detail']}")
        private String postExemptionCertDetail;
        @Value("#{tenderlinkProperties['bid_preparation_and_submission_create_bid']?:237}")
        private int bidPreparationSubmissionCreateBid;
    @Autowired
    private MessageSource messageSource;
	private static final int FILESIGNATURE_ZIP[] = new int[]{0x50, 0x4B, 0x03, 0x04};
	private static final int FILESIGNATURE_PDF[] = new int[]{0x25, 0x50, 0x44, 0x46};
	private static final int FILESIGNATURE_RAR[] = new int[]{0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x00};
	private static final int FILESIGNATURE_EXE[] = new int[]{0x4D, 0x5A};
	private static final int FILESIGNATURE_BMP[] = new int[]{0x42, 0x4D};
	private static final int FILESIGNATURE_DOCX_XLSX[] =  new int[]{0x50, 0x4B, 0x03, 0x04, 0x14, 0x00, 0x06, 0x00};
	private static final int FILESIGNATURE_DOC_PPT_XLS_PPS[] = new int[]{0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1};
	private static final int FILESIGNATURE_PNG[] = new int[]{0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A};
	private static final String SESSION_OBJECT="sessionObject";
    private static final String EVENT_ID="txtEventId";
	private static final String CSTATUS_DOC ="cStatusDoc";
	private static final String TXT_LINKID ="txtlinkId";
	private static final String TXT_OBJECTID ="txtobjectId";
	private static final String OBJECTID ="objectId";
	private static final String DOC_ID ="docId";
	private static final String LINKID ="linkId";
	private static final String TENDERID ="tenderId";
	private static final String FOLDERLIST ="folderList";
	private static final String HDOBJECTID ="hdObjectId";
	private static final String HDTENDERID ="hdTenderId";
	private static final String HDLINKID ="hdLinkId";
	private static final String TXT_FOLDERNAME ="txtFolderName";
	private static final String TXT_MANDOCNAME ="txtManDocName";
	private static final String URL ="etender/bidder/uploadbriefcasedocuments/"; 
	private static final String REDIRECTURL ="redirect:/etender/bidder/uploadbriefcasedocuments/";
	private static final String END_TD ="</td>";
	private static final String END_TH ="</tH>";
	private static final String END_A ="</a>";
	@Value("#{projectProperties['doc_upload_path']}")
	private String docUploadPath;
	@Value("#{etenderAuditTrailProperties['getuploadbriefcasedocumentpage']}")
    private String getUploadBriefcaseDocumentPage;
	@Value("#{etenderAuditTrailProperties['ajaxgetuploadbriefcasedocumentpage']}")
    private String ajaxGetUploadBriefcaseDocumentPage;
	@Value("#{etenderAuditTrailProperties['ajaxgetmapbriefcasedocumentpage']}")
    private String ajaxGetMapBriefcaseDocumentPage;
	@Value("#{etenderAuditTrailProperties['ajaxpostbriefcasefileuploaded']}")
    private String ajaxPostBriefcaseFileUploaded;
	@Value("#{etenderAuditTrailProperties['ajaxpostbriefcasefileuploadedmapped']}")
    private String ajaxPostBriefcaseFileUploadedMapped;
	@Value("#{etenderAuditTrailProperties['getcreatefolder']}")
    private String getCreateFolder;
	@Value("#{etenderAuditTrailProperties['postaddcreatefolder']}")
    private String postAddCreateFolder;
	@Value("#{etenderAuditTrailProperties['postmappeddocument']}")
    private String postMappedDocument;
	@Value("#{etenderAuditTrailProperties['postunmappeddocument']}")
    private String postUnmappedDocument;
	@Value("#{etenderAuditTrailProperties['getmovetofolder']}")
    private String getMoveToFolder;
	@Value("#{etenderAuditTrailProperties['postmovetofolder']}")
    private String postMoveToFolder;
	@Value("#{etenderAuditTrailProperties['ajaxgetuploadeddocsforbriefcase']}")
    private String ajaxGetuploadedDocsForBriefcase;
	@Value("#{etenderAuditTrailProperties['ajaxgetbriefcasemapeddocs']}")
    private String ajaxGetBriefcaseMapedDocs;
	@Value("#{etenderAuditTrailProperties['ajaxdeletebriefcasedocument']}")
    private String ajaxDeleteBriefcaseDocument;
	@Value("#{etenderAuditTrailProperties['ajaxarchivedbriefcasedocument']}")
    private String ajaxArchivedBriefcaseDocument;
	@Value("#{etenderAuditTrailProperties['ajaxdownloadbriefcasedocument']}")
    private String ajaxDownloadBriefcaseDocument;
	@Value("#{etenderAuditTrailProperties['getdeletefolder']}")
    private String deleteFolder;
	@Value("#{etenderAuditTrailProperties['geteditfolder']}")
    private String getEditFolder;
	@Value("#{etenderAuditTrailProperties['posteditfolder']}")
    private String postEditFolder;
	
	@Value("#{tenderlinkProperties['bidder_download']?:256}")
    private int downloadDocLinkId;
	@Value("#{tenderlinkProperties['bidder_file_upload']?:269}")
    private int fileUploadLinkId;
	@Value("#{tenderlinkProperties['bidder_create_folder']?:270}")
    private int createFolderLinkId;
	@Value("#{tenderlinkProperties['bidder_unmap_document']?:272}")
    private int unmapDocumentLinkId;
	@Value("#{tenderlinkProperties['bidder_map_document']?:271}")
    private int mapDocumentLinkId;
	@Value("#{tenderlinkProperties['bidder_delete_document']?:273}")
    private int deleteDocumentLinkId;
	@Value("#{tenderlinkProperties['bidder_move_to_folder']?:274}")
    private int moveToFolderLinkId;
	@Value("#{tenderlinkProperties['bidder_move_to_archive']?:275}")
    private int moveToArchiveLinkId;
        @Value("#{tenderlinkProperties['bidder_configure']?:426}")
        private int configureExemptionCertLinkId;
        @Value("#{tenderlinkProperties['bidder_upload']?:427}")
        private int uploadExemptionCertLinkId;
        @Value("#{tenderlinkProperties['manage_exemption_configure']?:458}")
        private int exemptionDetailConfigureLinkId;
	@Value("#{tenderlinkProperties['bidding_form_create_mandatory_docs']?:317}")
    private int createManDocLinkId;
       @Value("#{tenderlinkProperties['bidder.upload.certificate.eventId']?:88}")
    private int upload_cert_eventId;
   @Value("#{tenderlinkProperties['bidder_edit_folder']?:446}")
   private int editFolderLinkId;
   @Value("#{tenderlinkProperties['bidder_remove_folder']?:447}")
   private int deleteFolderLinkId;
      
    
    /** author : heeral.soni
     * to get list of exemption certificate details
     * @param request
     * @param modelMap
     * @return
     */
        @RequestMapping(value = "/etender/bidder/getexemptioncertdetail", method = RequestMethod.POST)  
        public String getExemptionCertDetail(ModelMap modelMap, HttpServletRequest request){
            try {
                SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
                int companyId = 0;
                if(sessionBean != null){
                    companyId = sessionBean.getCompanyId();
                }
                modelMap.addAttribute("ExemptionCertList", tenderBriefcaseService.getExemptionConfigurationDetail(companyId,abcUtility.getSessionClientId(request)));
            } catch(Exception ex) {
                return exceptionHandlerService.writeLog(ex);
            } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), exemptionDetailConfigureLinkId, getExemptionCertDetail,0,0);
            }
            return "etender/bidder/ExemptionCertConfigurationList";
        }
        
     /** author : heeral.soni
     * to get uplaoded certificate of bidder
     * @param objectId
     * @param request
     * @param modelMap
     * @return
     */
        @RequestMapping(value = "/etender/bidder/uploadcertificate/{objectId}/{enc}", method = RequestMethod.GET)
        public String uploadExemptionCertificate(@PathVariable("objectId") int objectId,ModelMap modelMap, HttpServletRequest request, HttpSession session) {
        try {
	    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(upload_cert_eventId, abcUtility.getSessionClientId(request));
	    int allowedSize = 0;
	    StringBuilder allowedExt = new StringBuilder();
	    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
                allowedSize = lstDocUploadConf.get(0).getMaxSize();
                allowedExt.append(lstDocUploadConf.get(0).getType());
                modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
	    }
	    int index = allowedExt.toString().indexOf(",");
	    allowedExt.insert(index + 1, "*.");
	    while (index >= 0) {
                index = allowedExt.toString().indexOf(",", index + ",".length());
                allowedExt.insert(index + 1, "*.");
	    }

	    modelMap.addAttribute("allowedExt", allowedExt);
	    modelMap.addAttribute("allowedSize", allowedSize/1024);
	    //modelMap.addAttribute("linkId", 175);
            modelMap.addAttribute("linkId", uploadExemptionCertLinkId);
	    modelMap.addAttribute("objectId", objectId);
	    modelMap.addAttribute("cStatusDoc", 1);
            modelMap.addAttribute("cStatusDocView", 1);
            modelMap.addAttribute("SingleFileUpload", 1);            
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), uploadExemptionCertLinkId, getUploadedExemptionCertificate,objectId,0);
        }
        return "etender/bidder/UploadExemptionCertificate";
    }
        
     /** author : heeral.soni
     * to configure exemption certificate
     * @param request
     * @param modelMap
     * @return
     */
        @RequestMapping(value = "/etender/bidder/exemptionconfig/{enc}", method = RequestMethod.GET)                       
        public String exemptionCertConfiguration(ModelMap modelMap, HttpServletRequest request){
            try {
                SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
                int companyId = 0;
                if(sessionBean != null){
                    companyId = sessionBean.getCompanyId();
                }
                modelMap.addAttribute("selCertificate", abcUtility.convert(tenderBriefcaseService.getExemptionCertificateType(abcUtility.getSessionClientId(request))));
                modelMap.addAttribute("companyId",companyId);
                modelMap.addAttribute("companyName", commonService.getCompanyNameByCompanyId(companyId));
            } catch(Exception ex) {
                return exceptionHandlerService.writeLog(ex);
            } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), configureExemptionCertLinkId, getExemptionCertDetail,0,0);
            }
            return "etender/bidder/ExemptionCertConfiguration";
        }
                 
     /** author : heeral.soni
     * to save exemtion cert configuration
     * @param request
     * @param modelMap
     * @return
     */
        @RequestMapping(value = "/etender/bidder/addexemptionconfig", method = RequestMethod.POST)
        public String addExemptionConfiguration(HttpServletRequest request, RedirectAttributes redirectAttributes){
            int exemptionCertTypeId = 0;
            String retVal = null;
            try{
                String dateFrom = request.getParameter("txtCertDateFrom");
                String dateTo = request.getParameter("txtCertDateTo");
                                
                TblExemptionCertConf tblExemptionCertConf = new TblExemptionCertConf();
                tblExemptionCertConf.setTblExemptionCertificate(new TblExemptionCertificate(StringUtils.hasLength(request.getParameter("selExCertType")) ? Integer.parseInt(request.getParameter("selExCertType")) : 0));
                tblExemptionCertConf.setTblCompany(new TblCompany(StringUtils.hasLength(request.getParameter("hdCompanyId")) ? Integer.parseInt(request.getParameter("hdCompanyId")) : 0));
                tblExemptionCertConf.setCertificateType(StringUtils.hasLength(request.getParameter("txtCertType"))?request.getParameter("txtCertType"):null);
                tblExemptionCertConf.setCertificateNo(StringUtils.hasLength(request.getParameter("txtCertNo"))?request.getParameter("txtCertNo"):null);
                tblExemptionCertConf.setCertificateFrom(StringUtils.hasLength(dateFrom) ? CommonUtility.getDateObj(dateFrom) : null);
                tblExemptionCertConf.setCertificateUpTo(StringUtils.hasLength(dateTo) ? CommonUtility.getDateObj(dateTo) : null);
                tblExemptionCertConf.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                
                boolean isInserted = tenderBriefcaseService.addExemptionCertDetails(tblExemptionCertConf);
                exemptionCertTypeId = tblExemptionCertConf.getExemptionCertConfId();
                retVal = "etender/bidder/uploadcertificate/"+exemptionCertTypeId;
                redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? "msg_certificate_success" : CommonKeywords.ERROR_MSG_KEY.toString());
            }catch (Exception ex) {
                return exceptionHandlerService.writeLog(ex);
            }finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), configureExemptionCertLinkId, postExemptionCertDetail,0,exemptionCertTypeId);
            }
            return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
        }
                
    /**
     * to get tender upload document page at bidder side for briefcase
     * @param objectId
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/etender/bidder/uploadbriefcasedocuments/{objectId}/{tenderId}/{linkId}/{tabId}/{enc}", method = RequestMethod.GET)
    public String uploadBriefcaseDocuments(@PathVariable(OBJECTID) int objectId,@PathVariable(LINKID) int linkId,@PathVariable(TENDERID) int tenderId,@PathVariable("tabId") int tabId, HttpServletRequest request, ModelMap modelMap) {
	try{
		int clientId = abcUtility.getSessionClientId(request);
	    //tenderCommonService.tenderSummary(objectId, modelMap, clientId);
		String publicKey=null;
		int signedPdfRequired = 0;
		if(tenderId != 0){
			signedPdfRequired = (Integer)tenderCommonService.getTenderField(tenderFormService.getTenderFormById(tenderId).getTblTender().getTenderId(),"signedPdfRequired");
		}
    	if(abcUtility.getSessionIsPkiEnabled(request)==1){
    		String certIds[] = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
    		if(certIds!=null && certIds.length!=0){
    			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
    		}
    		modelMap.addAttribute("publicKey", publicKey);
		}
    	List<Object[]> tenderIdList=commonService.getExecuteQuery("select tbltenderform.tblTender.tenderId,tbltenderform.formId from TblTenderForm tbltenderform where tbltenderform.formId="+tenderId, clientId);
    	if(tenderIdList !=null && !tenderIdList.isEmpty() && tenderId !=0){
    		tenderCommonService.tenderSummary((Integer)tenderIdList.get(0)[0], modelMap, clientId);
    	}
    	modelMap.addAttribute("tenderIdList", tenderIdList);
		List<Object[]> eventList=commonService.getEventIdFromLinkId(linkId);
		if(!eventList.isEmpty()){
		    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(Integer.parseInt(eventList.get(0)[1].toString()), clientId);
		    int allowedSize = 0;
		    StringBuilder allowedExt = new StringBuilder();
		    StringBuilder allowedExtPdfOnly = new StringBuilder();
		    allowedExtPdfOnly.append("*.pdf");
		    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
				allowedSize = lstDocUploadConf.get(0).getMaxSize();
				allowedExt.append(lstDocUploadConf.get(0).getType());
				modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
		    }
		    int index = allowedExt.toString().indexOf(",");
		    allowedExt.insert(index + 1, "*.");
		    while (index >= 0) {
				index = allowedExt.toString().indexOf(",", index + ",".length());
				allowedExt.insert(index + 1, "*.");
		    }
		    if(signedPdfRequired == 1){
			    modelMap.addAttribute("allowedExt", allowedExtPdfOnly);
		    }else{
			    modelMap.addAttribute("allowedExt", allowedExt);
		    }
		    modelMap.addAttribute("allowedSize", allowedSize/1024);
		}
	    modelMap.addAttribute(FOLDERLIST, abcUtility.convert(tenderBriefcaseService.getBidderFolder(abcUtility.getSessionUserId(request))));
	    modelMap.addAttribute(LINKID, linkId);
	    modelMap.addAttribute("otherObjectId", tenderId);
	    modelMap.addAttribute(OBJECTID, objectId);
	    modelMap.addAttribute("cStatusDoc", bidderDocStatusApprove);
        modelMap.addAttribute("isNSICConfigure", tenderBriefcaseService.isNSICConfigure(clientId));
        modelMap.addAttribute("signedPdfRequired", signedPdfRequired);
        if(linkId == bidPreparationSubmissionCreateBid){
        	modelMap.addAttribute("formName",(tenderFormService.getTenderFormById(tenderId)).getFormName());
        }
	}catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	}finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), fileUploadLinkId, getUploadBriefcaseDocumentPage, objectId, 0);
	}
		return "etender/bidder/UploadBriefcaseDocuments";
    }
    
    /**
     * @param tenderId
     * @param tabId
     * @param request
     * @param modelMap
     * @return ajax jsp
     */
    @RequestMapping(value = "/etender/bidder/briefcasecontent", method = RequestMethod.POST)
    public String briefcaseContent(@RequestParam(HDOBJECTID) int objectId, @RequestParam("txtTabId") int tabId, @RequestParam("txtLinkId") int linkId,@RequestParam(HDTENDERID) int tenderId, HttpServletRequest request, ModelMap modelMap) {
    	String message="";
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            	int clientId = abcUtility.getSessionClientId(request);
            	List<Object[]> docslst=null,tmpdocslst=null;
            	 List<Object[]> lstDocumentDetails = new ArrayList<Object[]>();
            	 int i=0;
            	int signedPdfRequired = 0;
            	if(tenderId != 0){
            		signedPdfRequired = (Integer)tenderCommonService.getTenderField(tenderFormService.getTenderFormById(tenderId).getTblTender().getTenderId(),"signedPdfRequired");
            	}
     		    StringBuilder allowedExtPdfOnly = new StringBuilder();
     		    allowedExtPdfOnly.append("*.pdf");
                switch(tabId){
                    case 1:
                	    //tenderCommonService.tenderSummary(objectId, modelMap, clientId);
                    	String publicKey=null;
                    	if(abcUtility.getSessionIsPkiEnabled(request)==1){
                    		String certIds[] = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
                    		if(certIds!=null && certIds.length!=0){
                    			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
                    		}
                    		modelMap.addAttribute("publicKey", publicKey);
                		}
                    	List<Object[]> eventList=commonService.getEventIdFromLinkId(linkId);
                    	if(!eventList.isEmpty()){
                		    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(Integer.parseInt(eventList.get(0)[1].toString()), clientId);
	                	    int allowedSize = 0;
	                	    StringBuilder allowedExt = new StringBuilder();
	                	    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
	                			allowedSize = lstDocUploadConf.get(0).getMaxSize();
	                			allowedExt.append(lstDocUploadConf.get(0).getType());
	                			modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
	                	    }
	                	    int index = allowedExt.toString().indexOf(",");
	                	    allowedExt.insert(index + 1, "*.");
	                	    while (index >= 0) {
	                			index = allowedExt.toString().indexOf(",", index + ",".length());
	                			allowedExt.insert(index + 1, "*.");
	                	    }
	                	    if(signedPdfRequired == 1){
	            			    modelMap.addAttribute("allowedExt", allowedExtPdfOnly);
	            		    }else{
	            			    modelMap.addAttribute("allowedExt", allowedExt);
	            		    }
	                	    modelMap.addAttribute("allowedSize", allowedSize/1024);
                    	}
                	    modelMap.addAttribute(FOLDERLIST, abcUtility.convert(tenderBriefcaseService.getBidderFolder(abcUtility.getSessionUserId(request))));
                	    //modelMap.addAttribute("docCheckListList", abcUtility.convert(tenderBriefcaseService.getMandatoryDoc(tenderId, createManDocLinkId)));
                	    docslst=tenderBriefcaseService.getDocumentCheckList(tenderId, createManDocLinkId);
                	    tmpdocslst=new ArrayList<Object[]>();
                	    lstDocumentDetails=tenderBriefcaseService.getMapedDocuments(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request),objectId,linkId);
                	    if(lstDocumentDetails!=null){
                	    for(Object[] obj:lstDocumentDetails){
                	    	for(Object[] list:docslst){
                	    		if(obj[4]!=null && obj[4].equals(list[1]))
                	    			tmpdocslst.add(list);
                	    	}
                	    }
                	    for(Object[] list:tmpdocslst)
                	    	docslst.remove(list);
                	    }
                	    modelMap.addAttribute("docCheckListList", abcUtility.convert(docslst));
                	    modelMap.addAttribute("docCheckLists", docslst);
                	    modelMap.addAttribute(LINKID, linkId);
                	    modelMap.addAttribute(OBJECTID, objectId); 
                	    modelMap.addAttribute("cStatusDoc", bidderDocStatusApprove);
                	    message=ajaxGetUploadBriefcaseDocumentPage;
                        break;
                    
                    case 2:
                    	modelMap.addAttribute(FOLDERLIST, abcUtility.convert(tenderBriefcaseService.getBidderFolder(abcUtility.getSessionUserId(request))));
                    	//modelMap.addAttribute("docCheckListList", abcUtility.convert(tenderBriefcaseService.getMandatoryDoc(tenderId, createManDocLinkId)));
                    	docslst=tenderBriefcaseService.getDocumentCheckList(tenderId, createManDocLinkId);
                    	tmpdocslst=new ArrayList<Object[]>();
                        i=0;
                	    lstDocumentDetails=tenderBriefcaseService.getMapedDocuments(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request),objectId,linkId);
                	    modelMap.addAttribute("docCheckListList", abcUtility.convert(docslst));
                	    if(lstDocumentDetails!=null){
                	    for(Object[] obj:lstDocumentDetails){
                	    	for(Object[] list:docslst){
                	    		if(obj[4]!=null && obj[4].equals(list[1]))
                	    			tmpdocslst.add(list);
                	    	}
                	    }
                	    for(Object[] list:tmpdocslst)
                	    	docslst.remove(list);
                	    }
                		
                    	modelMap.addAttribute("docCheckLists", docslst);

                    	modelMap.addAttribute(LINKID, linkId);
                	    modelMap.addAttribute(OBJECTID, objectId);
                	    modelMap.addAttribute("tenderIdList", commonService.getExecuteQuery("select tbltenderform.tblTender.tenderId,tbltenderform.formId from TblTenderForm tbltenderform where tbltenderform.formId="+tenderId, clientId));
                	    message=ajaxGetMapBriefcaseDocumentPage;
                        break;
                    
                }
                modelMap.addAttribute("signedPdfRequired", signedPdfRequired);
                modelMap.addAttribute("otherObjectId", tenderId);
                modelMap.addAttribute("tabId", tabId);
                modelMap.addAttribute("isNSICConfigure", tenderBriefcaseService.isNSICConfigure(clientId));
            }else{
                modelMap.addAttribute("sessionExpired",true);
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), fileUploadLinkId, message, objectId, 0);
        }
        return "/etender/bidder/BriefcaseContent";
    }
    
    
    /**
     * to submit file upload through ajax
     * @param request
     * @param response
     * @param session
     * @throws IOException
     */
    @RequestMapping(value = "/ajax/submitbriefcasefileupload",method = RequestMethod.POST)
    public void ajaxSubmitFileUpload(HttpServletRequest request, HttpServletResponse response,HttpSession session){
    	 boolean isValidate = true;
         int clientId = 0;
         String result="";
         Integer objectId=0;
         int auditTrialObjectId=0;
         String donloadDocPath="";
         String signText="";
         int tenderId=0;
         try {
        	 PrintWriter out = response.getWriter();
        	 Object sessionBean=session.getAttribute(SESSION_OBJECT);
        	 response.setContentType("text/html");
        	 if(sessionBean != null){
	        	 int userId = abcUtility.getSessionUserId(request);
	             String fileDesc = null;
	             clientId = abcUtility.getSessionClientId(request);
	             int eventId=0;
	             int linkId=0;
	             String description=StringUtils.hasLength(request.getParameter("txtDocDesc")) ? request.getParameter("txtDocDesc") : null; 
	             objectId = StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0;
	             eventId = StringUtils.hasLength(request.getParameter(EVENT_ID)) ? Integer.parseInt(request.getParameter(EVENT_ID)) : 0;
	        	 linkId = StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? Integer.parseInt(request.getParameter(TXT_LINKID)) : 0;
	        	 tenderId=StringUtils.hasLength(request.getParameter("txtTenderId")) ? Integer.parseInt(request.getParameter("txtTenderId")) : 0;
	             List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, clientId);
	             int folderId=StringUtils.hasLength(request.getParameter(TXT_FOLDERNAME)) ? Integer.parseInt(request.getParameter(TXT_FOLDERNAME)) : 0;
	             int documentId=StringUtils.hasLength(request.getParameter("txtDocCheckList")) && !"undefined".equalsIgnoreCase(request.getParameter("txtDocCheckList")) ? Integer.parseInt(request.getParameter("txtDocCheckList")) : 0;
	             String docName=StringUtils.hasLength(request.getParameter(TXT_MANDOCNAME)) && !"undefined".equalsIgnoreCase(request.getParameter(TXT_MANDOCNAME)) ? request.getParameter(TXT_MANDOCNAME) : "";
	             signText=StringUtils.hasLength(request.getParameter("skpSignText")) ? request.getParameter("skpSignText") : "";
	             TblDocUploadConf tblDocUploadConf=lstDocUploadConf.get(0);
	             boolean fileUploadedSuccess = false;
	             File file = null;
	             File tmpDir=null;
	             String fileDir = "";
	             long fileSize = 0;
	             String fileName = "";
	             long fileMaxSize = lstDocUploadConf.get(0).getMaxSize() * 1024;
	             String fileExtensions = lstDocUploadConf.get(0).getType();
	             DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
	             fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
	             ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
	             List items = uploadHandler.parseRequest(request);
	             Iterator itr = items.iterator();
	             int signedPdfRequired = 0;
	             if(tenderId != 0){
	                 signedPdfRequired = (Integer)tenderCommonService.getTenderField(tenderFormService.getTenderFormById(tenderId).getTblTender().getTenderId(),"signedPdfRequired");
	             }
	             while (itr.hasNext()) {
	            	 if(description == null){
	            		 isValidate = false;
	            		 result=messageSource.getMessage("msg_tender_docbrief_empty", null, LocaleContextHolder.getLocale());
	                     break;
	            	 }
	                 FileItem item = (FileItem) itr.next();
	                 if (item.isFormField()) {
	                     if (item.getFieldName().equals("txtDocDesc")) {
	                         fileDesc = item.getString();
	                         if(fileDesc == null || "".equalsIgnoreCase(fileDesc.trim())){
	                             isValidate = false;
	                             break;
	                         }
	                     }
	                 } else {
	                     fileSize = item.getSize();
	                     if (item.getName().lastIndexOf("\\") != -1) {
	                         fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1, item.getName().length());
	                     } else {
	                         fileName = item.getName();
	                     }
	                     if (fileName != null && !fileName.equalsIgnoreCase("")) {
	                         if(fileSize == 0){
	                        	 result=messageSource.getMessage("msg_tender_emptyfile", null, LocaleContextHolder.getLocale());
	                             isValidate = false;
	                             break;
	                         }
	                         if (!checkFileSize(fileSize, fileMaxSize)) {
	                        	 result= messageSource.getMessage("msg_tender_filesizeexceeds", new Object[]{fileMaxSize / (1024*1024)}, LocaleContextHolder.getLocale());
	                             isValidate = false;
	                             break;
	                         }
	                         if(signedPdfRequired == 1){
	                        	 if(fileName.endsWith(".pdf")  && !commonService.checkPdfSigned(item.get())){
	                        		 result=messageSource.getMessage("msg_bidder_uploaded_pdf_not_signed", null, LocaleContextHolder.getLocale());
		                             isValidate = false;
		                             break;
	                        	 }else if(!fileName.endsWith(".pdf")){
	                        		 result=messageSource.getMessage("msg_tender_acceptablefiletypes", new Object[]{"*.pdf"}, LocaleContextHolder.getLocale());
		                             isValidate = false;
		                             break;
	                        	 }
	                         }
	                         if (!checkFileExn(fileName, fileExtensions)) {
	                        	 StringBuilder allowedExt = new StringBuilder();
	                        	 if(!lstDocUploadConf.isEmpty()){
	                        		 allowedExt.append(lstDocUploadConf.get(0).getType());
	                        	 }
	                             int index = allowedExt.toString().indexOf(",");
	                             allowedExt.insert(index + 1, "*.");
	                             while (index >= 0) {
	                                 index = allowedExt.toString().indexOf(",", index + ",".length());
	                                 allowedExt.insert(index + 1, "*.");
	                             }
	                        	 result=messageSource.getMessage("msg_tender_acceptablefiletypes", new Object[]{allowedExt}, LocaleContextHolder.getLocale());
	                             isValidate = false;
	                             break;
	                         } else {
	                        	 /* if destination directory not exist then create it */
	                        	 isDirExists(docUploadPath.split(":")[0]+":\\\\", docUploadPath.substring(3, docUploadPath.length())+tblDocUploadConf.getPath());
	                        	 StringBuilder tmpDirPath=new StringBuilder();
	                        	 tmpDirPath.append(docUploadPath).append(tblDocUploadConf.getPath());
	                             if (tblDocUploadConf.getIsDynamicPath() == 1 && objectId == 0) {
	                                 fileDir = userId+"";
	                                 tmpDir = new File(tmpDirPath.append("\\").append(fileDir).toString());
	                                 donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                             } else if (objectId != 0 && tblDocUploadConf.getIsDynamicPath() ==1) {
	                                 fileDir = objectId.toString();
	                                 tmpDir = new File(tmpDirPath.append("\\").append(fileDir).toString());
	                                 donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                             }else if (objectId != 0 && tblDocUploadConf.getIsDynamicPath() ==0) {
	                                 fileDir = objectId.toString();
	                                 tmpDir = new File(tmpDirPath.append("\\").append(fileDir).toString());
	                                 donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                             }else if (objectId == 0) {
	                                 fileDir = String.valueOf(userId);
	                                 tmpDir = new File(tmpDirPath + "\\" + fileDir);
	                                 donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                             }
	                             else {
	                                 tmpDir = new File(tmpDirPath.toString());
	                                 donloadDocPath=tblDocUploadConf.getPath();
	                             }
	                             if (!tmpDir.isDirectory()) {
	                            	 tmpDir.mkdirs();
	                             }
	                             file = new File(tmpDir, fileName);
	                             if(abcUtility.ValidationForFileExist(file)) {
	                                 result= messageSource.getMessage("msg_tender_fileexists", null, LocaleContextHolder.getLocale());
	                                 isValidate = false;
	                                 fileUploadedSuccess = false;
	                                 break;
	                             }
	                             item.write(file);
	                             if (checkFileExn(fileName, "enc")){
	                            	 TblTenderForm tblTenderForm = null;
	                            	 String[] res = new String[2];
	                            	 tblTenderForm = tenderFormService.getTenderFormById(tenderId);//tenderId as formId
	                            	 if(tblTenderForm!=null){
	                            		 res =  encryptDecryptUtils.decryptSignerCode(file,tblTenderForm.getTblTender().getTenderId(),tblTenderForm.getTblTenderEnvelope().getEnvelopeId());
	                            		 if(res[0].contains("false")){
	                            			 isValidate = false;
	                            			 result= messageSource.getMessage(res[1], null, LocaleContextHolder.getLocale());
	                            		 }
	                            	 }
	                             }
	                             if (!isValidContentType(file)) {
	                                  file.delete();
	                                  result= messageSource.getMessage("msg_tender_invalidfiletype", null, LocaleContextHolder.getLocale());
	                                  fileUploadedSuccess = false;
	                                  isValidate = false;
	                              } else {
                                         if(tblDocUploadConf.getIsEncryptionReq()==1){
                                            fileEncryptDecryptUtil.fileEncryptUtil(file, (int) fileSize);
                                         }
	                                 fileUploadedSuccess = true;
	                             }
	                         }
	                     }
	                 }
	             }
	             if (isValidate) {
	                 if (fileUploadedSuccess) {
	                		 TblBidderDocument tblBidderDocument = new TblBidderDocument();
	                         tblBidderDocument.setDocName(fileName);
	                         tblBidderDocument.setTblClient(new TblClient(clientId));
	                         tblBidderDocument.setBidderFolderId(folderId);
	                         tblBidderDocument.setPath(donloadDocPath);
	                         tblBidderDocument.setDescription(description);
	                         tblBidderDocument.setFileSize(fileSize);
	                         tblBidderDocument.setCreatedBy(userId);
	                         tblBidderDocument.setCstatus(bidderDocStatusApprove);
	                         tblBidderDocument.setIsEncryptionReq(tblDocUploadConf.getIsEncryptionReq());
	                         TblBidderDocMapping tblBidderDocMapping=null;
	                         if(objectId !=0){
                        		tblBidderDocMapping = new TblBidderDocMapping();
             	                tblBidderDocMapping.setObjectId(objectId);
             	                tblBidderDocMapping.setTblLink(new TblLink(linkId));
             	                tblBidderDocMapping.setChildId(tenderId);
             	                tblBidderDocMapping.setMappedBy(userId);
             	                tblBidderDocMapping.setCstatus(bidderDocStatusApprove);
             	                tblBidderDocMapping.setDocumentId(documentId);
             	                tblBidderDocMapping.setDocumentName(docName);
             	                tblBidderDocMapping.setTblCompany(new TblCompany(commonService.getCompanyId(userId,clientId)));
	                         }
	                         if (tenderBriefcaseService.addBidderDocument(tblBidderDocument,tblBidderDocMapping) ) {
	                        	 auditTrialObjectId=tblBidderDocument.getBidderDocId();
	                         }
	                	 out.print(result);
	                 }else{
	                	 out.print("Error:" + result);
	                 }
	             }else{
	            	 out.print("Error:" + result);
	             }
        	 }else{
            	 out.print("Error:sessionexpired");
             }
         } catch (Exception e) {
             exceptionHandlerService.writeLog(e);
         } finally {
        	 if(abcUtility.getSessionIsPkiEnabled(request) == 1 ){
        		 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), fileUploadLinkId, objectId==0 ? ajaxPostBriefcaseFileUploaded : ajaxPostBriefcaseFileUploadedMapped, objectId, auditTrialObjectId,objectId==0 ? ajaxPostBriefcaseFileUploaded : ajaxPostBriefcaseFileUploadedMapped,signText);
         	}else{
         		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), fileUploadLinkId, objectId==0 ? ajaxPostBriefcaseFileUploaded : ajaxPostBriefcaseFileUploadedMapped, objectId, auditTrialObjectId);
         	}
         }
    }
    
    @RequestMapping(value = "/etender/bidder/createfolder/{objectId}/{otherObjectId}/{linkId}/{folderId}/{enc}", method = RequestMethod.GET)
    public String createFolder(@PathVariable(OBJECTID) int objectId,@PathVariable("otherObjectId") int otherObjectId,@PathVariable(LINKID) int linkId,@PathVariable("folderId") int folderId,HttpServletRequest request, ModelMap modelMap) {
    	try{
    		List<Object[]> folderList=tenderBriefcaseService.getBidderFolderForMoveToFolder(abcUtility.getSessionUserId(request),0);
    		String folderNameString="";
    		if(folderList != null && !folderList.isEmpty()){
    			for(Object[] obj : folderList){
        			folderNameString=folderNameString+obj[1]+",";
        		}
    			modelMap.addAttribute("folderNameString", folderNameString);
    		}
    		modelMap.addAttribute(FOLDERLIST, folderList);
    		if(folderId !=0){
    			List<Object[]> data = tenderBriefcaseService.getFolderDetailsFromFolderId(folderId);
    			if(!data.isEmpty()){
    				modelMap.addAttribute("folderNameDetails", data.get(0)[1]);
    			}
    		}
    	}catch (Exception e) {
    	    return exceptionHandlerService.writeLog(e);
    	}finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), folderId == 0 ? createFolderLinkId : editFolderLinkId, folderId == 0 ? getCreateFolder : getEditFolder, objectId, 0);
    	}
		return "etender/bidder/CreateFolder";
    }
    
    @RequestMapping(value = "/etender/bidder/deletefolder/{objectId}/{otherObjectId}/{linkId}/{folderId}/{enc}", method = RequestMethod.GET)
    public String deleteFolder(@PathVariable(OBJECTID) int objectId,@PathVariable("otherObjectId") int otherObjectId,@PathVariable(LINKID) int linkId,@PathVariable("folderId") int folderId,HttpServletRequest request, ModelMap modelMap,RedirectAttributes redirectAttributes) {
    	try{
    		boolean success=tenderBriefcaseService.deleteFolder(folderId);
    		modelMap.addAttribute(FOLDERLIST, tenderBriefcaseService.getBidderFolderForMoveToFolder(abcUtility.getSessionUserId(request),0));
    		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_folderdeleted" : CommonKeywords.ERROR_MSG_KEY.toString());
    	}catch (Exception e) {
    	    return exceptionHandlerService.writeLog(e);
    	}finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deleteFolderLinkId, deleteFolder, objectId, folderId);
    	}
		return "redirect:/etender/bidder/createfolder/"+objectId+"/"+otherObjectId+"/"+linkId+"/0"+encryptDecryptUtils.generateRedirect("etender/bidder/createfolder/"+objectId+"/"+otherObjectId+"/"+linkId+"/0", request);
    }
    
    @RequestMapping(value = "/etender/bidder/addcreatefolder", method = RequestMethod.POST)
    public String addCreateFolder(HttpServletRequest request, ModelMap modelMap,RedirectAttributes redirectAttributes) {
    	String retVal="redirect:/sessionexpired";
    	boolean result=false;
    	int objectId=0;
    	int didderDocFolderId=0;
    	int tenderId=0;
    	String message="msg_success_addfolder";
    	int linkIdAuditTrail=createFolderLinkId;
    	String auditTrailMessage=postAddCreateFolder;
	try{
		int userId=abcUtility.getSessionUserId(request);
		if(userId != 0){
			String folderName=StringUtils.hasLength(request.getParameter(TXT_FOLDERNAME)) ? request.getParameter(TXT_FOLDERNAME) : null;
			int linkId=StringUtils.hasLength(request.getParameter(HDLINKID)) ? Integer.parseInt(request.getParameter(HDLINKID)) : 0;
			objectId=StringUtils.hasLength(request.getParameter(HDOBJECTID)) ? Integer.parseInt(request.getParameter(HDOBJECTID)) : 0;
			tenderId=StringUtils.hasLength(request.getParameter(HDTENDERID)) ? Integer.parseInt(request.getParameter(HDTENDERID)) : 0;
			didderDocFolderId=StringUtils.hasLength(request.getParameter("hdFolderId")) ? Integer.parseInt(request.getParameter("hdFolderId")) : 0;
			if(folderName == null){
				retVal="redirect:/etender/bidder/createfolder/"+objectId+"/"+tenderId+"/"+linkId+encryptDecryptUtils.generateRedirect("etender/bidder/createfolder/"+objectId+"/"+tenderId+"/"+linkId, request);
			}else{
				TblBidderDocFolder tblBidderDocFolder=new TblBidderDocFolder();
				if(didderDocFolderId != 0){
					message="msg_success_editfolder";
					linkIdAuditTrail=editFolderLinkId;
					auditTrailMessage=postEditFolder;
					tblBidderDocFolder.setBidderFolderId(didderDocFolderId);
				}
				tblBidderDocFolder.setTblUserLogin(new TblUserLogin(userId));
				tblBidderDocFolder.setFolderName(folderName);
				result=tenderBriefcaseService.addBidderDocFolder(tblBidderDocFolder);
				if(result){
					didderDocFolderId=tblBidderDocFolder.getBidderFolderId();
					retVal=REDIRECTURL+objectId+"/"+tenderId+"/"+linkId+"/1"+encryptDecryptUtils.generateRedirect(URL+objectId+"/"+tenderId+"/"+linkId+"/1", request);
				}else{
					retVal="redirect:/etender/bidder/createfolder/"+objectId+"/"+tenderId+"/"+linkId+"/0"+encryptDecryptUtils.generateRedirect("etender/bidder/createfolder/"+objectId+"/"+tenderId+"/"+linkId+"/0", request);
				}
			}
			redirectAttributes.addFlashAttribute(result ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), result ? message : CommonKeywords.ERROR_MSG_KEY.toString());
		}
	}catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	}finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkIdAuditTrail, auditTrailMessage, objectId, didderDocFolderId);
	}
		return retVal;
    }
    
    /**
     * to map the documents
     * @param request
     * @param modelMap
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/etender/bidder/mapdocuments", method = RequestMethod.POST)
    public String mapDocuments(HttpServletRequest request, ModelMap modelMap,RedirectAttributes redirectAttributes) {
    	String retVal="redirect:/sessionexpired";
    	boolean result=false;
    	int objectId=0;
    	int linkId=0;
    	int tenderId=0;
    	try{
    		int userId=abcUtility.getSessionUserId(request);
    		if(userId != 0){
				String docId[]=request.getParameterValues("isSelect");
				if(docId==null){
					docId=StringUtils.hasLength(request.getParameter("txtDocId")) ? request.getParameter("txtDocId").split(",") : null;
				}
				objectId=StringUtils.hasLength(request.getParameter(HDOBJECTID)) ? Integer.parseInt(request.getParameter(HDOBJECTID)) : 0;
				linkId=StringUtils.hasLength(request.getParameter(HDLINKID)) ? Integer.parseInt(request.getParameter(HDLINKID)) : 0;
				tenderId=StringUtils.hasLength(request.getParameter(HDTENDERID)) ? Integer.parseInt(request.getParameter(HDTENDERID)) : 0;
				int documentId=StringUtils.hasLength(request.getParameter("selDocCheckList")) ? Integer.parseInt(request.getParameter("selDocCheckList")) : 0;
                                String docName=StringUtils.hasLength(request.getParameter(TXT_MANDOCNAME)) ? request.getParameter(TXT_MANDOCNAME) : "";
                                String mandatoryDocId[]=StringUtils.hasLength(request.getParameter("txtDocId1")) ? request.getParameter("txtDocId1").split(",") : null;
                                if(mandatoryDocId!=null){
                                    docId = mandatoryDocId;
                                    docName = commonService.getDocumentsByDocumentId(documentId).get(0).getDocumentName();
                                }
				if(docId == null || docId.length == 0 || objectId == 0){
					retVal=REDIRECTURL+objectId+"/"+tenderId+"/"+linkId+"/2"+encryptDecryptUtils.generateRedirect(URL+objectId+"/"+tenderId+"/"+linkId+"/2", request);
				}else{
					int clientId=abcUtility.getSessionClientId(request);
					int companyId=commonService.getCompanyId(userId,clientId);
					List<TblBidderDocMapping> tblBidderDocMappingList=new ArrayList<TblBidderDocMapping>();
					TblBidderDocMapping tblBidderDocMapping=null;
					for(int i=0;i<docId.length;i++){
						tblBidderDocMapping = new TblBidderDocMapping();
						tblBidderDocMapping.setTblBidderDocument(new TblBidderDocument(Integer.parseInt(docId[i])));
		                tblBidderDocMapping.setObjectId(objectId);
		                tblBidderDocMapping.setTblLink(new TblLink(linkId));
		                tblBidderDocMapping.setChildId(tenderId);
		                tblBidderDocMapping.setMappedBy(userId);
		                tblBidderDocMapping.setDocumentId(documentId);
	 	                tblBidderDocMapping.setDocumentName(docName);
		                tblBidderDocMapping.setCstatus(bidderDocStatusApprove);
		                tblBidderDocMapping.setTblCompany(new TblCompany(companyId));
		                tblBidderDocMappingList.add(tblBidderDocMapping);
					}
					boolean isFinalBidSubmisionDone=false;
					List<Object[]> tenderIdList=commonService.getExecuteQuery("select tbltenderform.tblTender.tenderId,tbltenderform.formId from TblTenderForm tbltenderform where tbltenderform.formId="+tenderId, clientId);
			    	if(tenderIdList !=null && !tenderIdList.isEmpty() && tenderId !=0){
			    		isFinalBidSubmisionDone=tenderCommonService.isFinalBidSubmision((Integer)tenderIdList.get(0)[0], companyId);
			    		Date submissionEndDate=(Date)tenderCommonService.getTenderField((Integer)tenderIdList.get(0)[0],"submissionEndDate");
						if(objectId !=0 && !isFinalBidSubmisionDone && submissionEndDate != null && submissionEndDate.after(commonService.getServerDateTime())){
							result=tenderBriefcaseService.mapDocuments(tblBidderDocMappingList);
						}
			    	}
					
					if(result){
						retVal=REDIRECTURL+objectId+"/"+tenderId+"/"+linkId+"/2"+encryptDecryptUtils.generateRedirect(URL+objectId+"/"+tenderId+"/"+linkId+"/2", request);
					}else{
						retVal=REDIRECTURL+objectId+"/"+tenderId+"/"+linkId+"/2"+encryptDecryptUtils.generateRedirect(URL+objectId+"/"+tenderId+"/"+linkId+"/2", request);
					}
				}
				redirectAttributes.addFlashAttribute(result ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), result ? "msg_success_mapdocument" : CommonKeywords.ERROR_MSG_KEY.toString());
    		}
		}catch (Exception e) {
			retVal= exceptionHandlerService.writeLog(e);
		}finally {
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), mapDocumentLinkId, postMappedDocument, objectId, 0);
		}
		return retVal;
    }
    
    @RequestMapping(value = "/etender/bidder/unmapdocuments", method = RequestMethod.POST)
    public String unMapDocuments(HttpServletRequest request, ModelMap modelMap,RedirectAttributes redirectAttributes) {
    	String retVal="redirect:/sessionexpired";
    	boolean result=false;
    	int objectId=0;
    	int linkId=0;
    	int tenderId=0;
    	try{
    		String docIdString=request.getParameter("txtDocId");
    		int userId=abcUtility.getSessionUserId(request);
    		if(userId != 0){
				objectId=StringUtils.hasLength(request.getParameter(HDOBJECTID)) ? Integer.parseInt(request.getParameter(HDOBJECTID)) : 0;
				linkId=StringUtils.hasLength(request.getParameter(HDLINKID)) ? Integer.parseInt(request.getParameter(HDLINKID)) : 0;
				tenderId=StringUtils.hasLength(request.getParameter(HDTENDERID)) ? Integer.parseInt(request.getParameter(HDTENDERID)) : 0;
				if(!StringUtils.hasLength(docIdString)|| objectId == 0){
					retVal=REDIRECTURL+objectId+"/"+tenderId+"/"+linkId+"/2"+encryptDecryptUtils.generateRedirect(URL+objectId+"/"+tenderId+"/"+linkId+"/2", request);
				}else{
					int clientId=abcUtility.getSessionClientId(request);
					int companyId=commonService.getCompanyId(userId,clientId);
					boolean isFinalBidSubmisionDone=false;
					List<Object[]> tenderIdList=commonService.getExecuteQuery("select tbltenderform.tblTender.tenderId,tbltenderform.formId from TblTenderForm tbltenderform where tbltenderform.formId="+tenderId, clientId);
			    	if(tenderIdList !=null && !tenderIdList.isEmpty() && tenderId !=0){
			    		isFinalBidSubmisionDone=tenderCommonService.isFinalBidSubmision((Integer)tenderIdList.get(0)[0], companyId);
			    		Date submissionEndDate=(Date)tenderCommonService.getTenderField((Integer)tenderIdList.get(0)[0],"submissionEndDate");
						if(objectId !=0 && !isFinalBidSubmisionDone && submissionEndDate != null &&submissionEndDate.after(commonService.getServerDateTime())){
							result=tenderBriefcaseService.unMapDocuments(docIdString);
						}
			    	}
					if(result){
						retVal=REDIRECTURL+objectId+"/"+tenderId+"/"+linkId+"/2"+encryptDecryptUtils.generateRedirect(URL+objectId+"/"+tenderId+"/"+linkId+"/2", request);
					}else{
						retVal=REDIRECTURL+objectId+"/"+tenderId+"/"+linkId+"/2"+encryptDecryptUtils.generateRedirect(URL+objectId+"/"+tenderId+"/"+linkId+"/2", request);
					}
				}
				redirectAttributes.addFlashAttribute(result ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), result ? "msg_success_unmapdocument" : CommonKeywords.ERROR_MSG_KEY.toString());
    		}
		}catch (Exception e) {
			retVal= exceptionHandlerService.writeLog(e);
		}finally {
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), unmapDocumentLinkId, postUnmappedDocument, objectId, 0);
		}
		return retVal;
    }
    
    /**
     * to get move to folder page
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/etender/bidder/movetofolder", method = RequestMethod.POST)
    public String moveToFolder(HttpServletRequest request, ModelMap modelMap) {
	try{
		String docIdString=request.getParameter("txtDocId");
		int objectId=StringUtils.hasLength(request.getParameter(HDOBJECTID)) ? Integer.parseInt(request.getParameter(HDOBJECTID)) : 0;
		int linkId=StringUtils.hasLength(request.getParameter(HDLINKID)) ? Integer.parseInt(request.getParameter(HDLINKID)) : 0;
		int tenderId=StringUtils.hasLength(request.getParameter(HDTENDERID)) ? Integer.parseInt(request.getParameter(HDTENDERID)) : 0;
		modelMap.addAttribute("docId",docIdString);
		modelMap.addAttribute(OBJECTID,objectId);
		modelMap.addAttribute(LINKID,linkId);
		modelMap.addAttribute("otherObjectId",tenderId);
		List<Object[]> data=tenderBriefcaseService.getFolderIdFromDocId(Integer.parseInt(docIdString));
		int folderId=!data.isEmpty() ? (Integer)data.get(0)[0] : 0;
		modelMap.addAttribute(FOLDERLIST, abcUtility.convert(tenderBriefcaseService.getBidderFolderForMoveToFolder(abcUtility.getSessionUserId(request),folderId)));
	}catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	}finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), moveToFolderLinkId, getMoveToFolder, 0, 0);
	}
		return "etender/bidder/MoveToFolder";
    }
    
    @RequestMapping(value = "/etender/bidder/addmovetofolder",method = RequestMethod.POST)
    public String addMoveToFolder(HttpServletRequest request,HttpSession session,RedirectAttributes redirectAttributes) {
    	int objectId=StringUtils.hasLength(request.getParameter(HDOBJECTID)) ? Integer.parseInt(request.getParameter(HDOBJECTID)) : 0;
        String docId = StringUtils.hasLength(request.getParameter("hdDocId")) ? request.getParameter("hdDocId") : "";
        int folderId=StringUtils.hasLength(request.getParameter("selFolderName")) ? Integer.parseInt(request.getParameter("selFolderName")) : 0;
        int linkId=StringUtils.hasLength(request.getParameter(HDLINKID)) ? Integer.parseInt(request.getParameter(HDLINKID)) : 0;
        int tenderId=StringUtils.hasLength(request.getParameter(HDTENDERID)) ? Integer.parseInt(request.getParameter(HDTENDERID)) : 0;
        String retVal="redirect:/sessionexpired";
        boolean result = false;
        try {
        	int userId=abcUtility.getSessionUserId(request);
        	if(userId != 0){
	        	if(!StringUtils.hasLength(docId) || folderId == 0){
	        		retVal=REDIRECTURL+objectId+"/"+tenderId+"/"+linkId+"/1"+encryptDecryptUtils.generateRedirect(URL+objectId+"/"+tenderId+"/"+linkId+"/1", request);
				}else{
					result = tenderBriefcaseService.moveToFolder(docId,folderId);
					if(result){
						retVal=REDIRECTURL+objectId+"/"+tenderId+"/"+linkId+"/1"+encryptDecryptUtils.generateRedirect(URL+objectId+"/"+tenderId+"/"+linkId+"/1", request);
					}else{
						retVal=REDIRECTURL+objectId+"/"+tenderId+"/"+linkId+"/1"+encryptDecryptUtils.generateRedirect(URL+objectId+"/"+tenderId+"/"+linkId+"/1", request);
					}
				}
	        	redirectAttributes.addFlashAttribute(result ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), result ? "msg_success_movefolder" : CommonKeywords.ERROR_MSG_KEY.toString());
        	}
        } catch (Exception e) {
        	retVal= exceptionHandlerService.writeLog(e);
        }finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), moveToFolderLinkId, postMoveToFolder, objectId, objectId);
        }
        return retVal;
    }
    
    @RequestMapping(value = "/ajax/getbriefcaseuploadeddocs",method = RequestMethod.POST)
    public void getUploadedDocs(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
        int objectId=0;
        int linkId=0;
        try {
        	if(session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	        	objectId=StringUtils.hasLength(request.getParameter(OBJECTID)) ? Integer.parseInt(request.getParameter(OBJECTID)) : 0; 
	        	linkId=StringUtils.hasLength(request.getParameter(LINKID)) ? Integer.parseInt(request.getParameter(LINKID)) : 0;
	        	TblLink tblLink=commonService.getTblLink(linkId);
        		List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(tblLink.getTblEvent().getEventId(), abcUtility.getSessionClientId(request));
	        	int tabId=StringUtils.hasLength(request.getParameter("txtTabId")) ? Integer.parseInt(request.getParameter("txtTabId")) : 0;
	        	int folderId=StringUtils.hasLength(request.getParameter("txtSearchFolder")) ? Integer.parseInt(request.getParameter("txtSearchFolder")) : 0;
	        	int formId=StringUtils.hasLength(request.getParameter("formId")) ? Integer.parseInt(request.getParameter("formId")) : 0;
	        	String docDesc=StringUtils.hasLength(request.getParameter("txtDocDescSearch")) ? request.getParameter("txtDocDescSearch") : null;
	            response.getWriter().write(getHtml(tenderBriefcaseService.getBidderDocuments(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request),tabId,folderId,docDesc,linkId,objectId,!lstDocUploadConf.isEmpty() ?  lstDocUploadConf.get(0).getIsEncryptionReq() : 1),request,objectId,1,tabId,formId));
        	}else{
        		response.getWriter().write("sessionexpired");
        	}
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, ajaxGetuploadedDocsForBriefcase, objectId, 0);
        }
    }
    
    @RequestMapping(value = "/ajax/getbriefcasemapeddocs",method = RequestMethod.POST)
    public void getMapedDocs(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
        List<Object[]> lstDocumentDetails = null;
        int objectId=0;
        int linkId=0;
        try {
        	if(session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	        	objectId=StringUtils.hasLength(request.getParameter(OBJECTID)) ? Integer.parseInt(request.getParameter(OBJECTID)) : 0; 
	        	linkId=StringUtils.hasLength(request.getParameter(LINKID)) ? Integer.parseInt(request.getParameter(LINKID)) : 0;
	        	int tenderId=StringUtils.hasLength(request.getParameter(TENDERID)) ? Integer.parseInt(request.getParameter(TENDERID)) : 0;
	            lstDocumentDetails=tenderBriefcaseService.getMapedDocuments(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request),objectId,linkId);
	            
	            long mandatoryDocs = tenderBriefcaseService.getMandatoryDocCount(createManDocLinkId, tenderId);
	            long uploadedDocs = tenderBriefcaseService.getUploadedMandatoryDocs(linkId, tenderId);
	            long remainingDocs = mandatoryDocs - uploadedDocs;
	            List<Object[]> mandatoryDocList=tenderBriefcaseService.getMandatoryDocument(createManDocLinkId, tenderId);
	            List<Object[]> uploadedDocList=tenderBriefcaseService.getUploadedDocs(linkId, objectId);
	            String generatedHtml=getHtml(lstDocumentDetails,request,objectId,0,0,tenderId);
	            StringBuilder pendingMandatoryHtml=new StringBuilder();
	            pendingMandatoryHtml.append("||~||");
                    if(remainingDocs>0){
                        pendingMandatoryHtml.append(" <tr> ");
                        pendingMandatoryHtml.append(" <td class=\"a-left v-a-middle black\" width='27%'>").append(messageSource.getMessage("label_briefcase_mandatorydocsummary", null, LocaleContextHolder.getLocale())).append("</td>");
                        pendingMandatoryHtml.append(" <td class=\"a-left line-height\"> ");
                        for(Object[] mandatoryDocData : mandatoryDocList){
                            boolean isUploaded=false;
                            for(Object[] uploadedDocData : uploadedDocList){
                                    if(Integer.parseInt(mandatoryDocData[0].toString()) == Integer.parseInt(uploadedDocData[0].toString())){
                                            //pendingMandatoryHtml.append(uploadedDocData[1]).append(" ,");
                                            isUploaded=true;
                                    }
                            }
                            if(!isUploaded){
                                    pendingMandatoryHtml.append(mandatoryDocData[1]).append("<br />");
                            }
                        }
                        pendingMandatoryHtml.append(" </td></tr>");
                    }
	            response.getWriter().write(generatedHtml + pendingMandatoryHtml.toString());
        	}else{
        		response.getWriter().write("sessionexpired");
        	}
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, ajaxGetBriefcaseMapedDocs, objectId, 0);
        }
    }
    
    /**
     * to change the status of the document and remove physical file (if status is rejected(delete))
     */
    @RequestMapping(value = "/ajax/deletebriefcasefile",method = RequestMethod.POST)
    public void removeUploadedFile(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
    	int objectId=0;
        String docId = StringUtils.hasLength(request.getParameter(DOC_ID)) ? request.getParameter(DOC_ID) : "";
        int cStatusDoc=0;
        cStatusDoc = StringUtils.hasLength(request.getParameter(CSTATUS_DOC)) ? Integer.parseInt(request.getParameter(CSTATUS_DOC)) : 0;
        objectId=StringUtils.hasLength(request.getParameter(OBJECTID)) ? Integer.parseInt(request.getParameter(OBJECTID)) : 0;
        boolean renameFlag = false;
        try {
        	if(session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	    		List<Object[]> tblBidderDocument=tenderBriefcaseService.getBidderDocDetails(docId);
	    		for(int i=0;i<tblBidderDocument.size();i++){
		    		String filePath=docUploadPath+tblBidderDocument.get(i)[1].toString();
		    		//filePath=filePath.replace("\\", "\\\\");
		    		//filePath += "\\"+tblBidderDocument.get(i)[0].toString();
		    		renameFlag = renameFile(filePath,tblBidderDocument.get(i)[0].toString());
	    		}
	    		if (renameFlag) {
	    			renameFlag = tenderBriefcaseService.updateBidderDocStatus(docId,cStatusDoc);
	            }
	          response.getWriter().write(renameFlag + "");
        	}else{
        		response.getWriter().write("sessionexpired");
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deleteDocumentLinkId, ajaxDeleteBriefcaseDocument, objectId, objectId);
        }
    }
    
    @RequestMapping(value = "/ajax/archivebriefcasefile",method = RequestMethod.POST)
    public void archiveUploadedFile(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
    	int objectId=0;
        String docId = StringUtils.hasLength(request.getParameter(DOC_ID)) ? request.getParameter(DOC_ID) : "";
        objectId=StringUtils.hasLength(request.getParameter(OBJECTID)) ? Integer.parseInt(request.getParameter(OBJECTID)) : 0;
        boolean archiveFlag = false;
        try {
        	if(session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	        	archiveFlag = tenderBriefcaseService.archiveDocuments(docId);
	            response.getWriter().write(archiveFlag + "");
        	}else{
        		response.getWriter().write("sessionexpired");
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), moveToArchiveLinkId, ajaxArchivedBriefcaseDocument, objectId, objectId);
        }
    }
    
    /**
     * to download briefcase documents 
     * @param docId
     * @param objectId
     * @param request
     * @param response
     */
    @RequestMapping(value = "/ajax/downloadbriefcasefile/{docId}/{objectId}/{enc}")
    public void downloadBriefcaseFile(@PathVariable(DOC_ID) int docId,@PathVariable(OBJECTID) int objectId,HttpServletRequest request,HttpServletResponse response) {
        ServletOutputStream outputStream = null;
        InputStream fis=null;
        try {
        	String filePath=null;
        	String fileName=null;
    		List<Object[]> tblBidderDocument=tenderBriefcaseService.getBidderDocDetails(docId);
    		int isEncryptionReq=0;
    		if(!tblBidderDocument.isEmpty()){
	    		filePath=docUploadPath+tblBidderDocument.get(0)[1].toString();
	    		filePath=filePath.replace("\\", "\\\\");
	    		filePath += "\\"+tblBidderDocument.get(0)[0].toString();
	    		fileName=tblBidderDocument.get(0)[0].toString();
	    		isEncryptionReq=(Integer)tblBidderDocument.get(0)[2];
    		}
    		//System.out.println("File Path="+filePath);
            File file = null;
            file = new File(filePath);
            file = abcUtility.CheckDirExist(file);
            if(file.exists()){
	            fis = new FileInputStream(file);
	            byte[] buf = new byte[(int) file.length()];
	            int offset = 0;
	            int numRead = 0;
	            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
	                offset += numRead;
	            }
	            if(isEncryptionReq == 1){
	            	buf = fileEncryptDecryptUtil.fileDecryptUtil(buf);
	            }
	            
	            response.setContentType("application/octet-stream");
	            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
	            outputStream = response.getOutputStream();
	            outputStream.write(buf);
	            outputStream.flush();
	            outputStream.close();
	        }
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }finally{
        	if(fis != null){
        		try {
					fis.close();
				} catch (IOException e) {
					//e.printStackTrace();
				}
        	}
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), downloadDocLinkId, ajaxDownloadBriefcaseDocument, objectId, docId);
        }
    }
    
    /**
     * to delete the file physically
     * @param filePath
     * @return boolean
     */
    private boolean renameFile(String filePath,String oldFileName) {
        boolean flg = false;
        try {
            File f = new File(filePath+"\\"+oldFileName);
            File f2=new File(filePath+"\\"+oldFileName.replace(".", "_deleted"+commonService.getServerDateTime().toString().replace(".","_").replace(":","_")+"."));
            f = abcUtility.CheckDirExist(f);
            if(f.exists()){
            	flg=f.renameTo(f2);
            }
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
        return flg;
    }
    
    /**
     * to check the file size   
     * @param fielSize
     * @param maxFileSize
     * @return boolean
     */
    private boolean checkFileSize(long fielSize, long maxFileSize) {
        boolean chextn = false;
        if (maxFileSize > fielSize) {
            chextn = true;
        } else {
            chextn = false;
        }
        return chextn;
    }
    
    /**
     * to check file extention
     * @param fileName
     * @param allowExtensions
     * @return boolean
     */
    private boolean checkFileExn(String fileName, String allowExtensions) {
        boolean chextn = false;
        int j = fileName.lastIndexOf('.');
        String lst = fileName.substring(j + 1);
        String str = allowExtensions;
        String[] str1 = str.split(",");
        for (int i = 0; i < str1.length; i++) {
            if (str1[i].trim().equalsIgnoreCase(lst)) {
                chextn = true;
            }
        }
        return chextn;
    }
    
    /**
     * to check the valid type 
     * @param file
     * @return boolean
     * @throws FileNotFoundException
     * @throws IOException
     */
    private boolean isValidContentType(File file) throws FileNotFoundException, IOException {
        boolean flag = false;
        int count = 0;
        FileInputStream fis = new FileInputStream(file);
        int j = file.getName().lastIndexOf('.');
        String fileExt = file.getName().substring(j + 1);
        //System.out.println("fileExt :: " + fileExt);
        if ("pdf".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_PDF.length; ++i) {
                if (fis.read() != FILESIGNATURE_PDF[i]) {
                    //System.out.println("not a valid pdf file");
                    count++;
                }
            }
        } else if ("zip".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_ZIP.length; ++i) {
                if (fis.read() != FILESIGNATURE_ZIP[i]) {
                    //System.out.println("not a valid zip file");
                    count++;
                }
            }
        } else if ("rar".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_RAR.length; ++i) {
                if (fis.read() != FILESIGNATURE_RAR[i]) {
                    count++;
                }
            }
        }else if ("exe".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_EXE.length; ++i) {
                if (fis.read() != FILESIGNATURE_EXE[i]) {
                    count++;
                }
            }
        }/*else if ("bmp".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_BMP.length; ++i) {
                if (fis.read() != FILESIGNATURE_BMP[i]) {
                    count++;
                }
            }
        }*/else if ("DOCX".equalsIgnoreCase(fileExt) || "XLSX".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_DOCX_XLSX.length; ++i) {
                if (fis.read() != FILESIGNATURE_DOCX_XLSX[i]) {
                    count++;
                }
            }
        }else if ("doc".equalsIgnoreCase(fileExt) || "ppt".equalsIgnoreCase(fileExt) || "xls".equalsIgnoreCase(fileExt) || "pps".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_DOC_PPT_XLS_PPS.length; ++i) {
                if (fis.read() != FILESIGNATURE_DOC_PPT_XLS_PPS[i]) {
                    count++;
                }
            }
        }/*else if ("PNG".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_PNG.length; ++i) {
                if (fis.read() != FILESIGNATURE_PNG[i]) {
                    count++;
                }
            }
        }*/
        if (count > 0) {
            flag = false;
        } else {
            flag = true;
        }
        fis.close();
        return flag;
    }
    
    /**
     * create directory if it does not exists
     * @param drive
     * @param rpath
     * @return boolean
        String[] tpath = rpath.split("\\\\");
     */
    private boolean isDirExists(String drive, String rpath) {
        boolean flag = false;
        String[] tpath = rpath.split("\\\\");
        StringBuilder path = new StringBuilder();
        path.append(drive);

        for (int i = 0; i < tpath.length; i++) {
            path.append("\\").append(tpath[i]);

            File f = new File(path.toString());

            if (!f.isDirectory()) {
                f.mkdirs();
            }
        }
        return flag;
    }
    /**
     * 
     * @param lstDocumentDetails
     * @param request
     * @param objectId
     * @param isUploadedDoc == 0 means from mapped docs and 1 for uploaded docs  
     * @return
     */
    private String getHtml(List<Object[]> lstDocumentDetails,HttpServletRequest request,int objectId,int isUploadedDoc,int tabId,int formId) throws Exception{
    	StringBuilder strDocList=new StringBuilder();
        //List<Object[]> lstManDoc = tenderBriefcaseService.getMandatoryDoc(formId, createManDocLinkId);
        List<Object[]> lstManDoc = tenderBriefcaseService.getDocumentCheckList(formId, createManDocLinkId);
        int mandatoryDocSize = formId!=0 && lstManDoc!=null ? lstManDoc.size() : 0;
    	strDocList.append("<tr class='gradi'>");
    	if(objectId !=0){
    		strDocList.append("<th width='8%'>").append(messageSource.getMessage("col_select", null, LocaleContextHolder.getLocale())).append(END_TH);
    	}
        strDocList.append("<th class='a-left' width='8%'>").append(messageSource.getMessage("col_srno", null, LocaleContextHolder.getLocale())).append(END_TH);
        strDocList.append("<th class='a-left' width='22%'>").append(messageSource.getMessage("fields_tender_docname", null, LocaleContextHolder.getLocale())).append(END_TH);
        strDocList.append("<th class='a-left' width='24%'>").append(messageSource.getMessage("fields_docbrief", null, LocaleContextHolder.getLocale())).append(END_TH);
        if(mandatoryDocSize>0 && isUploadedDoc!=1){
            strDocList.append("<th class='a-left'  width='25%'>").append(messageSource.getMessage("fields_mandatorydocs", null, LocaleContextHolder.getLocale())).append(END_TH);
        }
        if(tabId==1){
            strDocList.append("<th class='a-left'  width='15%'>").append(messageSource.getMessage("field_foldername", null, LocaleContextHolder.getLocale())).append(END_TH);
            strDocList.append("<th class='a-left'  width='17%'>").append(messageSource.getMessage("col_action", null, LocaleContextHolder.getLocale())).append(END_TH);
        }else{
            strDocList.append("<th class='a-left'  width='13%'>").append(messageSource.getMessage("col_action", null, LocaleContextHolder.getLocale())).append(END_TH);
        }
        strDocList.append("</tr>");
            if (lstDocumentDetails != null && !lstDocumentDetails.isEmpty()) {
            	int cnt=0;
                for (int i=0;i<lstDocumentDetails.size();i++) {
                	boolean isSkipRow=false;
                	if(isUploadedDoc == 1 && (Long)lstDocumentDetails.get(i)[8] != 0){
                		isSkipRow=true;
                	}
                	if(!isSkipRow){
                		cnt=cnt+1;
	                    strDocList.append("     <tr id='fli_"+lstDocumentDetails.get(i)[0]+"'>");
	                    if(objectId != 0){
		                    strDocList.append("         <td class='a-center'>");
		                    if(isUploadedDoc == 1 && (Long)lstDocumentDetails.get(i)[8] == 0){
		                    	strDocList.append("         <input type='checkbox' name='isSelect' id='isSelect_").append(i).append("' value='").append(lstDocumentDetails.get(i)[0]).append("'>");
		                    }else if(isUploadedDoc !=1){
		                    	strDocList.append("         <input type='checkbox' name='isSelect' id='isSelect_").append(i).append("' value='").append(lstDocumentDetails.get(i)[0]).append("'>");
		                    }
		                    strDocList.append(END_TD);
	                    }
	                    strDocList.append("<td class='a-center'>");
	                    strDocList.append(cnt);
	                    strDocList.append(END_TD);
	                    strDocList.append("<td class='word-break line-height'>");
	                    strDocList.append(lstDocumentDetails.get(i)[5]);
	                    strDocList.append(END_TD);
	                    strDocList.append("<td class='word-break line-height'>");
	                    strDocList.append(lstDocumentDetails.get(i)[6]);
	                    strDocList.append(END_TD);
                            if(mandatoryDocSize>0 && isUploadedDoc!=1){
                                strDocList.append("<td class='line-height'>");
                                strDocList.append(lstDocumentDetails.get(i)[4] != null ? lstDocumentDetails.get(i)[4].toString() : "-");
                                strDocList.append(END_TD);
                            }
                            if(tabId==1){
                                strDocList.append("<td class='line-height a-left'>");
                                strDocList.append(lstDocumentDetails.get(i)[4] != null ? lstDocumentDetails.get(i)[4].toString() : "-");
                                strDocList.append(END_TD);
                            }
                            strDocList.append("<td class='line-height v-a-middle a-left'>");
			            
	                    if(objectId !=0 && isUploadedDoc == 1){
                                if(mandatoryDocSize>0){
                                    strDocList.append("<a class='doc-map-icn' title='").append(messageSource.getMessage("label_map", null, LocaleContextHolder.getLocale())).append("' href='javascript:void(0);' onclick=\"getMandatoryDoc('");
                                }else{
                                    strDocList.append("<a class='doc-map-icn' title='").append(messageSource.getMessage("label_map", null, LocaleContextHolder.getLocale())).append("' href='javascript:void(0);' onclick=\"mapDocuments('");
                                }
                                if(isUploadedDoc == 0){
                                    strDocList.append(lstDocumentDetails.get(i)[7]);
                                }else{
                                    strDocList.append(lstDocumentDetails.get(i)[0]);
                                }
                                strDocList.append("');\">").append(END_A).append(" ");
	                    }
	                    
	                    if(isUploadedDoc == 0){
		                    strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadbriefcasefile/");
		                    strDocList.append(lstDocumentDetails.get(i)[7]).append("/").append(objectId);
		                    strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadbriefcasefile/"+lstDocumentDetails.get(i)[7]+"/"+objectId, request));
		                    strDocList.append(" class='download-icn' title='").append(messageSource.getMessage("lbl_download", null, LocaleContextHolder.getLocale())).append("'> ").append(END_A).append(" ");
	                    }else{
	                    	strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadbriefcasefile/");
		                    strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
		                    strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadbriefcasefile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
		                    strDocList.append(" class='download-icn'  title='").append(messageSource.getMessage("lbl_download", null, LocaleContextHolder.getLocale())).append("'> ").append(END_A).append(" ");
	                    }
	                    strDocList.append("<a class='move-folder-icn' title='").append(messageSource.getMessage("link_movetofolder", null, LocaleContextHolder.getLocale())).append("' href='#' onclick=\"moveToFolder('");
                            if(isUploadedDoc == 0){
                                strDocList.append(lstDocumentDetails.get(i)[7]);
                            }else{
                                strDocList.append(lstDocumentDetails.get(i)[0]);
                            }
	                    strDocList.append("');\"> ").append(END_A).append(" ");
	                    if(tabId != 2){
				            strDocList.append("<a class='move-archive-icn' title='").append(messageSource.getMessage("link_movetoarchive", null, LocaleContextHolder.getLocale())).append("' href='#' onclick=\"archiveFile('");
				            if(isUploadedDoc == 0){
				            	strDocList.append(lstDocumentDetails.get(i)[7]);
				            }else{
				            	strDocList.append(lstDocumentDetails.get(i)[0]);
				            }
		                    strDocList.append("');\"> ").append(END_A).append(" ");
	                    }
	                    if(isUploadedDoc == 1 && (Long)lstDocumentDetails.get(i)[7] == 0){
					        strDocList.append("<a class='delete-icn' title='").append(messageSource.getMessage("link_tender_deleteform", null, LocaleContextHolder.getLocale())).append("' href='#' onclick=\"removeFile('");
		                    strDocList.append(lstDocumentDetails.get(i)[0]);
		                    strDocList.append("','"+(bidderDocStatusReject)+"');\"> ").append(END_A);
			            }
	                    strDocList.append(END_TD);
	                    strDocList.append("</tr>");
                        }
                }//end of for loop
                if(cnt==0){
                    strDocList.append(" <tr id='tr_tender_biddermap_empty'> <td colspan='8'>").append(messageSource.getMessage("msg_tender_biddermap_empty", null, LocaleContextHolder.getLocale())).append("</td></tr>");
                }
                }else{
            		strDocList.append(" <tr id='tr_tender_biddermap_empty'> <td colspan='8'>").append(messageSource.getMessage("msg_tender_biddermap_empty", null, LocaleContextHolder.getLocale())).append("</td></tr>");
            	}
            return strDocList.toString();
    }
}
