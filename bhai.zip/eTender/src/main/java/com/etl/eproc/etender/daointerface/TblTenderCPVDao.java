package com.etl.eproc.etender.daointerface;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderCPV;
import java.util.List;

public interface TblTenderCPVDao  {

    public void addTblTenderCPV(TblTenderCPV tblTenderCPV);

    public void deleteTblTenderCPV(TblTenderCPV tblTenderCPV);

    public void updateTblTenderCPV(TblTenderCPV tblTenderCPV);

    public List<TblTenderCPV> getAllTblTenderCPV();

    public List<TblTenderCPV> findTblTenderCPV(Object... values) throws Exception;

    public List<TblTenderCPV> findByCountTblTenderCPV(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderCPVCount();

    public void saveUpdateAllTblTenderCPV(List<TblTenderCPV> tblTenderCPVs);
}