package com.etl.eproc.etender.daoimpl;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblItemSelectionDao;
import com.etl.eproc.etender.model.TblItemSelection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;

import java.util.Collection;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblItemSelectionImpl extends AbcAbstractClass<TblItemSelection> implements TblItemSelectionDao {

   

    @Override
    public void addTblItemSelection(TblItemSelection tblItemSelection){
        super.addEntity(tblItemSelection);
    }

    @Override
    public void deleteTblItemSelection(TblItemSelection tblItemSelection) {
        super.deleteEntity(tblItemSelection);
    }

    @Override
    public void updateTblItemSelection(TblItemSelection tblItemSelection) {
        super.updateEntity(tblItemSelection);
    }

    @Override
    public List<TblItemSelection> getAllTblItemSelection() {
        return super.getAllEntity();
    }

    @Override
    public List<TblItemSelection> findTblItemSelection(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblItemSelectionCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblItemSelection> findByCountTblItemSelection(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblItemSelection(List<TblItemSelection> tblItemSelections){
        super.updateAll(tblItemSelections);
    }

	/*@Override
	public void deleteAll(Collection<TblItemSelection> collection) {
		// TODO Auto-generated method stub
		
	}*/
}
