package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblSmboq;
import com.etl.eproc.etender.daointerface.TblSmboqDao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblSmboqImpl extends AbcAbstractClass<TblSmboq> implements TblSmboqDao {

   

    @Override
    public void addTblsmboq(TblSmboq tblsmboq){
        super.addEntity(tblsmboq);
    }

    @Override
    public void deleteTblsmboq(TblSmboq tblsmboq) {
        super.deleteEntity(tblsmboq);
    }

    @Override
    public void updateTblsmboq(TblSmboq tblsmboq) {
        super.updateEntity(tblsmboq);
    }

    @Override
    public List<TblSmboq> getAllTblsmboq() {
        return super.getAllEntity();
    }

    @Override
    public List<TblSmboq> findTblsmboq(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblsmboqCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblSmboq> findByCountTblsmboq(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblsmboq(List<TblSmboq> tblsmboqs){
        super.updateAll(tblsmboqs);
    }
}
