package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblTenderBidRegression;
import com.etl.eproc.etender.daointerface.TblTenderBidRegressionDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderBidRegressionImpl extends AbcAbstractClass<TblTenderBidRegression> implements TblTenderBidRegressionDao {

   
    @Override
    public void addTblTenderBidRegression(TblTenderBidRegression tblTenderBidRegression){
        super.addEntity(tblTenderBidRegression);
    }

    @Override
    public void deleteTblTenderBidRegression(TblTenderBidRegression tblTenderBidRegression) {
        super.deleteEntity(tblTenderBidRegression);
    }

    @Override
    public void updateTblTenderBidRegression(TblTenderBidRegression tblTenderBidRegression) {
        super.updateEntity(tblTenderBidRegression);
    }

    @Override
    public List<TblTenderBidRegression> getAllTblTenderBidRegression() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderBidRegression> findTblTenderBidRegression(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderBidRegressionCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderBidRegression> findByCountTblTenderBidRegression(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderBidRegression(List<TblTenderBidRegression> tblTenderBidRegressions){
        super.updateAll(tblTenderBidRegressions);
    }
}
