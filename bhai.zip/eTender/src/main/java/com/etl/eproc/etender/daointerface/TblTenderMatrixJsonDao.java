/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblTenderMatrixJson;
import java.util.List;

/**
 *
 * @author taher.tinwala
 */
public interface TblTenderMatrixJsonDao  {

    public void addTblTenderMatrixJson(TblTenderMatrixJson tblTenderMatrixJson);

    public void deleteTblTenderMatrixJson(TblTenderMatrixJson tblTenderMatrixJson);

    public void updateTblTenderMatrixJson(TblTenderMatrixJson tblTenderMatrixJson);

    public List<TblTenderMatrixJson> getAllTblTenderMatrixJson();

    public List<TblTenderMatrixJson> findTblTenderMatrixJson(Object... values) throws Exception;

    public List<TblTenderMatrixJson> findByCountTblTenderMatrixJson(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderMatrixJsonCount();

    public void saveUpdateAllTblTenderMatrixJson(List<TblTenderMatrixJson> tblTenderMatrixJsons);
}
