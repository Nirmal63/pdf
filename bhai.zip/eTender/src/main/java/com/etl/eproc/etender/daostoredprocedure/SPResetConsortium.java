package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author dipal
 */
@Component
public class SPResetConsortium extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderbid.P_ResetConsortium";

    public SPResetConsortium() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_ConsortiumId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_IPAddress", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_SessionUserId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_ClientId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_MSGReset", Types.NVARCHAR));
        
    }


    public ArrayList<LinkedHashMap<String, Object>> executeProcedure(int tenderId, int consortiumId, String  ipadd,  int sessionUserId, int clientId,String resetMsg) throws Exception
    {
        Map inParams = new HashMap();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_ConsortiumId", consortiumId);
        inParams.put("@V_IPAddress", ipadd);
        inParams.put("@V_SessionUserId", sessionUserId);
        inParams.put("@V_ClientId", clientId);
        inParams.put("@V_MSGReset", resetMsg);
        this.compile();
        return (ArrayList<LinkedHashMap<String, Object>>) execute(inParams).get("#result-set-1");       
    }
}


