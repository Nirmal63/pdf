/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblDynReportColumnDao;
import com.etl.eproc.etender.model.TblDynReportColumn;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author shreyansh.shah
 */
@Repository @Transactional
public class TblDynReportColumnImpl extends AbcAbstractClass<TblDynReportColumn> implements TblDynReportColumnDao {

  
    @Override
    public void addTblDynReportColumn(TblDynReportColumn tblDynReportColumn){
        super.addEntity(tblDynReportColumn);
    }

    @Override
    public void deleteTblDynReportColumn(TblDynReportColumn tblDynReportColumn) {
        super.deleteEntity(tblDynReportColumn);
    }

    @Override
    public void updateTblDynReportColumn(TblDynReportColumn tblDynReportColumn) {
        super.updateEntity(tblDynReportColumn);
    }

    @Override
    public List<TblDynReportColumn> getAllTblDynReportColumn() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynReportColumn> findTblDynReportColumn(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynReportColumnCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynReportColumn> findByCountTblDynReportColumn(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDynReportColumn(List<TblDynReportColumn> tblDynReportColumns){
        super.updateAll(tblDynReportColumns);
    }
}
