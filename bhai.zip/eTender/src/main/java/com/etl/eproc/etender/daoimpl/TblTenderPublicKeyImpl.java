package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderPublicKeyDao;
import com.etl.eproc.etender.model.TblTenderPublicKey;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author bhavin.patel
 */
@Repository @Transactional
public class TblTenderPublicKeyImpl extends AbcAbstractClass<TblTenderPublicKey> implements TblTenderPublicKeyDao {

   
    @Override
    public void addTblTenderPublicKey(TblTenderPublicKey tblTenderPublicKey){
        super.addEntity(tblTenderPublicKey);
    }

    @Override
    public void deleteTblTenderPublicKey(TblTenderPublicKey tblTenderPublicKey) {
        super.deleteEntity(tblTenderPublicKey);
    }

    @Override
    public void updateTblTenderPublicKey(TblTenderPublicKey tblTenderPublicKey) {
        super.updateEntity(tblTenderPublicKey);
    }

    @Override
    public List<TblTenderPublicKey> getAllTblTenderPublicKey() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderPublicKey> findTblTenderPublicKey(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderPublicKeyCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderPublicKey> findByCountTblTenderPublicKey(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderPublicKey(List<TblTenderPublicKey> tblTenderPublicKeys){
        super.updateAll(tblTenderPublicKeys);
    }
}
