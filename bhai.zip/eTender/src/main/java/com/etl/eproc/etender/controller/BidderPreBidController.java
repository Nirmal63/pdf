package com.etl.eproc.etender.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblQuestion;
import com.etl.eproc.common.model.TblSubModule;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.PrebidService;
import com.etl.eproc.etender.services.TenderCommonService;

/**
 *
 * @author Darshan Shah
 */
@Controller
@RequestMapping("/etender/bidder")
public class BidderPreBidController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private PrebidService prebidService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private CommonService commonService;
    @Value("#{etenderAuditTrailProperties['allprebidqusans']}")
    private String allPrebidQusAns;
    @Value("#{etenderAuditTrailProperties['getprebidpostquery']}")
    private String getPrebidpostquery;
    @Value("#{etenderAuditTrailProperties['postprebidquestion']}")
    private String getPrebidQuestion;

    @Value("#{tenderlinkProperties['bidder_post_question']?:369}")
    private int bidderPostQuestionLinkID;
    @Value("#{tenderlinkProperties['bidder_submit_question']?:370}")
    private int bidderSubmitQuestionLinkID;
    @Value("#{tenderlinkProperties['bidder_view_my_questions']?:371}")
    private int bidderViewMyQuestionLinkID;
    @Value("#{tenderlinkProperties['bidder_view_all_questions']?:372}")
    private int bidderViewAllQuestionLinkID;
    @Value("#{etenderProperties['prebid_submoduleId']?:31}")
    private int prebidSubModuleId;

    private static final int PREBID_MODULE_TYPE = 3;
    //private static final int PRE_BID_SUBMODULE = 31;
    private static final int QUESTION_POSTED = 0;
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    private static final String PREBID_OBJ="preBidObj";
    private static final String CURRENT_DATE="currentDate";
    private static final String QUESTIONS="questions";
    private static final String QUESTIONS_LIST="questionList";
    private static final String TENDER_ID="tenderId";
    private static final String SHOW_POST_QUERY="showPostQuery";
    private static final String VIEW_TYPE="viewType";
    private static final String VIEW_ALL_QUESTIONS="View all questions";
    /**
     * For join meeting
     *
     * @param tenderId
     * @param modelMap
     * @param request
     * @return to join meeting page
     */
    @RequestMapping(value = "/prebidmeeting/{tenderId}/{enc}", method = RequestMethod.GET)
    public String joinPrebidMeeting(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request) {
	try {
//	    System.out.println("In joinPrebidMeeting " + tenderId);
	    if (abcUtility.getSessionUserId(request) != 0) {
		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
		List<Object[]> lstPrebidObjArray = tenderCommonService.getTenderPrebidDetailByTenderId(tenderId);
		modelMap.addAttribute(PREBID_OBJ, lstPrebidObjArray);
		modelMap.addAttribute(CURRENT_DATE, commonService.getServerDateTime());
		modelMap.addAttribute(QUESTIONS, prebidService.getQuestionList().size());
		modelMap.addAttribute(QUESTIONS_LIST, prebidService.getQuestionList());
		modelMap.addAttribute(TENDER_ID, tenderId);
		modelMap.addAttribute(SHOW_POST_QUERY, "true");
		modelMap.addAttribute(VIEW_TYPE, VIEW_ALL_QUESTIONS);
	    }
	} catch (Exception e) {
	    exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidderPostQuestionLinkID, getPrebidpostquery, tenderId, 0);
	}
	return "etender/bidder/PreBidMeeting";
    }

    /**
     * For posting Question/Query
     *
     * @param modelMap
     * @param request
     * @param redirectAttributes
     * @return to Pre-bid meeting
     */
    @RequestMapping(value = "/postPrebidQuery", method = RequestMethod.POST)
    public String postBidQuery(ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) {
	int tenderId = Integer.parseInt(request.getParameter("hdTenderId").toString());
	String strQuery = (request.getParameter("rtfQuestion") != null ? request.getParameter("rtfQuestion").toString() : "");
	boolean isSuccess = false;
	String strErrorMessage = CommonKeywords.ERROR_MSG_KEY.toString();
	try {
//	    System.out.println("In postBidQuery Query Text is " + strQuery);
	    if (abcUtility.getSessionUserId(request) != 0) {
		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
		List<Object[]> lstPrebidObjArray = tenderCommonService.getTenderPrebidDetailByTenderId(tenderId);
		Object[] preBidObj = lstPrebidObjArray.get(0);
//		System.out.println("preBidObj "+preBidObj.length + " preBidObj[3] " +preBidObj[3]);

		if(lstPrebidObjArray.isEmpty() || commonService.getServerDateTime().after((Date)preBidObj[3])){
		    strErrorMessage = "msg_prebid_post_query_timeover";
		    modelMap.addAttribute(SHOW_POST_QUERY, "false");
		} else {
		    if (!strQuery.trim().equals("")) {
			TblQuestion tblQuestion = new TblQuestion();
			tblQuestion.setModuleType(PREBID_MODULE_TYPE);
			tblQuestion.setParentQuestionId(0);
			tblQuestion.setTblSubModule(new TblSubModule(prebidSubModuleId));
			tblQuestion.setCstatus(QUESTION_POSTED);
			tblQuestion.setQuestionText(strQuery);
			tblQuestion.setObjectId(tenderId);
			tblQuestion.setTblUserLogin(new TblUserLogin(abcUtility.getSessionUserId(request)));
			tblQuestion.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
			tblQuestion.setUserTypeId(abcUtility.getSessionUserTypeId(request));

			isSuccess = prebidService.addTblQuestion(tblQuestion);
		    }
		    modelMap.addAttribute(SHOW_POST_QUERY, "true");
		}
		List<Object[]> listArrObj = prebidService.getQuestionAnswers(abcUtility.getSessionUserId(request), abcUtility.getSessionUserTypeId(request), tenderId, true);
		modelMap.addAttribute(PREBID_OBJ, lstPrebidObjArray);
		modelMap.addAttribute(CURRENT_DATE, commonService.getServerDateTime());
		modelMap.addAttribute(QUESTIONS, listArrObj.size());
		modelMap.addAttribute("qusAnsList", listArrObj);
		modelMap.addAttribute(TENDER_ID, tenderId);
	    }
	    modelMap.addAttribute(VIEW_TYPE, VIEW_ALL_QUESTIONS);
	} catch (Exception e) {
	    exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidderSubmitQuestionLinkID, getPrebidQuestion, tenderId, 0);
	}
	redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_prebid_post_question" : strErrorMessage);
	return "redirect:/etender/bidder/prebidmeeting/" + tenderId + encryptDecryptUtils.generateRedirect("etender/bidder/prebidmeeting/" + tenderId, request);
    }

    /**
     * For View questions
     *
     * @param tenderId
     * @param viewType
     * @param modelMap
     * @param request
     * @return ajaxView
     */
    @RequestMapping(value = "/viewAjaxQueries", method = RequestMethod.POST)
    public String viewAjaxQuestion(@RequestParam("hdTenderId") int tenderId, @RequestParam("hdViewType") int viewType, ModelMap modelMap, HttpServletRequest request) {
	String strReturn = REDIRECT_SESSION_EXPIRED;
	int linkId = bidderViewAllQuestionLinkID; // View All Question
	try {
	    if (abcUtility.getSessionUserId(request) != 0) {
		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
		List<Object[]> listArrObj = prebidService.getQuestionAnswers(abcUtility.getSessionUserId(request), abcUtility.getSessionUserTypeId(request), tenderId, (viewType == 1));
		List<Object[]> lstPrebidObjArray = tenderCommonService.getTenderPrebidDetailByTenderId(tenderId);
		modelMap.addAttribute(PREBID_OBJ, lstPrebidObjArray);
		modelMap.addAttribute(CURRENT_DATE, commonService.getServerDateTime());
		modelMap.addAttribute("totalRec", listArrObj.size());
		modelMap.addAttribute("QusAnsList", listArrObj);
		modelMap.addAttribute(TENDER_ID, tenderId);
		modelMap.addAttribute(VIEW_TYPE, (viewType == 1 ? VIEW_ALL_QUESTIONS : "View my questions"));

		if(viewType != 1 )
		{
		    linkId = bidderViewMyQuestionLinkID;
		}
		strReturn = "etender/common/ViewPrebidQuesAns";
	    }
	} catch (Exception e) {
	    exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, (viewType == 1 ? "All " : "Own ") + allPrebidQusAns, tenderId, 0);
	}
	return strReturn;
    }

    /**
     * View question from pre-bid meeting tab
     *
     * @param tenderId
     * @param viewType
     * @param modelMap
     * @param request
     * @return Pre-bid meeting page
     */
    @RequestMapping(value = "/viewQueries/{tenderId}/{viewType}/{enc}", method = RequestMethod.GET)
    public String viewQuestions(@PathVariable("tenderId") int tenderId, @PathVariable("viewType") int viewType, ModelMap modelMap, HttpServletRequest request) {
	int linkId = bidderViewAllQuestionLinkID; // View All Question
	try {
	    if (abcUtility.getSessionUserId(request) != 0) {
		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
		List<Object[]> listArrObj = prebidService.getQuestionAnswers(abcUtility.getSessionUserId(request), abcUtility.getSessionUserTypeId(request), tenderId, (viewType == 1));
		List<Object[]> lstPrebidObjArray = tenderCommonService.getTenderPrebidDetailByTenderId(tenderId);
		modelMap.addAttribute(PREBID_OBJ, lstPrebidObjArray);
		modelMap.addAttribute(CURRENT_DATE, commonService.getServerDateTime());
		modelMap.addAttribute("totalRec", listArrObj.size());
		modelMap.addAttribute("QusAnsList", listArrObj);
		modelMap.addAttribute(TENDER_ID, tenderId);
		modelMap.addAttribute(SHOW_POST_QUERY, "false");
		modelMap.addAttribute(VIEW_TYPE, (viewType == 1 ? VIEW_ALL_QUESTIONS : "View my questions"));
		if(viewType != 1 )
		{
		    linkId = bidderViewAllQuestionLinkID;
		}
	    }
	} catch (Exception e) {
	    exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, (viewType == 1 ? "All " : "Own ") + allPrebidQusAns, tenderId, 0);
	}
	return "etender/bidder/PreBidMeeting";
    }
}