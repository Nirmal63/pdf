/**
 * 
 */
package com.etl.eproc.etender.daointerface;

/**
 * @author janak
 *
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TblBidderweightageScore;

public interface TblBidderweightageScoreDao  {

    public void addTblBidderweightageScore(TblBidderweightageScore tblBidderweightageScore);

    public void deleteTblBidderweightageScore(TblBidderweightageScore tblBidderweightageScore);

    public void updateTblBidderweightageScore(TblBidderweightageScore tblBidderweightageScore);

    public List<TblBidderweightageScore> getAllTblBidderweightageScore();

    public List<TblBidderweightageScore> findTblBidderweightageScore(Object... values) throws Exception;

    public List<TblBidderweightageScore> findByCountTblBidderweightageScore(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidderweightageScoreCount();

    public void saveUpdateAllTblBidderweightageScore(List<TblBidderweightageScore> tblBidderweightageScores);
}