package com.etl.eproc.etender.daoimpl;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblTenderBidderCPV;
import com.etl.eproc.etender.daointerface.TblTenderBidderCPVDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderBidderCPVImpl extends AbcAbstractClass<TblTenderBidderCPV> implements TblTenderBidderCPVDao {

   

    @Override
    public void addTblTenderBidderCPV(TblTenderBidderCPV tblTenderBidderCPV){
        super.addEntity(tblTenderBidderCPV);
    }

    @Override
    public void deleteTblTenderBidderCPV(TblTenderBidderCPV tblTenderBidderCPV) {
        super.deleteEntity(tblTenderBidderCPV);
    }

    @Override
    public void updateTblTenderBidderCPV(TblTenderBidderCPV tblTenderBidderCPV) {
        super.updateEntity(tblTenderBidderCPV);
    }

    @Override
    public List<TblTenderBidderCPV> getAllTblTenderBidderCPV() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderBidderCPV> findTblTenderBidderCPV(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderBidderCPVCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderBidderCPV> findByCountTblTenderBidderCPV(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderBidderCPV(List<TblTenderBidderCPV> tblTenderBidderCPVs){
        super.updateAll(tblTenderBidderCPVs);
    }
}
