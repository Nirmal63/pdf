///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package com.etl.eproc.etender.databean;
//
//import com.form.table.TblBidJsonData;
//import com.form.table.TblBidderItemMapping;
//import com.form.table.TblColumnMaster;
//import com.form.table.TblTableMaster;
//import com.form.table.TblFormulaMaster;
//import com.form.table.TblCellMaster;
//import com.form.table.TblTableJsonFormat;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.Iterator;
//import java.util.List;
//import org.hibernate.Session;
//import org.hibernate.Transaction;
//import org.json.JSONArray;
//import org.json.JSONException;
//import org.json.JSONObject;
//
///**
// *
// * @author taher
// */
//public class FormBean {
//
////    public Connection getConnection() {
////        try {
////            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
////            Connection con = DriverManager.getConnection("jdbc:sqlserver://10.10.10.12:1440;databaseName=SAA");
////            return con;
////        } catch (Exception ex) {
////            Logger.getLogger(FormBean.class.getName()).log(Level.SEVERE, null, ex);
////        }
////        return null;
////    }
//    public TblTableMaster getTableStructure(int tableId) throws SQLException {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        TblTableMaster tableMaster = (TblTableMaster) session.createQuery("from TblTableMaster where tableId=" + tableId).list().get(0);
//        session.flush();
//        session.clear();
//        session.close();
//        return tableMaster;
//    }
//
//    public List<TblColumnMaster> getTableColumns(int tableId) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        List<TblColumnMaster> tableMaster = (List<TblColumnMaster>) session.createQuery("from TblColumnMaster where tblTableMaster.tableId=" + tableId).list();
//        session.flush();
//        session.clear();
//        session.close();
//        return tableMaster;
//    }
//
//    public List<TblBidderItemMapping> getMappedItems(int tableId, int userId) {
//        Session session = HibernateUtil.getSessionFactory().openSession();        
//        List<TblBidderItemMapping> bidderItemMappings = (List<TblBidderItemMapping>) session.createQuery("from TblBidderItemMapping where tableId=" + tableId + " and userId=" + userId).list();        
//        session.flush();
//        session.clear();
//        session.close();
//        return bidderItemMappings;
//
//    }
////JSONArray jSONArray = new JSONArray();
////        for (TblCellMaster tcm : cellMasters) {
////            JSONObject jSONObject = new JSONObject();
////            jSONObject.put(new StringBuilder().append(tcm.getCellNo()).append("_").append(tcm.getColumnNo()).append("_").append(tcm.getRowNo()).append("_").append(tcm.getDataTypeId()).toString(), tcm.getValue() != null ? tcm.getValue() : "null");
////            jSONArray.put(tcm.getCellNo(), jSONObject);
////        }
//    public String formatJSONBidder(String json,List<TblBidderItemMapping> itemMappings) throws JSONException {
//        String data = "";
//        if (json != null && !json.isEmpty()) {
//            JSONArray jsonArray = new JSONArray(json);
//            JSONArray jsonData = new JSONArray();
//            int counter = 0;
//            for (int i = 0; i < jsonArray.length(); i++) {
//                JSONObject jSONObject = jsonArray.getJSONObject(i);                
//                boolean tobeAdded = false;
//                for (Iterator it = jSONObject.keys(); it.hasNext();) {
//                    String key = it.next().toString();
//                    String[] values = key.split("_");
////                    jSONObject.getString(key);                    
//                    for (TblBidderItemMapping tbim : itemMappings) {
//                        if(Integer.parseInt(values[2]) == tbim.getRowId()){
//                            tobeAdded = true;
//                        }
//                    }
//                }
//                if(tobeAdded){
//                    jsonData.put(counter, jSONObject);                    
//                            counter++;
//                }
//                
//            }
//            data = jsonData.toString();
//        }        
//        return data;
//    }
//
//    public List<TblCellMaster> getTableCells(int tableId) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        List<TblCellMaster> tableMaster = (List<TblCellMaster>) session.createQuery("from TblCellMaster where tblTableMaster.tableId=" + tableId).list();
//        session.flush();
//        session.clear();
//        session.close();
//        return tableMaster;
//    }
//
//    public String getTableJson(int tableId) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        String json = "";
//        List<TblTableJsonFormat> tblTableJsonFormat = (List<TblTableJsonFormat>) session.createQuery("from TblTableJsonFormat where tableId=" + tableId).list();
//        if (!tblTableJsonFormat.isEmpty()) {
//            json = tblTableJsonFormat.get(0).getJson();
//        }
//        session.flush();
//        session.clear();
//        session.close();
//        return json;
//    }
//
//    public List<TblFormulaMaster> getTableFormulas(int tableId) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        List<TblFormulaMaster> tableMaster = (List<TblFormulaMaster>) session.createQuery("from TblFormulaMaster where tblTableMaster.tableId=" + tableId).list();
//        session.flush();
//        session.clear();
//        session.close();
//        return tableMaster;
//    }
//
//    public String getBidderData(int tableId, int userId) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        List<TblBidJsonData> bidJsonDatas = (List<TblBidJsonData>) session.createQuery("from TblBidJsonData where tableId=" + tableId + " and userId=" + userId).list();
//        String json = "";
//        if (!bidJsonDatas.isEmpty()) {
//            json = bidJsonDatas.get(0).getJsonData();
//        }
//        session.flush();
//        session.clear();
//        session.close();
//        return json;
//    }
//
//    public void getBidderData(TblBidJsonData bidJsonData) {
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        Transaction transaction = session.beginTransaction();
//        transaction.begin();
//        session.createQuery("delete from TblBidJsonData where tableId=" + bidJsonData.getTableId() + " and userId=" + bidJsonData.getUserId()).executeUpdate();
//        session.save(bidJsonData);
//        transaction.commit();
//        session.flush();
//        session.clear();
//        session.close();
//    }
//
//    public String _toJSON(List<TblCellMaster> cellMasters) throws JSONException {
//        JSONArray jSONArray = new JSONArray();
//        for (TblCellMaster tcm : cellMasters) {
//            JSONObject jSONObject = new JSONObject();
//            jSONObject.put(new StringBuilder().append(tcm.getCellNo()).append("_").append(tcm.getColumnNo()).append("_").append(tcm.getRowNo()).append("_").append(tcm.getDataTypeId()).toString(), tcm.getValue() != null ? tcm.getValue() : "null");
//            jSONArray.put(tcm.getCellNo(), jSONObject);
//        }
//        return jSONArray.toString();
//    }
//
//    public List<TblCellMaster> _toCellMasters(String json) throws JSONException {
//        List<TblCellMaster> cellMasters = new ArrayList<TblCellMaster>();
//        if (json != null && !json.isEmpty()) {
//            JSONArray jsonArray = new JSONArray(json);
//            int counter = 0;
//            for (int i = 0; i < jsonArray.length(); i++) {
//                JSONObject jSONObject = jsonArray.getJSONObject(i);
//                for (Iterator it = jSONObject.keys(); it.hasNext();) {
//                    String key = it.next().toString();
//                    String[] values = key.split("_");
//                    cellMasters.add(new TblCellMaster(counter + 1, Integer.parseInt(values[0]), Integer.parseInt(values[1]), Integer.parseInt(values[3]), Integer.parseInt(values[2]), new TblTableMaster(1), jSONObject.getString(key)));
//                    counter++;
//
//                }
//            }
//        }
//        //System.out.println("cellMasters :: "+cellMasters.size());
//        return cellMasters;
//    }
//
//    public List<BidData> _toBidDatas(String json) throws JSONException {
//        List<BidData> bidDatas = new ArrayList<BidData>();
//        if (json != null && !json.isEmpty()) {
//            JSONArray jsonArray = new JSONArray(json);
//            for (int i = 0; i < jsonArray.length(); i++) {
//                JSONObject jSONObject = jsonArray.getJSONObject(i);
//                for (Iterator it = jSONObject.keys(); it.hasNext();) {
//                    String key = it.next().toString();
//                    bidDatas.add(new BidData(Integer.parseInt(key), jSONObject.getString(key)));
//                }
//            }
//        }
//        return bidDatas;
//    }
//}
