package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderMapBidderHistory;
import java.util.List;

public interface TblTenderMapBidderHistoryDao  {

    public void addTblTenderMapBidderHistory(TblTenderMapBidderHistory tblTenderMapBidderHistory);

    public void deleteTblTenderMapBidderHistory(TblTenderMapBidderHistory tblTenderMapBidderHistory);

    public void updateTblTenderMapBidderHistory(TblTenderMapBidderHistory tblTenderMapBidderHistory);

    public List<TblTenderMapBidderHistory> getAllTblTenderMapBidderHistory();

    public List<TblTenderMapBidderHistory> findTblTenderMapBidderHistory(Object... values) throws Exception;

    public List<TblTenderMapBidderHistory> findByCountTblTenderMapBidderHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderMapBidderHistoryCount();

    public void saveUpdateAllTblTenderMapBidderHistory(List<TblTenderMapBidderHistory> tblTenderMapBidderHistorys);
}