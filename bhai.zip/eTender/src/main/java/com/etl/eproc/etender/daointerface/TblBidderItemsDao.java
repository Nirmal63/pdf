package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblBidderItems;

import java.util.List;

public interface TblBidderItemsDao  {

    public void addTblBidderItems(TblBidderItems tblBidderItems);

    public void deleteTblBidderItems(TblBidderItems tblBidderItems);

    public void updateTblBidderItems(TblBidderItems tblBidderItems);

    public List<TblBidderItems> getAllTblBidderItems();

    public List<TblBidderItems> findTblBidderItems(Object... values) throws Exception;

    public List<TblBidderItems> findByCountTblBidderItems(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidderItemsCount();

    public void saveUpdateAllTblBidderItems(List<TblBidderItems> tblBidderItemss);
}