/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author dipal
 */
@Component
public class SPGetVendorPQReport extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "appreport.P_VendorPqReport";

    public SPGetVendorPQReport() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_ClientId", Types.SMALLINT));
        this.declareParameter(new SqlParameter("@V_OfficerId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_DeptId", Types.INTEGER));
        
        this.declareParameter(new SqlParameter("@V_fileNo", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_companyName", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_departmentId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_registeredIn", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_indTypeId", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_ActiontakenId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_indClassificationId", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_EffectiveDateFrom", Types.DATE));
        this.declareParameter(new SqlParameter("@V_EffectiveDateTo", Types.DATE));
        this.declareParameter(new SqlParameter("@V_EffectiveDateOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_expiredOnOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_expiredOnTo", Types.DATE));
        this.declareParameter(new SqlParameter("@V_expiredOnFrom", Types.DATE));
        this.declareParameter(new SqlParameter("@V_Status", Types.TINYINT));
        
        
        this.declareParameter(new SqlParameter("@V_TimeZoneOffset", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_ConversionValue", Types.INTEGER));
        
        
        
        //this.declareParameter(new SqlParameter("@V_IsShowSrNo", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowDepartment", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowFileNo", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowcompanyName", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowcategoryName", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowregisteredNo", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowindType", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowindClassification", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowStatus", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowsubmissionDate", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowexpiredOn", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowactionTakenBy", Types.BIT));
        this.declareParameter(new SqlParameter("@V_Showadmin", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowEffectiveDate", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowAction", Types.BIT));
        this.declareParameter(new SqlParameter("@V_Sortorder", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_SortBy", Types.VARCHAR));
        
        this.declareParameter(new SqlParameter("@V_RecordsPerPage", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_PageNo", Types.INTEGER));
        
        this.declareParameter(new SqlOutParameter("@V_TotalPages", Types.INTEGER));
        this.declareParameter(new SqlOutParameter("@V_TotalRecords", Types.INTEGER));
        //this.declareParameter(new SqlOutParameter("@v_tabCountDetails", Types.VARCHAR));
        
    }

    /**
     * Method use for call store procedure for get Individual, Comparative, Bidder wise abstract report details.
     * @param tenderId
     * @param reportTypeId
     * @return {@code Map<String,Object>}
     * @throws Exception 
     */
    public Map<String,Object> executeProcedure(int clientId,int officerId,int deptId,
    		String fileNo,String companyName,int departmentId,int registeredIn
    		,int indTypeId,int actionTakenId,int indClassificationId,
    		int effectiveDateOperator,Date effectiveDateFrom,Date effectiveDateTo,int expiredOnOperator,Date expiredOnFrom,Date expiredOnTo,
    		int status,String timeZoneOffset,int conversionValue,List<Short> showHide,int recordPerPage,int pageNo,String sortBy,String sortOrder) throws Exception
    {
        Map inParams = new HashMap();        
        inParams.put("@V_ClientId",clientId);
        inParams.put("@V_OfficerId",officerId);
        inParams.put("@V_DeptId", deptId);
        
        inParams.put("@V_fileNo",fileNo);
        inParams.put("@V_companyName",companyName);
        inParams.put("@V_departmentId",departmentId);
        inParams.put("@V_registeredIn", registeredIn);
        inParams.put("@V_indTypeId",indTypeId );
        inParams.put("@V_ActiontakenId",actionTakenId);
        inParams.put("@V_indClassificationId", indClassificationId);
        inParams.put("@V_EffectiveDateFrom", effectiveDateFrom);
        inParams.put("@V_EffectiveDateTo", effectiveDateTo);
        inParams.put("@V_EffectiveDateOperator", effectiveDateOperator);
        inParams.put("@V_expiredOnOperator", expiredOnOperator);
        inParams.put("@V_expiredOnTo",expiredOnTo);
        inParams.put("@V_expiredOnFrom",expiredOnFrom);
        inParams.put("@V_Status",status);
        
        inParams.put("@V_TimeZoneOffset", timeZoneOffset);
        inParams.put("@V_ConversionValue", conversionValue);
        if(showHide.size()>0){                              
            //inParams.put("@V_IsShowSrNo", showHide.get(0));  
            inParams.put("@V_ShowFileNo", showHide.get(1));
            inParams.put("@V_ShowcompanyName", showHide.get(2));
            inParams.put("@V_ShowregisteredNo", showHide.get(3));
            inParams.put("@V_ShowindType", showHide.get(4));
            inParams.put("@V_ShowindClassification", showHide.get(5));
            inParams.put("@V_ShowcategoryName", showHide.get(6));
            inParams.put("@V_ShowDepartment", showHide.get(7));
            inParams.put("@V_Showadmin", showHide.get(8));
            inParams.put("@V_ShowsubmissionDate", showHide.get(9));  
            inParams.put("@V_ShowStatus", showHide.get(10));  
            inParams.put("@V_ShowEffectiveDate", showHide.get(11));
            inParams.put("@V_ShowactionTakenBy", showHide.get(12));
            inParams.put("@V_ShowexpiredOn", showHide.get(13));
            inParams.put("@V_ShowAction", showHide.get(14));
        }
        inParams.put("@V_SortBy", sortBy);
        inParams.put("@V_Sortorder", sortOrder);
        inParams.put("@V_RecordsPerPage", recordPerPage);
        inParams.put("@V_PageNo", pageNo);
        this.compile();
        return execute(inParams);
    }
}

