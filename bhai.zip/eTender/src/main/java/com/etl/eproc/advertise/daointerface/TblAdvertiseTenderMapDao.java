/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.advertise.daointerface;

/**
 *
 * @author hiral
 */

import com.etl.eproc.advertise.model.TblAdvertiseTenderMap;
import java.util.List;

public interface TblAdvertiseTenderMapDao  {

    public void addTblAdvertiseTenderMap(TblAdvertiseTenderMap tblAdvertiseTenderMap);

    public void deleteTblAdvertiseTenderMap(TblAdvertiseTenderMap tblAdvertiseTenderMap);

    public void updateTblAdvertiseTenderMap(TblAdvertiseTenderMap tblAdvertiseTenderMap);

    public List<TblAdvertiseTenderMap> getAllTblAdvertiseTenderMap();

    public List<TblAdvertiseTenderMap> findTblAdvertiseTenderMap(Object... values) throws Exception;

    public List<TblAdvertiseTenderMap> findByCountTblAdvertiseTenderMap(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAdvertiseTenderMapCount();

    public void saveUpdateAllTblAdvertiseTenderMap(List<TblAdvertiseTenderMap> tblAdvertiseTenderMaps);
}