package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TblTenderRebateDetail;

public interface TblTenderRebateDetailDao  {

    public void addTblTenderRebateDetail(TblTenderRebateDetail tblTenderRebateDetail);

    public void deleteTblTenderRebateDetail(TblTenderRebateDetail tblTenderRebateDetail);

    public void updateTblTenderRebateDetail(TblTenderRebateDetail tblTenderRebateDetail);

    public List<TblTenderRebateDetail> getAllTblTenderRebateDetail();

    public List<TblTenderRebateDetail> findTblTenderRebateDetail(Object... values) throws Exception;

    public List<TblTenderRebateDetail> findByCountTblTenderRebateDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderRebateDetailCount();

    public void saveUpdateAllTblTenderRebateDetail(List<TblTenderRebateDetail> tblTenderRebateDetails);
}