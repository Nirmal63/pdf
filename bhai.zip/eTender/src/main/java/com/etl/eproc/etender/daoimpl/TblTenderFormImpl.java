package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderFormDao;
import com.etl.eproc.etender.model.TblTenderForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;


/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderFormImpl extends AbcAbstractClass<TblTenderForm> implements TblTenderFormDao {

    @Override
    public void addTblTenderForm(TblTenderForm tblTenderForm){
        super.addEntity(tblTenderForm);
    }

    @Override
    public void deleteTblTenderForm(TblTenderForm tblTenderForm) {
        super.deleteEntity(tblTenderForm);
    }

    @Override
    public void updateTblTenderForm(TblTenderForm tblTenderForm) {
        super.updateEntity(tblTenderForm);
    }

    @Override
    public List<TblTenderForm> getAllTblTenderForm() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderForm> findTblTenderForm(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderFormCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderForm> findByCountTblTenderForm(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderForm(List<TblTenderForm> tblTenderForms){
        super.updateAll(tblTenderForms);
    }
}
