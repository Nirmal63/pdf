package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TblEnvelope;

public interface TblEnvelopeDao  {

    public void addTblEnvelope(TblEnvelope tblEnvelope);

    public void deleteTblEnvelope(TblEnvelope tblEnvelope);

    public void updateTblEnvelope(TblEnvelope tblEnvelope);

    public List<TblEnvelope> getAllTblEnvelope();

    public List<TblEnvelope> findTblEnvelope(Object... values) throws Exception;

    public List<TblEnvelope> findByCountTblEnvelope(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEnvelopeCount();

    public void saveUpdateAllTblEnvelope(List<TblEnvelope> tblEnvelopes);
}