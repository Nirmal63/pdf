package com.etl.eproc.etender.daointerface;

/**
* @author Lipi Shah
*/

import java.util.List;


import com.etl.eproc.etender.model.TblBroadCastQuestionMapping;

public interface TblBroadCastQuestionMappingDao  {

    public void addTblBroadCastQuestionMapping(TblBroadCastQuestionMapping tblBroadCastQuestionMapping);

    public void deleteTblBroadCastQuestionMapping(TblBroadCastQuestionMapping tblBroadCastQuestionMapping);

    public void updateTblBroadCastQuestionMapping(TblBroadCastQuestionMapping tblBroadCastQuestionMapping);

    public List<TblBroadCastQuestionMapping> getAllTblBroadCastQuestionMapping();

    public List<TblBroadCastQuestionMapping> findTblBroadCastQuestionMapping(Object... values) throws Exception;

    public List<TblBroadCastQuestionMapping> findByCountTblBroadCastQuestionMapping(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBroadCastQuestionMappingCount();

    public void saveUpdateAllTblBroadCastQuestionMapping(List<TblBroadCastQuestionMapping> tblBroadCastQuestionMappings);
}