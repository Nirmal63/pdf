package com.etl.eproc.etender.controller;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * @author TaherT
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblColumnType;
import com.etl.eproc.common.model.TblCommitteeRemarks;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblDocument;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblOfficerDocMapping;
import com.etl.eproc.common.model.TblPurchaseOrder;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.NegotiationService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.databean.EvaluateBiddersDataBean;
import com.etl.eproc.etender.databean.TenderEnvelopeCorrigendumDtBean;
import com.etl.eproc.etender.databean.TenderFormDtBean;
import com.etl.eproc.etender.databean.TenderGoverningColumnDtBean;
import com.etl.eproc.etender.model.TblBidderApprovalDetail;
import com.etl.eproc.etender.model.TblBidderItems;
import com.etl.eproc.etender.model.TblBidderweightageScore;
import com.etl.eproc.etender.model.TblCommitteeUser;
import com.etl.eproc.etender.model.TblCorrigendum;
import com.etl.eproc.etender.model.TblCorrigendumDetail;
import com.etl.eproc.etender.model.TblDynReport;
import com.etl.eproc.etender.model.TblEnvelope;
import com.etl.eproc.etender.model.TblEvaluationRework;
import com.etl.eproc.etender.model.TblFinalSubmission;
import com.etl.eproc.etender.model.TblLoadingFactorProcess;
import com.etl.eproc.etender.model.TblRebate;
import com.etl.eproc.etender.model.TblRebateForm;
import com.etl.eproc.etender.model.TblReworkDetail;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBid;
import com.etl.eproc.etender.model.TblTenderBidDetail;
import com.etl.eproc.etender.model.TblTenderBidMatrix;
import com.etl.eproc.etender.model.TblTenderBidOpenSign;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderColumn;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderFormula;
import com.etl.eproc.etender.model.TblTenderGovColumn;
import com.etl.eproc.etender.model.TblTenderOpen;
import com.etl.eproc.etender.model.TblTenderProxyBid;
import com.etl.eproc.etender.model.TblTenderReevaluation;
import com.etl.eproc.common.model.TblAdvancePurchaseOrder;
import com.etl.eproc.etender.model.TblTenderSOR;
import com.etl.eproc.etender.model.TblTenderSaving;
import com.etl.eproc.etender.model.TblTenderTable;
import com.etl.eproc.etender.model.TbltenderEnvelopeWeightage;
import com.etl.eproc.etender.model.TbltenderFormWeightage;
import com.etl.eproc.etender.model.TblNegotiationSORRemarks;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.CommitteeFormationService;
import com.etl.eproc.etender.services.DynamicReportService;
import com.etl.eproc.etender.services.EventBidSubmissionService;
import com.etl.eproc.etender.services.EventCreationService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderCorrigendumService;
import com.etl.eproc.etender.services.TenderFormService;
import com.etl.eproc.etender.services.TenderOpenService;
import com.etl.eproc.etender.services.TenderReportService;
import org.springframework.security.core.context.SecurityContextHolder;
import com.etl.eproc.common.services.MailBoxService;


@Controller
@RequestMapping("/etender")
public class TenderFormController {

    @Autowired
    private CommonValidators commonValidators;
    @Autowired
    private CommonService commonService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private TenderOpenService tenderOpenService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private TenderCorrigendumService tenderCorrigendumService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    EventBidSubmissionService eventBidSubmissionService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private CommitteeFormationService committeeFormationService;
    @Autowired
    private LoginService loginService;
    @Autowired
    private ManageBidderService manageBidderService;
    @Autowired
    private NegotiationService negotiationService;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private EventCreationService eventCreationService;
    @Autowired
	private DynamicReportService dynamicReportService;
    @Autowired
    private TenderReportService tenderReportService;
    @Autowired
    private MailBoxService mailBoxService; 
//        @Autowired
//	private ModelToSelectItem modelToSelectItem;
    @Value("#{projectProperties['file.drive']}")
    private String drive;
    @Value("#{projectProperties['file.tenderformmatrix']}")
    private String formmatrix;
    @Value("#{projectProperties['file.upload']}")
    private String upload;
    @Value("#{projectProperties['file.drive']}")
    private String fileDrive;
    @Value("#{projectProperties['file.tenderwisereport']}")
    private String tenderwiseReport;
    @Value("#{projectProperties['doc_upload_path']}")
	private String docUploadPath;
    @Value("#{projectProperties['contextName']}")
	 private String contextName;
    private static final String TOTAL = "TOTAL(";
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    private static final String TABLE_ID = "tableId";
    @Value("#{tenderlinkProperties['bidding_form_prepare']?:183}")
    private int prepareFormLinkId;
    @Value("#{tenderlinkProperties['bidding_form_form_library']?:184}")
    private int formLibraryLinkId;
    @Value("#{tenderlinkProperties['bidding_form_edit']?:185}")
    private int editFormLinkId;
    @Value("#{tenderlinkProperties['bidding_form_delete']?:187}")
    private int deleteFormLinkId;
    @Value("#{tenderlinkProperties['bidding_form_publish']?:192}")
    private int publishFormLinkId;
    @Value("#{tenderlinkProperties['bidding_form_copy_form']?:193}")
    private int copyFormLinkId;
    @Value("#{tenderlinkProperties['tender_search_tender']?:315}")
    private int searchTenderLinkId;
    @Value("#{tenderlinkProperties['tender_toc_tec']?:316}")
    private int tocTecLinkId;
    @Value("#{tenderlinkProperties['bidding_form_form_dashboard']?:260}")
    private int formDashboardLinkId;
    @Value("#{tenderlinkProperties['bidding_form_proxy']?:280}")
    private int proxyLinkId;
    @Value("#{tenderlinkProperties['bidding_form_proxy_bid']?:281}")
    private int proxyBidLinkId;
    @Value("#{tenderlinkProperties['bidding_form_cancel']?:190}")
    private int cancelFormLinkId;
    @Value("#{linkProperties['report_tender_form_library_reportid']?:40}")
    private int manageFormLibraryReportId;
    @Value("#{tenderlinkProperties['bidding_form_upload_matrix_excel']?:145}")
    private int bidFormExcelMatrix;
    @Value("#{tenderlinkProperties['bidding_form_create_sor']?:357}")
    private int bidFormCreateSor;
    @Value("#{tenderlinkProperties['bidding_form_edit_sor']?:358}")
    private int bidFormEditSor;
    @Value("#{tenderlinkProperties['bidding_form_view_sor']?:359}")
    private int bidFormViewSor;
    @Value("#{tenderlinkProperties['bidding_form_delete_sor']?:360}")
    private int bidFormDeleteSor;
    @Value("#{tenderlinkProperties['organize_from']?:194}")
    private int organizeFrom;
    @Value("#{tenderlinkProperties['organize_from_view']?:195}")
    private int organizeFromView;
    @Value("#{tenderlinkProperties['bidding_form_show_hide_column']?:448}")
    private int biddingShowHideCols;
    @Value("#{tenderlinkProperties['bid_opening_remarks']?:1138}")
    private int bidOpeningRemarksLinkId;
    @Value("#{projectProperties['officer.docstatus.approve']?:1}")
    private int officerDocStatusApprove;
    @Value("#{projectProperties['officer.docstatus.pending']?:0}")
    private int officerDocStatusPending;
    
    @Value("#{etenderAuditTrailProperties['addXlsMatrix']}")    
    private String addXlsMatrixAudit="";//todo
    @Value("#{etenderAuditTrailProperties['getManageFormLibraryRemark']}")
    private String getManageFormLibraryRemark;
    @Value("#{etenderAuditTrailProperties['getCancelForm']}")
    private String getCancelForm;
    @Value("#{etenderAuditTrailProperties['postFormLibraryRemark']}")
    private String postFormLibraryRemark;
    @Value("#{etenderAuditTrailProperties['getTenderPublishRemark']}")
    private String getTenderPublishRemark;
    @Value("#{etenderAuditTrailProperties['postTenderPublishRemark']}")
    private String postTenderPublishRemark;
    @Value("#{etenderAuditTrailProperties['postTenderCopyFormRemark']}")
    private String postTenderCopyFormRemark;
    @Value("#{projectProperties['serverside.validation']?:false}")
    private boolean isServerValidationReq;
    @Value("#{etenderAuditTrailProperties['getCreateFormRemark']}")
    private String getCreateFormRemark;
    @Value("#{etenderAuditTrailProperties['postCreateFormRemark']}")
    private String postCreateFormRemark;
    @Value("#{etenderAuditTrailProperties['getEditFormRemark']}")
    private String getEditFormRemark;
    @Value("#{etenderAuditTrailProperties['postEditFormRemark']}")
    private String postEditFormRemark;
    @Value("#{etenderAuditTrailProperties['getFormDashboardRemark']}")
    private String getFormDashboardRemark;
    @Value("#{etenderAuditTrailProperties['getTenderListingRemark']}")
    private String getTenderListingRemark;
    @Value("#{etenderAuditTrailProperties['gettendertables']}")
    private String getTenderTablesRemark;
    @Value("#{etenderAuditTrailProperties['posttendertables']}")
    private String postTenderTablesRemark;
    @Value("#{etenderAuditTrailProperties['getaddtendertable']}")
    private String getAddTenderTableRemark;
    @Value("#{etenderAuditTrailProperties['postaddtendertable']}")
    private String postAddTenderTableRemark;
    @Value("#{etenderAuditTrailProperties['getedittendertable']}")
    private String getEditTenderTableRemark;
    @Value("#{etenderAuditTrailProperties['postupdatetendertable']}")
    private String postUpdateTenderTableRemark;
    @Value("#{etenderAuditTrailProperties['addFormFormula']}")
    private String addFormFormulaAudit;
    @Value("#{etenderAuditTrailProperties['deleteFormula']}")
    private String deleteFormulaAudit;
    @Value("#{etenderAuditTrailProperties['editTenderEnvelope']}")
    private String postEditTenderEnvelope;
    @Value("#{etenderAuditTrailProperties['getEditTenderEnvelope']}")
    private String getEditTenderEnvelope;
    @Value("#{auctionAuditTrailProperties['changeGovCol']}")
    private String changeGovColAudit;
    @Value("#{etenderAuditTrailProperties['viewForm']}")
    private String viewFormAudit;
    @Value("#{etenderAuditTrailProperties['testForm']}")
    private String testFormAudit;
    @Value("#{etenderAuditTrailProperties['postupdateorganizeform']}")
    private String postupdateorganizeform;
    @Value("#{etenderAuditTrailProperties['getorganizeform']}")
    private String getorganizeform;
    @Value("#{etenderAuditTrailProperties['getcreaterebateform']}")
    private String getcreaterebateform;
    @Value("#{etenderAuditTrailProperties['geteditrebateform']}")
    private String geteditrebateform; 
    @Value("#{etenderAuditTrailProperties['viewRebateReport']}")
    private String viewRebateReport;
    @Value("#{etenderAuditTrailProperties['deleteRebateReport']}")
    private String deleteRebateReport;
    @Value("#{etenderAuditTrailProperties['rebateformcreated']}")
    private String rebateformcreated;
    @Value("#{etenderAuditTrailProperties['rebateformedited']}")
    private String rebateformedited;
    @Value("#{etenderAuditTrailProperties['getopenmenddocreq']}")
    private String getopenmenddocreq;
    @Value("#{etenderAuditTrailProperties['getopeneditmenddocreq']}")
    private String getopeneditmenddocreq;
    @Value("#{etenderAuditTrailProperties['getopenshowmenddocreq']}")
    private String getopenshowmenddocreq;
    @Value("#{etenderAuditTrailProperties['manDocumrntcreated']}")
    private String manDocumrntcreated;
    @Value("#{etenderAuditTrailProperties['manDocumrntcreatefail']}")
    private String manDocumrntcreatefail;
    @Value("#{etenderAuditTrailProperties['manDocumrntupdated']}")
    private String manDocumrntupdated;
    @Value("#{etenderAuditTrailProperties['manDocumrntupdatedfail']}")
    private String manDocumrntupdatedfail;
    @Value("#{etenderAuditTrailProperties['getusercommitteeremarks']}")
    private String getusercommitteeremarks;
    @Value("#{etenderAuditTrailProperties['getevalcommitteeremarks']}")
    private String getevalcommitteeremarks;
    @Value("#{etenderAuditTrailProperties['usercommitteeremarksupdated']}")
    private String usercommitteeremarksupdated;
    @Value("#{etenderAuditTrailProperties['evalcommitteeremarksupdated']}")
    private String evalcommitteeremarksupdated;
    @Value("#{etenderAuditTrailProperties['usercommitteeremarksupdatedfail']}")
    private String usercommitteeremarksupdatedfail;
    @Value("#{etenderAuditTrailProperties['evalcommitteeremarksupdatedfail']}")
    private String evalcommitteeremarksupdatedfail;
    @Value("#{etenderAuditTrailProperties['evaluatebiddersstatusaddpage']}")
    private String evaluatebiddersstatusaddpage;
    @Value("#{etenderAuditTrailProperties['reevaluatebiddersstatusaddpage']}")
    private String reevaluatebiddersstatusaddpage;
    @Value("#{etenderAuditTrailProperties['evaluatebidderswisestatusaddpage']}")
    private String evaluatebidderswisestatusaddpage;    
    @Value("#{etenderAuditTrailProperties['evaluatebiddersstatusadd']}")
    private String evaluatebiddersstatusadd;
    @Value("#{etenderAuditTrailProperties['evaluatebiddersstatusaddfail']}")
    private String evaluatebiddersstatusaddfail;
    @Value("#{etenderAuditTrailProperties['evaluatebiddersstatusupdate']}")
    private String evaluatebiddersstatusupdate;
    @Value("#{etenderAuditTrailProperties['evaluatebiddersstatusupdatefail']}")
    private String evaluatebiddersstatusupdatefail;
     @Value("#{etenderAuditTrailProperties['reevaluatebiddersstatusupdate']}")
    private String reevaluatebiddersstatusupdate;
    @Value("#{etenderAuditTrailProperties['reevaluatebiddersstatusupdatefail']}")
    private String reevaluatebiddersstatusupdatefail;
    @Value("#{linkProperties['report_tender_tec_toc_reportid']?:41}")
    private int manageTocTecReportId;
    @Value("#{etenderAuditTrailProperties['getTocTecReportRemark']}")
    private String getTocTecReportRemark;
    @Value("#{etenderAuditTrailProperties['getMapBidderForProxy']}")
    private String getMapBidderForProxyAudit;
    @Value("#{etenderAuditTrailProperties['getTenderProxy']}")
    private String getTenderProxyAudit;
    @Value("#{etenderAuditTrailProperties['postAddUpdateProxy']}")
    private String postAddUpdateProxyAudit;
    @Value("#{etenderAuditTrailProperties['getDeleteForm']}")
    private String getDeleteFormAudit;
    @Value("#{etenderAuditTrailProperties['postAjaxDeleteForm']}")
    private String postAjaxDeleteFormAudit;
    @Value("#{etenderAuditTrailProperties['sorForm']}")
    private String sorFormAudit;
    @Value("#{etenderAuditTrailProperties['addSorForm']}")
    private String addSorFormAudit;
    @Value("#{etenderAuditTrailProperties['editSorForm']}")
    private String editSorFormAudit;
    @Value("#{etenderAuditTrailProperties['viewSorForm']}")
    private String viewSorFormAudit;
    @Value("#{etenderAuditTrailProperties['deleteSorForm']}")
    private String deleteSorFormAudit;   
    @Value("#{etenderAuditTrailProperties['getBiddingShowHideColumns']}")
    private String getBiddingShowHideColumns; 
    @Value("#{etenderAuditTrailProperties['postBiddingShowHideColumns']}")
    private String postBiddingShowHideColumns; 
    @Value("#{tenderlinkProperties['report_master_form_library']?:54}")
    private int reportMasterFormLibrary;
    @Value("#{tenderlinkProperties['bidding_form_master_form_library']?:491}")
    private int biddingFormMasterFormLibrary;
    @Value("#{tenderlinkProperties['bidding_form_edit_envelope_name']?:751}")
    private int biddingFormEditEnvelopeName;
    @Value("#{etenderAuditTrailProperties['getMasterFormLibraryRemark']}")
    private String getMasterFormLibraryRemark;
    @Value("#{tenderlinkProperties['link_loading_factor_after']?:830}")
    private int link_loading_factor_after;
    @Value("#{etenderAuditTrailProperties['getLoadingFactorAfter']}")
    private String getLoadingFactorAfter;
    @Value("#{etenderAuditTrailProperties['saveLoadingFactorAfter']}")
    private String saveLoadingFactorAfter;
    @Value("#{tenderlinkProperties['negotiation_negotiation_process_invite_for_negotiation']?:602}")
    private int negotiation_negotiation_process_invite_for_negotiation;
    @Value("#{tenderlinkProperties['negotiation_negotiation_process_invite_for_negotiation']?:602}")
    private int inviteBidderForNegotiationLinkIdTender;
    
    @Value("#{tenderlinkProperties['link_configure_WeightageEvaluation']?:1126}")
    private int configureWeightageEvaluationLinkId;
    @Value("#{tenderlinkProperties['link_edit_WeightageEvaluation']?:1127}")
    private int editWeightageEvaluationLinkId;
    @Value("#{tenderlinkProperties['link_view_WeightageEvaluation']?:1128}")
    private int viewWeightageEvaluationLinkId;
    @Value("#{etenderAuditTrailProperties['ConfigurationOfWeightage']}")
    private String configurationOfWeightage;
    @Value("#{etenderAuditTrailProperties['SubmittedWeightageConfiguration']}")
    private String submittedWeightageConfiguration;
    @Value("#{etenderAuditTrailProperties['ReConfigurationOfWeightage']}")
    private String reConfigurationOfWeightage;
    @Value("#{etenderAuditTrailProperties['UpdatedWeightageConfigurationPage']}")
    private String updatedWeightageConfigurationPage;
    @Value("#{etenderAuditTrailProperties['ViewWeightagePageFromWeightageConfiguration']}")
    private String viewWeightagePageFromWeightageConfiguration;
    @Value("#{etenderAuditTrailProperties['ViewWeightagePageFromPrepareBidByBidder']}")
    private String viewWeightagePageFromPrepareBidByBidder;
    @Value("#{etenderAuditTrailProperties['InsertBidderWeightagePage']}")
    private String insertBidderWeightagePage;
    @Value("#{etenderAuditTrailProperties['UpdateBidderWeightagePage']}")
    private String updateBidderWeightagePage;
    @Value("#{etenderAuditTrailProperties['InsertedBidderWeightagePage']}")
    private String insertedBidderWeightagePage;
    @Value("#{etenderAuditTrailProperties['UpdatedBidderWeightagePage']}")
    private String updatedBidderWeightagePage;
    @Autowired
    private MessageSource messageSource;
    @Value("#{etenderProperties['rtf_length_limit']?:10000}")
    private int rtf_length_limit;
    @Value("#{etenderProperties['biddingForms_submoduleId']?:28}")
    private int biddingFormsSubModuleId;
    @Value("#{etenderAuditTrailProperties['get_bidwithdrawn']}")
    private String bidwithdrawn;
    @Value("#{tenderlinkProperties['bid_withdrawn_count']?:3297}")
    private int bidWithdrawnLink;
    @Value("#{projectProperties['mvp_sector']?:7}")
    private int mvpSectorId;
    @Value("#{clientProperties['cgClient']}")
    private String cgClient;
    @Value("#{etenderAuditTrailProperties['getViewBidEvaluationFromBidEvaluationTab']}")
    private String getViewBidEvaluationFromBidEvaluationTab;
    @Value("#{etenderAuditTrailProperties['getViewEvaluationHistoryFromBidEvaluationTab']}")
    private String getViewEvaluationHistoryFromBidEvaluationTab;
    		
    private static final String SELECT_ENVELOPE_ID = "selEnvelopeId";
    private static final String HIDDEN_TENDER_ID = "hdTenderId";
    private static final String HIDDEN_FORM_ID = "hdFormId";
    private static final String HIDDEN_TABLE_ID = "hdTableId";
    private static final String FROM_DASH = "hdFromDash";
    private static final int TAB_TENDER_OPENING = 7;
    private static final int TAB_EVALUATE_BID = 8;
    private static final String PUBLICKEY="publicKey";
    private static final String SKPSIGNTEXT = "skpSignText";
    private static final String RESULT_SET_1= "#result-set-1";
    private static final String RESULT_SET_2= "#result-set-2";
    @Value("#{tenderlinkProperties['bidding_form_form_matrix']?:306}")
    private int bidFormCreate;
    @Value("#{tenderlinkProperties['bidding_form_edit_form_matrix']?:309}")
    private int bidFormEdit;
    @Value("#{etenderAuditTrailProperties['createFormMatrix']}")
    private String createFormMatrixAudit;
    @Value("#{tenderlinkProperties['bidding_form_delete_formula']?:283}")
    private int bidFormFormulaDel;
    @Value("#{auclinkProperties['bidding_form_remove_governing_column']?:137}")
    private int bidFormRemGovCol;
    @Value("#{etenderProperties['datatype_smalltext']?:1}")
    private int smalltext;
    @Value("#{etenderProperties['datatype_longtext']?:2}")
    private int longtext;
    @Value("#{etenderProperties['datatype_numeric']?:3}")
    private int numeric;
    @Value("#{etenderProperties['datatype_money']?:4}")
    private int money;
    @Value("#{etenderProperties['datatype_money_all']?:5}")
    private int moneyall;
    @Value("#{etenderProperties['datatype_combo']?:6}")
    private int combobox;
    @Value("#{etenderProperties['datatype_date']?:7}")
    private int date;
    @Value("#{etenderProperties['datatype_master_field']?:8}")
    private int masterField;
     @Value("#{etenderProperties['datatype_listbox']?:9}")
    private int listBox;
     @Value("#{etenderProperties['datatype_autonumber']?:10}")
    private int autoNumber;
    @Value("#{etenderProperties['filledby_auto']?:3}")
    private int auto;
    @Value("#{etenderProperties['load_no_of_items']?:50}")
    private int loadNoOfItems;
    @Value("#{etenderProperties['increment_items']?:20}")
    private int incrementItems;
    @Value("#{tenderlinkProperties['bidding_form_view']?:186}")
    private int bidFormView;
    @Value("#{tenderlinkProperties['bidding_form_test_form']?:188}")
    private int bidFormTest;
    @Value("#{etenderAuditTrailProperties['addFormMatrixEdit']}")
    private String addFormMatrixEditAudit;
    @Value("#{etenderAuditTrailProperties['addFormMatrixCreate']}")
    private String addFormMatrixCreateAudit;
    @Value("#{etenderProperties['bidding_form_document_fees']?:9}")
    private int documentFeesId;
    @Value("#{etenderProperties['bidding_form_emd_amount']?:10}")
    private int emdAmountId;
    @Value("#{etenderProperties['bidding_form_emd_by_officer_fees']?:18}")
    private int emdOfficerAmountId;
    @Value("#{etenderProperties['bidding_form_document_by_fees_officer']?:31}")
    private int docfeesOfficerAmountId;
    @Value("#{etenderProperties['bidding_form_participation_fees_by_officer']?:32}")
    private int participationOfficerAmountId;
    @Value("#{etenderProperties['bidding_form_processing_fees']?:11}")
    private int processingFeesId;
    @Value("#{etenderProperties['bidding_form_encr_not_req']?:20}")
    private int encNotReq;
    @Value("#{etenderProperties['bidding_form_loading_factor']?:23}")
    private int loadingFactor;
    @Value("#{etenderProperties['bidding_form_auto_loading_total']?:26}")
    private int autoLoadingTotal;
    @Value("#{etenderProperties['bidding_form_unit_rate_after_loading']?:27}")
    private int unitRateAfterLoading;

	 @Value("#{clientProperties['bob_client_id']}")
	 private String bobClientId;
    private static final String TENDER_ID = "tenderId";
    private static final String FORM_ID = "formId";
    private static final String HDDATATYPE = "hdDataType_";
    private static final String HDDFILLEDBY = "hdFilledBy_";
    private static final String HDCOLUMNID = "hdColumnId_";
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    private static final String TENDER_DASHBOARD_URL = "etender/buyer/tenderdashboard/";
    
    private static final String MANDATORY_DOCUMENT_REQ = "etender/buyer/addmandatdocreq";
    private static final String EDIT_MANDATORY_DOCUMENT_REQ = "etender/buyer/updatemandatdocreq";
    private static final String GET_USER_COMMITTEE_REMARKS = "etender/buyer/getcommitteeuserremark/";
    
    @Value("#{tenderlinkProperties['manage_bidder_master_data_for_bidder']?:161}")
    private int bidderMasterField;
    @Value("#{tenderlinkProperties['bidding_form_build_formula']?:189}")
    private int bidFormFormulaGovCol;
    @Value("#{etenderAuditTrailProperties['createFormula']}")
    private String createFormulaAudit;
    @Value("#{projectProperties['pki_enable']?:1}")   
    private int pkiEnable;
    @Value("#{projectProperties['pki_eventspecific']?:2}")   
    private int pkiEventSpecific;
    @Value("#{tenderlinkProperties['bidding_form_add_to_standard']?:307}")
    private int bidFormAddStd;
    @Value("#{etenderAuditTrailProperties['submitStandardFormAdd']}")
    private String submitStandardFormAddAudit;
    @Value("#{etenderAuditTrailProperties['submitStandardFormRem']}")
    private String submitStandardFormRemAudit;
    @Value("#{tenderlinkProperties['bidding_form_remove_from_standard']?:308}")
    private int bidFormRemStd;
    @Value("#{linkProperties['report_tender_buyer_tender_listing']?:36}")
 	private int tenderListingReportId;

    @Value("#{tenderlinkProperties['bidding_form_add_multiple_tables']?:300}")
    private int addMultipleTableLinkId;
    @Value("#{tenderlinkProperties['bidding_form_add_table']?:282}")
    private int addTableLinkId;
    @Value("#{tenderlinkProperties['bidding_form_edit_table']?:285}")
    private int editTableLinkId;
    @Value("#{tenderlinkProperties['bidding_form_view_table']?:284}")
    private int viewTableLinkId;
    @Value("#{tenderlinkProperties['bidding_form_add_governing_column']?:286}")
    private int addGoverningColumnLinkId;
    @Value("#{tenderlinkProperties['bidding_form_edit_governing_column']?:292}")
    private int editGoverningColumnLinkId;
    @Value("#{tenderlinkProperties['bidding_form_view_governing_column']?:683}")
    private int viewGoverningColumnLinkId;
    @Value("#{tenderlinkProperties['bidding_form_create_mandatory_docs']?:317}")
    private int createFormDocuLinkId;
    @Value("#{tenderlinkProperties['bidding_form_edit_mandatory_docs']?:319}")
    private int editMandatoryDocsLinkId;
    @Value("#{tenderlinkProperties['bidding_form_view_mandatory_docs']?:318}")
    private int viewMandatoryDocsLinkkId;
    
    @Value("#{tenderlinkProperties['bidding_form_create_rebate_report']?:191}")
    private int createRebateReportLinkId;
    @Value("#{tenderlinkProperties['bidding_form_edit_rebate_report']?:258}")
    private int editRebateReportLinkId;
    @Value("#{tenderlinkProperties['bidding_form_view_rebate_report']?:259}")
    private int viewRebateReportLinkId;
    @Value("#{tenderlinkProperties['bidding_form_delete_rebate_report']?:261}")
    private int deleteRebateReportLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_consent']?:209}")
    private int evaluationConsentLinkId;
    @Value("#{tenderlinkProperties['bid_opening_consent']?:226}")
    private int openingConsentLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_evaluate']?:210}")
    private int evaluationEvaluateLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_re_evaluate']?:276}")
    private int evaluationReEvaluateLinkId;
    @Value("#{etenderAuditTrailProperties['getcreategovcolumn']}")
    private String getcreategovcolumn;
    @Value("#{etenderAuditTrailProperties['postaddgovcolumn']}")
    private String postaddgovcolumn;
    @Value("#{etenderAuditTrailProperties['geteditgovcolumn']}")
    private String getEditGovColumn;
    @Value("#{etenderAuditTrailProperties['posteditgovcolumn']}")
    private String postEditGovColumn;
    @Value("#{etenderAuditTrailProperties['getviewgovcolumn']}")
    private String getViewGovColumn;
    @Value("#{etenderAuditTrailProperties['standardFormAdd']}")
    private String standardFormAddAudit;
    @Value("#{etenderAuditTrailProperties['standardFormRem']}")
    private String standardFormRemAudit;
    @Value("#{etenderAuditTrailProperties['bidopeningremarksaddpage']}")
    private String bidOpeningRemarksAudit;
    @Value("#{etenderAuditTrailProperties['postbidopeningremarkssuccess']}")
    private String postBidOpeningRemarksSuccessAudit;
    @Value("#{etenderAuditTrailProperties['postbidopeningremarksfailed']}")
    private String postBidOpeningRemarksFailedAudit;
    @Value("#{etenderAuditTrailProperties['evaluatebiddersreevaluateaddpage']}")
    private String evaluatebiddersreevaluateaddpage;
    @Value("#{etenderAuditTrailProperties['postevaluatebiddersreevaluateaddpage']}")
    private String postevaluatebiddersreevaluateaddpage;
    @Value("#{etenderAuditTrailProperties['reevaluationprocesshasbeeninitiated']}")
    private String reevaluationprocesshasbeeninitiated;
    
    @Value("#{tenderlinkProperties['tender_form_copy_table']?:3335}")
    private int copyTableLinkId;
    @Value("#{etenderAuditTrailProperties['postcopytendertable']}")
    private String postcopytendertable;
    @Value("#{etenderProperties['tender_opened_status']?:4}")
    private int TENDER_OPENED_STATUS;
    @Value("#{etenderProperties['tender_completed_status']?:5}")
    private int TENDER_COMPLETED_STATUS;
    @Value("#{etenderAuditTrailProperties['myLibraryFormAdd']}")
    private String libraryFormAddAudit;
    @Value("#{etenderAuditTrailProperties['myLibraryFormRem']}")
    private String libraryFormRemAudit;
    @Value("#{etenderAuditTrailProperties['submitMyLibraryFormAdd']}")
    private String submitMyLibraryFormAddAudit;
    @Value("#{etenderAuditTrailProperties['submitMyLibraryFormRem']}")
    private String submitMyLibraryFormRemAudit;
    @Value("#{linkProperties['view_authorized_rfx_reportid']?:154}")
    private int viewAuthorizedRFXReportId;
    @Value("#{tenderlinkProperties['view_authorized_rfx_and_tender']?:5539}") 
    private int viewAuthorizedRfxAndTender;
    @Value("#{etenderAuditTrailProperties['viewAuthorizedRFX']}")
    private String viewAuthorizedRFX;
    /**
     * Use to set form combo
     * @author nirav.modi
     * @param tenderId 
     * @param modelMap2 
     * @param request 
     * @param modelMap
     * @param tenderId
     * @throws Exception
     */
    private void setFormData(HttpServletRequest request, ModelMap modelMap, int tenderId) throws Exception{
    	/*
    	 * isConsortiumAllowed = 1 then show Form secondary field on page other wise not
    	 */
    	List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isConsortiumAllowed,isCertRequired,isOpeningByCommittee");
    	if(tenderDetails!= null && !tenderDetails.isEmpty()){
    		/*** Change model map variable name isConsortiumAllowed to isConsortiumAllowedTrueFalse because of data type issue to call tender summary page in form create screen **/
    		//modelMap.addAttribute("isConsortiumAllowed", "1".equals(tenderDetails.get(0)[0].toString()));
    		modelMap.addAttribute("isConsortiumAllowedTrueFalse", "1".equals(tenderDetails.get(0)[0].toString()));
    		
    		modelMap.addAttribute("isCertRequired","1".equals(tenderDetails.get(0)[1].toString()));
    		modelMap.addAttribute("isOpeningByCommittee","1".equals(tenderDetails.get(0)[2].toString()));
    	}
    	modelMap.addAttribute("passBaseEncrypReq","1".equals(String.valueOf(abcUtility.getSessionIsPasswordEncryptionReq(request))));
    	modelMap.addAttribute("yesNoList", commonService.getYesNo());
    	modelMap.addAttribute("envelopeList",abcUtility.convert(tenderFormService.getTenderEnvelopeListForEditForm(tenderId), 0, 1));
    }

    private void setEditFormData(ModelMap modelMap,int formId) throws Exception{
    	List<Object[]> formList =tenderFormService.getTenderFormDetails(formId);
    	if(formList != null && !formList.isEmpty()){
    		Object[] data= formList.get(0);
    		TblTenderForm tblTenderForm = new TblTenderForm(formId);
    		tblTenderForm.setFormName(data[0].toString());
    		tblTenderForm.setFormHeader(data[1].toString());
    		tblTenderForm.setFormFooter(data[2].toString());
    		tblTenderForm.setIsDocumentReq((Integer)data[3]);
    		tblTenderForm.setIsEncryptedDocument((Integer)data[4]);
    		tblTenderForm.setIsEncryptionReq((Integer)data[5]);
    		tblTenderForm.setIsEvaluationReq((Integer)data[6]);
    		tblTenderForm.setIsMandatory((Integer)data[7]);
    		tblTenderForm.setIsMultipleFilling((Integer)data[8]);
    		tblTenderForm.setIsPriceBid((Integer)data[9]);
    		tblTenderForm.setIsSecondary((Integer)data[10]);
    		tblTenderForm.setNoOfTables((Integer)data[11]);
    		TblTenderEnvelope tblTenderEnvelope = new TblTenderEnvelope((Integer)data[12]);
    		tblTenderEnvelope.setTblEnvelope( new TblEnvelope((Integer)data[13]));
    		tblTenderForm.setSortOrder((Integer)data[14]);
    		tblTenderForm.setTblTenderEnvelope(tblTenderEnvelope);
                tblTenderForm.setIsItemWiseDocAllowed((Integer)data[16]);
    		modelMap.addAttribute("tblTenderForm", tblTenderForm);
    	}
    }

    /**
     * @author nirav.modi
     * @param modelMap
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/gettenderenvelopeforpublish/{tenderId}/{isWorkFlow}/{enc}", method = RequestMethod.GET)                       
    public String getTenderEnvelopePublish(ModelMap modelMap, HttpServletRequest request,@PathVariable(TENDER_ID) int tenderId,@PathVariable("isWorkFlow") int isWorkFlow){
    	String retVal="etender/buyer/PublishTenderEnvelope";
    	try{
    		int publishEnvelop=0;
    		if(isWorkFlow == 1){
    			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    			modelMap.addAttribute("envelopeList", tenderFormService.getTenderEnvelopeForPublish(tenderId,false,false));
        		modelMap.addAttribute("formDetalisList", tenderCommonService.getTenderFormByTenderId(false,false,tenderId));
        		modelMap.addAttribute("isCertRequired", modelMap.get("isCertRequired")); 
                modelMap.addAttribute("isWorkFlow", isWorkFlow);
    		}else{
    			int isCertRequired=0;
    			boolean isCertiFound=true;
        		String certIds[] =null;
        		SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
                ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
                if(clientBean.getIsPkiEnabled()==pkiEventSpecific){
                	isCertRequired=  (Integer) tenderCommonService.getTenderField(tenderId, "isCertRequired");
                }
    			if(clientBean.getIsPkiEnabled()==pkiEnable){
                    certIds = sessionBean.getCertId().split(",");
            		if(certIds!=null && certIds.length!=0){
            			modelMap.addAttribute(PUBLICKEY,commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                    }
        		}else if (clientBean.getIsPkiEnabled()==pkiEventSpecific && isCertRequired ==1){
        			if(!sessionBean.isEventSpecVerify()){
        				isCertiFound=false;
        				retVal="common/buyer/attacheventspeccerti/etender,buyer,gettenderenvelopeforpublish,"+tenderId+","+isWorkFlow;
        			}else{
        				certIds = sessionBean.getCertId().split(",");
                		if(certIds!=null && certIds.length!=0){
                			modelMap.addAttribute(PUBLICKEY,commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                        }
                    }
                }
        		if(isCertiFound){
        			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        			modelMap.addAttribute("envelopeList", tenderFormService.getTenderEnvelopeForPublish(tenderId,false));
            		modelMap.addAttribute("formDetalisList", tenderCommonService.getTenderFormByTenderId(false,false,tenderId,publishEnvelop));
            		modelMap.addAttribute("isCertRequired", modelMap.get("isCertRequired")); 
                    modelMap.addAttribute("isWorkFlow", isWorkFlow);
        		}else{
    				retVal="redirect:/"+retVal+ encryptDecryptUtils.generateRedirect(retVal, request);
                }
    		}
    	}
    	catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),publishFormLinkId, getTenderPublishRemark, tenderId, 0);
    	}
    	return retVal;
    }
    

    /**
     * @author nirav.modi
     * @param redirectAttributes
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/publishtenderenvelope", method = RequestMethod.POST)                       
    public String publishTenderEnvelope(RedirectAttributes redirectAttributes, HttpServletRequest request){
    	String retVal=REDIRECT_SESSION_EXPIRED;
    	String remarks=null;
    	String formIds=null;
    	int isCertRequired=0;
    	int tenderId=0;
    	boolean success = false;
    	List<Map<String,Object>> validateTenderLinks=null;
    	try{
    		int userDetailId = abcUtility.getSessionUserDetailId(request);
    		int userId = abcUtility.getSessionUserId(request);
    		if(userDetailId!=0){
    			remarks = request.getParameter("txtaRemarks");
    			tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))?Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
    			validateTenderLinks=(List<Map<String,Object>>)commonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, biddingFormsSubModuleId, abcUtility.getSessionUserId(request),publishFormLinkId).get(RESULT_SET_1);
    			if(validateTenderLinks.get(0).get("remark").toString().equals("Success")){
	    			formIds = request.getParameter("hdFormIds");
	    			isCertRequired = StringUtils.hasLength(request.getParameter("hdIsCertRequired"))?Integer.parseInt(request.getParameter("hdIsCertRequired")):0;
	    			if(tenderId!=0 && StringUtils.hasLength(remarks) && StringUtils.hasLength(formIds)){
	    				if(formIds.length()>1 && formIds.toString().startsWith(",")){
	    					formIds=formIds.substring(1,formIds.length());
	    				}
	    				int rowCount = eventCreationService.updateTenderEnvForPublish(tenderId, null, userId, userDetailId,remarks);
	    				if(rowCount > 0){
	    					success=tenderFormService.publishTenderEnvelope(formIds,userDetailId);
	    				}
	    				int tenderResult =  (Integer) tenderCommonService.getTenderField(tenderId, "tenderResult");
	    				int isNegotiationAllowed =  (Integer) tenderCommonService.getTenderField(tenderId, "isNegotiationAllowed");
	    				int isWeightageEvaluationRequired =  (Integer) tenderCommonService.getTenderField(tenderId, "isWeightageEvaluationRequired");
	    				int isRebateForm =  (Integer) tenderCommonService.getTenderField(tenderId, "isRebateForm");
	    				/*** Code to call procedure for negotiation l1 h1 report  last parameter o for publish tender if Corrigendum it is 1**/
	    	    		tenderFormService.executeSPforGenerateL1Report(tenderId, tenderResult, userDetailId,1,0); // Change for MBPT Issue
	    	    		if(isNegotiationAllowed!=0)
	    	    			tenderFormService.executeSPforGenerateL1Report(tenderId, tenderResult, userDetailId,1,1);
	    	    		if(isWeightageEvaluationRequired==1)
	    	    			tenderFormService.executeSPforGenerateL1Report(tenderId, tenderResult, userDetailId,1,2);
	    	    		if(isRebateForm==1 && tenderResult==1)
	    	    			tenderFormService.executeSPforGenerateL1Report(tenderId, tenderResult, userDetailId,1,4);
	    				//retVal=success? TENDER_DASHBOARD_URL+tenderId+"/2": "etender/buyer/gettenderenvelopeforpublish/"+tenderId+"/0";
	    				//retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	    			}
    			}
    		}
    	}
    	catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
    		int pki=abcUtility.getSessionIsPkiEnabled(request);
    		if(pki==pkiEnable || (pki==pkiEventSpecific && isCertRequired==1)){
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), publishFormLinkId, postTenderPublishRemark,tenderId, 0,remarks,StringUtils.hasLength(request.getParameter("skpSignText"))?request.getParameter("skpSignText"):"");
    		}else{
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), publishFormLinkId, postTenderPublishRemark,tenderId, 0,remarks);
    		}
    	}
    	retVal=success? TENDER_DASHBOARD_URL+tenderId+"/2": "etender/buyer/gettenderenvelopeforpublish/"+tenderId+"/0";
		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_publish_envelope" : validateTenderLinks.get(0).get("showAlert").toString().equals("1") ? validateTenderLinks.get(0).get("remark").toString() : CommonKeywords.ERROR_MSG_KEY.toString());
    	return retVal;
    }

    /**Use case: copy form
     * @author nirav.modi
     * @param redirectAttributes
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/copytenderform/{tenderId}/{formId}/{envelopeId}/{isFormWithValue}/{enc}", method = RequestMethod.GET)                       
    public String copyTenderForm(RedirectAttributes redirectAttributes, HttpServletRequest request,@PathVariable(TENDER_ID) int tenderId,@PathVariable(FORM_ID) int formId,@PathVariable("envelopeId") int envelopeId,@PathVariable("isFormWithValue") int isFormWithValue){
        boolean success = false;
        String retVal=REDIRECT_SESSION_EXPIRED;
        try{
        	String[]formIds=new String[1];
        	formIds[0]= String.valueOf(formId);
        	int userDetailId = abcUtility.getSessionUserDetailId(request);
    		if(userDetailId!=0 && tenderId!=0 && formId!=0 && envelopeId!=0){
    			String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    			success=tenderFormService.mapTenderForm(abcUtility.getSessionClientId(request), tenderId, envelopeId, formIds, ipAddress, userDetailId,isFormWithValue);
    			retVal=TENDER_DASHBOARD_URL+tenderId+"/2";
    			retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    		}
        }
        catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),copyFormLinkId, postTenderCopyFormRemark,tenderId,formId);
    	}
    	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_copy_form" : CommonKeywords.ERROR_MSG_KEY.toString());
    	return retVal;
    }
    
    /**
     * This method is used to copy table in the same form with same table properties. PT : 33257.
     * @author jitendra
     * @param redirectAttributes
     * @param request
     * @param tenderId
     * @param formId
     * @param tableId
     * @param isTableWithValue
     * @return
     */
    @RequestMapping(value = "/buyer/copytendertable/{tenderId}/{formId}/{envelopeId}/{tableId}/{isCopyTable}/{enc}", method = RequestMethod.GET)
    public String copyTenderTable(RedirectAttributes redirectAttributes, HttpServletRequest request,@PathVariable(TENDER_ID) int tenderId,@PathVariable(FORM_ID) int formId,@PathVariable("envelopeId") int envelopeId ,@PathVariable("tableId") int tableId,@PathVariable("isCopyTable") int isCopyTable){
    	boolean success = false;
    	String retVal=REDIRECT_SESSION_EXPIRED;
    	try {
    		int userDetailId = abcUtility.getSessionUserDetailId(request);
    		if(userDetailId!=0 && tenderId!=0 && formId!=0){
    			String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    			success = tenderFormService.mapTenderTable(abcUtility.getSessionClientId(request), tenderId, formId, envelopeId, tableId, ipAddress, userDetailId, isCopyTable);
    			retVal = "redirect:/etender/buyer/formdashboard/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/formdashboard/" + tenderId + "/" + formId, request);
    		}
    	} 
    	catch (Exception ex) {
    		retVal= exceptionHandlerService.writeLog(ex);
		}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),copyTableLinkId, postcopytendertable,tenderId,formId);
    	}
    	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_copy_table" : CommonKeywords.ERROR_MSG_KEY.toString());
    	return retVal;
    }
    
    /**
     * Use case : form library 
     * @author nirav.modi
     * @param modelMap
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/managetenderformlibrary/{tenderId}/{isForWizard}/{enc}", method = RequestMethod.GET)                       
    public String manageTenderFormLibrary(ModelMap modelMap, HttpServletRequest request,@PathVariable(TENDER_ID) int tenderId, @PathVariable("isForWizard") int isForWizard){
    	String retVal="etender/buyer/ManageTenderFormLibrary";
    	try {
    		
    		 List<SelectItem> items = new ArrayList<SelectItem>();
    		 List<Object[]> list = tenderFormService.getTenderEnvelopeList(tenderId);
    		 if (list != null) {
    	            for (Object[] objects : list) {
    	                if (objects.length >= 2) {
    	                    items.add(new SelectItem(objects[1], objects[0]+"_"+objects[2]));
    	                }                
    	            }
    	        }
    		 
    		
    		modelMap.addAttribute("tenderResult", tenderCommonService.getTenderField(tenderId,"tenderResult"));
    		modelMap.addAttribute("envelopeList",items);
    		modelMap.addAttribute("reportId", manageFormLibraryReportId);
    		reportGeneratorService.getReportConfigDetails(manageFormLibraryReportId, modelMap);
                tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    	} catch (Exception ex) {
    		retVal= exceptionHandlerService.writeLog(ex);
    	} finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formLibraryLinkId, getManageFormLibraryRemark,tenderId, 0);
    	}
    	return retVal;
    }

    /**
     * Ajax call for check whether form is form complete  or not
     * 
     * @return
     */
    @RequestMapping(value = "/buyer/isFormAlreadyExists", method = RequestMethod.POST)
    @ResponseBody
    public String isFormAlreadyExists(HttpServletRequest request){
    	String result = "";
    	StringBuilder parentFormIds = new StringBuilder();
    	try{
    		int hdTenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) && !"".equals(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;
    		List<Object[]> list = null;
    		list = tenderFormService.getTenderFormByTenderId(hdTenderId);
    		if(list!=null && !list.isEmpty())
    		{
    			for (Object[] objects : list) {
    				parentFormIds.append(objects[0]).append(",");
    			}
    		}	
    		result = parentFormIds.toString().endsWith(",") ? parentFormIds.toString().substring(0, parentFormIds.length() - 1) : parentFormIds.toString();
    	}
    	catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), formLibraryLinkId, postAjaxDeleteFormAudit, 0,0);
    	}
    	return result.toString();
    }
    
    /**
     * Use Case: Map Tender form from form library
     * @author nirav.modi
     * @param redirectAttributes
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/maptenderformlibrary", method = RequestMethod.POST)                       
    public String mapTenderFormLibrary(RedirectAttributes redirectAttributes, HttpServletRequest request){
    	boolean success = false;
    	String retVal=REDIRECT_SESSION_EXPIRED;
    	int tenderId =0;
    	String envelopeId = "";
    	int tenderEnvelopeId=0;
    	String[]formIds=null;
    	int isCopyFormWithValue;
    	try{
    		int userDetailId = abcUtility.getSessionUserDetailId(request);
    		tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))?Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
    		envelopeId = StringUtils.hasLength(request.getParameter("selEnvelopeId"))? request.getParameter("selEnvelopeId"):"";
    		if(StringUtils.hasLength(envelopeId))
    		{
    			tenderEnvelopeId = Integer.parseInt(envelopeId.split("_")[1]);
    		}	
    		formIds = request.getParameterValues(HIDDEN_FORM_ID)!=null?request.getParameterValues(HIDDEN_FORM_ID):null;
    		isCopyFormWithValue = StringUtils.hasLength(request.getParameter("jhdFormValueConf"))?Integer.parseInt(request.getParameter("jhdFormValueConf")):0;
    		if(userDetailId!=0 && tenderId!=0 && formIds!=null && tenderEnvelopeId!=0){
    			String isForWizard = StringUtils.hasLength(request.getParameter("hdIsForWizard"))?request.getParameter("hdIsForWizard"):"0";
    			String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    			success=tenderFormService.mapTenderForm(abcUtility.getSessionClientId(request), tenderId, tenderEnvelopeId, formIds, ipAddress, userDetailId,isCopyFormWithValue);
    			retVal=success ? TENDER_DASHBOARD_URL+tenderId+"/2" : "etender/buyer/managetenderformlibrary/"+tenderId+"/"+isForWizard;
    			retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    		}
    	}
    	catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formLibraryLinkId,postFormLibraryRemark, tenderId ,0);
    	}
    	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_form_selected" : CommonKeywords.ERROR_MSG_KEY.toString());
    	return retVal;
    }
    
    /**
     * Use case : Standard Form GET
     * @author nirav.modi
     * @param tenderId
     * @param tableId
     * @param standard
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/standardform/{tenderId}/{formId}/{actualTenderId}/{isWorkFlow}/{standard}/{enc}", method = RequestMethod.GET)
    public String standardForm(@PathVariable(TENDER_ID) Integer tenderId,@PathVariable("actualTenderId") Integer actualTenderId,@PathVariable("isWorkFlow") int isWorkFlow, @PathVariable(FORM_ID) int formId, @PathVariable("standard") int standard, ModelMap modelMap, HttpServletRequest request) {
    	String retVal="etender/buyer/ViewForm";
        try {
        	tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        } catch (Exception e) {
            retVal= exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), standard == 1 ? bidFormAddStd : bidFormRemStd, standard == 1 ? standardFormAddAudit :standardFormRemAudit, tenderId, formId);
        }
        return retVal;
    }

    /**
     * Use Case : Standard Form POST
     * @author nirav.modi
     * @param modelMap
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/buyer/submitstandardform", method = RequestMethod.POST)
    public String submitStandardForm(ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
        int formId = StringUtils.hasLength(request.getParameter(HIDDEN_FORM_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_FORM_ID)) : 0;
        int standard = StringUtils.hasLength(request.getParameter("hdStandard")) ? Integer.parseInt(request.getParameter("hdStandard")) : 0;
        int actualTenderId = StringUtils.hasLength(request.getParameter("hdActualTenderId")) ? Integer.parseInt(request.getParameter("hdActualTenderId")) : 0;
        String retVal=REDIRECT_SESSION_EXPIRED;
        boolean success=false;
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		success=tenderFormService.addFormToStandard(formId, standard);
        		redirectAttributes.addFlashAttribute(success? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString() ,success? standard == 1 ? "redirect_success_standardadd" : "redirect_success_standardrem":  CommonKeywords.ERROR_MSG_KEY.toString());
        		retVal=success ? "etender/buyer/managetenderformlibrary/"+actualTenderId+"/0" : "etender/buyer/"+tenderId+"/"+formId+"/"+actualTenderId+"/0"+"/"+standard;
        		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
        	}
        } catch (Exception e) {
            retVal= exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), standard == 1 ? bidFormAddStd : bidFormRemStd, (standard == 1 ? submitStandardFormAddAudit : submitStandardFormRemAudit), tenderId, formId);
        }
        return retVal;
    }

    /**
     * Use to get all active tender
     * @author nirav.modi
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/tenderlisting/{enc}", method = RequestMethod.GET)                       
    public String tenderListing(ModelMap modelMap, HttpServletRequest request){
    	String retVal="etender/common/TenderListing";
    	ClientBean clientBean = null;
    	TblUserLogin tblUserLogin = null;
    	String userName = "";
    	userName = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
    	clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    	try{
    		modelMap.put("lstClientMarquee", clientService.getClientMarqueeAfterLogin((int) abcUtility.getSessionClientId(request)));/* For After Loging Marque */
    		tblUserLogin = loginService.getUserLoginByLoginId(userName);
    		modelMap.addAttribute("reportId", tenderListingReportId);
    		modelMap.addAttribute("tenderList",tenderFormService.getTenderList());
    		reportGeneratorService.getReportConfigDetails(tenderListingReportId, modelMap);
    		setTaskListData(tblUserLogin.getUserId(),clientBean.getClientId(),request); /*used to display reminder pupup*/
    	}
    	catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),searchTenderLinkId,getTenderListingRemark,0,0);
    	}
    	return retVal;
    }
    
    /*For tooltip refresh every time*/
    private void setTaskListData(int userId, int clientId, HttpServletRequest request) throws Exception {
    	String taskLists = new String();
       String currentTask = "";
       List<Object[]> taskListData = mailBoxService.getTaskListData(userId, clientId);
       request.getSession().removeAttribute("taskLists");
       request.getSession().removeAttribute("isFirstTime");
       if(taskListData!=null && !taskListData.isEmpty()) {
       	for(Object[] task : taskListData) {
       		currentTask="";
       		currentTask= task[0] +"|~|"+ task[1] +"|~|"+ task[2] +"|~|"+ CommonUtility.convertTimezoneToClientTimezone(task[3]) +"|~|"+ task[4]+"|~|"+ task[5]+"|~|"+ task[6]+ "|~|"+ CommonUtility.convertTimezoneToClientTimezone(task[7])+"|#|";
       		taskLists+=currentTask;        		
       	}        	        			 
       	request.getSession().setAttribute("taskLists", taskLists);        	 	  
       	request.getSession().setAttribute("isFirstTime", true);
       	
       }
   }

    /**
     * Use to get form dashboard
     * @author nirav.modi
     * @param formId
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/formdashboard/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)                       
    public String formDashborard(@PathVariable(FORM_ID) int formId,@PathVariable(TENDER_ID) int tenderId,ModelMap modelMap, HttpServletRequest request){
    	String retVal="etender/buyer/TenderFormDashboard";
    	try{
    		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		List<Object[]> formList =tenderFormService.getTenderFormDetails(formId);
    		if(formList != null && !formList.isEmpty()){
    			modelMap.addAttribute("formName", formList.get(0)[0]);
    			modelMap.addAttribute("ispricebid", formList.get(0)[9]);
    			modelMap.addAttribute("cstatus", formList.get(0)[15]);
    			modelMap.addAttribute("envelopeId", formList.get(0)[12]);
    		}
    		List<Object[]> customParam = eventCreationService.getClientConfigurationFields(abcUtility.getSessionClientId(request),(Integer)modelMap.get("eventTypeId"));
    		for (Object[] objects : customParam) {
				if(objects[3].equals("isEditBiddingForm")){
					modelMap.addAttribute("isEditBiddingForm", objects[4]);
				}
			}
    		
    		modelMap.addAttribute("tableList",tenderFormService.getTenderTableList(formId));
    		modelMap.addAttribute("isMVPVertical", clientService.isClientMVPVertical(abcUtility.getSessionClientId(request), mvpSectorId));
    	}
    	catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),formDashboardLinkId,getFormDashboardRemark,tenderId,formId);
    	}
    	return retVal;
    }
    /**
     * To Show/Hide columns
     * 
     * @author purvesh
     * @param tenderId
     * @param formId
     * @param tableId
     * @param map
     * @param request
     * @return
     */
    @RequestMapping(value="/buyer/showhidecolumns/{tenderId}/{formId}/{tableId}/{enc}", method=RequestMethod.GET)
    public String showHideColumns(@PathVariable(TENDER_ID) int tenderId,@PathVariable(FORM_ID) int formId,@PathVariable("tableId") int tableId,ModelMap map, HttpServletRequest request){
    	String retVal = "etender/buyer/ShowHideColumns";
    	try {
    		List<Object[]> formList =tenderFormService.getTenderFormDetails(formId);
    		List<Object[]> lstTblDetails = tenderFormService.getTableDetails(formId, tableId);
    		map.addAttribute("tableId", tableId);
    		map.addAttribute("formId", formId);
    		map.addAttribute("tenderId", tenderId);
    		List<Object[]> lstColumnDtls = tenderFormService.getTenderColumn(tableId, formId);
    		if(formList!=null && !formList.isEmpty() && lstTblDetails!=null && !lstTblDetails.isEmpty() && lstColumnDtls!=null && !lstColumnDtls.isEmpty()){
    			map.addAttribute("formName", formList.get(0)[0]);
    			map.addAttribute("tblDetails", lstTblDetails);
    			map.addAttribute("columnDtls", lstColumnDtls);
    		}
			List<SelectItem> showHideList = new ArrayList<SelectItem>();
			showHideList.add(new SelectItem("Show", 1));
			showHideList.add(new SelectItem("Hide", 0));
	        map.addAttribute("showHideList", showHideList);
    		tenderCommonService.tenderSummary(tenderId, map, abcUtility.getSessionClientId(request));
		} catch (Exception ex) {
			retVal= exceptionHandlerService.writeLog(ex);
		}
    	finally{
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), biddingShowHideCols, getBiddingShowHideColumns,tenderId,tableId);
    	}
    	return retVal;
    }
    
    /**
     *  To update show/hide columns
     *  
     * @author purvesh
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value="/buyer/updateshowhidecolumns", method=RequestMethod.POST)
    public String updateShowHideColumns(HttpServletRequest request, RedirectAttributes redirectAttributes){
    	String retVal=REDIRECT_SESSION_EXPIRED;
    	boolean success = false;
    	boolean hideSuccess = false;
    	boolean showsuccess = false;
    	int tenderId=0;
    	int tableId=0;
    	try {
    		if(abcUtility.getSessionUserId(request)!=0){
    			
    			int count = StringUtils.hasLength(request.getParameter("hdCount")) ? Integer.parseInt(request.getParameter("hdCount")) : 0;
    			tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
    			int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
    			tableId = StringUtils.hasLength(request.getParameter("hdTableId")) ? Integer.parseInt(request.getParameter("hdTableId")) : 0;
    			List<Integer> showColumnIds = new ArrayList<Integer>();
    			List<Integer> hideColumnIds = new ArrayList<Integer>();
    			retVal = "redirect:/etender/buyer/showhidecolumns/" + tenderId + "/" + formId + "/" + tableId + encryptDecryptUtils.generateRedirect("etender/buyer/showhidecolumns/" + tenderId + "/" + formId + "/" + tableId, request);
    			for(int i=1; i<=count; i++){
    				int isShown = StringUtils.hasLength(request.getParameter("rdIsShow_"+i)) ? Integer.parseInt(request.getParameter("rdIsShow_"+i)) : 0;
    				int columnId = StringUtils.hasLength(request.getParameter("hdColumnId_"+i)) ? Integer.parseInt(request.getParameter("hdColumnId_"+i)) : 0;
    				if(columnId!=0){
	    				if(isShown!=0){
	    					showColumnIds.add(columnId);
	    				}
	    				else{
	    					hideColumnIds.add(columnId);
	    				}
    				}
    			}
    			if(showColumnIds!=null && !showColumnIds.isEmpty()){
    				showsuccess = tenderFormService.updateshowHideColumns(1, showColumnIds);
    			}
    			if(hideColumnIds!=null && !hideColumnIds.isEmpty()){
    				hideSuccess = tenderFormService.updateshowHideColumns(0, hideColumnIds);
    			}
    			if(showsuccess || hideSuccess){
    				success = true;
    			}
    			if(success){
    				retVal = "redirect:/etender/buyer/formdashboard/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/formdashboard/" + tenderId + "/" + formId, request);
    			}
    			redirectAttributes.addFlashAttribute(success? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString() ,success?  "redirect_success_showhide_updated_successfully" :  CommonKeywords.ERROR_MSG_KEY.toString());
    		}
			
		} catch (Exception e) {
			retVal= exceptionHandlerService.writeLog(e);
		}
    	finally{
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), biddingShowHideCols, postBiddingShowHideColumns,tenderId,tableId);
    	}
    	return retVal;
    	
    }
    /**
     * @author nirav.modi
     * @param tenderFormDtBean
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/getform/{tenderId}/{enc}", method = RequestMethod.GET)                       
    public String getForm(@ModelAttribute TenderFormDtBean tenderFormDtBean ,@PathVariable(TENDER_ID) int tenderId,ModelMap modelMap,HttpServletRequest request){
    	String retVal="etender/buyer/TenderForm";
    	try{
    		/*** Get Common Services for tender detail **/
 			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
 			
    		setFormData(request, modelMap,tenderId);
    	}
    	catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),prepareFormLinkId,getCreateFormRemark,tenderId, 0);
    	}
    	return retVal;
    }

    /**
     * @author nirav.modi
     * @param tenderFormDtBean
     * @param result
     * @param modelMap
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/addform", method = RequestMethod.POST)                       
    public String addForm(@ModelAttribute TenderFormDtBean tenderFormDtBean, BindingResult result,ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request){
    	boolean success = false;
    	StringBuilder retVal = new StringBuilder();
    	StringBuilder retUrl = new StringBuilder();
    	int isBiddingFormPublishWithTender = 0;
    	int tenderId=0;
    	try{
    		tenderId= StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))?Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
    		int userDetailId = abcUtility.getSessionUserDetailId(request);
    		boolean isConsortiumAllowed= StringUtils.hasLength(request.getParameter("hdIsConsortiumAllowed"))?Boolean.parseBoolean(request.getParameter("hdIsConsortiumAllowed")):false;
    		boolean isCertRequired= StringUtils.hasLength(request.getParameter("hdIsCertRequired"))?Boolean.parseBoolean(request.getParameter("hdIsCertRequired")):false;
    		boolean isOpeningByCommittee= StringUtils.hasLength(request.getParameter("hdIsOpeningByCommittee"))?Boolean.parseBoolean(request.getParameter("hdIsOpeningByCommittee")):false;
    		boolean hasErrors=false;
              
    		if(tenderId!=0 && userDetailId!=0){
    			tenderFormDtBean.setCertRequired(isCertRequired);
    			tenderFormDtBean.setConsortiumAllowed(isConsortiumAllowed);
    			tenderFormDtBean.setOpeningByCommittee(isOpeningByCommittee);
    			tenderFormDtBean.setCommonValidators(commonValidators);
    			if(isServerValidationReq){
    				tenderFormDtBean.validate(result,rtf_length_limit); /*CR:28161 Max length changes*/
    				if(result.hasErrors()){
    					setFormData(request,modelMap,tenderId);
    					retVal.append("etender/buyer/TenderForm");
    					modelMap.addAttribute(TENDER_ID,tenderId);
    					modelMap.addAttribute("tblTenderForm", tenderFormDtBean.toTblTenderForm());
    					hasErrors=true;
    				}
    			}
    			if(!hasErrors){
    				TblTenderForm tblTenderForm = tenderFormDtBean.toTblTenderForm();
    				tblTenderForm.setTblTender(new TblTender(tenderId));
    				//Form sort order will increment by particular envelope
    				tblTenderForm.setSortOrder(tenderFormService.getFormMaxSortOrder(tenderId,tblTenderForm.getTblTenderEnvelope().getTblEnvelope().getEnvId())+1);
    				List<Object[]> list = tenderFormService.getTenderEnvelopeList(tenderId);
    				int envId=tblTenderForm.getTblTenderEnvelope().getTblEnvelope().getEnvId();
    				if(list !=null && !list.isEmpty()){
    					for(Object[] obj: list){
    						if(envId==(Integer)obj[0]){//This is envId and we have to put envelopId in tenderForm
    							tblTenderForm.setTblTenderEnvelope(new TblTenderEnvelope((Integer)obj[2]));
    						}
    					}
    				}
    				tblTenderForm.setCreatedBy(userDetailId);
                                tblTenderForm.setLoadNoOfItems(loadNoOfItems);
                                tblTenderForm.setIncrementItems(incrementItems);
                                tblTenderForm.setIsItemWiseDocAllowed(Integer.parseInt(request.getParameter("selItemWiseDocAllowed")));
                                List<Object[]> clientConfigList=commonService.getClientConfigurations(abcUtility.getSessionClientId(request));
                                if(!clientConfigList.isEmpty() && clientConfigList.size()>0){
                                    isBiddingFormPublishWithTender = Integer.parseInt(clientConfigList.get(0)[3].toString());
                                }
                                success=tenderFormService.addTenderForm(tblTenderForm,userDetailId,tenderId,true,isBiddingFormPublishWithTender);//if form publishwithtender=1 than make entry in corriDetail else not
    				//Added by Mitesh
                                if(success && (tblTenderForm.getIsMandatory()==1)){
                                    boolean corgPenging=tenderCorrigendumService.isCorrigendumPending(tenderId);
                                    if(!corgPenging){
                                        tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(tblTenderForm.getTblTenderEnvelope().getEnvelopeId());
                                    }
                                    else if(corgPenging && tenderFormService.isEnvelopePending(tblTenderForm.getTblTenderEnvelope().getEnvelopeId())){
                                        tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(tblTenderForm.getTblTenderEnvelope().getEnvelopeId());
                                    }
                                }
                                //Ended by Mitesh
    				retVal=success?retUrl.append("redirect:/etender/buyer/tendertables/").append(tenderId).append("/").append(tblTenderForm.getFormId()):retUrl.append("redirect:/etender/buyer/getform/").append(tenderId);
    				retVal.append(encryptDecryptUtils.generateRedirect(retVal.substring(retVal.indexOf("/")+1,retVal.length()).toString(), request));
    			}
    		}else{
    			retVal.append(REDIRECT_SESSION_EXPIRED);
    		}
    	}
    	catch(Exception ex){
    		retVal.setLength(0);
    		retVal.append(exceptionHandlerService.writeLog(ex));
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),prepareFormLinkId,postCreateFormRemark, tenderId , 0);
    	}
    	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_create_form" : CommonKeywords.ERROR_MSG_KEY.toString());
    	return retVal.toString();
    }

    /**
     * @author nirav.modi
     * @param formId
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/editform/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)                       
    public String editForm(@PathVariable(FORM_ID) int formId,@PathVariable(TENDER_ID) int tenderId,ModelMap modelMap, HttpServletRequest request){
    	String retVal="etender/buyer/TenderForm";
    	try{
    		
    		/*** Get Common Services for tender detail **/
 			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
 			
    		setFormData(request, modelMap,tenderId);
    		setEditFormData(modelMap,formId);
    		
    		/*** Code to get form column type in case form will change from technical to price bid form **/
    		List<Object[]> formColumnList = tenderFormService.getFormColumnType(formId);
    		modelMap.addAttribute("formColumnList", formColumnList);
    		
    		modelMap.addAttribute("opType", "update");
    	}
    	catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editFormLinkId,getEditFormRemark, tenderId, formId);
    	}
    	return retVal;
    }

    /**
     * @author nirav.modi
     * @param tenderFormDtBean
     * @param result
     * @param modelMap
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/updateform", method = RequestMethod.POST)                       
    public String updateForm(@ModelAttribute TenderFormDtBean tenderFormDtBean, BindingResult result,ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request){
    	boolean success = false;
    	String retVal = REDIRECT_SESSION_EXPIRED;
    	int tenderId= 0;
    	int formId=0;
    	try{
    		tenderId= StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))?Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
    		formId= StringUtils.hasLength(request.getParameter("hdFormId"))?Integer.parseInt(request.getParameter("hdFormId")):0;
    		int userDetailId=abcUtility.getSessionUserDetailId(request);
    		int sortOrder=StringUtils.hasLength(request.getParameter("hdSortOrder"))?Integer.parseInt(request.getParameter("hdSortOrder")):0;
    		String noOfTables=request.getParameter("hdNoOfTables");
    		boolean isConsortiumAllowed= StringUtils.hasLength(request.getParameter("hdIsConsortiumAllowed"))?Boolean.parseBoolean(request.getParameter("hdIsConsortiumAllowed")):false;
    		boolean isCertRequired= StringUtils.hasLength(request.getParameter("hdIsCertRequired"))?Boolean.parseBoolean(request.getParameter("hdIsCertRequired")):false;
    		boolean isOpeningByCommittee= StringUtils.hasLength(request.getParameter("hdIsOpeningByCommittee"))?Boolean.parseBoolean(request.getParameter("hdIsOpeningByCommittee")):false;
    		boolean hasErrors=false;
    		int previousEnvelopeId = 0;
    		if(formId !=0 && tenderId!=0 && userDetailId!=0 && StringUtils.hasLength(noOfTables) && sortOrder!=0){
        		TblTenderForm tblTenderFormForId =  tenderFormService.getTenderFormById(formId);
        		previousEnvelopeId = tblTenderFormForId.getTblTenderEnvelope().getEnvelopeId();
    			tenderFormDtBean.setCommonValidators(commonValidators);
    			tenderFormDtBean.setConsortiumAllowed(isConsortiumAllowed);
    			tenderFormDtBean.setOpeningByCommittee(isOpeningByCommittee);
    			tenderFormDtBean.setCertRequired(isCertRequired);
    			if(isServerValidationReq){
    				tenderFormDtBean.setTxtNoOfTables(noOfTables);//In update case: it will come from hidden
    				tenderFormDtBean.validate(result,rtf_length_limit); /*CR:28161 Max length changes*/
    				if(result.hasErrors()){
    					setFormData(request,modelMap,tenderId);
    					setEditFormData(modelMap,formId);
    					retVal="etender/buyer/TenderForm";

    					modelMap.addAttribute(TENDER_ID,tenderId);
    					modelMap.addAttribute(FORM_ID, formId);
    					modelMap.addAttribute("opType", "update");
    					hasErrors=true;
    				}
    			}
    			if(!hasErrors){
    				TblTenderForm tblTenderForm = tenderFormDtBean.toTblTenderForm();
    				tblTenderForm.setTblTender(new TblTender(tenderId));
    				tblTenderForm.setFormId(formId);
    				tblTenderForm.setSortOrder(sortOrder);
    				int envId=tblTenderForm.getTblTenderEnvelope().getTblEnvelope().getEnvId();
    				List<Object[]> list = tenderFormService.getTenderEnvelopeList(tenderId);
    				if(list !=null && !list.isEmpty()){
    					for(Object[] obj: list){
    						if(envId==(Integer)obj[0]){//This is envId and we have to put envelopId in tenderForm
    							tblTenderForm.setTblTenderEnvelope(new TblTenderEnvelope((Integer)obj[2]));
    						}
    					}
    				}
    				tblTenderForm.setLoadNoOfItems(loadNoOfItems);
                                tblTenderForm.setIncrementItems(incrementItems);
                                tblTenderForm.setIsItemWiseDocAllowed(Integer.parseInt(request.getParameter("selItemWiseDocAllowed")));
    				success=tenderFormService.addTenderForm(tblTenderForm,userDetailId,tenderId,false,0);
                                //Added by Mitesh
                                boolean corgPenging=tenderCorrigendumService.isCorrigendumPending(tenderId);
                                if(success){
                                    if(!corgPenging){
                                        tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(tblTenderForm.getTblTenderEnvelope().getEnvelopeId());
                                        if(previousEnvelopeId != tblTenderForm.getTblTenderEnvelope().getEnvelopeId() && previousEnvelopeId != 0) {
                                        tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(previousEnvelopeId);
                                        }
                                    }
                                    else if(corgPenging && tenderFormService.isEnvelopePending(tblTenderForm.getTblTenderEnvelope().getEnvelopeId())){
                                       tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(tblTenderForm.getTblTenderEnvelope().getEnvelopeId());
                                       if(previousEnvelopeId != tblTenderForm.getTblTenderEnvelope().getEnvelopeId() && previousEnvelopeId != 0) {
                                       tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(previousEnvelopeId);
                                       }
                                    }
                                }
                                //Ended by Mitesh
    				retVal=success?TENDER_DASHBOARD_URL+tenderId+"/2":"etender/buyer/editform/"+tenderId+"/"+formId;
    				retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    			}
    		}
    	}
    	catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editFormLinkId, postEditFormRemark, tenderId,formId);
    	}
    	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_update_form" : CommonKeywords.ERROR_MSG_KEY.toString());
    	return retVal;
    }
    
    /**
     * Ajax call for check whether form is rebate or not
     * 
     * @return
     */
    @RequestMapping(value = "/buyer/isRebatForm", method = RequestMethod.POST)
    @ResponseBody
    public String isRebatForm(@RequestParam("txtFormId") int formId, HttpServletRequest request){
    	Boolean result = false;
    	try{
    		result = tenderFormService.getRebateFormByFormId(formId);
    	}
    	catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deleteFormLinkId, postAjaxDeleteFormAudit, formId,0);
    	}
    	return result.toString();
    }
    
    
    
    /**
     * Ajax call for check whether form is form complete  or not
     * 
     * @return
     */
    @RequestMapping(value = "/buyer/isFormComplete", method = RequestMethod.POST)
    @ResponseBody
    public String isFormComplete(HttpServletRequest request){
    	Boolean result = false;
    	ArrayList<Integer> tableStatus = new ArrayList<Integer>();
    	try{
    		int formId = StringUtils.hasLength(request.getParameter("hdFormId")) && !"".equals(request.getParameter("hdFormId"))? Integer.parseInt(request.getParameter("hdFormId")):0;
    		List<Object[]> list = null;
    		list = tenderFormService.getFormCompleteStatus(formId);
    		if(list!=null && !list.isEmpty())
    		{
    			for (Object[] objects : list) {
        			if((Integer)objects[3] > 0 && (Integer)objects[1] == 0 && (Integer)objects[2] == 0 ){//condition for form complete 
        				tableStatus.add(1);
    				} else {
        				tableStatus.add(0);
        			}	
    			}
    		}	
			if (!tableStatus.contains(0)) {
				result = true;
			}
    	}
    	catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deleteFormLinkId, postAjaxDeleteFormAudit, 0,0);
    	}
    	return result.toString();
    }
    
   /**
     * Delete Form
     * 
     * @author purvesh
     * @param tenderId
     * @param formId
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value="/buyer/deleteform/{tenderId}/{formId}/{enc}", method=RequestMethod.GET)
    public String deleteForm(@PathVariable(TENDER_ID)int tenderId, @PathVariable(FORM_ID)int formId, HttpServletRequest request, RedirectAttributes redirectAttributes){
    	String redirectUrl = "etender/buyer/tenderdashboard/";
    	String retVal="redirect:/"+redirectUrl+tenderId+"/2"+encryptDecryptUtils.generateRedirect(redirectUrl+tenderId+"/2", request);
    	boolean success = false;
    	try {
            int corrigendumId=tenderCorrigendumService.getPendingCorrigendumId(tenderId);
            tenderCorrigendumService.deleteFormEntryFromCorrigendum(corrigendumId,formId);
			int envelopeId= tenderFormService.getEnvelopeIdByFormId(formId);
			success =tenderFormService.deleteTblTenderFormLibrary(formId) && tenderFormService.deleteForm(tenderId, formId);
                        //Added by Mitesh
                        if(success){
                            boolean corgPenging=tenderCorrigendumService.isCorrigendumPending(tenderId);
                            if(!corgPenging){
                                tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(envelopeId);
                            }
                            else if(corgPenging && tenderFormService.isEnvelopePending(envelopeId)){
                                tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(envelopeId);
                            }
                            else if(corgPenging && tenderFormService.isEnvelopePublishPending(envelopeId)){
                                tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(envelopeId);
                            }
                        }
                        //Ended by Mitesh
			redirectAttributes.addFlashAttribute(success?CommonKeywords.SUCCESS_MSG.toString():CommonKeywords.ERROR_MSG.toString(), success?"msg_delete_form":CommonKeywords.ERROR_MSG_KEY.toString());
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		} finally{
			 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),deleteFormLinkId, getDeleteFormAudit, tenderId,formId);
		}
    	return retVal;
    }
    

    /**
     * Create Form Matrix GET
     *
     * @param tenderId
     * @param formOperation
     * @param fromDash
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/createformmatrix/{tenderId}/{formId}/{tableId}/{formOperation}/{fromDash}/{enc}", method = RequestMethod.GET)
    public String createFormMatrix(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, @PathVariable("tableId") Integer tableId, @PathVariable("formOperation") String formOperation, @PathVariable("fromDash") Integer fromDash, ModelMap modelMap, HttpServletRequest request) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> list = tenderFormService.getTableDetails(formId, tableId);
            int clientId = abcUtility.getSessionClientId(request);
            modelMap.addAttribute("isCatReq", abcUtility.isModuleAssignToClient(request, 9));
            int rowCount = 0;
            int eventTypeId = 0;
            boolean isLoadingFacPresent = false;
//            List<Object[]> tenderFields = new ArrayList<Object[]>();
//            tenderFields.add(new Object[]{1,1,1,1,1});            
            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "tenderMode,tenderResult,biddingType,decimalValueUpto,isEMDByBidder,isProcessingFeeByBidder,isDocumentFeeByBidder,winningReportMode,tblEventType.eventTypeId,envelopeType,isTwoStageEvaluation,isParticipationFeesBy");
            if (!tenderFields.isEmpty()) {
            	
                int tenderResult = (Integer) tenderFields.get(0)[1];
                boolean isICB = (Integer) tenderFields.get(0)[2] == 2;
                boolean isOpenTender = (Integer) tenderFields.get(0)[0] == 1;
                boolean isGTWise = false;
                int winningReportMode = (Integer) tenderFields.get(0)[7];
                eventTypeId = (Integer) tenderFields.get(0)[8];
                List<Object[]> columnDtls = tenderFormService.getColumnDetailByClient(clientId,eventTypeId);
                if (list != null && !list.isEmpty()) {
                    isGTWise = (Integer) list.get(0)[5] == 1;
                    if (isGTWise) {
                        rowCount = (Integer) list.get(0)[0];
                    }
                    modelMap.addAttribute("rowcount", isGTWise ? ((Integer) list.get(0)[0] - 1) : (Integer) list.get(0)[0]);
                    modelMap.addAttribute("colcount", list.get(0)[1]);
                    modelMap.addAttribute("tableName", list.get(0)[2]);
                    modelMap.addAttribute("hasGTRow", list.get(0)[5]);
                    modelMap.addAttribute("isOpenTender", isOpenTender);
                    modelMap.addAttribute(TABLE_ID, tableId);
                }
                modelMap.addAttribute("isICB", isICB);
                modelMap.addAttribute("tenderResult", tenderResult);
                modelMap.addAttribute("dataType", tenderFormService.getDataType());
                modelMap.addAttribute("showHide", tenderFormService.getShowHide());
                modelMap.addAttribute("winningReportMode", winningReportMode);
                
                if (isICB) {
                    modelMap.addAttribute("currConv", tenderFormService.getCurrConv());
                }

                boolean priceBid = tenderFormService.getIsPriceBidForm(formId);
                //1 for CPV Category, 2 for Manual Category
                if(priceBid){
                    int categoryType =  commonService.getClientCategoryType(clientId);
                    modelMap.addAttribute("categoryType", categoryType);
                }
                modelMap.addAttribute("pricebid", priceBid);
                if(priceBid){
                    List<SelectItem> columnType = abcUtility.convert(columnDtls);
                    List<SelectItem> columnTypes = new ArrayList<SelectItem>();
                    JSONObject jsonObject=new JSONObject();
                    Map<String,String> coulmnTypeMap = new HashMap<String, String>();
                    
                    if(columnDtls != null && !columnDtls.isEmpty()){
	                    for (Object[] columns : columnDtls) {
	                    	if((Integer)columns[0] != emdAmountId  && (Integer)columns[0] != emdOfficerAmountId && (Integer)columns[0] != docfeesOfficerAmountId && (Integer)columns[0] != participationOfficerAmountId && (Integer)columns[0] != processingFeesId && (Integer)columns[0] != documentFeesId && (Integer)columns[0] != encNotReq && (Integer)columns[0] != loadingFactor ){
	                    		jsonObject.put("coltype_"+columns[0], columns[2]+"~~"+0+"@@"+columns[1]);// json : isMendetory~~counter@@columnName
	                    	}
	                    	coulmnTypeMap.put("coltype_"+columns[0], columns[2]+"~~"+0+"@@"+columns[1]);
						}
                	}
                
                    for (SelectItem colType : columnType) {
                        if((Integer)colType.getValue()==emdAmountId){
                            if((Integer)tenderFields.get(0)[4]==1){                                
                                columnTypes.add(colType);
                                jsonObject.put("coltype_"+emdAmountId, coulmnTypeMap.get("coltype_"+emdAmountId));
                            }
                            continue;
                        }
                        if((Integer)colType.getValue()==processingFeesId){
                            if((Integer)tenderFields.get(0)[5]==1){                                
                                columnTypes.add(colType);
                                jsonObject.put("coltype_"+processingFeesId, coulmnTypeMap.get("coltype_"+emdAmountId));
                            }
                            continue;
                        }
                        if((Integer)colType.getValue()==documentFeesId){
                            if((Integer)tenderFields.get(0)[6]==1){                                
                                columnTypes.add(colType);
                                jsonObject.put("coltype_"+documentFeesId, coulmnTypeMap.get("coltype_"+documentFeesId));
                            }
                            continue;
                        }
                        if((Integer)colType.getValue()==docfeesOfficerAmountId){
                            if((Integer)tenderFields.get(0)[6]==2){                                
                                columnTypes.add(colType);
                                jsonObject.put("coltype_"+docfeesOfficerAmountId, coulmnTypeMap.get("coltype_"+docfeesOfficerAmountId));
                            }
                            continue;
                        }
                        if((Integer)colType.getValue()==participationOfficerAmountId){
                            if((Integer)tenderFields.get(0)[11]==1){                                
                                columnTypes.add(colType);
                                jsonObject.put("coltype_"+participationOfficerAmountId, coulmnTypeMap.get("coltype_"+participationOfficerAmountId));
                            }
                            continue;
                        }
                        if((Integer)colType.getValue()==emdOfficerAmountId){
                            if((Integer)tenderFields.get(0)[4]==2){                                
                                columnTypes.add(colType);
                                jsonObject.put("coltype_"+emdOfficerAmountId, coulmnTypeMap.get("coltype_"+emdOfficerAmountId));
                            }
                            continue;
                        }
                        if((Integer)colType.getValue()==encNotReq){
                            if((Integer)tenderFields.get(0)[9]==2){                                
                                columnTypes.add(colType);
                                jsonObject.put("coltype_"+encNotReq, coulmnTypeMap.get("coltype_"+encNotReq));
                            }
                            continue;
                        }
                        if((Integer)colType.getValue()==loadingFactor){
                            if(tenderResult==2){
                            	isLoadingFacPresent = true;
                                columnTypes.add(colType);
                                jsonObject.put("coltype_"+loadingFactor, coulmnTypeMap.get("coltype_"+loadingFactor));
                            }
                            continue;
                        }
                        if((Integer)colType.getValue()==autoLoadingTotal){
                        	if(tenderResult==2){
	                            columnTypes.add(colType);
	                            jsonObject.put("coltype_"+autoLoadingTotal, coulmnTypeMap.get("coltype_"+autoLoadingTotal));
                        	}
                        	continue;
                        }
                        if((Integer)colType.getValue()==unitRateAfterLoading){
                        	if(tenderResult==2){
	                            columnTypes.add(colType);
	                            jsonObject.put("coltype_"+unitRateAfterLoading, coulmnTypeMap.get("coltype_"+unitRateAfterLoading));
                        	}
                        	continue;
                        }
                        columnTypes.add(colType);
                    } 
                    
                    modelMap.addAttribute("columnType", columnTypes);
                    modelMap.addAttribute("jsonObject", jsonObject);
                }
                
                List<TblTenderColumn> columns = tenderFormService.getTenderColumnByTableId(tableId);
                modelMap.addAttribute("columns", columns);
                modelMap.addAttribute("filledBy", tenderFormService.getFilledBy(!isOpenTender || isLoadingFacPresent));
                if (!columns.isEmpty()) {
                    List<TblTenderCell> cells = null;
                    String tableJson = tenderFormService.getTableJson(tableId);
                    if (StringUtils.hasLength(tableJson)) {
                        cells = tenderFormService._toCellMasters(tableJson);
                    } else {
                        cells = tenderFormService.getTenderCellByTableId(tableId, isGTWise ? (rowCount) : 0);
                    }
                    modelMap.addAttribute("cells", cells);
                }
                modelMap.addAttribute("decimalUpto", tenderFields.get(0)[3]);
                List<Object[]> combo = tenderFormService.getClientCombo(clientId);
                List<SelectItem> clientCombo = new ArrayList<SelectItem>();
                List<SelectItem> clientListBox = new ArrayList<SelectItem>();
                for (Object[] cmb : combo) {
                    if((Integer)cmb[2]==1){
                        clientCombo.add(new SelectItem(cmb[1], cmb[0]));
                    }else if((Integer)cmb[2]==2){
                        clientListBox.add(new SelectItem(cmb[1], cmb[0]));
                    }
                }                
                modelMap.addAttribute("clientCombo", clientCombo);
                modelMap.addAttribute("clientListBox", clientListBox);
                modelMap.addAttribute("masterField", abcUtility.convert(tenderFormService.getBidderMasterField(bidderMasterField)));
                modelMap.addAttribute("isMVPVertical", clientService.isClientMVPVertical(abcUtility.getSessionClientId(request), mvpSectorId));
            }

        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), formOperation.equals("1") ? bidFormCreate : bidFormEdit, createFormMatrixAudit, tenderId, tableId);
        }
        return "/etender/buyer/CreateFormMatrix";
    }

    @RequestMapping(value = "/buyer/tendertables/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)
    public String getTenderTables(@PathVariable("tenderId") int tenderId, @PathVariable("formId") int formId, ModelMap modelMap, HttpServletRequest request) {
        try {
            List<Object> data = tenderFormService.getNoOfTables(formId);
            modelMap.addAttribute("tableCount", data != null && !data.isEmpty() ? Integer.parseInt(data.get(0).toString()) : 1);
            modelMap.addAttribute("yesNoList", commonService.getYesNo());
            modelMap.addAttribute("isPriceBid",tenderFormService.getIsPriceBidForm(formId));
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addMultipleTableLinkId, getTenderTablesRemark, tenderId, 0);
        }
        return "etender/buyer/TenderTable";
    }

    @RequestMapping(value = "/buyer/addtendertables", method = RequestMethod.POST)
    public String addTenderTables(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/sessionexpired";
        int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
        try {
            int tableCount = StringUtils.hasLength(request.getParameter("txtRowCnt")) ? Integer.parseInt(request.getParameter("txtRowCnt")) : 0;
            //int envelopeId=StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")) : 0;
            int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
            int userId = abcUtility.getSessionUserDetailId(request);
            String[] tableName = new String[tableCount];
            String[] tableHeader = new String[tableCount];
            String[] tableFooter = new String[tableCount];
            int[] noOfRows = new int[tableCount];
            int[] noOfCols = new int[tableCount];
            int[] isMultFilling = new int[tableCount];
            int[] isMandatory = new int[tableCount];
            int[] isPartialFillingAllowed = new int[tableCount];
            boolean bool = false;
            boolean success = false;
            List<TblTenderTable> tenderTableList = new ArrayList<TblTenderTable>();
            TblTenderTable tblTenderTable = null;
            if (tenderId != 0 && userId != 0) {
                for (int i = 0; i < tableCount; i++) {
                    tableName[i] = StringUtils.hasLength(request.getParameter("txtaTableName_" + i)) ? request.getParameter("txtaTableName_" + i) : "";
                    tableHeader[i] = StringUtils.hasLength(request.getParameter("rtfTableHeader_" + i)) ? request.getParameter("rtfTableHeader_" + i) : ""; /*Changes Bug Id:29383*/
                    tableFooter[i] = StringUtils.hasLength(request.getParameter("rtfTableFooter_" + i)) ? request.getParameter("rtfTableFooter_" + i) : "";
                    noOfRows[i] = StringUtils.hasLength(request.getParameter("txtNoOfRows_" + i)) ? Integer.parseInt(request.getParameter("txtNoOfRows_" + i)) : 0;
                    noOfCols[i] = StringUtils.hasLength(request.getParameter("txtNoOfCols_" + i)) ? Integer.parseInt(request.getParameter("txtNoOfCols_" + i)) : 0;
                    isMultFilling[i] = StringUtils.hasLength(request.getParameter("selIsMultipleFilling_" + i)) ? Integer.parseInt(request.getParameter("selIsMultipleFilling_" + i)) : 0;
                    isMandatory[i]= StringUtils.hasLength(request.getParameter("selIsMandatory_"+i)) ? Integer.parseInt(request.getParameter("selIsMandatory_"+i)) : 0;
                    isPartialFillingAllowed[i] = StringUtils.hasLength(request.getParameter("selPartialFillingAllowed_"+i))?Integer.parseInt(request.getParameter("selPartialFillingAllowed_"+i)):0;
                }
                for (int i = 0; i < tableCount; i++) {
                    if ("".equals(tableName[i]) || noOfRows[i] == 0 || noOfCols[i] == 0 || isMultFilling[i] == -1) {
                        bool = true;
                    } else {
                        tblTenderTable = new TblTenderTable();
                        tblTenderTable.setHasGTRow(0);
                        tblTenderTable.setSortOrder((i + 1));
                        tblTenderTable.setIsMultipleFilling(isMultFilling[i]);
                        tblTenderTable.setNoOfCols(noOfCols[i]);
                        tblTenderTable.setNoOfRows(noOfRows[i]);
                        tblTenderTable.setCreatedBy(userId);
                        tblTenderTable.setTableFooter(tableFooter[i]);
                        tblTenderTable.setTableHeader(tableHeader[i]);
                        tblTenderTable.setTableName(tableName[i]);
                        tblTenderTable.setTblTenderForm(new TblTenderForm(formId));
                        tblTenderTable.setUpdatedBy(userId);
                        tblTenderTable.setUpdatedOn(commonService.getServerDateTime());
                        tblTenderTable.setIsPartialFillingAllowed(isPartialFillingAllowed[i]);
                        tblTenderTable.setIsMandatory(isMandatory[i]);
                        tenderTableList.add(tblTenderTable);
                    }
                }
                if (bool) {
                    retVal = "redirect:/etender/buyer/tendertables/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/tendertables/" + tenderId + "/" + formId, request);
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                } else {
                    success = tenderFormService.addTenderTable(tenderTableList);
                    if(success){//update the mandatory table counter into the form for minTablesReqForBidding.
                    	tenderFormService.getAndUpdateNoOfMandatoryBiddingTables(formId);
                    }
                    redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_add_table" : CommonKeywords.ERROR_MSG_KEY.toString());
                    retVal = "redirect:/etender/buyer/formdashboard/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/formdashboard/" + tenderId + "/" + formId, request);
                }
            }
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addMultipleTableLinkId, postTenderTablesRemark, tenderId, 0);
        }
        return retVal;
    }

    @RequestMapping(value = "/buyer/gettendertable/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)
    public String getTenderTable(@PathVariable("tenderId") int tenderId, @PathVariable("formId") int formId, ModelMap modelMap, HttpServletRequest request) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("yesNoList", commonService.getYesNo());
            modelMap.addAttribute("isPriceBid",tenderFormService.getIsPriceBidForm(formId));
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addTableLinkId, getAddTenderTableRemark, tenderId, 0);
        }
        return "etender/buyer/AddTenderTable";
    }

    @RequestMapping(value = "/buyer/addtendertable", method = RequestMethod.POST)
    public String addTenderTable(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/sessionexpired";
        int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        try {
            //int envelopeId=StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")) : 0;
            int userId = abcUtility.getSessionUserDetailId(request);
            boolean bool = false;
            boolean success = false;
            TblTenderTable tblTenderTable = null;
            if (tenderId != 0 && userId != 0) {
                String tableName = StringUtils.hasLength(request.getParameter("txtaTableName")) ? request.getParameter("txtaTableName") : "";
                String tableHeader = StringUtils.hasLength(request.getParameter("rtfTableHeader")) ? request.getParameter("rtfTableHeader") : ""; /*Changes Bug Id:29383*/
                String tableFooter = StringUtils.hasLength(request.getParameter("rtfTableFooter")) ? request.getParameter("rtfTableFooter") : "";
                int noOfRows = StringUtils.hasLength(request.getParameter("txtNoOfRows")) ? Integer.parseInt(request.getParameter("txtNoOfRows")) : 0;
                int noOfCols = StringUtils.hasLength(request.getParameter("txtNoOfCols")) ? Integer.parseInt(request.getParameter("txtNoOfCols")) : 0;
                int isMultFilling = StringUtils.hasLength(request.getParameter("selIsMultipleFilling")) ? Integer.parseInt(request.getParameter("selIsMultipleFilling")) : 0;
                int isMandatory= StringUtils.hasLength(request.getParameter("selIsMandatory")) ? Integer.parseInt(request.getParameter("selIsMandatory")) : 0;
                int isPartialFillingAllowed = StringUtils.hasLength(request.getParameter("selPartialFillingAllowed"))?Integer.parseInt(request.getParameter("selPartialFillingAllowed")):0;
                if ("".equals(tableName) || noOfRows == 0 || noOfCols == 0 || isMultFilling == -1) {
                    bool = true;
                } else {
                    tblTenderTable = new TblTenderTable();
                    long tableCount = tenderFormService.getTableCountForSortOrder(formId);
                    tblTenderTable.setHasGTRow(0);
                    tblTenderTable.setSortOrder((int) (tableCount + 1));
                    tblTenderTable.setIsMultipleFilling(isMultFilling);
                    tblTenderTable.setNoOfCols(noOfCols);
                    tblTenderTable.setNoOfRows(noOfRows);
                    tblTenderTable.setCreatedBy(userId);
                    tblTenderTable.setTableFooter(tableFooter);
                    tblTenderTable.setTableHeader(tableHeader);
                    tblTenderTable.setTableName(AbcUtility.reverseReplaceSpecialChars(tableName)); //approved of shreyansh
                    tblTenderTable.setTblTenderForm(new TblTenderForm(formId));
                    tblTenderTable.setUpdatedBy(userId);
                    tblTenderTable.setUpdatedOn(commonService.getServerDateTime());
                    tblTenderTable.setIsPartialFillingAllowed(isPartialFillingAllowed);
                    tblTenderTable.setIsMandatory(isMandatory);
                    //tenderTableList.add(tblTenderTable);
                }
                if (bool) {
                    retVal = "redirect:/etender/buyer/gettendertable/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/gettendertable/" + tenderId + "/" + formId, request);
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                } else {
                    success = tenderFormService.addTenderTable(tblTenderTable);
                    if(success){//update the mandatory table counter into the form for minTablesReqForBidding.
                    	success=tenderFormService.getAndUpdateNoOfMandatoryBiddingTables(formId);
                    }
                    redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_add_table" : CommonKeywords.ERROR_MSG_KEY.toString());
                    retVal = "redirect:/etender/buyer/formdashboard/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/formdashboard/" + tenderId + "/" + formId, request);
                }
            }
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addTableLinkId, postAddTenderTableRemark, tenderId, 0);
        }
        return retVal;
    }

    @RequestMapping(value = "/buyer/getedittendertable/{tenderId}/{formId}/{tableId}/{enc}", method = RequestMethod.GET)
    public String getEditTenderTable(@PathVariable("tableId") int tableId, @PathVariable("tenderId") int tenderId, @PathVariable("formId") int formId, ModelMap modelMap, HttpServletRequest request) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("yesNoList", commonService.getYesNo());
            modelMap.addAttribute("tenderTableList", tenderFormService.getTenderTableDetails(tableId));
            modelMap.addAttribute("isPriceBid",tenderFormService.getIsPriceBidForm(formId));
            modelMap.addAttribute("isMVPVertical", clientService.isClientMVPVertical(abcUtility.getSessionClientId(request), mvpSectorId));
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editTableLinkId, getEditTenderTableRemark, tenderId, 0);
        }
        return "etender/buyer/AddTenderTable";
    }

    @RequestMapping(value = "/buyer/updatetendertable", method = RequestMethod.POST)
    public String updateTenderTable(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/sessionexpired";
        int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
        int tableId = StringUtils.hasLength(request.getParameter("hdTableId")) ? Integer.parseInt(request.getParameter("hdTableId")) : 0;
        try {
            int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
            int sortOrder = StringUtils.hasLength(request.getParameter("hdSortOrder")) ? Integer.parseInt(request.getParameter("hdSortOrder")) : 0;
            int hasGTRow = StringUtils.hasLength(request.getParameter("hdHasGTRow")) ? Integer.parseInt(request.getParameter("hdHasGTRow")) : 0;
            int radioId = StringUtils.hasLength(request.getParameter("rdFormOpr")) ? Integer.parseInt(request.getParameter("rdFormOpr")) : 0;
            int userId = abcUtility.getSessionUserDetailId(request);
            boolean bool = false;
            boolean success = false;
            TblTenderTable tblTenderTable = null;
            if (tenderId != 0 && userId != 0) {
                String tableName = StringUtils.hasLength(request.getParameter("txtaTableName")) ? request.getParameter("txtaTableName") : "";
                String tableHeader = StringUtils.hasLength(request.getParameter("rtfTableHeader")) ? request.getParameter("rtfTableHeader") : ""; /*Changes Bug Id:29383*/
                String tableFooter = StringUtils.hasLength(request.getParameter("rtfTableFooter")) ? request.getParameter("rtfTableFooter") : "";
                int noOfRows = StringUtils.hasLength(request.getParameter("txtNoOfRows")) ? Integer.parseInt(request.getParameter("txtNoOfRows")) : 0;
                int noOfCols = StringUtils.hasLength(request.getParameter("txtNoOfCols")) ? Integer.parseInt(request.getParameter("txtNoOfCols")) : 0;
                int isMultFilling = StringUtils.hasLength(request.getParameter("selIsMultipleFilling")) ? Integer.parseInt(request.getParameter("selIsMultipleFilling")) : 0;
                int isMandatory= StringUtils.hasLength(request.getParameter("selIsMandatory")) ? Integer.parseInt(request.getParameter("selIsMandatory")) : 0;
                int isPartialFillingAllowed = StringUtils.hasLength(request.getParameter("selPartialFillingAllowed"))?Integer.parseInt(request.getParameter("selPartialFillingAllowed")):0;
                if (isMultFilling == -1) {
                    bool = true;
                } else {
                    tblTenderTable = new TblTenderTable();
                    tblTenderTable.setTableId(tableId);
                    tblTenderTable.setHasGTRow(hasGTRow);
                    tblTenderTable.setSortOrder(sortOrder);
                    tblTenderTable.setIsMultipleFilling(isMultFilling);
                    tblTenderTable.setNoOfCols(noOfCols);
                    tblTenderTable.setNoOfRows(noOfRows);
                    tblTenderTable.setCreatedBy(userId);
                    tblTenderTable.setTableFooter(tableFooter);
                    tblTenderTable.setTableHeader(tableHeader);
                    tblTenderTable.setTableName(AbcUtility.reverseReplaceSpecialChars(tableName)); //approved of shreyansh
                    tblTenderTable.setTblTenderForm(new TblTenderForm(formId));
                    tblTenderTable.setUpdatedBy(userId);
                    tblTenderTable.setUpdatedOn(commonService.getServerDateTime());
                    tblTenderTable.setIsPartialFillingAllowed(isPartialFillingAllowed);
                    tblTenderTable.setIsMandatory(isMandatory);
                    //tenderTableList.add(tblTenderTable);
                }
                if (bool) {
                    retVal = "redirect:/etender/buyer/getedittendertable/" + tenderId + "/" + formId + "/" + tableId + encryptDecryptUtils.generateRedirect("etender/buyer/getedittendertable/" + tenderId + "/" + formId + "/" + tableId, request);
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                } else {
                    success = tenderFormService.updateTenderTable(tblTenderTable);
                    if(success){//update the mandatory table counter into the form for minTablesReqForBidding.
                    	success=tenderFormService.getAndUpdateNoOfMandatoryBiddingTables(formId);
                    }
                    redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_update_table" : CommonKeywords.ERROR_MSG_KEY.toString());
                    if (radioId == 1) {
                        retVal = "redirect:/etender/buyer/formdashboard/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/formdashboard/" + tenderId + "/" + formId, request);
                    } else {
                        retVal = "redirect:/etender/buyer/createformmatrix/" + tenderId + "/" + formId + "/" + tableId + "/" + radioId + "/1" + encryptDecryptUtils.generateRedirect("etender/buyer/createformmatrix/" + tenderId + "/" + formId + "/" + tableId + "/" + radioId + "/1", request);
                    }
                }
            }
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editTableLinkId, postUpdateTenderTableRemark, tenderId, tableId);
        }
        return retVal;
    }

    @RequestMapping(value = "/buyer/addformmatrix", method = RequestMethod.POST)
    public String addFormMatrix(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
//        boolean hasGTRow = StringUtils.hasLength(request.getParameter("hdHasGTRow")) ? Integer.parseInt(request.getParameter("hdHasGTRow"))==1 : false;
        int tableId = StringUtils.hasLength(request.getParameter(HIDDEN_TABLE_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TABLE_ID)) : 0;
        boolean priceBid = StringUtils.hasLength(request.getParameter("hdPriceBid")) ? Boolean.parseBoolean(request.getParameter("hdPriceBid")) : false;
        String fromDash = StringUtils.hasLength(request.getParameter(FROM_DASH)) ? request.getParameter(FROM_DASH) : "0";
        int autoColCnt = 0;
        int formOperation = StringUtils.hasLength(request.getParameter("hdFormOperation")) ? Integer.parseInt(request.getParameter("hdFormOperation")) : 0;
        if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            int col = StringUtils.hasLength(request.getParameter("txtCol")) ? Integer.parseInt(request.getParameter("txtCol")) : 0;
            int row = StringUtils.hasLength(request.getParameter("txtRow")) ? Integer.parseInt(request.getParameter("txtRow")) : 0;
            try {
                int userId = abcUtility.getSessionUserDetailId(request);
                int tenderResult = StringUtils.hasLength(request.getParameter("hdTenderResult")) ? Integer.parseInt(request.getParameter("hdTenderResult")) : 0;
                boolean isGTWise = tenderResult != 2;
                List<Object[]> allFormula = tenderFormService.getFormulaColId(tableId);
                /*boolean hasGT = false;
                for (Object[] formula : allFormula) {
//                    System.out.println("formula[0] :: "+formula[0]);
                    if (formula[2].toString().startsWith(TOTAL)) {
                        hasGT = true;
                        break;
                    }
                }*/
                Set<Integer> changedColId = new HashSet<Integer>();
				Set<Integer> changedColNo = new HashSet<Integer>();
                StringBuilder proxyCols = new StringBuilder();
//                StringBuilder bidderCols = new StringBuilder();// todo not in tender
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("tenderId", tenderId);
                params.put("isPriceBid", priceBid);
                Map<String, Boolean> operation = new HashMap<String, Boolean>();
                switch (formOperation) {
                    case 1:// Update with none of the below given operations/Fresh Insert 
                    case 3:// I want to update Data Type, Filled by option[updateall]
                    case 4:// I want to update form with Add Column operation[updateall]
                    case 5://I want to update form with Delete Column operation[DeleteInsert]
                    case 6://I want to update form with Add Row/Delete Row operation
                        List<TblTenderColumn> tenderColumns = new ArrayList<TblTenderColumn>();
                        List<TblTenderCell> tenderCells = new ArrayList<TblTenderCell>();
                        //Filled By - Auctioner:1, Bidder:2, Auto:3, Proxy Bid Column:4
                        //Data Type - SmallText:1, LongText:2, +No. with (.):3, +No. without (.):4, All Numbers:8
                        int cellNo = 0;
                        boolean delAllFormula = false;
                        for (int i = 0; i < col; i++) {
                            TblTenderColumn tenderColumn = new TblTenderColumn();
                            tenderColumn.setColumnHeader(request.getParameter("txtacolHeader_" + i));
                            tenderColumn.setTblTenderForm(new TblTenderForm(formId));
                            tenderColumn.setDataType(Integer.parseInt(StringUtils.hasLength(request.getParameter("selDataType_" + i)) ? request.getParameter("selDataType_" + i) : StringUtils.hasLength(request.getParameter(HDDATATYPE + i)) ? request.getParameter(HDDATATYPE + i) : "0"));
                            tenderColumn.setFilledBy(Integer.parseInt(StringUtils.hasLength(request.getParameter("selFilledBy_" + i)) ? request.getParameter("selFilledBy_" + i) : StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) ? request.getParameter(HDDFILLEDBY + i) : "0"));
                            if(tenderColumn.getFilledBy()==auto){
                                autoColCnt++;
                            }
                            tenderColumn.setIsShown(Integer.parseInt(StringUtils.hasLength(request.getParameter("selShowHide_" + i)) ? request.getParameter("selShowHide_" + i) : StringUtils.hasLength(request.getParameter("hdShowHide_" + i)) ? request.getParameter("hdShowHide_" + i) : "0"));
                            if (tenderColumn.getDataType() == smalltext || tenderColumn.getDataType() == longtext) {
                                tenderColumn.setIsCurrConvReq(0);
                            } else {
                                tenderColumn.setIsCurrConvReq(Integer.parseInt(StringUtils.hasLength(request.getParameter("selCurrConv_" + i)) ? request.getParameter("selCurrConv_" + i) : StringUtils.hasLength(request.getParameter("hdCurrConv_" + i)) ? request.getParameter("hdCurrConv_" + i) : "0"));
                            }
                            tenderColumn.setColumnNo(i + 1);
                            tenderColumn.setSortOrder(Integer.parseInt(StringUtils.hasLength(request.getParameter("txtColSortOrder_" + i)) ? request.getParameter("txtColSortOrder_" + i) : "0"));
                            tenderColumn.setTblTenderTable(new TblTenderTable(tableId));
                            tenderColumn.setTblColumnType(new TblColumnType(!priceBid ? (6) : (Integer.parseInt(StringUtils.hasLength(request.getParameter("selColumnType_" + i)) ? request.getParameter("selColumnType_" + i) : StringUtils.hasLength(request.getParameter("hdColumnType_" + i)) ? request.getParameter("hdColumnType_" + i) : "0"))));
                            if (formOperation == 3 || formOperation == 4 || formOperation == 6) {
                                tenderColumn.setColumnId(StringUtils.hasLength(request.getParameter(HDCOLUMNID + i)) ? Integer.parseInt(request.getParameter(HDCOLUMNID + i)) : 0);
                            }
                            if (formOperation == 3 || formOperation == 4) {
                                boolean proxyColSet = false;
                                if (StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) == 4 && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) != tenderColumn.getFilledBy()) {
                                    proxyCols.append(request.getParameter(HDCOLUMNID + i)).append(",");
                                    proxyColSet = true;
                                }
                                if (!proxyColSet && StringUtils.hasLength(request.getParameter(HDDATATYPE + i)) && tenderColumn.getDataType() != Integer.parseInt(request.getParameter(HDDATATYPE + i))) {
                                    proxyCols.append(request.getParameter(HDCOLUMNID + i)).append(",");
                                }
                                /*String aucbidderWiseForm = auctionCommonService.getAuctionSelectedField(auctionId, "showBidderWiseForm");// todo not in tender
                                 if ((StringUtils.hasLength(aucbidderWiseForm) ? Integer.parseInt(aucbidderWiseForm) == 1 : false) && StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) != 2 && auctionColumn.getFilledBy() == 2) {
                                 bidderCols.append(request.getParameter(HDCOLUMNID + i)).append(",");
                                 }*/
                            }
                            if(formOperation != 5 && !allFormula.isEmpty()){
                                if (StringUtils.hasLength(request.getParameter("hdColSortOrder_" + i)) && tenderColumn.getSortOrder() != Integer.parseInt(request.getParameter("hdColSortOrder_" + i))) {
                                    delAllFormula = true;                                   
                                }
                            }
                            if ((formOperation == 3 || formOperation == 4) && !allFormula.isEmpty()) {
                                if (StringUtils.hasLength(request.getParameter(HDDATATYPE + i)) && tenderColumn.getDataType() != Integer.parseInt(request.getParameter(HDDATATYPE + i))) {
                                    if (Integer.parseInt(request.getParameter(HDDATATYPE + i)) == money) {
                                        if (!(tenderColumn.getDataType() == numeric || tenderColumn.getDataType() == moneyall)) {
                                            changedColId.add(Integer.parseInt(request.getParameter(HDCOLUMNID + i)));
											changedColNo.add((i+1));
                                        }
                                    } else if (Integer.parseInt(request.getParameter(HDDATATYPE + i)) == numeric) {
                                        if (!(tenderColumn.getDataType() == money || tenderColumn.getDataType() == moneyall)) {
                                            changedColId.add(Integer.parseInt(request.getParameter(HDCOLUMNID + i)));
											changedColNo.add((i+1));
                                        }
                                    } else if (Integer.parseInt(request.getParameter(HDDATATYPE + i)) == moneyall) {
                                        if (!(tenderColumn.getDataType() == money || tenderColumn.getDataType() == numeric)) {
                                            changedColId.add(Integer.parseInt(request.getParameter(HDCOLUMNID + i)));
											changedColNo.add((i+1));
                                        }
                                    }
                                }
                                if (StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && tenderColumn.getFilledBy() != Integer.parseInt(request.getParameter(HDDFILLEDBY + i))) {
                                    changedColId.add(Integer.parseInt(request.getParameter(HDCOLUMNID + i)));
									changedColNo.add((i+1));
                                }
                            }
                            for (int j = 0; j < row; j++) {
                                TblTenderCell tenderCell = new TblTenderCell();
                                tenderCell.setCellNo(cellNo);
                                tenderCell.setTblTenderForm(new TblTenderForm(formId));
                                tenderCell.setRowId(Integer.parseInt(StringUtils.hasLength(request.getParameter("txtRowSort_" + j)) ? request.getParameter("txtRowSort_" + j) : "0"));
                                tenderCell.setTblTenderColumn(tenderColumn);
                                tenderCell.setTblTenderTable(new TblTenderTable(tableId));
                                if (tenderColumn.getFilledBy() == 1) {
                                    String[] cellValues = request.getParameterValues("txtcell_" + j + "_" + i);
                                    if (tenderColumn.getDataType() == longtext && cellValues==null) {
                                        tenderCell.setCellValue(request.getParameter("txtacell_" + j + "_" + i));
                                    } else {                                        
                                        if(cellValues.length==2){
//                                            System.out.println(cellValues[0]+ " : "+cellValues[1]);
                                            tenderCell.setObjectId(Integer.parseInt(cellValues[0]));
                                            tenderCell.setCellValue(cellValues[1]);
                                        }else if(cellValues.length==3){
//                                            System.out.println(cellValues[1]+ " : "+cellValues[2]);
                                            tenderCell.setObjectId(Integer.parseInt(cellValues[1]));
                                            tenderCell.setCellValue(cellValues[2]);
                                        }else if(cellValues.length==1){
                                            tenderCell.setCellValue(cellValues[0]);                                            
                                        }
                                    }
                                }
                                if (tenderColumn.getFilledBy() == 2) {
                                    tenderCell.setDataType(Integer.parseInt(StringUtils.hasLength(request.getParameter("selCellType_" + j + "_" + i)) ? request.getParameter("selCellType_" + j + "_" + i) : "0"));
                                    if (tenderCell.getDataType() == masterField) {
                                        tenderCell.setObjectId(Integer.parseInt(StringUtils.hasLength(request.getParameter("selMasterField_" + j + "_" + i)) ? request.getParameter("selMasterField_" + j + "_" + i) : "0"));
                                    }
                                    if (tenderCell.getDataType() == combobox) {
                                        tenderCell.setObjectId(Integer.parseInt(StringUtils.hasLength(request.getParameter("selClientCombo_" + j + "_" + i)) ? request.getParameter("selClientCombo_" + j + "_" + i) : "0"));
                                    }
                                    if (tenderCell.getDataType() == listBox) {
                                        tenderCell.setObjectId(Integer.parseInt(StringUtils.hasLength(request.getParameter("selClientCombo_" + j + "_" + i)) ? request.getParameter("selClientCombo_" + j + "_" + i) : "0"));
                                    }
                                } else {
                                    tenderCell.setDataType(tenderColumn.getDataType());
                                }
                                if (tenderCell.getCellValue() == null) {
                                    tenderCell.setCellValue("");
                                }
                                if (formOperation == 3) {
                                    //System.out.println("hdCellId_" + j + "_" + i);
                                    tenderCell.setCellId(StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0);
                                }
                                tenderCells.add(tenderCell);
                                cellNo++;
                            }
                            tenderColumns.add(tenderColumn);
                        }
                        if (formOperation == 6 || formOperation == 4) {
                            //tm
                            operation.put("deleteFormCell", true);
                            params.put(TABLE_ID, tableId);
                            params.put(FORM_ID, formId);
//                            formService.deleteFormCell(tableId);
                        }
                        StringBuilder formulaColId = new StringBuilder();
                        if (!allFormula.isEmpty()) {
							int counter=0;
                            for (Integer colId : changedColId) {
                                for (Object[] formula : allFormula) {
                                    String rawFormulaCols = "_"+(formula[0].toString().replace("N_", "N").replace("+", "_").replace("-", "_").replace("/", "_").replace("(", "_").replace("*", "_").replace(")", "_"))+"_";
                                        if (colId.equals((Integer) formula[0]) || rawFormulaCols.contains("_"+changedColNo.toArray()[counter]+"_")) {                                            
                                            formulaColId.append(formula[0]).append(",");
                                        }
                                }
								counter++;
                            }
                            if (formulaColId.length() != 0) {
                                //tm
                                operation.put("deleteFormula", true);
                                params.put("isGTWise", isGTWise);
                                params.put(TABLE_ID, tableId);
                                params.put("changedColId", changedColId);
                                params.put("row", row + 1);
                                params.put("formulaColId", formulaColId.toString());
                               if( formOperation == 3 && isGTWise){
                                       operation.put("delFormulaCell", true);     //#34643 Delete Cell As Formula is Deleted                                    
                               }
//                                formService.deleteFormula(isGTWise, tableId, changedColId, row + 1, formulaColId.toString());
                            } else {
                                if (isGTWise && (formOperation == 4)) {
                                    for (Object[] formula : allFormula) {
                                        if (formula[2].toString().startsWith(TOTAL)) {
                                            formulaColId.append(formula[0]).append(",");
                                            changedColId.add((Integer) formula[0]);
                                        }
                                    }
                                    if (formulaColId.length() != 0) {
                                        //tm
                                        operation.put("deleteFormula", true);
                                        params.put("isGTWise", isGTWise);
                                        params.put(TABLE_ID, tableId);
                                        params.put("changedColId", changedColId);
                                        params.put("row", row + 1);
                                        params.put("formulaColId", formulaColId.toString());
//                                        formService.deleteFormula(isGTWise, tableId, changedColId, row + 1, formulaColId.toString());
                                    }
                                }
                                if (delAllFormula || formOperation == 5) {
                                    for (Object[] formula : allFormula) {
                                        formulaColId.append(formula[0]).append(",");
                                        changedColId.add((Integer) formula[0]);
                                    }
                                    //tm
                                    operation.put("deleteFormula", true);
                                    params.put("isGTWise", isGTWise);
                                    if(delAllFormula){
                                        operation.put("delFormulaCell", true);                                        
                                    }
                                    params.put(TABLE_ID, tableId);
                                    params.put("changedColId", changedColId);
                                    params.put("row", row + 1);
                                    params.put("formulaColId", formulaColId.toString());
//                                    formService.deleteFormula(isGTWise, tableId, changedColId, row + 1, formulaColId.toString());
                                }
                            }
                        }
                        long govColId = 0;
                        if (isGTWise && formOperation == 6) {
                            boolean isGTFormula = false;
                            for (Object[] formula : allFormula) {
                                if (formula[2].toString().startsWith(TOTAL)) {
                                    isGTFormula = true;
                                    break;
                                }
                            }
                            if (isGTFormula) {
                                List<Object[]> govCols = tenderFormService.getGovColumn(tableId);
                                if (!govCols.isEmpty()) {
                                    govColId = (Integer) govCols.get(0)[0];
                                }
                                for (int i = 0; i < col; i++) {
                                    TblTenderCell tenderCell = new TblTenderCell();
                                    tenderCell.setCellNo(cellNo);
                                    tenderCell.setRowId(row + 1);
                                    tenderCell.setTblTenderColumn(tenderColumns.get(i));
                                    tenderCell.setTblTenderTable(new TblTenderTable(tableId));
                                    tenderCell.setTblTenderForm(new TblTenderForm(formId));
                                    tenderCell.setCellValue("");
                                    tenderCells.add(tenderCell);
                                    cellNo++;
                                }
                                row = row + 1;
                            }else {
                            	List<Object[]> listObject=tenderFormService.getTableDetails(formId, tableId);
                            	if(listObject!=null && !listObject.isEmpty()) {
                            		operation.put("updateIsGTFlag", Integer.parseInt(listObject.get(0)[5].toString()) == 1 ? true : false);
                            	}
                            }
                        }
                        if (formOperation != 3) {
                            //tm
                            operation.put("addFormMatrix", true);
                            params.put("tblTenderColumns", tenderColumns);
                            params.put("tblTenderCells", tenderCells);
                            params.put("noOfRows", row);
                            params.put("noOfCols", col);
                            params.put("createdBy", userId);
                            params.put("isEdit", formOperation == 5);
//                            success = formService.addFormMatrix(auctionColumns, auctionCells, row, col, userId, formOperation == 5);
                            if (govColId != 0) {
                                long updateCellId = 0;
                                for (TblTenderCell tblTenderCell : tenderCells.subList(col * (row - 1), tenderCells.size())) {
                                    if (govColId == tblTenderCell.getTblTenderColumn().getColumnId()) {
                                        updateCellId = tblTenderCell.getCellId();
                                    }
                                }
                                //tm
                                operation.put("updateGovCellId", true);
                                params.put("govColumnId", govColId);
                                params.put("cellId", (Long) updateCellId);
//                                formService.updateGovCellId(govColId, (Long) updateCellId);
                            }

                        } else {
                            //tm
                            operation.put("addFormMatrix", true);
                            params.put("tblTenderColumns", tenderColumns);
                            params.put("tblTenderCells", tenderCells);
                            params.put("noOfRows", 0);
                            params.put("noOfCols", 0);
                            params.put("createdBy", userId);
                            params.put("isEdit", false);
//                            success = formService.addFormMatrix(auctionColumns, auctionCells, 0, 0, userId, false);
                        }
                        if (formOperation == 3 || formOperation == 4) {
                            if (proxyCols.length() > 1) {
                                //tm
                                operation.put("deleteTenderProxyBid", true);
                                params.put("proxyColId", proxyCols.substring(0, proxyCols.length() - 1));
//                                formService.deleteTenderProxyBid(proxyCols.substring(0, proxyCols.length() - 1));
                            }
                            /*if (bidderCols.length() > 1) { // todo not in tender
                             //tm
                             operation.put("updateBidderColumn", true);
                             params.put("bidderColId", bidderCols.substring(0, bidderCols.length() - 1));
                             //                                formService.updateBidderColumn(bidderCols.substring(0, bidderCols.length() - 1));
                             }*/
                        }
                        if (formOperation == 6 && !isGTWise) {
                            String removeRow = request.getParameter("txtDelRow");
                            if (StringUtils.hasLength(removeRow)) {
                                //tm
                                operation.put("updateOnFormRowDelete", true);
                                params.put("tenderId", tenderId);
                                params.put("rowIds", removeRow);
//                                formService.updateOnFormRowDelete(auctionId, removeRow, abcUtility.getSessionUserId(request));
                            }
                        }
//                        System.out.println("hasGTRow : "+hasGTRow+" hasGT : "+hasGT);
                        //The code was while dump/copy form no cells are dumped in case of PB so it was decided to make hasGTRow=0 
                        //while keeping GT formula as it is and below code will do the rest
                        /*if(!hasGTRow && hasGT){ 
                            operation.put("addFormulaCell", true);
                            params.put("gtRows", row+1);
                            params.put("noOfCols", col);
                            params.put("createdBy", userId);
                            List<TblTenderCell> gtTenderCells = new ArrayList<TblTenderCell>();
                            for (int i = 0; i < col; i++) {
                                TblTenderCell tenderCell = new TblTenderCell();
                                tenderCell.setCellNo(cellNo);
                                tenderCell.setRowId(row + 1);
                                tenderCell.setTblTenderColumn(tenderColumns.get(i));
                                tenderCell.setTblTenderTable(new TblTenderTable(tableId));
                                tenderCell.setTblTenderForm(new TblTenderForm(formId));
                                tenderCell.setCellValue("");
                                tenderCell.setDataType(0);
                                tenderCell.setObjectId(0);
                                gtTenderCells.add(tenderCell);
                                cellNo++;
                            }
                            params.put("gtTenderCells", gtTenderCells);                            
                        }*/
                        success = tenderFormService.addFormMatrix(params, operation);
                        
                        
                        break;
                    case 2://I want to update Column/Row Description
                        List<Map<Integer, String>> colHead = new ArrayList<Map<Integer, String>>();
                        List<Map<Integer, String>> cellVal = new ArrayList<Map<Integer, String>>();
                        List<Map<Integer, Integer[]>> bidderCell = new ArrayList<Map<Integer, Integer[]>>();
                        for (int i = 0; i < col; i++) {
                            if (StringUtils.hasLength(request.getParameter(HDCOLUMNID + i)) && StringUtils.hasLength(request.getParameter("txtacolHeader_" + i))
                                    && StringUtils.hasLength(request.getParameter("hdColumnHeader_" + i))
                                    && !request.getParameter("hdColumnHeader_" + i).equals(request.getParameter("txtacolHeader_" + i))) {
                                //tm
                                Map<Integer, String> column = new HashMap<Integer, String>();
                                column.put(Integer.parseInt(request.getParameter(HDCOLUMNID + i)), request.getParameter("txtacolHeader_" + i));
                                colHead.add(column);
//                                formService.updateColumnHeader(Integer.parseInt(request.getParameter(HDCOLUMNID + i)), request.getParameter("txtacolHeader_" + i));
                            }
                            for (int j = 0; j < row; j++) {
                                String cellValue = null;
                                int cellId = 0;
                                if (StringUtils.hasLength(request.getParameter(HDDATATYPE + i)) && StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) == 1) {
                                    if (Integer.parseInt(request.getParameter(HDDATATYPE + i)) != longtext) {
                                        String[] cellValues = request.getParameterValues("txtcell_" + j + "_" + i);
                                        if(cellValues.length==2){                                            
                                            cellId = StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0;
                                            Map<Integer, Integer[]> cell = new HashMap<Integer, Integer[]>();
                                            cell.put(cellId, new Integer[]{smalltext,Integer.parseInt(cellValues[0])});
                                            bidderCell.add(cell);
                                            cellValue = cellValues[1];
                                        }else if(cellValues.length==1){
                                            cellValue = cellValues[0];
                                        }
                                    } else {
                                        cellValue = request.getParameter("txtacell_" + j + "_" + i);
                                    }
                                    if (StringUtils.hasLength(cellValue) && !cellValue.equals(request.getParameter("hdCellValue_" + j + "_" + i))) {
                                        cellId = StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0;
                                        //tm
                                        Map<Integer, String> cell = new HashMap<Integer, String>();
                                        cell.put(cellId, cellValue);
                                        cellVal.add(cell);
//                                        formService.updateCellValue(cellId, cellValue);
                                    }
                                }
                                int dataType = 0;
                                int objectId = 0;
                                if (StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) == 2) {
                                    if (StringUtils.hasLength(request.getParameter("hdCellType_" + j + "_" + i))) {
                                        boolean toBeUpdate = false;
                                        cellId = StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0;
                                        if (!request.getParameter("hdCellType_" + j + "_" + i).equals(request.getParameter("selCellType_" + j + "_" + i))) {
                                            dataType = Integer.parseInt(request.getParameter("selCellType_" + j + "_" + i));
                                            toBeUpdate = true;
                                        }
                                        if (StringUtils.hasLength(request.getParameter("selMasterField_" + j + "_" + i))) {
                                            dataType = Integer.parseInt(request.getParameter("selCellType_" + j + "_" + i));
                                            if (dataType == masterField && !request.getParameter("selMasterField_" + j + "_" + i).equals(request.getParameter("hdObjectId_" + j + "_" + i))) {
                                                objectId = Integer.parseInt(request.getParameter("selMasterField_" + j + "_" + i));
                                                toBeUpdate = true;
                                            }
                                        }
                                        if (StringUtils.hasLength(request.getParameter("selClientCombo_" + j + "_" + i))) {
                                            dataType = Integer.parseInt(request.getParameter("selCellType_" + j + "_" + i));
                                            if ((dataType == combobox || dataType == listBox) && !request.getParameter("selClientCombo_" + j + "_" + i).equals(request.getParameter("hdObjectId_" + j + "_" + i))) {
                                                objectId = Integer.parseInt(request.getParameter("selClientCombo_" + j + "_" + i));
                                                toBeUpdate = true;
                                            }
                                        }
                                        if (toBeUpdate) {
                                            Map<Integer, Integer[]> cell = new HashMap<Integer, Integer[]>();
                                            cell.put(cellId, new Integer[]{dataType, objectId});
                                            bidderCell.add(cell);

                                        }
                                    }
                                }
                            }
                        }
                        success = tenderFormService.updateFormHeadNCell(colHead, cellVal, bidderCell, tableId);
                        break;
                }
                if (success) {
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), formOperation == 1 ? "redirect_success_addformmatrix" : "redirect_success_updateformmatrix");
                } else {
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                }
            } catch (Exception ex) {
                return exceptionHandlerService.writeLog(ex);
            } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), formOperation == 1 ? bidFormCreate : bidFormEdit, formOperation == 1 ? addFormMatrixCreateAudit : addFormMatrixEditAudit, tenderId, tableId);
            }
        } else {
            return REDIRECT_SESSION_EXPIRED;
        }
        if (formOperation == 1 && autoColCnt!=0) {
            return "redirect:/etender/buyer/createformula/" + tenderId + "/" + formId + "/" + tableId + "/" + fromDash + encryptDecryptUtils.generateRedirect("etender/buyer/createformula/" + tenderId + "/" + formId + "/" + tableId + "/" + fromDash, request);
        } else {
            return "redirect:/etender/buyer/formdashboard/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/formdashboard/" + tenderId + "/" + formId, request);
        }
    }
    @RequestMapping(value = "/buyer/addformmatrixForCG", method = RequestMethod.POST)
    public String addformmatrixForCG(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
//        boolean hasGTRow = StringUtils.hasLength(request.getParameter("hdHasGTRow")) ? Integer.parseInt(request.getParameter("hdHasGTRow"))==1 : false;
        int tableId = StringUtils.hasLength(request.getParameter(HIDDEN_TABLE_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TABLE_ID)) : 0;
        boolean priceBid = StringUtils.hasLength(request.getParameter("hdPriceBid")) ? Boolean.parseBoolean(request.getParameter("hdPriceBid")) : false;
        String fromDash = StringUtils.hasLength(request.getParameter(FROM_DASH)) ? request.getParameter(FROM_DASH) : "0";
        int uploadByExcel = StringUtils.hasLength(request.getParameter("uploadByExcel")) ? Integer.parseInt(request.getParameter("uploadByExcel")) : 0;
        int autoColCnt = 0;
        int formOperation = StringUtils.hasLength(request.getParameter("hdFormOperation")) ? Integer.parseInt(request.getParameter("hdFormOperation")) : 0;
        if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            int col = StringUtils.hasLength(request.getParameter("txtCol")) ? Integer.parseInt(request.getParameter("txtCol")) : 0;
            int row = StringUtils.hasLength(request.getParameter("txtRow")) ? Integer.parseInt(request.getParameter("txtRow")) : 0;
            
            try {
                int userId = abcUtility.getSessionUserDetailId(request);
                int tenderResult = StringUtils.hasLength(request.getParameter("hdTenderResult")) ? Integer.parseInt(request.getParameter("hdTenderResult")) : 0;
                boolean isGTWise = tenderResult != 2;
                List<Object[]> allFormula = tenderFormService.getFormulaColId(tableId);
                
                Set<Integer> changedColId = new HashSet<Integer>();
				Set<Integer> changedColNo = new HashSet<Integer>();
                StringBuilder proxyCols = new StringBuilder();
//                StringBuilder bidderCols = new StringBuilder();// todo not in tender
                Map<String, Object> params = new HashMap<String, Object>();
                params.put("tenderId", tenderId);
                params.put("isPriceBid", priceBid);
                Map<String, Boolean> operation = new HashMap<String, Boolean>();
                switch (formOperation) {
                    case 1:// Update with none of the below given operations/Fresh Insert 
                    case 3:// I want to update Data Type, Filled by option[updateall]
                    case 4:// I want to update form with Add Column operation[updateall]
                    case 5://I want to update form with Delete Column operation[DeleteInsert]
                    case 6://I want to update form with Add Row/Delete Row operation
                        List<TblTenderColumn> tenderColumns = new ArrayList<TblTenderColumn>();
                        List<TblTenderCell> tenderCells = new ArrayList<TblTenderCell>();
                        //Filled By - Auctioner:1, Bidder:2, Auto:3, Proxy Bid Column:4
                        //Data Type - SmallText:1, LongText:2, +No. with (.):3, +No. without (.):4, All Numbers:8
                        int cellNo = 0;
                        boolean delAllFormula = false;
                        for (int i = 0; i < col; i++) {
                            TblTenderColumn tenderColumn = new TblTenderColumn();
                            tenderColumn.setColumnHeader(request.getParameter("txtacolHeader_" + i));
                            tenderColumn.setTblTenderForm(new TblTenderForm(formId));
                            tenderColumn.setDataType(Integer.parseInt(StringUtils.hasLength(request.getParameter("selDataType_" + i)) ? request.getParameter("selDataType_" + i) : StringUtils.hasLength(request.getParameter(HDDATATYPE + i)) ? request.getParameter(HDDATATYPE + i) : "0"));
                            tenderColumn.setFilledBy(Integer.parseInt(StringUtils.hasLength(request.getParameter("selFilledBy_" + i)) ? request.getParameter("selFilledBy_" + i) : StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) ? request.getParameter(HDDFILLEDBY + i) : "0"));
                            if(tenderColumn.getFilledBy()==auto){
                                autoColCnt++;
                            }
                            tenderColumn.setIsShown(Integer.parseInt(StringUtils.hasLength(request.getParameter("selShowHide_" + i)) ? request.getParameter("selShowHide_" + i) : StringUtils.hasLength(request.getParameter("hdShowHide_" + i)) ? request.getParameter("hdShowHide_" + i) : "0"));
                            if (tenderColumn.getDataType() == smalltext || tenderColumn.getDataType() == longtext) {
                                tenderColumn.setIsCurrConvReq(0);
                            } else {
                                tenderColumn.setIsCurrConvReq(Integer.parseInt(StringUtils.hasLength(request.getParameter("selCurrConv_" + i)) ? request.getParameter("selCurrConv_" + i) : StringUtils.hasLength(request.getParameter("hdCurrConv_" + i)) ? request.getParameter("hdCurrConv_" + i) : "0"));
                            }
                            tenderColumn.setColumnNo(i + 1);
                            tenderColumn.setSortOrder(Integer.parseInt(StringUtils.hasLength(request.getParameter("txtColSortOrder_" + i)) ? request.getParameter("txtColSortOrder_" + i) : "0"));
                            tenderColumn.setTblTenderTable(new TblTenderTable(tableId));
                            tenderColumn.setTblColumnType(new TblColumnType(!priceBid ? (6) : (Integer.parseInt(StringUtils.hasLength(request.getParameter("selColumnType_" + i)) ? request.getParameter("selColumnType_" + i) : StringUtils.hasLength(request.getParameter("hdColumnType_" + i)) ? request.getParameter("hdColumnType_" + i) : "0"))));
                            if (formOperation == 3 || formOperation == 4 || formOperation == 6) {
                                tenderColumn.setColumnId(StringUtils.hasLength(request.getParameter(HDCOLUMNID + i)) ? Integer.parseInt(request.getParameter(HDCOLUMNID + i)) : 0);
                            }
                            if (formOperation == 3 || formOperation == 4) {
                                boolean proxyColSet = false;
                                if (StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) == 4 && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) != tenderColumn.getFilledBy()) {
                                    proxyCols.append(request.getParameter(HDCOLUMNID + i)).append(",");
                                    proxyColSet = true;
                                }
                                if (!proxyColSet && StringUtils.hasLength(request.getParameter(HDDATATYPE + i)) && tenderColumn.getDataType() != Integer.parseInt(request.getParameter(HDDATATYPE + i))) {
                                    proxyCols.append(request.getParameter(HDCOLUMNID + i)).append(",");
                                }
                                /*String aucbidderWiseForm = auctionCommonService.getAuctionSelectedField(auctionId, "showBidderWiseForm");// todo not in tender
                                 if ((StringUtils.hasLength(aucbidderWiseForm) ? Integer.parseInt(aucbidderWiseForm) == 1 : false) && StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) != 2 && auctionColumn.getFilledBy() == 2) {
                                 bidderCols.append(request.getParameter(HDCOLUMNID + i)).append(",");
                                 }*/
                            }
                            if(formOperation != 5 && !allFormula.isEmpty()){
                                if (StringUtils.hasLength(request.getParameter("hdColSortOrder_" + i)) && tenderColumn.getSortOrder() != Integer.parseInt(request.getParameter("hdColSortOrder_" + i))) {
                                    delAllFormula = true;                                   
                                }
                            }
                            if ((formOperation == 3 || formOperation == 4) && !allFormula.isEmpty()) {
                                if (StringUtils.hasLength(request.getParameter(HDDATATYPE + i)) && tenderColumn.getDataType() != Integer.parseInt(request.getParameter(HDDATATYPE + i))) {
                                    if (Integer.parseInt(request.getParameter(HDDATATYPE + i)) == money) {
                                        if (!(tenderColumn.getDataType() == numeric || tenderColumn.getDataType() == moneyall)) {
                                            changedColId.add(Integer.parseInt(request.getParameter(HDCOLUMNID + i)));
											changedColNo.add((i+1));
                                        }
                                    } else if (Integer.parseInt(request.getParameter(HDDATATYPE + i)) == numeric) {
                                        if (!(tenderColumn.getDataType() == money || tenderColumn.getDataType() == moneyall)) {
                                            changedColId.add(Integer.parseInt(request.getParameter(HDCOLUMNID + i)));
											changedColNo.add((i+1));
                                        }
                                    } else if (Integer.parseInt(request.getParameter(HDDATATYPE + i)) == moneyall) {
                                        if (!(tenderColumn.getDataType() == money || tenderColumn.getDataType() == numeric)) {
                                            changedColId.add(Integer.parseInt(request.getParameter(HDCOLUMNID + i)));
											changedColNo.add((i+1));
                                        }
                                    }
                                }
                                if (StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && tenderColumn.getFilledBy() != Integer.parseInt(request.getParameter(HDDFILLEDBY + i))) {
                                    changedColId.add(Integer.parseInt(request.getParameter(HDCOLUMNID + i)));
									changedColNo.add((i+1));
                                }
                            }
                            boolean iscgClient = CommonUtility.isClientConditionExistInProperty(cgClient,abcUtility.getSessionClientId(request));
                            if(uploadByExcel==1 && iscgClient){
	                            for (int j = 0; j < row; j++) {
	                                String hiddenJSONArray = request.getParameter("hiddenJSON_" + j + "_" + i);
	                                TblTenderCell tenderCell = new TblTenderCell();
	                                if(hiddenJSONArray!=null && !"undefined".equalsIgnoreCase(hiddenJSONArray) &&  !"null".equalsIgnoreCase(hiddenJSONArray) && !"".equalsIgnoreCase(hiddenJSONArray)){
	                                	JSONObject jSONObject = new JSONObject(hiddenJSONArray);
	                                    for (Iterator it = jSONObject.keys(); it.hasNext();) {
	                                        String key = it.next().toString();
	                                        String[] values = key.split("_");
	                                        tenderCell.setCellNo(Integer.valueOf(cellNo));
	                                        tenderCell.setTblTenderForm(new TblTenderForm(formId));
	                                        tenderCell.setRowId(j+1);
	                                        tenderCell.setTblTenderColumn(tenderColumn);
	                                        tenderCell.setTblTenderTable(new TblTenderTable(tableId));
	                                        tenderCell.setCellValue(jSONObject.getString(key));
	                                        tenderCell.setDataType(tenderColumn.getDataType());
	                                        
	                                        if (formOperation == 3) {
	                                        	tenderCell.setCellId(StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0);
	                                        }
	                                    }
	                                    tenderCells.add(tenderCell);
	                                }
	                                cellNo++;
	                            }
                            }else if(uploadByExcel==0){
                            	for (int j = 0; j < row; j++) {
                                    TblTenderCell tenderCell = new TblTenderCell();
                                    tenderCell.setCellNo(cellNo);
                                    tenderCell.setTblTenderForm(new TblTenderForm(formId));
                                    tenderCell.setRowId(Integer.parseInt(StringUtils.hasLength(request.getParameter("txtRowSort_" + j)) ? request.getParameter("txtRowSort_" + j) : "0"));
                                    tenderCell.setTblTenderColumn(tenderColumn);
                                    tenderCell.setTblTenderTable(new TblTenderTable(tableId));
                                    if (tenderColumn.getFilledBy() == 1) {
                                        String[] cellValues = request.getParameterValues("txtcell_" + j + "_" + i);
                                        if (tenderColumn.getDataType() == longtext && cellValues==null) {
                                            tenderCell.setCellValue(request.getParameter("txtacell_" + j + "_" + i));
                                        } else {                                        
                                            if(cellValues.length==2){
//                                                System.out.println(cellValues[0]+ " : "+cellValues[1]);
                                                tenderCell.setObjectId(Integer.parseInt(cellValues[0]));
                                                tenderCell.setCellValue(cellValues[1]);
                                            }else if(cellValues.length==3){
//                                                System.out.println(cellValues[1]+ " : "+cellValues[2]);
                                                tenderCell.setObjectId(Integer.parseInt(cellValues[1]));
                                                tenderCell.setCellValue(cellValues[2]);
                                            }else if(cellValues.length==1){
                                                tenderCell.setCellValue(cellValues[0]);                                            
                                            }
                                        }
                                    }
                                    if (tenderColumn.getFilledBy() == 2) {
                                        tenderCell.setDataType(Integer.parseInt(StringUtils.hasLength(request.getParameter("selCellType_" + j + "_" + i)) ? request.getParameter("selCellType_" + j + "_" + i) : "0"));
                                        if (tenderCell.getDataType() == masterField) {
                                            tenderCell.setObjectId(Integer.parseInt(StringUtils.hasLength(request.getParameter("selMasterField_" + j + "_" + i)) ? request.getParameter("selMasterField_" + j + "_" + i) : "0"));
                                        }
                                        if (tenderCell.getDataType() == combobox) {
                                            tenderCell.setObjectId(Integer.parseInt(StringUtils.hasLength(request.getParameter("selClientCombo_" + j + "_" + i)) ? request.getParameter("selClientCombo_" + j + "_" + i) : "0"));
                                        }
                                        if (tenderCell.getDataType() == listBox) {
                                            tenderCell.setObjectId(Integer.parseInt(StringUtils.hasLength(request.getParameter("selClientCombo_" + j + "_" + i)) ? request.getParameter("selClientCombo_" + j + "_" + i) : "0"));
                                        }
                                    } else {
                                        tenderCell.setDataType(tenderColumn.getDataType());
                                    }
                                    if (tenderCell.getCellValue() == null) {
                                        tenderCell.setCellValue("");
                                    }
                                    if (formOperation == 3) {
                                        //System.out.println("hdCellId_" + j + "_" + i);
                                        tenderCell.setCellId(StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0);
                                    }
                                    tenderCells.add(tenderCell);
                                    cellNo++;
                                }
                            }
                            tenderColumns.add(tenderColumn);
                        }
                        if (formOperation == 6 || formOperation == 4) {
                            //tm
                            operation.put("deleteFormCell", true);
                            params.put(TABLE_ID, tableId);
                            params.put(FORM_ID, formId);
//                            formService.deleteFormCell(tableId);
                        }
                        StringBuilder formulaColId = new StringBuilder();
                        if (!allFormula.isEmpty()) {
							int counter=0;
                            for (Integer colId : changedColId) {
                                for (Object[] formula : allFormula) {
                                    String rawFormulaCols = "_"+(formula[0].toString().replace("N_", "N").replace("+", "_").replace("-", "_").replace("/", "_").replace("(", "_").replace("*", "_").replace(")", "_"))+"_";
                                        if (colId.equals((Integer) formula[0]) || rawFormulaCols.contains("_"+changedColNo.toArray()[counter]+"_")) {                                            
                                            formulaColId.append(formula[0]).append(",");
                                        }
                                }
								counter++;
                            }
                            if (formulaColId.length() != 0) {
                                //tm
                                operation.put("deleteFormula", true);
                                params.put("isGTWise", isGTWise);
                                params.put(TABLE_ID, tableId);
                                params.put("changedColId", changedColId);
                                params.put("row", row + 1);
                                params.put("formulaColId", formulaColId.toString());
                               if( formOperation == 3 && isGTWise){
                                       operation.put("delFormulaCell", true);     //#34643 Delete Cell As Formula is Deleted                                    
                               }
//                                formService.deleteFormula(isGTWise, tableId, changedColId, row + 1, formulaColId.toString());
                            } else {
                                if (isGTWise && (formOperation == 4)) {
                                    for (Object[] formula : allFormula) {
                                        if (formula[2].toString().startsWith(TOTAL)) {
                                            formulaColId.append(formula[0]).append(",");
                                            changedColId.add((Integer) formula[0]);
                                        }
                                    }
                                    if (formulaColId.length() != 0) {
                                        //tm
                                        operation.put("deleteFormula", true);
                                        params.put("isGTWise", isGTWise);
                                        params.put(TABLE_ID, tableId);
                                        params.put("changedColId", changedColId);
                                        params.put("row", row + 1);
                                        params.put("formulaColId", formulaColId.toString());
//                                        formService.deleteFormula(isGTWise, tableId, changedColId, row + 1, formulaColId.toString());
                                    }
                                }
                                if (delAllFormula || formOperation == 5) {
                                    for (Object[] formula : allFormula) {
                                        formulaColId.append(formula[0]).append(",");
                                        changedColId.add((Integer) formula[0]);
                                    }
                                    //tm
                                    operation.put("deleteFormula", true);
                                    params.put("isGTWise", isGTWise);
                                    if(delAllFormula){
                                        operation.put("delFormulaCell", true);                                        
                                    }
                                    params.put(TABLE_ID, tableId);
                                    params.put("changedColId", changedColId);
                                    params.put("row", row + 1);
                                    params.put("formulaColId", formulaColId.toString());
//                                    formService.deleteFormula(isGTWise, tableId, changedColId, row + 1, formulaColId.toString());
                                }
                            }
                        }
                        long govColId = 0;
                        if (isGTWise && formOperation == 6) {
                            boolean isGTFormula = false;
                            for (Object[] formula : allFormula) {
                                if (formula[2].toString().startsWith(TOTAL)) {
                                    isGTFormula = true;
                                    break;
                                }
                            }
                            if (isGTFormula) {
                                List<Object[]> govCols = tenderFormService.getGovColumn(tableId);
                                if (!govCols.isEmpty()) {
                                    govColId = (Integer) govCols.get(0)[0];
                                }
                                for (int i = 0; i < col; i++) {
                                    TblTenderCell tenderCell = new TblTenderCell();
                                    tenderCell.setCellNo(cellNo);
                                    tenderCell.setRowId(row + 1);
                                    tenderCell.setTblTenderColumn(tenderColumns.get(i));
                                    tenderCell.setTblTenderTable(new TblTenderTable(tableId));
                                    tenderCell.setTblTenderForm(new TblTenderForm(formId));
                                    tenderCell.setCellValue("");
                                    tenderCells.add(tenderCell);
                                    cellNo++;
                                }
                                row = row + 1;
                            }
                        }
                        if (formOperation != 3) {
                            //tm
                            operation.put("addFormMatrix", true);
                            params.put("tblTenderColumns", tenderColumns);
                            params.put("tblTenderCells", tenderCells);
                            params.put("noOfRows", row);
                            params.put("noOfCols", col);
                            params.put("createdBy", userId);
                            params.put("isEdit", formOperation == 5);
//                            success = formService.addFormMatrix(auctionColumns, auctionCells, row, col, userId, formOperation == 5);
                            if (govColId != 0) {
                                long updateCellId = 0;
                                for (TblTenderCell tblTenderCell : tenderCells.subList(col * (row - 1), tenderCells.size())) {
                                    if (govColId == tblTenderCell.getTblTenderColumn().getColumnId()) {
                                        updateCellId = tblTenderCell.getCellId();
                                    }
                                }
                                //tm
                                operation.put("updateGovCellId", true);
                                params.put("govColumnId", govColId);
                                params.put("cellId", (Long) updateCellId);
//                                formService.updateGovCellId(govColId, (Long) updateCellId);
                            }

                        } else {
                            //tm
                            operation.put("addFormMatrix", true);
                            params.put("tblTenderColumns", tenderColumns);
                            params.put("tblTenderCells", tenderCells);
                            params.put("noOfRows", 0);
                            params.put("noOfCols", 0);
                            params.put("createdBy", userId);
                            params.put("isEdit", false);
//                            success = formService.addFormMatrix(auctionColumns, auctionCells, 0, 0, userId, false);
                        }
                        if (formOperation == 3 || formOperation == 4) {
                            if (proxyCols.length() > 1) {
                                //tm
                                operation.put("deleteTenderProxyBid", true);
                                params.put("proxyColId", proxyCols.substring(0, proxyCols.length() - 1));
//                                formService.deleteTenderProxyBid(proxyCols.substring(0, proxyCols.length() - 1));
                            }
                            /*if (bidderCols.length() > 1) { // todo not in tender
                             //tm
                             operation.put("updateBidderColumn", true);
                             params.put("bidderColId", bidderCols.substring(0, bidderCols.length() - 1));
                             //                                formService.updateBidderColumn(bidderCols.substring(0, bidderCols.length() - 1));
                             }*/
                        }
                        if (formOperation == 6 && !isGTWise) {
                            String removeRow = request.getParameter("txtDelRow");
                            if (StringUtils.hasLength(removeRow)) {
                                //tm
                                operation.put("updateOnFormRowDelete", true);
                                params.put("tenderId", tenderId);
                                params.put("rowIds", removeRow);
//                                formService.updateOnFormRowDelete(auctionId, removeRow, abcUtility.getSessionUserId(request));
                            }
                        }
//                        System.out.println("hasGTRow : "+hasGTRow+" hasGT : "+hasGT);
                        //The code was while dump/copy form no cells are dumped in case of PB so it was decided to make hasGTRow=0 
                        //while keeping GT formula as it is and below code will do the rest
                        /*if(!hasGTRow && hasGT){ 
                            operation.put("addFormulaCell", true);
                            params.put("gtRows", row+1);
                            params.put("noOfCols", col);
                            params.put("createdBy", userId);
                            List<TblTenderCell> gtTenderCells = new ArrayList<TblTenderCell>();
                            for (int i = 0; i < col; i++) {
                                TblTenderCell tenderCell = new TblTenderCell();
                                tenderCell.setCellNo(cellNo);
                                tenderCell.setRowId(row + 1);
                                tenderCell.setTblTenderColumn(tenderColumns.get(i));
                                tenderCell.setTblTenderTable(new TblTenderTable(tableId));
                                tenderCell.setTblTenderForm(new TblTenderForm(formId));
                                tenderCell.setCellValue("");
                                tenderCell.setDataType(0);
                                tenderCell.setObjectId(0);
                                gtTenderCells.add(tenderCell);
                                cellNo++;
                            }
                            params.put("gtTenderCells", gtTenderCells);                            
                        }*/
                        success = tenderFormService.addFormMatrix(params, operation);
                        break;
                    case 2://I want to update Column/Row Description
                        List<Map<Integer, String>> colHead = new ArrayList<Map<Integer, String>>();
                        List<Map<Integer, String>> cellVal = new ArrayList<Map<Integer, String>>();
                        List<Map<Integer, Integer[]>> bidderCell = new ArrayList<Map<Integer, Integer[]>>();
                        for (int i = 0; i < col; i++) {
                            if (StringUtils.hasLength(request.getParameter(HDCOLUMNID + i)) && StringUtils.hasLength(request.getParameter("txtacolHeader_" + i))
                                    && StringUtils.hasLength(request.getParameter("hdColumnHeader_" + i))
                                    && !request.getParameter("hdColumnHeader_" + i).equals(request.getParameter("txtacolHeader_" + i))) {
                                //tm
                                Map<Integer, String> column = new HashMap<Integer, String>();
                                column.put(Integer.parseInt(request.getParameter(HDCOLUMNID + i)), request.getParameter("txtacolHeader_" + i));
                                colHead.add(column);
//                                formService.updateColumnHeader(Integer.parseInt(request.getParameter(HDCOLUMNID + i)), request.getParameter("txtacolHeader_" + i));
                            }
                            for (int j = 0; j < row; j++) {
                                String cellValue = null;
                                int cellId = 0;
                                if (StringUtils.hasLength(request.getParameter(HDDATATYPE + i)) && StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) == 1) {
                                    if (Integer.parseInt(request.getParameter(HDDATATYPE + i)) != longtext) {
                                        String[] cellValues = request.getParameterValues("txtcell_" + j + "_" + i);
                                        if(cellValues.length==2){                                            
                                            cellId = StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0;
                                            Map<Integer, Integer[]> cell = new HashMap<Integer, Integer[]>();
                                            cell.put(cellId, new Integer[]{smalltext,Integer.parseInt(cellValues[0])});
                                            bidderCell.add(cell);
                                            cellValue = cellValues[1];
                                        }else if(cellValues.length==1){
                                            cellValue = cellValues[0];
                                        }
                                    } else {
                                        cellValue = request.getParameter("txtacell_" + j + "_" + i);
                                    }
                                    if (StringUtils.hasLength(cellValue) && !cellValue.equals(request.getParameter("hdCellValue_" + j + "_" + i))) {
                                        cellId = StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0;
                                        //tm
                                        Map<Integer, String> cell = new HashMap<Integer, String>();
                                        cell.put(cellId, cellValue);
                                        cellVal.add(cell);
//                                        formService.updateCellValue(cellId, cellValue);
                                    }
                                }
                                int dataType = 0;
                                int objectId = 0;
                                if (StringUtils.hasLength(request.getParameter(HDDFILLEDBY + i)) && Integer.parseInt(request.getParameter(HDDFILLEDBY + i)) == 2) {
                                    if (StringUtils.hasLength(request.getParameter("hdCellType_" + j + "_" + i))) {
                                        boolean toBeUpdate = false;
                                        cellId = StringUtils.hasLength(request.getParameter("hdCellId_" + j + "_" + i)) ? Integer.parseInt(request.getParameter("hdCellId_" + j + "_" + i)) : 0;
                                        if (!request.getParameter("hdCellType_" + j + "_" + i).equals(request.getParameter("selCellType_" + j + "_" + i))) {
                                            dataType = Integer.parseInt(request.getParameter("selCellType_" + j + "_" + i));
                                            toBeUpdate = true;
                                        }
                                        if (StringUtils.hasLength(request.getParameter("selMasterField_" + j + "_" + i))) {
                                            dataType = Integer.parseInt(request.getParameter("selCellType_" + j + "_" + i));
                                            if (dataType == masterField && !request.getParameter("selMasterField_" + j + "_" + i).equals(request.getParameter("hdObjectId_" + j + "_" + i))) {
                                                objectId = Integer.parseInt(request.getParameter("selMasterField_" + j + "_" + i));
                                                toBeUpdate = true;
                                            }
                                        }
                                        if (StringUtils.hasLength(request.getParameter("selClientCombo_" + j + "_" + i))) {
                                            dataType = Integer.parseInt(request.getParameter("selCellType_" + j + "_" + i));
                                            if ((dataType == combobox || dataType == listBox) && !request.getParameter("selClientCombo_" + j + "_" + i).equals(request.getParameter("hdObjectId_" + j + "_" + i))) {
                                                objectId = Integer.parseInt(request.getParameter("selClientCombo_" + j + "_" + i));
                                                toBeUpdate = true;
                                            }
                                        }
                                        if (toBeUpdate) {
                                            Map<Integer, Integer[]> cell = new HashMap<Integer, Integer[]>();
                                            cell.put(cellId, new Integer[]{dataType, objectId});
                                            bidderCell.add(cell);

                                        }
                                    }
                                }
                            }
                        }
                        success = tenderFormService.updateFormHeadNCell(colHead, cellVal, bidderCell, tableId);
                        break;
                }
                if (success) {
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), formOperation == 1 ? "redirect_success_addformmatrix" : "redirect_success_updateformmatrix");
                } else {
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                }
            } catch (Exception ex) {
                return exceptionHandlerService.writeLog(ex);
            } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), formOperation == 1 ? bidFormCreate : bidFormEdit, formOperation == 1 ? addFormMatrixCreateAudit : addFormMatrixEditAudit, tenderId, tableId);
            }
        } else {
            return REDIRECT_SESSION_EXPIRED;
        }
        if (formOperation == 1 && autoColCnt!=0) {
            return "redirect:/etender/buyer/createformula/" + tenderId + "/" + formId + "/" + tableId + "/" + fromDash + encryptDecryptUtils.generateRedirect("etender/buyer/createformula/" + tenderId + "/" + formId + "/" + tableId + "/" + fromDash, request);
        } else {
            return "redirect:/etender/buyer/formdashboard/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/formdashboard/" + tenderId + "/" + formId, request);
        }
    }
    /**
     * Create Formula GET
     *
     * @param tenderId
     * @param fromDash
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/createformula/{tenderId}/{formId}/{tableId}/{fromDash}/{enc}", method = RequestMethod.GET)
    public String createFormula(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, @PathVariable("tableId") Integer tableId, @PathVariable("fromDash") Integer fromDash, ModelMap modelMap, HttpServletRequest request) {
        try {
            List<Object[]> list = tenderFormService.getTenderTableDetails(tableId);
            if (list != null && !list.isEmpty()) {
                modelMap.addAttribute("rowcount", list.get(0)[6]);
                modelMap.addAttribute("colcount", list.get(0)[7]);
                modelMap.addAttribute("tableName", list.get(0)[2]);
                modelMap.addAttribute("hasGTRow", list.get(0)[9]);
            }
            int rebateAvail = tenderFormService.checkTenderHasRebate(tenderId);
            int decimalValueUpto = (Integer) tenderCommonService.getTenderField(tenderId, "decimalValueUpto");
            modelMap.addAttribute("decimalValueUpto", decimalValueUpto);
            int tenderResult = 1/*(Integer) tenderCommonService.getTenderField(tenderId, "tenderResult")*/;
            //Filled By - Tenderer:1, Bidder:2, Auto:3, Proxy Bid Column:4
            //Data Type - SmallText:1, LongText:2, +No. with (.):3, +No. without (.):4, All Numbers:8              
            List<TblTenderColumn> columns = tenderFormService.getTenderColumnByTableId(tableId);
            List<SelectItem> autoCols = new ArrayList<SelectItem>();
//            List<SelectItem> govCols = new ArrayList<SelectItem>();//remgovcol
            List<TblTenderFormula> formulas = tenderFormService.getTenderFormulaByTableId(tableId);
            modelMap.put("rebateAvail", rebateAvail);
            if (rebateAvail != -1 && tenderResult!=2) {
                Set<Integer> gtColumnId = new HashSet<Integer>();
                for (TblTenderFormula formula : formulas) {
                    if (formula.getFormula().startsWith(TOTAL)) {
                        gtColumnId.add(formula.getTblTenderColumn().getColumnId());
                    }
                }
                if(!gtColumnId.isEmpty()){
                List<Object[]> gtCol = tenderFormService.getTenderCellRebateGT(gtColumnId);
                Map<Integer, Integer> gtCols = new HashMap<Integer, Integer>();
                for (Object[] col : gtCol) {
                    gtCols.put((Integer) col[0], (Integer) col[1]);
                }
                modelMap.put("gtCols", gtCols);
                }
            }
//            List<Object[]> govColumn = tenderFormService.getGovColumn(tableId);//remgovcol
//            String govColName = null;//remgovcol
//            long govColId = 0;//remgovcol
            int noautoCnt = 0;            
            for (TblTenderColumn tblTenderColumn : columns) {
                if (tblTenderColumn.getFilledBy() == 3 && tblTenderColumn.getDataType() != autoNumber) {
                    boolean addit = true;
                    for (TblTenderFormula formula : formulas) {
                        if (formula.getTblTenderColumn().getColumnId() == tblTenderColumn.getColumnId() && !formula.getDisplayFormula().startsWith(TOTAL) && !formula.getFormula().startsWith("VCF_") && !formula.getFormula().startsWith("VF_") && !formula.getFormula().startsWith("SPF_")) {
                            addit = false;
                        }
                    }
                    if (addit) {
                        boolean isText = (tblTenderColumn.getDataType() == smalltext || tblTenderColumn.getDataType() == longtext);
                        autoCols.add(new SelectItem(tblTenderColumn.getColumnHeader(), tblTenderColumn.getColumnId() + "_" + tblTenderColumn.getColumnNo() + "_" + isText));
                    }
                } else {
                    noautoCnt++;
                }                
                /*if (govColumn.isEmpty()) {//remgovcol
                    if ((tblTenderColumn.getFilledBy() == 3 || tblTenderColumn.getFilledBy() == 2) && (tblTenderColumn.getDataType() == numeric || tblTenderColumn.getDataType() == money || tblTenderColumn.getDataType() == moneyall)) {
                        govCols.add(new SelectItem(tblTenderColumn.getColumnHeader(), tblTenderColumn.getColumnId() + "_" + tblTenderColumn.getColumnNo()));
                    }
                } else {
                    if ((Integer) govColumn.get(0)[0] == tblTenderColumn.getColumnId()) {
                        govColName = tblTenderColumn.getColumnHeader();
                        govColId = tblTenderColumn.getColumnId();
                    }
                }*/
            }
//            modelMap.addAttribute("seletedGovCol", govColName);//remgovcol
//            modelMap.addAttribute("seletedGovColId", govColId);//remgovcol
            modelMap.addAttribute("autoCols", autoCols);
            modelMap.addAttribute("noautocol", noautoCnt == columns.size());
//            modelMap.addAttribute("govCols", govCols);//remgovcol
            modelMap.addAttribute("columns", columns);
            if (!columns.isEmpty()) {
                List<Integer> comboId = new ArrayList<Integer>();
                List<TblTenderCell> cells = tenderFormService.getTenderCellByTableIdOneRow(tableId);            
                for (TblTenderCell tenderCell : cells) {
                    if(tenderCell.getDataType()==combobox){
                        comboId.add(tenderCell.getObjectId());
                    }
                }
                if(!comboId.isEmpty()){
                    List<Object> combos = tenderFormService.getCalculationCombo(comboId);
                    if(!combos.isEmpty()){
                        modelMap.addAttribute("combos",tenderFormService.getComboDetailByComboId(combos.toArray()));                        
                        modelMap.addAttribute("calcombo",combos);
                    }
                }
                modelMap.addAttribute("cells", cells);
            }
            modelMap.put("tenderResult", tenderResult);
            modelMap.put("formulas", formulas);
            boolean conditionBtn = false;
            boolean autoColFinish = false;
            if (noautoCnt != columns.size()) {
                if (autoCols.isEmpty()) {
                    autoColFinish = true;
                }
            } else {
                autoColFinish = true;
            }

            conditionBtn = autoColFinish /*&& govColName != null*/;//remgovcol
            modelMap.put("conditionBtn", conditionBtn);
            if (conditionBtn) {
                boolean tenderMode = (Integer) tenderCommonService.getTenderField(tenderId, "tenderMode") == 2;
                modelMap.put("limited", tenderMode);
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormFormulaGovCol, createFormulaAudit, tenderId, tableId);
        }
        return "/etender/buyer/CreateFormula";
    }

    /**
     * Create Formula POST
     *
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/addformformula", method = RequestMethod.POST)
    public String addFormFormula(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
        int tableId = StringUtils.hasLength(request.getParameter(HIDDEN_TABLE_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TABLE_ID)) : 0;
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        String fromDash = StringUtils.hasLength(request.getParameter(FROM_DASH)) ? request.getParameter(FROM_DASH) : "0";
        String hasGTRow = StringUtils.hasLength(request.getParameter("hdHasGTRow")) ? request.getParameter("hdHasGTRow") : "0";
        boolean success = false;
        String pageName = REDIRECT_SESSION_EXPIRED;
        if(abcUtility.getSessionUserId(request)!=0){
            try {
                String[] colNoNId = request.getParameter("selAutoCol") != null ? request.getParameter("selAutoCol").split("_") : null;
                List<TblTenderFormula> tenderFormulas = new ArrayList<TblTenderFormula>();
                TblTenderFormula tenderFormula = null;
                boolean formulaCellAdd = false;
                if (colNoNId != null) {
                    tenderFormula = new TblTenderFormula();
                    tenderFormula.setCellId(0);
                    tenderFormula.setCellNo(0);
                    tenderFormula.setFormulaType(1);
                    tenderFormula.setColumnNo(Integer.parseInt(colNoNId[1]));
                    tenderFormula.setDisplayFormula(request.getParameter("frmaFormFormula"));
                    tenderFormula.setFormula(request.getParameter("frmFormFormula2").replace("txtcell_0_", ""));
                    tenderFormula.setColFormula(request.getParameter("frmFormFormula2").replace("txtcell_0_", ""));
                    tenderFormula.setTblTenderColumn(new TblTenderColumn(Integer.parseInt(colNoNId[0])));
                    tenderFormula.setTblTenderForm(new TblTenderForm(formId));
                    tenderFormula.setTblTenderTable(new TblTenderTable(tableId));
                    tenderFormulas.add(tenderFormula);
                }
    //            String[] gcolNoNId = request.getParameter("selGovCol") != null ? request.getParameter("selGovCol").split("_") : null;
    //            TblTenderGovColumn tenderGovColumn = null;
                String[] grtCols = request.getParameterValues("chktotalFormula");
                List<TblTenderCell> tenderCells = new ArrayList<TblTenderCell>();
                String colHeads = request.getParameter("hdColHeads");
                String[] colHeadArr = colHeads != null && colHeads.endsWith(",") ? colHeads.split(",") : null;
    //            int actualCellId = 0;
                int colcount = StringUtils.hasLength(request.getParameter("hdColCount")) ? Integer.parseInt(request.getParameter("hdColCount")) : 0;
                int rowcount = StringUtils.hasLength(request.getParameter("hdRowCount")) ? Integer.parseInt(request.getParameter("hdRowCount")) : 0;
                int cellNo = colcount * rowcount;
    //            if (gcolNoNId != null) {//remgovcol
                    /*if (tenderFormService.getTotalFormula(tableId, Integer.parseInt(gcolNoNId[0]))) {//remgovcol
                        actualCellId = tenderFormService.getGovCell(Integer.parseInt(gcolNoNId[0]), rowcount);
                    } else {*/
                if(grtCols!=null && hasGTRow.equals("0")){
                        String colIds = request.getParameter("hdColIds");
                        String colSorts = request.getParameter("hdColSorts");
                        String[] colSortArr = colSorts != null && colSorts.endsWith(",") ? colSorts.split(",") : null;                        
                        String[] colIdArr = colIds != null && colIds.endsWith(",") ? colIds.split(",") : null;                        
                        if (colIdArr != null) {
                            for (int i = 0; i < colcount; i++) {
                                TblTenderCell tenderCell = new TblTenderCell();
                                tenderCell.setCellNo(cellNo+(Integer.parseInt(colSortArr[i])-1) );
//                                System.out.println("cellNo "+tenderCell.getCellNo());
                                tenderCell.setRowId(rowcount + 1);
                                tenderCell.setTblTenderColumn(new TblTenderColumn(Integer.parseInt(colIdArr[Integer.parseInt(colSortArr[i])-1])));
//                                System.out.println("col "+tenderCell.getTblTenderColumn().getColumnId());
                                tenderCell.setTblTenderTable(new TblTenderTable(tableId));
                                tenderCell.setTblTenderForm(new TblTenderForm(formId));
                                tenderCell.setCellValue("");
                                tenderCell.setDataType(0);
                                tenderCell.setObjectId(0);
                                tenderCells.add(tenderCell);
//                                cellNo++;
                            }
                            formulaCellAdd = true;
    //                        formService.addFormulaCell(tenderCells, rowcount + 1, colcount, tableId);
                        }
                }
    //                }//remgovcol
    //            }//remgovcol
                /*if (gcolNoNId != null) {//remgovcol
                    tenderGovColumn = new TblTenderGovColumn();
                    String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
                    tenderGovColumn.setColumnNo(Integer.parseInt(gcolNoNId[1]));
                    tenderGovColumn.setIpAddress(ipAddress);
                    tenderGovColumn.setCellId(actualCellId);
                    tenderGovColumn.setTblTenderColumn(new TblTenderColumn(Integer.parseInt(gcolNoNId[0])));
                    tenderGovColumn.setTblTenderTable(new TblTenderTable(tableId));
                    tenderGovColumn.setTblTenderForm(new TblTenderForm(formId));
                }*/
                if (grtCols != null) {
                    for (String gtTotal : grtCols) {
                        String[] gtTotalNoNId = gtTotal.split("_");
                        tenderFormula = new TblTenderFormula();
                        tenderFormula.setCellId(0);
                        tenderFormula.setCellNo(0);
                        tenderFormula.setFormulaType(1);
                        tenderFormula.setColumnNo(Integer.parseInt(gtTotalNoNId[2]));
                        String formulaCol = colHeadArr[Integer.parseInt(gtTotalNoNId[1]) - 1];
                        tenderFormula.setDisplayFormula(TOTAL + formulaCol + ")");
                        tenderFormula.setFormula(TOTAL + gtTotalNoNId[2] + ")");
                        tenderFormula.setColFormula(TOTAL + gtTotalNoNId[2] + ")");
                        tenderFormula.setTblTenderColumn(new TblTenderColumn(Integer.parseInt(gtTotalNoNId[0])));
                        tenderFormula.setTblTenderTable(new TblTenderTable(tableId));
                        tenderFormula.setTblTenderForm(new TblTenderForm(formId));
                        tenderFormulas.add(tenderFormula);
                    }
                }
                tenderFormService.addFormula(tenderFormulas, /*tenderGovColumn,//remgovcol*/ formulaCellAdd, tenderCells, rowcount + 1, colcount, tableId);
                success = true;
            } catch (Exception e) {
                pageName = exceptionHandlerService.writeLog(e);
            } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormFormulaGovCol, addFormFormulaAudit, tenderId, tableId);
            }
            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_formulacreated" : CommonKeywords.ERROR_MSG_KEY.toString());
            pageName = "redirect:/etender/buyer/createformula/" + tenderId + "/" + formId + "/" + tableId + "/" + fromDash + encryptDecryptUtils.generateRedirect("etender/buyer/createformula/" + tenderId + "/" + formId + "/" + tableId + "/" + fromDash, request);
        }
        return pageName;
    }

    /**
     * Delete Form Formula GET
     *
     * @param tenderId
     * @param formulaId
     * @param fromDash
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/buyer/deleteformula", method = RequestMethod.POST)
    public String deleteFormula(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
        int tableId = StringUtils.hasLength(request.getParameter(HIDDEN_TABLE_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TABLE_ID)) : 0;
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        int rowcount = StringUtils.hasLength(request.getParameter("hdRowCount")) ? Integer.parseInt(request.getParameter("hdRowCount")) : 0;
        String fromDash = StringUtils.hasLength(request.getParameter(FROM_DASH)) ? request.getParameter(FROM_DASH) : "0";
        int gtw = StringUtils.hasLength(request.getParameter("hdHasGTRow")) ? Integer.parseInt(request.getParameter("hdHasGTRow")) : 0;
        String[] formulaIds = request.getParameterValues("chkFormulaId");
        try {
            int counter=0;
            if(formulaIds!=null){
                for (String formula : formulaIds) {
                    if(formula!=null && formula.contains("_")){
                        String[] formulas = formula.split("_");
                        int formulaId = Integer.parseInt(formulas[0]);
                        int columnId = Integer.parseInt(formulas[1]);
                        int cellId = Integer.parseInt(formulas[2]);
                        if(tenderFormService.deleteFormula(formulaId, tableId, rowcount, columnId, gtw == 1,cellId!=0,tenderId)){
                            counter++;
                        } 
                    }
                }
            }
            redirectAttributes.addFlashAttribute(counter!=0 ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), counter!=0 ? "redirect_success_formuladeleted" : CommonKeywords.ERROR_MSG_KEY.toString());
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormFormulaDel, deleteFormulaAudit, tenderId, tableId);
        }
        return "redirect:/etender/buyer/createformula/" + tenderId + "/" + formId + "/" + tableId + "/" + fromDash + encryptDecryptUtils.generateRedirect("etender/buyer/createformula/" + tenderId + "/" + formId + "/" + tableId + "/" + fromDash, request);
    }

    /**
     * Remove Governing Column GET
     *
     * @param tenderId
     * @param tableId
     * @param columnId
     * @param rowCount
     * @param gtw
     * @param fromDash
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/buyer/changegovcol/{tenderId}/{formId}/{tableId}/{columnId}/{rowCount}/{gtw}/{fromDash}/{enc}", method = RequestMethod.GET)
    public String changeGovCol(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, @PathVariable(TABLE_ID) Integer tableId, @PathVariable("columnId") Integer columnId, @PathVariable("rowCount") Integer rowCount, @PathVariable("gtw") Integer gtw, @PathVariable("fromDash") Integer fromDash, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        try {
            boolean success = tenderFormService.changeGovCol(tableId, columnId, gtw == 1, rowCount);
            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_changegovcol" : CommonKeywords.ERROR_MSG_KEY.toString());
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);   
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormRemGovCol, changeGovColAudit, tenderId, columnId);
        }
        return "redirect:/etender/buyer/createformula/" + tenderId + "/" + formId + "/" + tableId + "/" + fromDash + encryptDecryptUtils.generateRedirect("etender/buyer/createformula/" + tenderId + "/" + formId + "/" + tableId + "/" + fromDash, request);
    }

    /**
     * View Form Matrix GET
     *
     * @param tenderId
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/viewform/{tenderId}/{formId}/{isWorkFlow}/{enc}", method = RequestMethod.GET)
    public String viewForm(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, @PathVariable("isWorkFlow") Integer isWorkFlow, ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("columnType",tenderFormService.getColumnType());
            tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("isWorkFlow",isWorkFlow);
            dataTypeWithExample(modelMap);
            List<Object> usedDataTypes = tenderFormService.getDataTypesByFormId(formId);
            Set<Object> usedDataTypesSet = new HashSet<Object>(usedDataTypes);
            modelMap.addAttribute("usedDataTypes", usedDataTypesSet);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormView, viewFormAudit, tenderId, formId);
        }
        return "/etender/buyer/ViewForm";
    }
    
    /**
     * @author keval.soni
     * set Data type and Its Example in ModelMap
     * @param modelMap
     */
    private void dataTypeWithExample(ModelMap modelMap){
    	Map<Integer,String> dataType = new HashMap<Integer,String>();
        dataType.put(smalltext,"Small Text|~|ABC etc.");
        dataType.put(longtext,"Long Text|~|There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable etc.");
        dataType.put(numeric,"+No. without (.)|~|123, 445, Zero etc.. Values are allowed. Decimal (Point value) & Minus values are not allowed.");//Numeric
        dataType.put(money,"+No. with (.)|~|123, 12.30, 123.44, Zero etc.., values are allowed. Minus value are not allowed.");//Money (Positive)
        dataType.put(moneyall,"All Numbers|~|123, 1.23, -123, Zero etc.. Values are allowed.");//Money (All)
        dataType.put(combobox,"Combo Box|~|List of combo box as created with alphanumeric characters");
        dataType.put(date,"Date|~|Date picker");
        dataType.put(listBox,"List Box|~|List of list box as created with alphanumeric characters");
        dataType.put(masterField,"Master Field|~|List of Master fields as created");
        dataType.put(autoNumber,"Auto Number|~|Auto generated numbers like 1,2,3,4 etc.");
        modelMap.addAttribute("dataType", dataType);
    }
    /**
     * Test Form Matrix GET     
     * @param tenderId
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/testform/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)
    public String testForm(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, ModelMap modelMap, HttpServletRequest request) {
        try {
            tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
            dataTypeWithExample(modelMap);
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("decimalUpto",tenderCommonService.getTenderField(tenderId, "decimalValueUpto"));
            modelMap.addAttribute("formsor", false);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormTest, testFormAudit, tenderId, formId);
        }
        return "/etender/buyer/TestForm";
    }

    
    @RequestMapping(value = "/buyer/viewtable/{tenderId}/{formId}/{tableId}/{enc}", method = RequestMethod.GET)
    public String viewTable(@PathVariable("tenderId") int tenderId, @PathVariable("formId") int formId, @PathVariable("tableId") int tableId,
            HttpServletRequest request, ModelMap modelMap) {
        try {
            List<Integer> formulaColId = new ArrayList<Integer>();
            List<Object[]> allFormula = tenderFormService.getFormulaColId(tableId);
            List<Object[]> lstTblDetails = tenderFormService.getTableDetails(formId, tableId);
            int GTWise = 0;
            int rowCount = 0;
            for (Object[] formula : allFormula) {
                if (formula[2].toString().startsWith(TOTAL)) {
                    formulaColId.add((Integer) formula[0]);
                }
            }
            if (!lstTblDetails.isEmpty()) {
                GTWise = (Integer) lstTblDetails.get(0)[5];
                rowCount = (Integer) lstTblDetails.get(0)[0];
                modelMap.put("rowcount", GTWise == 1 ? (rowCount - 1) : rowCount);
                modelMap.put("tableDtls", lstTblDetails);
            }
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.put("formulaColId", formulaColId);
            modelMap.put("cellDtls", tenderFormService._toCellMasters(tenderFormService.getTableJson(tableId)));
            modelMap.put("columnDtls", tenderFormService.getTenderColumnByTableId(tableId));

        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewTableLinkId, "Access view tender table page", tenderId, formId);
        }
        return "etender/buyer/ViewTable";
    }

    @RequestMapping(value = "/buyer/cancelform/{formId}/{tenderId}/{enc}", method = RequestMethod.GET)
    public String approveForm(@PathVariable("formId") Integer formId, @PathVariable("tenderId") Integer tenderId, ModelMap modelMap, HttpServletRequest request) {
        try {
            tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
            int userId = abcUtility.getSessionUserId(request);
            modelMap.addAttribute("isWorkFlow",0); 
            modelMap.addAttribute("iscancel", 1);
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("isFinalSubmissionDoneByBidder", eventBidSubmissionService.isFinalSubmissionDone(tenderId)); //Bug Id: #31872
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),cancelFormLinkId, getCancelForm, tenderId, formId);
        }
        return "etender/buyer/ViewForm";
    }

    @RequestMapping(value = "/buyer/submitcancelform", method = RequestMethod.POST)
    public String submitApproveForm(ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String remarks = request.getParameter("txtaRemarks");
        boolean updateSuccess=false;
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
        int userDetailId=abcUtility.getSessionUserDetailId(request);
        int isBiddingFormPublishWithTender = 0;
        try {
             int corrigendumId=tenderCorrigendumService.getPendingCorrigendumId(tenderId);
             List<Object[]> clientConfigList=commonService.getClientConfigurations(abcUtility.getSessionClientId(request));
            if(!clientConfigList.isEmpty() && clientConfigList.size()>0){
                    isBiddingFormPublishWithTender = Integer.parseInt(clientConfigList.get(0)[3].toString());
            }
             if(corrigendumId>0){
            	boolean isFormCancelled = tenderCorrigendumService.isFormCancelled(corrigendumId,formId);
            	if(!isFormCancelled){
                tenderCorrigendumService.cancelFormCorrigendumById(userDetailId, corrigendumId, formId);
                updateSuccess=true;
            	}
             }else{
                updateSuccess= tenderFormService.updateFormStatus(formId, 2,userDetailId);  
                //Added by Mitesh
                int envelopeId= tenderFormService.getEnvelopeIdByFormId(formId);
                updateSuccess= tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(envelopeId);
             }
            if (updateSuccess) {
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_formcanceled");
            } else {
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "Form cancelled successfully", tenderId, formId, remarks);
        }
        return "redirect:/etender/buyer/tenderdashboard/" + tenderId + "/2"+ encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/2", request);
    }
    /**
     * 
     * @param viewType
     * @param tenderId
     * @param modelMap
     * @param request
     * @return 
     */
    @RequestMapping(value = "/buyer/organizeform/{viewType}/{tenderId}/{enc}", method = RequestMethod.GET)
    public String organizeForm(@PathVariable("viewType") String viewType, @PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request) {
        String retunVal=REDIRECT_SESSION_EXPIRED;
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                List<Integer> cStatusList=new ArrayList<Integer>();
                cStatusList.add(1);
                cStatusList.add(4);
                int envelopeType = (Integer) modelMap.get("envelopeType");
                boolean isTechnocommerceSelected = false;
                List<Object[]> tenderEnvelopeLst = tenderCommonService.getTenderEnvelopeByTenderId(tenderId,false,false,cStatusList);
                for(Object[] object : tenderEnvelopeLst )
                {
                	if(object[2].equals(5)){
                		isTechnocommerceSelected  = true;
                	}
                }
                
                modelMap.addAttribute("tenderEnvelopeLst", tenderEnvelopeLst);
                modelMap.addAttribute("tenderFormLst", tenderFormService.getOrganizeTenderFormByTenderId(tenderId));
                modelMap.addAttribute("isConsortiumAllowed", tenderCommonService.isConsortiumByTenderId(tenderId));
                if( (Integer) modelMap.get("isConsortiumAllowed") == 0){
                	List<TblCorrigendum> tblcorrigendum= tenderCorrigendumService.getPendingCorrigendumByTenderId(tenderId);
                	if(tblcorrigendum!=null && !tblcorrigendum.isEmpty()){
                		List<TblCorrigendumDetail> lsttblcorrigendumdetail =  tenderCorrigendumService.getCorrigendumDetailByTenderId(tblcorrigendum.get(0).getCorrigendumId());
                		for(TblCorrigendumDetail tblcorrigendumdetail : lsttblcorrigendumdetail){
                			if(tblcorrigendumdetail.getFieldName().equalsIgnoreCase("isConsortiumAllowed")){
                				 modelMap.addAttribute("isConsortiumAllowed",1);
                			}
                			
                		}
                		
                	}
                	
                }
                //table details
                List<Object[]> tableDetailList = tenderFormService.getTableDetailsByTenderId(tenderId);
                modelMap.addAttribute("tableList", tableDetailList);
                List<Object[]> countList = tenderFormService.getTenderEnvelopeFormCount(tenderId);
                
                //Added by Mitesh
                Map<Integer,Integer> envelopeWiseMinFormCounter=new HashMap<Integer, Integer>();
                //fill the map with default value
                for (Object[] objects : countList) {
                    envelopeWiseMinFormCounter.put(Integer.parseInt(objects[1].toString()), Integer.parseInt(objects[0].toString()));//0-count,1 envelopeId
                }
                //fill the map with corrigendum value
                List<Object[]> corrigendumForms= tenderCorrigendumService.getCorrigendumDetailsByTenderId(tenderId);
                Map<Integer,Integer> formStatusMap=new HashMap<Integer, Integer>();
                if(corrigendumForms!=null && corrigendumForms.size()>0)
                {
                    for (Object[] objects : corrigendumForms) {
                        formStatusMap.put(Integer.parseInt(objects[1].toString()), Integer.parseInt(objects[3].toString()));//1-form id,3-action type
                    }
                }
             // Get counter for pricebid and technicalbid form available in envelope
                Map<Integer,Integer> priceBidMinFormCounter=new HashMap<Integer, Integer>();
                Map<Integer,Integer> technicalMinFormCounter=new HashMap<Integer, Integer>();
                if(isTechnocommerceSelected)
                {
                	List<Object[]> object  = tenderFormService.getTenderEnvelopePriceBidFormCount(tenderId);
                	Object[] objectDetail=null;
                	if(object  != null && !object.isEmpty()){
                		objectDetail = object.get(0);
                		priceBidMinFormCounter.put(Integer.parseInt(objectDetail[1].toString()), Integer.parseInt(objectDetail[0].toString()));
                	}
                    object  = tenderFormService.getTenderEnvelopeTechnicalFormCount(tenderId);
                    if(object  != null && !object.isEmpty()){
                    	objectDetail = object.get(0);
                    	technicalMinFormCounter.put(Integer.parseInt(objectDetail[1].toString()), Integer.parseInt(objectDetail[0].toString()));
                    }
                    

                    //fill the map with corrigendum value ,Remove count if form is cancel in corrigendum for pricebid
                    if(corrigendumForms!=null && corrigendumForms.size()>0)
                    {
                        for (Object[] objects : corrigendumForms) {
                            formStatusMap.put(Integer.parseInt(objects[1].toString()), Integer.parseInt(objects[3].toString()));//1-form id,3-action type
                        }
                    }
                    //Remove count if form is cancel in corrigendum for technicalbid form
                    if(corrigendumForms!=null && corrigendumForms.size()>0)
                    {
                        for (Object[] objects : corrigendumForms) {
                            formStatusMap.put(Integer.parseInt(objects[1].toString()), Integer.parseInt(objects[3].toString()));//1-form id,3-action type
                        }
                    }
                    modelMap.addAttribute("priceBidMinFormCounter", priceBidMinFormCounter);
                    modelMap.addAttribute("technicalMinFormCounter", technicalMinFormCounter);
                }
                // Remove count from global variable envelopeWiseMinFormCounter for technical forms.
                for(Map.Entry<Integer, Integer> map : envelopeWiseMinFormCounter.entrySet())
                {
                	if(technicalMinFormCounter.containsKey(map.getKey()))
                	{
                		Integer temp = technicalMinFormCounter.get(map.getKey());
                		int pricebidcount = envelopeWiseMinFormCounter.get(map.getKey());
                		pricebidcount = pricebidcount - temp;
                		envelopeWiseMinFormCounter.put(map.getKey(), pricebidcount);
                	}
                	
                }
                modelMap.addAttribute("formCounterEnvwise", envelopeWiseMinFormCounter);
                modelMap.addAttribute("formStatusMap", formStatusMap);
                modelMap.addAttribute("isCorrigendumPending",tenderCorrigendumService.getPendingCorrigendumId(tenderId));
                List<Object[]> minFormCount = tenderFormService.getTenderEnvelopeMinFormRequiredCount(tenderId);
                Map<Integer,Integer> selectedMinform=new HashMap<Integer, Integer>();
                Map<Integer,Integer> selectedTechform=new HashMap<Integer, Integer>();
                for (Object[] objects : minFormCount) {
                	List<Object[]> CorrigendumDetailList = tenderFormService.getCorrigendumDetailByObjectId(Integer.parseInt(objects[0].toString())); 
                	if(CorrigendumDetailList != null && !CorrigendumDetailList.isEmpty()){
                		for (Object[] object : CorrigendumDetailList) {
                			if("minFormsReqforBidding".equalsIgnoreCase(object[3].toString())){
                    			selectedMinform.put(Integer.parseInt(object[0].toString()), Integer.parseInt(object[2].toString()));
                    		}else if("minTechFormsReqforBidding".equalsIgnoreCase(object[3].toString())){
                    			selectedTechform.put(Integer.parseInt(object[0].toString()), Integer.parseInt(object[2].toString()));
                    		}
						}
                	}else{
                		selectedMinform.put(Integer.parseInt(objects[0].toString()), Integer.parseInt(objects[1].toString()));
                		selectedTechform.put(Integer.parseInt(objects[0].toString()), Integer.parseInt(objects[2].toString()));
                	}
                	
                    
                }
                modelMap.addAttribute("selectedMinform",selectedMinform);
                modelMap.addAttribute("selectedTechform",selectedTechform);
                //Ended by Mitesh
                if (viewType.equals("update")) {
                    Map<Integer,List<SelectItem>> formSelectMap=new HashMap<Integer, List<SelectItem>>();
                    Integer envId = 0;
                    Set<Integer> envelopeCout=envelopeWiseMinFormCounter.keySet();
                    Iterator iter=envelopeCout.iterator();
                    while(iter.hasNext()){//envelope ids
                        envId = (Integer) iter.next();
                        List<SelectItem> items = new ArrayList<SelectItem>();
                        for (int i = 1; i <= envelopeWiseMinFormCounter.get(envId); i++) {  
                                items.add(new SelectItem(i, i));
                        }   
                        formSelectMap.put(envId,items);
                    }
                    envelopeCout=technicalMinFormCounter.keySet();
                    iter=envelopeCout.iterator();
                    // for manage sort order add count for form
                    while(iter.hasNext()){//envelope ids
                        envId = (Integer) iter.next();
                        List<SelectItem> items = formSelectMap.get(envId);
                        //List<SelectItem> items = new ArrayList<SelectItem>();
                        for (int i = 1; i <= technicalMinFormCounter.get(envId); i++) {
                                items.add(new SelectItem(items.size()+1, items.size()+1));
                        }   
                        formSelectMap.put(envId,items);
                    }
                    modelMap.addAttribute("tenderFormCount", formSelectMap);
                    //Added by Mitesh
                    List<Object[]> mandTableDetailsList=tenderFormService.getMandatoryTableDetails(tenderId);
                    formSelectMap=new HashMap<Integer, List<SelectItem>>();
                    Map<Integer,Integer> formMinTableMap = new HashMap<Integer,Integer>();
                    for (Object[] tableRow : mandTableDetailsList) {
                        int mandatoryTableCount,numberOfTables,mandatoryTable;
                        mandatoryTableCount=Integer.parseInt(tableRow[5].toString());
                        numberOfTables=Integer.parseInt(tableRow[6].toString());
                        mandatoryTable=Integer.parseInt(tableRow[7].toString());
                        List<SelectItem> items = new ArrayList<SelectItem>();
                        for(int i=mandatoryTable;i<=numberOfTables;i++){
                            items.add(new SelectItem(i, i));
                        }
                        formSelectMap.put(Integer.parseInt(tableRow[0].toString()), items);//Add into map with formId
                        formMinTableMap.put(Integer.parseInt(tableRow[0].toString()),mandatoryTableCount);
                    }
                      modelMap.addAttribute("formSelectMap", formSelectMap);
                      modelMap.addAttribute("formMinTableMap", formMinTableMap);
                }
                modelMap.addAttribute("tenderId", tenderId);
                modelMap.addAttribute("isFinalSubmissionDoneByBidder", eventBidSubmissionService.isFinalSubmissionDone(tenderId));
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),organizeFromView, getorganizeform, tenderId, 0);
        }
        if (viewType.equals("view")) {
            retunVal= "/etender/buyer/TenderOrganizeViewForm";
        } else {
           retunVal="/etender/buyer/TenderOrganizeForm";
        }
        return retunVal;
    }
    /**
     * 
     * @param redirectAttributes
     * @param request
     * @return 
     */
    @RequestMapping(value = "/buyer/updateorganizeform", method = RequestMethod.POST)
    public String updateTenderOrganizeForm(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        boolean success = false;
        int tenderId=0;
        boolean check=true;
        try {
            if (request.getParameter("hdtotalFeild") != null && Integer.parseInt(request.getParameter("hdtotalFeild")) > 0) {
             // validate num of form and table mandatory Mitesh server side validation
              tenderId = Integer.valueOf(request.getParameter("hdtenderId"));
//                 List<Object[]> mandTableDetailsList=tenderFormService.getMandatoryTableDetails(tenderId);
//                 List<Object[]> mandFormsDetailsList=tenderFormService.getMandatoryFormsDetails(tenderId);
//                  //create map for form
//                    Map<String,Object[]> formMandMap=new HashMap<String, Object[]>();
//                    for (Object[] formRow : mandFormsDetailsList) {
//                        Integer[] formCountList=new Integer[2];
//                        formCountList[0]=Integer.parseInt(formRow[3].toString()); //Number of form mandatory count
//                        formCountList[1]=Integer.parseInt(formRow[4].toString());  //Number of form total count
//                        formMandMap.put(formRow[1].toString(), formCountList);
//                    }
//                    
//                 //create map for table
//                    Map<String,Object[]> tableMandMap=new HashMap<String, Object[]>();
//                    for (Object[] tableRow : mandTableDetailsList) {
//                        Integer[] tableCountList=new Integer[2];
//                        tableCountList[0]=Integer.parseInt(tableRow[5].toString()); //Number of mandatory count
//                        tableCountList[1]=Integer.parseInt(tableRow[6].toString());  //Number of the total table count
//                        tableMandMap.put(tableRow[0].toString(), tableCountList);
//                    }
//                    //form validation
//                    boolean formValidate=true;
//                    String envelopeIds[]=request.getParameterValues("hdEnvelopeId");
//                    String minFormReqForBidding[]=request.getParameterValues("txtNoOfFormMand");
//                   System.out.println("envelopeIds.length "+envelopeIds.length);
//                    if(envelopeIds !=null && envelopeIds.length>0){
//                        for (int i=0 ; i<envelopeIds.length; i++) {
//                          Integer []formMandCount=(Integer[]) formMandMap.get(envelopeIds[i]);
//                            if(formMandCount!=null){
//                                System.out.println("Form "+minFormReqForBidding[i]+" Mandatory="+formMandCount[0]+" TOtal= "+formMandCount[1]);
//                                if(!((Integer.parseInt(minFormReqForBidding[i])>=formMandCount[0]) && (Integer.parseInt(minFormReqForBidding[i])<=formMandCount[1]))){
//                                formValidate=false;
//                                break;
//                             }
//                          }else{
//                                formValidate=false;
//                                break;
//                            }
//                        }
//                     }
//                    //Tabel validation
//                    boolean tableValidate=true;
//                    for (int i = 1; i < Integer.parseInt(request.getParameter("hdtotalFeild")); i++) {
//                      if (request.getParameter("selminTablesReqForBidding" + i) != null) {
//                          Integer []mandCount=(Integer[]) tableMandMap.get(request.getParameter("hdformId" + i));
//                          Integer minTablesReqForBidding=Integer.parseInt(request.getParameter("selminTablesReqForBidding"+i));
//                          if(mandCount!=null ){
//                              System.out.println("Table "+minTablesReqForBidding+" Madatory= "+mandCount[0]+" Total= "+mandCount[1]);
//                              if(!((minTablesReqForBidding>=mandCount[0]) && (minTablesReqForBidding<=mandCount[1]))){
//                                tableValidate=false;
//                                break;
//                              }
//                           }else{
//                                tableValidate=false;
//                                break;
//                            } 
//                        }
//                    }
                //End
               // if(tableValidate && formValidate){
                    success = tenderFormService.updateTederForm(request);
               // }
                    if(!success){
                    	check=false;
                    }
                    
                if(success){
                    success=tenderFormService.updateNoOfMandatoryBiddingForms(request);
                }
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), organizeFrom, postupdateorganizeform, Integer.valueOf(request.getParameter("hdtenderId").toString()), 0);
        }
        
        if(check==true)
        	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_organize_form" : CommonKeywords.ERROR_MSG_KEY.toString());
        else
        	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_biddin_form_modified");
        retVal = success ? TENDER_DASHBOARD_URL + tenderId + "/2" : "etender/buyer/gettenderenvelopeforpublish/" + tenderId+"/0";
        if(!check)
        	retVal=TENDER_DASHBOARD_URL + tenderId + "/2";
        /*
        if(httpSession.getAttribute("updateorganizeform")!=null && success==true)
        	request.removeAttribute("updateorganizeform");*/
        retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
        return retVal;
    }

    /**
 	 * Use to Open Rebate Report
 	 * @author krunal.patel
 	 * @param tenderId
 	 * @param modelMap
 	 * @param request
 	 * @param response
 	 * @throws Exception
 	 * @return
 	 */
     @RequestMapping(value = "/buyer/createrebatereport/{tenderId}/{enc}", method = RequestMethod.GET)                      
     public String createRebateAbstractReport(@PathVariable("tenderId")int tenderId,ModelMap modelMap, HttpServletResponse  response, HttpServletRequest request){
     	
     	String retVal = null;
     	int rebateId = 0;
     	int isCertRequired = 0;
     	boolean isDualCerti = false;
         try{
         	
 			List<Object[]> formList = null;
 			
 			/*** Get Common Services for tender detail **/
 			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
 			
 			isCertRequired =  Integer.parseInt(modelMap.get("isCertRequired").toString());
 			int isOpeningByCommittee =  Integer.parseInt(modelMap.get("isOpeningByCommittee").toString());
 			if(isCertRequired == 1){
 				isDualCerti = abcUtility.getSessionIsDualCerti(request);
 			}
 			
 			/*** Get Form List **/
         	formList = tenderFormService.getFormList(tenderId,rebateId,isDualCerti,isOpeningByCommittee);
         
         	modelMap.put("rbtFormYNList", commonService.getYesNo());
         	modelMap.put("tenderId", tenderId);
         	modelMap.put("formList", formList);
         	modelMap.put("crtUpdateFlag", "CRT");
         	
             retVal = "etender/buyer/CreateRebateConfig";
         }
         catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createRebateReportLinkId,  getcreaterebateform, tenderId, tenderId);
         }
         return retVal;
     } 
     /**
  	  * Use to Open Rebate Report Form for edit purpose
  	 * @author krunal.patel
  	 * @param tenderId
  	 * @param rebateId
  	 * @param modelMap
  	 * @param request
  	 * @param response
  	 * @throws Exception
  	 * @return
  	 */
     @RequestMapping(value = "/buyer/editrebatereport/{tenderId}/{rebateId}/{enc}", method = RequestMethod.GET)             
     public String editRebateAbstractReport(@PathVariable("tenderId")int tenderId,@PathVariable("rebateId")int  rebateId,ModelMap modelMap, HttpServletResponse response, HttpServletRequest request){
     	
     	String retVal = null;
     	int isCertRequired = 0;
     	boolean isDualCerti = false;
         try{
         	
 			List<Object[]> edtFormList = null;
 			List<Object[]> cancelFormList = null;
 			
 			/*** Get Common Services for tender detail **/
 			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
 			
 			
 			/*** Get Form List **/
 			isCertRequired =  Integer.parseInt(modelMap.get("isCertRequired").toString());
                        int isOpeningByCommittee =  Integer.parseInt(modelMap.get("isOpeningByCommittee").toString());
 			if(isCertRequired == 1){
 				isDualCerti = abcUtility.getSessionIsDualCerti(request);
 			}
 			 List<Object[]> formList = tenderFormService.getFormList(tenderId,rebateId,isDualCerti,isOpeningByCommittee);
         	
 			/*** Get Submitted Form List **/
         	edtFormList = tenderFormService.getEditFormListForRebate(rebateId);
         	
         	/*** Get Cancel form details and it can not checked at edit time **/
         	cancelFormList = tenderFormService.getCancelFormDtls(tenderId);			
			List<Object> encCancelFormList  = new ArrayList<Object>(); 
         	if(cancelFormList != null && !cancelFormList.isEmpty()){
	         	for(Object cancelList:cancelFormList){
	         		encCancelFormList.add(encryptDecryptUtils.encrypt(cancelList.toString()));
	         	}
         	}
         	modelMap.put("formIds",encCancelFormList);
         	modelMap.put("rbtFormYNList", commonService.getYesNo());
         	modelMap.put("tenderId", tenderId);
         	modelMap.put("rebateId", rebateId);
         	
         	modelMap.put("formList", formList);
         	modelMap.put("edtFormList", edtFormList);
         	
         	modelMap.put("crtUpdateFlag", "UPD");
         	
         	
             retVal = "etender/buyer/CreateRebateConfig";
         }
         catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editRebateReportLinkId,  geteditrebateform, tenderId, rebateId);
         }
         return retVal;
     } 
     
     /**
 	 * Use to save Rebate Report Form
 	 * @author krunal.patel
 	 * @param modelMap
 	 * @param request
 	 * @param response
 	 * @throws Exception
 	 * @return
 	 */
  @RequestMapping(value = "/buyer/addrebatereport", method = RequestMethod.POST)                       
  public String addRebateAbstractReport(ModelMap modelMap, HttpServletResponse response, HttpServletRequest  request,RedirectAttributes redirectAttributes)throws Exception{
  	
 	String retVal=REDIRECT_SESSION_EXPIRED;
  	boolean bSuccess = false;
  	int rebateId = 0;
  	int hdTenderId=0;
  	int isRebateForm=0;
  	String successMsg=null;
      try{
     	int sessionUserId = abcUtility.getSessionUserId(request);
  		if(sessionUserId!=0){
	        	 hdTenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;
	        	 isRebateForm = StringUtils.hasLength(request.getParameter("hdIsRebateForm"))? Integer.parseInt(request.getParameter("hdIsRebateForm")):0;
	        	 int isRebateYesNo = StringUtils.hasLength(request.getParameter("rdCrtFormYesNo"))?Integer.parseInt(request.getParameter("rdCrtFormYesNo")):0;
	         	/*** Start Code to set main Table Value **/
	         	
	         	TblRebate tblRebate = new TblRebate();
	         	tblRebate.setReportName(request.getParameter("txtReportName"));
	         	tblRebate.setTblTender(new TblTender(hdTenderId));
	         	tblRebate.setIsRebateForm(isRebateYesNo);
	         	String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
	         	tblRebate.setIpAddress(ipAddress);
	         	int userId = abcUtility.getSessionUserDetailId(request);
	         	tblRebate.setCreatedBy(userId);
	         	
	         	
	         	/*** Start Code to set Child Table Value **/
	         	List<TblRebateForm> tblRebateFormList = new ArrayList<TblRebateForm>();
	         	String[] forms = request.getParameterValues("chkForm");
	         	if(forms != null){
	 	        	for (int i = 0; i < forms.length; i++) {
	 	        		String[] formValue = forms[i].split("@");
	 	        		TblRebateForm tblRebateForm = new TblRebateForm();
	 	            	tblRebateForm.setTblRebate(tblRebate);
	 	            	tblRebateForm.setTblTenderForm(new TblTenderForm(Integer.parseInt(formValue[0])));
	 	            	tblRebateForm.setTblTenderCell(new TblTenderCell(Integer.parseInt(formValue[1])));
	 	            	tblRebateForm.setIpAddress(ipAddress);
	 	            	tblRebateForm.setCreatedBy(userId);
	 	            	tblRebateFormList.add(tblRebateForm);
	 				}
	         	}
	         	
	         	bSuccess = tenderFormService.addRebateDetail(tblRebate, tblRebateFormList);
	         	rebateId = tblRebate.getRebateId();
	         	successMsg = isRebateForm ==1?"msg_success_rebate_form_created":"msg_success_price_summary_form_configured_successfully";
  		}
      }
      catch(Exception e){
      	return exceptionHandlerService.writeLog(e);
      }finally {
          auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createRebateReportLinkId, rebateformcreated, hdTenderId, rebateId);
      }
      retVal=bSuccess?TENDER_DASHBOARD_URL+hdTenderId +"/2":"etender/buyer/createrebatereport/"+hdTenderId;
		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
		redirectAttributes.addFlashAttribute(bSuccess ? CommonKeywords.SUCCESS_MSG.toString() :CommonKeywords.ERROR_MSG.toString(), bSuccess ? successMsg : CommonKeywords.ERROR_MSG_KEY.toString());
      return retVal;
  }
  
  /**
 	 * Use to Update Rebate Report Form
 	 * @author krunal.patel
 	 * @param modelMap
 	 * @param request
 	 * @param response
 	 * @throws Exception
 	 * @return
 	 */
  @RequestMapping(value = "/buyer/updaterebatereport", method = RequestMethod.POST)                       
  public String updateRebateAbstractReport(ModelMap modelMap, HttpServletResponse response, HttpServletRequest request,RedirectAttributes redirectAttributes)throws Exception{
  	
 	String retVal=REDIRECT_SESSION_EXPIRED;
  	boolean bSuccess = false;
  	TblRebate tblRebate = null;
  	int tenderId=0;
  	int rebateId=0;
  	int isRebateForm=0;
  	String successMsg=null;
      try{
     	int sessionUserId = abcUtility.getSessionUserId(request);
   		if(sessionUserId!=0){
	        	 tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;
	        	 rebateId = StringUtils.hasLength(request.getParameter("hdRebateId"))? Integer.parseInt(request.getParameter("hdRebateId")):0;
	        	 isRebateForm = StringUtils.hasLength(request.getParameter("hdIsRebateForm"))? Integer.parseInt(request.getParameter("hdIsRebateForm")):0;
	        	 int isRebateYesNo = StringUtils.hasLength(request.getParameter("rdCrtFormYesNo"))?Integer.parseInt(request.getParameter("rdCrtFormYesNo")):0;
	         	/*** get main table row  **/
	         	tblRebate = tenderFormService.getRebateById(rebateId);        	
	         	
	         	tblRebate.setReportName(request.getParameter("txtReportName"));
	         	tblRebate.setTblTender(new TblTender(tenderId));
	         	tblRebate.setIsRebateForm(isRebateYesNo);
	         	String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
	         	tblRebate.setIpAddress(ipAddress);
	         	int userId = abcUtility.getSessionUserDetailId(request);
	         	tblRebate.setCreatedBy(userId);
	         	
	         	
	         	/*** Start Code to set Child Table Value **/
	         	List<TblRebateForm> tblRebateFormList = new ArrayList<TblRebateForm>();
	         	String[] forms = request.getParameterValues("chkForm");
	         	if(forms != null){
	 	        	for (int i = 0; i < forms.length; i++) {
	 	        		String[] formValue = forms[i].split("@");
	 	        		TblRebateForm tblRebateForm = new TblRebateForm();
	 	            	tblRebateForm.setTblRebate(tblRebate);
	 	            	tblRebateForm.setTblTenderForm(new TblTenderForm(Integer.parseInt(formValue[0])));
	 	            	tblRebateForm.setTblTenderCell(new TblTenderCell(Integer.parseInt(formValue[1])));
	 	            	tblRebateForm.setIpAddress(ipAddress);
	 	            	tblRebateForm.setCreatedBy(userId);
	 	            	tblRebateFormList.add(tblRebateForm);
	 				}
	         	}
	         	
	         	bSuccess = tenderFormService.editRebateDetail(tblRebate, tblRebateFormList);
	         	rebateId = tblRebate.getRebateId();
	         	successMsg = isRebateForm ==1?"msg_success_rebate_form_created":"msg_success_price_summary_form_configured_successfully";
   		}
      }
      catch(Exception e){
      	return exceptionHandlerService.writeLog(e);
      }finally {
          auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editRebateReportLinkId, rebateformedited, tenderId, rebateId);
      }
      retVal=bSuccess?TENDER_DASHBOARD_URL+tenderId+"/2":"etender/buyer/editrebatereport/"+tenderId+"/"+rebateId;
		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
		redirectAttributes.addFlashAttribute(bSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), bSuccess ? successMsg : CommonKeywords.ERROR_MSG_KEY.toString());
      return retVal;
  }
     
     /**
    	 * Use to View Rebate Report Form
    	 * @author krunal.patel
    	 * @param tenderId
    	 * @param rebateId
    	 * @param isWorkFlow 
    	 * @param modelMap
    	 * @param request
    	 * @param response
    	 * @throws Exception
    	 * @return
    	 */
     @RequestMapping(value = "/buyer/showrebatereport/{tenderId}/{rebateId}/{isWorkFlow}/{enc}", method = RequestMethod.GET)             
     public String viewRebateReport(@PathVariable("tenderId") int tenderId,@PathVariable("rebateId") int rebateId,@PathVariable("isWorkFlow") int isWorkFlow,ModelMap modelMap, HttpServletResponse response, HttpServletRequest request){
     	
     	String retVal = null;
         try{
         	List<Object[]>  rebateFormList= null;
         	
         	/*** Get Common Services for tender detail **/
 			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
 			
 			/*** Get Rebate Form List **/
         	rebateFormList = tenderFormService.getRebateForm(rebateId);
         	
         	modelMap.put("rebateFormList", rebateFormList);
         	modelMap.put("isWorkFlow", isWorkFlow);
         	
             retVal = "etender/buyer/ViewRebateReport";
         }
         catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewRebateReportLinkId, viewRebateReport, tenderId, rebateId);
         }
         return retVal;
     }
     /**
 	 * Use to Delete Rebate Report Form
 	 * @author krunal.patel
 	 * @param tenderId
 	 * @param rebateId
 	 * @param modelMap
 	 * @param request
 	 * @param response
 	 * @throws Exception
 	 * @return
 	 */
     @RequestMapping(value = "/buyer/deleterebatereport/{tenderId}/{rebateId}/{enc}", method = RequestMethod.GET)                       
     public String deleteRebateRprt(@PathVariable("tenderId") int tenderId,@PathVariable("rebateId") int rebateId, HttpServletResponse response, HttpServletRequest request,RedirectAttributes redirectAttributes){
         boolean success = false;
         String retVal=REDIRECT_SESSION_EXPIRED;
         boolean isRebate = false;
         try{
        	 int sessionUserId = abcUtility.getSessionUserId(request);
       		if(sessionUserId!=0){
       			TblRebate tblRebate = tenderFormService.getRebateById(rebateId);
       			isRebate = tblRebate.getIsRebateForm()==1;
       			success = tenderFormService.deleteRebateReport(rebateId);
       		}
         }
         catch(Exception e){
        	 return exceptionHandlerService.writeLog(e);
         }
         finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deleteRebateReportLinkId,deleteRebateReport,tenderId,rebateId);
         }
        retVal=success?TENDER_DASHBOARD_URL+tenderId+"/2":REDIRECT_SESSION_EXPIRED;
  		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
  		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? isRebate ? "msg_success_rebate_form_deleted" : "msg_success_price_summary_form_deleted" : CommonKeywords.ERROR_MSG_KEY.toString());
        return retVal;
     }
     /**
  	 * Use to open Mandatory Document Requirement page
  	 * @author krunal.patel
  	 * @param tenderId
  	 * @param formId
  	 * @param modelMap
  	 * @param request
  	 * @throws Exception
  	 * @return
  	 */
     @RequestMapping(value = "/buyer/createmandatdocreq/{formId}/{tenderId}/{enc}", method = RequestMethod.GET)
      public String createMandatDocReq(@PathVariable("formId") int formId,@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request) {
          try {
        	  
        	  /*** Get Common Services for tender detail **/
   			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
   			
        	  /*** get Yes No list from common services **/
	          	modelMap.addAttribute("mandatoryList", commonService.getYesNo());
	          	
	        	modelMap.put("formId", formId);
	        	modelMap.put("tenderId", tenderId);
	        	
	         	
          } catch (Exception e) {
              return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createFormDocuLinkId,getopenmenddocreq,tenderId,formId);
          }
          return "/etender/buyer/CreateMandDocReq";
      }
     /**
   	 * Use to open Mandatory Document Requirement page for edit
   	 * @author krunal.patel
   	 * @param tenderId
   	 * @param formId
   	 * @param modelMap
   	 * @param request
   	 * @throws Exception
   	 * @return
   	 */
     @RequestMapping(value = "/buyer/editmandatdocreq/{formId}/{tenderId}/{enc}", method = RequestMethod.GET)
     public String editMandatDocReq(@PathVariable("formId") int formId,@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request) {
         try {
	          	
        	 /*** Get Common Services for tender detail **/
    			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    			
        	 /*** get Yes No list from common services **/
	          	modelMap.addAttribute("mandatoryList", commonService.getYesNo());
	          	
	          /*** get document table data services **/
	          modelMap.addAttribute("tblDocuments", tenderFormService.getDocumentsByObjectId(formId));
	          	
	        	modelMap.put("formId", formId);
	        	modelMap.put("tenderId", tenderId);
	        	
	         	
         } catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editMandatoryDocsLinkId,getopeneditmenddocreq, tenderId,formId);
         }
         return "/etender/buyer/CreateMandDocReq";
     }
     /**
    	 * Use to open Mandatory Document Requirement page for View
    	 * @author krunal.patel
    	 * @param tenderId
    	 * @param formId
    	 * @param modelMap
    	 * @param request
    	 * @throws Exception
    	 * @return
     */
     @RequestMapping(value = "/buyer/viewmandatdocreq/{formId}/{tenderId}/{enc}", method = RequestMethod.GET)
      public String viewMandatDocReq(@PathVariable("formId") int formId,@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request) {
          try {
        	  
        	  /*** Get Common Services for tender detail **/
  				tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
  			
        	  /*** get document table data services **/
	          modelMap.addAttribute("tblDocuments", tenderFormService.getDocumentsByObjectId(formId));
	          	
	        	modelMap.put("formId", formId);
	        	modelMap.put("tenderId", tenderId);
	        	
	         	
          } catch (Exception e) {
              return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewMandatoryDocsLinkkId,getopenshowmenddocreq, tenderId,formId);
          }
          return "/etender/buyer/ViewMandDocReq";
      }
     /**
 	 * Use to add Mandatory Document Requirement page
 	 * @author krunal.patel
 	 * @param request
 	 * @throws Exception
 	 * @return
 	 */
     @RequestMapping(value = "/buyer/addmandatdocreq", method = RequestMethod.POST)
     public String addMandatDocReq(RedirectAttributes redirectAttributes, HttpServletRequest request) {
     	boolean success=false;
     	String retVal=REDIRECT_SESSION_EXPIRED;
         int formId = 0;
         int tenderId = 0;
         boolean valid=true;
         try{
        	 
        	 int sessionUserId = abcUtility.getSessionUserId(request);
       		if(sessionUserId!=0){
       			
	             TblDocument tblDocument=null;
	         	List<TblDocument> tblDocuments=new ArrayList<TblDocument>();
	         	
	         	int cnt = StringUtils.hasLength(request.getParameter("txtRowCnt")) && !"".equals(request.getParameter("txtRowCnt"))? Integer.parseInt(request.getParameter("txtRowCnt")):0;
	         	formId = StringUtils.hasLength(request.getParameter("hdFormId")) && !"".equals(request.getParameter("hdFormId"))? Integer.parseInt(request.getParameter("hdFormId")):0;
	         	tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) && !"".equals(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;
	         	
	         	String[] docName = request.getParameterValues("txtDocumentName");
	         	String[] mandatory=request.getParameterValues("selMandatory");
	         	int userId = abcUtility.getSessionUserDetailId(request);
	         	for(int i=0;i<cnt;i++){
	         		if(docName[i]==null || "".equals(docName[i])){
	         			valid=false;
	         			break;
	         		}
	         	}
	         	if(!valid){
	         		retVal="redirect:/"+MANDATORY_DOCUMENT_REQ+formId + encryptDecryptUtils.generateRedirect(MANDATORY_DOCUMENT_REQ+formId, request);
	         	}else{
	 	        	for(int i=0;i<cnt;i++){
	 	        		tblDocument=new TblDocument();
	 	        		tblDocument.setDocumentName(docName[i]);
	 	        		tblDocument.setObjectId(formId);
	 	        		tblDocument.setTblLink(new TblLink(createFormDocuLinkId));
	 	        		tblDocument.setParentId(tenderId);
	 	        		tblDocument.setIsMandatory(StringUtils.hasLength(mandatory[i]) && !"".equals(mandatory[i])?Integer.parseInt(mandatory[i]):0);
	 	        		tblDocument.setCreatedBy(userId);
	 	        		tblDocuments.add(tblDocument);
	 	        	}
	 	        	success=tenderFormService.addReqDocuments(tblDocuments);
	         	}
       		}
         }catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),createFormDocuLinkId, success ? manDocumrntcreated : manDocumrntcreatefail,tenderId,formId);
         }
         retVal=success?TENDER_DASHBOARD_URL+tenderId+"/2":MANDATORY_DOCUMENT_REQ+formId;
  		 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
  		 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_mandatory_document_created" : CommonKeywords.ERROR_MSG_KEY.toString());
         return retVal;
     }
     /**
  	 * Use to update Mandatory Document Requirement page
  	 * @author krunal.patel
  	 * @param request
  	 * @throws Exception
  	 * @return
  	 */
     @RequestMapping(value = "/buyer/updatemandatdocreq", method = RequestMethod.POST)
     public String updateMandatDocReq(RedirectAttributes redirectAttributes, HttpServletRequest request) {
     	boolean success=false;
     	String retVal=REDIRECT_SESSION_EXPIRED;
         int formId = 0;
         int tenderId = 0;
         boolean valid=true;
         try{
        	 
        	 int sessionUserId = abcUtility.getSessionUserId(request);
       		if(sessionUserId!=0){
       			
	             TblDocument tblDocument=null;
	         	List<TblDocument> tblDocuments=new ArrayList<TblDocument>();
	         	
	         	
	         	int cnt = StringUtils.hasLength(request.getParameter("txtRowCnt")) && !"".equals(request.getParameter("txtRowCnt"))? Integer.parseInt(request.getParameter("txtRowCnt")):0;
	         	formId = StringUtils.hasLength(request.getParameter("hdFormId")) && !"".equals(request.getParameter("hdFormId"))? Integer.parseInt(request.getParameter("hdFormId")):0;
	         	tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) && !"".equals(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;
	         	
	         	String[] docName=request.getParameterValues("txtDocumentName");
	         	String[] mandatory=request.getParameterValues("selMandatory");
	         	int userId = abcUtility.getSessionUserDetailId(request);
	         	for(int i=0;i<cnt;i++){
	         		if(docName[i]==null || "".equals(docName[i])){
	         			valid=false;
	         			break;
	         		}
	         	}
	         	if(!valid){
	         		retVal="redirect:/"+EDIT_MANDATORY_DOCUMENT_REQ+formId + encryptDecryptUtils.generateRedirect(EDIT_MANDATORY_DOCUMENT_REQ+formId, request);
	         	}else{
	 	        	for(int i=0;i<cnt;i++){
	 	        		tblDocument=new TblDocument();
	 	        		tblDocument.setDocumentName(docName[i]);
	 	        		tblDocument.setObjectId(formId);
	 	        		tblDocument.setTblLink(new TblLink(createFormDocuLinkId));
	 	        		tblDocument.setParentId(tenderId);
	 	        		tblDocument.setIsMandatory(StringUtils.hasLength(mandatory[i]) && !"".equals(mandatory[i])?Integer.parseInt(mandatory[i]):0);
	 	        		tblDocument.setCreatedBy(userId);
	 	        		tblDocuments.add(tblDocument);
	 	        	}
	 	        	
	 	        	/*** update services call in which first all row delete form table than after insert new row  **/
	 	        	success = tenderFormService.updateReqDocuments(formId, tblDocuments);
	         	}
       		}
         }catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editMandatoryDocsLinkId, success ? manDocumrntupdated : manDocumrntupdatedfail,tenderId,formId);
         }
         retVal=success?TENDER_DASHBOARD_URL+tenderId+"/2":EDIT_MANDATORY_DOCUMENT_REQ+formId;
  		 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
  		 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_mandatory_document_updated" : CommonKeywords.ERROR_MSG_KEY.toString());
         return retVal;
     }
     /**
   	 * Use to open page for tender opening consent
   	 * @author krunal.patel
   	 * @param tenderId
   	 * @param envelopeId
   	 * @param committeeUserId
   	 * @param committeeId
   	 * @param minOpeningMember
   	 * @param committeeType
   	 * @param request
   	 * @param ModelMap
   	 * @throws Exception
   	 * @return
   	 */
     @RequestMapping(value = "/buyer/getcommitteeuserremark/{tenderId}/{envelopeId}/{committeeUserId}/{committeeId}/{minOpeningMember}/{committeeType}/{enc}", method = RequestMethod.GET)
      public String getCommitteeUserRemark(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("committeeUserId") int committeeUserId,@PathVariable("committeeId") int committeeId,@PathVariable("minOpeningMember") int minOpeningMember,@PathVariable("committeeType") int committeeType,ModelMap modelMap,HttpServletRequest request) {
    	 String page="redirect:/sessionexpired";
    	 boolean isCertiFound=true; 
    	 
    	 try {
	          	
        	  /*** Check the client is PKI or event specific **/  
        	  
	        	int isCertRequired=(Integer)tenderCommonService.getTenderField(tenderId, "isCertRequired");
	        	modelMap.put("isCertRequired", isCertRequired);
	        	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	    		if(clientBean.getIsPkiEnabled()==1){
	        		String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
	        		if(certIds!=null && certIds.length!=0){
	        			modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
	        		}
	    		}
	    		else if(clientBean.getIsPkiEnabled()==pkiEventSpecific && isCertRequired ==1){
	    			SessionBean sessionBean = null; 
	    			if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())!=null){
	    	            sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
	    	        }
	    			
	    			if (sessionBean != null && !sessionBean.isEventSpecVerify()){
	                    isCertiFound = false;
	                    page="common/buyer/attacheventspeccerti/etender,buyer,getcommitteeuserremark,"+tenderId+","+envelopeId+","+committeeUserId+","+committeeId+","+minOpeningMember+","+committeeType;
	                } 
	                else{
	                    String certIds[] = sessionBean.getCertId().split(",");
	                    if (certIds != null && certIds.length != 0) {
	                        modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
	                    }
	                }
	    		}
	    		else{
	    			isCertiFound= true;
	    		}
	    		if(isCertiFound){
		    		/*** Get Common Services for tender detail **/
		   			tenderCommonService.tenderSummary(tenderId, modelMap,clientBean.getClientId());
		   			modelMap.put("tenderId", tenderId);
		   			modelMap.put("envelopeId", envelopeId);
		   			modelMap.put("committeeUserId", committeeUserId);
		   			modelMap.put("committeeId", committeeId);
		   			modelMap.put("minOpeningMember", minOpeningMember);
		   			modelMap.put("committeeType", committeeType);
		   			
		   			int tabId = committeeType == 1 ? TAB_TENDER_OPENING:TAB_EVALUATE_BID;
		   			
		   			modelMap.put("tabId", tabId);
		   			page ="etender/buyer/GetCommitteeUserRemark";
	    		}else{
	    			 page="redirect:/"+page+ encryptDecryptUtils.generateRedirect(page, request);
                }
          } catch (Exception e) {
              return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), committeeType == 1 ?openingConsentLinkId:evaluationConsentLinkId,committeeType == 1 ?getusercommitteeremarks:getevalcommitteeremarks,tenderId,envelopeId);
          }
    	 return page;
      }
     /**
    	 * Use to save remark for tender opening consent
    	 * @author krunal.patel
    	 * @param request
    	 * @throws Exception
    	 * @return
    	 */
     @RequestMapping(value = "/buyer/addusercommitteeremarks", method = RequestMethod.POST)
     public String addUserComitRemarks(RedirectAttributes redirectAttributes, HttpServletRequest request) {
     	boolean success=false;
     	String retVal=REDIRECT_SESSION_EXPIRED;
     	int tenderId = 0;
     	int envelopeId = 0;
     	int committeeUserId = 0;
     	int committeeId = 0;
     	int minOpeningMember = 0;
     	int committeeType = 0;
     	int isCertRequired = 0;
     	int tabId = 0;
     	String remark=null;
     	boolean isCorrigendumPrepare=false;      
     	boolean reevalsucess=true;
     	boolean isServerSideValidate=true;
         try{
        	 int sessionUserId = abcUtility.getSessionUserId(request);
         	if(sessionUserId!=0){
        	 tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;  
             envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
             committeeUserId = StringUtils.hasLength(request.getParameter("hdCommitteeUserId")) ? Integer.parseInt(request.getParameter("hdCommitteeUserId")):0;
             committeeId = StringUtils.hasLength(request.getParameter("hdCommitteeId")) ? Integer.parseInt(request.getParameter("hdCommitteeId")):0;
             minOpeningMember = StringUtils.hasLength(request.getParameter("hdMinOpeningMember")) ? Integer.parseInt(request.getParameter("hdMinOpeningMember")):0;
             committeeType = StringUtils.hasLength(request.getParameter("hdCommitteeType")) ? Integer.parseInt(request.getParameter("hdCommitteeType")):0;
             isCertRequired = StringUtils.hasLength(request.getParameter("hdIsCertRequired")) ? Integer.parseInt(request.getParameter("hdIsCertRequired")):0;
             remark = StringUtils.hasLength(request.getParameter("txtaRemark")) ? request.getParameter("txtaRemark"):null;
             if(committeeType==1){isCorrigendumPrepare=tenderCommonService.isCorrgendumPrepare(tenderId);}
	         	int isReEvaluationReq = 0;
	          	isReEvaluationReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isReEvaluationReq").toString());
	          	if( isReEvaluationReq==1 ){
	          		Integer[] ctatus={0};
	          		List<TblTenderReevaluation> tblTenderreevaluation = tenderFormService.getTblTenderEnvelopeRevaluationStatusByTenderId(tenderId, ctatus);
	          		if(tblTenderreevaluation!=null && !tblTenderreevaluation.isEmpty() ){
	          			reevalsucess=false;
	          		}
	          	}
	          if(reevalsucess){	
	        	  int latestCommitteeId = tenderFormService.getLatestCommitteeId(tenderId, committeeType);
	        	  if(committeeId!=latestCommitteeId){
	        		  isServerSideValidate=false;
	        	  }
	          }
             if(!isCorrigendumPrepare && reevalsucess && isServerSideValidate){
	             tabId = committeeType == 1 ? TAB_TENDER_OPENING:TAB_EVALUATE_BID;	 
	        	 int approvedBy = abcUtility.getSessionUserDetailId(request);
	        	 
	        	 /*** update UserCommittee table columns **/
	        	 success =  tenderFormService.updateUserComiteByComiteUserId(tenderId,envelopeId,committeeUserId,committeeId,approvedBy,remark,minOpeningMember,committeeType);
	        	 
	        	 // PT : #33589/53526 By Jitendra. Update tender status on opening envelope when consent received.
	        	 if(success){
	        		 tenderFormService.updateTenderEvalutionStatusForOpening(tenderId, envelopeId, TENDER_OPENED_STATUS);
	        	 }
             }
        	
         	}
         }catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         }finally {
        	 int pki=abcUtility.getSessionIsPkiEnabled(request);
        	 if(pki==1 || (pki==pkiEventSpecific && isCertRequired ==1)){
        		 String signText = StringUtils.hasLength(request.getParameter("skpSignText")) ? request.getParameter("skpSignText"):null;
         		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), committeeType == 1 ?openingConsentLinkId:evaluationConsentLinkId, success ? committeeType == 1 ?usercommitteeremarksupdated:evalcommitteeremarksupdated : committeeType == 1 ?usercommitteeremarksupdatedfail:evalcommitteeremarksupdatedfail,tenderId,envelopeId,remark,signText);
         	}else{
         		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), committeeType == 1 ?openingConsentLinkId:evaluationConsentLinkId, success ? committeeType == 1 ?usercommitteeremarksupdated:evalcommitteeremarksupdated : committeeType == 1 ?usercommitteeremarksupdatedfail:evalcommitteeremarksupdatedfail,tenderId,envelopeId,remark);
         	}
             
         }
         retVal=success?TENDER_DASHBOARD_URL+tenderId+"/"+tabId:GET_USER_COMMITTEE_REMARKS+tenderId+"/"+envelopeId+"/"+committeeUserId+"/"+committeeId+"/"+minOpeningMember+"/"+committeeType;
  		 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
  		 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_usercommittee_remarks_add" : isCorrigendumPrepare ? "msg_corrigendum_pending"  : reevalsucess==false ? "msg_reevaluate_opening_not_allowed" : !isServerSideValidate? "redirect_msg_committee_updated" : CommonKeywords.ERROR_MSG_KEY.toString() );
         return retVal;
     }
     
     private void setIncrementBidderWiseOfficerData(int tenderId,int envelopeId,int bidderId,int sessionUserId,boolean isView,ModelMap modelMap){
   	 
		  List<Object[]> incOffRemarksName = new ArrayList<Object[]>();
		  List<Object[]> incOffRemarksVal = new ArrayList<Object[]>();
		  if(isView){
			  incOffRemarksName =  tenderFormService.getIncrementBidderWiseOfficer(tenderId,envelopeId,bidderId,0);
			  incOffRemarksVal =  tenderFormService.getRemarksBidderWiseOfficer(tenderId,envelopeId,bidderId,0);
		  }else{
			  incOffRemarksName =  tenderFormService.getIncrementBidderWiseOfficer(tenderId,envelopeId,bidderId,sessionUserId);
			  incOffRemarksVal =  tenderFormService.getRemarksBidderWiseOfficer(tenderId,envelopeId,bidderId,sessionUserId);
		  }
		  modelMap.put("incOffRemarksName", incOffRemarksName);
		  modelMap.put("incOfficerRemarks", incOffRemarksVal);
}
     /**
	 	 * Use to view Bidder Evaluation Details
	 	 * @author Keval.soni
	 	 * @param tenderId
	 	 * @param ModelMap
	 	 * @param request
	 	 * @throws Exception
	 	 * @return
 	 */
     @RequestMapping(value = "/buyer/viewBidderEvaluationDetails/{tenderId}/{enc}", method = RequestMethod.GET)
     public String viewEvaluateDetails(@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request) {
         try {
        	 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	 boolean isTwoStageEvaluation = (Integer) modelMap.get("isTwoStageEvaluation")==1?true:false;
        	 List<Object[]> bidderList = tenderFormService.getBidderDetailsByTenderId(tenderId);
        	 List<Object[]> bidderListforPriceBid = tenderFormService.getBidderDetailsForPriceBidEnvelopByTenderId(tenderId);
        	 modelMap.addAttribute("BidderDetails", bidderList);
        	 modelMap.addAttribute("bidderListforPriceBid", bidderListforPriceBid);
        	 List<TblTenderEnvelope> envList = eventCreationService.getTblTenderEnvelopeList(tenderId);
        	 modelMap.addAttribute("ListTenderEnvelope",envList);
        	 Integer[] envIdsArr = new Integer[envList.size()];
        	 for(int i=0;i<envList.size();i++){
        		 envIdsArr[i] = envList.get(i).getEnvelopeId();
        	 }
        	 List<Object[]> commiteeRemarks = null;
        	 int isReEvaluationReq = 0;
	          	isReEvaluationReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isReEvaluationReq").toString());
	          	if( isReEvaluationReq==1 ){
	          		Integer[] ctatus={1};
	          		List<TblTenderReevaluation> tblTenderreevaluation = tenderFormService.getTblTenderEnvelopeRevaluationStatusByTenderId(tenderId, ctatus);
	          		if(tblTenderreevaluation!=null && !tblTenderreevaluation.isEmpty() ){
	          			  commiteeRemarks = tenderFormService.getOverAllRemarksForViewBidderReEvaluation(tenderId,isTwoStageEvaluation);
	          			 modelMap.addAttribute("reevalsuccess",true);
	          		}else{
	          			 commiteeRemarks = tenderFormService.getOverAllRemarksForViewBidderEvaluation(tenderId,isTwoStageEvaluation);
	          		}
	          	}else{
	          		 commiteeRemarks = tenderFormService.getOverAllRemarksForViewBidderEvaluation(tenderId,isTwoStageEvaluation);
	          	}
	          	 modelMap.addAttribute("OverAllRemarks",commiteeRemarks);
        	 Map<Integer, Map<Integer, String>> bidderCount = new HashMap<Integer, Map<Integer, String>>();
        	 Map<Integer, String> envCount = new HashMap<Integer, String>();
        	 int bidderId = 0,envelopId = 0,remBidderId = 0,remEnvelopId = 0,bidderRowCnt = 0,envRowCount = 0,priceBidEnv = 0;
        	 Map<Integer, Map<String, List<Object[]>>> remarksAndOfficeName = new HashMap<Integer, Map<String,List<Object[]>>>();
        	 List<Object[]> incOffRemarksName = new ArrayList<Object[]>();
        	 List<Object[]> incOffRemarksVal = new ArrayList<Object[]>();
        	 List<TblOfficerDocMapping> officerDocMapping = tenderFormService.getAllOfficerDocMapping(envIdsArr);
        	 TblOfficerDocMapping tblDoc = new TblOfficerDocMapping();
        	 Map<String, Integer> isDocAvailableMap = new HashMap<String, Integer>();
        	 for(int i=0;i<bidderList.size();i++){
        		 bidderRowCnt = 0;
        		 bidderId = Integer.parseInt(bidderList.get(i)[0].toString());
        		 for(int j=0;j<envList.size();j++){
        			 envRowCount = 0;
        			 envelopId = envList.get(j).getEnvelopeId();
        			 if(envList.get(j).getTblEnvelope().getEnvId() == 4 || envList.get(j).getTblEnvelope().getEnvId() == 5){
        				 priceBidEnv = envelopId;
        			 }
        			 for(int k=0;k<commiteeRemarks.size();k++){
        				 remBidderId = Integer.parseInt(commiteeRemarks.get(k)[5].toString());
        				 remEnvelopId = Integer.parseInt(commiteeRemarks.get(k)[4].toString());
        				 if(bidderId == remBidderId && envelopId == remEnvelopId){
        					 bidderRowCnt++;
        					 envRowCount++;
        					 for(int l=0;l<officerDocMapping.size();l++){
        						 tblDoc = (TblOfficerDocMapping)officerDocMapping.get(l);
        						 if(tblDoc.getChildId() == bidderId && tblDoc.getObjectId() == envelopId && tblDoc.getMappedBy() == Integer.parseInt(commiteeRemarks.get(k)[3].toString())){
        							 isDocAvailableMap.put(bidderId+"_"+envelopId+"_"+tblDoc.getMappedBy(), 1); //1 for there is Document for Download
        						 }
        					 }
        				 }
        			 }
        			 if(bidderCount.containsKey(bidderId)){
        				 envCount = bidderCount.get(bidderId);
        			 }else{
        				 envCount = new HashMap<Integer, String>();
        			 }
        			 envCount.put(envelopId,"~"+envRowCount);
    				 bidderCount.put(bidderId, envCount);
        		 }
        		 for (Map.Entry<Integer, String> entry : bidderCount.get(bidderId).entrySet())
        		 {
        			 envCount = bidderCount.get(bidderId);
        			 envCount.put(entry.getKey(), bidderRowCnt+entry.getValue());
        		 }
        		 bidderCount.put(bidderId, envCount);
        	 }
        	 List<String> formBidderIdList = new ArrayList<String>();
        	 for(int i=0;i<bidderListforPriceBid.size();i++){
        		 bidderId = Integer.parseInt(bidderListforPriceBid.get(i)[0].toString());
        		 incOffRemarksName =  tenderFormService.getIncrementBidderWiseOfficer(tenderId,priceBidEnv,bidderId,0);
				 incOffRemarksVal =  tenderFormService.getRemarksBidderWiseOfficer(tenderId,priceBidEnv,bidderId,0);
				 Map<String, List<Object[]>> remarksMap = new HashMap<String, List<Object[]>>();
				 remarksMap.put("incOffRemarksName", incOffRemarksName);
				 remarksMap.put("incOfficerRemarks", incOffRemarksVal);
				 remarksAndOfficeName.put(bidderId, remarksMap);
				 List<Integer> formIdList=tenderCommonService.getTenderFormIdByTenderAndBidderId(tenderId,bidderId,1);
				 if(formIdList!=null && !formIdList.isEmpty()){
				 for(int formCtr=0;formCtr<formIdList.size();formCtr++){
					 formBidderIdList.add(formIdList.get(formCtr)+"_"+bidderId);
	        	  }
				 }
        	 }
        	 modelMap.addAttribute("formBidderIdList",formBidderIdList);
        	 modelMap.addAttribute("isDocAvailable",isDocAvailableMap);
        	 modelMap.addAttribute("BidderCount", bidderCount);
        	 modelMap.addAttribute("remarksAndOfficeName",remarksAndOfficeName);
        	//ItemWiseRemarks
        	 List<Object[]> formAndTableDetalisList=tenderCommonService.getTenderFormAndTableByTenderId(tenderId,0,1);
    		 Map<Integer, String> formMap = new HashMap<Integer, String>();
        	 modelMap.addAttribute("formAndTableDetalisList",formAndTableDetalisList);
        	 List<Integer> tblIds=new ArrayList<Integer>();
        	 for(int i=0;i<formAndTableDetalisList.size();i++){
        		 tblIds.add((Integer)formAndTableDetalisList.get(i)[4]);
        		 formMap.put((Integer)formAndTableDetalisList.get(i)[0], formAndTableDetalisList.get(i)[3].toString());
        	 }
        	 if((Integer)modelMap.get("tenderResult") == 1){
        		 modelMap.addAttribute("formMap",formMap);
        		 modelMap.addAttribute("formMapSize",formMap.size());
        	 }
        	 List<Object[]> columnList = new ArrayList<Object[]>();
        	 if(formAndTableDetalisList.size() != 0){
        		 columnList=tenderCommonService.getColumnDetailsFromTableId(tblIds);
        		 List<Object[]> colmList=new ArrayList<Object[]>();
            	 List<Integer> clmIds=new ArrayList<Integer>();
            	 for(int i=0;i<columnList.size();i++){
            		 	if(Integer.valueOf(columnList.get(i)[4].toString()) == 1){
            		 		clmIds.add((Integer)columnList.get(i)[0]);
            		 		colmList.add(columnList.get(i));
            		 	}
            	 }
            	 modelMap.addAttribute("ListColumDtls",colmList);
            	 List<Object[]> cellList = new ArrayList<Object[]>();
            	 if(clmIds!=null && !clmIds.isEmpty()){
            	   cellList=tenderCommonService.getCellDetailsFromColumnId(clmIds);
            	 }
            	 int cellListSize=cellList.size();
            	
            	Map<String, List<Map<Integer, List<String>>>> CelldataMap=new HashMap<String, List<Map<Integer, List<String>>>>();
            	Map<String, Map<Integer, Integer>> rowSpanLength = new HashMap<String, Map<Integer,Integer>>(); // "BidderLen" , "TableLen" , "FormLen"
            	Map<Integer, Integer> eachMap = new HashMap<Integer, Integer>();
     			String rowStr=null;
     			for (int i = 0; i < cellList.size(); i++) {
     				if(i<cellListSize){
     					rowStr=cellList.get(i)[2].toString();
     				}else{
     					String dwVal  = cellList.get(i)[2]!=null ? cellList.get(i)[2].toString() : "";
     					rowStr=dwVal+cellList.get(i)[5].toString();
     				}if(CelldataMap.containsKey(cellList.get(i)[4].toString())){
     					List<Map<Integer, List<String>>> rowMap=CelldataMap.get(cellList.get(i)[4].toString());
     					boolean flag=false;
     					for (int j = 0; j < rowMap.size(); j++) {
     						if(rowMap.get(j).containsKey(cellList.get(i)[1])){
     							Map<Integer, List<String>> oneMap=rowMap.get(j);
     							List<String> rowddta=oneMap.get(cellList.get(i)[1]);
     							rowddta.add(rowStr);
     							oneMap.put((Integer)cellList.get(i)[1],rowddta);
     							rowMap.set(j, oneMap);
     							CelldataMap.put(cellList.get(i)[4].toString().toString(), rowMap);
     							flag=true;
     							break;
     						}
     					}if(flag==false){
     						Map<Integer, List<String>> oneMap=new HashMap<Integer,List<String>>();
     						List<String> s=new ArrayList<String>();
     						s.add(rowStr);
     						oneMap.put((Integer)cellList.get(i)[1], s);
     						rowMap.add(oneMap);
     						CelldataMap.put(cellList.get(i)[4].toString().toString(), rowMap);
     						if(rowSpanLength.containsKey("BidderLen")){
     							eachMap = rowSpanLength.get("BidderLen");
     							eachMap.put(-1, eachMap.get(-1)+1);
     						}else{
     							eachMap = new HashMap<Integer, Integer>();
     							eachMap.put(-1,1);
     						}
     						rowSpanLength.put("BidderLen", eachMap);
     						if(rowSpanLength.containsKey("FormLen")){
     							eachMap = rowSpanLength.get("FormLen");
     							if(eachMap.containsKey(Integer.parseInt(cellList.get(i)[6].toString()))){
     								eachMap.put(Integer.parseInt(cellList.get(i)[6].toString()),eachMap.get(Integer.parseInt(cellList.get(i)[6].toString()))+1);
     							}else{
     								eachMap.put(Integer.parseInt(cellList.get(i)[6].toString()),1);
     							}
     						}else{
     							eachMap = new HashMap<Integer, Integer>();
     							eachMap.put(Integer.parseInt(cellList.get(i)[6].toString()),1);
     						}
     						rowSpanLength.put("FormLen", eachMap);
     						if(rowSpanLength.containsKey("TableLen")){
     							eachMap = rowSpanLength.get("TableLen");
     							if(eachMap.containsKey(Integer.parseInt(cellList.get(i)[4].toString()))){
     								eachMap.put(Integer.parseInt(cellList.get(i)[4].toString()),eachMap.get(Integer.parseInt(cellList.get(i)[4].toString()))+1);
     							}else{
     								eachMap.put(Integer.parseInt(cellList.get(i)[4].toString()),1);
     							}
     						}else{
     							eachMap = new HashMap<Integer, Integer>();
     							eachMap.put(Integer.parseInt(cellList.get(i)[4].toString()),1);
     						}
     						rowSpanLength.put("TableLen", eachMap);
     					}	
     				}else{
     					List<Map<Integer, List<String>>> rowMap=new ArrayList<Map<Integer,List<String>>>();
     					Map<Integer, List<String>> oneMapp=new HashMap<Integer,List<String>>();
     					List<String> rowList=new ArrayList<String>();
     					rowList.add(rowStr);
     					oneMapp.put((Integer)cellList.get(i)[1], rowList);
     					rowMap.add(oneMapp);
     					CelldataMap.put(cellList.get(i)[4].toString(), rowMap);
     					if(rowSpanLength.containsKey("BidderLen")){
    							eachMap = rowSpanLength.get("BidderLen");
    							eachMap.put(-1, eachMap.get(-1)+1);
    						}else{
    							eachMap = new HashMap<Integer, Integer>();
    							eachMap.put(-1,1);
    						}
    						rowSpanLength.put("BidderLen", eachMap);
    						if(rowSpanLength.containsKey("FormLen")){
     							eachMap = rowSpanLength.get("FormLen");
     							if(eachMap.containsKey(Integer.parseInt(cellList.get(i)[6].toString()))){
     								eachMap.put(Integer.parseInt(cellList.get(i)[6].toString()),eachMap.get(Integer.parseInt(cellList.get(i)[6].toString()))+1);
     							}else{
     								eachMap.put(Integer.parseInt(cellList.get(i)[6].toString()),1);
     							}
     						}else{
     							eachMap = new HashMap<Integer, Integer>();
     							eachMap.put(Integer.parseInt(cellList.get(i)[6].toString()),1);
     						}
     						rowSpanLength.put("FormLen", eachMap);
    						if(rowSpanLength.containsKey("TableLen")){
    							eachMap = rowSpanLength.get("TableLen");
    							if(eachMap.containsKey(Integer.parseInt(cellList.get(i)[4].toString()))){
    								eachMap.put(Integer.parseInt(cellList.get(i)[4].toString()),eachMap.get(Integer.parseInt(cellList.get(i)[4].toString()))+1);
    							}else{
    								eachMap.put(Integer.parseInt(cellList.get(i)[4].toString()),1);
    							}
    						}else{
    							eachMap = new HashMap<Integer, Integer>();
    							eachMap.put(Integer.parseInt(cellList.get(i)[4].toString()),1);
    						}
    						rowSpanLength.put("TableLen", eachMap);
     				}
     			}
     			 if(rowSpanLength.get("BidderLen")!=null){
     			  modelMap.addAttribute("BidderLenCnt", rowSpanLength.get("BidderLen").get(-1));
     			 }
     			modelMap.addAttribute("rowSpanLength", rowSpanLength);
            	modelMap.addAttribute("ListCellDtls",CelldataMap);
        	 }
 		    List<Integer> lstLink=new ArrayList<Integer>();
 			lstLink.add(evaluationEvaluateLinkId);
 		    modelMap.addAttribute("linkId", lstLink);
 		    modelMap.addAttribute("isTenderDocDownload", "Y");
 		    modelMap.addAttribute("cStatusDocView", officerDocStatusPending);
 		    modelMap.addAttribute("cStatusDoc", 5);
// 		    modelMap.addAttribute("childId", bidderId);
 		   modelMap.addAttribute("bidderId", bidderId);
 		    modelMap.addAttribute("isUserIdwisePath","Y");
 		    modelMap.addAttribute("isReq","Y");
 		    int isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
             modelMap.put("isCertRequired", isCertRequired);
     		SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
     		ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
             String certIds[] = null;
             if (clientBean.getIsPkiEnabled() == pkiEnable && sessionBean != null) {
                 certIds = sessionBean.getCertId().split(",");
                 if (certIds != null && certIds.length != 0) {
                     modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                 }
             }
         }catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }finally{
 			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, getViewBidEvaluationFromBidEvaluationTab, tenderId,0);
 		}
         return "/etender/buyer/ViewBidderEvaluationDetails";
     }
    
     /**
	 	 * Use to view Reevaluation Evaluation Details
	 	 * @author Priyaka
	 	 * @param tenderId
	 	 * @param envelopeId
	 	 * @param ModelMap
	 	 * @param request
	 	 * @throws Exception
	 	 * @return
	 */
     @RequestMapping(value = "/buyer/getReEvaluationDetails/{tenderId}/{envelopeId}/{enc}", method = RequestMethod.GET)
     public String viewReEvaluationDetails(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,ModelMap modelMap,HttpServletRequest request)
     {
    	 try{
    		 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    	 TblTenderEnvelope tblTenderenvelope = tenderCommonService.getTenderEnvelopeById(envelopeId);
    	 modelMap.addAttribute("envelopeName",tblTenderenvelope.getEnvelopeName());
    	 List<Object[]> commiteeRemarks = null;
    	 int isReEvaluationReq = 0;
          	isReEvaluationReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isReEvaluationReq").toString());
          	if( isReEvaluationReq==1 ){
          		Integer[] ctatus={1};
          		List<TblTenderReevaluation> tblTenderreevaluation = tenderFormService.getTblTenderRevaluationStatusByEnvelopeId(tenderId,envelopeId, ctatus);
          		if(tblTenderreevaluation!=null && !tblTenderreevaluation.isEmpty() ){
          			  commiteeRemarks = tenderFormService.getReEvaluationRemark(tenderId,envelopeId);
          			 modelMap.addAttribute("reevalsuccess",true);
          		}else{
          			 commiteeRemarks = tenderFormService.getReEvaluationRemark(tenderId,envelopeId);
          		}
          	}else{
          		 commiteeRemarks = tenderFormService.getReEvaluationRemark(tenderId,envelopeId);
          	}
          	 List<Object> lstEvaluationDateAndTime =eventCreationService.getOfficerEvaluationDateAndTimeFromHistory(tenderId,envelopeId);
       		     		if(lstEvaluationDateAndTime!=null && !lstEvaluationDateAndTime.isEmpty()){
       		     		 modelMap.addAttribute("evaluationDate",(Date) lstEvaluationDateAndTime.get(0)); 
       		     		}
          	 modelMap.addAttribute("OverAllRemarks",commiteeRemarks);
    	 }catch (Exception e) {
              exceptionHandlerService.writeLog(e);
         }finally{
 			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, getViewEvaluationHistoryFromBidEvaluationTab, tenderId,0);
 		}
          	 return "/etender/buyer/ViewReevaluationRemark";
     }
     /**
    	 * Use to get Bidder Wise Evaluation ---Two Stage Evaluation
    	 * @author Keval.soni
    	 * @param tenderId
    	 * @param envelopeId
    	 * @param createEditFlage
    	 * @param envlopTypFlg
    	 * @param sortOrder
    	 * @param preEnvelopeId
    	 * @param bidderId
    	 * @param request
    	 * @param ModelMap
    	 * @throws Exception
    	 * @return
    	 */
     @RequestMapping(value = "/buyer/bidderWiseevaluation/{tenderId}/{envelopeId}/{createEditFlage}/{bidderId}/{companyId}/{commiteeType}/{isView}/{rejected}/{tenderResult}/{enc}", method = RequestMethod.GET)
     public String getEvaluateBiddersWise(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("createEditFlage") int createEditFlage,@PathVariable("bidderId") int bidderId,@PathVariable("companyId") int companyId,@PathVariable("commiteeType") int commiteeType,@PathVariable("isView") boolean isView,@PathVariable("rejected") String rejected,@PathVariable("tenderResult") int tenderResult,ModelMap modelMap,HttpServletRequest request) {
         try {
        	 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	 List<Object[]> formAndTableDetalisList=tenderCommonService.getTenderFormAndTableByTenderId(tenderId,bidderId,0);
        	 boolean isOnlyTechnical = tenderCommonService.getTenderFormAndTableByTenderId(tenderId,bidderId,1).size() != 0 ? true : false;
        	 modelMap.addAttribute("formAndTableDetalisList",formAndTableDetalisList);
        	 int userDetailId=loginService.getBidderUserDetailId(bidderId);
        	 int sessionUserId = abcUtility.getSessionUserId(request);
        	 int createdBy = abcUtility.getSessionUserDetailId(request);
        	 modelMap.addAttribute("CompanyDetls",manageBidderService.getUserDetailById(userDetailId));
        	 modelMap.addAttribute("encodedName",tenderFormService.getEncodedName(tenderId, bidderId));
        	 modelMap.addAttribute("letestCstatusEncodeDecodeHistory", commonService.getLetestCstatusEncodeDecodeHistory(tenderId));
        	 int isEncodedNameForPriceBid =  (Integer) tenderCommonService.getTenderField(tenderId, "isEncodedName");
		     modelMap.addAttribute("isEncodedNameForPriceBid", isEncodedNameForPriceBid);
        	 modelMap.addAttribute("companyId",companyId);
        	 List<Object[]> userRoleEncryptionLeval=tenderFormService.getUserRoleId(tenderId, envelopeId, commiteeType, sessionUserId);
        	 List<Integer> tblIds=new ArrayList<Integer>();
        	 for(int i=0;i<formAndTableDetalisList.size();i++){
        		 tblIds.add((Integer)formAndTableDetalisList.get(i)[4]);
        	 }
        	 List<Object[]> colmList=tenderCommonService.getColumnDetailsFromTableId(tblIds);
        	 List<Integer> clmIds=new ArrayList<Integer>();
        	 for(int i=0;i<colmList.size();i++){
        		 clmIds.add((Integer)colmList.get(i)[0]);
        	 }
        	 modelMap.addAttribute("ListColumDtls",colmList);
        	 List<Object[]> cellList = new ArrayList<Object[]>();
        	 if(clmIds!=null && !clmIds.isEmpty() && isOnlyTechnical){
        		 cellList=tenderCommonService.getCellDetailsFromColumnId(clmIds);
        	 }
        	 int cellListSize=cellList.size();
        	 List<Object[]> bidderwiseItmEntry = tenderFormService.ChkandgetItemWiseEvaluationData(tenderId,envelopeId,sessionUserId,bidderId);
        	 setIncrementBidderWiseOfficerData(tenderId,envelopeId,bidderId,sessionUserId,isView,modelMap);
        	 if(bidderwiseItmEntry.size()!=0){
//        		 cellList.addAll(bidderwiseItmEntry);
        		 modelMap.put("isEvaluationDone", "yes"); 
        	 }else{
        		 modelMap.put("isEvaluationDone", "no");
        	}
        	Map<String, List<Map<Integer, List<String>>>> CelldataMap=new HashMap<String, List<Map<Integer, List<String>>>>();
 			String rowStr=null;
 			for (int i = 0; i < cellList.size(); i++) {
 				if(i<cellListSize){
 					rowStr=cellList.get(i)[2].toString();
 				}else{
 					String dwVal  = cellList.get(i)[2]!=null ? cellList.get(i)[2].toString() : "";
 					rowStr=dwVal+cellList.get(i)[5].toString();
 				}if(CelldataMap.containsKey(cellList.get(i)[4].toString())){
 					List<Map<Integer, List<String>>> rowMap=CelldataMap.get(cellList.get(i)[4].toString());
 					boolean flag=false;
 					for (int j = 0; j < rowMap.size(); j++) {
 						if(rowMap.get(j).containsKey(cellList.get(i)[1])){
 							Map<Integer, List<String>> oneMap=rowMap.get(j);
 							List<String> rowddta=oneMap.get(cellList.get(i)[1]);
 							rowddta.add(rowStr);
 							oneMap.put((Integer)cellList.get(i)[1],rowddta);
 							rowMap.set(j, oneMap);
 							CelldataMap.put(cellList.get(i)[4].toString().toString(), rowMap);
 							flag=true;
 							break;
 						}
 					}if(flag==false){
 						Map<Integer, List<String>> oneMap=new HashMap<Integer,List<String>>();
 						List<String> s=new ArrayList<String>();
 						s.add(rowStr);
 						oneMap.put((Integer)cellList.get(i)[1], s);
 						rowMap.add(oneMap);
 						CelldataMap.put(cellList.get(i)[4].toString().toString(), rowMap);
 					}	
 				}else{
 					List<Map<Integer, List<String>>> rowMap=new ArrayList<Map<Integer,List<String>>>();
 					Map<Integer, List<String>> oneMapp=new HashMap<Integer,List<String>>();
 					List<String> rowList=new ArrayList<String>();
 					rowList.add(rowStr);
 					oneMapp.put((Integer)cellList.get(i)[1], rowList);
 					rowMap.add(oneMapp);
 					CelldataMap.put(cellList.get(i)[4].toString(), rowMap);
 				}
 			}
        	 if(((Integer)userRoleEncryptionLeval.get(0)[1]==0 || (Integer)userRoleEncryptionLeval.get(0)[1]==2) && (Integer)userRoleEncryptionLeval.get(0)[0]==1){
        		 modelMap.put("isChairPersonReq","1");
        	}else{
        		modelMap.put("isChairPersonReq","0");
        	}
        	 if((Integer)userRoleEncryptionLeval.get(0)[1] == 0){
        		 modelMap.addAttribute("ChairpersonApprovedRejected",tenderFormService.getChairpersonApprovedRejectData(tenderId,2,bidderId)); // 2 - userRole for Encryption level 0
        	 }else{
        		 modelMap.addAttribute("ChairpersonApprovedRejected",tenderFormService.getChairpersonApprovedRejectData(tenderId,4,bidderId)); // 4 - userRole for Encryption level 1 or 2
        	 }
//        	 List<Object[]> ListBidderApprovalRemarks = tenderFormService.getApprovalDetlsOfTechnicalEnvlop(tenderId,envelopeId,0,createdBy);
//        	modelMap.addAttribute("ListBidderApprovalRemarks",ListBidderApprovalRemarks); 
        	modelMap.addAttribute("ListCellDtls",CelldataMap);
        	modelMap.addAttribute("ApprovedRejectList", commonService.getApproveReject());
        	modelMap.put("userRoleId", userRoleEncryptionLeval.get(0)[0]);
        	modelMap.put("encryptionLevel",userRoleEncryptionLeval.get(0)[1]);
        	modelMap.put("userDetailId",userDetailId );
	        modelMap.put("tenderId", tenderId);
	        modelMap.put("rejected", rejected);
			modelMap.put("envelopeId", envelopeId);
			modelMap.put("bidderId", bidderId);
			modelMap.put("committeeType",commiteeType);
			modelMap.put("overAllRemarksDtls",tenderFormService.getOverAllRemarks(tenderId,envelopeId,bidderId,commiteeType));
			//String loginDtls = loginService.getUserLoginById(sessionUserId).getUserName();
			StringBuilder loginDtls = new StringBuilder();
	  		  List<Object[]> committeeUserList=committeeFormationService.getCommiteeUserDetailsByTenderId(tenderId, envelopeId,commiteeType);
	  		  for (Object[] objects : committeeUserList) {
					if(sessionUserId == Integer.parseInt(objects[1].toString())){
						loginDtls.append(objects[5].toString() + "@@" + objects[4].toString());
						loginDtls.append("@@" + objects[3].toString());
					}
	  		  }    	
	  		  modelMap.put("loginUserName",loginDtls);
//			for (Object[] objects : ListBidderApprovalRemarks) {
//				if(Integer.parseInt(objects[0].toString())==bidderId){
//					TblUserDetail tblUserDetail = manageBidderService.getUserDetailById(Integer.parseInt(objects[3].toString()));
//					modelMap.put("chairpersionUserName",loginService.getUserLoginById(tblUserDetail.getTblUserLogin().getUserId()).getUserName());
//				}
//			}
			//document
			List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(70, abcUtility.getSessionClientId(request));
		    int allowedSize = 0;
		    StringBuilder allowedExt = new StringBuilder();
		    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
				allowedSize = lstDocUploadConf.get(0).getMaxSize();
				allowedExt.append(lstDocUploadConf.get(0).getType());
				modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
		    }
		    int index = allowedExt.toString().indexOf(",");
		    allowedExt.insert(index + 1, "*.");
		    while (index >= 0) {
				index = allowedExt.toString().indexOf(",", index + ",".length());
				allowedExt.insert(index + 1, "*.");
		    }

		    modelMap.addAttribute("allowedExt", allowedExt);
		    modelMap.addAttribute("allowedSize", allowedSize/1024);
		    modelMap.addAttribute("allowFileExist","Y");
		    List<Integer> lstLink=new ArrayList<Integer>();
			lstLink.add(evaluationEvaluateLinkId);
		    modelMap.addAttribute("linkId", lstLink);
//		    modelMap.addAttribute("objectId", envelopeId);
		    modelMap.addAttribute("isTenderDocDownload", "Y");
		    modelMap.addAttribute("cStatusDocView", officerDocStatusPending);
		    modelMap.addAttribute("cStatusDoc", 5);
		    modelMap.addAttribute("bidderId", bidderId);
		    modelMap.addAttribute("txtbidderId", bidderId);
		    modelMap.addAttribute("isUserIdwisePath","Y");
		    modelMap.addAttribute("isReq","Y");
		    int isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
            modelMap.put("isCertRequired", isCertRequired);
    		SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
    		ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            String certIds[] = null;
            if (clientBean.getIsPkiEnabled() == pkiEnable && sessionBean != null) {
                certIds = sessionBean.getCertId().split(",");
                if (certIds != null && certIds.length != 0) {
                    modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                }
            }
            modelMap.addAttribute("isAnyCancelledDoc", fileUploadService.getOfficerDocsDynamic(String.valueOf(envelopeId),String.valueOf(bidderId),String.valueOf(abcUtility.getSessionClientId(request)),String.valueOf(evaluationEvaluateLinkId),"3",String.valueOf(0)).size());
		    //end
            boolean isAnyPriceBid = false;
            if(tenderResult==1){
            	List<Object[]>  rebateFormList = tenderFormService.getRebateFormByTenderId(tenderId);
            	modelMap.addAttribute("rebateFormList",rebateFormList);
            	/**
            	 * Below code will be executed when L/H1 is Manual,Price Summary is not created and 
            	 * Event is Grandtotalwise and two Stage evaluation is Yes(CR #32101)
            	 */
            	if(rebateFormList.isEmpty()){
            	Object winningReportMode = tenderCommonService.getTenderField(tenderId,"winningReportMode");
            	if(winningReportMode!=null && winningReportMode!=""){
            	if(Integer.parseInt(winningReportMode.toString()) == 2){//winningReportMode -2 means L1/H1 is Manual and 1 means Auto	
            	 modelMap.addAttribute("FormList", tenderFormService.getFormByTenderIdBidderIdEnvelopeId(tenderId,bidderId,envelopeId));
            	  }
            	 }
            	}
	            boolean isWeightageEvaluationRequired = Integer.parseInt(modelMap.get("isWeightageEvaluationRequired").toString())==1;
	    		if(isWeightageEvaluationRequired){
	    			ArrayList<String> bidderIdList = new ArrayList<String>();
	    			bidderIdList.add(Integer.toString(bidderId));
					boolean isBidderWeightageConfig = tenderFormService.getBidderweightageScoreCount(tenderId, envelopeId,abcUtility.getSessionUserId(request));
					if(isBidderWeightageConfig){
						Map<Integer,Boolean> weightageEval = tenderFormService.getBidderWeightageEvaluationApproveDetail(tenderId,envelopeId,bidderIdList,abcUtility.getSessionUserId(request));
						modelMap.put("weightageEval", weightageEval);
					}
					modelMap.put("bidderIdList", bidderIdList);
	    		}
            }else{
            	isAnyPriceBid = tenderCommonService.getTenderFormAndTableByTenderId(tenderId,bidderId,1).size() != 0 ? true : false;
            }
            modelMap.addAttribute("isAnyPriceBid",isAnyPriceBid);
         } catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), evaluationEvaluateLinkId , evaluatebidderswisestatusaddpage,tenderId,envelopeId);
         }
         return "/etender/buyer/EvaluateBidderWise";
     }     
     /**
    	 * Use to Save Bidder Wise Evaluation ---Two Stage Evaluation
    	 * @author Keval.soni
    	 * @param request
	 	 * @param ModelMap
	 	 * @throws Exception
	 	 * @return
    	 */
     @RequestMapping(value = "/buyer/saveBidderWiseEvaluation", method = RequestMethod.POST)
     public String saveBidderWiseEvaluation(RedirectAttributes redirectAttributes, HttpServletRequest request) {
     	boolean success=false;
     	String retVal=REDIRECT_SESSION_EXPIRED;
        int tenderId=0;
        int envelopeId=0;
         try{
	    	 int sessionUserId = abcUtility.getSessionUserId(request);
	    	 if(sessionUserId!=0){
		     tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;  
		     envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
	         int bidderId = StringUtils.hasLength(request.getParameter("hdBidderId"))? Integer.parseInt(request.getParameter("hdBidderId")):0;
	         int CommiteeType = StringUtils.hasLength(request.getParameter("hdCommiteeType"))? Integer.parseInt(request.getParameter("hdCommiteeType")):0;
	         int UserDetailId = StringUtils.hasLength(request.getParameter("hdUserDetailId"))? Integer.parseInt(request.getParameter("hdUserDetailId")):0;
	         int UserRoleId = StringUtils.hasLength(request.getParameter("hdUserRoleId"))? Integer.parseInt(request.getParameter("hdUserRoleId")):0;
	         int encryptionLevel = StringUtils.hasLength(request.getParameter("hdEncryptionLevel"))? Integer.parseInt(request.getParameter("hdEncryptionLevel")):0;
	         int companyId = StringUtils.hasLength(request.getParameter("hdCompanyId"))? Integer.parseInt(request.getParameter("hdCompanyId")):0;
	         int tenderResult = StringUtils.hasLength(request.getParameter("hdTenderResult"))? Integer.parseInt(request.getParameter("hdTenderResult")):0;
	         TblBidderApprovalDetail tblBidderApprovalDetail=null;
       		 List<TblBidderApprovalDetail> tblBidderApprovalDtls=new ArrayList<TblBidderApprovalDetail>();
       		 int hdRowCount = StringUtils.hasLength(request.getParameter("hdRowCount")) ? Integer.parseInt(request.getParameter("hdRowCount")):0;
       		 int userDetailId = abcUtility.getSessionUserDetailId(request);
       		 int bidderAprvYesNo=0;
       		 int priceBidNoCnt = 0,priceBidYesCnt = 0;
       		 List<Integer> formIds = new ArrayList<Integer>();
	       	 if(tenderResult==2){
	       		List<Object[]> formAndTableDetalisList=tenderCommonService.getTenderFormAndTableByTenderId(tenderId,bidderId,0);
	       		 for(Object[] obj : formAndTableDetalisList){
	       			 if((Integer)obj[6] == 0 && !formIds.contains((Integer)obj[0])){
	       				priceBidNoCnt++;
	       			 	formIds.add((Integer)obj[0]);
	       			 }else
	       				priceBidYesCnt++;
	       		 }
	       	 }
       		 List<Object[]> bidderwiseItmEntry = tenderFormService.ChkandgetItemWiseEvaluationData(tenderId,envelopeId,sessionUserId,bidderId);
       		 List<TblBidderItems> bidderItemsList = new ArrayList<TblBidderItems>();
       		 int isBidderAprvl=0;
       		 int formId = 0;
       		 int tableId = 0;
       		 int rowId = 0;
       		 List<TblCommitteeRemarks> tblCommitteeDtls=new ArrayList<TblCommitteeRemarks>();
		     if(bidderwiseItmEntry.isEmpty()){
	          		for(int i=0;i<hdRowCount;i++){
		          		String allValue = StringUtils.hasLength(request.getParameter("hdAllValues_"+i)) ? request.getParameter("hdAllValues_"+i):null;
	          			if(tenderResult==1){
	          				bidderAprvYesNo = StringUtils.hasLength(request.getParameter("rdItemWiseOfficerApvrl_"+bidderId)) ? Integer.parseInt(request.getParameter("rdItemWiseOfficerApvrl_"+bidderId)):0;
	          			}else{
	          				bidderAprvYesNo = StringUtils.hasLength(request.getParameter("rdItemWiseOfficerApvrl_"+allValue)) ? Integer.parseInt(request.getParameter("rdItemWiseOfficerApvrl_"+allValue)):0;	          				
	          			}
	          			String remarks = StringUtils.hasLength(request.getParameter("txtaRemarks_"+allValue)) ? request.getParameter("txtaRemarks_"+allValue):null;
	          			String allIds[]=allValue.split("_");
	          			if(tenderResult==1){
	          				formId=Integer.parseInt(allIds[0]);
	          			}else{
	          				formId=Integer.parseInt(allIds[1]);
	          			}
	          			if(bidderAprvYesNo==1){
	          				isBidderAprvl=1;
	          			}
	          			if(tenderResult==2){
	          				tableId = Integer.parseInt(allIds[2]);
	          				rowId = Integer.parseInt(allIds[3]);
	          			}
	          			TblBidderItems tblBidderItems = new TblBidderItems();
	          			tblBidderItems.setTblTender(new TblTender(tenderId));
	          			tblBidderItems.setUserRoleId(UserRoleId);
	          			
	          			if(UserRoleId==1){
	          				tblBidderItems.setIsCPRemarks(1);
	                     }else{
	                    	 tblBidderItems.setIsCPRemarks(0);	 
	                     }
                    	 if(encryptionLevel==0){
                    		 tblBidderItems.setUserRoleId(UserRoleId == 1 ? 2 : 1);
                    	 }else if(encryptionLevel==1){
                    		 tblBidderItems.setUserRoleId(UserRoleId == 1 ? 2 : 1);
	                    }else{
	                    	tblBidderItems.setUserRoleId(UserRoleId == 1 ? 4 : 3);
	                    }
                    	 
                    	 
	          			/*tblBidderItems.setRe*/
 	                	tblBidderItems.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
 	                	tblBidderItems.setTblTenderForm(new TblTenderForm(formId));//formId
 	                	if(tenderResult==2)
 	                		tblBidderItems.setTblTenderTable(new TblTenderTable(tableId));//tableId
 	                	tblBidderItems.setRemarks(remarks);
 	                	tblBidderItems.setRowId(rowId);//rowId
 	                	tblBidderItems.setTblUserLogin(new TblUserLogin(bidderId));
 	                	tblBidderItems.setTblCompany(new TblCompany(companyId));
 	                	tblBidderItems.setCreatedBy(sessionUserId); // user login id.
 	                	tblBidderItems.setIsActive(1);//1 for approve items
 	                	tblBidderItems.setChildId(0);
 	                	tblBidderItems.setIsApproved(bidderAprvYesNo);//1 for approve items
 	                    bidderItemsList.add(tblBidderItems);
		          	}
	          		for(int i=0;i<priceBidNoCnt;i++){
	          			if(priceBidYesCnt > 0)
	          				bidderAprvYesNo = isBidderAprvl;
	          			else
	          				isBidderAprvl = bidderAprvYesNo = StringUtils.hasLength(request.getParameter("rdNotAnyPriceBidForm_"+bidderId)) ? Integer.parseInt(request.getParameter("rdNotAnyPriceBidForm_"+bidderId)):0;
	          			formId = formIds.get(i);
	          			TblBidderItems tblBidderItems = new TblBidderItems();
	          			tblBidderItems.setTblTender(new TblTender(tenderId));
	          			tblBidderItems.setUserRoleId(UserRoleId);
	          			
	          			if(UserRoleId==1){
	          				tblBidderItems.setIsCPRemarks(1);
	                     }else{
	                    	 tblBidderItems.setIsCPRemarks(0);	 
	                     }
                    	 if(encryptionLevel==0){
                    		 tblBidderItems.setUserRoleId(UserRoleId == 1 ? 2 : 1);
                    	 }else if(encryptionLevel==1){
                    		 tblBidderItems.setUserRoleId(UserRoleId == 1 ? 2 : 1);
	                    }else{
	                    	tblBidderItems.setUserRoleId(UserRoleId == 1 ? 4 : 3);
	                    }
                    	tblBidderItems.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
  	                	tblBidderItems.setTblTenderForm(new TblTenderForm(formId));//formId
  	                	tblBidderItems.setTblTenderTable(null);//tableId
  	                	tblBidderItems.setRemarks("Price Bid No Form - Auto");
  	                	tblBidderItems.setRowId(0);//rowId
  	                	tblBidderItems.setTblUserLogin(new TblUserLogin(bidderId));
  	                	tblBidderItems.setTblCompany(new TblCompany(companyId));
  	                	tblBidderItems.setCreatedBy(sessionUserId); // user login id.
  	                	tblBidderItems.setIsActive(1);//1 for approve items
  	                	tblBidderItems.setChildId(0);
  	                	tblBidderItems.setIsApproved(bidderAprvYesNo);//1 for approve items
  	                    bidderItemsList.add(tblBidderItems);
	          		}
	          		if(bidderItemsList != null && !bidderItemsList.isEmpty()){
	          			success = tenderFormService.saveAllTblBidderItemsWiseEvaluation(bidderItemsList);
	                 }
		       }
	          	int isChairPersonReq=StringUtils.hasLength(request.getParameter("hdIsChairPersonReq"))? Integer.parseInt(request.getParameter("hdIsChairPersonReq")):0;
	          	boolean bidderwiseItmApprovalEntry = tenderFormService.checkEntryBidderAppDtlsBidderWise(tenderId, envelopeId,bidderId);
	          	if(success && bidderwiseItmApprovalEntry && isChairPersonReq==1){
	          		String remarks = StringUtils.hasLength(request.getParameter("txtaRemarks_OffReq")) ? request.getParameter("txtaRemarks_OffReq"):null;
	          		int finalSubmissionId=tenderFormService.getFinalSubmissionId(tenderId,bidderId);
	          		int userDtlId=loginService.getBidderUserDetailId(bidderId);
	          		tblBidderApprovalDetail = new TblBidderApprovalDetail();
	          		tblBidderApprovalDetail.setTblTender(new TblTender(tenderId));
	              	tblBidderApprovalDetail.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
	              	tblBidderApprovalDetail.setTblCompany(new TblCompany(companyId));
	              	tblBidderApprovalDetail.setTblUserLogin(new TblUserLogin(bidderId));
	              	tblBidderApprovalDetail.setTblUserDetail(new TblUserDetail(userDtlId));
	              	tblBidderApprovalDetail.setTblFinalSubmission(new TblFinalSubmission(finalSubmissionId));
	              	tblBidderApprovalDetail.setRemarks(remarks);
	              	tblBidderApprovalDetail.setCreatedBy(userDetailId);
	              	tblBidderApprovalDetail.setIsApproved(isBidderAprvl);
	              	tblBidderApprovalDtls.add(tblBidderApprovalDetail);
	              	success = tenderFormService.addEachBidderAprvalDtls(tblBidderApprovalDtls);
	          	}
	          	if(success){
	          		/*Over all remarks for members*/
	          		String remarks = StringUtils.hasLength(request.getParameter("txtaRemarks_OffReq")) ? request.getParameter("txtaRemarks_OffReq"):null;
	          		TblCommitteeRemarks tblCommitteeRemarks = new TblCommitteeRemarks();
                    tblCommitteeRemarks.setTblTender(new TblTender(tenderId));
                    tblCommitteeRemarks.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
                    tblCommitteeRemarks.setTblCompany(new TblCompany(companyId));  //companyId
                    tblCommitteeRemarks.setRemarks(remarks);
                    tblCommitteeRemarks.setCreatedBy(userDetailId);
                    tblCommitteeRemarks.setTblUserLogin(new TblUserLogin(sessionUserId));
                    
                    tblCommitteeRemarks.setBidderId(bidderId);
                    tblCommitteeRemarks.setIsActive(1);
                    tblCommitteeRemarks.setChildId(0);
                    tblCommitteeRemarks.setCommitteeType(CommiteeType);
                    
               	 if(UserRoleId==1){
                   	 tblCommitteeRemarks.setIsCPRemarks(1);
                    }else{
                   	 tblCommitteeRemarks.setIsCPRemarks(0);	 
                    }
               	 if(encryptionLevel==0){
               		 tblCommitteeRemarks.setUserRoleId(UserRoleId == 1 ? 2 : 1);
               	 }else if(encryptionLevel==1){
                   	tblCommitteeRemarks.setUserRoleId(UserRoleId == 1 ? 2 : 1);
                 }else{
                   	tblCommitteeRemarks.setUserRoleId(UserRoleId == 1 ? 4 : 3);
                 }
                 if(CommiteeType==1){
                	 tblCommitteeRemarks.setIsApproved(1); 
                 }if(CommiteeType==2){
                	 tblCommitteeRemarks.setIsApproved(isBidderAprvl); 
                 }
                 tblCommitteeDtls.add(tblCommitteeRemarks);
                 success = tenderFormService.addRemarksDetails(tblCommitteeDtls);
	          	}
	          	if(success && isEvaluationDone(tenderId)){
	          		/*Generate system generate Weightage L1 Report*/
	        		List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isWeightageEvaluationRequired,isItemwiseWinner");
	           		int isWeightageEvaluationRequired = 0;
	           		if(tenderDetails!= null && !tenderDetails.isEmpty()){
	           			isWeightageEvaluationRequired =Integer.parseInt(tenderDetails.get(0)[0].toString());
	           		}
	           		if(isWeightageEvaluationRequired == 1){
	           			TblDynReport tblDynReport  = dynamicReportService.getDynReportById(tenderId,5);
	           			if(tblDynReport!=null)
	           				dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(),tenderId,abcUtility.getSessionUserId(request));
	           		}
	        	}
	          	if (success) {
	          		// When all envelopes are evaluated then update tender status to completed.
		          	 List<Object[]>	obj= tenderFormService.getAllEnvelopWiseEvaluationDone(tenderId);
	              	 if(obj != null && obj.get(0)[0].equals(obj.get(0)[1])){
	              		eventCreationService.updateTenderEvalutionStatus(tenderId, TENDER_COMPLETED_STATUS);
	              	 }
	              		
	          		 String txtHidDocIds = CommonUtility.checkNull(request.getParameter("txtHidDocIds"));
	                 if (!"".equalsIgnoreCase(txtHidDocIds)) {
	                 	success = fileUploadService.updateOfficerDocsObjectId(txtHidDocIds, envelopeId,sessionUserId,bidderId);
	                 }
	          	}
	        }
        } 		
	     catch(Exception e){
	     	return exceptionHandlerService.writeLog(e);
	     }finally {
	    	 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), evaluationEvaluateLinkId , success ? evaluatebiddersstatusadd : evaluatebiddersstatusaddfail,tenderId,envelopeId);
	     }
	     retVal=success?TENDER_DASHBOARD_URL+tenderId+"/"+TAB_EVALUATE_BID:"/etender/buyer/evaluatebidders/"+tenderId+"/"+envelopeId+"/"+1;
		 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
		 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_evaluate_bidders_status_add" : CommonKeywords.ERROR_MSG_KEY.toString());
	     return retVal;
     }
     
     /**
 	 * Use to get Evaluate Bidders for add or edit status 
 	 * @author krunal.patel
 	 * @param tenderId
 	 * @param envelopeId
 	 * @param createEditFlage
 	 * @param envlopTypFlg
 	 * @param sortOrder
 	 * @param preEnvelopeId
 	 * @param request
 	 * @param ModelMap
 	 * @throws Exception
 	 * @return
 	 */
@RequestMapping(value = "/buyer/evaluatebidders/{tenderId}/{envelopeId}/{createEditFlage}/{envlopTypFlg}/{sortOrder}/{preEnvelopeId}/{isView}/{enc}", method = RequestMethod.GET)
   public String getEvaluateBidders(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("createEditFlage") int createEditFlage,@PathVariable("envlopTypFlg") int envlopTypFlg,@PathVariable("sortOrder") int sortOrder,@PathVariable("preEnvelopeId") int preEnvelopeId ,@PathVariable("isView") boolean isView,ModelMap modelMap,HttpServletRequest request) {
       try {
    	   StringBuilder formIds = new StringBuilder();
	          	
     	  	/*** Get Common Services for tender detail **/
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
			boolean isTwoStageEvaluation = (Integer) modelMap.get("isTwoStageEvaluation")==1?true:false;
			int sessionUserId = abcUtility.getSessionUserId(request);       	
			/*** get Yes No list from common services **/
			modelMap.addAttribute("mandatoryList", commonService.getApproveReject());
			modelMap.addAttribute("isTwoStageEvaluationFlag",isTwoStageEvaluation);
			
			
			/*** Get TenderEnvelope details for tender Envelope name **/
			TblTenderEnvelope tblTenderEnvelope = tenderCommonService.getTenderEnvelopeById(envelopeId);
			
			/*** Code to get isConsortiumAllowed field from tender table if 0 means then map have put all key has different else set same key in case of 2 user have in Consortium **/
			List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "isConsortiumAllowed,isCertRequired,isEncodedName,isEncodedForTechnical");
			int isConsortiumAllowed = Integer.parseInt(tenderFields.get(0)[0].toString());
			int isCertRequired = Integer.parseInt(tenderFields.get(0)[1].toString());
			/** Changes done to show encoded bidder name for Bug #50576 **/
			int isEncodedName = 0;
			int isEncodedNameForPriceBid = Integer.parseInt(tenderFields.get(0)[2].toString());
			int isEncodedNameForTechnical = Integer.parseInt(tenderFields.get(0)[3].toString());
			int letestCstatusEncodeDecodeHistory = commonService.getLetestCstatusEncodeDecodeHistory(tenderId);

			if(letestCstatusEncodeDecodeHistory == 1 && isEncodedNameForPriceBid == 1 && (tblTenderEnvelope.getTblEnvelope().getEnvId() == 4 || tblTenderEnvelope.getTblEnvelope().getEnvId() == 5))
				isEncodedName = 1;
			else if(letestCstatusEncodeDecodeHistory == 1 && isEncodedNameForTechnical == 1 && (tblTenderEnvelope.getTblEnvelope().getEnvId() == 3 || tblTenderEnvelope.getTblEnvelope().getEnvId() == 5))
				isEncodedName = 1;
			else
	        	isEncodedName = 0;
			modelMap.addAttribute("isEncodedName",isEncodedName);
			
			// Process if having encryption not require column
			List<Object[]> loadingFactorList = tenderFormService.getLoadingFactor(tenderId);
			int haveEncNotReqCol = !loadingFactorList.isEmpty() ? Integer.parseInt(loadingFactorList.get(0)[1].toString()) : 0;
            modelMap.addAttribute("isEncNotRequire",haveEncNotReqCol);
            if(haveEncNotReqCol == 1 && envlopTypFlg == 2 && tblTenderEnvelope.getTblEnvelope().getEnvId() == 3){
            	SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
	            List<Object[]> allBidderList = tenderFormService.getAllBidders(tenderId,sessionBean.getUserId());
				//StringBuffer companyIdsBidderItem = new StringBuffer();
				Map<String,Object> eligableCompany = new HashMap<String, Object>();  
				if(allBidderList!=null && !allBidderList.isEmpty()){
					for(Object[] obj: allBidderList){
						//companyIdsBidderItem.append(obj[1]).append(",");
						eligableCompany.put(obj[1].toString(), obj[1]);
					}
					//companyIdsBidderItem.deleteCharAt(companyIdsBidderItem.length()-1);
					
				}
				modelMap.put("companyIdsBidderItem", eligableCompany);
            }
			
            List <EvaluateBiddersDataBean> evaluateBiddersList = new ArrayList<EvaluateBiddersDataBean>();
            if(isTwoStageEvaluation){
            	setIncrementOfficerData(tenderId,envelopeId,2,sessionUserId,isView,modelMap);
            	//String loginDtls = loginService.getUserLoginById(sessionUserId).getUserName();
            	 StringBuilder loginDtls = new StringBuilder();
	      		List<Object[]> committeeUserList=committeeFormationService.getCommiteeUserDetailsByTenderId(tenderId, envelopeId,2);
	      		for (Object[] objects : committeeUserList) {
	      			if(sessionUserId == Integer.parseInt(objects[1].toString())){
	      				loginDtls.append(objects[5].toString() + "@@" + objects[4].toString());
	      				loginDtls.append("@@" + objects[3].toString());
	  				}
	      		}    	
	      		modelMap.put("loginUserName",loginDtls);
	      	//document
				List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(70, abcUtility.getSessionClientId(request));
			    int allowedSize = 0;
			    StringBuilder allowedExt = new StringBuilder();
			    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
					allowedSize = lstDocUploadConf.get(0).getMaxSize();
					allowedExt.append(lstDocUploadConf.get(0).getType());
					modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
			    }
			    int index = allowedExt.toString().indexOf(",");
			    allowedExt.insert(index + 1, "*.");
			    while (index >= 0) {
					index = allowedExt.toString().indexOf(",", index + ",".length());
					allowedExt.insert(index + 1, "*.");
			    }
			    modelMap.addAttribute("allowedExt", allowedExt);
                modelMap.addAttribute("allowedSize", allowedSize/1024);
                modelMap.addAttribute("cStatusDoc", 5);
                modelMap.addAttribute("allowFileExist","Y");
                modelMap.addAttribute("linkId", evaluationEvaluateLinkId);
                modelMap.addAttribute("objectIdNew",envelopeId);
	            modelMap.addAttribute("cStatusDocView", 0);
	    		modelMap.addAttribute("objectId", envelopeId);
			    modelMap.addAttribute("isTenderDocDownload", "Y");
			    modelMap.addAttribute("mappedBy",sessionUserId);
			    modelMap.addAttribute("isUserIdwisePath","Y");
			    modelMap.addAttribute("isReq","Y");
	            modelMap.put("isCertRequired", isCertRequired);
	    		SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
	    		ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	            String certIds[] = null;
	            if (clientBean.getIsPkiEnabled() == pkiEnable && sessionBean != null) {
	                certIds = sessionBean.getCertId().split(",");
	                if (certIds != null && certIds.length != 0) {
	                    modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
	                }
	            }
			    //end
            }
			/*** Get Evaluate bidders detail **/
			@SuppressWarnings("unchecked")
			Map<String,Object> evaluateBiddersListPro = (Map<String,Object>) tenderFormService.getEvaluateBiddersList(tenderId, envelopeId, preEnvelopeId,envlopTypFlg,isConsortiumAllowed, sortOrder, createEditFlage);
			List<Map<String,Object>> evaluateBiddersListObj = (List<Map<String,Object>>) evaluateBiddersListPro.get(RESULT_SET_1);
			List<Map<String,Object>> nextEnvelopFormIds = (List<Map<String,Object>>) evaluateBiddersListPro.get(RESULT_SET_2);
			ArrayList<String> bidderIdList = new ArrayList<String>();
			if(!evaluateBiddersListObj.isEmpty()){
				for(Map<String,Object> evalMap:evaluateBiddersListObj){
				
					
					EvaluateBiddersDataBean evaluateBiddersDB = new EvaluateBiddersDataBean();
					String bidderIdStr = evalMap.get("bidderIds").toString();
					String[] bidderIdArr   = bidderIdStr.split("\\|~\\|"); 
					long countofActiveForm = tenderFormService.getCountofActiveForm(tenderId,envelopeId,Integer.valueOf(bidderIdArr[2].toString()));
                    if(countofActiveForm!=0){ 
					bidderIdList.add(bidderIdArr[2]);
					evaluateBiddersDB.setBidderIds(evalMap.get("bidderIds").toString());
					evaluateBiddersDB.setCompanyName(evalMap.get("companyName").toString().substring(0,evalMap.get("companyName").toString().length()-1));
					evaluateBiddersDB.setBidderApprovalId(evalMap.get("bidderApprovalId").toString());
					evaluateBiddersDB.setRemarks(evalMap.get("remarks").toString());
					evaluateBiddersDB.setIsApproved(evalMap.get("isApproved").toString());
					evaluateBiddersDB.setEncodedName(evalMap.get("encodedName").toString());
					
					evaluateBiddersList.add(evaluateBiddersDB);
                    }else{
    					bidderIdList.add(bidderIdArr[2]);
    					evaluateBiddersDB.setBidderIds(evalMap.get("bidderIds").toString());
    					evaluateBiddersDB.setCompanyName(evalMap.get("companyName").toString().substring(0,evalMap.get("companyName").toString().length()-1));
    					evaluateBiddersDB.setBidderApprovalId(evalMap.get("bidderApprovalId").toString());
    					evaluateBiddersDB.setRemarks(evalMap.get("remarks").toString());
    					evaluateBiddersDB.setIsApproved("3");
    					
    					evaluateBiddersList.add(evaluateBiddersDB);
                        }
					
				}
			}
			if(!nextEnvelopFormIds.isEmpty()){
				for(Map<String,Object> formMap:nextEnvelopFormIds){
					formIds.append(formMap.get("formId").toString()).append(",");
				}
			}
			boolean isWeightageEvaluationRequired = Integer.parseInt(modelMap.get("isWeightageEvaluationRequired").toString())==1;
			boolean isGrandTotalWiseTenderResult = Integer.parseInt(modelMap.get("tenderResult").toString())==1;
    		if(isWeightageEvaluationRequired && isGrandTotalWiseTenderResult)
    		{
				boolean isBidderWeightageConfig = tenderFormService.getBidderweightageScoreCount(tenderId, envelopeId,isTwoStageEvaluation ? abcUtility.getSessionUserId(request) : 0);
				if(isBidderWeightageConfig)
				{
					Map<Integer,Boolean> weightageEval = tenderFormService.getBidderWeightageEvaluationApproveDetail(tenderId,envelopeId,bidderIdList,isTwoStageEvaluation ? abcUtility.getSessionUserId(request) : 0);
					modelMap.put("weightageEval", weightageEval);
				}
    		}
    		boolean isOpeningByCommitee = Integer.parseInt(modelMap.get("isOpeningByCommittee").toString())==0;
    		TblTenderEnvelope tblnextTenderEnvelope = tenderFormService.getEnvlopeIdAsSortorder(sortOrder+1,tenderId);
    		if(tblnextTenderEnvelope!=null){
    			modelMap.put("nextEnvOpened", tblnextTenderEnvelope.getIsOpened());
    		}
    		if(isOpeningByCommitee){
    			modelMap.put("nextEnvOpened", 1);
    		}
			modelMap.put("bidderIdList", bidderIdList);
			modelMap.put("tabId", TAB_EVALUATE_BID);
			modelMap.put("tenderId", tenderId);
			modelMap.put("envelopeId", envelopeId);
			modelMap.put("evaluateBiddersMap", evaluateBiddersList);
			modelMap.put("tblTenderEnvelope",tblTenderEnvelope);
			modelMap.put("createEditFlage",createEditFlage);
			modelMap.put("envlopTypFlg",envlopTypFlg);
			modelMap.put("sortOrder",sortOrder);
			modelMap.put("formIds",formIds);
			modelMap.put("isCertRequired",isCertRequired);
			modelMap.put("preEnvelopeId",preEnvelopeId);
			
       } catch (Exception e) {
           return exceptionHandlerService.writeLog(e);
       }finally {
           auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEditFlage==1?evaluationEvaluateLinkId:evaluationReEvaluateLinkId ,createEditFlage==1? evaluatebiddersstatusaddpage:reevaluatebiddersstatusaddpage,tenderId,envelopeId);
       }
       return "/etender/buyer/Evaluatebidders";
   }
     /**
 	 * Use to save Evaluate bidders Status 	
 	 * @author krunal.patel
 	 * @param request
 	 * @param ModelMap
 	 * @throws Exception
 	 * @return
 	 */
     @RequestMapping(value = "/buyer/saveevlutbiderstatus", method = RequestMethod.POST)
     public String saveEvlutBiderStatus(RedirectAttributes redirectAttributes, HttpServletRequest request) {
     	boolean success=false;
     	boolean tblEntryChk=false;
     	String retVal=REDIRECT_SESSION_EXPIRED;
        int tenderId=0;
        int envelopeId=0;
        int envlopTypFlg=0;
        int isCertRequired=0;
        String formIds="";
        boolean reevalsucess=true;
        String isView="";
        int preEnvelopeId=0;
        int sortOrder=0;
         try{
        	 int sessionUserId = abcUtility.getSessionUserId(request);
        	if(sessionUserId!=0){
	        	tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;  
	            envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
	            String eventType=StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
	            formIds = StringUtils.hasLength(request.getParameter("hdFormIds")) ? request.getParameter("hdFormIds") : "";
	            envlopTypFlg = StringUtils.hasLength(request.getParameter("hdEnvlopTypFlg")) ? Integer.parseInt(request.getParameter("hdEnvlopTypFlg")):0;
	            isCertRequired = StringUtils.hasLength(request.getParameter("hdIsCertRequired")) ? Integer.parseInt(request.getParameter("hdIsCertRequired")):0;
	            preEnvelopeId = StringUtils.hasLength(request.getParameter("hdpreEnvelopeId")) ? Integer.parseInt(request.getParameter("hdpreEnvelopeId")):0;	 
	        	 sortOrder = StringUtils.hasLength(request.getParameter("hdsortOrder")) ? Integer.parseInt(request.getParameter("hdsortOrder")):0;	 
	        	 isView = StringUtils.hasLength(request.getParameter("hdisView")) ? request.getParameter("hdisView"):"";	 
	        	 
	        	int hdRowCount = StringUtils.hasLength(request.getParameter("hdRowCount")) ? Integer.parseInt(request.getParameter("hdRowCount")):0;
	        	TblBidderApprovalDetail tblBidderApprovalDetail=null;
	          	List<TblBidderApprovalDetail> tblBidderApprovalDtls=new ArrayList<TblBidderApprovalDetail>();
	          	String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
	          	
	          	/*** Start Code to check for tenderId and envelopeId entry all ready in table then return to page **/
	          	tblEntryChk = tenderFormService.checkEntryBidderAppDtls(tenderId, envelopeId);
	          	
	          	int isReEvaluationReq = 0;
	          	isReEvaluationReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isReEvaluationReq").toString());
	          	if( isReEvaluationReq==1 ){
	          		Integer[] ctatus={0};
	          		List<TblTenderReevaluation> tblTenderreevaluation = tenderFormService.getTblTenderEnvelopeRevaluationStatusByTenderId(tenderId, ctatus);
	          		if(tblTenderreevaluation!=null && !tblTenderreevaluation.isEmpty() ){
	          			reevalsucess=false;
	          		}
	          	}
	          	if(tblEntryChk && reevalsucess){
	          	 int userDetailId = abcUtility.getSessionUserDetailId(request);
	          	List<TblCompany> companyIds = new ArrayList<TblCompany>();
	          	int bidderAprvYesNo=0;
	          	for(int i=0;i<hdRowCount;i++){
          			bidderAprvYesNo = StringUtils.hasLength(request.getParameter("rdBidderAprvYesNo_"+i)) ? Integer.parseInt(request.getParameter("rdBidderAprvYesNo_"+i)):0;
          			String remarks = StringUtils.hasLength(request.getParameter("txtaRemarks_"+i)) ? request.getParameter("txtaRemarks_"+i):null;
          			String allBidderVal = StringUtils.hasLength(request.getParameter("hdAllValues_"+i)) ? request.getParameter("hdAllValues_"+i):null;
          			
          				
          					String[] singleBidderVal = allBidderVal.split("\\|~~~\\|");
          						if(singleBidderVal != null){
          							for(int j=0;j<singleBidderVal.length;j++){
          								String[] singleBidderIds = singleBidderVal[j].split("\\|~\\|");
          								if(singleBidderVal != null){
          									
          									tblBidderApprovalDetail = new TblBidderApprovalDetail();
                                  			tblBidderApprovalDetail.setTblTender(new TblTender(tenderId));
                                          	tblBidderApprovalDetail.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
                                          	tblBidderApprovalDetail.setTblCompany(new TblCompany(Integer.parseInt(singleBidderIds[1])));
                                          	tblBidderApprovalDetail.setTblUserLogin(new TblUserLogin(Integer.parseInt(singleBidderIds[2])));
                                          	tblBidderApprovalDetail.setTblUserDetail(new TblUserDetail(Integer.parseInt(singleBidderIds[3])));
                                          	tblBidderApprovalDetail.setTblFinalSubmission(new TblFinalSubmission(Integer.parseInt(singleBidderIds[0])));
                                         
                                          	tblBidderApprovalDetail.setCreatedBy(userDetailId);
                                          	if(bidderAprvYesNo==0 && remarks==null){
                                          		tblBidderApprovalDetail.setRemarks("");
                                          		tblBidderApprovalDetail.setIsApproved(3);
                                          	}else{
                                          		tblBidderApprovalDetail.setRemarks(remarks);
                                          		tblBidderApprovalDetail.setIsApproved(bidderAprvYesNo);
                                          	}
                                                                                  	
                                          	companyIds.add(new TblCompany(Integer.parseInt(singleBidderIds[1])));
                                          	
                                          	tblBidderApprovalDtls.add(tblBidderApprovalDetail);	
          								}
          							}		
          						}
	          			}
	          	
	          	/*** Start Code to entry in addTenderBidOpenDetails for multiple envelop and in non pki case**/
	          	if(envlopTypFlg == 2 && !formIds.equals("0")){
	          		String[] strArray = formIds.split(",");
		          	List<TblTenderForm> tblTenderFormList = new ArrayList<TblTenderForm>();
		          	for(int i = 0; i < strArray.length; i++) {
		          		tblTenderFormList.add(new TblTenderForm(Integer.parseInt(strArray[i])));
		          	}
		          	
	        		List<TblTenderBid> tblTenderBidList = eventBidSubmissionService.getTenderBid(tenderId, companyIds.toArray(),tblTenderFormList.toArray());
	        		if(tblTenderBidList != null && !tblTenderBidList.isEmpty()){
	        			List<TblTenderOpen> tblTenderOpenList = new ArrayList<TblTenderOpen>();
	        			List<TblTenderBidOpenSign> tblTenderBidOpenSignList = new ArrayList<TblTenderBidOpenSign>();
	        			List<TblTenderBidDetail> tblTenderBidDetailList = new ArrayList<TblTenderBidDetail>();
	        			List<String> userFormIds = new ArrayList<String>();
	        			
	            		for(TblTenderBid tblTenderBid : tblTenderBidList){
	            			String userFormId = tblTenderBid.getTblTenderForm().getFormId() + "~" + tblTenderBid.getTblCompany().getCompanyId(); 
	            			if(!userFormIds.contains(userFormId)){
		            			TblTenderOpen tblTenderOpen = new TblTenderOpen();
		            			tblTenderOpen.setTblTender(tblTenderBid.getTblTender());
		            			tblTenderOpen.setTblTenderEnvelope(tblTenderBid.getTblTenderEnvelope());
		            			tblTenderOpen.setTblTenderForm(tblTenderBid.getTblTenderForm());
		            			tblTenderOpen.setTblCompany(tblTenderBid.getTblCompany());
		            			tblTenderOpen.setTblUserLogin(tblTenderBid.getTblUserLogin());
		            			tblTenderOpen.setDecryptionLevel(1);
		            			tblTenderOpen.setIpAddress(ipAddress);
		            			tblTenderOpen.setCreatedBy(userDetailId);
		            			tblTenderOpenList.add(tblTenderOpen);
	            			}
	            			
	            			List<TblTenderBidMatrix> tblTenderBidMatrixList = eventBidSubmissionService.getTableBidMatrix(tblTenderBid.getBidId());
	            			
	            			if(tblTenderBidMatrixList != null && !tblTenderBidMatrixList.isEmpty()){
	            				for(TblTenderBidMatrix tblTenderBidMatrix : tblTenderBidMatrixList){
	            					TblTenderBidOpenSign tblTenderBidOpenSign = new TblTenderBidOpenSign();
	            					tblTenderBidOpenSign.setTblTenderBidMatrix(tblTenderBidMatrix);
	            					tblTenderBidOpenSign.setDecryptedBid(tblTenderBidMatrix.getBidJson());
	            					tblTenderBidOpenSign.setBidSignText(tblTenderBidMatrix.getBidJson());
	            					tblTenderBidOpenSign.setCreatedBy(userDetailId);
	            					tblTenderBidOpenSignList.add(tblTenderBidOpenSign);
	            					
	            					JSONArray jsonArray = new JSONArray(tblTenderBidMatrix.getBidJson());
	            					for (int i = 0; i < jsonArray.length(); i++) {
	            						JSONObject jSONObject = jsonArray.getJSONObject(i);
	            						for (Iterator it = jSONObject.keys(); it.hasNext();) {
	            							String key = it.next().toString();
	            							String[] keyValues = key.split("_");
	            							String jsonValue = jSONObject.getString(key);
	            							
	            							TblTenderBidDetail tblTenderBidDetail = new TblTenderBidDetail();
	            							tblTenderBidDetail.setTblTenderBidMatrix(tblTenderBidMatrix);
	            							tblTenderBidDetail.setTblTenderCell(new TblTenderCell(Integer.parseInt(keyValues[0])));
	            							tblTenderBidDetail.setCellNo(Integer.parseInt(keyValues[1]));
	            							tblTenderBidDetail.setCellValue(jsonValue);
	            							tblTenderBidDetailList.add(tblTenderBidDetail);
	                                    }
	            					}
	            				}
	            			}
	            		}
	            		success = tenderFormService.addBidderAprvalDtls(tblBidderApprovalDtls,tblTenderOpenList, tblTenderBidOpenSignList, tblTenderBidDetailList);
	        		}
	          	}/*** End Code to entry in addTenderBidOpenDetails for multiple envelop and in pki case**/
	          	else
	          	{
	          		/*** Start Code to insert in TblBidderApprovalDetail table and insert in history table**/
	          		success = tenderFormService.addBidderAprvalDtls(tblBidderApprovalDtls);
	          	}
	          	/*if(success && isEvaluationCompleted(tenderId)){ 
	          		Generate system generate Weightage L1 Report
	        		List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isWeightageEvaluationRequired,isItemwiseWinner");
	           		int isWeightageEvaluationRequired = 0;
	           		if(tenderDetails!= null && !tenderDetails.isEmpty()){
	           			isWeightageEvaluationRequired =Integer.parseInt(tenderDetails.get(0)[0].toString());
	           		}
	           		if(isWeightageEvaluationRequired == 1){
	           			TblDynReport tblDynReport  = dynamicReportService.getDynReportById(tenderId,5);
	           			if(tblDynReport!=null)
	           				dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(),tenderId,abcUtility.getSessionUserId(request));
	           		}
	        	}*/
	          	if(success){
	          		// When all envelopes are evaluated then update tender status to completed.
	           	    List<Object[]>	obj= tenderFormService.getAllEnvelopWiseEvaluationDone(tenderId);
	           	    if(obj != null && obj.get(0)[0].equals(obj.get(0)[1])){
          				eventCreationService.updateTenderEvalutionStatus(tenderId, TENDER_COMPLETED_STATUS);
          				
          				/*Generate system generate Weightage L1 Report*/
    	        		List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isWeightageEvaluationRequired,isItemwiseWinner");
    	           		int isWeightageEvaluationRequired = 0;
    	           		if(tenderDetails!= null && !tenderDetails.isEmpty()){
    	           			isWeightageEvaluationRequired =Integer.parseInt(tenderDetails.get(0)[0].toString());
    	           		}
    	           		if(isWeightageEvaluationRequired == 1){
    	           			TblDynReport tblDynReport  = dynamicReportService.getDynReportById(tenderId,5);
    	           			if(tblDynReport!=null)
    	           				dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(),tenderId,abcUtility.getSessionUserId(request));
    	           		}
              		}
	          		
	          		TblTenderEnvelope tbltenderEnvelope = tenderFormService.getTblTenderEnvelopeByTenderIdSortOrder(tenderId,sortOrder+1);
	           		if(tbltenderEnvelope!=null){
		           		List<Integer> reportIdLst = new ArrayList<Integer>();
		           		List<TblDynReport> dynReports = dynamicReportService.getDynReport(tenderId);
	         			 if(dynReports!=null && !dynReports.isEmpty()){
	  	                         for (TblDynReport tblDynReport : dynReports) {
	  	                        	 if(tblDynReport.getReportOn()==1 || tblDynReport.getReportOn()==2 ){
	  	                        		 reportIdLst.add(tblDynReport.getReportId());
	  	                        	 }
	  							 }
	                    }
	         			boolean deleteSuccess =  dynamicReportService.deleteTblDynReportCellId(reportIdLst);
	         			Map<String,Object> dynamicReport = dynamicReportService.getDynamicL1H1Report(Integer.parseInt(reportIdLst.get(0).toString()),tenderId,abcUtility.getSessionUserId(request));
	           		}
	          	}
	          	if(envlopTypFlg == 2 && success)
	          	{
	          		List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isNextEnvOpeningDateAuto,nextEnvOpeningDateSetAfter");
	           		int isNextEnvOpeningDateAuto = 0;
	           		int nextEnvOpeningDateSetAfter = 0;
	           		if(tenderDetails!= null && !tenderDetails.isEmpty()){
	           			isNextEnvOpeningDateAuto =Integer.parseInt(tenderDetails.get(0)[0].toString());
	           			nextEnvOpeningDateSetAfter = Integer.parseInt(tenderDetails.get(0)[1].toString());
	           		}
	           		if(isNextEnvOpeningDateAuto == 1){
		          		 List<Object> lstEvaluationDateAndTime =eventCreationService.getOfficerEvaluationDateAndTime(tenderId,envelopeId);
		          		List<Object[]>  envlist = tenderFormService.getTenderEnvelopeList(tenderId);
		          		int nextEnvId = 0;
		          		String nextOpeningDate = "";
		          		if(envlist!=null && !envlist.isEmpty()){
		          			for(Object[] envlst  :envlist){
		          				if(Integer.parseInt(envlst[3].toString())==0){
		          					nextEnvId = Integer.parseInt(envlst[2].toString());
		          					break;
		          				}
		          			}
		          		}
		          		if(lstEvaluationDateAndTime!=null && !lstEvaluationDateAndTime.isEmpty() && nextEnvId!=0){
		          			Date approveddate = (Date) lstEvaluationDateAndTime.get(0);
		             	    Calendar cal = 	Calendar.getInstance();
		             		cal.setTime(approveddate);
		             		cal.add(Calendar.MINUTE,nextEnvOpeningDateSetAfter);
		             		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		             		nextOpeningDate = sdf.format(cal.getTime());
		             		success=tenderOpenService.updatePriceBidOpeningDate(tenderId,nextEnvId,nextOpeningDate);
		          		}
		          		 
	           		}
	          	}
	          			
	          		/*** Start Code to send email by services**/
	          		if(success){
	          			Map<String, Object> approveEvaluteBidderMap = new HashMap<String, Object>();
	          			String ccmail="";
	          			if(Integer.parseInt(bobClientId) == abcUtility.getSessionClientId(request)){
	          				int officerId =  (Integer) tenderCommonService.getTenderField(tenderId, "officerId");
	          				ccmail= commonService.getEmailByUserId(officerId);
	          			}
	          			approveEvaluteBidderMap.put("tenderId",tenderId);
	          			approveEvaluteBidderMap.put("tenderNo",tenderCommonService.getTenderField(tenderId, "tenderNo"));
	          			approveEvaluteBidderMap.put("EvaluationType", "accepted"); 	  		
	          			approveEvaluteBidderMap.put("EventType", eventType);	    		
	          			approveEvaluteBidderMap.put("SubDomainName",clientService.getClientNameByClientId(abcUtility.getSessionClientId(request)));
          				if(ccmail!=null && ccmail.length()>0)
          					approveEvaluteBidderMap.put("cc",ccmail);
	          			String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/biddingtenderdashboard/"+tenderId+"/7");
	          			String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
	          			approveEvaluteBidderMap.put("link", hrefStr);
	                         
	    				mailContentUtillity.dynamicMailGeneration("48", String.valueOf(0), String.valueOf(envelopeId),approveEvaluteBidderMap ,"");
	    				
	    				Map<String, Object> unApproveEvaluteBidderMap = new HashMap<String, Object>();
	    				unApproveEvaluteBidderMap.put("tenderId",tenderId);
	    				unApproveEvaluteBidderMap.put("tenderNo",tenderCommonService.getTenderField(tenderId, "tenderNo"));
	    				unApproveEvaluteBidderMap.put("EvaluationType", "rejected"); 	  		
	    				unApproveEvaluteBidderMap.put("EventType", eventType);	    		
	    				unApproveEvaluteBidderMap.put("SubDomainName",clientService.getClientNameByClientId(abcUtility.getSessionClientId(request)));
	    				unApproveEvaluteBidderMap.put("link", hrefStr);
          				if(ccmail!=null && ccmail.length()>0)
          					unApproveEvaluteBidderMap.put("cc",ccmail);
	                  	mailContentUtillity.dynamicMailGeneration("49", String.valueOf(0), String.valueOf(envelopeId),unApproveEvaluteBidderMap ,"");
	          		}
	          	}else if(reevalsucess){
		          		retVal=TENDER_DASHBOARD_URL+tenderId+"/"+TAB_EVALUATE_BID;
		         		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
		         		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_success_evaluate_bidders_status_add");
		                return retVal;
	          	}
        	} 		
          		
         }catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), evaluationEvaluateLinkId, success ? evaluatebiddersstatusadd : evaluatebiddersstatusaddfail,tenderId,envelopeId);
         }
         retVal=success?TENDER_DASHBOARD_URL+tenderId+"/"+TAB_EVALUATE_BID:"/etender/buyer/evaluatebidders/"+tenderId+"/"+envelopeId+"/"+1+"/"+envlopTypFlg+"/"+sortOrder+"/"+preEnvelopeId+"/"+isView;
  		 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
  		 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() :  CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_evaluate_bidders_status_add" : reevalsucess==false ? "msg_reevaluate_evaluation_not_allowed" : CommonKeywords.ERROR_MSG_KEY.toString());
         return retVal;
     }
     /**
  	 * Use to update Evaluate bidders Status 
  	 * @author krunal.patel
  	 * @param request
  	 * @param ModelMap
  	 * @throws Exception
  	 * @return
  	 */
     @RequestMapping(value = "/buyer/updateevlutbiderstatus", method = RequestMethod.POST)
     public String updateEvlutBiderStatus(RedirectAttributes redirectAttributes, HttpServletRequest request) {
     	boolean success=true;
     	String retVal=REDIRECT_SESSION_EXPIRED;
        int tenderId=0;
        int envelopeId=0;
        int preEnvelopeId=0;
        int sortOrder=0;
        int apoExist = 0;
        int envlopTypFlg=0;
        String errMsg = CommonKeywords.ERROR_MSG_KEY.toString();
        String formIds="";
         try{
        	 int sessionUserId = abcUtility.getSessionUserId(request);
         	if(sessionUserId!=0){
        	 tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;  
             envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")):0;	 
        	 int hdRowCount = StringUtils.hasLength(request.getParameter("hdRowCount")) ? Integer.parseInt(request.getParameter("hdRowCount")):0;
        	 String eventType=StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
        	 int hdReevaluate = StringUtils.hasLength(request.getParameter("hdReevaluateProcess")) ? Integer.parseInt(request.getParameter("hdReevaluateProcess")):0;
        	 preEnvelopeId = StringUtils.hasLength(request.getParameter("hdpreEnvelopeId")) ? Integer.parseInt(request.getParameter("hdpreEnvelopeId")):0;	 
        	 sortOrder = StringUtils.hasLength(request.getParameter("hdsortOrder")) ? Integer.parseInt(request.getParameter("hdsortOrder")):0;	 
        	 envlopTypFlg=StringUtils.hasLength(request.getParameter("hdEnvlopTypFlg")) ? Integer.parseInt(request.getParameter("hdEnvlopTypFlg")):0;
        	 formIds = StringUtils.hasLength(request.getParameter("hdFormIds")) ? request.getParameter("hdFormIds") : "";
        	 String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
        	 int tenderReEvalId = 0;
        		int isReEvaluationReq = 0;
	          	isReEvaluationReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isReEvaluationReq").toString());
	          	if( isReEvaluationReq==1 ){
	          		Integer[] ctatus={0};
	          		List<TblTenderReevaluation> tblTenderreevaluation = tenderFormService.getTblTenderRevaluationStatusByEnvelopeId(tenderId,envelopeId, ctatus);
	          		if(tblTenderreevaluation!=null && !tblTenderreevaluation.isEmpty() ){
	          			tenderReEvalId=tblTenderreevaluation.get(0).getTenderReEvalId();
	          		}
	          	} 
        	TblBidderApprovalDetail tblBidderApprovalDetail=null;
          	List<TblBidderApprovalDetail> tblBidderApprovalDtls=new ArrayList<TblBidderApprovalDetail>();
          	 List<Object[]> listCMS=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
 			
	            if (listCMS != null) {
	                for (int i = 0; i < listCMS.size(); i++) {
	                	if(listCMS.get(i)[0].toString().equalsIgnoreCase("12") ||listCMS.get(i)[0].toString().equalsIgnoreCase("13")){
	                		apoExist=1;                		 
	                    }
	                }
	            }
	            if(apoExist==1){
	            	TblAdvancePurchaseOrder tblAdvancepurchaseorder = commonService.getTblAdvancePurchaseOrderByObject(tenderId);
	            	if(tblAdvancepurchaseorder!=null){
	            		success=false;
	            		errMsg = "msg_apo_already_created_reevaluation";
	            	}
	            	TblPurchaseOrder tblpurchaseorder = commonService.getTblPurchaseOrderByObject(tenderId);
	            	if(tblpurchaseorder!=null){
	            		success=false;
	            		errMsg = "msg_apo_already_created_reevaluation";
	            	}
	            }
	            if(success){
		          	isReEvaluationReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isReEvaluationReq").toString());
		          	if( isReEvaluationReq==1 ){
		          		Integer[] ctatus={0};
		          		List<TblTenderReevaluation> tblTenderreevaluation = tenderFormService.getTblTenderEnvelopeRevaluationStatusByTenderId(tenderId, ctatus);
		          		if(tblTenderreevaluation!=null && !tblTenderreevaluation.isEmpty() ){
		          			success=true;
		          		}else{
		          			success=false;
		          			errMsg = "msg_reevaluate_evaluation_already_completed";
		          		}
		          	}
	            }
	          	
          	 int userDetailId = abcUtility.getSessionUserDetailId(request);
          	 int bidderAprvYesNo=0;
          	List<TblCompany> companyIds = new ArrayList<TblCompany>();
          	for(int i=0;i<hdRowCount;i++){
      			bidderAprvYesNo = StringUtils.hasLength(request.getParameter("rdBidderAprvYesNo_"+i)) ? Integer.parseInt(request.getParameter("rdBidderAprvYesNo_"+i)):0;
      			String remarks = StringUtils.hasLength(request.getParameter("txtaRemarks_"+i)) ? request.getParameter("txtaRemarks_"+i):null;
      			String allBidderVal = StringUtils.hasLength(request.getParameter("hdAllValues_"+i)) ? request.getParameter("hdAllValues_"+i):null;
      			
      				
      					String[] singleBidderVal = allBidderVal.split("\\|~~~\\|");
      						if(singleBidderVal != null){
      							for(int j=0;j<singleBidderVal.length;j++){
      								String[] singleBidderIds = singleBidderVal[j].split("\\|~\\|");
      								if(singleBidderVal != null){
      									
      									tblBidderApprovalDetail = new TblBidderApprovalDetail();
                              			tblBidderApprovalDetail.setTblTender(new TblTender(tenderId));
                                      	tblBidderApprovalDetail.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
                                      	tblBidderApprovalDetail.setTblCompany(new TblCompany(Integer.parseInt(singleBidderIds[1])));
                                      	tblBidderApprovalDetail.setTblUserLogin(new TblUserLogin(Integer.parseInt(singleBidderIds[2])));
                                      	tblBidderApprovalDetail.setTblUserDetail(new TblUserDetail(Integer.parseInt(singleBidderIds[3])));
                                      	tblBidderApprovalDetail.setTblFinalSubmission(new TblFinalSubmission(Integer.parseInt(singleBidderIds[0])));
                                      	if(bidderAprvYesNo==0 && remarks==null){
                                      		tblBidderApprovalDetail.setRemarks("");
                                      		tblBidderApprovalDetail.setIsApproved(3);
                                      	}else{
                                      		tblBidderApprovalDetail.setRemarks(remarks);
                                      		tblBidderApprovalDetail.setIsApproved(bidderAprvYesNo);
                                      		if(bidderAprvYesNo==0 && envlopTypFlg==2 && tenderReEvalId!=0){
                                      			List<Object> listOfNextEnvelopeIds = tenderCommonService.getListOfNextEnvelopeIds(tenderId,sortOrder);
                                      			if(listOfNextEnvelopeIds!=null && !listOfNextEnvelopeIds.isEmpty()){
                                      			for(Object nextEnvelopeId : listOfNextEnvelopeIds){
                                      			tenderOpenService.deleteRejectedBidder(tenderId,Integer.parseInt(nextEnvelopeId.toString()),Integer.parseInt(singleBidderIds[2]));
                                      			 }
                                      		    }
                                      		}
                                      	}
                                      	tblBidderApprovalDetail.setCreatedBy(userDetailId);
                                      	companyIds.add(new TblCompany(Integer.parseInt(singleBidderIds[1])));
                                      	
                                      	tblBidderApprovalDtls.add(tblBidderApprovalDetail);	
      								}
      							}		
      						}
          			}
          	
          	if(envlopTypFlg == 2 && !formIds.equals("0")){
          		String[] strArray = formIds.split(",");
	          	List<TblTenderForm> tblTenderFormList = new ArrayList<TblTenderForm>();
	          	for(int i = 0; i < strArray.length; i++) {
	          		tblTenderFormList.add(new TblTenderForm(Integer.parseInt(strArray[i])));
	          	}
	          	
        		List<TblTenderBid> tblTenderBidList = eventBidSubmissionService.getTenderBid(tenderId, companyIds.toArray(),tblTenderFormList.toArray());
        		if(tblTenderBidList != null && !tblTenderBidList.isEmpty()){
        			List<TblTenderOpen> tblTenderOpenList = new ArrayList<TblTenderOpen>();
        			List<TblTenderBidOpenSign> tblTenderBidOpenSignList = new ArrayList<TblTenderBidOpenSign>();
        			List<TblTenderBidDetail> tblTenderBidDetailList = new ArrayList<TblTenderBidDetail>();
        			List<String> userFormIds = new ArrayList<String>();
        			
            		for(TblTenderBid tblTenderBid : tblTenderBidList){
            			String userFormId = tblTenderBid.getTblTenderForm().getFormId() + "~" + tblTenderBid.getTblCompany().getCompanyId(); 
            			
            			if(!userFormIds.contains(userFormId)){
            				List<TblTenderOpen> tbltenderopen = tenderOpenService.getTenderOpenDetailBidderEnvelope(tblTenderBid.getTblTender().getTenderId(),tblTenderBid.getTblCompany().getCompanyId(),tblTenderBid.getTblTenderEnvelope().getEnvelopeId());
            				if(tbltenderopen.isEmpty()){
		            			TblTenderOpen tblTenderOpen = new TblTenderOpen();
		            			tblTenderOpen.setTblTender(tblTenderBid.getTblTender());
		            			tblTenderOpen.setTblTenderEnvelope(tblTenderBid.getTblTenderEnvelope());
		            			tblTenderOpen.setTblTenderForm(tblTenderBid.getTblTenderForm());
		            			tblTenderOpen.setTblCompany(tblTenderBid.getTblCompany());
		            			tblTenderOpen.setTblUserLogin(tblTenderBid.getTblUserLogin());
		            			tblTenderOpen.setDecryptionLevel(1);
		            			tblTenderOpen.setIpAddress(ipAddress);
		            			tblTenderOpen.setCreatedBy(userDetailId);
		            			tblTenderOpenList.add(tblTenderOpen);
            			}
            			}
            			
            			List<TblTenderBidMatrix> tblTenderBidMatrixList = eventBidSubmissionService.getTableBidMatrix(tblTenderBid.getBidId());
            			
            			if(tblTenderBidMatrixList != null && !tblTenderBidMatrixList.isEmpty()){
            				for(TblTenderBidMatrix tblTenderBidMatrix : tblTenderBidMatrixList){
            					List<TblTenderBidOpenSign> tbltenderBidOpenSign = tenderOpenService.getTenderBidOpenSign(tblTenderBidMatrix.getBidTableId());
	            				if(tbltenderBidOpenSign.isEmpty()){
	            					TblTenderBidOpenSign tblTenderBidOpenSign = new TblTenderBidOpenSign();
	            					tblTenderBidOpenSign.setTblTenderBidMatrix(tblTenderBidMatrix);
	            					tblTenderBidOpenSign.setDecryptedBid(tblTenderBidMatrix.getBidJson());
	            					tblTenderBidOpenSign.setBidSignText(tblTenderBidMatrix.getBidJson());
	            					tblTenderBidOpenSign.setCreatedBy(userDetailId);
	            					tblTenderBidOpenSignList.add(tblTenderBidOpenSign);
	            					
	            					JSONArray jsonArray = new JSONArray(tblTenderBidMatrix.getBidJson());
	            					for (int i = 0; i < jsonArray.length(); i++) {
	            						JSONObject jSONObject = jsonArray.getJSONObject(i);
	            						for (Iterator it = jSONObject.keys(); it.hasNext();) {
	            							String key = it.next().toString();
	            							String[] keyValues = key.split("_");
	            							String jsonValue = jSONObject.getString(key);
	            							List<TblTenderBidDetail> tblTenderBidDetails = tenderOpenService.getTenderBidDetails(tblTenderBidMatrix.getBidTableId());
	    		            				if(tblTenderBidDetails.isEmpty()){
		            							TblTenderBidDetail tblTenderBidDetail = new TblTenderBidDetail();
		            							tblTenderBidDetail.setTblTenderBidMatrix(tblTenderBidMatrix);
		            							tblTenderBidDetail.setTblTenderCell(new TblTenderCell(Integer.parseInt(keyValues[0])));
		            							tblTenderBidDetail.setCellNo(Integer.parseInt(keyValues[1]));
		            							tblTenderBidDetail.setCellValue(jsonValue);
		            							tblTenderBidDetailList.add(tblTenderBidDetail);
	    		            				}
	                                    }
	            					}
	            				}
            				}
            			}
            		}
            		success = tenderFormService.updateBidderAprvalDtlsForReevaluation(envelopeId, tblBidderApprovalDtls,tenderReEvalId,tblTenderOpenList, tblTenderBidOpenSignList, tblTenderBidDetailList);
        		}
          		} /*** End Code to entry in addTenderBidOpenDetails for multiple envelop and in pki case**/
          		else if(success){ /*** Start Code to insert in TblBidderApprovalDetail table and old record delete and insert in history table**/
		          		success = tenderFormService.updateBidderAprvalDtls(envelopeId, tblBidderApprovalDtls,tenderReEvalId);
		          	}
          		/*** Start Code to send email by services**/
          		if(success){
          			tenderFormService.updateTenderReEvaluation(envelopeId, tenderId);
          			
          			Integer[] ctatus={0};
              		List<TblTenderReevaluation> getTblTenderReevaluation = tenderFormService.getTblTenderEnvelopeRevaluationStatusByTenderId(tenderId, ctatus);
              		
              		//Update tender status to completed when reevaluation is completed for all envelope.
          			List<Object[]>	obj= tenderFormService.getAllEnvelopWiseEvaluationDone(tenderId);
          			if(obj != null && obj.get(0)[0].equals(obj.get(0)[1])){
          				eventCreationService.updateTenderEvalutionStatus(tenderId, TENDER_COMPLETED_STATUS);
          				
          				if(getTblTenderReevaluation.isEmpty()){
          					/*Generate system generate Weightage L1 Report*/
        	        		List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isWeightageEvaluationRequired,isItemwiseWinner");
        	           		int isWeightageEvaluationRequired = 0;
        	           		if(tenderDetails!= null && !tenderDetails.isEmpty()){
        	           			isWeightageEvaluationRequired =Integer.parseInt(tenderDetails.get(0)[0].toString());
        	           		}
        	           		if(isWeightageEvaluationRequired == 1){
    	    	           			TblDynReport tblDynReport  = dynamicReportService.getDynReportById(tenderId,5);
    	    	           			if(tblDynReport!=null)
    	    	           			{
    	    	           				List<Integer> reportIdLst = new ArrayList<Integer>();
    	    	           				reportIdLst.add(tblDynReport.getReportId());
    	    	           			   dynamicReportService.deleteTblDynReportCellId(reportIdLst);
    	    	           				dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(),tenderId,abcUtility.getSessionUserId(request));
    	    	           			}
    	    	           	}
          				}
          			}
              		
              	  /*  if(getTblTenderReevaluation.isEmpty() && isEvaluationDone(tenderId)){
          				Generate system generate Weightage L1 Report
    	        		List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isWeightageEvaluationRequired,isItemwiseWinner");
    	           		int isWeightageEvaluationRequired = 0;
    	           		if(tenderDetails!= null && !tenderDetails.isEmpty()){
    	           			isWeightageEvaluationRequired =Integer.parseInt(tenderDetails.get(0)[0].toString());
    	           		}
    	           		if(isWeightageEvaluationRequired == 1){
	    	           			TblDynReport tblDynReport  = dynamicReportService.getDynReportById(tenderId,5);
	    	           			if(tblDynReport!=null)
	    	           			{
	    	           				List<Integer> reportIdLst = new ArrayList<Integer>();
	    	           				reportIdLst.add(tblDynReport.getReportId());
	    	           			   dynamicReportService.deleteTblDynReportCellId(reportIdLst);
	    	           				dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(),tenderId,abcUtility.getSessionUserId(request));
	    	           			}
	    	           	}
      				
          			}*/
              		
              			
          				Map<String, Object> evaluteBidderMap = new HashMap<String, Object>();
    					evaluteBidderMap.put("tenderId",tenderId);
    					evaluteBidderMap.put("tenderNo",tenderCommonService.getTenderField(tenderId, "tenderNo"));
    					evaluteBidderMap.put("EvaluationType", bidderAprvYesNo==1?"accepted":"rejected"); 	  		
    					evaluteBidderMap.put("EventType", eventType);   
    					evaluteBidderMap.put("SubDomainName",clientService.getClientNameByClientId(abcUtility.getSessionClientId(request)));

        	  			 String encryptUrlStr = encryptDecryptUtils.encrypt("etender/buyer/tenderdashboard/"+tenderId+"/7");
                         String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                         evaluteBidderMap.put("link", hrefStr);
                         
                         if(Integer.parseInt(bobClientId) == abcUtility.getSessionClientId(request)){
 	          				int officerId =  (Integer) tenderCommonService.getTenderField(tenderId, "officerId");
 	          				evaluteBidderMap.put("cc",commonService.getEmailByUserId(officerId));
 	          			}
                  		mailContentUtillity.dynamicMailGeneration("48", String.valueOf(0), String.valueOf(envelopeId),evaluteBidderMap ,"");
                  		mailContentUtillity.dynamicMailGeneration("49", String.valueOf(0), String.valueOf(envelopeId),evaluteBidderMap ,"");
                  		boolean deleteSuccess= false;
                  		TblTenderEnvelope tbltenderEnvelope = tenderFormService.getTblTenderEnvelopeByTenderIdSortOrder(tenderId,sortOrder+1);
                  		TblTenderEnvelope tbltenderenv =  tenderFormService.getTblTenderEnvelopeByTenderIdAndEnvelopeId(tenderId,envelopeId);
                  		List<Integer> reportIdLst = new ArrayList<Integer>();
                  		if(tbltenderenv==null){
	                  		boolean isManualReportsConfig = tenderReportService.isManualReportsConfig(tenderId);
	        				if(isManualReportsConfig){
	        					boolean isReportExits = tenderReportService.isOverRuleReportExits(tenderId,1);
	        					if(isReportExits){
	        						deleteSuccess =  tenderReportService.updateOverRuledReportinReevaluation(tenderId,0);
	        					}
	        				}
                  		}
                  		if(tbltenderEnvelope!=null ){
                  		   boolean isPriceBidOpen = tenderCommonService.isPriceBidOpen(tenderId);
                           if(isPriceBidOpen){	//Decryption is pending for approved bidder or if not evaluation done then still decryption is pending for TenderOpen table (0,1 case)
                           	isPriceBidOpen = dynamicReportService.checkIsDecryptedAllApprovedBidderByTenderId(tenderId);
                           }
                  			if((envlopTypFlg==1) || envlopTypFlg == 2){
	                     		if(hdReevaluate==1){
	                     			List<TblDynReport> dynReports = dynamicReportService.getDynReport(tenderId);
	                     			int isNegotiationClosed=  negotiationService.isNegotiationClosed(tenderId,negotiation_negotiation_process_invite_for_negotiation);
	                     			 if(dynReports!=null && !dynReports.isEmpty()){
	       	   	                         for (TblDynReport tblDynReport : dynReports) {
	       	   	                        	 if(tblDynReport.getReportOn()==1 || tblDynReport.getReportOn()==2 || tblDynReport.getReportOn()==6){
	       	   	                        		 reportIdLst.add(tblDynReport.getReportId());
	       	   	                        	 }
	       	   	                        	 if(isNegotiationClosed==1 && (tblDynReport.getReportOn()==3 || tblDynReport.getReportOn()==4)){
	       	   	                        		reportIdLst.add(tblDynReport.getReportId());
	       	   	                        	 }
	       	   							 }
	                                }
	                     			deleteSuccess =  dynamicReportService.deleteTblDynReportCellId(reportIdLst);
	                     			if(isNegotiationClosed==1){
	                     				negotiationService.updateNegotiationProcessNotRequired(tenderId, inviteBidderForNegotiationLinkIdTender,1);
	                     				negotiationService.deleteNegotiationProcess(tenderId,inviteBidderForNegotiationLinkIdTender,0);
	                     				negotiationService.deleteNegotiationResult(tenderId);
	                     			}
	                     			
	                     		}
                  			}
                  		}
          		}
         	}
          		
         }catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), evaluationReEvaluateLinkId, success ? reevaluatebiddersstatusupdate : reevaluatebiddersstatusupdatefail,tenderId,envelopeId);
         }
         retVal=success?TENDER_DASHBOARD_URL+tenderId+"/"+TAB_EVALUATE_BID:"/etender/buyer/evaluatebidders/"+tenderId+"/"+envelopeId+"/"+2+"/"+envlopTypFlg+"/"+sortOrder+"/"+preEnvelopeId+"/"+false;
  		 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
  		 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_evaluate_bidders_status_update" : errMsg);
         return retVal;
     }
     /**
      * to append array
      * @param array
      * @param element
      * @return array
      */
     private  String[] append(String[] arr, String element) {
	    int N = arr.length;
	    arr = Arrays.copyOf(arr, N + 1);
	    arr[N] = element;
	    return arr;
    }
     
     /**
      * to get create governing column page
      * @param tenderId
      * @param modelMap
      * @param request
      * @return
      */
     @RequestMapping(value = "/buyer/creategovcolumn/{tenderId}/{enc}", method = RequestMethod.GET)
     public String createGovColumn(@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request) {
         try {
        	 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	 int tenderResult=modelMap.get("tenderResult")!=null ? Integer.parseInt(modelMap.get("tenderResult").toString()) : -1;
        	 int formId=0;
        	 int tableId=0;
        	 boolean isFirst=true;
        	 List<TenderGoverningColumnDtBean> tenderGoverningColumnDtBeanList=new ArrayList<TenderGoverningColumnDtBean>();
        	 List<Object[]> data=null;
        	 //tenderResult=1;
        	 if(tenderResult == 1 || tenderResult == 3){
        		data=tenderFormService.getTenderGovCols(tenderId);
        	 }else{
        		 data=tenderFormService.getTenderGovColsItemWise(tenderId);
        	 }
        	 modelMap.addAttribute("tenderResult", tenderResult);
    		 TenderGoverningColumnDtBean tenderGoverningColumnDtBean=new TenderGoverningColumnDtBean();
    		 List<String> tableName=new ArrayList<String>();
    		 List<List<SelectItem>> govCols=new ArrayList<List<SelectItem>>();
    		 List<SelectItem> selectItemList=new ArrayList<SelectItem>();
    		 if(data != null && !data.isEmpty()){
    			 for(int i=0;i<data.size();i++){
    				 int tempFormId=Integer.parseInt(data.get(i)[3].toString());
    				 int tempTableId=Integer.parseInt(data.get(i)[4].toString());
    				 if(formId !=tempFormId){
    					 formId=tempFormId;
    					 if(i!=0){
    						 if(isFirst){
    							 govCols.add(selectItemList);
    							 selectItemList=new ArrayList<SelectItem>();
    							 isFirst=false;
    						 }
    						 tenderGoverningColumnDtBean.setGovCols(govCols);
    						 tenderGoverningColumnDtBean.setTableName(tableName);
    						 tenderGoverningColumnDtBeanList.add(tenderGoverningColumnDtBean);
    						 tenderGoverningColumnDtBean=new TenderGoverningColumnDtBean();
    						 tableName=new ArrayList<String>();
    						 govCols=new ArrayList<List<SelectItem>>();
    					 }
    					 tenderGoverningColumnDtBean.setFormId(data.get(i)[3].toString());
    					 tenderGoverningColumnDtBean.setFormName(data.get(i)[0].toString());
    				 }
    				 if(formId == tempFormId && tempTableId !=tableId){
    					 tableName.add(data.get(i)[1].toString());
    				 }
    				 if(tempTableId !=tableId){
    					 tableId=tempTableId;
    					 if(i!=0){
    						 if(!selectItemList.isEmpty()){
    							 govCols.add(selectItemList);
    							 isFirst=true;
    							 selectItemList=new ArrayList<SelectItem>();
    						 }else{
    							 isFirst=true;
    						 }
    					 }
    					 selectItemList.add(new SelectItem(data.get(i)[2], data.get(i)[3].toString()+","+data.get(i)[4].toString()+","+data.get(i)[5].toString()+","+data.get(i)[6].toString()+","+data.get(i)[7].toString()));
    				 }else{
    					 selectItemList.add(new SelectItem(data.get(i)[2], data.get(i)[3].toString()+","+data.get(i)[4].toString()+","+data.get(i)[5].toString()+","+data.get(i)[6].toString()+","+data.get(i)[7].toString())); 
    				 }
    				 if(i==data.size()-1){
    					 govCols.add(selectItemList);
    					 tenderGoverningColumnDtBean.setGovCols(govCols);
						 tenderGoverningColumnDtBean.setTableName(tableName);
						 tenderGoverningColumnDtBeanList.add(tenderGoverningColumnDtBean);
        			 }
    			 }
    		 }
        	 modelMap.addAttribute("tenderGoverningColumnDtBeanList", tenderGoverningColumnDtBeanList);
         }catch(Exception e){
          	return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addGoverningColumnLinkId, getcreategovcolumn,tenderId,0);
          }
         return "/etender/buyer/CreateGovColumn";
     }
     
     
     /**
      * to add governing column
      * @param redirectAttributes
      * @param request
      * @return
      */
     @RequestMapping(value = "/buyer/addgovcolumn", method = RequestMethod.POST)
     public String addGovColumn(RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	 String retVal = "redirect:/sessionexpired";
    	 int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
    	 boolean success=false;
		 try {
			 int userId=abcUtility.getSessionUserId(request);
			 if(userId != 0){
				 String[] formId=request.getParameterValues("isSelect");
				 if(formId==null || formId.length == 0){
					 retVal="redirect:/etender/buyer/creategovcolumn/"+tenderId+encryptDecryptUtils.generateRedirect("etender/buyer/creategovcolumn/"+tenderId, request);
				 }else{
					 //List<String> dataList=new ArrayList<String>();
					 TblTenderGovColumn tblTenderGovColumn=null;
					 List<TblTenderGovColumn> tblTenderGovColumnList=new ArrayList<TblTenderGovColumn>();
					 for(String data:formId){
						 String[] tempArray=request.getParameterValues("selGovCols_"+data);
						 for(String tempString : tempArray){
							 String[] tempSplitString=tempString.split(",");
							 tblTenderGovColumn=new TblTenderGovColumn();
							 tblTenderGovColumn.setCellId(Integer.parseInt(tempSplitString[4]));
							 tblTenderGovColumn.setColumnNo(Integer.parseInt(tempSplitString[3]));
							 tblTenderGovColumn.setTblTenderColumn(new TblTenderColumn(Integer.parseInt(tempSplitString[2])));
							 tblTenderGovColumn.setTblTenderForm(new TblTenderForm(Integer.parseInt(tempSplitString[0])));
							 tblTenderGovColumn.setTblTenderTable(new TblTenderTable(Integer.parseInt(tempSplitString[1])));
							 tblTenderGovColumn.setIpAddress(request.getLocalAddr());
							 tblTenderGovColumn.setTblTender(new TblTender(tenderId));
							 tblTenderGovColumnList.add(tblTenderGovColumn);
						 }
					 }
					 success=tenderFormService.addGovColumns(tblTenderGovColumnList);
					 if(success){
	           		  retVal="redirect:/etender/buyer/tenderdashboard/"+tenderId+"/2"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/2", request);
	           	    }else{
	           	    	retVal="redirect:/etender/buyer/creategovcolumn/"+tenderId+encryptDecryptUtils.generateRedirect("etender/buyer/creategovcolumn/"+tenderId, request);
	           	    }
				 }
				 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_addgovcolumn" : CommonKeywords.ERROR_MSG_KEY.toString());
			 }
		 }catch(Exception e){
			 retVal= exceptionHandlerService.writeLog(e);
	      }finally {
	           auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addGoverningColumnLinkId, postaddgovcolumn,tenderId,0);
	      }
	      return retVal;
      }

     /**
      * to edit governing column
      * @param tenderId
      * @param modelMap
      * @param request
      * @return
      */
     @RequestMapping(value = "/buyer/editgovcolumn/{tenderId}/{enc}", method = RequestMethod.GET)
     public String editGovColumn(@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request) {
         try {
        	 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	 int tenderResult=modelMap.get("tenderResult")!=null ? Integer.parseInt(modelMap.get("tenderResult").toString()) : -1;
        	 int formId=0;
        	 int tableId=0;
        	 boolean isFirst=true;
        	 List<TenderGoverningColumnDtBean> tenderGoverningColumnDtBeanList=new ArrayList<TenderGoverningColumnDtBean>();
        	 List<Object[]> data=null;
        	 //tenderResult=1;
        	 if(tenderResult == 1 || tenderResult == 3){
        		data=tenderFormService.getTenderGovCols(tenderId);
        	 }else{
        		 data=tenderFormService.getTenderGovColsItemWise(tenderId);
        	 }
    		 TenderGoverningColumnDtBean tenderGoverningColumnDtBean=new TenderGoverningColumnDtBean();
    		 List<String> tableName=new ArrayList<String>();
    		 List<String> selectedValList=new ArrayList<String>();
    		 List<List<SelectItem>> govCols=new ArrayList<List<SelectItem>>();
    		 List<SelectItem> selectItemList=new ArrayList<SelectItem>();
    		 if(data != null && !data.isEmpty()){
    			 for(int i=0;i<data.size();i++){
    				 int tempFormId=Integer.parseInt(data.get(i)[3].toString());
    				 int tempTableId=Integer.parseInt(data.get(i)[4].toString());
    				 if(formId !=tempFormId){
    					 formId=tempFormId;
    					 if(i!=0){
    						 if(isFirst){
    							 govCols.add(selectItemList);
    							 selectItemList=new ArrayList<SelectItem>();
    							 isFirst=false;
    						 }
    						 tenderGoverningColumnDtBean.setGovCols(govCols);
    						 tenderGoverningColumnDtBean.setTableName(tableName);
    						 tenderGoverningColumnDtBean.setSelectedValList(selectedValList);
    						 tenderGoverningColumnDtBeanList.add(tenderGoverningColumnDtBean);
    						 tenderGoverningColumnDtBean=new TenderGoverningColumnDtBean();
    						 tableName=new ArrayList<String>();
    						 selectedValList=new ArrayList<String>();
    						 govCols=new ArrayList<List<SelectItem>>();
    					 }
    					 tenderGoverningColumnDtBean.setFormId(data.get(i)[3].toString());
    					 tenderGoverningColumnDtBean.setFormName(data.get(i)[0].toString());
    				 }
    				 if(formId == tempFormId && tempTableId !=tableId){
    					 tableName.add(data.get(i)[1].toString());
    				 }
    				 if(data.get(i)[8] != null && Integer.parseInt(data.get(i)[8].toString()) == Integer.parseInt(data.get(i)[5].toString())){
    					 selectedValList.add(data.get(i)[3].toString()+","+data.get(i)[4].toString()+","+data.get(i)[5].toString()+","+data.get(i)[6].toString()+","+data.get(i)[7].toString());
    				 }
    				 if(tempTableId !=tableId){
    					 tableId=tempTableId;
    					 if(i!=0){
    						 if(!selectItemList.isEmpty()){
    							 govCols.add(selectItemList);
    							 isFirst=true;
    							 selectItemList=new ArrayList<SelectItem>();
    						 }else{
    							 isFirst=true;
    						 }
    					 }
    					 selectItemList.add(new SelectItem(data.get(i)[2], data.get(i)[3].toString()+","+data.get(i)[4].toString()+","+data.get(i)[5].toString()+","+data.get(i)[6].toString()+","+data.get(i)[7].toString()));
    				 }else{
    					 selectItemList.add(new SelectItem(data.get(i)[2], data.get(i)[3].toString()+","+data.get(i)[4].toString()+","+data.get(i)[5].toString()+","+data.get(i)[6].toString()+","+data.get(i)[7].toString())); 
    				 }
    				 if(i==data.size()-1){
    					 govCols.add(selectItemList);
    					 tenderGoverningColumnDtBean.setGovCols(govCols);
    					 tenderGoverningColumnDtBean.setSelectedValList(selectedValList);
						 tenderGoverningColumnDtBean.setTableName(tableName);
						 tenderGoverningColumnDtBeanList.add(tenderGoverningColumnDtBean);
        			 }
    			 }
    		 }
    		 modelMap.addAttribute("oprType", "e");
    		 //Start Changes For Bug Id:26938 Item Wise Case
    		 if(tenderResult == 2){
	    		 for(TenderGoverningColumnDtBean tenderGoverningColumnDtBeans:tenderGoverningColumnDtBeanList){
	        		 if(tenderGoverningColumnDtBeans.getSelectedValList().size()!=tenderGoverningColumnDtBeans.getTableName().size()){
	        			 tenderGoverningColumnDtBeans.setSelectedValList(null);
	        		 }
	        	 }
    		 }
    		//End Changes For Bug Id:26938 Item Wise Case
    		 modelMap.addAttribute("tenderGoverningColumnDtBeanList", tenderGoverningColumnDtBeanList);
          }catch(Exception e){
          	return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editGoverningColumnLinkId, getEditGovColumn,tenderId,0);
          }
         return "/etender/buyer/CreateGovColumn";
     }
     
     @RequestMapping(value = "/buyer/editgovcolumn", method = RequestMethod.POST)
     public String editGovColumn(RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	 String retVal = "redirect:/sessionexpired";
    	 int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
    	 boolean success=false;
		 try {
			 int userId=abcUtility.getSessionUserId(request);
			 if(userId != 0){
				 String[] formId=request.getParameterValues("isSelect");
				 if(formId==null || formId.length == 0){
					 retVal="redirect:/etender/buyer/editgovcolumn/"+tenderId+encryptDecryptUtils.generateRedirect("etender/buyer/editgovcolumn/"+tenderId, request);
				 }else{
					 //List<String> dataList=new ArrayList<String>();
					 TblTenderGovColumn tblTenderGovColumn=null;
					 List<TblTenderGovColumn> tblTenderGovColumnList=new ArrayList<TblTenderGovColumn>();
					 for(String data:formId){
						 String[] tempArray=request.getParameterValues("selGovCols_"+data);
						 for(String tempString : tempArray){
							 String[] tempSplitString=tempString.split(",");
							 tblTenderGovColumn=new TblTenderGovColumn();
							 tblTenderGovColumn.setCellId(Integer.parseInt(tempSplitString[4]));
							 tblTenderGovColumn.setColumnNo(Integer.parseInt(tempSplitString[3]));
							 tblTenderGovColumn.setTblTenderColumn(new TblTenderColumn(Integer.parseInt(tempSplitString[2])));
							 tblTenderGovColumn.setTblTenderForm(new TblTenderForm(Integer.parseInt(tempSplitString[0])));
							 tblTenderGovColumn.setTblTenderTable(new TblTenderTable(Integer.parseInt(tempSplitString[1])));
							 tblTenderGovColumn.setIpAddress(request.getLocalAddr());
							 tblTenderGovColumn.setTblTender(new TblTender(tenderId));
							 tblTenderGovColumnList.add(tblTenderGovColumn);
						 }
					 }
					 success=tenderFormService.editGovColumns(tenderId,tblTenderGovColumnList);
					 if(success){
	           		  retVal="redirect:/etender/buyer/tenderdashboard/"+tenderId+"/2"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/2", request);
	           	    }else{
	           	    	retVal="redirect:/etender/buyer/editgovcolumn/"+tenderId+encryptDecryptUtils.generateRedirect("etender/buyer/editgovcolumn/"+tenderId, request);
	           	    }
				 }
				 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_editgovcolumn" : CommonKeywords.ERROR_MSG_KEY.toString());
			 }
		 }catch(Exception e){
			 retVal= exceptionHandlerService.writeLog(e);
	      }finally {
	           auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editGoverningColumnLinkId, postEditGovColumn,tenderId,0);
	      }
	      return retVal;
      }
     
     /**
      * to view governing column
      * @param tenderId
      * @param modelMap
      * @param request
      * @return
      */
     @RequestMapping(value = "/buyer/viewgovcolumn/{tenderId}/{enc}", method = RequestMethod.GET)
     public String viewGovColumn(@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request) {
         try {
        	 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	 int tenderResult=modelMap.get("tenderResult")!=null ? Integer.parseInt(modelMap.get("tenderResult").toString()) : -1;
        	 int formId=0;
        	 int tableId=0;
        	 boolean isFirst=true;
        	 List<TenderGoverningColumnDtBean> tenderGoverningColumnDtBeanList=new ArrayList<TenderGoverningColumnDtBean>();
        	 List<Object[]> data=null;
        	 //tenderResult=1;
        	 if(tenderResult == 1 || tenderResult == 3){
        		data=tenderFormService.getTenderGovColsForView(tenderId);
        	 }else{
        		 data=tenderFormService.getTenderGovColsItemWiseForView(tenderId);
        	 }
    		 TenderGoverningColumnDtBean tenderGoverningColumnDtBean=new TenderGoverningColumnDtBean();
    		 List<String> tableName=new ArrayList<String>();
    		 List<String> selectedValList=new ArrayList<String>();
    		 List<List<SelectItem>> govCols=new ArrayList<List<SelectItem>>();
    		 List<SelectItem> selectItemList=new ArrayList<SelectItem>();
    		 if(data != null && !data.isEmpty()){
    			 for(int i=0;i<data.size();i++){
    				 int tempFormId=Integer.parseInt(data.get(i)[3].toString());
    				 int tempTableId=Integer.parseInt(data.get(i)[4].toString());
    				 if(formId !=tempFormId){
    					 formId=tempFormId;
    					 if(i!=0){
    						 if(isFirst){
    							 govCols.add(selectItemList);
    							 selectItemList=new ArrayList<SelectItem>();
    							 isFirst=false;
    						 }
    						 tenderGoverningColumnDtBean.setGovCols(govCols);
    						 tenderGoverningColumnDtBean.setTableName(tableName);
    						 tenderGoverningColumnDtBean.setSelectedValList(selectedValList);
    						 tenderGoverningColumnDtBeanList.add(tenderGoverningColumnDtBean);
    						 tenderGoverningColumnDtBean=new TenderGoverningColumnDtBean();
    						 tableName=new ArrayList<String>();
    						 selectedValList=new ArrayList<String>();
    						 govCols=new ArrayList<List<SelectItem>>();
    					 }
    					 tenderGoverningColumnDtBean.setFormId(data.get(i)[3].toString());
    					 tenderGoverningColumnDtBean.setFormName(data.get(i)[0].toString());
    				 }
    				 if(formId == tempFormId && tempTableId !=tableId){
    					 tableName.add(data.get(i)[1].toString());
    				 }
    				 if(data.get(i)[8] != null && Integer.parseInt(data.get(i)[8].toString()) == Integer.parseInt(data.get(i)[5].toString())){
    					 selectedValList.add(data.get(i)[3].toString()+","+data.get(i)[4].toString()+","+data.get(i)[5].toString()+","+data.get(i)[6].toString()+","+data.get(i)[7].toString());
    				 }
    				 if(tempTableId !=tableId){
    					 tableId=tempTableId;
    					 if(i!=0){
    						 if(!selectItemList.isEmpty()){
    							 govCols.add(selectItemList);
    							 isFirst=true;
    							 selectItemList=new ArrayList<SelectItem>();
    						 }else{
    							 isFirst=true;
    						 }
    					 }
    					 selectItemList.add(new SelectItem(data.get(i)[2], data.get(i)[3].toString()+","+data.get(i)[4].toString()+","+data.get(i)[5].toString()+","+data.get(i)[6].toString()+","+data.get(i)[7].toString()));
    				 }else{
    					 selectItemList.add(new SelectItem(data.get(i)[2], data.get(i)[3].toString()+","+data.get(i)[4].toString()+","+data.get(i)[5].toString()+","+data.get(i)[6].toString()+","+data.get(i)[7].toString())); 
    				 }
    				 if(i==data.size()-1){
    					 govCols.add(selectItemList);
    					 tenderGoverningColumnDtBean.setGovCols(govCols);
    					 tenderGoverningColumnDtBean.setSelectedValList(selectedValList);
						 tenderGoverningColumnDtBean.setTableName(tableName);
						 tenderGoverningColumnDtBeanList.add(tenderGoverningColumnDtBean);
        			 }
    			 }
    		 }
        	 modelMap.addAttribute("tenderGoverningColumnDtBeanList", tenderGoverningColumnDtBeanList);
         }catch(Exception e){
          	return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewGoverningColumnLinkId, getViewGovColumn,tenderId,0);
          }
         return "/etender/buyer/ViewGovColumn";
     }
     
   @RequestMapping(value = "/buyer/addxlsmatrix", method = RequestMethod.POST,produces={"text/html; charset=UTF-8"})
    @ResponseBody
    public String addXlsMatrix(@RequestParam(HIDDEN_TABLE_ID) String hdTableId, @RequestParam(HIDDEN_TENDER_ID) String hdTenderId, @RequestParam("txtRowCount") Integer rowCount, @RequestParam("txtColCount") Integer colCount, HttpServletRequest request) {
        String data = null;
        boolean isValidate = true;
        int rowToGenerate = 0;
        int rowcount = 0;
        try {
            File file = null;
            boolean iscgClient = CommonUtility.isClientConditionExistInProperty(cgClient,abcUtility.getSessionClientId(request));
            File tmpDir = null;
            long fileSize = 0;
            String fileName = null;
            long fileMaxSize = 1024 * 1024;//1 MB
            String fileExtensions = "xls,xlsx";
            DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
            fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
            ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
            List items = uploadHandler.parseRequest(request);
            Iterator itr = items.iterator();
            while (itr.hasNext()) {
                FileItem item = (FileItem) itr.next();
                if (!item.isFormField()) {
                    fileSize = item.getSize();
                    if (item.getName().lastIndexOf("\\") != -1) {
                        fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1, item.getName().length());
                    } else {
                        fileName = item.getName();
                    }
                    if (fileName != null && !fileName.equalsIgnoreCase("")) {
                        if (fileSize == 0) {
                            data = messageSource.getMessage("msg_tender_emptyfile", null, LocaleContextHolder.getLocale());
                            isValidate = false;
                            break;
                        }
                        if (!checkFileSize(fileSize, fileMaxSize)) {
                            data = messageSource.getMessage("msg_tender_maxfilesize", new Object[]{(fileMaxSize / 1024)}, LocaleContextHolder.getLocale());
                            isValidate = false;
                            break;
                        }
                        if (!checkFileExn(fileName, fileExtensions)) {
                            data = messageSource.getMessage("msg_tender_fileformatnotsupp", null, LocaleContextHolder.getLocale());
                            isValidate = false;
                            break;
                        } else {
                            /* if destination directory not exist then create it*/
                            String tmpDirPath = drive + upload + formmatrix;
                            tmpDir = new File(tmpDirPath);
                            if (!tmpDir.isDirectory()) {
                                tmpDir.mkdir();
                            }
                            tmpDirPath = tmpDirPath + "\\" + hdTableId;
                            tmpDir = new File(tmpDirPath);
                            if (!tmpDir.isDirectory()) {
                                tmpDir.mkdir();
                            }
                            file = new File(tmpDir, fileName);
                            item.write(file);
                        }
                    }
                }
            }
            if (isValidate && file.exists()) {
                int j = fileName.lastIndexOf('.');
                String lst = fileName.substring(j + 1);
                boolean isXls = "xls".equalsIgnoreCase(lst);
                Iterator<Row> rows = null;
                if (isXls) {
                    HSSFWorkbook workBook = new HSSFWorkbook(new POIFSFileSystem(new FileInputStream(file)));
                    HSSFSheet sheet = workBook.getSheetAt(0);
                    rows = sheet.rowIterator();
                } else {
                    XSSFWorkbook workBook = new XSSFWorkbook(new FileInputStream(file));
                    XSSFSheet sheet = workBook.getSheetAt(0);
                    rows = sheet.rowIterator();
                }
                if (rows != null) {
                    int cellcount = 0;
                    int colcount = 0;
                    JSONArray jSONArray = new JSONArray();
                    while (rows.hasNext()) {
                        Row row = rows.next();
                        Iterator<Cell> cells = row.cellIterator();
                        JSONObject jSONObject = new JSONObject();
                        int cellno = 0;
                        /*while (cells.hasNext()) {*/
                        for(int cn=0; cn<row.getLastCellNum(); cn++) {
                        	if (rowcount == 0) {
                                colcount++;
                            }
                            /*Cell cell = cells.next();*/
                        	Cell cell = row.getCell(cn, Row.CREATE_NULL_AS_BLANK);
                        	if (cell.getCellType() == (isXls ? HSSFCell.CELL_TYPE_NUMERIC : XSSFCell.CELL_TYPE_NUMERIC)) {
                                jSONObject.put(rowcount == 0 ? String.valueOf(cellcount) : (rowcount - 1) + "_" + cellno, cell.getNumericCellValue());
                            } else if (cell.getCellType() == (isXls ? HSSFCell.CELL_TYPE_STRING : XSSFCell.CELL_TYPE_STRING)) {
                                jSONObject.put(rowcount == 0 ? String.valueOf(cellcount) : (rowcount - 1) + "_" + cellno, AbcUtility.htmlReplaceQuotes(cell.getRichStringCellValue().toString()).replaceAll("&quot;","\"").replaceAll("&quot","\""));
                            } else if (iscgClient && cell.getCellType() == (isXls ? HSSFCell.CELL_TYPE_BLANK : XSSFCell.CELL_TYPE_BLANK)) {
                                jSONObject.put(rowcount == 0 ? String.valueOf(cellcount) : (rowcount - 1) + "_" + cellno, "".toString());
                            } else if (iscgClient && cell.getCellType() == (isXls ? HSSFCell.CELL_TYPE_FORMULA : XSSFCell.CELL_TYPE_FORMULA)) {
                                jSONObject.put(rowcount == 0 ? String.valueOf(cellcount) : (rowcount - 1) + "_" + cellno, "".toString());
                            }
                            cellno++;
                            cellcount++;
                        }
                        jSONArray.put(rowcount, jSONObject);
                        rowcount++;
                        }
                    rowToGenerate = rowCount < (rowcount - 1) ? ((rowcount - 1) - rowCount) : 0;
                    if (colCount != colcount) {
                        data = messageSource.getMessage("msg_auc_excelformat", null, LocaleContextHolder.getLocale());
                        isValidate = false;
                    }
                    if (isValidate) {
                        data = jSONArray.toString();
                    }
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormExcelMatrix, addXlsMatrixAudit, Integer.parseInt(hdTenderId), Integer.parseInt(hdTableId));
        }
        return isValidate ? rowToGenerate+"_"+rowcount + "$~$" + data : "ERROR::" + data;
    }

    private boolean checkFileSize(long fielSize, long maxFileSize) {
        boolean chextn = false;
        if (maxFileSize > fielSize) {
            chextn = true;
        } else {
            chextn = false;
        }
        return chextn;
    }

    /**
     * to check file extention
     *
     * @param fileName
     * @param allowExtensions
     * @return
     */
    private boolean checkFileExn(String fileName, String allowExtensions) {
        boolean chextn = false;
        int j = fileName.lastIndexOf('.');
        String lst = fileName.substring(j + 1);
        String str = allowExtensions;
        String[] str1 = str.split(",");
        for (int i = 0; i < str1.length; i++) {
            if (str1[i].trim().equalsIgnoreCase(lst)) {
                chextn = true;
            }
        }
        return chextn;
    }
    
    /**
     * Use Case : TOC/TEC Report
     * @author nirav.modi
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/gettendertoctecreport/{committeeTypeId}/{enc}", method = RequestMethod.GET)                       
    public String getTenderTocTecReport(ModelMap modelMap, HttpServletRequest request,@PathVariable("committeeTypeId") Integer committeeTypeId ){
    	String retVal="etender/buyer/TocTecReport";
    	try {
            modelMap.addAttribute("reportId", manageTocTecReportId);
            reportGeneratorService.getReportConfigDetails(manageTocTecReportId, modelMap);
        } catch (Exception ex) {
            retVal= exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),tocTecLinkId, getTocTecReportRemark, 0, 0);
        }
    	return retVal;
    }
    /**
     * Show Bidder Mapping For Proxy
     * 
     * @author purvesh
     * @param tenderId
     * @param tableId
     * @param bidderId
     * @param tenderResult
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/proxy/{tenderId}/{formId}/{tableId}/{tenderResult}/{enc}", method = RequestMethod.GET)
    public String showBiddderMappingForProxyBid(@PathVariable(TENDER_ID)int tenderId, @PathVariable(FORM_ID)int formId, @PathVariable("tableId")int tableId, @PathVariable("tenderResult")int tenderResult, 
    									ModelMap modelMap,HttpServletRequest request) {
    	String retVal="/etender/buyer/MapBidderForTenderProxyBid";
    	List<Object[]> mappedBidderDetails = null;
    	try{
    		modelMap.put("formId", formId);
    		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		if(tenderResult==1){			/* Grand Total*/
    			mappedBidderDetails = tenderFormService.getGrandTotalWiseBidders(tenderId);
    		}
    		else{					 		/*  Item Wise*/
    			mappedBidderDetails = tenderFormService.getItemWiseBidders(tenderId, tableId);
    		}
    		modelMap.put("tableId", tableId);
    		if(mappedBidderDetails!=null && !mappedBidderDetails.isEmpty()){
    			modelMap.put("mappedBidderDetails", mappedBidderDetails);
    		}
    	}
    	catch(Exception e){
    		retVal = exceptionHandlerService.writeLog(e);
    	}
    	finally{
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), proxyLinkId, getMapBidderForProxyAudit,tenderId,formId);
    	}
    	return retVal;
    }
    
    /**
     * Create Proxy
     * 
     * @author purvesh
     * @param tenderId
     * @param tableId
     * @param companyId
     * @param tenderResult
     * @param modelMap
     * @param request
     * return
     * 
     */
    @RequestMapping(value = "/buyer/createproxy/{tenderId}/{formId}/{tableId}/{companyId}/{tenderResult}/{enc}", method=RequestMethod.GET)
    public String createProxy(@PathVariable(TENDER_ID)int tenderId, @PathVariable(FORM_ID)int formId, @PathVariable(TABLE_ID)int tableId,@PathVariable("companyId")int companyId, @PathVariable("tenderResult")int tenderResult, ModelMap modelMap, HttpServletRequest request){
    	
    	String retVal="/etender/buyer/TenderProxyBid";
    	List<Object[]> formTableDetails=null;
    	List<Object[]> listOfItems=null;
    	List<String> lstLabels = new ArrayList<String>();
    	List<String> lstValues = new ArrayList<String>();
    	List<String> lstColIds = new ArrayList<String>();
    	List<String> lstRowIds = new ArrayList<String>();
    	List<String> lstCellIds = new ArrayList<String>();
    	List<String> lstCellDataType = new ArrayList<String>();
    	List<String> lstProxtBidIds = new ArrayList<String>();
    	List<Object[]> lstColsName = new ArrayList<Object[]>();
    	List<HashMap <String, Object>> lstData= new ArrayList<HashMap <String, Object>>();
    	modelMap.put("forrmId", formId);
    	modelMap.put("tableId", tableId);
    	boolean isEditMode = false;
    	try {
    		int columnId = 0;
    		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		formTableDetails = tenderFormService.getFormTableDetails(tableId);
    		modelMap.put("formName", formTableDetails.get(0)[0]);
    		modelMap.put("tableHeader", formTableDetails.get(0)[1]);
    		modelMap.put("tableFooter", formTableDetails.get(0)[2]);
    		listOfItems = tenderFormService.getItemListForProxyBid(tableId, companyId, tenderResult);
    		for(Object[] obj:listOfItems){ 
    			if(columnId!=Integer.parseInt(obj[0].toString())){
    				lstColsName.add(new Object[]{Integer.parseInt(obj[0].toString()),obj[7].toString()});
    			}
    			columnId = Integer.parseInt(obj[0].toString());
    			if((Integer)obj[5]==1 || (Integer)obj[5]==2){
    				lstLabels.add(obj[3].toString());
    			}
    		}
    		Map<String, Object> mapItem = null;
    		int cnt = 0;
    		int rowCnt = 0;
    		columnId=0;
    		for(Object[] obj:listOfItems){
    			if((Integer)obj[5]!=1 && (Integer)obj[5]!=2){
	    			if(columnId!=Integer.parseInt(obj[0].toString())){
	    				if(cnt!=0){
	    					mapItem.put("cellValues", lstValues);
	    		    		mapItem.put("columnIds", lstColIds);
	    		    		mapItem.put("rowIds", lstRowIds);
	    		    		mapItem.put("cellIds", lstCellIds);
	    		    		mapItem.put("proxyBidIds", lstProxtBidIds);
	    		    		mapItem.put("cellDataType", lstCellDataType);
	    		    		lstData.add((HashMap<String, Object>) mapItem);
	    				}
	    				mapItem = new HashMap<String, Object>();
	    				lstValues = new ArrayList<String>();
	    				lstColIds = new ArrayList<String>();
	    				lstRowIds = new ArrayList<String>();
	    				lstCellIds = new ArrayList<String>();
	    				lstProxtBidIds = new ArrayList<String>();
	    				lstCellDataType = new ArrayList<String>();
	    				
	    				if(obj[4]!=null){
							isEditMode=true;
							lstProxtBidIds.add(obj[4].toString());
	    				}
	    				
	    				lstValues.add(obj[3].toString());
	    				lstColIds.add(obj[0].toString());
	    				lstRowIds.add(obj[1].toString());
	    				lstCellIds.add(obj[2].toString());
	    				lstCellDataType.add(obj[5].toString());
	    			}
	    			else{
	    				if(obj[4]!=null){
							isEditMode=true;
							lstProxtBidIds.add(obj[4].toString());
	    				}
						lstValues.add(obj[3].toString());
						lstColIds.add(obj[0].toString());
						lstRowIds.add(obj[1].toString());
						lstCellIds.add(obj[2].toString());
						lstCellDataType.add(obj[5].toString());
	    			}
	    			if(cnt==(listOfItems.size()-1-rowCnt)){
	    				mapItem.put("cellValues", lstValues);
			    		mapItem.put("columnIds", lstColIds);
			    		mapItem.put("rowIds", lstRowIds);
			    		mapItem.put("cellIds", lstCellIds);
			    		mapItem.put("proxyBidIds", lstProxtBidIds);
			    		mapItem.put("cellDataType", lstCellDataType);
			    		lstData.add((HashMap<String, Object>) mapItem);
	    			}
	    			columnId = Integer.parseInt(obj[0].toString());
	    			cnt++;
    			}
    			else{
    				rowCnt++;
    			}
    		}
    		modelMap.addAttribute("RowsName", lstLabels);
    		modelMap.addAttribute("ColsName", lstColsName);
    		modelMap.addAttribute("listOfItems", lstData);
    		modelMap.put("noOfRows",lstLabels.size());
    		modelMap.put("noOfcols",(lstColsName.size()-1) );
    		modelMap.addAttribute("isEditMode", isEditMode);
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		} finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), proxyBidLinkId, getTenderProxyAudit,tenderId,formId);
		}
    	return retVal;
    }
        
    /**
     * Proxy Submission
     * 
     * @author purvesh
     * @param request
     * @param modelMap
     * @param redirectAttributes
     * @return to view
     */
    @RequestMapping(value="/buyer/proxysubmission", method=RequestMethod.POST)
    public String proxySubmission(HttpServletRequest request, ModelMap modelMap, RedirectAttributes redirectAttributes){
    	String redirectUrl = "etender/buyer/proxy/";
    	String retVal=REDIRECT_SESSION_EXPIRED;
    	String failureMsg=CommonKeywords.ERROR_MSG.toString();
    	int tenderId = 0;
    	int formId =0;
    	int tableId = 0;
    	int companyId = 0;
    	int tenderResult = 0;
    	int rows = 0;
    	int cols = 0;
    	boolean isEditMode = false;
    	boolean success = false;
    	try {
    		SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
    		if(sessionBean!=null){
	    		String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
	    		tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
	    		formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
	        	tableId = StringUtils.hasLength(request.getParameter("hdTableId")) ? Integer.parseInt(request.getParameter("hdTableId")) : 0;
	        	tenderResult = StringUtils.hasLength(request.getParameter("hdTenderResult")) ? Integer.parseInt(request.getParameter("hdTenderResult")) : 0;
	        	companyId = StringUtils.hasLength(request.getParameter("hdCompanyId")) ? Integer.parseInt(request.getParameter("hdCompanyId")) : 0;
	        	rows = StringUtils.hasLength(request.getParameter("noOfRows")) ? Integer.parseInt(request.getParameter("noOfRows").toString()) : 0;
	        	cols = StringUtils.hasLength(request.getParameter("noOfcols")) ? Integer.parseInt(request.getParameter("noOfcols").toString()) : 0;
	        	isEditMode = StringUtils.hasLength(request.getParameter("hdIsEditMode")) ? Boolean.parseBoolean(request.getParameter("hdIsEditMode")) : false;
	        	
	        	if(tenderId!=0 && formId!=0 && tableId!=0 && companyId!=0 && rows!=0 && cols!=0){
			        	retVal="redirect:/"+redirectUrl+tenderId+"/"+formId+"/"+tableId+"/"+tenderResult+encryptDecryptUtils.generateRedirect(redirectUrl+tenderId+"/"+formId+"/"+tableId+"/"+tenderResult, request);
			        	if(tenderFormService.isBidderHasBid(tenderId, companyId)){
			        		failureMsg="bid_already_received";
			        	}
			        	else{
				        	int totalCells = rows*cols;
				        	String[] colIds = new String[totalCells];
				        	String[] rowlIds = new String[totalCells];
				        	String[] cellIds = new String[totalCells];
				        	String[] proxyBidIds = new String[totalCells];
				        	String[] cellValues = new String[totalCells];
				        	int index = 0;
				        	for(int i=0; i<rows; i++){
				        		for(int j=0; j<cols; j++){
				        			colIds[index] = StringUtils.hasLength(request.getParameter("hdColIds_"+i+"_"+j)) ? request.getParameter("hdColIds_"+i+"_"+j) :"";
				        			rowlIds[index] = StringUtils.hasText(request.getParameter("hdRowIds_"+i+"_"+j)) ? request.getParameter("hdRowIds_"+i+"_"+j) : "";
				        			cellIds[index] = StringUtils.hasLength(request.getParameter("hdCellIds_"+i+"_"+j)) ? request.getParameter("hdCellIds_"+i+"_"+j) : "";
				        			cellValues[index] = StringUtils.hasLength(request.getParameter("txtCellValue_"+i+"_"+j)) ? request.getParameter("txtCellValue_"+i+"_"+j) : "";
				        			if(isEditMode){
					        				proxyBidIds[index] = StringUtils.hasLength(request.getParameter("hdProxyBidIds_"+i+"_"+j)) ? request.getParameter("hdProxyBidIds_"+i+"_"+j) : "";
				        			}
				        			index++;
				        		}
				        	}
				        	List<Integer> proxyIds = new ArrayList<Integer>();
				        	if(isEditMode){
					    		for(int i=0; i<proxyBidIds.length; i++){
					    			proxyIds.add(Integer.parseInt(proxyBidIds[i]));
					    		}
				        	}
				        	List<TblTenderProxyBid>lstTblTenderProxyBid = new ArrayList<TblTenderProxyBid>();
				        	TblTenderProxyBid tblTenderProxyBid = null;
				        	for(int i=0; i<cellValues.length; i++){
				        		tblTenderProxyBid = new TblTenderProxyBid();
				        		tblTenderProxyBid.setTblTender(new TblTender(tenderId));
				        		tblTenderProxyBid.setTblTenderTable(new TblTenderTable(tableId));
				        		tblTenderProxyBid.setTblTenderColumn(new TblTenderColumn(Integer.parseInt(colIds[i])));
				        		tblTenderProxyBid.setTblTenderCell(new TblTenderCell(Integer.parseInt(cellIds[i])));
				        		tblTenderProxyBid.setRowId(Integer.parseInt(rowlIds[i]));
				        		tblTenderProxyBid.setTblCompany(new TblCompany(companyId));
				        		tblTenderProxyBid.setCellValue(cellValues[i]);
				        		tblTenderProxyBid.setIpAddress(ipAddress);
				        		tblTenderProxyBid.setCreatedBy(abcUtility.getSessionUserDetailId(request));
				        		lstTblTenderProxyBid.add(tblTenderProxyBid);
				        	}
				        	success = tenderFormService.addUpdateProxyBid(lstTblTenderProxyBid,isEditMode, proxyIds);
			        	}
		        	}
		        	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success? "bidders_specific_value_entered_successfully" : failureMsg);
	    		}
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
    	finally{
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), proxyBidLinkId,postAddUpdateProxyAudit,tenderId,formId);
    	}
    	return retVal;
    }
    
    /**
     * SOR Form Matrix GET     
     * @param tenderId
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/formsor/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)
    public String formSor(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, ModelMap modelMap, HttpServletRequest request) {
        Map<Integer,String> cellValues = new HashMap<Integer, String>();
        int UserId = abcUtility.getSessionUserId(request);
        try {
            tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("decimalUpto",tenderCommonService.getTenderField(tenderId, "decimalValueUpto"));
            List<TblTenderSOR> tenderSORs = tenderFormService.getTenderSORByFormId(formId);
            for (TblTenderSOR tblTenderSOR : tenderSORs) {
                cellValues.put(tblTenderSOR.getTblTenderCell().getCellId(), tblTenderSOR.getCellValue());
            }            
            modelMap.addAttribute("cellValues", cellValues);
            modelMap.addAttribute("formsor", true);
            modelMap.addAttribute("lodingProcessOver", false);
            modelMap.addAttribute("UserId",UserId);
            if(cellValues.size()>0)
            {
            	TblNegotiationSORRemarks tblBidFormSORRemarks=tenderFormService.getTenderNegotiationSORRemarks(formId,60);
            	if(tblBidFormSORRemarks!=null)
                {
            		modelMap.addAttribute("remarks",tblBidFormSORRemarks.getRemarks());
                }
             }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), cellValues.isEmpty() ? bidFormCreateSor : bidFormEditSor,sorFormAudit, tenderId, formId);
        }
        return "/etender/buyer/TestForm";
    }
    
    @RequestMapping(value = "/buyer/addsor", method = RequestMethod.POST)
    public String addSor(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
        boolean isEdit = StringUtils.hasLength(request.getParameter("hdEdit")) ? Boolean.parseBoolean(request.getParameter("hdEdit")) : false;
        int UserId = abcUtility.getSessionUserId(request);
        boolean success = false;
        String SORRemarks = null;
        TblNegotiationSORRemarks tblNegotiationSORRemarks =new TblNegotiationSORRemarks();
        String retVal = "redirect:/loginfailed";
        try {
            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            if (sessionBean != null) {
                List<TblTenderSOR> tenderSORs = new ArrayList<TblTenderSOR>();
                String[] hdTableIds = request.getParameterValues("hdTableId");
                for (String tableId : hdTableIds) {
                    String sorString = request.getParameter("rtfSorBid_" + tableId);
                    if (StringUtils.hasLength(sorString)) {
                        JSONArray jsonArray = new JSONArray(sorString);
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject jSONObject = jsonArray.getJSONObject(i);
                            for (Iterator it = jSONObject.keys(); it.hasNext();) {
                                String key = it.next().toString();
                                String[] values = key.split("_");
                                tenderSORs.add(new TblTenderSOR(formId,Integer.parseInt(tableId),Integer.parseInt(values[0]),jSONObject.getString(key)));
                            }
                        }
                    }
                }
                TblNegotiationSORRemarks SORRemarksfrmBidForm=tenderFormService.getTenderNegotiationSORRemarks(formId,60);
                SORRemarks = StringUtils.hasLength(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") : null;
                if(SORRemarks!=null && SORRemarksfrmBidForm==null)
               {
            	   tblNegotiationSORRemarks.setParentId(tenderId);
                   tblNegotiationSORRemarks.setObjectId(formId);
                   tblNegotiationSORRemarks.setEventId(60);
                   tblNegotiationSORRemarks.setRemarks(SORRemarks);
                   tblNegotiationSORRemarks.setCreatedBy(UserId);
                   tblNegotiationSORRemarks.setCreatedOn(commonService.getServerDateTime());
                   tblNegotiationSORRemarks.setUpdatedBy(UserId);
                   tblNegotiationSORRemarks.setUpdatedOn(commonService.getServerDateTime());
                   success = tenderFormService.addTblTenderSOR(tenderSORs,tblNegotiationSORRemarks);
               }
                else
                {
                	success = tenderFormService.addTblTenderSOR(tenderSORs);
                }
                
                if(success && dynamicReportService.isDynReportCellValueExist(tenderId,2,2,0)){ //reportOn=2 means Itemwise report and reportType=2 means System Generated L1/H1 Report (only for item wise event)
                	List<Object[]> list=tenderReportService.calculateAndGetTenderSavingDtlsItemWiseCase(tenderId);
                	if(list!=null && !list.isEmpty()){
                		TblTenderSaving tblTenderSaving=new TblTenderSaving();
                    	tblTenderSaving.setObjectId(tenderId);
                    	tblTenderSaving.setTblTender(new TblTender(tenderId));
                    	tblTenderSaving.setTotalAmt(list.get(0)[0].toString());
                    	tblTenderSaving.setEstimatedAmt(list.get(0)[1].toString());
                    	tblTenderSaving.setSavingGainAmt(list.get(0)[2].toString());
                    	tblTenderSaving.setCStatus(0);
                    	tblTenderSaving.setCreatedBy(abcUtility.getSessionUserId(request));
                    	tenderReportService.addTblTenderSaving(tblTenderSaving);
                	}
                }
                
                redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_tender_formsor" : CommonKeywords.ERROR_MSG_KEY.toString());
                retVal = success ? TENDER_DASHBOARD_URL + tenderId + "/2" : "etender/buyer/formsor/" + tenderId + "/" + formId;
                retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),!isEdit ? bidFormCreateSor : bidFormEditSor, !isEdit ? addSorFormAudit : editSorFormAudit, tenderId, formId);
        }
        return retVal;
    }
    
     @RequestMapping(value = "/buyer/deleteformsor/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)
    public String deleteFormSor(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        boolean success = false;
        try {
        	Integer[] eventIds = new Integer[3];
        	eventIds = new Integer[]{60,68,240};
        	success = tenderFormService.deleteTenderSORRemarks(formId,eventIds);
            success = tenderFormService.deleteTenderSOR(formId);
            
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),bidFormDeleteSor , deleteSorFormAudit, tenderId, formId);
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_delsuccess_tender_formsor" : CommonKeywords.ERROR_MSG_KEY.toString());        
        return "redirect:/" + TENDER_DASHBOARD_URL + tenderId + "/2" + encryptDecryptUtils.generateRedirect(TENDER_DASHBOARD_URL + tenderId + "/2", request);        
    }
     
    /**
     * SOR Form Matrix GET     
     * @param tenderId
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/viewformsor/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)
    public String viewFormSor(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, ModelMap modelMap, HttpServletRequest request) {
        try {
            tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("decimalUpto",tenderCommonService.getTenderField(tenderId, "decimalValueUpto"));
            Map<Integer,String> cellValues = new HashMap<Integer, String>();
            List<TblTenderSOR> tenderSORs = tenderFormService.getTenderSORByFormId(formId);
            TblNegotiationSORRemarks tblBidFormSORRemarks=tenderFormService.getTenderNegotiationSORRemarks(formId,60);
            for (TblTenderSOR tblTenderSOR : tenderSORs) {
                cellValues.put(tblTenderSOR.getTblTenderCell().getCellId(), tblTenderSOR.getCellValue());
            }       
            if(tblBidFormSORRemarks!=null)
            {
            	modelMap.addAttribute("remarks",tblBidFormSORRemarks.getRemarks()==null ? "" : tblBidFormSORRemarks.getRemarks());
            }
            modelMap.addAttribute("cellValues", cellValues);
            modelMap.addAttribute("formsor", true);
            modelMap.addAttribute("viewformsor", "1");
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormViewSor, viewSorFormAudit, tenderId, formId);
        }
        return "/etender/buyer/TestForm";
    }
     /**
     * Test Form Matrix GET     
     * @param tenderId
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/createcellform/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)
    public String createCellFormula(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, ModelMap modelMap, HttpServletRequest request) {
        try {
            tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("decimalUpto",tenderCommonService.getTenderField(tenderId, "decimalValueUpto"));
            modelMap.addAttribute("formulaType",tenderFormService.getFormulaType());
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "", tenderId, formId);
        }
        return "/etender/buyer/CreateCellFormula";
    }
    
     /**
     * Create Formula POST
     *
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/addcellformula", method = RequestMethod.POST)
    public String addCellFormula(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
        String txtCellInfo = request.getParameter("txtCellInfo");
        String skpFormFormula = request.getParameter("skpFormFormula");
        String skpFormula = request.getParameter("skpFormula");
        String txtFormulaMsg = request.getParameter("txtFormulaMsg");
        int selFormulaType = StringUtils.hasLength(request.getParameter("selFormulaType")) ? Integer.parseInt(request.getParameter("selFormulaType")) : 0;
        int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;        
        boolean success = false;
        String pageName = REDIRECT_SESSION_EXPIRED;
        if (abcUtility.getSessionUserId(request) != 0) {
            try {
                int cellId = selFormulaType==3 ? 0 : Integer.parseInt(skpFormula.split("=")[0]);
                int tableId = Integer.parseInt(txtCellInfo.split("_")[0]);
                int columnNo=Integer.parseInt(txtCellInfo.split("_")[1]);
                int cellNo= Integer.parseInt(txtCellInfo.split("_")[2]);
                int columnId=Integer.parseInt(txtCellInfo.split("_")[3]);
                TblTenderFormula tenderFormula = new TblTenderFormula();
                tenderFormula.setCellId(cellId);
                tenderFormula.setCellNo(cellNo);
                tenderFormula.setFormulaType(selFormulaType==1 ? 1 : 2);
                tenderFormula.setColumnNo(columnNo);
                tenderFormula.setDisplayFormula(skpFormFormula);                
                tenderFormula.setFormula((selFormulaType==1 ? "SPF_" : selFormulaType==2 ? "VCF_" : "VF_")+(selFormulaType==3 ? skpFormula : skpFormula.substring(skpFormula.indexOf("=")+1,skpFormula.length())));
                tenderFormula.setColFormula(tenderFormula.getFormula());
                tenderFormula.setTblTenderColumn(new TblTenderColumn(columnId));
                tenderFormula.setTblTenderForm(new TblTenderForm(formId));
                tenderFormula.setTblTenderTable(new TblTenderTable(tableId));
                tenderFormula.setValidationMessage(txtFormulaMsg);
                success = tenderFormService.addFormula(tenderFormula);
            } catch (Exception e) {
                pageName = exceptionHandlerService.writeLog(e);
            } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "", tenderId, formId);
            }
            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_formulacreated" : CommonKeywords.ERROR_MSG_KEY.toString());
            pageName = "redirect:/etender/buyer/createcellform/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/createcellform/" + tenderId + "/" + formId, request);
        }
        return pageName;
    }
    
     /**
     * Delete Form Formula GET
     *
     * @param tenderId
     * @param formulaId
     * @param fromDash
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/buyer/deletecellformula/{tenderId}/{formId}/{formulaId}/{enc}", method = RequestMethod.GET)
    public String deleteCellFormula(@PathVariable("tenderId") Integer tenderId,@PathVariable("formId") Integer formId,@PathVariable("formulaId") Integer formulaId,HttpServletRequest request, RedirectAttributes redirectAttributes) {
        try {
            boolean success = tenderFormService.deleteFormula(formulaId, 0, 0, 0, false,false,0);
            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_formuladeleted" : CommonKeywords.ERROR_MSG_KEY.toString());
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormFormulaDel, deleteFormulaAudit, tenderId, formulaId);
        }
        return "redirect:/etender/buyer/createcellform/" + tenderId + "/" + formId +encryptDecryptUtils.generateRedirect("etender/buyer/createcellform/" + tenderId + "/" + formId, request);
    }
    
    @RequestMapping(value = "/buyer/dumpmasterform", method = RequestMethod.POST)
    public String dumpMasterForm(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        int tenderId=StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
        int envelopeId=StringUtils.hasLength(request.getParameter(SELECT_ENVELOPE_ID)) ? Integer.parseInt(request.getParameter(SELECT_ENVELOPE_ID)) : 0;
        int masterFormId=StringUtils.hasLength(request.getParameter(HIDDEN_FORM_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_FORM_ID)) : 0;
        String retVal = "redirect:/sessionexpired";
        int isBiddingFormPublishWithTender = 0;
        try {
            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            if (sessionBean != null) {
                List<Object[]> clientConfigList=commonService.getClientConfigurations(abcUtility.getSessionClientId(request));
                if(!clientConfigList.isEmpty() && clientConfigList.size()>0){
                    isBiddingFormPublishWithTender = Integer.parseInt(clientConfigList.get(0)[3].toString());
                }
                boolean success = tenderFormService.dumpMasterForm(tenderId, envelopeId, masterFormId, sessionBean.getUserDetailId(),isBiddingFormPublishWithTender);
                //Added by Mitesh
                if(success){
                    if(!tenderCorrigendumService.isCorrigendumPending(tenderId)){
                        success=tenderFormService.getAndUpdateNoOfMandatoryBiddingForms(envelopeId);
                    }
                }
                //Ended by Mitesh
                redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_formuladeleted" : CommonKeywords.ERROR_MSG_KEY.toString());
                retVal = "redirect:/etender/buyer/tenderdashboard/"+tenderId+"/2"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/2", request);
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormFormulaDel, deleteFormulaAudit, tenderId, 0);
        }
        return retVal;
    }
    /**
     * Use to get Master Form library
     * @author Krunal.Patel	
     * @param formId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/masterformlibrary/{tenderId}/{enc}", method = RequestMethod.GET)
    public String masterFormLibrary(@PathVariable("tenderId") Integer tenderId, ModelMap modelMap, HttpServletRequest request) {
        try {
        	/*** Get Common Services for tender detail **/
 			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
 			
        	modelMap.addAttribute("envelopeList",abcUtility.convert(tenderFormService.getMasterFormEnvlopList(tenderId), 1,2));
        	modelMap.addAttribute("tenderId", tenderId);
            modelMap.addAttribute("reportId", reportMasterFormLibrary);
            reportGeneratorService.getReportConfigDetails(reportMasterFormLibrary, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), biddingFormMasterFormLibrary, getMasterFormLibraryRemark, tenderId, 0);
        }
        return "etender/buyer/MasterFormLibrary";
    }
    
    /**
     * Use to get envelopename 
     * @author heeral.soni
     */
    @RequestMapping(value = "/buyer/editenvelopename/{tenderId}/{envelopeId}/{enc}", method = RequestMethod.GET)
    public String editEnvelopeName(@PathVariable("tenderId") Integer tenderId,@PathVariable("envelopeId") Integer envelopeId, ModelMap modelMap, HttpServletRequest request) {
        try {
                tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                modelMap.addAttribute("envelopeName", tenderFormService.getEnvelopeNameById(envelopeId));
        	
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), biddingFormEditEnvelopeName, getEditTenderEnvelope, tenderId, envelopeId);
        }
        return "etender/buyer/EditEnvelope";
    }
    
    /**
     * Use to update envelope name from bidding form tab
     * @author heeral.soni
     */
    @RequestMapping(value="/buyer/updateenvelopename", method = RequestMethod.POST)
    public String updateEnvelopeName(RedirectAttributes redirectAttributes, HttpSession httpSession, HttpServletRequest request) throws IOException {
        String retVal = REDIRECT_SESSION_EXPIRED;
        int tenderId = 0;
        int envelopeId = 0;
        try {
            if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                    envelopeId = StringUtils.hasLength(request.getParameter("hiddenEnvId")) ? Integer.parseInt(request.getParameter("hiddenEnvId")) : 0;
                    tenderId = StringUtils.hasLength(request.getParameter("hiddenTenId")) ? Integer.parseInt(request.getParameter("hiddenTenId")) : 0;
                    String envelopeName=StringUtils.hasLength(request.getParameter("txtEnvName")) ? request.getParameter("txtEnvName") : ""; 
                    boolean isUpdated = tenderFormService.updateTenderEnvelopeName(envelopeId,envelopeName);
                    redirectAttributes.addFlashAttribute(isUpdated ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isUpdated ? "msg_update_tender_envelope" : CommonKeywords.ERROR_MSG_KEY.toString());
                    retVal = "redirect:/etender/buyer/tenderdashboard/"+tenderId+"/2"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/2", request);
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), biddingFormEditEnvelopeName, postEditTenderEnvelope, tenderId, envelopeId);
        }
        return retVal;
    }
    
    
    /**
     * 
     * @author nirav.prajapati
     * 
     * @param modelMap
     * @param request
     * @param tenderId
     * @param isWorkFlow
     * @param formId
     * @return
     */
    
    @RequestMapping(value = "/buyer/deletetendertable/{tableId}/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)                       
    public String deleteTenderTable(RedirectAttributes redirectAttributes,ModelMap modelMap, HttpServletRequest request,@PathVariable(TENDER_ID) int tenderId,@PathVariable("formId") int formId,@PathVariable("tableId") int tableId){
    	
    String	retVal = "redirect:/etender/buyer/formdashboard/" + tenderId + "/" + formId + encryptDecryptUtils.generateRedirect("etender/buyer/formdashboard/" + tenderId + "/" + formId, request);
    	
    boolean success = false;	
    try{
    		success = tenderFormService.deleteTenderTable(tableId,tenderId,formId);
                if(success){//update the mandatory table counter into the form for minTablesReqForBidding.
                 	success=tenderFormService.getAndUpdateNoOfMandatoryBiddingTables(formId);
                }
    		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_tabledeleted" : CommonKeywords.ERROR_MSG_KEY.toString());
    	}
    	catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),publishFormLinkId, getTenderPublishRemark, tenderId, 0);
    	}
    	return retVal;
    }

    /**
     * Get bidder bided items, it will be approved or rejected by committee members. Apply only if tables have 'encryption not require' column type column.
     * @author bharat
     * @param tenderId
     * @param bidderId
     * @param companyId
     * @param technicalEnvelopeId
     * @param committeeId
     * @param childId
     * @param modelMap
     * @param request
     * @return
     */
     @RequestMapping(value = "/buyer/formitemselection/{tenderId}/{bidderId}/{companyId}/{technicalEnvelopeId}/{committeeId}/{childId}/{techEnvelopeSortOrder}/{viewflag}/{enc}", method = RequestMethod.GET)
     public String getEvaluateBiddersItemWsie(@PathVariable("tenderId") int tenderId,@PathVariable("bidderId") int bidderId ,@PathVariable("companyId") int companyId,@PathVariable("technicalEnvelopeId") int technicalEnvelopeId,@PathVariable("committeeId") int committeeId,@PathVariable("childId") int childId,@PathVariable("techEnvelopeSortOrder") int techEnvelopeSortOrder,@PathVariable("viewflag") int  viewflag, ModelMap modelMap,HttpServletRequest request) {
    	 String page="";
            try {
           	 	Map<Integer,Map<String,Object>> formMap = new LinkedHashMap<Integer, Map<String,Object>>();
           	 	List<Object[]> formList = tenderFormService.getTenderApprovedPriceBidForm(tenderId);
           	    Map<Object,String> encReqFieldValue = new HashMap<Object, String>();  
           	    List<Object[]> allBidderItems =  new ArrayList<Object[]>();
           	    Map<Object,Object> encReqFormMap = new HashMap<Object, Object>();
           	    Map<Object,Object> encReqTableMap = new HashMap<Object, Object>();
            	for(Object[] obj : formList)
            	{
            		Map<String,Object> map = new HashMap<String, Object>();
            		int envelopformId = Integer.parseInt(obj[0].toString());
            		tenderFormService.setViewFormNFormula(envelopformId, map, tenderId);
            		formMap.put(envelopformId, map);
            		modelMap.put("envelopeId",obj[2]);
            		List<Object> cellIdList = new ArrayList<Object>();
            		tenderFormService.getBidDetailTblValue(envelopformId,encReqFieldValue,companyId,cellIdList);
            		if(cellIdList != null && !cellIdList.isEmpty()){
            			tenderFormService.getFormTableMap(cellIdList,encReqFormMap,encReqTableMap);
            		}
            	}
            	modelMap.addAttribute("companyName", commonService.getCompanyNameByCompanyId(companyId));
        		modelMap.put("envelopeSortOrder",techEnvelopeSortOrder); // Sort order of techniccal
            	modelMap.put("encReqFormMap", encReqFormMap);
            	modelMap.put("encReqTableMap", encReqTableMap);
            	modelMap.put("formList", formMap);
          		modelMap.put("encReqFieldValue", encReqFieldValue);
            	int loginuserid = abcUtility.getSessionUserId(request);
            	List<Integer> officerList =  new ArrayList<Integer>();
            	officerList.add(loginuserid);
            	
            	// Get item selected by officer
            	List<Object[]> bidderItemsSelectedByOfficerList = tenderFormService.getBidderItemssByOfficer(tenderId,0,officerList);
            	officerList.clear();
                if(bidderItemsSelectedByOfficerList != null && !bidderItemsSelectedByOfficerList.isEmpty())
	           	 {
                	
	           		 Map<String,String> itemSelected = new HashMap<String, String>();
	           		 
	           		 
	           		 for(Object[] obj : bidderItemsSelectedByOfficerList)
	           		 {
	           			if(obj[4].equals(bidderId)){
	           				itemSelected.put(obj[0]+"_"+obj[1]+"_"+obj[2],obj[6].toString()); // selected item flag
	           			}
	           		 }
	           		 modelMap.addAttribute("itemSelected",itemSelected);
	           		 modelMap.addAttribute("evaluationDoneForOne",true);
	           	 }
                // Get flag for bidded item by bidder. 
                List<Object[]> bidderBiddedList = tenderFormService.getBidderItems(tenderId,bidderId,0,false);
                if(bidderBiddedList != null && !bidderBiddedList.isEmpty())
	           	 {
	           		 Map<String,String> biddedMap = new HashMap<String, String>();
	           		 Map<Object,Object> selectedFormMap = new HashMap<Object, Object>();
	           		 Map<Object,Object> selectedTableMap = new HashMap<Object, Object>();
	           		 for(Object[] obj : bidderBiddedList)
	           		 {
	           			 biddedMap.put(obj[0]+"_"+obj[1]+"_"+obj[2],obj[6].toString()); // Bidded item flag
	           			 if(obj[6].equals(1)){
		           			selectedFormMap.put(obj[0], obj[0]);
		           			selectedTableMap.put(obj[1], obj[1]);
	           			 }
	           		 }
	           		 modelMap.addAttribute("biddedMap",biddedMap);
	           		 modelMap.addAttribute("selectedTableMap",selectedTableMap);
	           		modelMap.addAttribute("selectedFormMap",selectedFormMap);
	           	 }
                // Get officer list which are mapped in envelop 
	            List<Object[]> userRole = tenderFormService.getUserRoleByCommiteeIdEnvelopId(committeeId,technicalEnvelopeId);
	         	for (Object[] objects : userRole) {
	        		 if((Integer)objects[0] == loginuserid && viewflag != 1)
	        		 { 
	        			 continue;
	        		 }else{
	        			 officerList.add((Integer)objects[0]);
	        		 }
	        	 }
	         	// Get all officers selection status
	        	 if(officerList!=null && !officerList.isEmpty())
	        	 {
	        		 allBidderItems = tenderFormService.getBidderItemssByOfficer(tenderId,bidderId,officerList);
	        	 }	
	        	 if(allBidderItems  != null && !allBidderItems.isEmpty()){
	        	 	Map<String,String> officerItemSelected = new HashMap<String, String>();
	        	 	Map<String,String> processedByOfficer = new HashMap<String, String>();
	        	 	for(Object[] obj : allBidderItems)
	        	 	{
	        	 		officerItemSelected.put(obj[5]+"_"+obj[0]+"_"+obj[1]+"_"+obj[2],obj[6].toString()); // userid_formid_tableid_rowid
	        	 		processedByOfficer.put(obj[5].toString(), obj[5].toString());
	        	 		
	        	 	}
	        	 	modelMap.put("officerItemSelected", officerItemSelected);
	        	 	modelMap.addAttribute("processedByOfficer",processedByOfficer);
	        	 }
	        	// Get user role map and name map
	        	 tenderFormService.setOfficerRoleNameMapping(userRole,modelMap,loginuserid,tenderId);
	             
	        	 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	        	 if(viewflag == 1){
	        		 page = "/etender/buyer/FormItemSelectionOfficerView";
	        	 }else{
	        		 page = "/etender/buyer/FormItemSelectionOfficer";
	        	 }
            } catch (Exception e) {
                return exceptionHandlerService.writeLog(e);
            }finally {
            //    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), selectItemsForBiddingLink , getFormItemSelectionPage,tenderId,envelopeId);
            }
            return page;
        }      
     
    /**
     * Save item selected by officer for bidders.
     * @author bharat
     * @param modelMap
     * @param request
     * @param redirectAttributes
     * @return
     */
     @RequestMapping(value = "buyer/savebidderitem", method = RequestMethod.POST)
     public String saveBidderItem(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
         String retVal = "redirect:/sessionexpired";
         int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
         int priceBidenvelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")) : 0;
         int companyId = StringUtils.hasLength(request.getParameter("hdCompanyId")) ? Integer.parseInt(request.getParameter("hdCompanyId")) : 0;
         int bidderId = StringUtils.hasLength(request.getParameter("hdBidderId")) ? Integer.parseInt(request.getParameter("hdBidderId")) : 0;
         int hdChildId = StringUtils.hasLength(request.getParameter("hdChildId")) ? Integer.parseInt(request.getParameter("hdChildId")) : 0;
         int hdLoginUserRole = StringUtils.hasLength(request.getParameter("hdLoginUserRole")) ? Integer.parseInt(request.getParameter("hdLoginUserRole")) : 0;
         String hdIsUpdate = request.getParameter("hdIsUpdate");
         String approveRejectItems[]=null;
         String chkLotWiseApproveRejectItems[]=request.getParameterValues("chkLotWiseApproveRejectItems");
         String allItems[]=request.getParameterValues("hdAllItems");
         boolean isEvaluationAllow = true;
         String msg = "";
         boolean isInserted = false;
         SessionBean sessionBean = request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
         try {
             if (sessionBean != null) {
            	 if(hdLoginUserRole > 1){
            		 isEvaluationAllow = tenderFormService.isReworkLinkAllow(hdLoginUserRole,tenderId);
	              }else{
	            	  isEvaluationAllow = true;
	              }
             if(isEvaluationAllow) //If evaluation is not in rework state then only evaluation can done.
             {
                 approveRejectItems = request.getParameterValues("chkApproveRejectItems");
                 List<String> processed = new ArrayList<String>();
                 List<TblBidderItems> bidderItemsList = new ArrayList<TblBidderItems>();
                 if(approveRejectItems!=null){
                     /// All selected items
 	                for(int i=0;i<approveRejectItems.length;i++){
 	                	String[] approvedItem = approveRejectItems[i].split("_");
 	                	TblBidderItems tblBidderItems = new TblBidderItems();
 	                	tblBidderItems.setTblTender(new TblTender(tenderId));
 	                	tblBidderItems.setTblTenderEnvelope(new TblTenderEnvelope(priceBidenvelopeId));
 	                	tblBidderItems.setTblTenderForm(new TblTenderForm(Integer.parseInt(approvedItem[0])));//formId
 	                	tblBidderItems.setTblTenderTable(new TblTenderTable(Integer.parseInt(approvedItem[1])));//tableId
 	                	tblBidderItems.setRowId(Integer.parseInt(approvedItem[2]));//rowId
 	                	tblBidderItems.setTblUserLogin(new TblUserLogin(bidderId));
 	                	tblBidderItems.setTblCompany(new TblCompany(companyId));
 	                	tblBidderItems.setCreatedBy(abcUtility.getSessionUserId(request)); // user login id.
 	                	tblBidderItems.setIsActive(1);//1 for approve items
 	                	tblBidderItems.setChildId(hdChildId);//1 for approve items
 	                	tblBidderItems.setIsApproved(1);//1 for approve items
 	                    bidderItemsList.add(tblBidderItems);
 	                    processed.add(approveRejectItems[i].trim());
 	                }
 	                    	
                 }
                 if(chkLotWiseApproveRejectItems!=null){ // If Lot wise
 	                for(int i=0;i<chkLotWiseApproveRejectItems.length;i++){
 	                	if(!processed.contains(chkLotWiseApproveRejectItems[i].trim())){
	 	                	String[] approvedItem = chkLotWiseApproveRejectItems[i].split("_");
	 	                	TblBidderItems tblBidderItems = new TblBidderItems();
	 	                	tblBidderItems.setTblTender(new TblTender(tenderId));
	 	                	tblBidderItems.setTblTenderEnvelope(new TblTenderEnvelope(priceBidenvelopeId));
	 	                	tblBidderItems.setTblTenderForm(new TblTenderForm(Integer.parseInt(approvedItem[0])));//formId
	 	                	tblBidderItems.setTblTenderTable(new TblTenderTable(Integer.parseInt(approvedItem[1])));//tableId
	 	                	tblBidderItems.setRowId(Integer.parseInt(approvedItem[2]));//rowId
	 	                	tblBidderItems.setTblUserLogin(new TblUserLogin(bidderId));
	 	                	tblBidderItems.setTblCompany(new TblCompany(companyId));
	 	                	tblBidderItems.setCreatedBy(abcUtility.getSessionUserId(request)); // user login id.
	 	                	tblBidderItems.setIsActive(1);//1 for approve items
	 	                	tblBidderItems.setChildId(hdChildId);//1 for approve items
	 	                	tblBidderItems.setIsApproved(1);//1 for approve items
	 	                	bidderItemsList.add(tblBidderItems);
	 	                    processed.add(chkLotWiseApproveRejectItems[i].trim());
 	                	}
 	                }
 	                    	
                 }
                 if(allItems!=null){ // If Lot wise
  	                for(int i=0;i<allItems.length;i++){
  	                	if(!processed.contains(allItems[i].trim())){
 	 	                	String[] approvedItem = allItems[i].split("_");
 	 	                	TblBidderItems tblBidderItems = new TblBidderItems();
 	 	                	tblBidderItems.setTblTender(new TblTender(tenderId));
 	 	                	tblBidderItems.setTblTenderEnvelope(new TblTenderEnvelope(priceBidenvelopeId));
 	 	                	tblBidderItems.setTblTenderForm(new TblTenderForm(Integer.parseInt(approvedItem[0])));//formId
 	 	                	tblBidderItems.setTblTenderTable(new TblTenderTable(Integer.parseInt(approvedItem[1])));//tableId
 	 	                	tblBidderItems.setRowId(Integer.parseInt(approvedItem[2]));//rowId
 	 	                	tblBidderItems.setTblUserLogin(new TblUserLogin(bidderId));
 	 	                	tblBidderItems.setTblCompany(new TblCompany(companyId));
 	 	                	tblBidderItems.setCreatedBy(abcUtility.getSessionUserId(request)); // user login id.
 	 	                	tblBidderItems.setIsActive(1);//1 for approve items
 	 	                	tblBidderItems.setIsApproved(0);//1 for approve items
 	 	                	tblBidderItems.setChildId(hdChildId);//1 for approve items
 	 	                	bidderItemsList.add(tblBidderItems);
 	 	                    processed.add(allItems[i].trim());
  	                	}
  	                }
  	                    	
                  }
                 if(bidderItemsList != null && !bidderItemsList.isEmpty()){
                     isInserted = tenderFormService.addtblBidderItems(bidderItemsList, priceBidenvelopeId,bidderId, companyId,abcUtility.getSessionUserId(request),0,hdChildId,tenderId);
                 }
                 msg = "bidder_evaluated_success";
            	 redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? msg : CommonKeywords.ERROR_MSG_KEY.toString());
             }else{
            	 msg = "msg_rework_in_process";
                 redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? msg : msg );
             }
        	 retVal="etender/buyer/tenderdashboard/"+tenderId+"/8";
        	 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
           }
         } catch (Exception e) {
             exceptionHandlerService.writeLog(e);
         } finally {
        	 	//auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), selectItemsForBiddingLink , setFormItemSelectionPageValue ,tenderId,envelopeId);
         }
         return retVal;
     }
     /**
      * get evaluation rework by Chairperson
      * @Author Lipi Shah
      * @return 
      */
     @RequestMapping(value = "/buyer/evaluationrework/{tenderId}/{envelopeId}/{committeeId}/{sortOrder}/{enc}", method = RequestMethod.GET)
     public String evaluationRework(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("committeeId") int committeeId,@PathVariable("sortOrder") int sortOrder,ModelMap modelMap,HttpServletRequest request) {
         try {
  			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
  			int loginuserid = abcUtility.getSessionUserId(request);
  			TblCommitteeUser committeeUser = tenderFormService.getCommitteeUserDtlByEnvelope(loginuserid,envelopeId,committeeId);
  			int userRoleId = committeeUser.getUserRoleId();
  			int encryptionLevel = committeeUser.getEncryptionLevel();
  			List<Object[]> userRoleDtls = tenderFormService.getUserRoleByCommiteeIdEnvelopId(committeeId,envelopeId);//technical envelopeId
  			List<String> reWorkCommitteeDtls = new ArrayList<String>();
         	for (Object[] objects : userRoleDtls) {
        		 if((Integer)objects[3] == encryptionLevel && (userRoleId+1)==(Integer)objects[1]){
        			 reWorkCommitteeDtls.add(objects[0].toString()+"@@"+objects[2].toString());//officerid@@userName
        		 }
        	}
         	if(encryptionLevel == 1 && userRoleId == 1){//chairperson 1
         		modelMap.addAttribute("askedToLevel", 1);
         	}else if(encryptionLevel == 2 && userRoleId == 1){//chairperson 2
         		modelMap.addAttribute("askedToLevel", 3);
         	}
  			modelMap.addAttribute("evaluationReworkDtls", reWorkCommitteeDtls);
         } catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }finally {
//             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEditFlage==1?evaluationEvaluateLinkId:evaluationReEvaluateLinkId , evaluatebiddersstatusaddpage,tenderId,envelopeId);
         }
         return "/etender/buyer/EvaluationRework";
     }
     
     /**
      * add evaluation rework by chairperson(all level)
      * @Author Lipi Shah
      * @return 
      */
     @RequestMapping(value = "/buyer/addevaluationrework", method = RequestMethod.POST)
     public String addReworkCommittee(HttpServletRequest request, ModelMap modelMap, RedirectAttributes redirectAttributes) {
     	String retVal = REDIRECT_SESSION_EXPIRED;
     	boolean isSuccess =false;
     	String msg = "";
         try {
         	int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))?Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
            int envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId"))?Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
            int askedToLevel = StringUtils.hasLength(request.getParameter("hdAskedToLevel"))?Integer.parseInt(request.getParameter("hdAskedToLevel")):0;
            int sortOrder = StringUtils.hasLength(request.getParameter("hdSortOrder"))?Integer.parseInt(request.getParameter("hdSortOrder")):0;
            String[] officerIds= request.getParameterValues("officerIds");  
            TblEvaluationRework evaluationReworks = tenderFormService.getTblEvaluationReworkByLevel(askedToLevel,tenderId);//Rework request has already been done
	        if(evaluationReworks!=null){
	        	msg = "msg_rework_already_done";
	        }else{
	            List<TblEvaluationRework> tblEvaluationReworkList = new ArrayList<TblEvaluationRework>();
	         	for(String officerId : officerIds){//makers data
	         		TblEvaluationRework tblEvaluationRework = new TblEvaluationRework();
	         		tblEvaluationRework.setOfficerIdAskedTo(Integer.parseInt(officerId));
	         		tblEvaluationRework.setOfficerIdAskedBy(abcUtility.getSessionUserId(request));
	         		tblEvaluationRework.setTenderId(tenderId);
	         		tblEvaluationRework.setEnvelopeId(envelopeId);
	         		tblEvaluationRework.setAskedToLevel(askedToLevel);
	         		tblEvaluationRework.setCstatus(0);
	         		tblEvaluationRework.setIsMandatory(1);
	         		tblEvaluationRework.setCreatedOn(commonService.getServerDateTime());
	         		tblEvaluationReworkList.add(tblEvaluationRework);
	         	}
	         	isSuccess = tenderFormService.addTblEvaluationRework(tblEvaluationReworkList);
	         	if(isSuccess){
	         		isSuccess = setReworkDetails(tblEvaluationReworkList,sortOrder,tenderId,envelopeId);
	         	}
	         	if(isSuccess){
	         		msg = "msg_rework_success";
	         	}else{
	         		msg = CommonKeywords.ERROR_MSG_KEY.toString();
	         	}
	         	
	        }
         	StringBuilder redirectUrl = new StringBuilder();
            redirectUrl.append("redirect:/etender/buyer/tenderdashboard/" + tenderId + "/8"+ encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/8", request));
            retVal = redirectUrl.toString();
         } catch (Exception ex) {
             return exceptionHandlerService.writeLog(ex);
         } finally {
//             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), reconfigureClarificateDateLinkId, getReconfigureConfigureDates, tenderId, 0);
         }
       	redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), msg);
         return retVal;
     }
     /**
      * add evaluation rework details as per sortOrder
      * @author Lipi Shah
      * @return 
      */
     private boolean setReworkDetails(List<TblEvaluationRework> tblEvaluationReworkList,int sortOrder,int tenderId,int envelopeId) throws Exception{
    	 boolean isSuccess = false;
    	 List<TblFinalSubmission> finalSubmissions = new ArrayList<TblFinalSubmission>();
    	 List<TblBidderApprovalDetail> bidderApprovalDetail = new ArrayList<TblBidderApprovalDetail>();
      	 List<Integer> companyList = new ArrayList<Integer>();
      	//Get Company if first env then get from final submission otherwise bidder approval - Start
  		 if(sortOrder == 1){
  			 finalSubmissions = tenderFormService.getTblFinalSubmission(tenderId);
  			 for(TblFinalSubmission tblFinalSubmission : finalSubmissions){
  				 companyList.add(tblFinalSubmission.getTblCompany().getCompanyId());
  			 }
  		 }else{
  			 TblTenderEnvelope tblTenderEnvelope= tenderFormService.getEnvlopeIdAsSortorder((sortOrder-1),tenderId);
  			 bidderApprovalDetail = tenderFormService.getBidderApprovalDetail(tblTenderEnvelope.getEnvelopeId());
  			 for(TblBidderApprovalDetail tblBidderApprovalDetail : bidderApprovalDetail){
  				 companyList.add(tblBidderApprovalDetail.getTblCompany().getCompanyId());
  			 }
  		 }
  		 //end
      	//add bidders for rework
      	 List<TblReworkDetail> tblReworkDetailList = new ArrayList<TblReworkDetail>();
      	 for(TblEvaluationRework evaluationRework:tblEvaluationReworkList){
      	 	 for(Integer companyId :companyList){
      	 		 TblReworkDetail tblReworkDetail  = new TblReworkDetail();
      			 tblReworkDetail.setCompanyId(companyId);
      			 tblReworkDetail.setCstatus(0);
      			 tblReworkDetail.setTblEvaluationRework(new TblEvaluationRework(evaluationRework.getEvalReworkId()));
      			 tblReworkDetailList.add(tblReworkDetail);
      		 }
      	 }
      	 isSuccess = tenderFormService.addTblReworkDetail(tblReworkDetailList);
      	 return isSuccess;
      }
     /**
      * add evaluation rework by makers(not for first level)
      * @author Lipi Shah
      * @return 
      */
     @RequestMapping(value = "/buyer/addevaluationreworkbymakers", method = RequestMethod.POST)
     public String addEvaluationReworkByMakers(HttpServletRequest request, ModelMap modelMap, RedirectAttributes redirectAttributes) {
     	String retVal = REDIRECT_SESSION_EXPIRED;
     	boolean isSuccess =false;
     	String msg = "";
         try {
         	int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))?Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
            int envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId"))?Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
            int committeeId = StringUtils.hasLength(request.getParameter("hdCommitteeId"))?Integer.parseInt(request.getParameter("hdCommitteeId")):0;
            int sortOrder = StringUtils.hasLength(request.getParameter("hdSortOrder"))?Integer.parseInt(request.getParameter("hdSortOrder")):0;
            int loginuserid = abcUtility.getSessionUserId(request);
            TblCommitteeUser committeeUser = tenderFormService.getCommitteeUserDtlByEnvelope(loginuserid,envelopeId,committeeId);
            int userRoleId = committeeUser.getUserRoleId();//2
  			int encryptionLevel = committeeUser.getEncryptionLevel();//2
  			
  			//level 1 members is not applicable for rework
  			int askedToLevel = 0;
	        if(encryptionLevel == 2 && userRoleId == 2){
	        	askedToLevel = 2;//Member 2
	        }

	        TblEvaluationRework evaluationReworks = tenderFormService.getTblEvaluationReworkByLevel(askedToLevel,tenderId);//Rework request has already been done
	        if(evaluationReworks!=null){
	        	msg = "msg_rework_already_done";
	        }else{
	  			List<Object[]> userRoleDtls = tenderFormService.getUserRoleByCommiteeIdEnvelopId(committeeId,envelopeId);//technical
	  			List<String> reWorkCommitteeDtls = new ArrayList<String>();
	         	for (Object[] objects : userRoleDtls) {
	        		 if((Integer)objects[3] == (encryptionLevel-1) && (userRoleId-1)==(Integer)objects[1]){
	        			 reWorkCommitteeDtls.add(objects[0].toString());
	        		 }
	        	 }
	            List<TblEvaluationRework> tblEvaluationReworkList = new ArrayList<TblEvaluationRework>();
	         	for(String officerId : reWorkCommitteeDtls){//chairperson data 
	         		TblEvaluationRework tblEvaluationRework = new TblEvaluationRework();
	         		tblEvaluationRework.setOfficerIdAskedTo(Integer.parseInt(officerId));
	         		tblEvaluationRework.setOfficerIdAskedBy(abcUtility.getSessionUserId(request));
	         		tblEvaluationRework.setTenderId(tenderId);
	         		tblEvaluationRework.setEnvelopeId(envelopeId);
	         		tblEvaluationRework.setCstatus(0);
	         		tblEvaluationRework.setIsMandatory(1);
	         		tblEvaluationRework.setAskedToLevel(askedToLevel);
	         		tblEvaluationRework.setCreatedOn(commonService.getServerDateTime());
	         		tblEvaluationReworkList.add(tblEvaluationRework);
	         	}
	         	isSuccess = tenderFormService.addTblEvaluationRework(tblEvaluationReworkList);
	         	if(isSuccess){
	         		isSuccess = setReworkDetails(tblEvaluationReworkList,sortOrder,tenderId,envelopeId);
	         	}
	         	if(isSuccess){
	         		msg = "msg_rework_success";
	         	}else{
	         		msg = CommonKeywords.ERROR_MSG_KEY.toString();
	         	}
	        }
         	StringBuilder redirectUrl = new StringBuilder();
            redirectUrl.append("redirect:/etender/buyer/tenderdashboard/" + tenderId + "/8"+ encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/8", request));
            retVal = redirectUrl.toString();
         } catch (Exception ex) {
             return exceptionHandlerService.writeLog(ex);
         } finally {
//             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), reconfigureClarificateDateLinkId, getReconfigureConfigureDates, tenderId, 0);
         }
         redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), msg);
         return retVal;
     }
     /**
      * To upload doc for Technical Envelope
      *
      * @param tenderId
      * @param tableId
      * @param modelMap
      * @param request
      * @return
      */
     @RequestMapping(value = "/buyer/uploaddocfortechenv/{tenderId}/{formId}/{isWorkFlow}/{enc}", method = RequestMethod.GET)
     public String uploadDocForTechEnv(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, @PathVariable("isWorkFlow") Integer isWorkFlow, ModelMap modelMap, HttpServletRequest request) {
    	 int clientId = 0;
    	 SessionBean sessionBean = null;
         try {
             modelMap.addAttribute("columnType",tenderFormService.getColumnType());
             tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
             tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
             modelMap.addAttribute("isWorkFlow",isWorkFlow);
             
            clientId = abcUtility.getSessionClientId(request);
     	    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(60, clientId); // Event ID : 60 : Bidding form
     	    int allowedSize = 0;
     	    StringBuilder allowedExt = new StringBuilder();
     	    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
     			allowedSize = lstDocUploadConf.get(0).getMaxSize();
     			allowedExt.append(lstDocUploadConf.get(0).getType());
     			modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
     	    }
     	    int index = allowedExt.toString().indexOf(",");
     	    allowedExt.insert(index + 1, "*.");
     	    while (index >= 0) {
     			index = allowedExt.toString().indexOf(",", index + ",".length());
     			allowedExt.insert(index + 1, "*.");
     	    }

     	    modelMap.addAttribute("allowedExt", allowedExt);
     	    modelMap.addAttribute("allowedSize", allowedSize/1024);
     	    modelMap.addAttribute("linkId", 183); // LinkId : 183 :  prepare form
     	    modelMap.addAttribute("tenderId", tenderId);
     	    modelMap.addAttribute("isTenderDocDownload", "Y");
     	    modelMap.addAttribute("cStatusDoc", 1);
     	    sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
			ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
			int isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
            String certIds[] = null;
            if (clientBean.getIsPkiEnabled() == pkiEnable || (clientBean.getIsPkiEnabled() == pkiEventSpecific && isCertRequired == 1)) {
                certIds = sessionBean.getCertId().split(",");
                if (certIds != null && certIds.length != 0) {
                    modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                }
            }
         } catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormView, viewFormAudit, tenderId, formId);
         }
         return "/etender/buyer/UploadDocForTechEnv";
     }
     
      
      /**
       * Save loading factor added by chairpersions
       * @author bharat
       * @param modelMap
       * @param request
       * @param redirectAttributes
       * @return
       * used to save/edit bidder items
       */
      @RequestMapping(value = "buyer/savebidderloadingfactor", method = RequestMethod.POST)
      public String saveBidderLoadingFactor(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
          String retVal = "redirect:/sessionexpired";
          String proxyColumn[]=request.getParameterValues("hdProxyColumn");
          String proxyColumnData[]=request.getParameterValues("proxyColumnData");
          int companyId = StringUtils.hasLength(request.getParameter("hdCompanyId")) ? Integer.parseInt(request.getParameter("hdCompanyId")) : 0;
          int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
          SessionBean sessionBean = request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
          try {
              if (sessionBean != null) {
            	  Map<Integer,String> proxyDetail = new HashMap<Integer, String>();
                  boolean isInserted = false;
                  
                  if(proxyColumn != null)
                  {
                	  for(int i = 0;i<proxyColumn.length;i++)
                	  {
                		  int cellId = Integer.parseInt(proxyColumn[i]);
                		  proxyDetail.put(cellId , proxyColumnData[i]);
                	  }
                  }
                  if(proxyDetail != null && !proxyDetail.isEmpty()){
                	  isInserted = tenderFormService.updateBidderFactor(proxyDetail, companyId);
                	  if(isInserted){
                		  tenderFormService.deleteLoadingFactorProcess(tenderId,companyId,0);
                	  }
                  }
                  String msg = "";
                  msg = "redirect_loading_factor_formeval";
                  redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? msg : CommonKeywords.ERROR_MSG_KEY.toString());
             	 retVal="etender/buyer/tenderdashboard/"+tenderId+"/7";
             	 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                  
              }
          } catch (Exception e) {
              exceptionHandlerService.writeLog(e);  
          } finally {
         	 	//auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), selectItemsForBiddingLink , setFormItemSelectionPageValue ,tenderId,envelopeId);
          }
          return retVal;
      }
      /**
       * @author Foram
       * used to get opening remarks when twoStageOpening yes
       */
      @RequestMapping(value = "/buyer/openingremarks/{tenderId}/{envelopeId}/{committeeType}/{isView}/{isConsortiumAllowed}/{isShowEncodedName}/{tabId}/{enc}", method = RequestMethod.GET)
      public String getOpeningRemarks(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("committeeType") int committeeType,@PathVariable("isView") boolean isView,@PathVariable("isConsortiumAllowed") int isConsortiumAllowed,@PathVariable("isShowEncodedName") String isShowEncodedName,@PathVariable("tabId") int tabId,ModelMap modelMap,HttpServletRequest request) {
    	  try {	
    		  int sessionUserId = abcUtility.getSessionUserId(request);       	
    		  tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		  
    		  List<Object[]> bidderList = tenderFormService.getApprovalBidderByEnvelope(tenderId,envelopeId,isConsortiumAllowed);
    		  modelMap.put("envelopename",tenderCommonService.getTenderEnvelopeById(envelopeId).getEnvelopeName());
    		  
    		  modelMap.put("biddersList", bidderList);
    		  setIncrementOfficerData(tenderId,envelopeId,committeeType,sessionUserId,isView,modelMap);
    		  //String loginDtls = loginService.getUserLoginById(sessionUserId).getUserName();
    		  StringBuilder loginDtls = new StringBuilder();
    		  List<Object[]> committeeUserList=committeeFormationService.getCommiteeUserDetailsByTenderId(tenderId, envelopeId,committeeType);
    		  for (Object[] objects : committeeUserList) {
				if(sessionUserId == Integer.parseInt(objects[1].toString())){
					loginDtls.append(objects[5].toString() + "@@" + objects[4].toString());
					loginDtls.append("@@" + objects[3].toString());
				}
    		  }    	
    		  modelMap.put("loginUserName",loginDtls);
         } catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidOpeningRemarksLinkId , bidOpeningRemarksAudit,tenderId,envelopeId);
         }
       return "/etender/buyer/OpeningRemarks";
       }
      private void setIncrementOfficerData(int tenderId,int envelopeId,int committeeType,int sessionUserId,boolean isView,ModelMap modelMap){
    	  Map<Object,List<Object>> map = new HashMap<Object, List<Object>>();
		  List<Object> remarks = new ArrayList<Object>();
		  List<Object[]> incOffRemarksName = new ArrayList<Object[]>();
		  List<Object[]> incOffRemarksVal = new ArrayList<Object[]>();
		  if(isView){
			  incOffRemarksName =  tenderFormService.getRemarksOfficer(tenderId,envelopeId,committeeType,0);
			  incOffRemarksVal =  tenderFormService.getIncrementOfficerRem(tenderId,envelopeId,committeeType,0);
		  }else{
			  incOffRemarksName =  tenderFormService.getRemarksOfficer(tenderId,envelopeId,committeeType,sessionUserId);
			  incOffRemarksVal =  tenderFormService.getIncrementOfficerRem(tenderId,envelopeId,committeeType,sessionUserId);
		  }
		  modelMap.put("incOffRemarksName", incOffRemarksName);
		  
		  for(Object[] off : incOffRemarksName){
    		  for(Object[] obj : incOffRemarksVal){
    			  if(off[0].toString().equals(obj[0].toString())){
    				  remarks.add(obj[1].toString()+"@@"+obj[5].toString()+"###"+obj[3].toString());
    			  }
    		  }
    		  map.put(off[0].toString(), remarks);
    		  remarks = new ArrayList<Object>();
		  }
		  modelMap.put("incOfficerRemarks", map);
      }
      
      /**
       * @author Foram
       * used to set opening remarks when twoStageOpening yes
       */
      @RequestMapping(value = "/buyer/saveopeningremarks", method = RequestMethod.POST)
      public String saveOpeningRemarks(RedirectAttributes redirectAttributes, HttpServletRequest request) {
      	boolean success=false;
      	String retVal=REDIRECT_SESSION_EXPIRED;
         int tenderId=0;
         int envelopeId=0;
         int childId=0;
         int committeeType=0;
         int BidderApYorN=0;
         int userRoleId = 0;
         int encryptionLevel = 0;
         int envId=0;
         int isDecryptor = 0;
         String envelopename="";
          try{
         	 int sessionUserId = abcUtility.getSessionUserId(request);
         	String prevformIds="";
         	if(sessionUserId!=0){
                tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;  
 	            envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
 	            envId = StringUtils.hasLength(request.getParameter("hdEnvelopeEnvId")) ? Integer.parseInt(request.getParameter("hdEnvelopeEnvId")):0;
 	            committeeType = StringUtils.hasLength(request.getParameter("hdCommitteeType")) ? Integer.parseInt(request.getParameter("hdCommitteeType")) : 0;
 	        	int hdRowCount = StringUtils.hasLength(request.getParameter("hdRowCount")) ? Integer.parseInt(request.getParameter("hdRowCount")):0;
 	        	int IsConsortiumAllowed = StringUtils.hasLength(request.getParameter("hdIsConsortiumAllowed")) ? Integer.parseInt(request.getParameter("hdIsConsortiumAllowed")):0;
 	        	String IsShowEncodedName = StringUtils.hasLength(request.getParameter("hdIsShowEncodedName")) ? request.getParameter("hdIsShowEncodedName"):"";
 	        	int envlopTypFlg = StringUtils.hasLength(request.getParameter("hdEnvlopTypFlg")) ? Integer.parseInt(request.getParameter("hdEnvlopTypFlg")):0;
 	        	envelopename = tenderCommonService.getTenderEnvelopeById(envelopeId).getEnvelopeName();
 	        	TblCommitteeRemarks tblCommitteeRemarks=null;
 	          	List<TblCommitteeRemarks> tblCommitteeDtls=new ArrayList<TblCommitteeRemarks>();
 	          	List<TblCompany> companyIdForms = new ArrayList<TblCompany>();
 	          	TblBidderApprovalDetail tblBidderApprovalDetail=null;
	          	List<TblBidderApprovalDetail> tblBidderApprovalDtls=new ArrayList<TblBidderApprovalDetail>();
	          	String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
 	          	int userDetailId = abcUtility.getSessionUserDetailId(request);
 	          	String splitStr=null;
 	          	prevformIds = StringUtils.hasLength(request.getParameter("hdPrevFormIds")) ? request.getParameter("hdPrevFormIds") : "";
 	          	if(committeeType==1)
 	          	{
 	          		splitStr="_";
 	          	}
 	          	else
 	          	{
 	          		splitStr="\\|~\\|";
 	          	}
 	            List<Object[]> remarksList = tenderFormService.getRemarks(tenderId,sessionUserId,committeeType,envelopeId,0,-1,-1);
 	          	if(!remarksList.isEmpty()){
 	          	 redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_already_remarks_submitted");
 	          	 retVal = TENDER_DASHBOARD_URL+tenderId+"/"+TAB_TENDER_OPENING;
 	          	}else{
	 	          	for (int i = 0; i < hdRowCount; i++) {
		                 String remarks = StringUtils.hasLength(request.getParameter("txtaRemarks_" + i)) ? request.getParameter("txtaRemarks_" + i) : null;
		                 String allBidderVal = StringUtils.hasLength(request.getParameter("hdAllValues_" + i)) ? request.getParameter("hdAllValues_" + i) : null;
 		                 int isCancelForm = StringUtils.hasLength(request.getParameter("txtisCancelForm_" + i)) ? Integer.parseInt(request.getParameter("txtisCancelForm_" + i)) : 0;		                 
		                 String[] singleBidderVal = (allBidderVal!= null && !allBidderVal.isEmpty()) ? allBidderVal.split(splitStr) : null;
		                 if (singleBidderVal != null) {
		                	 int bidderId=0;
		                	 if(committeeType==1){bidderId = Integer.parseInt(singleBidderVal[0]);}
		                	 else{bidderId = Integer.parseInt(singleBidderVal[2]);}
		                     tblCommitteeRemarks = new TblCommitteeRemarks();
		                     tblCommitteeRemarks.setTblTender(new TblTender(tenderId));
		                     tblCommitteeRemarks.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
		                     tblCommitteeRemarks.setTblCompany(new TblCompany(Integer.parseInt(singleBidderVal[1])));  //companyId
		                     if(isCancelForm==1){
		                    	 tblCommitteeRemarks.setRemarks("All forms are Cancelled");
		                     }else{
		                    	 tblCommitteeRemarks.setRemarks(remarks);
		                     }
		                     tblCommitteeRemarks.setCreatedBy(userDetailId);
		                     tblCommitteeRemarks.setTblUserLogin(new TblUserLogin(sessionUserId));
		                     
		                     tblCommitteeRemarks.setBidderId(bidderId); //bidderId
		                     tblCommitteeRemarks.setIsActive(1);
		                     tblCommitteeRemarks.setChildId(childId);//0
		                     tblCommitteeRemarks.setCommitteeType(committeeType);
		                     
		                     List<Object[]> userRoleList  = tenderFormService.getUserRoleId(tenderId, envelopeId,committeeType,sessionUserId);
		                     if(userRoleList!=null && !userRoleList.isEmpty()){
		                    	 userRoleId = Integer.parseInt(userRoleList.get(0)[0].toString());
		                    	 encryptionLevel = Integer.parseInt(userRoleList.get(0)[1].toString());
		                    	 isDecryptor = Integer.parseInt(userRoleList.get(0)[3].toString());
		                     }
	                    	 if(userRoleId==1){
		                    	 tblCommitteeRemarks.setIsCPRemarks(1);
		                     }else{
		                    	 tblCommitteeRemarks.setIsCPRemarks(0);	 
		                     }
	                    	 encryptionLevel = isDecryptor == 1 ? 0 : encryptionLevel;  
	                    	 if(encryptionLevel==0){
	                    		 tblCommitteeRemarks.setUserRoleId(userRoleId == 1 ? 2 : 1);
	                    	 }else if(encryptionLevel==1){
		                    	tblCommitteeRemarks.setUserRoleId(userRoleId == 1 ? 2 : 1);
		                    }else{
		                    	tblCommitteeRemarks.setUserRoleId(userRoleId == 1 ? 4 : 3);
		                    }
		                     if(committeeType==1){
		                    	 tblCommitteeRemarks.setIsApproved(1); 
		                     }if(committeeType==2){
		                    	 if(isCancelForm==1){
		                    		 BidderApYorN=3;
		                    	 }else{
		                    		 BidderApYorN = StringUtils.hasLength(request.getParameter("rdBidderAprvYesNo_" + i)) ? Integer.parseInt(request.getParameter("rdBidderAprvYesNo_" + i)) : null;
		                    	 }
		                    	 tblCommitteeRemarks.setIsApproved(BidderApYorN); 
		                     }
		                     tblCommitteeDtls.add(tblCommitteeRemarks);
		                     int tenderResult = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "tenderResult").toString());
		                     //0 for Not Set, 1 for Grand Total, 2 for Itemwise,3 for Lotwise
		                     boolean bidderwiseItmApprovalEntry = tenderResult == 2 ? tenderFormService.checkEntryBidderAppDtls(tenderId, envelopeId) : true;
		                     boolean encryptionLevelAllow = encryptionLevel == 2 || encryptionLevel == 0 ? true : false;
		 		          	if(/*bidderwiseItmApprovalEntry && */encryptionLevelAllow && userRoleId==1)
		 		          	{
			 		          	 if((envId==1 || envId==2 || envId==3 || (tenderResult==1)) && (committeeType==2))/*only for technical env*/
			                     {
			 		          		int userDtlId=loginService.getBidderUserDetailId(bidderId);
			                    	tblBidderApprovalDetail = new TblBidderApprovalDetail();
			               			tblBidderApprovalDetail.setTblTender(new TblTender(tenderId));
			                       	tblBidderApprovalDetail.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
			                       	tblBidderApprovalDetail.setTblCompany(new TblCompany(Integer.parseInt(singleBidderVal[1])));
			                       	companyIdForms.add(new TblCompany(Integer.parseInt(singleBidderVal[1])));
			                       	tblBidderApprovalDetail.setTblUserLogin(new TblUserLogin(bidderId));//bidderid
			                       	tblBidderApprovalDetail.setTblUserDetail(new TblUserDetail(userDtlId));//userdetailid
			                       	tblBidderApprovalDetail.setTblFinalSubmission(new TblFinalSubmission(Integer.parseInt(singleBidderVal[0])));
			                       	if(isCancelForm==1){
			                         	tblBidderApprovalDetail.setRemarks("All forms are cancelled");
			                        }else{
			                         	tblBidderApprovalDetail.setRemarks(remarks);
			                        }
			                       	tblBidderApprovalDetail.setCreatedBy(userDetailId);
			                       	tblBidderApprovalDetail.setIsApproved(BidderApYorN);
			                       	tblBidderApprovalDtls.add(tblBidderApprovalDetail);
			                       		
			                       	
			                      //start
			    	              	/*** Start Code to entry in addTenderBidOpenDetails for multiple envelop and in non pki case**/
			                       	if(envlopTypFlg == 2 && !prevformIds.equals("0")){
			        		          	String[] strArray = prevformIds.split(",");
			    		          		List<TblTenderForm> tblTenderFormList = new ArrayList<TblTenderForm>();
			    		          		for(int formcnt = 0 ; formcnt < strArray.length ; formcnt++){
			    		          				tblTenderFormList.add(new TblTenderForm(Integer.parseInt(strArray[formcnt])));
			    		          		}
			    			          	
			    		        		List<TblTenderBid> tblTenderBidList = eventBidSubmissionService.getTenderBid(tenderId, companyIdForms.toArray(),tblTenderFormList.toArray());
			    		        		if(tblTenderBidList != null && !tblTenderBidList.isEmpty()){
			    		        			List<TblTenderOpen> tblTenderOpenList = new ArrayList<TblTenderOpen>();
			    		        			List<TblTenderBidOpenSign> tblTenderBidOpenSignList = new ArrayList<TblTenderBidOpenSign>();
			    		        			List<TblTenderBidDetail> tblTenderBidDetailList = new ArrayList<TblTenderBidDetail>();
			    		        			List<String> userFormIds = new ArrayList<String>();
			    		        			
			    		            		for(TblTenderBid tblTenderBid : tblTenderBidList){
			    		            			String userFormId = tblTenderBid.getTblTenderForm().getFormId() + "~" + tblTenderBid.getTblCompany().getCompanyId(); 
			    		            			if(!userFormIds.contains(userFormId)){
			    			            			TblTenderOpen tblTenderOpen = new TblTenderOpen();
			    			            			tblTenderOpen.setTblTender(tblTenderBid.getTblTender());
			    			            			tblTenderOpen.setTblTenderEnvelope(tblTenderBid.getTblTenderEnvelope());
			    			            			tblTenderOpen.setTblTenderForm(tblTenderBid.getTblTenderForm());
			    			            			tblTenderOpen.setTblCompany(tblTenderBid.getTblCompany());
			    			            			tblTenderOpen.setTblUserLogin(tblTenderBid.getTblUserLogin());
			    			            			tblTenderOpen.setDecryptionLevel(1);
			    			            			tblTenderOpen.setIpAddress(ipAddress);
			    			            			tblTenderOpen.setCreatedBy(userDetailId);
			    			            			tblTenderOpenList.add(tblTenderOpen);
			    		            			}
			    		            			
			    		            			List<TblTenderBidMatrix> tblTenderBidMatrixList = eventBidSubmissionService.getTableBidMatrix(tblTenderBid.getBidId());
			    		            			
			    		            			if(tblTenderBidMatrixList != null && !tblTenderBidMatrixList.isEmpty()){
			    		            				for(TblTenderBidMatrix tblTenderBidMatrix : tblTenderBidMatrixList){
			    		            					TblTenderBidOpenSign tblTenderBidOpenSign = new TblTenderBidOpenSign();
			    		            					tblTenderBidOpenSign.setTblTenderBidMatrix(tblTenderBidMatrix);
			    		            					tblTenderBidOpenSign.setDecryptedBid(tblTenderBidMatrix.getBidJson());
			    		            					tblTenderBidOpenSign.setBidSignText(tblTenderBidMatrix.getBidJson());
			    		            					tblTenderBidOpenSign.setCreatedBy(userDetailId);
			    		            					tblTenderBidOpenSignList.add(tblTenderBidOpenSign);
			    		            					
			    		            					JSONArray jsonArray = new JSONArray(tblTenderBidMatrix.getBidJson());
			    		            					for (int jsoni = 0; jsoni < jsonArray.length(); jsoni++) {
			    		            						JSONObject jSONObject = jsonArray.getJSONObject(jsoni);
			    		            						for (Iterator it = jSONObject.keys(); it.hasNext();) {
			    		            							String key = it.next().toString();
			    		            							String[] keyValues = key.split("_");
			    		            							String jsonValue = jSONObject.getString(key);
			    		            							
			    		            							TblTenderBidDetail tblTenderBidDetail = new TblTenderBidDetail();
			    		            							tblTenderBidDetail.setTblTenderBidMatrix(tblTenderBidMatrix);
			    		            							tblTenderBidDetail.setTblTenderCell(new TblTenderCell(Integer.parseInt(keyValues[0])));
			    		            							tblTenderBidDetail.setCellNo(Integer.parseInt(keyValues[1]));
			    		            							tblTenderBidDetail.setCellValue(jsonValue);
			    		            							tblTenderBidDetailList.add(tblTenderBidDetail);
			    		                                    }
			    		            					}
			    		            				}
			    		            			}
			    		            		}
			    		            		success = tenderFormService.addBidderAprvalDtls(tblBidderApprovalDtls,tblTenderOpenList, tblTenderBidOpenSignList, tblTenderBidDetailList);
			    		        		}

				    		        		
			    		        		
			    		          	}/*** End Code to entry in addTenderBidOpenDetails for multiple envelop and in pki case**/
			    		          	else
			    		          	{
			    		          		/*** Start Code to insert in TblBidderApprovalDetail table and insert in history table**/
			    		          		tblBidderApprovalDtls.add(tblBidderApprovalDetail);
			    		          	}
			    	              	//end
			                       	
			                     }
		 		          	}
		                 }
		                
		            }
	 	          	success = tenderFormService.addRemarksDetails(tblCommitteeDtls);
	 	          	if (success) {
                        String txtHidDocIds = CommonUtility.checkNull(request.getParameter("txtHidDocIdss"));
                        
                        if (!"".equalsIgnoreCase(txtHidDocIds)) {
                        	success = fileUploadService.updateOfficerDocsObjectId(txtHidDocIds, envelopeId,sessionUserId,0);
                        }
                	}
	 	          	if(tblBidderApprovalDtls.size()!=0){
	 	          		tenderFormService.addEachBidderAprvalDtls(tblBidderApprovalDtls);
	 	          	}
	 	          	if(success && isEvaluationDone(tenderId)){
		        		/*Generate system generate Weightage L1 Report*/
		        		List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isWeightageEvaluationRequired,isItemwiseWinner");
		           		int isWeightageEvaluationRequired = 0;
		           		if(tenderDetails!= null && !tenderDetails.isEmpty()){
		           			isWeightageEvaluationRequired =Integer.parseInt(tenderDetails.get(0)[0].toString());
		           		}
		           		if(isWeightageEvaluationRequired == 1){
		           			TblDynReport tblDynReport  = dynamicReportService.getDynReportById(tenderId,5);
		           			if(tblDynReport!=null)
		           				dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(),tenderId,abcUtility.getSessionUserId(request));
		           		}
		        	}
	 	          	/**
	        		 * Bug #60417 System should "Configure date" if auto next envelop opening date set as "YES"
	        		 */
	 	          	if(success && committeeType==2){
    		          		List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isNextEnvOpeningDateAuto,nextEnvOpeningDateSetAfter");
    		           		int isNextEnvOpeningDateAuto = 0;
    		           		int nextEnvOpeningDateSetAfter = 0;
    		           		if(tenderDetails!= null && !tenderDetails.isEmpty()){
    		           			isNextEnvOpeningDateAuto =Integer.parseInt(tenderDetails.get(0)[0].toString());
    		           			nextEnvOpeningDateSetAfter = Integer.parseInt(tenderDetails.get(0)[1].toString());
    		           		}
    		           		if(isNextEnvOpeningDateAuto == 1){
    			          		 List<Object> lstEvaluationDateAndTime =eventCreationService.getOfficerEvaluationDateAndTime(tenderId,envelopeId);
    			          		List<Object[]>  envlist = tenderFormService.getTenderEnvelopeList(tenderId);
    			          		int nextEnvId = 0;
    			          		String nextOpeningDate = "";
    			          		if(envlist!=null && !envlist.isEmpty()){
    			          			for(Object[] envlst  :envlist){
    			          				if(Integer.parseInt(envlst[3].toString())==0){
    			          					nextEnvId = Integer.parseInt(envlst[2].toString());
    			          					break;
    			          				}
    			          			}
    			          		}
    			          		if(lstEvaluationDateAndTime!=null && !lstEvaluationDateAndTime.isEmpty() && nextEnvId!=0){
    			          			Date approveddate = (Date) lstEvaluationDateAndTime.get(0);
    			             	    Calendar cal = 	Calendar.getInstance();
    			             		cal.setTime(approveddate);
    			             		cal.add(Calendar.MINUTE,nextEnvOpeningDateSetAfter);
    			             		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    			             		nextOpeningDate = sdf.format(cal.getTime());
    			             		success=tenderOpenService.updatePriceBidOpeningDate(tenderId,nextEnvId,nextOpeningDate);
    			          		}
    			          		 
    		           		}
	 	          	}
	 	          	if(committeeType==1){
	 	 	          	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_remarks_submitted" : CommonKeywords.ERROR_MSG_KEY.toString());
	 	 	          	retVal=success?TENDER_DASHBOARD_URL+tenderId+"/"+TAB_TENDER_OPENING:"/etender/buyer/openingremarks/"+tenderId+"/"+envelopeId+"/"+1+"/"+false+"/"+IsConsortiumAllowed+"/"+IsShowEncodedName;
	                }if(committeeType==2){
	     	          	retVal=success?TENDER_DASHBOARD_URL+tenderId+"/"+TAB_EVALUATE_BID:"/etender/buyer/evaluatebidders/"+tenderId+"/"+envelopeId+"/"+1;
	     	    		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	     	    		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_evaluate_bidders_status_add" : CommonKeywords.ERROR_MSG_KEY.toString());
	     	    		return retVal;
	                }
	         	} 	
         	}	
          }catch(Exception e){
          	return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidOpeningRemarksLinkId , success ? envelopename + " " + postBidOpeningRemarksSuccessAudit : envelopename + " " +postBidOpeningRemarksFailedAudit ,tenderId,envelopeId);
          }
   		 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
         return retVal;
      }
      @RequestMapping(value = {"/buyer/tenderdocaszipchildid/{tenderId}/{objectId}/{childId}/{enc}"}, method = RequestMethod.GET)
      public String tenderDocAsZipWithChildId(@PathVariable("tenderId")Integer tenderId,@PathVariable("objectId")Integer objectId,@PathVariable("childId")Integer childId,HttpServletRequest request ,HttpServletResponse response,RedirectAttributes redirectAttributes){
      	try {
              String envelopeName = abcUtility.correctFileName(tenderCommonService.getTenderEnvelopeById(objectId).getEnvelopeName());
              String companyName = abcUtility.correctFileName(loginService.getUserDetailId(childId)[2].toString());
              String filePath=docUploadPath+"\\"+abcUtility.getSessionClientId(request)+"\\Tender\\BidEvaluation\\"+envelopeName+"_"+tenderId;
              File  zfile = new File(filePath+".zip");
              List<Object[]> officerDocs = fileUploadService.getOfficerDocsDynamic(String.valueOf(objectId),String.valueOf(childId),String.valueOf(abcUtility.getSessionClientId(request)),String.valueOf(evaluationEvaluateLinkId),"1",String.valueOf(0));
              List<String[]> approvedDoc = new ArrayList<String[]>();
          
              ServletOutputStream outputStream = null;
              boolean isZipAvail = true;
              for (Object[] docs : officerDocs) {
                  String[] approvedDocsArr = new String[5];
                  approvedDocsArr[0]=docs[1].toString();
                  approvedDocsArr[1]=docs[5].toString();
                  approvedDocsArr[2]=docs[6].toString();
                  approvedDocsArr[3]=docs[7].toString();
                  approvedDocsArr[4]=docs[8].toString();
                  approvedDoc.add(approvedDocsArr);
              }
              String souceFilePath="";
              String mainFilePath="";
               if(approvedDoc.size()!=0){
                  souceFilePath = docUploadPath + "\\" + abcUtility.getSessionClientId(request)+ "\\" + "BidEvaluation" + "\\"+tenderId;
                  mainFilePath = souceFilePath; 
                  File tempDir = new File(souceFilePath+ "\\" + companyName);
                	  tempDir.mkdirs();
                	  for (String[] str : approvedDoc) {
                		  File tempsubDir = new File(tempDir, abcUtility.correctFileName(commonService.getUserName(Integer.parseInt(str[4].toString()))));
                          if (!tempsubDir.isDirectory()) {
                        	  tempsubDir.mkdirs();
                          }
                          String soruceFilePath = docUploadPath + "\\" +str[3] +"\\"+ str[0]; 
                          File file = new File(soruceFilePath);
                          file = abcUtility.CheckDirExist(file);
                          if (file.exists()) {
                        	  FileCopyUtils.copy(file,new File(tempsubDir.getPath()+"\\"+str[0]));
                          }
					}
                  File dir = new File(souceFilePath);
                  dir = abcUtility.CheckDirLength(dir);
                  if(dir.exists() && dir.list().length!=0){
                      abcUtility.zipDirectory(dir, zfile,approvedDoc);
                  }else{
                      isZipAvail = false;
                  }
                  FileUtils.deleteDirectory(new File(mainFilePath));
              }else{
                   isZipAvail = false;
              } 
              response.setContentType("application/octet-stream");
              if (isZipAvail) {
                  FileInputStream fis = new FileInputStream(zfile);
                  byte[] buf = new byte[(int) zfile.length()];
                  int offset = 0;
                  int numRead = 0;
                  while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                      offset += numRead;
                  }
                  response.setContentType("application/octet-stream");
                  response.setHeader("Content-Disposition", "attachment;filename=\"" + zfile.getName() + "\"");
                  outputStream = response.getOutputStream();
                  outputStream.write(buf);
                  outputStream.flush();
                  outputStream.close();

                  return null;
              } else {
                  redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_tender_nodocforzip");
                  String refererUrl = request.getHeader("referer");
                  return "redirect:" + refererUrl.substring(refererUrl.indexOf(contextName) + 5, refererUrl.length());
              }
          } catch (Exception ex) {
              return exceptionHandlerService.writeLog(ex);
          }
      }  
    @RequestMapping(value = "/buyer/evaluationremarks/{tenderId}/{envelopeId}/{envlopTypFlg}/{sortOrder}/{preEnvelopeId}/{committeeType}/{reEvaluationId}/{enc}", method = RequestMethod.GET)
    public String getEvaluateRemarks(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("envlopTypFlg") int envlopTypFlg,@PathVariable("sortOrder") int sortOrder,@PathVariable("preEnvelopeId") int preEnvelopeId ,@PathVariable("committeeType") int committeeType,@PathVariable("reEvaluationId") int reEvaluationId,ModelMap modelMap,HttpServletRequest request) {
        int createoredit=0;
        int oldReEvaluationId=0;
        int reEvaluateFlag=0;
     try {
	    int sessionUserId = abcUtility.getSessionUserId(request);       	
     	  	
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
			TblTenderEnvelope tblTenderEnvelope = tenderCommonService.getTenderEnvelopeById(envelopeId);
			List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "isConsortiumAllowed,isCertRequired,isEncodedName");
			int isConsortiumAllowed = Integer.parseInt(tenderFields.get(0)[0].toString());
			/** Changes done to show encoded bidder name for Bug #50576 **/
			int isEncodedName = Integer.parseInt(tenderFields.get(0)[2].toString());
			modelMap.addAttribute("isEncodedName",isEncodedName);
			List <EvaluateBiddersDataBean> evaluateBiddersList = new ArrayList<EvaluateBiddersDataBean>();
			@SuppressWarnings("unchecked")
			Map<String,Object> evaluateBiddersListPro = (Map<String,Object>) tenderFormService.getEvaluateBiddersList(tenderId, envelopeId, preEnvelopeId,envlopTypFlg,isConsortiumAllowed, sortOrder, 1);
			List<Map<String,Object>> evaluateBiddersListObj = (List<Map<String,Object>>) evaluateBiddersListPro.get(RESULT_SET_1);
//			List<Map<String,Object>> nextEnvelopFormIds = (List<Map<String,Object>>) evaluateBiddersListPro.get(RESULT_SET_2);
			if(!evaluateBiddersListObj.isEmpty()){
				for(Map<String,Object> evalMap:evaluateBiddersListObj){
                                        EvaluateBiddersDataBean evaluateBiddersDB = new EvaluateBiddersDataBean();
					evaluateBiddersDB.setBidderIds(evalMap.get("bidderIds").toString());
					evaluateBiddersDB.setCompanyName(evalMap.get("companyName").toString().substring(0,evalMap.get("companyName").toString().length()-1));
					evaluateBiddersDB.setBidderApprovalId(evalMap.get("bidderApprovalId").toString());
					evaluateBiddersDB.setRemarks(evalMap.get("remarks").toString());
					evaluateBiddersDB.setIsApproved(evalMap.get("isApproved").toString());
					evaluateBiddersDB.setEncodedName(evalMap.get("encodedName").toString());
					evaluateBiddersList.add(evaluateBiddersDB);
				}
			}
			modelMap.put("tabId", TAB_EVALUATE_BID);
			modelMap.put("tenderId", tenderId);
			modelMap.put("envelopeId", envelopeId);
			modelMap.put("evaluateBiddersMap", evaluateBiddersList);
			modelMap.put("tblTenderEnvelope",tblTenderEnvelope);
//			modelMap.put("envlopTypFlg",envlopTypFlg);
			modelMap.put("sortOrder",sortOrder);
			modelMap.put("committeeType",committeeType);
//			modelMap.put("isCertRequired",isCertRequired);
			//get the remarks details.for the all the cheker/maker.
                        List<Object[]> committeeUserList=committeeFormationService.getCommiteeUserDetailsByTenderId(tenderId, envelopeId,2);
                        List<Object[]> committeeRemarksList=committeeFormationService.getCommiteeRemarksDetails(tenderId, envelopeId);
                        Map<String,String> officerIdNameMap = new HashMap<String, String>();
                        Map<String,String> bidderRemarksMap = new HashMap<String, String>();
                        Map<String,ArrayList<String>> roleMap = new LinkedHashMap<String, ArrayList<String>>();
                        int committeeId=0;
                        Map<String,String> officerRoleMap=new HashMap<String, String>();
                        for(Object[] cmuObj: committeeUserList){
                            officerRoleMap.put(cmuObj[1].toString(), cmuObj[3].toString()+cmuObj[4].toString());//officerId,userRole+enclevel
  //                          officerSeqList.add(cmuObj[1].toString());
                            committeeId=Integer.parseInt(cmuObj[6].toString());
                            officerIdNameMap.put(cmuObj[1].toString(),cmuObj[5].toString());
                            String rolLevel="0";
                            if(cmuObj[4].equals(1) && cmuObj[2].equals(2))
                            {
                                    rolLevel = "1"; 
                            }else if(cmuObj[4].equals(1) && cmuObj[2].equals(1))
                            {
                                    rolLevel = "2"; 
                            }else if(cmuObj[4].equals(2) && cmuObj[2].equals(2))
                            {
                                    rolLevel = "3"; 
                            }else if(cmuObj[4].equals(2) && cmuObj[2].equals(1))
                            {
                                    rolLevel = "4"; 
                            }
                            if(roleMap.containsKey(rolLevel)){
                                    roleMap.get(rolLevel).add(cmuObj[1].toString());
                            }else{
                                    ArrayList<String> arr = new ArrayList<String>();
                                    arr.add(cmuObj[1].toString());
                                    roleMap.put(rolLevel,arr);

                                    ArrayList<String> arr1 = new ArrayList<String>();
                                    arr1.add(cmuObj[1].toString());

                            }
                            if(sessionUserId == Integer.parseInt(cmuObj[1].toString()))
                            {
                                    modelMap.addAttribute("loginUserRole",rolLevel);
                            }
                        }
                         modelMap.addAttribute("roleMap",roleMap);
                         int currentUserRole =Integer.parseInt(modelMap.get("loginUserRole").toString());
                            if(currentUserRole > 1){
                                   modelMap.addAttribute("allowReworkLink",tenderFormService.isReworkLinkAllow(currentUserRole,tenderId));
                            }else{
                                   modelMap.addAttribute("allowReworkLink",false);
                            }
                        for(Object[] crObj: committeeRemarksList){
                            if(Integer.parseInt(crObj[3].toString()) == sessionUserId  ){
                                oldReEvaluationId = Integer.parseInt(crObj[6].toString());
                                createoredit = 1;
                                if(reEvaluationId == oldReEvaluationId){
                                     reEvaluateFlag = 1;
                                }
                            } 
                          
                           bidderRemarksMap.put(crObj[2].toString()+"_"+crObj[3].toString(), crObj[4].toString());//bidderId_officerId,remarks
                        }
  //                      modelMap.put("currentUserRole",LoginUserRole);
  //                      modelMap.put("officerSeqList",officerSeqList);
                        modelMap.put("officerRoleMap",officerRoleMap);
  //                      modelMap.put("committeeUserList",committeeUserList);
  //                      modelMap.put("committeeRemarksList",committeeRemarksList);
                        modelMap.put("bidderRemarksMap",bidderRemarksMap);
                        modelMap.put("officerIdNameMap",officerIdNameMap);
                        modelMap.put("isRemarksView",createoredit);
                        modelMap.put("reEvaluationId",reEvaluationId);
                        modelMap.put("reEvaluateFlag",reEvaluateFlag);
                        modelMap.put("committeeId",committeeId);
                        
       } catch (Exception e) {
           return exceptionHandlerService.writeLog(e);
       }finally {
           auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createoredit==1?evaluationEvaluateLinkId:evaluationReEvaluateLinkId , evaluatebiddersstatusaddpage,tenderId,envelopeId);
       }
       return "/etender/buyer/EvaluateRemarks";
   }

   @RequestMapping(value = "/buyer/saveevaluateremarks", method = RequestMethod.POST)
     public String saveEvaluateRemarks(RedirectAttributes redirectAttributes, HttpServletRequest request) {
     	boolean success=false;
     	String retVal=REDIRECT_SESSION_EXPIRED;
        int tenderId=0;
        int envelopeId=0;
        int childId=0;
        int loginUserRole=0;
        int committeeType=0;
         try{
        	 int sessionUserId = abcUtility.getSessionUserId(request);
        	if(sessionUserId!=0){
                    tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;  
	            envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
	            String eventType=StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
	            committeeType = StringUtils.hasLength(request.getParameter("hdCommitteeType")) ? Integer.parseInt(request.getParameter("hdCommitteeType")) : 0;
	            childId = StringUtils.hasLength(request.getParameter("hdReEvaluationId")) ? Integer.parseInt(request.getParameter("hdReEvaluationId")):0;
	            loginUserRole = StringUtils.hasLength(request.getParameter("hdLoginUserRole")) ? Integer.parseInt(request.getParameter("hdLoginUserRole")):0;
	            
	        	int hdRowCount = StringUtils.hasLength(request.getParameter("hdRowCount")) ? Integer.parseInt(request.getParameter("hdRowCount")):0;
	        	TblCommitteeRemarks tblCommitteeRemarks=null;
	          	List<TblCommitteeRemarks> tblCommitteeDtls=new ArrayList<TblCommitteeRemarks>();
	          	
	          	int userDetailId = abcUtility.getSessionUserDetailId(request);
	          	for (int i = 0; i < hdRowCount; i++) {
                              
                                String remarks = StringUtils.hasLength(request.getParameter("txtaRemarks_" + i)) ? request.getParameter("txtaRemarks_" + i) : null;
                                String allBidderVal = StringUtils.hasLength(request.getParameter("hdAllValues_" + i)) ? request.getParameter("hdAllValues_" + i) : null;
                                String[] singleBidderVal = allBidderVal.split("\\|~~~\\|");
                                if (singleBidderVal != null) {
                                    for (int j = 0; j < singleBidderVal.length; j++) {
                                        String[] singleBidderIds = singleBidderVal[j].split("\\|~\\|");
                                        if (singleBidderVal != null) {

                                            tblCommitteeRemarks = new TblCommitteeRemarks();
                                            tblCommitteeRemarks.setTblTender(new TblTender(tenderId));
                                            tblCommitteeRemarks.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
                                            tblCommitteeRemarks.setTblCompany(new TblCompany(Integer.parseInt(singleBidderIds[1])));  //companyId
                                            tblCommitteeRemarks.setRemarks(remarks);
                                            tblCommitteeRemarks.setCreatedBy(userDetailId);
                                            tblCommitteeRemarks.setTblUserLogin(new TblUserLogin(sessionUserId));
                                            if(loginUserRole == 2 || loginUserRole == 4){
                                                tblCommitteeRemarks.setIsCPRemarks(1);
                                            }
                                            else{
                                                tblCommitteeRemarks.setIsCPRemarks(0);
                                            }
                                            tblCommitteeRemarks.setBidderId(Integer.parseInt(singleBidderIds[2])); //bidderId
//                                            companyIds.add(new TblCompany(Integer.parseInt(singleBidderIds[1])));
                                            tblCommitteeRemarks.setIsActive(1);
                                            tblCommitteeRemarks.setChildId(childId);
                                            tblCommitteeRemarks.setCommitteeType(committeeType);
                                            tblCommitteeDtls.add(tblCommitteeRemarks);
                                        }
                                    }
                                }
                           }
	          	success = tenderFormService.addCommiteeRemarksDetails(tblCommitteeDtls,tenderId,envelopeId,sessionUserId,childId);	
        	} 		
          		
         }catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), evaluationEvaluateLinkId, success ? evaluatebiddersstatusadd : evaluatebiddersstatusaddfail,tenderId,envelopeId);
         }
         retVal=success?TENDER_DASHBOARD_URL+tenderId+"/"+TAB_EVALUATE_BID:"/etender/buyer/evaluatebidders/"+tenderId+"/"+envelopeId+"/"+1;
  		 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
  		 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_evaluate_bidders_status_add" : CommonKeywords.ERROR_MSG_KEY.toString());
         return retVal;
     }
   
   /**
    * Loading before. Get bidder items , Only those items will be seen which has loading factor as column type in its table, and if have encryption not req. column then this form should be approve.
    * @author bharat
    * @param tenderId
    * @param bidderId
    * @param companyId
    * @param modelMap
    * @param request
    * @return
    */
    @RequestMapping(value = "/buyer/evaluatebidloadingfactor/{tenderId}/{bidderId}/{companyId}/{enc}", method = RequestMethod.GET)
    public String getEvaluateBiddersItemWsie(@PathVariable("tenderId") int tenderId,@PathVariable("bidderId") int bidderId ,@PathVariable("companyId") int companyId, ModelMap modelMap,HttpServletRequest request) {
   	 String page="";
           try {
          	 	Map<Integer,Map<String,Object>> formMap = new LinkedHashMap<Integer, Map<String,Object>>();
          	 	List<Object[]> formList = tenderFormService.getTenderApprovedPriceBidForm(tenderId);
          	    Map<Object,String> encReqFieldValue = new HashMap<Object, String>();
          	    Map<Object,String> proxyBidValue = new HashMap<Object, String>();
          	    Map<Object,Object> encReqFormMap = new HashMap<Object, Object>();
             	    Map<Object,Object> encReqTableMap = new HashMap<Object, Object>();
             	   Map<Object,Object> haveEncReqFormMap = new HashMap<Object, Object>();
            	    Map<Object,Object> haveEncReqTableMap = new HashMap<Object, Object>();
            	    Map<String,String> bidderCellValues = new HashMap<String, String>();
             	    int loginUserId = abcUtility.getSessionUserId(request);
	             	for(Object[] obj : formList)
	             	{
	             		Map<String,Object> map = new HashMap<String, Object>();
	             		int envelopformId = Integer.parseInt(obj[0].toString());
	             		tenderFormService.setViewFormNFormula(envelopformId, map, tenderId);
	             		formMap.put(envelopformId, map);
	             		modelMap.put("envelopeId",obj[2]);
	             		List<Object> cellIdList = new ArrayList<Object>();
	            		tenderFormService.getBidDetailTblValue(envelopformId,encReqFieldValue,companyId,cellIdList);
	            		if(cellIdList != null && !cellIdList.isEmpty()){
	            			tenderFormService.getFormTableMap(cellIdList,haveEncReqFormMap,haveEncReqTableMap);
	            		}
	            		
	            		List<Object[]> cellValue = tenderFormService.getBidderBid(companyId,envelopformId);
	                    for (Object[] tblTenderBid : cellValue) {
	                    	bidderCellValues.put(companyId + "_" + (Integer)tblTenderBid[0], tblTenderBid[1].toString());
	                    }
	             	}
	             	List<Integer> officerList =  new ArrayList<Integer>();
	            	officerList.add(loginUserId);
	             	List<Object[]> bidderItemsSelectedByOfficerList = tenderFormService.getBidderItemssByOfficer(tenderId,bidderId,officerList);
	            	officerList.clear();
	                if(bidderItemsSelectedByOfficerList != null && !bidderItemsSelectedByOfficerList.isEmpty())
		           	 {
		           		 Map<String,String> itemSelected = new HashMap<String, String>();
		           		 
		           		 
		           		 for(Object[] obj : bidderItemsSelectedByOfficerList)
		           		 {
		           			itemSelected.put(obj[0]+"_"+obj[1]+"_"+obj[2],obj[6].toString()); // selected item flag
		           			if(obj[6].equals(1)){
			           			encReqFormMap.put(obj[0], obj[0]);
			           			encReqTableMap.put(obj[1], obj[1]);
		           			}
		           			
		           		 }
		           		 modelMap.addAttribute("itemSelected",itemSelected);
		           	 }
	                modelMap.put("bidderCellValues",bidderCellValues);
	             	modelMap.put("encReqFormMap", encReqFormMap);
	            	modelMap.put("encReqTableMap", encReqTableMap);
	            	modelMap.put("haveEncReqFormMap", haveEncReqFormMap);
	            	modelMap.put("haveEncReqTableMap", haveEncReqTableMap);
	            	
	             	modelMap.put("formList", formMap);
	           		modelMap.put("encReqFieldValue", encReqFieldValue);
	           		List<Object[]> proxyBidList = tenderFormService.getProxyBidTblValue(tenderId,companyId);
	           		if(proxyBidList != null && !proxyBidList.isEmpty())
	                {
	                	for(Object[] obj : proxyBidList){
	                		proxyBidValue.put(obj[0], obj[1].toString());
	                	}
	                }
	           		modelMap.put("proxyBidValue", proxyBidValue );
	                // Get flag for bidded item by bidder. 
	                List<Object[]> bidderBiddedList = tenderFormService.getBidderItems(tenderId,bidderId,0,false);
	                if(bidderBiddedList != null && !bidderBiddedList.isEmpty())
		           	 {
		           		 Map<String,String> biddedMap = new HashMap<String, String>();
		           		 Map<Object,Object> selectedFormMap = new HashMap<Object, Object>();
		           		 Map<Object,Object> selectedTableMap = new HashMap<Object, Object>();
		           		 for(Object[] obj : bidderBiddedList)
		           		 {
		           			 biddedMap.put(obj[0]+"_"+obj[1]+"_"+obj[2],obj[6].toString()); // Bidded item flag
		           			 if(obj[6].equals(1)){
			           			selectedFormMap.put(obj[0], obj[0]);
			           			selectedTableMap.put(obj[1], obj[1]);
		           			 }
		           		 }
		           		 modelMap.addAttribute("biddedMap",biddedMap);
		           		 modelMap.addAttribute("selectedTableMap",selectedTableMap);
		           		modelMap.addAttribute("selectedFormMap",selectedFormMap);
		           	 }
	                modelMap.addAttribute("companyName", commonService.getCompanyNameByCompanyId(companyId));
	 	        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	 	        	 
	 	            page = "/etender/buyer/EvaluateBidLoadingFactor";
	             
	 	            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
           } catch (Exception e) {
               return exceptionHandlerService.writeLog(e);
           }finally {
           //    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), selectItemsForBiddingLink , getFormItemSelectionPage,tenderId,envelopeId);
           }
           return page;
       }      
	  
     /**
      * Give list of form in wihcih loading factor is inserted and approved and bidded.
      * @author bharat
      * @param tenderId
      * @param bidderId
      * @param companyId
      * @param tabId
      * @param modelMap
      * @param request
      * @return
      */
     @RequestMapping(value = "/buyer/evaluateforms/{tenderId}/{bidderId}/{companyId}/{tabId}/{enc}", method = RequestMethod.GET)
     public String evaluateForms(@PathVariable("tenderId")int tenderId,@PathVariable("bidderId")int bidderId ,@PathVariable("companyId")int companyId,@PathVariable("tabId")int tabId, ModelMap modelMap,HttpServletRequest request) {
    	 String retVal="";
         try {
        	 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	 List<Object[]> approvedFormList = tenderFormService.getApprovedFormsBeforeAfterLoading(tenderId, companyId);
        	 List<Object[]> approvedFormListAfterUpdate = tenderFormService.getApprovedFormsAfterLoading(tenderId, companyId);
        	 List<Object[]> processedForm = tenderFormService.getLoadingFactorProcessDetail(tenderId,0,companyId);
        	 Map<Object,Boolean> formMaped = new HashMap<Object, Boolean>();
        	 Map<Object,Boolean> formLoadingUpdateMaped = new HashMap<Object, Boolean>();
        	 if(processedForm  != null && !processedForm.isEmpty()){
        		 for(Object[] obj : processedForm )
        		 {
        			 formMaped.put(obj[1], true);
        		 }
        		 modelMap.put("formMaped",formMaped);
        	 }
        	 if(approvedFormListAfterUpdate !=null && !approvedFormListAfterUpdate.isEmpty())
        	 {
        		 for(Object[] obj : approvedFormListAfterUpdate )
        		 {
        			 formLoadingUpdateMaped.put(obj[0], true);
        		 }
        		 modelMap.put("formLoadingUpdateMaped",formLoadingUpdateMaped);
        	 }
    		 modelMap.put("approvedFormList",approvedFormList);
    		 modelMap.put("isNegotiationAllowedAndIsStarted", negotiationService.isNegotiationAllowedAndNegotiationStarted(tenderId,negotiation_negotiation_process_invite_for_negotiation));
        	 retVal="etender/buyer/EvaluateForms";
         }catch(Exception e){
          	return exceptionHandlerService.writeLog(e);
         }finally {
//              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, evaluateApprovedBidders,tenderId,envelopeId);
         }
         return retVal;
    }
     
       
     /**
      * @auther calculate loding factor for all the company& all the form.
      * @param tenderId
      * @param companyIdFormIds
      * @param tabId
      * @param processCnt
      * @param modelMap
      * @param request
      * @return 
      */
     @RequestMapping(value = "/buyer/getsaveloadingall/{tenderId}/{companyIdsFormIds}/{tabId}/{processcnt}/{enc}", method = RequestMethod.GET)
     public String getsaveloadingall(@PathVariable("tenderId")int tenderId,@PathVariable("companyIdsFormIds")String companyIdFormIds,@PathVariable("tabId")int tabId,@PathVariable("processcnt")int processCnt, ModelMap modelMap,HttpServletRequest request) {
         String retVal=processGetLoading(tenderId, companyIdFormIds, 0, 0, tabId, modelMap, request,processCnt,0);
         return retVal; 
     }
     
     /**
      * Loading after. Get bidder items , Only those items will be seen which has loading factor as column type in its table, and if have encryption not req. column then this form should be approve. 
      * @author janak
      * @param tenderId
      * @param formId
      * @param companyId
      * @param bidderId
      * @param modelMap
      * @param request
      * @return
      */
     @RequestMapping(value = "/buyer/evaluatebidderfactor/{tenderId}/{formId}/{companyId}/{bidderId}/{tabId}/{isEdit}/{enc}", method = RequestMethod.GET)
     public String evaluateBidderFactor(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") String formId, @PathVariable("companyId") Integer companyId,@PathVariable("bidderId") Integer bidderId,@PathVariable("tabId") Integer tabId,@PathVariable("isEdit") Integer isEdit, ModelMap modelMap, HttpServletRequest request) {
    	 modelMap.addAttribute("tabId",tabId);
    	 String retVal=processGetLoading(tenderId, formId, companyId, bidderId, tabId, modelMap, request,-1,isEdit);
         return retVal;   
     }
     
     /**
      * Process Get Loding function
      * @param tenderId
      * @param companyIdsFormIds
      * @param companyId
      * @param bidderId
      * @param tabId
      * @param modelMap
      * @param request
      * @param processCnt
      * @return 
      */
     private String processGetLoading(int tenderId,String companyIdsFormIds,int companyId,int bidderId,int tabId,ModelMap modelMap,HttpServletRequest request,int processCnt,int isEdit){
         Map<Integer,String> cellValues = new HashMap<Integer, String>();
         int formId=0;
         try {
             String companyFormId="";
             if(processCnt!=-1){
                companyFormId=companyIdsFormIds.split(",")[processCnt];
                companyId=Integer.parseInt(companyFormId.split("-")[0]);
                formId=Integer.parseInt(companyFormId.split("-")[1]);
                modelMap.addAttribute("processCnt", processCnt);
                modelMap.addAttribute("companyIdsFormIds", companyIdsFormIds);
                modelMap.addAttribute("formId", formId);
                modelMap.addAttribute("companyId",companyId);
                modelMap.addAttribute("bidderId",0);
                
             }
             else{
                formId=Integer.parseInt(companyIdsFormIds);
                modelMap.addAttribute("companyId",companyId);
            }
             modelMap.addAttribute("frombidfactor",true);
             int clientId = abcUtility.getSessionClientId(request);
             modelMap.put("clientId", clientId);
             tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
             tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
             modelMap.addAttribute("decimalUpto",tenderCommonService.getTenderField(tenderId, "decimalValueUpto"));
             List<Object[]> cellValue = tenderFormService.getBidderBid(companyId,formId);
             Set<Integer> bidTableId = new HashSet<Integer>();
             for (Object[] tblTenderBid : cellValue) {
                 cellValues.put((Integer)tblTenderBid[0], tblTenderBid[1].toString());
                 bidTableId.add((Integer)tblTenderBid[3]);
             }
             modelMap.addAttribute("bidCellData", StringUtils.arrayToCommaDelimitedString(cellValues.keySet().toArray()));
             Map<Integer,String> proxyData = (Map<Integer,String>)modelMap.get("proxyData");
             if(proxyData!=null && !proxyData.isEmpty()){
                 modelMap.addAttribute("proxyOffData", StringUtils.arrayToCommaDelimitedString(proxyData.keySet().toArray()));
                 cellValues.putAll(proxyData);
             }else{
                 modelMap.addAttribute("proxyOffData", "0");
             }
             List<Object[]> bidderBiddedList = tenderFormService.getBidderFromItemSelection(tenderId,bidderId,formId,true,true);
             Map<Object,Object> selectedFormMap = new HashMap<Object, Object>();
       		 Map<Object,Object> selectedTableMap = new HashMap<Object, Object>();
        	 if(bidderBiddedList != null && !bidderBiddedList.isEmpty())
           	 {
           		 Map<String,String> biddedMap = new HashMap<String, String>();
           		 
           		 for(Object[] obj : bidderBiddedList)
           		 {
           			 biddedMap.put(obj[0]+"_"+obj[1]+"_"+obj[2],obj[6].toString()); // Bidded item flag
           			 if(obj[6].equals(1)){
	           			selectedFormMap.put(obj[0], obj[0]);
	           			selectedTableMap.put(obj[1], obj[1]);
           			 }
           		 }
           		 modelMap.addAttribute("biddedMap",biddedMap);	// get bidder total 
           		 modelMap.addAttribute("selectedTableMap",selectedTableMap); // get all bidded table 
           		 modelMap.addAttribute("selectedFormMap",selectedFormMap); // get all bidded form
           	 }
             Map<String,Object> proxyBidValue = new HashMap<String, Object>();
             Map<Object,Object> proxyBidAllowTable = new HashMap<Object, Object>();
             List<Object[]> proxyBidList = tenderFormService.getProxyBidTblValue(tenderId,companyId);  // get data for which bidder bidded for loading
        		if(proxyBidList != null && !proxyBidList.isEmpty())
             {
             	for(Object[] obj : proxyBidList){
             		if(obj[5].equals(2) || obj[5].equals(1)){
             			proxyBidValue.put(obj[2]+"_"+obj[3]+"_"+obj[4], obj[4].toString());	// Check row having loading column and bidded bided in it
             			if(selectedTableMap.containsKey(obj[3])){
             				proxyBidAllowTable.put(obj[3], obj[3]); // get all table having proxy column
             			}
             		}
             	}
             }
        	 modelMap.addAttribute("proxyBidAllowTable", proxyBidAllowTable);
        	 modelMap.addAttribute("proxyBidValue", proxyBidValue);
        	 
        	 modelMap.addAttribute("companyName", commonService.getCompanyNameByCompanyId(companyId)); 
             modelMap.addAttribute("cellValues", cellValues);
             modelMap.addAttribute("formfactor", true);
             modelMap.addAttribute("bidTableId", StringUtils.arrayToCommaDelimitedString(bidTableId.toArray()));
        	 List<Object[]> loadingProcessData = tenderFormService.getLoadingFactorProcessDetail(tenderId,formId,companyId);
             if(loadingProcessData != null && !loadingProcessData.isEmpty() && isEdit != 1)
             {
          	   modelMap.addAttribute("lodingProcessOver", true);
             }else{
          	   modelMap.addAttribute("lodingProcessOver", false);
          	   if(isEdit==1)
          		  modelMap.addAttribute("isEdit", isEdit);
             }
             
         } catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         } finally {
        	 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),link_loading_factor_after,getLoadingFactorAfter, tenderId, formId);
         }
         return "/etender/buyer/TestForm";
     }
     
     /**
      * Save inserted loading factor for final update
      * @author janak
      * @param request
      * @param redirectAttributes
      * @return
      */
     @RequestMapping(value = "/buyer/addbidderfactor/{isCalculate}", method = RequestMethod.POST)
     public String addBidderFactor(HttpServletRequest request, RedirectAttributes redirectAttributes,@PathVariable("isCalculate") Integer isCalculate) {
         int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
         int formId = StringUtils.hasLength(request.getParameter("hdFormId")) ? Integer.parseInt(request.getParameter("hdFormId")) : 0;
         String proxyOffDatas[] = StringUtils.hasLength(request.getParameter("hdProxyOffData")) ? request.getParameter("hdProxyOffData").split(",") : null;
         String bidCellDatas[] = StringUtils.hasLength(request.getParameter("hdBidCellData")) ? request.getParameter("hdBidCellData").split(",") : null;
         String[] bidTableIds = StringUtils.hasLength(request.getParameter("hdBidTableId")) ? request.getParameter("hdBidTableId").split(",") : null;
         int companyId = StringUtils.hasLength(request.getParameter("hdCompanyId")) ? Integer.parseInt(request.getParameter("hdCompanyId")) : 0;
         int bidderId = StringUtils.hasLength(request.getParameter("hdBidderId")) ? Integer.parseInt(request.getParameter("hdBidderId")) : 0;
         boolean isEdit = StringUtils.hasLength(request.getParameter("hdEdit")) ? Boolean.parseBoolean(request.getParameter("hdEdit")) : false;
         boolean onlyfactor = StringUtils.hasLength(request.getParameter("hdOnlyfactor")) ? Boolean.parseBoolean(request.getParameter("hdOnlyfactor")) : false;
         int tabId = StringUtils.hasLength(request.getParameter("hdTabId")) ? Integer.parseInt(request.getParameter("hdTabId")) : 0;
         String companyIdFromId=StringUtils.hasLength(request.getParameter("hdCompanyIdsFormIds"))?request.getParameter("hdCompanyIdsFormIds"):"0";
         int processCnt=StringUtils.hasLength(request.getParameter("hdProcessCnt"))?Integer.parseInt(request.getParameter("hdProcessCnt")): -1;
         int isEditLoading = StringUtils.hasLength(request.getParameter("hdIsEdit")) ? Integer.parseInt(request.getParameter("hdIsEdit")) : 0;
         boolean success = false;
         String companyFormId="";
         String retVal = "redirect:/loginfailed";
         try {
            if(processCnt!=-1){
                if(companyIdFromId.split(",").length-1 == processCnt){
                    companyFormId=companyIdFromId.split(",")[processCnt];
                    processCnt=-2;
                    formId=Integer.parseInt(companyFormId.split("-")[1]);
                    retVal="redirect:/etender/buyer/tenderdashboard/"+tenderId+"/7"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/7", request);  
                }else{            
                    companyFormId=companyIdFromId.split(",")[processCnt];
                    formId=Integer.parseInt(companyFormId.split("-")[1]);
                    processCnt++;                                      
                    retVal="redirect:/etender/buyer/getsaveloadingall/"+tenderId+"/"+companyIdFromId+"/7/"+processCnt+encryptDecryptUtils.generateRedirect("etender/buyer/getsaveloadingall/"+tenderId+"/"+companyIdFromId+"/7/"+processCnt, request);  
                }
              }
            else
            {
            	retVal =  "etender/buyer/evaluateforms/"+tenderId+"/"+bidderId+"/"+companyId+"/"+tabId;
                retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
            }
            
             Map<Integer,String> bidDetail = new HashMap<Integer, String>();
             Map<Integer,String> proxyDetail = new HashMap<Integer, String>();
             List<Integer> bidTableId = new ArrayList<Integer>();
             Set<Integer> bidCellData = new HashSet<Integer>();
             Set<Integer> proxyOffData = new HashSet<Integer>();
             if(bidCellDatas!=null){
                 for (int i = 0; i < bidCellDatas.length; i++) {
                     bidCellData.add(Integer.parseInt(bidCellDatas[i]));
                 }
             }
             if(proxyOffDatas!=null){
                 for (int i = 0; i < proxyOffDatas.length; i++) {
                     proxyOffData.add(Integer.parseInt(proxyOffDatas[i]));
                 }
             }
             if(bidTableIds!=null){
                 for (int i = 0; i < bidTableIds.length; i++) {
                     bidTableId.add(Integer.parseInt(bidTableIds[i]));
                 }
             }
             SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
             if (sessionBean != null) {
                 String[] hdTableIds = request.getParameterValues("hdTableId");
                 for (String tableId : hdTableIds) {
                     String sorString = request.getParameter("rtfSorBid_" + tableId);
                     if (StringUtils.hasLength(sorString)) {
                         JSONArray jsonArray = new JSONArray(sorString);
                         for (int i = 0; i < jsonArray.length(); i++) {
                             JSONObject jSONObject = jsonArray.getJSONObject(i);
                             for (Iterator it = jSONObject.keys(); it.hasNext();) {
                                 String key = it.next().toString();
                                 String[] values = key.split("_");
                                 if(bidCellData.contains(Integer.parseInt(values[0]))){
                                     bidDetail.put(Integer.parseInt(values[0]), jSONObject.getString(key));
                                 }
                                 if(proxyOffData.contains(Integer.parseInt(values[0]))){
                                     proxyDetail.put(Integer.parseInt(values[0]), jSONObject.getString(key));
                                 }
                                 //System.out.println(+"_"+jSONObject.getString(key));
                             }
                         }
                     }
                 }
                 
                 if(proxyDetail != null && !proxyDetail.isEmpty()){
               	  	tenderFormService.updateBidderFactor(proxyDetail, companyId);
                 }
                 if(isEditLoading==1)
            	 {
            		 tenderFormService.deleteLoadingFactorProcess(tenderId,companyId,formId);
            	 }
                 if(isCalculate == 1)
                 {
                	 success = tenderFormService.updateBidderDetailFactor(bidDetail, companyId, bidTableId);
                     if(success){
    	                 TblLoadingFactorProcess tblLoadingFactorProcess = new TblLoadingFactorProcess();
    	                 tblLoadingFactorProcess.setCompanyId(companyId);
    	                 tblLoadingFactorProcess.setFormId(formId);
    	                 tblLoadingFactorProcess.setTenderId(tenderId);
    	                 tblLoadingFactorProcess.setOfficerId(abcUtility.getSessionUserId(request));
    	                 tblLoadingFactorProcess.setCreatedBy(abcUtility.getSessionUserId(request));
    	                 tenderFormService.updateLoadingFactorProcess(tblLoadingFactorProcess);
                     }
                 }
                 
                 if(processCnt==-2){ 
                     redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_loading_factor_formeval" : CommonKeywords.ERROR_MSG_KEY.toString());
                 }
                 else
                 {
                	 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_loading_factor_formeval" : CommonKeywords.ERROR_MSG_KEY.toString());
                 }
               //  retVal =  "etender/buyer/evaluateforms/"+tenderId+"/"+bidderId+"/"+companyId+"/"+tabId;
               //  retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
             }
         } catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),link_loading_factor_after,saveLoadingFactorAfter, tenderId, formId);
         }
         return retVal;
     }
     
     /**
      * @auther configure weightage Evaluation 
      * @param tenderId
      * @param modelMap
      * @param request
      * @return 
      */
     @RequestMapping(value = "/buyer/configureweightage/{tenderId}/{enc}", method = RequestMethod.GET)
     public String configureWeightageEvaluation(@PathVariable("tenderId")int tenderId, ModelMap modelMap,HttpServletRequest request) {
    	 String retVal = "redirect:/sessionexpired";
    	 SessionBean sessionBean = null;
    	 try {
    		 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		 List<Object[]> tenderEnvelopeLst=tenderFormService.getTenderEnvelopeListForWeightageScore(tenderId,0);
    		 List<Object[]> tenderEnvelopeFormList = new ArrayList<Object[]>(); 
    		 List<Integer> envelopeIdsList = new ArrayList<Integer>();
    		 if(tenderEnvelopeLst != null && ! tenderEnvelopeLst.isEmpty()){
	    		for (Object[] tenderEnvelope : tenderEnvelopeLst) {
	    			envelopeIdsList.add(Integer.parseInt(tenderEnvelope[0].toString()));
				}
	    		if(envelopeIdsList != null && !envelopeIdsList.isEmpty()){
	    			tenderEnvelopeFormList = tenderFormService.getTenderFormListForWeightageScore(tenderId,envelopeIdsList,0);
	    		}
    		 }
    		 modelMap.put("tenderEnvelopeList", tenderEnvelopeLst);
    		 modelMap.put("tenderEnvelopeFormList", tenderEnvelopeFormList);
    		 modelMap.put("oprType","a");
    		 sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
  			 ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
  			 int isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
             modelMap.put("isCertRequired", isCertRequired);
             String certIds[] = null;
             if (clientBean.getIsPkiEnabled() == pkiEnable || (clientBean.getIsPkiEnabled() == pkiEventSpecific && isCertRequired == 1)) {
                 certIds = sessionBean.getCertId().split(",");
                 if (certIds != null && certIds.length != 0) {
                     modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                 }
             }
    		 retVal="etender/buyer/EnvelopeWeightage";
          } catch (Exception e) {
              return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), configureWeightageEvaluationLinkId , configurationOfWeightage,tenderId,0);
          }
          return retVal;
     }
     
     /**
      * @auther configure weightage Evaluation 
      * @param tenderId
      * @param modelMap
      * @param request
      * @return 
      */
     @RequestMapping(value = "/buyer/editweightage/{tenderId}/{enc}", method = RequestMethod.GET)
     public String editWeightageEvaluation(@PathVariable("tenderId")int tenderId, ModelMap modelMap,HttpServletRequest request) {
    	 String retVal = "redirect:/sessionexpired";
    	 SessionBean sessionBean = null;
    	 try {
    		 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		 List<Object[]> tenderEnvelopeLst=tenderFormService.getTenderEnvelopeListForWeightageScore(tenderId,0);
    		 List<Object[]> tenderEnvelopeFormList = new ArrayList<Object[]>(); 
    		 List<Integer> envelopeIdsList = new ArrayList<Integer>();
    		 if(tenderEnvelopeLst != null && ! tenderEnvelopeLst.isEmpty()){
	    		for (Object[] tenderEnvelope : tenderEnvelopeLst) {
	    			envelopeIdsList.add(Integer.parseInt(tenderEnvelope[0].toString()));
				}
	    		if(envelopeIdsList != null && !envelopeIdsList.isEmpty()){
	    			tenderEnvelopeFormList = tenderFormService.getTenderFormListForWeightageScore(tenderId,envelopeIdsList,0);
	    		}
    		 }
    		 modelMap.put("tenderEnvelopeList", tenderEnvelopeLst);
    		 modelMap.put("tenderEnvelopeFormList", tenderEnvelopeFormList);
    		 modelMap.put("oprType","e");
    		 sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
  			 ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
  			 int isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
             modelMap.put("isCertRequired", isCertRequired);
             String certIds[] = null;
             if (clientBean.getIsPkiEnabled() == pkiEnable || (clientBean.getIsPkiEnabled() == pkiEventSpecific && isCertRequired == 1)) {
                 certIds = sessionBean.getCertId().split(",");
                 if (certIds != null && certIds.length != 0) {
                     modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                 }
             }
    		 retVal="etender/buyer/EnvelopeWeightage";
          } catch (Exception e) {
              return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editWeightageEvaluationLinkId, reConfigurationOfWeightage, tenderId, 0);
          }
          return retVal;
     }
     
     /**
      * @auther configure weightage Evaluation 
      * @param tenderId
      * @param modelMap
      * @param request
      * @return 
      */
     @RequestMapping(value = {"/buyer/viewweightage/{tenderId}/{enc}","/bidder/weightagecriteria/{tenderId}/{enc}"}, method = RequestMethod.GET)
     public String viewWeightageEvaluation(@PathVariable("tenderId")int tenderId, ModelMap modelMap,HttpServletRequest request) {
    	 String retVal = "redirect:/sessionexpired";
    	 int userType = abcUtility.getSessionUserTypeId(request);
    	 try {
    		 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		 List<Object[]> tenderEnvelopeLst=tenderFormService.getTenderEnvelopeListForWeightageScore(tenderId,0);
    		 List<Object[]> tenderEnvelopeFormList = new ArrayList<Object[]>(); 
    		 List<Integer> envelopeIdsList = new ArrayList<Integer>();
    		 if(tenderEnvelopeLst != null && ! tenderEnvelopeLst.isEmpty()){
	    		for (Object[] tenderEnvelope : tenderEnvelopeLst) {
	    			envelopeIdsList.add(Integer.parseInt(tenderEnvelope[0].toString()));
				}
	    		if(envelopeIdsList != null && !envelopeIdsList.isEmpty()){
	    			tenderEnvelopeFormList = tenderFormService.getTenderFormListForWeightageScore(tenderId,envelopeIdsList,0);
	    		}
    		 }
    		 modelMap.put("tenderEnvelopeList", tenderEnvelopeLst);
    		 modelMap.put("tenderEnvelopeFormList", tenderEnvelopeFormList);
    		 modelMap.put("oprType","v");
    		 retVal="etender/buyer/EnvelopeWeightage";
          } catch (Exception e) {
              return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewWeightageEvaluationLinkId, userType != 2 ?  viewWeightagePageFromWeightageConfiguration  : viewWeightagePageFromPrepareBidByBidder,tenderId,0);
          }
          return retVal;
     }
     /**
      * Save loading factor added by chairpersions
      * @author bharat
      * @param modelMap
      * @param request
      * @param redirectAttributes
      * @return
      * used to save/edit bidder items
      */
     @RequestMapping(value = "buyer/addEnvelopeWeightageScore", method = RequestMethod.POST)
     public String addEnvelopeWeightageScore(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
         String retVal = "redirect:/sessionexpired";
         String oprType= StringUtils.hasLength(request.getParameter("hdoprType")) ? request.getParameter("hdoprType") : "";
         String hdEnvelopeId[]=request.getParameterValues("hdEnvelopeId");
         String hdFormIdEnvId[] = request.getParameterValues("hdFormIdEnvId");
         String scoringCrt[] = request.getParameterValues("txtScoringCrt");
         String passingCrt[] = request.getParameterValues("txtPassingCrt");
         String formMarks[] = request.getParameterValues("txtFormMarksCrt");
         int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
         SessionBean sessionBean = request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
         int createEditFlag = 1;
         int isCertRequired = 0;
         try {
             if (sessionBean != null) {
            	 isCertRequired = StringUtils.hasLength(request.getParameter("hdIsCertRequired")) ? Integer.parseInt(request.getParameter("hdIsCertRequired")) : 0;
                 boolean isInserted = false;
                 if(hdEnvelopeId != null)
                 {
                	List<TbltenderEnvelopeWeightage> tbltenderEnvelopeWeightageList = new ArrayList<TbltenderEnvelopeWeightage>();
                	createEditFlag = 1;
               	 	for(int i = 0;i<hdEnvelopeId.length;i++)
               	  	{
               	  		int envelopeId = Integer.parseInt(hdEnvelopeId[i]);
               	  		TbltenderEnvelopeWeightage tbltenderEnvelopeWeightage = tenderFormService.getEnvelopeWeightageScoreByEnvelope(envelopeId);
	               	  	if(tbltenderEnvelopeWeightage != null){
	               	  		tbltenderEnvelopeWeightage.setUpdatedBy(abcUtility.getSessionUserDetailId(request));
	               	  		tbltenderEnvelopeWeightage.setUpdatedOn(commonService.getServerDateTime());
	               	  		tbltenderEnvelopeWeightage.setScoringMarks(new BigDecimal(scoringCrt[i].toString()));
	               	  		tbltenderEnvelopeWeightage.setPassingMarks(new BigDecimal(passingCrt[i].toString()));
	               	  		tbltenderEnvelopeWeightageList.add(tbltenderEnvelopeWeightage);
	               	  		createEditFlag = 2;
	               	  	}else
	               	  	{
	               	  		TbltenderEnvelopeWeightage tbltenderEnvelopeWeightageOnInsert  = new TbltenderEnvelopeWeightage();
	               	  		tbltenderEnvelopeWeightageOnInsert.setCreatedBy(abcUtility.getSessionUserDetailId(request));
	               	  		tbltenderEnvelopeWeightageOnInsert.setIsconfigured(1);
			               	tbltenderEnvelopeWeightageOnInsert.setUpdatedOn(commonService.getServerDateTime());
			               	tbltenderEnvelopeWeightageOnInsert.setUpdatedBy(abcUtility.getSessionUserDetailId(request));
			               	tbltenderEnvelopeWeightageOnInsert.setScoringMarks(new BigDecimal(scoringCrt[i].toString()));
			               	tbltenderEnvelopeWeightageOnInsert.setPassingMarks(new BigDecimal(passingCrt[i].toString()));
			               	tbltenderEnvelopeWeightageOnInsert.setTblTenderEnvelope( new TblTenderEnvelope(envelopeId));
	               	  		tbltenderEnvelopeWeightageList.add(tbltenderEnvelopeWeightageOnInsert);
	               	  	}
               	  	}
               	 	List<TbltenderFormWeightage> tblTbltenderFormWeightageList = new ArrayList<TbltenderFormWeightage>();
               	 	if(hdFormIdEnvId != null)
               	 	{
	               	 	for(int i = 0;i<hdFormIdEnvId.length;i++)
	               	  	{
	               	 		int formId = Integer.parseInt(hdFormIdEnvId[i].split("_")[0].toString());
	               	 		int envelopeId = Integer.parseInt(hdFormIdEnvId[i].split("_")[1].toString());
	               	 		TbltenderFormWeightage tbltenderFormWeightage = tenderFormService.getFormWeightageScore(formId,envelopeId);
	               	 		if(tbltenderFormWeightage != null){
	               	 			tbltenderFormWeightage.setFormMarks(new BigDecimal(formMarks[i].toString()));
	               	 			tbltenderFormWeightage.setUpdatedBy(abcUtility.getSessionUserDetailId(request));
	               	 			tbltenderFormWeightage.setUpdatedOn(commonService.getServerDateTime());
	               	 			tblTbltenderFormWeightageList.add(tbltenderFormWeightage);
	               	 			createEditFlag = 2;
	               	 		}
	               	 		else
	               	 		{
	               	 			TbltenderFormWeightage tbltenderFormWeightageOnInsert = new TbltenderFormWeightage();
	               	 			tbltenderFormWeightageOnInsert.setCreatedBy(abcUtility.getSessionUserDetailId(request));
	               	 			tbltenderFormWeightageOnInsert.setUpdatedOn(commonService.getServerDateTime());
	               	 			tbltenderFormWeightageOnInsert.setUpdatedBy(abcUtility.getSessionUserDetailId(request));
	               	 			tbltenderFormWeightageOnInsert.setIsconfigured(1);
	               	 			tbltenderFormWeightageOnInsert.setFormMarks(new BigDecimal(formMarks[i].toString()));
	               	 			tbltenderFormWeightageOnInsert.setTblTenderForm(new TblTenderForm(formId));
	               	 			tbltenderFormWeightageOnInsert.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
	               	 			tblTbltenderFormWeightageList.add(tbltenderFormWeightageOnInsert);
	               	 		}
	               	 	}
               	 	}
               	  	if(hdEnvelopeId != null){
               	  		tenderFormService.updateEnvelopeWeightageScore(tbltenderEnvelopeWeightageList);
               	  		tenderFormService.updateFormWeightageMarks(tblTbltenderFormWeightageList);
               	  		isInserted = true;
               	  	}
               	  	if(isInserted){
               	  		redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? (createEditFlag == 1? "redirect_add_envelope_score_formeval" : "redirect_edit_envelope_score_formeval"): CommonKeywords.ERROR_MSG_KEY.toString());
               	  		retVal="etender/buyer/tenderdashboard/"+tenderId+"/2";
               	  	}
                 }
             }
             retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
         } catch (Exception e) {
             exceptionHandlerService.writeLog(e);  
         } finally {
        	 int pki = abcUtility.getSessionIsPkiEnabled(request);
	    	 if (pki == pkiEnable || (pki == pkiEventSpecific && isCertRequired == 1)) {
	    		 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEditFlag == 1 ? configureWeightageEvaluationLinkId: editWeightageEvaluationLinkId , createEditFlag == 1 ? submittedWeightageConfiguration : updatedWeightageConfigurationPage ,tenderId,0,"", request.getParameter(SKPSIGNTEXT) != null ? request.getParameter(SKPSIGNTEXT) : "");
	    	 } else {
	    		 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEditFlag == 1 ? configureWeightageEvaluationLinkId: editWeightageEvaluationLinkId , createEditFlag == 1 ? submittedWeightageConfiguration : updatedWeightageConfigurationPage ,tenderId,0,"");
	    	 }
         }
         return retVal;
     }
     
     /**
	 	 * Use to view Weightage Details
	 	 * @author Keval.soni
	 	 * @param tenderId
	 	 * @param ModelMap
	 	 * @param request
	 	 * @throws Exception
	 	 * @return
	 */
  @RequestMapping(value = "/buyer/viewWeightageDetails/{tenderId}/{enc}", method = RequestMethod.GET)
  public String viewWeightageDetails(@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request) {
      try {
    	  /*** Get Common Services for tender detail **/
    	  tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    	  
    	  /*** Get TenderEnvelope details for tender Envelope name **/
    	  List<TblTenderEnvelope> envList = eventCreationService.getTblTenderEnvelopeList(tenderId);
    	  modelMap.addAttribute("EnvelopeList",envList);
    	  Integer[] envIdsArr = new Integer[envList.size()];
    	  for(int i=0;i<envList.size();i++){
     		 envIdsArr[i] = envList.get(i).getEnvelopeId();
 	 	  } 
    	  List<Object[]> envWeightage = tenderFormService.getTenderEnvelopeWeightage(envIdsArr);
    	  Map<Integer, String> envWeightageMap = new HashMap<Integer, String>(); 
    	  for(int i=0;i<envWeightage.size();i++){
    		  envWeightageMap.put(Integer.parseInt(envWeightage.get(i)[0].toString()), envWeightage.get(i)[1].toString()+"~"+envWeightage.get(i)[2].toString());
    	  }
    	  modelMap.addAttribute("envWeightageMap", envWeightageMap);

    	  /*** Get Weightage Score **/
    	  List <Object[]> tlBidderweightageScoreList = tenderFormService.getBidderweightageScoreDetails(tenderId);
    	  modelMap.addAttribute("bidderWeightageScoreMap",tlBidderweightageScoreList);

    	  List<Object[]> comitteeMember = new ArrayList<Object[]>();
    	  /*** Get tender Field **/
    	  List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "isEvaluationByCommittee,isEvaluationRequired");
    	  if(Integer.parseInt(tenderFields.get(0)[0].toString()) == 0 && Integer.parseInt(tenderFields.get(0)[1].toString()) == 1){ //if evaluationBycommittee = no and evaluationRequired = yes
    		  List<Integer> committeeMemIdList = new ArrayList<Integer>();
    		  for(int i=0;i<tlBidderweightageScoreList.size();i++){
    			  if(!committeeMemIdList.contains(tlBidderweightageScoreList.get(i)[0])){
    				  comitteeMember.add(new Object[]{tlBidderweightageScoreList.get(i)[0],tlBidderweightageScoreList.get(i)[4]});
    				  committeeMemIdList.add(Integer.parseInt(tlBidderweightageScoreList.get(i)[0].toString()));
    			  }
    		  }
    	  }else{
    		  comitteeMember = tenderFormService.getCommitteeMember(tenderId,2); //2 = committee type
    	  }
    	  modelMap.addAttribute("comitteeMemberList",comitteeMember);
    	  List<Object[]> bidderList = tenderFormService.getBidderDetailsByTenderId(tenderId);
    	  Map<Integer, String> bidderDataMap = new HashMap<Integer, String>(); 
    	  for(int i=0;i<bidderList.size();i++){
    		  bidderDataMap.put(Integer.parseInt(bidderList.get(i)[0].toString()), bidderList.get(i)[1].toString());
    	  }
    	  modelMap.addAttribute("BidderMap",bidderDataMap);
    	  List<Object[]> tenderFormList = tenderFormService.getOrganizeTenderFormByTenderId(tenderId);
    	  Map<Integer, String> formDataMap = new HashMap<Integer, String>(); 
    	  for(int i=0;i<tenderFormList.size();i++){
    		  formDataMap.put(Integer.parseInt(tenderFormList.get(i)[0].toString()), tenderFormList.get(i)[1].toString());
    	  }
    	  modelMap.addAttribute("tenderFormMap",formDataMap);
    	  List<Object[]> bidderBiddedFormMap = tenderFormService.getBidderBiddedFormList(tenderId, 0); //need to change
    	  
    	  List<String> biddedFormList = new ArrayList<String>();
    	  List<String> noBiddedFormList = new ArrayList<String>();
    	  for(int i=0;i<bidderBiddedFormMap.size();i++){
    		  biddedFormList.add(bidderBiddedFormMap.get(i)[0].toString()+"_"+bidderBiddedFormMap.get(i)[3].toString()+"_"+Integer.parseInt(bidderBiddedFormMap.get(i)[1].toString()));
    	  }
    	  for(int i=0;i<bidderList.size();i++){
    		  for(int j=0;j<tenderFormList.size();j++){
    			  if(!biddedFormList.contains(bidderList.get(i)[0].toString()+"_"+tenderFormList.get(j)[2].toString()+"_"+Integer.parseInt(tenderFormList.get(j)[0].toString())))
    				  noBiddedFormList.add(bidderList.get(i)[0].toString()+"_"+tenderFormList.get(j)[2].toString()+"_"+Integer.parseInt(tenderFormList.get(j)[0].toString()));
        	  }
    	  }
    	  modelMap.addAttribute("noBiddedFormList",noBiddedFormList);
    	  int officerId=0,bidderId=0,envelopeId=0,formId=0;
    	  Map<Integer, Map<Integer, Map<Integer, TreeMap<Integer,String>>>> allWeightageDataMap = new HashMap<Integer, Map<Integer,Map<Integer,TreeMap<Integer,String>>>>(); //In Map OfficerID,BidderId,EnvelopId,FormId and its marks
    	  Map<Integer, Map<Integer, TreeMap<Integer,String>>> bidderMap = new HashMap<Integer, Map<Integer,TreeMap<Integer,String>>>();
    	  Map<Integer, TreeMap<Integer,String>> envelopMap = new HashMap<Integer,TreeMap<Integer,String>>();
    	  TreeMap<Integer,String> formMap = new TreeMap<Integer,String>();
    	  Set<String> EnvSet = new HashSet<String>();
    	  for(int i=0;i<tlBidderweightageScoreList.size();i++){
    		  officerId = Integer.parseInt(tlBidderweightageScoreList.get(i)[0].toString());
    		  bidderId = Integer.parseInt(tlBidderweightageScoreList.get(i)[1].toString());
			  envelopeId = Integer.parseInt(tlBidderweightageScoreList.get(i)[2].toString());
			  EnvSet.add(officerId+"_"+bidderId+"_"+envelopeId);
			  formId = Integer.parseInt(tlBidderweightageScoreList.get(i)[3].toString());
    		  if(allWeightageDataMap.containsKey(officerId)){
    			  bidderMap = allWeightageDataMap.get(officerId);
    			  if(bidderMap.containsKey(bidderId)){
    				  envelopMap = bidderMap.get(bidderId);
    				  if(envelopMap.containsKey(envelopeId)){
    					  formMap =  envelopMap.get(envelopeId);
    				  }else{
    					  formMap = new TreeMap<Integer,String>();
    				  }
    			  }else{
    				  envelopMap = new HashMap<Integer,TreeMap<Integer,String>>();
    				  formMap = new TreeMap<Integer,String>();
    			  }
    		  }else{
    			  bidderMap = new HashMap<Integer, Map<Integer,TreeMap<Integer,String>>>();
    			  envelopMap = new HashMap<Integer,TreeMap<Integer,String>>();
    			  formMap = new TreeMap<Integer,String>();
    		  }
    		  formMap.put(formId, tlBidderweightageScoreList.get(i)[5].toString());
			  envelopMap.put(envelopeId, formMap);
			  bidderMap.put(bidderId, envelopMap);
    		  allWeightageDataMap.put(officerId, bidderMap);
    	  }
    	  modelMap.addAttribute("isWeightageStartForEnvelop", EnvSet);
    	  String[] noBiddedData = null; 
    	 for(int i=0;i<comitteeMember.size();i++){
    		 if(allWeightageDataMap.containsKey(Integer.parseInt(comitteeMember.get(i)[0].toString()))){
    			 bidderMap = allWeightageDataMap.get(Integer.parseInt(comitteeMember.get(i)[0].toString()));
    			 for(int j=0;j<noBiddedFormList.size();j++){
        			 noBiddedData = noBiddedFormList.get(j).split("_");
        			 if(bidderMap.containsKey(Integer.parseInt(noBiddedData[0]))){
        				 envelopMap = bidderMap.get(Integer.parseInt(noBiddedData[0]));
        				 if(envelopMap.containsKey(Integer.parseInt(noBiddedData[1]))){
       					  	formMap =  envelopMap.get(Integer.parseInt(noBiddedData[1]));
	       				  }else{
	       					  formMap = new TreeMap<Integer,String>();
	       				  }
        			 }else{
        				envelopMap = new HashMap<Integer,TreeMap<Integer,String>>();
   				  		formMap = new TreeMap<Integer,String>();
        			 }
        			 formMap.put(Integer.parseInt(noBiddedData[2]), "No Bid");
        			 envelopMap.put(Integer.parseInt(noBiddedData[1]), formMap);
        			 bidderMap.put(Integer.parseInt(noBiddedData[0]), envelopMap);
        		 }
    			 allWeightageDataMap.put(Integer.parseInt(comitteeMember.get(i)[0].toString()), bidderMap);
    		 }
    	 }
    	 modelMap.put("AllWeightageDataMap",allWeightageDataMap);
      }catch (Exception e) {
          return exceptionHandlerService.writeLog(e);
      }
      return "/etender/buyer/ViewBidderWeightage";
  }
     /**
  	 * Use to save / update biddder weightage score  
  	 * @author janak dhanani
  	 * @param tenderId
  	 * @param envelopeId
  	 * @param envlopTypFlg
  	 * @param sortOrder
  	 * @param preEnvelopeId
  	 * @param request
  	 * @param ModelMap
  	 * @throws Exception
  	 * @return
  	 */
 @RequestMapping(value = "/buyer/evaluatebidderweightage/{tenderId}/{envelopeId}/{createEditFlage}/{envlopTypFlg}/{sortOrder}/{preEnvelopeId}/{enc}", method = RequestMethod.GET)
    public String evaluateBidderWeightage(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("createEditFlage") int createEditFlage,@PathVariable("envlopTypFlg") int envlopTypFlg,@PathVariable("sortOrder") int sortOrder,@PathVariable("preEnvelopeId") int preEnvelopeId ,ModelMap modelMap,HttpServletRequest request) {
	 String createEditWeightage ="";   
	 SessionBean sessionBean = null;
	 try {
     	   StringBuilder formIds = new StringBuilder();
 	          	
      	  	/*** Get Common Services for tender detail **/
 			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
 			
 			/*** Get TenderEnvelope details for tender Envelope name **/
 			TblTenderEnvelope tblTenderEnvelope = tenderCommonService.getTenderEnvelopeById(envelopeId);
 			
 			/*** Code to get isConsortiumAllowed field from tender table if 0 means then map have put all key has different else set same key in case of 2 user have in Consortium **/
 			List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "isConsortiumAllowed,isCertRequired,isEncodedName,isEncodedForTechnical");
 			int isConsortiumAllowed = Integer.parseInt(tenderFields.get(0)[0].toString());
 			/** Changes done to show encoded bidder name for Bug #50576 **/
 			int isEncodedName = Integer.parseInt(tenderFields.get(0)[2].toString());
 			int isEncodedForTechnical = Integer.parseInt(tenderFields.get(0)[3].toString());
			int cstatus=commonService.getLetestCstatusEncodeDecodeHistory(tenderId);
			int isEncoded=0;
 			
			if(cstatus==1 && isEncodedName==1 && isEncodedForTechnical==1 && (tblTenderEnvelope.getTblEnvelope().getEnvId() == 3 || tblTenderEnvelope.getTblEnvelope().getEnvId() == 4 || tblTenderEnvelope.getTblEnvelope().getEnvId() == 5)) {
				isEncoded=1;
			}else if(cstatus==1 && isEncodedName==1 && (tblTenderEnvelope.getTblEnvelope().getEnvId() == 4 || tblTenderEnvelope.getTblEnvelope().getEnvId() == 5)) {
				isEncoded=1;
			}else if(cstatus==1 && isEncodedForTechnical==1 && (tblTenderEnvelope.getTblEnvelope().getEnvId() == 3 || tblTenderEnvelope.getTblEnvelope().getEnvId() == 5)) {
				isEncoded=1;
			}
			
 			modelMap.addAttribute("isEncoded",isEncoded);
 			
            List <EvaluateBiddersDataBean> evaluateBiddersList = new ArrayList<EvaluateBiddersDataBean>();
 			
 			/*** Get Evaluate bidders detail **/
 			@SuppressWarnings("unchecked")
 			Map<String,Object> evaluateBiddersListPro = (Map<String,Object>) tenderFormService.getEvaluateBiddersList(tenderId, envelopeId, preEnvelopeId,envlopTypFlg,isConsortiumAllowed, sortOrder, createEditFlage);
 			List<Map<String,Object>> evaluateBiddersListObj = (List<Map<String,Object>>) evaluateBiddersListPro.get(RESULT_SET_1);
 			List<Map<String,Object>> nextEnvelopFormIds = (List<Map<String,Object>>) evaluateBiddersListPro.get(RESULT_SET_2);
 			ArrayList<String> bidderIdList = new ArrayList<String>();
 			if(!evaluateBiddersListObj.isEmpty()){
 				for(Map<String,Object> evalMap:evaluateBiddersListObj){
 					
 					EvaluateBiddersDataBean evaluateBiddersDB = new EvaluateBiddersDataBean();
 					String bidderIdStr = evalMap.get("bidderIds").toString();
 					String[] bidderIdArr   = bidderIdStr.split("\\|~\\|"); 
 					bidderIdList.add(bidderIdArr[2]);
 					evaluateBiddersDB.setBidderIds(evalMap.get("bidderIds").toString());
 					evaluateBiddersDB.setCompanyName(evalMap.get("companyName").toString().substring(0,evalMap.get("companyName").toString().length()-1));
 					evaluateBiddersDB.setBidderApprovalId(evalMap.get("bidderApprovalId").toString());
 					evaluateBiddersDB.setRemarks(evalMap.get("remarks").toString());
 					evaluateBiddersDB.setIsApproved(evalMap.get("isApproved").toString());
 					evaluateBiddersDB.setEncodedName(evalMap.get("encodedName").toString());
 					evaluateBiddersList.add(evaluateBiddersDB);
 					
 				}
 			}
 			if(!nextEnvelopFormIds.isEmpty()){
 				for(Map<String,Object> formMap:nextEnvelopFormIds){
 					formIds.append(formMap.get("formId").toString()).append(",");
 				}
 			}
 			Set <String> bidderBiddedFormSet = new HashSet<String>();
 			List<Object[]> bidderBiddedFormMap = tenderFormService.getBidderBiddedFormList(tenderId, envelopeId);
 			if(bidderBiddedFormMap != null && !bidderBiddedFormMap.isEmpty())
 			{
 				for (Object[] objects : bidderBiddedFormMap) {
 					bidderBiddedFormSet.add(objects[0].toString() + "_" + objects[1].toString());
				}
 			}
 			int isTwoStageEvaluation = (Integer) modelMap.get("isTwoStageEvaluation");
 			if(isTwoStageEvaluation == 1){
 				List<Object> editDisabledWeightageBidderList = tenderFormService.getAlreadyEvaluationDoneBidderList(tenderId,envelopeId,abcUtility.getSessionUserId(request));
 				modelMap.addAttribute("evaluatedBidderList", editDisabledWeightageBidderList);
 			}
 			TbltenderEnvelopeWeightage tbltenderEnvelopeWeightage = tenderFormService.getEnvelopeWeightageScoreByEnvelope(envelopeId);
 			List <TblBidderweightageScore> tlBidderweightageScoreList = isTwoStageEvaluation == 1 ? tenderFormService.getBidderweightageScore(tenderId, envelopeId,abcUtility.getSessionUserId(request)) : tenderFormService.getBidderweightageScore(tenderId, envelopeId);
 			Map<String,BigDecimal> bidderWeightageScoreMap = new HashMap<String, BigDecimal>();  
 			if(tlBidderweightageScoreList != null && !tlBidderweightageScoreList.isEmpty()){
	 			for (TblBidderweightageScore tblBidderweightageScore : tlBidderweightageScoreList)
	 				bidderWeightageScoreMap.put(tblBidderweightageScore.getBidderId() + "_" + tblBidderweightageScore.getTblTenderForm().getFormId(), tblBidderweightageScore.getBidderMarks());
 			}
 			List<Object[]> envelopeForms = tenderFormService.getApprovedFormListForBidderWeightageEvaluation(tenderId,envelopeId);
 			modelMap.put("envelopeWeightage", tbltenderEnvelopeWeightage);
 			modelMap.put("bidderWeightageScoreMap", bidderWeightageScoreMap);
 			modelMap.put("bidderBiddedFormSet", bidderBiddedFormSet);
 			modelMap.put("bidderIdList", bidderIdList);
 			modelMap.put("tabId", TAB_EVALUATE_BID);
 			modelMap.put("tenderId", tenderId);
 			modelMap.put("envelopeId", envelopeId);
 			modelMap.put("evaluateBiddersMap", evaluateBiddersList);
 			modelMap.put("tblTenderEnvelope",tblTenderEnvelope);
 			 
 			createEditWeightage = tenderFormService.getBidderweightageScoreCount(tenderId, envelopeId,isTwoStageEvaluation==1 ? abcUtility.getSessionUserId(request) : 0)? "2" : "1";
 			modelMap.put("createEditFlage",createEditWeightage);
 			modelMap.put("envlopTypFlg",envlopTypFlg);
 			modelMap.put("sortOrder",sortOrder);
 			modelMap.put("envelopeForms", envelopeForms);
 			modelMap.put("formIds",formIds);
 			
 			sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
 			ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
 			int isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
            modelMap.put("isCertRequired", isCertRequired);
            String certIds[] = null;
            if (clientBean.getIsPkiEnabled() == pkiEnable || (clientBean.getIsPkiEnabled() == pkiEventSpecific && isCertRequired == 1)) {
                certIds = sessionBean.getCertId().split(",");
                if (certIds != null && certIds.length != 0) {
                    modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEditFlage==1?evaluationEvaluateLinkId:evaluationReEvaluateLinkId , createEditWeightage.equals("1") ? insertBidderWeightagePage : updateBidderWeightagePage,tenderId,envelopeId);
        }
        return "/etender/buyer/EvaluateBidderWeightage";
    }
    
	 /**
	  * save bidder weightage score for item
	  * @author janak
	  * @param modelMap
	  * @param request
	  * @param redirectAttributes
	  * @return
	  * used to save/edit bidder weighatage score
	  */
 
	 @RequestMapping(value = "buyer/addevaluatebidderweightage", method = RequestMethod.POST)
	 public String addEvaluatebidderweightage(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
	 
		 String retVal = "redirect:/sessionexpired";
	     String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
	     String createEditFlage= StringUtils.hasLength(request.getParameter("hdCreateEditFlage")) ? request.getParameter("hdCreateEditFlage") : "";
	     String bidderIdFormId[]=request.getParameterValues("hdBidderIdFormId");
	     int envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")) : 0;
	     int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
	     SessionBean sessionBean = request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
	     String msg = "";
	     int isCertRequired = 0;
	     try {
	         if (sessionBean != null) {
	        	 isCertRequired = StringUtils.hasLength(request.getParameter("hdIsCertRequired")) ? Integer.parseInt(request.getParameter("hdIsCertRequired")) : 0;	
	             boolean isInserted = false;
	             if(bidderIdFormId != null)
	             {
	            	List<TblBidderweightageScore> tblBidderweightageScoreList = new ArrayList<TblBidderweightageScore>();
	            	if(createEditFlage.equals("2")){
	            		List<Object[]> isTwostageEvaluationField = tenderCommonService.getTenderFields(tenderId,"isTwoStageEvaluation,isCertRequired");
	            		tenderFormService.deleteBidderweightageScore(tenderId,envelopeId,Integer.parseInt(isTwostageEvaluationField.get(0)[0].toString()) == 1 ? (abcUtility.getSessionUserId(request)) : 0);
	            		msg = "redirect_edit_evaluation_score_bidderformeval";
	            	}
	            	else
	            		msg = "redirect_add_evaluation_score_bidderformeval";
	           	 	for(int i = 0;i<bidderIdFormId.length;i++)
	           	  	{
	       	 			int bidderId = Integer.parseInt(bidderIdFormId[i].split("_")[0]);
	       	 			int formId = Integer.parseInt(bidderIdFormId[i].split("_")[1]);
	       	 			String bidderWeightageScoreStr = StringUtils.hasLength(request.getParameter("txtEvaluationScore_" + bidderIdFormId[i])) ? request.getParameter("txtEvaluationScore_" + bidderIdFormId[i]) : "-1";
	       	  			if(! bidderWeightageScoreStr.equals("-1"))
	       	  			{
	       	  				BigDecimal bidderWeightageScore = new BigDecimal(bidderWeightageScoreStr);
	       	  				TblBidderweightageScore tblBidderweightageScore = new TblBidderweightageScore();
	       	  				tblBidderweightageScore.setCreatedBy(abcUtility.getSessionUserDetailId(request));
	       	  				tblBidderweightageScore.setCStatus(1);
	       	  				tblBidderweightageScore.setIpAddress(ipAddress);
	       	  				tblBidderweightageScore.setBidderId(bidderId);
	       	  				tblBidderweightageScore.setTblTender(new TblTender(tenderId));
	       	  				tblBidderweightageScore.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
	       	  				tblBidderweightageScore.setTblTenderForm(new TblTenderForm(formId));
	       	  				tblBidderweightageScore.setUpdatedBy(abcUtility.getSessionUserDetailId(request));
	       	  				tblBidderweightageScore.setUpdatedOn(commonService.getServerDateTime());
	       	  				tblBidderweightageScore.setBidderMarks(bidderWeightageScore);
	       	  				int sessionUserId = abcUtility.getSessionUserId(request);
	       	  				tblBidderweightageScore.setTblUserLogin(new TblUserLogin(sessionUserId));
	       	  				List<Object[]> userRoleList  = tenderFormService.getUserRoleId(tenderId, envelopeId,2,sessionUserId);
	       	  				int userRoleId = 0;
	       	  				int encryptionLevel = 0;
	       	  				if(userRoleList!=null && !userRoleList.isEmpty()){
	       	  					userRoleId = Integer.parseInt(userRoleList.get(0)[0].toString());
	       	  					encryptionLevel = Integer.parseInt(userRoleList.get(0)[1].toString());
	       	  				}
	       	  				if(encryptionLevel==0){
	       	  					tblBidderweightageScore.setUserRoleId(userRoleId == 1 ? 2 : 1);
	       	  				}else if(encryptionLevel==1){
	       	  					tblBidderweightageScore.setUserRoleId(userRoleId == 1 ? 2 : 1);
		                    }else{
		                    	tblBidderweightageScore.setUserRoleId(userRoleId == 1 ? 4 : 3);
		                    }
	       	  				tblBidderweightageScoreList.add(tblBidderweightageScore);
	       	  			}
	               	 }
	           	  	if(tblBidderweightageScoreList != null && !tblBidderweightageScoreList.isEmpty()){
	           	  		isInserted = tenderFormService.insertBidderweightageScore(tblBidderweightageScoreList);
	           	  	}
	           	  	if(isInserted){	
	           	  		redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? msg : CommonKeywords.ERROR_MSG_KEY.toString());
	           	  		retVal="etender/buyer/tenderdashboard/"+tenderId+"/8";
	           	  	}
	             }
	         }
	         retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	     } catch (Exception e) {
	         exceptionHandlerService.writeLog(e);  
	     } finally {
	    	 int pki = abcUtility.getSessionIsPkiEnabled(request);
	    	 if (pki == pkiEnable || (pki == pkiEventSpecific && isCertRequired == 1)) {
	    		 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEditFlage.equals("1")?evaluationEvaluateLinkId:evaluationReEvaluateLinkId  , createEditFlage.equals("1")?insertedBidderWeightagePage:updatedBidderWeightagePage ,tenderId,envelopeId,"", request.getParameter(SKPSIGNTEXT) != null ? request.getParameter(SKPSIGNTEXT) : "");
	    	 } else {
	    		 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEditFlage.equals("1")?evaluationEvaluateLinkId:evaluationReEvaluateLinkId  , createEditFlage.equals("1")?insertedBidderWeightagePage:updatedBidderWeightagePage ,tenderId,envelopeId,"");
	    	 }
	    	 
	     }
	     return retVal;
	 }
	 
	 /**
	  * view bidder weightage score 
	  * @author priyanka
	  *  @param tenderId
	  * @param modelMap
	  * @param request
	  * @param redirectAttributes
	  * @return
	  * used to view bidder weightage score
	  */
	  
	 @RequestMapping(value = "/bidder/viewweightagescore/{tenderId}/{enc}", method = RequestMethod.GET)
     public String viewWeightageEvaluationScore(@PathVariable("tenderId")int tenderId, ModelMap modelMap,HttpServletRequest request) {
    	 String retVal = "redirect:/sessionexpired";
    	 int userType = abcUtility.getSessionUserTypeId(request);
    	 try {    		 
    		 int bidderId = abcUtility.getSessionUserId(request);    		
    		 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		 List<Object[]> tenderEnvelopeLst=tenderFormService.getTenderEnvelopeListForWeightageScore(tenderId,0);    		
    		 List<Integer> envelopeIdsList = new ArrayList<Integer>();
    		 List<Object[]> bidderScoreList =  new ArrayList<Object[]>();
    		 if(tenderEnvelopeLst != null && ! tenderEnvelopeLst.isEmpty()){
	    		for (Object[] tenderEnvelope : tenderEnvelopeLst) {
	    			envelopeIdsList.add(Integer.parseInt(tenderEnvelope[0].toString()));
				}
	    		if(envelopeIdsList != null && !envelopeIdsList.isEmpty()){
	    			int userRoleId = 1;
	    			if((Integer) modelMap.get("isTwoStageEvaluation") == 1 ){
	    				userRoleId = (Integer) modelMap.get("multiLevelEvaluationReq") == 1 ? 4 : 2;
	    			}
	    			 bidderScoreList = tenderFormService.getTenderBidderListForWeightageScore(tenderId,envelopeIdsList,bidderId,userRoleId);
	    		}
    		 }   		 
    		 modelMap.put("bidderScoreList", bidderScoreList);
    		 /** Get all EnvelopList */
    		 List<TblTenderEnvelope> envList = eventCreationService.getTblTenderEnvelopeList(tenderId);
    		 long finalSubmissionCnt = tenderFormService.getCountofFinalSubmissionWithConsourtiumForViewWeightage(tenderId, Integer.parseInt(modelMap.get("isConsortiumAllowed").toString()));
    		 Map<Integer, Integer> evaluationDoneEnvMap = new HashMap<Integer, Integer>();
    		 if(envList.size() == 1){
    			 evaluationDoneEnvMap.put(envList.get(0).getEnvelopeId(), tenderFormService.isEnvelopeWiseEvaluationDone(tenderId,envList.get(0).getEnvelopeId(),finalSubmissionCnt));
    		 }else{
    			 int previousEnvId = 0;
    			 for(TblTenderEnvelope tenderEnvelop : envList){
    				 evaluationDoneEnvMap.put(tenderEnvelop.getEnvelopeId(), tenderFormService.isEnvelopeWiseEvaluationDoneForViewWeightage(tenderId,tenderEnvelop.getEnvelopeId(),finalSubmissionCnt,(Integer) modelMap.get("isTwoStageEvaluation") == 1 ? -1 : previousEnvId));
    				 previousEnvId = envList.get(0).getEnvelopeId();
    			 }
    		 }
    		 modelMap.addAttribute("evaluationDoneEnvMap", evaluationDoneEnvMap);
    		 retVal="etender/bidder/EnvelopeWeightage";
          } catch (Exception e) {
              return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewWeightageEvaluationLinkId, userType != 2 ?  viewWeightagePageFromWeightageConfiguration  : viewWeightagePageFromPrepareBidByBidder,tenderId,0);
          }
          return retVal;
     }
	 private boolean isEvaluationDone(int tenderId)throws Exception{
   		List<TblTenderEnvelope> envList = eventCreationService.getTblTenderEnvelopeList(tenderId);
   		long finalSubmissionCnt = tenderFormService.getCountofFinalSubmission(tenderId);
   		List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isTwoStageEvaluation,isItemwiseWinner,isConsortiumAllowed");
   		int isConsortiumAllowed = Integer.parseInt(tenderDetails.get(0)[2].toString());
   			if(isConsortiumAllowed == 1){
   				finalSubmissionCnt = tenderFormService.getCountofFinalSubmissionWithConsourtium(tenderId, isConsortiumAllowed);
   			}
   		int isTwoStageEvaluation = 0;
   		if(tenderDetails!= null && !tenderDetails.isEmpty()){
   			isTwoStageEvaluation = Integer.parseInt(tenderDetails.get(0)[0].toString());
   		}
   		int evaluationDoneEnv = 0;
   		if(envList.size() == 1){
   			evaluationDoneEnv = tenderFormService.isEnvelopeWiseEvaluationDone(tenderId,envList.get(0).getEnvelopeId(),finalSubmissionCnt);
   		}else{
   			 int previousEnvId = 0;
   			 for(TblTenderEnvelope tenderEnvelop : envList){
   				 evaluationDoneEnv = tenderFormService.isEnvelopeWiseEvaluationDone(tenderId,tenderEnvelop.getEnvelopeId(),finalSubmissionCnt,isTwoStageEvaluation == 1 ? -1 : previousEnvId);
   				 previousEnvId = envList.get(0).getEnvelopeId();
   			 }
   		}
   		return evaluationDoneEnv!=0 ? true : false; 
	 }
	 /**
	  * Created the same function as above for solving the bug Bug :  38234
	  * @author nitin.w
	  * @param tenderId
	  * @return
	  * @throws Exception
	  */
	 private boolean isEvaluationCompleted(int tenderId)throws Exception{
	   		List<TblTenderEnvelope> envList = eventCreationService.getTblTenderEnvelopeList(tenderId);
	   		long finalSubmissionCnt = tenderFormService.getCountofFinalSubmission(tenderId);
	   		List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isTwoStageEvaluation,isItemwiseWinner,isConsortiumAllowed");
	   		int isConsortiumAllowed = Integer.parseInt(tenderDetails.get(0)[2].toString());
	   			if(isConsortiumAllowed == 1){
	   				finalSubmissionCnt = tenderFormService.getCountofFinalSubmissionWithConsourtium(tenderId, isConsortiumAllowed);
	   			}
	   		int isTwoStageEvaluation = 0;
	   		if(tenderDetails!= null && !tenderDetails.isEmpty()){
	   			isTwoStageEvaluation = Integer.parseInt(tenderDetails.get(0)[0].toString());
	   		}
	   		int evaluationDoneEnv = 0;
	   		if(envList.size() == 1){
	   			evaluationDoneEnv = tenderFormService.isEnvelopeWiseEvaluationDone(tenderId,envList.get(0).getEnvelopeId(),finalSubmissionCnt);
	   		}else{
	   			 int previousEnvId = 0;
	   			 for(TblTenderEnvelope tenderEnvelop : envList){
	   				 evaluationDoneEnv = tenderFormService.isEnvelopeWiseEvaluationCompleted(tenderId,tenderEnvelop.getEnvelopeId(),finalSubmissionCnt,isTwoStageEvaluation == 1 ? -1 : previousEnvId);
	   				 previousEnvId = envList.get(0).getEnvelopeId();
	   			 }
	   		}
	   		return evaluationDoneEnv!=0 ? true : false; 
		 }
	 
	/**
	 * Check form is published
	 * @author Vivek Rajyaguru
	 * @param formId
	 * @return
	 */
	@RequestMapping(value = "/buyer/isFormPublished", method = RequestMethod.POST)
	@ResponseBody
	public String isFormPublished(@RequestParam("txtFormId") int formId, HttpServletRequest request){
	    	String alertMsg = null;
	    	try{
	    		if(!tenderFormService.isFormPublished(formId)){
	    			if(this.isRebatForm(formId, request).equals("false")){
	    				alertMsg="confirm";
	    			}else{
	    				alertMsg=messageSource.getMessage("msg_delete_bidding_form_failed", null, LocaleContextHolder.getLocale());
	    			}
	    		}else{
	    			alertMsg=messageSource.getMessage("msg_bidding_form_envelope_published", null, LocaleContextHolder.getLocale());
	    		}
	    	}
	    	catch(Exception e){
	    		exceptionHandlerService.writeLog(e);
	    	}
	    	finally {
	    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deleteFormLinkId, postAjaxDeleteFormAudit, formId,0);
	    	}
	    	return alertMsg.toString();
	    }
	
	/**
	 * author Keval.soni
	 * @param tenderId
	 * @param request
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/buyer/viewBidWithdrawalDetails/{tenderId}/{enc}", method=RequestMethod.GET)
	public String viewCommittee(@PathVariable(TENDER_ID) Integer tenderId, HttpServletRequest request , ModelMap modelMap){
		int clientId = 0;
		try {
			clientId = abcUtility.getSessionClientId(request);
			tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
			List<Object[]> bidWithdrawalList = tenderFormService.getBidWithdrawalDetails(tenderId,clientId,(Integer)modelMap.get("isConsortiumAllowed"));
			Map<Integer, Object[]> bidWithdrawalMap = new HashMap<Integer, Object[]>();
			for(int i=0;i<bidWithdrawalList.size();i++){
				bidWithdrawalMap.put(Integer.parseInt(bidWithdrawalList.get(i)[1].toString()), bidWithdrawalList.get(i));
			}
			modelMap.addAttribute("bidWithdrawalMap", bidWithdrawalMap);
			modelMap.addAttribute("bidWithdrawalCnt", bidWithdrawalMap.size());
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidWithdrawnLink, bidwithdrawn, tenderId , 0);
		}
		return "etender/buyer/ViewBidWithdrawalDetails";
	}
	 
        /**
   	 * Use to open page for tender opening consent
   	 * @author Mittal
   	 * @param tenderId
   	 * @param envelopeId
   	 * @param request
   	 * @param ModelMap
   	 * @throws Exception
   	 * @return
   	 */
	@RequestMapping(value = "/buyer/reEvaluation/{tenderId}/{envelopeId}/{createEditFlage}/{envlopTypFlg}/{sortOrder}/{preEnvelopeId}/{isView}/{enc}", method = RequestMethod.GET)
       public String reEvaluation(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("createEditFlage") int createEditFlage,@PathVariable("envlopTypFlg") int envlopTypFlg,@PathVariable("sortOrder") int sortOrder,@PathVariable("preEnvelopeId") int preEnvelopeId ,@PathVariable("isView") boolean isView,ModelMap modelMap,HttpServletRequest request) {
         String page="redirect:/sessionexpired";
    	 boolean isCertiFound=true; 
    	 
    	 try {
	          	
        	  /*** Check the client is PKI or event specific **/  
        	  
	        	int isCertRequired=(Integer)tenderCommonService.getTenderField(tenderId, "isCertRequired");
	        	modelMap.put("isCertRequired", isCertRequired);
	        	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	    		if(clientBean.getIsPkiEnabled()==1){
	        		String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
	        		if(certIds!=null && certIds.length!=0){
	        			modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
	        		}
	    		}
	    		else if(clientBean.getIsPkiEnabled()==pkiEventSpecific && isCertRequired ==1){
	    			SessionBean sessionBean = null; 
	    			if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())!=null){
	    	            sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
	    	        }
	    			
	    		if (sessionBean != null && !sessionBean.isEventSpecVerify()){
	                    isCertiFound = false;
	                    page="common/buyer/attacheventspeccerti/etender,buyer,reEvaluation,"+tenderId+","+envelopeId+","+createEditFlage+","+envlopTypFlg+","+sortOrder+","+preEnvelopeId+","+isView;
	                } 
	                else{
	                    String certIds[] = sessionBean.getCertId().split(",");
	                    if (certIds != null && certIds.length != 0) {
	                        modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
	                    }
	                }
	    		}
	    		else{
	    			isCertiFound= true;
	    		}
	    		if(isCertiFound){
		    		/*** Get Common Services for tender detail **/
		   			tenderCommonService.tenderSummary(tenderId, modelMap,clientBean.getClientId());
                                        modelMap.put("tabId", TAB_EVALUATE_BID);
                                        modelMap.put("tenderId", tenderId);
                                        modelMap.put("envelopeId", envelopeId);
                                        modelMap.put("createEditFlage",createEditFlage);
                                        modelMap.put("envlopTypFlg",envlopTypFlg);
                                        modelMap.put("sortOrder",sortOrder);
                                        modelMap.put("isCertRequired",isCertRequired);
                                        modelMap.put("preEnvelopeId",preEnvelopeId);
		   			modelMap.put("isView",isView);
                                        modelMap.addAttribute("resultSharing",tenderCommonService.getTenderField(tenderId, "resultSharing"));
		   			page ="etender/buyer/ReEvaluateBidder";
	    		}else{
	    			 page="redirect:/"+page+ encryptDecryptUtils.generateRedirect(page, request);
                }
          } catch (Exception e) {
              return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),evaluationConsentLinkId,evaluatebiddersreevaluateaddpage,tenderId,envelopeId);
          }
    	 return page;
      }
     
     
     /**
    	 * Use to save remark for tender opening consent
    	 * @author Mittal
    	 * @param request
    	 * @throws Exception
    	 * @return
    	 */
     @RequestMapping(value = "/buyer/addReEvaluationRemarks", method = RequestMethod.POST)
     public String addReEvaluationRemarks(RedirectAttributes redirectAttributes,ModelMap modelMap, HttpServletRequest request) {
     	boolean success=true;
     	String retVal=REDIRECT_SESSION_EXPIRED;
     	int tenderId = 0;
     	int envelopeId = 0;
     	int envlopTypFlg = 0;
     	int sortOrder = 0;
     	int isCertRequired = 0;
     	int tabId = 0;
        int preEnvelopeId = 0;
     	String remark=null;
     	boolean isCorrigendumPrepare=false;  
     	String errMsg = CommonKeywords.ERROR_MSG_KEY.toString();;
     	 int apoExist = 0;
         try{
             int sessionUserId = abcUtility.getSessionUserId(request);
             if (sessionUserId != 0) {
                 
                 
                    tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))? Integer.parseInt(request.getParameter("hdTenderId")):0;  
	            envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
	            String eventType=StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
	            envlopTypFlg = StringUtils.hasLength(request.getParameter("hdEnvlopTypFlg")) ? Integer.parseInt(request.getParameter("hdEnvlopTypFlg")):0;
	            isCertRequired = StringUtils.hasLength(request.getParameter("hdIsCertRequired")) ? Integer.parseInt(request.getParameter("hdIsCertRequired")):0;
                    sortOrder = StringUtils.hasLength(request.getParameter("hdSortOrder")) ? Integer.parseInt(request.getParameter("hdSortOrder")):0;
                    preEnvelopeId = StringUtils.hasLength(request.getParameter("hdPreEnvelopeId")) ? Integer.parseInt(request.getParameter("hdPreEnvelopeId")):0;
                    remark = StringUtils.hasLength(request.getParameter("txtaRemark")) ? request.getParameter("txtaRemark") : null;
                    
                    List<Object[]> listCMS=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
 	            if (listCMS != null) {
 	                for (int i = 0; i < listCMS.size(); i++) {
 	                	if(listCMS.get(i)[0].toString().equalsIgnoreCase("12") ||listCMS.get(i)[0].toString().equalsIgnoreCase("13")){
 	                		apoExist=1;                		 
 	                    }
 	                }
 	            }
 	            if(apoExist==1){
 	            	TblAdvancePurchaseOrder tblAdvancepurchaseorder = commonService.getTblAdvancePurchaseOrderByObject(tenderId);
 	            	if(tblAdvancepurchaseorder!=null){
 	            		success=false;
 	            		errMsg = "msg_apo_already_created_reevaluation";
 	            	}
 	            	TblPurchaseOrder tblpurchaseorder = commonService.getTblPurchaseOrderByObject(tenderId);
 	            	if(tblpurchaseorder!=null){
 	            		success=false;
 	            		errMsg = "msg_apo_already_created_reevaluation";
 	            	}
 	            }
                    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                    Integer[] ctatus={0};        
                    List<TblTenderReevaluation> getTblTenderReevaluation = tenderFormService.getTblTenderEnvelopeRevaluationStatusByTenderId(tenderId,ctatus);
                 if (getTblTenderReevaluation.isEmpty() && success) {
                     tabId = TAB_EVALUATE_BID;
                     TblTenderReevaluation tblTenderReevaluation = new TblTenderReevaluation();
                     tblTenderReevaluation.setTblTender(new TblTender(tenderId));
                     tblTenderReevaluation.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
                     tblTenderReevaluation.setTblUserLogin(new TblUserLogin(sessionUserId));
                     tblTenderReevaluation.setCreatedOn(commonService.getServerDateTime());
                     tblTenderReevaluation.setUpdatedOn(commonService.getServerDateTime());
                     tblTenderReevaluation.setRemarks(remark);
                     tblTenderReevaluation.setCstatus(0);
                     success = tenderFormService.addTenderReevaluation(tblTenderReevaluation);
                     /*** Start Code to send email by services**/
          		if(success){
          		 	// PT : #33589 By Jitendra. Update tender status to opened when reevaluation is started for any envelope.	
          			eventCreationService.updateTenderEvalutionStatus(tenderId, TENDER_OPENED_STATUS);
          			
                            /*** Get TenderEnvelope details for tender Envelope name **/
                            TblTenderEnvelope tblTenderEnvelope = tenderCommonService.getTenderEnvelopeById(envelopeId);
                            
              			Map<String, Object> reEvaluateMap = new HashMap<String, Object>();
    					reEvaluateMap.put("EventId", tenderId);
    					reEvaluateMap.put("EventType", modelMap.get("eventType"));   					
                                        reEvaluateMap.put("EnvelopeName", tblTenderEnvelope.getEnvelopeName());
                                        reEvaluateMap.put("tenderId", tenderId);    
                                        reEvaluateMap.put("envelopeId", envelopeId);
                  		mailContentUtillity.dynamicMailGeneration("262", String.valueOf(0), String.valueOf(tenderId),reEvaluateMap ,String.valueOf(envelopeId));
          		}
                     
                 } else {
                     success = false;
                     if(!getTblTenderReevaluation.isEmpty()){
                     errMsg =  "msg_reevaluation_process_has_been_initiated";}
                 }

             }
         }catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         }finally {
        	 int pki=abcUtility.getSessionIsPkiEnabled(request);
        	 if(pki==1 || (pki==pkiEventSpecific && isCertRequired ==1)){
        		 String signText = StringUtils.hasLength(request.getParameter("skpSignText")) ? request.getParameter("skpSignText"):null;
         		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), evaluationConsentLinkId, success ? postevaluatebiddersreevaluateaddpage : postevaluatebiddersreevaluateaddpage,tenderId,envelopeId,remark,signText);
         	}else{
         		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), evaluationConsentLinkId, success ? postevaluatebiddersreevaluateaddpage : postevaluatebiddersreevaluateaddpage,tenderId,envelopeId,remark);
         	}
             
         }
         retVal=success?TENDER_DASHBOARD_URL+tenderId+"/"+tabId:"/etender/buyer/reEvaluation/"+tenderId+"/"+envelopeId+"/"+1+"/"+envlopTypFlg+"/"+sortOrder+"/"+preEnvelopeId+"/"+"false";
  		 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
  		 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_reevaluation_process_has_been_initiated" : errMsg );
         return retVal;
     }
    
     /**
      * Project Task #55777 
      * Use to Access My Library Form page 
      * @author Hardik Gohil
      * @param tenderId
      * @param tableId
      * @param isLibraryForm
      * @param modelMap
      * @param request
      * @return
      */
     @RequestMapping(value = "/buyer/myLibrary/{tenderId}/{formId}/{actualTenderId}/{isWorkFlow}/{isLibraryForm}/{enc}", method = RequestMethod.GET)
     public String myLibrary(@PathVariable(TENDER_ID) Integer tenderId,@PathVariable("actualTenderId") Integer actualTenderId,@PathVariable("isWorkFlow") int isWorkFlow, @PathVariable(FORM_ID) int formId, @PathVariable("isLibraryForm") int isLibraryForm, ModelMap modelMap, HttpServletRequest request) {
     	String retVal="etender/buyer/ViewForm";
         try {
         	tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
         	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
         	modelMap.put("isLibraryForm", isLibraryForm);
         } catch (Exception e) {
             retVal= exceptionHandlerService.writeLog(e);
         } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, isLibraryForm == 1 ? libraryFormAddAudit :libraryFormRemAudit, tenderId, formId);
         }
         return retVal;
     }
     
     /**
      * Project Task #55777 
      * Use to add or remove Form from user's my library 
      * @author Hardik Gohil
      * @param modelMap
      * @param request
      * @param redirectAttributes
      * @return
      */
     @RequestMapping(value = "/buyer/submitmylibraryform", method = RequestMethod.POST)
     public String submitMyLibraryForm(ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) {
         int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
         int formId = StringUtils.hasLength(request.getParameter(HIDDEN_FORM_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_FORM_ID)) : 0;
         int isLibraryForm = StringUtils.hasLength(request.getParameter("hdIsLibraryForm")) ? Integer.parseInt(request.getParameter("hdIsLibraryForm")) : 0;
         int actualTenderId = StringUtils.hasLength(request.getParameter("hdActualTenderId")) ? Integer.parseInt(request.getParameter("hdActualTenderId")) : 0;
         int userId=abcUtility.getSessionUserId(request);
         String retVal=REDIRECT_SESSION_EXPIRED;
         boolean success=false;
         try {
         	if(userId!=0){	
         		success=tenderFormService.addFormToMyLibrary(userId,formId, isLibraryForm);
         		redirectAttributes.addFlashAttribute(success? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString() ,success? isLibraryForm == 1 ? "redirect_success_myLibraryadd" : "redirect_success_myLibraryrem":  CommonKeywords.ERROR_MSG_KEY.toString());
         		retVal=success ? "etender/buyer/managetenderformlibrary/"+actualTenderId+"/0" : "etender/buyer/"+tenderId+"/"+formId+"/"+actualTenderId+"/0"+"/"+isLibraryForm;
         		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
         	}
         } catch (Exception e) {
             retVal= exceptionHandlerService.writeLog(e);
         } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, (isLibraryForm == 1 ? submitMyLibraryFormAddAudit : submitMyLibraryFormRemAudit), tenderId, formId);
         }
         return retVal;
     }
     @RequestMapping(value = "/buyer/viewauthorizedrfx/{userId}/{enc}" , method = RequestMethod.GET )
     public String viewAuthorizedRFX(@PathVariable("userId") int userId, HttpServletRequest request,ModelMap modelMap) {
    	 String page="/etender/buyer/ViewAuthorizedRFXReport";
    	 String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    	 try {
    		 ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    		 modelMap.addAttribute("reportId",viewAuthorizedRFXReportId);
    		 modelMap.addAttribute("userId",userId);
    		 reportGeneratorService.getReportConfigDetails(viewAuthorizedRFXReportId, modelMap);
		} catch (Exception e) {
			page = exceptionHandlerService.writeLog(e);
		}
    	 finally {
    		 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewAuthorizedRfxAndTender, viewAuthorizedRFX, 0,0,ipAddress);    		 
		}
    	 return page;
     }
     
     @RequestMapping(value = "/bidder/extendEndTime/{tenderId}/{enc}", method = RequestMethod.GET)
     public void extendEndTime(@PathVariable("tenderId") int tenderId,HttpServletRequest request, HttpServletResponse response, HttpSession session) {           
         try 
         {
             if (session !=null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null && session.getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) 
             {
            	 session.setMaxInactiveInterval(request.getSession().getMaxInactiveInterval());
             }
             else
             {
                 response.getWriter().write("sessionexpired");
             }

         } catch (Exception ex) {
             exceptionHandlerService.writeLog(ex);
         }
     }
}