package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblLoadingFactorProcessDao;
import com.etl.eproc.etender.model.TblLoadingFactorProcess;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblLoadingFactorProcessImpl extends AbcAbstractClass<TblLoadingFactorProcess> implements TblLoadingFactorProcessDao {

  

    @Override
    public void addTblLoadingFactorProcess(TblLoadingFactorProcess tblLoadingFactorProcess){
        super.addEntity(tblLoadingFactorProcess);
    }

    @Override
    public void deleteTblLoadingFactorProcess(TblLoadingFactorProcess tblLoadingFactorProcess) {
        super.deleteEntity(tblLoadingFactorProcess);
    }

    @Override
    public void updateTblLoadingFactorProcess(TblLoadingFactorProcess tblLoadingFactorProcess) {
        super.updateEntity(tblLoadingFactorProcess);
    }

    @Override
    public List<TblLoadingFactorProcess> getAllTblLoadingFactorProcess() {
        return super.getAllEntity();
    }

    @Override
    public List<TblLoadingFactorProcess> findTblLoadingFactorProcess(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblLoadingFactorProcessCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblLoadingFactorProcess> findByCountTblLoadingFactorProcess(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblLoadingFactorProcess(List<TblLoadingFactorProcess> tblLoadingFactorProcesss){
        super.updateAll(tblLoadingFactorProcesss);
    }

	@Override
	public void saveOrUpdateTblLoadingFactorProcess(TblLoadingFactorProcess tblLoadingFactorProcess) {
		super.saveOrUpdateEntity(tblLoadingFactorProcess);
	}
}
