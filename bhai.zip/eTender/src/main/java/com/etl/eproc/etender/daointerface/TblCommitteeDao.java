/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblCommittee;
import java.util.List;

/**
 *
 * @author shreyansh.shah
 */
public interface TblCommitteeDao  {

    public void addTblCommittee(TblCommittee tblCommittee);

    public void deleteTblCommittee(TblCommittee tblCommittee);

    public void updateTblCommittee(TblCommittee tblCommittee);

    public List<TblCommittee> getAllTblCommittee();

    public List<TblCommittee> findTblCommittee(Object... values) throws Exception;

    public List<TblCommittee> findByCountTblCommittee(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCommitteeCount();

    public void saveUpdateAllTblCommittee(List<TblCommittee> tblCommittees);
}
