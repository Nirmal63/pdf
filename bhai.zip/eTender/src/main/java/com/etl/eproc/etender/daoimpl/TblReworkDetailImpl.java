package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblReworkDetailDao;
import com.etl.eproc.etender.model.TblReworkDetail;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblReworkDetailImpl extends AbcAbstractClass<TblReworkDetail> implements TblReworkDetailDao {

  

    @Override
    public void addTblReworkDetail(TblReworkDetail tblReworkDetail){
        super.addEntity(tblReworkDetail);
    }

    @Override
    public void deleteTblReworkDetail(TblReworkDetail tblReworkDetail) {
        super.deleteEntity(tblReworkDetail);
    }

    @Override
    public void updateTblReworkDetail(TblReworkDetail tblReworkDetail) {
        super.updateEntity(tblReworkDetail);
    }

    @Override
    public List<TblReworkDetail> getAllTblReworkDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblReworkDetail> findTblReworkDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblReworkDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblReworkDetail> findByCountTblReworkDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblReworkDetail(List<TblReworkDetail> tblReworkDetails){
        super.updateAll(tblReworkDetails);
    }
}
