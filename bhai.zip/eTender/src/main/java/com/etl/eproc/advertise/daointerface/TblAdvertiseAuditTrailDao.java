package com.etl.eproc.advertise.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.advertise.model.TblAdvertiseAuditTrail;
import java.util.List;

public interface TblAdvertiseAuditTrailDao  {

    public void addTblAdvertiseAuditTrail(TblAdvertiseAuditTrail tblAdvertiseAuditTrail);

    public void deleteTblAdvertiseAuditTrail(TblAdvertiseAuditTrail tblAdvertiseAuditTrail);

    public void updateTblAdvertiseAuditTrail(TblAdvertiseAuditTrail tblAdvertiseAuditTrail);

    public List<TblAdvertiseAuditTrail> getAllTblAdvertiseAuditTrail();

    public List<TblAdvertiseAuditTrail> findTblAdvertiseAuditTrail(Object... values) throws Exception;

    public List<TblAdvertiseAuditTrail> findByCountTblAdvertiseAuditTrail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAdvertiseAuditTrailCount();

    public void saveUpdateAllTblAdvertiseAuditTrail(List<TblAdvertiseAuditTrail> tblAdvertiseAuditTrails);
}