package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TblCPPPXmlEntry;

public interface TblCPPPXmlEntryDao  {

    public void addTblCPPPXmlEntry(TblCPPPXmlEntry tblCPPPXmlEntry);

    public void deleteTblCPPPXmlEntry(TblCPPPXmlEntry tblCPPPXmlEntry);

    public void updateTblCPPPXmlEntry(TblCPPPXmlEntry tblCPPPXmlEntry);

    public List<TblCPPPXmlEntry> getAllTblCPPPXmlEntry();

    public List<TblCPPPXmlEntry> findTblCPPPXmlEntry(Object... values) throws Exception;

    public List<TblCPPPXmlEntry> findByCountTblCPPPXmlEntry(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCPPPXmlEntryCount();

    public void saveUpdateAllTblCPPPXmlEntry(List<TblCPPPXmlEntry> tblCPPPXmlEntrys);
}