/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.model.TblCustomParameter;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblEventEnquiry;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.eauction.model.TblAuction;
import com.etl.eproc.etender.databean.TenderCorrigendumDetailDtBean;
import com.etl.eproc.etender.databean.TenderCorrigendumDocumentDtBean;
import com.etl.eproc.etender.databean.TenderCorrigendumDtBean;
import com.etl.eproc.etender.model.TblCorrigendum;
import com.etl.eproc.etender.model.TblPreBidReport;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderPublicKey;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.CommitteeFormationService;
import com.etl.eproc.etender.services.EventBidSubmissionService;
import com.etl.eproc.etender.services.PrebidService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderCorrigendumService;

import java.util.Date;
import java.util.HashMap;

/**
 *
 * @author dipal
 */
@Controller
public class TenderDocumentController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private PrebidService prebidService;
    @Autowired
    private TenderCorrigendumService tenderCorrigendumService;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
   	private CommitteeFormationService committeeFormationService;
    @Autowired
    private EventBidSubmissionService eventBidSubmissionService;
    @Autowired
    private DepartmentUserService departmentUserService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Value("#{projectProperties['officer.docstatus.pending']?:0}")
    private int officerDocStatusPending;
    @Value("#{projectProperties['officer.docstatus.approve']?:1}")
    private int officerDocStatusApprove;
    @Value("#{projectProperties['officer.docstatus.cancel']?:3}")
    private int officerDocStatusCancel;
    @Value("#{tenderlinkProperties['pre-bid_meeting_upload']?:216}")
	 private int preBidMomDocLinkId;
    @Value("#{projectProperties['signer_version']}")
    private String signerVersion;
    @Value("#{projectProperties['signer_key']}")
    private String signerkey;
    @Value("#{linkProperties['hide_registration_link']?:3355}")
    private int hideRegistrationLinkId;
    
//     @Value("#{auctionAuditTrailProperties['getuploaddocuments']}")
//     private String getUploadDocuments;
//     @Value("#{auctionAuditTrailProperties['getapproveauctiondocuments']}")
//     private String getApproveAuctionDocuments;
//     @Value("#{auctionAuditTrailProperties['getdownloadauctiondocuments']}")
//     private String getDownloadAuctionDocuments;
//     @Value("#{auclinkProperties['document_upload']?:123}")
//     private int documentUpload;
//     @Value("#{auclinkProperties['document_approve']?:101}")
//     private int documentAprove;
//     @Value("#{auclinkProperties['document_download']?:102}")
//     private int documentDownload;
    @Value("#{etenderAuditTrailProperties['getuploadtenderdocuments']}")
    private String getUploadTenderDocuments;
    @Value("#{etenderAuditTrailProperties['getapprovetenderdocuments']}")
    private String getApproveTenderDocuments;
    @Value("#{tenderlinkProperties['notice_and_document_upload']?:175}")
    private int uploadTenderDocLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_approve_document']?:249}")
    private int approveTenderDocLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_download']?:255}")
    private int downloadTenderDocLinkId;
    @Value("#{tenderlinkProperties['corrigendum_upload']?:182}")
    private int corrigendumUpload;
    @Value("#{tenderlinkProperties['notice_and_document_cancel_document']?:250}")
    private int cancelTenderDocLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_cancel']?:170}")    
    private int tenderCancelLink;
    @Value("#{etenderAuditTrailProperties['getcanceltenderdocuments']}")
    private String getCancelTenderDocuments;
    @Value("#{tenderlinkProperties['bidder_download_document']?:381}")
    private int downloadTenderDocByBidderLinkId;
    @Value("#{etenderAuditTrailProperties['getTenderDocumentDownload']}")
    private String getTenderDocumentDownload;
    @Value("#{tenderlinkProperties['upload_clarification']?:1182}")
	private int upload_clarificationLinkId;
    @Value("#{advertiselinkProperties['upload_document']?:2287}")
    private int uploadDocLinkId;
    @Value("#{tenderlinkProperties['upload_reference_doc']?:5547}")
    private int uploadTenderReferenceDoc;
    @Value("#{etenderAuditTrailProperties['getUploadRefDoc']}")
    private String getTenderUploadRefDoc;
    @Value("#{tenderlinkProperties['upload_reference_doc_bidderwise']?:5548}")
    private int uploadTenderReferenceDocBidderWise;
    @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
    private String queueName;
    @Value("#{eauctionProperties['event_enquiry_mail']?:409}")
    private String eventEnquiryMailTemplateId;
    @Value("#{linkProperties['event_enq_mail']?:5554}")
    private int eventEnqmail;
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    @Autowired
    private ClientService clientService;
    /**
     * to get Auction document upload page
     *
     * @param objectId
     * @param request
     * @param modelMap
     * @return String
     */
    @RequestMapping(value = "/etender/buyer/uploaddocuments/{objectId}/{enc}", method = RequestMethod.GET)
    public String uploadDocuments(@PathVariable("objectId") int objectId, HttpServletRequest request, ModelMap modelMap) {
	int clientId = 0;
	try {
            TblPreBidReport tblPreBidReport = new TblPreBidReport();
            List<TblPreBidReport> preBidReportList = prebidService.getPreBidReportByTenderId(objectId);
            if(preBidReportList.size() > 0) {
                tblPreBidReport.setPrebidReportId(preBidReportList.get(0).getPrebidReportId());
            }
            tblPreBidReport.setTblTender(new TblTender(objectId));
            tblPreBidReport.setTblUserLogin(new TblUserLogin(abcUtility.getSessionUserId(request)));
            tblPreBidReport.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
            tblPreBidReport.setCstatus(0);
            tblPreBidReport.setRemark("");
            prebidService.addTblPreBidReport(tblPreBidReport);
	    clientId = abcUtility.getSessionClientId(request);
	    tenderCommonService.tenderSummary(objectId, modelMap, clientId);
	    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(65, clientId);
	    int allowedSize = 0;
	    StringBuilder allowedExt = new StringBuilder();
	    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
		allowedSize = lstDocUploadConf.get(0).getMaxSize();
		allowedExt.append(lstDocUploadConf.get(0).getType());
		modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
	    }
	    int index = allowedExt.toString().indexOf(",");
	    allowedExt.insert(index + 1, "*.");
	    while (index >= 0) {
		index = allowedExt.toString().indexOf(",", index + ",".length());
		allowedExt.insert(index + 1, "*.");
	    }

	    modelMap.addAttribute("allowedExt", allowedExt);
	    modelMap.addAttribute("allowedSize", allowedSize/1024);
	    modelMap.addAttribute("linkId", preBidMomDocLinkId);
	    modelMap.addAttribute("tenderId", objectId);
	    modelMap.addAttribute("cStatusDoc", 5);
            modelMap.addAttribute("cStatusDocView",officerDocStatusApprove);
	} catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), preBidMomDocLinkId, "Access prebid upload document page", objectId, 0);
	}
	return "etender/buyer/UploadDocuments";
    }

    /**
     * to get Approve tender documents page
     *
     * @param tenderId
     * @param request
     * @param modelMap
     * @return String
     */
    @RequestMapping(value = "/etender/buyer/approvetenderdocuments/{tenderId}/{enc}", method = RequestMethod.GET)
    public String approveTenderDocuments(@PathVariable("tenderId") int tenderId, HttpServletRequest request, ModelMap modelMap) {
	try {
		String publicKey=null;
    	if(abcUtility.getSessionIsPkiEnabled(request)==1){
    		String certIds[] = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
    		if(certIds!=null && certIds.length!=0){
    			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
    		}
    		modelMap.addAttribute("publicKey", publicKey);
		}
		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	    modelMap.addAttribute("linkId", uploadTenderDocLinkId);
	    modelMap.addAttribute("objectId", tenderId);
	    modelMap.addAttribute("cStatusDoc", officerDocStatusApprove);
	} catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), approveTenderDocLinkId, getApproveTenderDocuments, tenderId, 0);
	}
		return "etender/buyer/ApproveTenderDocuments";
    }
    
    @RequestMapping(value = "/etender/buyer/canceltenderdocuments/{tenderId}/{enc}", method = RequestMethod.GET)
    public String cancelTenderDocuments(@PathVariable("tenderId") int tenderId, HttpServletRequest request, ModelMap modelMap) {
	try {
		String publicKey=null;
    	if(abcUtility.getSessionIsPkiEnabled(request)==1){
    		String certIds[] = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
    		if(certIds!=null && certIds.length!=0){
    			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
    		}
    		modelMap.addAttribute("publicKey", publicKey);
		}
		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	    modelMap.addAttribute("linkId", uploadTenderDocLinkId);
	    modelMap.addAttribute("objectId", tenderId);
	    modelMap.addAttribute("cStatusDoc", officerDocStatusCancel);
	} catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), cancelTenderDocLinkId, getCancelTenderDocuments, tenderId, 0);
	}
		return "etender/buyer/ApproveTenderDocuments";
    }

    /**
     * to get tender document download page from buyer side, bidder side
     * as well as from the home page
     *
     * @param tenderId
     * @param request
     * @param modelMap
     * @return String
     */
    @RequestMapping(value = {"/etender/buyer/downloadtenderdocuments/{tenderId}/{enc}", "/etender/bidder/downloadtenderdocuments/{tenderId}/{enc}", "/etender/bidder/documentsdownloadfortender/{tenderId}/{enc}", "/downloadtenderdocuments/{tenderId}"}, method = RequestMethod.GET)
    public String downloadTenderDocuments(@PathVariable("tenderId") int tenderId, HttpServletRequest request, ModelMap modelMap) {
    int userTypeId=0;
	try {
		int clientId = abcUtility.getSessionClientId(request);
		if(abcUtility.getSessionUserId(request) == 0) {  // common request mapping
			List<Integer> sector = new ArrayList<Integer>();
			sector.add(1);
			sector.add(2);
			List<Object> drtClient = clientService.getClientFromSector(sector ,clientId); 
    		if(drtClient.isEmpty()) {
    			boolean isTenderView  = commonService.isTenderView(tenderId ,clientId);
    			if(!isTenderView) {
    				return "redirect:/";
    			}
    		}
		}
		modelMap.addAttribute("linkId", uploadTenderDocLinkId);
	    modelMap.addAttribute("isReadOnly", "Y");
	    modelMap.addAttribute("isTenderDocDownload", "Y");
	    modelMap.addAttribute("objectId", tenderId);
	    userTypeId=abcUtility.getSessionUserTypeId(request);
	    if(userTypeId == 2 || userTypeId == 0){
	    	modelMap.addAttribute("cStatusDoc", -2);
		    modelMap.addAttribute("cStatusDocView", -2);
	    }else{
		    modelMap.addAttribute("cStatusDoc", -1);
		    modelMap.addAttribute("cStatusDocView", -1);
	    }
	    List<TblCorrigendum> corrigendumList=tenderCorrigendumService.getAllCorrigendumByTenderId(tenderId);
	    modelMap.addAttribute("corrigendumList", corrigendumList);
	    modelMap.addAttribute("preBidReportList", prebidService.getPreBidReportByTenderId(tenderId));
	    modelMap.addAttribute("tenderDocSize",fileUploadService.getOfficerDocs(tenderId, abcUtility.getSessionClientId(request), uploadTenderDocLinkId, -1));
	    
	    List<TenderCorrigendumDtBean> resultList = new ArrayList<TenderCorrigendumDtBean>();
	    List<TenderCorrigendumDetailDtBean> detailList = new ArrayList<TenderCorrigendumDetailDtBean>();
	    // dipika start change
	    String ajaxUrl = abcUtility.getSessionUserId(request)!=0 ?"ajax/downloadfile/" : "/ajaxcall/downloadfile/";
	    for(TblCorrigendum tblCorrigendum : corrigendumList){
	    	List<Object[]> data=fileUploadService.getOfficerDocs(tblCorrigendum.getCorrigendumId(), abcUtility.getSessionClientId(request), corrigendumUpload, officerDocStatusApprove);
	    	List<TenderCorrigendumDocumentDtBean> docList=new ArrayList<TenderCorrigendumDocumentDtBean>();
	    	TenderCorrigendumDtBean corrigendumDtBean = new TenderCorrigendumDtBean();
	    	TenderCorrigendumDetailDtBean tcddb = new TenderCorrigendumDetailDtBean();
	    	for (int i = 0; i < data.size(); i++) {
	            TenderCorrigendumDocumentDtBean tenderCorrigendumDocumentDtBean = new TenderCorrigendumDocumentDtBean();
	            tenderCorrigendumDocumentDtBean.setOfficerDocMappingId(Integer.valueOf(data.get(i)[0].toString()));
	            tenderCorrigendumDocumentDtBean.setDocName(String.valueOf(data.get(i)[1]));
	            tenderCorrigendumDocumentDtBean.setDescription(String.valueOf(data.get(i)[2]));
	            tenderCorrigendumDocumentDtBean.setFileSize(String.valueOf(new BigDecimal(Double.parseDouble(String.valueOf(data.get(i)[3]))/(1024*1024)).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue()));
	            tenderCorrigendumDocumentDtBean.setMappedOn(CommonUtility.convertTimezone(String.valueOf(data.get(i)[4])));
	            tenderCorrigendumDocumentDtBean.setCstatus("Approved");
	            if(abcUtility.getSessionUserId(request)!=0) {
	                tenderCorrigendumDocumentDtBean.setDownloadUrl(request.getContextPath()+"/"+ ajaxUrl + Integer.valueOf(data.get(i)[0].toString()) + "/" + tblCorrigendum.getCorrigendumId()
	                        + encryptDecryptUtils.generateRedirect(ajaxUrl + Integer.valueOf(data.get(i)[0].toString()) + "/" + tblCorrigendum.getCorrigendumId(), request));
	            }
	            else {
	            	tenderCorrigendumDocumentDtBean.setDownloadUrl(request.getContextPath() + ajaxUrl + Integer.valueOf(data.get(i)[0].toString()) + "/" + tblCorrigendum.getCorrigendumId());
	            }
	            docList.add(tenderCorrigendumDocumentDtBean);
	           
	        }
	    	 tcddb.setCorrigendumId(tblCorrigendum.getCorrigendumId());
	            detailList.add(tcddb);
	        corrigendumDtBean.setDetails(detailList);
	        corrigendumDtBean.setDocuments(docList);
	        resultList.add(corrigendumDtBean);
	    }       
	    modelMap.addAttribute("resultList", resultList);
	   // dipika end change
        SessionBean sessionBean = (SessionBean)request.getSession().getAttribute("sessionObject");
        int companyId = 0;
        if(sessionBean != null){
        	companyId = sessionBean.getCompanyId();
        }
        else
        {
        	int ShowAccessDetail=abcUtility.getAccessDetail(request);
        	if(ShowAccessDetail==1){
        	int visitorCount=commonService.getVisitorDetail(request);
    		modelMap.addAttribute("visitorCount",visitorCount);
        	}
        }
	    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            boolean showDownloadAll = true;
            if(companyId!=0){
                Date currentDate = commonService.getServerDateTime();
            if(((Date)modelMap.get("documentStartDate")) != null && ((Date)modelMap.get("documentEndDate")) !=null )
                {
                if(((Date)modelMap.get("documentStartDate")).compareTo(currentDate) > 0 || 
                        ((Date)modelMap.get("documentEndDate")).compareTo(currentDate)<0 || 
                        ((Integer)modelMap.get("downloadDocument")== 3 && !fileUploadService.isPaymentDone(1, tenderId, companyId))){
                    showDownloadAll=false;
                }                                                
            }
            
            
            if(showDownloadAll){
	            if((userTypeId ==1 || userTypeId == 3) && userTypeId != 2){
	            	showDownloadAll=true;
	        	}else if(userTypeId == 2  && fileUploadService.isBidderMappedToTenderId(tenderId,abcUtility.getSessionUserId(request))){
	        		showDownloadAll=true;
	        	}else if(userTypeId == 2  && !fileUploadService.isBidderMappedToTenderId(tenderId,abcUtility.getSessionUserId(request))){
	        		showDownloadAll=false;
	        	}
            }
	    modelMap.addAttribute("showDownloadAll", showDownloadAll);
	    modelMap.addAttribute("NITDashboard", false);
	    if(request.getRequestURI().contains("documentsdownloadfortender")){
	    	 modelMap.addAttribute("NITDashboard", true);
	    }
	}
      modelMap.addAttribute("isRegistrationLinkHidden", clientService.isRegistrationLinkHidden(clientId, hideRegistrationLinkId, 1));
    } catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), userTypeId == 2 ? downloadTenderDocByBidderLinkId : downloadTenderDocLinkId, getTenderDocumentDownload, tenderId, 0);
	}
		return "etender/common/DownloadTenderDocuments";
    }
    
    /**
     * to get tender upload document page at buyer side 
     * @param objectId
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/etender/buyer/uploadtenderdocuments/{objectId}/{enc}", method = RequestMethod.GET)
    public String uploadTendereDocuments(@PathVariable("objectId") int objectId, HttpServletRequest request, ModelMap modelMap) {
	int clientId = 0;
	try {
	    clientId = abcUtility.getSessionClientId(request);
	    tenderCommonService.tenderSummary(objectId, modelMap, clientId);
	    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(57, clientId);
	    int allowedSize = 0;
	    StringBuilder allowedExt = new StringBuilder();
	    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
			allowedSize = lstDocUploadConf.get(0).getMaxSize();
			allowedExt.append(lstDocUploadConf.get(0).getType());
			modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
	    }
	    int index = allowedExt.toString().indexOf(",");
	    allowedExt.insert(index + 1, "*.");
	    while (index >= 0) {
			index = allowedExt.toString().indexOf(",", index + ",".length());
			allowedExt.insert(index + 1, "*.");
	    }

	    modelMap.addAttribute("allowedExt", allowedExt);
	    modelMap.addAttribute("allowedSize", allowedSize/1024);
	    modelMap.addAttribute("linkId", uploadTenderDocLinkId);
	    modelMap.addAttribute("tenderId", objectId);
	    modelMap.addAttribute("isTenderDocDownload", "Y");
	    modelMap.addAttribute("cStatusDoc", officerDocStatusPending);
	} catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), uploadTenderDocLinkId, getUploadTenderDocuments, objectId, 0);
	}
		return "etender/buyer/UploadTenderDocuments";
    }
    
    @RequestMapping(value={"/etender/buyer/downloadquestionanswerdocuments/{tenderId}/{enc}","/etender/bidder/downloadquestionanswerdocuments/{tenderId}/{enc}","/downloadquestionanswerdocuments/{tenderId}"}, method=RequestMethod.GET)
	public String downloadQuestionAnswerDocuments(@PathVariable("tenderId") int tenderId, HttpServletRequest request, ModelMap modelMap){
    	try {
    		 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		 modelMap.addAttribute("objectIdNew", tenderId);
			 modelMap.addAttribute("linkId", upload_clarificationLinkId);
			 int userTypeId=abcUtility.getSessionUserTypeId(request);
			    if(userTypeId == 2){
			    	modelMap.addAttribute("cStatusDoc", -2);
				    modelMap.addAttribute("cStatusDocView", -2);
			    }else{
				    modelMap.addAttribute("cStatusDoc", -1);
				    modelMap.addAttribute("cStatusDocView", -1);
			    }
			 modelMap.addAttribute("isReadOnly","Y");
			 modelMap.addAttribute("isTenderDocDownload", "Y");
    	} catch (Exception e) {
    	    return exceptionHandlerService.writeLog(e);
    	} finally {
    	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), upload_clarificationLinkId,"Download Clarification Document" , tenderId, 0);
    	}
    	return "common/questionanswer/DownloadClarificationListing";
	}
    
    /**
     * @param tenderId
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/getTenderBuyerPublicKey/{tenderId}/{envId}", method = RequestMethod.GET,produces = "application/json")
    @ResponseBody
    public String getTenderBuyerPublicKey(@PathVariable("tenderId") int tenderId,@PathVariable("envId") int envId)throws Exception{
    	JSONObject obj = new JSONObject();
    	JSONArray jsonArray = new JSONArray();
    	List<String> list=null;
    	boolean status = true;
    	int tenderCstatus = 0;
    	int isOpeningByCommittee = 0;
    	int isTwoStageOpening = 0;
    	int isCertRequired = 0;
    	int count = 0;
    	boolean committeepublish = false;
    	Date serverDate = null;
    	Date submissionEndDate = null;
    	List<Object[]> l = tenderCommonService.getTenderFields(tenderId, "cstatus,isCertRequired,isTwoStageOpening,isOpeningByCommittee,submissionEndDate");
  		if(l!=null && !l.isEmpty()){
  			Object[] tenderData = l.get(0);
  			tenderCstatus = Integer.parseInt(tenderData[0].toString());
  			isCertRequired = Integer.parseInt(tenderData[1].toString());
  			isTwoStageOpening = Integer.parseInt(tenderData[2].toString());
  			isOpeningByCommittee = Integer.parseInt(tenderData[3].toString());
  			submissionEndDate=(Date)tenderData[4];
  			serverDate=commonService.getServerDateTime();
  		}
  		
  		List<Object[]> lst = committeeFormationService.getCommitteeDetails(tenderId, 1, 1);
  		if(lst!=null && !lst.isEmpty()){
  			for(Object[] committeedata : lst){
  				if(Integer.parseInt(committeedata[4].toString())==1 && Integer.parseInt(committeedata[3].toString())==1){
  					committeepublish = true;
  				}
  			}
  		}
  		
  		boolean isEnvelopeExist = commonService.isEnvelopeExist(tenderId, envId);
  		
  		if(tenderCstatus == 1){
  			if(isCertRequired == 1){
  				if(submissionEndDate.after(serverDate)){
  					if(committeepublish){
  	  	  				if(!isEnvelopeExist){
  		  	  				status = false;
  			  	  			count = 4;
  	  	  				}
  	  	  			} else {
  		  	  			status = false;
  		  	  			count = 3;
  	  	  			}
  				} else {
  					status = false;
  	  	  			count = 5;
  				}
  			} else {
  				status = false;
  	  			count = 2;
  			}
  		} else {
  			status = false;
  			count = 1;
  		}
  		
  		switch(count) {
  			case 1 :
  				obj.put("errMsg", "Tender not published");
  				break;
  			case 2 :
  				obj.put("errMsg", "non PKI tender");
  				break;
  			case 3 :
  				obj.put("errMsg", "opening committee not published");
  				break;
  			case 4 :
  				obj.put("errMsg", "Envelope not mapped in tender");
  				break;
  			case 5 :
  				obj.put("errMsg", "Tender is archive");
  				break;	
  		}
  		obj.put("Version", signerVersion);
  		obj.put("Symmetric_Key", signerkey);
  		obj.put("status", status);
  		int envelopeId = 0;
  		List<Object[]> envelopeData = commonService.getTenderEnvelope(tenderId);
  		if(envelopeData!=null && !envelopeData.isEmpty()){
  			for(Object[] lst1 : envelopeData){
  				if(Integer.parseInt(lst1[3].toString()) == envId){
  					envelopeId = Integer.parseInt(lst1[0].toString());
  				}
  			}
  		}
  		obj.put("envelopeId",envelopeId);
  		if(tenderCstatus == 1 && isCertRequired == 1 && isOpeningByCommittee == 1 && isEnvelopeExist){
  			List<TblTenderPublicKey> lisTblTenderPublicKeys=tenderCommonService.getTenderBuyerPublicKey(tenderId);
  	    	if (lisTblTenderPublicKeys != null && !lisTblTenderPublicKeys.isEmpty()) {
  	    		list=new ArrayList<String>();
  	    		for (TblTenderPublicKey tblTenderPublicKey : lisTblTenderPublicKeys) {
  	    			list.add(tblTenderPublicKey.getPublicKey());
  	    			jsonArray.put(tblTenderPublicKey.getPublicKey());
  				}
  	    		try {
  					obj.put("publicKey", jsonArray);
  				} catch (JSONException e) {
  					return exceptionHandlerService.writeLog(e);
  				}
  	    	}
  		}
    	
    	return obj.toString();
    }
    @RequestMapping(value = {"/downloadadvertisedocuments/{advertisementId}"}, method = RequestMethod.GET)
    public String downloadAdvertiseDocuments(@PathVariable("advertisementId") int advertisementId, HttpServletRequest request, ModelMap modelMap) {
    	try {
   		 //tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
   		 modelMap.addAttribute("objectIdNew", advertisementId);
			 modelMap.addAttribute("linkId", uploadDocLinkId);
			 int userTypeId=abcUtility.getSessionUserTypeId(request);
			    if(userTypeId == 2){
			    	modelMap.addAttribute("cStatusDoc", -2);
				    modelMap.addAttribute("cStatusDocView", -2);
			    }else{
				    modelMap.addAttribute("cStatusDoc", -1);
				    modelMap.addAttribute("cStatusDocView", -1);
			    }
			 modelMap.addAttribute("isReadOnly","Y");
			 modelMap.addAttribute("isTenderDocDownload", "Y");
   	} catch (Exception e) {
   	    return exceptionHandlerService.writeLog(e);
   	} finally {
   	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 2287,"Advertisement Document" , advertisementId, 0);
   	}
    	return "etender/common/DownloadAdvertiseDocuments";
    } 
    
    /**
     * To get tender Cancel document and remarks download page for buyer side and bidder side
     *
     * @param tenderId
     * @param request
     * @param modelMap
     * @return String
     */
    @RequestMapping(value = {"/etender/buyer/viewtenderdocandremarks/{tenderId}/{enc}", "/etender/bidder/viewtenderdocandremarks/{tenderId}/{enc}", "/viewtenderdocandremarks/{tenderId}"}, method = RequestMethod.GET)
    public String viewTenderDocuments(@PathVariable("tenderId") int tenderId, HttpServletRequest request, ModelMap modelMap) {
    int userTypeId=0;
	try {
	    modelMap.addAttribute("linkId", tenderCancelLink);
	    modelMap.addAttribute("isReadOnly", "Y");
	    modelMap.addAttribute("isTenderDocDownload", "Y");
	    modelMap.addAttribute("objectId", tenderId); 
	    userTypeId=abcUtility.getSessionUserTypeId(request);
	    if(userTypeId == 2){
	    	modelMap.addAttribute("cStatusDoc", -2);
		    modelMap.addAttribute("cStatusDocView", -2);
	    }else{
		    modelMap.addAttribute("cStatusDoc", -1);
		    modelMap.addAttribute("cStatusDocView", -1);
	    }
	  
	    modelMap.addAttribute("tenderDocSize",fileUploadService.getOfficerDocs(tenderId, abcUtility.getSessionClientId(request), tenderCancelLink, -1));
	    modelMap.addAttribute("remark",tenderCommonService.getCancelledTenderRemark(tenderId,tenderCancelLink));
	    
        SessionBean sessionBean = (SessionBean)request.getSession().getAttribute("sessionObject");
        int companyId = 0;
        if(sessionBean != null){
        	companyId = sessionBean.getCompanyId();
        }
        else
        {
        	int ShowAccessDetail=abcUtility.getAccessDetail(request);
        	if(ShowAccessDetail==1){
        	int visitorCount=commonService.getVisitorDetail(request);
    		modelMap.addAttribute("visitorCount",visitorCount);
        	}
        }
	    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            boolean showDownloadAll = true;
            if(companyId!=0){
                Date currentDate = commonService.getServerDateTime();
            if(((Date)modelMap.get("documentStartDate")) != null && ((Date)modelMap.get("documentEndDate")) !=null )
                {
                if(((Date)modelMap.get("documentStartDate")).compareTo(currentDate) > 0 || 
                        ((Date)modelMap.get("documentEndDate")).compareTo(currentDate)<0 || 
                        ((Integer)modelMap.get("downloadDocument")== 3 && !fileUploadService.isPaymentDone(1, tenderId, companyId))){
                    showDownloadAll=false;
                }                                                
            }
            
            if((userTypeId ==1 || userTypeId == 3) && userTypeId != 2){
            	showDownloadAll=true;
        	}else if(userTypeId == 2  && fileUploadService.isBidderMappedToTenderId(tenderId,abcUtility.getSessionUserId(request))){
        		showDownloadAll=true;
        	}else if(userTypeId == 2  && !fileUploadService.isBidderMappedToTenderId(tenderId,abcUtility.getSessionUserId(request))){
        		showDownloadAll=false;
        	}
	    modelMap.addAttribute("showDownloadAll", showDownloadAll);
	    
	}} catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), userTypeId == 2 ? tenderCancelLink : tenderCancelLink, getTenderDocumentDownload, tenderId, 0);
	}
		return "etender/common/ViewTenderDocAndRemarks";
    }
    
    /**
     * get detailed documents for cancel event
     * @author meghna
     * @param tenderId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/ajax/getcancelTenderDocDetails", method = RequestMethod.POST)
    public String getclarificationDocDetails(@RequestParam("txttenderId") int tenderId,HttpServletRequest request,ModelMap modelMap) {
        String returnStr="redirect:/sessionexpired";
        try {
            if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                     List<Object[]> singleUserDocumentDetails =fileUploadService.getOfficerDocs(tenderId, abcUtility.getSessionClientId(request), tenderCancelLink, -1);
                     modelMap.addAttribute("singleUserDocumentDetails",singleUserDocumentDetails);
                     returnStr = "/common/CancelTenderDocDetail";
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } 
        return returnStr;
    }
    @RequestMapping(value = "/getTenderStatus", method = RequestMethod.POST,produces = "application/json")
    @ResponseBody
    public String getTenderStatus(@RequestParam("tenderId") String tenderId,  HttpServletRequest request)throws Exception{
		JSONObject obj = new JSONObject();
    	try {
    		int cstatus = (Integer)tenderCommonService.getTenderField(Integer.parseInt(tenderId), "cstatus") != null?(Integer)tenderCommonService.getTenderField(Integer.parseInt(tenderId), "cstatus"):0;
    		if(cstatus == 1){
        		obj.put("cstatus","true");
    		}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
    	return obj.toString();
    }
    
    @RequestMapping(value = "/etender/buyer/uploadreferencedocuments/{objectId}/{enc}", method = RequestMethod.GET)
    public String uploadTenderRefDoc(@PathVariable("objectId") int objectId, HttpServletRequest request, ModelMap modelMap) {
    	String pageName="etender/buyer/UploadTenderRefDocuments";
        List<Object[]> Bidder=null;
       
        TblTender tblTender=null;
        int clientId = 0;
        try {
        	clientId = abcUtility.getSessionClientId(request);
        	tenderCommonService.tenderSummary(objectId, modelMap, clientId);
        	tblTender=tenderCommonService.getTenderById(objectId);
        	
        	Bidder=tenderCommonService.getTenderAllBidderDetail(objectId, tblTender.getTenderMode());
        	modelMap.addAttribute("isTenderArchive",eventBidSubmissionService.isTenderArchive(objectId));
        	modelMap.addAttribute("letestCstatusEncodeDecodeHistory", commonService.getLetestCstatusEncodeDecodeHistory(objectId));
        	

    	    tenderCommonService.tenderSummary(objectId, modelMap, clientId);
    	    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(305, clientId);
    	    int allowedSize = 0;
    	    StringBuilder allowedExt = new StringBuilder();
    	    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
    			allowedSize = lstDocUploadConf.get(0).getMaxSize();
    			allowedExt.append(lstDocUploadConf.get(0).getType());
    			modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
    	    }
    	    int index = allowedExt.toString().indexOf(",");
    	    allowedExt.insert(index + 1, "*.");
    	    while (index >= 0) {
    			index = allowedExt.toString().indexOf(",", index + ",".length());
    			allowedExt.insert(index + 1, "*.");
    	    }
    	    String publicKey=null;
        	if(abcUtility.getSessionIsPkiEnabled(request)==1){
        		String certIds[] = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
        		if(certIds!=null && certIds.length!=0){
        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
        		}
        		modelMap.addAttribute("publicKey", publicKey);
    		}
    	    modelMap.addAttribute("allowedExt", allowedExt);
    	    modelMap.addAttribute("allowedSize", allowedSize/1024);

    		modelMap.addAttribute("linkId", uploadTenderReferenceDoc);
    	    modelMap.addAttribute("tenderId", objectId);
    	    modelMap.addAttribute("isTenderDocDownload", "Y");
    	    modelMap.addAttribute("cStatusDoc", officerDocStatusCancel);
            modelMap.addAttribute("cStatusDocView", 1);
            modelMap.addAttribute("tenderMode",tblTender.getTenderMode());
            modelMap.addAttribute("tblTender",tblTender);
            modelMap.addAttribute("Bidders",Bidder);
            modelMap.addAttribute("showCreatedBy", 1); //for Uploaded by column in documents view
    } catch (Exception ex) {
         
         return exceptionHandlerService.writeLog(ex);
    } finally {
        auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), uploadTenderReferenceDoc, getTenderUploadRefDoc, objectId,0);
    }
    return pageName; 
}
    @RequestMapping(value = "/etender/buyer/uploadreferencedocumentsbidderwise/{objectId}/{bidderId}/{enc}", method = RequestMethod.GET)
    public String uploadTenderDocBidderWise(@PathVariable("objectId") int objectId,@PathVariable("bidderId") int bidderId, HttpServletRequest request, ModelMap modelMap) {
	int clientId = 0;
	try {
	    clientId = abcUtility.getSessionClientId(request);
	    tenderCommonService.tenderSummary(objectId, modelMap, clientId);
	    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(303, clientId);
	    int allowedSize = 0;
	    StringBuilder allowedExt = new StringBuilder();
	    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
			allowedSize = lstDocUploadConf.get(0).getMaxSize();
			allowedExt.append(lstDocUploadConf.get(0).getType());
			modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
	    }
	    int index = allowedExt.toString().indexOf(",");
	    allowedExt.insert(index + 1, "*.");
	    while (index >= 0) {
			index = allowedExt.toString().indexOf(",", index + ",".length());
			allowedExt.insert(index + 1, "*.");
	    }
	    String publicKey=null;
    	if(abcUtility.getSessionIsPkiEnabled(request)==1){
    		String certIds[] = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
    		if(certIds!=null && certIds.length!=0){
    			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
    		}
    		modelMap.addAttribute("publicKey", publicKey);
		}
	    modelMap.addAttribute("allowedExt", allowedExt);
	    modelMap.addAttribute("allowedSize", allowedSize/1024);

	    List<Integer> lstLink=new ArrayList<Integer>();
		lstLink.add(uploadTenderReferenceDocBidderWise);
		modelMap.addAttribute("linkId", lstLink);
	    modelMap.addAttribute("tenderId", objectId);
	    modelMap.addAttribute("isTenderDocDownload", "Y");
	    modelMap.addAttribute("cStatusDoc", officerDocStatusCancel);
	    modelMap.addAttribute("bidderId", bidderId);
        modelMap.addAttribute("childId", bidderId);
        modelMap.addAttribute("cStatusDocView", 1);
        modelMap.addAttribute("showCreatedBy", 1); //for Uploaded by column in documents view
	} catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), uploadTenderReferenceDocBidderWise, getTenderUploadRefDoc, objectId, 0);
	}
		return "etender/buyer/UploadTenderRefDocBidderWise";
    }
}