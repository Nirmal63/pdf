/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblProductCategory;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.etender.daointerface.TblItemBidderMapDao;
import com.etl.eproc.etender.daointerface.TblTenderBidderMapDao;
import com.etl.eproc.etender.daointerface.TblTenderMapBidderHistoryDao;
import com.etl.eproc.etender.model.TblItemBidderMap;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBidderMap;
import com.etl.eproc.etender.model.TblTenderMapBidderHistory;
import com.etl.eproc.etender.model.TblTenderTable;

/**
 *
 * @author vipul
 */
@Service
public class EventBidderMapService {

    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    @Autowired
    private TblTenderBidderMapDao tblTenderBidderMapDao;
    @Autowired
    private TblItemBidderMapDao tblItemBidderMapDao;
    @Autowired
    private TblTenderMapBidderHistoryDao tblTenderMapBidderHistoryDao;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private TenderFormService tenderFormService;
    /**
     * List of search options
     *
     * @return {@code List<SelectItem>}
     */
    public List<SelectItem> getSearchOptions() {
        List<SelectItem> lstSearchOpt = new ArrayList<SelectItem>();

        lstSearchOpt.add(new SelectItem("Email ID", 1));
        lstSearchOpt.add(new SelectItem("Company Name", 2));
        return lstSearchOpt;
    }
    
    /**
     * @author SULABH
     * @return
     */
    public HttpServletRequest getServletRequest() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return attr.getRequest();
    }

    /**
     *
     * params[0]=tenderId, params[1]=mappingType,params[2]=searchOpt, params[3]=clientId,params[4]=tableId,params[5]=rowId
     *
     * @param searchTxt
     * @param params
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getUnmappedBidder(String searchTxt, int... params) throws Exception {
        StringBuilder query = new StringBuilder();
        String langVal=WebUtils.getCookie(getServletRequest(), "locale").getValue();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", params[0]);
        var.put("clientId", params[3]);

        query.append("select distinct ul.userId,c.companyName,ul.loginId,")
        .append("(SELECT MAX(tbluserdetail.userDetailId) FROM TblUserDetail tbluserdetail ")
        .append("WHERE tbluserdetail.tblUserLogin.userId = ul.userId AND tbluserdetail.clientId = 0 ")
        .append(" ) AS userDetailID,c.companyId,ul.userName,ul.mobileNo,tblCountry.lang"+langVal+",tblState.lang"+langVal+",")
        .append(" bs.cstatus, ")
        .append(" ub.type, ")		
        .append(" CASE WHEN CONVERT(date, ub.startDate) <= CONVERT(date, getutcdate())  and CONVERT(date, ub.endDate) >= CONVERT(date, getutcdate()) THEN 0 ELSE 1 END as c10 ")
        .append(" from TblBidderStatus bs ")
        .append(" left join bs.tblUserBlackList ub with ub.cstatus = 1 ")
        .append("inner join bs.tblUserLogin ul ")
        .append("inner join bs.tblCompany c inner join c.tblCountry tblCountry inner join c.tblState tblState ")
        .append(" where bs.tblClient.clientId = :clientId").append(" and bs.cstatus in (1,3) and ");
        if (params[2] == 1) {
            query.append("ul.loginId = '").append(searchTxt).append("'");
        }else if (params[2] == 3) {
        	 String searchArry[] = searchTxt.split(",");
        	 
        	 for(int i=0;i<searchArry.length;i++){
        		 if(i!=searchArry.length-1){
        			 if(i==0){
        				 query.append("(c.keywordText like '%").append(searchArry[i]).append("%' or ");
        			 }else{
        				 query.append("c.keywordText like '%").append(searchArry[i]).append("%' or ");
        			 }
        		 }else{
        			 query.append(" c.keywordText like '%").append(searchArry[i]).append("%'");
        		 }
        	 }
        	 if(searchArry.length>1){
        		 query.append(")");
        	 }
        	 query.append(" and bs.cstatus = 1 and bs.tblClient.clientId = :clientId");
        }else {
            query.append("c.companyName like '%").append(searchTxt).append("%'");
        }
        if (params[1] != 1) {
            var.put("tableId", params[4]);
            query.append(" and c.companyId not in (")
                    .append("select tbltenderbiddermap.tblCompany.companyId from TblTenderBidderMap tbltenderbiddermap ")
                    .append("inner join tbltenderbiddermap.tblItemBidderMap tblitembiddermap ")
                    .append("where tbltenderbiddermap.tblCompany.companyId=c.companyId and ")
                    .append(" tbltenderbiddermap.tblTender.tenderId=:tenderId ");
            if (params[1] != 4) {
            	var.put("rowId", params[5]);
                query.append(" and tblitembiddermap.rowId=:rowId ");
            }
            query.append(" and tblitembiddermap.tblTenderTable.tableId=:tableId) ");
        } else {
            query.append(" and c.companyId not in (")
                    .append("select tbltenderbiddermap.tblCompany.companyId from TblTenderBidderMap tbltenderbiddermap ")
                    .append("where tbltenderbiddermap.tblCompany.companyId=c.companyId and ")
                    .append(" tbltenderbiddermap.tblTender.tenderId=:tenderId) ");
        }

        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     *
     * @param lstTblTenderBidderMap
     * @param lstTblTenderMapBidderHistory
     * @param mappingType
     * @param lstItemBidderMap
     * @return boolean
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public boolean addAllTenderBidderMap(List<TblTenderBidderMap> lstTblTenderBidderMap, List<TblTenderMapBidderHistory> lstTblTenderMapBidderHistory, int mappingType, List<TblItemBidderMap> lstItemBidderMap) throws Exception {
        boolean bSuccess = false;
        if (!lstTblTenderBidderMap.isEmpty()) {
            tblTenderBidderMapDao.saveUpdateAllTblTenderBidderMap(lstTblTenderBidderMap);
        }
        if (lstItemBidderMap != null) {
            tblItemBidderMapDao.saveUpdateAllTblItemBidderMap(lstItemBidderMap);
        }
        tblTenderMapBidderHistoryDao.saveUpdateAllTblTenderMapBidderHistory(lstTblTenderMapBidderHistory);
        bSuccess = true;
        return bSuccess;

    }

  	/*
  	 * add by vijay
  	 * Concurrency probelm
  	 * Bug Id #39768
  	 * */
    public boolean getMapBidderValue(int userId,int tenderId,List<Integer> rowId,int tableId) throws Exception {
    	 boolean bSuccess = false;
    	 Map<String, Object> var = new HashMap<String, Object>();
	     StringBuilder query = new StringBuilder(); 
	     query.append("select itembiddermap.rowId,tbltendder.tenderId from TblItemBidderMap itembiddermap inner join itembiddermap.tblTenderBidderMap tenderbiddermap inner join tenderbiddermap .tblTender tbltendder inner join tenderbiddermap.tblUserLogin tbluserlogin ");
	     query.append("where tbluserlogin.userId=:bidderid and tbltendder.tenderId=:tenderid and itembiddermap.rowId in (:rowid) and itembiddermap.tblTenderTable.tableId=:tableId");
	     var.put("bidderid",userId);
	     var.put("tenderid",tenderId);
	     var.put("rowid",rowId);
	     var.put("tableId", tableId);
	     List<Object[]> getmapvalue = hibernateQueryDao.createNewQuery(query.toString(), var);  
	     if(getmapvalue!=null && !getmapvalue.isEmpty())
	     {
	    	 bSuccess=true;
	     }
	     return bSuccess;
    }
    /**
     * Remove already mapped bidders
     *
     * @param mapBidderIds
     * @param lstTenderMapBidderHistory
     * @return int
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED)
    public int removeMappedBidders(String mapBidderIds, int mappingType, List<TblTenderMapBidderHistory> lstTenderMapBidderHistory, int tableId,String mapBiddersIds) throws Exception {
        int cnt = 0;
        StringBuilder query = new StringBuilder();
        StringBuilder delTenderBidderMap=new StringBuilder();
        StringBuilder selHQL=new StringBuilder();
        StringBuilder itemMapBidderIds=new StringBuilder();
        if (mappingType == 1) {
            query.append("delete from TblTenderBidderMap tbltenderbiddermap where tbltenderbiddermap.mapBidderId in (").append(mapBidderIds).append(")");
        } else {
            if (mappingType == 4) {
                query.append("delete from TblItemBidderMap tblitembiddermap where tblitembiddermap.tblTenderTable.tableId=").append(tableId).append(" and tblitembiddermap.tblTenderBidderMap.mapBidderId in(").append(mapBidderIds).append(")");
            } else {
                query.append("delete from TblItemBidderMap tblitembiddermap where tblitembiddermap.mapBidderItemId in(").append(mapBidderIds).append(")");
            }
        }
        cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(), null);
        if(cnt!=0 && mappingType!=1){
        	selHQL.append("select tblitembiddermap.tblTenderBidderMap.mapBidderId from TblItemBidderMap tblitembiddermap where tblitembiddermap.tblTenderBidderMap.mapBidderId in (").append(mapBiddersIds).append(")group by tblitembiddermap.tblTenderBidderMap.mapBidderId having COUNT(tblitembiddermap.tblTenderBidderMap.mapBidderId)!=0");
        	List<Object> lst=hibernateQueryDao.singleColQuery(selHQL.toString(), null);
        	for(Object list:lst){
	    		if(itemMapBidderIds.length()>0){
	    			itemMapBidderIds.append(",");
	    		}
	    		itemMapBidderIds.append(list);
	    	}
        delTenderBidderMap.append("delete from TblTenderBidderMap where mapBidderId in (").append(mapBiddersIds).append(")"); 
        if(itemMapBidderIds.length()>0){
        	delTenderBidderMap.append(" and mapBidderId not in (").append(itemMapBidderIds.toString()).append("))");
        }
        hibernateQueryDao.updateDeleteNewQuery(delTenderBidderMap.toString(), null);
        }
        if (cnt != 0) {
        	tblTenderMapBidderHistoryDao.saveUpdateAllTblTenderMapBidderHistory(lstTenderMapBidderHistory);
        }
        return cnt;
    }

    
    /**
     * @author SULABH
     * @param tenderId
     * return Long
     */
    
    public long getCountFromItemBidderMap(int tenderId)throws Exception{
    	long count=0;
    	
    	Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder selectSQL=new StringBuilder();
        selectSQL.append("select count(tblItemBidderMap.tblTenderBidderMap.mapBidderId) from TblItemBidderMap tblItemBidderMap");
        selectSQL.append(" where tblItemBidderMap.tblTenderBidderMap.mapBidderId in (select tblTenderBidderMap.mapBidderId  from TblTenderBidderMap tblTenderBidderMap where tblTenderBidderMap.tblTender.tenderId=:tenderId)");
    	List<Object> list=hibernateQueryDao.singleColQuery(selectSQL.toString(), var);
    	if(!list.isEmpty()){
    		count=(Long) list.get(0);
    	}
    	return count;    	
    }
    

    /**
     * @author SULABH
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public int deleteTenderBidderMap(int tenderId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderBidderMap tbltenderbiddermap where tbltenderbiddermap.tblTender.tenderId=:tenderId",var);        
        return cnt;
    }

    
    /**
     *
     * @param mappingPair
     * @param tenderId
     * @return int
     * @throws Exception
     */
    public int getBidderMappingCount(String mappingPair, int tenderId) throws Exception {
        int rowCount = 0;
        StringBuilder query = new StringBuilder();
        query.append("select COUNT(*) ")
                .append(" from apptender.tbl_TenderBidderMap a ")
                .append("inner join (SELECT * FROM (VALUES ").append(mappingPair)
                .append(") v (companyId)) b on a.companyId = b.companyId ")
                .append(" where a.tenderId = ").append(tenderId);
        rowCount = jdbcTemplate.queryForObject(query.toString(),Integer.class);
        return rowCount;
    }

    /**
     *
     * @param tenderId
     * @param searchTxt
     * @return boolean
     * @throws Exception
     */
    public boolean isTenderBiddermapped(int tenderId, String searchTxt, int mappingType, int tableId, int rowId) throws Exception {

        /*long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        StringBuilder whereTxt = new StringBuilder();
        var.put("tenderId", tenderId);
        var.put("searchTxt", searchTxt);
        whereTxt.append("tbltenderbiddermap.tblTender.tenderId=:tenderId and tbluserlogin.loginId=:searchTxt");
        count = hibernateQueryDao.countForNewQuery(" TblTenderBidderMap tbltenderbiddermap  inner join  tbltenderbiddermap.tblUserLogin tbluserlogin ",
                "tbluserlogin.userId ", whereTxt.toString(), var);*/
        long count = 0;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("loginId", searchTxt);
        query.append("select COUNT(tbltenderbiddermap.mapBidderId) ")
             .append(" from TblTenderBidderMap tbltenderbiddermap ")
    		 .append(" inner join tbltenderbiddermap.tblUserLogin tbluserlogin ");
        if(mappingType == 2){
	        	var.put("tableId", tableId);
	            var.put("rowId", rowId);
                query.append(" inner join tbltenderbiddermap.tblItemBidderMap tblitembiddermap with tblitembiddermap.tblTenderTable.tableId=:tableId and tblitembiddermap.rowId=:rowId");
        }
        query.append(" where tbltenderbiddermap.tblTender.tenderId=:tenderId and tbluserlogin.loginId=:loginId");
        List<Object> data = hibernateQueryDao.singleColQuery(query.toString(), var);
        if(!data.isEmpty()){
            count = (Long) data.get(0);
        }        
        return count != 0;
    }

    /**
     *
     * @param tenderId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getTenderBidderMap(int tenderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);

        query.append("select mapBidderId,tblCompany.companyId,tblUserDetail.userDetailId,createdBy from TblTenderBidderMap where tblTender.tenderId=:tenderId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     *
     * @param mappingPair
     * @param tenderId
     * @return int
     * @throws Exception
     */
    public int getItemBidderMapCount(String mappingPair, int tenderId) throws Exception {
        int rowCount = 0;
        StringBuilder query = new StringBuilder();

        query.append("select COUNT(*) ")
                .append(" from apptender.tbl_TenderBidderMap TBM ")
                .append(" inner join apptender.tbl_ItemBidderMap IBM on TBM.mapBidderId = IBM.mapBidderId ")
                .append(" inner join (")
                .append("   select * from (")
                .append("       VALUES ").append(mappingPair)
                .append("   ) V (companyId, tableId, rowId)) A ").append(" ON TBM.companyId = A.companyId AND IBM.tableId = A.tableId ")
                .append(" AND IBM.rowId = A.rowId where TBM.tenderId = ").append(tenderId);

        rowCount = jdbcTemplate.queryForObject(query.toString(),Integer.class);
        return rowCount;
    }

    /**
     *
     * @param tenderId
     * @param companyIds
     * @return {@code List<Object>}
     * @throws Exception
     */
    public List<Object> getFinalSubmissionCompanyDtls(int tenderId, String companyIds) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);

        query.append("select tblCompany.companyId from TblFinalSubmission where tblTender.tenderId=:tenderId and tblCompany.companyId in (")
                .append(companyIds).append(")");

        return hibernateQueryDao.getSingleColQuery(query.toString(), var);
    }

    /**
     *
     * @param mappedBidderId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> GetMappedBidderTableDtls(int mappedBidderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("mappedBidderId", mappedBidderId);

        query.append("select tbltendertable.tableId,tbltendercell.cellValue,tbltendertable.tableName,tbltendercolumn.columnHeader ")
                .append(" from TblItemBidderMap tblitembiddermap ")
                .append(" inner join tblitembiddermap.tblTenderTable tbltendertable ")
                .append(" inner join tbltendertable.tblTenderColumn tbltendercolumn with tbltendercolumn.tblColumnType.columnTypeId=1 ")
                .append(" inner join tbltendercolumn.tblTenderCell tbltendercell ")
                .append(" where tblitembiddermap.tblTenderBidderMap.mapBidderId=:mappedBidderId and tblitembiddermap.rowId = tbltendercell.rowId ")
                .append(" order by tbltendertable.tableId ,tbltendercell.rowId ");

        return hibernateQueryDao.createNewQuery(query.toString(), var);

    }

    /**
     *
     * @param mappedBidderId
     * @param clientId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getUserDtlsByMappedBidderId(int mappedBidderId, int clientId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("mappedBidderId", mappedBidderId);
        var.put("clientId", clientId);

        query.append("select tbluserlogin.loginId,tblcompany.companyName  ")
                .append(" from TblTenderBidderMap tbltenderbiddermap ")
                .append(" inner join tbltenderbiddermap.tblUserLogin tbluserlogin ")
                .append(" inner join tbluserlogin.tblBidderStatus tblbidderstatus with tblbidderstatus.tblClient.clientId=:clientId")
                .append(" inner join tblbidderstatus.tblCompany tblcompany ")
                .append(" where mapBidderId=:mappedBidderId");

        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     *
     * @param tenderId
     * @return boolean
     * @throws Exception
     */
    public boolean isSingleBidderMapped(int tenderId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        count = hibernateQueryDao.countForNewQuery("TblTenderBidderMap tbltenderbiddermap ", "tbltenderbiddermap.mapBidderId ", "tbltenderbiddermap.tblTender.tenderId=:tenderId", var);
        return count == 1;
    }
    
    /**
     * 
     * @param tenderId
     * @param companyId
     * @return boolean
     * @throws Exception 
     */
    public boolean isCompanyMapped(int tenderId, int companyId,int tenderResult) throws Exception{
        long count = 0;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("companyId", companyId);
        query.append("select COUNT(tbltenderbiddermap.mapBidderId) ")
             .append(" from TblTenderBidderMap tbltenderbiddermap ");
        if(tenderResult == 2){
                query.append(" inner join tbltenderbiddermap.tblItemBidderMap tblitembiddermap ");
        }
        query.append(" where tbltenderbiddermap.tblTender.tenderId=:tenderId and tbltenderbiddermap.tblCompany.companyId=:companyId");
        //System.out.println("query isCompanyMapped isCompanyMapped= " + query.toString());
        List<Object> data = hibernateQueryDao.singleColQuery(query.toString(), var);
        if(!data.isEmpty()){
            count = (Long) data.get(0);
        }        
        return count != 0;
    }
     /**
     * 
     * @param tenderId
     * @param columnTypeId
     * @return
     * @throws Exception 
     */
    public List<Object[]> GetMappedItemsByTenderId(int tenderId,int columnTypeId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        StringBuilder queryString = new StringBuilder();
        var.put("tenderId",tenderId);
        var.put("columnTypeId",columnTypeId);
        queryString.append("select tbltenderbiddermap.mapBidderId,tbltendercell.cellValue from TblItemBidderMap tblItemBidderMap ")
                .append("inner join tblItemBidderMap.tblTenderBidderMap tbltenderbiddermap with tbltenderbiddermap.tblTender.tenderId =:tenderId ")
                .append("inner join tblItemBidderMap.tblTenderTable tbltendertable ")
                .append("inner join tbltendertable.tblTenderCell tbltendercell ")
                .append("inner join tbltendercell.tblTenderColumn tbltendercolumn with tbltendercolumn.tblColumnType.columnTypeId =:columnTypeId ")
                .append("inner join tbltendertable.tblTenderForm tblTenderForm with tblTenderForm.cstatus != 2 ")
                .append("where tblItemBidderMap.rowId = tbltendercell.rowId");
        list = hibernateQueryDao.createNewQuery(queryString.toString(),var);                
        return list;        

    }
    /**
     * @param tenderId
     */
    public void deleteMappedBidder(int tenderId,int tenderResult){
    	Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        if(tenderResult==2 || tenderResult==3 ){
        	hibernateQueryDao.updateDeleteNewQuery("delete  from TblItemBidderMap tblItemBidderMap where tblItemBidderMap.tblTenderBidderMap.mapBidderId in (select mapBidderId from TblTenderBidderMap tbltenderbiddermap where tbltenderbiddermap.tblTender.tenderId=:tenderId)",var);
        }
        
        hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderBidderMap tbltenderbiddermap where tbltenderbiddermap.tblTender.tenderId=:tenderId",var);
        
        hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderMapBidderHistory tblTenderMapBidderHistory where tblTenderMapBidderHistory.tblTender.tenderId=:tenderId",var);
    }
    
    /**
	 *@author meghna
	  */
    public List<SelectItem> getSearchOption() {
        List<SelectItem> lstSearchOpt = new ArrayList<SelectItem>();

        lstSearchOpt.add(new SelectItem("Email ID", 1));
        lstSearchOpt.add(new SelectItem("Company Name", 2));
        lstSearchOpt.add(new SelectItem("Category", 3));
        return lstSearchOpt;
    }
    
    /**
	 *@author meghna
	 *@param clientId */
	public List<TblProductCategory> getCategoryList(int linkId, int objectId) throws Exception {
        List<TblProductCategory> list = new ArrayList<TblProductCategory>();
        TblProductCategory TblProductCategory=null;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("linkId", linkId);
        var.put("objectId", objectId);
        query.append("select tblProductCategory.categoryId as c0,tblProductCategory.categoryName as c1 from appcommon.tbl_MapCategory tblMapCategory ");
        query.append("inner join appclient.tbl_ProductCategory tblProductCategory on tblProductCategory.categoryId=tblMapCategory.categoryId ");
        query.append("where tblMapCategory.linkId=:linkId and tblMapCategory.objectId=:objectId");
        int colArr[]={1};
        List<Object[]> lst = hibernateQueryDao.createSQLQuery(query.toString(),var,colArr,2);
        for (int i = 0; i < lst.size(); i++) {
        	TblProductCategory=new TblProductCategory();
        	TblProductCategory.setCategoryId(Integer.parseInt(lst.get(i)[0].toString()));
        	TblProductCategory.setCategoryName(lst.get(i)[1].toString());
        	list.add(TblProductCategory);
		}
        return list;
    }
	
	public List<Object[]> getTenderFormTableAllItems(int tenderId) throws Exception {
	      StringBuilder query = new StringBuilder();
	      Map<String, Object> var = new HashMap<String, Object>();
	      var.put("tenderId", tenderId);
	      query.append("select tblTenderTable.noOfRows,(tblTenderTable.noOfRows-tblTenderTable.hasGTRow),tblTenderTable.tableId from TblTenderTable tblTenderTable inner join tblTenderTable.tblTenderForm tblTenderForm where tblTenderForm.cstatus <> 2 and tblTenderForm.tblTender.tenderId=:tenderId and tblTenderForm.isPriceBid=1");
	      List<Object[]> list = hibernateQueryDao.createQuery(query.toString(), var);
	      return list;
	  }
	
	@Transactional(propagation = Propagation.REQUIRED)
    public int removeMappedBiddersItemWise(int mapBidderIds) throws Exception {
        int cnt = 0;
        StringBuilder query = new StringBuilder();
           query.append("delete from TblItemBidderMap tblitembiddermap where tblitembiddermap.tblTenderBidderMap.mapBidderId in(").append(mapBidderIds).append(")");
        cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(), null);
        
        return cnt;
    }
	
	public void addMapBidderEntryForItemWiseCase(int tenderId,int corrigendumId,String ipAddress, List<Object> lstNewFormId) throws Exception{
	 	Map<String, Object> var = new HashMap<String, Object>();
	 	
	 	Object[] formId = null;
	 	List<Integer> formIds = new ArrayList<Integer>();
	 	List<Object> lst = null;
		if(corrigendumId != 0){
		 	var.put("corrigendumId", corrigendumId);   
			lst = hibernateQueryDao.getSingleColQuery("select objectId from TblCorrigendumDetail where tblCorrigendum.corrigendumId=:corrigendumId and tblProcess.processId=4 and actionType = 1", var);
			var.clear();
		}else{
			if(lstNewFormId != null){
				lst = lstNewFormId;
			}
		}
		if(lst!=null && !lst.isEmpty()){
			for (int i=0;i<lst.size();i++) {
				boolean priceBid = tenderFormService.getIsPriceBidForm((Integer)lst.get(i));
				if(priceBid){
					formIds.add((Integer)lst.get(i));
				}	
			}
			formId = formIds.toArray();
			if(formId!=null && formId.length>0){
				List<TblTenderTable> tblTenderTable = tenderFormService.getTenderTableByFormId(formId);
				List<Object[]> mappedBidderLst = getTenderBidderMap(tenderId);
				if(mappedBidderLst!=null && !mappedBidderLst.isEmpty() && tblTenderTable!=null && !tblTenderTable.isEmpty()){
					itemwiseBidderMapping(tenderId, ipAddress,tblTenderTable, mappedBidderLst);
				}
			} 
		}
}
	public void itemwiseBidderMapping(int tenderId, String ipAddress, List<TblTenderTable> tblTenderTable,
			List<Object[]> mappedBidderLst) throws Exception {
		List<TblItemBidderMap> lstItemBidderMap = new ArrayList<TblItemBidderMap>();
	 	List<TblTenderMapBidderHistory> lstTenderMapBidderHistory = new ArrayList<TblTenderMapBidderHistory>();
		int mapBidderId;
		int companyId;
		int vendorCode;
		int userDetailId;
		int createdBy;
		for(Object[] objects : mappedBidderLst){
			mapBidderId = (Integer) objects[0];
			companyId = (Integer) objects[1];
//			vendorCode = (Integer) objects[2];
			userDetailId = (Integer) objects[2];
			createdBy = (Integer) objects[3];
			List<Object> tableIdsOfItemBidderMap = getTableIdsOfItemBidderMap(tenderId);
			boolean isTableIdListEmpty = true;
			if(tableIdsOfItemBidderMap!=null && !tableIdsOfItemBidderMap.isEmpty()){
				isTableIdListEmpty = false;
			}
			for(TblTenderTable table : tblTenderTable){
				if((!isTableIdListEmpty && !tableIdsOfItemBidderMap.contains(table.getTableId())) || (isTableIdListEmpty)){
					int cnt = (table.getNoOfRows()-table.getHasGTRow());
					for(int i = 1; i <= cnt; i++){
						TblItemBidderMap tblItemBidderMap = new TblItemBidderMap();
						tblItemBidderMap.setTblTenderBidderMap(new TblTenderBidderMap(mapBidderId));
						tblItemBidderMap.setTblTenderTable(new TblTenderTable(table.getTableId()));
						tblItemBidderMap.setRowId(i);
						tblItemBidderMap.setIpAddress(ipAddress);
						tblItemBidderMap.setCreatedBy(createdBy);
//						tblItemBidderMap.setTblVendorCodeMapping(new TblVendorCodeMapping(vendorCode));
						lstItemBidderMap.add(tblItemBidderMap);

						TblTenderMapBidderHistory tblTenderMapBidderHistory = new TblTenderMapBidderHistory();
						tblTenderMapBidderHistory.setTblTender(new TblTender(tenderId));
						tblTenderMapBidderHistory.setTblUserDetail(new TblUserDetail(userDetailId));
						tblTenderMapBidderHistory.setCreatedBy(createdBy);
						tblTenderMapBidderHistory.setIsMapped(1);
						tblTenderMapBidderHistory.setTblCompany(new TblCompany(companyId));
//						tblTenderMapBidderHistory.setTblVendorCodeMapping(new TblVendorCodeMapping(vendorCode));
						tblTenderMapBidderHistory.setTableId(table.getTableId());
						tblTenderMapBidderHistory.setRowId(i);
						lstTenderMapBidderHistory.add(tblTenderMapBidderHistory);
					}
				}
			}
		}
		tblItemBidderMapDao.saveUpdateAllTblItemBidderMap(lstItemBidderMap);
		tblTenderMapBidderHistoryDao.saveUpdateAllTblTenderMapBidderHistory(lstTenderMapBidderHistory);
	}
public List<Object> getTableIdsOfItemBidderMap(int tenderId)throws Exception{
    	
    	Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder query = new StringBuilder();
        query.append("select tblItemBidderMap.tblTenderTable.tableId from TblItemBidderMap tblItemBidderMap where ");
        query.append(" tblItemBidderMap.tblTenderBidderMap.mapBidderId IN(select tblTenderBidderMap.mapBidderId from ");
        query.append(" TblTenderBidderMap tblTenderBidderMap where tblTenderBidderMap.tblTender.tenderId=:tenderId) ");
        query.append(" group by tblItemBidderMap.tblTenderTable.tableId");
        List<Object> list=hibernateQueryDao.singleColQuery(query.toString(), var);
    	
    	return list;    	
    }
}
