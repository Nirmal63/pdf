/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderMatrixJsonDao;
import com.etl.eproc.etender.model.TblTenderMatrixJson;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author TaherT
 */
@Repository @Transactional
public class TblTenderMatrixJsonImpl extends AbcAbstractClass<TblTenderMatrixJson> implements TblTenderMatrixJsonDao {

  

    @Override
    public void addTblTenderMatrixJson(TblTenderMatrixJson tblTenderMatrixJson){
        super.addEntity(tblTenderMatrixJson);
    }

    @Override
    public void deleteTblTenderMatrixJson(TblTenderMatrixJson tblTenderMatrixJson) {
        super.deleteEntity(tblTenderMatrixJson);
    }

    @Override
    public void updateTblTenderMatrixJson(TblTenderMatrixJson tblTenderMatrixJson) {
        super.updateEntity(tblTenderMatrixJson);
    }

    @Override
    public List<TblTenderMatrixJson> getAllTblTenderMatrixJson() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderMatrixJson> findTblTenderMatrixJson(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderMatrixJsonCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderMatrixJson> findByCountTblTenderMatrixJson(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderMatrixJson(List<TblTenderMatrixJson> tblTenderMatrixJsons){
        super.updateAll(tblTenderMatrixJsons);
    }
}
