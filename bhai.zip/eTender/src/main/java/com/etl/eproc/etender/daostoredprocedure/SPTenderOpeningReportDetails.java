/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author dipal
 */
@Component
public class SPTenderOpeningReportDetails extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderresult.P_TenderReportDetail";

    public SPTenderOpeningReportDetails() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_TableId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_ReportTypeId", Types.INTEGER));
    }

    /*
     * 
     */
    public Map<String,Object> executeProcedure(int tenderId, int tableId,int reportTypeId) throws Exception
    {
        Map inParams = new HashMap();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_TableId", tableId);
        inParams.put("@V_ReportTypeId", reportTypeId);
        this.compile();
        return execute(inParams);
    }
}
