package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TblEvaluationRework;

public interface TblEvaluationReworkDao  {

    public void addTblEvaluationRework(TblEvaluationRework tblEvaluationRework);

    public void deleteTblEvaluationRework(TblEvaluationRework tblEvaluationRework);

    public void updateTblEvaluationRework(TblEvaluationRework tblEvaluationRework);

    public List<TblEvaluationRework> getAllTblEvaluationRework();

    public List<TblEvaluationRework> findTblEvaluationRework(Object... values) throws Exception;

    public List<TblEvaluationRework> findByCountTblEvaluationRework(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEvaluationReworkCount();

    public void saveUpdateAllTblEvaluationRework(List<TblEvaluationRework> tblEvaluationReworks);
}