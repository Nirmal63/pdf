package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblChallan;
import java.util.List;

public interface TblChallanDao  {

    public void addTblChallan(TblChallan tblChallan);

    public void deleteTblChallan(TblChallan tblChallan);

    public void updateTblChallan(TblChallan tblChallan);

    public List<TblChallan> getAllTblChallan();

    public List<TblChallan> findTblChallan(Object... values) throws Exception;

    public List<TblChallan> findByCountTblChallan(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblChallanCount();

    public void saveUpdateAllTblChallan(List<TblChallan> tblChallans);
}