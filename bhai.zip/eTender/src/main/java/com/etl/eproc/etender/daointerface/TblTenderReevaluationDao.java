/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblTenderReevaluation;
import java.util.List;

/**
 *
 * @author mittal
 */
public interface TblTenderReevaluationDao  {
    
    public void addTblTenderReevaluation(TblTenderReevaluation tblTenderReevaluation);

    public void deleteTblTenderReevaluation(TblTenderReevaluation tblTenderReevaluation);

    public void updateTblTenderReevaluation(TblTenderReevaluation tblTenderReevaluation);

    public List<TblTenderReevaluation> getAllTblTenderReevaluation();

    public List<TblTenderReevaluation> findTblTenderReevaluation(Object... values) throws Exception;

    public List<TblTenderReevaluation> findByCountTblTenderReevaluation(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderReevaluationCount();

    public void saveUpdateAllTblTenderReevaluation(List<TblTenderReevaluation> tblTenderReevaluations);

}
