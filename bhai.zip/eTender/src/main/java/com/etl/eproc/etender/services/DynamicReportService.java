package com.etl.eproc.etender.services;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.OrderBy;
import javax.swing.text.StyledEditorKit.BoldAction;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.etender.daointerface.TblDynReportCellDao;
import com.etl.eproc.etender.daointerface.TblDynReportColumnDao;
import com.etl.eproc.etender.daointerface.TblDynReportDao;
import com.etl.eproc.etender.daointerface.TblDynReportFormMapDao;
import com.etl.eproc.etender.daointerface.TblDynReportFormulaDao;
import com.etl.eproc.etender.daointerface.TblTenderCellDao;
import com.etl.eproc.etender.daointerface.TblTenderColumnDao;
import com.etl.eproc.etender.daointerface.TblTenderFormulaDao;
import com.etl.eproc.etender.daointerface.TblTenderGovColumnDao;
import com.etl.eproc.etender.daostoredprocedure.SPDynamicReport;
import com.etl.eproc.etender.model.TblDynReport;
import com.etl.eproc.etender.model.TblDynReportCell;
import com.etl.eproc.etender.model.TblDynReportColumn;
import com.etl.eproc.etender.model.TblDynReportFormMap;
import com.etl.eproc.etender.model.TblDynReportFormula;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderColumn;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderFormula;
import com.etl.eproc.etender.model.TblTenderGovColumn;
import com.etl.eproc.etender.model.TblTenderTable;

@Service
public class DynamicReportService{

    @Autowired
    private HibernateQueryDao hibernateQueryDao; 
    
    @Autowired
    private TblDynReportColumnDao tblDynReportColumnDao;
    @Autowired
    private TblDynReportDao tblDynReportDao;
    @Autowired
    private TblDynReportFormMapDao tblDynReportFormMapDao;
    @Autowired
    private TblTenderColumnDao tblTenderColumnDao;
    @Autowired
    private TblDynReportFormulaDao tblDynReportFormulaDao;
    @Autowired
    private SPDynamicReport spDynamicReport;
    @Autowired
    private TblDynReportCellDao tblDynReportCellDao;
    @Autowired
    private TblTenderGovColumnDao tblTenderGovColumnDao;
    @Autowired
    private TblTenderFormulaDao tblTenderFormulaDao;

    /**
     * to get form list for dynamic report
     * @param tenderId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getFormList(int tenderId,int isRebateReq,int reportOn) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
//        StringBuilder query=new StringBuilder("select tbltenderform.formId, tbltenderform.formName ");
//        if(reportOn == 2){
//        	query.append(" ,tbltendertable.tableId,tbltendertable.tableName ");
//        	query.append(" from TblTenderTable tbltendertable ");
//        	query.append(" inner join tbltendertable.tblTenderForm tbltenderform ");
//        }else if(reportOn == 1){
//        	query.append(" from TblTenderForm tbltenderform ");
//        	query.append(" inner join tbltenderform.tblTenderFormula tbltenderformula with tbltenderformula.colFormula like 'TOTAL(%'");
//	        if(isRebateReq ==1){
//	        	query.append(" inner join tbltenderform.tblRebateForm tblrebateform ");
//	        }
//        }
//        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isPriceBid=1 and  tbltenderform.cstatus!=2 order by tbltenderform.sortOrder");
 StringBuilder query=new StringBuilder("select tbltenderform.formId, tbltenderform.formName ");
        if(reportOn == 2){
        	query.append(" ,tbltendertable.tableId,tbltendertable.tableName ");
        	query.append(" from TblTenderTable tbltendertable ");
        	query.append(" inner join tbltendertable.tblTenderForm tbltenderform ");
        }else if(reportOn == 1){
        	query.append(" from TblTenderForm tbltenderform ");
	        if(isRebateReq ==1){
	        	query.append(" inner join tbltenderform.tblRebateForm tblrebateform ");
	        	query.append(" inner join tblrebateform.tblTenderCell tbltendercell ");
	        	query.append(" inner join tbltendercell.tblTenderColumn tbltendercolumn ");
	        	query.append(" inner join tbltendercolumn.tblTenderFormula tbltenderformula with tbltenderformula.colFormula like 'TOTAL(%'");
//	        }else{
//			query.append(" inner join tbltenderform.tblTenderCell tbltendercell ");
//	        	query.append(" inner join tbltendercell.tblTenderColumn tbltendercolumn ");
//	        	query.append(" inner join tbltendercolumn.tblTenderFormula tbltenderformula with tbltenderformula.colFormula like 'TOTAL(%'");
	        }
        }
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isPriceBid=1 and  tbltenderform.cstatus=1 and tbltenderform.isMultipleFilling=0 order by tbltenderform.sortOrder");	
        return hibernateQueryDao.createNewQuery(query.toString(),var);        
    }
    
      /**
     * 
     * @param tbldynreportcolumn
     * @return
     * @throws Exception 
     */
    public  boolean addTblDynReportColumn(List<TblDynReportColumn> tbldynreportcolumns) throws Exception{
    boolean bSuccess = false;             
                tblDynReportColumnDao.saveUpdateAllTblDynReportColumn(tbldynreportcolumns);
            bSuccess=true;        
        return bSuccess;

    }
    /**
     * to add dynamic report
     * @param tblDynReport
     * @return boolean
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
    public boolean addDynamicReport(TblDynReport tblDynReport,boolean isReportOnChange) throws Exception{
    	boolean bSuccess = false;             
        tblDynReportDao.saveOrUpdateTblDynReport(tblDynReport);
        if(!isReportOnChange){
        	Map<String, Object> var = new HashMap<String, Object>();
            var.put("reportId",tblDynReport.getReportId());
        	deleteReportMappedForm(tblDynReport.getReportId());
        	hibernateQueryDao.updateDeleteNewQuery("delete  from TblDynReportFormula tbldynreportformula where tbldynreportformula.tblDynReport.reportId=:reportId",var);        
        }
        bSuccess=true;        
        return bSuccess;
    }
    
    /**
     * 
     * @param reportId
     * @return
     * @throws Exception 
     */
    public  TblDynReport getDynReportById(int reportId) throws Exception{
        List<TblDynReport> list = null;        
        list = tblDynReportDao.findTblDynReport("reportId",Operation_enum.EQ,reportId);                
        return (list!=null && !list.isEmpty()) ? list.get(0) : null;            
    }
    
    /**
     * 
     * @param tblDynReportFormMapList
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
    public boolean addDynReportFormMap(List<TblDynReportFormMap> tblDynReportFormMapList,int oprType,int reportId, int reportOn) throws Exception{
    	boolean bSuccess = false;
    	if(oprType == 2 && reportId != 0 && reportOn==1){
    		deleteReportMappedForm(reportId);
    	}
        tblDynReportFormMapDao.saveUpdateAllTblDynReportFormMap(tblDynReportFormMapList);
        bSuccess=true;        
        return bSuccess;
    }
    
    /**
     * 
     * @return
     * @throws Exception 
     */
    public List<TblDynReportFormMap> getDynReporFormMaptById(int reportId) throws Exception{
        List<TblDynReportFormMap> list = null;        
        list = tblDynReportFormMapDao.findTblDynReportFormMap("tblDynReport.reportId",Operation_enum.EQ,reportId);                
        return list;            
    }
    
    /**
     * 
     * @param reportId
     * @return
     * @throws Exception 
     */
    public boolean deleteReportMappedForm(int reportId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("reportId",reportId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblDynReportFormMap tbldynreportformmap where tbldynreportformmap.tblDynReport.reportId=:reportId",var);        
        return cnt!=0;
    }


     /**
     * 
     * @param reportId
     * @return
     * @throws Exception 
     */
    public  List<TblDynReportColumn> getDynReportColumnByReportId(int reportId) throws Exception{
            List<TblDynReportColumn> list = null;        
            list = tblDynReportColumnDao.findTblDynReportColumn("tblDynReport",Operation_enum.EQ,new TblDynReport(reportId));                
            return list;

    }
    
    /**
     * 
     * @param reportId
     * @return
     * @throws Exception 
     */
    public  List<TblDynReportColumn> getDynReportColumnByReportId(int reportId,int filledBy) throws Exception{
            List<TblDynReportColumn> list = null;        
            list = tblDynReportColumnDao.findTblDynReportColumn("tblDynReport",Operation_enum.EQ,new TblDynReport(reportId),"filledBy",Operation_enum.EQ,filledBy);                
            return list;

    }
    
      /**
     * 
     * @param reportId
     * @param filledBy
     * @return
     * @throws Exception 
     */
    public List<Object[]> getAutoColumnsForFormula(int reportId,int filledBy,List<Integer> colIds,String[] formId,int tableId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("reportId",reportId);
        var.put("filledBy",filledBy);
	var.put("tableId",tableId);
        StringBuilder query=new StringBuilder("select distinct (cast(tbldynreportcolumn.columnId as string) + '_' + cast(tbldynreportcolumn.columnNo as string)) as columnDtl , tbldynreportcolumn.columnName ");
        query.append(" from TblDynReportColumn tbldynreportcolumn ");
        query.append(" inner join tbldynreportcolumn.tblDynReport tbldynreport ");
        if(tableId == 0){
        	query.append(" inner join tbldynreport.tblDynReportFormMap tbldynreportformmap ");
        }
        query.append(" left join tbldynreport.tblDynReportFormula tbldynreportformula with tbldynreportformula.tableId=:tableId ");
        query.append(" where tbldynreportcolumn.tblDynReport.reportId=:reportId and tbldynreportcolumn.filledBy=:filledBy ");
        if(tableId == 0){
	    List<Integer> formIdList=new ArrayList<Integer>();
            for(String tempFormId : formId){
         	   formIdList.add(Integer.parseInt(tempFormId));
            }
            var.put("formId", formIdList);
            query.append(" and tbldynreportformmap.tblTenderForm.formId in (:formId) ");
        }
        if(!colIds.isEmpty()){
        	var.put("colIds",colIds);
        	query.append(" and tbldynreportcolumn.columnId not in(:colIds)");
        }
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        

    }
    
     /**
     * 
     * @param formId
     * @param tableId
     * @param columnTypeId
     * @return
     * @throws Exception 
     */
    public  List<TblTenderColumn> getTenderColumn(String[] formId,int tableId) throws Exception{
        List<TblTenderColumn> list = null;
        if(tableId == 0){
        	Object[] temp=new Object[formId.length];
        	int cnt=0;	
        	for(String tempString: formId){
        		temp[cnt++]=Integer.parseInt(tempString);
        	}
        	list = tblTenderColumnDao.findTblTenderColumn("tblTenderForm.formId",Operation_enum.IN,temp,"tblTenderTable.tableId",Operation_enum.ORDERBY,Operation_enum.ASC,"sortOrder",Operation_enum.ORDERBY,Operation_enum.ASC);
        }else{
        	list = tblTenderColumnDao.findTblTenderColumn("tblTenderTable.tableId",Operation_enum.EQ,tableId);
        }
        return list;

    }
    
    /**
     * 
     * @param tbldynreportformula
     * @return
     * @throws Exception 
     */
    public  boolean addTblDynReportFormula(TblDynReportFormula tbldynreportformula) throws Exception{
    boolean bSuccess = false;             
                tblDynReportFormulaDao.saveOrUpdateTblDynReportFormula(tbldynreportformula);
            bSuccess=true;        
        return bSuccess;

    }
    
      /**
     * 
     * @param reportId
     * @param columnId
     * @return
     * @throws Exception 
     */
    public  List<TblDynReportFormula> getDynReportFormula(int reportId,int tableId) throws Exception{
        List<TblDynReportFormula> list = null;
	if(tableId != 0){
	    list = tblDynReportFormulaDao.findTblDynReportFormula("tblDynReport.reportId",Operation_enum.EQ,reportId,"tableId",Operation_enum.EQ,tableId);                
	} else {
	    list = tblDynReportFormulaDao.findTblDynReportFormula("tblDynReport.reportId",Operation_enum.EQ,reportId);
	}
        return list;

    }
    
     /**
     * 
     * @param formulaId
     * @return
     * @throws Exception 
     */
    public  boolean deleteTblDynReportFormulaById(int formulaId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formulaId",formulaId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblDynReportFormula tbldynreportformula where tbldynreportformula.formulaId=:formulaId",var);        
        return cnt!=0;

    }
    
    /**
     * @author priyanka
     * @param reportId
     * @return
     * @throws Exception 
     */
    public  boolean deleteTblDynReportCellId(List<Integer> reportId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("reportId",reportId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblDynReportCell tblDynReportCell where tblDynReportCell.tblDynReport.reportId in (:reportId)",var);        
        return cnt!=0;
    }
    
    public List<TblTenderCell> getTenderCellByTableIdOneRow(int formId) throws Exception {
        StringBuilder query = new StringBuilder();
        query.append("select tbltendercell.cellId,tbltendercell.tblTenderForm.formId,tbltendercell.tblTenderTable.tableId,")
                .append("tbltendercell.tblTenderColumn.columnId,tbltendercell.rowId,tbltendercell.cellValue,tbltendercell.cellNo,tbltendercell.dataType,")
                .append("tbltendercell.objectId,tbltendercolumn.columnNo ")
                .append("from TblTenderCell tbltendercell inner join tbltendercell.tblTenderColumn tbltendercolumn where ")
                .append("tbltendercell.tblTenderForm.formId=:formId ")        
                .append(" order by tbltendercell.tblTenderTable.tableId,tbltendercell.rowId asc");        
        Map<String,Object> var = new HashMap<String, Object>();        
        var.put("formId", formId);
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);      
        return toTenderCell(list);
    }
    
    /**
    *Get TblTenderCell data is form of Json
    * @param tableId
    * @return Json String
    * @throws Exception
    */
   public List<TblTenderCell> getTableJson(String[] formId,int tableId) throws Exception {
	   List<TblTenderCell> cellList = new ArrayList<TblTenderCell>();
       List<Object> list = null;
       Map<String, Object> var = new HashMap<String, Object>();
       List<Integer> formIdList=new ArrayList<Integer>();
       for(String tempFormId : formId){
    	   formIdList.add(Integer.parseInt(tempFormId));
       }
       var.put("formId", formIdList);
       StringBuilder query=new StringBuilder("select tbltendermatrixjson.jsonData from TblTenderMatrixJson tbltendermatrixjson where tbltendermatrixjson.tblTenderForm.formId in (:formId)");
       if(tableId != 0){
    	   var.put("tableId", tableId);
    	   query.append(" and tbltendermatrixjson.tblTenderTable.tableId=:tableId ");
       }
       list = hibernateQueryDao.getSingleColQuery(query.toString(), var);
       if (!list.isEmpty()) {
    	   for(int i=0;i<list.size();i++){
    		   cellList.addAll(_toCellMasters(list.get(i).toString().replace("\\r\\n", "<br/>")));
    	   }
       }
       return cellList;
   }
   
   /**
    * Converts json into List
    * @param json
    * @return
    * @throws JSONException 
    */
   public List<TblTenderCell> _toCellMasters(String json) throws JSONException {
       List<TblTenderCell> cellMasters = new ArrayList<TblTenderCell>();
       if (json != null && !json.isEmpty()) {
           JSONArray jsonArray = new JSONArray(json);
           for (int i = 0; i < jsonArray.length(); i++) {
               JSONObject jSONObject = jsonArray.getJSONObject(i);
               for (Iterator it = jSONObject.keys(); it.hasNext();) {
                   String key = it.next().toString();
                   String[] values = key.split("_");
                   cellMasters.add(new TblTenderCell(Integer.parseInt(values[6]), Integer.parseInt(values[0]), new TblTenderColumn(Integer.parseInt(values[5])), Integer.parseInt(values[3]), Integer.parseInt(values[2]), new TblTenderTable(Integer.parseInt(values[4])), jSONObject.getString(key),values.length==8 ? Integer.parseInt(values[7]) : 0));
               }
           }
       }
       return cellMasters;
   }
    
    private List<TblTenderCell> toTenderCell(List<Object[]> list){
        List<TblTenderCell> tenderCells = new ArrayList<TblTenderCell>();
        for (Object[] cells : list) {
            TblTenderCell tblTenderCell = new TblTenderCell();
            tblTenderCell.setCellId((Integer)cells[0]);
            tblTenderCell.setTblTenderForm(new TblTenderForm((Integer)cells[1]));
            tblTenderCell.setTblTenderTable(new TblTenderTable((Integer)cells[2]));
            TblTenderColumn tblTenderColumn = new TblTenderColumn((Integer)cells[3]);
            tblTenderColumn.setColumnNo((Integer)cells[9]);
            tblTenderCell.setTblTenderColumn(tblTenderColumn);
            tblTenderCell.setRowId((Integer)cells[4]);
            tblTenderCell.setCellValue(cells[5].toString());
            tblTenderCell.setCellNo((Integer)cells[6]);
            tblTenderCell.setDataType((Integer)cells[7]);
            tblTenderCell.setObjectId((Integer)cells[8]);
            tenderCells.add(tblTenderCell);
        }
        return tenderCells;
    }
    
     /**
     * 
     * @param reportId
     * @return
     * @throws Exception 
     */
    public Map<String, Object> getDynamicL1H1Report(int reportId,int tenderId,int OfficerId) throws Exception{
            return spDynamicReport.executeProcedure(reportId,tenderId,OfficerId);
    }
    
      /**
     * 
     * @param tbldynreportcell
     * @return
     * @throws Exception 
     */
    public  boolean addTblDynReportCell(List<TblDynReportCell> tbldynreportcells) throws Exception{
    boolean bSuccess = false;             
                tblDynReportCellDao.saveUpdateAllTblDynReportCell(tbldynreportcells);
            bSuccess=true;        
        return bSuccess;

    }
    
    /**
     * 
     * @param tableId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getFormIdByTableId(int tableId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId",tableId);
        list = hibernateQueryDao.createNewQuery("select tbltendertable.tableId, tbltendertable.tblTenderForm.formId from TblTenderTable tbltendertable where tbltendertable.tableId=:tableId",var);                
        return list;        

    }
    
    /**
     * to get listing of all dynamic report for that particular tender  
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public  List<TblDynReport> getDynReportByTenderId(int tenderId) throws Exception{
        List<TblDynReport> list = null;
        Object[] reportOn = new Object[2];
        reportOn[0]=1;
        reportOn[1]=2;
        list = tblDynReportDao.findTblDynReport("tblTender.tenderId",Operation_enum.EQ,tenderId,"reportOn",Operation_enum.IN,reportOn);
        return list;

    }
    /**
     * to get listing of all dynamic report for that particular tender  
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public  List<TblDynReport> getDynReport(int tenderId) throws Exception{
        List<TblDynReport> list = null;
        list = tblDynReportDao.findTblDynReport("tblTender.tenderId",Operation_enum.EQ,tenderId);
        return list;

    }
    
    /**
     * 
     * @param tenderId
     * @param formId
     * @param tableId
     * @param columnId
     * @return
     * @throws Exception 
     */
    /*public  List<TblTenderGovColumn> getTenderGovColumn(String[] formId) throws Exception{
        List<TblTenderGovColumn> list = null;
        Object[] temp=new Object[formId.length];
    	int cnt=0;
    	for(String tempString: formId){
    		temp[cnt++]=Integer.parseInt(tempString);
    	}
        list = tblTenderGovColumnDao.findTblTenderGovColumn("tblTenderForm.formId",Operation_enum.IN,temp,"tblTenderTable.tableId",Operation_enum.ORDERBY,Operation_enum.ASC);                
        return list;
    }*/
    
    public  List<Object[]> getTenderGovColumn(String[] formId) throws Exception{
        List<Object[]> list = null;
        Object[] temp=new Object[formId.length];
    	int cnt=0;
    	for(String tempString: formId){
    		temp[cnt++]=Integer.parseInt(tempString);
    	}
    	Map<String, Object> var = new HashMap<String, Object>();
    	var.put("formula", "TOTAL(%");
    	var.put("formId", temp);
    	StringBuilder query=new StringBuilder("select tbltendercell.tblTenderTable.tableId, tbltendercell.tblTenderColumn.columnId, tbltendercell.cellId, tbltendercell.cellValue, tbltendercell.rowId ");
    	query.append(" from TblTenderCell tbltendercell  ");
    	query.append(" inner join tbltendercell.tblTenderColumn tbltendercolumn ");
    	query.append(" inner join tbltendercolumn.tblTenderFormula tbltenderformula ");
    	query.append(" where tbltendercell.dataType=0 and tbltenderformula.colFormula like:formula and tbltendercell.tblTenderForm.formId in (:formId) ");
    	query.append(" order by tbltendercell.tblTenderTable.tableId ");
    	list=hibernateQueryDao.createNewQuery(query.toString(),var);
        //list = tblTenderFormulaDao.findTblTenderFormula("tblTenderColumn.columnId",Operation_enum.IN,temp,"colFormula",Operation_enum.LIKE,"TOTAL(%","tblTenderTable.tableId",Operation_enum.ORDERBY,Operation_enum.ASC);                
        return list;
    }
    
    /**
     *To get tender table details on the basis of the table id
     * @param tableId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getTenderTableDetails(String[] formId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        List<Integer> formIdList=new ArrayList<Integer>();
        for(String tempFormId : formId){
     	   formIdList.add(Integer.parseInt(tempFormId));
        }
        var.put("formId", formIdList);
        list = hibernateQueryDao.createNewQuery("select tbltendertable.tableId, tbltendertable.tblTenderForm.formId, tbltendertable.tableName, tbltendertable.tableHeader, tbltendertable.tableFooter,tbltendertable.isMultipleFilling,tbltendertable.noOfRows,tbltendertable.noOfCols,tbltendertable.sortOrder,tbltendertable.hasGTRow from TblTenderTable tbltendertable where tbltendertable.tblTenderForm.formId in (:formId) order by tbltendertable.tblTenderForm.formId", var);
        return list;
    }
    
    /**
     * 
     * @param reportId
     * @param tbldynreportcolumns
     * @return boolean
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
    public boolean deleteAddDynamicReportColumn(int reportId,List<TblDynReportColumn> tbldynreportcolumns) throws Exception{
    	boolean bSuccess = false;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("reportId",reportId);
        hibernateQueryDao.updateDeleteNewQuery("delete  from TblDynReportFormula tbldynreportformula where tbldynreportformula.tblDynReport.reportId=:reportId",var);        
        hibernateQueryDao.updateDeleteNewQuery("delete  from TblDynReportColumn tbldynreportcolumn where tbldynreportcolumn.tblDynReport.reportId=:reportId",var);
        tblDynReportColumnDao.saveUpdateAllTblDynReportColumn(tbldynreportcolumns);
        bSuccess=true;
        return bSuccess;
    }
    
    /**
     * to get dynamic report id on the basis of the form Id
     * @param formId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getDynReportByFormId(int formId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        list = hibernateQueryDao.createNewQuery("select tbldynreportformmap.tblDynReport.reportId, tbldynreportformmap.tblTenderForm.formId from TblDynReportFormMap tbldynreportformmap where tbldynreportformmap.tblTenderForm.formId=:formId",var);                
        return list;        

    }
    
    /**
     * 
     * @param reportId
     * @return boolean
     * @throws Exception 
     */
    public boolean deleteDynReport(int reportId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("reportId",reportId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblDynReport tbldynreport where tbldynreport.reportId=:reportId",var);        
        return cnt!=0;

    }
    
    /**
     * 
     * @param tenderId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> isEvaluationDone(int tenderId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        list = hibernateQueryDao.createNewQuery("select tbltenderenvelope.isEvaluated, tbltenderenvelope.tblTender.tenderId from TblTenderEnvelope tbltenderenvelope where tbltenderenvelope.tblTender.tenderId=:tenderId and tbltenderenvelope.tblEnvelope.envId in (4,5)",var);                
        return list;        
    }
    
      /**
     * 
     * @param reportId
     * @return
     * @throws Exception 
     */
    public  List<TblDynReportFormula> getDynReportFormulaByReportId(int reportId) throws Exception{
            List<TblDynReportFormula> list = null;        
        list = tblDynReportFormulaDao.findTblDynReportFormula("tblDynReport",Operation_enum.EQ,new TblDynReport(reportId));                
            return list;

    }
    
    /**
     * Get form and table detail from tenderid
     * @author bharat
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderPriceBidFormWithTableId(int tenderId) throws Exception{
    	Map<String,Object> var = new HashMap<String,Object>();
        StringBuilder queryString = new StringBuilder();
        var.put("tenderId", tenderId);
        //queryString.append("select formId,formName from TblTenderForm where tenderId=:tenderId and isPriceBid=1 and noOfTables=1 and cstatus=1");
        
        queryString.append("select tbltenderform.formId , tbltenderform.formName,tblTendertable.tableId");
        queryString.append(" from TblTenderForm tbltenderform");
        queryString.append(" inner join tbltenderform.tblTenderTable tblTendertable");
        queryString.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isPriceBid=1 and tbltenderform.cstatus=1 ");
        queryString.append(" and (select count(tbltendertable.tableId) from TblTenderTable tbltendertable");
        queryString.append(" where tbltendertable.tblTenderForm.formId = tbltenderform.formId) = 1");
        return hibernateQueryDao.createNewQuery(queryString.toString(), var);
    }
    
    /**
     * Get dynamic report id where report type is 2 that means report should be system generated 
     * @author SULABH
     * @param tenderId
     * @return
     * @throws Exception
     */
    public String getSystemGeneratedReportIdByTenderId(int tenderId) throws Exception{
    	String data = null;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        list = hibernateQueryDao.getSingleColQuery("select tbldynreport.reportId from TblDynReport tbldynreport where tbldynreport.tblTender.tenderId=:tenderId and tbldynreport.reportType=2", var);
        if (!list.isEmpty()) {
            data = list.get(0).toString();
        }
        return data;
    }
    
    /**
     * 
     * @param reportId
     * @param tableId
     * @return
     * @throws Exception 
     */
    public long getFormulaColumnCount(int reportId, int tableId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("reportId", reportId);
        if (tableId != 0) {
            var.put("tableId", tableId);
            count = hibernateQueryDao.countForNewQuery("TblDynReportFormula tbldynreportformula ", "distinct tbldynreportformula.tblDynReportColumn.columnId ", "tbldynreportformula.tblDynReport.reportId=:reportId and tbldynreportformula.tableId=:tableId", var);
        } else {
            count = hibernateQueryDao.countForNewQuery("TblDynReportFormula tbldynreportformula ", "distinct tbldynreportformula.tblDynReportColumn.columnId ", "tbldynreportformula.tblDynReport.reportId=:reportId", var);
        }
        return count;
    }
    
    /** Get the formwise table & GT column details for lotwise report.
     * @auther mitesh
     * @param tenderId
     * @return
     * @throws Exception 
     */
     public List<Object[]> getPriceFormTableDetails(int tenderId) throws Exception{
    	Map<String,Object> var = new HashMap<String,Object>();
        StringBuilder queryString = new StringBuilder();
        var.put("tenderId", tenderId);
        queryString.append("select tblTenderForm.formId,tblTenderTable.tableId,tblTenderGovColumn.cellId,tblTenderForm.formName,tblTenderTable.tableName from TblTenderForm tblTenderForm ");
        queryString.append("inner join tblTenderForm.tblTenderTable tblTenderTable ");
        queryString.append("inner join tblTenderTable.tblTenderGovColumn tblTenderGovColumn ");
        queryString.append("where tblTenderForm.tblTender.tenderId=:tenderId and tblTenderForm.isPriceBid=1 order by tblTenderTable.tableId");
        return hibernateQueryDao.createNewQuery(queryString.toString(), var);
    }
     
     /** Get the L1 bidder data from the cellIds
      * @auther Mitesh
      * @param cellIds
      * @return
      * @throws Exception 
      */
    public List<Object[]> getL1BidderDetailsByTableIds(List<Integer> cellIds,String reportVarient,List<Object[]> envelopeId) throws Exception{
    	Map<String,Object> var = new HashMap<String,Object>();
        StringBuilder queryString = new StringBuilder();
        var.put("cellIds", cellIds);
        var.put("envelopeId", envelopeId);
        queryString.append("select tblTenderBidMatrix.tblTenderTable.tableId,tblCompany.companyId,tblCompany.companyName,tblTenderBidDetail.cellValue from TblTenderBid tblTenderBid ");
        queryString.append(" inner join tblTenderBid.tblUserLogin.tblBidderApprovalDetail tblBidderApprovalDetail ");
        queryString.append(" inner join tblTenderBid.tblTenderBidMatrix tblTenderBidMatrix ");
        queryString.append(" inner join tblTenderBidMatrix.tblTenderBidDetail tblTenderBidDetail ");
        queryString.append(" inner join tblTenderBid.tblCompany tblCompany ");
        queryString.append(" where tblTenderBidDetail.tblTenderCell.cellId in (:cellIds) ");
        queryString.append(" and tblBidderApprovalDetail.isApproved=1 and tblBidderApprovalDetail.tblTenderEnvelope.envelopeId in (:envelopeId) and cast(tblTenderBidDetail.cellValue as float) != 0 ");
        queryString.append(" order by tblTenderBidMatrix.tblTenderTable.tableId,cast(tblTenderBidDetail.cellValue As float) ").append(reportVarient).append( ")");
        return hibernateQueryDao.createNewQuery(queryString.toString(), var);
    }
    /**
     * 
     * @param reportId
     * @return
     * @throws Exception 
     */
    public  List<Object[]> getDynReportCellByReportId(int reportId,int isItemwiseWinner,int clientId) throws Exception{
    	Map<String,Object> var = new HashMap<String,Object>();       
        var.put("clientId", clientId);
	    List<Object[]> list = null;    
	    StringBuilder query=new StringBuilder("select distinct tblDynReportColumn.columnName,tblDynReportCell.companyId,tblDynReportColumn.columnId,tblDynReportColumn.filledBy,tblDynReportCell.cellValue ");
	    query.append(",(select tblBidderStatus.tblUserLogin.userId from TblBidderStatus tblBidderStatus where tblBidderStatus.tblClient.clientId=:clientId and tblBidderStatus.tblCompany.companyId=tblDynReportCell.companyId) as userId")
	    .append(" from TblDynReportColumn tblDynReportColumn ")
	    .append(" inner join tblDynReportColumn.tblDynReportCell tblDynReportCell");
	    if(isItemwiseWinner==1){
	    	query.append(" where tblDynReportColumn.filledBy=1 ");
	    }else{
	    	query.append(" where tblDynReportColumn.filledBy in (1,3) ");
	    }
	    
	    if(reportId!=0){
	    	 var.put("reportId", reportId);
	    	query.append(" and tblDynReportCell.tblDynReport.reportId=:reportId ");
	    }
	    query.append(" order by tblDynReportColumn.filledBy desc,tblDynReportCell.cellValue asc");
	    list = hibernateQueryDao.createNewQuery(query.toString(), var)     ;      
	    return list;
    }
    /**
     * 
     * @param reportId,companyId
     * @return
     * @throws Exception 
     */
    public  Object[] getDynReportCellValueByCompanyId(int reportId,int companyId) throws Exception{
    	Map<String,Object> var = new HashMap<String,Object>();       
        var.put("reportId", reportId);
        var.put("companyId", companyId);
	    List<Object[]> list = null;    
	    StringBuilder query=new StringBuilder("select tblDynReportCell.companyId,tblDynReportCell.cellValue ")
	    .append(" from TblDynReportColumn tblDynReportColumn ")
	    .append(" inner join tblDynReportColumn.tblDynReportCell tblDynReportCell")
	    .append(" where tblDynReportColumn.filledBy=2 ")	    
	    .append(" and tblDynReportCell.tblDynReport.reportId=:reportId ")
	    .append(" and tblDynReportCell.companyId=:companyId ");
	    list = hibernateQueryDao.createNewQuery(query.toString(), var)     ;      
	    return (list!=null && !list.isEmpty()) ? list.get(0) : null;
    }
    /**
     * 
     * @param reportId
     * @return
     * @throws Exception 
     */
    public  TblDynReport getDynReportById(int tenderId,int reportOn) throws Exception{
        List<TblDynReport> list = null;        
        list = tblDynReportDao.findTblDynReport("tblTender.tenderId",Operation_enum.EQ,tenderId,"reportOn",Operation_enum.EQ,reportOn);                
        return (list!=null && !list.isEmpty()) ? list.get(0) : null;            
    }
    
    /**
     * 
     * @param reportId
     * @return isDecrypted all approved bidder or not
     * @throws Exception 
     */
    public boolean checkIsDecryptedAllApprovedBidderByTenderId(int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();
	    var.put("tenderId",tenderId);
	    StringBuilder query = new StringBuilder();
	    query.append(" SELECT tf.envelopeId, tf.formId,tb.companyId,case when count(tto.tenderOpenId) > 0 then 1 else 0 end isDecrypted, case when count(ba.companyId) = 0 then 1 else 0 end isApproved");
	    query.append(" FROM  apptender.tbl_TenderEnvelope te");
	    query.append(" LEFT JOIN apptenderbid.tbl_FinalSubmission fs on fs.tenderId = te.tenderId and partnerType in (0,1,2)");
	    query.append(" INNER JOIN apptender.tbl_TenderForm tf ON tf.envelopeId= te.envelopeId ");
	    query.append(" LEFT JOIN apptenderbid.tbl_TenderBid tb ON te.tenderId = tb.tenderId and fs.companyId = tb.companyId  and tf.formId = tb.formId");
		query.append(" LEFT JOIN (SELECT bla.companyid");
			query.append(" FROM apptender.tbl_tenderenvelope tle");
			query.append(" INNER JOIN apptenderresult.tbl_BidderApprovalDetail bla ON tle.tenderId=bla.tenderId and tle.envelopeId=bla.envelopeId  and bla.tenderId=:tenderId and isApproved=0");
			query.append(" GROUP BY bla.companyid");
			query.append(" ) ba on ba.companyId= tb.companyId");
		query.append(" LEFT JOIN apptenderresult.tbl_TenderOpen tto ON tf.tenderId = tto.tenderId and tto.envelopeId= te.envelopeId and tf.formId = tto.formId and tto.companyId=fs.companyId  and tto.decryptionLevel=1 ");
		query.append(" WHERE tf.tenderId=:tenderId and tf.cstatus = 1 and tf.isPriceBid =1 and tb.companyId is not null");
		query.append(" GROUP BY tf.envelopeId, tf.formId,tb.companyId");
		List<Object[]> decryptedAndApprovedList = hibernateQueryDao.createSQLQuery(query.toString(), var);
	    boolean isDecryptionDoneAndOpen = true;
		for (Object[] eachFormWiseDAB : decryptedAndApprovedList) {
	    	if("0".equalsIgnoreCase(eachFormWiseDAB[3].toString()) && "1".equalsIgnoreCase(eachFormWiseDAB[4].toString())){
	    		isDecryptionDoneAndOpen = false;
	    	}
		}
		return isDecryptionDoneAndOpen;
	}
    
    /**
     * @author vivek.rajyaguru
     * @param tenderId
     * @param auctionId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderItemWiseReportDtls(int tenderId,int auctionId,int biddingVariant)throws Exception{
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("auctionId",auctionId);
         StringBuffer sb = new StringBuffer();
         sb.append(" select BD.rowId as c0,D.[1] as c1,D.[2] as c2,BD.bidderId as c3,BD.companyName as c4,TD.cellValue as c5,AD.bidPrice as c6,BD.loginId as c7 ");
         sb.append(" ,case when convert(decimal(18,5),isnull(TD.cellValue,0)) ");
         if(biddingVariant==2){
        	 sb.append("  <  ");
         }else if(biddingVariant==1){
        	 sb.append("  >  ");
         }
         sb.append(" convert(decimal(18,5),isnull(AD.bidPrice,0))  ");
         sb.append(" then ");
         sb.append(" case when  convert(decimal(18,5),isnull(AD.bidPrice,0))=0  ");
         sb.append(" then convert(decimal(18,5),isnull(TD.cellValue,0))  ");
         sb.append(" else convert(decimal(18,5),isnull(AD.bidPrice,0)) ");
         sb.append(" end ");
         sb.append("else   ");
         sb.append(" case when convert(decimal(18,5),isnull(TD.cellValue,0)) = 0  ");
         sb.append(" then convert(decimal(18,5),isnull(AD.bidPrice,0))  ");
         sb.append(" else convert(decimal(18,5),isnull(TD.cellValue,0))  ");
         sb.append(" end   ");
         sb.append("end as c8 ");
         sb.append(" from (select  DISTINCT ISNULL(ab.rowId,tm.auctionRowId) rowId,ABR.bidderId,UD.companyName,UD.loginId");
         sb.append(" from appauctionbid.tbl_AuctionBid AB");
         sb.append(" INNER JOIN  appauctionbid.tbl_AuctionBidRank ABR ON AB.bidderId=ABR.bidderId and AB.bidId=ABR.bidId ");
         sb.append(" and AB.auctionId=ABR.auctionId and AB.auctionId=:auctionId and ABR.isActive=1 ");
         sb.append(" INNER JOIN appuser.tbl_userDetail UD ON ABR.bidderId=UD.userId and UD.userDetailId=AB.userDetailId ");
         sb.append(" LEFT JOIN appcommon.tbl_TenderAuctionItemMapping tm ON tm.auctionId = ab.auctionId and ab.rowId = tm.auctionRowId ");
         sb.append(" union ");
         sb.append(" select TCL.rowId,TB.bidderId,UD.companyName,UD.loginId");
         sb.append(" from apptender.tbl_TenderGovColumn TGC   ");
         sb.append(" INNER JOIN apptender.tbl_TenderForm TF ON TGC.formId=TF.formId and TF.cstatus=1 and TGC.tenderId=:tenderId ");
         sb.append(" INNER JOIN apptender.tbl_TenderColumn TC ON TGC.columnId=TC.columnId and TF.formId=TC.formId and TGC.tableId=TC.tableId  ");
         sb.append(" INNER JOIN apptender.tbl_TenderCell TCL ON TCL.columnId=TC.columnId and TCL.formId=TC.formId and TCL.tableId=TC.tableId and TCL.dataType!=0  ");
         sb.append(" INNER JOIN apptenderbid.tbl_TenderBid TB ON TB.cstatus = 2 and TB.formId=TC.formId  ");
         sb.append(" INNER JOIN apptenderbid.tbl_TenderBidMatrix TBM ON TBM.bidId=TB.bidId   ");
         sb.append(" INNER JOIN apptenderresult.tbl_TenderBidDetail TBD ON TBD.bidTableId=TBM.bidTableId and TBD.cellId=TCL.cellId   ");
         sb.append(" INNER JOIN apptenderbid.tbl_FinalSubmission FS ON FS.tenderId = TB.tenderId AND TB.companyId = FS.companyId AND FS.partnerType IN (0, 1, 2)  ");
         sb.append(" INNER JOIN appuser.tbl_UserDetail UD ON UD.userDetailId=FS.userDetailId) AS BD ");
         sb.append(" LEFT OUTER JOIN (select TCL.rowId,TB.bidderId,UD.companyName,TBD.cellValue  ");
         sb.append(" from apptender.tbl_TenderGovColumn TGC  ");
         sb.append(" INNER JOIN apptender.tbl_TenderForm TF ON TGC.formId=TF.formId and TF.cstatus=1 and TGC.tenderId=:tenderId ");
         sb.append(" INNER JOIN apptender.tbl_TenderColumn TC ON TGC.columnId=TC.columnId and TF.formId=TC.formId and TGC.tableId=TC.tableId ");
         sb.append(" INNER JOIN apptender.tbl_TenderCell TCL ON TCL.columnId=TC.columnId and TCL.formId=TC.formId and TCL.tableId=TC.tableId and TCL.dataType!=0 ");
         sb.append(" INNER JOIN apptenderbid.tbl_TenderBid TB ON TB.cstatus = 2 and TB.formId=TC.formId ");
         sb.append(" INNER JOIN apptenderbid.tbl_TenderBidMatrix TBM ON TBM.bidId=TB.bidId  ");
         sb.append(" INNER JOIN apptenderresult.tbl_TenderBidDetail TBD ON TBD.bidTableId=TBM.bidTableId and TBD.cellId=TCL.cellId  ");
         sb.append(" INNER JOIN apptenderbid.tbl_FinalSubmission FS ON FS.tenderId = TB.tenderId AND TB.companyId = FS.companyId AND FS.partnerType IN (0, 1, 2) ");
         sb.append(" INNER JOIN appuser.tbl_UserDetail UD ON UD.userDetailId=FS.userDetailId  	");
         sb.append(" )  AS TD ON BD.bidderId=TD.bidderId and TD.rowId=BD.rowId ");
         sb.append(" LEFT OUTER JOIN( select  DISTINCT ISNULL(tm.tenderRowId,ABR.rowId) rowId,ABR.bidderId,UD.companyName,ABR.bidPrice ");
         sb.append("  from appauctionbid.tbl_AuctionBid AB ");
         sb.append(" INNER JOIN  appauctionbid.tbl_AuctionBidRank ABR ON AB.bidderId=ABR.bidderId and AB.bidId=ABR.bidId ");
         sb.append(" and AB.auctionId=ABR.auctionId and AB.auctionId=:auctionId and ABR.isActive=1  ");
         sb.append(" INNER JOIN appuser.tbl_userDetail UD ON ABR.bidderId=UD.userId and UD.userDetailId=AB.userDetailId  LEFT JOIN appcommon.tbl_TenderAuctionItemMapping tm ON tm.auctionId = ab.auctionId AND tm.auctionRowId = ab.rowId) AS AD ON ");
         sb.append(" BD.bidderId=AD.bidderId and AD.rowId=BD.rowId  ");
         sb.append(" LEFT OUTER JOIN (SELECT [formId],[tableId],[rowId],[1],[2] ");
         sb.append(" FROM (SELECT DISTINCT TCC1.formId, TCC1.tableId, TCC1.rowId, TCC1.cellValue , TC1.columnTypeId  ");
         sb.append(" FROM apptender.tbl_TenderGovColumn TGC1  ");
         sb.append(" INNER JOIN  apptender.tbl_TenderForm TF1 ON TGC1.formId = TF1.formId and TGC1.tenderId =:tenderId AND TF1.cstatus = 1 ");
         sb.append(" INNER JOIN apptender.tbl_TenderCell TCC1 ON TCC1.formId=TF1.formId ");
         sb.append(" INNER JOIN apptender.tbl_TenderColumn TC1 on TCC1.columnId = TC1.columnId  ");
         sb.append(" WHERE TC1.filledBy = 1 and TC1.columnTypeId in (1,2)) AS A ");
         sb.append(" PIVOT (MAX(cellValue) FOR columnTypeId IN ([1], [2])) AS P ) AS D ON D.rowId=BD.rowId where (TD.cellValue is not null or AD.bidPrice is not null)  order by BD.rowId asc, ");
         if(biddingVariant==2){
        	 sb.append(" c8 desc ");
         }else if(biddingVariant==1){
        	 sb.append(" c8 asc ");
         }
        int nVarCharColumnIndex [] = {1,2,4,5,6,7,8};
        return  hibernateQueryDao.createSQLQuery(sb.toString(), var, nVarCharColumnIndex, 9);
    }
    
    
    /**
     * @author vivek.rajyaguru
     * @param tenderId
     * @param auctionId
     * @param moduleId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderAuctionDtls(int tenderId,int auctionId,int moduleId) throws Exception{
    	 Map<String, Object> var = new HashMap<String, Object>();
         StringBuffer sb = new StringBuffer();
         if(tenderId>0 && moduleId==3){
        	 var.put("tenderId",tenderId);
        	 sb.append(" select PE.oldEventId , PE.newEventId, PE.procurementEventId from appcommon.tbl_ProcurementEvent PE where PE.oldEventId=:tenderId and PE.newEventTypeId=1  ");
         }
         if(auctionId>0){
        	 var.put("auctionId",auctionId);
        	 sb.append(" select PE.oldEventId , PE.newEventId,PE.procurementEventId  from appcommon.tbl_ProcurementEvent PE where PE.newEventId=:auctionId   ");
         }
         sb.append("order by PE.procurementEventId desc ");
         
         return hibernateQueryDao.createSQLQuery(sb.toString(), var);
    }
    
    
 /**
 * @author vivek.rajyaguru
 * @param tenderId
 * @param auctionId
 * @return
 * @throws Exception
 */
public List<Object[]> getTenderGrandTotalReportDtls(int tenderId,int auctionId,int isRebateForm,int biddingVariant)throws Exception{
   	 Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("auctionId",auctionId);
        StringBuffer sb = new StringBuffer();
        sb.append(" select BD.bidderId as c0,BD.companyName as c1,TD.cellValue as c2,AD.bidprice as c3,BD.loginId as c4 ");
        sb.append(" ,case when convert(decimal(18,5),isnull(TD.cellValue,0)) ");
        if(biddingVariant==2){
       	 sb.append("  <  ");
        }else if(biddingVariant==1){
       	 sb.append("  >  ");
        }
        sb.append(" convert(decimal(18,5),isnull(AD.bidPrice,0))  ");
        sb.append(" then ");
        sb.append(" case when  convert(decimal(18,5),isnull(AD.bidPrice,0))=0  ");
        sb.append(" then convert(decimal(18,5),isnull(TD.cellValue,0))  ");
        sb.append(" else convert(decimal(18,5),isnull(AD.bidPrice,0)) ");
        sb.append(" end ");
        sb.append("else   ");
        sb.append(" case when convert(decimal(18,5),isnull(TD.cellValue,0)) = 0  ");
        sb.append(" then convert(decimal(18,5),isnull(AD.bidPrice,0))  ");
        sb.append(" else convert(decimal(18,5),isnull(TD.cellValue,0))  ");
        sb.append(" end   ");
        sb.append("end as c5 ");
        sb.append(" from (select TB.bidderId,UD.companyName,UD.loginId ");
        sb.append(" from apptender.tbl_Rebate TR ");
        sb.append(" INNER JOIN apptender.tbl_RebateForm RF ON TR.tenderId=:tenderId and TR.rebateId=RF.rebateId ");
        sb.append(" INNER JOIN apptender.tbl_TenderForm TF ON RF.formId=TF.formId and TF.cstatus=1 "); 
        sb.append(" INNER JOIN apptender.tbl_TenderCell TCL ON TCL.formId=RF.formId and RF.cellId=TCL.cellId ");
        sb.append(" INNER JOIN apptenderbid.tbl_TenderBid TB ON TB.cstatus = 2 and TB.formId=TF.formId ");
        sb.append(" INNER JOIN apptenderbid.tbl_TenderBidMatrix TBM ON TBM.bidId=TB.bidId  ");
        sb.append(" INNER JOIN apptenderresult.tbl_TenderBidDetail TBD ON TBD.bidTableId=TBM.bidTableId  and TBD.cellId=TCL.cellId ");
        sb.append(" INNER JOIN apptenderbid.tbl_FinalSubmission FS ON FS.tenderId = TB.tenderId AND TB.companyId = FS.companyId AND FS.partnerType IN (0, 1, 2) ");
        sb.append(" INNER JOIN appuser.tbl_UserDetail UD ON UD.userDetailId=FS.userDetailId ");
        sb.append(" union   ");
        sb.append(" select ABR.bidderId,UD.companyName,UD.loginId ");
        sb.append(" from appauctionbid.tbl_AuctionBid AB ");
        sb.append(" INNER JOIN  appauctionbid.tbl_AuctionBidRank ABR ON AB.bidderId=ABR.bidderId and AB.bidId=ABR.bidId  ");
        sb.append(" and AB.auctionId=ABR.auctionId and AB.auctionId=:auctionId  and ABR.isActive=1 and ABR.rowId=0  ");
        sb.append(" INNER JOIN appuser.tbl_userDetail UD ON ABR.bidderId=UD.userId and UD.userDetailId=AB.userDetailId  ");
        sb.append(" ) AS BD  ");
        sb.append(" LEFT OUTER JOIN ( ");
        sb.append(" select TB.bidderId,UD.companyName, CASE WHEN TBD.cellValue IS NULL or TBD.cellValue ='' or TR.isRebateForm=0 THEN ");
        sb.append(" TBD.cellValue ELSE CONVERT(decimal(18,5),(convert(decimal(18,5),TBD.cellValue)-(convert(decimal(18,5),TBD.cellValue) * convert(decimal(18,5),TRD.rebateValue))/100)) END AS cellValue ");
        sb.append(" from apptender.tbl_Rebate TR ");
        sb.append(" INNER JOIN apptender.tbl_RebateForm RF ON TR.tenderId=:tenderId and TR.rebateId=RF.rebateId ");
        sb.append(" INNER JOIN apptender.tbl_TenderForm TF ON RF.formId=TF.formId and TF.cstatus=1  ");
        sb.append(" INNER JOIN apptender.tbl_TenderCell TCL ON TCL.formId=RF.formId and RF.cellId=TCL.cellId ");
        sb.append(" INNER JOIN apptenderbid.tbl_TenderBid TB ON TB.cstatus = 2 and TB.formId=TF.formId ");
        sb.append(" INNER JOIN apptenderbid.tbl_TenderBidMatrix TBM ON TBM.bidId=TB.bidId  ");
        sb.append(" INNER JOIN apptenderresult.tbl_TenderBidDetail TBD ON TBD.bidTableId=TBM.bidTableId  and TBD.cellId=TCL.cellId ");
        sb.append(" INNER JOIN apptenderbid.tbl_FinalSubmission FS ON FS.tenderId = TB.tenderId AND TB.companyId = FS.companyId AND FS.partnerType IN (0, 1, 2) ");
        sb.append(" INNER JOIN appuser.tbl_UserDetail UD ON UD.userDetailId=FS.userDetailId ");
        sb.append(" LEFT OUTER JOIN apptenderbid.tbl_TenderRebate TTR ON FS.companyId=TTR.companyId and TR.rebateId=TTR.rebateId "
    			+ " LEFT OUTER JOIN apptenderresult.tbl_TenderRebateDetail TRD ON TRD.tenderRebateId = TTR.tenderRebateId AND TRD.decryptionLevel in (1,0) ");
        sb.append(" ) AS TD ON TD.bidderId=BD.bidderId ");
        sb.append(" LEFT OUTER JOIN ( ");
        sb.append(" select ABR.bidderId,UD.companyName,ABR.bidPrice ");
        sb.append(" from appauctionbid.tbl_AuctionBid AB ");
        sb.append(" INNER JOIN  appauctionbid.tbl_AuctionBidRank ABR ON AB.bidderId=ABR.bidderId and AB.bidId=ABR.bidId  ");
        sb.append(" and AB.auctionId=ABR.auctionId and AB.auctionId=:auctionId  and ABR.isActive=1 and ABR.rowId=0  ");
        sb.append(" INNER JOIN appuser.tbl_userDetail UD ON ABR.bidderId=UD.userId and UD.userDetailId=AB.userDetailId  ");
        sb.append(" ) AS AD ON AD.bidderId=BD.bidderId order by ");
        if(biddingVariant==2){
       	 sb.append(" c5 desc ");
        }else if(biddingVariant==1){
       	 sb.append(" c5 ");
        }
        
        int nVarCharColumnIndex [] = {1,2,3,4,5};
    return  hibernateQueryDao.createSQLQuery(sb.toString(), var, nVarCharColumnIndex, 6);
   }


/**
 * @param tenderId
 * @param auctionId
 * @return
 * @throws Exception
 */
public List<Object[]> getTenderAuctionItemWiseGoverningColumnsHeaders(int tenderId,int auctionId) throws Exception{
	 Map<String, Object> var = new HashMap<String, Object>();
    StringBuffer sb = new StringBuffer();
    var.put("tenderId",tenderId);
   	var.put("auctionId",auctionId);
   	sb.append(" select TC.columnHeader as c0 ,AC.columnHeader as c1,TT.noOfRows as c2 from appcommon.tbl_ProcurementEvent PE ");
   	sb.append(" INNER JOIN apptender.tbl_TenderGovColumn TGC ON PE.oldEventId=TGC.tenderId and PE.oldEventId=:tenderId ");
   	sb.append(" INNER JOIN apptender.tbl_TenderForm TF ON TGC.formId=TF.formId and TF.cstatus=1 ");
   	sb.append("  INNER JOIN apptender.tbl_TenderTable TT ON TT.formId=TF.formId and TGC.tableId=TT.tableId ");
   	sb.append(" INNER JOIN apptender.tbl_TenderColumn TC ON TGC.columnId=TC.columnId  and TT.tableId=TC.tableId  ");
   	sb.append(" INNER JOIN appauction.tbl_AuctionTable AT ON  PE.newEventId=AT.auctionId and AT.auctionId=:auctionId  ");
   	sb.append(" INNER JOIN appauction.tbl_AuctionGovColumn AGC ON  AGC.tableId=AT.tableId  ");
   	sb.append(" INNER JOIN appauction.tbl_AuctionColumn AC ON AGC.columnId=AC.columnId  ");
   	int nVarCharColumnIndex [] = {0,1};
    return  hibernateQueryDao.createSQLQuery(sb.toString(), var, nVarCharColumnIndex, 3);
}

/**
 * @param tenderId
 * @param auctionId
 * @return
 * @throws Exception
 */
public List<Object[]> getTenderAuctionGrandTotalGoverningColumnsHeaders(int tenderId,int auctionId) throws Exception{
	 Map<String, Object> var = new HashMap<String, Object>();
   StringBuffer sb = new StringBuffer();
   var.put("tenderId",tenderId);
  	var.put("auctionId",auctionId);
  	sb.append(" select TC.columnHeader as c0 ,AC.columnHeader as c1 from appcommon.tbl_ProcurementEvent PE ");
  	sb.append(" INNER JOIN apptender.tbl_Rebate TR ON PE.oldEventId=TR.tenderId and PE.oldEventId=:tenderId ");
  	sb.append(" INNER JOIN apptender.tbl_RebateForm RF ON TR.rebateId=RF.rebateId  ");
  	sb.append(" INNER JOIN apptender.tbl_TenderCell TCC ON TCC.cellId=RF.cellId  ");
  	sb.append(" INNER JOIN apptender.tbl_TenderColumn TC ON TCC.columnId=TC.columnId  ");
  	sb.append(" INNER JOIN appauction.tbl_AuctionTable AT ON  PE.newEventId=AT.auctionId and AT.auctionId=:auctionId  ");
  	sb.append(" INNER JOIN appauction.tbl_AuctionGovColumn AGC ON  AGC.tableId=AT.tableId ");
  	sb.append(" INNER JOIN appauction.tbl_AuctionColumn AC ON AGC.columnId=AC.columnId ");
  	int nVarCharColumnIndex [] = {0,1};
   return  hibernateQueryDao.createSQLQuery(sb.toString(), var, nVarCharColumnIndex, 2);
}



/**
 * @author vivek.rajyaguru
 * @param tenderId
 * @param reportOn
 * @param reportType
 * @return
 * @throws Exception
 */
public boolean isDynReportCellValueExist(int tenderId,int reportOn,int reportType,int isDemoTender)throws Exception{
	StringBuilder sb=new StringBuilder();
	Map<String, Object> var = new HashMap<String, Object>();
	var.put("tenderId",tenderId);
	var.put("reportOn",reportOn);
	var.put("reportType",reportType);
	var.put("isDemoTender",isDemoTender);
	sb.append(" SELECT tblDynReportCell.cellId FROM TblDynReport tblDynReport ");
	sb.append(" INNER JOIN tblDynReport.tblTender tblTender with tblTender.tenderId=:tenderId and tblTender.isDemoTender=:isDemoTender ");
	sb.append(" INNER JOIN tblDynReport.tblDynReportCell tblDynReportCell ");
	sb.append(" WHERE tblDynReport.reportOn=:reportOn and tblDynReport.reportType=:reportType ");
	List<Object[]> listTblDynReportCell=hibernateQueryDao.createQuery(sb.toString(), var);
	return listTblDynReportCell!=null && !listTblDynReportCell.isEmpty() ? true : false;
}
/**
 * @author anjali
 * @param reportId
 * @return
 * @throws Exception 
 */
public  boolean deleteTblDynReportCellId(int reportId) throws Exception{
    int cnt = 0;
    Map<String, Object> var = new HashMap<String, Object>();
    var.put("reportId",reportId);
    cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblDynReportCell tblDynReportCell where tblDynReportCell.tblDynReport.reportId=:reportId",var);        
    return cnt!=0;
}


/**
 * @param tenderId
 * @param reportOn
 * @return
 * @throws Exception
 */
public List<Object> getDynReport(int tenderId,List<Integer> reportOn) throws Exception{
    List<Object> list = null;
    Map<String, Object> var = new HashMap<String, Object>();
    var.put("tenderId", tenderId);
    var.put("reportOn", reportOn);
    list = hibernateQueryDao.getSingleColQuery("select tbldynreport.reportId from TblDynReport tbldynreport where tbldynreport.tblTender.tenderId=:tenderId and tbldynreport.reportOn in (:reportOn)", var);
    return list;
}

/**
 * @param reportId
 * @return
 * @throws Exception
 */
public  boolean deleteTblDynReportCellIds(List<Object> reportId) throws Exception{
    int cnt = 0;
    Map<String, Object> var = new HashMap<String, Object>();
    var.put("reportId",reportId);
    cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblDynReportCell tblDynReportCell where tblDynReportCell.tblDynReport.reportId in (:reportId)",var);        
    return cnt!=0;
}

public boolean checkUserisMappedOrNotIW(int auctionId,int bidderId,int rowId) throws Exception {
	boolean retVal=false;
	List<Object> rowObj = getAuctionRowID(auctionId,rowId);
	Map<String,Object> vars=new HashMap<String, Object>();
	List<Object> data=null;
	vars.put("auctionId", auctionId);
	vars.put("userId", bidderId);
	vars.put("rowObj", rowObj);
	if(rowObj != null || !rowObj.isEmpty()) {
	String query="select abm.mapBidderId  from TblAuctionBidderMap abm where abm.tblAuction.auctionId =:auctionId and abm.tblUserLogin.userId=:userId and abm.rowId in (:rowObj) ";  
	data=hibernateQueryDao.getSingleColQuery(query,vars);
	}
	if(data != null || !data.isEmpty())
	{
		retVal=true;
	}
	else
	{
		retVal=false;
	}
		
	return retVal;
}

public boolean checkUserisMappedOrNotGT(int auctionId,int bidderId) throws Exception {
	boolean retVal=false;
	Map<String,Object> vars=new HashMap<String, Object>();
	List<Object> data=null;
	vars.put("auctionId", auctionId);
	vars.put("userId", bidderId);
	String query="select abm.mapBidderId from TblAuctionBidderMap abm where abm.tblAuction.auctionId =:auctionId and abm.tblUserLogin.userId=:userId";
	data=hibernateQueryDao.getSingleColQuery(query,vars);
	if(!data.isEmpty())
	{
		retVal=true;
	}
	else
	{
		retVal=false;
	}
		
	return retVal;
}
	public boolean checkUserIsMappedInTenderIW(int tenderId,int bidderId,int rowId) throws Exception 
	{
		boolean retVal=false;
		Map<String,Object> vars=new HashMap<String,Object>();
		vars.put("tenderId", tenderId);
		vars.put("bidderId", bidderId);
		vars.put("rowId", rowId);
		String query="select tbm.mapBidderId from TblTenderBidderMap tbm inner join tbm.tblItemBidderMap ibm where tbm.tblTender.tenderId=:tenderId and tbm.tblUserLogin.userId=:bidderId and ibm.rowId=:rowId";
		List<Object> data=hibernateQueryDao.getSingleColQuery(query, vars);
		if(!data.isEmpty()) {
			retVal=true;
		}
		else
		{
			retVal=false;
		}
		return retVal;
	}
	public boolean checkUserIsMappedInTenderGT(int tenderId,int bidderId) throws Exception
	{
		boolean retVal=false;
		Map<String,Object> vars=new HashMap<String, Object>();
		vars.put("tenderId", tenderId);
		vars.put("bidderId",bidderId);
		String query="select tbm.mapBidderId from TblTenderBidderMap tbm where tbm.tblTender.tenderId=:tenderId and tbm.tblUserLogin.userId=:bidderId ";
		List<Object> result=hibernateQueryDao.getSingleColQuery(query, vars);
		if(!result.isEmpty()) {
			retVal=true;
		}
		else
		{
			retVal=false;
		}
		return retVal;
	}
	private List<Object> getAuctionRowID(int auctionId,int rowId) {
		Map<String,Object> vars=new HashMap<String, Object>();
		List<Object> data=null;
		vars.put("auctionId", auctionId);
		vars.put("rowId", rowId);
		String query = "select auctionRowId from TblTenderAuctionItemMapping TAI where TAI.tenderRowId =:rowId and TAI.tblAuction.auctionId =:auctionId" ;
		data=hibernateQueryDao.getSingleColQuery(query,vars);
        return data;
	}
	
}