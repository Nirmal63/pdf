/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.awt.print.Book;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.UUID;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.poi.hssf.usermodel.DVConstraint;
import org.apache.poi.hssf.usermodel.HSSFDataValidation;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellRangeAddressList;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DataValidationConstraint.OperatorType;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellReference;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.expression.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.TblCouponHistoryDao;
import com.etl.eproc.common.daostoredprocedure.SPCompanyNameEncoded;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientBidTerm;
import com.etl.eproc.common.model.TblComboDetail;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblCouponHistory;
import com.etl.eproc.common.model.TblNegotiation;
import com.etl.eproc.etender.model.TblTenderBidRegression;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.NegotiationService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.NumberToWorldConversion;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.daointerface.TblTenderDao;
import com.etl.eproc.etender.model.TblBidDetail;
import com.etl.eproc.etender.model.TblBidderPresence;
import com.etl.eproc.etender.model.TblChallan;
import com.etl.eproc.etender.model.TblConsortium;
import com.etl.eproc.etender.model.TblEventFees;
import com.etl.eproc.etender.model.TblItemSelection;
import com.etl.eproc.etender.model.TblRebate;
import com.etl.eproc.etender.model.TblRebateDetail;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBid;
import com.etl.eproc.etender.model.TblTenderBidConfirmation;
import com.etl.eproc.etender.model.TblTenderBidCurrency;
import com.etl.eproc.etender.model.TblTenderBidMatrix;
import com.etl.eproc.etender.model.TblTenderBidRegression;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderColumn;
import com.etl.eproc.etender.model.TblTenderCurrency;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderProxyBid;
import com.etl.eproc.etender.model.TblTenderRebate;
import com.etl.eproc.etender.model.TblTenderTable;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.EventBidSubmissionService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderFormService;

/**
 *
 * @author TaherT
 */
@Controller
@RequestMapping("/etender")
public class EventBidSubmissionController {
    
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private ExceptionHandlerService  exceptionHandlerService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private EventBidSubmissionService eventBidSubmissionService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private SPCompanyNameEncoded spCompanyNameEncoded;
    @Autowired
    private NumberToWorldConversion numberToWorldConversion;
    @Autowired
    private LoginService loginService;
    @Autowired
    private BiddingTenderDashboardController biddingTenderDashboardController;
    @Autowired
    private NegotiationService negotiationService;
    @Autowired
    private TblTenderDao tblTenderDao;
    @Autowired
    private TblCouponHistoryDao tblCouponHistoryDao;
            
    @Value("#{projectProperties['pki_eventspecific']?:2}")   
    private int pkiEventSpecific;
    @Value("#{projectProperties['moduleId_tender']?:3}")   
    private int tenderModuleId;
    @Value("#{projectProperties['srilanka_clientId']?:0}")   
    private int srilankaClient;
     @Value("#{projectProperties['future_release']?:false}")
    private Boolean futureRelease;
    @Value("#{projectProperties['pki_enable']?:1}")   
    private int pkiEnable;
    @Value("#{etenderAuditTrailProperties['createrebatepercentagepage']}")
    private String createrebatepercentagepage;
    @Value("#{etenderAuditTrailProperties['rebatepercentageadd']}")
    private String rebatepercentageadd;
    @Value("#{etenderAuditTrailProperties['rebatepercentageaddfail']}")
    private String rebatepercentageaddfail;
    @Value("#{etenderAuditTrailProperties['rebatepercentageupdate']}")
    private String rebatepercentageupdate;
    @Value("#{etenderAuditTrailProperties['rebatepercentageupdatefail']}")
    private String rebatepercentageupdatefail;
    @Value("#{etenderAuditTrailProperties['bidForm']}")
    private String bidFormAudit;
    @Value("#{etenderAuditTrailProperties['bidFormEdit']}")
    private String bidFormEditAudit;
    @Value("#{etenderAuditTrailProperties['addBidForm']}")
    private String addBidFormAudit;
    @Value("#{etenderAuditTrailProperties['addBidFormEdit']}")
    private String addBidFormEditAudit;
    @Value("#{etenderAuditTrailProperties['postBidwithdrawal']}")
    private String postBidwithdrawalAudit;
    @Value("#{etenderAuditTrailProperties['postBidwithdrawalFailed']}")
    private String postBidwithdrawalFailedAudit;
    @Value("#{etenderAuditTrailProperties['getBidwithdrawal']}")
    private String getBidwithdrawal;
    @Value("#{etenderAuditTrailProperties['getuploadtenderdocuments']}")
    private String getUploadTenderDocuments;
    
    @Value("#{tenderlinkProperties['bid_preparation_and_submission_create_bid']?:237}")
    private int bidFormCreate;
    @Value("#{tenderlinkProperties['bidder_edit_bid']?:314}")
    private int bidFormEdit;
    @Value("#{etenderAuditTrailProperties['viewBidForm']}")
    private String viewBidFormAudit;
    @Value("#{tenderlinkProperties['bidder_view_bid']?:287}")
    private int viewBidForm;
    @Value("#{etenderAuditTrailProperties['deleteBid']}")
    private String deleteBidAudit;
    @Value("#{tenderlinkProperties['bidder_delete_bid']?:288}")
    private int deleteBid;
    @Value("#{tenderlinkProperties['bidder_bid_withdrawal']?:288}")
    private int bidWithdrawalLinkId;
    @Value("#{tenderlinkProperties['bidder_i_agree']?:301}")
    private int bidderiAgreeLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_result']?:302}")
    private int bidEvaluationResultLinkId;

    @Value("#{tenderlinkProperties['bidder_add_rebate_detail']?:303}")
    private int addRebateDetailLinkId;
    @Value("#{tenderlinkProperties['bidder_edit_rebate_detail']?:304}")
    private int editRebateDetailLinkId;
    @Value("#{tenderlinkProperties['bidder_view_rebate_detail']?:305}")
    private int viewRebateDetailLinkId;
    @Value("#{etenderAuditTrailProperties['postfinalSubmission']}")
    private String postFinalSubmission;
    @Value("#{tenderlinkProperties['bidder_final_submission']?:291}")
    private int linkFinalSubmission;
    @Value("#{tenderlinkProperties['bidder_view_challan']?:420}")
    private int viewOnlineChallanLinkId;
    @Value("#{tenderlinkProperties['select_items_for_bidding']?:806}")
    private int selectItemsForBiddingLink;
    @Value("#{tenderlinkProperties['regret_items_for_bidding']?:4387}")
    private int regretItemsForBiddingLink;
    @Value("#{tenderlinkProperties['activate_items_for_bidding']?:4388}")
    private int activateItemsForBiddingLink;
    @Value("#{tenderlinkProperties['item_wise_doc_upload']?:808}")
    private int itemWiseDocUploadLinkId;
    @Value("#{etenderAuditTrailProperties['getOnlineChallan']}")
    private String getOnlineChallan;
    @Value("#{projectProperties['file.drive']}")
    private String drive;
    @Value("#{projectProperties['file.upload']}")
    private String upload;
    @Value("#{etenderAuditTrailProperties['getFormItemSelectionPage']}")
    private String getFormItemSelectionPage;
    @Value("#{etenderAuditTrailProperties['setFormItemSelectionPageValue']}")
    private String setFormItemSelectionPageValue;
    @Value("#{etenderAuditTrailProperties['getRegretItemPage']}")
    private String getRegretItemPage;
    @Value("#{etenderAuditTrailProperties['setRegretItemPage']}")
    private String setRegretItemPage;
    @Value("#{etenderAuditTrailProperties['getActivateItemPage']}")
    private String getActivateItemPage;
    @Value("#{etenderAuditTrailProperties['setActivateItemPage']}")
    private String setActivateItemPage;
    @Value("#{projectProperties['idfc_client_id']?:385}")
    private int idfcClientID;
    @Value("#{etenderProperties['bidding_form_document_fees']?:9}")
    private int documentFeesByBidder;
    @Value("#{etenderProperties['bidding_form_emd_amount']?:10}")
    private int emdAmountByBidder;
    @Value("#{etenderAuditTrailProperties['regretted_page_accessed']}")
    private String regrettedPageAccessed;
    @Value("#{etenderAuditTrailProperties['regret_remarks_submitt']}")
    private String regretremarkssubmitted;
    @Value("#{clientProperties['cgClient']}")
    private String cgClient;
   
    @Autowired
    private MessageSource messageSource;
    @Autowired
    private ClientService clientService;
    
    private static final String HIDDEN_TENDER_ID = "hdTenderId";
    private static final int FINALSUBMISSION_REQUEST_TYPE_POST = 1;
    private static final String SKPSIGNTEXT="skpSignText";
    private final static String XFORWARDEDFOR = "X-FORWARDED-FOR";
    private final static String BIDDERDASHBOARD = "etender/bidder/biddingtenderdashboard/";
    private final static String REDIRECTBIDDERDASHBOARD = "redirect:/etender/bidder/biddingtenderdashboard/";
    /**
     * Bid Form Matrix GET
     *
     * @param tenderId
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     * @throws Exception 
     */
    @RequestMapping(value = "/bidder/bidform/{tenderId}/{envelopeId}/{formId}/{bidId}/{enc}", method = RequestMethod.GET)
    public String bidForm(@PathVariable("tenderId") Integer tenderId,@PathVariable("envelopeId") Integer envelopeId, @PathVariable("formId") Integer formId,@PathVariable("bidId") Integer bidId, ModelMap modelMap, HttpServletRequest request) throws Exception {
    	TblTenderForm tblTenderForm = null;
    	boolean isEncCertVerified = false;
    	try {
			 tblTenderForm = tenderFormService.getTenderFormById(formId);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
    	List<TblTender> tblTender = tblTenderDao.findTblTender("tenderId",Operation_enum.EQ,tenderId);
    	if(tblTender.get(0).getCstatus() == 2){
    		String page = "etender/bidder/biddingtenderdashboard/"+tenderId+"/5";
			return "redirect:/"+page+encryptDecryptUtils.generateRedirect(page, request);
    	}else{
    		if(abcUtility.getSessionUserTypeId(request) == 2 && tblTenderForm.getIsEncryptionReq() == 1)
    		{
    			int isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
    			isEncCertVerified = commonService.checkIsCertificateVerified(isCertRequired,2,request);
    		}
    		else
    		{
    			isEncCertVerified = true;    		
    		}
    		request.getSession().setAttribute("isEncCertVerified",isEncCertVerified);
    		if(!isEncCertVerified)
    		{
    			String page = "etender/bidder/biddingtenderdashboard/"+tenderId+"/5";
    			return "redirect:/"+page+encryptDecryptUtils.generateRedirect(page, request);
    		}
    		else
    		{
    			try
    			{
    				SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
    				modelMap.addAttribute("bidId", bidId);
    				modelMap.addAttribute("fromBidForm", true);
    				tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));            
    				modelMap.addAttribute("isCertRequired", Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString()));
    				modelMap.addAttribute("isItemSelectionPageRequired", Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isItemSelectionPageRequired").toString()));
    				modelMap.addAttribute("isPartialFillingAllowedForTender", Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isPartialFillingAllowed").toString()));
    				modelMap.addAttribute("bidderId",sessionBean.getUserId());
    				modelMap.addAttribute("companyId", sessionBean.getCompanyId());
    	            modelMap.addAttribute("sessionTimeOutByHalf", ((request.getSession().getMaxInactiveInterval()*1000)/2));
    				tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);
    				setBidFormData(modelMap, request, tenderId, envelopeId);
    				modelMap.addAttribute("rebateCellId", eventBidSubmissionService.getRebateCellId(formId));
    			} catch (Exception e) {
    				return exceptionHandlerService.writeLog(e);
    			} finally {
    				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidId==0 ? bidFormCreate : bidFormEdit, bidId==0 ? bidFormAudit : bidFormEditAudit, tenderId, formId);
    			}
    			return "/etender/bidder/BidForm";
    		}
    	}
        
        
    }
    
    /** author : heeral.soni
     * used to get online challan details(generate reciept)
     * @param tenderId
     * @param operation
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/bidder/getchallandetail/{tenderId}/{operation}/{enc}" , method = RequestMethod.GET)
    public String getChallanDetail(@PathVariable("tenderId") Integer tenderId,@PathVariable("operation") int operation,ModelMap modelMap, HttpServletRequest request){
        Map<String, Object> emdMap = new HashMap<String, Object>();
        Map<String, Object> docFeesMap = new HashMap<String, Object>();
        BigDecimal amt = new BigDecimal(0.0);
        int companyId = 0;
        int bidderId = 0;
        try {
                SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
                if(sessionBean != null){
                    companyId = sessionBean.getCompanyId();
                    bidderId = sessionBean.getUserId();
                }
                //System.out.println("in get challan--------------->"+companyId);
                //System.out.println("in get challan--------------->"+bidderId);
                int clientId = abcUtility.getSessionClientId(request);
                Object obj = eventBidSubmissionService.getChallanDetails(tenderId, companyId);
                if(obj == null){
                    TblChallan tblChallanDetails = new TblChallan();
                    tblChallanDetails.setChallanNo(eventBidSubmissionService.getMaxChallanId(clientId)+1);
                    tblChallanDetails.setTblClient(new TblClient(clientId));
                    tblChallanDetails.setTblCompany(new TblCompany(companyId));
                    tblChallanDetails.setTblTender(new TblTender(tenderId));
                    eventBidSubmissionService.addChallanDetails(tblChallanDetails);
                    obj = eventBidSubmissionService.getChallanDetails(tenderId, companyId);
                }
                List<Object[]> lstPaymentDetail = eventBidSubmissionService.getOnlinePaymentDeatil(tenderId,bidderId);
            
                if(lstPaymentDetail != null && !lstPaymentDetail.isEmpty()){
                    for (int i = 0; i < lstPaymentDetail.size(); i++) {
                        amt = amt.add(new BigDecimal(lstPaymentDetail.get(i)[2].toString()));
                        if ("DOC FEE".equalsIgnoreCase(lstPaymentDetail.get(i)[0].toString())) {
                            docFeesMap.put("paymentFor", lstPaymentDetail.get(i)[0].toString());
                            docFeesMap.put("deptName", lstPaymentDetail.get(i)[6].toString());
                            docFeesMap.put("amount", lstPaymentDetail.get(i)[2].toString());
                            docFeesMap.put("companyName", lstPaymentDetail.get(i)[3].toString());
                            docFeesMap.put("paymentTypeId", lstPaymentDetail.get(i)[4].toString());
                            docFeesMap.put("amountInWords",numberToWorldConversion.doIt(new BigDecimal((lstPaymentDetail.get(i)[2].toString()))));
                        }else{
                             emdMap.put("paymentFor", lstPaymentDetail.get(i)[0].toString());
                             emdMap.put("deptName", lstPaymentDetail.get(i)[6].toString());
                             emdMap.put("amount", lstPaymentDetail.get(i)[2].toString());
                             emdMap.put("companyName", lstPaymentDetail.get(i)[3].toString());
                             emdMap.put("paymentTypeId", lstPaymentDetail.get(i)[4].toString());
                             emdMap.put("amountInWords",numberToWorldConversion.doIt(new BigDecimal((lstPaymentDetail.get(i)[2].toString()))));
                        }                     
                    }
                }
                modelMap.addAttribute("tenderId", tenderId);
                modelMap.addAttribute("amt",amt);
                modelMap.addAttribute("tenderBrief",tenderCommonService.getTenderFields(tenderId, "tenderBrief").get(0));
                modelMap.addAttribute("tblTenderWiseBudgetDetails", tenderCommonService.getTenderWiseBudgetDetailsByTenderId(tenderId));
                modelMap.addAttribute("operation",operation);//for save as excel(1) and word(2)
                modelMap.addAttribute("lstPaymentDetail",lstPaymentDetail);
                modelMap.addAttribute("challanDetail",obj);//set challan details
                modelMap.addAttribute("emdMap", emdMap);
                modelMap.addAttribute("docFeesMap", docFeesMap);
        }catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewOnlineChallanLinkId, getOnlineChallan , tenderId, 0);
        }
        return "/etender/bidder/viewChallan";
    }
    
    @RequestMapping(value = "/bidder/addbid", method = RequestMethod.POST)
    public String addBid(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        int tenderId=StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))?Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
        int isItemSelectionPageRequired=StringUtils.hasLength(request.getParameter("hdIsItemSelectionPageRequired"))?Integer.parseInt(request.getParameter("hdIsItemSelectionPageRequired")):0;
        int envelopeId= StringUtils.hasLength(request.getParameter("hdEnvelopeId"))?Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
        int formId= StringUtils.hasLength(request.getParameter("hdFormId"))?Integer.parseInt(request.getParameter("hdFormId")):0;
        boolean isPriceBid=StringUtils.hasLength(request.getParameter("hdIsPriceBid"))? (Integer.parseInt(request.getParameter("hdIsPriceBid"))==1) : false;
        boolean isFillByBidder = StringUtils.hasLength(request.getParameter("hdIsFillByBidder")) ? (Integer.parseInt(request.getParameter("hdIsFillByBidder"))==1) : false;
        boolean isMultipleFill = StringUtils.hasLength(request.getParameter("hdIsMultipleFilling"))? (Integer.parseInt(request.getParameter("hdIsMultipleFilling"))==1) : false; 
        int bidId= StringUtils.hasLength(request.getParameter("hdBidId"))?Integer.parseInt(request.getParameter("hdBidId")):0;
        boolean success = false;
        boolean isValidBid = true;
        int cstatus = 0;
        String pageName = "redirect:/sessionexpired";
        String errMsg = CommonKeywords.ERROR_MSG_KEY.toString();
        try {
            SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());            
            if(sessionBean!=null){
                boolean isAdbClient = false;
                boolean isBidOk = (isMultipleFill || bidId!=0);
                if(!isMultipleFill && bidId==0 && eventBidSubmissionService.checkFormBided(formId, sessionBean.getCompanyId())){
                    isBidOk = true;
                }
                  if (abcUtility.getSessionClientId(request) == srilankaClient) {
                    isAdbClient=true;
                    String[] hdTableId = request.getParameterValues("hdTableId");
                    for (String tableId : hdTableId) {
                        String[] bidString = request.getParameterValues("tableBid_" + tableId);
                        
                        double rate = 0;
                        double amount = 0;
                        
                        List<Object[]> columnDataList = eventBidSubmissionService.getcolumnData(Integer.parseInt(tableId), sessionBean.getCompanyId());
                        if(columnDataList.size()==5){
                        for (int json = 0; json < bidString.length; json++) {
                            try{
                            JSONArray jsnArr = new JSONArray(bidString[json]);
                            for (int i = 0; i < jsnArr.length(); i++) {
                                JSONObject jsonObject = jsnArr.getJSONObject(i);
                                Iterator<?> keys = jsonObject.keys();
                                while (keys.hasNext()) {
                                    String key = (String) keys.next();
                                    if (key.equals(columnDataList.get(1)[2] + "_" +columnDataList.get(1)[3] )) {
                                        rate =Double.parseDouble(jsonObject.get(key).toString());
                                    }
                                    if (key.equals(columnDataList.get(2)[2] + "_" + columnDataList.get(2)[3])) {
                                        amount = Double.parseDouble(jsonObject.get(key).toString());
                                    }
                                }
                            }
                            }catch(Exception ex){
                            }
                        }
                          if (!(rate >= Double.parseDouble(columnDataList.get(0)[1].toString()))) {
                              isBidOk = false;
                              redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_bid_rate_greater");
                              pageName = "redirect:/etender/bidder/bidform/" + tenderId + "/" + envelopeId + "/" + formId + "/" + bidId + encryptDecryptUtils.generateRedirect("etender/bidder/bidform/" + tenderId + "/" + envelopeId + "/" + formId + "/" + bidId, request);
                          } else if (!(amount >= Double.parseDouble(columnDataList.get(3)[1].toString()))) {
                              isBidOk = false;
                              redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_bid_amount_min");
                              pageName = "redirect:/etender/bidder/bidform/" + tenderId + "/" + envelopeId + "/" + formId + "/" + bidId + encryptDecryptUtils.generateRedirect("etender/bidder/bidform/" + tenderId + "/" + envelopeId + "/" + formId + "/" + bidId, request);
                          } else if (!(amount <= Double.parseDouble(columnDataList.get(4)[1].toString()))) {
                              isBidOk = false;
                              redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_bid_amount_max");
                              pageName = "redirect:/etender/bidder/bidform/" + tenderId + "/" + envelopeId + "/" + formId + "/" + bidId + encryptDecryptUtils.generateRedirect("etender/bidder/bidform/" + tenderId + "/" + envelopeId + "/" + formId + "/" + bidId, request);
                          } else if (!(amount % 100000 == 0)) {
                              isBidOk = false;
                              redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_multiple_amount");
                              pageName = "redirect:/etender/bidder/bidform/" + tenderId + "/" + envelopeId + "/" + formId + "/" + bidId + encryptDecryptUtils.generateRedirect("etender/bidder/bidform/" + tenderId + "/" + envelopeId + "/" + formId + "/" + bidId, request);
                          } else {
                              isBidOk = true;
                          }
                      }else{
                            isBidOk = false;
                            //Contact Support Executive "Form format"
                            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_form_format");
                            pageName = "redirect:/etender/bidder/bidform/" + tenderId + "/" + envelopeId + "/" + formId + "/" + bidId + encryptDecryptUtils.generateRedirect("etender/bidder/bidform/" + tenderId + "/" + envelopeId + "/" + formId + "/" + bidId, request);                            
                        }
                  }

                }
                if(isBidOk){
                    List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "submissionEndDate,isEMDByBidder,isProcessingFeeByBidder,isDocumentFeeByBidder,isParticipationFeesBy,isItemwiseRegretAllowed");
                    if(((Date)tenderFields.get(0)[0]).after(commonService.getServerDateTime())){
                        if(eventBidSubmissionService.checkFinalSubmitDone(sessionBean.getCompanyId(), tenderId)){
                            //PaymentTable 1 for Docfees, 2 for EMD, 4 for Processing Fee
                            boolean isDocumentFeeByBidder = (((Integer)tenderFields.get(0)[3]==1) || ((Integer)tenderFields.get(0)[3]==2)) ? true : false;
                            boolean isEMDByBidder = (((Integer)tenderFields.get(0)[1]==1) || ((Integer)tenderFields.get(0)[1]==2)) ? true : false;
                            boolean isProcessingFeeByBidder = (Integer)tenderFields.get(0)[2]==1;
                            boolean isParticipationFeesBy =  (Integer)tenderFields.get(0)[3]==1;
                            int isItemwiseRegretAllowed = (Integer)tenderFields.get(0)[5];
                            List<Integer> paymentFor = new ArrayList<Integer>();
                            List<Integer> rowId = new ArrayList<Integer>();
                            if(isDocumentFeeByBidder){paymentFor.add(1);}
                            if(isEMDByBidder){paymentFor.add(2);}
                            if(isProcessingFeeByBidder){paymentFor.add(4);}
                             if((!isDocumentFeeByBidder && !isEMDByBidder && !isProcessingFeeByBidder && !isParticipationFeesBy) || ((isDocumentFeeByBidder || isEMDByBidder || isProcessingFeeByBidder || isParticipationFeesBy) 
                                    && isPriceBid==false?true:isFillByBidder==false?true:true)){
                            	
                            String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();

                            TblTenderBid tblTenderBid = null;
                            cstatus = StringUtils.hasLength(request.getParameter("hdFormActionS")) ? Integer.parseInt(request.getParameter("hdFormActionS")) : StringUtils.hasLength(request.getParameter("hdFormActionD")) ? Integer.parseInt(request.getParameter("hdFormActionD")) : 0;
                            if(bidId==0){
                                tblTenderBid = new TblTenderBid();                
                                tblTenderBid.setBidPrice(BigDecimal.ZERO);
                                tblTenderBid.setCreatedBy(sessionBean.getUserDetailId());
                                tblTenderBid.setIpAddress(ipAddress);
                                tblTenderBid.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
                                tblTenderBid.setTblTender(new TblTender(tenderId));
                                tblTenderBid.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
                                tblTenderBid.setTblTenderForm(new TblTenderForm(formId));
                                tblTenderBid.setTblUserDetail(new TblUserDetail(sessionBean.getUserDetailId()));
                                tblTenderBid.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
                                tblTenderBid.setCstatus(cstatus);
                            }  

                            List<TblTenderBidMatrix> tblTenderBidMatrixs = new ArrayList<TblTenderBidMatrix>();
                            List<TblRebateDetail> tblRebateDetails = new ArrayList<TblRebateDetail>();
                            List<TblEventFees> tenderFeeses = new ArrayList<TblEventFees>();
                            List<TblBidDetail> bidDetails = new ArrayList<TblBidDetail>();
                            String[] hdTableIds = request.getParameterValues("hdTableId");
                            String[] txtTableRow = StringUtils.hasLength(request.getParameter("abcdTableRow")) ? request.getParameter("abcdTableRow").split(",") : null;
                            List<TblItemSelection> selections = new ArrayList<TblItemSelection>();
                            List<Object[]> activateItems = new ArrayList<Object[]>();
                            boolean iscgClient = StringUtils.hasLength(request.getParameter("hdIscgClient"))? (Integer.parseInt(request.getParameter("hdIscgClient"))==1) : false;
                            //boolean iscgClient = CommonUtility.isClientConditionExistInProperty(cgClient,abcUtility.getSessionClientId(request));
                            if(iscgClient){
	                            if(isPriceBid){
		                            List<Object[]> itemselected = tenderFormService.getBidderItems(tenderId,sessionBean.getUserId(),formId,true);
		                            if(itemselected != null && !itemselected.isEmpty())
		                       	 	{
		                       		 //modelMap.addAttribute("bidderItemId",1);
			                       		 for(Object[] obj : itemselected)
			                       		 {
			                       			TblItemSelection itemSelection = new TblItemSelection();
			                                itemSelection.setCreatedBy(sessionBean.getUserId());
			                                itemSelection.setIsBidded(1);
			                                itemSelection.setIsSelected(1);
			                                itemSelection.setTblTenderTable(new TblTenderTable(Integer.parseInt(obj[1].toString())));
			                                itemSelection.setRowId(Integer.parseInt(obj[2].toString()));
			                                itemSelection.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
			                                itemSelection.setTblTender(new TblTender(tenderId));
			                                itemSelection.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
			                                itemSelection.setTblTenderForm(new TblTenderForm(formId));
			                                itemSelection.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
			                                itemSelection.setBidderItemId(Integer.parseInt(obj[7].toString()));
			                                selections.add(itemSelection);
			                                rowId.add(Integer.parseInt(obj[2].toString()));
			                       		}
		                       	 	}
	                            }else{
	                            	if(txtTableRow!=null){
	    	                            for (String tableIdRow : txtTableRow) {
	    	                                String[] tableIdRowId = tableIdRow.split("_");
	    	//                                if(isItemSelectionPageRequired==0){
	    	                                	
	    		                                    TblItemSelection itemSelection = new TblItemSelection();
	    		                                    itemSelection.setCreatedBy(sessionBean.getUserDetailId());
	    		                                    itemSelection.setIsBidded(1);
	    		                                    itemSelection.setIsSelected((isItemSelectionPageRequired==1 && isPriceBid) ? -1 : 1);
	    		                                    itemSelection.setTblTenderTable(new TblTenderTable(Integer.parseInt(tableIdRowId[0])));
	    		                                    itemSelection.setRowId(Integer.parseInt(tableIdRowId[1])+1);
	    		                                    itemSelection.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
	    		                                    itemSelection.setTblTender(new TblTender(tenderId));
	    		                                    itemSelection.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
	    		                                    itemSelection.setTblTenderForm(new TblTenderForm(formId));
	    		                                    itemSelection.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
	    		                                    selections.add(itemSelection);
	    		                                    rowId.add(Integer.parseInt(tableIdRowId[1])+1);
	    	                                	
	    	                                    if(isPriceBid && (isItemwiseRegretAllowed==1 || isItemwiseRegretAllowed==3)&& activateItems!=null){
	    		                                    for (Object[] rows : activateItems) {
	    		                                        if((Integer)rows[1] == Integer.parseInt(tableIdRowId[0]) && Integer.parseInt(rows[2].toString()) == Integer.parseInt(tableIdRowId[1])+1){
	    		                                        	isValidBid = false;
	    		                                        	errMsg = "msg_item_already_regreted";
	    		                                        }
	    		                                    }
	    	                                    }
	    	//                                }
	    	                            }
	                                }
	                            }
                            }
                            activateItems = eventBidSubmissionService.getRegretActivateItem(tenderId,formId,1,sessionBean.getCompanyId());
                            if(txtTableRow!=null){
	                            for (String tableIdRow : txtTableRow) {
	                                String[] tableIdRowId = tableIdRow.split("_");
	//                                if(isItemSelectionPageRequired==0){
	                                	if(!iscgClient){
		                                    TblItemSelection itemSelection = new TblItemSelection();
		                                    itemSelection.setCreatedBy(sessionBean.getUserDetailId());
		                                    itemSelection.setIsBidded(1);
		                                    itemSelection.setIsSelected((isItemSelectionPageRequired==1 && isPriceBid) ? -1 : 1);
		                                    itemSelection.setTblTenderTable(new TblTenderTable(Integer.parseInt(tableIdRowId[0])));
		                                    itemSelection.setRowId(Integer.parseInt(tableIdRowId[1])+1);
		                                    itemSelection.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
		                                    itemSelection.setTblTender(new TblTender(tenderId));
		                                    itemSelection.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
		                                    itemSelection.setTblTenderForm(new TblTenderForm(formId));
		                                    itemSelection.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
		                                    selections.add(itemSelection);
		                                    rowId.add(Integer.parseInt(tableIdRowId[1])+1);
	                                	}
	                                    if(isPriceBid && (isItemwiseRegretAllowed==1 || isItemwiseRegretAllowed==3)&& activateItems!=null){
		                                    for (Object[] rows : activateItems) {
		                                        if((Integer)rows[1] == Integer.parseInt(tableIdRowId[0]) && Integer.parseInt(rows[2].toString()) == Integer.parseInt(tableIdRowId[1])+1){
		                                        	isValidBid = false;
		                                        	errMsg = "msg_item_already_regreted";
		                                        }
		                                    }
	                                    }
	//                                }
	                            }
                            }
                            for (String tableId : hdTableIds) {
                                String[] bidString = request.getParameterValues("tableBid_"+tableId);
                                String[] encString = request.getParameterValues("tableEnc_"+tableId);
                                String rebateCell = request.getParameter("skpRebateCell_"+tableId);
                                String[] processCell = request.getParameterValues("skpProcessCell_"+tableId);
                                String[] docCell = request.getParameterValues("skpDocCell_"+tableId);
                                String[] docCellOfficer = request.getParameterValues("skpDocCellOfficer_"+tableId);
                                String[] emdCellOfficer = request.getParameterValues("skpEmdCellOfficer_"+tableId);
                                String[] participationCellOfficer = request.getParameterValues("skpParticipationCellOfficer_"+tableId);
                                String[] emdCell = request.getParameterValues("skpEmdCell_"+tableId);
                                String[] notEncrCell = request.getParameterValues("skpNotEncrCell_"+tableId);
                                for (int i = 0; i < bidString.length; i++) {
                                    if(StringUtils.hasLength(bidString[i]) && !bidString[i].equals("false") && StringUtils.hasLength(encString[i]) && !encString[i].equals("false")){
                                        TblTenderBidMatrix tblTenderBidMatrix = new TblTenderBidMatrix();
                                        tblTenderBidMatrix.setBidJson(bidString[i]);
                                        tblTenderBidMatrix.setEncryptedBid(encString[i]);
                                        tblTenderBidMatrix.setTblTenderBid(tblTenderBid==null ? new TblTenderBid(bidId,cstatus,ipAddress) : tblTenderBid);
                                        tblTenderBidMatrix.setTblTenderTable(new TblTenderTable(Integer.parseInt(tableId)));
                                        tblTenderBidMatrixs.add(tblTenderBidMatrix);
                                    }else{
                                        isValidBid = false;
                                    }
                                }
                                if(StringUtils.hasLength(rebateCell)){
                                    TblRebateDetail rebateDetail = new TblRebateDetail();
                                    String[] rebateVal = rebateCell.split("@@@");
                                    rebateDetail.setCellValue(rebateVal[1]);
                                    rebateDetail.setTblTenderCell(new TblTenderCell(Integer.parseInt(encryptDecryptUtils.decrypt(rebateVal[0]))));
                                    rebateDetail.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
                                    rebateDetail.setTblTender(new TblTender(tenderId));
                                    rebateDetail.setCreatedBy(sessionBean.getUserDetailId());
                                    rebateDetail.setTblTenderBidMatrix(tblTenderBidMatrixs.get(tblTenderBidMatrixs.size()-1));
                                    tblRebateDetails.add(rebateDetail);
                                }
                                if(processCell!=null){
                                	String uniqueId = tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8);
                                	List <Integer> eventfeeaddList= new ArrayList<Integer>();
                                	int i =0;
                                	for (String string : processCell) {
	                            		String[] processVal = string.split("@@@");
	                            		if(processVal.length > 1){
	                            			TblEventFees tenderFees = new TblEventFees();                                                                       
		                                    tenderFees.setFeeType(1);
		                                    tenderFees.setEventFee(processVal[1]);
		                                    tenderFees.setExemptionAmt(new BigDecimal(processVal[1]));
		                                    tenderFees.setBidId(bidId);
		                                    tenderFees.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
		                                    tenderFees.setObjectId(tenderId);
		                                    tenderFees.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
		                                    tenderFees.setUniqueId(uniqueId);
		                                    tenderFees.setRowId(rowId.get(i));
		                                    tenderFees.setTableId(Integer.parseInt(tableId));
		                                    tenderFees.setFormId(formId);
		                                    tenderFees.setModuleId(3);
		                                    tenderFees.setIsActive(1);
		                                    eventfeeaddList.add(tenderFees.getEventFeeId());
		                                    tenderFeeses.add(tenderFees);
	                            		}
	                                }
                                }
                                if(emdCell!=null){
                                	int i =0;
                               	 	String uniqueId = tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8);
	                            	for (String string : emdCell) {
	                            		TblEventFees tenderFees = new TblEventFees();
	                                    String[] emdVal = string.split("@@@");
	                                	if(emdVal.length > 1){
	                                		List <TblEventFees> lstTenderFees= tenderFormService.getTenderFeesPaymentDetail(tenderId,sessionBean.getCompanyId(),formId, Integer.parseInt(tableId),rowId.get(i), bidId,3);
	                                		List<Object[]> paymentPending = new ArrayList<Object[]>();
	                            			paymentPending = tenderFormService.getPaymentPending(tenderId, sessionBean.getCompanyId(), formId, Integer.parseInt(tableId),rowId.get(i),bidId,3);
	                                		if(lstTenderFees.isEmpty()  ){
	                                			if(paymentPending!=null && !paymentPending.isEmpty()){
			                                        	eventBidSubmissionService.deletetenderFeesBid(bidId,3);
			                                    }
			                                    tenderFees.setFeeType(3);
			                                    tenderFees.setEventFee(emdVal[1]);
			                                    tenderFees.setExemptionAmt(new BigDecimal(emdVal[1]));
			                                    tenderFees.setBidId(bidId);
			                                    tenderFees.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
			                                    tenderFees.setObjectId(tenderId);
			                                    tenderFees.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
			                                    tenderFees.setRowId(rowId.get(i));
			                                    tenderFees.setTableId(Integer.parseInt(tableId));
			                                    tenderFees.setFormId(formId);
			                                    tenderFees.setCstatus(0);
			                                    tenderFees.setModuleId(3);
			                                    tenderFees.setIsActive(1);		                                    
			                                    tenderFees.setUniqueId(uniqueId);
			                                    tenderFeeses.add(tenderFees);
		                                		}
		                                    i++;
	                                	}
	                            		
	                                }
                                }
                                if(emdCellOfficer!=null){
                                	String uniqueId = tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8);
                                	for (String string:emdCellOfficer) {
	                            		String[] emdVal = string.split("@@@");
	                            		if(bidString.length > 0 && rowId.contains(Integer.parseInt(emdVal[2])+1)){
	                            			List <TblEventFees> lstTenderFees= tenderFormService.getTenderFeesPaymentDetail(tenderId,sessionBean.getCompanyId(),formId, Integer.parseInt(tableId),Integer.parseInt(emdVal[2])+1, 0,3);
	                            			List<Object[]> paymentPending = new ArrayList<Object[]>();
	                            			paymentPending = tenderFormService.getPaymentPending(tenderId, sessionBean.getCompanyId(), formId, Integer.parseInt(tableId),Integer.parseInt(emdVal[2])+1,bidId,3);
	                                		if(lstTenderFees.isEmpty()  ){
		                                			if(paymentPending!=null && !paymentPending.isEmpty()){
 			                                        	eventBidSubmissionService.deletetenderFeesBid(bidId,3);
 			                                        }
		                            			TblEventFees tenderFees = new TblEventFees();
			                                    tenderFees.setFeeType(3);
			                                    tenderFees.setEventFee(emdVal[1]);
			                                    tenderFees.setExemptionAmt(new BigDecimal(emdVal[1]));
//			                                    tenderFees.setTblTenderBid(tblTenderBid==null ? new TblTenderBid(bidId,cstatus,ipAddress) : tblTenderBid);
			                                    tenderFees.setBidId(bidId);
			                                    tenderFees.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
			                                    tenderFees.setObjectId(tenderId);
			                                    tenderFees.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
			                                    tenderFees.setRowId(Integer.parseInt(emdVal[2])+1);
			                                    tenderFees.setTableId(Integer.parseInt(tableId));
			                                    tenderFees.setFormId(formId);
			                                    tenderFees.setCstatus(0);
			                                    tenderFees.setModuleId(3);
			                                    tenderFees.setIsActive(1);		                                    
			                                    tenderFees.setUniqueId(uniqueId);
			                                    tenderFeeses.add(tenderFees);
	                                		}else{
	                                			TblEventFees tenderFees = lstTenderFees.get(0);
	                                			if(bidId!=0 && tenderFees.getBidId()!=bidId ){
	                                				 tenderFees.setBidId(bidId);
	                                			}
			                                    tenderFees.setCstatus(lstTenderFees.get(0).getCstatus());
			                                    tenderFeeses.add(tenderFees);
	                                		}
	                            		}
	                                }
                                }
                                if(participationCellOfficer!=null){
                                	String uniqueId = tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8);
                                	 for (String string:participationCellOfficer) {
 	                            		String[] participationVal = string.split("@@@");
 	                            		if(bidString.length > 0 && rowId.contains(Integer.parseInt(participationVal[2])+1)){
 		                            		List <TblEventFees> lstTenderFees= tenderFormService.getTenderFeesPaymentDetail(tenderId,sessionBean.getCompanyId(),formId, Integer.parseInt(tableId),Integer.parseInt(participationVal[2])+1, 0,8); // participation fees
 		                            		List<Object[]> paymentPending = new ArrayList<Object[]>();
	                            			paymentPending = tenderFormService.getPaymentPending(tenderId, sessionBean.getCompanyId(), formId, Integer.parseInt(tableId),Integer.parseInt(participationVal[2])+1,bidId,8);
 		                                		if(lstTenderFees.isEmpty()  ){
 		                                			if(paymentPending!=null && !paymentPending.isEmpty()){
 			                                        	eventBidSubmissionService.deletetenderFeesBid(bidId,8);
 			                                        }
			                            			TblEventFees tenderFees = new TblEventFees();
				                                    tenderFees.setFeeType(8); // For Participation Fees  
				                                    tenderFees.setEventFee(participationVal[1]);
				                                    tenderFees.setExemptionAmt(new BigDecimal(participationVal[1]));
				                                    tenderFees.setBidId(bidId);
				                                    tenderFees.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
				                                    tenderFees.setObjectId(tenderId);
				                                    tenderFees.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
				                                    tenderFees.setRowId(Integer.parseInt(participationVal[2])+1);
				                                    tenderFees.setTableId(Integer.parseInt(tableId));
				                                    tenderFees.setFormId(formId);
				                                    tenderFees.setCstatus(0);
				                                    tenderFees.setModuleId(3);
				                                    tenderFees.setIsActive(1);		                                    
				                                    tenderFees.setUniqueId(uniqueId);
				                                    tenderFeeses.add(tenderFees);
 		                                		}else{
 		                                			TblEventFees tenderFees = lstTenderFees.get(0);
 		                                			if(bidId!=0 && tenderFees.getBidId()!=bidId ){
 		                                				 tenderFees.setBidId(bidId);
 		                                			}
 				                                    tenderFees.setCstatus(lstTenderFees.get(0).getCstatus());
 				                                    tenderFeeses.add(tenderFees);
 		                                		}
 	                            		}
	                            	 }
                                }
                                if(docCellOfficer!=null){
                                	String uniqueId = tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8);
                                	for (String string:docCellOfficer) {
	                            		String[] docVal = string.split("@@@");
	                            		if(bidString.length > 0 && rowId.contains(Integer.parseInt(docVal[2])+1)){
	                            			List <TblEventFees> lstTenderFees= tenderFormService.getTenderFeesPaymentDetail(tenderId,sessionBean.getCompanyId(),formId, Integer.parseInt(tableId),Integer.parseInt(docVal[2])+1, 0,2);
	                            			List<Object[]> paymentPending = new ArrayList<Object[]>();
	                            			paymentPending = tenderFormService.getPaymentPending(tenderId, sessionBean.getCompanyId(), formId, Integer.parseInt(tableId),Integer.parseInt(docVal[2])+1,bidId,2);
	                            			if(lstTenderFees.isEmpty()){
	                            				if(paymentPending!=null && !paymentPending.isEmpty()){
			                            					eventBidSubmissionService.deletetenderFeesBid(bidId,2);
			                            				}	
	                            			TblEventFees tenderFees = new TblEventFees();
		                                    tenderFees.setFeeType(2);
		                                    tenderFees.setEventFee(docVal[1]);
		                                    tenderFees.setExemptionAmt(new BigDecimal(docVal[1]));
		                                    tenderFees.setBidId(bidId);
		                                    tenderFees.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
		                                    tenderFees.setObjectId(tenderId);
		                                    tenderFees.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
		                                    tenderFees.setRowId(Integer.parseInt(docVal[2])+1);
		                                    tenderFees.setTableId(Integer.parseInt(tableId));
		                                    tenderFees.setFormId(formId);
		                                    tenderFees.setCstatus(0);
		                                    tenderFees.setModuleId(3);
		                                    tenderFees.setIsActive(1);		                                    
		                                    tenderFees.setUniqueId(uniqueId);
		                                    tenderFeeses.add(tenderFees);
	                            		}else{
	                                			TblEventFees tenderFees = lstTenderFees.get(0);
	                                			if(bidId!=0 && tenderFees.getBidId()!=bidId ){
	                                				 tenderFees.setBidId(bidId);
	                                			}
			                                    tenderFees.setCstatus(lstTenderFees.get(0).getCstatus());
			                                    tenderFeeses.add(tenderFees);
	                                		}
	                            		}
	                            	}
                                }
                                if(docCell!=null){
                                	int i = 0;
                                	String uniqueId = tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8);
	                            	for (String string : docCell) {
	                            		String[] docVal = string.split("@@@");
	                            		if(docVal.length > 1){
	                            			List <TblEventFees> lstTenderFees= tenderFormService.getTenderFeesPaymentDetail(tenderId,sessionBean.getCompanyId(),formId, Integer.parseInt(tableId),rowId.get(i), bidId,2);
	                            			List<Object[]> paymentPending = new ArrayList<Object[]>();
	                            			paymentPending = tenderFormService.getPaymentPending(tenderId, sessionBean.getCompanyId(), formId, Integer.parseInt(tableId),rowId.get(i),bidId,2);
	                            			if(lstTenderFees.isEmpty()){
	                            				if(paymentPending!=null && !paymentPending.isEmpty()){
	                            					eventBidSubmissionService.deletetenderFeesBid(bidId,2);
	                            				}
	                            				TblEventFees tenderFees = new TblEventFees();
			                                    tenderFees.setFeeType(2);
			                                    tenderFees.setEventFee(docVal[1]);
			                                    tenderFees.setExemptionAmt(new BigDecimal(docVal[1]));
			                                    tenderFees.setBidId(bidId);
			                                    tenderFees.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
			                                    tenderFees.setObjectId(tenderId);
			                                    tenderFees.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
			                                    tenderFees.setRowId(rowId.get(i));
			                                    tenderFees.setTableId(Integer.parseInt(tableId));
			                                    tenderFees.setFormId(formId);
			                                    tenderFees.setCstatus(0);
			                                    tenderFees.setModuleId(3);
			                                    tenderFees.setUniqueId(uniqueId);
			                                    tenderFees.setIsActive(1);
			                                    tenderFeeses.add(tenderFees);
	                            			}
		                                    i++;
	                            			}
	                                	}
                                	}
                                if(notEncrCell!=null && notEncrCell.length!=0){
                                    for (String notEncr : notEncrCell) {
                                        String[] processVal = notEncr.split("@@@");
                                        if(processVal != null && processVal.length > 1){
                                            TblBidDetail tblbidDetail = new TblBidDetail();
                                            tblbidDetail.setCellId(Integer.parseInt(encryptDecryptUtils.decrypt(processVal[0])));
                                            tblbidDetail.setCellValue(processVal[1]);
                                            tblbidDetail.setCompanyId(sessionBean.getCompanyId());
                                            tblbidDetail.setFormId(formId);
                                            bidDetails.add(tblbidDetail);
                                        }
                                    }
                                }

                            }                            
                            success = isValidBid ? eventBidSubmissionService.addBidderBid(tblTenderBid, tblTenderBidMatrixs,tblRebateDetails,tenderFeeses,bidDetails,selections,iscgClient,isPriceBid) : false;
                            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? (cstatus==1 ? "redirect_success_bid_drafted" : "redirect_success_bid_submission") : errMsg);
                            pageName = REDIRECTBIDDERDASHBOARD+tenderId+"/5"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/5", request);
                        }else{
                            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_bidform_editafterpay");
                            pageName = "redirect:/etender/bidder/bidform/"+tenderId+"/"+envelopeId+"/"+formId+"/"+bidId+encryptDecryptUtils.generateRedirect("etender/bidder/bidform/"+tenderId+"/"+envelopeId+"/"+formId+"/"+bidId,request);
                        }
                        }else{
                            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_bid_submission_done");
                            pageName = "redirect:/etender/bidder/bidform/"+tenderId+"/"+envelopeId+"/"+formId+"/"+bidId+encryptDecryptUtils.generateRedirect("etender/bidder/bidform/"+tenderId+"/"+envelopeId+"/"+formId+"/"+bidId,request);
                        }
                    }else{
                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_bid_submission");
                        pageName = "redirect:/etender/bidder/bidform/"+tenderId+"/"+envelopeId+"/"+formId+"/"+bidId+encryptDecryptUtils.generateRedirect("etender/bidder/bidform/"+tenderId+"/"+envelopeId+"/"+formId+"/"+bidId,request);
                    }
                }else{
                       if(!isAdbClient){
                            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_bid_submission_duplicate");
                            pageName = "redirect:/etender/bidder/bidform/"+tenderId+"/"+envelopeId+"/"+formId+"/"+bidId+encryptDecryptUtils.generateRedirect("etender/bidder/bidform/"+tenderId+"/"+envelopeId+"/"+formId+"/"+bidId,request);
                       }
                }
            }
        } catch (Exception e) {
            pageName = exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidId==0 ? bidFormCreate : bidFormEdit, bidId==0 ? addBidFormAudit : addBidFormEditAudit, tenderId, bidId);
        }        
        return pageName;
    }
   
    /**
     * @author VIPULP
     * @param request
     * @param modelMap
     * @param redirectAttributes
     * @return to view
     */
    @RequestMapping(value = "/bidder/finalsubmission", method = RequestMethod.POST)
    public String finalSubmission(HttpServletRequest request, ModelMap modelMap, RedirectAttributes redirectAttributes) {
        int tenderId = 0;
        String pageView = "redirect:/loginfailed";
        String eventType = "";
        String errorStr= "";
        boolean isFinalSubmissionDone = false;
        int conostiumId=0;
        SessionBean sBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
        try {
        	/* boolean isLeadPartnerRegret=false;
        	 isLeadPartnerRegret=eventBidSubmissionService.isLeadPartnerRegret(tenderId,2);*/
        	/*if(isLeadPartnerRegret){
        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"lead_already_regrett_bidder");
        	}
        	else{*/
        	if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
                String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();
                int userId = sBean.getUserId();
                int companyId = sBean.getCompanyId();
                int userDetailId = sBean.getUserDetailId();
                int certiType = 1;
               
                int[] bidderStatus = loginService.getBidderStatus(userId, abcUtility.getSessionClientId(request));
              /*  Bug #34657 Event Form DocsMandatory Server side validation 
               *  Bug #34897 is also related with form Mandatory  so remove DocsMandatory condition*/
                boolean serverSideValid = true;
                TblTender  tblTender = tenderCommonService.getTenderById(tenderId);
                errorStr= biddingTenderDashboardController.validateBidderEventDashboard(tenderId, tblTender.getIsConsortiumAllowed(), 6, request);
                serverSideValid=errorStr.equals("noerr") ? true : false;
                
               if(serverSideValid){
             /* Bug #34657 Event Form DocsMandatory Server side validation*/
            	boolean isBlacklist = loginService.checkDateofBidderForBlacklist(bidderStatus[0]);
                if(bidderStatus != null && (bidderStatus[1] == 1 || (bidderStatus[1] ==3 && !isBlacklist))){
                if(eventBidSubmissionService.isTenderIdRepeated(tenderId, userId)){
                	if(bidderStatus[2] == userId && bidderStatus[1] ==3) {
                		redirectAttributes.addFlashAttribute("errorMsg", "reason_for_blacklist");
                		isFinalSubmissionDone = true;
                	}
                    if(eventBidSubmissionService.isFinalSubmissionDone(tenderId,companyId)){
                        redirectAttributes.addFlashAttribute("errorMsg", "msg_final_submission_already_completed");
                        isFinalSubmissionDone = true;
                    }
	                if(abcUtility.getSessionIsDualCerti(request)){
	                	certiType = 2;
	                }
	                eventType = StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
	                
	                List<Object[]> lstTenderFields = tenderCommonService.getTenderFields(tenderId, "tenderNo,isConsortiumAllowed,isCertRequired,envelopeType,tenderBrief,isRebateForm");
	                
	                String finalSubmissionMsg = !isFinalSubmissionDone ? tenderCommonService.allowFinalSubmission(ipAddress, tenderId, companyId, userId, userDetailId, FINALSUBMISSION_REQUEST_TYPE_POST, (Integer) lstTenderFields.get(0)[2], (Integer) lstTenderFields.get(0)[3], (Integer) lstTenderFields.get(0)[5], certiType) : "";
	                if (finalSubmissionMsg.contains("msg_tender_fs_finalsubmission_done")) {
	                    Map mailParams = new HashMap();
	                    
	                    modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg.split("@")[0]);
	                    modelMap.addAttribute("msgArgumentOne", finalSubmissionMsg.split("@")[1]);
	                    modelMap.addAttribute("msgArgumentTwo", CommonUtility.convertTimezone(finalSubmissionMsg.split("@")[2]));
	                    
	                    if(!lstTenderFields.isEmpty()){                    	
	                        mailParams.put("tenderId",tenderId);
	                        mailParams.put("tenderNo",lstTenderFields.get(0)[0]);
	                        //Added By Lipi - Start
	                        mailParams.put("brief",lstTenderFields.get(0)[4]);
	                        mailParams.put("eventType", eventType);
	                        mailParams.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
	                        String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/biddingtenderdashboard/" + tenderId + "/" + 6);
	                    	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
	                    	mailParams.put("link", herfStr);
	                    	//End
	                        int isConsortiumAllowed = (Integer) lstTenderFields.get(0)[1];
	                        if(isConsortiumAllowed == 1){
	                            boolean isLeadPartner = (tenderCommonService.getConsortiumPartnerType(tenderId, sBean.getCompanyId())[1]!= 3);
	                            if(isLeadPartner){
	                            	// PT #33259 By Jitendra. Mail Template change for IDFC domain only.
	                                mailContentUtillity.dynamicMailGeneration(abcUtility.getSessionClientId(request) == idfcClientID ? "261" : "56", String.valueOf(userId), "0", mailParams, "");
	                            }else{
	                                if(futureRelease){
	                                	//Final submission done by secondary partner
	                                	conostiumId=tenderCommonService.getConsortiumIdByTenderIdUserId(tenderId,userDetailId);
	                                    userId = tenderCommonService.getLeadPartnerBidderId(tenderId,conostiumId);
	                                    if(abcUtility.getSessionClientId(request) != idfcClientID){
	                                    	mailContentUtillity.dynamicMailGeneration("58", String.valueOf(userId), "0", mailParams, String.valueOf(companyId));
	                                    }
	                                }
	                            }
	                        } else{
	                        	// PT #33259 By Jitendra. Mail Template change for IDFC domain only.
	                            mailContentUtillity.dynamicMailGeneration(abcUtility.getSessionClientId(request) == idfcClientID ? "261" : "56", String.valueOf(userId), "0", mailParams, "");
	                        }
	                    }
	                    if(tblTender.getIsEDraw()==1){
	                    	String coupon = CommonUtility.generateCoupon(tenderId, userId);
	                    	modelMap.addAttribute("coupon",coupon);
	                    	
	                    	TblCouponHistory tblCouponHistory = new TblCouponHistory();
	                    	tblCouponHistory.setBidderId(userId);
	                    	tblCouponHistory.setCouponcode(coupon);
	                    	tblCouponHistory.setTenderId(tenderId);
	                    	tblCouponHistory.setPropertyId(0);
	                    	tblCouponHistoryDao.saveOrUpdateTblCouponHistory(tblCouponHistory);
	                    }

	                } else {
	                    modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg);
	                }
                }else{
                    redirectAttributes.addFlashAttribute("errorMsg", "msg_temder_err_iagree");
                }
                }else{
                	int varBidderStatus = 0;
                	if(bidderStatus != null){
                		varBidderStatus = bidderStatus[1];
                	}
                	if(varBidderStatus == 3){
                		redirectAttributes.addFlashAttribute("errorMsg", "msg_user_not_approved_blacklisted");
                	}else if(varBidderStatus == 4){
                		redirectAttributes.addFlashAttribute("errorMsg", "msg_user_not_approved_expired");
                	}else if(varBidderStatus == 7){
                		redirectAttributes.addFlashAttribute("errorMsg", "msg_user_not_approved_rejected");
                	}else{
                		redirectAttributes.addFlashAttribute("errorMsg", "msg_user_not_approved");
                	}
                }
                pageView = REDIRECTBIDDERDASHBOARD + tenderId + "/6" + encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD + tenderId + "/6", request);
              }else if(errorStr.equals("msg_event_cancel")){
            	  pageView = REDIRECTBIDDERDASHBOARD + tenderId + "/5" + encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD + tenderId + "/5", request);
              }else{
            	  redirectAttributes.addFlashAttribute("errorMsg", errorStr);
            	  pageView = REDIRECTBIDDERDASHBOARD + tenderId + "/5" + encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD + tenderId + "/5", request);
              }
            }
         }catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkFinalSubmission, postFinalSubmission, tenderId, 0);
        }
        return pageView;
    }
   
    /**
     * @param request
     */  
    @RequestMapping(value= "bidder/bidderIagree" , method = RequestMethod.POST )
    public String  bidderAgreeFormSubmit(HttpServletRequest request,RedirectAttributes redirectAttributes){
    	int tenderId=Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID));
    	String page = "";
    	page =REDIRECTBIDDERDASHBOARD+tenderId+"/2"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/2", request);
    	HttpSession session = request.getSession();
    	SessionBean sessionBean=(SessionBean)session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
		try{
			boolean isTenderBidConfirmation = eventBidSubmissionService.isTenderBidConfirmation(tenderId, sessionBean.getCompanyId());
		       	if(isTenderBidConfirmation)
		       	{
		       		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"already_agreed_bidder");
		       	}
		       	else
		       	{
			TblTenderBidConfirmation tblTenderBidConfirmation=null;
			TblTender tblTender=null;
			TblUserDetail tblUserDetail=null;
			TblUserLogin tblUserLogin=null;
			TblClientBidTerm tblClientBidTerm=null;
			TblTenderBidCurrency tblTenderBidCurrency=null;
			TblCompany tblCompany=null;
    		
    	    
    	     
    	     if(sessionBean!=null){
    	    	 List<Object[]> cellValues = tenderFormService.getProxyColumnData(tenderId);
	    	     int companyId = sessionBean.getCompanyId();	    	     
	    	     int userDetailId = sessionBean.getUserDetailId();    	    	     
	    	     // Change by krunal to get ip Address 
	    	     //String ipAdress = sessionBean.getIpAddress();
	    	     String ipAdress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();
	    	     int  clientBidtermId = Integer.parseInt(request.getParameter("hdclientBidTermId"));
	    	     int createdBy = sessionBean.getUserDetailId();
	    	     int bidderId = sessionBean.getUserId(); 
	    	     int biddingType=0;
	    	    if((StringUtils.hasLength(request.getParameter("hdBiddingType").toString()))){
	    	    	biddingType = Integer.parseInt(request.getParameter("hdBiddingType").toString());
	    	    }
	    	    
	    	    List<TblTenderProxyBid>lstTblTenderProxyBid = new ArrayList<TblTenderProxyBid>();
	        	TblTenderProxyBid tblTenderProxyBid = null;
	        	
	        	if(cellValues!=null && !cellValues.isEmpty())
	        	{
	        		for(int i=0; i<cellValues.size(); i++){
		        		tblTenderProxyBid = new TblTenderProxyBid();
		        		tblTenderProxyBid.setTblTender(new TblTender(tenderId));
		        		tblTenderProxyBid.setTblTenderTable(new TblTenderTable((Integer)cellValues.get(i)[0]));
		        		tblTenderProxyBid.setTblTenderColumn(new TblTenderColumn((Integer)cellValues.get(i)[1]));
		        		tblTenderProxyBid.setTblTenderCell(new TblTenderCell((Integer)cellValues.get(i)[2]));
		        		tblTenderProxyBid.setRowId((Short)cellValues.get(i)[3]);
		        		tblTenderProxyBid.setTblCompany(new TblCompany(companyId));
		        		tblTenderProxyBid.setCellValue("1");
		        		tblTenderProxyBid.setIpAddress(ipAdress);
		        		tblTenderProxyBid.setIsUpdatedFrom(1);
		        		tblTenderProxyBid.setCreatedBy(abcUtility.getSessionUserDetailId(request));
		        		lstTblTenderProxyBid.add(tblTenderProxyBid);
		        	}
	        	}	
	    	 	tblTenderBidConfirmation = new TblTenderBidConfirmation();
	    		tblTender = new TblTender(tenderId);	
	    		tblCompany = new TblCompany(companyId);
	    		tblUserDetail = new TblUserDetail(userDetailId);
	    		tblUserLogin = new TblUserLogin(bidderId);
	    		tblClientBidTerm = new TblClientBidTerm(clientBidtermId);	    		
	    			
	    		tblTenderBidConfirmation.setTblTender(tblTender);
	    		tblTenderBidConfirmation.setTblCompany(tblCompany);
	    		tblTenderBidConfirmation.setTblClientBidTerm(tblClientBidTerm);
	    		tblTenderBidConfirmation.setTblUserDetail(tblUserDetail);
	    		tblTenderBidConfirmation.setEncodedName(spCompanyNameEncoded.executeProcedure(tenderModuleId,tenderId));
	    		tblTenderBidConfirmation.setIpAddress(ipAdress);
	    		tblTenderBidConfirmation.setCreatedBy(createdBy);
	    		tblTenderBidConfirmation.setTblUserLogin(tblUserLogin);
	    		
	    		int currencyId = 0;
	    		if(biddingType==2){
		    		if(StringUtils.hasLength(request.getParameter("selBidCurrencyId").toString())){
		    			currencyId = Integer.parseInt(request.getParameter("selBidCurrencyId").toString());
		    		}
	    			tblTenderBidCurrency = new TblTenderBidCurrency();	
	    			tblTenderBidCurrency.setTblCompany(tblCompany);
	    			tblTenderBidCurrency.setTblTenderCurrency(new TblTenderCurrency(currencyId));
	    			tblTenderBidCurrency.setTblUserLogin(tblUserLogin);
	    			eventBidSubmissionService.addTenderBidCurrency(tblTenderBidCurrency);
	    		}
	    		boolean isRepeated = eventBidSubmissionService.isTenderIdRepeated(tenderId,bidderId);
	    		if (!isRepeated) {
	    			eventBidSubmissionService.addTenderBidConfm(tblTenderBidConfirmation,lstTblTenderProxyBid);
				}
	    		boolean isBidderRegretted = eventBidSubmissionService.isBidderRegretted(bidderId,tenderId);
	    		if(isBidderRegretted){
	    			eventBidSubmissionService.deleteBidRegressionEntry(bidderId,tenderId);
	    		}
	    		int isAllowded = (Integer) (StringUtils.hasLength(request.getParameter("hdisConsortiumAllowed")) ? Integer.parseInt(request.getParameter("hdisConsortiumAllowed")): 0);
	    		tblTender = tenderCommonService.getTenderById(tenderId);
	    		if (isAllowded == 0) {
	    			if(tblTender.getIsDocfeesApplicable() == 1  || tblTender.getIsEMDApplicable()==1 || tblTender.getIsEMDApplicable()==3){
	    					    			
		    			if(tblTender.getIsDocfeesApplicable() == 1){
	                        page =REDIRECTBIDDERDASHBOARD+tenderId+"/3"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/3", request);
	                    }else if((tblTender.getIsEMDApplicable()==1) || (tblTender.getIsEMDApplicable()==3)){
	                        page =REDIRECTBIDDERDASHBOARD+tenderId+"/4"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/4", request);
		    			}
		    		}else{
                        
                    }
				}else {
					page =REDIRECTBIDDERDASHBOARD+tenderId+"/11"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/11", request);
				}
	    		
	    		// PT #33259 By Jitendra.Mail Send functionality on tender bid confirmation for IDFC Domain Only.
	    		Map<String, Object>mailParams = new HashMap<String, Object>();
    			mailParams.put("tenderId", tenderId);
                mailParams.put("tenderNo", tblTender.getTenderNo());
                mailParams.put("brief", AbcUtility.reverseReplaceSpecialChars(tblTender.getTenderBrief())); 
                mailParams.put("eventType", tenderCommonService.getEventTypeByTenderId(tenderId));
                mailParams.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
                // Bug #33343 By Jitendra. Add CC Email ID if tender mode is limited.
                if(tblTender.getTenderMode() == 2){
                	mailParams.put("cc", "idfc@procuretiger.com");
                }
                mailContentUtillity.dynamicMailGeneration("260", String.valueOf(bidderId), "0", mailParams, "");
    	    }
    	}
		}
    	catch (Exception e) {
    		exceptionHandlerService.writeLog(e);
		}
    	finally{
    		 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidderiAgreeLinkId, "I agrree Form Submited", tenderId, 0);
    	}
			//page =REDIRECTBIDDERDASHBOARD+tenderId+"/3"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/3", request);
    		return page;
	}
    
    /** 
     *author : Dhananjay Dubey
     *
     *Regret button  
     */
    @RequestMapping(value= "bidder/tenderBidRegret/{tenderId}/{enc}" , method = RequestMethod.GET )
    public String getTenderBidRegret(@PathVariable("tenderId") Integer tenderId, ModelMap modelMap,HttpServletRequest request){
    	String page = "redirect:/sessionexpired";
		try{
			HttpSession session = request.getSession();
   	     	SessionBean sessionBean=(SessionBean)session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
   	     	if(sessionBean!=null && tenderId!=0 ){
   	     		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
   	     		modelMap.put("tenderId", tenderId);
   	        	page = "/etender/bidder/TenderBidRegret";
   	     	}
		}
    	catch (Exception e) {
    		exceptionHandlerService.writeLog(e);
		}
    	finally{
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, regrettedPageAccessed, tenderId, 0);
    	}
        return page;
    }
    /** 
     *author : Dhananjay Dubey
     *
     *Regret button  
     */
    @RequestMapping(value= "bidder/submitTenderBidReject" , method = RequestMethod.POST )
    public String  submitTenderBidRegret(HttpServletRequest request, RedirectAttributes redirectAttributes){
    	int tenderId=Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID));
    	String page="";
    	HttpSession session = request.getSession();
    	SessionBean sessionBean=(SessionBean)session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
    	int bidderId = sessionBean.getUserId(); 
    	page = "redirect:/sessionexpired";
		try{
			int errCode = tenderCommonService.isEventLive(tenderId);
			if(errCode!=1){
				redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_tender_err_msg_bidregret");
			}
			else{
				
			boolean isBidderRegretted = eventBidSubmissionService.isBidderRegretted(bidderId,tenderId);
		 	if(isBidderRegretted)
		       	{
		       		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"already_regrett_bidder");
		       	}
		       	else
		       	{
			 if(sessionBean!=null && tenderId!=0 ){
    		   boolean isFinalSubmissionDone=eventBidSubmissionService.isFinalSubmissionDone(tenderId,sessionBean.getCompanyId());
    		   if(isFinalSubmissionDone){
	    			 eventBidSubmissionService.deleteFinalSubmissionEntry(bidderId,bidderId);
	    		 }
    		   if(!isFinalSubmissionDone){
    			 String ipAdress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();
				 String remarks=StringUtils.hasLength(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") : "";
				 TblTenderBidRegression tblTenderBidRegret=new TblTenderBidRegression();
				 tblTenderBidRegret.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
				 tblTenderBidRegret.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
				 tblTenderBidRegret.setTblUserDetail(new TblUserDetail(sessionBean.getUserDetailId()));
				 tblTenderBidRegret.setTblTender(new TblTender(tenderId));
				 tblTenderBidRegret.setIpAddress(ipAdress);
				 tblTenderBidRegret.setRemarks(remarks);
				 tblTenderBidRegret.setIsActive(1);
				 tblTenderBidRegret.setCreatedBy(sessionBean.getUserDetailId());
				 tblTenderBidRegret.setUpdatedBy(0);
				 tblTenderBidRegret.setFormId(0);
				 tblTenderBidRegret.setTableId(0);
				 tblTenderBidRegret.setRowId(0);
				 tblTenderBidRegret.setRegretType(1);
				 tblTenderBidRegret.setEncodedName(spCompanyNameEncoded.executeProcedure(tenderModuleId,tenderId));
				 Map<String, Object>mailParams = new HashMap<String, Object>();
				 TblTender tblTender=eventBidSubmissionService.getTblTenderDetail(tenderId);
				 
				 mailParams.put("TenderID", tenderId);
	    		 mailParams.put("ClientName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
	    		 mailParams.put("TenderReferenceNo", tblTender.getTenderBrief());
	    		 mailParams.put("TenderTitle", tblTender.getTenderDetail());
	    		 mailParams.put("SystemID", tenderId);
	    		 mailParams.put("to", commonService.getUserLoginById(bidderId).get(0).getLoginId());
	    		 boolean isTenderBidConfirmation = eventBidSubmissionService.isTenderBidConfirmation(tenderId, sessionBean.getCompanyId());
	    		 mailContentUtillity.dynamicMailGeneration("384", String.valueOf(bidderId), "0", mailParams, "");
	    		 if(isTenderBidConfirmation){
	    			 eventBidSubmissionService.deleteBidIAgreeEntry(bidderId,tenderId);
		    		}
	    		 List<Object[]> consortiumPartnerDetail =eventBidSubmissionService.getSecoundryPartnerDetail(tenderId);
	    			for(Object o : consortiumPartnerDetail) {
	    				Object[] obj = (Object[])o;
	    				int bId = (Integer) obj[1];
	    				int partnerType = (Byte) obj[2];
	    			    int consortiumId = (Integer) obj[5];
	    			    boolean isLeadPartnerRegret=false;
	    			    if(partnerType==1){
	    			    isLeadPartnerRegret=eventBidSubmissionService.isLeadPartnerRegret(consortiumId,partnerType,bidderId);
	    			    }else{
	    			    	isLeadPartnerRegret=eventBidSubmissionService.isLeadPartnerRegretPartenerType(consortiumId,2,bidderId);
	    			    
	    		 if(isLeadPartnerRegret){
	    			 
	    			//List<Object[]> consortiumPartnerDetail =eventBidSubmissionService.getSecoundryPartnerDetail(tenderId);
	    			/*for(Object o : consortiumPartnerDetail) {
	    			    Object[] obj = (Object[])o;*/
	    			    Map<String, Object>mailParamsforConsortiumParter = new HashMap<String, Object>();
	   				    mailParamsforConsortiumParter.put("TenderID", tenderId);
	    			    mailParamsforConsortiumParter.put("ClientName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
	    			    mailParamsforConsortiumParter.put("TenderReferenceNo", tblTender.getTenderBrief());
	    			    mailParamsforConsortiumParter.put("TenderTitle", tblTender.getTenderDetail());
	    			    mailParamsforConsortiumParter.put("SystemID", tenderId);
	    			    mailParamsforConsortiumParter.put("userName", commonService.getUserName(bidderId));
	    			    mailParamsforConsortiumParter.put("to",obj[4]);
	    			    mailContentUtillity.dynamicMailGeneration("385", String.valueOf(bidderId), "0", mailParamsforConsortiumParter, "");
	    			    //commonService.getUserName(bidderId));
	    			    /*int bId = (Integer) obj[1];
	    			    int consortiumId = (Integer) obj[5];*/
	    				    	eventBidSubmissionService.deleteFinalSubmissionEntry(bId,tenderId);	
		    			    	eventBidSubmissionService.deleteConsortiumSecoundryPartnerEntry(bId,consortiumId);
		    			    	eventBidSubmissionService.deleteConsortiumPrimaryPartnerEntry(bidderId,consortiumId);
		    			
	    			}
	    		 }
	    			
	    			 
	    		 }
	    		 
	    		boolean success=eventBidSubmissionService.addRegretBidConfm(tblTenderBidRegret);
			     int isAllowded = (Integer) (StringUtils.hasLength(request.getParameter("hdisConsortiumAllowed")) ? Integer.parseInt(request.getParameter("hdisConsortiumAllowed")): 0);
				 page =REDIRECTBIDDERDASHBOARD+tenderId+"/2"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/2", request);
				 
				 if(!success)
					 {
					 	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
					 }
   		       	}}else{
   		       	page =REDIRECTBIDDERDASHBOARD+tenderId+"/2"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/2", request);
				 redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"regrett_success");
    		 }
    		}}
    	  
		}catch (Exception e) {
    		exceptionHandlerService.writeLog(e);
		}
    	finally{
    		 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, regretremarkssubmitted, tenderId, 0);
    	}
		page =REDIRECTBIDDERDASHBOARD+tenderId+"/2"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/2", request);
        return page;
	}
   
    /**
     * @param request
     */  
	@RequestMapping(value = "bidder/result", method = RequestMethod.POST)                       
    public String remarkForTenderOpening(HttpServletResponse response, HttpServletRequest request , ModelMap map,RedirectAttributes rea){
		int isCertRequired=0;
		String[] remarkSign = null;
		String remarks = null;
		boolean remarkIsValid = false;
		SessionBean sBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
		int userId = sBean.getUserId();
		int tenderId=Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID));
		HttpSession session = request.getSession();
		SessionBean sessionBean=(SessionBean)session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
		ClientBean clientBean = (ClientBean)session.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        try{
        	boolean isBidderRegretted = eventBidSubmissionService.isBidderRegretted(userId,tenderId);
            //modelMap.addAttribute("isBidderRegretted", isBidderRegretted);
            if(isBidderRegretted)
		       	{
           	 rea.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_temder_err_regret");
		       	}
			TblUserLogin tblUserLogin=null;
			TblCompany tblCompany=null;
			TblTender tblTender = null;
			TblBidderPresence tblBidderPresence = null;
    	     if(sessionBean != null){
    	    	 int companyId = sessionBean.getCompanyId();
        	     int createdBy = sessionBean.getUserDetailId();
        	     int bidderId = sessionBean.getUserId(); 
        	     remarks = StringUtils.hasLength(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") :"";
        	     remarkIsValid = StringUtils.hasLength(request.getParameter("txtaRemarks"));
        	     if (remarkIsValid && !remarks.equals("") ) {
        	    	  tblCompany = new TblCompany(companyId);
         	    	 tblUserLogin = new TblUserLogin(bidderId);
         	    	 tblBidderPresence = new TblBidderPresence();
         	    	 tblTender = new TblTender(tenderId);
         	    	 tblBidderPresence.setCreatedBy(createdBy);
         	    	 tblBidderPresence.setRemark(remarks);
         	    	 tblBidderPresence.setTblCompany(tblCompany);
         	    	 tblBidderPresence.setTblUserLogin(tblUserLogin);
         	    	 tblBidderPresence.setTblTender(tblTender);
         	    	 eventBidSubmissionService.remarkForTenderOpening(tblBidderPresence);
				}
    	     }
        }
        catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	isCertRequired= StringUtils.hasLength(request.getParameter("hdisCertRequired"))?Integer.parseInt(request.getParameter("hdisCertRequired")):0;
    		int pki=abcUtility.getSessionIsPkiEnabled(request);
    		if(pki==pkiEnable || clientBean.getIsPkiEnabled()==pkiEventSpecific && isCertRequired ==1){
    			remarkSign = new String[2];
				remarkSign[0]= remarks;
    			remarkSign[1] = request.getParameter(SKPSIGNTEXT)!=null ?request.getParameter(SKPSIGNTEXT): "";
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidEvaluationResultLinkId, "accessed tender dashboard result tab", tenderId, 0 , remarkSign);
    		}
    		else{    			
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidEvaluationResultLinkId, "accessed tender dashboard result tab", tenderId, 0);
    		}
    	}
        return  REDIRECTBIDDERDASHBOARD+tenderId+"/7"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/7", request);
    }
        
    /**
     * View Bid Form Matrix GET
     *
     * @param tenderId
     * @param tableId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/bidder/viewbidform/{tenderId}/{envelopeId}/{formId}/{bidId}/{enc}", method = RequestMethod.GET)
    public String viewBidForm(@PathVariable("tenderId") Integer tenderId,@PathVariable("envelopeId") Integer envelopeId, @PathVariable("formId") Integer formId,@PathVariable("bidId") Integer bidId, ModelMap modelMap, HttpServletRequest request) {
     	try {
            modelMap.addAttribute("bidId", bidId);
            modelMap.addAttribute("fromBidForm", true);
            SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            modelMap.addAttribute("bidderId",sessionBean.getUserId());
            modelMap.addAttribute("companyId", sessionBean.getCompanyId());
            modelMap.addAttribute("isCertRequired", Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString()));
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);                        
            setBidFormData(modelMap, request, tenderId, envelopeId);
            SessionBean sBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            int companyId = sBean.getCompanyId();
            int userId = sBean.getUserId();
            String finalSubmissionMsg = tenderCommonService.allowFinalSubmission(sBean.getIpAddress(), tenderId, companyId, userId,sBean.getUserDetailId(), 0);
            if (finalSubmissionMsg.contains("msg_tender_fs_finalsubmission_done")) {
                modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg.split("@")[0]);
            } else {
                modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg);
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),viewBidForm ,viewBidFormAudit , tenderId, formId);
        }
        	return "/etender/bidder/ViewBidForm";
    }    
    @RequestMapping(value = "/bidder/verifybidform/{tenderId}/{envelopeId}/{formId}/{bidId}/{nextBidIds}/{enc}", method = RequestMethod.GET)
    public String verifyBidForm(@PathVariable("tenderId") Integer tenderId,@PathVariable("envelopeId") Integer envelopeId, @PathVariable("formId") Integer formId,@PathVariable("bidId") Integer bidId,@PathVariable("nextBidIds") String nextBidIds, ModelMap modelMap, HttpServletRequest request,HttpSession httpSession) {
        try {
            SessionBean sBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            int companyId = sBean.getCompanyId();
            int userId = sBean.getUserId();
            String finalSubmissionMsg = tenderCommonService.allowFinalSubmission(sBean.getIpAddress(), tenderId, companyId, userId,sBean.getUserDetailId(), 0);
            if (finalSubmissionMsg.contains("msg_tender_fs_finalsubmission_done")) {
                modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg.split("@")[0]);
            } else {
                modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg);
            }
            /*Bug #34897 is form Mandatory validation And also add else for this if*/
            if(finalSubmissionMsg.contains("Success")){
            /*Bug #34897 is form Mandatory validation And also add else for this if*/
            	
            List<Object[]> lstTenderBidDtls = tenderCommonService.getTenderBidDtls(tenderId, companyId, false);
            if(bidId==0 && !lstTenderBidDtls.isEmpty()){
                envelopeId=(Integer)lstTenderBidDtls.get(0)[1];
                formId=(Integer)lstTenderBidDtls.get(0)[2];
                bidId=(Integer)lstTenderBidDtls.get(0)[0];
            }else{
                TblTenderBid tblTenderBid = eventBidSubmissionService.getTenderBidById(bidId);
                envelopeId = tblTenderBid.getTblTenderEnvelope().getEnvelopeId();
                formId = tblTenderBid.getTblTenderForm().getFormId();
            }
            modelMap.addAttribute("fromBidForm", true);
            modelMap.addAttribute("envelopeId", envelopeId);
            modelMap.addAttribute("formId", formId);
            modelMap.addAttribute("bidId", bidId);
            SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            modelMap.addAttribute("bidderId",sessionBean.getUserId());
            modelMap.addAttribute("companyId", sessionBean.getCompanyId());
            modelMap.addAttribute("isCertRequired", Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString()));
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);                        
            setBidFormData(modelMap, request, tenderId, envelopeId);
            }else{
            	modelMap.addAttribute("errorMsg", finalSubmissionMsg);
            	String page = "etender/bidder/biddingtenderdashboard/"+tenderId+"/5";
            	return "forward:/"+page+encryptDecryptUtils.generateRedirect(page, request);
            }
          
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),viewBidForm ,viewBidFormAudit , tenderId, formId);
        }
        return "/etender/bidder/ViewBidForm";
    }    
    private void setBidFormData(ModelMap modelMap,HttpServletRequest request,int tenderId,int envelopeId)throws Exception{
            List<Object[]> tenderData = tenderCommonService.getTenderFields(tenderId, "encryptionLevel,decimalValueUpto,isItemSelectionPageRequired"); 
            int level = !tenderData.isEmpty() ? (Integer) tenderData.get(0)[0] : 0 ;
            int decimalUpto = !tenderData.isEmpty() ? (Integer) tenderData.get(0)[1] : 0 ;
            int isItemSelectionPageRequired = !tenderData.isEmpty() ? (Integer) tenderData.get(0)[2] : 0 ;
            modelMap.addAttribute("decimalUpto",decimalUpto);
            modelMap.addAttribute("isItemSelectionPageRequired",isItemSelectionPageRequired);
            if((Integer)modelMap.get("isCertRequired")!=0){
                String[] certIds = abcUtility.getSessionCertId(request).split(",");            
                modelMap.addAttribute("bidpkey", commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                if(certIds.length==2){
                    modelMap.addAttribute("bidpkey2", commonService.getPublicKeyById(Integer.parseInt(certIds[1])));
                }
            }
            modelMap.addAttribute("level",level);
            if((Integer)modelMap.get("encryptionReq")==1){                
                List<Object[]> pkeyList = eventBidSubmissionService.getOfficerPublicKey(tenderId, envelopeId);
                if(level==1){                    
                    List<String> levelonepkey = new ArrayList<String>();
                    for (Object[] pkey : pkeyList) {
                        if((Integer)pkey[1]==1){
                            levelonepkey.add(pkey[0].toString());
                        }
                    }
                    modelMap.addAttribute("levelonepkey",levelonepkey);
                }
                if(level==2){                    
                    List<String> levelonepkey = new ArrayList<String>();
                    List<String> leveltwopkey = new ArrayList<String>();
                    for (Object[] pkey : pkeyList) {
                        if((Integer)pkey[1]==1){
                            levelonepkey.add(pkey[0].toString());
                        }
                        if((Integer)pkey[1]==2){
                            leveltwopkey.add(pkey[0].toString());
                        }
                    }
                    modelMap.addAttribute("levelonepkey",levelonepkey);
                    modelMap.addAttribute("leveltwopkey",leveltwopkey);
                }
            }
    }
    
    /**
     * To Show bidwithdraw page
     *
     * @author purvesh
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/bidder/showbidwithdraw/{tenderId}/{enc}", method = RequestMethod.GET)
    public String showBidWithdraw(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request) {
    	String retVal = "etender/bidder/BidWithdrawDashboard";
        try {
        	String publicKey=null;
        	if(abcUtility.getSessionIsPkiEnabled(request)==1){
        		String certIds[] = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
        		if(certIds!=null && certIds.length!=0){
        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
        		}
        		modelMap.addAttribute("publicKey", publicKey);
    		}
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("tenderId", tenderId);
        } catch (Exception e) {
            retVal =  exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidWithdrawalLinkId, getBidwithdrawal, tenderId, 0);
        }
        return retVal;
    }
    
    /**
     * Withdraw a bid
     * 
     * @author purvesh
     * @param request
     * @param modelMap
     * @param redirectAttributes
     * @return to view
     */
    @RequestMapping(value="/bidder/withdrawbid/{tenderId}", method=RequestMethod.POST)
    public String withdrawBid(@PathVariable("tenderId")int tenderId, ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes){
    	boolean success = false;
    	boolean isPkiEnable = false;
    	boolean isFinalSubmissionDone = false;
    	boolean isSubmissionDatelapsed = false;
    	String signRemarks = null;
    	String remarks = null;
    	String redirectUrl = "etender/bidder/showbidwithdraw/";
    	String retVal="redirect:/sessionexpired";
    	String successMsgCode=null;
    	String failureMsgCode=CommonKeywords.ERROR_MSG_KEY.toString();
    	String auditMsg=postBidwithdrawalFailedAudit;
    	String eventType = "";
        int isConsortiumAllowed=0;
    	try {
    		remarks = StringUtils.hasLength(request.getParameter("txtaWidthrawRemarks")) ? request.getParameter("txtaWidthrawRemarks") : null;
    		SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
    		int bidderId = sessionBean.getUserId();
    		if(sessionBean!=null && !"".equalsIgnoreCase(remarks) && remarks!=null){
    			if(abcUtility.getSessionIsPkiEnabled(request)==1){
    				isPkiEnable = true;
    				signRemarks = StringUtils.hasLength(request.getParameter("skpSignText")) ? request.getParameter("skpSignText") : "";
    			}
    			eventType = StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
    			String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();
    			int userDetailedId = sessionBean.getUserDetailId();
    			int companyId = sessionBean.getCompanyId();
    			isFinalSubmissionDone = eventBidSubmissionService.isFinalSubmissionDone(tenderId, companyId);
    			List<Object[]> data = tenderCommonService.getSubEndDtAndManDocs(tenderId);
    			if(data!=null && !data.isEmpty()){
    				isSubmissionDatelapsed = (Boolean) data.get(0)[0];
                                isConsortiumAllowed = (Integer) data.get(0)[2];
    			}
    			if(!isFinalSubmissionDone){
    				success = false;
    				failureMsgCode = "msg_final_submission_not_done";
    				retVal="redirect:/"+redirectUrl+tenderId+ encryptDecryptUtils.generateRedirect(redirectUrl+tenderId, request);
    			}
    			else if(isSubmissionDatelapsed){
    				success=false;
    				failureMsgCode = "msg_submission_date_lapsed";
    				retVal="redirect:/"+redirectUrl+tenderId+ encryptDecryptUtils.generateRedirect(redirectUrl+tenderId, request);
    			}
    			else{
    				success = eventBidSubmissionService.withdrawBid(tenderId, bidderId, userDetailedId, companyId, remarks, ipAddress);
    				if(success){
    					List<Object[]> mailData = tenderCommonService.getTenderFields(tenderId, "isConsortiumAllowed,tenderNo,tenderBrief");
    					int isConsortium = 0;
    					String tenderNo = null;
    					String tenderBrief = null;
    					if(mailData!=null && !mailData.isEmpty()){
    						isConsortium = (Integer) mailData.get(0)[0];
        					tenderNo = (String) mailData.get(0)[1];
        					tenderBrief = (String) mailData.get(0)[2]; 
    					}
    					int[] ConsrtFields = tenderCommonService.getConsortiumPartnerType(tenderId, companyId);
                                        if(isConsortiumAllowed == 1){
                                            //code for send mail to all secondary partner on withdraw
                                            List<Object> emailIdList = tenderCommonService.getSecondaryPartnerEmailIDs(tenderId,ConsrtFields[0]);
                                            if(emailIdList.size()>0){
                                                String to = abcUtility.converObjectArrayToCommas(emailIdList);
                                                Map<String, Object> paramMapSecodary = new HashMap<String, Object>();
                                                paramMapSecodary.put("tenderId", tenderId);
                                                paramMapSecodary.put("tenderNo", tenderNo);
                                                //Added By Lipi - Start
                                                paramMapSecodary.put("brief", tenderBrief);
                                                paramMapSecodary.put("eventType", eventType);
                                                String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/biddingtenderdashboard/" + tenderId + "/" + 6);
                                                String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                                                paramMapSecodary.put("link", herfStr);
                                                paramMapSecodary.put("to",to);
                                                paramMapSecodary.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
                                                mailContentUtillity.dynamicMailGeneration("182", "0", "0", paramMapSecodary,String.valueOf(companyId));
                                            }
                                        }
                                        //mail for lead partner
                                        Map<String, Object> paramMap = new HashMap<String, Object>();
    					paramMap.put("tenderId", tenderId);
    					paramMap.put("tenderNo", tenderNo);
                                        //Added By Lipi - Start
    					paramMap.put("brief", tenderBrief);
    					paramMap.put("eventType", eventType);
    					String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/biddingtenderdashboard/" + tenderId + "/" + 6);
                                        String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                                        paramMap.put("link", herfStr);
                                        mailContentUtillity.dynamicMailGeneration("57", String.valueOf(bidderId), String.valueOf(tenderId), paramMap, String.valueOf(isConsortium), String.valueOf(companyId),String.valueOf(ConsrtFields[1]),String.valueOf(ConsrtFields[0]));
                                    
    					retVal=REDIRECTBIDDERDASHBOARD+tenderId+"/6"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/6", request);
        				successMsgCode = "msg_withdrawn_bid";
        				auditMsg=postBidwithdrawalAudit;
        			}
    				else {
    					retVal="redirect:/"+redirectUrl+tenderId+ encryptDecryptUtils.generateRedirect(redirectUrl+tenderId, request);
    				}
    			}
    			redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? successMsgCode : failureMsgCode);
    		}
		} catch (Exception e) {
			retVal =  exceptionHandlerService.writeLog(e);
		}
    	finally{
    		if(isPkiEnable){
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidWithdrawalLinkId,auditMsg, tenderId, 0,remarks, signRemarks);
    		}
    		else{
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidWithdrawalLinkId,auditMsg, tenderId, 0);
    		}
    	}
    	return retVal;
    }
    
    @RequestMapping(value = "/bidder/deletebid/{tenderId}/{formId}/{bidId}/{enc}", method = RequestMethod.GET)
    public String deleteBid(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") Integer formId, @PathVariable("bidId") Integer bidId, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String pageName = "redirect:/sessionexpired";
        try {
            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            if (sessionBean != null) {
                List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "submissionEndDate,isEMDByBidder,isProcessingFeeByBidder,isDocumentFeeByBidder");
                if (((Date) tenderFields.get(0)[0]).after(commonService.getServerDateTime())) {
                    if (eventBidSubmissionService.checkFinalSubmitDone(sessionBean.getCompanyId(), tenderId)) {
                            //PaymentTable 1 for Docfees, 2 for EMD, 4 for Processing Fee
                            boolean isDocumentFeeByBidder = (Integer)tenderFields.get(0)[3]==1;
                            boolean isEMDByBidder = (Integer)tenderFields.get(0)[1]==1;
                            boolean isProcessingFeeByBidder = (Integer)tenderFields.get(0)[2]==1;
                            boolean isFillByBidder= false;
                            List<Integer> paymentFor = new ArrayList<Integer>();
                            if(isDocumentFeeByBidder){paymentFor.add(1);}
                            if(isEMDByBidder){paymentFor.add(2);}
                            if(isProcessingFeeByBidder){paymentFor.add(4);}
                            TblTenderForm tblTenderForm = tenderFormService.getTenderFormById(formId);
                            List<TblTenderTable> tables = tenderFormService.getTenderTableByFormId(formId);
                            for (TblTenderTable tenderTable : tables) {
                            	 List<TblTenderColumn> columns = tenderFormService.getTenderColumnByTableId(tenderTable.getTableId());
                            	  for (TblTenderColumn tblTenderColumn : columns) {
                            		  if (tblTenderColumn.getTblColumnType().getColumnTypeId() == documentFeesByBidder) {
                                          isFillByBidder=true;
                                      }            
                                      if (tblTenderColumn.getTblColumnType().getColumnTypeId() == emdAmountByBidder) {
                                          isFillByBidder=true;
                                      }
                            	  }
                            }
                            if((!isDocumentFeeByBidder && !isEMDByBidder && !isProcessingFeeByBidder) || ((isDocumentFeeByBidder || isEMDByBidder || isProcessingFeeByBidder) 
                            		&& tblTenderForm.getIsPriceBid()==0?true:!isFillByBidder?true:eventBidSubmissionService.checkBidPayment(abcUtility.getSessionClientId(request), tenderId, sessionBean.getCompanyId(),paymentFor))){
                            boolean success = eventBidSubmissionService.deleteBidSubmitted(bidId,tenderId,formId,sessionBean.getCompanyId());
                            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),success ?  "redirect_success_bid_delete" : CommonKeywords.ERROR_MSG_KEY.toString());
                        }else{
                            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_bidform_delafterpay");
                        }
                    } else {
                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_bid_submission_done");
                    }
                } else {
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_bid_submission");
                }
                pageName = REDIRECTBIDDERDASHBOARD+tenderId+"/5"+ encryptDecryptUtils.generateRedirect(BIDDERDASHBOARD+tenderId+"/5", request);
            } 
        } catch (Exception e) {
            pageName = exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),deleteBid ,deleteBidAudit , tenderId, bidId);
        }
        return pageName;
    }
    /**
	 * Use to Show Rebate Report Form for encryption level
	 * @author krunal.patel
	 * @param tenderId
	 * @param envelopeId
	 * @param rebateId
	 * @param formId
	 * @param companyId 
	 * @param addEdtFlage
	 * @param tabType
	 * @param modelMap
	 * @param request
	 * @param response
	 * @throws Exception
	 * @return
	 */
 @RequestMapping(value = "/bidder/crteditrebate/{tenderId}/{rebateId}/{companyId}/{addEdtFlage}/{tabType}/{enc}", method = RequestMethod.GET)             
 public String crtEditRebate(@PathVariable("tenderId") int tenderId,@PathVariable("rebateId") int rebateId,@PathVariable("companyId") int companyId,
		 @PathVariable("addEdtFlage") int addEdtFlage,@PathVariable("tabType") int  tabType,ModelMap modelMap, HttpServletResponse response, HttpServletRequest request){
 	
 	String retVal = null;
	
 	boolean isDualCerti = false;
	boolean isEncCertVerified = false;
	if(abcUtility.getSessionUserTypeId(request) == 2 && (addEdtFlage != 4 && addEdtFlage != 3))
	{
		int isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
		isEncCertVerified = commonService.checkIsCertificateVerified(isCertRequired,2,request);
	}
	else
	{
		isEncCertVerified = true;    		
	}
	request.getSession().setAttribute("isEncCertVerified",isEncCertVerified);
   if(!isEncCertVerified)
	{
		String page = "etender/bidder/biddingtenderdashboard/"+tenderId+"/5";
		return "redirect:/"+page+encryptDecryptUtils.generateRedirect(page, request);
	}
	else
	{
 	
     try{
     		
    	 	//TblTenderForm tblTenderForm = tenderFormService.getTenderFormById(formId);
    	 	//if(tblTenderForm!=null){
    	 		modelMap.put("encryptionReq", 1);
    	 	//}
    	 	
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
			
    	 	/*** Get Common Services to get officer publicKey by tenderId and envelopeId**/
	 		setBidFormData(modelMap, request, tenderId,0);
	 		
	 		int isCertRequired =  Integer.parseInt(modelMap.get("isCertRequired").toString());
 			if(isCertRequired == 1){
 				isDualCerti = abcUtility.getSessionIsDualCerti(request);
 			}
 			modelMap.put("isCertRequired", isDualCerti == true ? 1 : 0);
 			modelMap.put("isOpeningByCommittee", Integer.parseInt(modelMap.get("isOpeningByCommittee").toString()));
 		
     		/*** Get Common Services for tender detail **/
			
			/*** Get Rebate Form List encryption level**/
			modelMap.put("rebateFormList", eventBidSubmissionService.getRebateList(rebateId,companyId));
			
         retVal = "etender/bidder/addRebate";
     }
     catch(Exception e){
     	return exceptionHandlerService.writeLog(e);
     } finally {
         auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addEdtFlage==1?addRebateDetailLinkId:addEdtFlage==2?editRebateDetailLinkId:viewRebateDetailLinkId, createrebatepercentagepage, tenderId, rebateId);
     }
     return retVal;
	}
 }
 /**
	 * Use to add Rebate at bidders
	 * @author krunal.patel
	 * @param request
	 * @throws Exception
	 * @return
	 */
 @RequestMapping(value = "/bidder/addrebate", method = RequestMethod.POST)
 public String addRebate(RedirectAttributes redirectAttributes, HttpServletRequest request) {
 	boolean success=false;
 	String retVal = "redirect:/sessionexpired";
 	int tenderId = 0 ;
 	int rebateId = 0;
 	int companyId = 0;
 	
     
     
     try{
    	 int sessionUserId = abcUtility.getSessionUserId(request);
    	 if(sessionUserId!=0){
    	  	tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
    	  	rebateId = StringUtils.hasLength(request.getParameter("hdRebateId"))? Integer.parseInt(request.getParameter("hdRebateId")):0;
    	  	companyId = StringUtils.hasLength(request.getParameter("hdCompanyId"))? Integer.parseInt(request.getParameter("hdCompanyId")):0;
    	  	String encryptVal = request.getParameter("perEncVal");
    	  	String rbtEncVal = request.getParameter("rbtEncVal");
      	
      	 	int userDetailId = abcUtility.getSessionUserDetailId(request);
      	 	if(StringUtils.hasLength(encryptVal) && StringUtils.hasLength(rbtEncVal)){
      			 
      	 	TblTenderRebate tblTenderRebate = new TblTenderRebate();
      	 	
      	 	tblTenderRebate.setTblCompany(new TblCompany(companyId));
      	 	tblTenderRebate.setTblRebate(new TblRebate(rebateId));
      	 	tblTenderRebate.setRebateValue(encryptVal);
      	 	tblTenderRebate.setRebateEncrypt(rbtEncVal);
      	 	tblTenderRebate.setCreatedBy(userDetailId);
          	

      		/*** Start Code to insert in TblTenderRebate table**/
      		success = eventBidSubmissionService.addTenderRebate(tblTenderRebate);
      	 	}
    	 }	
     }catch(Exception e){
     	return exceptionHandlerService.writeLog(e);
     }finally {
         auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addRebateDetailLinkId, success ? rebatepercentageadd : rebatepercentageaddfail,tenderId,rebateId);
     }
     retVal=success?BIDDERDASHBOARD+tenderId+"/"+5:"/bidder/crteditrebate/"+tenderId+"/"+rebateId+"/"+companyId+"/1/{enc}";
     retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
     redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_bidder_rebate_add" : CommonKeywords.ERROR_MSG_KEY.toString());
     return retVal;
 }
 /**
	 * Use to edit Rebate at bidders
	 * @author krunal.patel
	 * @param request
	 * @throws Exception
	 * @return
	 */
 @RequestMapping(value = "/bidder/editrebate", method = RequestMethod.POST)
 public String editRebate(RedirectAttributes redirectAttributes, HttpServletRequest request) {
 	boolean success=false;
    String retVal = "redirect:/sessionexpired";
    int tenderId = 0 ;
  	int rebateId = 0;
  	int companyId = 0;
     
     
     try{
    	 int sessionUserId = abcUtility.getSessionUserId(request);
    	 if(sessionUserId!=0){
    		 
    	 tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
         rebateId = StringUtils.hasLength(request.getParameter("hdRebateId"))? Integer.parseInt(request.getParameter("hdRebateId")):0;
         companyId = StringUtils.hasLength(request.getParameter("hdCompanyId"))? Integer.parseInt(request.getParameter("hdCompanyId")):0;
         String encryptVal = StringUtils.hasLength(request.getParameter("perEncVal"))? request.getParameter("perEncVal"):"";
         String rbtEncVal = StringUtils.hasLength(request.getParameter("rbtEncVal"))? request.getParameter("rbtEncVal"):"";
      	
      	 	int userDetailId = abcUtility.getSessionUserDetailId(request);
      	 	if( StringUtils.hasLength(encryptVal) && StringUtils.hasLength(rbtEncVal)){
      	 
	      	 	TblTenderRebate tblTenderRebate = new TblTenderRebate();
	      	 	
	      	 	tblTenderRebate.setTblCompany(new TblCompany(companyId));
	      	 	tblTenderRebate.setTblRebate(new TblRebate(rebateId));
	      	 	tblTenderRebate.setRebateValue(encryptVal);
	      	 	tblTenderRebate.setRebateEncrypt(rbtEncVal);
	      	 	tblTenderRebate.setCreatedBy(userDetailId);
	          	
	
	      		/*** Start Code to insert in TblTenderRebate table**/
	      		success = eventBidSubmissionService.editTenderRebate(rebateId,tblTenderRebate,companyId);
      	 	}
    	 }	
      		
     }catch(Exception e){
     	return exceptionHandlerService.writeLog(e);
     }finally {
         auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editRebateDetailLinkId, success ? rebatepercentageupdate : rebatepercentageupdatefail,tenderId,rebateId);
     }
     retVal=success?BIDDERDASHBOARD+tenderId+"/"+5:"/bidder/crteditrebate/"+tenderId+"/"+rebateId+"/"+companyId+"/2/{enc}";
	 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_bidder_rebate_update" : CommonKeywords.ERROR_MSG_KEY.toString());
     return retVal;
 }
    @RequestMapping(value = {"/bidder/gentableexcel/{tenderId}/{formId}/{enc}","/buyer/gentableexcel/{tenderId}/{formId}/{enc}"}, method = RequestMethod.GET)
    public void genTableExcel(@PathVariable("tenderId") int tenderId, @PathVariable("formId") int formId, HttpServletResponse response,HttpServletRequest request) {
        try {
            StringBuilder path = new StringBuilder();
            TblTenderForm tblTenderForm = tenderFormService.getTenderFormById(formId);
            path.append(drive).append(upload).append("\\OfflineBidForm\\").append(tenderId).append("\\").append(formId).append("\\");
            File folder = new File(path.toString());
            if(!folder.exists()){
                folder.mkdirs();
            }
            File file = new File(path.toString() + abcUtility.correctFileName(abcUtility.reverseReplaceSpecialChars(tblTenderForm.getFormName())) + ".xls");
            if (true || !file.exists()) {
                Workbook wb = new HSSFWorkbook(); // Create New WorkBook
                List<Object[]> tables = tenderFormService.getTenderTableListByFormId(formId);
                for (Object[] table : tables) {                    
                int tableId = (Integer)table[0];
                List<Object[]> tableList = tenderFormService.getTenderTableDetails(tableId);                
                List<Object[]> headerList = tenderFormService.getTenderColumn(tableId);
                Map<Integer,Integer> sortVsColNo = new HashMap<Integer, Integer>();
                String tableName = !tableList.isEmpty() ? abcUtility.reverseReplaceSpecialChars(tableList.get(0)[2].toString()) : "";
                int lastLocation = !tableList.isEmpty() ? (Integer) tableList.get(0)[6] : 0;
                List<TblTenderCell> contentList = negotiationService.getTenderCellByTableIdNewOrderBy(tableId, 0);
                List<Object[]> formulaList = tenderFormService.getFormulaColId(tableId);
                int headerCount = 0;
                int contentCount = 0;
                int rowCount = 0;
                boolean isTotal = false;
                 int combocolNo = 0;
                 int formulaCell = 0;
                 List<String> formulaArr2 = new ArrayList<String>();
                SessionBean sessionBean = (SessionBean)request.getSession().getAttribute("sessionObject");
                List<Object[]> visibleRows = null;
                List<Object[]> activateItems = null;
                Map<Integer,List<Integer>> tableRows = new HashMap<Integer, List<Integer>>();
                Map<Integer,List<Integer>> activatetableRows = new HashMap<Integer, List<Integer>>();
                int isItemSelectionPageRequired = 0;
                int isItemwiseRegretAllowed = 0;
                StringBuilder finalFormula = new StringBuilder();
                StringBuilder finalFormula2 = new StringBuilder();
                boolean isBidRowLimited = false;
                Map<Integer,List<Integer>> mappedItemsTableRows = new HashMap<Integer, List<Integer>>();
                List<Object[]> mappedItems = null;
                if(sessionBean.getCompanyId()!=0){
                    isItemSelectionPageRequired = (Integer)tenderCommonService.getTenderField(tenderId, "isItemSelectionPageRequired");
                    visibleRows = tenderFormService.getSelectedRowsForBidding(formId, sessionBean.getCompanyId());
                    for (Object[] rows : visibleRows) {
                        List<Integer> rowIds = null;
                        if(tableRows.containsKey(rows[0])){                            
                            rowIds = tableRows.get(rows[0]);
                        }else{
                            rowIds = new ArrayList<Integer>();
                        }
                        rowIds.add((Integer)rows[1]);
                        tableRows.put((Integer)rows[0],rowIds);
                    }
                    isItemwiseRegretAllowed = (Integer)tenderCommonService.getTenderField(tenderId, "isItemwiseRegretAllowed");
                    activateItems = eventBidSubmissionService.getRegretActivateItem(tenderId,formId,0,sessionBean.getCompanyId());
                    for (Object[] rows : activateItems) {
                        List<Integer> rowIds = null;
                        if(activatetableRows.containsKey(rows[1])){                            
                            rowIds = activatetableRows.get(rows[1]);
                        }else{
                            rowIds = new ArrayList<Integer>();
                        }
                        rowIds.add(Integer.parseInt(rows[2].toString()));
                        activatetableRows.put(Integer.parseInt(rows[1].toString()),rowIds);
                    }
                    Object[] tenderFields = (Object[]) tenderCommonService.getTenderField(tenderId, "tenderResult,tenderMode");
                    isBidRowLimited = ((Integer)tenderFields[0] == 2 || (Integer)tenderFields[0] == 3) && ((Integer)tenderFields[1] == 2 || (Integer)tenderFields[1] == 3 || (Integer)tenderFields[1] == 4);
                    if(isBidRowLimited) {
	                    mappedItems = tenderFormService.getBidderItem(tenderId,sessionBean.getUserId());
	                    for (Object[] rows : mappedItems) {
	                        List<Integer> rowIds = null;
	                        if(mappedItemsTableRows.containsKey(rows[0])){                            
	                            rowIds = mappedItemsTableRows.get(rows[0]);
	                        }else{
	                            rowIds = new ArrayList<Integer>();
	                        }
	                        rowIds.add(Integer.parseInt(rows[1].toString()));
	                        mappedItemsTableRows.put(Integer.parseInt(rows[0].toString()),rowIds);
	                    }
                    }
                }
                
                Sheet sheet = wb.createSheet((tableName.length()>15 ? tableName.substring(0, 15).replaceAll("/", "") : tableName.replaceAll("/", ""))+"-"+tableId);// Create WorkSheet
                sheet.protectSheet("password"); //Protect WorkSheet                

                Font font = wb.createFont();  // Apply Font
                font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);  // Font Face

                CellStyle headingStyle = wb.createCellStyle();// Object that create Style
                headingStyle.setLocked(true); // Lock Cell
                headingStyle.setFillForegroundColor(IndexedColors.BLUE_GREY.getIndex());
                font.setColor(IndexedColors.WHITE.getIndex());
                headingStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
                headingStyle.setAlignment(CellStyle.ALIGN_CENTER);
                headingStyle.setFont(font);

                CellStyle contentStyle = wb.createCellStyle();
                contentStyle.setLocked(true);                
//                contentStyle.setAlignment(CellStyle.ALIGN_RIGHT);//taher right

                CellStyle enterNumeric = wb.createCellStyle();
                enterNumeric.setLocked(false); // Unlock Cell
//            
//            CellStyle totalStyle = wb.createCellStyle();
//            totalStyle.setAlignment(CellStyle.ALIGN_RIGHT);
//            totalStyle.setFont(font);
//            totalStyle.setLocked(true);

                int iscellAvail = -1;
                if (!headerList.isEmpty()) {
                    Row rowHeader = sheet.createRow(0);
                    for (Object[] head : headerList) {//List that Print Header in EXCEL
                        sortVsColNo.put((Integer)head[3], (Integer)head[4]);
                        String headerData = abcUtility.reverseReplaceSpecialChars(head[0].toString()).replace("\\<.*?\\>", "");
                        Cell cell = rowHeader.createCell(headerCount);
                        cell.setCellValue(headerData);
                        cell.setCellStyle(headingStyle);
                        sheet.setColumnWidth(headerCount, 7000);
                        if((Integer)head[2]==0){                            
                            sheet.setColumnHidden(headerCount, true);
                        }
                        if((Integer)head[5]==7){                            
                        	cell.setCellValue(headerData+ " (DD-MMM-YYYY)");
                        }
                        headerCount++;
                    }
                }
                int cellNum = 0;
                boolean addRow = false;
                Row rowContent = sheet.createRow(1);                
                if (!contentList.isEmpty()) {// Loop until List is Not Empty
                    for (TblTenderCell obj2 : contentList) {// condition that is used to create new Row
                        int columnNo = obj2.getTblTenderColumn().getSortOrder();// ColId at CellMaster                                                
                        int location = obj2.getRowId() + 1;// Location +1 Because We have to Skip Header Part in EXCEL
                        int dataType = obj2.getDataType();                        
                        int objectId = obj2.getObjectId();
                        int filledBy = obj2.getTblTenderColumn().getFilledBy();
                        String contentData = obj2.getCellValue();// Data Located at cellMaster
                        if (contentCount % headerCount == 0) {// until formula list is not empty
                            rowCount++;
                            cellNum = 0;
                            addRow = false;
                            if( tblTenderForm.getIsPriceBid() == 0  || dataType == 0 || (isItemSelectionPageRequired==0 && isItemwiseRegretAllowed==0) ||
                            		(isItemSelectionPageRequired == 1 && tableRows.containsKey(tableId) && tableRows.get(tableId).contains(rowCount) && isItemwiseRegretAllowed == 0) ||
                            		(isItemSelectionPageRequired == 0 && isItemwiseRegretAllowed == 1 && activatetableRows.containsKey(tableId) && activatetableRows.get(tableId).contains(rowCount)) ||
                            		(isItemSelectionPageRequired == 1 && isItemwiseRegretAllowed == 3 && activatetableRows.containsKey(tableId) && activatetableRows.get(tableId).contains(rowCount) && tableRows.containsKey(tableId) && tableRows.get(tableId).contains(rowCount)) ||
                            		(isItemSelectionPageRequired == 0 && isItemwiseRegretAllowed == 3 && activatetableRows.containsKey(tableId) && activatetableRows.get(tableId).contains(rowCount)) ||
                            		(isItemSelectionPageRequired == 1 && isItemwiseRegretAllowed == 1 && activatetableRows.containsKey(tableId) && activatetableRows.get(tableId).contains(rowCount) && tableRows.containsKey(tableId) && tableRows.get(tableId).contains(rowCount))
                            		){
                            	
                            	if((isBidRowLimited &&  dataType != 0 && tblTenderForm.getIsPriceBid() == 1) ? mappedItemsTableRows.containsKey(tableId) && mappedItemsTableRows.get(tableId).contains(rowCount) : true) {
                            		rowContent = sheet.createRow(rowCount);//Compare Formula colid to CellMaster colid and if Match then create formula Based On EXCEl                             
                                    addRow = true;
                            	}else {
                            		rowContent = sheet.createRow(rowCount);
                                	sheet.getRow(rowCount).setZeroHeight(true);
                            	}
                            	
                                /*rowContent = sheet.createRow(rowCount);//Compare Formula colid to CellMaster colid and if Match then create formula Based On EXCEl                             
                                addRow = true;*/
                            }else{
                            	rowContent = sheet.createRow(rowCount);
                            	sheet.getRow(rowCount).setZeroHeight(true);
                            }                             
                        }
                        if(addRow){
                          if (!formulaList.isEmpty()) {//List that take each and every Formula from FormulaMaster 
                            for (Object[] obj1 : formulaList) {// until formula list is not empty
                                if (!(obj1[2].toString().startsWith("SPF_") || obj1[2].toString().startsWith("VF_") || obj1[2].toString().startsWith("VCF_"))) {
                                	int colNo = sortVsColNo.get((Integer) obj1[5]);
                                    String formula = obj1[2].toString();
                                    List<String> formulaArr = new ArrayList<String>();
                                    if (colNo == columnNo) {//Compare Formula colid to CellMaster colid and if Match then create formula Based On EXCEl 
//                                        System.out.println("Original Formula : "+formula);    
                                    	 
                                         finalFormula = new StringBuilder();
                                        if (!formula.startsWith("WORD") && !formula.startsWith("TOTAL") && dataType!=0){//else for (2*3) or (2*3+N_35) like Formula
                                           
                                            boolean isnum = false;                                            
                                            for (int c = 0; c < formula.length(); c++) {
                                                char cc = formula.charAt(c);
                                                if (cc != 'N' && cc != '_') {
                                                    if (!isNumeric(String.valueOf(cc)) && cc != '.') {
                                                        formulaArr.add(String.valueOf(cc));
                                                        isnum = false;
                                                    } else {
                                                        if (isnum) {
                                                            formulaArr.set(formulaArr.size()-1, formulaArr.get(formulaArr.size()-1) + cc);
                                                        } else {
                                                            formulaArr.add(String.valueOf(cc));                                                            
                                                        }
                                                        isnum = true;
                                                    }
                                                }
                                            }                                            
                                            String formulaStr = formula.replaceAll("[_]", "").replaceAll("[\\+]", "_").replaceAll("[-]", "_").replaceAll("[\\)]", "_").replaceAll("[\\(]", "_").replaceAll("[\\*]", "_").replaceAll("[/]", "_");
                                            String[] arr = formulaStr.split("_");
                                            List<String> columns = new ArrayList<String>();
                                            for (int i = 0; i < arr.length; i++) {                        
                                                if (arr[i] != "" && arr[i].indexOf('N') == -1) {
                                                    columns.add(arr[i]);
                                                }
                                            }
//                                            System.out.println("columns : "+columns);
                                            for (int cnt2 = 0; cnt2 < columns.size(); cnt2++) {
                                                for (int cnt3 = 0; cnt3 < formulaArr.size(); cnt3++) {
                                                    if (columns.get(cnt2).equals(formulaArr.get(cnt3))) {
//                                                        System.out.println("CellRef : "+CellReference.convertNumToColString(sortVsColNo.get(Integer.parseInt(formulaArr.get(cnt3))) - 1));
                                                      formulaArr.set(cnt3, CellReference.convertNumToColString(sortVsColNo.get(Integer.parseInt(formulaArr.get(cnt3))) - 1)+location);
                                                    }
                                                }
                                            }
                                            if(combocolNo !=0 && formula.contains(String.valueOf(combocolNo))){
                                            	int index = formula.indexOf(String.valueOf(combocolNo));
                                            	formulaArr.add(index, "LEFT("+formulaArr.get(index).toString()+",FIND(\"_\","+formulaArr.get(index).toString()+")-1)");
                                            	formulaArr.remove(index+1);
                                            	
                                            }
                                            formulaArr2 = formulaArr;
                                            for (String formulaChunk : formulaArr) {
                                                finalFormula.append(formulaChunk);
                                            }
                                            /*for (int i = 0; i < formula.length(); i++) {
                                                char c = formula.charAt(i);
                                                int k = 0;
                                                if (Character.isLetter(c)) {//If condition for (2*3+N_35) like formula
                                                    for (k = i + 2; k < formula.length(); k++) {// if Operator comes like (+) after N_35 move on else case and break condition
                                                        if (!isOperator(formula.charAt(k))) {
                                                            finalFormula.append(formula.charAt(k));
                                                            i = k;
                                                        } else {
                                                            finalFormula.append(formula.charAt(k));
                                                            i = k;
                                                            break;
                                                        }
                                                    }
                                                }
                                                if (Character.isDigit(c)) {// if (2*3) like formula append 2 and 3
                                                    finalFormula.append(CellReference.convertNumToColString(Integer.parseInt(String.valueOf(c)) - 1));
                                                    finalFormula.append(location);
                                                } else {
                                                    if (!Character.isLetter(c)) {
                                                        finalFormula.append(c);// if(2*3) append *
                                                    }
                                                }
                                            }*/
//                                            System.out.println("Formula : "+finalFormula.toString());
                                            formulaCell = cellNum;
                                            Cell cellContentFormula = rowContent.createCell(cellNum);
                                            cellContentFormula.setCellType(Cell.CELL_TYPE_STRING);
                                            cellContentFormula.setCellFormula((finalFormula.toString()));
                                            cellContentFormula.setCellStyle(contentStyle);
                                            iscellAvail = cellNum;
                                        }else if (formula.startsWith("TOTAL")) {//If Formula Contains TOTAL make total of that Column
                                            isTotal = true;
                                            int colNoNew = colNo;
                                            if((Integer)headerList.get(colNoNew-1)[1] == 2){
                                                Cell cellContentData = rowContent.createCell(cellNum);
                                                cellContentData.setCellType(Cell.CELL_TYPE_NUMERIC);
                                                if (StringUtils.hasLength(contentData)) {
                                                    cellContentData.setCellStyle(contentStyle);
                                                    cellContentData.setCellValue(Double.parseDouble(contentData));
                                                } else {
                                                    cellContentData.setCellStyle(enterNumeric);
                                                }
                                            }
                                            String locationFirst = CellReference.convertNumToColString(colNoNew - 1) + "2";
                                            String locationEnd = CellReference.convertNumToColString(colNoNew - 1) + String.valueOf(lastLocation);
                                            Row rowTotal;
                                            if (sheet.getRow(lastLocation) != null) {
                                                rowTotal = sheet.getRow(lastLocation);
                                            } else {
                                                rowTotal = sheet.createRow(lastLocation);
                                            }
                                            Cell grandTotal = rowTotal.createCell(colNoNew - 1);
                                            grandTotal.setCellType(Cell.CELL_TYPE_STRING);
                                            grandTotal.setCellValue("");
                                            grandTotal.setCellFormula("SUM(" + locationFirst + ":" + locationEnd + ")");
                                            grandTotal.setCellStyle(headingStyle);
                                            iscellAvail = cellNum;
                                        }else if (formula.startsWith("WORD")) {
                                            Cell wordCell = rowContent.createCell(cellNum);
                                            wordCell.setCellType(Cell.CELL_TYPE_STRING);                                            
                                            wordCell.setCellValue("Conversion will be done on importing file into web form");
                                            wordCell.setCellStyle(contentStyle);                                            
                                            iscellAvail = cellNum;
                                                }
                                    } else {
                                        if (!(iscellAvail == cellNum)) {//To Protect OverWritting Data
                                            if (dataType==3 || dataType==4 || dataType==5) {// If data is Numeric create Cell Numeric Type
                                                Cell cellContentData = rowContent.createCell(cellNum);
                                                
                                                if (StringUtils.hasLength(contentData)) {
                                                	cellContentData.setCellType(Cell.CELL_TYPE_NUMERIC);
                                                    cellContentData.setCellStyle(contentStyle);
                                                    cellContentData.setCellValue(Double.parseDouble(contentData));
                                                } else {
                                                	cellContentData.setCellStyle(enterNumeric);
                                                	if(filledBy!=2)
                                                	{
                                                		cellContentData.setCellType(Cell.CELL_TYPE_NUMERIC);
                                                	}
                                                }
//                                                System.out.println("colcount "+columnNo);
//                                                System.out.println("cellNum "+cellNum);
//                                                System.out.println("cellValue "+contentData);
//                                                System.out.println("cellId "+obj2.getCellId());
                                            } else// Create Cell String Type
                                            {
                                                if(dataType == 7){//Date
                                                	CellStyle cellStyle = wb.createCellStyle();
                                                	CreationHelper createHelper = wb.getCreationHelper();
	                                            	DataValidationHelper dvHelper = sheet.getDataValidationHelper();
	                                                CellRangeAddressList addressList = new CellRangeAddressList(rowCount, rowCount, columnNo-1, columnNo-1);               
		                                            DataValidationConstraint dvConstraint = dvHelper.createDateConstraint(OperatorType.BETWEEN,
		                                                      "01/Jan/1900", "30/Dec/9999", "dd/MMM/YYYY");
		                                            DataValidation dataValidation = new HSSFDataValidation(addressList, dvConstraint);
		                                            sheet.addValidationData(dataValidation);
		                                            Cell cellContentData = rowContent.createCell(cellNum);                                                                                
		                                            short dateFormat = createHelper.createDataFormat().getFormat("dd-MMM-yyyy");
		                                            cellStyle.setDataFormat(dateFormat);
		                                            cellStyle.setLocked(false);
		                                            cellContentData.setCellStyle(cellStyle);
	                                            }else if(dataType ==6){//combo
                                                    List<TblComboDetail> comboDetail = tenderFormService.getComboDetailByComboId(new Object[]{objectId});
                                                    String[] combo = new String[comboDetail.size()];
                                                    for (int i = 0; i < combo.length; i++) {
                                                        combo[i] = comboDetail.get(i).getOptionValue()+"_"+comboDetail.get(i).getOptionName();
                                                    }                                        
                                                    CellRangeAddressList addressList = new CellRangeAddressList(rowCount, rowCount, columnNo-1, columnNo-1);                                        
                                                    DVConstraint dvConstraint = DVConstraint.createExplicitListConstraint(combo);
                                                    DataValidation dataValidation = new HSSFDataValidation(addressList, dvConstraint);
                                                    dataValidation.setSuppressDropDownArrow(false);
                                                    sheet.addValidationData(dataValidation);   
                                                    int colNo1 = sortVsColNo.get((Integer) obj1[5]);
                                                    if (colNo == columnNo) 
                                                    {
                                                    	combocolNo  = columnNo;
                                                    }else{
                                                    	Integer intValue=columnNo;
                                                    	for(Map.Entry entry: sortVsColNo.entrySet()){
                                                    	    if(intValue.equals(entry.getValue())){
                                                    	       String  strKey = entry.getKey().toString();
                                                    	        combocolNo = Integer.parseInt(strKey);
                                                    	    }
                                                    	}
                                                    }
                                                    
                                                    Cell cellContentData = rowContent.createCell(cellNum);                                                                                
                                                    cellContentData.setCellStyle(enterNumeric);
                                                    
                                                   
                                                    if(formula.contains(String.valueOf(combocolNo)) &&  obj2.getRowId()==1 && formulaCell!=0){
                                                    	int ind = formula.indexOf(String.valueOf(combocolNo));
                                                    	formulaArr2.add(ind, "LEFT("+formulaArr2.get(ind).toString()+",FIND(\"_\","+formulaArr2.get(ind).toString()+")-1)");
                                                    	formulaArr2.remove(ind+1);
                                                    	formulaArr = formulaArr2;
                                                    	 for (String formulaChunk : formulaArr) {
                                                             finalFormula2.append(formulaChunk);
                                                         }
                                                    	 finalFormula= finalFormula2 ;
                                                    Cell cellContentFormula = rowContent.createCell(formulaCell);
                                                    cellContentFormula.setCellType(Cell.CELL_TYPE_STRING);
                                                    cellContentFormula.setCellFormula((finalFormula.toString()));
                                                    cellContentFormula.setCellStyle(contentStyle);
                                                    }
                                                    
                                                }else{
                                                    Cell cellContentData = rowContent.createCell(cellNum);                                        
                                                    cellContentData.setCellType(Cell.CELL_TYPE_STRING);
                                                    if (StringUtils.hasLength(contentData)) {
                                                        cellContentData.setCellStyle(contentStyle);
                                                        cellContentData.setCellValue(abcUtility.reverseReplaceSpecialChars(contentData).replace("\\<.*?\\>", ""));
                                                    } else {
                                                        cellContentData.setCellStyle(enterNumeric);
                                                    }                                        
                                                }
//                                                System.out.println("colcount "+columnNo);
//                                                System.out.println("cellNum "+cellNum);
//                                                System.out.println("cellValue "+contentData);
//                                                System.out.println("cellId "+obj2.getCellId());
                                            }
                                        }
                                    }
                                }
                            }
                        }else{
                            if (!(iscellAvail == cellNum)) {//To Protect OverWritting Data
                            	if (dataType==3 || dataType==4 || dataType==5) {// If data is Numeric create Cell Numeric Type
                                    Cell cellContentData = rowContent.createCell(cellNum);
                                    cellContentData.setCellType(Cell.CELL_TYPE_NUMERIC);
                                    if (StringUtils.hasLength(contentData)) {
                                        cellContentData.setCellStyle(contentStyle);
                                        cellContentData.setCellValue(Double.parseDouble(contentData));
                                    } else {                                            
                                        cellContentData.setCellStyle(enterNumeric);
                                    }
                                } else// Create Cell String Type
                                {
                                    if(dataType == 7){//Date
                                    	CellStyle cellStyle = wb.createCellStyle();
                                    	CreationHelper createHelper = wb.getCreationHelper();
                                    	DataValidationHelper dvHelper = sheet.getDataValidationHelper();
                                        CellRangeAddressList addressList = new CellRangeAddressList(rowCount, rowCount, columnNo-1, columnNo-1);               
                                        DataValidationConstraint dvConstraint = dvHelper.createDateConstraint(OperatorType.BETWEEN,
                                                  "01/Jan/1900", "30/Dec/9999", "dd/MMM/YYYY");
                                        DataValidation dataValidation = new HSSFDataValidation(addressList, dvConstraint);
                                        sheet.addValidationData(dataValidation);
                                        Cell cellContentData = rowContent.createCell(cellNum);                                                                                
                                        short dateFormat = createHelper.createDataFormat().getFormat("dd-MMM-yyyy");
                                        cellStyle.setDataFormat(dateFormat);
                                        cellStyle.setLocked(false);
                                        cellContentData.setCellStyle(cellStyle);
                                    }else if(dataType ==6){//combo
                                        List<TblComboDetail> comboDetail = tenderFormService.getComboDetailByComboId(new Object[]{objectId});
                                        String[] combo = new String[comboDetail.size()];
                                        for (int i = 0; i < combo.length; i++) {
                                        	combo[i] = comboDetail.get(i).getOptionValue()+"_"+comboDetail.get(i).getOptionName();
                                            
                                        }
                                        CellRangeAddressList addressList = new CellRangeAddressList(rowCount, rowCount, columnNo-1, columnNo-1);                                        
                                        DVConstraint dvConstraint = DVConstraint.createExplicitListConstraint(combo);
                                        DataValidation dataValidation = new HSSFDataValidation(addressList, dvConstraint);
                                        dataValidation.setSuppressDropDownArrow(false);
                                        sheet.addValidationData(dataValidation);                                        
                                        Cell cellContentData = rowContent.createCell(cellNum);                                                                                
                                        cellContentData.setCellStyle(enterNumeric);
                                        combocolNo = columnNo;
                                    }else{
                                        Cell cellContentData = rowContent.createCell(cellNum);                                        
                                        cellContentData.setCellType(Cell.CELL_TYPE_STRING);
                                        cellContentData.setCellValue(abcUtility.reverseReplaceSpecialChars(contentData).replace("\\<.*?\\>", ""));
                                        if (StringUtils.hasLength(contentData)) {
                                            cellContentData.setCellStyle(contentStyle);
                                        } else {
                                            cellContentData.setCellStyle(enterNumeric);
                                        }                                        
                                    }
                                  }
                                }
                            }
                        }            
                        cellNum++;// Increment Cell and When new Row is Created Initialize  with 0
                        contentCount++; // content count used to create New Row
                    }
                    if (isTotal) {//isTotal=True at that time we have to Display Grand Total
                        Row rowTotal;
                        if (sheet.getRow(lastLocation) != null) {
                            rowTotal = sheet.getRow(lastLocation);
                        } else {
                            rowTotal = sheet.createRow(lastLocation);
                        }
                        Cell cellGrandTotal = rowTotal.createCell(0);
                        cellGrandTotal.setCellValue("Grand Total");
                        cellGrandTotal.setCellStyle(headingStyle);
                    }
                }
                    for (int i = 0; i < headerCount; i++) {                        
                        sheet.autoSizeColumn(i);
                    }
                }
                FileOutputStream fout = new FileOutputStream(file);// Write File
                wb.write(fout);
                fout.flush();
                fout.close();
            }
            InputStream fis = new FileInputStream(file);
            byte[] buf = new byte[fis.available()];
            int offset = 0;
            int numRead = 0;
            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                offset += numRead;
            }
            ServletOutputStream outputStream = response.getOutputStream();
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment;filename=\"" + abcUtility.reverseReplaceSpecialChars(tblTenderForm.getFormName()) + ".xls\"");            
            outputStream.write(buf);
            outputStream.flush();
            outputStream.close();
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
    }

    private boolean isNumeric(String contentData){// Check Wether Data is Numeric 
        List<Integer> numbers = Arrays.asList(new Integer[]{46, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57});
        int numCnt = 0;
        char[] c = contentData.toCharArray();
        for (int d : c) {
            if (numbers.contains(d)) {
                numCnt++;
            }
        }
        return StringUtils.hasLength(contentData) && numCnt == c.length;
    }

    public boolean isOperator(char op) {
        if (op == '+' || op == '-' || op == '*' || op == '/' || op == '%') {
            return true;
        }
        return false;
    }
    @RequestMapping(value ={"/bidder/uploadbidderbid","/buyer/uploadbidderbid"}, method = RequestMethod.POST)
    @ResponseBody
    public String uploadBidderBid(@RequestParam("hdFormId") String hdFormId, @RequestParam(HIDDEN_TENDER_ID) String hdTenderId,HttpServletRequest request) {
        String data = null;
        boolean isValidate = true;        
        try {
            int userId = abcUtility.getSessionUserId(request);
            if(userId!=0){
            File file = null;
            File tmpDir = null;
            long fileSize = 0;
            String fileName = null;
            long fileMaxSize = 1024 * 1024L;//1 MB
            String fileExtensions = "xls"; 
            DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
            fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
            ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
            List items = uploadHandler.parseRequest(request);
            Iterator itr = items.iterator();
            String dateFormat = WebUtils.getCookie(request, "dateFormat").getValue();
            while (itr.hasNext()) {
                FileItem item = (FileItem) itr.next();
                if (!item.isFormField()) {
                    fileSize = item.getSize();
                    if (item.getName().lastIndexOf("\\") != -1) {
                        fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1, item.getName().length());
                    } else {
                        fileName = item.getName();
                    }
                    if (fileName != null && !fileName.equalsIgnoreCase("")) {
                        if (fileSize == 0) {
                            data = messageSource.getMessage("msg_tender_emptyfile", null, LocaleContextHolder.getLocale());
                            isValidate = false;
                            break;
                        }
                        if (!checkFileSize(fileSize, fileMaxSize)) {
                            data = messageSource.getMessage("msg_tender_maxfilesize", new Object[]{(fileMaxSize / 1024)}, LocaleContextHolder.getLocale());
                            isValidate = false;
                            break;
                        }
                        if (!checkFileExn(fileName, fileExtensions)) {
                            data = messageSource.getMessage("msg_tender_fileformatnotsupp", null, LocaleContextHolder.getLocale());
                            isValidate = false;
                            break;
                        } else {
                            /* if destination directory not exist then create it*/
                            String tmpDirPath = drive + upload + "\\OfflineBid";
                            tmpDir = new File(tmpDirPath);
                            if (!tmpDir.isDirectory()) {
                                tmpDir.mkdir();
                            }
                            tmpDirPath = tmpDirPath + "\\" + hdFormId + "\\" + userId;
                            tmpDir = new File(tmpDirPath);
                            if (!tmpDir.isDirectory()) {
                                tmpDir.mkdirs();
                            }
                            file = new File(tmpDir, fileName);
                            item.write(file);
                            if (checkFileExn(fileName, "enc")){
                            	String[] res = new String[2];
	                           	 res = encryptDecryptUtils.decryptSignerCode(file,Integer.parseInt(hdTenderId),0);
	                       		 if(res[0].contains("false")){
	                       			 isValidate = false;
	                       			 data= messageSource.getMessage(res[1], null, LocaleContextHolder.getLocale());
	                       		 }
                            }
                        }
                    }
                }
            }
            if (isValidate && file != null && file.exists()) {
                        FileInputStream fis = new FileInputStream(file);
                        HSSFWorkbook workbook = new HSSFWorkbook(fis);
                        //Get first sheet from the workbook
                        StringBuffer jsons = new StringBuffer();
                        List<Object[]> tables = tenderFormService.getTenderTableListByFormId(Integer.parseInt(hdFormId));
                        Map<String, Object> dateCellsMap = tenderFormService.getDateColumnNoRowNoByFormId(Integer.parseInt(hdFormId));
                        SimpleDateFormat formatter = new SimpleDateFormat(dateFormat.replace("D", "d").replace("Y", "y"));
                        for (Object[] table : tables) {                 
                            String tableName = abcUtility.reverseReplaceSpecialChars(table[1].toString().toString());
                            String sheetName = (tableName.length()>15 ? tableName.substring(0, 15) : tableName)+"-"+table[0].toString();                            
                            HSSFSheet sheet = workbook.getSheet(sheetName);
                            if(sheet!=null){
                            boolean isrightProtected = sheet.getProtect();
                            if(isrightProtected){
                            //Iterate through each rows from first sheet
                            Iterator<Row> rowIterator = sheet.iterator();
                            JSONArray jSONArray = new JSONArray();
                            int cellcount = 0;
                            int rowcount = 0;
                            while (rowIterator.hasNext()) {
                                Row row = rowIterator.next();
                                JSONObject jSONObject = new JSONObject();
                                //For each row, iterate through each columns
                                Iterator<Cell> cellIterator = row.cellIterator();
                                int cellno = 0;
                                while (cellIterator.hasNext()) {
                                	 Cell cell = cellIterator.next();
                                	 if(dateCellsMap.containsKey(table[0] + "_" + (cell.getColumnIndex()+1) + "_" + rowcount)){
                                		 String date = cell.toString();
                                   		 if(!date.matches("(0[1-9]|[12][0-9]|[3][01])-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)-\\d{4}")){
                                   			 data = messageSource.getMessage("msg_date_formate_is_not_validate",  null, LocaleContextHolder.getLocale());
                                             isValidate = false;
                                             break;
                                   		 }else{
                                   			 try {
                                   				String strDate= formatter.format(cell.getDateCellValue());  
                                                jSONObject.put((rowcount - 1) + "_" + cellno, strDate);
											} catch (Exception e) {
												 data = messageSource.getMessage("msg_date_formate_is_not_validate",  null, LocaleContextHolder.getLocale());
	                                             isValidate = false;
	                                             break;
											}
                                   		 }
                                	 }else{
                                		 switch (cell.getCellType()) {
	                                        case Cell.CELL_TYPE_NUMERIC:
	                                            jSONObject.put(rowcount == 0 ? String.valueOf(cellcount) : (rowcount - 1) + "_" + cellno, cell.getNumericCellValue());
	                                            break;
	                                        case Cell.CELL_TYPE_STRING:
	                                        	String splitString[] = cell.getRichStringCellValue().toString().split("_");
	                                        	jSONObject.put(rowcount == 0 ? String.valueOf(cellcount) : (rowcount - 1) + "_" + cellno, splitString[0].toString().trim().replaceAll("&quot;","\"").replaceAll("&quot","\""));
	                                            break;                                     
	                                        case Cell.CELL_TYPE_FORMULA:
	                                            jSONObject.put(rowcount == 0 ? String.valueOf(cellcount) : (rowcount - 1) + "_" + cellno, cell.getNumericCellValue());
	                                            break;
                                		 }
                            	 
                                	 }
	                                    cellno++;
	                                    cellcount++;
                                    }
	                                jSONArray.put(rowcount, jSONObject);
	                                rowcount++;
                            	}
                            	jsons.append(jSONArray.toString()).append("@@@");
                            }else{ 
                            	data = messageSource.getMessage("not_valid_file_format_msg",  null, LocaleContextHolder.getLocale());
                                isValidate = false;
                                break;
                            }
                            }/*If ends here*/
                            else{
                            	data = messageSource.getMessage("not_valid_bid_format_msg",  null, LocaleContextHolder.getLocale());
                                isValidate = false;
                                break;
                            }
                        }
                        if(isValidate){
                        data = jsons.length()>3 ? jsons.substring(0,jsons.length()-3) : jsons.toString();
                        }  
                        fis.close();
            }
            }else{
                data = "Session expired";
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormExcelMatrix, addXlsMatrixAudit, Integer.parseInt(hdTenderId), Integer.parseInt(hdTableId));
        }
        return isValidate ? data : "ERROR::" + data;
    }

	private boolean checkFileSize(long fielSize, long maxFileSize) {
        boolean chextn = false;
        if (maxFileSize > fielSize) {
            chextn = true;
        } else {
            chextn = false;
        }
        return chextn;
    }

    /**
     * to check file extention
     *
     * @param fileName
     * @param allowExtensions
     * @return
     */
    private boolean checkFileExn(String fileName, String allowExtensions) {
        boolean chextn = false;
        int j = fileName.lastIndexOf('.');
        String lst = fileName.substring(j + 1);
        String str = allowExtensions;
        String[] str1 = str.split(",");
        for (int i = 0; i < str1.length; i++) {
            if (str1[i].trim().equalsIgnoreCase(lst)) {
                chextn = true;
            }
        }
        return chextn;
    }
    /**
     * 
     * @param tenderId
     * @param bidderId
     * @param companyId
     * @param modelMap
     * @param request
     * @return
     */
     @RequestMapping(value = "/bidder/formitemselection/{tenderId}/{envelopeId}/{formId}/{bidId}/{enc}", method = RequestMethod.GET)
        public String getEvaluateBiddersItemWsie(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("formId") int formId,@PathVariable("bidId") int bidId, ModelMap modelMap,HttpServletRequest request) {
    	    try {
           	 SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
           	 int companyId = sessionBean.getCompanyId();
           	 int bidderId = sessionBean.getUserId();
             modelMap.addAttribute("bidderId",sessionBean.getUserId());
             modelMap.addAttribute("companyId", companyId);
             TblTender tblTender = tenderCommonService.getTenderById(tenderId);
             modelMap.addAttribute("isItemwiseRegretAllowed", tblTender.getIsItemwiseRegretAllowed());
           	 Map<Integer,Map<String,Object>> formMap = new LinkedHashMap<Integer, Map<String,Object>>();
           	 if(formId == 0){
	             List<Object[]> envelopForm = tenderFormService.getApprovedPriceBidForm(tenderId);
	             if(envelopForm != null && !envelopForm.isEmpty()){
	            	 int minFormsReqForBidding = 0;
	            	for(Object[] obj : envelopForm)
	            	{
	            		Map<String,Object> map = new HashMap<String, Object>();
	            		map.put("companyId", companyId);
	            		// Bug #32568 By Jitendra.
	            		map.put("bidderId", sessionBean.getUserId());
	            		map.put("formItemSelection", "Yes");
	            		map.put("isItemwiseRegretAllowed", tblTender.getIsItemwiseRegretAllowed());
	            		int envelopformId = Integer.parseInt(obj[0].toString());
	            		tenderFormService.setViewFormNFormula(envelopformId, map, tenderId);
	            		formMap.put(envelopformId, map);
	            		if(obj[5].equals(1)){
	            			minFormsReqForBidding++;
	            		}
	            		modelMap.put("envelopName", obj[4]);
	            	}
	            	modelMap.put("minFormsReqForBidding", minFormsReqForBidding);
	             }
           		modelMap.put("formList", formMap);
           	 }else{
            		Map<String,Object> map = new HashMap<String, Object>();
            		map.put("companyId", companyId);
            		// Bug #32568 By Jitendra.
            		map.put("bidderId", sessionBean.getUserId());
            		map.put("isItemwiseRegretAllowed", tblTender.getIsItemwiseRegretAllowed());
            		map.put("formItemSelection", "Yes");
            		tenderFormService.setViewFormNFormula(formId, map, tenderId);
            		formMap.put(formId, map);
            		modelMap.put("formList", formMap);
           	 }
             List<Object[]> itemselected = tenderFormService.getBidderItems(tenderId,bidderId,formId,false);
             if(itemselected != null && !itemselected.isEmpty())
        	 {
        		 //modelMap.addAttribute("bidderItemId",1);
        		 modelMap.addAttribute("itemselected",itemselected);
        		 ArrayList<String> arr = new ArrayList<String>();
        		 Map<String,String> biddedMap = new HashMap<String, String>(); 
        		 Map<String,String> selectedMap = new HashMap<String, String>();
        		 
        		 for(Object[] obj : itemselected)
        		 {
        			 if(obj[3].equals(1)){
        				 arr.add(obj[0]+"_"+obj[1]+"_"+obj[2]);
        			 }
        			 biddedMap.put(obj[0]+"_"+obj[1]+"_"+obj[2],obj[6].toString());
        			 selectedMap.put(obj[0]+"_"+obj[1]+"_"+obj[2],obj[3].toString());
        		 }
        		 
        		 modelMap.addAttribute("biddedMap",biddedMap);
        		 modelMap.addAttribute("selectedMap",selectedMap);
        		 modelMap.addAttribute("itemselected",arr);
        	 }
              tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            } catch (Exception e) {
                return exceptionHandlerService.writeLog(e);
            }finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), selectItemsForBiddingLink , getFormItemSelectionPage,tenderId,envelopeId);
            }
            return "/etender/bidder/FormItemSelection";
        }
     /**
      * 
      * @author bharat
      * @param modelMap
      * @param request
      * @param redirectAttributes
      * @return
      * used to save/edit bidder items
      */
     @RequestMapping(value = "bidder/savebidderitem", method = RequestMethod.POST)
     public String saveBidderItem(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
         String retVal = "redirect:/sessionexpired";
         int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
         int envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")) : 0;
         int companyId = StringUtils.hasLength(request.getParameter("hdCompanyId")) ? Integer.parseInt(request.getParameter("hdCompanyId")) : 0;
         int bidderId = StringUtils.hasLength(request.getParameter("hdBidderId")) ? Integer.parseInt(request.getParameter("hdBidderId")) : 0;
         int hdformId = StringUtils.hasLength(request.getParameter("hdformId")) ? Integer.parseInt(request.getParameter("hdformId")) : 0;
         int hdBidId = StringUtils.hasLength(request.getParameter("hdBidId")) ? Integer.parseInt(request.getParameter("hdBidId")) : 0;
         String hdIsUpdate = request.getParameter("hdIsUpdate");
         
         String approveRejectItems[]=null;
         
         String approveRejectAllItems[]=request.getParameterValues("hdItemCombo");
         String mandatoryItemCombo[]=request.getParameterValues("hdMandatoryItemCombo");
                  
         SessionBean sessionBean = request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
         try {
             if (sessionBean != null) {
                 boolean isInserted = false;
                 approveRejectItems = request.getParameterValues("chkApproveRejectItems");
                 List<String> processed = new ArrayList<String>();
                 List<TblItemSelection> bidderItemsList = new ArrayList<TblItemSelection>();
                 List <Integer> eventfeeList= new ArrayList<Integer>();
                 List <Integer> eventfeeaddList= new ArrayList<Integer>();
                 if(approveRejectItems!=null){
                	 List <TblEventFees> lstTenderFees= new ArrayList<TblEventFees>();
                     /// All selected items
 	                for(int i=0;i<approveRejectItems.length;i++){
 	                	String[] approvedItem = approveRejectItems[i].split("_");
 	                        TblItemSelection TblItemSelection = new TblItemSelection();
 	                        TblItemSelection.setTblTender(new TblTender(tenderId));
 	                        TblItemSelection.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
 	                        TblItemSelection.setTblTenderForm(new TblTenderForm(Integer.parseInt(approvedItem[0])));//formId
 	                        TblItemSelection.setTblTenderTable(new TblTenderTable(Integer.parseInt(approvedItem[1])));//tableId
 	                        TblItemSelection.setRowId(Integer.parseInt(approvedItem[2]));//rowId
 	                       lstTenderFees = tenderFormService.getEventFeesCheckPayment(tenderId,sessionBean.getCompanyId(),Integer.parseInt(approvedItem[0]), Integer.parseInt(approvedItem[1]),Integer.parseInt(approvedItem[2]), hdBidId,0);
	                         if(lstTenderFees!=null && !lstTenderFees.isEmpty()){
	                        	 for (TblEventFees tbleventfees : lstTenderFees){
	                        		 eventfeeaddList.add(tbleventfees.getEventFeeId());
	                        	 }
	                         }
 	                        TblItemSelection.setTblUserLogin(new TblUserLogin(bidderId));
 	                        TblItemSelection.setTblCompany(new TblCompany(companyId));
 	                        TblItemSelection.setCreatedBy(abcUtility.getSessionUserId(request)); // user login id.
 	                        TblItemSelection.setIsSelected(1);//1 for approve items
 	                        TblItemSelection.setIsBidded(Integer.parseInt(approvedItem[3]));//1 for bidded
 	                        bidderItemsList.add(TblItemSelection);
 	                        processed.add(approveRejectItems[i].trim());
 	                }
 	                    	
                 }
                 /// All items which are not selected
                 if(approveRejectAllItems != null){
                	 List <TblEventFees> lstTenderFees= new ArrayList<TblEventFees>();
	                 for(String obj : approveRejectAllItems){
	                 	if(!processed.contains(obj)){
	                 		String[] approvedItem = obj.split("_");
	                         TblItemSelection TblItemSelection = new TblItemSelection();
	                         TblItemSelection.setTblTender(new TblTender(tenderId));
	                         TblItemSelection.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
	                         TblItemSelection.setTblTenderForm(new TblTenderForm(Integer.parseInt(approvedItem[0])));//formId
	                         TblItemSelection.setTblTenderTable(new TblTenderTable(Integer.parseInt(approvedItem[1])));//tableId
	                         TblItemSelection.setRowId(Integer.parseInt(approvedItem[2]));//rowId
	                          lstTenderFees = tenderFormService.getEventFeesCheckPayment(tenderId,sessionBean.getCompanyId(),Integer.parseInt(approvedItem[0]), Integer.parseInt(approvedItem[1]),Integer.parseInt(approvedItem[2]), hdBidId,1);
	                         if(lstTenderFees!=null && !lstTenderFees.isEmpty()){
	                        	 for (TblEventFees tbleventfees : lstTenderFees){
	                        		 eventfeeList.add(tbleventfees.getEventFeeId());
	                        	 }
	                         }
	                         TblItemSelection.setTblUserLogin(new TblUserLogin(bidderId));
	                         TblItemSelection.setTblCompany(new TblCompany(companyId));
	                         TblItemSelection.setCreatedBy(abcUtility.getSessionUserId(request)); // user login id.
	                         TblItemSelection.setIsSelected(0);//1 for approve items
	 	                     TblItemSelection.setIsBidded(Integer.parseInt(approvedItem[3]));//1 for bidded
	                         bidderItemsList.add(TblItemSelection);
	                         processed.add(obj.trim());
	 	             } 
	                } 
                 }
                 /// All items which are mandatory to insert.
                 if(mandatoryItemCombo != null){
	                 for(String obj : mandatoryItemCombo){
	                 	if(!processed.contains(obj)){
	                 		String[] approvedItem = obj.split("_");
	                         TblItemSelection TblItemSelection = new TblItemSelection();
	                         TblItemSelection.setTblTender(new TblTender(tenderId));
	                         TblItemSelection.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
	                         TblItemSelection.setTblTenderForm(new TblTenderForm(Integer.parseInt(approvedItem[0])));//formId
	                         TblItemSelection.setTblTenderTable(new TblTenderTable(Integer.parseInt(approvedItem[1])));//tableId
	                         TblItemSelection.setRowId(Integer.parseInt(approvedItem[2]));//rowId
	                         TblItemSelection.setTblUserLogin(new TblUserLogin(bidderId));
	                         TblItemSelection.setTblCompany(new TblCompany(companyId));
	                         TblItemSelection.setCreatedBy(abcUtility.getSessionUserId(request)); // user login id.
	                         TblItemSelection.setIsSelected(1);//1 for approve items
	 	                        TblItemSelection.setIsBidded(Integer.parseInt(approvedItem[3]));//1 for bidded
	                         bidderItemsList.add(TblItemSelection);
	                         processed.add(obj.trim());
	 	             } 
	                } 
                 }
                 
                 if(bidderItemsList != null && !bidderItemsList.isEmpty()){
                	 if(!eventfeeList.isEmpty()){
                		 eventBidSubmissionService.updateBidFees(eventfeeList,0,tenderId,companyId);
                	 }
                	 if(!eventfeeaddList.isEmpty()){
                		 eventBidSubmissionService.updateBidFees(eventfeeaddList,1,tenderId,companyId);
                	 }
                     isInserted = tenderFormService.addTblItemSelection(bidderItemsList, envelopeId, companyId,abcUtility.getSessionUserId(request),hdformId);
                 }
                 String msg = "";
                 if(hdIsUpdate == null)
                 {
                	 msg = "msg_item_for_bidding_select_success";
                 }else{
                	 msg = "msg_add_remove_success";
                 }
                 if(hdformId != 0)
                 {
                	 
                	 redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? msg : CommonKeywords.ERROR_MSG_KEY.toString());
                	 retVal="etender/bidder/bidform/"+tenderId+"/"+envelopeId+"/"+hdformId+"/"+hdBidId;
                 	 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                 }else{
                	 List<Object[]> list=eventBidSubmissionService.getFirstPricedBidFormBidId(tenderId, envelopeId, companyId);
                	 msg = "msg_item_for_bidding_select_success";
                	 if(list!=null && !list.isEmpty()){
                		 redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? msg : CommonKeywords.ERROR_MSG_KEY.toString());
                    	 retVal="etender/bidder/bidform/"+tenderId+"/"+envelopeId+"/"+Integer.parseInt(list.get(0)[0].toString())+"/"+Integer.parseInt(list.get(0)[1].toString());
                	 }else{
                 		redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? msg : CommonKeywords.ERROR_MSG_KEY.toString());
                 		retVal="etender/bidder/biddingtenderdashboard/"+tenderId+"/5";
                     }
                	 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                 }
             }
         } catch (Exception e) {
             exceptionHandlerService.writeLog(e);
         } finally {
        	 	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), selectItemsForBiddingLink , setFormItemSelectionPageValue ,tenderId,envelopeId);
         }
         return retVal;
     }

    /**
     * author Lipi
     * View Bid Form Matrix GET - item wise upload doc (same for View Bid Form)
     */
    @RequestMapping(value = "/bidder/itemWiseDocUpload/{tenderId}/{envelopeId}/{formId}/{bidId}/{enc}", method = RequestMethod.GET)
    public String ItemWiseDocUpload(@PathVariable("tenderId") Integer tenderId,@PathVariable("envelopeId") Integer envelopeId, @PathVariable("formId") Integer formId,@PathVariable("bidId") Integer bidId, ModelMap modelMap, HttpServletRequest request) {
        try {
        	modelMap.addAttribute("isFromItemWise", true);
            modelMap.addAttribute("bidId", bidId);
            modelMap.addAttribute("fromBidForm", true);
            SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            modelMap.addAttribute("bidderId",sessionBean.getUserId());
            modelMap.addAttribute("companyId", sessionBean.getCompanyId());
            modelMap.addAttribute("isCertRequired", Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString()));
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            tenderFormService.setViewFormNFormula(formId, modelMap, tenderId);                        
            setBidFormData(modelMap, request, tenderId, envelopeId);
            SessionBean sBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            int companyId = sBean.getCompanyId();
            int userId = sBean.getUserId();
            modelMap.addAttribute("encTenderId",encryptDecryptUtils.encrypt(tenderId.toString()));
            modelMap.addAttribute("encEnvelopeId",encryptDecryptUtils.encrypt(envelopeId.toString()));
            modelMap.addAttribute("encFormId",encryptDecryptUtils.encrypt(formId.toString()));
            modelMap.addAttribute("encBidId",encryptDecryptUtils.encrypt(bidId.toString()));
            String finalSubmissionMsg = tenderCommonService.allowFinalSubmission(sBean.getIpAddress(), tenderId, companyId, userId,sBean.getUserDetailId(), 0);
            if (finalSubmissionMsg.contains("msg_tender_fs_finalsubmission_done")) {
                modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg.split("@")[0]);
            } else {
                modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg);
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),viewBidForm ,viewBidFormAudit , tenderId, formId);
        }
        return "/etender/bidder/ViewBidForm";
    } 
    /**
     * author Lipi
     * to set url for item wise doc upload
     */
    @RequestMapping(value = "/bidder/setItemWiseBidURL", method = RequestMethod.POST)
    public String setItemWiseBidURL(HttpServletRequest request, RedirectAttributes redirectAttributes) {
    	String pageName = "";
    	int tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))?Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
    	int envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId"))?Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
    	int formId = StringUtils.hasLength(request.getParameter("hdFormId"))?Integer.parseInt(request.getParameter("hdFormId")):0;
    	int bidId = StringUtils.hasLength(request.getParameter("hdBidId"))?Integer.parseInt(request.getParameter("hdBidId")):0;
    	int bidTableId = StringUtils.hasLength(request.getParameter("hdBidTableId"))?Integer.parseInt(request.getParameter("hdBidTableId")):0;
    	int rowId = StringUtils.hasLength(request.getParameter("txtRowId"))?Integer.parseInt(request.getParameter("txtRowId")):0;
    	String otherIds = envelopeId+","+formId+","+bidId;
   		pageName = "redirect:/common/bidder/uploadbriefcasedocuments/"+rowId+"/"+bidTableId+"/"+itemWiseDocUploadLinkId+"/"+tenderId+"/"+2+"/"+otherIds+encryptDecryptUtils.generateRedirect("common/bidder/uploadbriefcasedocuments/"+rowId+"/"+bidTableId+"/"+itemWiseDocUploadLinkId+"/"+tenderId+"/"+2+"/"+otherIds,request);
    	return pageName;
    }
    
    /**
     * To set values in excel while user click on excel download in case of negotiation
     * @author:Anjali
     * @param tenderId
     * @param formId
     * @param bidderid
     * @param negotiationId
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = {"/bidder/gentableexcel/{tenderId}/{formId}/{bidderid}/{negotiationId}/{enc}","/buyer/gentableexcel/{tenderId}/{formId}/{bidderid}/{negotiationId}/{enc}"}, method = RequestMethod.GET)
    public void genTableExcelForNegotiation(@PathVariable("tenderId") int tenderId, @PathVariable("formId") int formId,@PathVariable("bidderid") int bidderid,@PathVariable("negotiationId") int negotiationId,
    		HttpServletResponse response,HttpServletRequest request) {
        try {
            StringBuilder path = new StringBuilder();
            TblTenderForm tblTenderForm = tenderFormService.getTenderFormById(formId);
            path.append(drive).append(upload).append("\\OfflineBidForm\\").append(tenderId).append("\\").append(formId).append("\\");
            File folder = new File(path.toString());
            if(!folder.exists()){
                folder.mkdirs();
            }
            File file = new File(path.toString() + abcUtility.correctFileName(abcUtility.reverseReplaceSpecialChars(tblTenderForm.getFormName())) + ".xls");
            if (true || !file.exists()) {
                Workbook wb = new HSSFWorkbook(); // Create New WorkBook
                List<Object[]> tables = tenderFormService.getTenderTableListByFormId(formId);
                for (Object[] table : tables) {                    
                int tableId = (Integer)table[0];
                List<Object[]> tableList = tenderFormService.getTenderTableDetails(tableId);                
                List<Object[]> headerList = tenderFormService.getTenderColumn(tableId);
                Map<Integer,Integer> sortVsColNo = new HashMap<Integer, Integer>();
                String tableName = !tableList.isEmpty() ? abcUtility.reverseReplaceSpecialChars(tableList.get(0)[2].toString()) : "";
                int lastLocation = !tableList.isEmpty() ? (Integer) tableList.get(0)[6] : 0;
                List<TblTenderCell> contentList = negotiationService.getTenderCellByTableIdNewOrderBy(tableId,0);
                List<Object[]> formulaList = tenderFormService.getFormulaColId(tableId);
                int headerCount = 0;
                int contentCount = 0;
                int rowCount = 0;
                boolean isTotal = false;
                Map<Integer, Object> cellValues = new HashMap<Integer, Object>();
                TblNegotiation tblNegotiation = negotiationService.getTbNegotiation(negotiationId);
                
                if(tblNegotiation.getParentNegotiationId() != 0){
                	cellValues = negotiationService.getNegotiationBidData(negotiationId,formId);
              		 if(cellValues!=null && cellValues.isEmpty()){
              			cellValues = negotiationService.getNegotiationBidData(tblNegotiation.getParentNegotiationId(),formId);
              		 }
              	 }
              	 else{
              		cellValues = negotiationService.getNegotiationBidData(negotiationId,formId);
              		 if(cellValues!=null && cellValues.isEmpty()){
              			cellValues = negotiationService.getTenderBid(formId,bidderid);
              		 }
              	 }
           
                SessionBean sessionBean = (SessionBean)request.getSession().getAttribute("sessionObject");
                List<Object[]> visibleRows = null;
                Map<Integer,List<Integer>> tableRows = new HashMap<Integer, List<Integer>>();
                Map<Integer,List<Integer>> itemNegotiateRows = new HashMap<Integer, List<Integer>>();
                int tenderResult = 0;
                if(sessionBean.getCompanyId()!=0){
                	tenderResult = (Integer)tenderCommonService.getTenderField(tenderId, "tenderResult");
                    visibleRows = tenderFormService.getSelectedRowsForBidding(formId, sessionBean.getCompanyId());
                    for (Object[] rows : visibleRows) {
                        List<Integer> rowIds = null;
                        if(tableRows.containsKey(rows[0])){                            
                            rowIds = tableRows.get(rows[0]);
                        }else{
                            rowIds = new ArrayList<Integer>();
                        }
                        rowIds.add((Integer)rows[1]);
                        tableRows.put((Integer)rows[0],rowIds);
                    }
                    visibleRows = tenderFormService.getInviteRowsForBidder(tenderId, sessionBean.getCompanyId());
                    for (Object[] rows : visibleRows) {
                        List<Integer> rowIds = null;
                        if(itemNegotiateRows.containsKey(rows[0])){                            
                            rowIds = itemNegotiateRows.get(rows[0]);
                        }else{
                            rowIds = new ArrayList<Integer>();
                        }
                        rowIds.add((Integer)rows[1]);
                        itemNegotiateRows.put((Integer)rows[0],rowIds);
                    }
                }
                
                Sheet sheet = wb.createSheet((tableName.length()>15 ? tableName.replaceAll("/", "").substring(0, 15) : tableName.replaceAll("/", ""))+"-"+tableId);// Create WorkSheet
                sheet.protectSheet("password"); //Protect WorkSheet                

                Font font = wb.createFont();  // Apply Font
                font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);  // Font Face

                CellStyle headingStyle = wb.createCellStyle();// Object that create Style
                headingStyle.setLocked(true); // Lock Cell
                headingStyle.setFillForegroundColor(IndexedColors.BLUE_GREY.getIndex());
                font.setColor(IndexedColors.WHITE.getIndex());
                headingStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
                headingStyle.setAlignment(CellStyle.ALIGN_CENTER);
                headingStyle.setFont(font);

                CellStyle contentStyle = wb.createCellStyle();
                contentStyle.setLocked(true);                

                CellStyle enterNumeric = wb.createCellStyle();
                enterNumeric.setLocked(false); // Unlock Cell

                int iscellAvail = -1;
                if (!headerList.isEmpty()) {
                    Row rowHeader = sheet.createRow(0);
                    for (Object[] head : headerList) {//List that Print Header in EXCEL
                        sortVsColNo.put((Integer)head[3], (Integer)head[4]);
                        String headerData = abcUtility.reverseReplaceSpecialChars(head[0].toString()).replace("\\<.*?\\>", "");
                        Cell cell = rowHeader.createCell(headerCount);
                        cell.setCellValue(headerData);
                        cell.setCellStyle(headingStyle);
                        sheet.setColumnWidth(headerCount, 7000);
                        if((Integer)head[2]==0){                            
                            sheet.setColumnHidden(headerCount, true);
                        }if((Integer)head[5]==7){                            
                        	cell.setCellValue(headerData+ " (DD-MMM-YYYY)");
                        }
                        headerCount++;
                    }
                }
                int cellNum = 0;
                boolean addRow = false;
                Row rowContent = sheet.createRow(1);                
                if (!contentList.isEmpty()) {// Loop until List is Not Empty
                    for (TblTenderCell obj2 : contentList) {// condition that is used to create new Row
                        int columnNo = obj2.getTblTenderColumn().getSortOrder();// ColId at CellMaster                                                
                        int location = obj2.getRowId() + 1;// Location +1 Because We have to Skip Header Part in EXCEL
                        int dataType = obj2.getDataType();                        
                        int objectId = obj2.getObjectId();
                        int cellId = obj2.getCellId();
                        int filledBy = obj2.getTblTenderColumn().getFilledBy();
                        String contentData  = obj2.getCellValue();
                        if(contentData.equals("")){
                        	if(cellValues!=null && !cellValues.isEmpty()){
                        		if(cellValues.containsKey(cellId)){
                        			contentData = cellValues.get(cellId).toString();
                        		}
                        	}
                        	else{
                                contentData = obj2.getCellValue();// Data Located at cellMaster
                             }
                        }else{
                           contentData = obj2.getCellValue();// Data Located at cellMaster
                        }
                        if (contentCount % headerCount == 0) {// until formula list is not empty
                            rowCount++;
                            cellNum = 0;
                            addRow = false;
                            if(tenderResult != 2 || tblTenderForm.getIsPriceBid() == 0 || (tenderResult == 2 && tableRows.containsKey(tableId) && tableRows.get(tableId).contains(rowCount) && itemNegotiateRows.containsKey(tableId) && itemNegotiateRows.get(tableId).contains(rowCount))){                                    
                                rowContent = sheet.createRow(rowCount);//Compare Formula colid to CellMaster colid and if Match then create formula Based On EXCEl                             
                                addRow = true;
                            }else{
                            	rowContent = sheet.createRow(rowCount);
                            	sheet.getRow(rowCount).setZeroHeight(true);
                            }                             
                        }
                        if(addRow){
                          if (!formulaList.isEmpty()) {//List that take each and every Formula from FormulaMaster 
                            for (Object[] obj1 : formulaList) {// until formula list is not empty
                                if (!(obj1[2].toString().startsWith("SPF_") || obj1[2].toString().startsWith("VF_") || obj1[2].toString().startsWith("VCF_"))) {
                                	int colNo = sortVsColNo.get((Integer) obj1[5]);
                                    String formula = obj1[2].toString();
                                    if (colNo == columnNo) {//Compare Formula colid to CellMaster colid and if Match then create formula Based On EXCEl 
//                                        System.out.println("Original Formula : "+formula);    
                                        StringBuilder finalFormula = new StringBuilder();
                                        if (!formula.startsWith("WORD") && !formula.startsWith("TOTAL") && dataType!=0){//else for (2*3) or (2*3+N_35) like Formula
                                            List<String> formulaArr = new ArrayList<String>();
                                            boolean isnum = false;                                            
                                            for (int c = 0; c < formula.length(); c++) {
                                                char cc = formula.charAt(c);
                                                if (cc != 'N' && cc != '_') {
                                                    if (!isNumeric(String.valueOf(cc)) && cc != '.') {
                                                        formulaArr.add(String.valueOf(cc));
                                                        isnum = false;
                                                    } else {
                                                        if (isnum) {
                                                            formulaArr.set(formulaArr.size()-1, formulaArr.get(formulaArr.size()-1) + cc);
                                                        } else {
                                                            formulaArr.add(String.valueOf(cc));                                                            
                                                        }
                                                        isnum = true;
                                                    }
                                                }
                                            }                                            
                                            String formulaStr = formula.replaceAll("[_]", "").replaceAll("[\\+]", "_").replaceAll("[-]", "_").replaceAll("[\\)]", "_").replaceAll("[\\(]", "_").replaceAll("[\\*]", "_").replaceAll("[/]", "_");
                                            String[] arr = formulaStr.split("_");
                                            List<String> columns = new ArrayList<String>();
                                            for (int i = 0; i < arr.length; i++) {                        
                                                if (arr[i] != "" && arr[i].indexOf('N') == -1) {
                                                    columns.add(arr[i]);
                                                }
                                            }
//                                            System.out.println("columns : "+columns);
                                            for (int cnt2 = 0; cnt2 < columns.size(); cnt2++) {
                                                for (int cnt3 = 0; cnt3 < formulaArr.size(); cnt3++) {
                                                    if (columns.get(cnt2).equals(formulaArr.get(cnt3))) {
//                                                        System.out.println("CellRef : "+CellReference.convertNumToColString(sortVsColNo.get(Integer.parseInt(formulaArr.get(cnt3))) - 1));
                                                      formulaArr.set(cnt3, CellReference.convertNumToColString(sortVsColNo.get(Integer.parseInt(formulaArr.get(cnt3))) - 1)+location);
                                                    }
                                                }
                                            }
                                            for (String formulaChunk : formulaArr) {
                                                finalFormula.append(formulaChunk);
                                            }   
                                            Cell cellContentFormula = rowContent.createCell(cellNum);
                                            cellContentFormula.setCellType(Cell.CELL_TYPE_STRING);
                                            cellContentFormula.setCellFormula((finalFormula.toString()));
                                            cellContentFormula.setCellStyle(contentStyle);
                                            iscellAvail = cellNum;
                                        }else if (formula.startsWith("TOTAL")) {//If Formula Contains TOTAL make total of that Column
                                            isTotal = true;
                                            int colNoNew = colNo;
                                            if((Integer)headerList.get(colNoNew-1)[1] == 2){
                                                Cell cellContentData = rowContent.createCell(cellNum);
                                                cellContentData.setCellType(Cell.CELL_TYPE_NUMERIC);
                                                if (StringUtils.hasLength(contentData)) {
                                                    cellContentData.setCellValue(Double.parseDouble(contentData));
                                                }
                                                if(filledBy == 2){
                                            		cellContentData.setCellStyle(enterNumeric);
                                            	}else{
                                            		 cellContentData.setCellStyle(contentStyle);
                                            	}
                                            }
                                            String locationFirst = CellReference.convertNumToColString(colNoNew - 1) + "2";
                                            String locationEnd = CellReference.convertNumToColString(colNoNew - 1) + String.valueOf(lastLocation);
                                            Row rowTotal;
                                            if (sheet.getRow(lastLocation) != null) {
                                                rowTotal = sheet.getRow(lastLocation);
                                            } else {
                                                rowTotal = sheet.createRow(lastLocation);
                                            }
                                            Cell grandTotal = rowTotal.createCell(colNoNew - 1);
                                            grandTotal.setCellType(Cell.CELL_TYPE_STRING);
                                            grandTotal.setCellValue("");
                                            grandTotal.setCellFormula("SUM(" + locationFirst + ":" + locationEnd + ")");
                                            grandTotal.setCellStyle(headingStyle);
                                            iscellAvail = cellNum;
                                        }else if (formula.startsWith("WORD")) {
                                            Cell wordCell = rowContent.createCell(cellNum);
                                            wordCell.setCellType(Cell.CELL_TYPE_STRING);                                            
                                            wordCell.setCellValue("Conversion will be done on importing file into web form");
                                            wordCell.setCellStyle(contentStyle);                                            
                                            iscellAvail = cellNum;
                                                }
                                    } else {
                                        if (!(iscellAvail == cellNum)) {//To Protect OverWritting Data
                                            if (dataType==3 || dataType==4 || dataType==5) {// If data is Numeric create Cell Numeric Type
                                                Cell cellContentData = rowContent.createCell(cellNum);
                                                cellContentData.setCellType(Cell.CELL_TYPE_NUMERIC);
                                                if (StringUtils.hasLength(contentData)) {
                                                    cellContentData.setCellValue(Double.parseDouble(contentData));
                                                }  
                                                if(filledBy == 2){
                                            		cellContentData.setCellStyle(enterNumeric);
                                            	}else{
                                            		 cellContentData.setCellStyle(contentStyle);
                                            	}
                                            } else// Create Cell String Type
                                            {
                                                if(dataType == 7){//Date
                                                	CellStyle cellStyle = wb.createCellStyle();
                                                	CreationHelper createHelper = wb.getCreationHelper();
	                                            	DataValidationHelper dvHelper = sheet.getDataValidationHelper();
	                                                CellRangeAddressList addressList = new CellRangeAddressList(rowCount, rowCount, columnNo-1, columnNo-1);               
		                                            DataValidationConstraint dvConstraint = dvHelper.createDateConstraint(OperatorType.BETWEEN,
		                                                      "01/Jan/1900", "30/Dec/9999", "dd/MMM/yyyy");
		                                            DataValidation dataValidation = new HSSFDataValidation(addressList, dvConstraint);
		                                            sheet.addValidationData(dataValidation);
		                                            Cell cellContentData = rowContent.createCell(cellNum);                                                                                
		                                            short dateFormat = createHelper.createDataFormat().getFormat("dd-MMM-yyyy");
		                                            cellStyle.setDataFormat(dateFormat);
		                                            cellStyle.setLocked(false);
		                                            // #72942 :: START
		                                            if (StringUtils.hasLength(contentData)) {
		                                            	cellContentData.setCellValue(contentData.toString());
                                                    }
		                                            if(filledBy == 2){
                                                		cellStyle.setLocked(false);
                                                	}else{
                                                		cellStyle.setLocked(true);
                                                	}
		                                            // #72942 :: END
		                                            cellContentData.setCellStyle(cellStyle);
	                                            }else if(dataType == 6 || dataType == 9){ //combo & listbox #72942 #73142
                                                    List<TblComboDetail> comboDetail = tenderFormService.getComboDetailByComboId(new Object[]{objectId});
                                                    String[] combo = new String[comboDetail.size()];
                                                    for (int i = 0; i < combo.length; i++) {
                                                        combo[i] = comboDetail.get(i).getOptionValue()+"_"+comboDetail.get(i).getOptionName();

                                                    }                                        
                                                    CellRangeAddressList addressList = new CellRangeAddressList(rowCount, rowCount, columnNo-1, columnNo-1);                                        
                                                    DVConstraint dvConstraint = DVConstraint.createExplicitListConstraint(combo);
                                                    DataValidation dataValidation = new HSSFDataValidation(addressList, dvConstraint);
                                                    dataValidation.setSuppressDropDownArrow(false);
                                                    sheet.addValidationData(dataValidation);                                        
                                                    Cell cellContentData = rowContent.createCell(cellNum);
                                                    // #72942 #73142 :: START
		                                            if (combo.length>0) {
                                                        cellContentData.setCellValue(combo[0].toString());
                                                    }
		                                            // #72942 :: END
                                                    cellContentData.setCellStyle(enterNumeric);
                                                }else{
                                                    Cell cellContentData = rowContent.createCell(cellNum);                                        
                                                    cellContentData.setCellType(Cell.CELL_TYPE_STRING);
                                                    if (StringUtils.hasLength(contentData)) {
                                                        cellContentData.setCellValue(abcUtility.reverseReplaceSpecialChars(contentData).replace("\\<.*?\\>", ""));
                                                    }  
                                                    if(filledBy == 2){
                                                    	enterNumeric.setLocked(false); // #72942 :: UNLOCK ITEMS FILLED BY BIDDER IN EXCEL
                                                		cellContentData.setCellStyle(enterNumeric);
                                                	}else{
                                                		 contentStyle.setLocked(true); // #72942 :: LOCK ITEMS FILLED BY OFFICER IN EXCEL
                                                		 cellContentData.setCellStyle(contentStyle);
                                                	}                                            
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }else{
                            if (!(iscellAvail == cellNum)) {//To Protect OverWritting Data
                            	if (dataType==3 || dataType==4 || dataType==5) {// If data is Numeric create Cell Numeric Type
                                    Cell cellContentData = rowContent.createCell(cellNum);
                                    cellContentData.setCellType(Cell.CELL_TYPE_NUMERIC);
                                    if (StringUtils.hasLength(contentData)) {
                                        cellContentData.setCellValue(Double.parseDouble(contentData));
                                    }
                                    if(filledBy == 2){
                                		cellContentData.setCellStyle(enterNumeric);
                                	}else{
                                		 cellContentData.setCellStyle(contentStyle);
                                	}   
                                } else// Create Cell String Type
                                {
                                    if(dataType == 7){//Date
                                    	CellStyle cellStyle = wb.createCellStyle();
                                    	CreationHelper createHelper = wb.getCreationHelper();
                                    	DataValidationHelper dvHelper = sheet.getDataValidationHelper();
                                        CellRangeAddressList addressList = new CellRangeAddressList(rowCount, rowCount, columnNo-1, columnNo-1);               
                                        DataValidationConstraint dvConstraint = dvHelper.createDateConstraint(OperatorType.BETWEEN,
                                                  "01/Jan/1900", "30/Dec/9999", "dd/MMM/yyyy");
                                        DataValidation dataValidation = new HSSFDataValidation(addressList, dvConstraint);
                                        sheet.addValidationData(dataValidation);
                                        Cell cellContentData = rowContent.createCell(cellNum);                                                                                
                                        short dateFormat = createHelper.createDataFormat().getFormat("dd-MMM-yyyy");
                                        cellStyle.setDataFormat(dateFormat);
                                        // #72942 :: START
                                        if (StringUtils.hasLength(contentData)) {
                                        	cellContentData.setCellValue(contentData.toString());
                                        }
                                        if(filledBy == 2){
                                    		cellStyle.setLocked(false);
                                    	}else{
                                    		cellStyle.setLocked(true);
                                    	}
                                        // #72942 :: END
                                        cellContentData.setCellStyle(cellStyle);
                                    }else if(dataType == 6 || dataType == 9){//combo & listbox #72942 #73142
                                        List<TblComboDetail> comboDetail = tenderFormService.getComboDetailByComboId(new Object[]{objectId});
                                        String[] combo = new String[comboDetail.size()];
                                        for (int i = 0; i < combo.length; i++) {
                                        	combo[i] = comboDetail.get(i).getOptionValue()+"_"+comboDetail.get(i).getOptionName();
                                            
                                        }
                                        CellRangeAddressList addressList = new CellRangeAddressList(rowCount, rowCount, columnNo-1, columnNo-1);                                        
                                        DVConstraint dvConstraint = DVConstraint.createExplicitListConstraint(combo);
                                        DataValidation dataValidation = new HSSFDataValidation(addressList, dvConstraint);
                                        dataValidation.setSuppressDropDownArrow(false);
                                        sheet.addValidationData(dataValidation);                                        
                                        Cell cellContentData = rowContent.createCell(cellNum);                                                                                
                                        // #72942 #73142 :: START
                                        if (combo.length>0) {
                                            cellContentData.setCellValue(combo[0].toString());
                                        }
                                        // #72942 :: END
                                        cellContentData.setCellStyle(enterNumeric);
                                    }else{
                                        Cell cellContentData = rowContent.createCell(cellNum);                                        
                                        cellContentData.setCellType(Cell.CELL_TYPE_STRING);
                                        cellContentData.setCellValue(abcUtility.reverseReplaceSpecialChars(contentData).replace("\\<.*?\\>", ""));
                                        if(filledBy == 2){
                                    		cellContentData.setCellStyle(enterNumeric);
                                    	}else{
                                    		 cellContentData.setCellStyle(contentStyle);
                                    	}                             
                                    }
                                }
                                }
                            }
                        }            
                        cellNum++;// Increment Cell and When new Row is Created Initialize  with 0
                        contentCount++; // content count used to create New Row
                    }
                    if (isTotal) {//isTotal=True at that time we have to Display Grand Total
                        Row rowTotal;
                        if (sheet.getRow(lastLocation) != null) {
                            rowTotal = sheet.getRow(lastLocation);
                        } else {
                            rowTotal = sheet.createRow(lastLocation);
                        }
                        Cell cellGrandTotal = rowTotal.createCell(0);
                        cellGrandTotal.setCellValue("Grand Total");
                        cellGrandTotal.setCellStyle(headingStyle);
                    }
                }
                    for (int i = 0; i < headerCount; i++) {                        
                        sheet.autoSizeColumn(i);
                    }
                }
                FileOutputStream fout = new FileOutputStream(file);// Write File
                wb.write(fout);
                fout.flush();
                fout.close();
            }
            InputStream fis = new FileInputStream(file);
            byte[] buf = new byte[fis.available()];
            int offset = 0;
            int numRead = 0;
            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                offset += numRead;
            }
            ServletOutputStream outputStream = response.getOutputStream();
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment;filename=\"" + abcUtility.reverseReplaceSpecialChars(tblTenderForm.getFormName()) + ".xls\"");            
            outputStream.write(buf);
            outputStream.flush();
            outputStream.close();
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
    }
    
    /**
     * @author Priyanka Dalwadi
     * @param modelMap
     * @param request
     * get regret/Activate Item List
     * @return
     */
    
    @RequestMapping(value = "/bidder/regretActivateItem/{status}/{tenderId}/{formId}/{enc}", method = RequestMethod.GET)
    public String getRegretActivateItem(ModelMap modelMap, @PathVariable("status") int status,@PathVariable("tenderId") int tenderId,@PathVariable("formId") int formId,HttpServletRequest request) {
        try {
        	SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
           	int companyId = sessionBean.getCompanyId();
            modelMap.addAttribute("bidderId",sessionBean.getUserId());
            modelMap.addAttribute("companyId", companyId);     
            modelMap.addAttribute("status", status);
            boolean show= true;
        	Map<String,Object> map = new HashMap<String, Object>();
        	Set<TblTenderTable> tablelst = new TreeSet<TblTenderTable>();
        	 List<TblTenderTable> tables = tenderFormService.getTenderTableByFormId(formId);
        	 List<Object[]> regretitems = eventBidSubmissionService.getRegretActivateItem(tenderId,formId,status,companyId);
             for (TblTenderTable tenderTable : tables) {
            	 List<Object> rowIds = tenderFormService.getBidderMappedRows(tenderId, (Integer)modelMap.get("bidderId"), tenderTable.getTableId());
            	  	 if(regretitems!=null){
            		 Iterator itr = regretitems.iterator();
            		 String s = rowIds.toString().replace("[",",").replace("]",",").replace(" ","");
            		 while (itr.hasNext())
	         		 {
            			 Object[] obj = (Object[]) itr.next();
	         			 if(tenderTable.getTableId() == Integer.parseInt(obj[1].toString())){
	         				tablelst.add(tenderTable);
	         				if(rowIds != null && !rowIds.isEmpty()){
		         				 if( !s.contains(","+obj[2].toString()+",")  ){
		         					itr.remove();
		         				 }
		         			 }
	         			 }
	         		 }
            	 }
             }
        	 modelMap.addAttribute("tableList", tablelst);
    		map.put("companyId", companyId);
    		map.put("bidderId", sessionBean.getUserId());
    		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		map.put("isItemwiseRegretAllowed", 1);
            modelMap.addAttribute("lstRegretActivateItem",regretitems);
            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "submissionEndDate,isEMDByBidder,isProcessingFeeByBidder,isDocumentFeeByBidder,isParticipationFeesBy");
            if(!((Date)tenderFields.get(0)[0]).after(commonService.getServerDateTime())){
                	show = false;
            }
	        if(!eventBidSubmissionService.checkFinalSubmitDone(sessionBean.getCompanyId(), tenderId)){
	        	show = false;
	        }
            modelMap.addAttribute("show", show);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
        	 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),status == 0 ? regretItemsForBiddingLink	: activateItemsForBiddingLink, getRegretItemPage ,tenderId, formId);
        }
        return "etender/bidder/RegretActivateItem";
    }
    
    /**
     * @author Priyanka Dalwadi
     * @param modelMap
     * @param request
     * insert/update regret/Activate Item List
     * @return
     */
    @RequestMapping(value = "/bidder/updateregretactivateitem", method = RequestMethod.POST)
    public String updateRegretActivateItem(HttpServletRequest request,ModelMap modelMap,RedirectAttributes redirectAttributes) {
        String retVal = null;
        SessionBean sessionBean = (SessionBean)request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
        int status = StringUtils.hasLength(request.getParameter("txtRegretActivateStatus")) ? Integer.parseInt(request.getParameter("txtRegretActivateStatus")) : null;
        int formId = StringUtils.hasLength(request.getParameter("hdFormId"))?Integer.parseInt(request.getParameter("hdFormId")):0;
        int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))?Integer.parseInt(request.getParameter("hdTenderId")):0;
        int companyId = sessionBean.getCompanyId();	    	     
        int userDetailId = sessionBean.getUserDetailId();    	    	     
        int bidderId = sessionBean.getUserId();
        String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
        int regretStatus = status == 1 ? 0 : 1;
        boolean success = true;
        boolean updateItemSelection = false;
        String errMsg = CommonKeywords.ERROR_MSG_KEY.toString();
        int isItemSelectionPageRequired = 0;
        
        try {
        	
        	boolean isFinalSubmissionDoneByBidder = eventBidSubmissionService.isFinalSubmissionDoneByBidder(tenderId,bidderId);
            if(isFinalSubmissionDoneByBidder ==true && status==0){
        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_item_already_bidded");
        	}
        	else{
        	String[] itemList = request.getParameterValues("chkItemId");
            List<TblTenderBidRegression> bidderItemsList = new ArrayList<TblTenderBidRegression>();
            Map<Integer,Integer> rowIds = new HashMap<Integer,Integer>();
            List<Integer> rowId = new ArrayList<Integer>();
            List<Integer> bidderItemId = new ArrayList<Integer>();
            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "submissionEndDate,isItemSelectionPageRequired");
            isItemSelectionPageRequired=  Integer.parseInt(tenderFields.get(0)[1].toString());
            List<Integer> rowIdbidded = null;
            Map<Integer,List<Integer>> tableRows = new HashMap<Integer, List<Integer>>();
            if(((Date)tenderFields.get(0)[0]).after(commonService.getServerDateTime())){
                if(eventBidSubmissionService.checkFinalSubmitDone(sessionBean.getCompanyId(), tenderId)){
                	 if(itemList!=null && itemList.length!=0){
                     	           /// All selected items
                  	                for(int i=0;i<itemList.length;i++){
                  	                	String[] regretItem = itemList[i].split("_");
                  	                	String remark = request.getParameter("txtaRemarks_"+regretItem[0]+"_"+regretItem[1].toString());
                  	                	TblTenderBidRegression tblTenderBidRegression = new TblTenderBidRegression();
                  	                	tblTenderBidRegression.setTblTender(new TblTender(tenderId));
                  	                	tblTenderBidRegression.setFormId(formId);//formId
                  	                	tblTenderBidRegression.setTableId(Integer.parseInt(regretItem[0]));//tableId
                  	                	tblTenderBidRegression.setRowId(Integer.parseInt(regretItem[1]));//rowId
                  	                	tblTenderBidRegression.setRemarks(remark);
                  	                	tblTenderBidRegression.setTblCompany(new TblCompany(companyId));
                                        tblTenderBidRegression.setTblUserLogin(new TblUserLogin(bidderId));
                                        tblTenderBidRegression.setTblUserDetail(new TblUserDetail(userDetailId));
                                        tblTenderBidRegression.setIpAddress(ipAddress);
                                        tblTenderBidRegression.setCreatedBy(userDetailId);
                                        tblTenderBidRegression.setUpdatedBy(userDetailId);
                                        tblTenderBidRegression.setIsActive(regretStatus);
                                        tblTenderBidRegression.setRegretType(2);
                                        bidderItemsList.add(tblTenderBidRegression);
                                        rowIds.put(Integer.parseInt(regretItem[0]), Integer.parseInt(regretItem[1]));
                                        rowId.add(Integer.parseInt(regretItem[1]));
                                      
                      	                if(tableRows.containsKey(tblTenderBidRegression.getTableId())){
                      	                	rowIdbidded = tableRows.get(tblTenderBidRegression.getTableId());
                      	                }else{                        
                      	                	rowIdbidded = new ArrayList<Integer>();
                      	                }
                      	                rowIdbidded.add(Integer.parseInt(regretItem[1]));
                      	                tableRows.put(tblTenderBidRegression.getTableId(), rowIdbidded);
                  	                }
                  	             
                  	                
                  	           
                  	               List<Object[]> itemselected = tenderFormService.getBidderItems(tenderId,bidderId,formId,false);
                  	               if(itemselected != null && !itemselected.isEmpty())
                  	         	   {
                  	         		 for(Object[] obj : itemselected)
                  	         		 {
                  	         			if(tableRows.get(obj[1])!=null){
                  	         			String s = tableRows.get(obj[1]).toString().replace("[",",").replace("]",",").replace(" ","");
                  	         			 if(tableRows.get(obj[1])!=null && s.contains(","+obj[2].toString()+",") && Integer.parseInt(obj[6].toString())==1 &&  Integer.parseInt(obj[3].toString())==1 && isItemSelectionPageRequired==1){
                  	         				updateItemSelection = true;
                  	         				bidderItemId.add(Integer.parseInt((obj[7].toString())));
                  	         			 }
                  	         			 }
                  	         		 }
                  	         	   }
                         	  
                         }
                }else{
                	success=false;
                	errMsg =  "redirect_error_bid_submission_done";
                }
            }else{
            	success=false;
            	errMsg = "redirect_error_bid_submission";
            }
           
            if(success){
            	
            	success = eventBidSubmissionService.updateRegretActivateItem(bidderItemsList, regretStatus,formId,companyId,rowIds,updateItemSelection,bidderItemId,tenderId);
            }
            
            if(status == 1){
                redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_item_activate" : errMsg);
            }else{
                redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_item_regret" : errMsg);
            }}
            retVal = "etender/bidder/regretActivateItem/" +status +"/"+tenderId+"/"+formId ;
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),status==0?regretItemsForBiddingLink :activateItemsForBiddingLink , status==0? setRegretItemPage : setActivateItemPage, tenderId, formId);
        }
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    /**
	 * Bid Form verfify Matrix exist on Decrypt
	 *
	 * @param tenderId
	 * @param tableId
	 * @param modelMap
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/bidder/editbid", method = RequestMethod.POST)
	public @ResponseBody String editbid(@RequestParam("bidId") String bidId, @RequestParam("formId") String formId,
			HttpServletRequest request) throws Exception {
		return tenderFormService.verifyEncryptBidMatrix(Integer.parseInt(bidId), Integer.parseInt(formId)) + "";

	}
}
