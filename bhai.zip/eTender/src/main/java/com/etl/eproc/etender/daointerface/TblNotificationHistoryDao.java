package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblNotificationHistory;
import java.util.List;

public interface TblNotificationHistoryDao  {

    public void addTblNotificationHistory(TblNotificationHistory tblNotificationHistory);

    public void deleteTblNotificationHistory(TblNotificationHistory tblNotificationHistory);

    public void updateTblNotificationHistory(TblNotificationHistory tblNotificationHistory);

    public List<TblNotificationHistory> getAllTblNotificationHistory();

    public List<TblNotificationHistory> findTblNotificationHistory(Object... values) throws Exception;

    public List<TblNotificationHistory> findByCountTblNotificationHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNotificationHistoryCount();

    public void saveUpdateAllTblNotificationHistory(List<TblNotificationHistory> tblNotificationHistorys);
}