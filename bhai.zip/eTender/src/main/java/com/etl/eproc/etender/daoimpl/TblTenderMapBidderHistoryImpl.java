package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderMapBidderHistoryDao;
import com.etl.eproc.etender.model.TblTenderMapBidderHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderMapBidderHistoryImpl extends AbcAbstractClass<TblTenderMapBidderHistory> implements TblTenderMapBidderHistoryDao {


    @Override
    public void addTblTenderMapBidderHistory(TblTenderMapBidderHistory tblTenderMapBidderHistory){
        super.addEntity(tblTenderMapBidderHistory);
    }

    @Override
    public void deleteTblTenderMapBidderHistory(TblTenderMapBidderHistory tblTenderMapBidderHistory) {
        super.deleteEntity(tblTenderMapBidderHistory);
    }

    @Override
    public void updateTblTenderMapBidderHistory(TblTenderMapBidderHistory tblTenderMapBidderHistory) {
        super.updateEntity(tblTenderMapBidderHistory);
    }

    @Override
    public List<TblTenderMapBidderHistory> getAllTblTenderMapBidderHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderMapBidderHistory> findTblTenderMapBidderHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderMapBidderHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderMapBidderHistory> findByCountTblTenderMapBidderHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderMapBidderHistory(List<TblTenderMapBidderHistory> tblTenderMapBidderHistorys){
        super.updateAll(tblTenderMapBidderHistorys);
    }
}