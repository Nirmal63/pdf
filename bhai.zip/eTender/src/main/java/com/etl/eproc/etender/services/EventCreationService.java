/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.WebUtils;
import org.zefer.cache.b;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblClientDao;
import com.etl.eproc.common.daointerface.TblEventPaymentDao;
import com.etl.eproc.common.daostoredprocedure.SpKeywordOperation;
import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientCPPPConfig;
import com.etl.eproc.common.model.TblEventPayment;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.MessageQueueService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.etender.daointerface.TblCancelRequestDao;
import com.etl.eproc.etender.daointerface.TblCommitteeDao;
import com.etl.eproc.etender.daointerface.TblEncodeDecodeHistoryDao;
import com.etl.eproc.etender.daointerface.TblTenderCurrencyDao;
import com.etl.eproc.etender.daointerface.TblTenderDao;
import com.etl.eproc.etender.daointerface.TblTenderEnvelopeDao;
import com.etl.eproc.etender.daointerface.TblTenderMatrixJsonDao;
import com.etl.eproc.etender.daointerface.TblTenderPublicKeyDao;
import com.etl.eproc.etender.daointerface.TblTenderWiseBudgetDetailsDao;
import com.etl.eproc.etender.daostoredprocedure.SPBoqDump;
import com.etl.eproc.etender.daostoredprocedure.SPGenerateL1ReportForNegotiation;
import com.etl.eproc.etender.databean.TenderDtBean;
import com.etl.eproc.etender.databean.TenderPublishBean;
import com.etl.eproc.etender.model.TblCancelRequest;
import com.etl.eproc.etender.model.TblCommittee;
import com.etl.eproc.etender.model.TblEncodeDecodeHistory;
import com.etl.eproc.etender.model.TblItemBidderMap;
import com.etl.eproc.etender.model.TblRebate;
import com.etl.eproc.etender.model.TblRebateForm;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBidderMap;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderColumn;
import com.etl.eproc.etender.model.TblTenderCurrency;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderGovColumn;
import com.etl.eproc.etender.model.TblTenderMapBidderHistory;
import com.etl.eproc.etender.model.TblTenderMatrixJson;
import com.etl.eproc.etender.model.TblTenderPublicKey;
import com.etl.eproc.etender.model.TblTenderTable;
import com.etl.eproc.etender.model.TblTenderWiseBudgetDetails;

/**
 *
 * @author vanita
 */
@Service
public class EventCreationService {

    @Autowired
    private ReloadableResourceBundleMessageSource messageSource;
    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    @Autowired
    private TblTenderDao tblTenderDao;
    @Autowired
    private CommonService commonService;
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private SpKeywordOperation spKeywordOperation;
    @Autowired
    private TblTenderCurrencyDao tblTenderCurrencyDao;
    @Autowired
    private TblCancelRequestDao tblCancelRequestDao;
    @Autowired
    private TblTenderEnvelopeDao tblTenderEnvelopeDao;
    @Autowired
    private TblEventPaymentDao tblEventPaymentDao;
    @Autowired
    private CommitteeFormationService committeeFormationService;
    @Autowired
    private TblCommitteeDao tblCommitteeDao;
    @Autowired
    private TblTenderPublicKeyDao tblTenderPublicKeyDao;
    @Autowired
    private TblTenderWiseBudgetDetailsDao tblTenderWiseBudgetDetailsDao;
    @Autowired
    private TblEncodeDecodeHistoryDao tblEncodeDecodeHistoryDao;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private MessageQueueService messageQueueService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private SPBoqDump sPBoqDump;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private EventBidderMapService eventBidderMapService;
    @Autowired
    private TblTenderMatrixJsonDao tblTenderMatrixJsonDao;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private TblClientDao tblClientDao;
    @Value("#{projectProperties['brd_etl_officer_mailid']}")
    private String brd_etl_officer_mailid;
    @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
    private String queueName;
    @Value("#{eauctionProperties['tender_moduleid']?:3}")
    private int tenderModuleId;
    @Value("#{projectProperties['tender.eventid']?:63}")
    private int tenderEventId;
    @Value("#{tenderlinkProperties['notice_and_document_upload']?:175}")
    private int tenderdocupload;
    @Value("#{tenderlinkProperties['notice_and_document_publish']?:169}")
    private int tenderPublishLink;
    @Value("#{etenderProperties['ten_brdmail_templateId']?:62}")
    private int tenBrdMailTempleteId;
    @Value("#{etenderProperties['ten_brd_regeneratemail_templateId']?:66}")
    private int tenBrdRegeMailTemplateId;
    @Value("#{etenderProperties['IsRebateFormCreated_ruleId']?:26}")
    private static final String CLIENTID = "clientId";
	
    private static final String RESULT = "result";
    private static final String TENDERID = "tenderId";
    private static final String LOCALE = "locale";
    private static final String EVENTTYPEID = "eventTypeId";
    private static final String ENVELOPETYPE = "envelopeType";
    private static final String VALIDITYPRD = "validityPeriod";
    private static final String PROCNATUREID = "procurementNatureId";
    private static final String PROJDURATION = "projectDuration";
    private static final String DOWNLOADDOC = "downloadDocument";
    private static final String TENDERVALUE = "tenderValue";
    private static final String ISSPLITPOALLOWED = "isSplitPOAllowed";
    private static final String ISITEMWISEWINNER = "isItemwiseWinner";
    private static final String SUBMISSIONMODE = "submissionMode";
    private static final String TENDERMODE = "tenderMode";
    private static final String BIDDINGTYPE = "biddingType";
    private static final String ISCONSORTIUMALLOWED = "isConsortiumAllowed";
    private static final String ISBIDWITHDRAWAL = "isBidWithdrawal";
    private static final String BIDDONGVARIANT = "biddingVariant";
    private static final String ISPREBIDMEETING = "isPreBidMeeting";
    private static final String PREBIDMODE = "preBidMode";
    private static final String PREBIDADDRESS = "preBidAddress";
    private static final String DOCSUBMISSION = "documentSubmission";
    private static final String ISWORKFLOWREQUIRED = "isWorkflowRequired";
    private static final String WORKFLOWTYPEID = "workflowTypeId";
    private static final String ISQUEANS = "isQuestionAnswer";
    private static final String DOCSTARTDATE = "documentStartDate";
    private static final String DOCENDDATE = "documentEndDate";
    private static final String SUBMISSIONSTARTDATE = "submissionStartDate";
    private static final String ISDOCFEESAPPLICABLE = "isDocfeesApplicable";
    private static final String ISSECFEESAPPLICABLE = "isSecurityfeesApplicable";
    private static final String SECFEEPAYMENTMOND = "secFeePaymentMode";
    private static final String ISEMDAPPLICABLE = "isEMDApplicable";
    private static final String EMDPAYMENTMODE = "emdPaymentMode";
    private static final String DECIMALVALUEUPTO = "decimalValueUpto";
    private static final String TBLTENDERTENDERID = "tblTender.tenderId";
    private static final String ISREGISTRATIONCHARAGES = "isRegistrationCharges";
    private static final String REGISTRATIONCHARAGESMODE = "registrationChargesMode";
    private static final String DOCFEEPAYMENTMODE = "docFeePaymentMode";
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    private static final String EMDSUBMISSIONENDDATE = "emdSubmissionEndDate";
    
    /**
     * get Yes No
     *
     * @author vanita.vaghasiya
     * @return List of selectItem with Yes No value
     * @throws Exception
     */
    public List<SelectItem> getyesNo() {
        List<SelectItem> lstYesNo = new ArrayList<SelectItem>();
        lstYesNo.add(new SelectItem(messageSource.getMessage("fields_auc_yes", null, LocaleContextHolder.getLocale()), "1"));
        lstYesNo.add(new SelectItem(messageSource.getMessage("fields_auc_no", null, LocaleContextHolder.getLocale()), "0"));
        return lstYesNo;
    }

    /**
     * Method use to get Tender Detail for given tenderId
     *
     * @author vanita.vaghasiya
     * @param tenderId
     * @return get TblTender record for particular tender id
     * @throws Exception
     */
    public TblTender getTenderMaster(int tenderId) throws Exception {

        List<TblTender> lstTblTender = tblTenderDao.findTblTender(TENDERID, Operation_enum.EQ, tenderId);
        if (lstTblTender != null && !lstTblTender.isEmpty()) {
            return lstTblTender.get(0);
        } else {
            return null;
        }

    }

    /**
     * get tblTenderEnvelope List particular tender
     *
     * @author vanita.vaghasiya
     * @param int tenderId
     * @return List<TblTenderEnvelope>
     * @throws Exception
     */
    public List<TblTenderEnvelope> getTblTenderEnvelopeList(int tenderId) throws Exception {
        return tblTenderEnvelopeDao.findTblTenderEnvelope(TBLTENDERTENDERID, Operation_enum.EQ, tenderId,"cstatus",Operation_enum.EQ,1, "tblEnvelope.envId", Operation_enum.ORDERBY, Operation_enum.ASC);
    }

    /**
     *
     * get Envelope Id List
     *
     * @author vanita.vaghasiya
     * @param int tenderId
     * @return List<Integer>
     * @throws Exception
     */
    public List<Integer> getEnvelopeIdList(int tenderId) throws Exception {
        String query = "select tbltenderenvelope.tblEnvelope.envId from TblTenderEnvelope tbltenderenvelope where tbltenderenvelope.tblTender.tenderId=:tenderId  order by tbltenderenvelope.tblEnvelope.envId";
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDERID, tenderId);
        List<Integer> lstEnvId = new ArrayList<Integer>();
        List<Object> lst = hibernateQueryDao.singleColQuery(query, parameters);
        for (Object evnId : lst) {
            lstEnvId.add(Integer.parseInt(evnId.toString()));
        }
        return lstEnvId;
    }

    /**
     * get tender Detail for view and edit auction
     *
     * @author vanita.vaghasiya
     * @param int tenderId
     * @return int
     * @throws Exception
     */
    public List<Object> getTenderDetail(int tenderId) throws Exception {
        TblTender tblTender = null;
        Map<Integer, BigDecimal> tenderCurr = new HashMap<Integer, BigDecimal>();
        List<TblTenderCurrency> lstTenderCurr = null;
        List<Object> lstTenderDetail = new ArrayList<Object>();
        tblTender = getTenderMaster(tenderId);
        List<TblTenderEnvelope> lstTblTenderEnvelope = null;
        lstTenderDetail.add(tblTender);
        lstTenderCurr = tblTenderCurrencyDao.findTblTenderCurrency(TBLTENDERTENDERID, Operation_enum.EQ, tenderId, "isActive", Operation_enum.EQ, 1);
        for (TblTenderCurrency ob : lstTenderCurr) {
            tenderCurr.put(ob.getTblCurrency().getCurrencyId(), ob.getExchangeRate());
        }
        lstTblTenderEnvelope = getTblTenderEnvelopeList(tenderId);
        lstTenderDetail.add(tenderCurr);
        lstTenderDetail.add(lstTblTenderEnvelope);

        return lstTenderDetail;
    }
    
    /**
     * get tender Detail for Corrigendum
     *
     * @author krunal.patel
     * @param int tenderId
     * @return int
     * @throws Exception
     */
    public List<Object> getTenderDetailForCorrigendum(int tenderId) throws Exception {
        TblTender tblTender = null;
        Map<Integer, BigDecimal> tenderCurr = new HashMap<Integer, BigDecimal>();
        List<TblTenderCurrency> lstTenderCurr = null;
        List<Object> lstTenderDetail = new ArrayList<Object>();
        tblTender = getTenderMaster(tenderId);
        List<TblTenderEnvelope> lstTblTenderEnvelope = null;
        lstTenderDetail.add(tblTender);
        lstTenderCurr = tblTenderCurrencyDao.findTblTenderCurrency(TBLTENDERTENDERID, Operation_enum.EQ, tenderId);
        for (TblTenderCurrency ob : lstTenderCurr) {
            tenderCurr.put(ob.getTblCurrency().getCurrencyId(), ob.getExchangeRate());
        }
        lstTblTenderEnvelope = getTblTenderEnvelopeList(tenderId);
        lstTenderDetail.add(tenderCurr);
        lstTenderDetail.add(lstTblTenderEnvelope);
        lstTenderDetail.add(lstTenderCurr);

        return lstTenderDetail;
    }

    /**
     * Add new tender
     *
     * @author vanita.vaghasiya
     * @param TblTender tblTender
     * @return boolean
     * @throws Exception
     */
    public boolean addTender(TblTender tblTender) throws Exception {
        boolean bSuccess = false;
        tblTenderDao.addTblTender(tblTender);
        bSuccess = true;
        return bSuccess;
    }

    /**
     * get Envelope name by Id
     *
     * @author vanita.vaghasiya
     * @param int envelopeId
     * @return String
     * @throws Exception
     */
    public String getEnvelopeNameById(int envelopeId) throws Exception {
        String query = "select lang" + WebUtils.getCookie(getServletRequest(), LOCALE).getValue() + " from TblEnvelope tblenvelope where tblenvelope.envId=:envelopeId";
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("envelopeId", envelopeId);
        List<Object> lst = hibernateQueryDao.singleColQuery(query, parameters);
        return lst.get(0).toString();
    }

    /**
     * Add Base tender base currency
     *
     * @author vanita.vaghasiya
     * @param TblTenderCurrency tblTenderCurrency
     * @return boolean
     * @throws Exception
     */
    public boolean addTenderBaseCurrency(TblTenderCurrency tblTenderCurrency) throws Exception {
        boolean bSuccess = false;
        tblTenderCurrencyDao.addTblTenderCurrency(tblTenderCurrency);
        bSuccess = true;
        return bSuccess;
    }

    /**
     * Add Tender currency list in case of Bidding type is Global
     *
     * @author vanita.vaghasiya
     * @param List<TblTenderCurrency> tblTenderCurrencys
     * @return boolean
     * @throws Exception
     */
    public boolean addTenderCurrencyList(List<TblTenderCurrency> tblTenderCurrencys) throws Exception {
        boolean bSuccess = false;
        tblTenderCurrencyDao.saveUpdateAllTblTenderCurrency(tblTenderCurrencys);
        bSuccess = true;
        return bSuccess;
    }

    /**
     * add form for particular envelope
     *
     * @author vanita.vaghasiya
     * @param List<TblTenderEnvelope> tblTenderEnvelopes
     * @return boolean
     * @throws Exception
     */
    public boolean addTenderEnvelopeList(List<TblTenderEnvelope> tblTenderEnvelopes) throws Exception {
        boolean bSuccess = false;
        tblTenderEnvelopeDao.saveUpdateAllTblTenderEnvelope(tblTenderEnvelopes);
        bSuccess = true;
        return bSuccess;
    }

    /**
     * Update Tender
     *
     * @author vanita.vaghasiya
     * @param TblTender tblTender
     * @return boolean
     * @throws Exception
     */
    public boolean updateTender(TblTender tblTender) throws Exception {
        boolean bSuccess = false;
        tblTenderDao.updateTblTender(tblTender);
        bSuccess = true;
        return bSuccess;
    }

    /**
     * update Tender currency isActive status
     *
     * @param int tenderId
     * @return int
     * @throws Exception
     */
    public int updateTenderCurrencyIsActiveStatus(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        return hibernateQueryDao.updateDeleteNewQuery("update TblTenderCurrency tbltendercurrency  set tbltendercurrency.isActive=0 where tbltendercurrency.tblTender.tenderId = :tenderId", var);
    }

    /**
     * get tender base currency
     *
     * @author vanita.vaghasiya
     * @param Integer tenderId
     * @return String
     * @throws Exception
     */
    public String getTenderBaseCurrency(Integer tenderId) throws Exception {
        StringBuilder strQuery = new StringBuilder();
        String currencyId = null;
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDERID, tenderId);
        strQuery.append("Select tblcurrency.currencyId from TblTenderCurrency tbltendercurrency inner join tbltendercurrency.tblCurrency tblcurrency where tbltendercurrency.tblTender.tenderId=:tenderId  and tbltendercurrency.isDefault=1 and tbltendercurrency.isActive=1");
        List<Object> lst = hibernateQueryDao.singleColQuery(strQuery.toString(), parameters);
        if (lst != null && !lst.isEmpty()) {
            currencyId = lst.get(0).toString();
        }
        return currencyId;
    }

    /**
     * To insert the details in tblTender, tblTenderCurrency,
     * tblTenderCurrencys, keywords, tblTenderEnvelopes at time of auction
     * create
     *
     * @param TblTender tblTender
     * @param TblTenderCurrency tblTenderCurrency
     * @param List<TblTenderCurrency> tblTenderCurrencys
     * @param String keywords
     * @param List<TblTenderEnvelope> tblTenderEnvelopes
     * @return boolean
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addTenderAllDetails(TblTender tblTender, TblTenderCurrency tblTenderCurrency, List<TblTenderCurrency> tblTenderCurrencys, TenderDtBean tenderDtBean, List<TblTenderEnvelope> tblTenderEnvelopes,Map<String,Integer> proceParam) throws Exception {
        boolean success = false;
        success = addTender(tblTender);
        if (tenderDtBean.getTxtaKeyword() != null) {
            List<LinkedHashMap<String, Object>> list = spKeywordOperation.executeProcedure(tenderDtBean.getTxtaKeyword(),tblTender.getTenderId(),tenderEventId, 0);
            if (list != null && !list.isEmpty() && list.get(0).get(RESULT) != null && list.get(0).get(RESULT).equals("true")) {
                success = true;
            }
        }
        if (tblTenderCurrency != null) {
            success = addTenderBaseCurrency(tblTenderCurrency);
        }
        if (tblTenderCurrencys != null && !tblTenderCurrencys.isEmpty()) {
            success = addTenderCurrencyList(tblTenderCurrencys);
        }
        if (tblTenderEnvelopes != null && !tblTenderEnvelopes.isEmpty()) {
            success = addTenderEnvelopeList(tblTenderEnvelopes);
        }
        
        /*** Code to call procedure for indent  and entry in to TenderMatrixJson**/
        if(proceParam.get("indentId") != 0){
        	Map<String,Object> returnParam = sPBoqDump.executeProcedure(proceParam.get("indentId"),tblTender.getTenderId(), proceParam.get("linkId"));
        	Object objFormId = returnParam.get("@V_formId");
			if(objFormId != null && !objFormId.toString().isEmpty()){				
				int formId = Integer.parseInt(objFormId.toString());
				List<TblTenderTable>  tblTenderTables = tenderFormService.getTenderTableByFormId(formId);
				List<TblTenderMatrixJson> matrixJsons = new ArrayList<TblTenderMatrixJson>();
				
			    for (TblTenderTable tblTenderTable : tblTenderTables) {
			        TblTenderMatrixJson matrixJson = new TblTenderMatrixJson();
			        List<TblTenderCell> tenderCells = tenderFormService.getTenderCellByTableId(tblTenderTable.getTableId(), 0);
			        matrixJson.setJsonData(tenderFormService.tenderTabletoJSON(tenderCells));
			        matrixJson.setTblTenderForm(new TblTenderForm(formId));
			        matrixJson.setTblTenderTable(tblTenderTable);
			        matrixJsons.add(matrixJson);            
			    }
			    tblTenderMatrixJsonDao.saveUpdateAllTblTenderMatrixJson(matrixJsons);
			}        	
        }
        
        /*** PT : #38138. Dump form for technical & price bid envelope on tender creation for MVP Vertical Client **/
        if(proceParam.get("isMVPVertical") != 0){
        	String ipAddress = getServletRequest().getHeader(X_FORWARDED_FOR) != null ? getServletRequest().getHeader(X_FORWARDED_FOR) : getServletRequest().getRemoteAddr();
        	for (int i = 0; i < tenderDtBean.getSelFormType().length; i++) {
        		int envId = Integer.parseInt(tenderDtBean.getSelFormType()[i]);
        		int envelopeId = tenderFormService.getEnvelopeIdByTenderIdAndEnvId(tblTender.getTenderId(), envId);
        		int formId = clientService.getFormIdFromMVPVertical(proceParam.get("clientId"), proceParam.get("moduleId"), envId, tblTender.getTenderResult());
        		String[]formIds=new String[1];
            	formIds[0]= String.valueOf(formId);
        		tenderFormService.mapTenderForm(proceParam.get("clientId"), tblTender.getTenderId(), envelopeId, formIds, ipAddress, proceParam.get("userDetailId"), 1);
        	
        		if(envId == 4){
        			int pricebidFormId = tenderFormService.getPriceBidFormId(tblTender.getTenderId(), envelopeId);
        			// For Grand Total ==> Dump Price Summary Details
        			if(tblTender.getTenderResult() == 1){
        				List<Object[]> priceSummaryDetails = tenderFormService.getPriceSummaryDetails(formId);
        				if(priceSummaryDetails != null && !priceSummaryDetails.isEmpty()){
    						TblRebate tblRebate = new TblRebate();
    						tblRebate.setReportName(priceSummaryDetails.get(0)[1].toString());
    						tblRebate.setTblTender(new TblTender(tblTender.getTenderId()));
    						tblRebate.setIsRebateForm((Byte)priceSummaryDetails.get(0)[2]);
    						tblRebate.setIpAddress(ipAddress);
    						tblRebate.setCreatedBy(abcUtility.getSessionUserDetailId(getServletRequest()));
    						
    						List<Object[]> cellDetails = tenderFormService.getPriceSumaryCellDetails(pricebidFormId, (Byte)priceSummaryDetails.get(0)[0]);
    						if(cellDetails !=null && !cellDetails.isEmpty()){
    							TblRebateForm tblRebateForm = new TblRebateForm();
        						tblRebateForm.setTblRebate(tblRebate);
        						tblRebateForm.setTblTenderForm(new TblTenderForm(pricebidFormId));
        						tblRebateForm.setTblTenderCell(new TblTenderCell((Integer)cellDetails.get(0)[2])); 
        						tblRebateForm.setIpAddress(ipAddress);
        						tblRebateForm.setCreatedBy(abcUtility.getSessionUserDetailId(getServletRequest()));
            						
        						List<TblRebateForm> tblRebateFormList = new ArrayList<TblRebateForm>();
        						tblRebateFormList.add(tblRebateForm);
        						success = tenderFormService.addRebateDetail(tblRebate, tblRebateFormList);
    						}
        				}
        			} 
        			// For ItemWise ==> Dump Governing Columns Details
        			else if(tblTender.getTenderResult() == 2){
        				int columnTypeId = (Byte)tenderFormService.getColumnTypeForGovColumn(formId).get(0)[1];
        				List<Object[]> govColumnDetails = tenderFormService.getGovColumnDetails(pricebidFormId, columnTypeId);
        				if(govColumnDetails != null && !govColumnDetails.isEmpty()){
        					TblTenderGovColumn tblTenderGovColumn = new TblTenderGovColumn();
        					tblTenderGovColumn.setTblTender(new TblTender(tblTender.getTenderId()));
        					tblTenderGovColumn.setTblTenderForm(new TblTenderForm(pricebidFormId)); 
        					tblTenderGovColumn.setTblTenderTable(new TblTenderTable((Integer)govColumnDetails.get(0)[0]));
        					tblTenderGovColumn.setTblTenderColumn(new TblTenderColumn((Integer)govColumnDetails.get(0)[1])); 
        					tblTenderGovColumn.setColumnNo((Byte)govColumnDetails.get(0)[2]); 
        					tblTenderGovColumn.setCellId(0);
        					tblTenderGovColumn.setIpAddress(ipAddress);
        					
        					List<TblTenderGovColumn> tblTenderGovColumnList = new ArrayList<TblTenderGovColumn>();
        					tblTenderGovColumnList.add(tblTenderGovColumn);
        					success = tenderFormService.addGovColumns(tblTenderGovColumnList);
        				}
        			}
        		}
        	}
        }
        return success;
    }

	/**
     * Delete tender currency at time of update of tender
     *
     * @author vanita.vaghasiya
     * @param Integer tenderId
     * @param List<Integer> lstEnvelopeId
     * @return boolean
     * @throws Exception
     */
    public boolean deleteTenderEnvelope(List<Integer> lstEnvelopeId, Integer tenderId) throws Exception {

        if (lstEnvelopeId != null && lstEnvelopeId.size() > 0) {
            StringBuilder strQuery = new StringBuilder();
            Map<String, Object> parameters = new HashMap<String, Object>();
            List<Integer> lstEnvId = new ArrayList<Integer>();
            parameters.put(TENDERID, tenderId);
            parameters.put("envIds", lstEnvelopeId);
            strQuery.append("select tbltenderenvelope.envelopeId  from TblTenderEnvelope tbltenderenvelope where tbltenderenvelope.tblTender.tenderId=:tenderId and tbltenderenvelope.tblEnvelope.envId in (:envIds)");
            List<Object> lst = hibernateQueryDao.singleColQuery(strQuery.toString(), parameters);
            if (lst != null && !lst.isEmpty()) {
                for (Object o : lst) {
                    lstEnvId.add((Integer) o);
                }
            }
            
            strQuery = new StringBuilder();
            parameters = new HashMap<String, Object>();
            parameters.put("envelopeId", lstEnvId);
            strQuery.append("delete from TblCommitteeUser where childId IN (:envelopeId) ");
            hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(), parameters);
            
            strQuery = new StringBuilder();
            strQuery.append("delete from TblCommitteeEnvelope where envelopeId IN (:envelopeId)");
            hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(), parameters);
            
            strQuery = new StringBuilder();
            strQuery.append("delete from TblRebateForm where tblTenderForm.formId in (select formId from TblTenderForm where tblTenderEnvelope.envelopeId in(:envelopeId))");
            hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(), parameters);
            
            strQuery = new StringBuilder();
            strQuery.append("delete from TblDynReportFormMap where tblTenderForm.formId in (select formId from TblTenderForm where tblTenderEnvelope.envelopeId in(:envelopeId))");
            hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(), parameters);
            
            if(lstEnvelopeId.contains(4) || lstEnvelopeId.contains(5)){
            	eventBidderMapService.deleteTenderBidderMap(tenderId);
            }
            strQuery = new StringBuilder();
            parameters = new HashMap<String, Object>();
            parameters.put(TENDERID, tenderId);
            parameters.put("envIds", lstEnvelopeId);
            strQuery.append("Delete from TblTenderEnvelope tbltenderenvelope where tbltenderenvelope.tblTender.tenderId=:tenderId and tbltenderenvelope.tblEnvelope.envId in (:envIds)");
            hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(), parameters);
           
            
        }
        return true;
    }

    /**
     * update enveloped sort order
     *
     * @author vanita.vaghasiya
     * @param int envId
     * @param int tenderId
     * @param int sortOrder
     * @return int
     * @throws Exception
     */
    public int updateEnvelopeSortOrder(int envId, int tenderId, int sortOrder) {
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDERID, tenderId);
        parameters.put("envId", envId);
        parameters.put("sortOrder", sortOrder);
        String query = "update TblTenderEnvelope tbltenderenvelope set tbltenderenvelope.sortOrder=:sortOrder where tbltenderenvelope.tblTender.tenderId=:tenderId and tbltenderenvelope.tblEnvelope.envId=:envId";
        return hibernateQueryDao.updateDeleteNewQuery(query, parameters);
    }

    /**
     * this method call at edition time of tender
     *
     * @param TblTender tblTender
     * @param TblTenderCurrency tblTenderCurrency
     * @param List<TblTenderCurrency> tblTenderCurrencys
     * @param String keywords
     * @param List<TblTenderEnvelope> tblTenderEnvelopes
     * @return
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean updateTenderAllDetails(TblTender tblTender, TblTenderCurrency tblTenderCurrency, List<TblTenderCurrency> tblTenderCurrencys, TenderDtBean tenderDtBean, List<TblTenderEnvelope> tblTenderEnvelopes, List<Integer> lstEnvelopeId, Map<String,Integer> proceParam) throws Exception {
        boolean success = false;
        success = updateTender(tblTender);
        List<TblTenderEnvelope> lsttblTenderEnvelope = new ArrayList<TblTenderEnvelope>();
        if (success && tenderDtBean.getTxtaKeyword() != null) {
            List<LinkedHashMap<String, Object>> list = spKeywordOperation.executeProcedure(tenderDtBean.getTxtaKeyword(),tblTender.getTenderId(),tenderEventId,1);
            if (list != null && !list.isEmpty() && list.get(0).get(RESULT) != null && list.get(0).get(RESULT).equals("true")) {
                success = true;
            }
        }
        updateTenderCurrencyIsActiveStatus(tblTender.getTenderId());
        if (tblTenderCurrency != null) {
            success = addTenderBaseCurrency(tblTenderCurrency);
        }
        if (tblTenderCurrencys != null && !tblTenderCurrencys.isEmpty()) {
            success = addTenderCurrencyList(tblTenderCurrencys);
        }
        /* List<Object> nonDeleteEnv = getCommitteeEnvelope(tblTender.getTenderId());
         for (int i = 0; i < nonDeleteEnv.size(); i++) {
         for (int j = 0; j < lstEnvelopeId.size(); j++) {
         if (Integer.parseInt(nonDeleteEnv.get(i).toString()) == lstEnvelopeId.get(j)) {
         lstEnvelopeId.remove(j);
         j--;
         }
         }
         }
        nonDeleteEnv = getFormEnvelope(tblTender.getTenderId());
         for (int i = 0; i < nonDeleteEnv.size(); i++) {
         for (int j = 0; j < lstEnvelopeId.size(); j++) {
         if (Integer.parseInt(nonDeleteEnv.get(i).toString()) == lstEnvelopeId.get(j)) {
         lstEnvelopeId.remove(j);
         j--;
         }
         }
         }*/
        success = deleteTenderEnvelope(lstEnvelopeId, tblTender.getTenderId());
        lstEnvelopeId=new ArrayList<Integer>();
        lstEnvelopeId = getEnvelopeIdList(tblTender.getTenderId());
        for (TblTenderEnvelope tblTenderEnvelope : tblTenderEnvelopes) {
            if (!lstEnvelopeId.contains(tblTenderEnvelope.getTblEnvelope().getEnvId())) {
                lsttblTenderEnvelope.add(tblTenderEnvelope);
            }
        }

        if (success && lsttblTenderEnvelope != null && !lsttblTenderEnvelope.isEmpty()) {
            success = addTenderEnvelopeList(lsttblTenderEnvelope);
        }
        lstEnvelopeId = getEnvelopeIdList(tblTender.getTenderId());
        for (int i = 0; i < lstEnvelopeId.size(); i++) {
            updateEnvelopeSortOrder(lstEnvelopeId.get(i), tblTender.getTenderId(), i + 1);
        }
        
        /*** Start Code to delete entry for TblTenderGovColumn if tender is grand total else delete entry in TblRebate **/
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tblTender.getTenderId());
        if(tblTender.getIsItemwiseWinner()==1 || tblTender.getIsItemwiseWinner()==2){
        	query.append("delete from TblRebate tblrebate where tblrebate.tblTender.tenderId=:tenderId");	
        }else{
        	query.append("delete from TblTenderGovColumn tblTenderGovColumn where tblTenderGovColumn.tblTender.tenderId=:tenderId");	
        }
        hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
        /*** End Code to delete entry for TblTenderGovColumn if tender is grand total else delete entry in TblRebate **/
        
        
        /*** PT : #38138. Dump form for technical & price bid envelope on tender creation for MVP Vertical Client **/
        if(proceParam.get("isMVPVertical") != 0){
        	String ipAddress = getServletRequest().getHeader(X_FORWARDED_FOR) != null ? getServletRequest().getHeader(X_FORWARDED_FOR) : getServletRequest().getRemoteAddr();
        	if(proceParam.get("oldTenderResult")!=tblTender.getTenderResult()){
    			List<Object[]> listTenderForms=tenderFormService.getTenderFormByTenderId(tblTender.getTenderId());
    			if(listTenderForms!=null && !listTenderForms.isEmpty()){
    				for(Object[] obj:listTenderForms){
    					tenderFormService.deleteForm(tblTender.getTenderId(),Integer.parseInt(obj[1].toString()));
    				}
    			}
    		}
        	for (int i = 0; i < tenderDtBean.getSelFormType().length; i++) {
        		int envId = Integer.parseInt(tenderDtBean.getSelFormType()[i]);
        		int envelopeId = tenderFormService.getEnvelopeIdByTenderIdAndEnvId(tblTender.getTenderId(), envId);
        		int formId = clientService.getFormIdFromMVPVertical(proceParam.get("clientId"), proceParam.get("moduleId"), envId, tblTender.getTenderResult());
        		String[]formIds=new String[1];
            	formIds[0]= String.valueOf(formId);
            	// check tender form exist for given tenderId & envelopeId
            	if(!tenderFormService.checkFormExist(tblTender.getTenderId(), envelopeId)){
            		tenderFormService.mapTenderForm(proceParam.get("clientId"), tblTender.getTenderId(), envelopeId, formIds, ipAddress, proceParam.get("userDetailId"), 1);
            	
            		if(envId == 4){
            			int pricebidFormId = tenderFormService.getPriceBidFormId(tblTender.getTenderId(), envelopeId);
            			// For Grand Total ==> Dump Price Summary Details
            			if(tblTender.getTenderResult() == 1){
            				List<Object[]> priceSummaryDetails = tenderFormService.getPriceSummaryDetails(formId);
            				if(priceSummaryDetails != null && !priceSummaryDetails.isEmpty()){
        						TblRebate tblRebate = new TblRebate();
        						tblRebate.setReportName(priceSummaryDetails.get(0)[1].toString());
        						tblRebate.setTblTender(new TblTender(tblTender.getTenderId()));
        						tblRebate.setIsRebateForm((Byte)priceSummaryDetails.get(0)[2]);
        						tblRebate.setIpAddress(ipAddress);
        						tblRebate.setCreatedBy(abcUtility.getSessionUserDetailId(getServletRequest()));
        						
        						List<Object[]> cellDetails = tenderFormService.getPriceSumaryCellDetails(pricebidFormId, (Byte)priceSummaryDetails.get(0)[0]);
        						if(cellDetails !=null && !cellDetails.isEmpty()){
        							TblRebateForm tblRebateForm = new TblRebateForm();
            						tblRebateForm.setTblRebate(tblRebate);
            						tblRebateForm.setTblTenderForm(new TblTenderForm(pricebidFormId));
            						tblRebateForm.setTblTenderCell(new TblTenderCell((Integer)cellDetails.get(0)[2])); 
            						tblRebateForm.setIpAddress(ipAddress);
            						tblRebateForm.setCreatedBy(abcUtility.getSessionUserDetailId(getServletRequest()));
                						
            						List<TblRebateForm> tblRebateFormList = new ArrayList<TblRebateForm>();
            						tblRebateFormList.add(tblRebateForm);
            						success = tenderFormService.addRebateDetail(tblRebate, tblRebateFormList);
        						}
            				}
            			} 
            			// For ItemWise ==> Dump Governing Columns Details
            			else if(tblTender.getTenderResult() == 2){
            				int columnTypeId = (Byte)tenderFormService.getColumnTypeForGovColumn(formId).get(0)[1];
            				List<Object[]> govColumnDetails = tenderFormService.getGovColumnDetails(pricebidFormId, columnTypeId);
            				if(govColumnDetails != null && !govColumnDetails.isEmpty()){
            					TblTenderGovColumn tblTenderGovColumn = new TblTenderGovColumn();
            					tblTenderGovColumn.setTblTender(new TblTender(tblTender.getTenderId()));
            					tblTenderGovColumn.setTblTenderForm(new TblTenderForm(pricebidFormId)); 
            					tblTenderGovColumn.setTblTenderTable(new TblTenderTable((Integer)govColumnDetails.get(0)[0]));
            					tblTenderGovColumn.setTblTenderColumn(new TblTenderColumn((Integer)govColumnDetails.get(0)[1])); 
            					tblTenderGovColumn.setColumnNo((Byte)govColumnDetails.get(0)[2]); 
            					tblTenderGovColumn.setCellId(0);
            					tblTenderGovColumn.setIpAddress(ipAddress);
            					
            					List<TblTenderGovColumn> tblTenderGovColumnList = new ArrayList<TblTenderGovColumn>();
            					tblTenderGovColumnList.add(tblTenderGovColumn);
            					success = tenderFormService.addGovColumns(tblTenderGovColumnList);
            				}
            			}
            		}
            	}
        	}
        }
        return success;
    }

    /**
     * get Tender Currency list for particular tender
     *
     * @author vanita.vaghasiya
     * @param int tenderId
     * @return List<Object[]>
     * @throws Exception Updated By Nirav Modi added isDefault etc
     */
    public List<Object[]> getTenderCurrencyData(int tenderId) throws Exception {
    	String lang  = WebUtils.getCookie(getServletRequest(), "locale") != null  ? WebUtils.getCookie(getServletRequest(), "locale").getValue() : "1";   //exception throw
        StringBuilder strQuery = new StringBuilder();
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDERID, tenderId);
        strQuery.append("select tbltendercurrency.tenderCurrencyId, tblcurrency.lang").append(lang).append(",tbltendercurrency.exchangeRate,tbltendercurrency.isDefault,tbltender.biddingType from TblTender tbltender  ");
        strQuery.append(" inner join tbltender.tblTenderCurrency tbltendercurrency with tbltendercurrency.isActive=1");
        strQuery.append(" inner join tbltendercurrency.tblCurrency tblcurrency  ");
        strQuery.append(" where tbltender.tenderId=:tenderId ");
        return hibernateQueryDao.createNewQuery(strQuery.toString(), parameters);
    }

    /**
     * get list of envelopeId where envelope include in committee of tender
     *
     * @param tenderId
     * @List<Object>
     */
    public List<Object> getCommitteeEnvelope(int tenderId) {
        StringBuilder strQuery = new StringBuilder();
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDERID, tenderId);
        strQuery.append("select tbltenderenvelope.tblEnvelope.envId from com.etl.eproc.etender.model.TblCommittee tblcommittee ");
        strQuery.append(" inner join tblcommittee.tblTender tbltender  inner join tblcommittee.tblCommitteeUser tblcommitteeuser");
        strQuery.append(" inner join tbltender.tblTenderEnvelope tbltenderenvelope");
        strQuery.append(" where tbltender.tenderId=:tenderId  and tblcommittee.committeeType in (1,2) and  tbltenderenvelope.envelopeId=tblcommitteeuser.childId");
        return hibernateQueryDao.getSingleColQuery(strQuery.toString(), parameters);
    }

    /**
     * get list of envelopeId where envelope include in form of tender
     *
     * @param tenderId
     * @List<Object>
     */
    public List<Object> getFormEnvelope(int tenderId) {
        StringBuilder strQuery = new StringBuilder();
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDERID, tenderId);
        strQuery.append("select tbltenderenvelope.tblEnvelope.envId from TblTenderForm tbltenderform inner join tbltenderform.tblTenderEnvelope tbltenderenvelope where tbltenderform.tblTender.tenderId=:tenderId");
        return hibernateQueryDao.getSingleColQuery(strQuery.toString(), parameters);
    }

    /**
     * get get base currency name , department name officer name for tender
     *
     * @author vanita.vaghasiya
     * @param int tenderId
     * @return List<Object[]>
     * @throws Exception
     */
    public List<Object[]> getTenderSummeryData(int tenderId) throws Exception {
        StringBuilder strQuery = new StringBuilder();
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDERID, tenderId);
        strQuery.append(" select tbltender.tblDepartment.deptName,tbluserlogin.userName,tbltendercurrency.tblCurrency.lang1,tbltender.officerUserDetailId ");
        strQuery.append(" from TblTender tbltender, TblUserLogin tbluserlogin ");
        strQuery.append(" inner join tbltender.tblDepartment tbldepartment ");
        strQuery.append(" inner join tbltender.tblTenderCurrency tbltendercurrency WITH  tbltendercurrency.isDefault = 1 and tbltendercurrency.isActive = 1 ");
        strQuery.append(" where tbltender.tenderId = :tenderId and tbltender.officerId = tbluserlogin.userId  ");
        return hibernateQueryDao.createNewQuery(strQuery.toString(), parameters);
    }

    /**
     * get Tender Data for View
     *
     * @author vanita.vaghasiya
     * @param tenderId
     * @param hashMap
     * @param clientId
     * @throws Exception
     */
    public void tenderView(int tenderId, HashMap hashMap, int clientId) throws Exception {
        List<Object> lstTenderDetail = null;
        TblTender tblTender = null;
        lstTenderDetail = getTenderDetail(tenderId);
        tblTender = (TblTender) lstTenderDetail.get(0);
        List<TblTenderEnvelope> lstTblTenderEnvelope = null;
        List<Object[]> lstTenderCurrency = getTenderCurrencyData(tenderId);
        List<Object[]> lst = getTenderSummeryData(tblTender.getTenderId());
        String userName="";
        if(tblTender.getOfficerUserDetailId()>0) {
        	userName=commonService.getUserDetailById(tblTender.getOfficerUserDetailId()).getUserName();
        }
        if(!lst.isEmpty() && lst!=null){
        	Object[] ob = lst.get(0);
        	hashMap.put("deptName", ob[0]);
        	 hashMap.put("baseCurrencyName", ob[2]);
        	 hashMap.put("officerName",tblTender.getOfficerUserDetailId() == 0 ? ob[1] : userName);
        }
        hashMap.put("tblTender", tblTender);
        //Bug: 19183 if other is selected then it should display value for other also.	
        String eprocNature = commonService.getProcurementNatureName(tblTender.getTblProcurementNature().getProcurementNatureId());
        if(tblTender.getTblProcurementNature().getProcurementNatureId() == 5 && tblTender.getOtherProcurementNature() != null && !tblTender.getOtherProcurementNature().equals(""))
        {
        	eprocNature += " - "+tblTender.getOtherProcurementNature();
        }
        hashMap.put("eprocNature", eprocNature);
        
       
        hashMap.put("lstTenderCurrency", lstTenderCurrency);
        hashMap.put("keyword", commonService.getKeywords(tenderId, tenderEventId));
        lstTblTenderEnvelope = getTblTenderEnvelopeList(tenderId);
        /* start changes Bug Id#31474*/
        if(lstTblTenderEnvelope!=null && !lstTblTenderEnvelope.isEmpty()){
        	if(lstTblTenderEnvelope.size()==1 && lstTblTenderEnvelope.get(0).getTblEnvelope().getEnvId()==4){
        		hashMap.put("isReqSecPartnerForm",true);
        	}else{
        		hashMap.put("isReqSecPartnerForm",false);
        	}
        }
        /* end changes Bug Id#31474*/
        hashMap.put("lstTblTenderEnvelope", lstTblTenderEnvelope);
        hashMap.put("workflowList", commonService.getWorkflowList());
        hashMap.put("corrigendumCount", tblTender.getCorrigendumCount());
        
        int moduleId = 3;
        List<Object[]> lstdocFeesPaymentType = getEventPaymentType(tenderId,clientId,tblTender.getDocFeePaymentMode(), 1 ,moduleId);
        List<Object[]> lstsecPaymentType = getEventPaymentType(tenderId,clientId,tblTender.getSecFeePaymentMode(), 10, moduleId);
        List<Object[]> lstemdPaymentType = getEventPaymentType(tenderId,clientId,tblTender.getEmdPaymentMode(), 2, moduleId);
        List<Object[]> lstregPaymentType = getEventPaymentType(tenderId,clientId,tblTender.getRegistrationChargesMode(),8, moduleId);
        hashMap.put("lstdocFeesPaymentType",abcUtility.converObjectArrayToCommas(lstdocFeesPaymentType,1,2));
        hashMap.put("lstsecPaymentType",abcUtility.converObjectArrayToCommas(lstsecPaymentType,1,2));
        hashMap.put("lstemdPaymentType",abcUtility.converObjectArrayToCommas(lstemdPaymentType,1,2));
        hashMap.put("lstregPaymentType",abcUtility.converObjectArrayToCommas(lstregPaymentType,1,2));
        
    }

    /**
     * get event type for particular domain
     *
     * @param int clientId
     * @return List<Object[]>
     */
    public List<Object[]> getEventType(int clientId) {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(CLIENTID, clientId);
        var.put("tenderModuleId", tenderModuleId);
        query.append("select tbleventtype.eventTypeId,tbleventtype.lang").append(WebUtils.getCookie(getServletRequest(), LOCALE).getValue()).append(" from TblEventType tbleventtype");
        query.append(" inner join tbleventtype.tblModule  tblmodule with tblmodule.moduleId=:tenderModuleId");
        query.append(" inner join tbleventtype.tblClientEventType tblclienteventtype with tblclienteventtype.isActive=1");
        query.append(" inner join  tblclienteventtype.tblClient tblclient with tblclient.clientId=:clientId order by tbleventtype.lang").append(WebUtils.getCookie(getServletRequest(), "locale").getValue());
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     * get Form type
     *
     * @param int tenderId
     * @return List<Object[]>
     */
    public List<Object[]> getFormType(int tenderId) {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        String query = "select tblenvelope.envId,tblenvelope.lang" + WebUtils.getCookie(getServletRequest(), "locale").getValue() + ",tbltenderenvelope.envelopeId from TblEnvelope tblenvelope left join tblenvelope.tblTenderEnvelope tbltenderenvelope with tbltenderenvelope.tblTender.tenderId=:tenderId";
        return hibernateQueryDao.createNewQuery(query, var);
    }
    
    public List<Object[]> getFormTypeForMVPVertical(int tenderId) {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        String query = "select tblenvelope.envId,tblenvelope.lang" + WebUtils.getCookie(getServletRequest(), "locale").getValue() + ",tbltenderenvelope.envelopeId from TblEnvelope tblenvelope left join tblenvelope.tblTenderEnvelope tbltenderenvelope with tbltenderenvelope.tblTender.tenderId=:tenderId WHERE tblenvelope.envId in (3,4)";
        return hibernateQueryDao.createNewQuery(query, var);
    }

    /**
     * get field configuration according admin side configuration
     *
     * @param int clientId
     * @param int eventTypeId
     * @return List<Object[]>
     * @throws Exception
     */
    public List<Object[]> getClientConfigurationFields(int clientId, int eventTypeId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId", clientId);
        var.put(EVENTTYPEID, eventTypeId);
        StringBuilder query = new StringBuilder(" select tblcustomparameter.isShown, tblfield.controlType, tblfield.fieldGroupId, tblcustomparameter.field, ");
        query.append(" tblcustomparameter.fieldValue, tblfield.query, tblcustomparameter.fieldLabel, tblfield.controlValue, tblfield.defaultValue, ");
        query.append(" tblcustomparameter.customParamId, tblcustomparameter.tblEventType.eventTypeId, tblcustomparameter.tblField.fieldId");
        query.append(" from  TblCustomParameter tblcustomparameter  inner join  tblcustomparameter.tblField tblfield ");
        query.append(" where tblfield.isActive = 1 and tblcustomparameter.tblClient.clientId=:clientId and tblcustomparameter.tblEventType.eventTypeId=:eventTypeId ");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    public List<Object[]> getClientConfigurationFields(int clientId, int eventTypeId,List<Integer> fieldIds) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId", clientId);
        var.put(EVENTTYPEID, eventTypeId);
        var.put("fieldId", fieldIds);
        StringBuilder query = new StringBuilder("select isnull(TC.isShown, 1), TF.controlType, TF.fieldGroupId, isnull(TC.field, TF.fieldName), ");
        query.append("isnull(TC.fieldValue, ''), TF.query, isnull(TC.fieldLabel, TF.fieldLabel), TF.controlValue, TF.defaultValue, ");
        query.append("isnull(TC.customParamId, 0), TF.tblEventType.eventTypeId, TF.fieldId, TF.fieldName, TF.hasDefaultValue, TF.description from TblField TF");
        query.append(" inner join TF.tblCustomParameter TC with TC.tblClient.clientId=:clientId ");
        query.append(" where TF.isActive=1 and TF.tblEventType.eventTypeId=:eventTypeId and TC.tblEventType.eventTypeId=:eventTypeId and TF.fieldId in (:fieldId) order by  TF.fieldGroupId , TF.sortOrder ");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     * get Office by Department for particular domain
     *
     * @param Integer deptId
     * @param Integer clientId
     * @return List<Object[]>
     * @throws Exception
     */
    public List<Object[]> getDepartmentOfficer(Integer deptId, Integer clientId) throws Exception {
        List<Object[]> list = null;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(CLIENTID, clientId);
        var.put("deptId", deptId);
        query.append("select tbluserlogin.userId, tbluserlogin.userName from TblUserLogin tbluserlogin inner join tbluserlogin.tblOfficer tblofficer with tblofficer.tblClient.clientId = :clientId and tblofficer.cstatus = 1 where tblofficer.tblDepartment.deptId = :deptId order by tbluserlogin.userName");
        list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return list;
    }

    /**
     * get servlet request
     *
     * @return HttpServletRequest
     */
    public HttpServletRequest getServletRequest() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return attr.getRequest();
    }

    /**
     * Set administrator side configure value in Tender Model map
     *
     * @param TenderDtBean tenderDtBean
     * @param Map<String, Object> configParam
     * @param Map<String, Object> hideConfigParam
     */
    public void setCustConfigTenderData(TenderDtBean tenderDtBean, Map<String, Object> configParam, Map<String, Object> hideConfigParam) {
        if (configParam.containsKey(EVENTTYPEID)) {
            tenderDtBean.setSelEventType(Integer.parseInt(configParam.get(EVENTTYPEID).toString()));
        } else if (hideConfigParam.containsKey(EVENTTYPEID)) {
            tenderDtBean.setSelEventType(Integer.parseInt(hideConfigParam.get(EVENTTYPEID).toString()));
        }
        if (configParam.containsKey(ENVELOPETYPE)) {
            tenderDtBean.setSelEnvelopeType(Integer.parseInt(configParam.get(ENVELOPETYPE).toString()));
        } else if (hideConfigParam.containsKey(ENVELOPETYPE)) {
            tenderDtBean.setSelEnvelopeType(Integer.parseInt(hideConfigParam.get(ENVELOPETYPE).toString()));
        }
        if (configParam.containsKey(VALIDITYPRD)) {
            tenderDtBean.setTxtValidityPeriod(configParam.get(VALIDITYPRD).toString());
        } else if (hideConfigParam.containsKey(VALIDITYPRD)) {
            tenderDtBean.setTxtValidityPeriod(hideConfigParam.get(VALIDITYPRD).toString());
        }
        if (configParam.containsKey(PROCNATUREID)) {
            tenderDtBean.setSelProcurementNatureId(Integer.parseInt(configParam.get(PROCNATUREID).toString()));
        } else if (hideConfigParam.containsKey(PROCNATUREID)) {
            tenderDtBean.setSelProcurementNatureId(Integer.parseInt(hideConfigParam.get(PROCNATUREID).toString()));
        }
        if (configParam.containsKey(PROJDURATION)) {
            tenderDtBean.setTxtProjectDuration(configParam.get(PROJDURATION).toString());
        } else if (hideConfigParam.containsKey(PROJDURATION)) {
            tenderDtBean.setTxtProjectDuration(hideConfigParam.get(PROJDURATION).toString());
        }
        if (configParam.containsKey(DOWNLOADDOC)) {
            tenderDtBean.setSelDownloadDocument(Integer.parseInt(configParam.get(DOWNLOADDOC).toString()));
        } else if (hideConfigParam.containsKey(DOWNLOADDOC)) {
            tenderDtBean.setSelDownloadDocument(Integer.parseInt(hideConfigParam.get(DOWNLOADDOC).toString()));
        }
        if (configParam.containsKey(TENDERVALUE)) {
            tenderDtBean.setTxtTenderValue(configParam.get(TENDERVALUE).toString());
        } else if (hideConfigParam.containsKey(TENDERVALUE)) {
            tenderDtBean.setTxtTenderValue(hideConfigParam.get(TENDERVALUE).toString());
        }
        if (configParam.containsKey(ISSPLITPOALLOWED)) {
            tenderDtBean.setSelIsSplitPOAllowed(Integer.parseInt(configParam.get(ISSPLITPOALLOWED).toString()));
        } else if (hideConfigParam.containsKey(ISSPLITPOALLOWED)) {
            tenderDtBean.setSelIsSplitPOAllowed(Integer.parseInt(hideConfigParam.get(ISSPLITPOALLOWED).toString()));
        }
        if (configParam.containsKey(ISITEMWISEWINNER)) {
            tenderDtBean.setSelIsItemwiseWinner(Integer.parseInt(configParam.get(ISITEMWISEWINNER).toString()));
        } else if (hideConfigParam.containsKey(ISITEMWISEWINNER)) {
            tenderDtBean.setSelIsItemwiseWinner(Integer.parseInt(hideConfigParam.get(ISITEMWISEWINNER).toString()));
        }
        if (configParam.containsKey(SUBMISSIONMODE)) {
            tenderDtBean.setSelSubmissionMode(Integer.parseInt(configParam.get(SUBMISSIONMODE).toString()));
        } else if (hideConfigParam.containsKey(SUBMISSIONMODE)) {
            tenderDtBean.setSelSubmissionMode(Integer.parseInt(hideConfigParam.get(SUBMISSIONMODE).toString()));
        }
        if (configParam.containsKey(TENDERMODE)) {
            tenderDtBean.setSelTenderMode(Integer.parseInt(configParam.get(TENDERMODE).toString()));
        } else if (hideConfigParam.containsKey(TENDERMODE)) {
            tenderDtBean.setSelTenderMode(Integer.parseInt(hideConfigParam.get(TENDERMODE).toString()));
        }
        if (configParam.containsKey(BIDDINGTYPE)) {
            tenderDtBean.setSelBiddingType(Integer.parseInt(configParam.get(BIDDINGTYPE).toString()));
        } else if (hideConfigParam.containsKey(BIDDINGTYPE)) {
            tenderDtBean.setSelBiddingType(Integer.parseInt(hideConfigParam.get(BIDDINGTYPE).toString()));
        }
        if (configParam.containsKey(ISCONSORTIUMALLOWED)) {
            tenderDtBean.setSelIsConsortiumAllowed(Integer.parseInt(configParam.get(ISCONSORTIUMALLOWED).toString()));
        } else if (hideConfigParam.containsKey(ISCONSORTIUMALLOWED)) {
            tenderDtBean.setSelIsConsortiumAllowed(Integer.parseInt(hideConfigParam.get(ISCONSORTIUMALLOWED).toString()));
        }
        if (configParam.containsKey(ISBIDWITHDRAWAL)) {
            tenderDtBean.setSelIsBidWithdrawal(Integer.parseInt(configParam.get(ISBIDWITHDRAWAL).toString()));
        } else if (hideConfigParam.containsKey(ISBIDWITHDRAWAL)) {
            tenderDtBean.setSelIsBidWithdrawal(Integer.parseInt(hideConfigParam.get(ISBIDWITHDRAWAL).toString()));
        }
        if (configParam.containsKey(BIDDONGVARIANT)) {
            tenderDtBean.setSelBiddingVariant(Integer.parseInt(configParam.get(BIDDONGVARIANT).toString()));
        } else if (hideConfigParam.containsKey(BIDDONGVARIANT)) {
            tenderDtBean.setSelBiddingVariant(Integer.parseInt(hideConfigParam.get(BIDDONGVARIANT).toString()));
        }
        if (configParam.containsKey(ISPREBIDMEETING)) {
            tenderDtBean.setSelIsPreBidMeeting(Integer.parseInt(configParam.get(ISPREBIDMEETING).toString()));
        } else if (hideConfigParam.containsKey(ISPREBIDMEETING)) {
            tenderDtBean.setSelIsPreBidMeeting(Integer.parseInt(hideConfigParam.get(ISPREBIDMEETING).toString()));
        }
        if (configParam.containsKey(PREBIDMODE)) {
            tenderDtBean.setSelPreBidMode(Integer.parseInt(configParam.get(PREBIDMODE).toString()));
        } else if (hideConfigParam.containsKey(PREBIDMODE)) {
            tenderDtBean.setSelPreBidMode(Integer.parseInt(hideConfigParam.get(PREBIDMODE).toString()));
        }
        if (configParam.containsKey(PREBIDADDRESS)) {
            tenderDtBean.setTxtaPreBidAddress(configParam.get(PREBIDADDRESS).toString());
        } else if (hideConfigParam.containsKey(PREBIDADDRESS)) {
            tenderDtBean.setTxtaPreBidAddress(hideConfigParam.get(PREBIDADDRESS).toString());
        }
        if (configParam.containsKey(DOCSUBMISSION)) {
            tenderDtBean.setTxtaDocumentSubmission(configParam.get(DOCSUBMISSION).toString());
        } else if (hideConfigParam.containsKey(DOCSUBMISSION)) {
            tenderDtBean.setTxtaDocumentSubmission(hideConfigParam.get(DOCSUBMISSION).toString());
        }
        if (configParam.containsKey(ISWORKFLOWREQUIRED)) {
            tenderDtBean.setSelIsWorkflowRequired(Integer.parseInt(configParam.get(ISWORKFLOWREQUIRED).toString()));
        } else if (hideConfigParam.containsKey(ISWORKFLOWREQUIRED)) {
            tenderDtBean.setSelIsWorkflowRequired(Integer.parseInt(hideConfigParam.get(ISWORKFLOWREQUIRED).toString()));
        }
        if (configParam.containsKey(WORKFLOWTYPEID)) {
            tenderDtBean.setSelWorkflowType(Integer.parseInt(configParam.get(WORKFLOWTYPEID).toString()));
        } else if (hideConfigParam.containsKey(WORKFLOWTYPEID)) {
            tenderDtBean.setSelWorkflowType(Integer.parseInt(hideConfigParam.get(WORKFLOWTYPEID).toString()));
        }
        if (configParam.containsKey(ISQUEANS)) {
            tenderDtBean.setSelIsQuestionAnswer(Integer.parseInt(configParam.get(ISQUEANS).toString()));
        } else if (hideConfigParam.containsKey(ISQUEANS)) {
            tenderDtBean.setSelIsQuestionAnswer(Integer.parseInt(hideConfigParam.get(ISQUEANS).toString()));
        }
        if (configParam.containsKey(DOCSTARTDATE)) {
            tenderDtBean.setTxtDocumentStartDate(configParam.get(DOCSTARTDATE).toString());
        } else if (hideConfigParam.containsKey(DOCSTARTDATE)) {
            tenderDtBean.setTxtDocumentStartDate(hideConfigParam.get(DOCSTARTDATE).toString());
        }
        if (configParam.containsKey(DOCENDDATE)) {
            tenderDtBean.setTxtDocumentEndDate(configParam.get(DOCENDDATE).toString());
        } else if (hideConfigParam.containsKey(DOCENDDATE)) {
            tenderDtBean.setTxtDocumentEndDate(hideConfigParam.get(DOCENDDATE).toString());
        }
        if (configParam.containsKey(SUBMISSIONSTARTDATE)) {
            tenderDtBean.setTxtSubmissionStartDate(configParam.get(SUBMISSIONSTARTDATE).toString());
        } else if (hideConfigParam.containsKey(SUBMISSIONSTARTDATE)) {
            tenderDtBean.setTxtSubmissionStartDate(hideConfigParam.get(SUBMISSIONSTARTDATE).toString());
        }
        if (configParam.containsKey(ISDOCFEESAPPLICABLE)) {
            tenderDtBean.setSelIsDocfeesApplicable(Integer.parseInt(configParam.get(ISDOCFEESAPPLICABLE).toString()));
        } else if (hideConfigParam.containsKey(ISDOCFEESAPPLICABLE)) {
            tenderDtBean.setSelIsDocfeesApplicable(Integer.parseInt(hideConfigParam.get(ISDOCFEESAPPLICABLE).toString()));
        }
        // PT: 20681
        if (configParam.containsKey(ISREGISTRATIONCHARAGES)) {
            tenderDtBean.setSelIsRegistrationCharges(Integer.parseInt(configParam.get(ISREGISTRATIONCHARAGES).toString()));
        } else if (hideConfigParam.containsKey(ISREGISTRATIONCHARAGES)) {
            tenderDtBean.setSelIsRegistrationCharges(Integer.parseInt(hideConfigParam.get(ISREGISTRATIONCHARAGES).toString()));
        }
        
        if (configParam.containsKey(REGISTRATIONCHARAGESMODE)) {
            tenderDtBean.setSelRegistrationChargesMode(Integer.parseInt(configParam.get(REGISTRATIONCHARAGESMODE).toString()));
        } else if (hideConfigParam.containsKey(REGISTRATIONCHARAGESMODE)) {
        	tenderDtBean.setSelRegistrationChargesMode(Integer.parseInt(hideConfigParam.get(REGISTRATIONCHARAGESMODE).toString()));
        }
        
        if (configParam.containsKey(ISSECFEESAPPLICABLE)) {
            tenderDtBean.setSelIsSecurityfeesApplicable(Integer.parseInt(configParam.get(ISSECFEESAPPLICABLE).toString()));
        } else if (hideConfigParam.containsKey(ISSECFEESAPPLICABLE)) {
            tenderDtBean.setSelIsSecurityfeesApplicable(Integer.parseInt(hideConfigParam.get(ISSECFEESAPPLICABLE).toString()));
        }
        if (configParam.containsKey(SECFEEPAYMENTMOND)) {
            tenderDtBean.setSelSecFeePaymentMode(Integer.parseInt(configParam.get(SECFEEPAYMENTMOND).toString()));
        } else if (hideConfigParam.containsKey(SECFEEPAYMENTMOND)) {
            tenderDtBean.setSelSecFeePaymentMode(Integer.parseInt(hideConfigParam.get(SECFEEPAYMENTMOND).toString()));
        }
        if (configParam.containsKey(ISEMDAPPLICABLE)) {
            tenderDtBean.setSelIsEMDApplicable(Integer.parseInt(configParam.get(ISEMDAPPLICABLE).toString()));
        } else if (hideConfigParam.containsKey(ISEMDAPPLICABLE)) {
            tenderDtBean.setSelIsEMDApplicable(Integer.parseInt(hideConfigParam.get(ISEMDAPPLICABLE).toString()));
        }
        if (configParam.containsKey(EMDPAYMENTMODE)) {
            tenderDtBean.setSelEmdPaymentMode(Integer.parseInt(configParam.get(EMDPAYMENTMODE).toString()));
        } else if (hideConfigParam.containsKey(EMDPAYMENTMODE)) {
            tenderDtBean.setSelEmdPaymentMode(Integer.parseInt(hideConfigParam.get(EMDPAYMENTMODE).toString()));
        }
        if (configParam.containsKey(DECIMALVALUEUPTO)) {
            tenderDtBean.setSelDecimalValueUpto(Integer.parseInt(configParam.get(DECIMALVALUEUPTO).toString()));
        } else if (hideConfigParam.containsKey(DECIMALVALUEUPTO)) {
            tenderDtBean.setSelDecimalValueUpto(Integer.parseInt(hideConfigParam.get(DECIMALVALUEUPTO).toString()));
        }
        
        if (configParam.containsKey(DOCFEEPAYMENTMODE)) {
            tenderDtBean.setSelDocFeePaymentMode(Integer.parseInt(configParam.get(DOCFEEPAYMENTMODE).toString()));
        } else if (hideConfigParam.containsKey(DOCFEEPAYMENTMODE)) {
        	tenderDtBean.setSelDocFeePaymentMode(Integer.parseInt(hideConfigParam.get(DOCFEEPAYMENTMODE).toString()));
        }
        if (configParam.containsKey(EMDSUBMISSIONENDDATE)) {
            tenderDtBean.setTxtEmdSubmissionEndDate(configParam.get(EMDSUBMISSIONENDDATE).toString());
        } else if (hideConfigParam.containsKey(EMDSUBMISSIONENDDATE)) {
            tenderDtBean.setTxtEmdSubmissionEndDate(hideConfigParam.get(EMDSUBMISSIONENDDATE).toString());
        }
        //CPPP changes
        if (configParam.containsKey("productId")) {
            tenderDtBean.setSelProduct(Integer.parseInt(configParam.get("productId").toString()));
        } else if (hideConfigParam.containsKey("productId")) {
            tenderDtBean.setSelProduct(Integer.parseInt(hideConfigParam.get("productId").toString()));
        }
        if (configParam.containsKey("formContract")) {
            tenderDtBean.setSelFormContract(Integer.parseInt(configParam.get("formContract").toString()));
        } else if (hideConfigParam.containsKey("formContract")) {
            tenderDtBean.setSelFormContract(Integer.parseInt(hideConfigParam.get("formContract").toString()));
        }
        if (configParam.containsKey("tenderSector")) {
            tenderDtBean.setSelTenderSector(Integer.parseInt(configParam.get("tenderSector").toString()));
        } else if (hideConfigParam.containsKey("tenderSector")) {
            tenderDtBean.setSelTenderSector(Integer.parseInt(hideConfigParam.get("tenderSector").toString()));
        }
        if (configParam.containsKey("prequalification")) {
        	tenderDtBean.setTxtaPrequalification(configParam.get("prequalification").toString());
        } else if (hideConfigParam.containsKey("prequalification")) {
        	tenderDtBean.setTxtaPrequalification(hideConfigParam.get("prequalification").toString());
        }
        if (configParam.containsKey("displayOfficerName")) {
        	tenderDtBean.setSeldisplayOfficerName(Integer.parseInt(configParam.get("displayOfficerName").toString()));
        } else if (hideConfigParam.containsKey("displayOfficerName")) {
        	tenderDtBean.setSeldisplayOfficerName(Integer.parseInt(hideConfigParam.get("displayOfficerName").toString()));
        }
        if(configParam.containsKey("taxType")){
        	tenderDtBean.setSelTaxType(Integer.parseInt(configParam.get("taxType").toString()));
        }else if (hideConfigParam.containsKey("taxType")) {
        	tenderDtBean.setSelTaxType(Integer.parseInt(hideConfigParam.get("taxType").toString()));
        }
        if(configParam.containsKey("cgst")){
        	tenderDtBean.setHdCgst(Integer.parseInt(configParam.get("cgst").toString()));
        }
        if(configParam.containsKey("sgst")){
        	tenderDtBean.setHdSgst(Integer.parseInt(configParam.get("sgst").toString()));
        }
        if(configParam.containsKey("igst")){
        	tenderDtBean.setHdIgst(Integer.parseInt(configParam.get("igst").toString()));
        }
    }

    /**
     * Update tbl_tender ,TblTenderEnvelope,TblTenderForm opening date,publish
     * by,publish on and update on , update by and cstatus of all the object
     *
     * @author vanita.vaghasiya
     * @param int tenderId
     * @param TenderPublishBean tenderPublishBean
     * @param int clientId
     * @param int userId
     * @param int isDualCert
     * @param int userDetailId
     * @return boolean
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean updateTenderForPublish(int tenderId, TenderPublishBean tenderPublishBean, int clientId, int userId, int isDualCert, int userDetailId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        boolean success = true;
        int rowCount = 0;
        TblTender tblTender = getTenderMaster(tenderId);
        if (StringUtils.hasLength(tenderPublishBean.getTxtDocumentStartDate())) {
            tblTender.setDocumentStartDate(conversionService.convert(tenderPublishBean.getTxtDocumentStartDate(), Date.class));
        }
        if (StringUtils.hasLength(tenderPublishBean.getTxtDocumentEndDate())) {
            tblTender.setDocumentEndDate(conversionService.convert(tenderPublishBean.getTxtDocumentEndDate(), Date.class));
        }
        if (StringUtils.hasLength(tenderPublishBean.getTxtPreBidEndDate())) {
            tblTender.setPreBidEndDate(conversionService.convert(tenderPublishBean.getTxtPreBidEndDate(), Date.class));
        }
        if (StringUtils.hasLength(tenderPublishBean.getTxtPreBidStartDate())) {
            tblTender.setPreBidStartDate(conversionService.convert(tenderPublishBean.getTxtPreBidStartDate(), Date.class));
        }
        if (StringUtils.hasLength(tenderPublishBean.getTxtQuestionAnswerEndDate())) {
            tblTender.setQuestionAnswerEndDate(conversionService.convert(tenderPublishBean.getTxtQuestionAnswerEndDate(), Date.class));
        }
        if (StringUtils.hasLength(tenderPublishBean.getTxtQuestionAnswerStartDate())) {
            tblTender.setQuestionAnswerStartDate(conversionService.convert(tenderPublishBean.getTxtQuestionAnswerStartDate(), Date.class));
        }
        if (StringUtils.hasLength(tenderPublishBean.getTxtSubmissionStartDate())) {
            tblTender.setSubmissionStartDate(conversionService.convert(tenderPublishBean.getTxtSubmissionStartDate(), Date.class));
        } else {
            tblTender.setSubmissionStartDate(commonService.getServerDateTime());
        }
        if (StringUtils.hasLength(tenderPublishBean.getTxtSubmissionEndDate())) {
            tblTender.setSubmissionEndDate(conversionService.convert(tenderPublishBean.getTxtSubmissionEndDate(), Date.class));
        }
        if (StringUtils.hasLength(tenderPublishBean.getTxtEmdSubmissionEndDate())) {
            tblTender.setEmdSubmissionEndDate(conversionService.convert(tenderPublishBean.getTxtEmdSubmissionEndDate(), Date.class));
        }
        if (StringUtils.hasLength(tenderPublishBean.getTxtBidOpenDate())) {
            tblTender.setOpeningDate(conversionService.convert(tenderPublishBean.getTxtBidOpenDate(), Date.class));
        }
        if (StringUtils.hasLength(tenderPublishBean.getTxtBidOpenDate())) {
            tblTender.setPublishedOn(commonService.getServerDateTime());
        }
        tblTender.setPublishedBy(userDetailId);
        if (StringUtils.hasLength(tenderPublishBean.getTxtaRemarks()) && StringUtils.hasLength(tenderPublishBean.getTxtTenderNo()) && StringUtils.hasLength(tenderPublishBean.getTxtaTenderBrief())) {
            tblTender.setRemark(tenderPublishBean.getTxtaRemarks());
            tblTender.setTenderNo(tenderPublishBean.getTxtTenderNo());
            tblTender.setTenderBrief(tenderPublishBean.getTxtaTenderBrief());
        } else {
            success = false;
        }
        tblTender.setCstatus(1);
        tblTender.setUpdatedBy(userDetailId);
        tblTender.setOfficerUserDetailId(commonService.getUserDetailIdFromUserId(tblTender.getOfficerId(),clientId));
        if (success) {
            success = updateTender(tblTender);
        }
        if (success) {
            rowCount = fileUploadService.approvePendingOfficerDoc(tblTender.getTenderId(), tenderdocupload);
        }
        List<Object[]> wFRulelist = commonService.getClientConfiguration(clientId);
        if (wFRulelist != null && !wFRulelist.isEmpty()) {
            for (Object[] objects : wFRulelist) {
            	boolean isCheck = false;
            	if(Integer.parseInt(objects[4].toString()) == 0 && envPublishedOrNot(tenderId)==0){
            		isCheck = true;
            	}else if(Integer.parseInt(objects[4].toString()) == 1){
            		isCheck = true;
            	}
                if (objects[4] != null && isCheck) {
	                	if (success) {
	                        rowCount = updateTenderEnvForPublish(tenderId, tenderPublishBean, userId, userDetailId,null);
	                        success = rowCount > 0 ? true : false;
	                    }
                        if (success && rowCount > 0) {
                            rowCount = updateTenderFormForPublish(tenderId, userDetailId);
                        }
                }
                if (success) {
                	
                	 Map<String, Object> paramMap = new HashMap<String, Object>();
					 paramMap.put("eventType", tblTender.getTblEventType().getEventType());
					 paramMap.put("tenderId", tenderId);
					
					 String encryptUrlStr = null; 
                     String hrefStr = null;                     
                     
                    List<TblCommittee> lstTblCommittee = getTenderCommittee(tenderId);
                    for (TblCommittee tblCommittee : lstTblCommittee) {
                    	
                    	  //encryptUrlStr = encryptDecryptUtils.encrypt("etender/buyer/viewcommittee/"+tenderId+"/"+tblCommittee.getCommitteeType()+"/"+tblTender.getIsWorkflowRequired());
                    	  encryptUrlStr = encryptDecryptUtils.encrypt("etender/buyer/viewcommittee/"+tenderId+"/"+tblCommittee.getCommitteeType()+"/"+0);
                          hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                         paramMap.put("link", hrefStr);
                         
                        if (tblCommittee.getCommitteeType() == 2) {
                            if (objects[3] != null && Integer.parseInt(objects[3].toString()) ==1) {
                                    committeeFormationService.publishCommittee(tenderPublishBean.getTxtaRemarks(), clientId, tblTender.getPublishedBy(), tblCommittee.getCommitteeId(), tblCommittee.getCommitteeType(), tenderId, 0, isDualCert,paramMap);
                                }
                        } else if (tblCommittee.getCommitteeType() == 1) {
                                if (objects[2] != null && Integer.parseInt(objects[2].toString()) == 1) {
                                    committeeFormationService.publishCommittee(tenderPublishBean.getTxtaRemarks(), clientId, tblTender.getPublishedBy(), tblCommittee.getCommitteeId(), tblCommittee.getCommitteeType(), tenderId, 0, isDualCert,paramMap);
                                }
                        } else if (tblCommittee.getCommitteeType() == 3) {
                        if (objects[1] != null && Integer.parseInt(objects[1].toString()) == 1) {
                            success = committeeFormationService.approveCommittee(tenderPublishBean.getTxtaRemarks(), userDetailId, tblCommittee.getCommitteeId());
                                if (success) {
                                	Map<String, Object> msgParams = new HashMap<String, Object>();
                                	msgParams.put("EventType", tblTender.getTblEventType().getEventType());
                                	msgParams.put("EventId", tenderId);	  
                                	msgParams.put("SubDomainName", clientService.getClientNameById(clientId));
                                	String encryptUrlStr1 = encryptDecryptUtils.encrypt("etender/buyer/viewcommitee/" + tenderId + "/" + tblCommittee.getCommitteeType() + "/0");
                                	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr1 + " ');\">click here</a>"; 
                                	msgParams.put("link", herfStr);
                                    mailContentUtillity.dynamicMailGeneration("35", String.valueOf(userId), String.valueOf(tenderId), msgParams, String.valueOf(tblCommittee.getCommitteeId()));
                                }
                            }
                        }
                    }
                }
            }
        }
        
        /*** Code to call procedure for negotiation l1 h1 report  last parameter o for publish tender if Corrigendum it is 1**/
        List<Object[]> list=commonService.getClientConfigurations(clientId);
        boolean isSytemGeneratedDone = false;
        if(list!=null && !list.isEmpty() && list.get(0)[3].toString().equals("1")){
        	tenderFormService.executeSPforGenerateL1Report(tenderId, tblTender.getTenderResult(), userDetailId,0,0);
        	isSytemGeneratedDone = true;
        }
        
        if(isSytemGeneratedDone && tblTender.getIsNegotiationAllowed() != 0){
        	tenderFormService.executeSPforGenerateL1Report(tenderId, tblTender.getTenderResult(), userDetailId,0,1);
        }
        if(isSytemGeneratedDone && tblTender.getIsWeightageEvaluationRequired() == 1){
        	tenderFormService.executeSPforGenerateL1Report(tenderId, tblTender.getTenderResult(), userDetailId,0,2);
        }
        
        if(isSytemGeneratedDone  && tblTender.getTenderResult()==1 && tblTender.getIsRebateForm() == 1){
        	tenderFormService.executeSPforGenerateL1Report(tenderId, tblTender.getTenderResult(), userDetailId,0,4);
        }
        
        return success;
    }

    /**
     * get tbl_TenderPublicKey data for perticuler tender
     *
     * @auther vanita.vaghasiya
     * @param int tenderId
     * @throws Exception
     */
    public List<TblTenderPublicKey> getTenderPublicKey(int tenderId) throws Exception {
        return tblTenderPublicKeyDao.findTblTenderPublicKey(TBLTENDERTENDERID, Operation_enum.EQ, tenderId);
    }

    /**
     * get tbl_tenderEnvelope data for perticuler tender
     *
     * @auther vanita.vaghasiya
     * @param int tenderId
     * @throws Exception
     */
    public List<TblTenderEnvelope> getTenderEnvelope(int tenderId) throws Exception {
        return tblTenderEnvelopeDao.findTblTenderEnvelope(TBLTENDERTENDERID, Operation_enum.EQ, tenderId);
    }

    /**
     * get tbl_Committee data for perticular tender
     *
     * @auther vanita.vaghasiya
     * @param int tenderId
     * @throws Exception
     */
    public List<TblCommittee> getTenderCommittee(int tenderId) throws Exception {
        return tblCommitteeDao.findTblCommittee(TBLTENDERTENDERID, Operation_enum.EQ, tenderId);
    }

    /**
     * Update tbl_tenderEnvelope for publish tender
     *
     * @author vanita.vaghasiya
     * @param int tenderId
     * @param TenderPublishBean tenderPublishBean
     * @param int userId
     * @param int userDetailId
     * @return boolean
     * @throws Exception
     */
    public int updateTenderEnvForPublish(int tenderId, TenderPublishBean tenderPublishBean, int userId, int userDetailId,String remarks) throws Exception {
        StringBuffer query = new StringBuffer();
        Map<String, Object> var = new HashMap<String, Object>();
        boolean success = true;
        SimpleDateFormat sp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    	if(remarks!=null){
    		var.put("remark", remarks);
    	}else{
    		if (StringUtils.hasLength(tenderPublishBean.getTxtaRemarks())) {
    			var.put("remark", tenderPublishBean.getTxtaRemarks());
    		}else {
    			success = false;
    		}
        }
        var.put("publishedBy", userDetailId);
        var.put(TENDERID, tenderId);
        int envlopeType = 0;
        String openingDate = "";
        if(tenderPublishBean == null){
        	List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "envelopeType,openingDate");
        	if(tenderFields!=null && !tenderFields.isEmpty()){
        		envlopeType = Integer.parseInt(tenderFields.get(0)[0].toString());
        		if(tenderFields.get(0)[1] !=null && !tenderFields.get(0)[1].toString().isEmpty())
        		openingDate = CommonUtility.convertTimezone(tenderFields.get(0)[1].toString());
            }
        }else{
        	envlopeType = Integer.parseInt(tenderPublishBean.getHdEnvlopeType());
        	openingDate = tenderPublishBean.getTxtBidOpenDate();
        }
        if (success) {
        	if (envlopeType == 1) {
		    	query.append("update TblTenderEnvelope tbltenderenvelope  set tbltenderenvelope.openingDate='");
		    	
		    	if(openingDate.isEmpty())
		    	{
		    		query.append(sp.format(commonService.getServerDateTime()));
		    	}
		    	else
		    	{
		    		query.append(sp.format((Date) conversionService.convert(openingDate, Date.class)));
		    	}
		    		
		    	query.append("',tbltenderenvelope.remark=:remark, ");
		        query.append(" tbltenderenvelope.publishedOn='").append(sp.format(commonService.getServerDateTime())).append("',tbltenderenvelope.publishedBy=:publishedBy,tbltenderenvelope.cstatus=1");
		        query.append(" ,tbltenderenvelope.openingDatePublishedBy=:publishedBy,tbltenderenvelope.openingDatePublishedOn='").append(sp.format(commonService.getServerDateTime())).append("',tbltenderenvelope.openingDateStatus=1");
                query.append("where tbltenderenvelope.tblTender.tenderId=:tenderId");
            }else if (envlopeType == 2) {
            	query.append("update TblTenderEnvelope tbltenderenvelope  set tbltenderenvelope.openingDate= case when sortOrder = 1 then '");
            	
            	if(openingDate.isEmpty())
            	{
            		query.append(sp.format(commonService.getServerDateTime()));
            	}
            	else
            	{
            		query.append(sp.format((Date) conversionService.convert(openingDate, Date.class)));
            	}
            	query.append("' else tbltenderenvelope.openingDate end");
            	query.append(" ,tbltenderenvelope.remark=:remark,");
                query.append(" tbltenderenvelope.publishedOn='").append(sp.format(commonService.getServerDateTime()));
                query.append("',tbltenderenvelope.publishedBy=:publishedBy,tbltenderenvelope.cstatus=1");
                query.append(" ,tbltenderenvelope.openingDatePublishedBy = case when sortOrder = 1 then "+userDetailId+" else tbltenderenvelope.openingDatePublishedBy end");
                query.append(" ,tbltenderenvelope.openingDatePublishedOn = case when sortOrder = 1 then '").append(sp.format(commonService.getServerDateTime())).append("' else tbltenderenvelope.openingDatePublishedOn end");
                query.append(" ,tbltenderenvelope.openingDateStatus = case when sortOrder = 1 then 1 else tbltenderenvelope.openingDateStatus end");
                query.append(" where tbltenderenvelope.tblTender.tenderId=:tenderId");
            }
            return hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
        } else {
            return 0;
        }
    }

    /**
     * Update tbl_tenderForm status for publish tender
     *
     * @author vanita.vaghasiya
     * @param int tenderId
     * @param int userDetailId
     * @return boolean
     * @throws Exception
     */
    public int updateTenderFormForPublish(int tenderId, int userDetailId) throws Exception {
        StringBuffer query = new StringBuffer();
        Map<String, Object> var = new HashMap<String, Object>();
        SimpleDateFormat sp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        var.put(TENDERID, tenderId);
        var.put("publishedBy", userDetailId);
        query.append("update TblTenderForm tbltenderform  set tbltenderform.cstatus=1,tbltenderform.publishedOn='").append(sp.format(commonService.getServerDateTime())).append("',tbltenderform.publishedBy=:publishedBy");
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId ");
        return hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
    }
    
    /**
     * Update tbl_tenderForm isEncryptionReq
     *'digi cert required' Yes to No than all forms with isPriceBid=1 must be updated with isEncryptionReq=0 vice versa
     * @author Lipi Shah
     * @param int tenderId
     * @param int isEncryptionReq
     * @return boolean
     * @throws Exception
     */
    public boolean updateTenderFormEncryptionReq(int tenderId,int isEncryptionReq) throws Exception {
    	boolean success = false;
    	StringBuffer query = new StringBuffer();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        var.put("isEncryptionReq", isEncryptionReq);
        query.append(" UPDATE TblTenderForm tbltenderform  SET isEncryptionReq=:isEncryptionReq");
        query.append(" WHERE tbltenderform.tblTender.tenderId=:tenderId");
        if(isEncryptionReq == 1){
        	query.append(" AND tbltenderform.isPriceBid = 1");
        }
        hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
        success=true;
        return success;
    }

    /**
     * @author purvesh
     *
     * get field Business Rule Fields
     *
     * @param clientId
     * @param eventTypeId
     * @return
     * @throws Exception
     */
    public List<Object[]> getBusinessRuleFields(int clientId, int eventTypeId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId", clientId);
        var.put(EVENTTYPEID, eventTypeId);
        StringBuilder query = new StringBuilder("select isnull(TC.isShown, 1), TF.controlType, TF.fieldGroupId, isnull(TC.field, TF.fieldName), ");
        query.append("isnull(TC.fieldValue, ''), TF.query, isnull(TC.fieldLabel, TF.fieldLabel), TF.controlValue, TF.defaultValue, ");
        query.append("isnull(TC.customParamId, 0), TF.tblEventType.eventTypeId, TF.fieldId, TF.fieldName, TF.hasDefaultValue, TF.description from TblField TF");
        query.append(" inner join TF.tblCustomParameter TC with TC.tblClient.clientId=:clientId ");
//        	query.append(" and TC.isShown=1");
        query.append(" where TF.isActive=1 and TF.tblEventType.eventTypeId=:eventTypeId and TC.tblEventType.eventTypeId=:eventTypeId and TF.forBusinessRule=1 order by  TF.fieldGroupId , TF.sortOrder ");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    
    public List<Object[]> getBusinessRuleFields(int clientId, int eventTypeId,List<Integer> fieldIds) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId", clientId);
        var.put(EVENTTYPEID, eventTypeId);
        var.put("fieldId", fieldIds);
        StringBuilder query = new StringBuilder("select isnull(TC.isShown, 1), TF.controlType, TF.fieldGroupId, isnull(TC.field, TF.fieldName), ");
        query.append("isnull(TC.fieldValue, ''), TF.query, isnull(TC.fieldLabel, TF.fieldLabel), TF.controlValue, TF.defaultValue, ");
        query.append("isnull(TC.customParamId, 0), TF.tblEventType.eventTypeId, TF.fieldId, TF.fieldName, TF.hasDefaultValue, TF.description from TblField TF");
        query.append(" inner join TF.tblCustomParameter TC with TC.tblClient.clientId=:clientId ");
        query.append(" where TF.isActive=1 and TF.tblEventType.eventTypeId=:eventTypeId and TC.tblEventType.eventTypeId=:eventTypeId and TF.forBusinessRule=1 and TF.fieldId in (:fieldId) order by  TF.fieldGroupId , TF.sortOrder ");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    

    /**
     * @author purvesh
     *
     * update Business Rule.
     *
     * @param var
     * @param paramPaired
     * @param temderId
     * @return
     * @throws Exception
     */
    public boolean updateBusinessRule(Map var, String paramPaired, int tenderId) throws Exception {
        int cnt = 0;
        var.put(TENDERID, tenderId);
        StringBuilder query = new StringBuilder("update TblTender tblTender SET ")
                .append(paramPaired).append(" where tblTender.tenderId=:tenderId");
        cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
        return cnt != 0;
    }

    /**
     * @author purvesh
     *
     * Check whether any bid on particular tender.
     *
     * @param var
     * @param paramPaired
     * @param temderId
     * @return
     * @throws Exception
     */
    public long biddingCount(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        return hibernateQueryDao.countForQuery("TblTenderBid tblTenderBid", "tblTenderBid.tblTender.tenderId", "tblTenderBid.tblTender.tenderId=:tenderId", var);
    }
    /**
     * To check tender is price bid or not
     * author Foram
     */
    public long checkpricebidform(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        return hibernateQueryDao.countForQuery("TblTenderEnvelope tblTenderEnvelope", "tblTenderEnvelope.tblTender.tenderId", "tblTenderEnvelope.tblTender.tenderId=:tenderId AND tblTenderEnvelope.tblEnvelope.envId in (4,5)", var);
    }

    /**
     * to add tender cancel request
     *
     * @param tblCancelRequest
     * @return
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addCancelRequest(TblCancelRequest tblCancelRequest, int isWorkFlowRequired) throws Exception {
        boolean bSuccess = false;
        tblCancelRequestDao.addTblCancelRequest(tblCancelRequest);
        if (isWorkFlowRequired == 0) {
            updateTenderStatus(tblCancelRequest.getObjectId(), 2);
            updateContractStatus(tblCancelRequest.getObjectId(), 3);
            updateTenderEvalutionStatus(tblCancelRequest.getObjectId(), 0);
        }
        bSuccess = true;
        return bSuccess;
    }

    /**
     * to update the status of the tender
     *
     * @param tenderId
     * @param cStatus
     * @return
     * @throws Exception
     */
    public boolean updateTenderStatus(int tenderId, int cStatus) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        var.put("cstatus", cStatus);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTender set cstatus=:cstatus where tenderId=:tenderId", var);
        return cnt != 0;

    }
    
    /**
     * to update the evaluationStatus of the tender Opened/Complete.
     *
     * @param tenderId
     * @param evaluationstatus
     * @return
     * @throws Exception
     */
    public boolean updateTenderEvalutionStatus(int tenderId, int evaluationstatus) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        if(commonService.checkTenderCancel(tenderId) != 0){
        	cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTender set evaluationstatus=0 where tenderId=:tenderId", var);
        }else{
        	var.put("evaluationstatus", evaluationstatus);
        	cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTender set evaluationstatus=:evaluationstatus where tenderId=:tenderId", var);
        }
        return cnt != 0;
    }
    
    /**
     * to update the status of the APO/PO
     *
     * @param tenderId
     * @param cStatus
     * @return
     * @throws Exception
     */
    public boolean updateContractStatus(int tenderId, int cStatus) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        var.put("cstatus", cStatus);
        if(commonService.getTblAdvancePurchaseOrderByObject(tenderId)!=null)/*if exists then update*/
        	cnt = hibernateQueryDao.updateDeleteNewQuery("update TblAdvancePurchaseOrder set cstatus=:cstatus where objectId=:tenderId", var);
        if(cnt != 0 && commonService.getTblPurchaseOrderByObject(tenderId)!=null)/*if exists then update*/
        	cnt = hibernateQueryDao.updateDeleteNewQuery("update TblPurchaseOrder set cstatus=:cstatus where objectId=:tenderId", var);
        return cnt != 0;

    }
    
     /**
     * author : heeral.soni
     * @param tbltenderwisebudgetdetails
     * @return
     * @throws Exception 
     */
    public  boolean addTblTenderWiseBudgetDetails(TblTenderWiseBudgetDetails tbltenderwisebudgetdetails) throws Exception{
        boolean bSuccess = false;             
        tblTenderWiseBudgetDetailsDao.saveOrUpdateTblTenderWiseBudgetDetails(tbltenderwisebudgetdetails);
        bSuccess=true;        
        return bSuccess;
    }
    
    /**
     * @author heeral.soni
     * @param tenderId
     * @return
     * @throws Exception
     */
    /*public TblTenderWiseBudgetDetails getTblTenderWiseBudgetDetails(int tenderId) throws Exception {
        System.out.println("in methoddddddddddddddddddddddddddddddddddddddd");
    	List<TblTenderWiseBudgetDetails> list = tblTenderWiseBudgetDetailsDao.findTblTenderWiseBudgetDetails("tblTender", Operation_enum.EQ, new TblTender(tenderId));
    	return list.isEmpty() ? null : list.get(0);
    }*/

    /**
     * @author heeral.soni
     * @param tenderId
     * @return
     * @throws Exception
     */
    public  boolean addTblEncodeDecodeHistory(List<TblEncodeDecodeHistory> tblEncodeDecodeHistory) throws Exception{
        boolean bSuccess = false; 
        tblEncodeDecodeHistoryDao.saveUpdateAllTblEncodeDecodeHistory(tblEncodeDecodeHistory);
        bSuccess=true;        
        return bSuccess;
    }
    
    /**
     * @author heeral.soni
     * for get list of encode decode tenders
     * @return
     * @throws Exception
     */
    public List<Object[]> getEncodeDecodeTender(int clientId, int tenderId,String endDate,String openDate,int status) throws Exception {
    	//Bug id 34337 added tendercstatus change 
    	List<Integer> cstatus = new ArrayList<Integer>();
    	cstatus.add(1);
    	//Added for Bug #51646 (2 for Cancelled)
    	cstatus.add(2);
    	cstatus.add(4);
    	cstatus.add(5);
    	Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId", clientId);
        var.put("status",status);
        var.put("cstatus",cstatus);
        StringBuilder query = new StringBuilder("select tbltender.tenderId,tbltender.tenderNo,tbltender.tenderDetail,tbltender.submissionEndDate,tbltender.openingDate,tbltender.isEncodedName ");
        query.append("from TblTender tbltender ");
        query.append("inner join tbltender.tblDepartment tbldepartment ");
        query.append("where tbltender.cstatus in (:cstatus) and tbldepartment.tblClient.clientId=:clientId ");
        query.append(" and tbltender.isEncodedName=:status ");
        if(tenderId!=0){
            var.put("tenderId", tenderId);
            query.append(" and tbltender.tenderId=:tenderId ");
        }
        if(endDate!=null && !"null".equalsIgnoreCase(endDate) && !endDate.isEmpty()){
            var.put("endDate", endDate);
            query.append(" and tbltender.submissionEndDate =:endDate ");
        }
        if(openDate!=null && !"null".equalsIgnoreCase(openDate) && !openDate.isEmpty()){
            var.put("openDate", openDate);
            query.append(" and tbltender.openingDate=:openDate ");
        }
        query.append(" order by tbltender.openingDate desc");
        //System.out.println("query getEncodeDecodeTender :------->"+query.toString());
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    
    /**
     * author : heeral.soni
     * @param tenderIds
     * @param status
     * used to inset/update status
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean updateTenderEncodedName(String tenderIds,List<TblEncodeDecodeHistory> tblEncodeDecodeHistory,int status) throws Exception{
        boolean bSuccess = addTblEncodeDecodeHistory(tblEncodeDecodeHistory);
        int cnt = 0;
        if(bSuccess){
            StringBuilder query = new StringBuilder();
            query.append("update TblTender set isEncodedName=").append(status).append(" where tenderId in (").append(tenderIds).append(")");
            //System.out.println("in queryyyyy-------updateTenderEncodedName->"+query.toString());
            cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),null);        
        }   
        return cnt != 0;
    }
    
    /**
     * Send BRD mails to mapped bidders
     * 
     * @author purvesh
     * @param object = eventId
     * @param moduleId
     * @return
     */
    public boolean inviteBiddersForParticipation(int eventId,int userId, int clientId, String urlStr, String contextPath,boolean isBRDRegenerate, String timeZoneAbbr) throws Exception{
    	boolean bsuccess=false;
    	MessageConfigDatabean messageConfigDatabean = null;
    	List<Object> mappedBidders = null;
    	List<Object[]> officerContactDetails = null;
    	List<Object[]> eventDetails = null;
    	Map<String, Object> mailParams = null;
    	List<String> params= new ArrayList<String>();
    	mappedBidders = getTenderMappedBidders(eventId);
    	eventDetails =  tenderCommonService.getTenderFields(eventId, "tblEventType.lang"+WebUtils.getCookie(getServletRequest(), "locale").getValue() +",tenderBrief,submissionStartDate,submissionEndDate,officerId");
    	officerContactDetails = commonService.getOfficerContactDetails(Integer.parseInt(eventDetails.get(0)[4].toString()), clientId);
    	List<Object> lst=commonService.getDemoEventId(tenderModuleId, eventId);
        String demoEventid = "";
        List<Object[]> clientDetails = null;
        
        clientDetails = clientService.getClientNameAndCountry(clientId);
        if(lst!=null && !lst.isEmpty())
        {
            demoEventid = (String) lst.get(0);
            demoEventid=demoEventid.replace("<p>","").trim();
            demoEventid=demoEventid.replace("</p>","").trim();
        }
        
        int i=0;
    	if(mappedBidders!=null){
            for(i=0; i<mappedBidders.size(); i++){
                params.clear();
                mailParams = new HashMap<String, Object>();
                messageConfigDatabean =  new MessageConfigDatabean();
                mailParams.put("to",mappedBidders.get(i));
                mailParams.put("loginId",mappedBidders.get(i));
                mailParams.put("eventType", "e"+eventDetails.get(0)[0].toString()); 
                mailParams.put("keywords", eventDetails.get(0)[1]);
                mailParams.put("startDateTime", CommonUtility.convertTimezoneToClientTimezone(eventDetails.get(0)[2])+" "+timeZoneAbbr);
                mailParams.put("endDateTime", CommonUtility.convertTimezoneToClientTimezone(eventDetails.get(0)[3])+" "+timeZoneAbbr);
                mailParams.put("objectId", eventId);
                mailParams.put ("domainName", clientDetails.get(0)[1]);
                mailParams.put ("demoEventid",demoEventid.replace("<p>","").replace("</p>",""));
                mailParams.put ("officerName", officerContactDetails.get(0)[0]);
                mailParams.put ("companyName", officerContactDetails.get(0)[1]);
                mailParams.put ("emailId", officerContactDetails.get(0)[2]);
                mailParams.put ("contactNo", officerContactDetails.get(0)[3]);
                mailParams.put ("cellNo", officerContactDetails.get(0)[4]);
                mailParams.put ("clientName", clientDetails.get(0)[2]);
                mailParams.put ("countryName", clientDetails.get(0)[3]);
                String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/viewtender/"+eventId);
                String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                mailParams.put("link",hrefStr);
                
                messageConfigDatabean.setQueueName(queueName);
                if(isBRDRegenerate) /* From BRD Revised event */ 
                {
                    messageConfigDatabean.setTemplateId(tenBrdRegeMailTemplateId);
                }
                else/* From auction approve event */ 
                {
                    messageConfigDatabean.setTemplateId(tenBrdMailTempleteId);
                }
                messageConfigDatabean.setUserId(userId);
	        	messageConfigDatabean.setClientId(clientId);
	        	messageConfigDatabean.setObjectId(eventId);
                messageConfigDatabean.setCc(officerContactDetails.get(0)[2].toString());
                messageConfigDatabean.setBcc(brd_etl_officer_mailid);
	        	messageConfigDatabean.setUrlStr(urlStr);
	        	messageConfigDatabean.setContextPath(contextPath);
	        	messageConfigDatabean.setParamMap(mailParams);
	        	messageConfigDatabean.setLstParams(params);
	    		messageQueueService.sendMessage(messageConfigDatabean);
			}
    	}
    	if(mappedBidders.size()==i){
			bsuccess=true;
		}
    	return bsuccess;
    }
    /**
     * To get all mapped bidders with repective eventid
     * @author purvesh
     * @param eventId
     * @return
     * @throws Exception
     */
    private List<Object> getTenderMappedBidders(int eventId) throws Exception{
    	List<Object> result=null;
    	StringBuilder query = new StringBuilder();
    	Map<String,Object> var= new HashMap<String, Object>();
    	var.put("tenderId", eventId);
    	query.append("select distinct tbltenderbiddermap.tblUserLogin.loginId ")
    		 .append("from TblTenderBidderMap tbltenderbiddermap ")
    		 .append("INNER JOIN tbltenderbiddermap.tblUserLogin tbluserlogin ")
    		 .append("where tbltenderbiddermap.tblTender.tenderId=:tenderId");
    	result = hibernateQueryDao.singleColQuery(query.toString(), var);
    	return result; 
    }
    /**
     * @author krunal.patel
     * @param clientId
     * @param tenderId
     * @return List<Object[]>
     * @throws Exception
     */
    public List<Object[]> getTenderCurrencyList(Integer clientId,Integer tenderId) throws Exception {
        List<Object[]> list = null;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId", clientId);
        var.put("tenderId", tenderId);
        query.append("select tblCurrency.currencyId,tblCurrency.lang").append(WebUtils.getCookie(getServletRequest(), "locale").getValue()).append(",tblTenderCurrency.tblCurrency.currencyId,tblCurrency.symbol ");
        query.append("from  TblClientCurrency tblClientCurrency ");
        query.append("inner join  tblClientCurrency.tblCurrency tblCurrency ");
        query.append("left outer join  tblCurrency.tblTenderCurrency tblTenderCurrency ");
        query.append("with tblTenderCurrency.tblTender.tenderId=:tenderId and tblTenderCurrency.isActive = 1 ");
        query.append("where tblClientCurrency.isActive=1 and tblClientCurrency.tblClient.clientId=:clientId");
        list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return list;
    }
    
        /**
     * Send BRD mails to mapped bidders
     * 
     * @author purvesh
     * @param object = eventId
     * @param moduleId
     * @return
     */
    public boolean inviteBidderForParticipation(int eventId,int userId, int clientId, String urlStr, String contextPath,boolean isBRDRegenerate, String timeZoneAbbr,int bidderId) throws Exception{
    	boolean bsuccess=false;
    	MessageConfigDatabean messageConfigDatabean = null;
    	List<Object[]> mappedBidders = null;
    	List<Object[]> officerContactDetails = null;
    	List<Object[]> eventDetails = null;
    	Map<String, Object> mailParams = null;
    	List<String> params= new ArrayList<String>();
    	mappedBidders = getTenderMappedBidder(eventId,bidderId);
    	eventDetails =  tenderCommonService.getTenderFields(eventId, "tblEventType.lang"+WebUtils.getCookie(getServletRequest(), "locale").getValue() +",tenderBrief,submissionStartDate,submissionEndDate,officerId");
    	officerContactDetails = commonService.getOfficerContactDetails(Integer.parseInt(eventDetails.get(0)[4].toString()), clientId);
    	List<Object> lst=commonService.getDemoEventId(tenderModuleId, eventId);
        String demoEventid = "";
        List<Object[]> clientDetails = null;
        
        clientDetails = clientService.getClientNameAndCountry(clientId);
        if(lst!=null && !lst.isEmpty())
        {
            demoEventid = (String) lst.get(0);
            demoEventid=demoEventid.replace("<p>","").trim();
            demoEventid=demoEventid.replace("</p>","").trim();
        }
        
    	int i=0;
    	if(mappedBidders!=null){
                params.clear();
                mailParams = new HashMap<String, Object>();
                messageConfigDatabean =  new MessageConfigDatabean();
                mailParams.put("to",mappedBidders.get(i)[1]);
                mailParams.put("loginId",mappedBidders.get(i)[1]);
                mailParams.put("eventType", "e"+eventDetails.get(0)[0].toString()); 
                mailParams.put("keywords", eventDetails.get(0)[1]);
                mailParams.put("startDateTime", CommonUtility.convertTimezoneToClientTimezone(eventDetails.get(0)[2])+" "+timeZoneAbbr);
                mailParams.put("endDateTime", CommonUtility.convertTimezoneToClientTimezone(eventDetails.get(0)[3])+" "+timeZoneAbbr);
                mailParams.put("objectId", eventId);
                mailParams.put ("domainName", clientDetails.get(0)[1]);
                mailParams.put ("demoEventid",demoEventid.replace("<p>","").replace("</p>",""));
                mailParams.put ("officerName", officerContactDetails.get(0)[0]);
                mailParams.put ("companyName", officerContactDetails.get(0)[1]);
                mailParams.put ("emailId", officerContactDetails.get(0)[2]);
                mailParams.put ("contactNo", officerContactDetails.get(0)[3]);
                mailParams.put ("cellNo", officerContactDetails.get(0)[4]);
                mailParams.put ("clientName", clientDetails.get(0)[2]);
                mailParams.put ("countryName", clientDetails.get(0)[3]);

                messageConfigDatabean.setQueueName(queueName);
                if(isBRDRegenerate) /* From BRD Revised event */ 
                {
                    messageConfigDatabean.setTemplateId(tenBrdRegeMailTemplateId);
                }
                else/* From auction approve event */ 
                {
                    messageConfigDatabean.setTemplateId(tenBrdMailTempleteId);
                }
                messageConfigDatabean.setUserId(userId);
	        	messageConfigDatabean.setClientId(clientId);
	        	messageConfigDatabean.setObjectId(eventId);
                messageConfigDatabean.setCc(officerContactDetails.get(0)[2].toString());
                messageConfigDatabean.setBcc(brd_etl_officer_mailid);
	        	messageConfigDatabean.setUrlStr(urlStr);
	        	messageConfigDatabean.setContextPath(contextPath);
	        	messageConfigDatabean.setParamMap(mailParams);
	        	messageConfigDatabean.setLstParams(params);
	    		bsuccess = messageQueueService.sendMessage(messageConfigDatabean);
    	}
    	return bsuccess;
    }
    
    private List<Object[]> getTenderMappedBidder(int eventId,int userId) throws Exception{
    	List<Object[]> result=null;
    	StringBuilder query = new StringBuilder();
    	Map<String,Object> var= new HashMap<String, Object>();
    	var.put("tenderId", eventId);
    	var.put("userId", userId);
    	query.append("select distinct  tbluserlogin.userId,tbltenderbiddermap.tblUserLogin.loginId ")
    		 .append("from TblTenderBidderMap tbltenderbiddermap ")
    		 .append("INNER JOIN tbltenderbiddermap.tblUserLogin tbluserlogin ")
    		 .append("where tbltenderbiddermap.tblTender.tenderId=:tenderId and tbltenderbiddermap.tblUserLogin.userId=:userId");
    	result = hibernateQueryDao.createNewQuery(query.toString(), var);
    	return result; 
    }
    /**
     * set Tender Notice footer
     * @author Lipi
     * @param clientId 
     * @return
     */
	public List<Object[]> eventBannerContactList(int clientId) {
		List<Object[]> result = null;
    	StringBuilder query = new StringBuilder();
    	Map<String,Object> var= new HashMap<String, Object>();
    	var.put("clientId", clientId);
    	query.append(" SELECT A.personName as c0,A.bannerType as c1,A.mobileNo as c2,A.phoneNo as c3,A.email as c4,A.faxNo as c5");
    	query.append(" FROM (select  ROW_NUMBER() OVER (PARTITION BY CB.personname ORDER BY CB.personname DESC) AS rnk,CB.certBannerId, CB.personName,");
    	query.append(" CB.bannerType, CB.mobileNo, CB.phoneNo, CB.email, CB.faxNo, CB.isActive");
    	query.append(" ,CBM.clientCertBannerId, CBM.clientId");
    	query.append(" from appmaster.tbl_CertBanner CB");
    	query.append(" inner join appclient.tbl_ClientCertBannerMapping CBM");
    	query.append(" on CB.certBannerId = CBM.certBannerId");
    	query.append(" where CBM.clientId =:clientId and CB.isActive = 1 and CBM.isActive= 1) A where rnk = 1 ");
    	int nVarCharColumnIndex [] = {0,2,3,4,5};
    	result = hibernateQueryDao.createSQLQuery(query.toString(), var,nVarCharColumnIndex,6);
    	return result; 
	}
	
	/**
     * @author nirav.prajapati
     * @return List<Object[]>
     * @throws Exception
     */
    public List<Object[]> getAdvertiseByTenderForL1Report(int tenderId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuffer query=new StringBuffer();
        query.append("select tblAdvertise.advertiseId,tblAdvertise.advertiseNo,tblAdvertise.advertiseType,tblAdvertise.corrigendumText,tblAdvertise.documentStartDate, ");
        query.append(" tblAdvertise.documentEndDate,tblAdvertise.openingDate,tblAdvertise.submissionEndDate");
        query.append(" from TblAdvertiseTenderMap tblAdvertiseTenderMap inner join tblAdvertiseTenderMap.tblAdvertise tblAdvertise");
        query.append(" where tblAdvertiseTenderMap.tblTender.tenderId=:tenderId and tblAdvertise.cstatus = 1 and tblAdvertise.isExtended = 0 order by tblAdvertise.createdOn ");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);
        return list;
    }
    
    /**
     * @author nirav.prajapati
     * @param tenderId
     */
	public List<Object[]> getOfficerByTenderId(int tenderId)
	{
		List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuffer query=new StringBuffer();
        query.append("select tblUserDetail.userName,tblUserDetail.designation from TblUserDetail tblUserDetail  where tblUserDetail.userDetailId in ( select createdBy from TblTender tblTender where tblTender.tenderId=:tenderId)");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);
        return list;
	}
	
	/**
	 * @author nirav.prajapati
	 * @param tenderId
	 * @return
	 */
	public List<Object[]> getDynReportIdByTenderId(int tenderId)
	{
		List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuffer query=new StringBuffer();
        query.append("select tblDynReport.reportId,tblDynReport.reportId from TblDynReport tblDynReport where tblDynReport.reportType = 2 and tblDynReport.tblTender.tenderId =:tenderId");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);
        return list;
	}
	/**
	 *  Delete committee if two stage evaluation is changed.
	 * @param tenderId
	 */
	public void deleteEvaluationCommittee(int tenderId) {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append(" delete TblCommittee where committeeType = 2 and tenderId=:tenderId ");
        hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);        
	}
	
	/**
	 * To Know workflow required is yes or No at client configuration
	 * @author manoj.gadhavi
	 * @param clientId
	 * @return
	 * @throws Exception
	 */
	public boolean isWorkflowReq(int clientId) throws Exception{
		boolean flag = true;
		List<TblClient> list = tblClientDao.findTblClient("clientId",Operation_enum.EQ,clientId);
		if(list.get(0).getIsWorkflowReq() == 0){
			flag = false;
		}
		return flag;
	}
	
	/**
	 * @author janak
	 * @since 16 apr 2015
	 * @param tenderId
	 * @return
	 * @throws Exception 
	 */
	
	public boolean addTendersToCppp(int clientId, int tenderId) throws Exception
	{
		int cnt = 0;
		List<TblClientCPPPConfig> clientCppConfigList = clientService.getCPPPDetailsByClient(clientId);
		
		if(clientCppConfigList != null && !clientCppConfigList.isEmpty() && clientCppConfigList.size() == 1)   // only if cppp configuration are available for particular client
		{
			TblClientCPPPConfig tblClientCPPPConfig = new TblClientCPPPConfig();
			tblClientCPPPConfig = (TblClientCPPPConfig)clientCppConfigList.get(0);
			String currency = "";
        	StringBuilder currencyStr = new StringBuilder();
        	Map<String, Object> var1 = new HashMap<String, Object>();
            var1.put(TENDERID, tenderId);
        	currencyStr.append("select tblCurrency.lang").append(WebUtils.getCookie(getServletRequest(), LOCALE).getValue()).append(",tblCurrency.lang1 from TblTenderCurrency tblTenderCurrency  inner join  tblTenderCurrency.tblCurrency tblCurrency  where  tblTenderCurrency.isActive=1 and tblTenderCurrency.tblTender.tenderId=:tenderId "); 
        	List<Object[]> lst =  hibernateQueryDao.createQuery(currencyStr.toString(), var1);
        	if(lst!=null && !lst.isEmpty()){
        		for (int i = 0; i < lst.size(); i++) {
        			if(i!=lst.size()-1){
        				currency = currency +(String)lst.get(i)[0]+",";
        			}else{
        				currency = currency +(String)lst.get(i)[0];
        			}
				}
        	}	
        	
        	StringBuilder strQuery = new StringBuilder();
        	strQuery.append(" insert into dbo.tenders2cppp( xml_user_id, tender_refno, tid, tender_title, tender_desc, prequalification, tender_location, tender_pincode, tia_details, tia_address, product_subcategory, return_url, remarks, currency, tender_fee, tender_value, emd, published_date, prebid_date, docsale_download_startdate, docsale_download_enddate, bid_submission_startdate, bid_submission_enddate, bid_opening_date, prod_id, tender_type, tender_category, form_contract, tender_sector, tender_state)") 
        	.append(" select distinct '").append(tblClientCPPPConfig.getXml_user_id()).append("',tenderNo,tenderId,REPLACE(REPLACE(tenderBrief,'—','&#8212;'),'*','&#42;'),REPLACE(REPLACE(tenderDetail,'—','&#8212;'),'*','&#42;'),prequalification,TDEPT.city,'',")
        	.append(" TU.userName+','+TDEPT.deptName,TDEPT.address,isnull(keywordText,''),").append("'"+tblClientCPPPConfig.getUrl() + "/viewtender/" + tenderId+ "',") 
        	.append(" remark,'").append(currency).append("',documentFee,0,emdAmount,")
        	.append(" dateadd(minute, datediff(minute, sysutcdatetime(), sysdatetime()), publishedOn),isnull(dateadd(minute, datediff(minute, sysutcdatetime(), sysdatetime()), preBidStartDate),''),dateadd(minute, datediff(minute, sysutcdatetime(), sysdatetime()), documentStartDate),dateadd(minute, datediff(minute, sysutcdatetime(), sysdatetime()), documentEndDate),dateadd(minute, datediff(minute, sysutcdatetime(), sysdatetime()), submissionStartDate),dateadd(minute, datediff(minute, sysutcdatetime(), sysdatetime()), submissionEndDate),dateadd(minute, datediff(minute, sysutcdatetime(), sysdatetime()), openingDate),")
        	.append(" productId,(CASE WHEN tenderMode = 3 THEN 2 ELSE tenderMode END),procurementNatureId,formContract,tenderSector, TST.cppStateId ") 
        	.append(" from apptender.tbl_Tender TA inner join appclient.tbl_Department TDEPT on TA.deptId = TDEPT.deptId ") 
        	.append(" inner join appuser.tbl_Officer TOF on TA.officerId=TOF.userId ") 
        	.append(" inner join appuser.tbl_UserLogin TU on TOF.userId=TU.userId inner join appmaster.tbl_State TST on TDEPT.stateId=TST.stateId ")
        	.append(" where TA.tenderId = ").append(tenderId);
        	cnt =  hibernateQueryDao.updateDeleteSQLQuery(strQuery.toString(), null);
        	return cnt!=0;
		}
		else {
			return false;
		}
	}
	
	/**
	 *  Delete weightage evaluation configuration from the tender level
	 * @param tenderId
	 */
	public void deleteWeightageEvaluationConfiguration(int tenderId) {
        StringBuilder queryEnv = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        queryEnv.append("delete from TbltenderEnvelopeWeightage where tblTenderEnvelope.envelopeId in (select envelopeId from TblTenderEnvelope where tblTender.tenderId =:tenderId)");
        hibernateQueryDao.updateDeleteNewQuery(queryEnv.toString(),var);
        
        StringBuilder queryForm = new StringBuilder();
        queryForm.append("delete from TbltenderFormWeightage where tblTenderEnvelope.envelopeId in (select envelopeId from TblTenderEnvelope where tblTender.tenderId =:tenderId)");
        hibernateQueryDao.updateDeleteNewQuery(queryForm.toString(),var);
	}
	/**
	 *  Update Partial Filling if grand total wise tender
	 * @param tenderId
	 */
	public void updatePartialFiilingTenderTableConfiguration(int tenderId) {
		Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDERID, tenderId);
        
		StringBuilder query = new StringBuilder("SELECT tblTenderTable.tableId");
		query.append(" FROM TblTenderForm tblTenderForm");
		query.append(" INNER JOIN tblTenderForm.tblTenderTable tblTenderTable");
		query.append(" WHERE tblTenderForm.tblTender.tenderId=:tenderId");
		query.append(" AND tblTenderForm.isPriceBid = 1 ");
		query.append(" AND tblTenderTable.isPartialFillingAllowed = 1");
        
        List<Object> tableIds = hibernateQueryDao.singleColQuery(query.toString(), parameters);
        if(!tableIds.isEmpty()){
	        parameters.clear();
	        parameters = new HashMap<String, Object>();
	        parameters.put("tableId", tableIds);
	        StringBuilder queryForm = new StringBuilder();
	        queryForm.append("UPDATE TblTenderTable SET isPartialFillingAllowed = 0 WHERE tableId IN(:tableId)");
	        hibernateQueryDao.updateDeleteNewQuery(queryForm.toString(),parameters);
        }
	}
	
	/**
	 * Check env is published or not
	 */
	public long envPublishedOrNot(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        return hibernateQueryDao.countForQuery("TblTenderEnvelope tblTenderEnvelope", "tblTenderEnvelope.tblTender.tenderId", "tblTenderEnvelope.tblTender.tenderId=:tenderId AND tblTenderEnvelope.openingDateStatus=0", var);
    }
	/**
	 *  Delete workflow in edit case when change its type
	 * @param tenderId
	 */
	public void deleteWorkflowConfiguration(int tenderId) {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("DELETE FROM TblWorkflowConfiguration WHERE parentId =:tenderId");
       hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
	}
	/**
	 *  Update workflow Reference No in edit case when change its type
	 * @param tenderId
	 */
	public void updateWorkflowReferenceNo(int tenderId,String referenceNo) {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("referenceNo", referenceNo);
        query.append("update TblWorkflow tblWorkflow  set tblWorkflow.referenceNo=:referenceNo where tblWorkflow.parentId = :tenderId");
        hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
	}
	/**
	 * Get Officer evaluation Date and Time
	 */
	 public List<Object> getOfficerEvaluationDateAndTime(int tenderId,int envelopeId){
		StringBuilder strQuery = new StringBuilder();
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("tenderId", tenderId);
        parameters.put("envelopeId", envelopeId);
        strQuery.append("select tblBidderApprovalDetail.createdOn from TblBidderApprovalDetail tblBidderApprovalDetail ");
        strQuery.append(" where tblBidderApprovalDetail.tblTender.tenderId=:tenderId  and tblBidderApprovalDetail.tblTenderEnvelope.envelopeId=:envelopeId order by tblBidderApprovalDetail.createdOn desc");
        return hibernateQueryDao.getSingleColQuery(strQuery.toString(), parameters);
	 }
	 
	 public List<Object> getOfficerEvaluationDateAndTimeFromHistory(int tenderId,int envelopeId){
			StringBuilder strQuery = new StringBuilder();
	        Map<String, Object> parameters = new HashMap<String, Object>();
	        parameters.put("tenderId", tenderId);
	        parameters.put("envelopeId", envelopeId);
	        strQuery.append("select tblBidderApprovalHistory.createdOn from TblBidderApprovalHistory tblBidderApprovalHistory ");
	        strQuery.append(" where tblBidderApprovalHistory.tenderId=:tenderId  and tblBidderApprovalHistory.envelopeId=:envelopeId and tenderReEvalId=0 order by tblBidderApprovalHistory.createdOn desc");
	        return hibernateQueryDao.getSingleColQuery(strQuery.toString(), parameters);
		 }
	   /**
	     * Add new TblEncodeDecodeHistory
	     * @author pooja.kakkad
	     * @param TblEncodeDecodeHistory
	     * @return boolean
	     * @throws Exception
	     */
	 
	 @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
	    public boolean addTblEncodeDecodeHistory(TblEncodeDecodeHistory tblEncodeDecodeHistory) throws Exception {
	        boolean bSuccess = false;
	        tblEncodeDecodeHistoryDao.addTblEncodeDecodeHistory(tblEncodeDecodeHistory);
	        bSuccess = true;
	        return bSuccess;
	    }
	 
	 /**
      * @author anjali
	     * Delete entry from appcommon.tbl_Document table based on objectId
	  	 * @param tenderId
	  	 * @return
	  	 * @throws Exception
	  */
	 public int deleteTenderDocument(int tenderId) throws Exception {
	        Map<String, Object> parameter = new HashMap<String, Object>();
	        parameter.put(TENDERID, tenderId);
	        StringBuilder query = new StringBuilder("DELETE TblDocument tblDocument")
	        .append(" WHERE objectId IN(SELECT formId FROM TblTenderForm tblTenderForm WHERE tblTenderForm.tblTender.tenderId=:tenderId)");
	        return hibernateQueryDao.updateDeleteNewQuery(query.toString(), parameter);  
	   }
	 
	 /**
		 * Add Event Payment Mode Type
		 * @author Hira Chaudhary
		 * @throws Exception
	 */
    public boolean addTenderPaymentType(List<TblEventPayment> tblEventPayments) {
    	boolean bSuccess = false;
    	tblEventPaymentDao.saveUpdateAllTblEventPayment(tblEventPayments);
    	bSuccess = true;
		return bSuccess;
	}
	 
	 /**
	 * update Event Payment Mode Type
	 * @author Hira Chaudhary
	 * @param int tenderId
	 * @param int moduleId
	 * @throws Exception
	 */
	 public int updateEventPaymentType(int tenderId,int moduleId) {
		 Map<String, Object> var = new HashMap<String, Object>();
	     var.put(TENDERID, tenderId);
	     var.put("moduleId", moduleId);
	     return hibernateQueryDao.updateDeleteNewQuery("update TblEventPayment tbleventPayment set tbleventPayment.isActive=0 where tbleventPayment.objectId = :tenderId and tbleventPayment.moduleId =:moduleId", var);
	 }	 
	 
	 /**
	     * To get Event Mode Payment Type
	     * @author Hira Chaudhary
	     * @return
	     * @throws Exception
	  */
	 public List<Object[]> getEventPaymentType(int tenderId, int clientId, int PayMode, int PayFor, int moduleId){
		 List<Object[]> list = null;
		 Map<String, Object> var = new HashMap<String, Object>();
	     StringBuilder query = new StringBuilder();
	     var.put("clientId",clientId);
	     var.put("tenderId",tenderId);	     
	     var.put("PayFor",PayFor);
	     var.put("moduleId",moduleId);
	 	 query.append("select tblpaymenttype.paymentTypeId, tblpaymenttype.lang"+WebUtils.getCookie(getServletRequest(), "locale").getValue()+",tbleventPayment.tblPaymentType.paymentTypeId ");
    	 query.append(" from TblEventPayment tbleventPayment inner join  tbleventPayment.tblPaymentType tblpaymenttype ");
    	 query.append(" where tbleventPayment.tblClient.clientId =:clientId and tbleventPayment.objectId =:tenderId ");
    	 query.append(" and tbleventPayment.moduleId =:moduleId and tbleventPayment.paymentFor =:PayFor and tbleventPayment.isActive = 1");
 
	     list = hibernateQueryDao.createNewQuery(query.toString(),var);  
		 
	     return list;
		 
	 }
	 
	 /**
	  *	To get Bidder details by keywords
	  * @author meghna
	  * @param String keywordText
	  * @param int clientId
	  */
	 public List<Object[]> getCompanyDetailsByKeyword(String keywordText,int clientId) throws Exception{
    	 Map<String, Object> var = new HashMap<String, Object>();
    	 StringBuilder query = new StringBuilder();
    	 String searchArry[] = keywordText.split(",");
    	 var.put("clientId",clientId);
    	 query.append("select distinct tblbidderstatus.tblUserLogin.loginId,isnull(tblcompany.keywordText,'')");
    	 query.append(" from TblBidderStatus tblbidderstatus");
    	 query.append(" inner join tblbidderstatus.tblCompany tblcompany where");
    	 for(int i=0;i<searchArry.length;i++){
    		 if(i!=searchArry.length-1){
    			 if(i==0){
    	 				query.append(" (tblcompany.keywordText like '%").append(searchArry[i].trim()).append("%' or");
    	 			}else{
    	 				query.append(" tblcompany.keywordText like '%").append(searchArry[i].trim()).append("%' or");
    	 			}	
    		 }else{
    			 query.append(" tblcompany.keywordText like '%").append(searchArry[i].trim()).append("%'");
    		 }
    	 }
    	 if(searchArry.length>1){
    	 		query.append(")");
    	 }
    	 query.append(" and tblbidderstatus.cstatus=1 and tblbidderstatus.tblClient.clientId=:clientId");
    	 List<Object[]> lst = hibernateQueryDao.createNewQuery(query.toString(), var);
		 return lst;
     }
	 
	 /**
	  *	To get Bidder details by keywords
	  * @author meghna
	  * @param String keywordText
	  * @param int clientId
	  * @param int linkId
	  */
	 public List<Object[]> getBidderDetailByKeyword(String keywordText,int clientId,int linkId) throws Exception{
    	 Map<String, Object> var = new HashMap<String, Object>();
    	 StringBuilder query = new StringBuilder();
    	 String searchArry[] = keywordText.split(",");
    	 var.put("clientId",clientId);
    	 var.put("linkId", linkId);
    	 query.append("SELECT DISTINCT UL.loginId as c0 ,UL.userId as c1");
    	 query.append(" from  appuser.tbl_BidderStatus BS");
    	 query.append(" inner join  appcommon.tbl_MapCategory MC on MC.objectId=BS.userId and MC.linkId=:linkId ");
    	 query.append(" inner join appclient.tbl_ProductCategory PC on PC.categoryId=MC.categoryId  and PC.clientId=:clientId");
    	 query.append(" inner join appuser.tbl_UserLogin UL on UL.userId=BS.userId where");
    	 for(int i=0;i<searchArry.length;i++){
    		 if(i!=searchArry.length-1){
    			 if(i==0){
    				 	query.append(" (PC.categoryName like '").append(searchArry[i].trim()).append("' or");
    	 			}else{
    	 				query.append(" PC.categoryName like '").append(searchArry[i].trim()).append("' or");
    	 			}	
    		 }else{
    			 query.append(" PC.categoryName like '").append(searchArry[i].trim()).append("'");
    		 }
    	 }
    	 if(searchArry.length>1){
    	 		query.append(")");
    	 }
    	 query.append(" and BS.cstatus=1 and BS.clientId=:clientId");
    	 int nVarCharColumnIndex [] = {0};
    	 List<Object[]> lst = hibernateQueryDao.createSQLQuery(query.toString(), var,nVarCharColumnIndex,2);
		 return lst;
     }
	 
	 /**
	  *	To get Bidder details with keywords by userId
	  * @author meghna
	  * @param List<Integer> userIdList
	  * @param int linkId
	  */
	 public List<Object[]> getCategoryNameListByUserId(List<Integer> userIdList,int linkId) {
		 	StringBuilder query = new StringBuilder();	
		 	Map<String,Object> var = new HashMap<String, Object>();
			var.put("userIdList", userIdList);
	    	var.put("linkId", linkId);
			query.append("select distinct tblMapCategory.objectId as c0,");
			query.append(" STUFF((SELECT distinct ',' + isnull(PC.categoryName,'') from  appclient.tbl_ProductCategory PC,appcommon.tbl_MapCategory MC");
			query.append(" where MC.objectId in (:userIdList) and MC.linkId =:linkId and MC.categoryId =PC.categoryId and tblMapCategory.objectId = MC.objectId");
			query.append(" FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') c1");
			query.append(" from appclient.tbl_ProductCategory tblProductCategory,appcommon.tbl_MapCategory tblMapCategory");
			query.append(" where tblMapCategory.objectId in (:userIdList) and tblMapCategory.linkId =:linkId and tblMapCategory.categoryId =tblProductCategory.categoryId ");
			int nVarCharColumnIndex [] = {1};
			List<Object[]> categoryList = hibernateQueryDao.createSQLQuery(query.toString(), var,nVarCharColumnIndex,2);
			return categoryList;
	}

	public List<Object[]> getItemBidderMapByTableidAndMapibidderid(int tableId, int mapBidderId) {
		StringBuilder query = new StringBuilder();	
	 	Map<String,Object> var = new HashMap<String, Object>();
		var.put("tableId", tableId);
    	var.put("mapBidderId", mapBidderId);
		query.append("select ibm.rowId from TblItemBidderMap ibm ");
		query.append(" where ibm.tblTenderBidderMap.mapBidderId=:mapBidderId and ibm.tblTenderTable.tableId=:tableId ");
		List<Object[]> itemList = hibernateQueryDao.createNewQuery(query.toString(), var);
		return itemList;
	}
	
}
