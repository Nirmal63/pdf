package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblEncodeDecodeHistory;
import java.util.List;

public interface TblEncodeDecodeHistoryDao  {

    public void addTblEncodeDecodeHistory(TblEncodeDecodeHistory tblEncodeDecodeHistory);

    public void deleteTblEncodeDecodeHistory(TblEncodeDecodeHistory tblEncodeDecodeHistory);

    public void updateTblEncodeDecodeHistory(TblEncodeDecodeHistory tblEncodeDecodeHistory);

    public List<TblEncodeDecodeHistory> getAllTblEncodeDecodeHistory();

    public List<TblEncodeDecodeHistory> findTblEncodeDecodeHistory(Object... values) throws Exception;

    public List<TblEncodeDecodeHistory> findByCountTblEncodeDecodeHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEncodeDecodeHistoryCount();

    public void saveUpdateAllTblEncodeDecodeHistory(List<TblEncodeDecodeHistory> tblEncodeDecodeHistorys);
}