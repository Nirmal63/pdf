package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderReport;
import java.util.List;

public interface TblTenderReportDao  {

    public void addTblTenderReport(TblTenderReport tblTenderReport);

    public void deleteTblTenderReport(TblTenderReport tblTenderReport);

    public void updateTblTenderReport(TblTenderReport tblTenderReport);

    public List<TblTenderReport> getAllTblTenderReport();

    public List<TblTenderReport> findTblTenderReport(Object... values) throws Exception;

    public List<TblTenderReport> findByCountTblTenderReport(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderReportCount();

    public void saveUpdateAllTblTenderReport(List<TblTenderReport> tblTenderReports);

	public void saveOrUpdateTblTenderReport(TblTenderReport tblTenderReport);
}
