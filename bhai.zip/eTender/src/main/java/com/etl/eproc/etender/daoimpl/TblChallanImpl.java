package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblChallanDao;
import com.etl.eproc.etender.model.TblChallan;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblChallanImpl extends AbcAbstractClass<TblChallan> implements TblChallanDao {


    @Override
    public void addTblChallan(TblChallan tblChallan){
        super.addEntity(tblChallan);
    }

    @Override
    public void deleteTblChallan(TblChallan tblChallan) {
        super.deleteEntity(tblChallan);
    }

    @Override
    public void updateTblChallan(TblChallan tblChallan) {
        super.updateEntity(tblChallan);
    }

    @Override
    public List<TblChallan> getAllTblChallan() {
        return super.getAllEntity();
    }

    @Override
    public List<TblChallan> findTblChallan(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblChallanCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblChallan> findByCountTblChallan(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblChallan(List<TblChallan> tblChallans){
        super.updateAll(tblChallans);
    }
}
