package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblConsortiumDetailDao;
import com.etl.eproc.etender.model.TblConsortiumDetail;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblConsortiumDetailImpl extends AbcAbstractClass<TblConsortiumDetail> implements TblConsortiumDetailDao {


    @Override
    public void addTblConsortiumDetail(TblConsortiumDetail tblConsortiumDetail){
        super.addEntity(tblConsortiumDetail);
    }

    @Override
    public void deleteTblConsortiumDetail(TblConsortiumDetail tblConsortiumDetail) {
        super.deleteEntity(tblConsortiumDetail);
    }

    @Override
    public void updateTblConsortiumDetail(TblConsortiumDetail tblConsortiumDetail) {
        super.updateEntity(tblConsortiumDetail);
    }

    @Override
    public List<TblConsortiumDetail> getAllTblConsortiumDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblConsortiumDetail> findTblConsortiumDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblConsortiumDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblConsortiumDetail> findByCountTblConsortiumDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblConsortiumDetail(List<TblConsortiumDetail> tblConsortiumDetails){
        super.updateAll(tblConsortiumDetails);
    }
}
