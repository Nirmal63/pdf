package com.etl.eproc.etender.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblBidderDocFolderDao;
import com.etl.eproc.common.daointerface.TblBidderDocMappingDao;
import com.etl.eproc.common.daointerface.TblBidderDocumentDao;
import com.etl.eproc.common.daointerface.TblExemptionCertConfDao;
import com.etl.eproc.common.model.TblBidderDocFolder;
import com.etl.eproc.common.model.TblBidderDocMapping;
import com.etl.eproc.common.model.TblBidderDocument;
import com.etl.eproc.common.model.TblExemptionCertConf;
import com.etl.eproc.common.utility.AbcUtility;

import javax.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.WebUtils;

@Service
public class TenderBriefcaseService{

    @Autowired
    private HibernateQueryDao hibernateQueryDao;    
    @Autowired
    private TblBidderDocumentDao tblBidderDocumentDao;
    @Autowired
    private TblBidderDocFolderDao tblBidderDocFolderDao;
    @Autowired
    private TblBidderDocMappingDao tblBidderDocMappingDao;
    @Autowired
    private TblExemptionCertConfDao tblExemptionCertConfDao;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private AbcUtility abcUtility;

    /**
     * to add bidder document
     * @param tblBidderDocument
     * @return boolean
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addBidderDocument(TblBidderDocument tblBidderDocument,TblBidderDocMapping tblBidderDocMapping) throws Exception{
    	boolean bSuccess = false;             
        tblBidderDocumentDao.addTblBidderDocument(tblBidderDocument);
        bSuccess=true;
        if(bSuccess && tblBidderDocument.getBidderDocId() != 0 && tblBidderDocMapping != null){
        	tblBidderDocMapping.setTblBidderDocument(new TblBidderDocument(tblBidderDocument.getBidderDocId()));
        	tblBidderDocMappingDao.addTblBidderDocMapping(tblBidderDocMapping);
        	bSuccess=true;
        }
        return bSuccess;

    }
    public HttpServletRequest getServletRequest() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return attr.getRequest();
    }
    /**
     * to add bidder folder
     * @param tblBidderDocFolder
     * @return boolean
     * @throws Exception 
     */
    public boolean addBidderDocFolder(TblBidderDocFolder tblBidderDocFolder) throws Exception{
    	boolean bSuccess = false;             
        tblBidderDocFolderDao.saveOrUpdateTblBidderDocFolder(tblBidderDocFolder);
        bSuccess=true;        
        return bSuccess;
    }
    
    /**
     * to get bidder folder
     * @param userId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getBidderFolder(int userId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId",userId);
        return hibernateQueryDao.createNewQuery("select tblbidderdocfolder.bidderFolderId, tblbidderdocfolder.folderName from TblBidderDocFolder tblbidderdocfolder where tblbidderdocfolder.tblUserLogin.userId=:userId",var);        

    }
    
    /**
     * to get bidder doc foldert
     * @param folderId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getFolderDetailsFromFolderId(int folderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("folderId",folderId);
        return hibernateQueryDao.createNewQuery("select tblbidderdocfolder.bidderFolderId, tblbidderdocfolder.folderName from TblBidderDocFolder tblbidderdocfolder where tblbidderdocfolder.bidderFolderId=:folderId",var);        

    }
    
    /**
     * delete folder
     * @param folderId
     * @return
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean deleteFolder(int folderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("folderId",folderId);
        hibernateQueryDao.updateDeleteNewQuery("update TblBidderDocument set bidderFolderId=0 where bidderFolderId=:folderId",var);
        hibernateQueryDao.updateDeleteNewQuery("delete from TblBidderDocFolder tblbidderdocfolder where tblbidderdocfolder.bidderFolderId=:folderId",var);        
        return true;
    }
    
    
    /**
     * to get bidder doc foldert
     * @param userId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getBidderFolderForMoveToFolder(int userId,int folderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId",userId);
        var.put("folderId",folderId);
        return hibernateQueryDao.createNewQuery("select tblbidderdocfolder.bidderFolderId, tblbidderdocfolder.folderName from TblBidderDocFolder tblbidderdocfolder where tblbidderdocfolder.tblUserLogin.userId=:userId and tblbidderdocfolder.bidderFolderId != :folderId",var);        

    }
    
    /**
     * to get bidder folder
     * @param userId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getBidderDocuments(int userId,int clientId,int tabId,int folderId,String docDesc,int linkId,int objectId,int isEncryptionReq) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId",userId);
        var.put("clientId",clientId);
        var.put("linkId",linkId);
        var.put("objectId",objectId);
        var.put("isEncryptionReq",isEncryptionReq);
        StringBuilder query=new StringBuilder("select tblbidderdocument.bidderDocId, tblbidderdocument.bidderFolderId, tblbidderdocument.fileSize, tblbidderdocument.createdOn, ");
        query.append(" (select tblbidderdocfolder.folderName from TblBidderDocFolder tblbidderdocfolder where tblbidderdocfolder.bidderFolderId= tblbidderdocument.bidderFolderId ) As folderName, tblbidderdocument.docName, tblbidderdocument.description ");
        query.append(" ,(select count(bidderDocMappingId) from TblBidderDocMapping tblbidderdocmapping where tblbidderdocmapping.tblBidderDocument.bidderDocId=tblbidderdocument.bidderDocId AND tblbidderdocmapping.cstatus = 1) As cntMapDoc ");
        query.append(" ,(select count(bidderDocMappingId) from TblBidderDocMapping tblbidderdocmapping where tblbidderdocmapping.tblBidderDocument.bidderDocId=tblbidderdocument.bidderDocId AND tblbidderdocmapping.cstatus = 1 AND tblbidderdocmapping.tblLink.linkId=:linkId AND tblbidderdocmapping.objectId=:objectId) As cntMapDocCheck ");
        query.append(" from TblBidderDocument tblbidderdocument ");
        query.append(" where tblbidderdocument.cstatus = 1 and tblbidderdocument.tblClient.clientId=:clientId and tblbidderdocument.createdBy=:userId and tblbidderdocument.isEncryptionReq=:isEncryptionReq ");
        if(folderId != 0){
        	var.put("folderId",folderId);
        	query.append(" and tblbidderdocument.bidderFolderId =:folderId ");
        }
        if(tabId == 1){
        	query.append(" and tblbidderdocument.bidderFolderId != 0 and tblbidderdocument.isArchive = 0 ");
        }
        if(tabId == 2){
        	query.append(" and tblbidderdocument.isArchive = 1 ");
        }
        if(tabId == 3){
        	query.append(" and tblbidderdocument.bidderFolderId = 0 and tblbidderdocument.isArchive = 0 ");
        }
        if(docDesc != null){
        	var.put("description","%"+docDesc+"%");
        	query.append(" and tblbidderdocument.description like :description ");
        }
        return hibernateQueryDao.createNewQuery(query.toString(),var);        

    }
    
    /**
     * to get bidder doc details based on the doc id
     * @param docId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getBidderDocDetails(String docId) throws Exception{
        List<Integer> docIds = new ArrayList<Integer>(); 
        for (int i = 0; i < docId.split(",").length; i++) {
			docIds.add(Integer.parseInt(docId.split(",")[i]));
		}
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("docId", docIds);
        return hibernateQueryDao.createNewQuery("select tblbidderdocument.docName, tblbidderdocument.path from TblBidderDocument tblbidderdocument where tblbidderdocument.bidderDocId in (:docId)",var);        
    }

    /**
     * to change the status of the bidder documents
     * @param docId
     * @param cStatusDoc
     * @return
     * @throws Exception 
     */
    public boolean updateBidderDocStatus(String docId,int cStatusDoc) throws Exception{
        int cnt = 0;
        List<Integer> docIds = new ArrayList<Integer>(); 
        for (int i = 0; i < docId.split(",").length; i++) {
			docIds.add(Integer.parseInt(docId.split(",")[i]));
		}
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("docId", docIds);
        var.put("cStatusDoc",cStatusDoc);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblBidderDocument set cstatus=:cStatusDoc where bidderDocId in (:docId)",var);        
        return cnt!=0;

    }
    
    /**
     * to get bidder doc details based on the doc id
     * @param docId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getBidderDocDetails(int docId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("docId",docId);
        return hibernateQueryDao.createNewQuery("select tblbidderdocument.docName, tblbidderdocument.path,tblbidderdocument.isEncryptionReq from TblBidderDocument tblbidderdocument where tblbidderdocument.bidderDocId=:docId",var);        
    }
    
    /**
     * to archive document
     * @param docId
     * @return boolean
     * @throws Exception 
     */
    public boolean archiveDocuments(String docId) throws Exception{
        int cnt = 0;
        List<Integer> docIds = new ArrayList<Integer>(); 
        for (int i = 0; i < docId.split(",").length; i++) {
			docIds.add(Integer.parseInt(docId.split(",")[i]));
		}
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("docId", docIds);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblBidderDocument set isArchive=1 where bidderDocId in (:docId)",var);        
        return cnt!=0;

    }
    
    /**
     * to map documents
     * @param tblBidderDocMappingList
     * @return boolean
     * @throws Exception 
     */
    public boolean mapDocuments(List<TblBidderDocMapping> tblBidderDocMappingList) throws Exception{
    	boolean bSuccess = false;             
        tblBidderDocMappingDao.saveUpdateAllTblBidderDocMapping(tblBidderDocMappingList);
        bSuccess=true;        
        return bSuccess;
    }

    
    /**
     * to get mapped documents
     * @param userId
     * @param clientId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getMapedDocuments(int userId,int clientId,int objectId,int linkId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId",userId);
        var.put("clientId",clientId);
        var.put("objectId",objectId);
        var.put("linkId",linkId);
        StringBuilder query=new StringBuilder("select distinct tblbidderdocmapping.bidderDocMappingId, tblbidderdocument.bidderFolderId, tblbidderdocument.fileSize, tblbidderdocument.createdOn, ");
        //query.append(" (select tblbidderdocfolder.folderName from TblBidderDocFolder tblbidderdocfolder where tblbidderdocfolder.bidderFolderId= tblbidderdocument.bidderFolderId ) As folderName, tblbidderdocument.docName, tblbidderdocument.description,tblbidderdocument.bidderDocId ");
        query.append(" (select tbldocument.documentName from TblDocument tbldocument where tbldocument.documentId= tblbidderdocmapping.documentId ) As mandatoryDocName, tblbidderdocument.docName, tblbidderdocument.description,tblbidderdocument.bidderDocId ");
        query.append(" from  TblBidderDocMapping tblbidderdocmapping  inner join  tblbidderdocmapping.tblBidderDocument tblbidderdocument ");
        query.append(" where tblbidderdocmapping.cstatus = 1 and tblbidderdocument.tblClient.clientId=:clientId and tblbidderdocument.createdBy=:userId and tblbidderdocmapping.objectId=:objectId ");
        query.append(" and tblbidderdocmapping.tblLink.linkId=:linkId ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);        

    }
    
    /**
     * to unmap document
     * @param docId
     * @return boolean
     * @throws Exception 
     */
    public boolean  unMapDocuments(String docId) throws Exception{
        int cnt = 0;
        List<Integer> docIds = new ArrayList<Integer>(); 
        for (int i = 0; i < docId.split(",").length; i++) {
			docIds.add(Integer.parseInt(docId.split(",")[i]));
		}
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("docId", docIds);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblBidderDocMapping set cstatus=0 where bidderDocMappingId in (:docId)",var);        
        return cnt!=0;
    }
    
    /**
     * to Move document
     * @param docId
     * @return boolean
     * @throws Exception 
     */
    public boolean  moveToFolder(String docId,int folderId) throws Exception{
        int cnt = 0;
        List<Integer> docIds = new ArrayList<Integer>(); 
        for (int i = 0; i < docId.split(",").length; i++) {
			docIds.add(Integer.parseInt(docId.split(",")[i]));
		}
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("docId", docIds);
        var.put("folderId", folderId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblBidderDocument set bidderFolderId=:folderId where bidderDocId in (:docId)",var);        
        return cnt!=0;
    }
    
    /**
     * to get documents check list
     * @param objectId
     * @param linkId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getDocumentCheckList(int objectId,int linkId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("objectId",objectId);
        var.put("linkId",linkId);
        return hibernateQueryDao.createNewQuery("select tbldocument.documentId, tbldocument.documentName,tbldocument.isMandatory from TblDocument tbldocument where tbldocument.tblLink.linkId=:linkId and tbldocument.objectId=:objectId",var);        

    }
     
    public List<Object[]> getMandatoryDoc(int objectId,int linkId) throws Exception{
        StringBuilder query = new StringBuilder();
        query.append("select distinct d.documentId,d.documentName,bd.cstatus from appcommon.tbl_Document d ");
        query.append("left join  appuser.tbl_BidderDocMapping bd  on bd.documentId = d.documentId ");
        query.append("where d.linkId = ").append(linkId).append(" and  d.documentId in (select td.documentId from appcommon.tbl_Document td where td.objectId =").append(objectId).append(")");
        query.append(" order by bd.cstatus");
        return abcUtility.convertMapListToObjArrayList(jdbcTemplate.queryForList(query.toString())); 
    }
    
    /**
     * to get mandatory pending document count
     * @param linkId
     * @param objectId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getMandatoryPendingDocCount(int manDocLinkId, int objectId,int linkId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("manDocLinkId",manDocLinkId);
        var.put("linkId",linkId);
        var.put("objectId",objectId);
        StringBuilder query = new StringBuilder();
        query.append("select COUNT(tbldocument.documentId) ,").
        append("(select count(distinct tblbidderdocmapping.documentId) from TblBidderDocMapping tblbidderdocmapping where tblbidderdocmapping.documentId=tbldocument.documentId and ").
        append(" tblbidderdocmapping.childId=:objectId and tblbidderdocmapping.tblLink.linkId=:linkId and tblbidderdocmapping.cstatus=1) ").
        append(" from TblDocument tbldocument ").
        append(" where tbldocument.isMandatory=1 and tbldocument.tblLink.linkId=:manDocLinkId and tbldocument.objectId=:objectId");
        return hibernateQueryDao.createQuery(query.toString(), var);
    }
    
    /**
     * to get folderId from the bidderDocId
     * @param bidderDocId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getFolderIdFromDocId(int bidderDocId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidderDocId",bidderDocId);
        return hibernateQueryDao.createNewQuery("select tblbidderdocument.bidderFolderId, tblbidderdocument.bidderDocId from TblBidderDocument tblbidderdocument where tblbidderdocument.bidderDocId=:bidderDocId",var);        
    }
    
    /**
     * to get manadatory document count
     * @param linkId
     * @param objectId
     * @return long
     * @throws Exception 
     */
    public long getMandatoryDocCount(int linkId,int objectId) throws Exception{
        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("linkId",linkId);
        var.put("objectId",objectId);
        count = hibernateQueryDao.countForNewQuery("TblDocument tbldocument ","tbldocument.documentId ","tbldocument.tblLink.linkId=:linkId and tbldocument.objectId=:objectId and tbldocument.isMandatory=1",var);
        return count;
    }
    
    public long getUploadedMandatoryDocs(int linkId,int objectId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("linkId",linkId);
        var.put("objectId",objectId);
        StringBuilder query=new StringBuilder("select count(distinct tbldocument.documentId) ");
        query.append(" from TblBidderDocMapping tblbidderdocmapping, TblDocument tbldocument ");
        query.append(" where tblbidderdocmapping.documentId = tbldocument.documentId and tbldocument.isMandatory = 1 and tblbidderdocmapping.childId=:objectId and tblbidderdocmapping.tblLink.linkId=:linkId and tblbidderdocmapping.cstatus=1  ");
        List<Object> data= hibernateQueryDao.getSingleColQuery(query.toString(),var);
        return !data.isEmpty() ? Long.parseLong(data.get(0).toString()) : 0;
    }
    
    public List<Object[]> getMandatoryDocument(int linkId,int objectId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("linkId",linkId);
        var.put("objectId",objectId);
        return hibernateQueryDao.createNewQuery("select tbldocument.documentId, tbldocument.documentName from TblDocument tbldocument where tbldocument.tblLink.linkId=:linkId and tbldocument.objectId=:objectId and tbldocument.isMandatory=1",var);        
    }
    
    public List<Object[]> getUploadedDocs(int linkId,int objectId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("linkId",linkId);
        var.put("objectId",objectId);
        StringBuilder query=new StringBuilder("select distinct tblbidderdocmapping.documentId,tblbidderdocument.docName ");
        query.append(" from TblBidderDocMapping tblbidderdocmapping ");
        query.append(" INNER JOIN tblbidderdocmapping.tblBidderDocument  tblbidderdocument ");
        query.append(" where tblbidderdocmapping.objectId=:objectId and tblbidderdocmapping.tblLink.linkId=:linkId and tblbidderdocmapping.cstatus=1  ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);
    }
     /**
     * author: heeral.soni
     * used to get ExemptionCertificate
     * @param clientId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getExemptionCertificateType(int clientId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        StringBuilder query = new StringBuilder();
        var.put("clientId",clientId);
                
        query.append("select tblexemptioncertificate.exemptionCertificateId,tblexemptioncertificate.lang").append(WebUtils.getCookie(getServletRequest(), "locale").getValue());
        query.append(" from TblExemptionCertificate tblexemptioncertificate ");
        query.append("inner join tblexemptioncertificate.tblClientExemptionCertificate tblclientexemptioncertificate ");
        query.append("where tblclientexemptioncertificate.isActive = 1 and tblclientexemptioncertificate.tblClient.clientId=:clientId");
        //System.out.println("getExemptionCertificateType query:--------tblClientExemptionCertificate-------->"+query.toString());
        return hibernateQueryDao.createNewQuery(query.toString(),var);        
    }
    
     /**
     * author: heeral.soni
     * used to get ExemptionCertificate
     * @param clientId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getExemptionConfigurationDetail(int companyId,int clientId) throws Exception{
        StringBuilder query = new StringBuilder();
        query.append("select exconf.exemptionCertConfId as c0,exconf.certificateNo as c1,exconf.certificateType as c2,exconf.certificateFrom as c3,exconf.certificateUpTo as c4, ");
        query.append("bd.docName as c5,bd.description as c6,bd.fileSize as c7,bd.createdOn as c8,bdmap.bidderDocMappingId as c9, ");
        query.append("ex.lang").append(WebUtils.getCookie(getServletRequest(), "locale").getValue()).append(" as c10 ");
        query.append("from appuser.tbl_ExemptionCertConf exconf ");
        query.append("inner join appuser.tbl_Company cmp on cmp.companyId = exconf.companyId ");
        query.append("inner join appclient.tbl_ClientExemptionCertificate clexe on clexe.exemptionCertificateId = exconf.exemptionCertificateId ");
        query.append("inner join appmaster.tbl_ExemptionCertificate ex on ex.exemptionCertificateId = clexe.exemptionCertificateId ");
        query.append("left join appuser.tbl_BidderDocMapping bdmap on exconf.exemptionCertConfId = bdmap.objectId  and bdmap.linkId = 427 ");
        query.append("left join appuser.tbl_BidderDocument bd on bd.bidderDocId = bdmap.bidderDocId ");
        query.append(" where exconf.companyId =").append(companyId).append(" and clexe.clientId=").append(clientId).append(" and clexe.isActive = 1 ");
        query.append(" order by exconf.exemptionCertConfId  desc");
        
        return abcUtility.convertMapListToObjArrayList(jdbcTemplate.queryForList(query.toString())); 
    }
   
        /**
     * author : heeral.soni
     * @param TblExemptionCertConf
     * @return
     * @throws Exception 
     */
    public boolean addExemptionCertDetails(TblExemptionCertConf tblExemptionCertConf) throws Exception{
        boolean bSuccess = false;            
        tblExemptionCertConfDao.addTblExemptionCertConf(tblExemptionCertConf);
        bSuccess=true;                
        return bSuccess;
    }
    
    /**author :heeral.soni
     * to check nsic is configured or not
     * @param clientId
     * @return
     * @throws Exception 
     */
    public boolean isNSICConfigure(int clientId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId",clientId);
        
        StringBuilder query = new StringBuilder();
        query.append("select tblclientpayment.tblPaymentType.paymentTypeId ");
        query.append("from  TblClientPayment tblclientpayment ");
        query.append("inner join  tblclientpayment.tblPaymentType tblpaymenttype ");
        query.append("where tblclientpayment.tblClient.clientId=:clientId and tblclientpayment.tblPaymentType.paymentTypeId =6 and ");
        query.append("tblclientpayment.isActive=1");
        //System.out.println("query isNSICConfigure:--->"+query.toString());
        
        List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(),var);                
        return !list.isEmpty() ? true : false;
    }
    

}

