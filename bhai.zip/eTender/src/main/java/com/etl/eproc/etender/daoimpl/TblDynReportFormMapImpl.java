package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblDynReportFormMapDao;
import com.etl.eproc.etender.model.TblDynReportFormMap;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblDynReportFormMapImpl extends AbcAbstractClass<TblDynReportFormMap> implements TblDynReportFormMapDao {


    @Override
    public void addTblDynReportFormMap(TblDynReportFormMap tblDynReportFormMap){
        super.addEntity(tblDynReportFormMap);
    }

    @Override
    public void deleteTblDynReportFormMap(TblDynReportFormMap tblDynReportFormMap) {
        super.deleteEntity(tblDynReportFormMap);
    }

    @Override
    public void updateTblDynReportFormMap(TblDynReportFormMap tblDynReportFormMap) {
        super.updateEntity(tblDynReportFormMap);
    }

    @Override
    public List<TblDynReportFormMap> getAllTblDynReportFormMap() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynReportFormMap> findTblDynReportFormMap(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynReportFormMapCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynReportFormMap> findByCountTblDynReportFormMap(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDynReportFormMap(List<TblDynReportFormMap> tblDynReportFormMaps){
        super.updateAll(tblDynReportFormMaps);
    }
}
