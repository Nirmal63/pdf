package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblFinalSubmissionDao;
import com.etl.eproc.etender.model.TblFinalSubmission;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblFinalSubmissionImpl extends AbcAbstractClass<TblFinalSubmission> implements TblFinalSubmissionDao {

  

    @Override
    public void addTblFinalSubmission(TblFinalSubmission tblFinalSubmission){
        super.addEntity(tblFinalSubmission);
    }

    @Override
    public void deleteTblFinalSubmission(TblFinalSubmission tblFinalSubmission) {
        super.deleteEntity(tblFinalSubmission);
    }

    @Override
    public void updateTblFinalSubmission(TblFinalSubmission tblFinalSubmission) {
        super.updateEntity(tblFinalSubmission);
    }

    @Override
    public List<TblFinalSubmission> getAllTblFinalSubmission() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFinalSubmission> findTblFinalSubmission(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFinalSubmissionCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFinalSubmission> findByCountTblFinalSubmission(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFinalSubmission(List<TblFinalSubmission> tblFinalSubmissions){
        super.updateAll(tblFinalSubmissions);
    }
}
