package com.etl.eproc.etender.databean;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class GetExcelDataBean implements Comparable<GetExcelDataBean> {

	private String projectID;
	private String ProjectName;
	private String bOQType;
	private String bOQDescription;
	private String bOQNo;
	private String bOQItem;
	private String customerNo;
	private String customerName;
	private String material;
	private String UoM;
	private String Description;
	private int materialGroup;
	private String packageDescription;
	private String qtyInBOQ;
	private String salesPrice;
	private String amountInBOQ;
	private String prNo;
	private String prItem;
	private String plantCode;

	public String getProjectID() {
		return projectID;
	}

	public void setProjectID(String projectID) {
		this.projectID = projectID;
	}

	public String getProjectName() {
		return ProjectName;
	}

	public void setProjectName(String projectName) {
		ProjectName = projectName;
	}

	public String getbOQType() {
		return bOQType;
	}

	public void setbOQType(String bOQType) {
		this.bOQType = bOQType;
	}

	public String getbOQDescription() {
		return bOQDescription;
	}

	public void setbOQDescription(String bOQDescription) {
		this.bOQDescription = bOQDescription;
	}

	public String getbOQNo() {
		return bOQNo;
	}

	public void setbOQNo(String bOQNo) {
		this.bOQNo = bOQNo;
	}

	public String getbOQItem() {
		return bOQItem;
	}

	public void setbOQItem(String bOQItem) {
		this.bOQItem = bOQItem;
	}

	public String getCustomerNo() {
		return customerNo;
	}

	public void setCustomerNo(String customerNo) {
		this.customerNo = customerNo;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getMaterial() {
		return material;
	}

	public void setMaterial(String material) {
		this.material = material;
	}

	public String getUoM() {
		return UoM;
	}

	public void setUoM(String uoM) {
		UoM = uoM;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public int getMaterialGroup() {
		return materialGroup;
	}

	public void setMaterialGroup(int materialGroup) {
		this.materialGroup = materialGroup;
	}

	public String getPackageDescription() {
		return packageDescription;
	}

	public void setPackageDescription(String packageDescription) {
		this.packageDescription = packageDescription;
	}

	public String getQtyInBOQ() {
		return qtyInBOQ;
	}

	public void setQtyInBOQ(String qtyInBOQ) {
		this.qtyInBOQ = qtyInBOQ;
	}

	public String getSalesPrice() {
		return salesPrice;
	}

	public void setSalesPrice(String salesPrice) {
		this.salesPrice = salesPrice;
	}

	public String getAmountInBOQ() {
		return amountInBOQ;
	}

	public void setAmountInBOQ(String amountInBOQ) {
		this.amountInBOQ = amountInBOQ;
	}

	public String getPrNo() {
		return prNo;
	}

	public void setPrNo(String prNo) {
		this.prNo = prNo;
	}

	public String getPrItem() {
		return prItem;
	}

	public void setPrItem(String prItem) {
		this.prItem = prItem;
	}
	
	public String getPlantCode() {
		return plantCode;
	}
	public void setPlantCode(String plantCode) {
		this.plantCode = plantCode;
	}

	@Override
	public int compareTo(GetExcelDataBean o) {
		// TODO Auto-generated method stub
		return this.getMaterialGroup() - o.getMaterialGroup();
	}

}
