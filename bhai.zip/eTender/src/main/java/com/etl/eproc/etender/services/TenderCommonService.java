/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblPaymentGSTDetailsDao;
import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblCustomParameter;
import com.etl.eproc.common.model.TblEventEnquiry;
import com.etl.eproc.common.model.TblFavouriteEvent;
import com.etl.eproc.common.model.TblPaymentGSTDetails;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.utility.SendGCMNotification;
import com.etl.eproc.eauction.model.TblAuction;
import com.etl.eproc.common.daointerface.TblFavouriteTenderDao;
import com.etl.eproc.etender.daointerface.TblNotificationHistoryDao;
/*import com.etl.eproc.common.model.TblFavouriteTender;*/
import com.etl.eproc.etender.model.TblNotificationHistory;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;

import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.etender.daointerface.TblTenderDao;
import com.etl.eproc.etender.daointerface.TblTenderEnvelopeDao;
import com.etl.eproc.etender.daointerface.TblTenderPublicKeyDao;
import com.etl.eproc.etender.daointerface.TblTenderTableDao;
import com.etl.eproc.etender.daostoredprocedure.SPConvetSealBidToAuction;
import com.etl.eproc.etender.daostoredprocedure.SPTenderFinalSubmission;
import com.etl.eproc.etender.daostoredprocedure.SPTenderFormsList;
import com.etl.eproc.etender.daostoredprocedure.SPValidateTenderRules;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderPublicKey;
import com.etl.eproc.etender.model.TblTenderTable;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.etender.daointerface.TblTenderWiseBudgetDetailsDao;
import com.etl.eproc.etender.model.TblTenderWiseBudgetDetails;

/**
 *
 * @author TaherT
 */
@Service
public class TenderCommonService {

    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    @Autowired
    private TblTenderEnvelopeDao tblTenderEnvelopeDao;
    @Autowired
    private TblFavouriteTenderDao tblFavouriteTenderDao;
    @Autowired
    private TblTenderTableDao tblTenderTableDao;
    @Autowired
    private SPTenderFinalSubmission sPTenderFinalSubmission;
    @Autowired
    private SendGCMNotification sendGCMNotification;
    @Value("#{projectProperties['mobileapp.defaultAPClientId']?:1}")
    private int defaultAPClientId;
    @Value("#{tenderlinkProperties['tender_create_tender']?:212}")
    private int tendercreationlink;
    @Value("#{projectProperties['moduleId_tender']?:3}")
    private int moduleId;
    @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
	 private String queueName;
    @Value("#{eauctionProperties['event_enquiry_mail']?:409}")
	 private String eventEnquiryMailTemplateId;
	 @Value("#{linkProperties['event_enq_mail']?:5554}")
	 private int eventEnqmail;
    private static final String TENDER_ID = "tenderId";
    private static final String CLIENT_ID = "clientId";
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private MessageSource messageSource;
    @Autowired
    private TblTenderDao tblTenderDao;
    @Autowired
    private SPValidateTenderRules sPValidateTenderRules;
    @Autowired
    private TenderCorrigendumService tenderCorrigendumService;
    @Autowired
    private TblTenderWiseBudgetDetailsDao tblTenderWiseBudgetDetailsDao;
    @Autowired
    private TblNotificationHistoryDao tblNotificationHistoryDao;
    @Autowired
    private SPTenderFormsList spTenderFormsList;
    @Autowired 
    private SPConvetSealBidToAuction spConvetSealBidToAuction;
    @Autowired
    private EventBidSubmissionService eventBidSubmissionService;
    @Autowired
    private TblTenderPublicKeyDao tblTenderPublicKeyDao;
    @Autowired
    private EventCreationService eventCreationService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private ManageBidderService manageBidderService;
    @Autowired
    private TblPaymentGSTDetailsDao tblPaymentGSTDetailsDao;
	@Autowired
	private DepartmentUserService departmentUserService;
	@Autowired
	private MailContentUtillity mailContentUtillity;
    /**
     * Method use to fetch specific columns from TblTender. Pass comma separated filed. Do not pass space between comma and field name
     *
     * @param tenderId
     * @param field ex: field1,field2,...
     * @return {@code List<Object[]>}
     */
    public List<Object[]> getTenderFields(int tenderId, String field) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDER_ID, tenderId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append(" select ").append(field).append(" from TblTender ");
        strQuery.append(" where tenderId=:tenderId");
        return hibernateQueryDao.createNewQuery(strQuery.toString(), var);
    }
    
    /**
     * Method use to fetch specific columns from TblTender. Pass comma separated filed. Do not pass space between comma and field name
     *
     * @param tenderId
     * @param field ex: field1,field2,...
     * @return {@code List<Object[]>}
     */
    public Object getTenderField(int tenderId, String field) {
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDER_ID, tenderId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append(" select ").append(field).append(" from TblTender ");
        strQuery.append(" where tenderId=:tenderId");
        List<Object> ls = hibernateQueryDao.singleColQuery(strQuery.toString(), parameters);
        if (ls != null && !ls.isEmpty()) {
            return ls.get(0);
        }
        return null;
    }
    
    public List<Object[]> getListOfRespondedBidders(int tenderId,int clientId,int selectedTenderDetails,int isShowEncodedName){
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDER_ID, tenderId);
        parameters.put(CLIENT_ID, clientId);
        StringBuilder strQuery = new StringBuilder();

        if(selectedTenderDetails==1)
        {
        	
        	strQuery.append("select ul.loginId AS c0, c.companyName AS c1,ul.userId AS c2 ,fs.finalsubmissionId AS c3");
        	if(isShowEncodedName == 1)
        	{
        		strQuery.append(" ,tbc.encodedName as c4 ");	
        	}
        	
        	strQuery.append(" from apptenderbid.tbl_finalSubmission fs inner join appuser.tbl_UserLogin ul on fs.bidderId = ul.userId and fs.tenderId=:tenderId ");
        	if(isShowEncodedName == 1)
        	{
        		strQuery.append(" left join apptenderbid.Tbl_TenderBidConfirmation tbc on fs.tenderId = tbc.tenderId and tbc.bidderId = fs.bidderId ");
        	}
        	strQuery.append(" inner join appuser.tbl_BidderStatus bs on ul.userId = bs.userId and bs.clientId =:clientId ");
        	strQuery.append(" inner join appuser.tbl_Company c on c.companyId = bs.companyId; ");
        }
        else 
        {
        	
            strQuery.append(" select ul.loginId AS c0,c.companyName AS c1,result.bidderId AS c2,result.finalSubmissionId AS c3 ");
            if(isShowEncodedName == 1)
        	{
        		strQuery.append(" ,tbc.encodedName as c4 ");	
        	}
            
            strQuery.append(" from (select tbm.bidderId,fs.finalSubmissionId,tbm.tenderId from apptender.tbl_TenderBidderMap tbm left join apptenderbid.tbl_Finalsubmission fs on tbm.tenderId  = fs.tenderId and tbm.bidderId = fs.bidderId where tbm.tenderId=:tenderId )result ");
            if(isShowEncodedName == 1)
        	{
        		strQuery.append(" left join apptenderbid.Tbl_TenderBidConfirmation tbc on tbc.tenderId = result.tenderId  and tbc.bidderId = result.bidderId ");
        	}
            
            strQuery.append(" inner join appuser.tbl_UserLogin ul on  result.bidderId = ul.userId inner join appuser.tbl_BidderStatus bs on ul.userId = bs.userId and bs.clientId=:clientId inner join appuser.tbl_Company c on c.companyId = bs.companyId; ");
        }
        List<Object[]> ls = null;
        if(isShowEncodedName == 1)
        {
        	ls = hibernateQueryDao.createSQLQuery(strQuery.toString(),parameters,new int[]{0,1,4},5);
        }
        else
        {
        	ls = hibernateQueryDao.createSQLQuery(strQuery.toString(),parameters,new int[]{0,1},4);
        }
        
        if (ls != null && !ls.isEmpty()) {
            return ls;
        }
        return null;
    }
    
    public List<Object[]>  getFirstEnvelopeId(int tenderId)
    {
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDER_ID, tenderId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append(" select envelopeId,isOpened,isEvaluated,envId from apptender.tbl_TenderEnvelope a where a.tenderId=:tenderId and sortOrder = 1 and cstatus in (1,3); ");
        List<Object[]> ls = hibernateQueryDao.createSQLQuery(strQuery.toString(),parameters);
        if (ls != null && !ls.isEmpty()) {
           return ls;
        }
        return null;
    }
    public Boolean isAnyEnvelopeOpened(int tenderId)
    {
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put(TENDER_ID, tenderId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append(" select isOpened,isEvaluated,envId from apptender.tbl_TenderEnvelope a where a.tenderId=:tenderId and cstatus in (1,3); ");
        List<Object[]> ls = hibernateQueryDao.createSQLQuery(strQuery.toString(),parameters);
        if (ls != null && !ls.isEmpty()) 
        {
        	for(int i=0;i<ls.size();i++)
        	{
        		Byte value = (Byte) ls.get(i)[0];
        		if(value == 1)
        		{
        			return true;
        		}
        	}
        }
        return false;
    	
    }
    

    /**
     *
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderEnvelopeByTenderId(int tenderId, boolean isConsortium,boolean isMapBidder,List<Integer> cStatus) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("cStatus", cStatus);
        query.append("select distinct tbltenderenvelope.envelopeId,tbltenderenvelope.envelopeName,tbltenderenvelope.tblEnvelope.envId,tbltenderenvelope.minFormsReqForBidding,tbltenderenvelope.cstatus,tbltenderenvelope.minTechFormsReqForBidding from TblTenderEnvelope tbltenderenvelope ");
        if (isConsortium) {
            query.append(" inner join tbltenderenvelope.tblTenderForm tbltenderform with tbltenderform.isSecondary=1 and tbltenderform.cstatus in (1,2)");
        }
        query.append(" where tbltenderenvelope.tblTender.tenderId=:tenderId and tbltenderenvelope.cstatus in (:cStatus)");
        if(isMapBidder){
            query.append(" and tbltenderenvelope.tblEnvelope.envId=4 ");
        }
        query.append(" order by tbltenderenvelope.tblEnvelope.envId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    /**
    * @author DharmeshP
    * @param tenderId
    * @return
    * @throws Exception
    */
   public List<Object[]> isItemWiseDocAllowed(int tenderId) throws Exception {
       StringBuilder query = new StringBuilder();
       Map<String, Object> var = new HashMap<String, Object>();
       var.put("tenderId", tenderId);
       query.append("select isItemWiseDocAllowed From TblTenderForm WHERE tenderId = :tenderId AND isItemWiseDocAllowed = 1 ");
       return hibernateQueryDao.createNewQuery(query.toString(), var);       
   }
    /**
     *
     * @param tenderId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getTenderFormByTenderId(boolean isBidder, boolean isConsortium, int... objectId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", objectId[0]);
        query.append(" select tbltenderform.formId,tbltenderform.formName,tbltenderform.tblTenderEnvelope.envelopeId, ")
                .append(" case when tbltenderform.cstatus=0 then 'Pending' ")
                .append(" when tbltenderform.cstatus=1 then 'Approved' when tbltenderform.cstatus=2 then 'Cancelled' end ")
                .append(" ,tbltenderform.sortOrder ,tbltenderform.isMandatory ,tbltenderform.isSecondary ,tbltenderform.isPriceBid ")
                .append(" ,tbltenderform.isEncryptionReq ,tbltenderform.isMultipleFilling ,tbltenderform.isDocumentReq")
                .append(" ,(select count(tbldocument.documentId) from TblDocument tbldocument where tbldocument.objectId=tbltenderform.formId and tbldocument.tblLink.linkId = 317) ");
        query.append(" ,tbltenderform.isItemWiseDocAllowed,tbltenderform.tblTenderEnvelope.minFormsReqForBidding,tbltenderform.minTablesReqForBidding from TblTenderForm tbltenderform where tbltenderform.tblTender.tenderId=:tenderId ");
        if (objectId.length > 1 && objectId[1] == 0) {
            query.append(" and tbltenderform.cstatus=0 ");
        }
        if (isBidder) {
            if (objectId.length > 1 && objectId[1] == 1) {
                query.append(" and tbltenderform.cstatus=1");
            } else {
                query.append(" and tbltenderform.cstatus in (1,2)");
            }
            if (isConsortium) {
                query.append(" and tbltenderform.isSecondary=1");
            }
        }
        if((objectId.length == 5) && (objectId[2] == 2 || objectId[2] == 3 || objectId[2] == 4) && (objectId[3] == 1)){
            query.append(" and tbltenderform.formId in (");
            query.append(" select distinct tbltenderform.formId");
            query.append(" from TblTenderForm tbltenderform");
            query.append(" inner join tbltenderform.tblTenderTable tbltendertable");
            query.append(" left join tbltendertable.tblItemBidderMap tblitembiddermap");
            query.append(" left join tblitembiddermap.tblTenderBidderMap tbltenderbiddermap");
            query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus in (1,2) and ((tbltenderform.isPriceBid=1 and tbltenderbiddermap.tblCompany.companyId=").append(objectId[4]).append(") or tbltenderform.isPriceBid=0))");
        }
        query.append(" order by tbltenderform.tblTenderEnvelope.envelopeId,tbltenderform.sortOrder");
        //System.out.println("getTenderFormByTenderId query = " + query.toString());
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    /**
     * Use case : Tender Bidding Forms tab listing
     * @author nirav.modi
     * @param tenderId
     * @return <code>Map<String, Object></code>
     * @throws Exception 
     */
    public Map<String, Object> getTenderBiddingForm(int tenderId,int linkId) throws Exception{
		return spTenderFormsList.executeProcedure(tenderId,linkId);                
    }

    /**
     * To call SP and convert seal bid to auction
     * @author SULABH
     * @param tenderId
     * @param formId
     * @param clientId
     * @param createdBy
     * @return Map<String, Object>
     * @throws Exception
     */
    public Map<String, Object> createAuctionFromSealBid(int tenderId,int formId,int clientId,int createdBy,String ipAddress,int isDumpAllItem,int startPriceForAuction,int h1l1Bidder,int bidderMasking) throws Exception{
    	return spConvetSealBidToAuction.executeStoredProcedure(tenderId, formId, clientId, createdBy,ipAddress,isDumpAllItem,startPriceForAuction,h1l1Bidder,bidderMasking);
    }
    
    
    
    /**
     *
     * @param tenderId
     * @param Object>
     * @param clientId
     * @return
     * @throws Exception
     */
    public void tenderSummary(int tenderId, Map<String, Object> hashMap, int clientId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder query = new StringBuilder("select tbltender.evaluationMode, tbltender.isConsortiumAllowed, tbltender.tenderMode, tbltender.biddingType, tbltender.tenderResult,");
        query.append(" tbltender.tenderNo, tbldepartment.deptName,tbltender.tblEventType.eventTypeId,tbltender.documentStartDate,")
                .append("tbltender.documentEndDate,tbltender.downloadDocument,tbltender.submissionEndDate,tbltender.openingDate,")
                .append("tbltender.isCertRequired,tbltender.isMandatoryDocument,tbltender.isOpeningByCommittee,tbltender.isRebateForm,tbltender.tenderBrief,tbltender.corrigendumCount,tbltender.decimalValueUpto ")
                .append(",tbltender.brdMode,tbleventtype.lang" + WebUtils.getCookie(getServletRequest(), "locale").getValue()).append(",tbltender.isEvaluationByCommittee, tbltender.cstatus,tbltender.biddingVariant ")
                .append(",tbltender.isItemwiseWinner,tbltender.isEvaluationRequired,tbltender.officerId,tbltender.sorVariation,tbltender.isSORApplicable,tbltender.submissionMode,tbltender.isWorkflowRequired,tbltender.isEncodedName,tbltender.docFeePaymentMode,tbltender.emdPaymentMode,tbltender.isBidWithdrawal ")
                .append(",tbltender.isPartialFillingAllowed,tbltender.isEMDApplicable,tbltender.isItemSelectionPageRequired")
                .append(",tbltender.multiLevelEvaluationReq,tbltender.isTwoStageEvaluation,tbltender.isTwoStageOpening ")//41
                .append(",(select tblReviveTenderHistory.oldTenderId  from TblReviveTenderHistory tblReviveTenderHistory where tblReviveTenderHistory.newTenderId=tenderId),tbltender.isReworkRequired,tbltender.isSystemGeneratedTenderDoc, tbltender.envelopeType, tbltender.isWeightageEvaluationRequired ")
                .append(",tbltender.isSplitPOAllowed,tbltender.assignUserId,tbltender.submissionStartDate,tbltender.encryptionLevel,tbltender.isNegotiationAllowed,tbltender.workflowForTEC,tbltender.workflowForTOC ")
                .append(",tbltender.showNoOfBidders ")
                .append(",tbltender.isEMDByBidder,tbltender.isDocumentFeeByBidder,tbltender.isParticipationFeesBy,tbltender.isRestOfEventMoney,tbltender.isReEvaluationReq,tbltender.isItemwiseRegretAllowed ")
                .append(" from  TblTender tbltender  inner join  tbltender.tblDepartment tbldepartment  inner join tbltender.tblEventType tbleventtype ")
                .append(" where tbltender.tenderId=:tenderId ");
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);
        if (list != null && !list.isEmpty()) {
            hashMap.put("evaluationMode", list.get(0)[0]);
            hashMap.put("isConsortiumAllowed", list.get(0)[1]);
            hashMap.put("tenderMode", list.get(0)[2]);
            hashMap.put("biddingType", list.get(0)[3]);
            hashMap.put("tenderResult", list.get(0)[4]);
            hashMap.put("tenderNo", list.get(0)[5]);
            hashMap.put("deptName", list.get(0)[6]);
            hashMap.put("eventTypeId", list.get(0)[7]);
            hashMap.put("tenderId",tenderId);
            hashMap.put("documentStartDate", list.get(0)[8]);
            hashMap.put("documentEndDate", list.get(0)[9]);
            hashMap.put("downloadDocument", list.get(0)[10]);
            hashMap.put("submissionEndDate", CommonUtility.convertTimezone(list.get(0)[11]));
            hashMap.put("openingDate", CommonUtility.convertTimezone(list.get(0)[12]));
            hashMap.put("isCertRequired", list.get(0)[13]);
            hashMap.put("isMandatoryDocument", list.get(0)[14]);
            hashMap.put("isOpeningByCommittee",list.get(0)[15]);
            hashMap.put("isRebateForm",list.get(0)[16]);
            hashMap.put("tenderBrief",list.get(0)[17]);
            hashMap.put("endDateOfsubmission", list.get(0)[11]);
            hashMap.put("decimalValueUpto", list.get(0)[19]);
            if(((Integer)list.get(0)[18]) > 0){
                hashMap.put("isCorrigendumPublished",1);
            }
            hashMap.put("brdMode", list.get(0)[20]);
            hashMap.put("eventType", list.get(0)[21]);
            hashMap.put("isEvaluationByCommittee", list.get(0)[22]);
            hashMap.put("cstatus", list.get(0)[23]);
            hashMap.put("biddingVariant", list.get(0)[24]);
            hashMap.put("isItemwiseWinner", list.get(0)[25]);
            if(list.get(0)[25].equals(1)){
            	hashMap.put("isItemSelectionPageRequired", list.get(0)[38]);
            }
            hashMap.put("isEvaluationRequired", list.get(0)[26]);
            // officerId
            hashMap.put("eventOfficerId", list.get(0)[27]);
            hashMap.put("sorVariation", list.get(0)[28]);
            hashMap.put("isSORApplicable", list.get(0)[29]);
            hashMap.put("submissionMode", list.get(0)[30]);
            hashMap.put("isWorkflowRequired", list.get(0)[31]);
            hashMap.put("isEncodedName", list.get(0)[32]);
            hashMap.put("docFeePaymentMode", list.get(0)[33]);
            hashMap.put("emdPaymentMode", list.get(0)[34]);
            hashMap.put("isBidWithdrawal", list.get(0)[35]);
            hashMap.put("isPartialFillingAllowed", list.get(0)[36]);
            hashMap.put("isEMDApplicable", list.get(0)[37]);
            hashMap.put("multiLevelEvaluationReq", list.get(0)[39]);
            hashMap.put("isTwoStageEvaluation", list.get(0)[40]);
            hashMap.put("isTwoStageOpening", list.get(0)[41]);
            hashMap.put("referanceRfxId", list.get(0)[42]);
            hashMap.put("isReworkRequired", list.get(0)[43]);
            hashMap.put("isSystemGeneratedTenderDoc", list.get(0)[44]);
            hashMap.put("envelopeType", list.get(0)[45]);
            hashMap.put("isWeightageEvaluationRequired", list.get(0)[46]);
            hashMap.put("isSplitPOAllowed", ((Object[])list.get(0))[47]);
            hashMap.put("assignUserId", ((Object[])list.get(0))[48]);
            hashMap.put("submissionStartDate", CommonUtility.convertTimezone(list.get(0)[49]));
            hashMap.put("encryptionLevel", ((Object[])list.get(0))[50]);
            hashMap.put("isNegotiationAllowed", ((Object[])list.get(0))[51]);
            hashMap.put("workflowForTEC", ((Object[])list.get(0))[52]);
            hashMap.put("workflowForTOC", ((Object[])list.get(0))[53]);
            hashMap.put("showNoOfBidders", ((Object[])list.get(0))[54]);
            hashMap.put("isEMDByBidder", ((Object[])list.get(0))[55]);
            hashMap.put("isDocumentFeeByBidder", ((Object[])list.get(0))[56]);
            hashMap.put("isParticipationFeesBy", ((Object[])list.get(0))[57]);
            hashMap.put("isRestOfEventMoney", ((Object[])list.get(0))[58]);
            hashMap.put("isReEvaluationReq", ((Object[])list.get(0))[59]);
            hashMap.put("isItemwiseRegretAllowed", ((Object[])list.get(0))[60]);
        }
        
        // Project Task #32434  Display reference event details @jitendra
	    List<Object[]> referenceEventDetails = commonService.getReferenceEventDetails(tenderId,Integer.parseInt(list.get(0)[7].toString()));
	    if(referenceEventDetails!=null && !referenceEventDetails.isEmpty()){
	    	hashMap.put("oldEventId", referenceEventDetails.get(0)[0]);
	    	hashMap.put("oldEventTypeId", referenceEventDetails.get(0)[1]);
	    	hashMap.put("oldEventType", referenceEventDetails.get(0)[2]);
	    }
            
      //Project Task #33190 bug #33285
            List<String> field = new ArrayList<String>();
			field.add("tenderNo");
       		List<Object[]> lstClientConfigFields = commonService.getClientConfigurationFields(clientId,Integer.parseInt(hashMap.get("eventTypeId").toString()),field);
            if (lstClientConfigFields != null) {
                for (int i = 0; i < lstClientConfigFields.size(); i++) {
                	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("tenderNo")){
                                hashMap.put("TenderReferenceLabel", lstClientConfigFields.get(i)[6].toString());
                    }
                }
            }
            String Marqueetext =getMarqueetext(tenderId,3);
    		hashMap.put("marqueetext",Marqueetext);
    }

    public List<Object[]> getTenderMappedBidderDetails(int tenderId, int clientId, int mappingType, int tableId, int rowId) throws Exception {
    	String langVal=WebUtils.getCookie(getServletRequest(), "locale").getValue();
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();

        var.put("tenderId", tenderId);
        var.put("clientId", clientId);

        query.append("select ");
        if(mappingType == 4 || mappingType == 3){
            query.append(" distinct ");
        }
        query.append("tbltenderbiddermap.mapBidderId,tbluserlogin.userId, tblcompany.companyName, tbluserlogin.loginId ,")
                .append("tbltenderbiddermap.tblUserDetail.userDetailId,tblcompany.companyId");
        if (mappingType == 2) {
            query.append(",tblitembiddermap.mapBidderItemId");
        }
        query.append(",tbluserlogin.userName,tbluserlogin.mobileNo ,tblCountry.lang"+langVal+",tblState.lang"+langVal);
        query.append(" from  TblTenderBidderMap tbltenderbiddermap ")
                .append(" inner join tbltenderbiddermap.tblUserLogin tbluserlogin ")
                .append(" inner join tbluserlogin.tblBidderStatus tblbidderstatus with tblbidderstatus.tblClient.clientId=:clientId ")
                //.append(" and tblbidderstatus.cstatus=1 ") //Changes Bug Id: #31358
                .append(" inner join tblbidderstatus.tblCompany tblcompany inner join tblcompany.tblCountry tblCountry inner join tblcompany.tblState tblState");
        if (mappingType == 2 || mappingType == 4 || mappingType == 3) {
            var.put("tableId", tableId);
            query.append(" inner join tbltenderbiddermap.tblItemBidderMap tblitembiddermap ")
                    .append(" with tblitembiddermap.tblTenderTable.tableId=:tableId ");

        }
        if (mappingType == 2) {
            var.put("rowId", rowId);
            query.append(" and tblitembiddermap.rowId=:rowId");
        }
        if (mappingType == 2) {
        	query.append(" where tbltenderbiddermap.tblTender.tenderId=:tenderId order by tblitembiddermap.rowId ASC");
        }
        else
        {
        	query.append(" where tbltenderbiddermap.tblTender.tenderId=:tenderId order by tbltenderbiddermap.mapBidderId ASC");
        }
       
        
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     *
     * @param tenderId
     * @param companyId
     * @return
     * @throws Exception
     */
    public boolean isFinalBidSubmision(int tenderId, int companyId) throws Exception {

        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("companyId", companyId);
        count = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblfinalsubmission ", "tblfinalsubmission.finalSubmissionId ", "tblfinalsubmission.tblCompany.companyId=:companyId and tblfinalsubmission.tblTender.tenderId=:tenderId", var);
        return count != 0;
    }

    /**
     *
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getSubEndDtAndManDocs(int tenderId) throws Exception {
        List<Object[]> list = null;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);

        query.append("select case when tbltender.submissionEndDate < getutcdate() then true else false end,tbltender.isMandatoryDocument,isConsortiumAllowed,isBidWithdrawal,isRebateForm ")
                .append(" from TblTender tbltender where tbltender.tenderId=:tenderId ");

        list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return list;

    }

    /**
     *
     * @param tenderId
     * @param companyId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getTenderBidDtls(int tenderId, int companyId, boolean isFinalSubmission) throws Exception {
        List<Object[]> list = null;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("companyId", companyId);

        query.append("select ");
        if (!isFinalSubmission) {
            query.append(" bidId,tblTenderEnvelope.envelopeId,");
        } else {
            query.append("COUNT(tblTenderForm.formId),");
        }
        query.append(" tblTenderForm.formId ");
        if (!isFinalSubmission) {
            query.append(" ,cstatus ");
        }
        query.append(" from TblTenderBid where tblTender.tenderId=:tenderId and tblCompany.companyId=:companyId ");
        if (isFinalSubmission) {
            query.append(" group by tblTenderForm.formId");
        }
        list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return list;

    }

    public List<Object[]> getTenderBidderDocs(int tenderId, int companyId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("companyId", companyId);

        query.append("select tbltenderbid.bidId,tblbidderdocmapping.bidderDocMappingId,tblbidderdocument.docName,tblbidderdocument.bidderDocId ")
                .append(" ,concat(concat(tblbidderdocument.path,'\\'),tblbidderdocument.docName),tblbidderdocument.description,tblbidderdocmapping.documentId, ")
                .append(" tblbidderdocmapping.documentName")
                .append(" from TblTenderBid tbltenderbid,TblBidderDocMapping tblbidderdocmapping ")
                .append(" inner join tblbidderdocmapping.tblBidderDocument tblbidderdocument ")
                .append(" where tbltenderbid.bidId=tblbidderdocmapping.objectId and ")
                .append(" tbltenderbid.tblCompany.companyId=tblbidderdocmapping.tblCompany.companyId and ")
                .append(" tbltenderbid.tblTender.tenderId=:tenderId and tbltenderbid.tblCompany.companyId=:companyId ")
                .append(" and tblbidderdocmapping.tblLink.linkId=237 and tblbidderdocument.cstatus=1 and tblbidderdocmapping.cstatus=1 order by tblbidderdocmapping.documentId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    public List<Object[]> getTenderBidderDocs(int tenderId, int companyId,int linkId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("companyId", companyId);
        var.put("linkId", linkId);
        query.append("select tblpayment.paymentId,tblbidderdocmapping.bidderDocMappingId,tblbidderdocument.docName,tblbidderdocument.bidderDocId ")
                .append(" ,concat(concat(tblbidderdocument.path,'\\'),tblbidderdocument.docName),tblbidderdocument.description,tblbidderdocmapping.documentId, ")
                .append(" tblbidderdocmapping.documentName")
                .append(" from TblPayment tblpayment,TblBidderDocMapping tblbidderdocmapping ")
                .append(" inner join tblbidderdocmapping.tblBidderDocument tblbidderdocument ")
                .append(" where tblpayment.paymentId=tblbidderdocmapping.objectId and ")
                .append(" tblpayment.tblCompany.companyId=tblbidderdocmapping.tblCompany.companyId and ")
                .append(" tblpayment.objectId=:tenderId and tblpayment.tblCompany.companyId=:companyId ")
                .append(" and tblbidderdocmapping.tblLink.linkId=:linkId and tblbidderdocument.cstatus=1 and tblbidderdocmapping.cstatus=1 order by tblbidderdocmapping.documentId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    /**
     * @author SULABH
     * @param fromId
     * @param tableId
     * @param rowId
     * @return List<Object[]>
     * @throws Exception
     */
    public List<Object[]> getItemNameWithFormNameAndTableName(int fromId, int tableId,int rowId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("fromId", fromId);
        var.put("tableId", tableId);
        var.put("rowId", rowId);
        query.append("select tbltenderform.formName,tblTenderTable.tableName,tbltendercell.cellValue  from TblTenderForm tbltenderform")
                .append(" inner join tbltenderform.tblTenderTable tblTenderTable")
                .append(" inner join tblTenderTable.tblTenderColumn tbltendercolumn with tbltendercolumn.tblColumnType.columnTypeId=1")
                .append(" inner join tbltendercolumn.tblTenderCell tbltendercell  with tbltendercell.rowId=:rowId")
                .append(" where tbltenderform.formId=:fromId and tblTenderTable.tableId=:tableId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    /**
     * @author SULABH
     * @param fromId
     * @param tableId
     * @return List<Object[]>
     * @throws Exception
     */
    public List<Object[]> getFormNameAndTableName(int fromId, int tableId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("fromId", fromId);
        var.put("tableId", tableId);
        query.append("select tbltenderform.formName,tbltendertable.tableName from TblTenderForm tbltenderform")
                .append(" inner join tbltenderform.tblTenderTable tbltendertable")
                .append(" where tbltenderform.formId=:fromId and tbltendertable.tableId=:tableId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    public List<Object[]> getTenderBidderMandatoryDocs(List<Integer> mandatoryDocId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("mandatoryDocId", mandatoryDocId);
        query.append("select tblbidderdocument.description,tblbidderdocument.bidderDocId,tblbidderdocmapping.documentId,tbltenderbid.bidId");
        query.append(" from TblTenderBid tbltenderbid,TblBidderDocMapping tblbidderdocmapping ");
        query.append(" inner join tblbidderdocmapping.tblBidderDocument tblbidderdocument ");
        query.append(" where  tbltenderbid.bidId=tblbidderdocmapping.objectId  and tblbidderdocmapping.documentId in (:mandatoryDocId)");
        query.append(" order by tblbidderdocmapping.documentId");
        //System.out.println("var getTenderBidderMandatoryDocs= " +query.toString());
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    public int isConsortiumByTenderId(int tenderId) throws Exception {
        String query = new String();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query = "select isConsortiumAllowed from TblTender where tenderId=:tenderId";
        List<Object> list = hibernateQueryDao.singleColQuery(query.toString(), var);
        int result = (list != null && !list.isEmpty()) ? Integer.parseInt(list.get(0).toString()) : 0;
        return result;
    }

    /**
     *
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderPrebidDetailByTenderId(int tenderId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        list = hibernateQueryDao.createNewQuery("select tbltender.isPreBidMeeting, tbltender.preBidMode, tbltender.preBidStartDate, tbltender.preBidEndDate, tbltender.preBidAddress, tbltender.submissionEndDate,tbltender.cstatus from TblTender tbltender where tbltender.tenderId=:tenderId", var);
        return list;
    }

    /**
     *
     * @param tenderId
     * @return
     * @throws Exception
     */
    public boolean isTenderPublicKeyMapped(int tenderId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);

        count = hibernateQueryDao.countForNewQuery("TblTenderPublicKey tbltenderpublickey ", "tbltenderpublickey.tenderPublicKeyId ", "tbltenderpublickey.tblTender.tenderId=:tenderId", var);
        return count != 0;
    }

    /**
     *
     * @param tenderId
     * @param companyId
     * @return int
     * @throws Exception
     */
    public int[] getConsortiumPartnerType(int tenderId, int companyId) throws Exception {
        int[] consortFields = new int[2];
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("companyId", companyId);

        query.append("select tblconsortium.consortiumId,tblconsortiumdetail.partnerType  ")
                .append(" from TblConsortium tblconsortium ")
                .append(" inner join tblconsortium.tblConsortiumDetail tblconsortiumdetail ")
                .append(" with tblconsortiumdetail.tblCompany.companyId=:companyId AND tblconsortiumdetail.cstatus=1")
                .append(" where tblconsortium.tblTender.tenderId=:tenderId AND tblconsortium.isActive=1");

        List<Object[]> lstPartnerType = hibernateQueryDao.createNewQuery(query.toString(), var);
        if (!lstPartnerType.isEmpty()) {
        	consortFields[0] = (Integer) lstPartnerType.get(0)[0];
            consortFields[1] = (Integer) lstPartnerType.get(0)[1];
        }
        return consortFields;
    }

    /**
     *
     * @param ipAddress
     * @param params
     * @return String
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
    public String allowFinalSubmission(String ipAddress, int... params) throws Exception {
        String msgCode = null;
        List<LinkedHashMap<String, Object>> lstTenderFinalSubmission = sPTenderFinalSubmission.executeProcedure(params[0], params[1], params[2], params[3], ipAddress, params[4]);

        if (lstTenderFinalSubmission != null && !lstTenderFinalSubmission.isEmpty() && lstTenderFinalSubmission.get(0).get("result") != null) {
            msgCode = lstTenderFinalSubmission.get(0).get("result").toString();
        }
        if(msgCode.equalsIgnoreCase("Success") || msgCode.contains("msg_tender_fs_finalsubmission_done")){
        	if(params[4] == 1){
            	eventBidSubmissionService.addTenderBidOpenDetails(ipAddress, params);
            	
            	if(params[7] == 1 && !(params[5] == 1 && params[8] == 2)){
                	eventBidSubmissionService.addTenderRebateDetails(params[0], params[1]);
                }
            }
        }
        return msgCode;
    }

    /**
     * get form wise count of mandatory tender documents
     *
     * @param isConsortium
     * @param tenderId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getMandatoryDocsCounts(boolean isConsortium, int tenderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);

        query.append("select COUNT(DISTINCT tbldocument.documentId),tbltenderform.formId ")
                .append(" FROM TblDocument tbldocument,TblTenderForm tbltenderform ")
                .append(" WHERE tbltenderform.tblTender.tenderId=:tenderId and tbldocument.tblLink.linkId = 317 AND tbldocument.isMandatory = 1 ")
                .append("AND tbldocument.objectId = tbltenderform.formId AND tbltenderform.cstatus = 1 ");
        if (isConsortium) {
            query.append(" AND tbltenderform.isSecondary = 1");
        }
        query.append(" group by tbltenderform.formId");

        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     * get form wise count of mandatory documents uploaded by company
     *
     * @param tenderId
     * @param companyId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getManDocsUploadedCount(int tenderId, int companyId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("companyId", companyId);

        query.append("select COUNT(DISTINCT tblbidderdocmapping.documentId),tbltenderform.formId ")
                .append(" FROM TblDocument tbldocument,TblTenderForm tbltenderform, TblBidderDocMapping tblbidderdocmapping ")
                .append(" INNER JOIN tbltenderform.tblTenderBid TB with TB.tblCompany.companyId =:companyId AND TB.cstatus = 2 ")
                .append(" WHERE tbltenderform.tblTender.tenderId=:tenderId and tbldocument.tblLink.linkId = 317 AND ")
                .append(" tbldocument.isMandatory = 1 AND tbldocument.objectId = tbltenderform.formId AND tbltenderform.cstatus = 1 ")
                .append(" AND  tbldocument.documentId = tblbidderdocmapping.documentId AND TB.bidId = tblbidderdocmapping.objectId ")
                .append(" AND tblbidderdocmapping.tblLink.linkId=237 AND tblbidderdocmapping.cstatus = 1 group by tbltenderform.formId");

        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     *
     * @param tenderId
     * @return
     * @throws Exception
     */
    public boolean isTenderFormDocsMandatory(int tenderId) throws Exception {

        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        count = hibernateQueryDao.countForNewQuery("TblTenderForm tbltenderform ", "tbltenderform.formId ", "tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isDocumentReq=1", var);
        return count != 0;
    }

    /**
     *
     * @param envelopeId
     * @return
     * @throws Exception
     */
    public TblTenderEnvelope getTenderEnvelopeById(int envelopeId) throws Exception {
        List<TblTenderEnvelope> list = null;
        list = tblTenderEnvelopeDao.findTblTenderEnvelope("envelopeId", Operation_enum.EQ, envelopeId);
        return (list != null && !list.isEmpty()) ? list.get(0) : null;

    }

    /**
     * Use case: Result sharing of tender
     *
     * @author nirav.modi
     * @return List<SelectItem>
     * @throws Exception
     */
    public List<SelectItem> getResultSharingCriteria(boolean isForOpening) {
        List<SelectItem> criteriaList = new ArrayList<SelectItem>();
    	criteriaList.add(new SelectItem(messageSource.getMessage("field_all_bidder", null, LocaleContextHolder.getLocale()), 1));
    	criteriaList.add(new SelectItem(messageSource.getMessage("field_qul_bidder", null, LocaleContextHolder.getLocale()), 2));
    	criteriaList.add(new SelectItem(messageSource.getMessage("field_part_bidder", null, LocaleContextHolder.getLocale()), 3));
    	criteriaList.add(new SelectItem(messageSource.getMessage("field_all_registered_users", null, LocaleContextHolder.getLocale()), 4));
        if (!isForOpening) {
            criteriaList.add(new SelectItem(messageSource.getMessage("field_not_share", null, LocaleContextHolder.getLocale()), 4));
        }
        return criteriaList;
    }

    /**
     * Method user for get TblTender object for given tenderId
     *
     * @param tenderId
     * @return TblTender object
     * @throws Exception
     */
    public TblTender getTenderById(int tenderId) throws Exception {
        List<TblTender> list = null;
        list = tblTenderDao.findTblTender("tenderId", Operation_enum.EQ, tenderId);
        return (list != null && !list.isEmpty()) ? list.get(0) : null;

    }
    /**
     * Method use to check tender is support online payment or not 
     * @param tenderId
     * @param clientId
     * @return true/false
     * @throws Exception
     */
    public Map<String,Object> verifyTenderPaymentConfig(int tenderId,int clientId) throws Exception{
    	List<Object[]> paymentFeesDetails =  getTenderFields(tenderId, "isRegistrationCharges,registrationChargesMode,isDocfeesApplicable,docFeePaymentMode,isEMDApplicable,emdPaymentMode,isSecurityfeesApplicable,secFeePaymentMode");
    	Map<String,Object>  paymentAllow = new HashMap<String, Object>();
    	if(paymentFeesDetails!=null && !paymentFeesDetails.isEmpty())
    	{
	    	Map<Integer,Integer> mapPaymentFeesDetail = new HashMap<Integer, Integer>();
	    	if(Integer.parseInt(paymentFeesDetails.get(0)[0].toString()) !=0){
	    		mapPaymentFeesDetail.put(8, Integer.parseInt(paymentFeesDetails.get(0)[1].toString()));//Event Reg. charges
	    	}
	    	if(Integer.parseInt(paymentFeesDetails.get(0)[4].toString()) !=0){
	    		mapPaymentFeesDetail.put(2, Integer.parseInt(paymentFeesDetails.get(0)[5].toString()));//EMD 
			}
	    	if(Integer.parseInt(paymentFeesDetails.get(0)[2].toString()) !=0){
	    		mapPaymentFeesDetail.put(1, Integer.parseInt(paymentFeesDetails.get(0)[3].toString()));//DocFees  	
			}
	    	if(Integer.parseInt(paymentFeesDetails.get(0)[6].toString())==1 && Integer.parseInt(paymentFeesDetails.get(0)[7].toString())!=2 ){
	    		 paymentAllow.put("result", false);
	    		 paymentAllow.put("errMsg", "msg_paymentconf_pg_pending");
	    		 return paymentAllow;//SecFees not developed yet
			} 
	    	paymentAllow=commonService.verifyPaymentConfiguration(3,clientId,tenderId,mapPaymentFeesDetail);
    	}
    	return paymentAllow;
    }
    /**
     * Use for All dashboard link
     *
     * @author nirav.modi
     * @param clientId
     * @param tenderId
     * @param subModuleId
     * @param officerId
     * @return {
     * @codeMap<String, Object>}
     */
    public Map<String, Object> validateTenderRules(int clientId, int tenderId, int subModuleId, int officerId) throws Exception {
        return sPValidateTenderRules.executeProcedure(clientId, tenderId, subModuleId, officerId);
    }
    
    /**
     * 
     * @param tableId
     * @return {@code  List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getItemBidderMapDtls(int tableId,boolean isSearch) throws Exception{
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId", tableId);
        
        if(isSearch){
            query.append("select tbltendercell.rowId,tbltendercell.cellValue from TblTenderTable tbltendertable ")
                    .append(" inner join tbltendertable.tblTenderColumn tbltendercolumn ")
                    .append(" inner join tbltendercolumn.tblTenderCell tbltendercell ")
                    .append(" where tbltendertable.tableId=:tableId and tbltendercolumn.tblColumnType.columnTypeId=1 ")
                    .append(" and (case when tbltendertable.hasGTRow = 1 then (tbltendertable.noOfRows-1) else tbltendertable.noOfRows end) >= tbltendercell.rowId ")
                    .append(" order by tbltendercell.rowId ");
        }else{
            query.append("select tblitembiddermap.mapBidderItemId,tbltenderbiddermap.mapBidderId,tbltenderbiddermap.tblUserLogin.userId,tblitembiddermap.rowId,tbltendercell.cellValue ")
                    .append(" from TblItemBidderMap tblitembiddermap ")
                    .append(" inner join tblitembiddermap.tblTenderBidderMap tbltenderbiddermap ")
                    .append(" inner join tblitembiddermap.tblTenderTable tbltendertable ")
                    .append(" inner join tbltendertable.tblTenderColumn tbltendercolumn ")
                    .append(" inner join tbltendercolumn.tblTenderCell tbltendercell ")
                    .append(" where tblitembiddermap.tblTenderTable.tableId=:tableId ")
                    .append(" and tbltendercolumn.tblColumnType.columnTypeId=1 and tbltendercell.rowId=tblitembiddermap.rowId ")
                    .append(" and (case when tbltendertable.hasGTRow = 1 then (tbltendertable.noOfRows-1) else tbltendertable.noOfRows end) >= tbltendercell.rowId ")
                    .append(" order by tbltenderbiddermap.tblUserLogin.userId,tblitembiddermap.rowId");
        }
        
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    /**
     * @author VIPULP
     * @param tenderId
     * @return boolean
     * @throws Exception 
     */
    public int isEventLive(int tenderId) throws Exception{
        int isLive = 0;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        
        query.append("select case when  getutcdate() >= submissionStartDate then ")
                .append("   case when getutcdate() < submissionEndDate then 1 else -1 end else 0 end ")
            .append(" from TblTender where tenderId=:tenderId and cstatus=1");
        
        List<Object> lstObject = hibernateQueryDao.getSingleColQuery(query.toString(), var);
        if(!lstObject.isEmpty()){
            isLive = (Integer) lstObject.get(0);
        }
        return isLive;
    }
    
    /**
     * @author SULABH
     * @param tenderId
     * @return boolean
     * @throws Exception 
     */
    public int isEventArchive(int tenderId) throws Exception{
        int isArchive = 0;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select case when getutcdate() > submissionEndDate then 1 else 0 end  ")
                .append("    from TblTender where tenderId=:tenderId and cstatus in (1,4,5) ");
        List<Object> lstObject = hibernateQueryDao.getSingleColQuery(query.toString(), var);
        if(!lstObject.isEmpty()){
            isArchive = (Integer) lstObject.get(0);
        }
        return isArchive;
    }
    
    public int isEventFuture(int tenderId) throws Exception{
        int isEventFuture = 0;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select case when getutcdate() < submissionStartDate then 1 else 0 end  from TblTender where tenderId=:tenderId and cstatus=1");
        List<Object> lstObject = hibernateQueryDao.getSingleColQuery(query.toString(), var);
        if(!lstObject.isEmpty()){
            isEventFuture = (Integer) lstObject.get(0);
        }
        return isEventFuture;
    }
    
    /**
     * @author VIPULP
     * @param tenderId
     * @return int
     * @throws Exception
     */
    public int getLeadPartnerBidderId(int tenderId,int consortiumId) throws Exception {
        int bidderId = 0;
        List<Object> list = null;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("consortiumId", consortiumId);
        query.append(" select tblconsortiumdetail.tblUserLogin.userId from TblConsortium tblconsortium ");
		query.append(" inner join tblconsortium.tblConsortiumDetail tblconsortiumdetail with tblconsortiumdetail.partnerType = 2  ");
		query.append(" where tblconsortium.tblTender.tenderId=:tenderId and tblconsortium.isActive=1 and tblconsortium.consortiumId=:consortiumId ");
		list = hibernateQueryDao.getSingleColQuery(query.toString(), var);
        if(!list.isEmpty()){
            bidderId = (Integer) list.get(0);
        }
        return bidderId;

    }
    
    public List<Object> getSecondaryPartnerEmailIDs(int tenderId,int consortiumId) throws Exception{
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        //var.put("tenderId",tenderId);
        var.put("consortiumId",consortiumId);
        StringBuilder query = new StringBuilder();
        query.append("select tblconsortiumdetail.tblUserLogin.loginId  ")
            .append(" from TblConsortium tblconsortium ")
            .append(" inner join tblconsortium.tblConsortiumDetail tblconsortiumdetail ")
            .append(" where tblconsortiumdetail.cstatus=1 and tblconsortium.consortiumId=:consortiumId and tblconsortiumdetail.partnerType = 3 ");
        list = hibernateQueryDao.getSingleColQuery(query.toString(),var);                
        return list;        

    }
    
    /**
     * @author sharmila
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderPaymentAmount(int tenderId,int payFor,int isGivenByBidder,int companyId,int rowId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        if(isGivenByBidder == 0){
        	query.append("select ");
        	if(payFor == 1){
        		query.append(" CASE WHEN documentFee = '' THEN '0' ELSE documentFee END ,0 ");
        	}else if(payFor == 2){
        		query.append(" CASE WHEN emdAmount = '' THEN '0' ELSE emdAmount END ,0 ");
        	}else{
        		query.append(" CASE WHEN registrationCharges = '' THEN '0' ELSE registrationCharges END ,0");
        	}
        	query.append(" from TblTender where tenderId=:tenderId");
        }else{
        	query.append("SELECT tbleventfees.eventFee,tbleventfees.uniqueId,tbleventfees.exemptionAmt FROM TblEventFees tbleventfees,TblTender tbltender");
        	query.append(" INNER JOIN tbltender.tblTenderForm tbltenderform with tbltenderform.cstatus = 1");
        	query.append(" INNER JOIN tbltenderform .tblTenderColumn tbltendercolumn WITH tbltendercolumn.tblColumnType.columnTypeId = :columnTypeId");
        	query.append(" INNER JOIN tbltenderform.tblTenderBid tbltenderbid ");
        	query.append(" WHERE tbleventfees.feeType = :feeType AND tbleventfees.tblCompany.companyId = :companyId");
        	query.append(" AND tbltenderbid.bidId = tbleventfees.bidId ");
        	query.append(" AND tbltender.tenderId = :tenderId and tbleventfees.cstatus = 0 and isActive = 1 ");
        	if(rowId!=0){
        		var.put("rowId", rowId);
        		query.append(" AND  tbleventfees.rowId = :rowId  ");
        	}
        	if(payFor == 1){
        		var.put("columnTypeId", isGivenByBidder==1?9:31);
        		var.put("feeType", 2);
        	}else if (payFor == 2){
        		var.put("columnTypeId", isGivenByBidder==1?10:18);
        		var.put("feeType", 3);
        	}else {
        		var.put("columnTypeId", 32);
        		var.put("feeType", 8);
        	}
        	var.put("companyId", companyId);
        }
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return list;
    }
    
    /**
     * Get tender table details by form Id.
     * @param formId
     * @return
     * @throws Exception 
     */
    public List<TblTenderTable> getTenderTableByFormId(int formId) throws Exception{
        return tblTenderTableDao.findTblTenderTable("tblTenderForm.formId",Operation_enum.EQ,formId);            
    }
    
    /**
     * @author heeral.soni
     * @param tenderId
     * used to get tender wise budget details
     */
    public TblTenderWiseBudgetDetails getTenderWiseBudgetDetailsByTenderId(int tenderId) throws Exception {
    	List<TblTenderWiseBudgetDetails> list = tblTenderWiseBudgetDetailsDao.findTblTenderWiseBudgetDetails("tblTender", Operation_enum.EQ, new TblTender(tenderId));
    	return list.isEmpty() ? null : list.get(0);
    }
    
    public HttpServletRequest getServletRequest() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return attr.getRequest();
    }
    /**
     * To get LOI winning bidder list.
     * 
     * @author purvesh
     * @param tenderId
     * @param clientId
     * @return
     * @throws Exception
     */
    public List<Object[]> getLoiBidderList(int tenderId, int clientId) throws Exception{
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("clientId",clientId);
         var.put("filledBy",3);
         StringBuilder query = new StringBuilder();
         query.append("select distinct tblbidderstatus.tblUserLogin.userId, tbldynreportcell.companyId, tblcompany.companyName ")
         	  .append("from TblDynReport tbldynreport, TblDynReportColumn tbldynreportcolumn, TblCompany tblcompany ")
         	  .append("inner join tbldynreportcolumn.tblDynReportCell  tbldynreportcell ")
         	  .append("inner join tblcompany.tblBidderStatus tblbidderstatus with tblbidderstatus.tblClient.clientId=:clientId ")
         	  .append("where tbldynreport.tblTender.tenderId=:tenderId and tbldynreport.reportId=tbldynreportcolumn.tblDynReport.reportId and tbldynreportcell.companyId = tblcompany.companyId and tbldynreportcolumn.filledBy=:filledBy and tbldynreportcell.cellValue='1'");
         return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    public List<Object[]> getLoiList(String companyIds, int eventId, int clientId) throws Exception{
   	 Map<String, Object> var = new HashMap<String, Object>();
        //var.put("companyIds",companyIds);
   	var.put("clientId",clientId);
        var.put("eventId",eventId);
        StringBuilder query = new StringBuilder();
        query.append("select tblbidderstatus.tblUserLogin.userId, tblcompany.companyId, tblcompany.companyName, tblloi.loiId, tblloi.cstatus  from TblCompany tblcompany ")
        	 .append("inner join tblcompany.tblBidderStatus tblbidderstatus with tblbidderstatus.tblClient.clientId=:clientId ")
        	 .append("left join tblcompany.tblLOI  tblloi with tblloi.eventId=:eventId  ")
        	 .append("where tblcompany.companyId in (").append(companyIds).append(")");
        	
        return hibernateQueryDao.createNewQuery(query.toString(), var);
   }
    /**
     * author : heeral.soni
     * @param formId
     * @return boolean
     * @throws Exception
     * used to get count of mult table filling
     */
    public int getMulTableFillingCount(int formId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        int count=0;
        List<Object> list = hibernateQueryDao.getSingleColQuery("select COUNT(tableId) from TblTenderTable where formId=:formId and isMultipleFilling=1",var);
        if(list!=null && !list.isEmpty()){
            count = Integer.parseInt(list.get(0).toString());
        }
        //System.out.println("getMultiFillingCount count = " + count);
        return count;
    }
    /**
     * author : heeral.soni
     * @param formId
     * @return boolean
     * @throws Exception
     * used to get count of result sharing done or not
     */
    public boolean isResultShareDone(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        int count=0;
        List<Object> list = hibernateQueryDao.getSingleColQuery("select COUNT(shareReportId) from TblShareReport tblsharereport where tblsharereport.tblTender.tenderId=:tenderId",var);
        if(list!=null && !list.isEmpty()){
            count = Integer.parseInt(list.get(0).toString());
        }
        //System.out.println("isResultShareDone count = " + count);
        return count>0;
    }
    
    
    public BigDecimal getTenderEstimatedValue(int tenderId){
    	BigDecimal estimatedValue=BigDecimal.ZERO;
    	Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("tenderId", tenderId);
        StringBuilder strQuery=new StringBuilder("Select prevEstimatedValue from TblTender  where tenderId=:tenderId");
        List<Object> lst = hibernateQueryDao.singleColQuery(strQuery.toString(), parameters);
        if (lst != null && !lst.isEmpty()) {
        	//estimatedValue=Integer.parseInt(lst.get(0).toString());
        	estimatedValue = new BigDecimal(lst.get(0).toString()); //BigDecimal.valueOf(Double.parseDouble(lst.get(0).toString()));
        }
    	return estimatedValue;
    }
    
     public int isSecondaryPartner(int tenderId,int companyId) throws Exception{
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
        int count=0;
        StringBuilder query = new StringBuilder();
        query.append(" select count(tblconsortiumdetail.consortiumDetailId)");
        query.append(" from TblConsortiumDetail tblconsortiumdetail");
        query.append(" inner join tblconsortiumdetail.tblConsortium tblconsortium");
        query.append(" where tblconsortium.tblTender.tenderId=:tenderId and tblconsortiumdetail.tblCompany.companyId=:companyId and tblconsortiumdetail.partnerType = 3");
        query.append(" and tblconsortiumdetail.cstatus=1 and tblconsortium.isActive=1");
         //System.out.println("query = " + query.toString());
        list = hibernateQueryDao.getSingleColQuery(query.toString(),var);
        if(list!=null && !list.isEmpty()){
            count = Integer.parseInt(list.get(0).toString());
        }
        return count;
    }

     /**
      * 
      * @param tenderId
      * @return
      * @throws Exception
      */
     public boolean isEvaluationCompleteForAllEnv(int tenderId) throws Exception{
    	 boolean isEvaluatedAnyEnvl = false;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         List<Object> list = hibernateQueryDao.getSingleColQuery("select tblBidderApprovalDetail.tblTenderEnvelope.envelopeId from TblBidderApprovalDetail tblBidderApprovalDetail where tblBidderApprovalDetail.tblTenderEnvelope.tblTender.tenderId=:tenderId and tblBidderApprovalDetail.isApproved=1",var);
         if(list!=null && !list.isEmpty()){
        	 isEvaluatedAnyEnvl = list.size() > 0 ? true : false; 
         }
         return isEvaluatedAnyEnvl;
     }
     
     /**
     *
     * @param tenderId
     * @param searchTxt
     * @return boolean
     * @throws Exception
     */
    public boolean isBiddermappedByTenderId(int tenderId) throws Exception {
        long count = 0;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select COUNT(tbltenderbiddermap.mapBidderId) from TblTenderBidderMap tbltenderbiddermap ");
        query.append(" where tbltenderbiddermap.tblTender.tenderId=:tenderId ");
        List<Object> data = hibernateQueryDao.singleColQuery(query.toString(), var);
        if(data!=null && !data.isEmpty()){
            count = (Long) data.get(0);
        }        
        return count != 0;
    }
    
    /** 
     * @auther Mitesh
     * @param tenderId
     * @return
     * @throws Exception 
     */
     public List<Object[]> getEnvelopeTypeByTenderId(int tenderId) throws Exception {
        long count = 0;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select tblTenderEnvelope.envelopeId from TblTenderEnvelope tblTenderEnvelope where tblTenderEnvelope.tblTender.tenderId=:tenderId and tblTenderEnvelope.tblEnvelope.envId in (3,5)");
        List<Object[]> data = hibernateQueryDao.createNewQuery(query.toString(), var);
        return data;
    }
     /**
     * author Lipi Shah
     * @param committeeId
     * @return
     * @throws Exception
     */
    public boolean consentGivenOrNot(int committeeId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId", committeeId);
        count = hibernateQueryDao.countForNewQuery("TblCommitteeUser tblCommitteeUser", "tblCommitteeUser.committeeUserId", "tblCommitteeUser.tblCommittee.committeeId=:committeeId AND tblCommitteeUser.isApproved=1", var);
        return count != 0;
    }
    /**
     * author Lipi Shah
     * @param tenderId
     * @param commiteeType
     * @return
     * @throws Exception
     */
    public int getActiveCommittee(int tenderId, int committeeType) throws Exception {
    	int committeeId = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("committeeType", committeeType);
        List<Object> list = hibernateQueryDao.getSingleColQuery("SELECT committeeId FROM TblCommittee tblCommittee WHERE tblCommittee.tblTender.tenderId=:tenderId AND tblCommittee.committeeType=:committeeType AND tblCommittee.isActive=1", var);
        if(list!=null && !list.isEmpty()){
        	committeeId = Integer.parseInt(list.get(0).toString());
        }
        return committeeId;
    }
    
    /**
     * This method returns flag whether bidder has accepted terms and condition for particular tender 
     * @author SULABH
     * @param tenderId
     * @param companyId
     * @return
     */
    public boolean isBidderAcceptTermsCondition(int tenderId,int companyId){
    	int count=0;
    	boolean flag=false;
    	Map<String,Object> var = new HashMap<String,Object>();
        var.put("tenderId", tenderId);
        var.put("companyId", companyId);
    	StringBuffer selectHQL=new StringBuffer("select COUNT(bidConfirmationId) from TblTenderBidConfirmation where tenderId=:tenderId and companyId=:companyId");
    	List<Object> list=hibernateQueryDao.singleColQuery(selectHQL.toString(), var);
    	if(!list.isEmpty()){
    		count=Integer.parseInt(list.get(0).toString());
    	}
    	if(count>0){
    		flag=true;
    	}
    	return flag;
    }

	
	/**
	 * get bidder detail 
	 * @author janak
	 * @param tenderId
	 * @param tenderMode
	 * @return
	 */
	public List<Object[]> getTenderBidderDetail(int tenderId,int tenderMode) {
		StringBuilder query = new StringBuilder();
	    Map<String, Object> var = new HashMap<String, Object>();
	    var.put("tenderId", tenderId);
	    if(tenderMode == 2 || tenderMode == 3 ){ // Limited and single
	    	query.append(" select tbltenderbidderMap.tblUserLogin.userId,tbltenderbidderMap.tblCompany.companyId,tbltenderbidderMap.tblUserDetail.userDetailId from TblTenderBidderMap tbltenderbidderMap where tbltenderbidderMap.tblTender.tenderId=:tenderId ");
	    }else if(tenderMode == 1){ // Open
	    	query.append(" select tbltenderbidconfirmation.tblUserLogin.userId,tbltenderbidconfirmation.tblCompany.companyId,tbltenderbidconfirmation.tblUserDetail.userDetailId ");
			query.append(" from TblTenderBidConfirmation tbltenderbidconfirmation where tbltenderbidconfirmation.tblTender.tenderId=:tenderId ");
	    }
	    List<Object[]> res = null;
	    if(query != null && query.length() > 0){
	    	res = hibernateQueryDao.createNewQuery(query.toString(), var);
	    }
	    return res;
	}
    
    /**This method is used to give domain name by passing tenderId
     * @author priyanka
     * @param tenderId
     * @return
     */
  	public List<Object[]> getDomainNamebyTenderId(int tenderId) {
  		 List<Object[]> list = null;
  		 StringBuilder query = new StringBuilder();
  	      Map<String, Object> var = new HashMap<String, Object>();
  	      var.put("tenderId", tenderId);
  	      query.append("select tblclient.clientId , tblclient.domainName from TblTender tbltender  ");
  	      query.append("inner join tbltender.tblDepartment tbldepartment ");
  	      query.append("inner join tbldepartment.tblClient tblclient ");
  	      query.append("where tbltender.tenderId =:tenderId ");
  	      list = hibernateQueryDao.createNewQuery(query.toString(), var);
  	  return list;
  	}
  	
  	 /**
     * @author priyanka
     * @param tenderId
     * @return 
     * @throws Exception
     */
    public List<Object[]> getConsortiumPartnerDetail(int tenderId) throws Exception {        
        List<Object[]> list = null;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);        
        query.append("select tblconsortiumdetail.tblUserLogin.userId ,tblconsortiumdetail.tblCompany.companyName,tblconsortiumdetail.tblUserLogin.loginId")
                .append(" from TblConsortium tblconsortium ")
                .append(" inner join tblconsortium.tblConsortiumDetail tblconsortiumdetail with tblconsortiumdetail.partnerType <> 0 ")
                .append(" where tblconsortium.tblTender.tenderId=:tenderId and tblconsortium.isActive=1 ");        
        list = hibernateQueryDao.createNewQuery(query.toString(), var);    
        return list;

    }
    
    public boolean isPriceBidOpen(int tenderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select tblTenderEnvelope.envelopeId,tblTenderEnvelope.isOpened from TblTenderEnvelope tblTenderEnvelope ");
        query.append(" where tblTenderEnvelope.tblEnvelope.envId in (4,5) and tblTenderEnvelope.tblTender.isOpeningByCommittee = 1 and tblTenderEnvelope.tblTender.tenderId = :tenderId ");
        List<Object[]> lst = hibernateQueryDao.createNewQuery(query.toString(), var);
        boolean flag = true;
        if(lst.size() > 0 && lst.get(0)[1] != null && (Integer)lst.get(0)[1] != 1){
        	flag = false;
        }
        return flag;
    }

    /**
     * Get opening committeId
     * @author manoj.gadhavi
     * @param tenderId
     * @return
     */
    public int getOpeningCommittee(int tenderId,int commiteeType){
    	int committeeId = 0;
    	Map<String,Object> var = new HashMap<String,Object>();
        var.put("tenderId", tenderId);
        var.put("commiteeType", commiteeType);
    	StringBuffer selectHQL=new StringBuffer("select committeeId from TblCommittee tblCommittee where tblCommittee.tblTender.tenderId=:tenderId and tblCommittee.isActive = 1 and tblCommittee.isApproved = 1 and tblCommittee.committeeType =:commiteeType");
    	List<Object> list=hibernateQueryDao.singleColQuery(selectHQL.toString(), var);
    	if(!list.isEmpty()){
    		committeeId=Integer.parseInt(list.get(0).toString());
    	}
    	return committeeId;
    }
    
	public List<Object[]> getTenderFormAndTableByTenderId(int tenderId, int bidderId, int isPriceBidCondition) {
		 StringBuilder query = new StringBuilder();
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put("tenderId", tenderId);
	        if(bidderId != 0){
	        	var.put("bidderId", bidderId);
	        }
			 query.append("select tblTenderForm.formId,tblTenderForm.formHeader,tblTenderForm.formFooter,tblTenderForm.formName,tblTenderTable.tableId,tblTenderTable.tableName,tblTenderForm.isPriceBid from TblItemSelection tblItemSelection");  
			  query.append(" inner join tblItemSelection.tblTenderForm tblTenderForm");  
			  query.append(" inner join tblTenderForm.tblTenderTable tblTenderTable"); 
			  query.append(" where  tblTenderForm.tblTender.tenderId=:tenderId");
			  if(bidderId != 0){
				  query.append(" and tblItemSelection.tblUserLogin.userId=:bidderId");
			  }
			  if(isPriceBidCondition != 0)
				  query.append(" and tblTenderForm.isPriceBid=1");
			  query.append(" and tblTenderForm.tblTenderEnvelope.tblEnvelope.envId in (4,5) and tblItemSelection.isBidded = 1 and tblTenderForm.cstatus = 1");
			  query.append(" group by tblTenderForm.formId,tblTenderForm.formHeader,tblTenderForm.formFooter,tblTenderForm.formName,tblTenderTable.tableId,tblTenderTable.tableName,tblTenderForm.isPriceBid");
			 
			 
			 return hibernateQueryDao.createNewQuery(query.toString(), var);
		
	}

	public List<Object[]> getColumnDetailsFromTableId(List<Integer> tblIds) {
		 StringBuilder query = new StringBuilder();
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put("tblIds", tblIds);
	        query.append("select tblTenderColumn.columnId,tblTenderTable.tableId,tblTenderForm.formId,tblTenderColumn.columnHeader,tblTenderColumn.tblColumnType.columnTypeId from TblTenderColumn tblTenderColumn ");
	        query.append("inner join tblTenderColumn.tblTenderTable tblTenderTable ");
	        query.append("inner join  tblTenderTable.tblTenderForm tblTenderForm ");
	        query.append("where tblTenderColumn.filledBy=1 and tblTenderTable.tableId in (:tblIds)");
	        return hibernateQueryDao.createNewQuery(query.toString(), var);
	}

	public List<Object[]> getCellDetailsFromColumnId(List<Integer> clmIds) {
		StringBuilder query = new StringBuilder();
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("clmIds", clmIds);
        query.append("select tblTenderCell.cellId,tblTenderCell.rowId,tblTenderCell.cellValue,tblTenderColumn.columnId,tblTenderTable.tableId,tblTenderColumn.columnHeader,tblTenderCell.tblTenderForm.formId from TblTenderCell tblTenderCell ");
        query.append("inner join tblTenderCell.tblTenderColumn tblTenderColumn ");
        query.append("inner join tblTenderColumn.tblTenderTable tblTenderTable ");
        query.append("where  tblTenderCell.dataType!=0 and  tblTenderColumn.columnId in (:clmIds)");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
	} 

	/*
	 * @author priyanka
     * @param companyId
     * @param clientId
     * @return 
     * @throws Exception
	 */
	public List<Object[]> getFinalSubmissionReceipt(int companyId, int clientId) {		
		StringBuilder query = new StringBuilder();
		Map<String, Object> var = new HashMap<String, Object>();
		List<Object[]> list = null;       
		var.put("companyId", companyId);
		var.put("clientId", clientId);
      	query.append("select tbluserlogin.loginId,tblcompany.companyName, tbluserlogin.mobileNo, tblcompany.address,tblcountry.lang").append(WebUtils.getCookie(getServletRequest(), "locale").getValue())
		.append(" ,tblcompany.city, tblcompany.tblState.lang").append(WebUtils.getCookie(getServletRequest(), "locale").getValue()).append(",tblcompany.phoneNo,tbluserlogin.userId ");		
		 query.append(" from TblCompany tblcompany ")
		 .append("inner join tblcompany.tblBidderStatus tblbidderstatus " )
		 .append("inner join tblbidderstatus.tblUserLogin tbluserlogin ")
		 .append("inner join tblcompany.tblCountry tblcountry ")
		 .append("where tblbidderstatus.tblClient.clientId=:clientId and tblcompany.companyId=:companyId");		 
		 list = hibernateQueryDao.createNewQuery(query.toString(), var);	
		 return list;		
	}	
	/*
	 * @author priyanka
     * @param tenderId
     * @param companyId
     * @return 
     * @throws Exception
	 */
	public Object getConsortiumDetail(int tenderId,int companyId) throws Exception {
		StringBuilder query = new StringBuilder();
		Object companyName = null;
		Map<String, Object> var = new HashMap<String, Object>();
		List<Object[]> list = null; 
		var.put("tenderId", tenderId);	
		var.put("companyId", companyId);
		query.append("select tblcompany.companyName from TblConsortiumDetail tblConsortiumDetail")
		.append(" inner join tblConsortiumDetail.tblConsortium tblconsortium")
		.append(" inner join tblConsortiumDetail.tblCompany tblcompany where tblConsortiumDetail.tblConsortium.consortiumId in ") 
		.append(" (select  tblconsortium.consortiumId from TblConsortium tblconsortium")  
		.append(" inner join tblconsortium.tblConsortiumDetail tblconsortiumdetail ")
		.append(" where tblconsortium.tblTender.tenderId=:tenderId and tblconsortium.isActive=1 and tblconsortiumdetail.tblCompany.companyId=:companyId) and tblConsortiumDetail.partnerType=2");  
		list = hibernateQueryDao.createNewQuery(query.toString(), var);	
		 if (list != null && !list.isEmpty()) {
			 companyName =   list.get(0);
	     }	
		 return companyName;	
	}
	/**
	 * @author manoj.gadhavi
	 * @param tenderId
	 * @return
	 * @throws Exception
	 */
	public boolean isL1H1Generated(int tenderId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        count = hibernateQueryDao.countForNewQuery("TblDynReportCell tblDynReportCell ", "tblDynReportCell.cellId ", "tblDynReportCell.tblDynReport.tblTender.tenderId=:tenderId", var);
        return count != 0;
    }
	
	
	/**
	 * @param tenderId
	 * @return
	 * @throws Exception
	 */
	public List<TblTenderPublicKey> getTenderBuyerPublicKey(int tenderId)throws Exception{
		List<TblTenderPublicKey> list = null; 
		list = tblTenderPublicKeyDao.findTblTenderPublicKey("tblTender.tenderId", Operation_enum.EQ, tenderId);
		return list;
	}
	/**
	 * @author vivek.rajyaguru
	 * @param objectId
	 * @return
	 */
	public boolean isCorrgendumPrepare(int objectId){
		boolean flag=false;
		StringBuilder query = new StringBuilder();
		Map<String, Object> var = new HashMap<String, Object>();
		List<Object[]> list = null; 
		var.put("objectId", objectId);	
		query.append("select tblCorrigendum.corrigendumId from TblCorrigendum tblCorrigendum");
		query.append(" where tblCorrigendum.cstatus in (0,3) and tblCorrigendum.objectId=:objectId");
		list = hibernateQueryDao.createNewQuery(query.toString(), var);	
		 if (list != null && !list.isEmpty()) {
			 flag=true;
	     }	
		 return flag;
	}

	 public String getDeptNameByTenderId(int tenderId) throws Exception{
	        String data=null;
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put("tenderId",tenderId);
	        List<Object> list = hibernateQueryDao.getSingleColQuery("select tbldepartment.deptName from TblTender tbltender inner join tbltender.tblDepartment tbldepartment where tbltender.tenderId=:tenderId",var);                
	        if(!list.isEmpty()){            
	            data = list.get(0).toString();
	        }
	        return data;
	    }
	 
	 public List<Object[]> getTenderColumnType(int tenderId){
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         StringBuilder query = new StringBuilder();
         query.append(" select columnTypeId,t.tenderId from apptender.tbl_Tender t  ")
         .append(" inner join apptender.tbl_TenderForm tf on t.tenderId = tf.tenderId ")
         .append(" inner join apptender.tbl_TenderColumn tc on tf.formId = tc.formId ")
         .append(" where t.tenderId=:tenderId and tf.cstatus = 1 ");
         return hibernateQueryDao.createSQLQuery(query.toString(), var);
	 }
	 /**
	     * @author dharmesh
	     * get Rest of auction money payment details
	     * @param objectId
	     * @param paymentFor
	     * @return
	     * @throws Exception
	     */
	    public List<Object[]> getRestOfTenderDetails(int objectId,int companyId,int moduleId,int transactionTypeId,int paymentTypeId,List<Integer> rowId) throws Exception{
	   	 Map<String, Object> var = new HashMap<String, Object>();
	     var.put("objectId",objectId);
	     var.put("moduleId",moduleId);
	     var.put("transactionTypeId", transactionTypeId);
	     var.put("feeType", 3);
	     boolean isItemwise= (getIsItemWise( objectId, moduleId)==2);
	     StringBuilder query = new StringBuilder();
	     query.append(" select TB.companyId as c0,UD.companyName as c1,(CAST(EF.eventFee as decimal)) as c2,payment.paymentId as c3,(CAST(TBD.cellValue as decimal)) as c4,0 as c5,(CAST(TBD.cellValue as decimal))-(CAST(EF.eventFee as decimal)) as c6,emdTransactionDetail.amount as c7,0 as c8,0 as c9, 0 as c10, 0 as c11,D.[1] as c12, TCL.rowId as c13 ")
	    .append(" from apptender.tbl_TenderGovColumn TGC    ")
	    .append(" INNER JOIN apptender.tbl_TenderForm TF ON TGC.formId=TF.formId and TF.cstatus=1 and TGC.tenderId=:objectId ")
	    .append(" INNER JOIN apptender.tbl_TenderColumn TC ON TGC.columnId=TC.columnId and TF.formId=TC.formId and TGC.tableId=TC.tableId  ")
	    .append(" INNER JOIN apptender.tbl_TenderCell TCL ON TCL.columnId=TC.columnId and TCL.formId=TC.formId and TCL.tableId=TC.tableId ") 
	    .append(" INNER JOIN apptenderbid.tbl_TenderBid TB ON TB.cstatus = 2 and TB.formId=TC.formId ")  
	    .append(" INNER JOIN apptenderbid.tbl_TenderBidMatrix TBM ON TBM.bidId=TB.bidId   ")
	    .append(" INNER JOIN apptenderresult.tbl_TenderBidDetail TBD ON TBD.bidTableId=TBM.bidTableId and TBD.cellId=TCL.cellId ")   
	    .append(" INNER JOIN apptenderbid.tbl_FinalSubmission FS ON FS.tenderId = TB.tenderId AND TB.companyId = FS.companyId AND FS.partnerType IN (0, 1, 2) ")  
	    .append(" INNER JOIN appuser.tbl_UserDetail UD ON UD.userDetailId=FS.userDetailId ")
	    .append(" INNER JOIN  appuser.tbl_EmdTransactionDetail emdTransactionDetail on emdTransactionDetail.objectId = TGC.tenderId and emdTransactionDetail.cstatus=2 and emdTransactionDetail.companyId= FS.companyId and TCL.rowId=emdTransactionDetail.rowId ");
	    if(rowId!=null){
	    	 var.put("rowId",rowId);
		     query.append(" and emdTransactionDetail.rowId in (:rowId) ");
	    }
	    if(companyId!=0){
	      	 var.put("companyId",companyId);
	      	query.append(" and FS.companyId =:companyId ");
	       }
	    query.append(" inner join appuser.tbl_Payment payment on payment.paymentId=emdTransactionDetail.paymentId and emdTransactionDetail.objectId=payment.objectId ")
	    .append(" INNER JOIN apppayment.tbl_EventFees EF ON  EF.objectId=TGC.tenderId and EF.companyId= FS.companyId and TCL.rowId=EF.rowId and EF.uniqueId=payment.uniqueId ")
	    .append("    LEFT OUTER JOIN (SELECT [formId],[tableId],[rowId],[1],[2]  FROM ( ")
	    .append("   SELECT DISTINCT TCC1.formId, TCC1.tableId, TCC1.rowId, TCC1.cellValue , TC1.columnTypeId   FROM apptender.tbl_TenderGovColumn TGC1 ")   
	    .append("   INNER JOIN  apptender.tbl_TenderForm TF1 ON TGC1.formId = TF1.formId and TGC1.tenderId = :objectId ") 
	    .append("   AND TF1.cstatus = 1  INNER JOIN apptender.tbl_TenderCell TCC1 ON TCC1.formId=TF1.formId ")  
	    .append("  INNER JOIN apptender.tbl_TenderColumn TC1 on TCC1.columnId = TC1.columnId  ")
	    .append("   WHERE TC1.filledBy = 1 and TC1.columnTypeId in (1,2)) AS A  PIVOT (MAX(cellValue) FOR columnTypeId IN ([1], [2])) AS P ) AS D ON D.formId=TF.formId ") 
	    .append("    and D.tableId=TBM.tableId and TCl.rowId=D.rowId and  emdTransactionDetail.transactionTypeId =:transactionTypeId ")
	    .append("    and EF.isActive=1 and EF.cstatus=1 and EF.feeType=:feeType and payment.moduleId=:moduleId ");
	    if(rowId!=null){
	    	 var.put("rowId",rowId);
		     query.append(" and emdTransactionDetail.rowId in (:rowId) ");
	    }
		
		 query.append("  order by TCl.rowId ");
	   	 int nVarCharColumnIndex [] = {1,9,12};
	      	return hibernateQueryDao.createSQLQuery(query.toString(),var,nVarCharColumnIndex,14);
	}
	 public int getIsItemWise(int objectId,int moduleId) throws Exception{
			int isEMDApplicable=0;
			if(moduleId==3){
	  		List<Object[]> l = getTenderFields(objectId, "isEMDApplicable,isCertRequired");
	  		if(!l.isEmpty()){
	  			Object[] tenderData = l.get(0);
	  			isEMDApplicable = Integer.parseInt(tenderData[0].toString());
	  		}
			}else if(moduleId==5){
//				TblAuction tblAuction=auctionService.getAuctionMaster(objectId);
//				isEMDApplicable = tblAuction.getIsEmdReq();
				isEMDApplicable=0;
			}
		  return isEMDApplicable;
	  }
	 
	 
	 /**
	 * @param objectId
	 * @param companyId
	 * @param moduleId
	 * @param transactionTypeId
	 * @param paymentTypeId
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> getRestOfTenderDetailsForItems(int objectId,int companyId,int moduleId,int transactionTypeId,int paymentTypeId) throws Exception{
	   	 Map<String, Object> var = new HashMap<String, Object>();
	     var.put("objectId",objectId);
	     var.put("moduleId",moduleId);
	     var.put("companyId",companyId);
	     var.put("moduleId",moduleId);
	     var.put("transactionTypeId",transactionTypeId);
	     StringBuilder query = new StringBuilder();
	     query.append(" select TB.companyId as c0 ,UD.companyName as c1,isnull(CAST(EF.eventFee as DECIMAL(20,4)),0) as c2,payment.paymentId as c3,TBD.cellValue as c4,emdTransactionDetail.amount as c5,  (CAST(emdTransactionDetail.amount as DECIMAL(20,4)))  -(CAST(ISNULL(REMP.eventFee,0) as DECIMAL(20,4))) as c6,TCL.formId as c7,TCL.tableId as c8,D.[1] as c9,TCL.rowId as c10,emdTransactionDetail.isTransactionDateWise as c11,emdTransactionDetail.transactionEndDateTime as c12 ")
	    .append(" from appuser.tbl_EmdTransactionDetail emdTransactionDetail  ")
	    .append(" inner join apptender.tbl_TenderGovColumn TGC on TGC.tenderId = emdTransactionDetail.objectid  and emdTransactionDetail.objectid=:objectId and emdTransactionDetail.transactionTypeId=:transactionTypeId and emdTransactionDetail.cstatus=2 and emdTransactionDetail.companyId=:companyId ")
	    .append(" INNER JOIN apptender.tbl_TenderForm TF ON TGC.formId=TF.formId and TF.cstatus=1  ")
	    .append(" INNER JOIN apptender.tbl_TenderColumn TC ON TGC.columnId=TC.columnId and TF.formId=TC.formId and TGC.tableId=TC.tableId  ") 
	    .append(" INNER JOIN apptender.tbl_TenderCell TCL ON TCL.columnId=TC.columnId and TCL.formId=TC.formId and TCL.tableId=TC.tableId and emdTransactionDetail.rowId=TCL.rowId ")  
	    .append(" INNER JOIN apptenderbid.tbl_TenderBid TB ON TB.cstatus = 2 and TB.formId=TC.formId and emdTransactionDetail.objectid=TB.tenderId and  TB.companyId=emdTransactionDetail.companyId      ")
	    .append(" INNER JOIN apptenderbid.tbl_TenderBidMatrix TBM ON TBM.bidId=TB.bidId    ")
	    .append(" INNER JOIN apptenderresult.tbl_TenderBidDetail TBD ON TBD.bidTableId=TBM.bidTableId and TBD.cellId=TCL.cellId ")   
	    .append(" INNER JOIN apptenderbid.tbl_FinalSubmission FS ON FS.tenderId = TB.tenderId AND TB.companyId = FS.companyId AND FS.partnerType IN (0, 1, 2) and  FS.companyId=emdTransactionDetail.companyId ")  
	    .append(" INNER JOIN appuser.tbl_UserDetail UD ON UD.userDetailId=FS.userDetailId ")
	    .append(" LEFT join appuser.tbl_Payment payment on payment.paymentId=emdTransactionDetail.paymentId and emdTransactionDetail.objectId=payment.objectId and payment.moduleId=:moduleId ")
	    .append(" LEFT OUTER JOIN (select  EFD.rowid,EFD.companyId,EFD.objectId, sum(CAST(EFD.eventfee as DECIMAL(20,4))) as eventFee,EFD.feeType from apppayment.tbl_EventFees EFD where EFD.isActive=1 and EFD.cstatus=1 and EFD.feeType=3 and EFD.companyId=:companyId and EFD.objectId=:objectId   group by rowId,companyId,objectId,EFD.feeType) AS EF ON EF.objectId=TGC.tenderId and EF.companyId= FS.companyId and TCL.rowId=EF.rowId  ")
	    .append(" LEFT OUTER JOIN (select  EFD.rowid,EFD.companyId,EFD.objectId, sum(CAST(EFD.eventfee as DECIMAL(20,4))) as eventFee,EFD.feeType from apppayment.tbl_EventFees EFD where EFD.isActive=1 and EFD.cstatus=1 and EFD.feeType=9 and EFD.companyId=:companyId and EFD.objectId=:objectId     group by rowId,companyId,objectId,EFD.feeType) AS REMP ON REMP.objectId=TGC.tenderId and REMP.companyId= FS.companyId and TCL.rowId=REMP.rowId  ")
	    .append("    LEFT OUTER JOIN (SELECT [formId],[tableId],[rowId],[1],[2]  FROM ( ")
	    .append("   SELECT DISTINCT TCC1.formId, TCC1.tableId, TCC1.rowId, TCC1.cellValue , TC1.columnTypeId   FROM apptender.tbl_TenderGovColumn TGC1 ")   
	    .append("   INNER JOIN  apptender.tbl_TenderForm TF1 ON TGC1.formId = TF1.formId and TGC1.tenderId = :objectId ") 
	    .append("   AND TF1.cstatus = 1  INNER JOIN apptender.tbl_TenderCell TCC1 ON TCC1.formId=TF1.formId ")  
	    .append("  INNER JOIN apptender.tbl_TenderColumn TC1 on TCC1.columnId = TC1.columnId  ")
	    .append("   WHERE TC1.filledBy = 1 and TC1.columnTypeId in (1,2)) AS A  PIVOT (MAX(cellValue) FOR columnTypeId IN ([1], [2])) AS P ) AS D ON D.formId=TF.formId ") 
	    .append("    and D.tableId=TBM.tableId and TCl.rowId=D.rowId order by TCl.rowId   ");
	    int nVarCharColumnIndex [] = {1,4,9,12};
	    return hibernateQueryDao.createSQLQuery(query.toString(),var,nVarCharColumnIndex,13);
	}
	
	
	/**
     * @param objectId
     * @param companyId
     * @return
     * @throws Exception
     */
    public boolean isRestofEventCongfigured(int objectId,int companyId,int transactionTypeId,int cstatus)throws Exception{
    	 boolean isAccessTab=false;
    	 Map<String, Object> map = new HashMap<String, Object>();
    	 map.put("objectId", objectId);
    	 map.put("transactionTypeId", transactionTypeId);
    	 map.put("cstatus", cstatus);
    	 StringBuilder query = new StringBuilder();
    	 query.append(" select count(emdTransactionId) from TblEMDTransactionDetail tblEMDTransactionDetail INNER JOIN tblEMDTransactionDetail.tblCompany tblCompany INNER JOIN tblEMDTransactionDetail.tblTransactionType tblTransactionType where tblEMDTransactionDetail.objectId=:objectId ");
    	 if(companyId !=0){
    		 map.put("companyId", companyId);
    		 query.append(" and tblCompany.companyId=:companyId ");
    	 }
    	 query.append(" and tblEMDTransactionDetail.cstatus=:cstatus and tblTransactionType.transactionTypeId=:transactionTypeId ");
    	 List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(),map);
         if(list!=null && !list.isEmpty()){
        	 if(Integer.parseInt(list.get(0).toString())>0){
        		 isAccessTab=true;
        	 }
         }
         return isAccessTab;
    }
    
    
    /**
     * @param objectId
     * @param companyId
     * @param moduleId
     * @param transactionTypeId
     * @param paymentTypeId
     * @return
     * @throws Exception
     */
    public List<Object[]> getRestOfTenderDetailsForGT(int objectId,int companyId,int moduleId,int transactionTypeId,int paymentTypeId) throws Exception{
	   	 Map<String, Object> var = new HashMap<String, Object>();
	     var.put("objectId",objectId);
	     var.put("companyId",companyId);
	     var.put("transactionTypeId",transactionTypeId);
	     StringBuilder query = new StringBuilder();
	     int isEMD=-1;
         int isItemwiseWinner=-1;
         var.put("objectId",objectId);
         
         List<Object[]> l = getTenderFields(objectId, "isEMDApplicable,isItemwiseWinner");
	  		if(!l.isEmpty()){
	  			Object[] tenderData = l.get(0);
	  			isEMD = Integer.parseInt(tenderData[0].toString());
	  			isItemwiseWinner =  Integer.parseInt(tenderData[1].toString());// 0 for Grand total wise, 1 for Item wise, 2 for Lot wise
	  		}
	     query.append(" select TB.companyId as c0,UD.companyName as c1, isnull(tblpayment0_.amount,0) as c2,isnull(tblpayment0_.paymentId,0) as c3,(CAST(TBD.cellValue as decimal)) AS c4,0 as c5,(CAST(TBD.cellValue as decimal))-(ISNULL(tblpayment0_.amount, 0)) as c6,emdTransactionDetail.amount as c7   ,isnull(tblPaymentType0_.paymentTypeId,0) as c8,tblPaymentType0_.lang1 as c9,0 as c10,emdTransactionDetail.isTransactionDateWise as c11,emdTransactionDetail.transactionEndDateTime as c12  ")
	   .append(" from apptender.tbl_Rebate TR  ")
	    .append(" INNER JOIN apptender.tbl_RebateForm RF ON TR.rebateId=RF.rebateId   ")
	    .append(" INNER JOIN apptender.tbl_TenderForm TF ON RF.formId=TF.formId and TF.cstatus=1   ")   
	    .append(" INNER JOIN apptender.tbl_TenderCell TCL ON TCL.formId=RF.formId and RF.cellId=TCL.cellId  ")  
	    .append(" INNER JOIN apptenderbid.tbl_TenderBid TB ON TB.cstatus = 2 and TB.formId=TF.formId   ") // and TB.companyId=tblpayment0_.companyId
	    .append(" INNER JOIN apptenderbid.tbl_TenderBidMatrix TBM ON TBM.bidId=TB.bidId   ")
	    .append(" INNER JOIN apptenderresult.tbl_TenderBidDetail TBD ON TBD.bidTableId=TBM.bidTableId  and TBD.cellId=TCL.cellId   ")
	    .append(" INNER JOIN apptenderbid.tbl_FinalSubmission FS ON FS.tenderId = TB.tenderId AND TB.companyId = FS.companyId AND FS.partnerType IN (0, 1, 2)   ")
	    .append(" INNER JOIN appuser.tbl_UserDetail UD ON UD.userDetailId=FS.userDetailId  ")
	    .append(" INNER JOIN  appuser.tbl_EmdTransactionDetail emdTransactionDetail on emdTransactionDetail.objectId = FS.tenderId  and emdTransactionDetail.cstatus=2    ")   //and  emdTransactionDetail.paymentid = tblpayment0_.paymentid
	     .append(" LEFT JOIN appuser.Tbl_Payment tblpayment0_  ON TR.tenderid = tblpayment0_.objectId and tblpayment0_.cstatus=1  and tblpayment0_.paymentFor=2 and tblpayment0_.companyId =:companyId  ")
	    .append(" LEFT JOIN appuser.Tbl_OnlinePayment tblonlinep1_ on tblpayment0_.paymentId=tblonlinep1_.paymentid and tblonlinep1_.responseCode='0300'  ")
	    .append(" LEFT JOIN appuser.Tbl_OfflinePayment tblofflinep4_ on tblpayment0_.paymentId=tblofflinep4_.paymentid   ")
	    .append(" INNER JOIN appuser.Tbl_Company tblcompany2_ on FS.companyId=tblcompany2_.companyId and tblcompany2_.companyId =:companyId  ")   
	    .append(" LEFT JOIN appmaster.tbl_PaymentType tblPaymentType0_  on tblPaymentType0_.paymentTypeId = tblpayment0_.paymentTypeId   ")  
	    .append(" WHERE 1=1 ");
	    if(isEMD!=0){
	    	 var.put("moduleId",moduleId);
	    	query.append("  and tblpayment0_.moduleid=:moduleId   ") 
		    .append(" and tblPaymentType0_.paymentTypeId=tblpayment0_.paymentTypeId      ");  
	    }
	     query.append(" and emdTransactionDetail.transactionTypeId =:transactionTypeId and TR.tenderid = :objectId   ");
	    
	    int nVarCharColumnIndex [] = {1,9,12};
	    return hibernateQueryDao.createSQLQuery(query.toString(),var,nVarCharColumnIndex,13);
	}
    
    public int advanceFormulaCount(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        int count=0;
        StringBuilder query = new StringBuilder();
        query.append(" select COUNT(tblTenderFormula.tblTenderForm.formId) from TblTenderFormula tblTenderFormula where tblTenderFormula.tblTenderForm.tblTender.tenderId=:tenderId ");
        query.append(" and tblTenderFormula.tblTenderForm.isPriceBid=1 and tblTenderFormula.tblTenderForm.cstatus <> 2 ");
        query.append(" and (tblTenderFormula.formula LIKE 'VCF_%' OR tblTenderFormula.formula LIKE 'VF_%' OR tblTenderFormula.formula LIKE 'SPF_%') ");
        List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(),var);
        if(list!=null && !list.isEmpty()){
            count = Integer.parseInt(list.get(0).toString());
        }
        return count;
    }
    
    /**
     * To get event type of particular tenderId.
     * @author jitendra
     * @param tenderId
     * @return
     * @throws Exception
     */
    public String getEventTypeByTenderId(int tenderId) throws Exception{
        String event = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        List<Object> list = hibernateQueryDao.getSingleColQuery("select tblEventType.lang" + WebUtils.getCookie(getServletRequest(), "locale").getValue()+" from TblTender tbltender inner join tbltender.tblEventType tblEventType where tbltender.tenderId=:tenderId",var);                
        if(!list.isEmpty()){            
        	event = list.get(0).toString();
        }
        return event;
    }
    
    /**
     * To get remark of cancelled tender using tenderId and linkId.
     * @author anjali
     * @param tenderId
     * @param linkId
     * @return
     * @throws Exception
     */
    
    public String getCancelledTenderRemark(int tenderId,int linkId) throws Exception{
    	
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId", tenderId);
         var.put("linkId", linkId); 
    	 String query = "select remark from TblCancelRequest where objectId = :tenderId and linkId = :linkId"; 
         
         List<Object> list = hibernateQueryDao.getSingleColQuery(query, var);
         
         return !list.isEmpty() ? list.get(0).toString() : "";
    }
    
    /**
     * To get gcmId for Mobile Application Notification.
     * @author Priyanka Dalwadi
     * @param eventType
     * @param isApple
     * @return
     * @throws Exception
     */
    public List<Object[]> getGcmIds(int eventType,boolean isApple) throws Exception {
        List<Object[]> list = null;
        
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId", defaultAPClientId);
        
        		query.append("select distinct tbluserlogin.userId,tblmobileuserlogin.gcmId,tblCompany.keywordText,tblCompany.companyId,tbluserlogin.loginId from TblUserLogin tbluserlogin ")
                .append(" inner join tbluserlogin.tblMobileBidderStatus tblMobileBidderStatus with tblMobileBidderStatus.cstatus =1 ")
        		.append(" inner join tbluserlogin.tblMobileUserLogin tblmobileuserlogin with tblmobileuserlogin.isActive=1")
                .append(" inner join tbluserlogin.tblBidderStatus tblBidderStatus with tblBidderStatus.tblClient.clientId=:clientId and tblBidderStatus.cstatus = 1")
                 .append(" inner join tblBidderStatus.tblCompany tblCompany ")
                .append(" where tblmobileuserlogin.gcmId is not null");
        		if(isApple){
        			query.append(" and tblmobileuserlogin.manufactureName like 'apple'");
        		}else{
        			query.append(" and tblmobileuserlogin.manufactureName not like 'apple'");
        		}
       if(eventType == 3) { // Tender
    	   query.append(" and tblmobileuserlogin.appFor  like 'AP' "); 
       }
       //query.append(" and tblmobileuserlogin.appFor =:appFor ");
        list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return list;

    }
    
    /**
     * To Send Notification for Mobile Application.
     * @author Priyanka Dalwadi
     * @param eventType
     * @param notificationMsg
     * @param tenderId
     * @param notificationType
     * @param clientId
     * @return
     * @throws Exception
     */
    public void sendMobileNotification(int eventType,String notificationMsg,int tenderId,int notificationType,int clientId) throws Exception {
    	
    	List<String> deviceLst = new ArrayList<String>();
    	List<Integer> userLst = new ArrayList<Integer>();
    	List<Integer> userLstIos = new ArrayList<Integer>();
    	List<TblNotificationHistory> tblNotificationHistorys=  new ArrayList<TblNotificationHistory>();
        List<Object[]> lstGcmIds = getGcmIds(3,false);
        String keywords="";
        int i=0;
        String selectedCategory = "";
        i= commonService.isCategoryAllow(clientId);
    	if(i==1){
        	 selectedCategory = commonService.getCategoryNameList(tenderId,tendercreationlink);
    	}
        TblTender tblTender = getTenderById(tenderId);
        //prepare iosTokens list Project Task #26572
        List<String> deviceLstIos = new ArrayList<String>();
        List<Object[]> lstIosTokens = getGcmIds(3,true); //true for apple
        if (!lstIosTokens.isEmpty()) {
        		for (Object[] objects : lstIosTokens) {
        			if(notificationType==0){
        			if(getMobileDomain(Integer.parseInt(objects[0].toString()), clientId)){
	        		String[] keywordList = objects[2].toString().split(",");
	        		for(String keyword :  keywordList){
	//	        		if(tblTender.getTenderBrief().contains(keyword) || tblTender.getTenderDetail().contains(keyword) || String.valueOf(tblTender.getTenderId()).contains(keyword) || tblTender.getTenderNo().contains(keyword)  || tblTender.getKeywordText().contains(keyword)){
	        			if(i==1 && selectedCategory.toLowerCase().contains(keyword.toLowerCase()) || i==0 && tblTender.getKeywordText().toLowerCase().contains(keyword.toLowerCase())){
		        			deviceLstIos.add((String) objects[1]);
		        			userLst.add(Integer.parseInt(objects[0].toString()));
		        		}
	        		}
        		}
        	}else if(notificationType==1){
        			List<TblFavouriteEvent> tblFavouriteTenderLst = getUserByTenderId(tenderId);
        			if(tblFavouriteTenderLst!=null && !tblFavouriteTenderLst.isEmpty()){
        				for(TblFavouriteEvent tblFavouriteTender :  tblFavouriteTenderLst){
        					if(tblFavouriteTender.getTblUserLogin().getUserId() == Integer.parseInt(objects[0].toString())){
        						deviceLstIos.add((String) objects[1]);
        						userLst.add(Integer.parseInt(objects[0].toString()));
			        		}
		        		}
        			}
        		}
            }
        }

        if (!lstGcmIds.isEmpty()) {
            for (Object[] objects : lstGcmIds) {
        		if(notificationType==0){	
        			if(getMobileDomain(Integer.parseInt(objects[0].toString()), clientId)){
	        		String[] keywordList = objects[2].toString().split(",");
	        		for(String keyword :  keywordList){
	//	        		if(tblTender.getTenderBrief().contains(keyword) || tblTender.getTenderDetail().contains(keyword) || String.valueOf(tblTender.getTenderId()).contains(keyword) || tblTender.getTenderNo().contains(keyword)  || tblTender.getKeywordText().contains(keyword)){
	        			if(i==1 && selectedCategory.toString().toLowerCase().contains(keyword.toLowerCase()) || i==0 && tblTender.getKeywordText().toLowerCase().contains(keyword.toLowerCase())){
	        				deviceLst.add((String) objects[1]);
	        				userLst.add(Integer.parseInt(objects[0].toString()));
		        		}
	        		}
        			}
        		}else if(notificationType==1){
        			List<TblFavouriteEvent> tblFavouriteTenderLst = getUserByTenderId(tenderId);
        			if(tblFavouriteTenderLst!=null && !tblFavouriteTenderLst.isEmpty()){
        				for(TblFavouriteEvent tblFavouriteTender :  tblFavouriteTenderLst){
        					if(tblFavouriteTender.getTblUserLogin().getUserId() == Integer.parseInt(objects[0].toString())){
        						deviceLst.add((String) objects[1]);
        						userLst.add(Integer.parseInt(objects[0].toString()));
			        		}
		        		}
        			}
        		}
            }
        }
        
        boolean success = true;
        // Added By Nirav Raval for avoid exception "java.net.UnknownHostException: android.googleapis.com" for message notification.
        if(!deviceLst.isEmpty()){
        	success = sendNotification(deviceLst, notificationMsg, tenderId, clientId,eventType);
        }
        //Project Task #26572
        if(!deviceLstIos.isEmpty()){
        	success = sendGCMNotification.sendTenderAPNS(notificationMsg, deviceLstIos, eventType, tenderId, clientId);
        }
        
        if(success){
        	if(userLst!=null && !userLst.isEmpty()){ 
        	for(Integer user :  userLst){
		        TblNotificationHistory tblNotificationHistory=new TblNotificationHistory();
		    	tblNotificationHistory.setTblClient(new TblClient(clientId));
		    	tblNotificationHistory.setTblTender(new TblTender(tenderId));
		    	tblNotificationHistory.setTblUserLogin(new TblUserLogin(user));
		    	tblNotificationHistory.setIsActive(0);
		    	tblNotificationHistory.setNotificationMsg(notificationMsg);
		    	tblNotificationHistorys.add(tblNotificationHistory);
        	}
        	tblNotificationHistoryDao.saveUpdateAllTblNotificationHistory(tblNotificationHistorys);
        	}
        }
    }
   
    /**
     * To get User who had marked Tender as Favourite
     * @author Priyanka Dalwadi
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<TblFavouriteEvent> getUserByTenderId(int tenderId) throws Exception {
    	  List<TblFavouriteEvent> list = null;
          list = tblFavouriteTenderDao.findTblFavouriteTender("objectId", Operation_enum.EQ, tenderId,"isActive", Operation_enum.EQ, 1);
          return (list != null && !list.isEmpty()) ? list : null;
    }
    
    /**
     * To Send Notification for Mobile Application.
     * @author Priyanka Dalwadi
     * @param deviceLst
     * @param notificationMsg
     * @param clientId
     * @param eventType
     * @return
     * @throws Exception
     */
    public boolean sendNotification(List<String> deviceLst, String msg, int tenderId, int clientId , int eventType ) throws Exception {

        JSONObject object = new JSONObject();
        object.put("tenderId", tenderId);
        object.put("clientId", clientId);
        object.put("message", msg);
        List<String> notificationLst = sendGCMNotification.sendNotificationForTender(object.toString(), deviceLst,eventType);
        if(notificationLst==null || notificationLst.isEmpty() ){
        	return true;
        }
        return false;
    }
	
	 /**
     * @author anjali
     * Get FormIds for which bidder has done bidding
  	 * @param tenderId
  	 * @param bidderId
  	 * @param isPriceBidCondition
  	 * @return
  	 * @throws Exception
  	*/
    public List<Integer> getTenderFormIdByTenderAndBidderId(int tenderId, int bidderId, int isPriceBidCondition) throws Exception{
		 StringBuilder query = new StringBuilder();
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put("tenderId", tenderId);
	        if(bidderId != 0){
	        	var.put("bidderId", bidderId);
	        }
			 query.append("SELECT tblTenderForm.formId FROM TblItemSelection tblItemSelection");  
			 query.append(" INNER JOIN tblItemSelection.tblTenderForm tblTenderForm");  
			 query.append(" WHERE tblTenderForm.tblTender.tenderId=:tenderId");
			  if(bidderId != 0){
				  query.append(" AND tblItemSelection.tblUserLogin.userId=:bidderId");
			  }
			  if(isPriceBidCondition != 0)
				  query.append(" AND tblTenderForm.isPriceBid=1");
			  query.append(" AND tblTenderForm.tblTenderEnvelope.tblEnvelope.envId IN (4,5) AND tblItemSelection.isBidded = 1 AND tblTenderForm.cstatus = 1");
			  query.append(" GROUP BY tblTenderForm.formId");
			  List<Integer> formIdList = new ArrayList<Integer>();
			  List<Object> list =  hibernateQueryDao.singleColQuery(query.toString(), var);
			  if(list!=null && !list.isEmpty()){
				  for(Object formId : list){
				  formIdList.add(Integer.valueOf(formId.toString()));
				  }
			  }
			 
			 return formIdList;
	}
    
    /**
     * @author anjali
     * Get FormIds and TableIds for which bidder has done bidding
  	 * @param tenderId
  	 * @param bidderId
  	 * @param isPriceBidCondition
  	 * @return
  	 * @throws Exception
  	*/
    public List<String> getTenderFormIdTableIdByTenderAndBidderId(int tenderId, int bidderId) throws Exception{
		 StringBuilder query = new StringBuilder();
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put("tenderId", tenderId);
	        if(bidderId != 0){
	        	var.put("bidderId", bidderId);
	        }
			 query.append("SELECT tblTenderForm.formId,tblItemSelection.tblTenderTable.tableId FROM TblItemSelection tblItemSelection");  
			 query.append(" INNER JOIN tblItemSelection.tblTenderForm tblTenderForm");  
			 query.append(" WHERE tblTenderForm.tblTender.tenderId=:tenderId");
			  if(bidderId != 0){
				  query.append(" AND tblItemSelection.tblUserLogin.userId=:bidderId");
			  }
			  query.append(" AND tblItemSelection.isBidded = 1 AND tblTenderForm.cstatus = 1");
			  query.append(" GROUP BY tblTenderForm.formId,tblItemSelection.tblTenderTable.tableId");
			  List<String> formAndTableIdList = new ArrayList<String>();
			  List<Object[]> list =  hibernateQueryDao.createNewQuery(query.toString(),var);
			  if(list!=null && !list.isEmpty()){
				  for(Object[] formId : list){
					  formAndTableIdList.add(formId[0].toString()+"_"+formId[1].toString());
				  }
			  }
			 
			 return formAndTableIdList;
	}
   /**
     * @author anjali
     * Get List of BidderIds using consortiumId
  	 * @param consortiumId
  	 * @return
  	 * @throws Exception
  	*/
    public List<Object> getTenderBidderIdByConsoritumId(int consortiumId) throws Exception{
		    StringBuilder query = new StringBuilder();
	        Map<String, Object> var = new HashMap<String, Object>();
	        List<Object> list = new ArrayList<Object>();
	        var.put("consortiumId", consortiumId);
	       
			 query.append("SELECT tblConsortiumDetail.tblUserLogin.userId FROM TblConsortiumDetail tblConsortiumDetail ");  
			 query.append("WHERE tblConsortiumDetail.tblConsortium.consortiumId=:consortiumId AND cstatus=1");
		
			 list =  hibernateQueryDao.singleColQuery(query.toString(), var);
			 
			 return list.isEmpty() ? null : list;
	}
    /**@author Dhruvil.panchal
     * @param objectId
     * @param moduleId
     * @return
     * @throws Exception
     */
     public String getMarqueetext(int objectId,int moduleId) throws Exception{
     	String marqueeText =null;
 	    Map<String, Object> var = new HashMap<String, Object>();
        List<Object[]> list = null;
        StringBuffer sb = new StringBuffer();
 		sb.append(" select top 1 marqueetext  as c0 ,objectid as c1 from appcommon.tbl_eventmarquee where objectId="+objectId+" and moduleId ="+moduleId+" and isactive in (0,1) and cstatus ="+1+" and endDate > GETUTCDATE() and startDate < GETUTCDATE() order by marqueeId desc ");
 		list = hibernateQueryDao.createSQLQuery(sb.toString(), var,new int[]{0},2);
 		if(!list.isEmpty()){
 			marqueeText= list.get(0)[0].toString();
 	      }
 		return marqueeText;
     }
     /**
      * For PT.# 38353 send mobile notification for selected client 
      * @author Dhruvil.panchal
      * @param userId
      * @param clientId
      * @return
      * @throws Exception
      */
     public boolean getMobileDomain(int userId,int clientId) throws Exception{
      	Map<String, Object> var = new HashMap<String, Object>();
        List<Object[]> list = null;
        StringBuffer sb = new StringBuffer();
  		sb.append(" select clientIds as c0 , 1 as c1 from appuser.tbl_mobilebidderstatus where cStatus="+1+" and userId ="+userId);
  		list = hibernateQueryDao.createSQLQuery(sb.toString(), var,new int[]{0},2);
  		String clientIds =list.get(0).toString();
  		if(clientIds.contains(Integer.toString(clientId))){
  			return true;
  		} 
     	return false;
      }
     
     /**
      * This method returns List of all next envelopeIds based on tenderId and sortOrder
      * @author anjali
      * @param tenderId
      * @param sortOrder
      * @return
      * @throws Exception
      */
     public List<Object> getListOfNextEnvelopeIds(int tenderId,int sortOrder) throws Exception {
         String query = new String();
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId", tenderId);
         var.put("sortOrder", sortOrder);
         query = "SELECT envelopeId FROM TblTenderEnvelope WHERE tblTender.tenderId=:tenderId AND sortOrder>:sortOrder ORDER BY sortOrder";
         List<Object> list = hibernateQueryDao.singleColQuery(query.toString(), var);
         return (list != null && !list.isEmpty()) ? list : null;
     }
     
     /**
      * To check whether bidder has done payment for EMD or not
      * @author anjali
      * @param tenderId
      * @param companyId
      * @return
      * @throws Exception
      */
     
     public boolean isEmdPayed(int tenderId,int companyId){
   	  boolean isEmdPayedFlag = false;
   	  Map<String,Object> var = new HashMap<String, Object>();
   	  var.put("tenderId", tenderId);
      var.put("companyId", companyId);
   	  String query = "select cstatus from TblEventFees where objectId=:tenderId and tblCompany.companyId=:companyId and feeType = 3 and isActive=1";
   	  List<Object> list= hibernateQueryDao.singleColQuery(query, var);
   	  
   	  if(list!=null && !list.isEmpty()){
   		  if(Integer.parseInt(list.get(0).toString()) == 1){
   			isEmdPayedFlag = true;
   		  }
   	  }
   	  return isEmdPayedFlag;
     }
     /**
      * To loginId of Mapped department officer in tender
      * @author anjali
      * @param tenderId
      * @param clientId
      * @return
      * @throws Exception
      */
     public String getMappedDepartmentOfficerLoginId(int tenderId,int clientId) throws Exception{
    	  Map<String,Object> var = new HashMap<String, Object>();
    	  var.put("tenderId",tenderId);
    	  var.put("clientId",clientId);
    	  StringBuilder query = new StringBuilder();
    	  query.append("select tblOfficer.tblUserLogin.loginId from TblOfficer tblOfficer where ");
    	  query.append("tblOfficer.tblUserLogin.userId =(select officerId from TblTender where tenderId =:tenderId) ");
    	  query.append("and tblOfficer.tblClient.clientId =:clientId");
    	  
    	  List<Object> list = hibernateQueryDao.singleColQuery(query.toString(),var);
    	  
    	  return (list!=null && !list.isEmpty()) ? list.get(0).toString() : "";
     }

     /**Get Alternate email ids for the mapped bidder id
      * @author nitin.w
      * @param mapBidderId
      * @return
      * @throws Exception
      */
     public List<Object[]> getDataAlternateEmailWithMapBidderId(int mapBidderId) throws Exception {
    	 List<Object[]> list = null;
         
         StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("mapBidderId", mapBidderId);
         query.append("select tblMapAlternateEmailIds.alternateEmailId,tblMapAlternateEmailIds.alternateEmail,tblMapAlternateEmailIds.mapBidderId ");
         query.append("from TblMapAlternateEmailIds tblMapAlternateEmailIds where tblMapAlternateEmailIds.mapBidderId = :mapBidderId");
        
         list = hibernateQueryDao.createNewQuery(query.toString(), var);
         return list;
     }
     
     /**
     *
     * @param tenderId
     * @param envId
     * @return
     * @throws Exception
     */
     public boolean isEnvelopeExist(int tenderId, int envId) throws Exception {

        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("envId", envId);
        count = hibernateQueryDao.countForNewQuery("TblTenderEnvelope tblTenderEnvelope ", "tblTenderEnvelope.envelopeId ", "tblTenderEnvelope.tblEnvelope.envId=:envId and tblTenderEnvelope.tblTender.tenderId=:tenderId", var);
        return count != 0;
    }
     /**
      * @author meghna
      * @param tenderId
      * @return
      * @throws Exception
      */
     public int checkDocumentDownloadDate(int tenderId) throws Exception{
         int isDocdownloadendDate = 0;
         StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId", tenderId);
         query.append("select case when getutcdate() < documentEndDate then 2 else -2 end")
             .append(" from TblTender where tenderId=:tenderId and cstatus=1 and downloadDocument=3");
         List<Object> lstObject = hibernateQueryDao.getSingleColQuery(query.toString(), var);
         if(!lstObject.isEmpty()){
        	 isDocdownloadendDate = (Integer) lstObject.get(0);
         }
         return isDocdownloadendDate;
     }
     /**
      * author :anjali.c for getting encoded companyName from tenderId and companyId
      *
      * @param tenderId
      * @param companyId
      * @return
      * @throws Exception
      */
     public String getEncodedCompanyName(int tenderId,int companyId) throws Exception {
         String data = null;
         Map<String, Object> var = new HashMap<String, Object>();
         StringBuilder query = new StringBuilder();
         var.put("tenderId", tenderId);
         var.put("companyId", companyId);
         query.append("SELECT tblTenderBidConfirmation.encodedName FROM TblTenderBidConfirmation tblTenderBidConfirmation WHERE ");
         query.append(" tblTenderBidConfirmation.tblTender.tenderId=:tenderId AND tblTenderBidConfirmation.tblCompany.companyId=:companyId");
         List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(), var);
         if (!list.isEmpty()) {
             data = list.get(0).toString();
         }
         return data;
     }
     public void getNetAmountAndTax(Map<String, Object> hashMap,int clientId,int userId,int payFor,BigDecimal gstAmount,int isDocfeesByBidder,int isFromReceipt) throws Exception{
   	  int objectId = Integer.valueOf(hashMap.get("objectId").toString());
   	  int bidderStateId = 0;
   	  int data = 0;
   	  int paymentId = 0;
   	  List<Object[]> obj = getTenderFields(objectId, "taxType,cgst,sgst,igst,documentFee,registrationCharges,tblDepartment.deptId");
   	  if(Integer.valueOf(hashMap.get("userTypeId").toString())==1 || Integer.valueOf(hashMap.get("userTypeId").toString())==3){
   		  bidderStateId = commonService.getStateIdByCompanyId(userId);
   	  }else if(Integer.valueOf(hashMap.get("userTypeId").toString())==2){
   		  List<Object[]> bidderDetails = manageBidderService.viewBidderProfile(userId, clientId, true);
   		  bidderStateId = Integer.valueOf(bidderDetails.get(0)[4].toString());
   	  }
   	  if ((isFromReceipt == 1 || hashMap.get("paymentId") != null) && hashMap.get("offlinePayment") == null) {
   		  if(hashMap.get("paymentId") != null){
				paymentId = Integer.valueOf(hashMap.get("paymentId").toString());
				if (paymentId != 0) {
					data = commonService.getPaymentGSTState(paymentId);
					if (data != 0) {
						bidderStateId = data;
					}
				}
   		  }
   	  }
   	  int deptStateId = commonService.getStateIdByDeptId(Integer.valueOf(obj.get(0)[6].toString()));
   	  BigDecimal amount = new BigDecimal("0.00");
   	  int taxType = Integer.valueOf(obj.get(0)[0].toString());
   	  if(payFor==1 && isDocfeesByBidder==0){
   		  amount = amount.add(new BigDecimal((String) obj.get(0)[4]));
   	  }else if((payFor==1 || payFor==8) && isDocfeesByBidder!=0){
   		  amount = amount.add(gstAmount);
   	  }
   	  else if(payFor==8){
   		amount = amount.add(new BigDecimal(obj.get(0)[5].toString()));
   	  }
   	  BigDecimal cgstPer = new BigDecimal(obj.get(0)[1].toString());
   	  BigDecimal sgstPer = new BigDecimal(obj.get(0)[2].toString());
   	  BigDecimal igstPer = new BigDecimal(obj.get(0)[3].toString());
   	  BigDecimal cgstAmount = new BigDecimal("0.00");
   	  BigDecimal sgstAmount = new BigDecimal("0.00");
   	  BigDecimal igstAmount = new BigDecimal("0.00");
   	  BigDecimal totalTax = new BigDecimal("0.00");
   	  BigDecimal netAmount = new BigDecimal("0.00");
   	  BigDecimal totalAmount = new BigDecimal("0.00");
   	  if(deptStateId==bidderStateId){
   		  totalTax = totalTax.add(new BigDecimal(100.00)).add(cgstPer).add(sgstPer);
   	  }else{
   		  totalTax = totalTax.add(new BigDecimal(100.00)).add(igstPer);
   	  }
   	  if(taxType==0 && isFromReceipt==0){
   		  cgstAmount = cgstAmount.add(amount.multiply(cgstPer));
   		  cgstAmount = cgstAmount.divide(new BigDecimal(100.00), 2, RoundingMode.HALF_UP);
   		  sgstAmount = sgstAmount.add(amount.multiply(sgstPer));
   		  sgstAmount = sgstAmount.divide(new BigDecimal(100.00), 2, RoundingMode.HALF_UP);
   		  igstAmount = igstAmount.add(amount.multiply(igstPer));
   		  igstAmount = igstAmount.divide(new BigDecimal(100.00), 2, RoundingMode.HALF_UP);
   		  if(deptStateId==bidderStateId){
   			  totalAmount = totalAmount.add(amount).add(cgstAmount).add(sgstAmount);
	    	  }else{
	    		  totalAmount = totalAmount.add(amount).add(igstAmount);
	    	  }
   		  hashMap.put("totalAmount", totalAmount);
   		  hashMap.put("netAmount", amount);
   		  
   	  }else if(taxType==1 && isFromReceipt==0){
   		  cgstAmount = cgstAmount.add(amount.multiply(cgstPer));
   		  cgstAmount = cgstAmount.divide(totalTax, 2, RoundingMode.HALF_UP);
   		  sgstAmount = sgstAmount.add(amount.multiply(sgstPer));
   		  sgstAmount = sgstAmount.divide(totalTax, 2, RoundingMode.HALF_UP);
   		  igstAmount = igstAmount.add(amount.multiply(igstPer));
   		  igstAmount = igstAmount.divide(totalTax, 2, RoundingMode.HALF_UP);
   		  if(deptStateId==bidderStateId){
   			  netAmount = amount.subtract(cgstAmount).subtract(sgstAmount);
   		  }else{
   			  netAmount = amount.subtract(igstAmount);
   		  }
   		  hashMap.put("totalAmount", amount);
   		  hashMap.put("netAmount", netAmount);
   	  }else if(isFromReceipt==1){
   		cgstAmount = cgstAmount.add(amount.multiply(cgstPer));
 		  cgstAmount = cgstAmount.divide(totalTax, 2, RoundingMode.HALF_UP);
 		  sgstAmount = sgstAmount.add(amount.multiply(sgstPer));
 		  sgstAmount = sgstAmount.divide(totalTax, 2, RoundingMode.HALF_UP);
 		  igstAmount = igstAmount.add(amount.multiply(igstPer));
 		  igstAmount = igstAmount.divide(totalTax, 2, RoundingMode.HALF_UP);
 		 if(deptStateId==bidderStateId){
  			  netAmount = amount.subtract(cgstAmount).subtract(sgstAmount);
  		  }else{
  			  netAmount = amount.subtract(igstAmount);
  		  }
 		  hashMap.put("totalAmount", amount);
 		  hashMap.put("netAmount", netAmount);
   	  }
   	  hashMap.put("taxType", taxType);
   	  hashMap.put("cgstAmount", cgstAmount);
		  hashMap.put("sgstAmount", sgstAmount);
		  hashMap.put("igstAmount", igstAmount);
		  hashMap.put("bidderStateId", bidderStateId);
		  hashMap.put("deptStateId", deptStateId);
		}
     
     
     /**
      * To check whether form is saved in draft mode or not
      * @author garvi
      * @param tenderId
      * @param companyId
      * @return
      * @throws Exception
      */
     
     public boolean isBidSavedInDraft(int tenderId,int companyId) throws Exception{
    	 long count=0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("companyId",companyId);
    	 count = hibernateQueryDao.countForNewQuery("TblTenderBid tbltenderbid inner join tbltenderbid.tblTenderForm tbltenderform","tbltenderform.formId","tbltenderbid.tblTender.tenderId=:tenderId and tbltenderform.isPriceBid = 1 and tbltenderform.cstatus = 1 and tbltenderbid.tblCompany.companyId=:companyId and tbltenderbid.cstatus=1",var);
    	 return count!=0;
     }
     
     /**
     * @param tenderId
     * @param userId
     * @return
     * @throws Exception
     */
    public List<Object[]> getEnvelopeListFromMappedOfficer(int tenderId,int userId) throws Exception{
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("officerId",userId);
         StringBuilder query = new StringBuilder();
         query.append(" select distinct CU.childId,TC.committeeType from apptender.tbl_Committee TC  ");
         query.append(" INNER JOIN apptender.tbl_CommitteeUser CU on TC.committeeType in (1,2) and TC.committeeId=CU.committeeId ");
         query.append(" INNER JOIN apptender.tbl_TenderEnvelope TE on TE.envelopeId=CU.childId and TE.envId in (4,5) and TE.tenderId=TC.tenderId ");
         query.append(" where TC.tenderId=:tenderId and CU.officerId=:officerId " );
         return hibernateQueryDao.createSQLQuery(query.toString(), var);
     }
     
    public List<Object[]> isItemWiseDocAllowedEnvWise(int tenderId,int envelopeId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("envelopeId", envelopeId);
        query.append("select tblTenderForm.isItemWiseDocAllowed From TblTenderForm tblTenderForm inner join tblTenderForm.tblTenderEnvelope tbltenderEnvelope WHERE tblTenderForm.tblTender.tenderId = :tenderId AND tblTenderForm.isItemWiseDocAllowed = 1 AND tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tbltenderEnvelope.tblEnvelope.envId not in (2,4)");
        return hibernateQueryDao.createNewQuery(query.toString(), var);       
    }
    
    public int getConsortiumIdByTenderIdUserId(int tenderId,int userDetailId)
    {
    	 int consortiumId = 0;
         List<Object> list = null;
         StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId", tenderId);
         var.put("userDetailId", userDetailId);
         query.append(" select tblConsortium.consortiumId from TblConsortium tblConsortium  ");
         query.append(" inner join tblConsortium.tblConsortiumDetail tblConsortiumDetail ");
         query.append(" where tblConsortium.tblTender.tenderId=:tenderId and tblConsortiumDetail.tblUserDetail.userDetailId =:userDetailId and tblConsortium.isActive =1  ");

         list = hibernateQueryDao.getSingleColQuery(query.toString(), var);
         
         if(!list.isEmpty()){
        	 consortiumId = Integer.parseInt(list.get(0).toString());
         }
         return consortiumId;
    }
    /**
     * @param tenderId
     * @return
     * @throws Exception
     */
    public int isDocumentDateLive(int tenderId) throws Exception{
        int isLive = 0;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        
        query.append("select case when  getutcdate() >= documentStartDate then ")
                .append("   case when getutcdate() < documentEndDate then 1 else -1 end else 0 end ")
            .append(" from TblTender where tenderId=:tenderId and cstatus=1");
        
        List<Object> lstObject = hibernateQueryDao.getSingleColQuery(query.toString(), var);
        if(!lstObject.isEmpty()){
            isLive = (Integer) lstObject.get(0);
        }
        return isLive;
    }
    public List<Object[]> getTenderAllBidderDetail(int tenderId,int tenderMode) {
		StringBuilder query = new StringBuilder();
	    Map<String, Object> var = new HashMap<String, Object>();
	    var.put("tenderId", tenderId);
	    if(tenderMode == 2 || tenderMode == 3 ){ // Limited and single
	    	query.append(" select distinct tbltenderbidderMap.tblCompany.companyName+' <BR/> ('+ tbltenderbidderMap.tblUserLogin.loginId +')' ,tbltenderbidderMap.tblUserLogin.userId,tbltenderbidderMap.tblCompany.companyId,tbltenderbidderMap.tblUserDetail.userDetailId from TblTenderBidderMap tbltenderbidderMap where tbltenderbidderMap.tblTender.tenderId=:tenderId ");
	    }else if(tenderMode == 1){ // Open
	    	query.append(" select  distinct  tblFinalSubmission.tblCompany.companyName+' <BR/> ('+ tblFinalSubmission.tblUserLogin.loginId +')' , tblFinalSubmission.tblUserLogin.userId,tblFinalSubmission.tblCompany.companyId,tblFinalSubmission.tblUserDetail.userDetailId ");
			query.append(" from TblFinalSubmission tblFinalSubmission where tblFinalSubmission.tblTender.tenderId=:tenderId ");
	    }
	    List<Object[]> res = null;
	    if(query != null && query.length() > 0){
	    	res = hibernateQueryDao.createNewQuery(query.toString(), var);
	    }
	    return res;
	}
    public String tenderInterested(int userId, int eventId, HttpServletRequest request,RedirectAttributes redirectAttributes, ModelMap modelMap) throws Exception {
		boolean isSuccess = false;
		String isExisted = "false";
		String fullName = "";
		String emailId = "";
		String mobileNo = "";
		final String CHECKDIGIT = "^\\d+$";
		if(userId!=0){
			if (!commonService.chkCountForEventEnquiry(eventId, userId, moduleId)) {isExisted = "true";}
		}
		if (isExisted.equals("false")) {
			ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
			TblEventEnquiry tblEventEnquiry = new TblEventEnquiry();
			TblTender tblTender = getTenderById(eventId);
			TblUserLogin officerDetail = departmentUserService.getClientByUserId(tblTender.getOfficerId());
			TblUserLogin bidderDetail = departmentUserService.getClientByUserId(userId);
			List<TblCustomParameter> customParamInterested = commonService.getCustomParameterByField(moduleId,clientBean.getClientId(),tblTender.getTblEventType().getEventTypeId(),"I am interested");
        	List<TblCustomParameter> customParamCC = commonService.getCustomParameterByField(moduleId,clientBean.getClientId(),tblTender.getTblEventType().getEventTypeId(),"Add CC");
        	//save eventEnquiry 
			if (userId == 0) {
				fullName = StringUtils.hasLength(request.getParameter("txtfullNanme")) ? request.getParameter("txtfullNanme") : null;
				emailId = StringUtils.hasLength(request.getParameter("txtEmailId")) ? request.getParameter("txtEmailId") : null;
				mobileNo = StringUtils.hasLength(request.getParameter("txtmobileno")) ? request.getParameter("txtmobileno") : null;
				if(mobileNo.length() != 10) {
					redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),"msg_err_mob_no_length_interested");
					return "redirect:/";
				}else if(!mobileNo.trim().matches(CHECKDIGIT)) {
					redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),"msg_err_mob_no_numeric_interested");
					return "redirect:/";
				}
				tblEventEnquiry.setFullName(fullName);
				tblEventEnquiry.setEmailId(emailId);
				tblEventEnquiry.setMobileNo(mobileNo);
				tblEventEnquiry.setEmailTo(officerDetail.getLoginId());
			} else {
				tblEventEnquiry.setFullName(bidderDetail.getUserName());
				tblEventEnquiry.setEmailId(bidderDetail.getLoginId());
				tblEventEnquiry.setMobileNo(bidderDetail.getMobileNo());
				tblEventEnquiry.setEmailTo(officerDetail.getLoginId());
			}
			tblEventEnquiry.setBidderId(userId);
			tblEventEnquiry.setOfficerId(tblTender.getOfficerId());
			tblEventEnquiry.setEventTypeId(tblTender.getTblEventType().getEventTypeId());
			tblEventEnquiry.setModuleId(moduleId);
			if (customParamInterested.get(0).getFieldValue().equalsIgnoreCase("1")) {
				tblEventEnquiry.setEmailCc(customParamCC.get(0).getFieldValue().toString());
			} else {
				tblEventEnquiry.setEmailCc("");
			}
			tblEventEnquiry.setClientId(clientBean.getClientId());
			tblEventEnquiry.setCreatedOn(commonService.getServerDateTime());
			tblEventEnquiry.setEventId(eventId);
			isSuccess = commonService.saveTblEventEnqiry(tblEventEnquiry);
			Map<String, Object> mailParams = new HashMap<String, Object>();
			MessageConfigDatabean messageConfigDatabean = null;
			if (userId == 0) {
				isSuccess = commonService.saveTblEventEnqiry(tblEventEnquiry);
			} else {
				boolean count = commonService.chkCountForEventEnquiry(eventId, userId, moduleId);
				if (count == false) {
					isSuccess = commonService.saveTblEventEnqiry(tblEventEnquiry);
				} else {
					modelMap.addAttribute("interestAlreadyShown", "Interest already shown");
				}
			}
			//mail content
			if (isSuccess) {
				TblUserLogin tblUserLogins = null;
				int toUserDetailId = commonService.getEventReassByobjectId(eventId);
				if (toUserDetailId != 0) {
					TblUserDetail tblUserDetail = commonService.getTblUserDetailById(toUserDetailId);
					if (tblUserDetail != null) {
						tblUserLogins = departmentUserService.getClientByUserId(tblUserDetail.getTblUserLogin().getUserId());
					}
				}
				redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),"msg_interested");
				String domainName = clientService.getClientNameById(clientBean.getClientId());
				if (userId == 0) {
					mailParams.put("userName", fullName);
					mailParams.put("mobileNumber", mobileNo);
					mailParams.put("emailId", emailId);
					mailParams.put("to", officerDetail.getLoginId());
				} else {
					mailParams.put("userName", bidderDetail.getUserName());
					mailParams.put("mobileNumber", bidderDetail.getMobileNo());
					mailParams.put("emailId", bidderDetail.getLoginId());
					if (tblUserLogins != null) {
						mailParams.put("to", tblUserLogins.getLoginId());
					} else {
						mailParams.put("to", officerDetail.getLoginId());
					}
				}
				mailParams.put("EventType",commonService.getEventNameFromEventId(tblTender.getTblEventType().getEventTypeId()).get(0).toString());
				mailParams.put("Event", "Tender");
				mailParams.put("Brief", tblTender.getTenderBrief());
				mailParams.put("ReferenceNo", tblTender.getTenderNo());
				mailParams.put("eventId", eventId);
				mailParams.put("website", domainName);
				mailParams.put("startDate",  CommonUtility.convertTimezone(tblTender.getSubmissionStartDate()));
				if (customParamInterested.get(0).getFieldValue().equalsIgnoreCase("1")) {
					mailParams.put("cc", customParamCC.get(0).getFieldValue().toString());
				} else {
					mailParams.put("cc", "");
				}
				messageConfigDatabean = new MessageConfigDatabean();
				messageConfigDatabean.setQueueName(queueName);
				messageConfigDatabean.setTemplateId(Integer.parseInt(eventEnquiryMailTemplateId));
				messageConfigDatabean.setUserId(userId);
				messageConfigDatabean.setClientId(clientBean.getClientId());
				messageConfigDatabean.setObjectId(eventId);
				messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
				messageConfigDatabean.setContextPath(request.getContextPath());
				messageConfigDatabean.setParamMap(mailParams);
				mailContentUtillity.dynamicMailGeneration(eventEnquiryMailTemplateId, String.valueOf(userId),String.valueOf(eventId), mailParams, String.valueOf(eventEnqmail));
			}
		}
		return isExisted;
	}
    
    public List<Object[]> getCellDataByTenderId(int tenderId)
    {
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put(TENDER_ID, tenderId);
         StringBuilder query = new StringBuilder();
         query.append("SELECT  TCELL.cellValue,TCELL.cellId FROM  TblTenderCell TCELL"
          		+ " inner join TCELL.tblTenderColumn TC"
          		+ " inner join TC.tblTenderTable TT"
          		+ " inner join TT.tblTenderForm TF"
          		+ " inner join TF.tblTender TM"
          		+ " WHERE TM.tenderId=:tenderId and TC.tblColumnType.columnTypeId=1"
          		+ " AND  TCELL.cellValue <> '' group by TCELL.cellValue,TCELL.cellId"
          		+ " order by TCELL.cellValue ");
         return hibernateQueryDao.createNewQuery(query.toString(), var);   	
    }

	public void updateTblCouponHistory(String coupon, int propertyId) {
		StringBuilder query = new StringBuilder();
		 Map<String, Object> var = new HashMap<String, Object>();
         var.put("propertyId", propertyId);
         var.put("coupon", coupon);
         query.append("UPDATE TblCouponHistory tblCouponHistory set tblCouponHistory.propertyId=:propertyId"
          		+ " where tblCouponHistory.couponcode=:coupon  ");
         hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
	}

	public List<Object[]> getTblCouponHistoryByTenderId(int tenderId) {
		StringBuilder query = new StringBuilder();
		 Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDER_ID, tenderId);
        query.append("SELECT tblCouponHistory.couponcode,tblCouponHistory.propertyId,tblCouponHistory.bidderId FROM TblCouponHistory tblCouponHistory "
         		+ " WHERE tblCouponHistory.tenderId=:tenderId and tblCouponHistory.propertyId!=0 ");
		return hibernateQueryDao.createNewQuery(query.toString(), var);
	}
	public List<Object> getTblFinalSubmission(String tenderId) {
		 StringBuilder builder= new StringBuilder();
		  builder.append(" select tblFinalSubmission.tblUserLogin.userId from TblFinalSubmission tblFinalSubmission");
   	   builder.append(" where tblFinalSubmission.tblTender.tenderId=:tenderId and tblFinalSubmission.isActive=1");
      	   Map<String,Object> var = new HashMap<String, Object>();
          var.put("tenderId",tenderId);
          return hibernateQueryDao.singleColQuery(builder.toString(), var);
	}	
	public int getCountOfProperty(String tenderId) {
		 StringBuilder builder= new StringBuilder();
		  builder.append(" SELECT count(TCELL.cellvalue) FROM  apptender.tbl_tender TM "
		  		+ "inner join apptender.tbl_TenderForm TF ON TF.tenderId = TM.tenderId "
		  		+ "inner join apptender.tbl_TenderTable TT ON TT.formId=TF.formId "
		  		+ "inner join apptender.tbl_TenderColumn TC ON  TC.tableId=TT.tableId "
		  		+ "inner join apptender.tbl_TenderCell TCELL ON TCELL.columnId=TC.columnId and TM.tenderId=:tenderId and TC.columnTypeId=1 group by TM.tenderId,TCELL.rowId");
      	   Map<String,Object> var = new HashMap<String, Object>();
          var.put("tenderId",tenderId);
          List<Object[]> properties = hibernateQueryDao.createSQLQuery(builder.toString(), var);
          return properties.size();
	}
	public int getPriceBidOrTechnoEnvelopeId(int tenderId) throws Exception {
   		int envelopeId = 0;
   		List<Object> list = null;
    	Map<String, Object> var = new HashMap<String, Object>();
    	var.put("tenderId",tenderId);
    	list = hibernateQueryDao.getSingleColQuery("select tblTenderEnvelope.envelopeId from TblTenderEnvelope tblTenderEnvelope WHERE tblTenderEnvelope.tblTender.tenderId=:tenderId and tblTenderEnvelope.tblEnvelope.envId IN(4,5)",var);                   	
    	envelopeId = (list!=null && !list.isEmpty()) ? Integer.parseInt(list.get(0).toString()) : 0;
    	return envelopeId;
   	}
}
