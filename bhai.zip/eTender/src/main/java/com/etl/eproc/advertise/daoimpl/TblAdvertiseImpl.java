/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.advertise.daoimpl;

/**
 *
 * @author hiral
 */
import com.etl.eproc.advertise.model.TblAdvertise;
import com.etl.eproc.advertise.daointerface.TblAdvertiseDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

@Repository @Transactional
public class TblAdvertiseImpl extends AbcAbstractClass<TblAdvertise> implements TblAdvertiseDao {

   

    @Override
    public void addTblAdvertise(TblAdvertise tblAdvertise){
        super.addEntity(tblAdvertise);
    }

    @Override
    public void deleteTblAdvertise(TblAdvertise tblAdvertise) {
        super.deleteEntity(tblAdvertise);
    }

    @Override
    public void updateTblAdvertise(TblAdvertise tblAdvertise) {
        super.updateEntity(tblAdvertise);
    }

    @Override
    public List<TblAdvertise> getAllTblAdvertise() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAdvertise> findTblAdvertise(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAdvertiseCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAdvertise> findByCountTblAdvertise(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAdvertise(List<TblAdvertise> tblAdvertises){
        super.updateAll(tblAdvertises);
    }

	@Override
	public void saveOrUpdateTblAdvertise(TblAdvertise tblAdvertise) {
		super.saveOrUpdateEntity(tblAdvertise);
	}
}

