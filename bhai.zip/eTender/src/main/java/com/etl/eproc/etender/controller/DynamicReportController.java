package com.etl.eproc.etender.controller;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.CellRangeAddress;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblAdvancePurchaseOrder;
import com.etl.eproc.common.model.TblPurchaseOrder;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.etender.model.TblDynReport;
import com.etl.eproc.etender.model.TblDynReportColumn;
import com.etl.eproc.etender.model.TblDynReportFormMap;
import com.etl.eproc.etender.model.TblDynReportFormula;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderColumn;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.DynamicReportService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderFormService;


@Controller
@RequestMapping("/etender")
public class DynamicReportController {
    
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
	@Autowired
	private DynamicReportService dynamicReportService;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private TenderCommonService tenderCommonService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private ClientService clientService;
	
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private TenderFormService tenderFormService;
        @Autowired
	private MessageSource messageSource;
	
	 /*@Value("#{etenderProperties['datatype_smalltext']?:1}")
	 private int smalltext;
	 @Value("#{etenderProperties['datatype_longtext']?:2}")
	 private int longtext;*/
	 @Value("#{etenderProperties['datatype_combo']?:6}")
	 private int combobox;
	 
	 @Value("#{etenderAuditTrailProperties['postReportTable']}")
     private String postReportTable;
	 @Value("#{etenderAuditTrailProperties['getCreateReport']}")
     private String getCreateReport;
	 @Value("#{etenderAuditTrailProperties['getEditReport']}")
     private String getEditReport;
	 @Value("#{etenderAuditTrailProperties['postDynamicReportConfigured']}")
     private String postDynamicReportConfigured;
	 @Value("#{etenderAuditTrailProperties['getCreateReportTable']}")
     private String getCreateReportTable;
	 @Value("#{etenderAuditTrailProperties['getEditReportTable']}")
     private String getEditReportTable;
	 @Value("#{etenderAuditTrailProperties['getSelectBiddingForm']}")
     private String getSelectBiddingForm;
	 @Value("#{etenderAuditTrailProperties['postSelectBiddingForm']}")
     private String postSelectBiddingForm;
	 @Value("#{etenderAuditTrailProperties['getCreateFormula']}")
     private String getCreateFormula;
	 @Value("#{etenderAuditTrailProperties['postCreateFormula']}")
     private String postCreateFormula;
	 @Value("#{etenderAuditTrailProperties['postDeleteFormula']}")
     private String postDeleteFormula;
	 @Value("#{etenderAuditTrailProperties['postDeleteDynamicReport']}")
     private String postDeleteDynamicReport;
	 
	 
     @Value("#{etenderAuditTrailProperties['viewDynamicL1Report']}")
     private String viewDynamicL1Report;
     @Value("#{etenderAuditTrailProperties['viewDynamicH1Report']}")
     private String viewDynamicH1Report;
     @Value("#{etenderAuditTrailProperties['viewDynamicL1ReportExcel']}")
     private String viewDynamicL1ReportExcel;
     @Value("#{etenderAuditTrailProperties['viewDynamicH1ReportExcel']}")
     private String viewDynamicH1ReportExcel;
     @Value("#{tenderlinkProperties['bid_evaluation_dynamic_l1h1_report']?:444}")
     private int dynamicL1H1ReportLinkId;
     @Value("#{tenderlinkProperties['report_create_report']?:433}")
     private int createReportLinkId;
     @Value("#{tenderlinkProperties['report_edit_report']?:434}")
     private int editReportLinkId;
     @Value("#{tenderlinkProperties['report_delete_report']?:435}")
     private int deleteReportLinkId;
     @Value("#{tenderlinkProperties['report_view_report']?:436}")
     private int viewReportLinkId;
     @Value("#{tenderlinkProperties['report_create_table']?:437}")
     private int createTableLinkId;
     @Value("#{tenderlinkProperties['report_edit_table']?:438}")
     private int editTableLinkId;
     @Value("#{tenderlinkProperties['report_map_bidding_form']?:439}")
     private int mapBiddingFormLinkId;
     @Value("#{tenderlinkProperties['report_edit_selected_form']?:440}")
     private int editSelectedBiddingFormLinkId;
     @Value("#{tenderlinkProperties['report_create_formula']?:441}")
     private int createFormulaLinkId;
     @Value("#{tenderlinkProperties['report_edit_formula']?:442}")
     private int editFormulaLinkId;

	
	
	private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
	private static final String TENDER_DASHBOARD_URL = "redirect:/etender/buyer/tenderdashboard/";
	/*private static final String TOTAL = "TOTAL(";*/
    
	/**
	 * to get configure dynamic report page
	 * @param tenderId
	 * @param modelMap
	 * @param request
	 * @return String
	 */
    @RequestMapping(value="/buyer/configurereport/{tenderId}/{reportId}/{oprType}/{enc}",method= RequestMethod.GET)
    public String configureReport(@PathVariable("tenderId") int tenderId ,@PathVariable("reportId") int reportId ,@PathVariable("oprType") int oprType ,ModelMap modelMap,HttpServletRequest request) {
    	int auditTrailLinkId=createReportLinkId;
        try {
	        tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	        if(oprType == 2 && reportId !=0){
	        	modelMap.addAttribute("tblDynReport",dynamicReportService.getDynReportById(reportId));
	        }
	        List<SelectItem> reportType = new ArrayList<SelectItem>();
	        reportType.add(new SelectItem("L1", "1"));
	        reportType.add(new SelectItem("H1", "2"));
	        modelMap.addAttribute("reportType",reportType);
	        List<SelectItem> reportOn = new ArrayList<SelectItem>();
	        reportOn.add(new SelectItem("Grand Total", "1"));
	        reportOn.add(new SelectItem("Item wise", "2"));
	        modelMap.addAttribute("reportOn",reportOn);
        } catch(Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally {
        	String msg="";
        	if(oprType == 2){
        		msg=getCreateReport;
        	}else{
        		msg=getEditReport;
        		auditTrailLinkId=editReportLinkId;
        	}
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auditTrailLinkId, msg, tenderId, 0);
		}
        return "/etender/common/ConfigureReport";
    }
    
    /**
     * to add dynamic report
     * @param request
     * @param redirectAttributes
     * @return String
     */
    @RequestMapping(value="/buyer/submitconfigurereport",method= RequestMethod.POST)
    public String submitConfigureReport(HttpServletRequest request,RedirectAttributes redirectAttributes,ModelMap modelMap) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        boolean isSuccess = false;
        int tenderId = 0;
        int reportId=0;
        int auditTrailLinkId=createReportLinkId;
        try {
            if(abcUtility.getSessionUserId(request)!=0) {
            	StringBuilder redirectUrl = new StringBuilder();
            	tenderId = CommonUtility.checkValue(request.getParameter("hdTenderId"));
            	boolean contractCreated = isContractCreated(tenderId,request,modelMap);
            	if(contractCreated){
	            	int userDetailId=abcUtility.getSessionUserDetailId(request);
	            	 reportId=CommonUtility.checkValue(request.getParameter("hdReportId"));
			         int reportOn = CommonUtility.checkValue(request.getParameter("rdReportOn"));
			         int reportFor = CommonUtility.checkValue(request.getParameter("rdReportType"));
			         int noOfColumns = CommonUtility.checkValue(request.getParameter("txtNoOfColumns"));
			         String reportName=CommonUtility.checkNull(request.getParameter("txtReportName"));
			         String reportHeader=CommonUtility.checkNull(request.getParameter("txtaReportHeader"));
			         String reportFooter=CommonUtility.checkNull(request.getParameter("txtaReportFooter"));
			         int editReportOn=CommonUtility.checkValue(request.getParameter("txtEditReportOn"));
			         TblDynReport tblDynReport=new TblDynReport();
			         if(reportId !=0){
			        	 tblDynReport.setReportId(reportId);
			        	 auditTrailLinkId=editReportLinkId;
			         }
			         tblDynReport.setTblTender(new TblTender(tenderId));
			         tblDynReport.setReportOn(reportOn);
			         tblDynReport.setReportFor(reportFor);
			         tblDynReport.setNoOfCols(noOfColumns);
			         tblDynReport.setReportName(reportName);
			         tblDynReport.setReportHeader(reportHeader);
			         tblDynReport.setReportFooter(reportFooter);
			         tblDynReport.setCreatedBy(userDetailId);
			         tblDynReport.setUpdatedBy(userDetailId);
			         tblDynReport.setIsDetailedBreakUp(0);
			         tblDynReport.setUpdatedOn(new Date());
			         tblDynReport.setReportType(1);
			         isSuccess = dynamicReportService.addDynamicReport(tblDynReport,reportId !=0 ? editReportOn==reportOn : true);
			         if(isSuccess) {
			        	 if(reportId == 0){
			        		 redirectUrl.append("redirect:/etender/buyer/reportformmatrix/").append(tenderId).append("/").append(tblDynReport.getReportId()).append("/").append(reportFor).append("/").append(reportOn).append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
			        	 }else{
			        		 redirectUrl.append(TENDER_DASHBOARD_URL).append(tenderId).append("/9").append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
			        	 }
			         }
	            }else{
	            	redirectUrl.append(TENDER_DASHBOARD_URL).append(tenderId).append("/9").append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
	            }
            	retVal = redirectUrl.toString();
            }
        }catch (Exception e) {
            retVal = exceptionHandlerService.writeLog(e);
        }finally {
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auditTrailLinkId, postDynamicReportConfigured, tenderId, 0);
		}
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_report_config_succ" : modelMap.get("msg").toString());
        return retVal;
    }
    
    @RequestMapping(value="/buyer/reportformmatrix/{tenderId}/{reportId}/{reportFor}/{reportOn}/{enc}",method= RequestMethod.GET)
    public String reportFormMatrix(@PathVariable("tenderId") int tenderId,@PathVariable("reportFor") int reportFor,@PathVariable("reportOn") int reportOn,@PathVariable("reportId") int reportId,ModelMap modelMap,HttpServletRequest request) {
    	int auditTrailLinkId=createTableLinkId;
        try {
	        tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	        List<SelectItem> columnType = new ArrayList<SelectItem>();
	        columnType.add(new SelectItem("Company", "1"));
	        columnType.add(new SelectItem("Auto", "2"));
	        columnType.add(new SelectItem("Auto Rank", "3"));
	        columnType.add(new SelectItem("SOR", "4"));
	        if(reportOn==1) {
	            columnType.add(new SelectItem("Rebate", "5"));
	        }else{
	        	columnType.add(new SelectItem("Item Description", "6"));
	        }
	        modelMap.addAttribute("operType",1);
	        modelMap.addAttribute("columnType",columnType);
	        modelMap.addAttribute("noOfColumns",dynamicReportService.getDynReportById(reportId).getNoOfCols());
        } catch (Exception e) {
        	exceptionHandlerService.writeLog(e);
        }finally {
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auditTrailLinkId, getCreateReportTable, tenderId, 0);
		}
        return "/etender/common/CreateReportFormMatrix";
    }
    
    @RequestMapping(value="/buyer/editreportformmatrix/{tenderId}/{reportId}/{reportFor}/{reportOn}/{enc}",method= RequestMethod.GET)
    public String editReportFormMatrix(@PathVariable("tenderId") int tenderId,@PathVariable("reportFor") int reportFor,@PathVariable("reportOn") int reportOn,@PathVariable("reportId") int reportId,ModelMap modelMap,HttpServletRequest request) {
        try {
            
        tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        List<SelectItem> columnType = new ArrayList<SelectItem>();
        columnType.add(new SelectItem("Company", "1"));
        columnType.add(new SelectItem("Auto", "2"));
        columnType.add(new SelectItem("Auto Rank", "3"));
        columnType.add(new SelectItem("SOR", "4"));
        if(reportOn==1) {
            columnType.add(new SelectItem("Rebate", "5"));
        }else{
	    columnType.add(new SelectItem("Item Description", "6"));
        }
        modelMap.addAttribute("columnType",columnType);
        modelMap.addAttribute("reportColumnList", dynamicReportService.getDynReportColumnByReportId(reportId));
        modelMap.addAttribute("operType",2);
        modelMap.addAttribute("noOfColumns",dynamicReportService.getDynReportById(reportId).getNoOfCols());
        modelMap.addAttribute("reportName",dynamicReportService.getDynReportById(reportId).getReportName());
        } catch (Exception e) {
        	exceptionHandlerService.writeLog(e);
        }finally {
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editTableLinkId, getEditReportTable, tenderId, 0);
		}
        return "/etender/common/CreateReportFormMatrix";
    }
    
    @RequestMapping(value="/buyer/submitreportformmatrix",method= RequestMethod.POST)
    public String submitReportFormMatrix(HttpServletRequest request,RedirectAttributes redirectAttributes,ModelMap modelMap) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        boolean isSuccess = false;
        int tenderId = 0;
        int reportFor = 0;
        int reportOn = 0;
        int noOfColumns = 0;
        int reportId = 0;
        int oprType=0;
        int auditTrailLinkId=createTableLinkId;
        try {
        	StringBuilder redirectUrl = new StringBuilder();
            if(abcUtility.getSessionUserId(request)!=0) {
            	tenderId = CommonUtility.checkValue(request.getParameter("hdTenderId"));
            	boolean contractCreated = isContractCreated(tenderId,request,modelMap);
            	if(contractCreated){
		         reportOn = CommonUtility.checkValue(request.getParameter("hdReportOn"));
		         reportFor = CommonUtility.checkValue(request.getParameter("hdReportFor"));
		         noOfColumns = CommonUtility.checkValue(request.getParameter("txtRowCnt"));
		         reportId = CommonUtility.checkValue(request.getParameter("hdReportId"));
		         oprType = CommonUtility.checkValue(request.getParameter("hdOprType"));
		         List<TblDynReportColumn> list = new ArrayList<TblDynReportColumn>();
		         for (int i = 0; i < noOfColumns; i++) {
		            TblDynReportColumn tblDynReportColumn = new TblDynReportColumn();
		            tblDynReportColumn.setTblDynReport(new TblDynReport(reportId));
		            tblDynReportColumn.setColumnNo(i);
		            tblDynReportColumn.setColumnName(request.getParameter("txtColumnHeader_"+i));
		            tblDynReportColumn.setFilledBy(Integer.parseInt(request.getParameter("selColumnType_"+i)));
			    if(StringUtils.hasLength(request.getParameter("txtGoverning")) && Integer.parseInt(request.getParameter("txtGoverning").replace("_", "")) == i) {
				tblDynReportColumn.setIsGovColumn(1); 
			    } else {
				tblDynReportColumn.setIsGovColumn(0); 
			    }
		            list.add(tblDynReportColumn);
		         }
		         if(oprType ==1){
		        	 isSuccess=dynamicReportService.addTblDynReportColumn(list);
		         }else if(oprType ==2){
		        	 auditTrailLinkId=editTableLinkId;
		        	 isSuccess=dynamicReportService.deleteAddDynamicReportColumn(reportId, list);
		         }
		         if(isSuccess) {
		            if(oprType == 1){
		            	redirectUrl.append("redirect:/etender/buyer/selectbidform/").append(tenderId).append("/").append(reportId).append("/").append(reportOn).append("/").append("1").append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
		            }else{
		            	redirectUrl.append(TENDER_DASHBOARD_URL).append(tenderId).append("/9").append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
		            }
		         }
            	}else{
		            	redirectUrl.append(TENDER_DASHBOARD_URL).append(tenderId).append("/9").append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
		        }
		        retVal = redirectUrl.toString();
            }
        } catch (Exception e) {
            retVal = exceptionHandlerService.writeLog(e);
        }finally {
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auditTrailLinkId, postReportTable, tenderId, 0);
		}
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_report_config_succ" : modelMap.get("msg").toString());
        return retVal;
    }
    
	/**
	 * to get select pricer bid form page
	 * @param linkId
	 * @param tenderId
	 * @param request
	 * @param modelMap
	 * @return String
	 */
	@RequestMapping(value = "/buyer/selectbidform/{tenderId}/{reportId}/{reportOn}/{oprType}/{enc}", method = RequestMethod.GET)
    public String selectBidForm(@PathVariable("oprType") int oprType,@PathVariable("reportId") int reportId,@PathVariable("reportOn") int reportOn,@PathVariable("tenderId") int tenderId, HttpServletRequest request, ModelMap modelMap) {
		int auditTrailLinkId=mapBiddingFormLinkId;
		String auditTrailMessage=getSelectBiddingForm;
		try{
			List<TblDynReportFormMap> tblDynReportFormList= new ArrayList<TblDynReportFormMap>();
			if(oprType == 2){
				auditTrailLinkId=editSelectedBiddingFormLinkId;
				tblDynReportFormList=dynamicReportService.getDynReporFormMaptById(reportId);
				modelMap.addAttribute("tblDynReportFormMap", tblDynReportFormList);
			}
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
			if(reportOn == 1){
				List<TblDynReportColumn> dynReportColumnsLst = dynamicReportService.getDynReportColumnByReportId(reportId);
				int rebetCol = 0;
				for(TblDynReportColumn dynRptCol : dynReportColumnsLst){
				    if(dynRptCol.getFilledBy() == 5){
				       rebetCol = 1;
				    }
				}
				modelMap.addAttribute("formList", dynamicReportService.getFormList(tenderId, rebetCol, reportOn));
			}else{
				List<Object[]> tenderFormList=dynamicReportService.getFormList(tenderId,0,reportOn);
				List<SelectItem> items = new ArrayList<SelectItem>();
				List<Map<String,Object>> linkList = new ArrayList<Map<String,Object>>();
				Map<String,Object> tempLinkMap=new HashMap<String, Object>();
				boolean isSameTableId=false;
				int tempFormId=0;
				int cnt=0;
				Map<String,Object> tempMap=new HashMap<String, Object>();
				List<Map<String,Object>>formList=new ArrayList<Map<String,Object>>();
				for(Object[] data : tenderFormList){
					if(tempFormId != (Integer)data[0]){
						tempFormId = (Integer)data[0];
						if(cnt != 0){
							tempMap.put("tableList", items);
							tempMap.put("linkList", linkList);
							formList.add(tempMap);
							tempMap=new HashMap<String, Object>();
							items = new ArrayList<SelectItem>();
							linkList = new ArrayList<Map<String,Object>>();
						}
						tempMap.put("formId", (Integer)data[0]);
						tempMap.put("formName", data[1]);
					}
					if(oprType == 2){
						for(TblDynReportFormMap tDynReportFormMap : tblDynReportFormList){
							if((Integer)data[2] == tDynReportFormMap.getTableId()){
								isSameTableId=true;
							}
						}
						if(!isSameTableId){
							items.add(new SelectItem(data[3], data[2]));
						}else{
							tempLinkMap.put("tableId", data[2]);
							tempLinkMap.put("tableName", data[3]);
							linkList.add(tempLinkMap);
							tempLinkMap=new HashMap<String, Object>();
							isSameTableId=false;
						}
					}else{
						items.add(new SelectItem(data[3], data[2]));
					}
					if(cnt == tenderFormList.size()-1){
						tempMap.put("tableList", items);
						tempMap.put("linkList", linkList);
						formList.add(tempMap);
					}
					cnt++;
				}
				modelMap.addAttribute("formList", formList);
			}
		}catch (Exception e) {
		    return exceptionHandlerService.writeLog(e);
		}finally {
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auditTrailLinkId, auditTrailMessage, tenderId, 0);
		}
		return "etender/common/SelectBidForm";
    }
	
	/**
	 * to map form with the report
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/buyer/submitreportform",method= RequestMethod.POST)
    public String submitReportForm(HttpServletRequest request,RedirectAttributes redirectAttributes,ModelMap modelMap) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        boolean isSuccess = false;
        int tenderId = 0;
        int reportOn = 0;
        int formId=0;
        int reportId=0;
        int tableId=0;
        String formIds="";
        int auditTrailLinkId=mapBiddingFormLinkId;
        try {
            if(abcUtility.getSessionUserId(request)!=0) {
            	tenderId = CommonUtility.checkValue(request.getParameter("hdTenderId"));
            	boolean contractCreated = isContractCreated(tenderId,request,modelMap);
            	StringBuilder redirectUrl = new StringBuilder();
            	if(contractCreated){
            	List<TblDynReportFormMap> tblDynReportFormMapList=new ArrayList<TblDynReportFormMap>();
		         reportOn = CommonUtility.checkValue(request.getParameter("hdReportOn"));
		         int oprType=CommonUtility.checkValue(request.getParameter("hdOprType"));
		         auditTrailLinkId=oprType==2 ? editSelectedBiddingFormLinkId : mapBiddingFormLinkId;
		         reportId=CommonUtility.checkValue(request.getParameter("hdReportId"));
		         TblDynReportFormMap tblDynReportFormMap=null;
		         if(reportOn == 2){
		        	 //formId=CommonUtility.checkValue(request.getParameter("hdFormId"));
		        	 tableId=CommonUtility.checkValue(request.getParameter("rdTableId"));
		        	 List<Object[]> data=dynamicReportService.getFormIdByTableId(tableId);
		        	 formId=!data.isEmpty() ? (Integer)data.get(0)[1]:0;
		        	 //int dynFormMapId=CommonUtility.checkValue(request.getParameter("hdDynFormMapId"));
		        	 tblDynReportFormMap=new TblDynReportFormMap();
		        	 /*if(dynFormMapId != 0 && oprType ==2){
		        		 tblDynReportFormMap.setReportFormMappingId(dynFormMapId);
		        	 }*/
		        	 tblDynReportFormMap.setTblDynReport(new TblDynReport(reportId));
		        	 tblDynReportFormMap.setTblTenderForm(new TblTenderForm(formId));
		        	 tblDynReportFormMap.setTableId(tableId);
		        	 tblDynReportFormMapList.add(tblDynReportFormMap);
		         }else{
		        	 String[] formIdArr=request.getParameterValues("chkFormId");
		        	 //String[] dynFormMapId=request.getParameterValues("hdDynFormMapId");
		        	 if(formIdArr != null && formIdArr.length > 0){
		        		 for(int i=0;i< formIdArr.length;i++){
		        			 tblDynReportFormMap=new TblDynReportFormMap();
		        			 /*if(dynFormMapId != null && oprType ==2 && i < dynFormMapId.length){
				        		 tblDynReportFormMap.setReportFormMappingId(Integer.parseInt(dynFormMapId[i]));
				        	 }*/
		        			 tblDynReportFormMap.setTblDynReport(new TblDynReport(reportId));
				        	 tblDynReportFormMap.setTblTenderForm(new TblTenderForm(Integer.parseInt(formIdArr[i])));
				        	 tblDynReportFormMapList.add(tblDynReportFormMap);
				        	 tblDynReportFormMap.setTableId(tableId);
				        	 formIds=formIds+formIdArr[i]+",";
		        		 }
		        	 }
		         }
		        isSuccess = dynamicReportService.addDynReportFormMap(tblDynReportFormMapList,oprType,reportId,reportOn);
	            if(isSuccess) {
	            	
	            	//if(oprType == 1 || reportOn == 1){
	            		redirectUrl.append("redirect:/etender/buyer/createreportformula/").append(tenderId).append("/").append(reportOn == 2 ? String.valueOf(formId) : formIds.substring(0, formIds.length()-1)).append("/").append(tableId).append("/").append(reportId).append("/").append(1).append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
	            	/*}else{
	            		redirectUrl.append(TENDER_DASHBOARD_URL).append(tenderId).append("/9").append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
	            	}*/
	            }
            }else{
            	redirectUrl.append(TENDER_DASHBOARD_URL).append(tenderId).append("/9").append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
            }
            	retVal = redirectUrl.toString();
            }
        } catch (Exception e) {
            retVal = exceptionHandlerService.writeLog(e);
        }finally {
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auditTrailLinkId, postSelectBiddingForm, tenderId, 0);
		}
        return retVal;
    }
	
	/**
	 * to get create report formula page
	 * @param tenderId
	 * @param formId
	 * @param tableId
	 * @param reportId
	 * @param fromDash
	 * @param modelMap
	 * @param request
	 * @return String
	 */
	@RequestMapping(value = "/buyer/createreportformula/{tenderId}/{formId}/{tableId}/{reportId}/{fromDash}/{enc}", method = RequestMethod.GET)
    public String createFormula(@PathVariable("tenderId") Integer tenderId, @PathVariable("formId") String formId, @PathVariable("tableId") Integer tableId, @PathVariable("reportId") Integer reportId, @PathVariable("fromDash") Integer fromDash, ModelMap modelMap, HttpServletRequest request) {
        try {
            List<Object[]> list = dynamicReportService.getTenderTableDetails(formId.split(","));
            /*if (list != null && !list.isEmpty() && tableId != 0) {
                modelMap.addAttribute("rowcount", list.get(0)[6]);
                modelMap.addAttribute("colcount", list.get(0)[7]);
                modelMap.addAttribute("tableName", list.get(0)[2]);
                modelMap.addAttribute("hasGTRow", list.get(0)[9]);
            }*/
            //int rebateAvail = tenderFormService.checkTenderHasRebate(tenderId);
            int tenderResult = (Integer) tenderCommonService.getTenderField(tenderId, "tenderResult");
            //Filled By - Tenderer:1, Bidder:2, Auto:3, Proxy Bid Column:4
            //Data Type - SmallText:1, LongText:2, +No. with (.):3, +No. without (.):4, All Numbers:8   
            List<TblTenderColumn> columns = dynamicReportService.getTenderColumn(formId.split(","),tableId);
            List<TblTenderCell> tableCells = dynamicReportService.getTableJson(formId.split(","),tableId);
            List<Object[]> govColList=null;
            String tempColumnId="";
            /*for (int i = 0; i < columns.size(); i++) {
            	tempColumnId= tempColumnId + String.valueOf(columns.get(i).getColumnId()) + ",";
            }*/
            if(tableId == 0){
            	govColList=dynamicReportService.getTenderGovColumn(formId.split(","));
            	modelMap.addAttribute("govColList", govColList);
            }
            List<SelectItem> autoCols = new ArrayList<SelectItem>();
            List<TblTenderColumn> columnsList = new ArrayList<TblTenderColumn>();
            List<TblTenderCell> cellList = new ArrayList<TblTenderCell>();
            //List<List<TblTenderColumn>> tempColumnsList = new ArrayList<List<TblTenderColumn>>();
            List<Map<String,Object>> tempColumnsList = new ArrayList<Map<String,Object>>();
            //List<Map<String,Object>> tempCellList = new ArrayList<Map<String,Object>>();
            TblTenderColumn tempTblTenderColumn=null;
            TblTenderCell tempTenderCell=null;
            //int tempRowId=1;
            int tempTableId = 0;
            Map<String,Object> tempMap=new HashMap<String,Object>();
            int cnt=0;
            int cntTable=0;
            //Map<String,Object> tempTenderCellMap=new HashMap<String,Object>();
            for (int i = 0; i < columns.size(); i++) {
                tempTblTenderColumn= columns.get(i);
                if(tempTableId != tempTblTenderColumn.getTblTenderTable().getTableId()){
				    /*if(tableId == 0 && govColList != null && i !=0 && cnt < govColList.size()){
				    	//for(int k=0;k < govColList.size();k++){
				    		if(govColList.get(cnt).getTblTenderTable().getTableId() == tempTblTenderColumn.getTblTenderTable().getTableId()){
				    			System.out.println("gov id in last ::: "+govColList.get(cnt).getTblTenderTable().getTableId());
					    		tempMap.put("govColList", govColList.get(cnt));
					    		cnt=cnt+1;
				    		}else{
				    			tempMap.put("govColList", new TblTenderGovColumn());
				    		}
				    	//}
				    }*/
				    if(tableId == 0 && list != null && cntTable < list.size() && i !=0){
					    tempMap.put("tableName", list.get(cntTable)[2]);
					    cntTable++;
				    }
                    if(i!=0){
                    	tempMap.put("cellList", cellList);
                    	tempMap.put("columnsList", columnsList);
                        tempColumnsList.add(tempMap);
                        tempMap=new HashMap<String,Object>();
                        //tempRowId=1;
                    }
                    columnsList = new ArrayList<TblTenderColumn>();
                    cellList = new ArrayList<TblTenderCell>();
                    //tempCellList = new ArrayList<Map<String,Object>>();
                }
                tempTableId=tempTblTenderColumn.getTblTenderTable().getTableId();
                columnsList.add(tempTblTenderColumn);
                for (int j = 0; j < tableCells.size(); j++) {
                	tempTenderCell=tableCells.get(j);
                	if(tempTableId==tempTenderCell.getTblTenderTable().getTableId()){
                		cellList.add(tempTenderCell);
                	}
                }
                /*if(i==columns.size()-1 && !cellList.isEmpty()){
                	tempTenderCellMap=new HashMap<String, Object>();
    				tempTenderCellMap.put("cellDataList", cellList);
    				tempCellList.add(tempTenderCellMap);
	        	}*/
                if(i==columns.size()-1){
                	/*if(tableId == 0 && govColList != null){
        		    	for(int k=0;k < govColList.size();k++){
        		    		if(govColList.get(k).getTblTenderTable().getTableId() == tempTblTenderColumn.getTblTenderTable().getTableId()){
        		    			System.out.println("gov id in last ::: "+govColList.get(k).getTblTenderTable().getTableId());
        			    		tempMap.put("govColList", govColList.get(k));
        			    		break;
        		    		}
        		    	}
        		    }*/
                	if(tableId == 0 && list != null && cntTable < list.size() && i !=0){
        			    tempMap.put("tableName", list.get(cntTable)[2]);
        			    cntTable++;
        		    }
                	tempMap.put("cellList", cellList);
                	tempMap.put("columnsList", columnsList);
                	/*if(tableId == 0 && govColList != null && cnt < govColList.size()){
                		tempMap.put("govColList", govColList.get(cnt++));
                	}*/
                    tempColumnsList.add(tempMap);
                }
            }
            modelMap.addAttribute("colList", tempColumnsList);
            //modelMap.addAttribute("tempRowCount", tempRowId);
//            List<SelectItem> govCols = new ArrayList<SelectItem>();//remgovcol
            //List<TblTenderFormula> formulas = tenderFormService.getTenderFormulaByTableId(tableId);
            List<TblDynReportFormula> formulas = dynamicReportService.getDynReportFormula(reportId,tableId);
//            modelMap.put("rebateAvail", rebateAvail);
//            if (rebateAvail != -1) {
//                Set<Integer> gtColumnId = new HashSet<Integer>();
//                for (TblDynReportFormula formula : formulas) {
//                    if (formula.getFormula().startsWith(TOTAL)) {
//                        gtColumnId.add(formula.getTblTenderColumn().getColumnId());
//                    }
//                }
//                List<Object[]> gtCol = tenderFormService.getTenderCellRebateGT(gtColumnId);
//                Map<Integer, Integer> gtCols = new HashMap<Integer, Integer>();
//                for (Object[] col : gtCol) {
//                    gtCols.put((Integer) col[0], (Integer) col[1]);
//                }
//                modelMap.put("gtCols", gtCols);
//            }
//            List<Object[]> govColumn = tenderFormService.getGovColumn(tableId);//remgovcol
//            String govColName = null;//remgovcol
//            long govColId = 0;//remgovcol
            int noautoCnt = 0;            
           /* for (TblTenderColumn tblTenderColumn : columns) {
                if (tblTenderColumn.getFilledBy() == 3) {
                    boolean addit = true;
                    for (TblTenderFormula formula : formulas) {
                        if (formula.getTblTenderColumn().getColumnId() == tblTenderColumn.getColumnId() && !formula.getDisplayFormula().startsWith(TOTAL)) {
                            addit = false;
                        }
                    }
                    if (addit) {
                        boolean isText = (tblTenderColumn.getDataType() == smalltext || tblTenderColumn.getDataType() == longtext);
                        autoCols.add(new SelectItem(tblTenderColumn.getColumnHeader(), tblTenderColumn.getColumnId() + "_" + tblTenderColumn.getColumnNo() + "_" + isText));
                    }
                } else {
                    noautoCnt++;
                }                
                if (govColumn.isEmpty()) {//remgovcol
                    if ((tblTenderColumn.getFilledBy() == 3 || tblTenderColumn.getFilledBy() == 2) && (tblTenderColumn.getDataType() == numeric || tblTenderColumn.getDataType() == money || tblTenderColumn.getDataType() == moneyall)) {
                        govCols.add(new SelectItem(tblTenderColumn.getColumnHeader(), tblTenderColumn.getColumnId() + "_" + tblTenderColumn.getColumnNo()));
                    }
                } else {
                    if ((Integer) govColumn.get(0)[0] == tblTenderColumn.getColumnId()) {
                        govColName = tblTenderColumn.getColumnHeader();
                        govColId = tblTenderColumn.getColumnId();
                    }
                }
            } */
//            modelMap.addAttribute("seletedGovCol", govColName);//remgovcol
//            modelMap.addAttribute("seletedGovColId", govColId);//remgovcol
            modelMap.addAttribute("autoCols", autoCols);
            modelMap.addAttribute("noautocol", noautoCnt == columns.size());
//            modelMap.addAttribute("govCols", govCols);//remgovcol
            
            modelMap.addAttribute("columns", columns);
            if (!columns.isEmpty()) {
                List<Integer> comboId = new ArrayList<Integer>();
                List<TblTenderCell> cells = tenderFormService.getTenderCellByTableIdOneRow(tableId);            
                for (TblTenderCell tenderCell : cells) {
                    if(tenderCell.getDataType()==combobox){
                        comboId.add(tenderCell.getObjectId());
                    }
                }
                if(!comboId.isEmpty()){
                    List<Object> combos = tenderFormService.getCalculationCombo(comboId);
                    if(!combos.isEmpty()){
                        modelMap.addAttribute("combos",tenderFormService.getComboDetailByComboId(combos.toArray()));                        
                        modelMap.addAttribute("calcombo",combos);
                    }
                }
                /*modelMap.addAttribute("cells", cells);*/
            }
            modelMap.put("tenderResult", tenderResult);
            modelMap.put("formulas", formulas);
            boolean conditionBtn = false;
            boolean autoColFinish = false;
            if (noautoCnt != columns.size()) {
                if (autoCols.isEmpty()) {
                    autoColFinish = true;
                }
            } else {
                autoColFinish = true;
            }

            conditionBtn = autoColFinish; /*&& govColName != null;//remgovcol*/
            modelMap.put("conditionBtn", conditionBtn);
            if (conditionBtn) {
                boolean tenderMode = (Integer) tenderCommonService.getTenderField(tenderId, "tenderMode") == 2;
                modelMap.put("limited", tenderMode);
            }
            List<Integer> colIds = new ArrayList<Integer>();
            for(TblDynReportFormula tblDynReportFormula : formulas){
            	colIds.add(tblDynReportFormula.getTblDynReportColumn().getColumnId());
            }
            modelMap.addAttribute("selAutoColumns", abcUtility.convert(dynamicReportService.getAutoColumnsForFormula(reportId, 2,colIds,formId.split(","),tableId)));
            modelMap.addAttribute("dynamicReportForm", dynamicReportService.getDynReportColumnByReportId(reportId));
            modelMap.addAttribute("moduleId",commonService.getModuleIdbyLinkId(createFormulaLinkId));
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createFormulaLinkId, getCreateFormula, tenderId, tableId);
        }
        return "/etender/common/CreateReportFormula";
    }
        /**
         * to add report formula
         * @param request
         * @param redirectAttributes
         * @return String
         */
        @RequestMapping(value="/buyer/addreportformula",method= RequestMethod.POST)
        public String addReportFormula(HttpServletRequest request,RedirectAttributes redirectAttributes) {
        	boolean isSuccess=false;
        	String retVal = REDIRECT_SESSION_EXPIRED;
        	int tenderId=0;
        	String formId="";
        	int reportId = 0;
            try {
                //String[] colNoNId = request.getParameter("selAutoCol") != null ? request.getParameter("selAutoCol").split("_") : null;
               reportId = CommonUtility.checkValue(request.getParameter("hdReportId"));
               tenderId = CommonUtility.checkValue(request.getParameter("hdTenderId"));
               formId = CommonUtility.checkNull(request.getParameter("hdFormId"));
               int tableId = CommonUtility.checkValue(request.getParameter("hdTableId"));
                //List<TblDynReportFormula> tenderFormulas = new ArrayList<TblDynReportFormula>();
                TblDynReportFormula tenderFormula = null;
                if(abcUtility.getSessionUserId(request)!=0) {
                    tenderFormula = new TblDynReportFormula();
                    tenderFormula.setTblDynReport(new TblDynReport(reportId));
                    tenderFormula.setTblDynReportColumn(new TblDynReportColumn(Integer.parseInt(request.getParameter("selAutoCol").split("_")[0])));
                    StringBuilder strFormula= new StringBuilder();
                    strFormula.append(request.getParameter("frmFormFormula2").startsWith("txtcell_0")?request.getParameter("frmFormFormula2").replace("txtcell_0", "dcolNo") :request.getParameter("frmFormFormula2"));
                    if(tableId != 0){
                    	tenderFormula.setFormula(strFormula.toString().replace("txtcell_", "colId_"));
                    } else {                    	
                    	tenderFormula.setFormula(strFormula.toString());
                    }
                    tenderFormula.setDisplayFormula(request.getParameter("frmaFormFormula"));
                    tenderFormula.setColFormula(request.getParameter("frmFormFormula2").replace("txtcell_", ""));
                    tenderFormula.setTableId(tableId);
                    isSuccess=dynamicReportService.addTblDynReportFormula(tenderFormula);
                    if(isSuccess) {
    	            	StringBuilder redirectUrl = new StringBuilder();
    	                redirectUrl.append("redirect:/etender/buyer/createreportformula/").append(tenderId).append("/").append(formId).append("/").append(tableId).append("/").append(reportId).append("/").append(1).append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
    	                retVal = redirectUrl.toString();
    	            }
                    
                }
            } catch (Exception e) {
            	return exceptionHandlerService.writeLog(e);
            }
            finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createFormulaLinkId, postCreateFormula, tenderId, reportId);
            }
            return retVal;
        }
        
    /**
     * Delete Form Formula GET
     *
     * @param tenderId
     * @param formulaId
     * @param fromDash
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/buyer/deletereportformula/{tenderId}/{formId}/{tableId}/{formulaId}/{reportId}/{fromDash}/{enc}", method = RequestMethod.GET)
    public String deleteReportFormula(@PathVariable("tenderId") Integer tenderId, @PathVariable("formulaId") Integer formulaId, @PathVariable("tableId") Integer tableId,  @PathVariable("formId") String formId, @PathVariable("reportId") Integer reportId,@PathVariable("fromDash") Integer fromDash,HttpServletRequest request, RedirectAttributes redirectAttributes) {
        try {
            boolean success = dynamicReportService.deleteTblDynReportFormulaById(formulaId);
            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_formuladeleted" : CommonKeywords.ERROR_MSG_KEY.toString());
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editFormulaLinkId, postDeleteFormula, tenderId, reportId);
        }
        return "redirect:/etender/buyer/createreportformula/" + tenderId + "/" + formId + "/" + tableId + "/" + reportId +"/"+fromDash+ encryptDecryptUtils.generateRedirect("etender/buyer/createreportformula/" + tenderId + "/" + formId + "/" + tableId + "/" + reportId+"/"+fromDash, request);
    }

    
     @RequestMapping(value="/buyer/generatedynamicreport/{tenderId}/{reportId}/{reportFor}/{tabId}/{enc}",method= RequestMethod.GET)
    public String generateDynamicReport(@PathVariable("tenderId") int tenderId,@PathVariable("reportId") int reportId,@PathVariable("reportFor") int reportFor,@PathVariable("tabId") int tabId,ModelMap modelMap,HttpServletRequest request) {
    	 boolean forArchivalProcess = modelMap.get("forArchivalProcess") != null ? (Boolean) modelMap.get("forArchivalProcess") : false;
    	 try {
        	 /*Changes for PT #50381*/
            /* TblDynReport tblDynReport = dynamicReportService.getDynReportById(reportId);
         	if(tblDynReport!=null){
         		if(tblDynReport.getReportOn()==1 || tblDynReport.getReportOn()==2 || tblDynReport.getReportOn() ==6){
         		     dynamicReportService.deleteTblDynReportCellId(reportId); 
         		}
         	}*/
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            Map<String,Object> dynamicReport = dynamicReportService.getDynamicL1H1Report(reportId,tenderId,abcUtility.getSessionUserId(request));
            if(dynamicReport != null && !dynamicReport.isEmpty()) {
                modelMap.addAttribute("reportColumnList", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-3"));
                modelMap.addAttribute("reportColumnHeaderList", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-2"));
                modelMap.addAttribute("reportFormHeader", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-1") );
                modelMap.addAttribute("reportHeader", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-4") );
            }
          } catch (Exception e) {
        	  if(forArchivalProcess) {
              		modelMap.addAttribute("Exception", e);
              }
        	  return exceptionHandlerService.writeLog(e);
        } finally {
        	if(!forArchivalProcess) {
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), dynamicL1H1ReportLinkId, reportFor == 1 ? viewDynamicL1Report : viewDynamicH1Report, tenderId, reportId);
        	}
        }
       return "/etender/common/DynamicL1H1Report";
    }

    
    /**
     * to delete dynamic report
     * @param tenderId
     * @param reportId
     * @param request
     * @param redirectAttributes
     * @return String
     */
    @RequestMapping(value = "/buyer/deletereport/{tenderId}/{reportId}/{enc}", method = RequestMethod.GET)
    public String deleteReport(@PathVariable("tenderId") Integer tenderId,@PathVariable("reportId") Integer reportId,HttpServletRequest request, RedirectAttributes redirectAttributes,ModelMap modelMap) {
    	StringBuilder redirectUrl = new StringBuilder();
        try {
        	boolean contractCreated = isContractCreated(tenderId,request,modelMap);
            boolean success = contractCreated ? dynamicReportService.deleteDynReport(reportId) : false;
            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString() , success ? "redirect_success_reporteleted" : modelMap.get("msg").toString());
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deleteReportLinkId, postDeleteDynamicReport, tenderId, reportId);
        }
        return redirectUrl.append(TENDER_DASHBOARD_URL).append(tenderId).append("/9").append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request)).toString();
    }
    private boolean isContractCreated(int tenderId,HttpServletRequest request,ModelMap modelMap) throws Exception{
	    /* APO - Po changes start*/
	    boolean isDirectContractPO = false;
	    boolean isDirectContractAPO = false;
	    List<Object[]> listContract=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
	    if (listContract != null) {
	        for (int i = 0; i < listContract.size(); i++) {
	        	if(listContract.get(i)[0].toString().equalsIgnoreCase("12")){
	        		isDirectContractAPO=true;                		 
	            }
	        	if(listContract.get(i)[0].toString().equalsIgnoreCase("13")){
	        		isDirectContractPO=true;                		 
	            }
	        }
	    }
	    boolean contractCreated = true;
	    String msg = CommonKeywords.ERROR_MSG.toString();
	    if(isDirectContractAPO){
	    	TblAdvancePurchaseOrder tblAdvancePurchaseOrder =  commonService.getTblAdvancePurchaseOrderByObject(tenderId);
	    	if(tblAdvancePurchaseOrder!=null){
	    		contractCreated = false;
	    		msg ="msg_rpot_apo_created";
	    	}
	    }else if(isDirectContractPO){
	    	TblPurchaseOrder tblPurchaseOrder =  commonService.getTblPurchaseOrderByObject(tenderId);
	    	if(tblPurchaseOrder!=null){
	    		contractCreated = false;
	    		msg ="msg_rpot_po_created";
	    	}
	    }
	    modelMap.addAttribute("msg",msg);
	    return contractCreated;
    }
     /*  end*/
    @RequestMapping(value = "/buyer/downloaddynamicl1h1report/{tenderId}/{reportId}/{reportFor}/{enc}", method = RequestMethod.GET)
    public void downloadBidderDetail(@PathVariable("tenderId") int tenderId, @PathVariable("reportId") int reportId, @PathVariable("reportFor") int reportFor, ModelMap modelMap, HttpServletRequest request, HttpServletResponse response) {
        String fileName = null;
        List<LinkedHashMap<String, Object>> lstReportHeader = null;
        List<LinkedHashMap<String, Object>> lstReportColumnList = null;
        List<LinkedHashMap<String, Object>> lstReportColumnHeaderList = null;
        List<LinkedHashMap<String, Object>> lstReportFormHeader = null;
        try {
            Map<String, Object> dynamicReport = dynamicReportService.getDynamicL1H1Report(reportId, tenderId, abcUtility.getSessionUserId(request));
            if (dynamicReport != null && !dynamicReport.isEmpty()) {
                lstReportColumnList = (ArrayList<LinkedHashMap<String, Object>>) dynamicReport.get("#result-set-3");
                lstReportColumnHeaderList = (ArrayList<LinkedHashMap<String, Object>>) dynamicReport.get("#result-set-2");
                lstReportFormHeader = (ArrayList<LinkedHashMap<String, Object>>) dynamicReport.get("#result-set-1");
                lstReportHeader = (ArrayList<LinkedHashMap<String, Object>>) dynamicReport.get("#result-set-4");
            }

            Date now = new Date();
            String currDate = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(now);
            fileName = "DynamicL1H1Report_"+currDate;
            HSSFWorkbook wb = new HSSFWorkbook();
            HSSFSheet sheet = wb.createSheet();

            //Set Header Font
            HSSFFont headerFont = wb.createFont();
            headerFont.setBoldweight(headerFont.BOLDWEIGHT_BOLD);
            headerFont.setFontHeightInPoints((short) 12);

            //Set Header Style
            CellStyle headerStyle = wb.createCellStyle();
            headerStyle.setFillBackgroundColor(IndexedColors.BLACK.getIndex());
            headerStyle.setAlignment(headerStyle.ALIGN_CENTER);
            headerStyle.setFont(headerFont);
            headerStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
            headerStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
            int rowCount = 0;
            Row header;

            //Set Auto Column style
            CellStyle autoColumnStyle = wb.createCellStyle();
            autoColumnStyle.setAlignment(CellStyle.ALIGN_RIGHT);
            autoColumnStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

            // Set Table Style
            HSSFFont tableFont = wb.createFont();
            tableFont.setBoldweight(headerFont.BOLDWEIGHT_BOLD);
            tableFont.setFontHeightInPoints((short) 9);

            CellStyle tableStyle = wb.createCellStyle();
            tableStyle.setFillBackgroundColor(IndexedColors.BLACK.getIndex());
            tableStyle.setAlignment(headerStyle.ALIGN_CENTER);
            tableStyle.setFont(tableFont);

            // Set Form Style
            HSSFFont formFont = wb.createFont();
            formFont.setBoldweight(headerFont.BOLDWEIGHT_BOLD);
            formFont.setFontHeightInPoints((short) 11);

            CellStyle formStyle = wb.createCellStyle();
            formStyle.setFillBackgroundColor(IndexedColors.BLACK.getIndex());
            formStyle.setAlignment(headerStyle.ALIGN_CENTER);
            formStyle.setFont(formFont);
            //Create Header Cell
                /*
             * Iterate through list of report form headers
             * rowCount - to create unique row for excel generation
             */
            header = sheet.createRow(rowCount);//its for header 
            Cell cell;
            for (int j = 0; j < lstReportColumnHeaderList.size(); j++) {
                cell = header.createCell(j);
                if (j == 0) {
                    cell.setCellValue(lstReportHeader.get(0).get("reportName").toString());
                }
                cell.setCellStyle(headerStyle);
            }
            sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, 0, lstReportFormHeader.size() - 1));
            rowCount=rowCount+2;
            header = sheet.createRow(rowCount);
            for (int j = 0; j < lstReportColumnHeaderList.size(); j++) {
                cell = header.createCell(j);
                if (j == 0) {
                    cell.setCellValue(lstReportHeader.get(0).get("reportHeader").toString());
                }
                cell.setCellStyle(headerStyle);
            }
            sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, 0, lstReportFormHeader.size() - 1));

            rowCount++;
            if (lstReportFormHeader != null && !lstReportFormHeader.isEmpty()) {
                for (int countForm = 0; countForm < lstReportFormHeader.size(); countForm++) {
                    if (countForm > 0) {
                        if (!lstReportFormHeader.get(countForm).get("formName").equals(lstReportFormHeader.get(countForm - 1).get("formName"))) {
                            rowCount = rowCount + 2;
                            header = sheet.createRow(rowCount);//its for header 
                            cell = header.createCell(0);
                            cell.setCellValue(lstReportFormHeader.get(countForm).get("formName").toString());
                            cell.setCellStyle(formStyle);
                            sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, 0, lstReportFormHeader.size() - 1));
                        }
                    } else {
                        rowCount++;
                        header = sheet.createRow(rowCount);//its for header 
                        cell = header.createCell(0);
                        cell.setCellValue(lstReportFormHeader.get(countForm).get("formName").toString());
                        cell.setCellStyle(formStyle);
                        sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, 0, lstReportFormHeader.size() - 1));
                    }
                    rowCount++;
                    header = sheet.createRow(rowCount);//its for header 
                    cell = header.createCell(0);
                    cell.setCellValue(lstReportFormHeader.get(countForm).get("tableName").toString());
                    cell.setCellStyle(tableStyle);
                    sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, 0, lstReportFormHeader.size() - 1));
                    rowCount++;
                    header = sheet.createRow(rowCount);
                    // Display list of headers return by stored procedure
                    if (lstReportColumnHeaderList != null && !lstReportColumnHeaderList.isEmpty()) {
                        for (int count = 0; count < lstReportColumnHeaderList.size(); count++) {
                            cell = header.createCell(count);
                            cell.setCellValue(lstReportColumnHeaderList.get(count).get("columnName").toString());
                            cell.setCellStyle(tableStyle);
                        }
                    }
                    /*
                     * Iterate through data return from stored procedure
                     */
                    int isDataAvail = 0;
                    StringBuilder cellValue = new StringBuilder();
                    if (lstReportColumnList != null && !lstReportColumnList.isEmpty()) {
                        for (int i = 0; i < lstReportColumnList.size(); i++) {
                            if (lstReportFormHeader.get(countForm).get("tableId").equals(lstReportColumnList.get(i).get("tableId"))) {
                                isDataAvail++;
                                rowCount++;
                                header = sheet.createRow(rowCount);
                                for (int count = 0; count < lstReportColumnHeaderList.size(); count++) {
                                    cell = header.createCell(count);
                                    if(cellValue != null && cellValue.length() > 0) {
                                    cellValue.delete(0, cellValue.length());
                                    }
                                    if (Integer.parseInt(lstReportColumnHeaderList.get(count).get("filledBy").toString()) == 3) {
                                        cellValue.append(reportFor == 1 ? "L"  : "H");
                                        cellValue.append(lstReportColumnList.get(i).get(lstReportColumnHeaderList.get(count).get("columnId").toString()).toString());
                                    } else if (Integer.parseInt(lstReportColumnHeaderList.get(count).get("filledBy").toString()) == 4 || Integer.parseInt(lstReportColumnHeaderList.get(count).get("filledBy").toString()) == 2) {
                                        cellValue.append(new BigDecimal(lstReportColumnList.get(i).get(lstReportColumnHeaderList.get(count).get("columnId").toString()).toString()).setScale(3, BigDecimal.ROUND_HALF_UP).toString());
                                    } else {
                                        cellValue.append(lstReportColumnList.get(i).get(lstReportColumnHeaderList.get(count).get("columnId").toString()).toString());
                                    }
                                    cell.setCellValue(cellValue.toString());
                                    if (Integer.parseInt(lstReportColumnHeaderList.get(count).get("filledBy").toString()) == 4 || Integer.parseInt(lstReportColumnHeaderList.get(count).get("filledBy").toString()) == 2) {
                                        cell.setCellStyle(autoColumnStyle);
                                    }
                                }
                            }
                        }
                    }
                    if (isDataAvail == 0) {
                        header = sheet.createRow(rowCount);
                        cell = header.createCell(0);
                        cell.setCellValue(messageSource.getMessage("msg_tender_biddermap_empty", null, LocaleContextHolder.getLocale()));
                        cell.setCellStyle(tableStyle);
                        sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, 0, lstReportFormHeader.size() - 1));
                    }
                    rowCount++;
                }
                rowCount++;
                header = sheet.createRow(rowCount);//its for header 
                cell = header.createCell(0);
                cell.setCellValue(lstReportHeader.get(0).get("reportFooter").toString());
                cell.setCellStyle(headerStyle);
                for (int j = 1; j < lstReportColumnHeaderList.size(); j++) {
                    cell = header.createCell(j);
                    cell.setCellStyle(headerStyle);
                }
                sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, 0, lstReportFormHeader.size()-1));
                /*
                 * Adjust Auto columns size
                 */
                sheet = wb.getSheetAt(0);
                for (int j = 0; j < lstReportColumnHeaderList.size(); j++) {
                    sheet.autoSizeColumn(j);
                }
            }


            ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
            wb.write(outByteStream);
            byte[] outArray = outByteStream.toByteArray();
            response.setContentType("application/ms-excel");
            response.setContentLength(outArray.length);
            response.setHeader("Expires:", "0"); // eliminates browser caching
            response.setHeader("Content-Disposition", "attachment; filename=" + fileName + ".xls");
            OutputStream outStream = response.getOutputStream();
            outStream.write(outArray);
            outStream.flush();
            outStream.close();
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), dynamicL1H1ReportLinkId,reportFor == 1 ? viewDynamicL1ReportExcel : viewDynamicH1ReportExcel,tenderId,0);
        }
    }
     @RequestMapping(value = "/buyer/getformmapandformula", method = RequestMethod.POST)
    @ResponseBody
    public String getFormMapandFormula(@RequestParam("txtReportId") Integer reportId, HttpServletRequest request) {
        String retVal = "sessionexpired";
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		List<TblDynReportFormMap> formMapSize=dynamicReportService.getDynReporFormMaptById(reportId);
        		if(formMapSize != null && !formMapSize.isEmpty()){
        			//List<TblDynReportFormula>  formulaList=dynamicReportService.getDynReportFormulaByReportId(reportId);
        			List<TblDynReportColumn> columnList=dynamicReportService.getDynReportColumnByReportId(reportId, 2);
					Long countColumns =dynamicReportService.getFormulaColumnCount(reportId,0);
                    retVal = String.valueOf(columnList.size() != 0 && columnList.size() == countColumns ? -1 : 0);
        		}else{
        			retVal = String.valueOf("1");
        		}
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return retVal;
    }
     
    @RequestMapping(value="/buyer/generatelotwisereport/{tenderId}/{enc}",method= RequestMethod.GET)
    public String generateLotwiseReport(@PathVariable("tenderId") int tenderId,ModelMap modelMap,HttpServletRequest request) {
         String retVal = "/etender/common/LotWiseL1Report";
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> techEnvId=tenderCommonService.getEnvelopeTypeByTenderId(tenderId);
            if(Integer.parseInt(modelMap.get("tenderResult").toString()) == 3){ //Lot wise L1/H1 report.
                List<Object[]> formData=dynamicReportService.getPriceFormTableDetails(tenderId);
                HashMap<String,List<Object[]>> formMap=new HashMap<String, List<Object[]>>();
                Map<String,String> formNameMap=new Hashtable<String, String>();
                //get the unique form ids & all cell Ids.
                List<Integer> cellIds = new ArrayList<Integer>();
                for (Object[] objects : formData) {
                    Object[] tableTemData=new Object[4];
                    List<Object[]> tableTempList = formMap.containsKey(objects[0].toString())== true ? formMap.get(objects[0].toString()):new ArrayList<Object[]>();
                    tableTemData[0]=objects[1].toString();// tableId
                    tableTemData[1]=objects[2].toString();// cellId
                    tableTemData[2]=objects[3].toString();// formName
                    tableTemData[3]=objects[4].toString();// tableName
                    cellIds.add(Integer.parseInt(objects[2].toString()));
                    formNameMap.put(objects[0].toString(), objects[3].toString());
                    tableTempList.add(tableTemData);
                    formMap.put(objects[0].toString(), tableTempList);
                }
                modelMap.addAttribute("reportType",Integer.parseInt(modelMap.get("biddingVariant").toString())== 1 ? "L" : "H");
                List<Object[]> bidderData=dynamicReportService.getL1BidderDetailsByTableIds(cellIds,Integer.parseInt(modelMap.get("biddingVariant").toString())== 1 ? "asc" : "desc",techEnvId);
                modelMap.addAttribute("formsDataMap",formMap);
                modelMap.addAttribute("biderData",bidderData);
                modelMap.addAttribute("formNameMap",formNameMap); 
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), dynamicL1H1ReportLinkId, true ? viewDynamicL1Report : viewDynamicH1Report, tenderId, 0);
        }
        return retVal;
    }     
	
}
