package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

@Component
public class SPGetTenderListForMobile extends StoredProcedure {

	 @Autowired
	 @Qualifier("dataSource")
	    public void init(BasicDataSource factory) {
	        setDataSource(factory);
	    }
	    
	    private static final String SPROC_NAME = "apptender.P_GetHomePageTenderListForMobile";

	    public SPGetTenderListForMobile() {
	        super.setSql(SPROC_NAME);
	        this.declareParameter(new SqlParameter("@V_TabId", Types.TINYINT));
	        this.declareParameter(new SqlParameter("@V_Keyword", Types.NVARCHAR));
	        this.declareParameter(new SqlParameter("@V_TimeZoneOffset", Types.NVARCHAR));
	        this.declareParameter(new SqlParameter("@V_ConversionValue", Types.SMALLINT));
	        this.declareParameter(new SqlParameter("@V_RecordsPerPage", Types.INTEGER));
	        this.declareParameter(new SqlParameter("@V_PageNo", Types.INTEGER));
	    }

	    public  Map<String, Object> executeProcedure( int tabId, String keyWords,
	    															String timeZoneOffset,int conversionValue , 
	    															int recordPerPage , int pageNo)throws Exception {
	        Map<String, Object> inParams = new HashMap<String, Object>();
	        inParams.put("@V_TabId", tabId);
	        inParams.put("@V_Keyword", keyWords);
	        inParams.put("@V_TimeZoneOffset", timeZoneOffset);
	        inParams.put("@V_ConversionValue", conversionValue);
	        inParams.put("@V_RecordsPerPage", recordPerPage);
	        inParams.put("@V_PageNo", pageNo);
	        
	        this.compile();
	        return execute(inParams);
	    }
	    
}
