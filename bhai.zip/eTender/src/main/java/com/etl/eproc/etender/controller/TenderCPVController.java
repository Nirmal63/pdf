package com.etl.eproc.etender.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.NegotiationService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBidderCPV;
import com.etl.eproc.etender.model.TblTenderCPV;
import com.etl.eproc.etender.services.TenderCPVService;
import com.etl.eproc.etender.services.TenderCommonService;

/**
 * @author Priyanka 
 */
@Controller
public class TenderCPVController {
	
	
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private TenderCommonService tenderCommonService;	
	@Autowired
	private TenderCPVService tenderCPVService;
	@Autowired
	private NegotiationService negotiationService;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
    private ReportGeneratorService reportGeneratorService;
	@Value("#{etenderAuditTrailProperties['getsuccessCPVReport']}")    
    private String successMsgTenderCPVReport;
	@Autowired
    private ExceptionHandlerService exceptionHandlerService;
	@Autowired
    private AuditTrailService auditTrailService;
	@Autowired
    private ClientService clientService;
	@Autowired
	private CommonService commonService; 
	@Value("#{tenderlinkProperties['tender_cpv_mapping_report']?:104}") 
    private int tenderCPVMappingReportId;
	@Value("#{tenderlinkProperties['add_tender_cpv_code']?:1137}") 
    private int addTenderCPVKeywordLinkId;
	@Value("#{tenderlinkProperties['tender_classification_report']?:129}") 
    private int tenderClassificationReportId;
	
	
	/**
  	 * @author Priyanka
  	 * @param modelMap
  	 * @param response
  	 * @param reportId
  	 * @param request
  	 * @return
  	 */
  	@RequestMapping(value ="/etender/buyer/tendercpvmappingreport/{reportId}/{enc}", method = RequestMethod.GET)
   	public String getCPCVMappingReport(ModelMap modelMap, HttpServletResponse response,@PathVariable("reportId") String reportId, HttpServletRequest request) {
  		String auditMsg="";
  		try{
  			reportGeneratorService.getReportConfigDetails(tenderCPVMappingReportId, modelMap);
  			auditMsg=successMsgTenderCPVReport;
  		}catch(Exception e){
  			return exceptionHandlerService.writeLog(e);
  		}finally{
  			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addTenderCPVKeywordLinkId, auditMsg, 0, 0);
  		}
  		return "/etender/buyer/TenderCPVMappingReport";
  	}
  	
  	
	/**
	 * @author Priyanka
	 * @param modelMap
	 * @param response
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	
	@RequestMapping(value = "/etender/buyer/tendercpvmapping/{tenderId}/{operation}/{enc}", method = RequestMethod.GET)
	public String getTenderCPVMapping(ModelMap modelMap,HttpServletResponse response,@PathVariable("tenderId") Integer tenderId,@PathVariable("operation") int operation, HttpServletRequest request)
	{
		List<Object[]> tenderDetailLst = null;
		List<Object[]> bidderLst = null;		
		int tenderMode = 1;
		int clientId = 0;
		int isConsortiumAllowed = 0;
		try {
		
			tenderDetailLst = tenderCommonService.getTenderFields(tenderId,"tenderBrief,keywordText,tenderMode,isConsortiumAllowed");
		
			if (tenderDetailLst!=null && !tenderDetailLst.isEmpty()) {			
				tenderMode = Integer.parseInt(tenderDetailLst.get(0)[2].toString());
				isConsortiumAllowed = Integer.parseInt(tenderDetailLst.get(0)[3].toString());			
			}
			
			List<Object[]> lst = tenderCommonService.getDomainNamebyTenderId(tenderId);			
			if (lst!=null && !lst.isEmpty()) {
				clientId = Integer.parseInt(lst.get(0)[0].toString());					
			}					
			tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
			if(isConsortiumAllowed==1)
			{				
				bidderLst = tenderCommonService.getConsortiumPartnerDetail(tenderId);		
				modelMap.addAttribute("isConsoTenderMode", tenderMode);
				
			}else if(tenderMode==1)
			{				
				bidderLst = negotiationService.getParticipatedBiddersForRFx(tenderId,0);
				modelMap.addAttribute("isConsoTenderMode", 0);
			}
			else
			{
				bidderLst = tenderCommonService.getTenderMappedBidderDetails(tenderId, clientId, 1, 0, 0);			
				modelMap.addAttribute("isConsoTenderMode", 0);
			}						
			modelMap.addAttribute("bidderLst", bidderLst);
			modelMap.addAttribute("tenderDetailLst", tenderDetailLst);			
			List<Object[]> tenderCpvId = tenderCPVService.getTenderIdTblTenderCPV(tenderId); 
			// operation = 0 for Create AND 1 for Edit
			if (operation == 1) {			
				StringBuilder keyword = null;
				keyword = new StringBuilder();			
				for (int i = 0; i < tenderCpvId.size(); i++) {
						if (i==0)
						{
							keyword.append(tenderCpvId.get(i)[2]);
						}else{
							keyword.append(",").append(tenderCpvId.get(i)[2]);
						}
				}				
				modelMap.addAttribute("editValue", keyword.toString());
			}			
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		return "etender/buyer/TenderCPVMapping";
	}

	/**
	 * @author Priyanka
	 * @param modelMap
	 * @param response
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	
	@RequestMapping(value = "/etender/buyer/cpvcode/{operation}", method = RequestMethod.POST)
	public String saveCPVCode(ModelMap modelMap,@PathVariable("operation") int operation,HttpServletResponse response, HttpServletRequest request,RedirectAttributes redirectAttributes) {
		int tenderId = 0;
		int buyerId = 0;
		int deptId = 0;
		int clientId = 0;
		String cpvCode = "";		
		boolean isSuccess = false;
		String pageName = "etender/buyer/tendercpvmappingreport/"+ tenderCPVMappingReportId;
		String returnUrl;
		List<TblTenderCPV> tblTenderCPVList = new ArrayList<TblTenderCPV>();
		TblTenderCPV tblTenderCPV = null;
		List<TblTenderBidderCPV> tblTenderBidderCPVList = new ArrayList<TblTenderBidderCPV>();
		TblTenderBidderCPV tblTenderBidderCPV = null;
		String cpvCodeChar[];	
		
		try {
			tenderId = Integer.parseInt(request.getParameter("hdTenderId"));
			TblTender tblTender = tenderCommonService.getTenderById(tenderId);			
			deptId = tblTender.getTblDepartment().getDeptId();		
			buyerId = tblTender.getOfficerId();
			List<Object[]> lst = tenderCommonService.getDomainNamebyTenderId(tenderId);
			String domainName = "";
			if (lst!=null && !lst.isEmpty()) {
				clientId = Integer.parseInt(lst.get(0)[0].toString());	
				domainName = lst.get(0)[1].toString();
			}										
			if (operation == 1) {
				tenderCPVService.addCPVCode(tblTenderCPVList,tblTenderBidderCPVList, tenderId, operation);	// Delete Detail
			}					
			cpvCode = request.getParameter("txtCPVCode");
			if (cpvCode.contains(",")) {
				cpvCodeChar = cpvCode.split(",");
				for (int k = 0; k < cpvCodeChar.length; k++) {
					tblTenderCPV = new TblTenderCPV();
					tblTenderCPV.setTblTender(new TblTender(tenderId));
					tblTenderCPV.setCpvCode("");
					tblTenderCPV.setKeyword(cpvCodeChar[k].trim());
					tblTenderCPV.setTblUserLogin(new TblUserLogin(buyerId));
					tblTenderCPV.setIsDummyOfficer(0);
					tblTenderCPV.setDomainId(clientId);
					tblTenderCPV.setDeptId(deptId);				
					tblTenderCPVList.add(tblTenderCPV);
				}
			} else {
				tblTenderCPV = new TblTenderCPV();
				tblTenderCPV.setTblTender(new TblTender(tenderId));
				tblTenderCPV.setCpvCode("");
				tblTenderCPV.setKeyword(cpvCode.trim());
				tblTenderCPV.setTblUserLogin(new TblUserLogin(buyerId));
				tblTenderCPV.setIsDummyOfficer(0);
				tblTenderCPV.setDomainId(clientId);
				tblTenderCPV.setDeptId(deptId);				
				tblTenderCPVList.add(tblTenderCPV);
			}		
			
			List<Object[]> bidderLst = null;
				int index = 0;
				if(tblTender.getIsConsortiumAllowed()==1)
				{
					bidderLst = tenderCommonService.getConsortiumPartnerDetail(tenderId);	
					index = 0;
				}
				else if(tblTender.getTenderMode()==1)
				{
						bidderLst = negotiationService.getParticipatedBiddersForRFx(tenderId,0);
						index = 3;
				}
				else
				{
						bidderLst = tenderCommonService.getTenderMappedBidderDetails(tenderId, clientId, 1, 0, 0);
						index = 1;
				}               
				if(bidderLst!=null && !bidderLst.isEmpty() ){
					for(int i=0;i<bidderLst.size();i++){					
		    			cpvCode = request.getParameter("txtCPVCode");	    		
		    			if (cpvCode.contains(",")) {
		    				cpvCodeChar = cpvCode.split(",");
		    				for (int k = 0; k < cpvCodeChar.length; k++) {
		    					tblTenderBidderCPV = new TblTenderBidderCPV();	    	    			
		    	    			tblTenderBidderCPV.setTblUserLogin(new TblUserLogin(Integer.parseInt(bidderLst.get(i)[index].toString())));
		    	    			tblTenderBidderCPV.setTblTender(new TblTender(tenderId));
		    					tblTenderBidderCPV.setCpvCode("");
		    					tblTenderBidderCPV.setKeyword(cpvCodeChar[k].trim());
		    					tblTenderBidderCPV.setIsDummyBidder(0);
		    					tblTenderBidderCPVList.add(tblTenderBidderCPV);
		    				}
		    			}
		    			else
		    			{
		    				tblTenderBidderCPV = new TblTenderBidderCPV();		    			
			    			tblTenderBidderCPV.setTblUserLogin(new TblUserLogin(Integer.parseInt(bidderLst.get(i)[index].toString())));
			    			tblTenderBidderCPV.setTblTender(new TblTender(tenderId));
							tblTenderBidderCPV.setCpvCode("");
							tblTenderBidderCPV.setKeyword(cpvCode.trim());
							tblTenderBidderCPV.setIsDummyBidder(0);
							tblTenderBidderCPVList.add(tblTenderBidderCPV);
		    			}    		
		    		}	
				}
			if (tenderCPVService.addCPVCode(tblTenderCPVList,tblTenderBidderCPVList, 0, 0)) {
				isSuccess = true;
				
  				List<Object[]> tenderLst=null;  			
  				tenderLst=tenderCPVService.gettenderIdToSaveTenderCPVCode(tenderId, domainName, tblTender.getTblDepartment().getDeptId());  				
				
				if (operation == 1) {
					pageName = "etender/buyer/tendercpvmappingreport/"+ tenderCPVMappingReportId;
				}else if(tenderLst!=null && !tenderLst.isEmpty()){				
  					int tmpTenderId=Integer.parseInt(tenderLst.get(0)[0].toString());
  					if(operation == 3){
  						pageName = "etender/buyer/tenderclassifycreate/"+tmpTenderId+"/0";
  					}else{
  						pageName = "etender/buyer/tendercpvmapping/"+tmpTenderId+"/0";
  					}
				}
				 else {
					pageName = "etender/buyer/tendercpvmappingreport/"+ tenderCPVMappingReportId;
				}
  				}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		returnUrl = "redirect:/" + pageName	+ encryptDecryptUtils.generateRedirect(pageName, request);
		redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString(): CommonKeywords.ERROR_MSG.toString(),isSuccess ? "msg_ten_add_cpv_code" : CommonKeywords.ERROR_MSG_KEY.toString());
		return returnUrl;
	}
	/*PT #38423 : start*/
	@RequestMapping(value ="/etender/buyer/tenderclassificationreport/{reportId}/{enc}", method = RequestMethod.GET)
   	public String getTenderClassificationReport(ModelMap modelMap, HttpServletResponse response,@PathVariable("reportId") String reportId, HttpServletRequest request) {
  		String auditMsg="";
  		try{
  			reportGeneratorService.getReportConfigDetails(tenderClassificationReportId, modelMap);
  			auditMsg=successMsgTenderCPVReport;
  		}catch(Exception e){
  			return exceptionHandlerService.writeLog(e);
  		}finally{
  			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addTenderCPVKeywordLinkId, auditMsg, 0, 0);
  		}
  		return "/etender/buyer/TenderClassificationReport";
  	}
	
	@RequestMapping(value = {"/etender/buyer/tenderclassifycreate/{tenderId}/{operation}/{enc}","/etender/buyer/tenderclassifyview/{tenderId}/{operation}/{enc}"}, method = RequestMethod.GET)
	public String getTenderClassificationMapping(ModelMap modelMap,HttpServletResponse response,@PathVariable("tenderId") Integer tenderId,@PathVariable("operation") int operation, HttpServletRequest request)
	{
		List<Object[]> tenderDetailLst = null;
		List<Object[]> bidderLst = null;		
		int tenderMode = 1;
		int clientId = 0;
		int isConsortiumAllowed = 0;
		TblClient tblclient = null;
		try {
			List<Object[]> lst = tenderCommonService.getDomainNamebyTenderId(tenderId);			
			if (lst!=null && !lst.isEmpty()) {
				clientId = Integer.parseInt(lst.get(0)[0].toString());					
			}
			tblclient = clientService.getClientById(clientId);
			tenderDetailLst = tenderCommonService.getTenderFields(tenderId,"tenderBrief,keywordText,tenderMode,isConsortiumAllowed");
			modelMap.addAttribute("categoryType",tblclient.getCategoryType());
			if(tblclient != null && tblclient.getCategoryType() == 2){
				modelMap.addAttribute("categoryNameList", commonService.getCategoryNameByObjectIdList(tenderId));
			}
			if (tenderDetailLst!=null && !tenderDetailLst.isEmpty()) {			
				tenderMode = Integer.parseInt(tenderDetailLst.get(0)[2].toString());
				isConsortiumAllowed = Integer.parseInt(tenderDetailLst.get(0)[3].toString());			
			}
			
			tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
			if(isConsortiumAllowed==1)
			{				
				bidderLst = tenderCommonService.getConsortiumPartnerDetail(tenderId);		
				modelMap.addAttribute("isConsoTenderMode", tenderMode);
				
			}else if(tenderMode==1)
			{				
				bidderLst = negotiationService.getParticipatedBiddersForRFx(tenderId,0);
				modelMap.addAttribute("isConsoTenderMode", 0);
			}
			else
			{
				bidderLst = tenderCommonService.getTenderMappedBidderDetails(tenderId, clientId, 1, 0, 0);			
				modelMap.addAttribute("isConsoTenderMode", 0);
			}						
			modelMap.addAttribute("bidderLst", bidderLst);
			modelMap.addAttribute("tenderDetailLst", tenderDetailLst);			
			List<Object[]> tenderCpvId = tenderCPVService.getTenderIdTblTenderCPV(tenderId); 
			// operation = 0 for Create AND 1 for Edit
			if (operation == 1) {			
				StringBuilder keyword = null;
				keyword = new StringBuilder();			
				for (int i = 0; i < tenderCpvId.size(); i++) {
						if (i==0)
						{
							keyword.append(tenderCpvId.get(i)[2]);
						}else{
							keyword.append(",").append(tenderCpvId.get(i)[2]);
						}
				}				
				modelMap.addAttribute("editValue", keyword.toString());
			}			
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		return "etender/buyer/TenderClassificationMapping";
	}
	/*PT #38423 : End*/
}
