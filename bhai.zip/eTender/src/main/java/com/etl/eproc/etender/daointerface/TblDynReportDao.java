package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblDynReport;
import java.util.List;

public interface TblDynReportDao  {

    public void addTblDynReport(TblDynReport tblDynReport);

    public void deleteTblDynReport(TblDynReport tblDynReport);

    public void updateTblDynReport(TblDynReport tblDynReport);

    public List<TblDynReport> getAllTblDynReport();

    public List<TblDynReport> findTblDynReport(Object... values) throws Exception;

    public List<TblDynReport> findByCountTblDynReport(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynReportCount();

    public void saveUpdateAllTblDynReport(List<TblDynReport> tblDynReports);

	public void saveOrUpdateTblDynReport(TblDynReport tblDynReport);
}