package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.etender.model.TblItemBidderMap;
import java.util.List;

public interface TblItemBidderMapDao  {

    public void addTblItemBidderMap(TblItemBidderMap tblItemBidderMap);

    public void deleteTblItemBidderMap(TblItemBidderMap tblItemBidderMap);

    public void updateTblItemBidderMap(TblItemBidderMap tblItemBidderMap);

    public List<TblItemBidderMap> getAllTblItemBidderMap();

    public List<TblItemBidderMap> findTblItemBidderMap(Object... values) throws Exception;

    public List<TblItemBidderMap> findByCountTblItemBidderMap(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblItemBidderMapCount();

    public void saveUpdateAllTblItemBidderMap(List<TblItemBidderMap> tblItemBidderMaps);
}