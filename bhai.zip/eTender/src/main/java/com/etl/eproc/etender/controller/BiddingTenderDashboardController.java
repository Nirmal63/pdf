package com.etl.eproc.etender.controller;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.TblCouponHistoryDao;
import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.model.TblClientPGBankMapping;
import com.etl.eproc.common.model.TblClientPayment;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblExemptionCertConf;
import com.etl.eproc.common.model.TblOfflinePayment;
import com.etl.eproc.common.model.TblPayment;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.InvoiceDocServie;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.MessageQueueService;
import com.etl.eproc.common.services.NegotiationService;
import com.etl.eproc.common.services.QuestionAnswerService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.services.TblFavouriteTenderService;
import com.etl.eproc.common.services.TpslService;
import com.etl.eproc.common.services.WorkflowService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.DateUtils;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.eauction.model.TblAuction;
import com.etl.eproc.etender.daointerface.TblShareReportDao;
import com.etl.eproc.etender.databean.TenderOpenProcessDTBean;
import com.etl.eproc.etender.model.TblConsortium;
import com.etl.eproc.etender.model.TblConsortiumDetail;
import com.etl.eproc.etender.model.TblDynReport;
import com.etl.eproc.etender.model.TblPreBidReport;
import com.etl.eproc.etender.model.TblShareReport;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBidRegression;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.DynamicReportService;
import com.etl.eproc.etender.services.EventBidSubmissionService;
import com.etl.eproc.etender.services.EventBidderMapService;
import com.etl.eproc.etender.services.PrebidService;
import com.etl.eproc.etender.services.TenderBriefcaseService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderCorrigendumService;
import com.etl.eproc.etender.services.TenderFormService;
import com.etl.eproc.etender.services.TenderOpenService;
import com.etl.eproc.etender.services.TenderService;

/**
 *
 * @author Nihar,VIPULP,Dipal(for Consortium)
 */
@Controller
@RequestMapping("/etender/bidder")
public class BiddingTenderDashboardController {
	
    @Autowired
    private TenderOpenService tenderOpenService;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private DateUtils dateUtils;
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private CommonService commonService;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private PrebidService prebidService;
    @Autowired
    private EventBidSubmissionService eventBidSubmissionService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private LoginService loginService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private TpslService tpslService;
    @Autowired
    private TenderBriefcaseService tenderBriefcaseService;
    @Autowired
    private EventBidderMapService eventBidderMapService;  
    @Autowired
	private ReportGeneratorService reportGeneratorService;
    @Autowired
    private NegotiationService negotiationService;
    @Autowired
    private QuestionAnswerService questionAnswerService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private WorkflowService workflowService;
    @Autowired
    private InvoiceDocServie invoiceDocServie;
    @Autowired
    private DynamicReportService dynamicReportService;
    @Autowired
    private TenderCorrigendumService tenderCorrigendumService;
    @Autowired
    private TblFavouriteTenderService tblFavouriteTenderService;
    @Autowired
    private TenderService tenderService;
    @Autowired
    private TblShareReportDao tblShareReportDao;
    @Autowired
    private FileUploadService fileUploadService;
    
    @Value("#{tenderlinkProperties['pre_bid_meeting_upload']?:216}")
    private int uploadPrebidDocLinkId;
    @Value("#{projectProperties['pki_eventspecific']?:2}")
    private int pkiEventSpecific;
    @Value("#{projectProperties['pki_enable']?:2}")
    private int pkiEnable;
    @Value("#{tenderlinkProperties['bidder_consortium_create']?:199}")
    private int lnkCreateCons;
    @Value("#{tenderlinkProperties['bidder_add_partner']?:262}")
    private int lnkAddConsPart;
    @Value("#{tenderlinkProperties['bidder_remove_partner']?:263}")
    private int lnkRemoveConsPart;
    @Value("#{tenderlinkProperties['bidder_finalize']?:264}")
    private int lnkFinalizeCons;
    @Value("#{tenderlinkProperties['bidder_reset']?:265}")
    private int lnkResetCons;
    @Value("#{tenderlinkProperties['bidder_accept_invitation']?:266}")
    private int lnkAcceptConsInvi;
    @Value("#{tenderlinkProperties['bidder_reject_invitation']?:267}")
    private int lnkRejectConsInvi;
    @Value("#{tenderlinkProperties['bidder_dashboard']?:279}")
    private int biddingEventDashboardLinkId;
    @Value("#{etenderAuditTrailProperties['getBiddingTenderDashboard']}")
    private String getBiddingTenderDashboard;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentPQ']}")
    private String postajaxBiddingTenderDashboardContentPQ;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentDEC']}")
    private String postajaxBiddingTenderDashboardContentDEC;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentDF']}")
    private String postajaxBiddingTenderDashboardContentDF;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentEMD']}")
    private String postajaxBiddingTenderDashboardContentEMD;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentPB']}")
    private String postajaxBiddingTenderDashboardContentPB;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentFS']}")
    private String postajaxBiddingTenderDashboardContentFS;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentRES']}")
    private String postajaxBiddingTenderDashboardContentRES;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentNEG']}")
    private String postajaxBiddingTenderDashboardContentNEG;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentAPO']}")
    private String postajaxBiddingTenderDashboardContentAPO;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentPO']}")
    private String postajaxBiddingTenderDashboardContentPO;
    @Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentCON']}")
    private String postajaxBiddingTenderDashboardContentCON;
    @Value("#{etenderAuditTrailProperties['postajaxTenderDashboardContentREST']}")
    private String postajaxTenderDashboardContentREST;
    @Value("#{etenderAuditTrailProperties['ajaxInviteConsPartner']}")
    private String ajaxInviteConsPartner; 
    @Value("#{etenderAuditTrailProperties['ajaxSearchConsPartner']}")
    private String ajaxSearchConsPartner; 
    @Value("#{etenderAuditTrailProperties['ajaxRemoveConsPartner']}")
    private String ajaxRemoveConsPartner; 
    @Value("#{etenderAuditTrailProperties['postAcceptConRequest']}")
    private String postAcceptConRequest; 
    @Value("#{etenderAuditTrailProperties['postRejectConRequest']}")
    private String postRejectConRequest; 
    @Value("#{etenderAuditTrailProperties['postConPartnerType']}")
    private String postConPartnerType; 
    @Value("#{etenderAuditTrailProperties['postFinalConProcess']}")
    private String postFinalConProcess; 
    @Value("#{etenderAuditTrailProperties['postConReset']}")
    private String postConReset; 
    @Value("#{projectProperties['doc_upload_path']}")
    private String docUploadPath; 
    @Value("#{etenderAuditTrailProperties['msg_tender_reset_consotrium']}")
    private String msgResetConsortium;
    @Value("#{tenderlinkProperties['bidder_pcf_upload']?:524}")
    private int pcfUploadTender;
    @Value("#{linkProperties['report_bidder_negotiatio_listing']?:70}")
	private int biddersideNegogationListingReportId;
    @Value("#{tenderlinkProperties['negotiation_negotiation_process_invite_for_negotiation']?:602}")
	private int tenderLinkForBidderInvite;
    @Value("#{tenderlinkProperties[' negotiation_bidder_start_chat']?:614}")
  	private int tenderLinkForBidderStartChat;
    @Value("#{tenderlinkProperties['negotiation_bidder_negotiation_listing']?:662}")
  	private int tenderLinkForBidderListingLink;
    @Value("#{etenderAuditTrailProperties['getBidderNegotationTabListing']}")
    private String getBidderNegotationTabListing;
    @Autowired
    private MessageQueueService messageQueueService;
    @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
    private String queueName;
    @Value("#{eauctionProperties['invite_consortium_templateId']?:41}")
    private String inviteConsortiumTemplateId;
    @Value("#{eauctionProperties['accpt_rej_consortium_templateId']?:42}")
    private String accptRejConsortiumTemplateId;
    @Value("#{eauctionProperties['reset_consortium_templateId']?:43}")
    private String resetConsortiumtemplateId;
    @Value("#{tenderlinkProperties['bid_preparation_registration_charges_offline_payment']?:798}")
  	private int linkBidPreRegChargesOfflinePayment;
    @Value("#{tenderlinkProperties['lnk_docfee_payment']?:929}") 
    private int lnkTenderDocPayment;
    @Value("#{tenderlinkProperties['lnk_emdfee_payment']?:930}") 
    private int lnkTenderEmdPayment; 
    @Value("#{tenderlinkProperties['docfees_offline_payment_eventId']?:89}")
    private int docfeesOfflinePaymentEventId;
    @Value("#{tenderlinkProperties['emd_offline_payment_eventId']?:90}")
    private int emdOfflinePaymentEventId;
    @Value("#{tenderlinkProperties['registration_offline_payment_eventId']?:152}")
    private int regOfflinePaymentEventId;
    @Value("#{projectProperties['rci_client_ids']}")
    private String rciClientIds;
    
    @Value("#{projectProperties['prebidmeeting_id']?:31}")
	private int prebidMeetingId;
	@Value("#{projectProperties['bidopening_id']?:32}")
	private int bidOpeningId;
	@Value("#{projectProperties['bidevaluation_id']?:33}")
	private int bidEvaluationId;
	@Value("#{tenderlinkProperties['bid_evaluation_dynamic_l1h1_report']?:444}")
    private int dynamicL1H1ReportLinkId;
	@Value("#{etenderAuditTrailProperties['viewDynamicL1Report']}")
	private String viewDynamicL1Report;
	@Value("#{etenderAuditTrailProperties['viewDynamicH1Report']}")
	private String viewDynamicH1Report;
	@Value("#{projectProperties['default_contry_id']}")
    private int countryId;
	@Value("#{clientProperties['cgClient']}")
    private String cgClient;
	@Value("#{etenderAuditTrailProperties['postajaxBiddingTenderDashboardContentQA']}")
    private String postajaxBiddingTenderDashboardContentQA;

    
    private static final String PUBLICKEY = "publicKey";
    private static final int TAB_POST_QUERY = 1;
    private static final int TAB_DECLARATION = 2;
    private static final int TAB_DOC_FEES = 3;
    private static final int TAB_EMD = 4;
    private static final int TAB_PREPARE_BID = 5;
    private static final int TAB_FINAL_SUBMISSION = 6;
    private static final int TAB_RESULT = 7;
    private static final int TAB_NEGOTIATION = 8;
    private static final int TAB_APOCO = 9;
    private static final int TAB_PO = 10;
    private static final int FINALSUBMISSION_REQUEST_TYPE_GET = 0;
    private static final int TAB_CONSORTIUM = 11;
    private static final int TAB_LOI = 12;
    private static final int TAB_QA = 13;
    private static final int TAB_REG_PAYMENT = 14;
    private static final int TAB_PAYMENT = 15;
    private static final int TAB_COMMUNICATION = 16;
    private static final int TAB_PARTICIPATION_FEES = 17;
    private static final int TAB_RESTEVENTMONEY = 18;
    private static final int TAB_CONTRACT = 19;

    private static final String TENDER_ID = "tenderId";
    private static final String HIDDEN_TENDER_ID = "hdTenderId";
    private static final String HIDDEN_CONSORTIUM_ID = "hdConsortiumId";
    private static final String TAB_ID = "tabId";

    /**
     * @param tenderId
     * @param tabId
     * @param modelMap
     * @param request
     * @return to view
     */
    @RequestMapping(value = "/biddingtenderdashboard/{tenderId}/{tabId}/{enc}", method = RequestMethod.GET)
    public String biddingTenderDashboard(@PathVariable(TENDER_ID) int tenderId, @PathVariable(TAB_ID) int tabId, ModelMap modelMap, HttpServletRequest request,HttpSession httpSession,RedirectAttributes redirectAttributes ) {
        String retVal="etender/bidder/BiddingTenderDashboard";
        try {
        	 	/*String languageId = WebUtils.getCookie(request, "locale").getValue();
             	int eventTypeId = eventBidSubmissionService.getEventTypeId(tenderId);
        		List<Object[]> condition = eventBidSubmissionService.getTenderBidConfirmForm(tenderId, modelMap, abcUtility.getSessionClientId(request), languageId, eventTypeId);
        		boolean isRepeated = eventBidSubmissionService.isTenderIdRepeated(tenderId, abcUtility.getSessionUserId(request));
        		int clientBidTermId = 0;
                for (Object[] object : condition) {
                    clientBidTermId = (Integer) object[0];
                }*/
                TblTender tblTender = tenderCommonService.getTenderById(tenderId);
                ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
                SessionBean sessionBean=(SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
                int isRegistrationCharges = tblTender.getIsRegistrationCharges();
                int registrationChargesMode = tblTender.getRegistrationChargesMode();
                modelMap.addAttribute("isEventFuture", tenderCommonService.isEventFuture(tenderId));
                modelMap.addAttribute("isRegistrationCharges", isRegistrationCharges);
                modelMap.addAttribute("registrationChargesMode", registrationChargesMode);
                boolean isPendingSecondaryPartner = false;
                Object[]  eventRegFeePaymentDetail = null;
                if(isRegistrationCharges==1){
                     eventRegFeePaymentDetail = tpslService.getPaymentDetail(8, tenderId, sessionBean.getCompanyId(),1,3);
                     modelMap.addAttribute("paymentDetail", eventRegFeePaymentDetail);
                    if(tblTender.getIsConsortiumAllowed()==1){
                    	List<Object> list=eventBidSubmissionService.getConsDtlForSecondPartReq(tenderId, abcUtility.getSessionUserId(request));
                    	isPendingSecondaryPartner = list!=null && !list.isEmpty() ? true :false;
                        modelMap.addAttribute("isPendingSecondaryPartner",isPendingSecondaryPartner);
                        if(!isPendingSecondaryPartner){
                            if(eventRegFeePaymentDetail==null){
                                tabId=TAB_REG_PAYMENT;
                                modelMap.addAttribute("tabId", tabId);
                            }
                        }
                    }else{
                        if(eventRegFeePaymentDetail==null){
                            tabId=TAB_REG_PAYMENT;
                            modelMap.addAttribute("tabId", tabId);
                        }
                    }
                } 
                if(clientBean.getIsPkiEnabled()==pkiEventSpecific && tblTender.getIsCertRequired() ==1){
                	
                	if(!sessionBean.isEventSpecVerify()){
            			retVal="common/bidder/attacheventspeccerti/etender,bidder,biddingtenderdashboard,"+tenderId+","+tabId;
            			retVal="redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
        			}else{
                		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                        int brdMode=(Integer)modelMap.get("brdMode");
                        boolean isPcfUploaddedByBidder=false,isPCFEnable=true;
                            
                        if(brdMode == 1)
                        {
                    		int clientId = abcUtility.getSessionClientId(request);
                    		isPCFEnable = commonService.isRCIClient(rciClientIds,clientId) == true ? false : true;
                        	if(isPCFEnable && ((Integer)modelMap.get("tenderMode") == 2) || ((Integer)modelMap.get("tenderMode") == 3 || ((Integer)modelMap.get("tenderMode") == 4))){
                        		if(commonService.getPCFUploadCount(tenderId, pcfUploadTender, abcUtility.getSessionUserId(request))>0)
                                {
                                    isPcfUploaddedByBidder=true;
                                }
                                else
                                {
                                    isPcfUploaddedByBidder=false;
                                }
                        	}else{
                        		isPcfUploaddedByBidder=true;
                        	}
                        }
                        else
                        {
                            isPcfUploaddedByBidder=true;
                        }
                        //Added by Mitesh on 20140320 for task #Feature #16859
                        //get the bidder is invited for negogation ,added by Mitesh
                        int isNegotiationAllowd= negotiationService.getisNegotiationAllowed(3,tenderId,tenderLinkForBidderInvite,abcUtility.getSessionUserId(request),abcUtility.getSessionClientId(request));
                        if(isNegotiationAllowd!=0 && isNegotiationAllowd==1){
                        	modelMap.addAttribute("isNegotiationAllowed",1);
                        }
                        else{
                        	modelMap.addAttribute("isNegotiationAllowed",0);
                        }
                       
                       
                        //Ended by mitesh
                        if (isPcfUploaddedByBidder) 
                        {
                                List<Object[]> lstPrebidDtls = tenderCommonService.getTenderFields(tenderId, "isPreBidMeeting,preBidMode,isEMDApplicable,isDocfeesApplicable,docFeePaymentMode,emdPaymentMode");
                                if (!lstPrebidDtls.isEmpty()) {
                                    modelMap.addAttribute("isPrebidMeeting", lstPrebidDtls.get(0)[0]);
                                    modelMap.addAttribute("preBidMode", lstPrebidDtls.get(0)[1]);
                                    modelMap.addAttribute("isEMDApplicable", lstPrebidDtls.get(0)[2]);
                                    modelMap.addAttribute("isDocfeesApplicable", lstPrebidDtls.get(0)[3]);
                                    modelMap.addAttribute("docFeePaymentMode", lstPrebidDtls.get(0)[4]);
                                    modelMap.addAttribute("emdPaymentMode", lstPrebidDtls.get(0)[5]);
                                    SessionBean sBean =(SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
                                    modelMap.addAttribute("isOnlinePaymentDone", tpslService.isOnlinePaymentDone(0, tenderId, sBean.getCompanyId(),3,""));
                                    modelMap.addAttribute("isChallanConfigure", eventBidSubmissionService.isChallanConfigure(abcUtility.getSessionClientId(request)));
                                }
                        }
                        else
                        {
                            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_pcfDocs_upload");
                            retVal="etender/bidder/tenderlisting/0";
                            retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                        }
                        //@Jaynam
                        List<Object[]> lstQADetails = tenderCommonService.getTenderFields(tenderId, "isQuestionAnswer,questionAnswerStartDate,questionAnswerEndDate,createdBy");
                        boolean isQaAllowed=questionAnswerService.getIsQaAllowed(3,tenderId,abcUtility.getSessionUserId(request),abcUtility.getSessionClientId(request),abcUtility.getSessionUserTypeId(request),lstQADetails,abcUtility.getSessionUserDetailId(request),false,modelMap);
                        modelMap.addAttribute("isQaAllowed", isQaAllowed);
                    }
                	 boolean isAPOAllow=false;
                     boolean isPOAllow=false;
                     boolean isPOPaymentTab = false;
                     List<Object[]> listCMS=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
                     if (listCMS != null) {
                         for (int i = 0; i < listCMS.size(); i++) {
                         	if(listCMS.get(i)[0].toString().equalsIgnoreCase("12")){
                         		isAPOAllow=true;                		 
                             }
                         	if(listCMS.get(i)[0].toString().equalsIgnoreCase("13")){
                         		isPOAllow=true;                		 
                             }
                         }
                     }
                    List<Object[]> list = invoiceDocServie.getPOListForPayment(tenderId, abcUtility.getSessionClientId(request), loginService.getCompanyId(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request)));
                    for (Object[] lst : list) {
                        Integer.parseInt(lst[0].toString());
                        if (Integer.parseInt(lst[1].toString()) == 1 || Integer.parseInt(lst[1].toString()) == 3) {
                            isPOPaymentTab = true;
                        }
                    }
                    boolean isRCIClient = false;
                    isRCIClient = commonService.isRCIClient(rciClientIds, abcUtility.getSessionClientId(request));
                    if (isRCIClient) {
                        List<Object[]> listInvoice = invoiceDocServie.getPOListForPayment(tenderId, abcUtility.getSessionClientId(request), loginService.getCompanyId(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request)));
                        for (Object[] lst : listInvoice) {
                            Integer.parseInt(lst[0].toString());
                            if (Integer.parseInt(lst[1].toString()) == 1 || Integer.parseInt(lst[1].toString()) == 3) {
                                isPOPaymentTab = true;
                            }
                        }
                    }
                     modelMap.addAttribute("isRCIClient", isRCIClient);
                     modelMap.addAttribute("isPOPaymentTab", isPOPaymentTab);
                     modelMap.addAttribute("isAPOAllow",isAPOAllow);
                     modelMap.addAttribute("isPOAllow",isPOAllow);
                     modelMap.addAttribute("isNegotiationOfflineOnline",tblTender.getIsNegotiationAllowed());
                }else{
            		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                    int brdMode=(Integer)modelMap.get("brdMode");
                    boolean isPcfUploaddedByBidder=false,isPCFEnable=true;
                        
                    if(brdMode == 1)
                    {
                    	int clientId = abcUtility.getSessionClientId(request);
                		isPCFEnable = commonService.isRCIClient(rciClientIds,clientId) == true ? false : true;
                		if(isPCFEnable){
                			if(commonService.getPCFUploadCount(tenderId, pcfUploadTender, abcUtility.getSessionUserId(request))>0)
                            {
                                isPcfUploaddedByBidder=true;
                            }
                            else
                            {
                                isPcfUploaddedByBidder=false;
                            }
                		}else{
                			isPcfUploaddedByBidder=true;
                		}
                    }
                    else
                    {
                        isPcfUploaddedByBidder=true;
                    }
                    //Added by Mitesh on 20140320 for task #Feature #16859
                    //get the bidder is invited for negogation ,added by Mitesh
                    int isNegotiationAllowd=  negotiationService.getisNegotiationAllowed(3,tenderId,tenderLinkForBidderInvite,abcUtility.getSessionUserId(request),abcUtility.getSessionClientId(request));
                    if(isNegotiationAllowd!=0 && isNegotiationAllowd==1){
                    	modelMap.addAttribute("isNegotiationAllowed",1);
                    }
                    else{
                    	modelMap.addAttribute("isNegotiationAllowed",0);
                    }
                   
                   
                    //Ended by mitesh
                    if (isPcfUploaddedByBidder) 
                    {
                            List<Object[]> lstPrebidDtls = tenderCommonService.getTenderFields(tenderId, "isPreBidMeeting,preBidMode,isEMDApplicable,isDocfeesApplicable,docFeePaymentMode,emdPaymentMode");
                            if (!lstPrebidDtls.isEmpty()) {
                                modelMap.addAttribute("isPrebidMeeting", lstPrebidDtls.get(0)[0]);
                                modelMap.addAttribute("preBidMode", lstPrebidDtls.get(0)[1]);
                                modelMap.addAttribute("isEMDApplicable", lstPrebidDtls.get(0)[2]);
                                modelMap.addAttribute("isDocfeesApplicable", lstPrebidDtls.get(0)[3]);
                                modelMap.addAttribute("docFeePaymentMode", lstPrebidDtls.get(0)[4]);
                                modelMap.addAttribute("emdPaymentMode", lstPrebidDtls.get(0)[5]);
                                SessionBean sBean =(SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
                                modelMap.addAttribute("isOnlinePaymentDone", tpslService.isOnlinePaymentDone(0, tenderId, sBean.getCompanyId(),3,""));
                                modelMap.addAttribute("isChallanConfigure", eventBidSubmissionService.isChallanConfigure(abcUtility.getSessionClientId(request)));
                            }
                    }
                    else
                    {
                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_pcfDocs_upload");
                        retVal="etender/bidder/tenderlisting/0";
                        retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                    }
                  //@Jaynam
                    List<Object[]> lstQADetails = tenderCommonService.getTenderFields(tenderId, "isQuestionAnswer,questionAnswerStartDate,questionAnswerEndDate,createdBy");
                    boolean isQaAllowed=questionAnswerService.getIsQaAllowed(3,tenderId,abcUtility.getSessionUserId(request),abcUtility.getSessionClientId(request),abcUtility.getSessionUserTypeId(request),lstQADetails,abcUtility.getSessionUserDetailId(request),false,modelMap);
                    modelMap.addAttribute("isQaAllowed", isQaAllowed);
                    boolean isAPOAllow=false;
                    boolean isPOAllow=false;
                    boolean isPOPaymentTab = false;
                    List<Object[]> listCMS=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
                    if (listCMS != null) {
                        for (int i = 0; i < listCMS.size(); i++) {
                        	if(listCMS.get(i)[0].toString().equalsIgnoreCase("12")){
                        		isAPOAllow=true;                		 
                            }
                        	if(listCMS.get(i)[0].toString().equalsIgnoreCase("13")){
                        		isPOAllow=true;                		 
                            }
                        }
                    }
                    boolean isRCIClient = false;
                    isRCIClient = commonService.isRCIClient(rciClientIds,abcUtility.getSessionClientId(request));
                    if(isRCIClient){
                    List<Object[]> listInvoice = invoiceDocServie.getPOListForPayment(tenderId, abcUtility.getSessionClientId(request), loginService.getCompanyId(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request)));
                        for (Object[] lst : listInvoice) {
                        Integer.parseInt(lst[0].toString());
                            if (Integer.parseInt(lst[1].toString()) == 1 || Integer.parseInt(lst[1].toString()) == 3) {
                            isPOPaymentTab = true;
                            }
                        }
                    }
                    modelMap.addAttribute("isRCIClient", isRCIClient);
                    modelMap.addAttribute("isPOPaymentTab", isPOPaymentTab);
                    modelMap.addAttribute("isAPOAllow",isAPOAllow);
                    modelMap.addAttribute("isPOAllow",isPOAllow);
                    modelMap.addAttribute("isNegotiationOfflineOnline",tblTender.getIsNegotiationAllowed());
                }
                SessionBean sBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
                int companyId = sBean.getCompanyId();
                boolean isSecondaryPartner=tenderCommonService.isSecondaryPartner(tenderId,companyId)>0 ? true : false;
                modelMap.addAttribute("isSecondaryPartner", isSecondaryPartner);
                modelMap.addAttribute("bidderNotificationExist",false); 
                if(!isSecondaryPartner){
                    List<Object[]> listNotification=tenderOpenService.getBidderNofiticationHistory(tenderId,abcUtility.getSessionUserId(request));
                    if (listNotification != null && !listNotification.isEmpty() && listNotification.size()>0) {
                 	   modelMap.addAttribute("bidderNotificationExist",true);
                    }
                }
                Date currentDate= commonService.getServerDateTime();
                Date submissionStartDate= tblTender.getSubmissionStartDate();
                modelMap.addAttribute("isCommunicationAllowed",currentDate.after(submissionStartDate));
                modelMap.addAttribute("isRestofEventMoneyCofigured",tenderCommonService.isRestofEventCongfigured(tenderId, companyId, 9, 2));
                /*** --- For CR Id : 51268 and PT : 51630 Start --- ***/
                modelMap.addAttribute("isResultShow",true);
                
                boolean isReporShare =false;
                if(tabId == TAB_RESULT){
                	List<TblShareReport> shareReport = tblShareReportDao.findTblShareReport("tblTender.tenderId",Operation_enum.EQ,tenderId,"isActive",Operation_enum.EQ,1);
                	isReporShare = (!shareReport.isEmpty())?(shareReport.get(0).getShareReport() == 4 && !eventBidSubmissionService.isTenderBidConfirmation(tenderId, companyId)? true: false):false;
                	modelMap.addAttribute("isOnlyViewResult",isReporShare);
                }else{
                	modelMap.addAttribute("isOnlyViewResult",isReporShare);
                }
                
                if(tblTender.getIsResultSharingDurationRequired()==1){
                	boolean isResultSharingDone = tenderCommonService.isResultShareDone(tenderId);
                	if((tblTender.getResultSharing()==1)){
                	Calendar calDurationDate = Calendar.getInstance();
                	calDurationDate.setTime(tblTender.getOpeningDate());
                	calDurationDate.add(Calendar.DAY_OF_MONTH, tblTender.getResultSharingDuration());
					if (calDurationDate.getTime().before(currentDate)) {
			        	modelMap.addAttribute("isResultShow",false);
			         } 
                	}
                	else if(tblTender.getResultSharing()==2 && isResultSharingDone){
                		Date createdOn = tblShareReportDao.findTblShareReport("tblTender.tenderId",Operation_enum.EQ,tenderId,"isActive",Operation_enum.EQ,1).get(0).getCreatedOn();
                    	Calendar calDurationDate = Calendar.getInstance();
                    	calDurationDate.setTime(createdOn);
                    	calDurationDate.add(Calendar.DAY_OF_MONTH, tblTender.getResultSharingDuration());
    					if (calDurationDate.getTime().before(currentDate)) {
    			        	modelMap.addAttribute("isResultShow",false);
    			         } 
                	}
                  }
                /*** --- For CR Id : 51268 and PT : 51630 End --- ***/
                
                boolean isContractTab = false;  
                List<Object[]> listContracts=commonService.getContractListForBidder( abcUtility.getSessionUserId(request),tenderId);
                List<Object[]> getdefaultConfigList=clientService.getEventTypeIdForDefaultConfg(abcUtility.getSessionClientId(request),13);
                if(listContracts!=null && !listContracts.isEmpty() && getdefaultConfigList!=null && !getdefaultConfigList.isEmpty() ) {
              	   isContractTab = true;
                }
                modelMap.addAttribute("isContractTab",isContractTab); 
                
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), biddingEventDashboardLinkId, getBiddingTenderDashboard, tenderId, 0);
        }
        return retVal;
    }

    /**
     * @param tenderId
     * @param tabId
     * @param request
     * @param modelMap
     * @return ajax jsp
     */
    @SuppressWarnings("unused")
	@RequestMapping(value = "/biddingtenderdashboardcontent", method = RequestMethod.POST)
    public String biddingTenderDashboardContent(@RequestParam(HIDDEN_TENDER_ID) int tenderId, @RequestParam("txtTabId") int tabId,
            HttpServletRequest request, ModelMap modelMap) {
        String auditMsg = "";
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                boolean isDocUploaded = false;
                boolean isConsortium = false;
                boolean isCompanyMapped = true;
                int formStatus = -1;
                int isRebateForm = 0;

                SessionBean sBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
                int companyId = sBean.getCompanyId();
                int userId = sBean.getUserId();

                List<Object[]> lstTenderBidderDocs = tenderCommonService.getTenderBidderDocs(tenderId, companyId);
                List<Object[]> lstTndrSubManDocsDtls = tenderCommonService.getSubEndDtAndManDocs(tenderId);
                boolean isDocsMandatory = tenderCommonService.isTenderFormDocsMandatory(tenderId);
                TblTender tblTender = tenderCommonService.getTenderById(tenderId);
                modelMap.addAttribute("tblTender", tblTender);
                
                ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        		TblClientPGBankMapping tblClientPGBankMapping=clientService.getTblClientPGBankMapping(clientBean.getClientId(),1);
				int pgId=tblClientPGBankMapping!=null?tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId():0;
				modelMap.addAttribute("userTypeId", sBean.getUserTypeId());
				modelMap.addAttribute("pgId",pgId);
				int bankId=tblClientPGBankMapping!=null?tblClientPGBankMapping.getTblBankMaster().getBankId():0;
				modelMap.addAttribute("bankId",bankId);
				modelMap.addAttribute("isDcVerificationRequired",clientBean.getIsDcVerificationRequired());
				if(clientBean.getIsDcVerificationRequired() == 1)
				{
					modelMap.addAttribute("isDcVerificationRequired",true);
				}
				else
				{
					modelMap.addAttribute("isDcVerificationRequired",false);
				}
                int tenderMode = tblTender.getTenderMode();
                int itemwiseWinner = tblTender.getIsItemwiseWinner();
                int isCertRequired = tblTender.getIsCertRequired(); 
                int isFormConfirmationReq = tblTender.getIsFormConfirmationReq();
                if(tblTender.getTblEventType().getEventTypeId() == 5 && tblTender.getTenderMode() == 2){
                    isCompanyMapped = eventBidderMapService.isCompanyMapped(tenderId, companyId,tblTender.getTenderResult());
                }
                    
                if (!lstTndrSubManDocsDtls.isEmpty()) {
                    isRebateForm = (Integer) lstTndrSubManDocsDtls.get(0)[4];
                    if ("1".equals(lstTndrSubManDocsDtls.get(0)[2].toString())) {
                        isConsortium = tenderCommonService.getConsortiumPartnerType(tenderId, companyId)[1] == 3 ? true : false;
                    }
                    modelMap.addAttribute("submissionEndDtLapse", lstTndrSubManDocsDtls.get(0)[0]);
                    modelMap.addAttribute("isBidWithdrawal", lstTndrSubManDocsDtls.get(0)[3]);
                }
                if (!lstTenderBidderDocs.isEmpty()) {
                    isDocUploaded = true;
                    modelMap.addAttribute("lstTenderBidderDocs", lstTenderBidderDocs);
                }
                
                if(isCertRequired!=0){
                      if(abcUtility.getSessionCertId(request)!=null){
                            String[] certIds = abcUtility.getSessionCertId(request).split(",");
                            modelMap.addAttribute("bidpkey", commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                            if(certIds.length==2){
                                modelMap.addAttribute("bidpkey2", commonService.getPublicKeyById(Integer.parseInt(certIds[1])));
                            }
                      }
    	        }
                // heeral : code for listing of mandatry document in prepare bid and final submission tab
                if(tabId==5 || tabId == 6){
                    if(isDocUploaded){
                        List<Integer> documentId = new ArrayList<Integer>();
                        int dId=0;
                        for (Object[] objects : lstTenderBidderDocs) {
                            if((Integer)objects[6] != 0 && (Integer)objects[6]!=dId){
                                documentId.add((Integer)objects[6]);
                            }
                            dId = (Integer)objects[6];
                        }
                        if(documentId.size()>0) {
                            Map<String,String> MandatoryFormDoc = new HashMap<String, String>();
                            Map<Integer,String> MandatoryFormDoc1 = new HashMap<Integer, String>();
                            for (Object[] formDocRemark : lstTenderBidderDocs) {
                                  String filePath = "";
                                  File fp = null;
                                  int docId = (Integer)formDocRemark[6];
                                      if(MandatoryFormDoc.get(docId+"_"+formDocRemark[0])==null){
                                          MandatoryFormDoc.put(docId+"_"+formDocRemark[0], formDocRemark[5]+"#"+(Integer)formDocRemark[3]+"#"+(Integer)formDocRemark[0]);
                                      }else{
                                          MandatoryFormDoc.put(docId+"_"+formDocRemark[0], MandatoryFormDoc.get(docId+"_"+formDocRemark[0])+","+formDocRemark[5]+"#"+(Integer)formDocRemark[3]+"#"+(Integer)formDocRemark[0]);
                                      }
                                      
                                      if(MandatoryFormDoc1.get(docId)==null){
                                          filePath = docUploadPath.concat((String)formDocRemark[4]);
                                          fp = new File(filePath);
                                          fp = abcUtility.CheckDirExist(fp);
                                          if(fp.exists()){
                                                MandatoryFormDoc1.put(docId, formDocRemark[5]+"#"+(Integer)formDocRemark[3]+"#"+(Integer)formDocRemark[0]+"#"+"y");
                                          }else{
                                                MandatoryFormDoc1.put(docId, formDocRemark[5]+"#"+(Integer)formDocRemark[3]+"#"+(Integer)formDocRemark[0]+"#"+"n");
                                          }
                                      }else{
                                          //MandatoryFormDoc1.put(docId, MandatoryFormDoc1.get(docId)+","+formDocRemark[5]+"#"+(Integer)formDocRemark[3]+"#"+(Integer)formDocRemark[0]);
                                          filePath = docUploadPath.concat((String)formDocRemark[4]);
                                          fp = new File(filePath);
                                          fp = abcUtility.CheckDirExist(fp);
                                          if(fp.exists()){
                                                MandatoryFormDoc1.put(docId, MandatoryFormDoc1.get(docId)+","+formDocRemark[5]+"#"+(Integer)formDocRemark[3]+"#"+(Integer)formDocRemark[0]+"#"+"y");
                                          }else{
                                                MandatoryFormDoc1.put(docId, MandatoryFormDoc1.get(docId)+","+formDocRemark[5]+"#"+(Integer)formDocRemark[3]+"#"+(Integer)formDocRemark[0]+"#"+"n");
                                          }
                                      }
                            }
                            modelMap.addAttribute("MandatoryFormDoc", MandatoryFormDoc);
                            modelMap.addAttribute("MandatoryFormDoc1", MandatoryFormDoc1);
                        }//end of mandatory doc loop
                    }
                }
                switch (tabId) {
                    case TAB_POST_QUERY:
                        auditMsg = postajaxBiddingTenderDashboardContentPQ;
                        List<Object[]> lstPrebidObjArray = tenderCommonService.getTenderPrebidDetailByTenderId(tenderId);
                        List<TblPreBidReport> lstPrebidReportObj = prebidService.getPreBidReportByTenderId(tenderId);
                        modelMap.addAttribute("preBidObj", lstPrebidObjArray);
                        modelMap.addAttribute("currentDate", commonService.getServerDateTime());
                        modelMap.addAttribute("linkId", uploadPrebidDocLinkId);
                        modelMap.addAttribute("isReadOnly", "Y");
                        modelMap.addAttribute("isAuctionDocDownload", "Y");
                        modelMap.addAttribute("objectId", tenderId);
                        modelMap.addAttribute("cStatusDocView", 1);
                        modelMap.addAttribute("cStatusDoc", 1);
                        modelMap.addAttribute("preBidReport", lstPrebidReportObj.isEmpty() ? new TblPreBidReport() : lstPrebidReportObj.get(0));
                        break;
                    case TAB_REG_PAYMENT:
                    	modelMap.addAttribute("objectId",tenderId);
                    	modelMap.addAttribute("moduleId",3);
                        if(tenderCommonService.isSecondaryPartner(tenderId,companyId)>0){
                            //if secondary bidder than not allow to pay doc-fees and emd
                            String retVal="/etender/bidder/redirecttodashboard/"+tenderId+"/"+tabId;
                            retVal = retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                            modelMap.addAttribute("isSecondary", retVal);
                        }else{
                        	int registrationChargesMode=tblTender.getRegistrationChargesMode();
                        	
                        	int paymentId=0;
                        	auditMsg = postajaxBiddingTenderDashboardContentDF;
                        	//Object[] eventRegFeePaymentDetail = tpslService.getPaymentDetail(8, tenderId, companyId,1,3);
                        	Object[] eventRegFeePaymentDetail = tpslService.getPaymentDetail(8, tenderId, companyId,1,3,registrationChargesMode,"");
                            modelMap.addAttribute("decimalValueUpto",tblTender.getDecimalValueUpto());
                            modelMap.addAttribute("chkpaymentMode",registrationChargesMode);
                            int errCode = tenderCommonService.isEventLive(tenderId);
                            if (errCode == -1 ) {
                                modelMap.addAttribute("errCode", errCode);                        
                            }   

                            if (eventRegFeePaymentDetail == null) {
                            	if (errCode == -1 ) {
                                    modelMap.addAttribute("err_bidsub_dt", "msg_tender_fs_submissionenddt_lapse");
                                }
                            	if(commonService.checkTenderCancel(tenderId)>0){
                         			modelMap.addAttribute("isEventCancel", 1);
                             	}
                            	eventRegFeePaymentDetail = tpslService.getPaymentDetail(8, tenderId, companyId,0,3,registrationChargesMode,"");
                            	if (eventRegFeePaymentDetail != null && !"0300".equals(eventRegFeePaymentDetail[0]) && Integer.parseInt(eventRegFeePaymentDetail[registrationChargesMode==3?6:5].toString()) ==1  && registrationChargesMode!=2) {
	                            	Object[] obj=clientService.getClientFields(abcUtility.getSessionClientId(request),"paymentConfigBy,deptId");
	        	            		int paymentConfigBy=Integer.valueOf(obj[0].toString());
	        	            		int deptId=tblTender.getTblDepartment().getDeptId();
	        	            		if(paymentConfigBy==1 ){
	        	            			deptId=Integer.valueOf(obj[1].toString());
	        	            		}
	        	            		try{
	        	            		boolean isReconcilationDone = tpslService.paymentReconcilation(8, Integer.parseInt(eventRegFeePaymentDetail[registrationChargesMode==3?2:1].toString()), clientBean.getClientId(), eventRegFeePaymentDetail[registrationChargesMode==3?3:2].toString(),deptId);
	        	            		if (isReconcilationDone) {
	        	            			eventRegFeePaymentDetail = tpslService.getPaymentDetail(8, tenderId, companyId,1,3,registrationChargesMode,"");
                                    }
	        	            		}catch(Exception e){
	        	            			 exceptionHandlerService.writeLog(e);
	        	            		}
                            	}
                            }
                            if (eventRegFeePaymentDetail != null && "0300".equals(eventRegFeePaymentDetail[0])) {
                            	if("6".equals(registrationChargesMode!=3?eventRegFeePaymentDetail[5].toString():eventRegFeePaymentDetail[6].toString())){
                                    Object[] exemptionCertificate =  tpslService.getExemptionCertificateByPaymentId(Integer.parseInt(registrationChargesMode==3?eventRegFeePaymentDetail[2].toString():eventRegFeePaymentDetail[1].toString()));
                                    TblExemptionCertConf tblExemptionCertConf = (TblExemptionCertConf) exemptionCertificate[0];
                                    modelMap.addAttribute("tblExemptionCertConf", tblExemptionCertConf);
                                    modelMap.addAttribute("docList",tpslService.getExemptionCertificateDocs(tblExemptionCertConf.getExemptionCertConfId()));
                            	}else{
                            		modelMap.addAttribute("paymentId", Integer.parseInt(eventRegFeePaymentDetail[registrationChargesMode==3?2:1].toString()));
	                            	 int isGSTRequired = (Integer)tenderCommonService.getTenderField(tenderId, "isGSTRequired");
	                                 if(commonService.getCountryIdByCompanyId(companyId)!=countryId){
	                                 	isGSTRequired = 0;
	                                 }
	                                 modelMap.addAttribute("isGSTRequired", isGSTRequired);
	                                 if(isGSTRequired==1){
		                                    tenderCommonService.getNetAmountAndTax(modelMap,abcUtility.getSessionClientId(request),userId,8,new BigDecimal(registrationChargesMode!=3?eventRegFeePaymentDetail[3].toString():eventRegFeePaymentDetail[4].toString()),0,0);
		                             }
                            	}
                                    modelMap.addAttribute("paymentDetail", eventRegFeePaymentDetail);
                            } else {
                                    modelMap.addAttribute("certTypeList", abcUtility.convert(tenderBriefcaseService.getExemptionCertificateType(abcUtility.getSessionClientId(request))));
                                    if(registrationChargesMode!=2){
                                    	List<SelectItem> payTypeList  = null;
                                    	payTypeList = commonService.getPaymentType(1,abcUtility.getSessionClientId(request),8,tenderId);
                                    	
                                    	modelMap.addAttribute("payTypeList", payTypeList);
                                    	modelMap.addAttribute("chRDModeOfPayment",!payTypeList.isEmpty()?payTypeList.get(0).getValue().toString():0);
                                    }else{
                                    	List<SelectItem> payTypeList  = null;
                                    	payTypeList = commonService.getPaymentType(2,abcUtility.getSessionClientId(request),8,tenderId);
//                                    	TblClientPayment tblClientPayment = clientService.getClientPaymentExemptionByclientId(abcUtility.getSessionClientId(request));
//                                    	if(tblClientPayment!=null){
//                                    		payTypeList.add(new SelectItem("Exemption Certificate",6));
//                                    	}
                                    	modelMap.addAttribute("payTypeList", payTypeList);
                                    	modelMap.addAttribute("chRDModeOfPayment",!payTypeList.isEmpty()?payTypeList.get(0).getValue().toString():0);
                                    }
                                    if(registrationChargesMode==3){
                                    	List<SelectItem> payModeList = new ArrayList<SelectItem>();
                                    	payModeList.add(new SelectItem("Online",1));
                                    	payModeList.add(new SelectItem("Offline",2));
                    					modelMap.addAttribute("payModeList", payModeList);
                    					
                                    }
                                    if(eventRegFeePaymentDetail != null && (registrationChargesMode==2 || registrationChargesMode==3))
                                    {
                                    	if(registrationChargesMode==2){
                                    		paymentId = Integer.parseInt(eventRegFeePaymentDetail[1].toString());
                                    	}else{
                                    		
                                    		paymentId = Integer.parseInt(eventRegFeePaymentDetail[2].toString());	
                                    		modelMap.addAttribute("chRDModeOfPayment",1);
                                    	}
                                    	modelMap.addAttribute("paymentId",paymentId);
                                    	TblOfflinePayment tblofflinePayment=tpslService.getOfflinePaymentDetail(paymentId);
                                    	TblPayment tblPayment  = tpslService.getPaymentDetail(paymentId);
                                    	  if(tblPayment!=null){
                                          	modelMap.addAttribute("chkpaymentMode",registrationChargesMode);
                                          	if(tblPayment.getCstatus()==1){
                                          	modelMap.addAttribute("payTypeList", commonService.getPaymentType(1,abcUtility.getSessionClientId(request),8,tenderId));
                                          	modelMap.addAttribute("chRDModeOfPayment",tblPayment.getTblPaymentType().getPaymentTypeId());
                                          	}
                                          }
                                    	if(tblofflinePayment!=null && tblPayment!=null){
                                    		 boolean checkStatus = tblPayment.getCstatus()==0?true:false;
                                             if (tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && checkStatus ) {
                                             		modelMap.addAttribute("offlinePayment",tblofflinePayment);
                                             		List<SelectItem> payTypeList  = null;
                                             		payTypeList = commonService.getPaymentType(2,abcUtility.getSessionClientId(request),8,tenderId);
                                             		modelMap.addAttribute("payTypeList", payTypeList);
                                             		modelMap.addAttribute("chRDModeOfPayment",tblPayment.getTblPaymentType().getPaymentTypeId());
                                             }else
                                             {
                                        	 modelMap.addAttribute("paymentDetail", eventRegFeePaymentDetail);
                                        	 modelMap.addAttribute("chkpaymentMode",registrationChargesMode);
                                             }
                                             if("6".equals(registrationChargesMode==3 ? eventRegFeePaymentDetail[6].toString() : eventRegFeePaymentDetail[5].toString())){
                                                 Object[] exemptionCertificate =  tpslService.getExemptionCertificateByPaymentId(registrationChargesMode==3 ? Integer.parseInt(eventRegFeePaymentDetail[2].toString()) : Integer.parseInt(eventRegFeePaymentDetail[1].toString()));
                                                 TblExemptionCertConf tblExemptionCertConf = (TblExemptionCertConf) exemptionCertificate[0];
                                                 modelMap.addAttribute("tblExemptionCertConf", tblExemptionCertConf);
                                                 modelMap.addAttribute("docList",tpslService.getExemptionCertificateDocs(tblExemptionCertConf.getExemptionCertConfId()));
                                        	 }
                                             modelMap.addAttribute("linkId", linkBidPreRegChargesOfflinePayment);
                                             modelMap.addAttribute("chkpaymentMode",registrationChargesMode);
                                 			 modelMap.addAttribute("remark",tblPayment.getRemark());
                                 			 modelMap.addAttribute("offlinepaymentDetail", tblofflinePayment);
                                    	}
                                    	List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(regOfflinePaymentEventId, abcUtility.getSessionClientId(request));
                                    	int allowedSize = 0;
                                        StringBuilder allowedExt = new StringBuilder();
                                    	allowedSize = lstDocUploadConf.get(0).getMaxSize();
                                    	allowedExt.append(lstDocUploadConf.get(0).getType());
                                    	modelMap.addAttribute("allowedExt", allowedExt);
                                        modelMap.addAttribute("allowedSize", allowedSize/1024);
                                    }
                                    modelMap.addAttribute("isRegistrationCharges",tblTender.getIsRegistrationCharges());
                                    String amount="";
                                    String uniqueId = "";
                                    List <Object[]> amountList=  tenderCommonService.getTenderPaymentAmount(tenderId,8,0,companyId,0);
                                    if(amountList != null && !amountList.isEmpty()){
                                        for (int i = 0; i < amountList.size(); i++) {
                                        	amount += amountList.get(i)[0].toString() + ",";
                                        }
                                    }
                                    BigDecimal netAmount = new BigDecimal("0.00");
                                    if(amount.length()>0){
        	                            String gstAmount = amount.substring(0, amount.length()-1);
        	                            String amountArray[] = gstAmount.split(",",gstAmount.length());
        	                            for(int i=0;i<amountArray.length;i++){
        	                            	netAmount = netAmount.add(new BigDecimal(amountArray[i]));
        	                            }
                                    }
                                    int isGSTRequired = (Integer)tenderCommonService.getTenderField(tenderId, "isGSTRequired");
                                    if(commonService.getCountryIdByCompanyId(companyId)!=countryId){
                                    	isGSTRequired = 0;
                                    }
                                    modelMap.addAttribute("isGSTRequired", isGSTRequired);
                                    if(isGSTRequired==1){
	                                    if(amountList!=null && !amountList.isEmpty()){
	                                    	tenderCommonService.getNetAmountAndTax(modelMap,abcUtility.getSessionClientId(request),userId,8,netAmount,0,0);
	                                    }
                                    }
                                    /*else if(docFeePaymentDetail!=null){
                                    	if(docFeesMode==3){
                                    		netAmount = new BigDecimal("0.00");
                                    		netAmount = netAmount.add(new BigDecimal(docFeePaymentDetail[4].toString()));
                                    		tenderCommonService.getNetAmountAndTax(modelMap,abcUtility.getSessionClientId(request),userId,1,netAmount,isDocfeesByBidder,1);
                                    	}else if(docFeesMode!=3){
                                    		netAmount = new BigDecimal("0.00");
                                    		netAmount = netAmount.add(new BigDecimal(docFeePaymentDetail[3].toString()));
                                    		tenderCommonService.getNetAmountAndTax(modelMap,abcUtility.getSessionClientId(request),userId,1,netAmount,isDocfeesByBidder,1);
                                    	}
                                    }*/
                                    modelMap.addAttribute("amountList",amount);
                                    modelMap.addAttribute("companyId",companyId);
                            }
                        }
                        break;
                    case TAB_DECLARATION:
                        auditMsg = postajaxBiddingTenderDashboardContentDEC;
                        String languageId = WebUtils.getCookie(request, "locale").getValue();
                        int eventTypeId = eventBidSubmissionService.getEventTypeId(tenderId);
                        boolean isRepeated = eventBidSubmissionService.isTenderIdRepeated(tenderId, abcUtility.getSessionUserId(request));
                        List<Object[]> condition = eventBidSubmissionService.getTenderBidConfirmForm(tenderId, modelMap, abcUtility.getSessionClientId(request), languageId, eventTypeId);
                        boolean isTenderBidConfirmation = eventBidSubmissionService.isTenderBidConfirmation(tenderId, companyId);
                        modelMap.addAttribute("isTenderBidConfirmation",isTenderBidConfirmation);
                        List<SelectItem> currencyList = null;
                        int biddingTypeId = eventBidSubmissionService.getBiddingType(tenderId);
                        String selectedCurrency = "";
                        boolean isFinalSubmissionDoneEventWise = eventBidSubmissionService.isFinalSubmissionDone(tenderId, companyId);
                        boolean isTenderArchive = eventBidSubmissionService.isTenderArchive(tenderId); 
                        modelMap.addAttribute("isFinalSubmissionDoneEventWise",isFinalSubmissionDoneEventWise);
                        modelMap.addAttribute("isTenderArchive",isTenderArchive);
                        if (biddingTypeId == 2) {
                           currencyList = abcUtility.convert(eventBidSubmissionService.getCurrencies(tenderId,companyId,false));
                           if(isRepeated){
                        	   selectedCurrency=eventBidSubmissionService.getCurrencies(tenderId, companyId, true).get(0)[1].toString();    //tenderFormService.getBidderCurrency(tenderId, companyId).get(0)[0].toString();
                           }
                           
                        }
                        String conditionForBidder = null;
                        int clientBidTermId = 0;
                        for (Object[] object : condition) {
                            conditionForBidder = object[1].toString();
                            clientBidTermId = (Integer) object[0];
                        }
                        if (!isRepeated && tblTender.getCstatus() != 2) {
                            int errCode = tenderCommonService.isEventLive(tenderId);
                            int docfeeErr = tenderCommonService.isDocumentDateLive(tenderId);
                            if(docfeeErr == 0 &&(null !=tblTender.getDocumentStartDate() && null != tblTender.getDocumentEndDate())){
                            	modelMap.addAttribute("docfeeErr", "msg_tender_err_msg_docsub_dt_notarrived");	
                            }else if(errCode ==-1 && docfeeErr == -1) {
                            	modelMap.addAttribute("err_bidsub_dt", "msg_tender_fs_submissionenddt_lapse");
                            }else if(errCode ==-1 && docfeeErr == 0) {
                            	modelMap.addAttribute("err_bidsub_dt", "msg_tender_fs_submissionenddt_lapse");
                            }
                        }else if(!isRepeated && tblTender.getCstatus() == 2){
                        	modelMap.addAttribute("err_bidsub_dt", "msg_event_cancel");
                        }

                        if(clientBidTermId==0){
                        	modelMap.addAttribute("err_iagree_config_pending", "msg_ten_iagree_config_pending");
                        }
                        modelMap.addAttribute("conditionForBidder", conditionForBidder);
                        modelMap.addAttribute("clientBidTermId", clientBidTermId);
                        modelMap.put("listOfCurrency", currencyList);
                        modelMap.put("isRepeated", isRepeated);
                        modelMap.put("selectedCurrency", selectedCurrency);
                        modelMap.put("biddingType", biddingTypeId);
                        modelMap.put("isAtleastOneFormApproved",tenderFormService.getApprovedFormCount(tenderId));
                        modelMap.put("isEventLive",tenderCommonService.isEventLive(tenderId)==1);
                        int corrigendumId = tenderCorrigendumService.getCorrigendumId(tenderId);
                        modelMap.addAttribute("isCorrigendumViewHistoryPending", tenderCorrigendumService.isCorrigendumViewHistoryPending(tenderId,corrigendumId,companyId));
                        modelMap.addAttribute("corrigendumId",corrigendumId);
                        tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                       // List<Object[]> regretBidderList=eventBidSubmissionService.getRegretBidder(tenderId);
                        TblTenderBidRegression regretBidderList=eventBidSubmissionService.getRegretBidderDetail(userId,tenderId);
                        if(regretBidderList!=null){
                        	Date regretedDate=regretBidderList.getCreatedOn();
                        	modelMap.addAttribute("regretedDate", regretedDate);
                        }
                        boolean isBidderRegretted = eventBidSubmissionService.isBidderRegretted(userId,tenderId);
                        modelMap.addAttribute("isBidderRegretted", isBidderRegretted);
                       // TblTender tblTender=new TblTender(tenderId);
                       // int isRegretAllow= tblTender.getIsRegretAllow();
                        int isRegretAllow= tblTender.getIsItemwiseRegretAllowed();
                        // boolean isRegretAllow = eventBidSubmissionService.isRegretAllow(tenderId);
                        modelMap.addAttribute("isRegretAllow", isRegretAllow);
                        boolean isBidWithdrawBidder = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
                        modelMap.addAttribute("isBidWithdrawBidder", isBidWithdrawBidder);
                        List<Object[]> consortiumPartnerDetail =eventBidSubmissionService.getPartnerType(tenderId,userId);
    	    			for(Object o : consortiumPartnerDetail) {
    	    				Object[] obj = (Object[])o;
    	    				int partnerType = (Byte) obj[2];
    	    				if(partnerType==3){
    	    				modelMap.addAttribute("partnerType", partnerType);
    	    				}else{
    	    					modelMap.addAttribute("partnerType", partnerType);
    	    				}
    	    				
    	    			    }
                        break;

                    case TAB_DOC_FEES:
                    	modelMap.addAttribute("objectId",tenderId);
                    	modelMap.addAttribute("moduleId",3);
                    	modelMap.addAttribute("isexcemptionCert",commonService.isexcemptionCert(abcUtility.getSessionClientId(request)));
                        if(tenderCommonService.isSecondaryPartner(tenderId,companyId)>0){
                            //if secondary bidder than not allow to pay doc-fees and emd
                            String retVal="/etender/bidder/redirecttodashboard/"+tenderId+"/"+tabId;
                            retVal = retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                            modelMap.addAttribute("isSecondary", retVal);
                        }else{
                        	int docFeesMode = tblTender.getDocFeePaymentMode();
                        	int isDocfeesByBidder = tblTender.getIsDocumentFeeByBidder();
                        	int paymentId=0;
                            auditMsg = postajaxBiddingTenderDashboardContentDF;
                            Object[] docFeePaymentDetail=null;
                            List <Object[]> amountList= tenderCommonService.getTenderPaymentAmount(tenderId,1,tblTender.getIsDocumentFeeByBidder(),companyId,0);
                            String amount="";
                            String uniqueId = "";
                            if(amountList != null && !amountList.isEmpty()){
                                for (int i = 0; i < amountList.size(); i++) {
                                	amount += amountList.get(i)[0].toString() + ",";
                                	if(isDocfeesByBidder!=0){
                                		uniqueId = amountList.get(i)[1].toString();
                                	}
                                }
                            }
                            BigDecimal netAmount = new BigDecimal("0.00");
                            if(amount.length()>0){
	                            String gstAmount = amount.substring(0, amount.length()-1);
	                            String amountArray[] = gstAmount.split(",",gstAmount.length());
	                            for(int i=0;i<amountArray.length;i++){
	                            	netAmount = netAmount.add(new BigDecimal(amountArray[i]));
	                            }
                            }
                            int isGSTRequired = (Integer)tenderCommonService.getTenderField(tenderId, "isGSTRequired");
                            if(commonService.getCountryIdByCompanyId(companyId)!=countryId){
                            	isGSTRequired = 0;
                            }
                            modelMap.addAttribute("isGSTRequired", isGSTRequired);
                            docFeePaymentDetail = tpslService.getPaymentDetail(1, tenderId, companyId,1,3,docFeesMode,uniqueId);
                            modelMap.addAttribute("decimalValueUpto",tblTender.getDecimalValueUpto());
                            modelMap.addAttribute("chkpaymentMode",docFeesMode);
                            int errCode = tenderCommonService.isEventLive(tenderId);
                            
                            int docDownloadErr = tenderCommonService.isDocumentDateLive(tenderId);
                            int docfeeErr = tenderCommonService.checkDocumentDownloadDate(tenderId);
                            if (errCode == 0 && docDownloadErr!=0 && docDownloadErr!=-1) {
                                modelMap.addAttribute("errCode", errCode);                        
                            }   
                            else if((docDownloadErr==0 || docDownloadErr==-1) && errCode==0 ){
                              	 modelMap.addAttribute("docDownloadErr", docDownloadErr);
                            }
                            
                            Object[] obj=clientService.getClientFields(abcUtility.getSessionClientId(request),"paymentConfigBy,deptId");
    	            		int paymentConfigBy=Integer.valueOf(obj[0].toString());
    	            		int deptId=tblTender.getTblDepartment().getDeptId();
    	            		if(paymentConfigBy==1 ){
    	            			deptId=Integer.valueOf(obj[1].toString());
    	            		}
    	            		
    	            		List<Object[]> PaymentDetails = tpslService.getPaymentDetails(1, tenderId, companyId, -1, 3, docFeesMode,uniqueId);
    	            		boolean isPaymentDetailsUpdate=false;
    	            		if(PaymentDetails!=null){
    	            			if(!PaymentDetails.isEmpty()){
    	            				paymentId=Integer.parseInt(PaymentDetails.get(0)[docFeesMode==3?2:1].toString());
    	            				if(null != PaymentDetails.get(0)[0]){
    	            					String paymentCode = PaymentDetails.get(0)[0].toString();
    	            					modelMap.addAttribute("paymentCode",paymentCode);
    	            				}else{
    	            					modelMap.addAttribute("paymentCode","not_set");
    	            				}
    	            				modelMap.addAttribute("paymentId",paymentId);
    	            			}
    	            			if(!tpslService.isOnlinePaymentDone(1, tenderId, companyId, 3, "")){
    	            				
    	            				for(Object[] paymentDetail : PaymentDetails){
	        	            			if(!"0399".equals(paymentDetail[0]) && !"0300".equals(paymentDetail[0]) && Integer.parseInt(paymentDetail[docFeesMode==3?6:5].toString()) ==1 && Integer.parseInt(paymentDetail[docFeesMode==3?9:8].toString())==0 || (null == (paymentDetail[0])&& Integer.parseInt(paymentDetail[docFeesMode==3?9:8].toString())==0)){//If Payment is not Faild/Success ,  paymentType is Payment Gateway and cstatus is 0
	        	            				isPaymentDetailsUpdate=true;
											try{
												boolean isReconcilationDone = tpslService.paymentReconcilation(1, docFeesMode==3 ? Integer.parseInt(paymentDetail[2].toString()): Integer.parseInt(paymentDetail[1].toString()), clientBean.getClientId(), docFeesMode==3 ? paymentDetail[3].toString(): paymentDetail[2].toString(),deptId);
	        	            					if (isReconcilationDone) {
		                                        	 amount = "";
		                                        	 amountList= tenderCommonService.getTenderPaymentAmount(tenderId,1,tblTender.getIsDocumentFeeByBidder(),companyId,0);
		                                        	 if(amountList != null && !amountList.isEmpty()){
		                                                for (int i = 0; i < amountList.size(); i++) {
		                                                	amount += amountList.get(i)[0].toString() + ",";
		                                                	if(isDocfeesByBidder!=0){
		                                                		uniqueId = amountList.get(i)[1].toString();
		                                                	}
		                                                }
		                                            }
		                                                 docFeePaymentDetail = tpslService.getPaymentDetail(1, tenderId, companyId,1,3,docFeesMode,uniqueId);
		                                         }
											 }catch(Exception e){
		        	            			 exceptionHandlerService.writeLog(e);
											}
	        	            			}
	        	            		}
    	            				
    	            			}
    	            		}
    	            		if(isPaymentDetailsUpdate){
    	            		PaymentDetails = tpslService.getPaymentDetails(1, tenderId, companyId, -1, 3, docFeesMode,uniqueId);
    	            		}
    	            		modelMap.addAttribute("PaymentDetails", PaymentDetails);
    	            		if(docfeeErr == -2){
                        		modelMap.addAttribute("err_docfee_dt", "msg_tender_fs_docdownloadenddt_lapse");
                        	}
                            if (docFeePaymentDetail == null) {
                            	if (errCode == -1 ) {
                                    modelMap.addAttribute("err_bidsub_dt", "msg_tender_fs_submissionenddt_lapse");
                                }
                            	if(commonService.checkTenderCancel(tenderId)>0){
                         			modelMap.addAttribute("isEventCancel", 1);
                             	}
//                            	docFeePaymentDetail = tpslService.getPaymentDetail(1, tenderId, companyId,0,3,docFeesMode,uniqueId);
//                            	if (docFeePaymentDetail != null && !"0300".equals(docFeePaymentDetail[0])) {
//	                            	
//	        	            		/* Priyanka Work starts here*/
//	        	            		if(bankId ==2 || bankId == 4)
//	        	            		{
//	        	            			Object[] docFeeeRefundAccountDetail =  tpslService.getRefundAccountDetail(abcUtility.getSessionClientId(request), companyId);
//	                                    if (docFeeeRefundAccountDetail != null) {
//	                                    	  modelMap.addAttribute("docFeeeRefundAccountDetail", docFeeeRefundAccountDetail);
//	                                    }
//	        	            		}
//	                                	/* Priyanka Work ends here*/
//                                    
//                            	}
                            }
                            if (docFeePaymentDetail != null && "0300".equals(docFeePaymentDetail[0])) {
                                    if("6".equals(docFeesMode==3 ? docFeePaymentDetail[6].toString() : docFeePaymentDetail[5].toString())){
                                            Object[] exemptionCertificate =  tpslService.getExemptionCertificateByPaymentId(Integer.parseInt(docFeesMode==3 ? docFeePaymentDetail[2].toString() : docFeePaymentDetail[1].toString()));
                                            TblExemptionCertConf tblExemptionCertConf = (TblExemptionCertConf) exemptionCertificate[0];
                                            modelMap.addAttribute("tblExemptionCertConf", tblExemptionCertConf);
                                            modelMap.addAttribute("docList",tpslService.getExemptionCertificateDocs(tblExemptionCertConf.getExemptionCertConfId()));
                                    }
                                    modelMap.addAttribute("paymentDetail", docFeePaymentDetail);
                            } else {
                                    modelMap.addAttribute("certTypeList", abcUtility.convert(tenderBriefcaseService.getExemptionCertificateType(abcUtility.getSessionClientId(request))));
                                    if(docFeesMode!=2){
                                    	List<SelectItem> payTypeList  = null;
                                    	payTypeList = commonService.getPaymentType(1,abcUtility.getSessionClientId(request),1,tenderId);
                                    	
                                    	modelMap.addAttribute("payTypeList", payTypeList);
                                    	modelMap.addAttribute("chRDModeOfPayment",!payTypeList.isEmpty()?payTypeList.get(0).getValue().toString():0);
                                    }else{
                                    	List<SelectItem> payTypeList  = null;
                                    	payTypeList = commonService.getPaymentType(2,abcUtility.getSessionClientId(request),1,tenderId);
//                                    	TblClientPayment tblClientPayment = clientService.getClientPaymentExemptionByclientId(abcUtility.getSessionClientId(request));
//                                    	if(tblClientPayment!=null){
//                                    		payTypeList.add(new SelectItem("Exemption Certificate",6));
//                                    	}
                                    	modelMap.addAttribute("payTypeList", payTypeList);
                                    	modelMap.addAttribute("chRDModeOfPayment",!payTypeList.isEmpty()?payTypeList.get(0).getValue().toString():0);
                                    }
                                    if(docFeesMode==3){
                                    	List<SelectItem> payModeList = new ArrayList<SelectItem>();
                                    	payModeList.add(new SelectItem("Online",1));
                                    	payModeList.add(new SelectItem("Offline",2));
                    					modelMap.addAttribute("payModeList", payModeList);
                    					
                                    }
                                    if(docFeePaymentDetail != null && (docFeesMode==2 || docFeesMode==3))
                                    {
                                    	if(docFeesMode==2){
                                    		paymentId = Integer.parseInt(docFeePaymentDetail[1].toString());
                                    	}else{
                                    		paymentId = Integer.parseInt(docFeePaymentDetail[2].toString());	
                                    		modelMap.addAttribute("chRDModeOfPayment",1);
                                    	}
                                    	modelMap.addAttribute("paymentId",paymentId);
                                    	TblOfflinePayment tblofflinePayment=tpslService.getOfflinePaymentDetail(paymentId);
                                    	TblPayment tblPayment  = tpslService.getPaymentDetail(paymentId);
                                    	  if(tblPayment!=null){
                                          	modelMap.addAttribute("chkpaymentMode",docFeesMode);
                                          	if(tblPayment.getCstatus()==1){
                                          	modelMap.addAttribute("payTypeList", commonService.getPaymentType(1,abcUtility.getSessionClientId(request),1,tenderId));
                                          	modelMap.addAttribute("chRDModeOfPayment",tblPayment.getTblPaymentType().getPaymentTypeId());
                                          	}
                                          }
                                    	if(tblofflinePayment!=null && tblPayment!=null){
                                    		  uniqueId = tblPayment.getUniqueId();
                                              if("6".equals(docFeesMode==3 ? docFeePaymentDetail[6].toString() : docFeePaymentDetail[5].toString()) && isDocfeesByBidder!=0 && amountList.isEmpty() && amountList !=null ){
                                             	 amount = tpslService.tenderFeesByUniqueId(uniqueId).get(0).toString();
                                              }else if(tblTender.getIsDocfeesApplicable()==2){
                                             	 amount = docFeesMode==3 ? docFeePaymentDetail[4].toString() : docFeePaymentDetail[3].toString();
                                              }else{
                                             	 amount = amount.replace(",", "");
                                              }
                                    		 boolean isFinalSubmissionDone = eventBidSubmissionService.isFinalSubmissionDone(tenderId, companyId);
                                    		 boolean isBidWithdraw = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
                                             if(tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && !isFinalSubmissionDone && !isBidWithdraw){
//                                             if (tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && !isFinalSubmissionDone && !isBidWithdraw ) {
                                             		modelMap.addAttribute("offlinePayment",tblofflinePayment);
                                             		List<SelectItem> payTypeList  = null;
                                             		payTypeList = commonService.getPaymentType(2,abcUtility.getSessionClientId(request),1,tenderId);
                                             		modelMap.addAttribute("payTypeList", payTypeList);
                                             		modelMap.addAttribute("chRDModeOfPayment",tblPayment.getTblPaymentType().getPaymentTypeId());
                                             	 	modelMap.addAttribute("isEdit",1);
                                             }else
                                             {
                                            modelMap.addAttribute("isEdit",0);
                                            amount = "";
                                        	 modelMap.addAttribute("paymentDetail", docFeePaymentDetail);
                                        	 modelMap.addAttribute("chkpaymentMode",docFeesMode);
                                             }
                                             if("6".equals(docFeesMode==3 ? docFeePaymentDetail[6].toString() : docFeePaymentDetail[5].toString())){
                                                 Object[] exemptionCertificate =  tpslService.getExemptionCertificateByPaymentId(docFeesMode==3 ? Integer.parseInt(docFeePaymentDetail[2].toString()) : Integer.parseInt(docFeePaymentDetail[1].toString()));
                                                 if(exemptionCertificate!=null){
                                                 TblExemptionCertConf tblExemptionCertConf = (TblExemptionCertConf) exemptionCertificate[0];
                                                 modelMap.addAttribute("tblExemptionCertConf", tblExemptionCertConf);
                                                 modelMap.addAttribute("docList",tpslService.getExemptionCertificateDocs(tblExemptionCertConf.getExemptionCertConfId()));
                                                 }
                                        	 }
                                             modelMap.addAttribute("linkId", lnkTenderDocPayment);
                                             modelMap.addAttribute("chkpaymentMode",docFeesMode);
                                 			 modelMap.addAttribute("remark",tblPayment.getRemark());
                                 			 modelMap.addAttribute("offlinepaymentDetail", tblofflinePayment);
                                    	}
                                    	List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(docfeesOfflinePaymentEventId, abcUtility.getSessionClientId(request));
                                    	int allowedSize = 0;
                                        StringBuilder allowedExt = new StringBuilder();
                                    	allowedSize = lstDocUploadConf.get(0).getMaxSize();
                                    	allowedExt.append(lstDocUploadConf.get(0).getType());
                                    	modelMap.addAttribute("allowedExt", allowedExt);
                                        modelMap.addAttribute("allowedSize", allowedSize/1024);
                                    }
                                    int isPkIEnabled = abcUtility.getSessionIsPkiEnabled(request);
                                    int isCertReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
                                    if (isPkIEnabled == pkiEnable || (isPkIEnabled == pkiEventSpecific && isCertReq == 1)) {
                                        modelMap.put("isPkRequired", true);
                                    } else {
                                        modelMap.put("isPkRequired", false);
                                    }
                                    modelMap.addAttribute("isDocfeesApplicable",tblTender.getIsDocfeesApplicable());
                                    modelMap.addAttribute("amountList",amount);
                                    modelMap.addAttribute("uniqueId",uniqueId);
                                    modelMap.addAttribute("isByBidder", tblTender.getIsDocumentFeeByBidder());
                                    modelMap.addAttribute("companyId",companyId);
                            }
                            if(amountList!=null && !amountList.isEmpty()){
                            	tenderCommonService.getNetAmountAndTax(modelMap,abcUtility.getSessionClientId(request),userId,1,netAmount,isDocfeesByBidder,0);
                            }
                            else if(docFeePaymentDetail!=null){
                            	if(docFeesMode==3){
                            		netAmount = new BigDecimal("0.00");
                            		netAmount = netAmount.add(new BigDecimal(docFeePaymentDetail[4].toString()));
                            		tenderCommonService.getNetAmountAndTax(modelMap,abcUtility.getSessionClientId(request),userId,1,netAmount,isDocfeesByBidder,1);
                            	}else if(docFeesMode!=3){
                            		netAmount = new BigDecimal("0.00");
                            		netAmount = netAmount.add(new BigDecimal(docFeePaymentDetail[3].toString()));
                            		tenderCommonService.getNetAmountAndTax(modelMap,abcUtility.getSessionClientId(request),userId,1,netAmount,isDocfeesByBidder,1);
                            	}
                            }
                            boolean isFinalSubmissionDone = eventBidSubmissionService.isFinalSubmissionDone(tenderId, companyId);
                            boolean isBidWithdraw = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
                         if(tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && !isFinalSubmissionDone && !isBidWithdraw){
//                            boolean isBidWithdraw = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
//                            if (tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && !isFinalSubmissionDone && !isBidWithdraw ) {
                            	modelMap.addAttribute("isEdit",1);
                            }else{
                            	modelMap.addAttribute("isEdit",0);
                            }
                        }
                        modelMap.addAttribute("documentEndDate",tblTender.getDocumentEndDate());
                        modelMap.addAttribute("downloadDocument",tblTender.getDownloadDocument());
                        break;
                    case TAB_EMD:
                    	modelMap.addAttribute("objectId",tenderId);
                    	modelMap.addAttribute("moduleId",3);
                        modelMap.addAttribute("tenderNo",tblTender.getTenderNo());
                        modelMap.addAttribute("briefText",tblTender.getTenderBrief());
                        modelMap.addAttribute("isexcemptionCert",commonService.isexcemptionCert(abcUtility.getSessionClientId(request)));
                        if(tenderCommonService.isSecondaryPartner(tenderId,companyId)>0){
                            //if secondary bidder than not allow to pay doc-fees and emd
                            String retVal="/etender/bidder/redirecttodashboard/"+tenderId+"/"+tabId;
                            retVal = retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                            modelMap.addAttribute("isSecondary", retVal);
                        }else{
                        	List <Object[]> amountList= tenderCommonService.getTenderPaymentAmount(tenderId,2,tblTender.getIsEMDByBidder(),companyId,0);
                            String amount="";
                            String uniqueId = "";
                            int isEmdByBidder = tblTender.getIsEMDByBidder();
                            if(amountList != null && !amountList.isEmpty()){
                                for (int i = 0; i < amountList.size(); i++) {
                                	amount += amountList.get(i)[0].toString() + ",";
                                	if(isEmdByBidder!=0){
                                		uniqueId = amountList.get(i)[1].toString();
                                	}
                                }
                            }
                            modelMap.addAttribute("isSecondaryPartner", tenderCommonService.isSecondaryPartner(tenderId,companyId)>0 ? true : false);
                            int emdMode = tblTender.getEmdPaymentMode();
                        	int paymentId=0;
                            auditMsg = postajaxBiddingTenderDashboardContentEMD;
                            Object[] emdPaymentDetail = tpslService.getPaymentDetail(2, tenderId, companyId,1,3,emdMode,uniqueId);
                            modelMap.addAttribute("decimalValueUpto",tblTender.getDecimalValueUpto());
                            modelMap.addAttribute("chkpaymentMode",emdMode);
                            int errCode = tenderCommonService.isEventLive(tenderId);
                            if (errCode == -1 ) {
                                modelMap.addAttribute("errCode", errCode);                        
                            } 
                            Object[] obj=clientService.getClientFields(abcUtility.getSessionClientId(request),"paymentConfigBy,deptId");
    	            		int paymentConfigBy=Integer.valueOf(obj[0].toString());
    	            		int deptId=tblTender.getTblDepartment().getDeptId();
    	            		if(paymentConfigBy==1){
    	            			deptId=Integer.valueOf(obj[1].toString());
    	            		}
                        	List<Object[]> PaymentDetails = tpslService.getPaymentDetails(2, tenderId, companyId, -1, 3, emdMode,uniqueId);
    	            		boolean isPaymentDetailsUpdate=false;
    	            		if(PaymentDetails!=null){
    	            			if(!PaymentDetails.isEmpty()){
    	            				paymentId=Integer.parseInt(PaymentDetails.get(0)[emdMode==3?2:1].toString());
    	            				modelMap.addAttribute("paymentId",paymentId);
    	            			}
    	            			if(!tpslService.isOnlinePaymentDone(2, tenderId, companyId, 3, "")){
	        	            		
    	            				for(Object[] paymentDetail : PaymentDetails){
	        	            			
	        	            			if(!"0399".equals(paymentDetail[0]) && !"0300".equals(paymentDetail[0]) && Integer.parseInt(paymentDetail[emdMode==3?6:5].toString()) ==1 && Integer.parseInt(paymentDetail[emdMode==3?9:8].toString())==0 || (null == (paymentDetail[0])&& Integer.parseInt(paymentDetail[emdMode==3?9:8].toString())==0)){//If Payment is not Field/Success ,  paymentType is Payment Gateway and cstatus is 0
	        	            				isPaymentDetailsUpdate=true;
											try{
	        	            				boolean isReconcilationDone = tpslService.paymentReconcilation(2, emdMode==3 ? Integer.parseInt(paymentDetail[2].toString()): Integer.parseInt(paymentDetail[1].toString()), clientBean.getClientId(), emdMode==3 ? paymentDetail[3].toString(): paymentDetail[2].toString(),deptId);
		                                    if (isReconcilationDone) {
		                                    	amount = "";
	                                            	 amountList= tenderCommonService.getTenderPaymentAmount(tenderId,2,tblTender.getIsEMDByBidder(),companyId,0);
	                                            	 if(amountList != null && !amountList.isEmpty()){
	                                                    for (int i = 0; i < amountList.size(); i++) {
	                                                    	amount += amountList.get(i)[0].toString() + ",";
	                                                     	if(isEmdByBidder!=0){
	                                                    		uniqueId = amountList.get(i)[1].toString();
	                                                    	}
	                                                    }
	                                                }
		                                            emdPaymentDetail = tpslService.getPaymentDetail(2, tenderId, companyId,1,3,emdMode,uniqueId);
		                                    }
											}catch(Exception e){
		        	            			 exceptionHandlerService.writeLog(e);
											}	
	        	            			}
	        	            			if("0300".equals(paymentDetail[0])){
	        	            				 emdPaymentDetail = tpslService.getPaymentDetail(2, tenderId, companyId,1,3,emdMode,uniqueId);
	        	            			}
	        	            		}
    	            			}
    	            		}
    	            		if(isPaymentDetailsUpdate){
    	            		PaymentDetails = tpslService.getPaymentDetails(2, tenderId, companyId, -1, 3, emdMode,uniqueId);
    	            		}
    	            		modelMap.addAttribute("PaymentDetails", PaymentDetails);
                        
                            if (emdPaymentDetail == null) {
                            	if (errCode == -1) {
                                    modelMap.addAttribute("err_bidsub_dt", "msg_tender_fs_submissionenddt_lapse");
                                } 
                            	if(commonService.checkTenderCancel(tenderId)>0){
                         			modelMap.addAttribute("isEventCancel", 1);
                             	}
                            	if(tblTender.getEmdSubmissionEndDate()!=null){
                            		if(tblTender.getEmdSubmissionEndDate().compareTo(commonService.getServerDateTime()) <= 0){
                            			modelMap.addAttribute("err_bidsub_dt", "msg_emdsubmition_end_datetime_lapse");
                            		}
                            	}
//                            	emdPaymentDetail = tpslService.getPaymentDetail(2, tenderId, companyId,0,3,emdMode,uniqueId);
//                            	if (emdPaymentDetail != null && !"0300".equals(emdPaymentDetail[0])) {
	                            
	        	            		/* Priyanka Work starts here*/
	        	            		if(bankId ==2 || bankId == 4)
	        	            		{
	        	            			Object[] docFeeeRefundAccountDetail =  tpslService.getRefundAccountDetail(abcUtility.getSessionClientId(request), companyId);
	                                    if (docFeeeRefundAccountDetail != null) {
	                                    	  modelMap.addAttribute("emdRefundAccountDetail", docFeeeRefundAccountDetail);
	                                    }//docFeeeRefundAccountDetail
	        	            		}
	                                
//                            	}
                            }
                            /**
                             *  Added by shreyansh to implement Feature #23753
                             *  When emdamount is 0 and type online set in tender
                             */
                            BigDecimal emdAmount = new BigDecimal(0);
                            if(tblTender.getIsEMDApplicable()==1){
                             emdAmount = BigDecimal.valueOf(Double.parseDouble(tblTender.getEmdAmount()));
                            }    
                            if((tblTender.getIsEMDByBidder()==0) && tblTender.getEmdPaymentMode()==1 && emdAmount.compareTo(BigDecimal.ZERO)<=0 && tblTender.getIsEMDApplicable() == 1){
                                modelMap.addAttribute("isAmtFillByBidder",true);
                            }
                            if((tblTender.getIsEMDByBidder()==0) && (tblTender.getIsEMDApplicable()==3)){
                                 modelMap.addAttribute("minEmdAmt",tblTender.getMinEmdAmt());
                                 modelMap.addAttribute("maxEmdAmt",tblTender.getMaxEmdAmt());
                                 modelMap.addAttribute("isAmtFillByBidder",true);
                            }
                            if (emdPaymentDetail != null && "0300".equals(emdPaymentDetail[0])  ) {
                                    if("6".equals(emdMode==3 ? emdPaymentDetail[6].toString() : emdPaymentDetail[5].toString())){
                                            Object[] exemptionCertificate =  tpslService.getExemptionCertificateByPaymentId(Integer.parseInt(emdMode==3 ? emdPaymentDetail[2].toString() : emdPaymentDetail[1].toString()));
                                            TblExemptionCertConf tblExemptionCertConf = (TblExemptionCertConf) exemptionCertificate[0];
                                            modelMap.addAttribute("tblExemptionCertConf", tblExemptionCertConf);
                                            modelMap.addAttribute("docList",tpslService.getExemptionCertificateDocs(tblExemptionCertConf.getExemptionCertConfId()));
                                    }
                                    modelMap.addAttribute("paymentDetail", emdPaymentDetail);
                            } else {
                                    modelMap.addAttribute("certTypeList", abcUtility.convert(tenderBriefcaseService.getExemptionCertificateType(abcUtility.getSessionClientId(request))));
                                    modelMap.addAttribute("payTypeList", commonService.getPaymentType(1,abcUtility.getSessionClientId(request),2,tenderId));
                                    if(emdMode!=2){
                                    	List<SelectItem> payTypeList  = null;
                                    	payTypeList = commonService.getPaymentType(1,abcUtility.getSessionClientId(request),2,tenderId);
                                    	
                                    	modelMap.addAttribute("payTypeList", payTypeList);
                                    	modelMap.addAttribute("chRDModeOfPayment",!payTypeList.isEmpty()?payTypeList.get(0).getValue().toString():0);
                                    }else{
                                    	List<SelectItem> payTypeList  = null;
                                    	payTypeList = commonService.getPaymentType(2,abcUtility.getSessionClientId(request),2,tenderId);
                                    	
                                    	modelMap.addAttribute("payTypeList", payTypeList);
                                    	modelMap.addAttribute("chRDModeOfPayment",!payTypeList.isEmpty()?payTypeList.get(0).getValue().toString():0);
                                    }
                                    if(emdMode==3){
                                    	List<SelectItem> payModeList = new ArrayList<SelectItem>();
                                    	payModeList.add(new SelectItem("Online",1));
                                    	payModeList.add(new SelectItem("Offline",2));
                    					modelMap.addAttribute("payModeList", payModeList);
                                    }
                                    if(emdPaymentDetail != null && (emdMode==2 || emdMode==3))
                                    {
                                    	if(emdMode==2){
                                    		paymentId = Integer.parseInt(emdPaymentDetail[1].toString());
                                    	}else{
                                    		paymentId = Integer.parseInt(emdPaymentDetail[2].toString());	
                                    		modelMap.addAttribute("chRDModeOfPayment",1);
                                    	}
                                    	modelMap.addAttribute("paymentId",paymentId);
                                    	TblOfflinePayment tblofflinePayment=tpslService.getOfflinePaymentDetail(paymentId);
                                    	TblPayment tblPayment  = tpslService.getPaymentDetail(paymentId);
                                    	  if(tblPayment!=null){
                                            	modelMap.addAttribute("chkpaymentMode",emdMode);
                                            	if(tblPayment.getCstatus()==1){
                                            	modelMap.addAttribute("payTypeList", commonService.getPaymentType(1,abcUtility.getSessionClientId(request),2,tenderId));
                                            	modelMap.addAttribute("chRDModeOfPayment",tblPayment.getTblPaymentType().getPaymentTypeId());
                                            	}
                                            }
                                      	if(tblofflinePayment!=null && tblPayment!=null){
                                      		uniqueId = tblPayment.getUniqueId();
                                       	 if("6".equals(emdMode==3 ? emdPaymentDetail[6].toString() : emdPaymentDetail[5].toString()) && isEmdByBidder!=0 && amountList.isEmpty() && amountList !=null ){
                                           	 amount = tpslService.tenderFeesByUniqueId(uniqueId).get(0).toString();
                                            }else if(tblTender.getIsEMDApplicable()==2){
                                            	 amount = emdMode==3 ? emdPaymentDetail[4].toString() : emdPaymentDetail[3].toString();
                                             }else{
                                            	 amount = amount.replace(",", "");
                                             }
                                            boolean isFinalSubmissionDone = eventBidSubmissionService.isFinalSubmissionDone(tenderId, companyId);
                                            boolean isBidWithdraw = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
                                            if(tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && !isFinalSubmissionDone && !isBidWithdraw){
//                                            if ((tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && isBidWithdraw == 0)  || (!isFinalSubmissionDone && isBidWithdraw == 1) ) {
	                                            	 modelMap.addAttribute("offlinePayment",tblofflinePayment);
	                                     			List<SelectItem> payTypeList  = null;
	                                             	payTypeList = commonService.getPaymentType(2,abcUtility.getSessionClientId(request),2,tenderId);
	                                              	modelMap.addAttribute("payTypeList", payTypeList);
	                                             	modelMap.addAttribute("chRDModeOfPayment",tblPayment.getTblPaymentType().getPaymentTypeId());
	                                             	modelMap.addAttribute("isEdit",1);
                                            }else
                                            {
                                            	modelMap.addAttribute("isEdit",0);
                                            	 amount = "";
                                            	  modelMap.addAttribute("paymentDetail", emdPaymentDetail);
                                            	  modelMap.addAttribute("chkpaymentMode",emdMode);
                                            }
                                            modelMap.addAttribute("linkId", lnkTenderEmdPayment);
                                            modelMap.addAttribute("remark",tblPayment.getRemark());
                                            modelMap.addAttribute("offlinepaymentDetail", tblofflinePayment);
                                            modelMap.addAttribute("chkpaymentMode",emdMode);
                                       	 	if("6".equals(emdMode==3 ? emdPaymentDetail[6].toString() : emdPaymentDetail[5].toString())){
                                                Object[] exemptionCertificate =  tpslService.getExemptionCertificateByPaymentId(emdMode==3 ? Integer.parseInt(emdPaymentDetail[2].toString()) : Integer.parseInt(emdPaymentDetail[1].toString()));
                                               	if(exemptionCertificate!=null){
                                                TblExemptionCertConf tblExemptionCertConf = (TblExemptionCertConf) exemptionCertificate[0];
                                                modelMap.addAttribute("tblExemptionCertConf", tblExemptionCertConf);
                                                modelMap.addAttribute("docList",tpslService.getExemptionCertificateDocs(tblExemptionCertConf.getExemptionCertConfId()));
                                                }
                                       	 	}
                                    	}
                                      	List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(emdOfflinePaymentEventId, abcUtility.getSessionClientId(request));
                                    	int allowedSize = 0;
                                        StringBuilder allowedExt = new StringBuilder();
                                    	allowedSize = lstDocUploadConf.get(0).getMaxSize();
                                    	allowedExt.append(lstDocUploadConf.get(0).getType());
                                    	modelMap.addAttribute("allowedExt", allowedExt);
                                        modelMap.addAttribute("allowedSize", allowedSize/1024);
                                    }
                                    int isPkIEnabled = abcUtility.getSessionIsPkiEnabled(request);
                                    int isCertReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
                                    if (isPkIEnabled == pkiEnable || (isPkIEnabled == pkiEventSpecific && isCertReq == 1)) {
                                        modelMap.put("isPkRequired", true);
                                    } else {
                                        modelMap.put("isPkRequired", false);
                                    }
                                    modelMap.addAttribute("isEMDApplicable",tblTender.getIsEMDApplicable());
                                    modelMap.addAttribute("companyId",companyId);                                    
                            }
                            boolean isFinalSubmissionDone = eventBidSubmissionService.isFinalSubmissionDone(tenderId, companyId);
                            boolean isBidWithdraw = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
                            if(tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && !isFinalSubmissionDone && !isBidWithdraw){
                            	modelMap.addAttribute("isEdit",1);
                            }else{
                            	modelMap.addAttribute("isEdit",0);
                            }
                            modelMap.addAttribute("amountList",amount);
                            modelMap.addAttribute("uniqueId",uniqueId);
                            modelMap.addAttribute("isByBidder", tblTender.getIsEMDByBidder());
                        }
                        break;
                    case TAB_RESTEVENTMONEY:
                    	auditMsg=postajaxTenderDashboardContentREST;
                    	modelMap.addAttribute("objectId",tenderId);
                    	modelMap.addAttribute("moduleId",3);
                        modelMap.addAttribute("tenderNo",tblTender.getTenderNo());
                        modelMap.addAttribute("briefText",tblTender.getTenderBrief());
                    	int isItemWise=tenderCommonService.getIsItemWise(tenderId,3);
                        BigDecimal remaingAmount = new BigDecimal(0);
	               		BigDecimal PaidAmount = null ;
                        BigDecimal PayableAmount = null ;
               		 	List<Object[]> lstDetail = null;
               		 	int rowId=0;
               		 	int isTransactionDateWise = 0;
               		 	String transactionEndDateTime=null;
        				request.setAttribute("pgId",pgId);
        				Object[] payConfDetail=clientService.getClientFields(abcUtility.getSessionClientId(request),"paymentConfigBy,deptId");
	            		int payConfigBy=Integer.valueOf(payConfDetail[0].toString());
	            		int dptId=tblTender.getTblDepartment().getDeptId();
	            		if(payConfigBy==1){
	            			dptId=Integer.valueOf(payConfDetail[1].toString());
	            		}
        				List<Object[]> restPaymentDetails = tpslService.getPaymentDetails(9, tenderId, companyId, -1, 3, 1,"");
	            		boolean isRestPaymentDetailsUpdate=false;
	            		if(restPaymentDetails!=null){
	            			if(!tpslService.isOnlinePaymentDone(9, tenderId, companyId, 3, "")){
		    	            	for(Object[] paymentDetail : restPaymentDetails){		
		    	            		if(!"0399".equals(paymentDetail[0]) && !"0300".equals(paymentDetail[0]) && Integer.parseInt(paymentDetail[5].toString()) ==1 && Integer.parseInt(paymentDetail[8].toString())==0 || (null == paymentDetail[0] && Integer.parseInt(paymentDetail[8].toString())==0)){//If Payment is not Field/Success ,  paymentType is Payment Gateway and cstatus is 0
		    	            			isRestPaymentDetailsUpdate=true;
										try{
		    	            			boolean isReconcilationDone = tpslService.paymentReconcilation(9, Integer.parseInt(paymentDetail[1].toString()), clientBean.getClientId(), paymentDetail[2].toString(),dptId);
										}catch(Exception e){
		        	            		 exceptionHandlerService.writeLog(e);
										}	
		    	            		}
		    	            	}
	            			}
	            		}
	            		if(isRestPaymentDetailsUpdate){
	            			restPaymentDetails = tpslService.getPaymentDetails(9, tenderId, companyId, -1, 3, 1,"");
	            		}
	            		modelMap.addAttribute("PaymentDetails", restPaymentDetails);
        	            modelMap.addAttribute("decimalValueUpto",tblTender.getDecimalValueUpto());
        	            int errCode = tenderCommonService.isEventLive(tenderId);
        	             if (errCode == -1 ) {
        	                modelMap.addAttribute("errCode", errCode);                        
        	            } 
        	            if(commonService.checkTenderCancel(tenderId)>0){
                 			modelMap.addAttribute("isEventCancel", 1);
                     	}
        	            if(isItemWise != 2){
	        	            List<Object[]>  RestOfAucPaymentDetail = null;
	        	            RestOfAucPaymentDetail = tpslService.getRestOfEventPaymentDetail(9, tenderId, companyId,1,3,9,0);
	    	            	if(RestOfAucPaymentDetail!=null){
	    	            	PaidAmount=new BigDecimal(0);
	    	            	PayableAmount = new BigDecimal(RestOfAucPaymentDetail.get(0)[3].toString());
	    	            	for(Object[] object:RestOfAucPaymentDetail){
	    	            		PaidAmount = new BigDecimal(object[4].toString()).add(PaidAmount);
	    	            	}
	    	            	remaingAmount = PayableAmount.subtract(PaidAmount);
	    	            	rowId = Integer.parseInt(RestOfAucPaymentDetail.get(0)[10].toString());
	    	            	isTransactionDateWise = Integer.parseInt(RestOfAucPaymentDetail.get(0)[12].toString());
	    	            	transactionEndDateTime = RestOfAucPaymentDetail.get(0)[13].toString();
	    	            	}else{
	    	            			lstDetail = tenderCommonService.getRestOfTenderDetailsForGT(tenderId,companyId,3,9,0);
	    	            			isTransactionDateWise= Integer.parseInt(lstDetail.get(0)[11].toString());
	    	            			transactionEndDateTime=lstDetail.get(0)[12].toString();
	    	            		if(lstDetail!=null && !lstDetail.isEmpty()){
	    	            			remaingAmount = new BigDecimal(lstDetail.get(0)[7].toString());
	    	            			PaidAmount = new BigDecimal(0);
	    	            		}
	    	            	}
	        	            		modelMap.addAttribute("paidAmount",PaidAmount);
	        	            		modelMap.addAttribute("remaingAmount",remaingAmount);
	        	            		modelMap.addAttribute("restOfAucPaymentDetail", RestOfAucPaymentDetail);
	        	            		if(isTransactionDateWise==1){//isTransactionDateWise true
	        	            			modelMap.addAttribute("paymentLastDateTime",transactionEndDateTime);	        	            			
	        	            		}
        	            }
        	            modelMap.addAttribute("isRestOfEventMoney",tblTender.getIsRestOfEventMoney());
                		if(remaingAmount.compareTo(new BigDecimal(0))>0) {
        		            modelMap.addAttribute("certTypeList", abcUtility.convert(tenderBriefcaseService.getExemptionCertificateType(abcUtility.getSessionClientId(request))));
        	                modelMap.addAttribute("payTypeList",commonService.getPaymentType(1,abcUtility.getSessionClientId(request),9,tenderId));
        	                modelMap.addAttribute("amountList",tenderCommonService.getTenderPaymentAmount(tenderId,9,tblTender.getIsEMDByBidder(),companyId,rowId));
        	                modelMap.addAttribute("isByBidder", 0);
        	                modelMap.addAttribute("companyId",companyId);
        	            }
	        	          if((remaingAmount !=null && remaingAmount.intValue() > 0) || (isItemWise==2 || (tblTender.getIsItemwiseWinner()==1 && tblTender.getIsEMDApplicable()==0))){
        	            	  modelMap.addAttribute("certTypeList", abcUtility.convert(tenderBriefcaseService.getExemptionCertificateType(abcUtility.getSessionClientId(request))));
        		                modelMap.addAttribute("payTypeList",commonService.getPaymentType(1,abcUtility.getSessionClientId(request),9,tenderId));
        		                modelMap.addAttribute("amountList",tenderCommonService.getTenderPaymentAmount(tenderId,9,tblTender.getIsEMDByBidder(),companyId,rowId));
        		                modelMap.addAttribute("isByBidder",0);
        		                modelMap.addAttribute("companyId",companyId);
        		                modelMap.addAttribute("makepayment",true);
        		            
        		            }
        	            
        	            modelMap.addAttribute("payFor",9);
        	            modelMap.addAttribute("paymentFor","restOfAucMoney");
        	            if(isCertRequired!=0){
                         if(abcUtility.getSessionCertId(request)!=null){
                               String[] certIds = abcUtility.getSessionCertId(request).split(",");
                               modelMap.addAttribute("bidpkey", commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                               if(certIds.length==2){
                                   modelMap.addAttribute("bidpkey2", commonService.getPublicKeyById(Integer.parseInt(certIds[1])));
                               }
                         }
        	          }
    	            	 	List<Object[]> isEMDlist = tenderCommonService.getTenderFields(tenderId, "isEMDApplicable,isItemwiseWinner");
        	            	 int isEMD=-1;
        	        		 int isItemwiseWinner=-1;
            	  		if(!isEMDlist.isEmpty()){
            	  			Object[] tenderData = isEMDlist.get(0);
            	  			isEMD = Integer.parseInt(tenderData[0].toString());
            	  			isItemwiseWinner =  Integer.parseInt(tenderData[1].toString());// 0 for Grand total wise, 1 for Item wise, 2 for Lot wise
            	  		}
        	            if(isItemWise!=2){
        	            	modelMap.addAttribute("paidAmount",PaidAmount);
        	            	modelMap.addAttribute("remaingAmount",remaingAmount);
        	            }
						modelMap.addAttribute("isItemwiseWinner",isItemwiseWinner);
						modelMap.addAttribute("isEMD",isEMD);
        	            modelMap.addAttribute("isItemWise",isItemWise);
                    	break;
                    case TAB_PREPARE_BID:
                    	Boolean isEncCertVerified = false;
                    	if (request.getSession().getAttribute("isEncCertVerified") != null)
                    	{
                    		isEncCertVerified = Boolean.parseBoolean(request.getSession().getAttribute("isEncCertVerified").toString());
                    		modelMap.addAttribute("isEncCertVerified", isEncCertVerified);
                    		request.getSession().removeAttribute("isEncCertVerified");	
                    	}
                        auditMsg = postajaxBiddingTenderDashboardContentPB;
                        formStatus = -1;
                        boolean isBidPrepared = false;
                        List<Object[]> lstTenderBidDtls = tenderCommonService.getTenderBidDtls(tenderId, companyId, false);

                        List<Object[]> lstRebateFormTenderBidCnt = eventBidSubmissionService.getRebateFormTenderBidCount(tenderId, companyId);
                        boolean showRebateAction = false;
                        if (!lstRebateFormTenderBidCnt.isEmpty()) {
                            if ( (Long.parseLong(lstRebateFormTenderBidCnt.get(0)[0].toString())!= 0) && Long.parseLong(lstRebateFormTenderBidCnt.get(0)[0].toString()) == Long.parseLong(lstRebateFormTenderBidCnt.get(0)[1].toString())) {
                                showRebateAction = true;
                            }
                            modelMap.addAttribute("showRebateAction", showRebateAction);
                        }

                        if (!lstTenderBidDtls.isEmpty()) {
                            isBidPrepared = true;
                            modelMap.addAttribute("lstTenderBidDtls", lstTenderBidDtls);
                        }
                        
                        if(isDocUploaded){
                            Map<Integer,String> isDocAvailForPrepareBid = new HashMap<Integer,String>();
                            for (Object[] objects : lstTenderBidderDocs) {
                                String fPath = docUploadPath.concat((String)objects[4]);
                                File f = new File(fPath);
                                f = abcUtility.CheckDirExist(f);
                                if(f.exists()){
                                    isDocAvailForPrepareBid.put((Integer)objects[3], "y");
                                }else{
                                    isDocAvailForPrepareBid.put((Integer)objects[3], "n");
                                }
                                }
                            modelMap.addAttribute("isDocAvail", isDocAvailForPrepareBid);
                         }
                        boolean isEmdOfflinePaid = tpslService.getOfflinePaymentCount(companyId, tenderId, 2) != 0;                        
                        modelMap.addAttribute("isEmdOfflinePaid", isEmdOfflinePaid);
                        boolean isEmdPaidByExemption = tpslService.getOfflinePaymentPaidByExemption(companyId, tenderId, 2);
                        modelMap.addAttribute("isEmdPaidByExemption", isEmdPaidByExemption);
                        if(isEmdOfflinePaid && !isEmdPaidByExemption){
                        	List<Object[]> lstTenderEmdDocs = tenderCommonService.getTenderBidderDocs(tenderId, companyId,lnkTenderEmdPayment);
                        	Map<Integer,String> isEMDDocAvailForPrepareBid = new HashMap<Integer,String>();
                        	int EMDBidderDocCount = 0 ;
                            for (Object[] objects : lstTenderEmdDocs) {
                                String fPath = docUploadPath.concat((String)objects[4]);
                                File f = new File(fPath);
                                f = abcUtility.CheckDirExist(f);
                                if(f.exists()){
                                	EMDBidderDocCount++;
                                	isEMDDocAvailForPrepareBid.put((Integer)objects[3], "y");
                                }else{
                                	isEMDDocAvailForPrepareBid.put((Integer)objects[3], "n");
                                }
                            }
                            if(EMDBidderDocCount == tpslService.getOfflinePaymentCount(companyId, tenderId, 2) ){
                             	 modelMap.addAttribute("isEMDBidderDocCount", true);
                             }else{
                             	 modelMap.addAttribute("isEMDBidderDocCount", false);
                             }
                            modelMap.addAttribute("isEMDDocAvail", isEMDDocAvailForPrepareBid);
                        	
                        }
                        boolean isDocFeeOfflinePaid = tpslService.getOfflinePaymentCount(companyId, tenderId, 1) != 0;
                        modelMap.addAttribute("isDocFeeOfflinePaid", isDocFeeOfflinePaid);
                        boolean isDocFeesPaidByExemption = tpslService.getOfflinePaymentPaidByExemption(companyId, tenderId, 1);                                      
                        modelMap.addAttribute("isDocFeesPaidByExemption", isDocFeesPaidByExemption);
                        if(isDocFeeOfflinePaid && !isDocFeesPaidByExemption){
                        	List<Object[]> lstTenderDocFeeDocs = tenderCommonService.getTenderBidderDocs(tenderId, companyId,lnkTenderDocPayment);
                        	Map<Integer,String> isDocFeeAvailForPrepareBid = new HashMap<Integer,String>();
                        	int DocFeesBidderDocCount = 0;
                            for (Object[] objects : lstTenderDocFeeDocs) {
                                String fPath = docUploadPath.concat((String)objects[4]);
                                File f = new File(fPath);
                                f = abcUtility.CheckDirExist(f);
                                if(f.exists()){
                                	DocFeesBidderDocCount++;
                                	isDocFeeAvailForPrepareBid.put((Integer)objects[3], "y");
                                }else{
                                	isDocFeeAvailForPrepareBid.put((Integer)objects[3], "n");
                                }
                            }
                            if(DocFeesBidderDocCount == tpslService.getOfflinePaymentCount(companyId, tenderId, 1) ){
                              	 modelMap.addAttribute("isDocFeesBidderDocCount", true);
                              }else{
                              	 modelMap.addAttribute("isDocFeesBidderDocCount", false);
                              }
                            modelMap.addAttribute("isDocFeeDocAvail", isDocFeeAvailForPrepareBid);
                        	
                        }
                        boolean isParticipationOfflinePaid = tpslService.getOfflinePaymentCount(companyId, tenderId, 8) != 0;                        
                        modelMap.addAttribute("isParticipationOfflinePaid", isParticipationOfflinePaid);
                        boolean isParticipationPaidByExemption = tpslService.getOfflinePaymentPaidByExemption(companyId, tenderId, 8);
                        modelMap.addAttribute("isParticipationPaidByExemption", isParticipationPaidByExemption);
                        if(isParticipationOfflinePaid && !isParticipationPaidByExemption){
                        	List<Object[]> lstTenderParticipationDocs = tenderCommonService.getTenderBidderDocs(tenderId, companyId,linkBidPreRegChargesOfflinePayment);
                        	Map<Integer,String> isParticipationDocAvailForPrepareBid = new HashMap<Integer,String>();
                        	int ParticipationBidderDocCount = 0; 
                            for (Object[] objects : lstTenderParticipationDocs) {
                                String fPath = docUploadPath.concat((String)objects[4]);
                                File f = new File(fPath);
                                f = abcUtility.CheckDirExist(f);
                                if(f.exists()){
                                	ParticipationBidderDocCount++;
                                	isParticipationDocAvailForPrepareBid.put((Integer)objects[3], "y");
                                }else{
                                	isParticipationDocAvailForPrepareBid.put((Integer)objects[3], "n");
                                }
                            }
                            if(ParticipationBidderDocCount == tpslService.getOfflinePaymentCount(companyId, tenderId, 8) ){
                            	 modelMap.addAttribute("isParticipationBidderDocCount", true);
                            }else{
                            	 modelMap.addAttribute("isParticipationBidderDocCount", false);
                            }
                            modelMap.addAttribute("isParticipationDocAvail", isParticipationDocAvailForPrepareBid);
                        	
                        }
                        String finalSubmissionMsg1 = tenderCommonService.allowFinalSubmission(sBean.getIpAddress(), tenderId, companyId, userId,sBean.getUserDetailId(), FINALSUBMISSION_REQUEST_TYPE_GET);
                        if (finalSubmissionMsg1.contains("msg_tender_fs_finalsubmission_done")) {
                            modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg1.split("@")[0]);
                            modelMap.addAttribute("msgArgumentOne", finalSubmissionMsg1.split("@")[1]);
                            modelMap.addAttribute("msgArgumentTwo", CommonUtility.convertTimezone(finalSubmissionMsg1.split("@")[2]));
                        } else {
                            modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg1);
                        }
                        if(isFormConfirmationReq==1 && lstTenderBidDtls.size()>0){
                            List<Integer> bidLst = new ArrayList<Integer>();
                            for (Object[] bidDetail : lstTenderBidDtls) {
                                bidLst.add(Integer.parseInt(bidDetail[0].toString()));
                            }
                            modelMap.addAttribute("bidIds", bidLst.toString().replace(" ", "").replace("[", "").replace("]", ""));
                            modelMap.addAttribute("leadRegret", eventBidSubmissionService.isLeadPartnerRegret(tenderId,2,userId));
                        }
                        /**
                         * * get rebate List by tender Id *
                         */
                        modelMap.addAttribute("rebateList", tenderFormService.getRebateByTenderNCompanyId(tenderId, companyId));
                        if (tblTender.getIsItemSelectionPageRequired() == 1) {
							List<Object[]> itemselected = tenderFormService.getBidderFromItemSelection(tenderId, userId, 0, false, false);
							Map<Object, Boolean> selectedForm = new HashMap<Object, Boolean>();
							if (itemselected != null && !itemselected.isEmpty()) {
								for (Object[] obj : itemselected) {
									if (obj[3].equals(1)) {
										selectedForm.put(obj[0], true);
									}
								}
								modelMap.addAttribute("selFormByItemSelection", selectedForm);
								modelMap.addAttribute("biditemselected",1);
							} else {
								modelMap.addAttribute("biditemselected",0);
							}
						}
                        modelMap.addAttribute("rebateList", tenderFormService.getRebateByTenderNCompanyId(tenderId, companyId));
                        modelMap.addAttribute("isBidPrepared", isBidPrepared);
                        
                        tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                        boolean isWeightageEvaluationRequired = Integer.parseInt(modelMap.get("isWeightageEvaluationRequired").toString())==1;
                		boolean isGrandTotalWiseTenderResult = Integer.parseInt(modelMap.get("tenderResult").toString())==1;
                		if(isWeightageEvaluationRequired && isGrandTotalWiseTenderResult){
                			setWeightageEvaluation(tenderId,modelMap);
                		}
                		modelMap.addAttribute("isPCFEnable",commonService.isRCIClient(rciClientIds,abcUtility.getSessionClientId(request)) == true ? false : true);
                		modelMap.addAttribute("isSecondaryPartner", tenderCommonService.isSecondaryPartner(tenderId,companyId)>0 ? true : false);
                		modelMap.addAttribute("isEmdPayed", tenderCommonService.isEmdPayed(tenderId, companyId));
                		int docDownloadErr = tenderCommonService.isDocumentDateLive(tenderId);
                		errCode = tenderCommonService.isEventLive(tenderId);
                		if(tblTender.getCstatus() != 2){
                			if(errCode == 0) {
	                			modelMap.addAttribute("err_bidsub_dt", "msg_tender_err_msg_bidsub_dt_notarrived");
	                		}else if(docDownloadErr == -1 && errCode == -1){
	                			modelMap.addAttribute("err_bidsub_dt", "msg_tender_fs_submissionenddt_lapse");
	                		}
                		}else if(tblTender.getCstatus() == 2 && !isBidPrepared){
                			modelMap.addAttribute("err_bidsub_dt", "msg_event_cancel");
                		}
                		break;

                    case TAB_FINAL_SUBMISSION:
                        auditMsg = postajaxBiddingTenderDashboardContentFS;
                        formStatus = 1;
                        String finalSubmissionMsg = "msg_event_cancel";
                        if(tblTender.getCstatus() != 2){
                        	finalSubmissionMsg = tenderCommonService.allowFinalSubmission(sBean.getIpAddress(), tenderId, companyId, userId,
                        			sBean.getUserDetailId(), FINALSUBMISSION_REQUEST_TYPE_GET);
                        }
                        if (isDocsMandatory) {
                            Map<Integer, Long> pendingDocUploadCount = new HashMap<Integer, Long>();
                            List<Object[]> lstManDocUploadedCount = tenderCommonService.getManDocsUploadedCount(tenderId, companyId);
                            Map<Integer, Long> docUploadCount = new HashMap<Integer, Long>();
                            for (Object[] manDocs : lstManDocUploadedCount) {
                                docUploadCount.put((Integer) manDocs[1], (Long) manDocs[0]);
                            }
                            List<Object[]> lstMandatoryDocsCount = tenderCommonService.getMandatoryDocsCounts(isConsortium, tenderId);
                            for (Object[] manDoc : lstMandatoryDocsCount) {
                                if (docUploadCount.containsKey((Integer) manDoc[1])) {
                                    pendingDocUploadCount.put((Integer) manDoc[1], (Long) manDoc[0] - docUploadCount.get((Integer) manDoc[1]));
                                } else {
                                    pendingDocUploadCount.put((Integer) manDoc[1], (Long) manDoc[0]);
                                }
                            }
                            
                            modelMap.addAttribute("PendingDocsCount", pendingDocUploadCount);
                        }

                        if (finalSubmissionMsg.contains("msg_tender_fs_finalsubmission_done")) {
                        	if(tblTender.getIsEDraw()==1){
                        		StringBuilder coupon = new StringBuilder();
                        		modelMap.addAttribute("coupon", coupon.append(tenderId+"O"+userId));
                        	}
                        	modelMap.addAttribute("isEDraw", tblTender.getIsEDraw());
                        	modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg.split("@")[0]);
                            modelMap.addAttribute("msgArgumentOne", finalSubmissionMsg.split("@")[1]);
                            modelMap.addAttribute("msgArgumentTwo", CommonUtility.convertTimezone(finalSubmissionMsg.split("@")[2]));
                            List<Object[]> lstFinalSubmissionReceipt =null;                         
                            int isConsortiumAllowed = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isConsortiumAllowed").toString());
                            lstFinalSubmissionReceipt = tenderCommonService.getFinalSubmissionReceipt(companyId,abcUtility.getSessionClientId(request));
                            isBidderRegretted = eventBidSubmissionService.isBidderRegretted(userId,tenderId);
                            modelMap.addAttribute("isBidderRegretted", isBidderRegretted);
                            if(isConsortiumAllowed==1)
                            {                                    	
                            	Object cmpname = tenderCommonService.getConsortiumDetail(tenderId,companyId);                              
                            	 modelMap.addAttribute("leadCompanyName", cmpname);                    	 
                            }                         
    	                    modelMap.addAttribute("lstFinalSubmissionReceipt", lstFinalSubmissionReceipt);
                        } else if(!finalSubmissionMsg.equals("msg_event_cancel")){
                            modelMap.addAttribute("allowFinalSubmission", finalSubmissionMsg);
                        }

                        showRebateAction = false;
                        lstRebateFormTenderBidCnt = eventBidSubmissionService.getRebateFormTenderBidCount(tenderId, companyId);
                        if (!lstRebateFormTenderBidCnt.isEmpty()) {
                            if (Long.parseLong(lstRebateFormTenderBidCnt.get(0)[0].toString()) == Long.parseLong(lstRebateFormTenderBidCnt.get(0)[1].toString())) {
                                showRebateAction = true;
                            }
                            modelMap.addAttribute("showRebateAction", showRebateAction);
                        }
                        
                        if(isDocUploaded){
                            Map<Integer,String> isDocAvail = new HashMap<Integer,String>();
                            for (Object[] objects : lstTenderBidderDocs) {
                                String fPath = docUploadPath.concat((String)objects[4]);
                                File f = new File(fPath);
                                f = abcUtility.CheckDirExist(f);
                                if(f.exists()){
                                    isDocAvail.put((Integer)objects[3], "y");
                                }else{
                                    isDocAvail.put((Integer)objects[3], "n");
                                }
                            }
                            modelMap.addAttribute("isDocAvail", isDocAvail);
                        }
                         isEmdOfflinePaid = tpslService.getOfflinePaymentCount(companyId, tenderId, 2) != 0; 
                         isEmdPaidByExemption = tpslService.getOfflinePaymentPaidByExemption(companyId, tenderId, 2);
                         modelMap.addAttribute("isEmdPaidByExemption", isEmdPaidByExemption);
                        modelMap.addAttribute("isEmdOfflinePaid", isEmdOfflinePaid);
                        if(isEmdOfflinePaid && !isEmdPaidByExemption){
                        	List<Object[]> lstTenderEmdDocs = tenderCommonService.getTenderBidderDocs(tenderId, companyId,lnkTenderEmdPayment);
                        	Map<Integer,String> isEMDDocAvailForPrepareBid = new HashMap<Integer,String>();
                        	int EMDBidderDocCount = 0;
                            for (Object[] objects : lstTenderEmdDocs) {
                                String fPath = docUploadPath.concat((String)objects[4]);
                                File f = new File(fPath);
                                f = abcUtility.CheckDirExist(f);
                                if(f.exists()){
                                	EMDBidderDocCount++;
                                	isEMDDocAvailForPrepareBid.put((Integer)objects[3], "y");
                                }else{
                                	isEMDDocAvailForPrepareBid.put((Integer)objects[3], "n");
                                }
                            }
                            if(EMDBidderDocCount == tpslService.getOfflinePaymentCount(companyId, tenderId, 2) ){
                            	 modelMap.addAttribute("isEMDBidderDocCount", true);
                            }else{
                            	 modelMap.addAttribute("isEMDBidderDocCount", false);
                            }
                            modelMap.addAttribute("isEMDDocAvail", isEMDDocAvailForPrepareBid);
                        	
                        }
                         isDocFeeOfflinePaid = tpslService.getOfflinePaymentCount(companyId, tenderId, 1) != 0;
                         isDocFeesPaidByExemption = tpslService.getOfflinePaymentPaidByExemption(companyId, tenderId, 1);
                        modelMap.addAttribute("isDocFeeOfflinePaid", isDocFeeOfflinePaid);                        
                        modelMap.addAttribute("isDocFeesPaidByExemption", isDocFeesPaidByExemption);
                        if(isDocFeeOfflinePaid && !isDocFeesPaidByExemption){
                        	List<Object[]> lstTenderDocFeeDocs = tenderCommonService.getTenderBidderDocs(tenderId, companyId,lnkTenderDocPayment);
                        	
                        	Map<Integer,String> isDocFeeAvailForPrepareBid = new HashMap<Integer,String>();
                        	int DocFeesBidderDocCount = 0; 
                            for (Object[] objects : lstTenderDocFeeDocs) {
                                String fPath = docUploadPath.concat((String)objects[4]);
                                File f = new File(fPath);
                                f = abcUtility.CheckDirExist(f);
                                if(f.exists()){
                                	DocFeesBidderDocCount++;
                                	isDocFeeAvailForPrepareBid.put((Integer)objects[3], "y");
                                }else{
                                	isDocFeeAvailForPrepareBid.put((Integer)objects[3], "n");
                                }
                            }
                            if(DocFeesBidderDocCount == tpslService.getOfflinePaymentCount(companyId, tenderId, 1) ){
                           	 modelMap.addAttribute("isDocFeesBidderDocCount", true);
                           }else{
                           	 modelMap.addAttribute("isDocFeesBidderDocCount", false);
                           }
                            modelMap.addAttribute("isDocFeeDocAvail", isDocFeeAvailForPrepareBid);
                        	
                        }
                         isParticipationOfflinePaid = tpslService.getOfflinePaymentCount(companyId, tenderId, 8) != 0;                        
                        modelMap.addAttribute("isParticipationOfflinePaid", isParticipationOfflinePaid);
                         isParticipationPaidByExemption = tpslService.getOfflinePaymentPaidByExemption(companyId, tenderId, 8);
                        modelMap.addAttribute("isParticipationPaidByExemption", isParticipationPaidByExemption);
                        if(isParticipationOfflinePaid && !isParticipationPaidByExemption){
                        	List<Object[]> lstTenderParticipationDocs = tenderCommonService.getTenderBidderDocs(tenderId, companyId,linkBidPreRegChargesOfflinePayment);
                        	Map<Integer,String> isParticipationDocAvailForPrepareBid = new HashMap<Integer,String>();
                        	int ParticipationBidderDocCount = 0; 
                            for (Object[] objects : lstTenderParticipationDocs) {
                                String fPath = docUploadPath.concat((String)objects[4]);
                                File f = new File(fPath);
                                f = abcUtility.CheckDirExist(f);
                                if(f.exists()){
                                	ParticipationBidderDocCount++;
                                	isParticipationDocAvailForPrepareBid.put((Integer)objects[3], "y");
                                }else{
                                	isParticipationDocAvailForPrepareBid.put((Integer)objects[3], "n");
                                }
                            }
                            if(ParticipationBidderDocCount == tpslService.getOfflinePaymentCount(companyId, tenderId, 8) ){
                            	 modelMap.addAttribute("isParticipationBidderDocCount", true);
                            }else{
                            	 modelMap.addAttribute("isParticipationBidderDocCount", false);
                            }
                            modelMap.addAttribute("isParticipationDocAvail", isParticipationDocAvailForPrepareBid);
                        	
                        }
                        modelMap.addAttribute("lstTenderBid", tenderCommonService.getTenderBidDtls(tenderId, companyId, false));
                        modelMap.addAttribute("lstTenderBidCount", tenderCommonService.getTenderBidDtls(tenderId, companyId, true));
                        modelMap.addAttribute("bidWithdrawalDtls", eventBidSubmissionService.getBidWithDrawaldtls(tenderId, companyId));
                        modelMap.addAttribute("rebateList", tenderFormService.getRebateByTenderNCompanyId(tenderId, companyId));
                        
                        List<Object[]> lstTenderBidDtl = tenderCommonService.getTenderBidDtls(tenderId, companyId, false);
                        if(isFormConfirmationReq==1 && lstTenderBidDtl.size()>0){
                            List<Integer> bidsLst = new ArrayList<Integer>();
                            for (Object[] bidDetail : lstTenderBidDtl) {
                                bidsLst.add(Integer.parseInt(bidDetail[0].toString()));
                            }
                            modelMap.addAttribute("bidIds", bidsLst.toString().replace(" ", "").replace("[", "").replace("]", ""));
                        }
                        //Added by Lipi
                        //for eventType for messageBox
                        tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                        break;

                    case TAB_RESULT:
                        auditMsg = postajaxBiddingTenderDashboardContentRES;
                        tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                        boolean isBidderPresenceRegistered = eventBidSubmissionService.isBidderPresenceRegistered(tenderId, companyId);
                        modelMap.addAttribute("isBidderPresenceRegistered", isBidderPresenceRegistered);
                        boolean isFinalSubmission = eventBidSubmissionService.isFinalSubmissionDone(tenderId, companyId);
                        modelMap.addAttribute("isFinalSubmissionDone", isFinalSubmission);
                        modelMap.addAttribute("isTenderBidConfirmation", eventBidSubmissionService.isTenderBidConfirmation(tenderId, companyId));
//                        List<TblShareReport> shareReport = tblShareReportDao.findTblShareReport("tblTender.tenderId",Operation_enum.EQ,tenderId,"isActive",Operation_enum.EQ,1);
//                        if((shareReport.get(0).getShareReport() != 4 || shareReport.get(0).getShareReport() == 3 || shareReport.get(0).getShareReport() == 2 || shareReport.get(0).getShareReport() == 1)  && !eventBidSubmissionService.isTenderBidConfirmation(tenderId, companyId)){
//                        	modelMap.addAttribute("err_bidsub_dt", "msg_tender_fs_submissionenddt_lapse");
//                        }else{
                        isBidderRegretted = eventBidSubmissionService.isBidderRegretted(userId,tenderId);
                        modelMap.addAttribute("isBidderRegretted", isBidderRegretted);
                        modelMap.addAttribute("letestCstatusEncodeDecodeHistory", commonService.getLetestCstatusEncodeDecodeHistory(tenderId));
                        if (isBidderPresenceRegistered) {
                            Map<String, Object> dataMap = null;
                            int isOpeningByCommittee = (Integer) modelMap.get("isOpeningByCommittee");
                            dataMap = tenderOpenService.getTenderOpeningDetails(tenderId, 3);
                            if (dataMap != null && !dataMap.isEmpty()) {
                                setDataForResultTab(modelMap, dataMap, isOpeningByCommittee);
                                
                                List<Integer> objectIds = new ArrayList<Integer>();
    					    	objectIds.add(tenderId);
    							List<Integer> linkIds = new ArrayList<Integer>();
    					    	linkIds.add(400);linkIds.add(401);
    							List<Object[]> lstOfficerResultdocList = fileUploadService.getOfficerAllDocs(objectIds, abcUtility.getSessionClientId(request),  linkIds, 1);
    	    					modelMap.put("lstOfficerResultdocList", lstOfficerResultdocList);
    	    					modelMap.put("tenderId", tenderId);
                            }
                        } else {
                            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
                            isCertRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
                            modelMap.put("isCertRequired", isCertRequired);
                            String certIds[] = null;
                            if (clientBean.getIsPkiEnabled() == pkiEnable || clientBean.getIsPkiEnabled() == pkiEventSpecific && isCertRequired == 1) {
                                if(sessionBean.getCertId()!=null){
                                    certIds = sessionBean.getCertId().split(",");
                                }
                                if (certIds != null && certIds.length != 0) {
                                    modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                                }
                            }
                        }
                        modelMap.addAttribute("isResultShareDone", tenderCommonService.isResultShareDone(tenderId));
                        if((Integer) modelMap.get("isWeightageEvaluationRequired") == 1){
	               		 	List<Object[]> tenderEnvelopeLst=tenderFormService.getTenderEnvelopeListForWeightageScore(tenderId,0);    		
	               		 	List<Integer> envelopeIdsList = new ArrayList<Integer>();
	               		 	List<Object[]> bidderScoreList =  new ArrayList<Object[]>();
	                        if(tenderEnvelopeLst != null && ! tenderEnvelopeLst.isEmpty()){
	            	    		for (Object[] tenderEnvelope : tenderEnvelopeLst) {
	            	    			envelopeIdsList.add(Integer.parseInt(tenderEnvelope[0].toString()));
	            				}
	            	    		if(envelopeIdsList != null && !envelopeIdsList.isEmpty()){
	            	    			int userRoleId = 1;
	            	    			if((Integer) modelMap.get("isTwoStageEvaluation") == 1 ){
	            	    				userRoleId = (Integer) modelMap.get("multiLevelEvaluationReq") == 1 ? 4 : 2;
	            	    			}
	            	    			 bidderScoreList = tenderFormService.getTenderBidderListForWeightageScore(tenderId,envelopeIdsList,abcUtility.getSessionUserId(request),userRoleId);
	            	    			 
	            	    		}
	            	    		modelMap.addAttribute("isWeightageEvalDone", bidderScoreList!=null && !bidderScoreList.isEmpty() ? true : false);
	            	    		List<Object> listSecondaryBidder = eventBidSubmissionService.isBidderSecondaryPartner(tenderId, userId);
	            	    		int isSecondaryBidder = 0;
	            	    		if(listSecondaryBidder != null && listSecondaryBidder.size() > 0){
	            	    			isSecondaryBidder = 1;
	            	    		}
	            	    		modelMap.addAttribute("isSecondaryBidder", isSecondaryBidder);
	                        }
                        }
                        List<TblDynReport> dynReportList=dynamicReportService.getDynReportByTenderId(tenderId);
        				modelMap.addAttribute("reportList",dynReportList);
//                        }
                        break;

                    case TAB_NEGOTIATION:
                    	//Added by Mitesh
                    	 //System.out.println("Inside bidder negotiation listing controller tender side");
                    	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                    	 auditMsg=getBidderNegotationTabListing;
                    	 biddingEventDashboardLinkId=tenderLinkForBidderListingLink;
                         modelMap.addAttribute("linkId",tenderLinkForBidderInvite);
                         modelMap.addAttribute("chatlinkId",tenderLinkForBidderStartChat);
                     //    System.out.println("chat is "+tenderLinkForBidderStartChat);
                    	 modelMap.addAttribute("companyId",companyId);
                    	 modelMap.addAttribute("objectId",tenderId);
                    	 modelMap.addAttribute("reportId",biddersideNegogationListingReportId);
                    	 modelMap.addAttribute("isWorkflowRejected",workflowService.getWorkFlowStatus(1181, tenderId, 4));
             		     reportGeneratorService.getReportConfigDetails(biddersideNegogationListingReportId, modelMap);
             		     //redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_final_submission_success");
                         break;

                    case TAB_APOCO:
                    
                    	int apoType=Integer.valueOf(tenderCommonService.getTenderField(tenderId, "POType").toString());
                    	modelMap.addAttribute("objectId",tenderId);
                    	modelMap.addAttribute("apoType",apoType);
                    	modelMap.addAttribute("apoList",commonService.getAPOListByObjectId(tenderId, abcUtility.getSessionClientId(request), 3,0,apoType,companyId));
                        auditMsg = postajaxBiddingTenderDashboardContentAPO;
                        break;

                    case TAB_PO:
                    	modelMap.addAttribute("objectId",tenderId);
                    	
                    	boolean isDirectPO=true;
    		            List<Object[]> listCMS=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
    		            if (listCMS != null) {
    		                for (int i = 0; i < listCMS.size(); i++) {
    		                	if(listCMS.get(i)[0].toString().equalsIgnoreCase("12")){
    		                		isDirectPO=false;                		 
    		                    }
    		                }
    		            }
                    	int poType=Integer.valueOf(tenderCommonService.getTenderField(tenderId, "POType").toString());
                    	modelMap.addAttribute("poList",commonService.getPOListByObjectId(tenderId, abcUtility.getSessionClientId(request), 3, 0, poType, companyId,isDirectPO));

        				modelMap.addAttribute("isDirectPO",isDirectPO);
        				modelMap.addAttribute("poType",poType);
                        auditMsg = postajaxBiddingTenderDashboardContentPO;
                        break;
                   
                    case TAB_CONTRACT:    
                    	modelMap.addAttribute("objectId",tenderId);
                    	modelMap.addAttribute("contractList", commonService.getContractListForBidder(userId,tenderId)); 
                    	break;
                    	
                    case TAB_PAYMENT:
                    	modelMap.addAttribute("objectId",tenderId);
                        modelMap.addAttribute("userType", abcUtility.getSessionUserTypeId(request));
                        modelMap.addAttribute("lstInvoice", invoiceDocServie.getInvoiceList(tenderId, loginService.getCompanyId(abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request)),abcUtility.getSessionClientId(request)));
                        break;
                        
                    case TAB_CONSORTIUM:
                        auditMsg = postajaxBiddingTenderDashboardContentCON;
                        SelectItem s = new SelectItem("Consortium", 2);
                        List<SelectItem> lst = new ArrayList<SelectItem>();
                        lst.add(s);
                        s = new SelectItem("Individual", 1);
                        lst.add(s);
                        modelMap.addAttribute("lstPartnerType", lst);
                        isBidderRegretted = eventBidSubmissionService.isBidderRegretted(userId,tenderId);
                        modelMap.addAttribute("isBidderRegretted", isBidderRegretted);
                        isBidWithdrawBidder = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
                        modelMap.addAttribute("isBidWithdrawBidder", isBidWithdrawBidder);
                        
                        tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                        lst = new ArrayList<SelectItem>();
                        s = new SelectItem("Lead", 2);
                        lst.add(s);
                        s = new SelectItem("Secondary", 3);
                        lst.add(s);
                        modelMap.addAttribute("lstConsortiumType", lst);
                        


                        if (tblTender.getTenderMode() != 1) /* if tender if limited tender? */ {
                            modelMap.addAttribute("bidderMapped", eventBidSubmissionService.checkBidderMappedWithLimitedTender(tenderId, userId));
                        } else {
                            modelMap.addAttribute("bidderMapped", true);
                        }

                        List<Object> lstResetConsortiumIds = eventBidSubmissionService.checkConsortiumResetForSecondaryPartner(tenderId, userId);
                        if (lstResetConsortiumIds != null && !lstResetConsortiumIds.isEmpty()) {
                            modelMap.addAttribute("consortiumReset", "true");
                        }
                        List<Object> lstConsortiumIds = eventBidSubmissionService.getConsDtlForSecondPartReq(tenderId, userId);
                        if ((modelMap.get("bidderType") != null && modelMap.get("bidderType").toString().equalsIgnoreCase("secondary")) || (lstConsortiumIds != null && !lstConsortiumIds.isEmpty())) {
                            String certIds[] = null;
                            int isPkIEnabled = abcUtility.getSessionIsPkiEnabled(request);
                            int isCertReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
                            if (isPkIEnabled == pkiEnable || (isPkIEnabled == pkiEventSpecific && isCertReq == 1)) {
                                modelMap.put("isPkRequired", true);
                                if(abcUtility.getSessionCertId(request)!=null){
                                    certIds = abcUtility.getSessionCertId(request).split(",");
                                }
                                if (certIds != null && certIds.length != 0) {
                                    modelMap.addAttribute(PUBLICKEY, commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                                }
                            } else {
                                modelMap.put("isPkRequired", false);
                            }
                            int consortiumId = 0;
                            modelMap.addAttribute("bidderType", "secondary");
                            modelMap.addAttribute("lstConsortiumIds", lstConsortiumIds);
                            List<Object[]> lstPendingBidder = eventBidSubmissionService.findSecondaryPartner(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString(), tenderId, abcUtility.getSessionClientId(request));
                            if (lstPendingBidder == null || lstPendingBidder.isEmpty()) {
                                lst = new ArrayList<SelectItem>();
                                s = new SelectItem("Reject", 2);
                                lst.add(s);
                                modelMap.addAttribute("lstAcceptReject", lst);
                            } else {
                                lst = new ArrayList<SelectItem>();
                                s = new SelectItem("Accept", 1);
                                lst.add(s);
                                s = new SelectItem("Reject", 2);
                                lst.add(s);
                                modelMap.addAttribute("lstAcceptReject", lst);
                            }
                            if (lstConsortiumIds != null && !lstConsortiumIds.isEmpty()) {
                                for (Object ob : lstConsortiumIds) {
                                    consortiumId = (Integer) ob;
                                    modelMap.addAttribute("lstConsortDtl_" + consortiumId, eventBidSubmissionService.getSecondaryPartnerRequest(tenderId, consortiumId));
                                }
                            }
                        } else {
                            int consortiumId = 0;
                            // Check individual consortium done?
                            List<Object[]> lstCon = eventBidSubmissionService.getConsortiumIdLeadPartner(userId, tenderId, 1);
                            if (lstCon != null && !lstCon.isEmpty()) {
                                consortiumId = (Integer) lstCon.get(0)[0];
                                modelMap.addAttribute("bidderType", "individual");
                                modelMap.addAttribute("consortiumId", consortiumId);
                            } else {
                                consortiumId = 0;
                                int isFinalJVApproved = 0;
                                // Check Lead partener?
                                lstCon = eventBidSubmissionService.getConsortiumIdLeadPartner(userId, tenderId, 2);
                                if (lstCon != null && !lstCon.isEmpty()) {
                                    consortiumId = (Integer) lstCon.get(0)[0];
                                    isFinalJVApproved = (Integer) lstCon.get(0)[1];
                                }
                                modelMap.addAttribute("bidderType", "lead");
                                if (consortiumId != 0) {
                                    modelMap.addAttribute("consortiumId", consortiumId);
                                    modelMap.addAttribute("isFinalJVApproved", isFinalJVApproved);
                                    modelMap.addAttribute("lstConsortDtl", eventBidSubmissionService.getSecondaryPartnerRequest(tenderId, consortiumId));

                                }
                            }
                        }
                        docDownloadErr = tenderCommonService.isDocumentDateLive(tenderId);
                		errCode = tenderCommonService.isEventLive(tenderId);
                		if(errCode == 0) {
                			modelMap.addAttribute("err_bidsub_dt", "msg_tender_err_msg_bidsub_dt_notarrived");
                		}else if(docDownloadErr == -1 && errCode == -1){
                			modelMap.addAttribute("err_bidsub_dt", "msg_tender_fs_submissionenddt_lapse");
                		}
                        break;
                    case TAB_LOI:
        				modelMap.addAttribute("moduleId", 3);
        				modelMap.addAttribute("objectId", tenderId);
        				List bidderLoiDetails = commonService.getBidderLoiDetails(tenderId, companyId, abcUtility.getSessionClientId(request));
        	    		if(bidderLoiDetails!=null && !bidderLoiDetails.isEmpty()){
        	    			modelMap.addAttribute("biddersList", bidderLoiDetails);
        	    		}
        				break;
                    case TAB_QA:
                    	boolean isQuestionAnswerTimeValid=false;
        				modelMap.addAttribute("moduleId", 3);
        				modelMap.addAttribute("objectId", tenderId);
        				String qaTimeNotice = "";
        				auditMsg = postajaxBiddingTenderDashboardContentQA;
        				int tFlag = 0;
        				List<Object[]> lstQADetails = tenderCommonService.getTenderFields(tenderId, "questionAnswerStartDate,questionAnswerEndDate");
        				 if (!lstQADetails.isEmpty()) {
	        				   Date serverDate=commonService.getServerDateTime();
	                           Date endDate=(Date)lstQADetails.get(0)[1];
	                           Date startDate=(Date)lstQADetails.get(0)[0];
	                           modelMap.addAttribute("endDate", endDate);
	                           modelMap.addAttribute("startDate", startDate);
	                           if ((((endDate).after(serverDate) || (endDate).equals(serverDate)) && ((startDate).before(serverDate) || (startDate).equals(serverDate))) || (endDate).equals(serverDate)) {   
	                        	   isQuestionAnswerTimeValid = true;	
	                        	   tFlag=0;
	                           } else {
	                        	   if((endDate).before(serverDate)){
	                        		   tFlag =1;
	                        		   qaTimeNotice = "question_hours_fininshed";
	                        	   }else if((startDate).after(serverDate)){
	                        		   tFlag=2;
	                        		   qaTimeNotice = "question_hours_not_yet_started";
	                        	   } 
	                           }	   
                           }
        				   modelMap.addAttribute("timeFlag", tFlag);
	                       modelMap.addAttribute("qaTimeNotice", qaTimeNotice);
	                       modelMap.addAttribute("isQuestionAnswerTimeValid", isQuestionAnswerTimeValid);
        				break;
                    case TAB_COMMUNICATION:
                    	List<Integer> list = new ArrayList<Integer>();
            			list.add(3);
            			list.add(6);
            			List<SelectItem> selSubModule = getSubModulSelectItemForCommunication(abcUtility.getSessionClientId(request),list,abcUtility.getSessionUserId(request));
                    	//List<SelectItem> selSubModule = getSubModulSelectItem(abcUtility.getSessionClientId(request),3,0);
            			modelMap.addAttribute("selSubModule", selSubModule);
            			modelMap.addAttribute("eventId", tenderId);
            			modelMap.addAttribute("createdBy", abcUtility.getSessionUserId(request));
            			modelMap.addAttribute("moduleType", 4);
            			commonService.commontenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            			List<SelectItem> selBidder =  getBidderSelectItem(tenderId,(Integer)modelMap.get("tenderMode"));
            			modelMap.addAttribute("selBidder", selBidder);
            			modelMap.addAttribute("userType", abcUtility.getSessionUserTypeId(request));
            			if(abcUtility.getSessionUserTypeId(request) == 1){
            				modelMap.addAttribute("questions",questionAnswerService.getQuestionsForOfficer(tenderId));
            			}else{
            				modelMap.addAttribute("questions", questionAnswerService.getQuestionsForBidder(tenderId,abcUtility.getSessionUserId(request)));
            			}
            			
            			int linkid = 1182;
        				int clientId = abcUtility.getSessionClientId(request);
        				List<Object[]> eventIdlist = commonService.getEventIdFromLinkId(linkid);
        	            int eventIdNew = 0;
        				if(eventIdlist!=null && !eventIdlist.isEmpty()){
        					eventIdNew = Integer.parseInt(eventIdlist.get(0)[1].toString());
        	            }
        	            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventIdNew, clientId);
        	            int allowedSize = 0;
        	            StringBuilder allowedExt = new StringBuilder();
        	            if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
        	                allowedSize = lstDocUploadConf.get(0).getMaxSize();
        	                allowedExt.append(lstDocUploadConf.get(0).getType());
        	                modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
        	            }
        	            int index = allowedExt.toString().indexOf(",");
        	            allowedExt.insert(index + 1, "*.");
        	            while (index >= 0) {
        	                index = allowedExt.toString().indexOf(",", index + ",".length());
        	                allowedExt.insert(index + 1, "*.");
        	            }
        	            modelMap.addAttribute("linkId", linkid);
        	            modelMap.addAttribute("allowedExt", allowedExt);
        	            modelMap.addAttribute("allowedSize", allowedSize/1024);
        	            modelMap.addAttribute("cStatusDoc", 0);
        	            modelMap.addAttribute("cStatusDocView", 0); 
        	            modelMap.addAttribute("showCreatedBy", 0); 
        	         //   modelMap.addAttribute("isReadonly",1);
        	            modelMap.addAttribute("objectIdNew",0);
        	            
        	            
        	            modelMap.addAttribute("cStatusDoc", 5);
        	            modelMap.addAttribute("cStatusDocView", 1);
        	            modelMap.addAttribute("allowFileExist","Y");
        	            
                    	break;
                    case TAB_PARTICIPATION_FEES:
                    	modelMap.addAttribute("objectId",tenderId);
                    	modelMap.addAttribute("moduleId",3);
                    	modelMap.addAttribute("isexcemptionCert",commonService.isexcemptionCert(abcUtility.getSessionClientId(request)));
                        if(tenderCommonService.isSecondaryPartner(tenderId,companyId)>0){
                            //if secondary bidder than not allow to pay participation
                        	String retVal="/etender/bidder/redirecttodashboard/"+tenderId+"/"+tabId;
                            retVal = retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                            modelMap.addAttribute("isSecondary", retVal);
                        }else{
                        	int regMode = tblTender.getRegistrationChargesMode();
                        	int paymentId=0;
                            auditMsg = postajaxBiddingTenderDashboardContentDF;
                            Object[] participationFeePaymentDetail=null;
                            List <Object[]> amountList= tenderCommonService.getTenderPaymentAmount(tenderId,8,tblTender.getIsParticipationFeesBy(),companyId,0);
                            String amount="";
                            int regCharges =  tblTender.getIsRegistrationCharges();
                            String uniqueId = "";
                            if(amountList != null && !amountList.isEmpty()){
                                for (int i = 0; i < amountList.size(); i++) {
                                	amount += amountList.get(i)[0].toString() + ",";
                                	if(regCharges!=0){
                                		uniqueId = amountList.get(i)[1].toString();
                                	}
                                }
                            }
                            BigDecimal netAmount = new BigDecimal("0.00");
                            if(amount.length()>0){
	                            String gstAmount = amount.substring(0, amount.length()-1);
	                            String amountArray[] = gstAmount.split(",",gstAmount.length());
	                            for(int i=0;i<amountArray.length;i++){
	                            	netAmount = netAmount.add(new BigDecimal(amountArray[i]));
	                            }
                            }
                            int isGSTRequired = (Integer)tenderCommonService.getTenderField(tenderId, "isGSTRequired");
                            if(commonService.getCountryIdByCompanyId(companyId)!=countryId){
                            	isGSTRequired = 0;
                            }
                            modelMap.addAttribute("isGSTRequired", isGSTRequired);
                            participationFeePaymentDetail = tpslService.getPaymentDetail(8, tenderId, companyId,1,3,regMode,uniqueId);
                            modelMap.addAttribute("decimalValueUpto",tblTender.getDecimalValueUpto());
                            modelMap.addAttribute("chkpaymentMode",regMode);
                            errCode = tenderCommonService.isEventLive(tenderId);
                            if (errCode == -1 ) {
                                modelMap.addAttribute("errCode", errCode);                        
                            }   
                            
                            Object[] obj=clientService.getClientFields(abcUtility.getSessionClientId(request),"paymentConfigBy,deptId");
    	            		int paymentConfigBy=Integer.valueOf(obj[0].toString());
    	            		int deptId=tblTender.getTblDepartment().getDeptId();
    	            		if(paymentConfigBy==1 ){
    	            			deptId=Integer.valueOf(obj[1].toString());
    	            		}
    	            		
    	            		List<Object[]> PaymentDetails = tpslService.getPaymentDetails(8, tenderId, companyId, -1, 3, regMode,uniqueId);
    	            		boolean isPaymentDetailsUpdate=false;
    	            		if(PaymentDetails!=null && !PaymentDetails.isEmpty()){
    	            			paymentId=Integer.parseInt(PaymentDetails.get(0)[regMode==3?2:1].toString());
	            				modelMap.addAttribute("paymentId",paymentId);
	            			}
    	            		if(PaymentDetails!=null){
    	            			if(!tpslService.isOnlinePaymentDone(8, tenderId, companyId, 3, "")){
	        	            		for(Object[] paymentDetail : PaymentDetails){
	        	            			
	        	            			if(!"0399".equals(paymentDetail[0]) && !"0300".equals(paymentDetail[0]) && Integer.parseInt(paymentDetail[regMode==3?6:5].toString()) ==1 && Integer.parseInt(paymentDetail[regMode==3?9:8].toString())==0 || (null == paymentDetail[0] && Integer.parseInt(paymentDetail[regMode==3?9:8].toString())==0 )){//If Payment is not Field/Success ,  paymentType is Payment Gateway and cstatus is 0
	        	            				isPaymentDetailsUpdate=true;
											try{
	        	            				boolean isReconcilationDone = tpslService.paymentReconcilation(8, regMode==3 ? Integer.parseInt(paymentDetail[2].toString()): Integer.parseInt(paymentDetail[1].toString()), clientBean.getClientId(), regMode==3 ? paymentDetail[3].toString(): paymentDetail[2].toString(),deptId);
	                                         if (isReconcilationDone) {
	                                        	 amount = "";
	                                        	 amountList= tenderCommonService.getTenderPaymentAmount(tenderId,8,tblTender.getIsParticipationFeesBy(),companyId,0);
	                                        	 if(amountList != null && !amountList.isEmpty()){
	                                                for (int i = 0; i < amountList.size(); i++) {
	                                                	amount += amountList.get(i)[0].toString() + ",";
	                                                	if(regCharges!=0){
	                                                		uniqueId = amountList.get(i)[1].toString();
	                                                	}
	                                                }
	                                            }
	                                        	 participationFeePaymentDetail = tpslService.getPaymentDetail(8, tenderId, companyId,1,3,regMode,uniqueId);
	                                         }
											 }catch(Exception e){
		        	            			 exceptionHandlerService.writeLog(e);
											}
	        	            			}
	        	            		}
    	            			}
    	            		}
    	            		if(isPaymentDetailsUpdate){
    	            		PaymentDetails = tpslService.getPaymentDetails(8, tenderId, companyId, -1, 3, regMode,uniqueId);
    	            		}
    	            		modelMap.addAttribute("PaymentDetails", PaymentDetails);
    	            		
                            if (participationFeePaymentDetail == null) {
                            	if (errCode == -1 ) {
                                    modelMap.addAttribute("err_bidsub_dt", "msg_tender_fs_submissionenddt_lapse");
                                }
                            	if(commonService.checkTenderCancel(tenderId)>0){
                         			modelMap.addAttribute("isEventCancel", 1);
                             	}
                            	participationFeePaymentDetail = tpslService.getPaymentDetail(8, tenderId, companyId,0,3,regMode,uniqueId);
//                            	if (participationFeePaymentDetail != null && !"0300".equals(participationFeePaymentDetail[0])) {
//	                            	
//	        	            		/* Priyanka Work starts here*/
//	        	            		if(bankId ==2 || bankId == 4)
//	        	            		{
//	        	            			Object[] docFeeeRefundAccountDetail =  tpslService.getRefundAccountDetail(abcUtility.getSessionClientId(request), companyId);
//	                                    if (docFeeeRefundAccountDetail != null) {
//	                                    	  modelMap.addAttribute("docFeeeRefundAccountDetail", docFeeeRefundAccountDetail);
//	                                    }
//	        	            		}
//	                                	/* Priyanka Work ends here*/
//                                    
//                            	}
                            }
                            if (participationFeePaymentDetail != null && "0300".equals(participationFeePaymentDetail[0])) {
                                    if("6".equals(regMode==3 ? participationFeePaymentDetail[6].toString() : participationFeePaymentDetail[5].toString())){
                                            Object[] exemptionCertificate =  tpslService.getExemptionCertificateByPaymentId(Integer.parseInt(regMode==3 ? participationFeePaymentDetail[2].toString() : participationFeePaymentDetail[1].toString()));
                                            TblExemptionCertConf tblExemptionCertConf = (TblExemptionCertConf) exemptionCertificate[0];
                                            modelMap.addAttribute("tblExemptionCertConf", tblExemptionCertConf);
                                            modelMap.addAttribute("docList",tpslService.getExemptionCertificateDocs(tblExemptionCertConf.getExemptionCertConfId()));
                                    }
                                    modelMap.addAttribute("paymentDetail", participationFeePaymentDetail);
                            } else {
                                    modelMap.addAttribute("certTypeList", abcUtility.convert(tenderBriefcaseService.getExemptionCertificateType(abcUtility.getSessionClientId(request))));
                                    if(regMode!=2){
                                    	List<SelectItem> payTypeList  = null;
                                    	payTypeList = commonService.getPaymentType(1,abcUtility.getSessionClientId(request),8,tenderId);
                                    	
                                    	modelMap.addAttribute("payTypeList", payTypeList);
                                    	modelMap.addAttribute("chRDModeOfPayment",!payTypeList.isEmpty()?payTypeList.get(0).getValue().toString():0);
                                    }else{
                                    	List<SelectItem> payTypeList  = null;
                                    	payTypeList = commonService.getPaymentType(2,abcUtility.getSessionClientId(request),8,tenderId);
//                                    	TblClientPayment tblClientPayment = clientService.getClientPaymentExemptionByclientId(abcUtility.getSessionClientId(request));
//                                    	if(tblClientPayment!=null){
//                                    		payTypeList.add(new SelectItem("Exemption Certificate",6));
//                                    	}
                                    	modelMap.addAttribute("payTypeList", payTypeList);
                                    	modelMap.addAttribute("chRDModeOfPayment",!payTypeList.isEmpty()?payTypeList.get(0).getValue().toString():0);
                                    }
                                    if(regMode==3){
                                    	List<SelectItem> payModeList = new ArrayList<SelectItem>();
                                    	payModeList.add(new SelectItem("Online",1));
                                    	payModeList.add(new SelectItem("Offline",2));
                    					modelMap.addAttribute("payModeList", payModeList);
                    					
                                    }
                                    if(participationFeePaymentDetail != null && (regMode==2 || regMode==3))
                                    {
                                    	if(regMode==2){
                                    		paymentId = Integer.parseInt(participationFeePaymentDetail[1].toString());
                                    	}else{
                                    		paymentId = Integer.parseInt(participationFeePaymentDetail[2].toString());	
                                    		modelMap.addAttribute("chRDModeOfPayment",1);
                                    	}
                                    	modelMap.addAttribute("paymentId",paymentId);
                                    	TblOfflinePayment tblofflinePayment=tpslService.getOfflinePaymentDetail(paymentId);
                                    	TblPayment tblPayment  = tpslService.getPaymentDetail(paymentId);
                                    	  if(tblPayment!=null){
                                          	modelMap.addAttribute("chkpaymentMode",regMode);
                                          	if(tblPayment.getCstatus()==1){
	                                          	modelMap.addAttribute("payTypeList", commonService.getPaymentType(1,abcUtility.getSessionClientId(request),8,tenderId));
	                                          	modelMap.addAttribute("chRDModeOfPayment",tblPayment.getTblPaymentType().getPaymentTypeId());
                                          	}
                                          }
                                    	if(tblofflinePayment!=null && tblPayment!=null){
                                    		 uniqueId = tblPayment.getUniqueId();
                                             if("6".equals(regMode==3 ? participationFeePaymentDetail[6].toString() : participationFeePaymentDetail[5].toString()) && tblTender.getIsParticipationFeesBy() !=0 && amountList.isEmpty() && amountList !=null ){
                                            	 amount = tpslService.tenderFeesByUniqueId(uniqueId).get(0).toString();
                                             }else if(tblTender.getIsRegistrationCharges()==2){
                                            	 amount = regMode==3 ? participationFeePaymentDetail[4].toString() : participationFeePaymentDetail[3].toString();
                                             }else{
                                            	 amount = amount.replace(",", "");
                                             }
                                    		 boolean isFinalSubmissionDone = eventBidSubmissionService.isFinalSubmissionDone(tenderId, companyId);
                                    		 boolean isBidWithdraw = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
                                             if(tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && !isFinalSubmissionDone && !isBidWithdraw){
//                                    		 boolean isBidWithdraw = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
//                                             if (tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && !isFinalSubmissionDone && !isBidWithdraw ) {
                                             		modelMap.addAttribute("offlinePayment",tblofflinePayment);
                                             		List<SelectItem> payTypeList  = null;
                                             		payTypeList = commonService.getPaymentType(2,abcUtility.getSessionClientId(request),8,tenderId);
                                             		modelMap.addAttribute("payTypeList", payTypeList);
                                             		modelMap.addAttribute("chRDModeOfPayment",tblPayment.getTblPaymentType().getPaymentTypeId());
                                             		modelMap.addAttribute("isEdit",1);
                                             }else
                                             {
                                        	 modelMap.addAttribute("paymentDetail", participationFeePaymentDetail);
                                        	 modelMap.addAttribute("chkpaymentMode",regMode);
                                        	 modelMap.addAttribute("isEdit",0);
                                        	 amount = "";
                                             }
                                             if("6".equals(regMode==3 ? participationFeePaymentDetail[6].toString() : participationFeePaymentDetail[5].toString())){
                                                 Object[] exemptionCertificate =  tpslService.getExemptionCertificateByPaymentId(regMode==3 ? Integer.parseInt(participationFeePaymentDetail[2].toString()) : Integer.parseInt(participationFeePaymentDetail[1].toString()));
                                                 if(exemptionCertificate!=null){
                                                 TblExemptionCertConf tblExemptionCertConf = (TblExemptionCertConf) exemptionCertificate[0];
                                                 modelMap.addAttribute("tblExemptionCertConf", tblExemptionCertConf);
                                                 modelMap.addAttribute("docList",tpslService.getExemptionCertificateDocs(tblExemptionCertConf.getExemptionCertConfId()));
                                                 }
                                        	 }
                                             modelMap.addAttribute("linkId", linkBidPreRegChargesOfflinePayment);
                                             modelMap.addAttribute("chkpaymentMode",regMode);
                                 			 modelMap.addAttribute("remark",tblPayment.getRemark());
                                 			 modelMap.addAttribute("offlinepaymentDetail", tblofflinePayment);
                                    	}
                                    	 lstDocUploadConf = commonService.getDocUploadConf(regOfflinePaymentEventId, abcUtility.getSessionClientId(request));
                                    	 allowedSize = 0;
                                         allowedExt = new StringBuilder();
                                    	allowedSize = lstDocUploadConf.get(0).getMaxSize();
                                    	allowedExt.append(lstDocUploadConf.get(0).getType());
                                    	modelMap.addAttribute("allowedExt", allowedExt);
                                        modelMap.addAttribute("allowedSize", allowedSize/1024);
                                    }
                                    int isPkIEnabled = abcUtility.getSessionIsPkiEnabled(request);
                                    int isCertReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
                                    if (isPkIEnabled == pkiEnable || (isPkIEnabled == pkiEventSpecific && isCertReq == 1)) {
                                        modelMap.put("isPkRequired", true);
                                    } else {
                                        modelMap.put("isPkRequired", false);
                                    }
                                    modelMap.addAttribute("isRegistrationCharges",tblTender.getIsRegistrationCharges());
                                    modelMap.addAttribute("amountList",amount);
                                    modelMap.addAttribute("uniqueId",uniqueId);
                                    modelMap.addAttribute("isByBidder", tblTender.getIsParticipationFeesBy());
                                    modelMap.addAttribute("companyId",companyId);
                            }
                            if(amountList!=null && !amountList.isEmpty()){
                            	tenderCommonService.getNetAmountAndTax(modelMap,abcUtility.getSessionClientId(request),userId,8,netAmount,1,0);
                            }
                            else if(participationFeePaymentDetail!=null){
                            	if(regMode==3){
                            		netAmount = new BigDecimal("0.00");
                            		netAmount = netAmount.add(new BigDecimal(participationFeePaymentDetail[4].toString()));
                            		tenderCommonService.getNetAmountAndTax(modelMap,abcUtility.getSessionClientId(request),userId,8,netAmount,1,1);
                            	}else if(regMode!=3){
                            		netAmount = new BigDecimal("0.00");
                            		netAmount = netAmount.add(new BigDecimal(participationFeePaymentDetail[3].toString()));
                            		tenderCommonService.getNetAmountAndTax(modelMap,abcUtility.getSessionClientId(request),userId,8,netAmount,1,1);
                            	}
                            }
                            boolean isFinalSubmissionDone = eventBidSubmissionService.isFinalSubmissionDone(tenderId, companyId);
                            boolean isBidWithdraw = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
                         if(tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && !isFinalSubmissionDone && !isBidWithdraw){
//                            boolean isBidWithdraw = eventBidSubmissionService.isBidWithdrawal(tenderId, companyId);
//                            if (tblTender.getSubmissionEndDate().compareTo(commonService.getServerDateTime()) > 0 && !isFinalSubmissionDone && !isBidWithdraw ) {
                            	modelMap.addAttribute("isEdit",1);
                            }
                        }
                        break;
                }
                
                modelMap.addAttribute("isCompanyMapped", isCompanyMapped);
                modelMap.addAttribute("companyId", companyId);
                modelMap.addAttribute("isRebateForm", isRebateForm);
                modelMap.addAttribute("isConsortium", isConsortium);
                modelMap.addAttribute("isDocsMandatory", isDocsMandatory);
                modelMap.addAttribute("isPkiMapped", tenderCommonService.isTenderPublicKeyMapped(tenderId));
                modelMap.addAttribute("isDocUploaded", isDocUploaded);
                List<Integer> cStatusList=new ArrayList<Integer>();
                cStatusList.add(1);
                modelMap.addAttribute("tenderEnvelopeLst", tenderCommonService.getTenderEnvelopeByTenderId(tenderId, isConsortium,false,cStatusList));
                modelMap.addAttribute("tenderFormLst", tenderCommonService.getTenderFormByTenderId(true, isConsortium, tenderId, formStatus,tenderMode,itemwiseWinner,companyId));
                modelMap.addAttribute("isFinalSubmission", tenderCommonService.isFinalBidSubmision(tenderId, companyId));
                modelMap.addAttribute("isItemWiseDocAllowed", tenderCommonService.isItemWiseDocAllowed(tenderId));
                modelMap.addAttribute(TAB_ID, tabId);
                modelMap.addAttribute(TENDER_ID, tenderId);
                /*** --- For CR Id : 51268 and PT : 51630 Start --- ***/
                modelMap.addAttribute("isResultShow",true);
                if(tblTender.getIsResultSharingDurationRequired()==1){
                	boolean isResultSharingDone = tenderCommonService.isResultShareDone(tenderId);
                	if((tblTender.getResultSharing()==1)){
                	Calendar calDurationDate = Calendar.getInstance();
                	calDurationDate.setTime(tblTender.getOpeningDate());
                	calDurationDate.add(Calendar.DAY_OF_MONTH, tblTender.getResultSharingDuration());
					if (calDurationDate.getTime().before(commonService.getServerDateTime())) {
			        	modelMap.addAttribute("isResultShow",false);
			         } 
                	}
                	else if(tblTender.getResultSharing()==2 && isResultSharingDone){
                		Date createdOn = tblShareReportDao.findTblShareReport("tblTender.tenderId",Operation_enum.EQ,tenderId,"isActive",Operation_enum.EQ,1).get(0).getCreatedOn();
                    	Calendar calDurationDate = Calendar.getInstance();
                    	calDurationDate.setTime(createdOn);
                    	calDurationDate.add(Calendar.DAY_OF_MONTH, tblTender.getResultSharingDuration());
    					if (calDurationDate.getTime().before(commonService.getServerDateTime())) {
    			        	modelMap.addAttribute("isResultShow",false);
    			         } 
                	}
                  }
                /*** --- For CR Id : 51268 and PT : 51630 End --- ***/
            } else {
                modelMap.addAttribute("sessionExpired", true);
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
			if(!StringUtils.hasLength(auditMsg)) {
            	auditMsg = ("blank_"+tabId+"_"+request.getHeader("referer")).substring(0, 99);
            }
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), biddingEventDashboardLinkId, auditMsg, tenderId, 0);
        }
        return "/etender/bidder/BiddingTenderDashboardContent";
    }
    private List<SelectItem> getBidderSelectItem(int eventId,int tenderMode) throws Exception{
		List<SelectItem> selBidder = new ArrayList<SelectItem>(); 
		if(tenderMode == 1){
			List<Object[]> TblTenderBidConfirmationByTenderId = questionAnswerService.getTblTenderBidConfirmationByTenderId(eventId);
			for (Object[] objects : TblTenderBidConfirmationByTenderId) {
				selBidder.add(new SelectItem(objects[1],objects[0]));	
			}
		}else {
			List<Object[]> TblTenderBidConfirmationByTenderId = questionAnswerService.getTblTenderBidderMapByTenderId(eventId);
			for (Object[] objects : TblTenderBidConfirmationByTenderId) {
				selBidder.add(new SelectItem(objects[1],objects[0]));	
			}
		}
		return selBidder;
	}
    private List<SelectItem> getSubModulSelectItemForCommunication(int clientId, List<Integer> moduleType,int userType) throws Exception {
		List<SelectItem> selSubModule = new ArrayList<SelectItem>(); // SubmoduleType
		List<Object[]> subModuleListData = questionAnswerService.getSubModule(clientId,moduleType);
     	for (Object[] objects : subModuleListData) {
     		/*if(userType == 2) {
     			if(Integer.parseInt(objects[0].toString()) != prebidMeetingId) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
     			if(Integer.parseInt(objects[0].toString()) != 60) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     		if(Integer.parseInt(objects[0].toString()) != 61) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     	} else {
	     		if(Integer.parseInt(objects[0].toString()) != prebidMeetingId) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     	}*/
     		if(Integer.parseInt(objects[0].toString()) != 31) {
     			selSubModule.add(new SelectItem(objects[1],objects[0]));
     		}
		}
		return selSubModule;
	}


    @ResponseBody
    @RequestMapping(value = "/consortiumstatus", method = RequestMethod.POST)
    public String consortiumstatus(RedirectAttributes redirectAttributes,@RequestParam(HIDDEN_TENDER_ID) int tenderId,@RequestParam("txtPayfor") int payFor,
    		HttpSession httpSession,HttpServletRequest request,HttpServletResponse response, ModelMap modelMap) {
    	String auditMsg = "";
        String retVal="";
        boolean isPendingSecondaryPartner=false;
        boolean isSecondaryPartner=false;
        try {
        	if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            	SessionBean sBean =(SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
        	List<Object> list=eventBidSubmissionService.getConsDtlForSecondPartReq(tenderId, abcUtility.getSessionUserId(request));
        	 isPendingSecondaryPartner = list!=null && !list.isEmpty() ? true :false;
             modelMap.addAttribute("isPendingSecondaryPartner",isPendingSecondaryPartner);
             int companyId = sBean.getCompanyId();
              isSecondaryPartner =(tenderCommonService.isSecondaryPartner(tenderId,companyId)>0 ? true : false);
         	if((isPendingSecondaryPartner || isSecondaryPartner) && payFor==8) {
         		retVal="etender/bidder/biddingtenderdashboard/" + tenderId + "/2";
         		retVal=retVal+ encryptDecryptUtils.generateRedirect(retVal, request);
     		}else{
     			retVal="consortiumstatussuccess";
     		}
        	}else {
        		retVal= "sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), biddingEventDashboardLinkId, auditMsg, tenderId, 0);
        }

        return retVal;
    }
    
    @SuppressWarnings("unchecked")
    private void setDataForResultTab(ModelMap modelMap, Map<String, Object> dataMap, int isOpeningByCommittee) {
        int resultSharing = 0;
        TenderOpenProcessDTBean openProcessDTBean = new TenderOpenProcessDTBean();
        List<LinkedHashMap<String, Object>> tenderDetailList = (List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-1");
        openProcessDTBean.setTenderDetailsList(tenderDetailList);
        openProcessDTBean.setEnvelopeList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-2"));
        openProcessDTBean.setBidderDetailList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-3"));
        openProcessDTBean.setVerifyList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-4"));
        if (tenderDetailList != null && !tenderDetailList.isEmpty()) {
            resultSharing = (Short) tenderDetailList.get(0).get("resultSharing");
        }
        if (resultSharing == 2) {//For Manual Result sharing =2
            List<LinkedHashMap<String, Object>> reportDataList = (List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-5");
            if (reportDataList != null && !reportDataList.isEmpty()) {
                openProcessDTBean.setTblShareReportMap(reportDataList.get(0));
            }
            if (isOpeningByCommittee == 1) {
                openProcessDTBean.setCommitteeMemeberList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-6"));
            }
        } else {
            if (isOpeningByCommittee == 1) {
                openProcessDTBean.setCommitteeMemeberList((List<LinkedHashMap<String, Object>>) dataMap.get("#result-set-5"));
            }
        }
        modelMap.addAttribute("resultSharing", resultSharing);
        modelMap.addAttribute("openProcessDTBean", openProcessDTBean);
    }
        
    private void setWeightageEvaluation(int tenderId, ModelMap modelMap) throws Exception{
    	boolean isWeightageEvaluationConfigDone = true;
		List<Object[]> tenderEnvelopeList=tenderFormService.getTenderEnvelopeListForWeightageScore(tenderId,1);
		List<Integer> envelopeIdsList = new ArrayList<Integer>();
		if(tenderEnvelopeList != null && ! tenderEnvelopeList.isEmpty()){
			BigDecimal envTotMarks = new BigDecimal(0);
    		for (Object[] tenderEnvelope : tenderEnvelopeList) {
    			int envelopeId = Integer.parseInt(tenderEnvelope[0].toString());
    			envelopeIdsList.add(envelopeId);
    				envTotMarks = envTotMarks.add(new BigDecimal(tenderEnvelope[9] != null ? tenderEnvelope[9].toString() : "0".toString()));
			}
    		int isAllEnvsTotMarks100 = envTotMarks.compareTo(new BigDecimal(100));
    		if(isAllEnvsTotMarks100 == 0){				// all Envelope Scoring Marks should be 100
    			List<Object[]> tenderWeightageMarksFormList = tenderFormService.getWeightageTotalMarksForAllForm(tenderId,envelopeIdsList);
    			if(tenderWeightageMarksFormList != null && !tenderWeightageMarksFormList.isEmpty())
    			{
    				for (Object[] tenderWeightageMarksForm : tenderWeightageMarksFormList) {
    					BigDecimal formTotMarks = new BigDecimal(tenderWeightageMarksForm[1].toString());
    					int isFormsTotMarks100 = formTotMarks.compareTo(new BigDecimal(100));  // all forms of envelope scoring Marks should be 100
    					if(isFormsTotMarks100 != 0)
    						isWeightageEvaluationConfigDone = false;
    				}
    			}
    		}
    		else{
    			isWeightageEvaluationConfigDone = false;
    		}
		 }
		modelMap.put("isWeightageEvaluationConfigDone", isWeightageEvaluationConfigDone);
    }
    
    /**
     * Method use for invite bidder is valid for secondary partner.
     * @author dipal
     * @param loginId
     * @param consortiumId
     * @param tenderId
     * @param response
     * @param httpSession
     * @param request
     * @param eventType
     * @throws IOException
     */
    @RequestMapping(value = {"/ajaxcall/inviteSecondaryPartner"}, method = RequestMethod.POST)
    public void inviteSecondaryPartner(@RequestParam("txtLoginId") String loginId, @RequestParam(HIDDEN_CONSORTIUM_ID) int consortiumId, @RequestParam(HIDDEN_TENDER_ID) int tenderId, @RequestParam("txtStake") float txtStake,@RequestParam("hdEventType") String eventType, HttpServletResponse response, HttpServletRequest request) throws IOException {
        String res = "userNotFound";
        int bidderId = 0;
        try {
            int userId = abcUtility.getSessionUserId(request);
            int clientId = abcUtility.getSessionClientId(request);
            if (userId != 0) {
                if(!eventBidSubmissionService.checkConsortiumFinalProcessPending(consortiumId))
                {
                     res = "msg_consortium_already_finihsed";
                }
                else if (eventBidSubmissionService.checkSecondaryPartenerReqAlreadySend(loginId, consortiumId, tenderId)) {
                    res = "requestAlreadySend";
                } else {
                    List<Object[]> lst = eventBidSubmissionService.findSecondaryPartner(loginId, tenderId, clientId);
                    if (lst != null && !lst.isEmpty()) {
                        res = "";
                        
                        String invitedcompanyname = lst.get(0)[2].toString();
                        bidderId = (Integer) lst.get(0)[0];
                        TblConsortiumDetail tblConsortiumDetail = new TblConsortiumDetail();
                        tblConsortiumDetail.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                        tblConsortiumDetail.setCstatus(0);
                        tblConsortiumDetail.setPartnerStake(new BigDecimal(txtStake));
                        tblConsortiumDetail.setPartnerType(3);
                        tblConsortiumDetail.setTblConsortium(new TblConsortium(consortiumId));
                        tblConsortiumDetail.setTblCompany(new TblCompany((Integer) lst.get(0)[1]));
                        tblConsortiumDetail.setTblUserDetail(new TblUserDetail(loginService.getBidderUserDetailId(bidderId)));
                        tblConsortiumDetail.setTblUserLogin(new TblUserLogin(bidderId));
                        tblConsortiumDetail.setRemarks("");
                        if (eventBidSubmissionService.addSecondaryPartner(tblConsortiumDetail)) {
                            res = "sucessed";
                            res += "::" + eventBidSubmissionService.getConsortiumDetailTable(tenderId, consortiumId, request);

                            /**
                             * ********** Send Mail for invitation *********
                             */
                          StringBuilder str = eventBidSubmissionService.getSecondayPartenerEmailIds(consortiumId, userId);                            
                            if (loginId != null && !"".equalsIgnoreCase(loginId)) {
                            	Map<String, Object> mailParams = new HashMap<String, Object>();
                                mailParams.put("to", loginId);
                                String companyName = "";
                                List<Object[]> lstCompDetail = commonService.getCompanyDetailsByUserId(userId, clientId);
                                if (lstCompDetail != null && !lstCompDetail.isEmpty()) {
                                    companyName = lstCompDetail.get(0)[0].toString();
                                }
                                //Added by Lipi - Start
                                //for eventType for messageBox
                                MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
                                messageConfigDatabean.setQueueName(queueName);
                                messageConfigDatabean.setTemplateId(Integer.parseInt(inviteConsortiumTemplateId));
                                messageConfigDatabean.setUserId(userId);
                                messageConfigDatabean.setClientId(clientId);
                                messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
                                messageConfigDatabean.setContextPath(request.getContextPath());
                                messageConfigDatabean.setObjectId(tenderId);
                                mailParams.put("companyname", companyName);
                                mailParams.put("invitedcompanyname", invitedcompanyname);
                                mailParams.put("tenderid", tenderId);
                                mailParams.put("tenderno", tenderCommonService.getTenderField(tenderId, "tenderNo"));
                                mailParams.put("eventType", eventType);
                                mailParams.put("brief", tenderCommonService.getTenderField(tenderId, "tenderBrief"));
                                String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/biddingtenderdashboard/" + tenderId + "/" + TAB_CONSORTIUM);
                            	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                            	mailParams.put("link", herfStr);
                            	messageConfigDatabean.setParamMap(mailParams);
                            	messageQueueService.sendMessage(messageConfigDatabean);
                            	//End 
                            }

                        } else {
                            res = "failed";
                        }
                    }
                }
                response.getWriter().write(res);
            }
            else
            {
               response.getWriter().write("sessionexpired"); 
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), lnkAddConsPart, ajaxInviteConsPartner, tenderId, consortiumId);
        }
    }

    /**
     * Method use for check bidder is valid for secondary partner.
     * @author dipal
     * @param loginId
     * @param consortiumId
     * @param tenderId
     * @param response
     * @param httpSession
     * @param request
     * @throws IOException
     */
    @RequestMapping(value = {"/ajaxcall/searchSecondaryPartner"}, method = RequestMethod.POST)
    public void searchSecondaryPartner(@RequestParam("txtLoginId") String loginId, @RequestParam(HIDDEN_CONSORTIUM_ID) int consortiumId, @RequestParam(HIDDEN_TENDER_ID) int tenderId, HttpServletResponse response, HttpServletRequest request,RedirectAttributes redirectAttributes) throws IOException {
        String res = "userNotFound";
        HttpSession session = request.getSession();
   	 	SessionBean sessionBean=(SessionBean)session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
        int bidderId = sessionBean.getUserId(); 
        try {
        	bidderId = commonService.getUserIdByLoginId(loginId);
        	boolean isBidderRegretted = eventBidSubmissionService.isBidderRegretted(bidderId,tenderId);
		 	if(isBidderRegretted)
		       	{
		       		//redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"already_regrett_bidder_consortium");
		       	 //res = "already_regrett_bidder_consortium";
		       	 //response.getWriter().write(res);
		       	}
		       	else
		       	{
            int clientId =  abcUtility.getSessionClientId(request);
            TblUserLogin tblUserLogin=eventBidSubmissionService.getUserIdByLoginId("loginId");
            if (abcUtility.getSessionUserId(request) != 0) {
                if(!eventBidSubmissionService.checkConsortiumFinalProcessPending(consortiumId))
                {
                     res = "msg_consortium_already_finihsed";
                }
                else if (eventBidSubmissionService.checkSecondaryPartenerReqAlreadySend(loginId, consortiumId, tenderId)) {
                    // Check Lead partener?
                   //bidderId = commonService.getUserIdByLoginId(loginId);
                   List<Object[]> lstCon = eventBidSubmissionService.getConsortiumIdLeadPartner(bidderId, tenderId, 2);
                    if (lstCon != null && !lstCon.isEmpty() && consortiumId == ((Integer) lstCon.get(0)[0])) 
                    {
                           res = "msg_consortium_cannot_invite_lead";
                    }
                    else
                    {
                        res = "requestAlreadySend";
                    }
                } else {
                    List<Object[]> lst = eventBidSubmissionService.findSecondaryPartner(loginId, tenderId, clientId);
                    if (lst == null || lst.isEmpty()) {
                        res = "userNotFound";
                    } else {
                        res = "<a href='" + request.getServletContext().getContextPath() + "/common/admin/viewbidderprofile/" + lst.get(0)[0] + encryptDecryptUtils.generateRedirect("common/admin/viewbidderprofile/" + lst.get(0)[0], request) + "' target='blank'>" + lst.get(0)[2] + "</a>";
                    }
                }
                response.getWriter().write(res);
            }
            else{
                response.getWriter().write("sessionexpired");
            }
        }
		 	} catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), lnkAddConsPart, ajaxSearchConsPartner, tenderId, consortiumId);
        }
    }

    /**
     * Method user for process remove secondary partner request of consortium.
     * @author dipal
     * @param tenderId
     * @param bidderId
     * @param consortiumId
     * @param response
     * @param httpSession
     * @param request
     * @throws IOException
     */
    @RequestMapping(value = {"/ajaxcall/removeSecondaryConsortiumBidder"}, method = RequestMethod.POST)
    public void removeSecondaryConsortiumBidder(@RequestParam(HIDDEN_TENDER_ID) int tenderId, @RequestParam("txtbidderId") int bidderId, @RequestParam(HIDDEN_CONSORTIUM_ID) int consortiumId, HttpServletResponse response, HttpSession httpSession, HttpServletRequest request) throws IOException {
        StringBuilder res = new StringBuilder();
        try {
            if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                if (eventBidSubmissionService.removeSecondaryPartner(consortiumId, bidderId)) {
                    res = eventBidSubmissionService.getConsortiumDetailTable(tenderId, consortiumId, request);
                } else {
                    res.append("failed");
                }
                response.getWriter().write(res.toString());
            }
            else
            {
                response.getWriter().write("sessionexpired");
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), lnkRemoveConsPart, ajaxRemoveConsPartner, tenderId, consortiumId);
        }
    }

    /**
     * Method use for process accept / reject consortium request by secondary partner.
     * @author dipal
     * @param tenderId
     * @param consortiumId
     * @param httpSession
     * @param request
     * @param modelMap
     * @param rea
     * @return
     * @throws IOException
     */
    @RequestMapping(value = {"/submitAcceptRejectInvitation"}, method = RequestMethod.POST)
    public String submitAcceptRejectInvitation(@RequestParam(HIDDEN_TENDER_ID) int tenderId, @RequestParam(HIDDEN_CONSORTIUM_ID) int consortiumId, HttpSession httpSession, HttpServletRequest request, ModelMap modelMap, RedirectAttributes rea) throws IOException {
        String page = "etender/bidder/biddingtenderdashboard/" + tenderId + "/" + TAB_CONSORTIUM;
        String remarks = "";
        int selectRequest = 0;
        int linkId = 0;
        String auditTrail=postAcceptConRequest;
         SessionBean sBean = (SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
        String eventType = "";
        try {
            if (sBean != null) {
                int userId = sBean.getUserId();
                eventType = StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
                modelMap.addAttribute(TENDER_ID, tenderId);
                modelMap.addAttribute(TAB_ID, TAB_CONSORTIUM);
                if (StringUtils.hasLength(request.getParameter("rdBidderSelect_" + consortiumId))) {
                    selectRequest = Integer.parseInt(request.getParameter("rdBidderSelect_" + consortiumId));
                }
                linkId = (selectRequest == 2) ? lnkRejectConsInvi : lnkAcceptConsInvi;
                if (request.getParameter("txtaRemarks_" + consortiumId) != null) {
                    remarks = request.getParameter("txtaRemarks_" + consortiumId);
                }
                 List<Object[]> lst =null;
                if(selectRequest == 1) // Accept request
                {
                    lst=eventBidSubmissionService.findSecondaryPartner(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString(), tenderId, abcUtility.getSessionClientId(request));
                }
                if (selectRequest == 2 || (lst != null && !lst.isEmpty())) {
                    if(eventBidSubmissionService.acceptRejectSecondaryPartnerRequest(consortiumId, userId, selectRequest, remarks))
                    {
                        /**
                         * ********** Send Mail for invitation *********
                         */
                        Map<String, Object> mailParams = new HashMap<String, Object>();
                        String str = eventBidSubmissionService.getLeadPartenerEmailId(consortiumId);
                        if (str != null) {
                            mailParams.put("to", str);
                            String companyName = "";
                            List<Object[]> lstCompDetail = commonService.getCompanyDetailsByUserId(userId, abcUtility.getSessionClientId(request));
                            if (lstCompDetail != null && !lstCompDetail.isEmpty()) {
                                companyName = lstCompDetail.get(0)[0].toString();
                            }
                            //Added By Lipi - Start
                            //for messageBox
                            MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
                            messageConfigDatabean.setQueueName(queueName);
                            messageConfigDatabean.setTemplateId(Integer.parseInt(accptRejConsortiumTemplateId));
                            messageConfigDatabean.setUserId(userId);
                            messageConfigDatabean.setClientId(abcUtility.getSessionClientId(request));
                            messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
                            messageConfigDatabean.setContextPath(request.getContextPath());
                            messageConfigDatabean.setObjectId(tenderId);
                            mailParams.put("companyname", companyName);
                            mailParams.put("tenderid", tenderId);
                            mailParams.put("invitestatus", (selectRequest == 2) ? "Rejection" : "Acceptance");
                            mailParams.put("action", (selectRequest == 2) ? "declined" : "accepted");
                            mailParams.put("tenderno", tenderCommonService.getTenderField(tenderId, "tenderNo"));
                            mailParams.put("eventType", eventType);
                            mailParams.put("brief", tenderCommonService.getTenderField(tenderId, "tenderBrief"));
                            String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/biddingtenderdashboard/" + tenderId + "/" + TAB_CONSORTIUM);
                        	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                        	mailParams.put("link", herfStr);
                        	messageConfigDatabean.setParamMap(mailParams);
                        	messageQueueService.sendMessage(messageConfigDatabean);
                        	//End
                        }
                        if (selectRequest == 2) {
                            rea.addFlashAttribute("successMsg", "msg_consortium_reject_success");
                            auditTrail=postRejectConRequest;
//                            String isRegistrationCharges=tenderCommonService.getTenderField(tenderId, "isRegistrationCharges").toString();
//                            if(isRegistrationCharges!=null && isRegistrationCharges.equals("1")){
//                            	page="etender/bidder/biddingtenderdashboard/" + tenderId + "/" + TAB_REG_PAYMENT;
//                            }
                            
                        } else {
                            rea.addFlashAttribute("successMsg", "msg_consortium_accept_success");
                        }
                    }
                    else
                    {
                        if (selectRequest == 2) {
                            rea.addFlashAttribute("errorMsg", "msg_consortium_reject_failed");
                        } else {
                            rea.addFlashAttribute("errorMsg", "msg_consortium_accept_failed");
                        }
                    }
                }
                else
                {
                     rea.addFlashAttribute("errorMsg", "msg_consortium_already_accepted");
                }
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
            if (selectRequest == 2) {
                rea.addFlashAttribute("errorMsg", "msg_consortium_reject_failed");
            } else {
                rea.addFlashAttribute("errorMsg", "msg_consortium_accept_failed");
            }
        } finally {
            int pki = abcUtility.getSessionIsPkiEnabled(request);
            int isCertReq = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isCertRequired").toString());
            if (pki == pkiEnable || (pki == pkiEventSpecific && isCertReq == 1)) {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrail, tenderId, consortiumId, remarks, StringUtils.hasLength(request.getParameter("signData_" + consortiumId)) ? request.getParameter("signData_" + consortiumId) : "");
            } else {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId,auditTrail, tenderId, consortiumId, remarks);
            }
        }
        return "redirect:/" + page + encryptDecryptUtils.generateRedirect(page, request);
    }

    /**
     * Method User for process submit consortium partner sub type.
     * @author dipal
     * @param tenderId
     * @param httpSession
     * @param request
     * @param rea
     * @param modelMap
     * @return
     * @throws IOException
     */
    @RequestMapping(value = {"/submitConsortiumPartnerType"}, method = RequestMethod.POST)
    public String submitPartnerTypeConsortium(@RequestParam(HIDDEN_TENDER_ID) int tenderId, HttpSession httpSession, HttpServletRequest request, RedirectAttributes rea, ModelMap modelMap) throws IOException {
        String page = "etender/bidder/biddingtenderdashboard/" + tenderId + "/" + TAB_CONSORTIUM;
        SessionBean sBean = (SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
        int userId = abcUtility.getSessionUserId(request);
        try {
        	 boolean isBidderRegretted = eventBidSubmissionService.isBidderRegretted(userId,tenderId);
             //modelMap.addAttribute("isBidderRegretted", isBidderRegretted);
             if(isBidderRegretted)
		       	{
            	 rea.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_temder_err_regret");
             }else if(eventBidSubmissionService.isSecondarypartnerInvited(userId,tenderId)){
            	 rea.addFlashAttribute("errorMsg", "msg_consoritum_you_alreadyinvited");
             }else if (sBean != null) {	
                int companyId = sBean.getCompanyId();
                //int userId = sBean.getUserId();
                int userDetailId = sBean.getUserDetailId();
                int consortiumType = 0;
                int consortiumSubType = 0;
                modelMap.addAttribute(TENDER_ID, tenderId);
                modelMap.addAttribute(TAB_ID, TAB_CONSORTIUM);
                if (StringUtils.hasLength(request.getParameter("rdConsortiumType"))) {
                    consortiumType = Integer.parseInt(request.getParameter("rdConsortiumType"));
                }
                if (StringUtils.hasLength(request.getParameter("rdConsortiumSubType"))) {
                    consortiumSubType = Integer.parseInt(request.getParameter("rdConsortiumSubType"));
                }
                if (consortiumSubType != 3 || consortiumType == 1)/* individual or not secondary */ {
                    List<Object[]> lst = eventBidSubmissionService.findSecondaryPartner(SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString(), tenderId, abcUtility.getSessionClientId(request));
                    if (lst != null && !lst.isEmpty()) {
                        TblConsortium tblConsortium = new TblConsortium();
                        tblConsortium.setCreatedBy(userDetailId);

                        tblConsortium.setTblTender(new TblTender(tenderId));

                        TblConsortiumDetail tblConsortiumDetail = new TblConsortiumDetail();
                        tblConsortiumDetail.setCreatedBy(userDetailId);
                        tblConsortiumDetail.setCstatus(1);
                        tblConsortiumDetail.setRemarks("");
                        tblConsortiumDetail.setPartnerStake(new BigDecimal(100));
                        if (consortiumType == 1) {
                            tblConsortium.setIsActive(1);
                            tblConsortiumDetail.setPartnerType(1);
                        } else {
                            tblConsortium.setIsActive(0);
                            tblConsortiumDetail.setPartnerType(2);
                        }
                        tblConsortiumDetail.setTblCompany(new TblCompany(companyId));
                        tblConsortiumDetail.setCreatedBy(userDetailId);
                        tblConsortiumDetail.setTblUserDetail(new TblUserDetail(loginService.getBidderUserDetailId(userId)));
                        tblConsortiumDetail.setTblUserLogin(new TblUserLogin(userId));
                        eventBidSubmissionService.addLeadPartner(tblConsortium, tblConsortiumDetail);
                        String isRegistrationCharges=tenderCommonService.getTenderField(tenderId, "isRegistrationCharges").toString();
                        if(isRegistrationCharges!=null && isRegistrationCharges.equals("1")){
                        	page="etender/bidder/biddingtenderdashboard/" + tenderId + "/" + TAB_CONSORTIUM;
                        }
                    } else {
                        rea.addFlashAttribute("errorMsg", "msg_consoritum_process_already_configured");
                    }
                } else {
                    rea.addFlashAttribute("errorMsg", "msg_consoritum_norequest");
                }
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), lnkCreateCons, postConPartnerType, tenderId, 0);
        }
        return "redirect:/" + page + encryptDecryptUtils.generateRedirect(page, request);
    }

    /**
     * Method use for process final consortium approved process.
     * @author dipal
     * @param tenderId
     * @param consortiumId
     * @param httpSession
     * @param request
     * @param modelMap
     * @param rea
     * @return
     * @throws IOException
     */
    @RequestMapping(value = {"/submitFinalConsortium"}, method = RequestMethod.POST)
    public String submitFinalConsortium(@RequestParam(HIDDEN_TENDER_ID) int tenderId, @RequestParam(HIDDEN_CONSORTIUM_ID) int consortiumId, HttpSession httpSession, HttpServletRequest request, ModelMap modelMap, RedirectAttributes rea) throws IOException {
        String page = "etender/bidder/biddingtenderdashboard/" + tenderId + "/" + TAB_CONSORTIUM;
        try {
        	
            if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                modelMap.addAttribute(TENDER_ID, tenderId);
                modelMap.addAttribute(TAB_ID, TAB_CONSORTIUM);
                if(!eventBidSubmissionService.checkAllConsortiumRequestProcessed(consortiumId))
                {
                    rea.addFlashAttribute("errorMsg", "msg_consortium_secondary_req_pending");
                }
                else if (eventBidSubmissionService.finalConsortiumProcess(consortiumId)) {
                    rea.addFlashAttribute("successMsg", "msg_consortium_approved_success");
                } else {
                    rea.addFlashAttribute("errorMsg", "msg_consortium_approved_failed");
                }
            }

        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), lnkFinalizeCons,postFinalConProcess, tenderId, consortiumId);
        }
        return "redirect:/" + page + encryptDecryptUtils.generateRedirect(page, request);
    }

    /**
     * Method use for reset consortium
     * @author dipal
     * @param tenderId
     * @param consortiumId
     * @param httpSession
     * @param request
     * @param modelMap
     * @param rea
     * @return
     * @throws IOException
     */
    @RequestMapping(value = {"/resetConsortium"}, method = RequestMethod.POST)
    public String resetConsortium(@RequestParam(HIDDEN_TENDER_ID) int tenderId, @RequestParam(HIDDEN_CONSORTIUM_ID) int consortiumId, HttpSession httpSession, HttpServletRequest request, ModelMap modelMap, RedirectAttributes rea) throws IOException {
        String page = "etender/bidder/biddingtenderdashboard/" + tenderId + "/" + TAB_CONSORTIUM;
        SessionBean sBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
        String eventType = "";
        int userId = abcUtility.getSessionUserId(request);
        try {
        	 boolean isBidderRegretted = eventBidSubmissionService.isBidderRegretted(userId,tenderId);
             if(isBidderRegretted)
		       	{
            	 rea.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_temder_err_regret_reset");
		       	}
             else if (sBean != null) {
            	eventType = StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
                modelMap.addAttribute(TENDER_ID, tenderId);
                modelMap.addAttribute(TAB_ID, TAB_CONSORTIUM);
                int clientId = abcUtility.getSessionClientId(request);
                if (eventBidSubmissionService.resetConsortium(tenderId, consortiumId, sBean.getIpAddress(), sBean.getUserDetailId(), clientId,msgResetConsortium)) {
                    rea.addFlashAttribute("successMsg", "msg_consortium_reset_success");
                    userId = abcUtility.getSessionUserId(request);
                    /**
                     * ********** Send Mail for invitation *********
                     */
                    Map<String, Object> mailParams = new HashMap<String, Object>();
                    StringBuilder str = eventBidSubmissionService.getSecondayPartenerEmailIds(consortiumId, userId);
                    if (str != null) {
                        mailParams.put("to", str.toString());
                        String companyName = "";
                        List<Object[]> lstCompDetail = commonService.getCompanyDetailsByUserId(userId, clientId);
                        if (lstCompDetail != null && !lstCompDetail.isEmpty()) {
                            companyName = lstCompDetail.get(0)[0].toString();
                        }
                        //Added By Lipi - Start
                        //for messageBox
                        MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
                        messageConfigDatabean.setQueueName(queueName);
                        messageConfigDatabean.setTemplateId(Integer.parseInt(resetConsortiumtemplateId));
                        messageConfigDatabean.setUserId(userId);
                        messageConfigDatabean.setClientId(abcUtility.getSessionClientId(request));
                        messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
                        messageConfigDatabean.setContextPath(request.getContextPath());
                        messageConfigDatabean.setObjectId(tenderId);
                        mailParams.put("companyname", companyName);
                        mailParams.put("tenderid", tenderId);
                        mailParams.put("tenderno", tenderCommonService.getTenderField(tenderId, "tenderNo"));
                        mailParams.put("eventType", eventType);
                        mailParams.put("brief", tenderCommonService.getTenderField(tenderId, "tenderBrief"));
                        messageConfigDatabean.setParamMap(mailParams);
                    	messageQueueService.sendMessage(messageConfigDatabean);
                        //End
                    }
                } else {
                    rea.addFlashAttribute("errorMsg", "msg_consortium_reset_failed");
                }
            }

        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), lnkResetCons, postConReset, tenderId, consortiumId);
        }
        return "redirect:/" + page + encryptDecryptUtils.generateRedirect(page, request);
    }

    /**
     * Use to get all active tender
     *
     * @author nirav.modi
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/tenderlisting/{enc}", method = RequestMethod.GET)
    public String tenderListing(ModelMap modelMap, HttpServletRequest request) {
        String retVal = "etender/common/TenderListing";
        try {
            modelMap.addAttribute("tenderList", tenderFormService.getTenderList());
        } catch (Exception ex) {
            retVal = exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "Bidder has clicked on Tender listing", 0, 0);
        }
        return retVal;
    }

    @RequestMapping(value = "/redirecttodashboard/{tenderId}/{tabId}/{enc}", method = RequestMethod.GET)
    public String redirectToDashboard(@PathVariable(TENDER_ID) int tenderId,@PathVariable("tabId") int tabId,ModelMap modelMap, HttpServletRequest request,HttpSession httpSession,RedirectAttributes redirectAttributes ) {
        String page = "etender/bidder/biddingtenderdashboard/" + tenderId+"/2";
        try {
        	switch (tabId) {
            case TAB_PARTICIPATION_FEES:
            	redirectAttributes.addFlashAttribute("payFor", "participation fees");
            	break;
            case TAB_REG_PAYMENT:
            	redirectAttributes.addFlashAttribute("payFor", "registration charges");
            	break;
            case TAB_DOC_FEES:
            	redirectAttributes.addFlashAttribute("payFor", "document fees");
            	break;
            case TAB_EMD:
            	redirectAttributes.addFlashAttribute("payFor", "EMD amount");
            	break;
        	}
        	 redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_notallow");
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "secondary Bidder has clicked on Doc fees/ EMD tab whithout refresh", 0, 0);
        }
        return "redirect:/" + page + encryptDecryptUtils.generateRedirect(page, request);   
    }

    /**
     * @author VIPULP
     * @param tenderId
     * @param isConsortium
     * @param request
     * @return String
     */
    @RequestMapping(value = "/validatebiddereventdashboard", method = RequestMethod.POST)
    @ResponseBody
    public String validateBidderEventDashboard(@RequestParam(HIDDEN_TENDER_ID) int tenderId, @RequestParam("txtJVRole") int isConsortium, @RequestParam("txtTabId") int tabId, HttpServletRequest request) {
        String response = "sessionexpired";
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                SessionBean sBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
                int companyId = sBean.getCompanyId();
                int userId = sBean.getUserId();
                boolean isTenderBidConfirmation = eventBidSubmissionService.isTenderBidConfirmation(tenderId, companyId);
                String finalSubmissionMsg1 = tenderCommonService.allowFinalSubmission(sBean.getIpAddress(), tenderId, companyId, userId,sBean.getUserDetailId(), FINALSUBMISSION_REQUEST_TYPE_GET);
                TblTender tblTender = tenderCommonService.getTenderById(tenderId);
                if(finalSubmissionMsg1.equalsIgnoreCase("msg_tender_fs_registration_charges_not_paid") || finalSubmissionMsg1.equalsIgnoreCase("msg_tender_fs_registration_charges_paid_but_not_approved")){
                   response = (tabId == 14)?"noerr":finalSubmissionMsg1;
                }else{
                    boolean doValidateIagree = (tabId == 7) ? false : true;

                    if (!doValidateIagree) {
                        Date openingDt = (Date) tenderCommonService.getTenderField(tenderId, "openingDate");
                        Date currentDt = commonService.getServerDateTime();
	                        if (openingDt.after(currentDt)) {
	                            response = "err_openingdt_not_arrived|" + CommonUtility.convertTimezone(openingDt);
	                        } else {
	                            doValidateIagree = true;
	                        }
                    }

                    if (doValidateIagree) {
                        if (isTenderBidConfirmation) {
                            if (isConsortium == 1) {
                                boolean isJVRoleSelected = eventBidSubmissionService.isConsortiumRoleSelected(tenderId, userId);
                                if (isJVRoleSelected) {
                                    if (tabId == 6) {
                                        String finalSubmissionMsg = tenderCommonService.allowFinalSubmission(sBean.getIpAddress(), tenderId, companyId, userId,
                                                sBean.getUserDetailId(), FINALSUBMISSION_REQUEST_TYPE_GET);
                                        if (!finalSubmissionMsg.contains("msg_tender_fs_finalsubmission_done") && !"Success".equals(finalSubmissionMsg.trim())) {
                                            response = finalSubmissionMsg;
                                        } else {
                                            response = "noerr";
                                        }
                                    } else {
                                        response = "noerr";
                                    }
                                } else {
                                	response = (tabId==11)?"noerr":(tabId==14)?"noerr":(tabId == 2)?"noerr":(tabId==18)?"noerr":"err_jvroleselect";//need to change (tabId==18):
                                }
                            } else {
                                if (tabId == 6) {
                                	if(tblTender.getCstatus() != 2){
                                		String finalSubmissionMsg = tenderCommonService.allowFinalSubmission(sBean.getIpAddress(), tenderId, companyId, userId,
                                            sBean.getUserDetailId(), FINALSUBMISSION_REQUEST_TYPE_GET);
	                                    if (!finalSubmissionMsg.contains("msg_tender_fs_finalsubmission_done") && !"Success".equals(finalSubmissionMsg.trim())) {
	                                        response = finalSubmissionMsg;
	                                    } else {
	                                        response = "noerr";
	                                    }
                                	}else{
                                		response = "msg_event_cancel";	
                                	}
                                } else{
                                    response = "noerr";
                                }
                            }
                            if(tabId==4){
                            	boolean iscgClient = CommonUtility.isClientConditionExistInProperty(cgClient,abcUtility.getSessionClientId(request));
                                boolean isBidSavedInDraft = false;
                                if(iscgClient){
                                	isBidSavedInDraft = tenderCommonService.isBidSavedInDraft(tenderId, companyId);
                                	if(isBidSavedInDraft){
                                		response = "msg_bid_submit_before_pay_emd";
                                	}
                                }
                            }
                        } else {
                        	if(tabId == 7){
                        		List<TblShareReport> shareReport = tblShareReportDao.findTblShareReport("tblTender.tenderId",Operation_enum.EQ,tenderId,"isActive",Operation_enum.EQ,1);
                        		response = (!shareReport.isEmpty())?shareReport.get(0).getShareReport() == 4?"noerr":"err_iagree":"err_iagree";
                        	}else{
                            	
                        		response = (tabId == 14)?"noerr":tabId == 3 || tabId == 2 ? "docDownloadErr" :"err_iagree";
                        	}
                        }
                    }
                }
                if(tabId == 16){
                	response = "noerr";
                }
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "Accessed validate bidder event dashboard", tenderId, 0);
        }
        return response;
    }

    /**
     * @author anjali
     * @param tenderId
     * @param reportId
     * @param reportFor
     * @param modelMap
     * @param request
     * @return String
     */
    @RequestMapping(value="/generatedynamicreport/{tenderId}/{reportId}/{reportFor}/{enc}",method= RequestMethod.GET)
    public String generateDynamicReport(@PathVariable("tenderId") int tenderId,@PathVariable("reportId") int reportId,@PathVariable("reportFor") int reportFor,ModelMap modelMap,HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	String page=""; 
    	Boolean showl1report = true; 
    	try {
    		List<Object[]> reportData=tenderOpenService.getShareReports(tenderId);
    		if(abcUtility.getSessionUserTypeId(request) == 2 && (Integer)tenderCommonService.getTenderField(tenderId, "resultSharing") == 2 && (reportData != null && !reportData.isEmpty())){
        		if((Integer)reportData.get(0)[2] == 1){
        			if((Integer)reportData.get(0)[0] == 2 || (Integer)reportData.get(0)[0] == 3){
        				int envelopeId=tenderCommonService.getPriceBidOrTechnoEnvelopeId(tenderId);
        				List<Object[]> bidderDetaillst = tenderOpenService.getParticipatedOrQualifiedBidderDetail(tenderId,abcUtility.getSessionUserId(request),envelopeId);
        				if(bidderDetaillst != null && !bidderDetaillst.isEmpty()){
        					if((Integer)reportData.get(0)[0] == 2 && (bidderDetaillst.get(0)[0] == null || (Byte) bidderDetaillst.get(0)[0] != 1 ))
        						showl1report = false;
        				}else {
        					showl1report = false;
        				}
        			}
        		}else{
        			showl1report = false;	
        		}
        	}
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            Map<String,Object> dynamicReport = dynamicReportService.getDynamicL1H1Report(reportId,tenderId,abcUtility.getSessionUserId(request));
            if(dynamicReport != null && !dynamicReport.isEmpty()) {
                modelMap.addAttribute("reportColumnList", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-3"));
                modelMap.addAttribute("reportColumnHeaderList", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-2"));
                modelMap.addAttribute("reportFormHeader", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-1") );
                modelMap.addAttribute("reportHeader", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-4") );
            }
            if(showl1report) {
            	page = "/etender/common/DynamicL1H1Report";
            }else {
            	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_not_allow_to_access");
				page="redirect:/etender/bidder/biddingtenderdashboard/" + tenderId + "/7" + encryptDecryptUtils.generateRedirect("etender/bidder/biddingtenderdashboard/" + tenderId + "/7", request);;
            }
          } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), dynamicL1H1ReportLinkId, reportFor == 1 ? viewDynamicL1Report : viewDynamicH1Report, tenderId, reportId);
        }
       return page;
    }
    
    
    /**
     * @author nitin.w
     * @param tenderId
     * @param tabId
     * @param modelMap
     * @param request
     * @param httpSession
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/favourite/{tenderId}/{tabId}/{enc}", method = RequestMethod.GET)
    public String favouriteTender(@PathVariable(TENDER_ID) int tenderId, @PathVariable(TAB_ID) int tabId, ModelMap modelMap, HttpServletRequest request,HttpSession httpSession,RedirectAttributes redirectAttributes ) {
    	String retVal ="/etender/bidder/tenderlisting/0";
    	retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    	
    	boolean success = false;
    	int isActive = 0;
    	int userId = abcUtility.getSessionUserId(request);
    	int clientId = abcUtility.getSessionClientId(request);
    	int moduleId = 3;
    	
    	try {
    		int favouriteTenderId = tblFavouriteTenderService.checkFavouriteTender(tenderId, userId, clientId,moduleId);
    		
    		
    		if(favouriteTenderId==0)
    		{
    			success = commonService.addFavouriteTender(tenderId, 2, clientId,userId,moduleId);
    			redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_tender_favourite");
    		}
    		else
    		{
    			//In isActive field 0 and 1 is revserved for the the mobile application 2 and 3 we use for favourite and unfavourite
    			success = tblFavouriteTenderService.updateFavouritetender(favouriteTenderId, 2);
    			redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_tender_favourite");
    		}
			
		} catch (JSONException e) { 
			e.printStackTrace();
		}
    	return retVal;
    }
    
    
    @RequestMapping(value = "/unfavourite/{tenderId}/{tabId}/{enc}", method = RequestMethod.GET)
    public String unfavouriteTender(@PathVariable(TENDER_ID) int tenderId, @PathVariable(TAB_ID) int tabId, ModelMap modelMap, HttpServletRequest request,HttpSession httpSession,RedirectAttributes redirectAttributes ) {
    	String retVal ="/etender/bidder/tenderlisting/0";
    	retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    	int userId = abcUtility.getSessionUserId(request);
		int clientId = abcUtility.getSessionClientId(request);
		int moduleId = 3;
		
		int favouriteTenderId = tblFavouriteTenderService.checkFavouriteTender(tenderId, userId, clientId,moduleId);
		
		tblFavouriteTenderService.updateFavouritetender(favouriteTenderId, 3);
		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_tender_unfavourite");
    	return retVal;
    }
}
