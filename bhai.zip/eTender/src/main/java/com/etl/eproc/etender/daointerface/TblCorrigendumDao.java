/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;

/**
 *
 * @author urja.r
 */

import com.etl.eproc.etender.model.TblCorrigendum;
import java.util.List;

public interface TblCorrigendumDao  {

    public void addTblCorrigendum(TblCorrigendum tblCorrigendum);

    public void deleteTblCorrigendum(TblCorrigendum tblCorrigendum);

    public void updateTblCorrigendum(TblCorrigendum tblCorrigendum);

    public List<TblCorrigendum> getAllTblCorrigendum();

    public List<TblCorrigendum> findTblCorrigendum(Object... values) throws Exception;

    public List<TblCorrigendum> findByCountTblCorrigendum(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblCorrigendumCount();

    public void saveUpdateAllTblCorrigendum(List<TblCorrigendum> tblCorrigendums);

	public void saveOrUpdateTblCorrigendum(TblCorrigendum tblCorrigendum);
}