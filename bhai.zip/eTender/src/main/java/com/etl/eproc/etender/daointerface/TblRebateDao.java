package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblRebate;
import java.util.List;

public interface TblRebateDao  {

    public void addTblRebate(TblRebate tblRebate);

    public void deleteTblRebate(TblRebate tblRebate);

    public void updateTblRebate(TblRebate tblRebate);

    public List<TblRebate> getAllTblRebate();

    public List<TblRebate> findTblRebate(Object... values) throws Exception;

    public List<TblRebate> findByCountTblRebate(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblRebateCount();

    public void saveUpdateAllTblRebate(List<TblRebate> tblRebates);
}