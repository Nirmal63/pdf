/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblCommitteeUserDao;
import com.etl.eproc.etender.model.TblCommitteeUser;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author shreyansh.shah
 */
@Repository @Transactional
public class TblCommitteeUserImpl extends AbcAbstractClass<TblCommitteeUser> implements TblCommitteeUserDao {

   

    @Override
    public void addTblCommitteeUser(TblCommitteeUser tblCommitteeUser){
        super.addEntity(tblCommitteeUser);
    }

    @Override
    public void deleteTblCommitteeUser(TblCommitteeUser tblCommitteeUser) {
        super.deleteEntity(tblCommitteeUser);
    }

    @Override
    public void updateTblCommitteeUser(TblCommitteeUser tblCommitteeUser) {
        super.updateEntity(tblCommitteeUser);
    }

    @Override
    public List<TblCommitteeUser> getAllTblCommitteeUser() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCommitteeUser> findTblCommitteeUser(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCommitteeUserCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCommitteeUser> findByCountTblCommitteeUser(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCommitteeUser(List<TblCommitteeUser> tblCommitteeUsers){
        super.updateAll(tblCommitteeUsers);
    }
}

