package com.etl.eproc.advertise.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.advertise.model.TblAdvertiseDigitalSignHistory;
import com.etl.eproc.advertise.daointerface.TblAdvertiseDigitalSignHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblAdvertiseDigitalSignHistoryImpl extends AbcAbstractClass<TblAdvertiseDigitalSignHistory> implements TblAdvertiseDigitalSignHistoryDao {

    

    @Override
    public void addTblAdvertiseDigitalSignHistory(TblAdvertiseDigitalSignHistory tblAdvertiseDigitalSignHistory){
        super.addEntity(tblAdvertiseDigitalSignHistory);
    }

    @Override
    public void deleteTblAdvertiseDigitalSignHistory(TblAdvertiseDigitalSignHistory tblAdvertiseDigitalSignHistory) {
        super.deleteEntity(tblAdvertiseDigitalSignHistory);
    }

    @Override
    public void updateTblAdvertiseDigitalSignHistory(TblAdvertiseDigitalSignHistory tblAdvertiseDigitalSignHistory) {
        super.updateEntity(tblAdvertiseDigitalSignHistory);
    }

    @Override
    public List<TblAdvertiseDigitalSignHistory> getAllTblAdvertiseDigitalSignHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAdvertiseDigitalSignHistory> findTblAdvertiseDigitalSignHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAdvertiseDigitalSignHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAdvertiseDigitalSignHistory> findByCountTblAdvertiseDigitalSignHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAdvertiseDigitalSignHistory(List<TblAdvertiseDigitalSignHistory> tblAdvertiseDigitalSignHistorys){
        super.updateAll(tblAdvertiseDigitalSignHistorys);
    }
}
