package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblShareReportDetailDao;
import com.etl.eproc.etender.model.TblShareReportDetail;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblShareReportDetailImpl extends AbcAbstractClass<TblShareReportDetail> implements TblShareReportDetailDao {

   

    @Override
    public void addTblShareReportDetail(TblShareReportDetail tblShareReportDetail){
        super.addEntity(tblShareReportDetail);
    }

    @Override
    public void deleteTblShareReportDetail(TblShareReportDetail tblShareReportDetail) {
        super.deleteEntity(tblShareReportDetail);
    }

    @Override
    public void updateTblShareReportDetail(TblShareReportDetail tblShareReportDetail) {
        super.updateEntity(tblShareReportDetail);
    }

    @Override
    public List<TblShareReportDetail> getAllTblShareReportDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblShareReportDetail> findTblShareReportDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblShareReportDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblShareReportDetail> findByCountTblShareReportDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblShareReportDetail(List<TblShareReportDetail> tblShareReportDetails){
        super.updateAll(tblShareReportDetails);
    }
}
