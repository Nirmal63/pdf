package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.etender.model.TblTenderEnvelope;
import java.util.List;

public interface TblTenderEnvelopeDao  {

    public void addTblTenderEnvelope(TblTenderEnvelope tblTenderEnvelope);

    public void deleteTblTenderEnvelope(TblTenderEnvelope tblTenderEnvelope);

    public void updateTblTenderEnvelope(TblTenderEnvelope tblTenderEnvelope);

    public List<TblTenderEnvelope> getAllTblTenderEnvelope();

    public List<TblTenderEnvelope> findTblTenderEnvelope(Object... values) throws Exception;

    public List<TblTenderEnvelope> findByCountTblTenderEnvelope(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblTenderEnvelopeCount();

    public void saveUpdateAllTblTenderEnvelope(List<TblTenderEnvelope> tblTenderEnvelopes);

	public void saveOrUpdateTblTenderEnvelope(TblTenderEnvelope tblTenderEnvelope);
}