/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblDynReportFormula;
import java.util.List;

/**
 *
 * @author shreyansh.shah
 */
public interface TblDynReportFormulaDao  {

    public void addTblDynReportFormula(TblDynReportFormula tblDynReportFormula);

    public void deleteTblDynReportFormula(TblDynReportFormula tblDynReportFormula);

    public void updateTblDynReportFormula(TblDynReportFormula tblDynReportFormula);

    public List<TblDynReportFormula> getAllTblDynReportFormula();

    public List<TblDynReportFormula> findTblDynReportFormula(Object... values) throws Exception;

    public List<TblDynReportFormula> findByCountTblDynReportFormula(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynReportFormulaCount();

    public void saveUpdateAllTblDynReportFormula(List<TblDynReportFormula> tblDynReportFormulas);

	public void saveOrUpdateTblDynReportFormula(TblDynReportFormula tbldynreportformula);
}
