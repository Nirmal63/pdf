package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblItemBidderMapDao;
import com.etl.eproc.etender.model.TblItemBidderMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblItemBidderMapImpl extends AbcAbstractClass<TblItemBidderMap> implements TblItemBidderMapDao {

    
    @Override
    public void addTblItemBidderMap(TblItemBidderMap tblItemBidderMap) {
        super.addEntity(tblItemBidderMap);
    }

    @Override
    public void deleteTblItemBidderMap(TblItemBidderMap tblItemBidderMap) {
        super.deleteEntity(tblItemBidderMap);
    }

    @Override
    public void updateTblItemBidderMap(TblItemBidderMap tblItemBidderMap) {
        super.updateEntity(tblItemBidderMap);
    }

    @Override
    public List<TblItemBidderMap> getAllTblItemBidderMap() {
        return super.getAllEntity();
    }

    @Override
    public List<TblItemBidderMap> findTblItemBidderMap(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblItemBidderMapCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblItemBidderMap> findByCountTblItemBidderMap(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblItemBidderMap(List<TblItemBidderMap> tblItemBidderMaps) {
        super.updateAll(tblItemBidderMaps);
    }
}