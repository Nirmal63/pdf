/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderCellDao;
import com.etl.eproc.etender.model.TblTenderCell;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderCellImpl extends AbcAbstractClass<TblTenderCell> implements TblTenderCellDao {


    @Override
    public void addTblTenderCell(TblTenderCell tblTenderCell) {
        super.addEntity(tblTenderCell);
    }

    @Override
    public void deleteTblTenderCell(TblTenderCell tblTenderCell) {
        super.deleteEntity(tblTenderCell);
    }

    @Override
    public void updateTblTenderCell(TblTenderCell tblTenderCell) {
        super.updateEntity(tblTenderCell);
    }

    @Override
    public List<TblTenderCell> getAllTblTenderCell() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderCell> findTblTenderCell(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderCellCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderCell> findByCountTblTenderCell(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderCell(List<TblTenderCell> tblTenderCells) {
        super.updateAll(tblTenderCells);
    }
}
