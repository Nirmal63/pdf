package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblCPPPXmlEntryDao;
import com.etl.eproc.etender.model.TblCPPPXmlEntry;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblCPPPXmlEntryImpl extends AbcAbstractClass<TblCPPPXmlEntry> implements TblCPPPXmlEntryDao {

   
    @Override
    public void addTblCPPPXmlEntry(TblCPPPXmlEntry tblCPPPXmlEntry){
        super.addEntity(tblCPPPXmlEntry);
    }

    @Override
    public void deleteTblCPPPXmlEntry(TblCPPPXmlEntry tblCPPPXmlEntry) {
        super.deleteEntity(tblCPPPXmlEntry);
    }

    @Override
    public void updateTblCPPPXmlEntry(TblCPPPXmlEntry tblCPPPXmlEntry) {
        super.updateEntity(tblCPPPXmlEntry);
    }

    @Override
    public List<TblCPPPXmlEntry> getAllTblCPPPXmlEntry() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCPPPXmlEntry> findTblCPPPXmlEntry(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCPPPXmlEntryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCPPPXmlEntry> findByCountTblCPPPXmlEntry(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCPPPXmlEntry(List<TblCPPPXmlEntry> tblCPPPXmlEntrys){
        super.updateAll(tblCPPPXmlEntrys);
    }
}
