package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;


/**
*
* @author bhavin.patel
*/
@Component
public class SPDumpEvaluationCommittee extends StoredProcedure {
	@Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptender.P_DumpEvaluationCommittee";

    public SPDumpEvaluationCommittee() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_ClientId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_CreatedBy", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_CommitteeId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
    }

    public ArrayList<LinkedHashMap<String, Object>> executeProcedure(int clientId, int userId, int committeeId, int tenderId) throws Exception {
        Map inParams = new HashMap();
        inParams.put("@V_ClientId", clientId);
        inParams.put("@V_CreatedBy", userId);
        inParams.put("@V_CommitteeId", committeeId);
        inParams.put("@V_TenderId", tenderId);
        this.compile();
        return (ArrayList<LinkedHashMap<String, Object>>) execute(inParams).get("#result-set-1");       
    }
}
