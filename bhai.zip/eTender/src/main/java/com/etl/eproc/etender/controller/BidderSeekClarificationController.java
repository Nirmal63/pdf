/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblAnswer;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblQuestion;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonValidations;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.EventBidSubmissionService;
import com.etl.eproc.etender.services.PrebidService;
import com.etl.eproc.etender.services.SeekClarificationService;
import com.etl.eproc.etender.services.TenderCommonService;

/**
 *
 * @author shreyansh.shah
 */
@Controller
@RequestMapping("/etender")
public class BidderSeekClarificationController {

    @Autowired
    private CommonService commonService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private PrebidService prebidService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private SeekClarificationService seekClarificationService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private CommonValidations commonValidations;
    @Autowired
    private EventBidSubmissionService eventBidSubmissionService;
    
    @Value("#{projectProperties['bidder.docstatus.approve']?:1}")
    private int bidderDocStatusApprove;
    @Value("#{etenderAuditTrailProperties['getResponseQuery']}")
    private String getResponseQuery;
    @Value("#{etenderAuditTrailProperties['getResponseQueryEdit']}")
    private String getResponseQueryEdit;
    @Value("#{etenderAuditTrailProperties['postResponseQuery']}")
    private String postResponseQuery;
    @Value("#{etenderAuditTrailProperties['postResponseQueryEdit']}")
    private String postResponseQueryEdit;
    @Value("#{etenderAuditTrailProperties['postPublishResponse']}")
    private String postPublishResponse;
    @Value("#{etenderAuditTrailProperties['viewBuyerQueriesList']}")
    private String viewBuyerQueriesList;
    @Value("#{etenderAuditTrailProperties['viewDetailQuery']}")
    private String viewDetailQuery;
    @Value("#{tenderlinkProperties['bid_evaluation_post_query']?:349}")
    private int ClarificatePostQueryLinkId;
    @Value("#{tenderlinkProperties['bidder_publish_seek_clarification']?:380}")
    private int publishReplyLinkId;
    
    @Value("#{tenderlinkProperties['bidder_reply']?:350}")
    private int bidderReplyLinkId;
    @Value("#{tenderlinkProperties['bidder_edit_seek_clarification']?:351}")
    private int editReplyLinkId;
    @Value("#{tenderlinkProperties['bidder_view_seek_clarification']?:352}")
    private int viewReplyLinkId;
    @Value("#{tenderlinkProperties['bidder_response']?:368}")
    private int responseLinkId;
    @Value("#{linkProperties['report_clarification_bidder_reportid']?:42}")
    private int clarificationBidderReportid;
    @Value("#{projectProperties['rci_client_ids']}")
    private String rciClientIds;
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    /**
     * 
     * @param tenderId
     * @param questionId
     * @param modelMap
     * @param request
     * @return 
     */
    @RequestMapping(value = "/bidder/responseQueryView/{tenderId}/{envelopeId}/{compId}/{envelopeType}/{sortOrder}/{isEvalDone}/{configType}/{questionId}/{enc}", method = RequestMethod.GET)
    public String responseQueryView(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("compId") int compId,@PathVariable("envelopeType") int envelopeType,@PathVariable("sortOrder") int sortOrder,@PathVariable("isEvalDone") String isEvalDone,@PathVariable("configType") int configType,@PathVariable("questionId") int questionId, ModelMap modelMap, HttpServletRequest request) {
    		int answerId = 0;
            int companyId=0;
            int bidderId=0;
            int userTypeId=2;
            int createdBy=0;
            String retVal="";
            boolean isBidderRemarksCheck=false;
            try {
	            int clientId = abcUtility.getSessionClientId(request);
	            HttpSession session = request.getSession();
	            SessionBean sessionBean=(SessionBean)session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
	            if(sessionBean != null)
	            {
	   	    	 companyId = sessionBean.getCompanyId();
	       	     createdBy = sessionBean.getUserDetailId();
	       	     sessionBean.getUserTypeId();
	       	     bidderId = sessionBean.getUserId(); 
	       	     userTypeId=sessionBean.getUserTypeId();
	       	    } 
	       	     if(userTypeId!=2 && userTypeId==3)
	       	     {
	       	    	retVal = "etender/buyer/viewClarificationQueries/" + tenderId + "/" + envelopeId+"/"+compId+"/"+envelopeType+"/"+sortOrder+"/"+isEvalDone+"/"+configType;
	       	    	retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	                return retVal;
	       	     }
	       	     else
	       	     {
	       	    	isBidderRemarksCheck= eventBidSubmissionService.isBidderPresenceRegistered(tenderId,companyId);
	       	    	if(isBidderRemarksCheck)
	         	     {
	       	    	   int EventId = 0;
	                   int quesId=0;
	                   List<Object[]> queAnsList;
	                   queAnsList = prebidService.getQuestionAnswerByQuestionId(questionId);
	                   if(queAnsList != null && !queAnsList.isEmpty()) {
	                       answerId = queAnsList.get(0)[4]!=null  ? Integer.parseInt(queAnsList.get(0)[4].toString()) : 0;
	                   }
	                   List<Object[]> eventIdlist = commonService.getEventIdFromLinkId(bidderReplyLinkId);
	                   if (eventIdlist != null && !eventIdlist.isEmpty()) {
	                       EventId = Integer.parseInt(eventIdlist.get(0)[1].toString());
	                   }
	                   List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(EventId, clientId);
	                   int allowedSize = 0;
	                   StringBuilder allowedExt = new StringBuilder();
	                   if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
	                       allowedSize = lstDocUploadConf.get(0).getMaxSize();
	                       allowedExt.append(lstDocUploadConf.get(0).getType());
	                       modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
	                       StringBuffer hidDocIds=new StringBuffer();
	                       List<Object[]> uploadedFile=null;
	                    	   uploadedFile = fileUploadService.getBidderDocsWithChildId(answerId, clientId, bidderReplyLinkId, 1, abcUtility.getSessionUserId(request),"0", envelopeId);
	                       for (int j = 0; j < uploadedFile.size(); j++) {
	       					if (j>0)
	       					{
	       						hidDocIds.append(",");
	       					}
	       					hidDocIds.append(uploadedFile.get(j)[0]);
	                       }
	                      modelMap.addAttribute("hidDocIds", hidDocIds);
	                   }
	                   int index = allowedExt.toString().indexOf(",");
	                   allowedExt.insert(index + 1, "*.");
	                   while (index >= 0) {
	                       index = allowedExt.toString().indexOf(",", index + ",".length());
	                       allowedExt.insert(index + 1, "*.");
	                   }
	                   tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
	                   modelMap.addAttribute("allowedExt", allowedExt);
	                   modelMap.addAttribute("allowedSize", allowedSize/1024);
	                   modelMap.addAttribute("cStatusDoc", 5);
	                   modelMap.addAttribute("linkId", bidderReplyLinkId);
	                   modelMap.addAttribute("objectIdNew", answerId);
	                   modelMap.addAttribute("queAnsList", queAnsList);
	                   modelMap.addAttribute("cStatusDocView", bidderDocStatusApprove);
	                   modelMap.addAttribute("objectId", questionId);
	                   modelMap.addAttribute("buyerDocList", fileUploadService.getOfficerDocs(questionId, clientId, ClarificatePostQueryLinkId, 1));
	                   modelMap.addAttribute("isSaveBtnEnable",commonService.isRCIClient(rciClientIds,abcUtility.getSessionClientId(request)));
	                   modelMap.addAttribute("allowFileExist","Y");
	                   retVal= "/etender/bidder/ResponseSeekClarificationQuery"; 
	         	     }
	               else
	               {
	            	   retVal = "etender/bidder/biddingtenderdashboard/" + tenderId + "/7";
	                   retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	               }
	       	     }
       	    	} catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), answerId == 0 ? bidderReplyLinkId : editReplyLinkId, answerId == 0 ? getResponseQuery : getResponseQueryEdit, tenderId, answerId);
        }
        return retVal;
    }
    @RequestMapping(value = "/bidder/responseQueryView/{tenderId}/{envelopeId}/{questionId}/{enc}", method = RequestMethod.GET)
    public String responseQueryView(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId, @PathVariable("questionId") int questionId, ModelMap modelMap, HttpServletRequest request) {
            int answerId = 0;
        try {
            int clientId = abcUtility.getSessionClientId(request);
            int EventId = 0;
            List<Object[]> queAnsList;
            queAnsList = prebidService.getQuestionAnswerByQuestionId(questionId);
            if(queAnsList != null && !queAnsList.isEmpty()) {
                answerId = queAnsList.get(0)[4]!=null  ? Integer.parseInt(queAnsList.get(0)[4].toString()) : 0;
            }
            List<Object[]> eventIdlist = commonService.getEventIdFromLinkId(bidderReplyLinkId);
            if (eventIdlist != null && !eventIdlist.isEmpty()) {
                EventId = Integer.parseInt(eventIdlist.get(0)[1].toString());
            }
            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(EventId, clientId);
            int allowedSize = 0;
            StringBuilder allowedExt = new StringBuilder();
            if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
                allowedSize = lstDocUploadConf.get(0).getMaxSize();
                allowedExt.append(lstDocUploadConf.get(0).getType());
                modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
                StringBuffer hidDocIds=new StringBuffer();
                List<Object[]> uploadedFile=null;
             	   uploadedFile = fileUploadService.getBidderDocsWithChildId(answerId, clientId, bidderReplyLinkId, 1, abcUtility.getSessionUserId(request),"0", envelopeId);
                for (int j = 0; j < uploadedFile.size(); j++) {
					if (j>0)
					{
						hidDocIds.append(",");
					}
					hidDocIds.append(uploadedFile.get(j)[0]);
                }
               modelMap.addAttribute("hidDocIds", hidDocIds);
            }
            int index = allowedExt.toString().indexOf(",");
            allowedExt.insert(index + 1, "*.");
            while (index >= 0) {
                index = allowedExt.toString().indexOf(",", index + ",".length());
                allowedExt.insert(index + 1, "*.");
            }
            tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
            modelMap.addAttribute("allowedExt", allowedExt);
            modelMap.addAttribute("allowedSize", allowedSize/1024);
            modelMap.addAttribute("cStatusDoc", 5);
            modelMap.addAttribute("linkId", bidderReplyLinkId);
            modelMap.addAttribute("objectIdNew", answerId);
            modelMap.addAttribute("queAnsList", queAnsList);
            modelMap.addAttribute("cStatusDocView", bidderDocStatusApprove);
            modelMap.addAttribute("objectId", questionId);
            modelMap.addAttribute("buyerDocList", fileUploadService.getOfficerDocs(questionId, clientId, ClarificatePostQueryLinkId, 1));
            modelMap.addAttribute("isSaveBtnEnable",commonService.isRCIClient(rciClientIds,abcUtility.getSessionClientId(request)));
            modelMap.addAttribute("allowFileExist","Y");
            return "/etender/bidder/ResponseSeekClarificationQuery";
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), answerId == 0 ? bidderReplyLinkId : editReplyLinkId, answerId == 0 ? getResponseQuery : getResponseQueryEdit, tenderId, answerId);
        }
    }

    @RequestMapping(value = "/bidder/responseQueryPost", method = RequestMethod.POST)
    public String responseQueryPost(HttpSession session, HttpServletRequest request, ModelMap modelMap, RedirectAttributes redirectAttributes, @RequestParam("hdQuestion") int questionId,@RequestParam("hdTenderId") int tenderId,@RequestParam("hdEnvelopeId") int envelopeId) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        boolean isSuccess = false;
        int questionStatus = StringUtils.hasLength(request.getParameter("txtQueryStatus")) ? Integer.parseInt(request.getParameter("txtQueryStatus")) : 0;
        String eventType=StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
		String tenderBrief=StringUtils.hasLength(request.getParameter("hdTenderBrief")) ? request.getParameter("hdTenderBrief") : "";
			
        TblAnswer tblAnswer = new TblAnswer();
        SessionBean sessionBean = session != null && session.getAttribute("sessionObject") != null ? (SessionBean) session.getAttribute("sessionObject") : null;
            int answerId = StringUtils.hasLength(request.getParameter("hdAnswerId")) ? Integer.parseInt(request.getParameter("hdAnswerId")) : 0;
            int companyId = sessionBean.getCompanyId();
            String redirectMsg = "msg_clarification_updatereply_sucess";
            int linkId = bidderReplyLinkId;
            String auditMsg = postResponseQuery;
            String errorMsg="redirect_failure_common";
            ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        try {
                String answer = StringUtils.hasLength(request.getParameter("rtfAnswer")) ? request.getParameter("rtfAnswer") : "";
            if (sessionBean.getUserId() != 0 && !answer.equals("")) {
                List<Object[]> configureDateList = seekClarificationService.getConfigureDateData(tenderId, envelopeId, companyId);
                if (configureDateList != null && !configureDateList.isEmpty() && commonValidations.compareWithSysDate(conversionService.convert(configureDateList.get(0)[1], Date.class)) > 0) {
                    errorMsg = "msg_reply_clarification_time_over";
                } else {
                    if (answerId != 0) {
                        tblAnswer.setAnswerId(answerId);
                        tblAnswer.setCreatedOn(commonService.getServerDateTime());
                        linkId = editReplyLinkId;
                        auditMsg = postResponseQueryEdit;
                    }
                    tblAnswer.setTblQuestion(new TblQuestion(questionId));
                    tblAnswer.setAnswerText(answer);
                    tblAnswer.setUserTypeId(sessionBean.getUserTypeId());
                    tblAnswer.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
                    tblAnswer.setTblUserDetail(new TblUserDetail(sessionBean.getUserDetailId()));
                    tblAnswer.setCstatus(questionStatus);
                    
                    isSuccess = prebidService.addTblAnswer(tblAnswer);
                    if (isSuccess) {
                        String txtHidDocIds = StringUtils.hasLength(request.getParameter("txtHidDocIds")) ? request.getParameter("txtHidDocIds") : "";
                        if (txtHidDocIds != null && !"".equalsIgnoreCase(txtHidDocIds)) {
                            fileUploadService.updateBidderDocsObjectId(txtHidDocIds, tblAnswer.getAnswerId());
                        }
                        if (questionStatus == 1) {
                            linkId = publishReplyLinkId;
                            redirectMsg = "msg_clarification_reply_sucess";
                            auditMsg = postPublishResponse;
                            

       					 Map<String, Object> paramMap = new HashMap<String, Object>();
       					 paramMap.put("EventType", eventType);
       					 paramMap.put("tenderId", tenderId);
       					 paramMap.put("EventBrief",tenderBrief);
       					 paramMap.put("Response",answer);
                                         paramMap.put("SubDomain", clientBean.getClientInfo().split(":")[1]);
       				     TblTenderEnvelope tblTenderEnvelope=tenderCommonService.getTenderEnvelopeById(envelopeId);
       				     
       		           String encryptUrlStr =encryptDecryptUtils.encrypt("etender/buyer/viewClarificationQueries/"+tenderId+"/"+envelopeId+"/"+companyId+"/"+tblTenderEnvelope.getTblEnvelope().getEnvId()+"/"+tblTenderEnvelope.getSortOrder()+"/"+tblTenderEnvelope.getIsEvaluated()+"/"+tblTenderEnvelope.getIsOpened());
       					// String encryptUrlStr =encryptDecryptUtils.encrypt("etender/buyer/viewQuestionAnswer/"+tenderId+"/"+questionId);
                    
                            String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                            paramMap.put("link", hrefStr);
                            
                            mailContentUtillity.dynamicMailGeneration("47", String.valueOf(sessionBean.getUserId()), String.valueOf(tenderId), paramMap, String.valueOf(companyId));
                        }
                    }
                }
                StringBuilder redirectUrl = new StringBuilder();
                redirectUrl.append("redirect:/etender/bidder/viewQueries/").append(tenderId).append("/").append(envelopeId).append("/").append(sessionBean.getUserId())
                        .append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
                retVal = redirectUrl.toString();
            }
        } catch (Exception ex) {
            retVal = exceptionHandlerService.writeLog(ex);
        } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditMsg,tenderId , answerId);
        }
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectMsg : errorMsg);
        return retVal;
    }
    
        /**
     * View list of queries and response posted by bidder
     * @Author Shreyansh shah
     * @param tenderId
     * @param userId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/bidder/viewQueries/{tenderId}/{envelopeId}/{userId}/{enc}", method = RequestMethod.GET)
    public String viewQueries(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId, @PathVariable("userId") int userId, HttpServletRequest request, ModelMap modelMap) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            int companyId =  Integer.parseInt(commonService.getCompanyIdByUserId(userId).toString());
            List<Object[]> list = seekClarificationService.getConfigureDateData(tenderId, envelopeId, companyId);
            if(list != null && !list.isEmpty()) {
                modelMap.addAttribute("configureDateList", list.get(0));
            }
            modelMap.addAttribute("reportId", clarificationBidderReportid);
            modelMap.addAttribute("userDetailsId", abcUtility.getSessionUserDetailId(request));
            modelMap.addAttribute("companyId", companyId);
            modelMap.addAttribute("editStatus", "1");
            reportGeneratorService.getReportConfigDetails(clarificationBidderReportid, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), responseLinkId, viewBuyerQueriesList, tenderId, 0);
        }
        return "/etender/common/ViewSeekClarificationQueries";
    }
    
    /**
     * To view query and response in details
     * @Author Shreyansh shah
     * @param questionId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/bidder/viewQuestionAnswer/{tenderId}/{questionId}/{envelopeId}/{enc}", method = RequestMethod.GET)
    public String viewQuestionAnswer(@PathVariable("tenderId") int tenderId,@PathVariable("questionId") int questionId,@PathVariable("envelopeId") int envelopeId, HttpServletRequest request, ModelMap modelMap) {
        try {
            int answerId = 0;
            List<Object[]> questionAnswer = prebidService.getQuestionAnswerByQuestionId(questionId);
            if(questionAnswer != null && !questionAnswer.isEmpty()) {
                modelMap.addAttribute("questionAns", questionAnswer.get(0));
                answerId =  questionAnswer.get(0)[4] != null ? Integer.parseInt(questionAnswer.get(0)[4].toString()) : 0;
            }
            List<Object[]> bidderDocList = null;
            if(answerId != 0) {
                bidderDocList = fileUploadService.getBidderDocsWithChildId(answerId, abcUtility.getSessionClientId(request), bidderReplyLinkId, 1, abcUtility.getSessionUserId(request),"0", envelopeId);
            }
            modelMap.addAttribute("cStatusDoc", 5);
            modelMap.addAttribute("cStatusDocView", bidderDocStatusApprove);
            modelMap.addAttribute("questionLinkId", ClarificatePostQueryLinkId);
            modelMap.addAttribute("answerLinkId", bidderReplyLinkId);
            modelMap.addAttribute("isReadOnly", "Y");
            modelMap.addAttribute("buyerDocList", fileUploadService.getOfficerDocs(questionId, abcUtility.getSessionClientId(request), ClarificatePostQueryLinkId, 1));
            modelMap.addAttribute("bidderDocList", bidderDocList);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewReplyLinkId, viewDetailQuery, tenderId,0);
        }
        return "/etender/common/ViewSeekClarificationQueAns";
    }
}
