/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 * To get bidding form dashboard
 * @author Nirav Modi
 */
@Component
public class SPTenderFormsList extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptender.P_GetTenderFormsList";

    public SPTenderFormsList() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_LinkId", Types.INTEGER));
    }


    /**
     * Use case : Tender Bidding Form dashboard
     * @author nirav.modi
     * @param tenderId
     * @param linkId
     * @return Map{@code<String,Object>}
     * @throws Exception
     */
    public Map<String,Object> executeProcedure(int tenderId,int linkId) throws Exception
    {
        Map<String, Integer> inParams = new HashMap<String, Integer>();
        inParams.put("@V_TenderId",tenderId);
        inParams.put("@V_LinkId",linkId);
        this.compile();
        return execute(inParams);
    }
}
