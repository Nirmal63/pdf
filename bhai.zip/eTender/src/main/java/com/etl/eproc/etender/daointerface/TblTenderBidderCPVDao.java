package com.etl.eproc.etender.daointerface;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderBidderCPV;
import java.util.List;

public interface TblTenderBidderCPVDao  {

    public void addTblTenderBidderCPV(TblTenderBidderCPV tblTenderBidderCPV);

    public void deleteTblTenderBidderCPV(TblTenderBidderCPV tblTenderBidderCPV);

    public void updateTblTenderBidderCPV(TblTenderBidderCPV tblTenderBidderCPV);

    public List<TblTenderBidderCPV> getAllTblTenderBidderCPV();

    public List<TblTenderBidderCPV> findTblTenderBidderCPV(Object... values) throws Exception;

    public List<TblTenderBidderCPV> findByCountTblTenderBidderCPV(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderBidderCPVCount();

    public void saveUpdateAllTblTenderBidderCPV(List<TblTenderBidderCPV> tblTenderBidderCPVs);
}