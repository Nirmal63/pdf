package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 * @author pranav.gandharva
 *
 */
@Component
public class SPProjectReport extends StoredProcedure{

	@Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    
    private static final String SPROC_NAME = "appsap.P_ProjectReport";

	public SPProjectReport() {
		super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@v_tenderid", Types.INTEGER));
        this.declareParameter(new SqlParameter("@v_projectid", Types.VARCHAR));  
        this.declareParameter(new SqlParameter("@v_companyname", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@v_responsibleuser", Types.NVARCHAR)); 
        this.declareParameter(new SqlParameter("@V_ClientId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_PublishDateOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_PublishDateFrom", Types.DATE));
        this.declareParameter(new SqlParameter("@V_PublishDateTo", Types.DATE));
        this.declareParameter(new SqlParameter("@V_RecordsPerPage", Types.INTEGER)); 
        this.declareParameter(new SqlParameter("@V_PageNo", Types.INTEGER)); 
       
	}
	 public Map<String,Object> executeProcedure(int tenderId,String projectId,String comapanyName,String responsibleUser,int clientId,int publishDateOperator,Date publishDateFrom,Date publishDateTo,int recordsPerPage,int pageNo) throws Exception {
	        Map<String, Object> inParams = new HashMap<String, Object>();
	        inParams.put("@v_tenderid", tenderId);
	        inParams.put("@v_projectid", projectId);
	        inParams.put("@v_companyname", comapanyName);
	        inParams.put("@v_responsibleuser", responsibleUser);
	        inParams.put("@V_ClientId", clientId);
	        inParams.put("@V_PublishDateOperator", publishDateOperator);
	        inParams.put("@V_PublishDateFrom", publishDateFrom);
	        inParams.put("@V_PublishDateTo", publishDateTo);
	        inParams.put("@V_RecordsPerPage", recordsPerPage);
	        inParams.put("@V_PageNo", pageNo);
	        	        
	        this.compile();
	        return execute(inParams);
	    }

	
}
