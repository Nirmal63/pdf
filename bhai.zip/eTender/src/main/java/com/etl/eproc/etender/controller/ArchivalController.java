package com.etl.eproc.etender.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.etender.services.ArchivalExceptionHandlerService;
import com.etl.eproc.etender.services.ArchivalReportService;


@Controller
public class ArchivalController {
	
	@Autowired
	private ArchivalReportService archivalReportService;
    @Autowired
    private ArchivalExceptionHandlerService archivalExceptionHandlerService;
    
    @ResponseBody
    @RequestMapping(value = "/etender/archive", method = RequestMethod.POST)
    public String archive(ModelMap modelMap, HttpServletRequest request,HttpSession session,HttpServletResponse response,RedirectAttributes redirectAttributes) {
    	String retVal = "success";
    	int archiveDataId = 0;
    	try {
    		boolean isSuccess = false;
    		int tenderId = StringUtils.hasLength(request.getParameter("tenderId")) ? Integer.parseInt(request.getParameter("tenderId")) : 0;
    		Object[] archiveDetails = archivalReportService.getArchiveDetails(tenderId);
    		if(archiveDetails != null) {
    			archiveDataId = (Integer)archiveDetails[0];
    			int clientId  = Integer.parseInt(archiveDetails[1].toString());
    			int reportArchiveStatus = Integer.parseInt(archiveDetails[2].toString());
    			int generatedReports = Integer.parseInt(archiveDetails[3].toString());
    			int reportFailedAttempts = Integer.parseInt(archiveDetails[4].toString());;
    			int newGeneratedReports = 0;
    			
    			archivalReportService.setSessionBeanAndClientBean(clientId, request);
    			List<Object[]> archiveFormDetailsList = archivalReportService.getArchiveFormDetails(archiveDataId, tenderId);
    			if(reportArchiveStatus == 0) {
    				modelMap.addAttribute("forArchivalProcess", true);
	    			switch (generatedReports) {
						case 0:
							isSuccess = archivalReportService.generateIndividualReport(archiveDataId, tenderId, archiveFormDetailsList, modelMap, request, response, session,redirectAttributes);
							if(isSuccess) { newGeneratedReports = 1; } else { reportFailedAttempts++; break;}
						case 1:
		            		isSuccess = archivalReportService.generateComparativeReport(archiveDataId, tenderId, archiveFormDetailsList, modelMap, request, response, session);
		            		if(isSuccess) { newGeneratedReports = 2; } else { reportFailedAttempts++; break;}
						case 2:
		            		isSuccess = archivalReportService.generateL1Report(archiveDataId, tenderId, modelMap, request, response, session);
		            		if(isSuccess) { newGeneratedReports = 3; } else { reportFailedAttempts++; break;}
						case 3:
		            		isSuccess = archivalReportService.generateAuditTrialReport(archiveDataId, tenderId, modelMap, request, response, session);
		            		if(isSuccess) { newGeneratedReports = 4; reportArchiveStatus = 1;} else { reportFailedAttempts++; break;}
					}
    			}
    			isSuccess = archivalReportService.updateArchiveData(archiveDataId, reportArchiveStatus, newGeneratedReports, reportFailedAttempts);
    		}
		} catch (Exception e) {
			retVal = archivalExceptionHandlerService.writeLog(archiveDataId, 0, 3, e);
		} finally {
			archivalReportService.removeSessionBeanAndClientBean(request);
		}
    	return retVal;
    }
}
