package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderTableDao;
import com.etl.eproc.etender.model.TblTenderTable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderTableImpl extends AbcAbstractClass<TblTenderTable> implements TblTenderTableDao {

   
    @Override
    public void addTblTenderTable(TblTenderTable tblTenderTable){
        super.addEntity(tblTenderTable);
    }

    @Override
    public void deleteTblTenderTable(TblTenderTable tblTenderTable) {
        super.deleteEntity(tblTenderTable);
    }

    @Override
    public void updateTblTenderTable(TblTenderTable tblTenderTable) {
        super.updateEntity(tblTenderTable);
    }

    @Override
    public List<TblTenderTable> getAllTblTenderTable() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderTable> findTblTenderTable(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderTableCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderTable> findByCountTblTenderTable(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderTable(List<TblTenderTable> tblTenderTables){
        super.updateAll(tblTenderTables);
    }
}
