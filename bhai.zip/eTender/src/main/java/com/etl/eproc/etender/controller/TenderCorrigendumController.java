/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.TblEventPaymentDao;
import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblEventPayment;
import com.etl.eproc.common.model.TblEventType;
import com.etl.eproc.common.model.TblPaymentType;
import com.etl.eproc.common.model.TblProcess;
import com.etl.eproc.common.model.TblProcurementNature;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.model.TblWorkflow;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.MessageQueueService;
import com.etl.eproc.common.services.NegotiationService;
import com.etl.eproc.common.services.TpslService;
import com.etl.eproc.common.services.WorkflowService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.daointerface.TblItemBidderMapDao;
import com.etl.eproc.etender.daointerface.TblTenderDao;
import com.etl.eproc.etender.daointerface.TblTenderMapBidderHistoryDao;
import com.etl.eproc.etender.databean.TenderCorrigendumDetailDtBean;
import com.etl.eproc.etender.databean.TenderCorrigendumDocumentDtBean;
import com.etl.eproc.etender.databean.TenderCorrigendumDtBean;
import com.etl.eproc.etender.databean.TenderCurrencyCorrigendumDtBean;
import com.etl.eproc.etender.databean.TenderDateDtBean;
import com.etl.eproc.etender.databean.TenderDtBean;
import com.etl.eproc.etender.databean.TenderEnvelopeCorrigendumDtBean;
import com.etl.eproc.etender.databean.TenderFormCorrigendumDtBean;
import com.etl.eproc.etender.model.TblCorrigendum;
import com.etl.eproc.etender.model.TblCorrigendumDetail;
import com.etl.eproc.etender.model.TblItemBidderMap;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBidderMap;
import com.etl.eproc.etender.model.TblTenderCPV;
import com.etl.eproc.etender.model.TblTenderCurrency;
import com.etl.eproc.etender.model.TblTenderMapBidderHistory;
import com.etl.eproc.etender.model.TblTenderTable;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.CommitteeFormationService;
import com.etl.eproc.etender.services.EventBidderMapService;
import com.etl.eproc.etender.services.EventCreationService;
import com.etl.eproc.etender.services.TenderCPVService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderCorrigendumService;
import com.etl.eproc.etender.services.TenderFormService;

/**
 *
 * @author urja.r
 */
@Controller
@RequestMapping("/etender")
public class TenderCorrigendumController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private CommitteeFormationService committeeFormationService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private TenderCorrigendumService tenderCorrigendumService;
    @Autowired
    private EventCreationService eventCreationService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private ReloadableResourceBundleMessageSource messageSource;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private CommonValidators commonValidators;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private TblTenderDao tblTenderDao;
    @Autowired
    private TblEventPaymentDao tblEventPaymentDao;
    @Autowired
    private MessageQueueService messageQueueService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private NegotiationService negotiationService;
    @Autowired
    private WorkflowService workflowService;
    @Autowired
    private EventBidderMapService eventBidderMapService;
    @Autowired
    private TpslService tpslService;
    @Autowired
	private TenderCPVService tenderCPVService;
    @Autowired
    private TblItemBidderMapDao itemBidderMapDao;
    @Autowired
    private TblTenderMapBidderHistoryDao tblTenderMapBidderHistoryDao;
    private static final String SESSIONOBJECT = "sessionObject";
    @Value("#{etenderAuditTrailProperties['getcreatecorrigendum']}")
    private String getcreatecorrigendum;
    @Value("#{etenderAuditTrailProperties['createcorrigendum']}")
    private String createcorrigendum;
    @Value("#{etenderAuditTrailProperties['viewcorrigendum']}")
    private String viewcorrigendum;
    @Value("#{tenderlinkProperties['tender_corrigendum_processId']}")
    private int corrigendumProcessId;
    @Value("#{tenderlinkProperties['tender_corrigendum_pending']}")
    private int tenderCorrigendumPending;
    @Value("#{projectProperties['tender.eventid']?:63}")
    private int tenderEventId;
    @Value("#{tenderlinkProperties['corrigendum_upload']}")
    private int corrigendumUpload;
    @Value("#{tenderlinkProperties['corrigendum_prepare']}")
    private int corrigendumPrepare;
    @Value("#{tenderlinkProperties['corrigendum_view']}")
    private int corrigendumView;
    @Value("#{tenderlinkProperties['corrigendum_edit_tender_notice']}")
    private int corrigendumEdit;
    @Value("#{tenderlinkProperties['corrigendum_publish']?:181}")
    private int corrigendumPublishLinkId;
    @Value("#{projectProperties['serverside.validation']?:true}")
    private boolean serverSideValidation;
    @Value("#{projectProperties['officer.docstatus.approve']?:1}")
    private int officerDocStatusApprove;
    @Value("#{etenderAuditTrailProperties['getpublishcorrigendum']}")
    private String getPublishcorrigendum;
    @Value("#{etenderAuditTrailProperties['postpublishcorrigendum']}")
    private String postPublishcorrigendum;
    @Value("#{etenderAuditTrailProperties['uploadcorrigendum']}")
    private String uploadcorrigendum;
    @Value("#{etenderAuditTrailProperties['deletecorrigendum']}")
    private String deletecorrigendum;
    @Value("#{etenderAuditTrailProperties['deletepreparecorrigendum']}")
    private String deletepreparecorrigendum;
     @Value("#{etenderProperties['publish_corrigendum_templateId']?:44}")
    private String publishCorrigendumTemplateId;
     @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
    private String queueName;
     @Value("#{projectProperties['idfc_email_cc']}")   
     private String idfcEmailCC;
     @Value("#{projectProperties['idfc_client_id']}")   
     private String idfcClientId;
     @Value("#{clientProperties['bob_client_id']}")
     private String bobClientId;
    
    @Value("#{tenderlinkProperties['tender_create_tender']?:212}")
    private int tendercreationlink;
    @Value("#{tenderlinkProperties['negotiation_negotiation_process_invite_for_negotiation']?:602}")
    private int negotiation_negotiation_process_invite_for_negotiation;
    
    @Value("#{tenderlinkProperties['corrigendum_delete']?:257}")
    private int corrigendumDelete;
    @Value("#{etenderAuditTrailProperties['getEditEventNotice']}")
    private String getEditEventNotice;
    @Value("#{etenderAuditTrailProperties['postEditEventNotice']}")
    private String postEditEventNotice;
    @Value("#{tenderlinkProperties['bid_opening_process_process_in_workflow']?:1181}")
    private int bid_opening_process_process_in_workflow;
    @Value("#{projectProperties['event_mail_bcc']}")
    private String eventMailBCC;
    
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    private  static final String LABELONLINE = "label_online::1";
    private  static final String LABELOFFLINE = "label_offline::2";
    private  static final String LABELBOTH = "label_both::3";
    private  static final String LABELALLOW = "label_allow::1";
    private  static final String LABELDONTALLOW = "label_dontallow::0";
    private static final String LABELEVENTWISE = "label_eventwise::1";
    private static final String LABELITEMWISE = "label_itemwise::2";
    private static final String LABELRANGE = "label_emd_rang::3";
    private static final String LABELNOTREQUIRED = "label_notrequired::0";
    private static final String RESULTSET_1= "#result-set-1";
    private String corrStatus="OTHERS";
    /**
     * @author urja
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/createcorrigendum/{opType}/{tenderId}/{eventTypeId}/{enc}", method = RequestMethod.GET)
    public String createCorrigendum(@PathVariable("opType") String opType, @PathVariable("tenderId") int tenderId, @PathVariable("eventTypeId") int eventTypeId, ModelMap modelMap, HttpServletRequest request) {
        String auditMsg = getcreatecorrigendum;
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("tenderId", tenderId);
            modelMap.addAttribute("eventTypeId", eventTypeId);
            if (opType.equals("update")) {
                List<TblCorrigendum> corrigendumList = tenderCorrigendumService.getPendingCorrigendumByTenderId(tenderId);
                modelMap.addAttribute("corrigendumList", corrigendumList);
                auditMsg = getEditEventNotice;
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumPrepare, auditMsg, tenderId, 0);
        }
        return "/etender/buyer/CreateCorrigendum";
    }

    /**
     * @author urja
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/buyer/corrigendumtext", method = RequestMethod.POST)
    public String addCorrigendumText(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        int userId = abcUtility.getSessionUserId(request);
        int clientId = abcUtility.getSessionClientId(request);
        if (userId != 0) {
        	boolean isPublish = false;
            int tenderId = Integer.valueOf(request.getParameter("hdtenderId"));
            int eventTypeId = Integer.valueOf(request.getParameter("hdeventTypeId"));
            String opType = StringUtils.hasLength(request.getParameter("hdOpType")) ? request.getParameter("hdOpType") : "";
            try {
            	List<Object[]> lst = tenderCommonService.getTenderFields(tenderId, "isOpeningByCommittee,isEvaluationByCommittee,isEvaluationRequired");
            	String msg=CommonKeywords.ERROR_MSG_KEY.toString();
            	if (!lst.isEmpty()) {
            		int isOpeningByCommittee = Integer.parseInt(lst.get(0)[0].toString());
            		int isEvaluationByCommittee = Integer.parseInt(lst.get(0)[1].toString());
            		int isEvaluationRequired = Integer.parseInt(lst.get(0)[2].toString());
            		boolean isNegotiationStated = negotiationService.isNegotiationAllowedAndNegotiationStarted(tenderId,negotiation_negotiation_process_invite_for_negotiation);
            		
            		int openingCommitteeId = tenderCommonService.getOpeningCommittee(tenderId,1);
                	List<TblWorkflow> list = workflowService.getWorkflowData(eventTypeId, openingCommitteeId, bid_opening_process_process_in_workflow, tenderId);
                	boolean isWorkflowForOpeningInProcess = false;
                	 List<TblCorrigendum> corrigendumList = tenderCorrigendumService.getPendingCorrigendumByTenderId(tenderId);
                	if(list.size() > 0 && (list.get(0).getWorkflowActionId() != 4 && list.get(0).getWorkflowActionId() != 5)){
                		isWorkflowForOpeningInProcess = true;
                	}
            		
            		if(isOpeningByCommittee==0 && isEvaluationByCommittee==0){
            			boolean isEvalutaionStart = tenderFormService.checkEntryBidderAppDtls(tenderId);
            			if(isEvaluationRequired==1 && !isEvalutaionStart){
            				isPublish = true;
            				msg = "msg_prepare_corrigendum_evastart";
            			}
            			if(!isPublish && isNegotiationStated){
            				isPublish = true;
            				msg = "msg_prepare_corrigendum_negotiationstart";
            			}
            		}else if(isWorkflowForOpeningInProcess){//Don't allow to process corrigendum when workflow for opening in process
            			isPublish = true;
        				msg = "msg_can_not_create_corrigendum_bid_opening_process";
            		}else{
            			List<Object> isTenderOpenedDtls = tenderFormService.isTenderEnvOpened(tenderId);
            			if(isTenderOpenedDtls!=null && !isTenderOpenedDtls.isEmpty()){
            				int isTenderEnvOpened = Integer.parseInt(isTenderOpenedDtls.get(0).toString());
            				if(isTenderEnvOpened >= 1){
            					isPublish = true;
            					msg = "msg_prepare_corrigendum_envopened";
            				}
            			}
            			boolean consentReceived =  committeeFormationService.getActiveCommiteeConsentReceived(tenderId,1);
            			if(consentReceived){
            				isPublish = true;
        					msg = "msg_prepare_corrigendum_consent_received";
            			}
            			
            			
            		}
            		if(corrigendumList!=null && !corrigendumList.isEmpty() && !opType.equalsIgnoreCase("update")){
            			isPublish = true;
            			msg = "msg_corrigendum_not_published";
               	 	}
            	}
            	if(isPublish){
            		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), msg);
            		retVal = "redirect:/etender/buyer/tenderdashboard/" + tenderId + "/4"
                            + encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/4", request);
            	}else{
            		if (request.getParameter("hdcorrigendumId") != null) {
                        int corrigendumId = Integer.valueOf(request.getParameter("hdcorrigendumId").toString());
                        int workFlowId = commonService.checkEntryTblWorkflow(corrigendumId,tenderId);
                        boolean isServerSideValidate = true;
						 if(workFlowId==3 || workFlowId==5){
							 isServerSideValidate = false;
							 redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_workflow_complete");
							 retVal = "redirect:/etender/buyer/tenderdashboard/" + tenderId + "/4"
			                            + encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/4", request);
						 }
						 if(isServerSideValidate){
							 tenderCorrigendumService.updateCorrigendum(request.getParameter("rtfCorrigendumText"), tenderId, corrigendumId);
						 }
                    } else {
                        TblCorrigendum tblCorrigendum = new TblCorrigendum();
                        TblProcess tblProcess = new TblProcess(corrigendumProcessId);
                        tblCorrigendum.setCorrigendumText(request.getParameter("rtfCorrigendumText"));
                        tblCorrigendum.setObjectId(tenderId);
                        tblCorrigendum.setTblProcess(tblProcess);
                        tblCorrigendum.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                        tblCorrigendum.setCstatus(tenderCorrigendumPending);
                        tblCorrigendum.setRemarks("");
                        tenderCorrigendumService.createCorrigendum(tblCorrigendum);
                    }
            		
            		/** PT #41209 */
            		int isOnlinePayment = clientService.getClientById(clientId).getIsOnlinePayment();
            		if (isOnlinePayment != 0 ){
            			
            		   TblTender tblTender = new TblTender();
                       tblTender = eventCreationService.getTenderMaster(tenderId);
                       List<TblEventPayment> tblEventPaymentType= tblEventPaymentDao.findTblEventPayment("objectId", Operation_enum.EQ, tenderId,"moduleId",Operation_enum.EQ, 3);
                       if(tblEventPaymentType.isEmpty() || tblEventPaymentType == null){
                    	   List<TblEventPayment> tblEventPayments=new ArrayList<TblEventPayment>();
                           if (tblTender.getIsDocfeesApplicable() != 0 && tblTender.getDocFeePaymentMode() !=0 ) {
	                        	List<Object[]> modeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getDocFeePaymentMode(), 1, 3);
	                        	for (Object[] pType : modeOfPayment) {
	                        		TblEventPayment tblEventPayment=new TblEventPayment();
	                        		tblEventPayment.setObjectId(tblTender.getTenderId());
	                        		tblEventPayment.setTblClient(new TblClient(clientId));
	                        		tblEventPayment.setTblPaymentType(new TblPaymentType(Integer.parseInt(pType[0].toString())));
	                        		tblEventPayment.setPaymentFor(1);  // 1 For DocFees
	                        		tblEventPayment.setModuleId(3);
	                        		tblEventPayment.setIsActive(1);
	                        		tblEventPayment.setCreatedBy(userId);
	                        		tblEventPayments.add(tblEventPayment);
	                        	}
	                        }
	                        if (tblTender.getIsSecurityfeesApplicable() != 0 && tblTender.getSecFeePaymentMode() != 0) {
	                        	List<Object[]> modeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getSecFeePaymentMode(), 10, 3);
	                        	for (Object[] pType : modeOfPayment) {
	                        		TblEventPayment tblEventPayment=new TblEventPayment();
	                        		tblEventPayment.setObjectId(tblTender.getTenderId());
	                        		tblEventPayment.setTblClient(new TblClient(clientId));
	                        		tblEventPayment.setTblPaymentType(new TblPaymentType(Integer.parseInt(pType[0].toString())));
	                        		tblEventPayment.setPaymentFor(10);  
	                        		tblEventPayment.setModuleId(3);
	                        		tblEventPayment.setIsActive(1);
	                        		tblEventPayment.setCreatedBy(userId);
	                        		tblEventPayments.add(tblEventPayment);
	                        	}
	                        }
	                        if (tblTender.getIsEMDApplicable() != 0 && tblTender.getEmdPaymentMode() !=0 ) {
	                        	List<Object[]> modeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId,  tblTender.getEmdPaymentMode(), 2, 3);
	                        	for (Object[] pType : modeOfPayment) {
	                        		TblEventPayment tblEventPayment=new TblEventPayment();
	                        		tblEventPayment.setObjectId(tblTender.getTenderId());
	                        		tblEventPayment.setTblClient(new TblClient(clientId));
	                        		tblEventPayment.setTblPaymentType(new TblPaymentType(Integer.parseInt(pType[0].toString())));
	                        		tblEventPayment.setPaymentFor(2); 
	                        		tblEventPayment.setModuleId(3);
	                        		tblEventPayment.setIsActive(1);
	                        		tblEventPayment.setCreatedBy(userId);
	                        		tblEventPayments.add(tblEventPayment);
	                        	}
	                        }
	                        if (tblTender.getIsRegistrationCharges() != 0 && tblTender.getRegistrationChargesMode() != 0) {
	                        	List<Object[]> modeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId,  tblTender.getRegistrationChargesMode(), 8, 3);
	                        	for (Object[] pType : modeOfPayment) {
	                        		TblEventPayment tblEventPayment=new TblEventPayment();
	                        		tblEventPayment.setObjectId(tblTender.getTenderId());
	                        		tblEventPayment.setTblClient(new TblClient(clientId));
	                        		tblEventPayment.setTblPaymentType(new TblPaymentType(Integer.parseInt(pType[0].toString())));
	                        		tblEventPayment.setPaymentFor(8);
	                        		tblEventPayment.setModuleId(3);
	                        		tblEventPayment.setIsActive(1);
	                        		tblEventPayment.setCreatedBy(userId);
	                        		tblEventPayments.add(tblEventPayment);
	                        	}
	                        }
	                    	eventCreationService.addTenderPaymentType(tblEventPayments);
                       }
            		}
            		retVal = "redirect:/etender/buyer/tendercorrigendum/" + tenderId + "/" + eventTypeId + encryptDecryptUtils.generateRedirect("etender/buyer/tendercorrigendum/" + tenderId + "/" + eventTypeId, request);
            	}
                

            } catch (Exception ex) {
                return exceptionHandlerService.writeLog(ex);
            } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumPrepare, createcorrigendum, tenderId, 0);
            }
        }
        return retVal;
    }

    /**
     * @author urja
     * @param tenderDtBean
     * @param tenderId
     * @param eventTypeId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/tendercorrigendum/{tenderId}/{eventTypeId}/{enc}", method = RequestMethod.GET)
    public String addTenedrCorrigendum(@ModelAttribute TenderDtBean tenderDtBean, @PathVariable("tenderId") int tenderId, @PathVariable("eventTypeId") int eventTypeId, ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes ) {
    	String redirect = "";
    	boolean isServerSideValidation = false;
    	try {
            TenderDateDtBean tenderDateDtBean=new TenderDateDtBean();
            
            int isWorkflowRequired = tenderDtBean.getSelIsWorkflowRequired();
            int corrigendumId = tenderCorrigendumService.getPendingCorrigendumId(tenderId);
            if(isWorkflowRequired==1 && corrigendumId==0){
            	isServerSideValidation = true;
            	redirect = "redirect:/etender/buyer/tenderdashboard/" + tenderId + "/4" + encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/4", request);
            	String msg = "msg_workflow_complete";
            	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), msg);
            }
            modelMap.addAttribute("tenderId", tenderId);
            modelMap.addAttribute("corrigendumId", corrigendumId);
            //Nikhil Jani Project Task : 31717 Eventwise Reg Chareges with Tender Mode
            modelMap.addAttribute("isEventWiseRegistrationChargePay", tpslService.getPaymentDetail(8,tenderId,0,1,3,0,"") == null ? false : true);
            List<Object> lstTenderDetail = eventCreationService.getTenderDetail(tenderId);
            int clientId = abcUtility.getSessionClientId(request);
        	modelMap.addAttribute("isOnlinePayment",clientService.getClientById(clientId).getIsOnlinePayment());
        	modelMap.addAttribute("selPaymentMode", clientService.getPaymentMode());
            List<Object[]> listCurrency = commonService.getCurrencyList(clientId);
            List<SelectItem> baseCurrency = abcUtility.convert(listCurrency);
            modelMap.addAttribute("baseCurrency", baseCurrency);
            modelMap.addAttribute("listCurrency", listCurrency);
            modelMap.addAttribute("opType", "edit");                  
            modelMap.addAttribute("lstTenderCurrency", (Map<Integer, BigDecimal>) lstTenderDetail.get(1));
            modelMap.addAttribute("isRestOfEventMoneyRequired",  ((TblTender)lstTenderDetail.get(0)).getIsRestOfEventMoney());
            corrigendumTenderModelMap(tenderDtBean,tenderDateDtBean, modelMap, request, corrigendumId, tenderId, eventTypeId,false);
            modelMap.addAttribute("tenderDateDtBean", tenderDateDtBean);
            if(tenderDtBean.getSelIsEMDApplicable()!=0){
            	modelMap.addAttribute("isEMDPaymentDone", tpslService.getPaymentDetail(2,tenderId,0,1,3,0,"") == null ? false : true);
            	
            }
            if(tenderDtBean.getSelIsDocfeesApplicable()!=0){
            	modelMap.addAttribute("isDocfeesPaymentDone", tpslService.getPaymentDetail(1,tenderId,0,1,3,0,"") == null ? false : true);
            	
            }
            if(tenderDtBean.getSelIsRegistrationCharges()!=0){
            	modelMap.addAttribute("isRegistrationChargesPaymentDone", tpslService.getPaymentDetail(8,tenderId,0,1,3,0,"") == null ? false : true);
            }
          //Bug: 19997 :- set officer name and department name directly for corrigendum.
            List<Object[]> lst =eventCreationService.getTenderSummeryData(tenderId);
            Object[] ob = lst.get(0);
            String userName="";
            if(Integer.parseInt(ob[3].toString())>0) {
            	userName=commonService.getUserDetailById(Integer.parseInt(ob[3].toString())).getUserName();
            }
            modelMap.put("deptName", ob[0]);
            modelMap.put("officerName", Integer.parseInt(ob[3].toString()) == 0 ? ob[1] : userName);
            modelMap.addAttribute("isCPPPRequire", clientService.checkCPPPRequireOrNot(clientId));
            modelMap.addAttribute("isCPPPConfigure",clientService.checkCPPPConfigureOrNot(clientId));
            modelMap.addAttribute("clientId",clientId);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumEdit, getcreatecorrigendum, tenderId, 0);
        }
    	if(isServerSideValidation){
    		return redirect;
    	}else{
    		return "/etender/buyer/TenderCorrigendum";
    	}
        
    }

    private void corrigendumDetails(int tenderId, ModelMap modelMap, HttpServletRequest request,long corrigendumCount) {
    	try {
            List<TenderCorrigendumDtBean> resultList = new ArrayList<TenderCorrigendumDtBean>();
            List<TenderCorrigendumDtBean> detailCurrencyList = new ArrayList<TenderCorrigendumDtBean>();
            List<TblCorrigendum> corrigendumList = tenderCorrigendumService.getAllCorrigendumByTenderId(tenderId);
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            for (int j = 0; j < corrigendumList.size(); j++) {
                List<TenderCorrigendumDetailDtBean> detailList = new ArrayList<TenderCorrigendumDetailDtBean>();
                List<TenderCurrencyCorrigendumDtBean> currencyList = new ArrayList<TenderCurrencyCorrigendumDtBean>();
                List<TenderFormCorrigendumDtBean> formList = new ArrayList<TenderFormCorrigendumDtBean>();
                List<TenderEnvelopeCorrigendumDtBean> envelopeList = new ArrayList<TenderEnvelopeCorrigendumDtBean>();
                List<TenderCorrigendumDocumentDtBean> docList = new ArrayList<TenderCorrigendumDocumentDtBean>();
                TenderCorrigendumDtBean corrigendumDtBean = new TenderCorrigendumDtBean();
                corrigendumDtBean.setId(corrigendumList.get(j).getCorrigendumId());
                corrigendumDtBean.setCstatus(corrigendumList.get(j).getCstatus());
                corrigendumDtBean.setCtext(corrigendumList.get(j).getCorrigendumText());
                //List<TblCorrigendumDetail> corrigendumDetailList = tenderCorrigendumService.getCorrigendumDetailByTenderId(corrigendumList.get(j).getCorrigendumId());
                //Change for Bug: 20577
                List<TblCorrigendumDetail> corrigendumDetailList = tenderCorrigendumService.getCorrigendumDetailWithProcessId(corrigendumList.get(j).getCorrigendumId());
                List<Object[]> tenderDocs=fileUploadService.getOfficerAllNoticeDocsAfterCorrigendum(tenderId, abcUtility.getSessionClientId(request),request,null);
                for (int i = 0; i < corrigendumDetailList.size(); i++) {
                    //if (corrigendumDetailList.get(i).getFieldName().equals("tenderCurrency") || corrigendumDetailList.get(i).getFieldName().equals("baseCurrency")) {
                	if (corrigendumDetailList.get(i).getTblProcess().getProcessId() == 2) {
                        TenderCurrencyCorrigendumDtBean tenderCurrencyDtBean = new TenderCurrencyCorrigendumDtBean();
                        String currencyName = tenderCorrigendumService.getCurrencyNameById(corrigendumDetailList.get(i).getObjectId(), tenderId);
                        if (corrigendumDetailList.get(i).getFieldName().equals("baseCurrency")) {
                            tenderCurrencyDtBean.setCurrencyName(currencyName + (" (Base Currency)"));
                        } else {
                            tenderCurrencyDtBean.setCurrencyName(currencyName);
                        }
                        if (corrigendumDetailList.get(i).getActionType() == 3) {
                            tenderCurrencyDtBean.setAction("Cancel");
                        } else {
                            tenderCurrencyDtBean.setAction("New");
                        }
                        currencyList.add(tenderCurrencyDtBean);
                    } //else if (corrigendumDetailList.get(i).getFieldLabel().equals("tenderForm")) {
                      else if (corrigendumDetailList.get(i).getTblProcess().getProcessId() == 4) {
                        TenderFormCorrigendumDtBean tenderFormCorrigendumDtBean = new TenderFormCorrigendumDtBean();
                        String formName = tenderCorrigendumService.getFormNameById(corrigendumDetailList.get(i).getObjectId());
                        tenderFormCorrigendumDtBean.setFormName(formName);
                        if (corrigendumDetailList.get(i).getActionType() == 3) {
                            tenderFormCorrigendumDtBean.setAction("Cancel");
                        } else {
                            tenderFormCorrigendumDtBean.setAction("New");
                        }
                        formList.add(tenderFormCorrigendumDtBean);
                    } //else if (corrigendumDetailList.get(i).getFieldName().equals("envelopeForm")) {
                      else if (corrigendumDetailList.get(i).getTblProcess().getProcessId() == 3) {
                        TenderEnvelopeCorrigendumDtBean tenderEnvelopCorrigendumDtBean = new TenderEnvelopeCorrigendumDtBean();
                        String envelopeName = tenderCorrigendumService.getEnvelopeNameById(corrigendumDetailList.get(i).getObjectId());
                        tenderEnvelopCorrigendumDtBean.setEnvelopeName(envelopeName);
                        if (corrigendumDetailList.get(i).getActionType() == 3) {
                            tenderEnvelopCorrigendumDtBean.setAction("Cancel");
                        } else {
                            tenderEnvelopCorrigendumDtBean.setAction("New");
                        }
                        envelopeList.add(tenderEnvelopCorrigendumDtBean);
                    } else {
                        TenderCorrigendumDetailDtBean tcddb = new TenderCorrigendumDetailDtBean();
                        tcddb.setCorrigendumId(corrigendumDetailList.get(i).getTblCorrigendum().getCorrigendumId());
                        tcddb.setFieldName(corrigendumDetailList.get(i).getFieldLabel());
                        if (corrigendumDetailList.get(i).getFieldName().equals("procurementNatureId")) {
                            tcddb.setOldValue(commonService.getProcurementNatureName(Integer.valueOf(corrigendumDetailList.get(i).getOldValue())));
                            tcddb.setNewValue(commonService.getProcurementNatureName(Integer.valueOf(corrigendumDetailList.get(i).getNewValue())));
                        }else if (corrigendumDetailList.get(i).getFieldName().equals("productId")) {
                            tcddb.setOldValue(commonService.getCPPProduceName(Integer.valueOf(corrigendumDetailList.get(i).getOldValue())));
                            tcddb.setNewValue(commonService.getCPPProduceName(Integer.valueOf(corrigendumDetailList.get(i).getNewValue())));
                        }else if (corrigendumDetailList.get(i).getFieldName().equals("tenderSector")) {
                            tcddb.setOldValue(commonService.getCPPTenderSector(Integer.valueOf(corrigendumDetailList.get(i).getOldValue())));
                            tcddb.setNewValue(commonService.getCPPTenderSector(Integer.valueOf(corrigendumDetailList.get(i).getNewValue())));
                        }else if (corrigendumDetailList.get(i).getFieldName().equals("formContract")) {
                            tcddb.setOldValue(commonService.getCPPFormContract(Integer.valueOf(corrigendumDetailList.get(i).getOldValue())));
                            tcddb.setNewValue(commonService.getCPPFormContract(Integer.valueOf(corrigendumDetailList.get(i).getNewValue())));
                        }else if(corrigendumDetailList.get(i).getFieldName().equals("tenderBrief")){ // Start Bug #50437 By Jitendra.
                        	tcddb.setOldValue(corrigendumDetailList.get(i).getOldValue()); 
                        	tcddb.setNewValue(corrigendumDetailList.get(i).getNewValue());
                        }else if(corrigendumDetailList.get(i).getFieldName().equals("tenderDetail")){
                        	tcddb.setOldValue(corrigendumDetailList.get(i).getOldValue());
                        	tcddb.setNewValue(corrigendumDetailList.get(i).getNewValue()); 			 // End Bug #50437 By Jitendra.
                        }else {
                            if (corrigendumDetailList.get(i).getOldValue().contains("::")) {
                                tcddb.setOldValue(generateDataForView(corrigendumDetailList.get(i).getOldValue()));
                            } else {
                                if (corrigendumDetailList.get(i).getFieldName().contains("Date") && !corrigendumDetailList.get(i).getOldValue().isEmpty()) {
                                    tcddb.setOldValue(CommonUtility.convertTimezone(corrigendumDetailList.get(i).getOldValue()));
                                } else {
                                    tcddb.setOldValue(corrigendumDetailList.get(i).getOldValue());
                                }
                            }
                            if (corrigendumDetailList.get(i).getNewValue().contains("::")) {
                                tcddb.setNewValue(generateDataForView(corrigendumDetailList.get(i).getNewValue()));
                            } else {
                                if (corrigendumDetailList.get(i).getFieldName().contains("Date") && !corrigendumDetailList.get(i).getNewValue().isEmpty()) {
                                    tcddb.setNewValue(CommonUtility.convertTimezone(corrigendumDetailList.get(i).getNewValue()));
                                } else {
                                    tcddb.setNewValue(corrigendumDetailList.get(i).getNewValue());
                                }
                            }
                        }
                        detailCurrencyList.add(corrigendumDtBean);

                        detailList.add(tcddb);
                    }
                }
                String ajaxUrl = abcUtility.getSessionUserId(request)!=0 ?"ajax/downloadfile/" : "/ajaxcall/downloadfile/";
                List<Object[]> data = fileUploadService.getOfficerDocs(corrigendumList.get(j).getCorrigendumId(), abcUtility.getSessionClientId(request), corrigendumUpload, officerDocStatusApprove);
                TenderCorrigendumDocumentDtBean tenderCorrigendumDocumentDtBean = new TenderCorrigendumDocumentDtBean();
                for (int i = 0; i < data.size(); i++) {
                    tenderCorrigendumDocumentDtBean = new TenderCorrigendumDocumentDtBean();
                    tenderCorrigendumDocumentDtBean.setOfficerDocMappingId(Integer.valueOf(data.get(i)[0].toString()));
                    tenderCorrigendumDocumentDtBean.setDocName(String.valueOf(data.get(i)[1]));
                    tenderCorrigendumDocumentDtBean.setDescription(String.valueOf(data.get(i)[2]));
                    tenderCorrigendumDocumentDtBean.setFileSize(String.valueOf(new BigDecimal(Double.parseDouble(String.valueOf(data.get(i)[3]))/(1024*1024)).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue()));
                    tenderCorrigendumDocumentDtBean.setMappedOn(CommonUtility.convertTimezone(String.valueOf(data.get(i)[4])));
                    tenderCorrigendumDocumentDtBean.setCstatus("Approved");
                    if(abcUtility.getSessionUserId(request)!=0) {
	                    tenderCorrigendumDocumentDtBean.setDownloadUrl(request.getContextPath()+"/"+ ajaxUrl + Integer.valueOf(data.get(i)[0].toString()) + "/" + corrigendumList.get(j).getCorrigendumId()
	                            + encryptDecryptUtils.generateRedirect(ajaxUrl + Integer.valueOf(data.get(i)[0].toString()) + "/" + corrigendumList.get(j).getCorrigendumId(), request));
                    }
                    else {
                    	tenderCorrigendumDocumentDtBean.setDownloadUrl(request.getContextPath() + ajaxUrl + Integer.valueOf(data.get(i)[0].toString()) + "/" + corrigendumList.get(j).getCorrigendumId());
                    }
                    docList.add(tenderCorrigendumDocumentDtBean);
                }
                tenderCorrigendumDocumentDtBean = new TenderCorrigendumDocumentDtBean();
                int cstatus=corrigendumList.get(j).getCstatus();
                for (int i = 0; i < tenderDocs.size(); i++) {
                    Date mappedOn=(Date) tenderDocs.get(i)[4];
                    Date approvedOn=(Date) tenderDocs.get(i)[10];
                    Date cancelledOn=(Date) tenderDocs.get(i)[11];
                    Date createdOn=corrigendumList.get(j).getCreatedOn();
                    Date publishedOn=corrigendumList.get(j).getPublishedOn();
                    tenderCorrigendumDocumentDtBean = new TenderCorrigendumDocumentDtBean();
                    if(mappedOn==null)
                    	tenderCorrigendumDocumentDtBean.setCstatus("");
                    else{
                    	if(cstatus>0){
                    		if(mappedOn.after(createdOn) && publishedOn!=null && publishedOn.after(mappedOn))
                    			tenderCorrigendumDocumentDtBean.setCstatus("Uploaded");
                    		if(approvedOn!=null && approvedOn.after(createdOn) && publishedOn!=null && publishedOn.after(approvedOn))
                    			tenderCorrigendumDocumentDtBean.setCstatus("Approved");
                    		if(cancelledOn!=null && cancelledOn.after(createdOn) && publishedOn!=null && publishedOn.after(createdOn))
                    			tenderCorrigendumDocumentDtBean.setCstatus("Cancelled");
                    	}
                    	if(cstatus==0){
                    		if(mappedOn.after(createdOn))
                    			tenderCorrigendumDocumentDtBean.setCstatus("Uploaded");
                    		if(approvedOn!=null && approvedOn.after(createdOn))
                    			tenderCorrigendumDocumentDtBean.setCstatus("Approved");
                    		if(cancelledOn!=null && cancelledOn.after(createdOn))
                    			tenderCorrigendumDocumentDtBean.setCstatus("Cancelled");
                    	}                    	
                    }
                    if(tenderCorrigendumDocumentDtBean.getCstatus()!=null && tenderCorrigendumDocumentDtBean.getCstatus().length()>0){
                    tenderCorrigendumDocumentDtBean.setOfficerDocMappingId(Integer.valueOf(tenderDocs.get(i)[0].toString()));
                    tenderCorrigendumDocumentDtBean.setDocName(String.valueOf(tenderDocs.get(i)[1]));
                    tenderCorrigendumDocumentDtBean.setDescription(String.valueOf(tenderDocs.get(i)[2]));
                    tenderCorrigendumDocumentDtBean.setFileSize(String.valueOf(new BigDecimal(Double.parseDouble(String.valueOf(tenderDocs.get(i)[3]))/(1024*1024)).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue()));
                    tenderCorrigendumDocumentDtBean.setMappedOn(CommonUtility.convertTimezone(String.valueOf(tenderDocs.get(i)[4])));
                    
                    if(abcUtility.getSessionUserId(request)!=0) {
	                    tenderCorrigendumDocumentDtBean.setDownloadUrl(request.getContextPath()+"/"+ ajaxUrl + Integer.valueOf(tenderDocs.get(i)[0].toString()) + "/" + corrigendumList.get(j).getCorrigendumId()
	                            + encryptDecryptUtils.generateRedirect(ajaxUrl + Integer.valueOf(tenderDocs.get(i)[0].toString()) + "/" + corrigendumList.get(j).getCorrigendumId(), request));
                    }
                    else {
                    	tenderCorrigendumDocumentDtBean.setDownloadUrl(request.getContextPath() + ajaxUrl + Integer.valueOf(tenderDocs.get(i)[0].toString()) + "/" + corrigendumList.get(j).getCorrigendumId());
                    }
                    docList.add(tenderCorrigendumDocumentDtBean);
                    }
                }
                corrigendumDtBean.setDetails(detailList);
                corrigendumDtBean.setCurrencies(currencyList);
                corrigendumDtBean.setForms(formList);
                corrigendumDtBean.setDocuments(docList);
                corrigendumDtBean.setEnvelopes(envelopeList);
                resultList.add(corrigendumDtBean);
            }
            modelMap.addAttribute("resultList", resultList);
            modelMap.addAttribute("detailCurrencyList", detailCurrencyList);
            modelMap.addAttribute("tenderId", tenderId);
            List<TblCorrigendumDetail> corrigendumDetailList = tenderCorrigendumService.getCorrigendumDetailByTenderId(tenderId);
            modelMap.addAttribute("corrigendumList", corrigendumList);
            modelMap.addAttribute("corrigendumDetailList", corrigendumDetailList);
            modelMap.addAttribute("tenderId", tenderId);
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } finally {
        	if(corrigendumCount!=0){
        	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumView, "Corrigendum "+corrigendumCount+" viewed", tenderId,0);
        	}
        	else{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumView, viewcorrigendum, tenderId, 0);
        	}
         }
    }

    /**
     * @author urja
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = {"/buyer/viewcorrigendum/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String viewCorrigendum(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request) {
        corrigendumDetails(tenderId, modelMap, request,0);
        modelMap.addAttribute("userType", abcUtility.getSessionUserTypeId(request));
        modelMap.addAttribute("isWorkFlow", 0);
        return "/etender/buyer/ViewCorrigendum";
    }

    /**
     * @author urja
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = {"/bidder/viewcorrigendum/{tenderId}/{enc}", "/viewcorrigendum/{tenderId}"}, method = RequestMethod.GET)
    public String bidderViewCorrigendum(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request) {
        corrigendumDetails(tenderId, modelMap, request,0);
        modelMap.addAttribute("userType", abcUtility.getSessionUserTypeId(request));
        modelMap.addAttribute("isWorkFlow", 0);
        int ShowAccessDetail=abcUtility.getAccessDetail(request);
		if(ShowAccessDetail==1){
    	int visitorCount=commonService.getVisitorDetail(request);
    	modelMap.addAttribute("visitorCount",visitorCount);
		}
        return "/etender/bidder/ViewCorrigendum";
    }

    /**
     * @author dixit
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = {"/buyer/viewwfcorrigendum/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String ViewWFCorrigendum(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request) {
        corrigendumDetails(tenderId, modelMap, request,0);
        modelMap.addAttribute("isWorkFlow", 1);
        return "/etender/buyer/ViewCorrigendum";
    }
    /**
      * @author anjali
      * Get corrigendum data and show it to bidder in popup
  	  * @param tenderId
  	  * @param corrigendumId
  	  * @param modelMap
  	  * @param request
  	  * @return
  	  * @throws Exception 
  	 */
    @RequestMapping(value = {"/bidder/viewcorrigendumhistory/{tenderId}/{corrigendumId}/{enc}"}, method = RequestMethod.GET)
    public String viewCorrigendumHistory(@PathVariable("tenderId") int tenderId,@PathVariable("corrigendumId") int corrigendumId,ModelMap modelMap, HttpServletRequest request) throws Exception{
    	try{
    	SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
    	int companyId = sessionBean.getCompanyId();
    	int userId = sessionBean.getUserId();
    	tenderCorrigendumService.insertCorrigendumViewHistory(tenderId,corrigendumId,userId,companyId,commonService.getServerDateTime());
    	
    	long corrigendumCount = tenderCorrigendumService.getTotalCorrigendumPublished(tenderId,corrigendumId);
    	corrigendumDetails(tenderId, modelMap, request,corrigendumCount);
    	}
    	 catch (Exception ex) {
             return exceptionHandlerService.writeLog(ex);
         } 
    	
        return "/etender/bidder/ViewCorrigendumHistory";
    }
    /**
     *
     * @param tenderDtBean
     * @param modelMap
     * @param request
     * @param corrigendumId
     * @param tenderId
     * @param eventTypeId
     * @throws Exception
     */
    public void corrigendumTenderModelMap(TenderDtBean tenderDtBean,TenderDateDtBean tenderDateDtBean, ModelMap modelMap, HttpServletRequest request, int corrigendumId, int tenderId, int eventTypeId,boolean hasErrors) throws Exception {
        int clientId = 0;
        TblTender tblTender = null;
        List<Object[]> lstClientConfigFields = null;
        Map<String, Object> configParam = new HashMap<String, Object>();
        Map<String, Object> hideConfigParam = new HashMap<String, Object>();
        Map<String, Object> labelMap = new HashMap<String, Object>();
        Map<String, Object> valueMap = new HashMap<String, Object>();
        List<SelectItem> arrFormType = null;
        List<SelectItem> lst = null;
        List<Object[]> lstFormTypeId = null;
        String data = "";
        List<Object> lstTenderDetail = eventCreationService.getTenderDetailForCorrigendum(tenderId);
        List<TenderCorrigendumDetailDtBean> tenderCorrigendumDetail = tenderCorrigendumService.getCorrigendumDetailForEditByTenderId(corrigendumId);


        clientId = abcUtility.getSessionClientId(request);
        lstClientConfigFields = eventCreationService.getClientConfigurationFields(clientId, eventTypeId);
        if (lstClientConfigFields != null) {
            for (int i = 0; i < lstClientConfigFields.size(); i++) {
                if (Integer.parseInt(lstClientConfigFields.get(i)[0].toString()) == 1) {
                    if (lstClientConfigFields.get(i)[4] != null) {
                        configParam.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[4].toString());
                    } else {
                        configParam.put(lstClientConfigFields.get(i)[3].toString(), data);
                    }
                } else {
                    if (lstClientConfigFields.get(i)[4] != null) {
                        hideConfigParam.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[4].toString());
                    } else {
                        hideConfigParam.put(lstClientConfigFields.get(i)[3].toString(), data);
                    }
                }
                labelMap.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[6].toString());
                if (Integer.parseInt(lstClientConfigFields.get(i)[1].toString()) == 2) {
                    if (lstClientConfigFields.get(i)[7] != null && !"".equals(lstClientConfigFields.get(i)[7].toString())) {
                        valueMap.put(lstClientConfigFields.get(i)[3].toString(), generateList(lstClientConfigFields.get(i)[7].toString()));
                    } else if (lstClientConfigFields.get(i)[5] != null && !"".equalsIgnoreCase(lstClientConfigFields.get(i)[5].toString())) {
                        lst = abcUtility.convert(tenderCorrigendumService.generateListFmQuery(lstClientConfigFields.get(i)[5].toString(), clientId));
                        valueMap.put(lstClientConfigFields.get(i)[3].toString(), lst);
                    }
                } else {
                    valueMap.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[7].toString());
                }
            }
        }
        tblTender = (TblTender) lstTenderDetail.get(0);
        modelMap.addAttribute("opType", "corrigendum");
        modelMap.addAttribute("configParam", configParam);
        modelMap.addAttribute("labelMap", labelMap);
        modelMap.addAttribute("valueMap", valueMap);
        modelMap.addAttribute("eventTypeId", eventTypeId);
        modelMap.addAttribute("corrigendumId", corrigendumId);
        List<Object[]> listCurrency = commonService.getCurrencyList(clientId);
        List<SelectItem> baseCurrency = abcUtility.convert(listCurrency);
        modelMap.addAttribute("baseCurrency", baseCurrency);
        modelMap.addAttribute("listCurrency", listCurrency);
        
        /*** This list return all currency is active 0 or 1**/
        modelMap.addAttribute("lstTenderCorrigendumCurrency", (List<TblTenderCurrency>)lstTenderDetail.get(3));

        modelMap.addAttribute("tenderId", tenderId);
        modelMap.addAttribute("hideConfigParam", hideConfigParam);
        Map<Integer, BigDecimal> currencyMap = (Map<Integer, BigDecimal>) lstTenderDetail.get(1);
        StringBuilder sb = new StringBuilder();

        for (java.util.Map.Entry entry : currencyMap.entrySet()) { 
            if (sb.toString().length() > 0) {
                sb.append(",");
            }
            sb.append(entry.getKey());
        }
        modelMap.put("oldCurrency", sb.toString());

        modelMap.addAttribute("lstTenderCurrency", currencyMap);
    
        if (tblTender != null) {
        	tenderDtBean.setSeldisplayOfficerName(tblTender.getDisplayOfficerName());
            tenderDtBean.setTxtTenderNo(tblTender.getTenderNo());
            tenderDtBean.setTxtParentDepartment(tblTender.getTblDepartment().getDeptId());
            tenderDtBean.setSelDeptOfficial(tblTender.getOfficerId());
            tenderDtBean.setTxtaTenderBrief(tblTender.getTenderBrief());
            tenderDtBean.setRtfTenderDetail(tblTender.getTenderDetail());
            tenderDtBean.setTxtaKeyword(tblTender.getKeywordText());
            tenderDtBean.setSelEnvelopeType(tblTender.getEnvelopeType());
            lstFormTypeId = tenderCorrigendumService.getCorrigendumFormType(tenderId);
            /* start changes Bug Id#31474*/
            if(lstFormTypeId!=null && !lstFormTypeId.isEmpty()){
            	if(lstFormTypeId.size()==1 && Integer.parseInt(lstFormTypeId.get(0)[0].toString())==4){
            		modelMap.put("isReqSecPartnerForm",true);
            	}else{
            		modelMap.put("isReqSecPartnerForm",false);
            	}
            }
            /* end changes Bug Id#31474*/
            arrFormType = abcUtility.convert(lstFormTypeId);
            tenderDtBean.setIsPastEvent(tblTender.getIsPastEvent());
             tenderDateDtBean.setSelDownloadDocument(tblTender.getDownloadDocument());
             tenderDtBean.setSelBiddingType(tblTender.getBiddingType());
            if(!hasErrors){
                tenderDtBean.setTxtValidityPeriod(Integer.toString(tblTender.getValidityPeriod()));
                tenderDtBean.setSelProcurementNatureId(tblTender.getTblProcurementNature().getProcurementNatureId());
                if(tblTender.getTblProcurementNature().getProcurementNatureId()==5){
                    tenderDtBean.setTxtOtherProcNature(tblTender.getOtherProcurementNature());
                }
                else{
                    tenderDtBean.setTxtOtherProcNature("");
                }
                tenderDtBean.setSelDownloadDocument(tblTender.getDownloadDocument());
                tenderDtBean.setTxtTenderValue(tblTender.getTenderValue().toString());
                tenderDtBean.setSelIsSplitPOAllowed(tblTender.getIsSplitPOAllowed());
                tenderDtBean.setSelIsItemwiseWinner(tblTender.getIsItemwiseWinner());
                tenderDtBean.setSelSubmissionMode(tblTender.getSubmissionMode());
                tenderDtBean.setSelTenderMode(tblTender.getTenderMode());
             

                if (eventCreationService.getTenderBaseCurrency(tenderId) != null) {
                    tenderDtBean.setSelCurrencyId(Integer.parseInt(eventCreationService.getTenderBaseCurrency(tenderId)));
                } else {
                    tenderDtBean.setSelCurrencyId(0);
                }
                tenderDtBean.setSelIsConsortiumAllowed(tblTender.getIsConsortiumAllowed());
                tenderDtBean.setSelIsBidWithdrawal(tblTender.getIsBidWithdrawal());
                tenderDtBean.setSelBiddingVariant(tblTender.getBiddingVariant());
                tenderDtBean.setSelIsPreBidMeeting(tblTender.getIsPreBidMeeting());
                tenderDtBean.setSelPreBidMode(tblTender.getPreBidMode());
                tenderDtBean.setTxtaPreBidAddress(tblTender.getPreBidAddress());
                tenderDtBean.setTxtaDocumentSubmission(tblTender.getDocumentSubmission());
                tenderDtBean.setSelIsWorkflowRequired(tblTender.getIsWorkflowRequired());
                tenderDtBean.setSelWorkflowType(tblTender.getWorkflowTypeId());
                tenderDtBean.setSelIsQuestionAnswer(tblTender.getIsQuestionAnswer());
               
            }
            if (tblTender.getDocumentStartDate() != null) {
                if(!hasErrors){
                     tenderDtBean.setTxtDocumentStartDate(tblTender.getDocumentStartDate().toString());
                }
                tenderDateDtBean.setTxtDocumentStartDate(tblTender.getDocumentStartDate().toString());
            }
            if (tblTender.getDocumentEndDate() != null) {
                if(!hasErrors){
                    tenderDtBean.setTxtDocumentEndDate(tblTender.getDocumentEndDate().toString());
                }
                tenderDateDtBean.setTxtDocumentEndDate(tblTender.getDocumentEndDate().toString());
            }
            if (tblTender.getSubmissionStartDate() != null) {
                if(!hasErrors){
                    tenderDtBean.setTxtSubmissionStartDate(tblTender.getSubmissionStartDate().toString());
                }
                tenderDateDtBean.setTxtSubmissionStartDate(tblTender.getSubmissionStartDate().toString());
            }
            if (tblTender.getSubmissionEndDate() != null) {
                if(!hasErrors){
                    tenderDtBean.setTxtSubmissionEndDate(tblTender.getSubmissionEndDate().toString());
                }
                tenderDateDtBean.setTxtSubmissionEndDate(tblTender.getSubmissionEndDate().toString());
            }
            if (tblTender.getPreBidStartDate() != null) {
                if(!hasErrors){
                    tenderDtBean.setTxtPreBidStartDate(tblTender.getPreBidStartDate().toString());
                }
                tenderDateDtBean.setTxtPreBidStartDate(tblTender.getPreBidStartDate().toString());
            }
            if (tblTender.getOpeningDate() != null) {
                if(!hasErrors){
                    tenderDtBean.setTxtBidOpenDate(tblTender.getOpeningDate().toString());
                }
                tenderDateDtBean.setTxtBidOpenDate(tblTender.getOpeningDate().toString());
            }
            if (tblTender.getQuestionAnswerStartDate() != null) {
                if(!hasErrors){
                    tenderDtBean.setTxtQuestionAnswerStartDate(tblTender.getQuestionAnswerStartDate().toString());
                }
                tenderDateDtBean.setTxtQuestionAnswerStartDate(tblTender.getQuestionAnswerStartDate().toString());
            }
            if (tblTender.getQuestionAnswerEndDate() != null) {
                if(!hasErrors){ 
                    tenderDtBean.setTxtQuestionAnswerEndDate(tblTender.getQuestionAnswerEndDate().toString());
                }
                tenderDateDtBean.setTxtQuestionAnswerEndDate(tblTender.getQuestionAnswerEndDate().toString());
            }
            if (tblTender.getPreBidEndDate() != null) {
                if(!hasErrors){ 
                    tenderDtBean.setTxtPreBidEndDate(tblTender.getPreBidEndDate().toString());
                }
                   tenderDateDtBean.setTxtPreBidEndDate(tblTender.getPreBidEndDate().toString());
            }
            if (tblTender.getEmdSubmissionEndDate() != null) {
                if(!hasErrors){ 
                    tenderDtBean.setTxtEmdSubmissionEndDate(tblTender.getEmdSubmissionEndDate().toString());
                }
                   tenderDateDtBean.setTxtEmdSubmissionEndDate(tblTender.getEmdSubmissionEndDate().toString());
            }
            //CPPP changes
            tenderDtBean.setTxtaPrequalification(tblTender.getPrequalification());
            tenderDtBean.setSelProduct(tblTender.getProductId());
            tenderDtBean.setSelFormContract(tblTender.getFormContract());
            tenderDtBean.setSelTenderSector(tblTender.getTenderSector());
            
            if(!hasErrors){
            	tenderDtBean.setSelIsRegistrationCharges(tblTender.getIsRegistrationCharges());
                tenderDtBean.setSelRegistrationChargesMode(tblTender.getRegistrationChargesMode());
                if(StringUtils.hasLength(tblTender.getRegistrationCharges())){
                	 BigDecimal txtRegAmt = new BigDecimal(tblTender.getRegistrationCharges());
                	tenderDtBean.setTxtRegistrationCharges((txtRegAmt.setScale(2,BigDecimal.ROUND_UP)).toString());
                }
                tenderDtBean.setSelIsDocfeesApplicable(tblTender.getIsDocfeesApplicable());
                tenderDtBean.setSelDocFeePaymentMode(tblTender.getDocFeePaymentMode());
                if (StringUtils.hasLength(tblTender.getDocumentFee())) {
                    BigDecimal txtDocumentFees = new BigDecimal(tblTender.getDocumentFee());
                    tenderDtBean.setTxtDocumentFee((txtDocumentFees.setScale(2, BigDecimal.ROUND_UP)).toString());
                }

                tenderDtBean.setTxtaDocFeePaymentAddress(tblTender.getDocFeePaymentAddress());
                tenderDtBean.setSelIsSecurityfeesApplicable(tblTender.getIsSecurityfeesApplicable());
                tenderDtBean.setSelSecFeePaymentMode(tblTender.getSecFeePaymentMode());
                if (StringUtils.hasLength(tblTender.getSecurityFee())) {
                    BigDecimal txtSecurityFees = new BigDecimal(tblTender.getSecurityFee());
                    tenderDtBean.setTxtSecurityFee((txtSecurityFees.setScale(2, BigDecimal.ROUND_UP)).toString());
                }
                tenderDtBean.setTxtaSecFeePaymentAddress(tblTender.getSecFeePaymentAddress());
                tenderDtBean.setSelEmdPaymentMode(tblTender.getEmdPaymentMode());
                if (StringUtils.hasLength(tblTender.getEmdAmount())) {
                    BigDecimal txtEmdAmt = new BigDecimal(tblTender.getEmdAmount());
                    tenderDtBean.setTxtEmdAmount((txtEmdAmt.setScale(2, BigDecimal.ROUND_UP)).toString());
                }
                if (StringUtils.hasLength(tblTender.getMinEmdAmt())) {
                    BigDecimal txtMinEmdAmt = new BigDecimal(tblTender.getMinEmdAmt());
                    tenderDtBean.setTxtMinEmdAmt((txtMinEmdAmt.setScale(2, BigDecimal.ROUND_UP)).toString());
                }
                if (StringUtils.hasLength(tblTender.getMaxEmdAmt())) {
                    BigDecimal txtMaxEmdAmt = new BigDecimal(tblTender.getMaxEmdAmt());
                    tenderDtBean.setTxtMaxEmdAmt((txtMaxEmdAmt.setScale(2, BigDecimal.ROUND_UP)).toString());
                }
                tenderDtBean.setTxtaEmdPaymentAddress(tblTender.getEmdPaymentAddress());
                tenderDtBean.setTxtProjectDuration(tblTender.getProjectDuration());
                tenderDtBean.setSelIsEMDApplicable(tblTender.getIsEMDApplicable());
                tenderDtBean.setSelDecimalValueUpto(tblTender.getDecimalValueUpto());
                tenderDtBean.setSelEventType(tblTender.getTblEventType().getEventTypeId());
                
            }
            
            if (clientService.getClientById(clientId).getIsOnlinePayment() != 0 ){
            	
            	int moduleId = 3;
            	List<Object[]> clientPayType =  clientService.getClientEventPaymentType(clientId, 0, 0, 0 ,moduleId);
                modelMap.addAttribute("clientPayType",clientPayType);
            	
                List<Object[]> docModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getDocFeePaymentMode(), 1, moduleId);
                List<SelectItem> selDocModeOfPayment = abcUtility.convertSelected(docModeOfPayment);
                modelMap.addAttribute("selDocModeOfPayment", selDocModeOfPayment);
                
                /*Enable Change in Corrigendum */
                List<Object[]>  modeOfDocPaymentType = tenderCorrigendumService.getPaymentTypeForEvent(tenderId, 1, 1, 3);
                modelMap.addAttribute("selmodeofdocpayment", modeOfDocPaymentType);
                    
        		List<Object[]> secModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getSecFeePaymentMode(), 10, moduleId);
                List<SelectItem> selSecModeOfPayment = abcUtility.convertSelected(secModeOfPayment);
                modelMap.addAttribute("selSecModeOfPayment", selSecModeOfPayment);
            
        		List<Object[]> emdModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getEmdPaymentMode(), 2, moduleId);
                List<SelectItem> selEmdModeOfPayment = abcUtility.convertSelected(emdModeOfPayment);
                modelMap.addAttribute("selEmdModeOfPayment", selEmdModeOfPayment);
                
                /*Enable Change in Corrigendum */
                List<Object[]>  modeOfEmdPaymentType = tenderCorrigendumService.getPaymentTypeForEvent(tenderId, 1, 2, 3);
                modelMap.addAttribute("selmodeofEmdpayment", modeOfEmdPaymentType);
            
        		List<Object[]> regModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getRegistrationChargesMode(), 8, moduleId);
                List<SelectItem> selRegModeOfPayment = abcUtility.convertSelected(regModeOfPayment);
                modelMap.addAttribute("selRegModeOfPayment", selRegModeOfPayment);
                
                /*Enable Change in Corrigendum */
                List<Object[]>  modeOfRegPaymentType = tenderCorrigendumService.getPaymentTypeForEvent(tenderId, 1, 8, 3);
                modelMap.addAttribute("selmodeofregpayment", modeOfRegPaymentType);
                
                /*Enable Change in Corrigendum SECURITY */
                List<Object[]>  modeOfSecPaymentType = tenderCorrigendumService.getPaymentTypeForEvent(tenderId, 1, 10, 3);
                modelMap.addAttribute("selmodeofsecpayment", modeOfSecPaymentType);
                
            
            }
        }
        
       
        if (tenderCorrigendumDetail != null) {
            Map<Integer, BigDecimal> tenderCurr = new LinkedHashMap<Integer, BigDecimal>();
            StringBuffer currList = new StringBuffer();
            for (int j = 0; j < tenderCorrigendumDetail.size(); j++) {

                if (tenderCorrigendumDetail.get(j).getFieldName().equals("validityPeriod")) {
                    tenderDtBean.setTxtValidityPeriod(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("procurementNatureId")) {
                    tenderDtBean.setSelProcurementNatureId(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("downloadDocument")) {
                    tenderDtBean.setSelDownloadDocument(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("tenderValue")) {
                    tenderDtBean.setTxtTenderValue(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isSplitPOAllowed")) {
                    tenderDtBean.setSelIsSplitPOAllowed(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isItemwiseWinner")) {
                    tenderDtBean.setSelIsItemwiseWinner(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("tenderMode")) {
                    tenderDtBean.setSelTenderMode(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                //Need to check
                if (eventCreationService.getTenderBaseCurrency(tenderId) != null) {
                    if (tenderCorrigendumDetail.get(j).getFieldName().equals("baseCurrency")) {
                        tenderDtBean.setSelCurrencyId(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                    }
                }

                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isConsortiumAllowed")) {
                    tenderDtBean.setSelIsConsortiumAllowed(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isBidWithdrawal")) {
                    tenderDtBean.setSelIsBidWithdrawal(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("biddingVariant")) {
                    tenderDtBean.setSelBiddingVariant(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isPreBidMeeting")) {
                    tenderDtBean.setSelIsPreBidMeeting(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("preBidMode")) {
                    tenderDtBean.setSelPreBidMode(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("preBidAddress")) {
                    tenderDtBean.setTxtaPreBidAddress(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("documentSubmission")) {
                    tenderDtBean.setTxtaDocumentSubmission(tblTender.getDocumentSubmission());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isWorkflowRequired")) {
                    tenderDtBean.setSelIsWorkflowRequired(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("workflowTypeId")) {
                    tenderDtBean.setSelWorkflowType(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isQuestionAnswer")) {
                    tenderDtBean.setSelIsQuestionAnswer(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("documentStartDate")) {
                    tenderDtBean.setTxtDocumentStartDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("documentEndDate")) {
                    tenderDtBean.setTxtDocumentEndDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("submissionStartDate")) {
                    tenderDtBean.setTxtSubmissionStartDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("submissionEndDate")) {
                    tenderDtBean.setTxtSubmissionEndDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("emdSubmissionEndDate")) {
                    tenderDtBean.setTxtEmdSubmissionEndDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("preBidStartDate")) {
                    tenderDtBean.setTxtPreBidStartDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("preBidEndDate")) {
                    tenderDtBean.setTxtBidOpenDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("questionAnswerStartDate")) {
                    tenderDtBean.setTxtQuestionAnswerStartDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("questionAnswerEndDate")) {
                    tenderDtBean.setTxtQuestionAnswerEndDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isDocfeesApplicable")) {
                    tenderDtBean.setSelIsDocfeesApplicable(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("docFeePaymentMode")) {
                    tenderDtBean.setSelDocFeePaymentMode(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("openingDate")) {
                    tenderDtBean.setTxtBidOpenDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("documentFee")) {
                    if (StringUtils.hasLength(tenderCorrigendumDetail.get(j).getNewValue())) {
                        BigDecimal txtDocumentFees = new BigDecimal(tenderCorrigendumDetail.get(j).getNewValue());
                        tenderDtBean.setTxtDocumentFee((txtDocumentFees.setScale(2, 2)).toString());
                    }
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("docFeePaymentAddress")) {
                    tenderDtBean.setTxtaDocFeePaymentAddress(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isSecurityfeesApplicable")) {
                    tenderDtBean.setSelIsSecurityfeesApplicable(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("secFeePaymentMode")) {
                    tenderDtBean.setSelSecFeePaymentMode(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("securityFee") && StringUtils.hasLength(tenderCorrigendumDetail.get(j).getNewValue())) {                   
                        BigDecimal txtSecurityFees = new BigDecimal(tenderCorrigendumDetail.get(j).getNewValue());
                        tenderDtBean.setTxtSecurityFee((txtSecurityFees.setScale(2, 2)).toString());
                    
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("secFeePaymentAddress")) {
                    tenderDtBean.setTxtaSecFeePaymentAddress(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("emdPaymentMode")) {
                    tenderDtBean.setSelEmdPaymentMode(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("emdAmount")) {
                    if (StringUtils.hasLength(tenderCorrigendumDetail.get(j).getNewValue())) {
                        BigDecimal txtEmdAmt = new BigDecimal(tenderCorrigendumDetail.get(j).getNewValue());
                        tenderDtBean.setTxtEmdAmount((txtEmdAmt.setScale(2, 2)).toString());
                    }
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("minEmdAmt")) {
                    if (StringUtils.hasLength(tenderCorrigendumDetail.get(j).getNewValue())) {
                        BigDecimal txtMinEmdAmt = new BigDecimal(tenderCorrigendumDetail.get(j).getNewValue());
                        tenderDtBean.setTxtMinEmdAmt((txtMinEmdAmt.setScale(2, 2)).toString());
                    }
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("maxEmdAmt")) {
                    if (StringUtils.hasLength(tenderCorrigendumDetail.get(j).getNewValue())) {
                        BigDecimal txtMaxEmdAmt = new BigDecimal(tenderCorrigendumDetail.get(j).getNewValue());
                        tenderDtBean.setTxtMaxEmdAmt((txtMaxEmdAmt.setScale(2, 2)).toString());
                    }
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("emdPaymentAddress")) {
                    tenderDtBean.setTxtaEmdPaymentAddress(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("projectDuration")) {
                    tenderDtBean.setTxtProjectDuration(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isEMDApplicable")) {
                    tenderDtBean.setSelIsEMDApplicable(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("isRegistrationCharges")) {
                    tenderDtBean.setSelIsRegistrationCharges(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("registrationChargesMode")) {
                    tenderDtBean.setSelRegistrationChargesMode(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("registrationCharges")) {
                    if (StringUtils.hasLength(tenderCorrigendumDetail.get(j).getNewValue())) {
                        BigDecimal txtRegAmt = new BigDecimal(tenderCorrigendumDetail.get(j).getNewValue());
                        tenderDtBean.setTxtRegistrationCharges((txtRegAmt.setScale(2, 2)).toString());
                    }
                }                
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("decimalValueUpto")) {
                    tenderDtBean.setSelDecimalValueUpto(Integer.valueOf(tenderCorrigendumDetail.get(j).getNewValue()));
                }

                if (tenderCorrigendumDetail.get(j).getFieldName().equals("preBidEndDate")) {
                    tenderDtBean.setTxtPreBidEndDate(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getFieldName().equals("keywordText")) {
                    tenderDtBean.setTxtaKeyword(tenderCorrigendumDetail.get(j).getNewValue());
                }
                if (tenderCorrigendumDetail.get(j).getProcessId()==2 || tenderCorrigendumDetail.get(j).getFieldName().equals("baseCurrency")) {

                    //currList.append(tenderCorrigendumDetail.get(j).getNewValue());
                    currList.append(tenderCorrigendumDetail.get(j).getObjectId());
                    currList.append(",");
                    tenderCurr.put(Integer.valueOf(tenderCorrigendumDetail.get(j).getObjectId()), new BigDecimal("0.0"));
                }
                 if (tenderCorrigendumDetail.get(j).getFieldName().equals("otherProcurementNature")) {                  
                        tenderDtBean.setTxtOtherProcNature(tenderCorrigendumDetail.get(j).getNewValue());                  
                 }
                 if (tenderCorrigendumDetail.get(j).getFieldName().equals("tenderNo")) {                  
                     tenderDtBean.setTxtTenderNo(tenderCorrigendumDetail.get(j).getNewValue());                  
                 }
                 if (tenderCorrigendumDetail.get(j).getFieldName().equals("tenderBrief")) {                  
                     tenderDtBean.setTxtaTenderBrief(tenderCorrigendumDetail.get(j).getNewValue());                  
                 }
                 if (tenderCorrigendumDetail.get(j).getFieldName().equals("tenderDetail")) {                  
                     tenderDtBean.setRtfTenderDetail(tenderCorrigendumDetail.get(j).getNewValue());                  
                 }
                 
                if(tenderCorrigendumDetail.get(j).getFieldName().contains("DocFeesPaymentType")){
                	String payTypes[]=tenderCorrigendumDetail.get(j).getNewValue().split(",");
                	List<SelectItem> selDocModeOfPayment = new ArrayList<SelectItem>();
                	List<Object[]> docModeOfPayment = null;
                	int docfeesPaymentMode = tenderCorrigendumService.getCorrigendumDetailPaymentMode(corrigendumId,"docFeePaymentMode");
                	if(docfeesPaymentMode !=0){
                		docModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, docfeesPaymentMode, 1, 3);
                	}else{
                		docModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getDocFeePaymentMode(), 1, 3);	
                	}
                	for (Object[] paymentType : docModeOfPayment) {
                		boolean flag = false;
						for (String payType : payTypes) {
							int payTypeId = commonService.getPaymentTypeDetail(payType.trim()).getPaymentTypeId();
							if(payTypeId == Integer.parseInt(paymentType[0].toString())){
								flag = true;
								selDocModeOfPayment.add(new SelectItem(paymentType[1],paymentType[0], paymentType[1]));
							}
						}
						
						if (!flag) {
							selDocModeOfPayment.add(new SelectItem(paymentType[1], paymentType[0], null));
			            }
					}
                	modelMap.addAttribute("selDocModeOfPayment", selDocModeOfPayment);
                }
                
                if(tenderCorrigendumDetail.get(j).getFieldName().contains("SecurityFeesPaymentType")) {    
                	String payTypes[]=tenderCorrigendumDetail.get(j).getNewValue().split(",");
                	List<SelectItem> selSecModeOfPayment = new ArrayList<SelectItem>();
                	List<Object[]> secModeOfPayment = null;
                	int secPaymentMode = tenderCorrigendumService.getCorrigendumDetailPaymentMode(corrigendumId,"secFeePaymentMode");
                	if(secPaymentMode !=0){
                		secModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, secPaymentMode, 10, 3);
                	}else{
                		secModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getSecFeePaymentMode(), 10, 3);
                	}
             		for (Object[] paymentType : secModeOfPayment) {
                		boolean flag = false;
						for (String payType : payTypes) {
							int payTypeId = commonService.getPaymentTypeDetail(payType.trim()).getPaymentTypeId();
							if(payTypeId == Integer.parseInt(paymentType[0].toString())){
								flag = true;
								selSecModeOfPayment.add(new SelectItem(paymentType[1],paymentType[0], paymentType[1]));
							}
						}
						
						if (!flag) {
							selSecModeOfPayment.add(new SelectItem(paymentType[1], paymentType[0], null));
			            }
					}
             		modelMap.addAttribute("selSecModeOfPayment", selSecModeOfPayment);
                }
                
                if(tenderCorrigendumDetail.get(j).getFieldName().contains("EMDPaymentType")) {
                	String payTypes[]=tenderCorrigendumDetail.get(j).getNewValue().split(",");
                	List<SelectItem> selEmdModeOfPayment = new ArrayList<SelectItem>();
                	List<Object[]> emdModeOfPayment= null;
                	int emdPaymentMode = tenderCorrigendumService.getCorrigendumDetailPaymentMode(corrigendumId,"emdPaymentMode");
                	if(emdPaymentMode !=0){
                		emdModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, emdPaymentMode, 2, 3);
                	}else{
                		emdModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getEmdPaymentMode(), 2, 3);	
                	}
                	for (Object[] paymentType : emdModeOfPayment) {
                		boolean flag = false;
						for (String payType : payTypes) {
							int payTypeId = commonService.getPaymentTypeDetail(payType.trim()).getPaymentTypeId();
							if(payTypeId == Integer.parseInt(paymentType[0].toString())){
								flag = true;
								selEmdModeOfPayment.add(new SelectItem(paymentType[1],paymentType[0], paymentType[1]));
							}
						}
						if (!flag) {
							selEmdModeOfPayment.add(new SelectItem(paymentType[1], paymentType[0], null));
			            }
					}
             		
                    modelMap.addAttribute("selEmdModeOfPayment", selEmdModeOfPayment);
                }
                
                if(tenderCorrigendumDetail.get(j).getFieldName().contains("RegistrationChargesPaymentTypes")) {
                	String payTypes[]=tenderCorrigendumDetail.get(j).getNewValue().split(",");
                	List<SelectItem> selRegModeOfPayment = new ArrayList<SelectItem>();
                	List<Object[]> regModeOfPayment = null;
                	int regPaymentMode = tenderCorrigendumService.getCorrigendumDetailPaymentMode(corrigendumId,"registrationChargesMode");
                	if(regPaymentMode != 0){
                		regModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, regPaymentMode, 8, 3);
                	}else{
                		regModeOfPayment = clientService.getClientEventPaymentType(clientId, tenderId, tblTender.getRegistrationChargesMode(), 8, 3);
                	}
             		for (Object[] paymentType : regModeOfPayment) {
                		boolean flag = false;
						for (String payType : payTypes) {
							int payTypeId = commonService.getPaymentTypeDetail(payType.trim()).getPaymentTypeId();
							if(payTypeId == Integer.parseInt(paymentType[0].toString())){
								flag = true;
								selRegModeOfPayment.add(new SelectItem(paymentType[1],paymentType[0], paymentType[1]));
							}
						}
						
						if (!flag) {
							selRegModeOfPayment.add(new SelectItem(paymentType[1], paymentType[0], null));
			            }
					}
             		
             		modelMap.addAttribute("selRegModeOfPayment", selRegModeOfPayment);
                }
                 
            }
            String[] ids = sb.toString().split(",");
            for (int i = 0; i < ids.length; i++) {
                boolean check = tenderCorrigendumService.isCanelCurrency(Integer.valueOf(ids[i]), tenderId);
                if (!check) {
                    currList.append(ids[i]);
                    currList.append(",");
                }
            }

            if (currList != null && currList.length() > 0) {
                modelMap.put("oldCurrency", currList.toString().substring(0, currList.length() - 1));
                modelMap.addAttribute("lstTenderCurrency", (Map<Integer, BigDecimal>) lstTenderDetail.get(1));
            }

        }
        List<SelectItem> formType = abcUtility.convert(eventCreationService.getFormType(tenderId));
        List<SelectItem> oldformType = new ArrayList<SelectItem>();

        if (arrFormType.size() > 0) {
            for (int i = 0; i < arrFormType.size(); i++) {
                oldformType.add(arrFormType.get(i));
                for (int j = 0; j < formType.size(); j++) {
                    boolean flag = formType.get(j).getLabel().equals(arrFormType.get(i).getLabel());
                    if (flag) {
                        formType.remove(formType.get(j));
                    }
                }

            }

        }
        List<Object[]> selectedformType = tenderCorrigendumService.getPendingCorrigendumFormType(tenderId);
        String selected = "0";
        List<SelectItem> items = new ArrayList<SelectItem>();
        StringBuffer selectedValue = new StringBuffer();


        for (int j = 0; j < formType.size(); j++) {
            boolean flag = false;
            for (int i = 0; i < selectedformType.size(); i++) {

                if (selectedformType.get(i)[1].equals(formType.get(j).getLabel())) {
                    flag = true;
                    items.add(new SelectItem(formType.get(j).getLabel(), formType.get(j).getValue(), formType.get(j).getValue()));
                    selectedValue.append(formType.get(j).getValue());
                    selectedValue.append(",");
                }
            }
            if (selectedValue.length() > 0) {
                selected = selectedValue.substring(0, selectedValue.length() - 1);
            }
            if (!flag) {
                items.add(new SelectItem(formType.get(j).getLabel(), formType.get(j).getValue(), null));
            }
        }

        modelMap.addAttribute("items", items);
        modelMap.addAttribute("selectedValue", selected);
        modelMap.addAttribute("oldformType", oldformType);
        modelMap.put("isIAgree", tenderCorrigendumService.isIAgreeByTenderId(tenderId));
        modelMap.addAttribute("hasErrors", hasErrors);
        
        /*** Check Brd mode condition **/
        modelMap.put("brdMode",tblTender.getBrdMode());	
        if(abcUtility.isModuleAssignToClient(request,9)){
        	modelMap.put("isCategoryAllow",commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
        	if(modelMap.get("isCategoryAllow").equals(1)){
        		modelMap.addAttribute("categoryNameList", commonService.getCategoryNameList(tenderId,tendercreationlink));
        		modelMap.addAttribute("eventTypeId", tblTender.getTblEventType().getEventTypeId());
        	}else{
        		modelMap.put("isCategoryAllow",0);
        	}
        }else{
        	modelMap.put("isCategoryAllow",0);
        }
        modelMap.addAttribute("isWorkflowReq", eventCreationService.isWorkflowReq(clientId));
    }

    /**
     * @author urja
     * @param tenderDtBean
     * @param tenderId
     * @param redirectAttributes
     * @param request
     * @param bindingResult
     * @param modelMap
     * @return
     * @throws Exception 
     */
    @RequestMapping(value = "/buyer/addtenderCorrigendum/{tenderId}", method = RequestMethod.POST)
    public String savetenderCorrigendum(@ModelAttribute TenderDtBean tenderDtBean, @PathVariable("tenderId") Integer tenderId, RedirectAttributes redirectAttributes, HttpServletRequest request, BindingResult bindingResult, ModelMap modelMap) throws Exception {
        String auditMessage = postEditEventNotice;
        List<Object[]> lstClientConfigFields = null;
        boolean validationflag = true;
        boolean isBidSubmitted = false;
        Map<String, Object> configParam1 = new HashMap<String, Object>();
        Map<String, Object> hideConfigParam = new HashMap<String, Object>();
        Map<String, Object> labelMap = new HashMap<String, Object>();
        // CR : 31701 done by Nikhil Jani Starting
        int oldTenderMode=0;
        int oldTenderResult=0;
        TblTender tblTender = new TblTender();
        tblTender = eventCreationService.getTenderMaster(tenderId);
    	oldTenderMode=tblTender.getTenderMode();
    	oldTenderResult=tblTender.getTenderResult();
    	//CR : 31701 finishing 
        String retVal = REDIRECT_SESSION_EXPIRED;
        boolean approvedInWorkflow = false;
        try {
        	 // CR : 31701 done by Nikhil Jani 
            if((oldTenderMode !=  tenderDtBean.getSelTenderMode() && tenderDtBean.getSelTenderMode() != 0) && (oldTenderMode==2 || oldTenderMode==3 || oldTenderMode==4)){
        		eventBidderMapService.deleteMappedBidder(tenderId,oldTenderResult);
        	}
            int clientId = abcUtility.getSessionClientId(request);
            int userDetailId = abcUtility.getSessionUserDetailId(request);
            int corrigendumId = 0;
            if (request.getParameter("hdcorrigendumId") != null) {
                corrigendumId = Integer.valueOf(request.getParameter("hdcorrigendumId").toString());
            }
            
            int workflowActionid=commonService.checkEntryTblWorkflow(corrigendumId,tenderId);
          	if(workflowActionid==3 || workflowActionid==5){
  				approvedInWorkflow = true;
  			}
            
            lstClientConfigFields = eventCreationService.getClientConfigurationFields(clientId, Integer.valueOf(request.getParameter("hdEventTypeId")));
            if (lstClientConfigFields != null) {
                for (int i = 0; i < lstClientConfigFields.size(); i++) {
                    labelMap.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[6].toString());
                }
            }
            if (lstClientConfigFields != null) {
            	 labelMap.put("docFeePaymentMode", "Mode of document fees payment");
            	 labelMap.put("secFeePaymentMode", "Mode of security fee payment");
            	 labelMap.put("emdPaymentMode", "Mode of EMD payment");
            	 labelMap.put("registrationChargesMode", "Registration charges payment mode");
            }
            if (serverSideValidation) {
                String data = "";
                if (lstClientConfigFields != null) {
                    for (int i = 0; i < lstClientConfigFields.size(); i++) {
                        if (Integer.parseInt(lstClientConfigFields.get(i)[0].toString()) == 1) {
                            if (lstClientConfigFields.get(i)[4] != null) {
                                configParam1.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[4].toString());
                            } else {
                                configParam1.put(lstClientConfigFields.get(i)[3].toString(), data);
                            }
                        }
                    }
                    if (lstClientConfigFields != null) {
                    	configParam1.put("docFeePaymentMode", "");
                    	configParam1.put("secFeePaymentMode", "");
                    	configParam1.put("emdPaymentMode", "");
                    	configParam1.put("registrationChargesMode", "");
                    }
                }
                tenderDtBean.setCommonValidators(commonValidators);
                tenderDtBean.setConversionService(conversionService);
                tenderDtBean.setConfigParam1(configParam1);
                tenderDtBean.setHideConfigParam(hideConfigParam);
                tenderDtBean.setIsCorrigendum(true);
                tenderDtBean.validateBean(bindingResult);
                //Custom validation
                customValidation(tenderDtBean,bindingResult, configParam1, tenderId);
                if (bindingResult.hasErrors()) {
                    validationflag = false;
                } else {
                    validationflag = true;
                }
                int iAgree=tenderCorrigendumService.isIAgreeByTenderId(tenderId);
                if (labelMap.get("isConsortiumAllowed") != null) {
                	if(iAgree>0){
                        if (!String.valueOf(tenderDtBean.getSelIsConsortiumAllowed()).equals(String.valueOf(tblTender.getIsConsortiumAllowed()))) {
                        	validationflag = false; 
                        	isBidSubmitted = true;
                        	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_publish_corrigendum_bid_received");
                        }
                    }
                }
            }
            if (validationflag && !approvedInWorkflow) {

                if (request.getSession().getAttribute(SESSIONOBJECT) != null) {  
                     String[] lst = null;
                    if (request.getParameter("hdFormType") != null) {
                        lst = request.getParameter("hdFormType").toString().split(",");
                    }
                    String currIdList = request.getParameter("txtCommaSepCur");
                //    String hiddenList = request.getParameter("hdcurrencies").toString();
                    String currencyId=request.getParameter("hdCurrencyId");
                    int envelopeType=0;
                    if (tenderDtBean.getTxtEmdSubmissionEndDate() != null ) {
                    	auditMessage = "EMD submission end date and time is edited";
                    }
                    if(tenderDtBean.getTxtSubmissionEndDate() != null && tenderDtBean.getTxtEmdSubmissionEndDate() == null){
                    	tenderDtBean.setTxtEmdSubmissionEndDate(tenderDtBean.getTxtSubmissionEndDate());
                    }
                    prepareCorrigendumData(tenderDtBean, corrigendumId,tenderId,lst,currIdList,currencyId,envelopeType, userDetailId, labelMap);
                }
                retVal = "redirect:/etender/buyer/tenderdashboard/" + tenderId + "/4" + encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/4", request);
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_success_corrigendum_updated");
            } else {
                TenderDateDtBean tenderDateDtBean=new TenderDateDtBean();
                corrigendumTenderModelMap(tenderDtBean, tenderDateDtBean,modelMap, request, corrigendumId, tenderId, Integer.valueOf(request.getParameter("hdEventTypeId")),true);
                modelMap.addAttribute("tenderId", tenderId);
                modelMap.addAttribute("corrigendumId", corrigendumId);
                List<Object> lstTenderDetail = eventCreationService.getTenderDetail(tenderId);              
                List<Object[]> listCurrency = commonService.getCurrencyList(clientId);
                List<SelectItem> baseCurrency = abcUtility.convert(listCurrency);
                modelMap.addAttribute("baseCurrency", baseCurrency);
                modelMap.addAttribute("listCurrency", listCurrency);
                modelMap.addAttribute("opType", "edit");                  
                modelMap.addAttribute("lstTenderCurrency", (Map<Integer, BigDecimal>) lstTenderDetail.get(1));
                modelMap.addAttribute("tenderDateDtBean", tenderDateDtBean);               
                retVal = "/etender/buyer/TenderCorrigendum";
                int iAgree=tenderCorrigendumService.isIAgreeByTenderId(tenderId);
                if(iAgree>0 && isBidSubmitted){
                	retVal="redirect:/etender/buyer/tendercorrigendum/"+tenderId+"/"+tblTender.getTblEventType().getEventTypeId()+ encryptDecryptUtils.generateRedirect("etender/buyer/tendercorrigendum/"+tenderId+"/"+tblTender.getTblEventType().getEventTypeId(), request);
                }
                if(approvedInWorkflow){
                	retVal = "redirect:/etender/buyer/tenderdashboard/" + tenderId + "/4" + encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/4", request);
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_workflow_complete");
                }
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumEdit, auditMessage, tenderId, 0);
        }
       return retVal;
    }

    /**
     *
     * @author VIPULP
     * @param tenderId
     * @param request
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/buyer/showpublishcorrigendum/{tenderId}/{corrigendumId}/{enc}", method = RequestMethod.GET)
    public String showPublishCorrigendum(@PathVariable("tenderId") int tenderId,@PathVariable("corrigendumId") int corrigendumId,
            HttpServletRequest request, ModelMap modelMap, RedirectAttributes redirectAttributes) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<TblCorrigendum> corrigendumList = tenderCorrigendumService.getPendingCorrigendumByTenderId(tenderId);
            int isMin1FormMappedAfterCorrigendum = tenderCorrigendumService.isMin1FormMappedAfterCorrigendum(tenderId,1,4);
            modelMap.addAttribute("tenderId", tenderId);
            modelMap.addAttribute("corrigendumList", corrigendumList);
            
            if(isMin1FormMappedAfterCorrigendum>0)
            {
            	String msg = "";
            	msg = "msg_minimum_one_form_not_mapped_with_envelope";
            	String pageView = "redirect:/etender/buyer/tenderdashboard/" + tenderId + "/4"  + encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/4", request); 
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), msg);
                 return pageView;
            }
            if(corrigendumList.isEmpty() || corrigendumList==null){
            	String msg = "";
                 List<TblCorrigendum> tblCorrigendumList = tenderCorrigendumService.getCorrigendumByCorrigendumId(corrigendumId);
                 if(tblCorrigendumList!=null && !tblCorrigendumList.isEmpty()){
                	 TblCorrigendum tblCorrigendum = tblCorrigendumList.get(0);
                	 if(tblCorrigendum.getCstatus()==1){
                    	 msg = "msg_corrigendum_already_published";
                     }
                 }else  {
                	 msg = "msg_corrigendum_already_deleted";
                 }
                 String pageView = "redirect:/etender/buyer/tenderdashboard/" + tenderId + "/4"  + encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/4", request); 
                 redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), msg);
                  return pageView;
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumPublishLinkId, getPublishcorrigendum, tenderId, 0);
        }

        return "/etender/buyer/PublishCorrigendum";
    }

    /**
     *
     * @author VIPULP
     * @param request
     * @param redirectAttributes
     * @return to view
     */
    @RequestMapping(value = "/buyer/publishcorrigendum", method = RequestMethod.POST)
    public String publishCorrigendum(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String pageView = "redirect:/sessionexpired";
        int clientId = abcUtility.getSessionClientId(request);
        int tenderId = 0;
        String eventType = "";
        List<String> lstParams = new ArrayList<String>();
        Map<String,Object> paramValue = new HashMap<String, Object>();
        Map<String,Object> mailParams = new HashMap<String, Object>();
        boolean isPublish = false;
        String msg=CommonKeywords.ERROR_MSG_KEY.toString();
        /*PT #38423 : start*/
        List<TblTenderCPV> tblTenderCPVList = new ArrayList<TblTenderCPV>();
		TblTenderCPV tblTenderCPV = null;
		String cpvCodeChar[];
		String cpvCode = null;
		int deptId = 0;
		int buyerId = 0;
		TblTender tblTender = null;
		TblClient tblClient = null;
		List<Map<String,Object>> validateTenderLinks = null;
		/*PT #38423 : End*/
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            	tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
            	int corrigendumId = StringUtils.hasLength(request.getParameter("hdCorrigendumId")) ? Integer.parseInt(request.getParameter("hdCorrigendumId")) : 0;
            	List<Object[]> lst = tenderCommonService.getTenderFields(tenderId, "isOpeningByCommittee,isEvaluationByCommittee,isEvaluationRequired,isCertRequired,tenderMode,bidderMapping,tenderResult");
            	Map<String,Object>  paymentAllow =tenderCommonService.verifyTenderPaymentConfig(tenderId, clientId);
            	validateTenderLinks = (List<Map<String,Object>>)commonService.validateTenderRules(abcUtility.getSessionClientId(request), tenderId, 27, abcUtility.getSessionUserId(request),corrigendumPublishLinkId).get(RESULTSET_1);
            	int isCertRequired =0;
            	int tenderMode = 0;
            	int bidderMapping = 0;
                int tenderResult = 0;
            	int isMin1FormMappedAfterCorrigendum = tenderCorrigendumService.isMin1FormMappedAfterCorrigendum(tenderId,1,4);
            	if (lst!=null && !lst.isEmpty()) {
            		 isCertRequired = Integer.parseInt(lst.get(0)[3].toString());
            		 tenderMode = Integer.parseInt(lst.get(0)[4].toString());
            		 tenderResult = Integer.parseInt(lst.get(0)[6].toString());
            		 bidderMapping = Integer.parseInt(lst.get(0)[5].toString());
            		 
            	}
            	if(!validateTenderLinks.get(0).get("remark").toString().equals("Success")){
            		isPublish = true;
            		msg = validateTenderLinks.get(0).get("remark").toString();
            	}else if(paymentAllow!=null && !paymentAllow.isEmpty() && !(Boolean)paymentAllow.get("result")){
            		isPublish = true;
            		msg= paymentAllow.get("errMsg").toString();
            	}else if(tenderFormService.getNoOfEncryptedPriceBidForm(tenderId)!=0 && isCertRequired == 1){
            		isPublish=true;
            		msg= "msg_pricebid_encryption_required";
            	}else if(isMin1FormMappedAfterCorrigendum>0)
	            {
            		isPublish=true;
            		msg= "msg_minimum_one_form_not_mapped_with_envelope";
	            }
            	
            	 List<TblCorrigendum> tblCorrigendumList = tenderCorrigendumService.getCorrigendumByCorrigendumId(corrigendumId);
            	if (lst!=null && !lst.isEmpty()) {
            		int isOpeningByCommittee = Integer.parseInt(lst.get(0)[0].toString());
            		int isEvaluationByCommittee = Integer.parseInt(lst.get(0)[1].toString());
            		int isEvaluationRequired = Integer.parseInt(lst.get(0)[2].toString());
//            		tenderResult = Integer.parseInt(lst.get(0)[5].toString());
            		boolean isNegotiationStated = negotiationService.isNegotiationAllowedAndNegotiationStarted(tenderId,negotiation_negotiation_process_invite_for_negotiation);
            		if(tblCorrigendumList!=null && !tblCorrigendumList.isEmpty()){
	                   	 TblCorrigendum tblCorrigendum = tblCorrigendumList.get(0);
	                   	 if(tblCorrigendum.getCstatus()==1){
	                   		isPublish = true;
	                       	 msg = "msg_corrigendum_already_published";
	                   	 }
		           		}else {
		           			isPublish = true;
		                  	 msg = "msg_corrigendum_already_deleted";
		               }
            		if(isOpeningByCommittee==0 && isEvaluationByCommittee==0){
            			boolean isEvalutaionStart = tenderFormService.checkEntryBidderAppDtls(tenderId);
            			if(isEvaluationRequired==1 && !isEvalutaionStart){
            				isPublish = true;
            				msg = "msg_publish_corrigendum_evastart";
            			}
            			if(!isPublish && isNegotiationStated){
            				isPublish = true;
            				msg = "msg_publish_corrigendum_negotiationstart";
            			}
            		}else{
            			List<Object> isTenderOpenedDtls = tenderFormService.isTenderEnvOpened(tenderId);
            			if(isTenderOpenedDtls!=null && !isTenderOpenedDtls.isEmpty()){
            				int isTenderEnvOpened = Integer.parseInt(isTenderOpenedDtls.get(0).toString());
            				if(isTenderEnvOpened >= 1){
            					isPublish = true;
            					msg = "msg_publish_corrigendum_envopened";
            				}
            			}
            		}
            		int iAgree=tenderCorrigendumService.isIAgreeByTenderId(tenderId);
            		if(iAgree > 0){
            			List<TblCorrigendumDetail> corrigendumDetailList = tenderCorrigendumService.getCorrigendumDetailWithProcessId(corrigendumId);
            			for (TblCorrigendumDetail tblCorrigendumDetail : corrigendumDetailList) {
							if(tblCorrigendumDetail.getFieldName().trim().equals("isConsortiumAllowed")){
								if(!tblCorrigendumDetail.getOldValue().equals(tblCorrigendumDetail.getNewValue())){
									isPublish = true;
	            					msg = "msg_publish_corrigendum_bid_received";
								}
							}
						}
            		}
            		
            		//Bug #38945 *************Start Here***********
            		List<TblCorrigendumDetail> corrigendumDtlforPayType = tenderCorrigendumService.getCorrigendumDetailWithProcessId(corrigendumId);
            		int delCount=0;
            	    for (TblCorrigendumDetail tblCorrigendumDetail : corrigendumDtlforPayType) {
            	    	if(tblCorrigendumDetail.getTblProcess().getProcessId() == 10){
            	    		List<Object[]>  modeOfDocPaymentType = tenderCorrigendumService.getPaymentTypeForEvent(tenderId, 1, 1, 3);
            	    		List<Object[]>  modeOfSecPaymentType = tenderCorrigendumService.getPaymentTypeForEvent(tenderId, 1, 10, 3);
            	    		List<Object[]>  modeOfEmdPaymentType = tenderCorrigendumService.getPaymentTypeForEvent(tenderId, 1, 2, 3);
            	    		List<Object[]>  modeOfRegPaymentType = tenderCorrigendumService.getPaymentTypeForEvent(tenderId, 1, 8, 3);
            	    		 
            	    		if(tblCorrigendumDetail.getFieldName().contains("DocFeesPaymentType") && modeOfDocPaymentType!= null && !modeOfDocPaymentType.isEmpty()) {
            	        		String payType[]=tblCorrigendumDetail.getNewValue().split(",");
            	        		String pType=""; 
            	        		for (Object[] paymentType : modeOfDocPaymentType) {
            	        			List<Integer> newDocFeesPaymentsList = new ArrayList<Integer>();
            	        			for (String type : payType) {
            	        				int payTypeId= commonService.getPaymentTypeDetail(type.trim()).getPaymentTypeId();
            	        				newDocFeesPaymentsList.add(payTypeId);
            	        			}
            	        			if(!newDocFeesPaymentsList.contains(Integer.parseInt(paymentType[0].toString()))){
            	        				isPublish = true;
            	        				pType += paymentType[1].toString()+ "," ;
            	        				redirectAttributes.addFlashAttribute("type", pType.substring(0, pType.length() - 1));
        	        					redirectAttributes.addFlashAttribute("payFor", "DocFees");
    	            					msg = "msg_event_paytype_corrigendum";
            	        			}
            	        		}
            	    		}else if(tblCorrigendumDetail.getFieldName().contains("SecurityFeesPaymentType") && modeOfSecPaymentType != null && !modeOfSecPaymentType.isEmpty()) {
            	    			String payType[]=tblCorrigendumDetail.getNewValue().split(",");
            	    			String pType="";
	    	    				for (Object[] paymentType : modeOfSecPaymentType) {
	    	    					List<Integer> newSecFeesPaymentsList = new ArrayList<Integer>();
	    	    					for (String type : payType) {
	        	        				int payTypeId= commonService.getPaymentTypeDetail(type.trim()).getPaymentTypeId();
	        	        				newSecFeesPaymentsList.add(payTypeId);
	        	        			}
	        	        			if(!newSecFeesPaymentsList.contains(Integer.parseInt(paymentType[0].toString()))){
	        	        				isPublish = true;
	        	        				pType += paymentType[1].toString()+ "," ;
	        	        				redirectAttributes.addFlashAttribute("type", pType.substring(0, pType.length() - 1));
        	        					redirectAttributes.addFlashAttribute("payFor", "SecurityFees");
		            					msg = "msg_event_paytype_corrigendum";
	        	        			}
	        	        		}
            	    		}else if(tblCorrigendumDetail.getFieldName().contains("EMDPaymentType") && modeOfEmdPaymentType != null && !modeOfEmdPaymentType.isEmpty()) {
            	    			String payType[]=tblCorrigendumDetail.getNewValue().split(",");
            	    			String pType="";
        	    				for (Object[] paymentType : modeOfEmdPaymentType) {
            	        			List<Integer> newEmdPaymentsList = new ArrayList<Integer>();
            	        			for (String type : payType) {
            	        				int payTypeId= commonService.getPaymentTypeDetail(type.trim()).getPaymentTypeId();
            	        				newEmdPaymentsList.add(payTypeId);
            	        			}
            	        			if(!newEmdPaymentsList.contains(Integer.parseInt(paymentType[0].toString()))){
            	        				isPublish = true;
            	        				pType += paymentType[1].toString()+ "," ;
            	        				redirectAttributes.addFlashAttribute("type", pType.substring(0, pType.length() - 1));
        	        					redirectAttributes.addFlashAttribute("payFor", "EMD");
    	            					msg = "msg_event_paytype_corrigendum";
            	        			}
            	        		}
            	    		}else if(tblCorrigendumDetail.getFieldName().contains("RegistrationChargesPaymentTypes") && modeOfRegPaymentType != null && !modeOfRegPaymentType.isEmpty()) {
            	    			String payType[]=tblCorrigendumDetail.getNewValue().split(",");
            	    			String pType="";
            	    			for (Object[] paymentType : modeOfRegPaymentType) {
            	    				List<Integer> newRegPaymentsList = new ArrayList<Integer>();
        	    					for (String type : payType) {
        	    						int payTypeId= commonService.getPaymentTypeDetail(type.trim()).getPaymentTypeId();
        	    						newRegPaymentsList.add(payTypeId);
        	    					}
        	    					if(!newRegPaymentsList.contains(Integer.parseInt(paymentType[0].toString()))){
        	    						isPublish = true;
        	    						pType += paymentType[1].toString()+ "," ;
        	        					redirectAttributes.addFlashAttribute("type", pType.substring(0, pType.length() - 1));
        	        					redirectAttributes.addFlashAttribute("payFor", "RegistrationCharges");
     	            					msg = "msg_event_paytype_corrigendum";
            	        			}
            	    			}
            	    		}
//            	    		#CR : 24441
            	    		else if(tblCorrigendumDetail.getFieldName().contains("AddNoticeDocument") && modeOfRegPaymentType != null && !modeOfRegPaymentType.isEmpty()) {
            	    			fileUploadService.updateOfficerDocDetailsForRemove(tblCorrigendumDetail.getObjectId(),1);            	    			
            	    		}else if(tblCorrigendumDetail.getFieldName().contains("ApproveNoticeDocument") && modeOfRegPaymentType != null && !modeOfRegPaymentType.isEmpty()) {
            	    			fileUploadService.updateOfficerDocDetailsForRemove(tblCorrigendumDetail.getObjectId(),1);
            	    		}else if(tblCorrigendumDetail.getFieldName().contains("CancelNoticeDocument") && modeOfRegPaymentType != null && !modeOfRegPaymentType.isEmpty()) {
            	    			delCount++;
            	    		}
            			}
            		}       
            	    if(delCount>0)
            	    	fileUploadService.cancelOfficerDocDetails(corrigendumId);
//            	    #CR : 24441 Ends
            	    //Bug #38945 *************END Here ************
            	}
            	if(isPublish){
            		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), msg);
            	}else{
            		if (StringUtils.hasLength(request.getParameter("txtaRemarks"))) {
                        tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
                        eventType = StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
                        corrigendumId = StringUtils.hasLength(request.getParameter("hdCorrigendumId")) ? Integer.parseInt(request.getParameter("hdCorrigendumId")) : 0;
                        lstParams.add(String.valueOf(corrigendumId));
                        int userDetailId = abcUtility.getSessionUserDetailId(request);
                        String remarks = request.getParameter("txtaRemarks");
                        
                        paramValue.put("objectId",tenderId);
                        paramValue.put("userDetailId",userDetailId);
                        
                        TblCorrigendum tblCorrigendum = new TblCorrigendum(corrigendumId);
                        tblCorrigendum.setRemarks(remarks);
                        tblCorrigendum.setPublishedOn(commonService.getServerDateTime());
                        tblCorrigendum.setPublishedBy(userDetailId);
                        tblCorrigendum.setObjectId(tenderId);
                        tblCorrigendum.setCstatus(1);
	                    try{
	                   	   if (clientService.checkCPPPConfigureOrNot(clientId) && clientService.checkCPPPRequireOrNot(clientId)) {
		                   		Set<String> corrtype = new HashSet<String>();
			                    TblTender tenderForCorringendum = eventCreationService.getTenderMaster(tenderId);
			                    List<TblCorrigendumDetail> lstCorrigendumDtls = tenderCorrigendumService.getCorrigendumDetailWithProcessId(corrigendumId);
		//	                    TblTender tenderForCorringendum = new TblTender();
			                    for (TblCorrigendumDetail tblCorrigendumDetail : lstCorrigendumDtls) {
			                    	if(!tblCorrigendumDetail.getNewValue().contains("label_") && tblCorrigendumDetail.getTblProcess().getProcessId() == 1){	
				                    	 Class<? extends Object> clazz = tenderForCorringendum.getClass();
				                    	 boolean tblPresent = false;
				                    	 if(tblCorrigendumDetail.getFieldName().equalsIgnoreCase("deptId")){
				                    		 tblPresent = true;
				                        	 Method getMethod = clazz.getDeclaredMethod("getTblDepartment");
				                        	 Method setMethod = clazz.getDeclaredMethod("setTblDepartment",getMethod.getReturnType());
				                        	 Class<? extends Object> clazz1 = getMethod.getReturnType();                    	 
				                        	 setMethod.invoke(tenderForCorringendum,toObject(clazz1, tblCorrigendumDetail.getNewValue()));
				                    	 }
				                    	 if(tblCorrigendumDetail.getFieldName().equalsIgnoreCase("procurementNatureId")){
				                    		 tblPresent = true;
				                        	 Method getMethod = clazz.getDeclaredMethod("getTblProcurementNature");
				                        	 Method setMethod = clazz.getDeclaredMethod("setTblProcurementNature",getMethod.getReturnType());
				                        	 Class<? extends Object> clazz1 = getMethod.getReturnType();                    	 
				                        	 setMethod.invoke(tenderForCorringendum,toObject(clazz1, tblCorrigendumDetail.getNewValue()));
				                    	 }
				                    	 if(tblCorrigendumDetail.getFieldName().equalsIgnoreCase("eventTypeId")){
				                    		 tblPresent = true;
				                        	 Method getMethod = clazz.getDeclaredMethod("getTblEventType");
				                        	 Method setMethod = clazz.getDeclaredMethod("setTblEventType",getMethod.getReturnType());
				                        	 Class<? extends Object> clazz1 = getMethod.getReturnType();                    	 
				                        	 setMethod.invoke(tenderForCorringendum,toObject(clazz1, tblCorrigendumDetail.getNewValue()));
				                    	 }
				                    	 if(!tblPresent && StringUtils.hasLength(tblCorrigendumDetail.getFieldName())){
				                        	 Method getMethod = clazz.getDeclaredMethod("get" + StringUtils.capitalize(tblCorrigendumDetail.getFieldName()));
				                        	 Method setMethod = clazz.getDeclaredMethod("set" + StringUtils.capitalize(tblCorrigendumDetail.getFieldName()),getMethod.getReturnType());
				                        	 Class<? extends Object> clazz1 = getMethod.getReturnType();                    	 
				                        	 setMethod.invoke(tenderForCorringendum,toObject(clazz1, tblCorrigendumDetail.getNewValue()));
				                        	 
				                        	 Map<String,List<String>> corrTypeMap = getCorrigendumStatus();
				                        	 for (Map.Entry<String, List<String>> entry : corrTypeMap.entrySet())
				                        	 {
				                        	     if(entry.getValue().contains(tblCorrigendumDetail.getFieldName())){
				                        	    	 corrtype.add(entry.getKey());
				                        	    }
				                        	     
				                        	 }
				                        	 
				                    	 }
				                    }
								}
			                    for (String corrtypeStr : corrtype) {
			                    	tenderCorrigendumService.toCoreTender2Cppp(clientId,tenderForCorringendum, tenderId, corrtypeStr, corrStatus, corrigendumId,remarks,tenderForCorringendum.getTenderNo());
								}
	                          }
	                   	}catch(Exception ex){
	                   		return exceptionHandlerService.writeLog(ex);
	                    }
	                    Map<String,Map<String,Object>>queryFields = new HashMap<String,Map<String,Object>>();
	                    List<String> lstQueries = getCorrigendumDtlQueries(remarks,queryFields,tenderId, corrigendumId,userDetailId);
	                    int corrigendumCount = (Integer) tenderCommonService.getTenderField(tenderId, "corrigendumCount");
	                    String keywordTxt = tenderCorrigendumService.getCorrigendumDtlKeywordTxt(corrigendumId);
	                    String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
	                    paramValue.put("ipAddress", ipAddress);
	                    ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	                    if (tenderCorrigendumService.executeCorrigendumDtlsQueries(lstQueries, queryFields,tblCorrigendum, keywordTxt,paramValue, (corrigendumCount + 1), tenderId,clientBean.getIsDualCerti(),clientId) != 0) {
	                        MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
	                        messageConfigDatabean.setQueueName(queueName);
	                        messageConfigDatabean.setTemplateId(Integer.parseInt(publishCorrigendumTemplateId));
	                        messageConfigDatabean.setUserId(abcUtility.getSessionUserId(request));
	                        messageConfigDatabean.setClientId(abcUtility.getSessionClientId(request));
	                        messageConfigDatabean.setObjectId(tenderId);
	                        messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
	                        messageConfigDatabean.setContextPath(request.getContextPath());
	                        messageConfigDatabean.setLstParams(lstParams);
	                        //Added By Lipi - Start
	                        mailParams.put("eventType",eventType);
	                        mailParams.put("eventId",tenderId);//for subject
	                        String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/viewtender/" + tenderId);
	                    	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
	                    	mailParams.put("link", herfStr);
	                    	mailParams.put("SubDomainName",clientService.getClientNameById(abcUtility.getSessionClientId(request)));
                            boolean isMarkCCRequired =(Integer.parseInt(commonService.getClientAlertConfig(corrigendumPublishLinkId, clientId).get(0)[3].toString())==1) ? true : false;
	                    	if(isMarkCCRequired){
		                    	int officerId =  (Integer) tenderCommonService.getTenderField(tenderId, "officerId");
		                        String deptOfficerLogin = "";
		                        List<TblUserLogin> list = commonService.getUserLoginById(officerId);
		                        if(list!=null && !list.isEmpty()){
		                        	deptOfficerLogin = list.get(0).getLoginId();
		                        }
		                        StringBuilder ccEmailIds = new StringBuilder();
		                        if(Integer.parseInt(idfcClientId) == clientId){
		                        	ccEmailIds.append(idfcEmailCC).append(",").append(deptOfficerLogin);
		                        }
		                        ccEmailIds.append(deptOfficerLogin);
		                        messageConfigDatabean.setCc(ccEmailIds.toString());
	                    	}
	                    	
	                    	// PT #34914 By Jitendra. Add BCC Email ID in publish corrigendum mail if tender mode is limited or proprietary or nomination.
                            if(tenderMode == 2 || tenderMode == 3 || tenderMode == 4){
                            	messageConfigDatabean.setBcc(eventMailBCC);
                            }
	                    	messageConfigDatabean.setParamMap(mailParams);
	                        //End
	                        messageQueueService.sendMessage(messageConfigDatabean);
	//                        mailContentUtillity.dynamicMailGeneration("44", "0", String.valueOf(tenderId), null, String.valueOf(corrigendumId));
	                        
	                        //Added For PT:#26230 (Only Used For ItemWiseCase and TenderMode=2 for Limited,3 for Proprietary, 4 for Nomination)
	                        tenderFormService.deleteMapBidderEntryForItemWiseCase(tenderId);

	                        //if whole event bidder mapped than bidder mapped in itemwise tender before adding bidding form (#64223) Rinju
	                        int mapBidderId = 0;
	                        int companyId = 0;
	                        int createdBy = 0;
	                        int bidderUserDetailId = 0;
	                        	if(bidderMapping == 0 && tenderResult == 2 && tenderMode == 2){
	                        		List<Object[]> mappedBidderLst = eventBidderMapService.getTenderBidderMap(tenderId);
	                        		List<Object> tableIdList = tenderFormService.getPriceBidTableLstByTenderId(tenderId);
	                        		for (Object[] mappedBidderLsts : mappedBidderLst) {
	                        			mapBidderId = (Integer) mappedBidderLsts[0];
	                        			companyId = (Integer) mappedBidderLsts[1];
	                        			bidderUserDetailId = (Integer) mappedBidderLsts[2];
	                        			createdBy = (Integer) mappedBidderLsts[3];
	                        			for(Object tableIds : tableIdList){
	                						List<Object[]> tenderTableList = tenderFormService.getTenderTableDetails((Integer)tableIds);
	                						int noOfRows = (Integer) tenderTableList.get(0)[6];
	                						int hasGTRows = (Integer) tenderTableList.get(0)[9];
	                						List<Object[]> itemList = eventCreationService.getItemBidderMapByTableidAndMapibidderid((Integer)tableIds,mapBidderId);
	                						for(int i=1; i<=(noOfRows-hasGTRows); i++){
	                							if(!itemList.contains(i)){
	                								TblItemBidderMap tblItemBidderMap = new TblItemBidderMap();
	            	          	      	            tblItemBidderMap.setTblTenderBidderMap(new TblTenderBidderMap(mapBidderId));
	            	          	      		        tblItemBidderMap.setTblTenderTable(new TblTenderTable((Integer)tableIds));
	            	          	      	            tblItemBidderMap.setRowId(i);
	            	          	      	            tblItemBidderMap.setIpAddress(ipAddress);
	            	          	      	            tblItemBidderMap.setCreatedBy(userDetailId);
	            	          	      	            itemBidderMapDao.addTblItemBidderMap(tblItemBidderMap);
	            	          	      	                  
	            	          	      	            TblTenderMapBidderHistory tblTenderMapBidderHistory = new TblTenderMapBidderHistory();
	            	          	      	            tblTenderMapBidderHistory.setTblTender(new TblTender(tenderId));
	            	          	      	            tblTenderMapBidderHistory.setTblUserDetail(new TblUserDetail(bidderUserDetailId));
	            	          	      	            tblTenderMapBidderHistory.setCreatedBy(userDetailId);
	            	          	      	            tblTenderMapBidderHistory.setIsMapped(1);
	            	          	      	            tblTenderMapBidderHistory.setTblCompany(new TblCompany(companyId));
	            	          	      	            tblTenderMapBidderHistory.setTableId((Integer)tableIds);
	            	          	      	            tblTenderMapBidderHistory.setRowId(i);
	            	          	      	            tblTenderMapBidderHistoryDao.addTblTenderMapBidderHistory(tblTenderMapBidderHistory);
	                						}
	                    						
	                    				}
	                			}
	                        		}
	                        	}
	                        	//END
	                        // Bug #59576
	                        eventCreationService.updateTenderEvalutionStatus(tenderId, 0);
	                        
	                        redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_success_corrigendum_published");
	                       
	                        String notificationMsg = "Corrigendum has been published for Event ID: "+tenderId;
	                        tenderCommonService.sendMobileNotification(3,  notificationMsg, tenderId,1,abcUtility.getSessionClientId(request));
	                        /*PT #38423 : start*/
	                		tblClient = clientService.getClientById(clientBean.getClientId());
	                		tblTender = eventCreationService.getTenderMaster(tenderId);
	                		cpvCode = tblTender.getKeywordText();
	                		if(tblTender != null && cpvCode != null && tblClient != null && tblClient.getCategoryType() == 1 && tblTender.getIsDemoTender() == 0){
		                		deptId = tblTender.getTblDepartment().getDeptId();		
		            			buyerId = tblTender.getOfficerId();
		            			if (cpvCode.contains(",")) {
		            				cpvCodeChar = cpvCode.split(",");
		            				for (int k = 0; k < cpvCodeChar.length; k++) {
		            					tblTenderCPV = new TblTenderCPV();
		            					tblTenderCPV.setTblTender(new TblTender(tenderId));
		            					tblTenderCPV.setCpvCode("");
		            					tblTenderCPV.setKeyword(cpvCodeChar[k].trim());
		            					tblTenderCPV.setTblUserLogin(new TblUserLogin(buyerId));
		            					tblTenderCPV.setIsDummyOfficer(0);
		            					tblTenderCPV.setDomainId(clientId);
		            					tblTenderCPV.setDeptId(deptId);				
		            					tblTenderCPVList.add(tblTenderCPV);
		            				}
		            			} else {
		            				tblTenderCPV = new TblTenderCPV();
		            				tblTenderCPV.setTblTender(new TblTender(tenderId));
		            				tblTenderCPV.setCpvCode("");
		            				tblTenderCPV.setKeyword(cpvCode.trim());
		            				tblTenderCPV.setTblUserLogin(new TblUserLogin(buyerId));
		            				tblTenderCPV.setIsDummyOfficer(0);
		            				tblTenderCPV.setDomainId(clientId);
		            				tblTenderCPV.setDeptId(deptId);				
		            				tblTenderCPVList.add(tblTenderCPV);
		            			}
		            			if(tenderCPVService.deleteTenderCPVCode(tenderId)){
		            				tenderCPVService.addClassificationKeywords(tblTenderCPVList);
		            			}
	                		}
	                		/*PT #38423 : End*/
	                    } else {
	                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
	                    }
	                    //Added by Mitesh
	                    tenderCorrigendumService.updateMinMandatoryFormsIfnotOrganize(tenderId, corrigendumId);
	                     //Remove workflow for bid opening process if submissionEndDate Changed
	                    if(tenderCorrigendumService.isFieldValueChangedCorrigendumDetail(corrigendumId,"submissionEndDate")){
	                    	workflowService.deleteWorkflowByLinkIdAndParentId(bid_opening_process_process_in_workflow, tenderId);
	                    }
	                    
	                }
            	}
            	pageView = "redirect:/etender/buyer/tenderdashboard/" + tenderId + "/4"
                        + encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/4", request);                
            }

        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumPublishLinkId, postPublishcorrigendum, tenderId, 0);
        }
        return pageView;
    }

    /**
     * @author urja
     * @param data
     * @return
     */
    private List<SelectItem> generateList(String data) {
        String[] dataOne = data.split("~");
        List<SelectItem> dataList = new ArrayList<SelectItem>();

        for (String tempData : dataOne) {
            String[] dataTwo = tempData.split("::");
            dataList.add(new SelectItem(messageSource.getMessage(dataTwo[0], null, LocaleContextHolder.getLocale()), dataTwo[1]));
        }
        return dataList;
    }

    /**
     * @author urja
     * @param data
     * @return
     */
    private String generateDataForView(String data) {
        String[] dataValue = data.split("::");
        return messageSource.getMessage(dataValue[0], null, LocaleContextHolder.getLocale());
    }

    /**
     * @author VIPULP
     * @param objectId
     * @return {@code List<String>}
     * @throws Exception
     */
    
    private List<String> getCorrigendumDtlQueries(String remark,Map<String,Map<String,Object>> queryParameter, int... objectId) throws Exception {
        List<String> lstQueries = new ArrayList<String>();
        Map<String, Object> tblTender = new HashMap<String, Object>();
        List<Object[]> lstCorrigendumDtls = tenderCorrigendumService.getTenderCorrigendumDtls(objectId[1]);
        List<Object> lstProcess = tenderCorrigendumService.getCorrigendumProcessTbls(objectId[1]);
        List<Object[]> lstTenderFields = tenderCommonService.getTenderFields(objectId[0], "envelopeType,openingDate");
        int envelopeType = 0;
        String tenderOpeningDt = null;
        if (!lstTenderFields.isEmpty()) {
            envelopeType = (Integer) lstTenderFields.get(0)[0];
            tenderOpeningDt = lstTenderFields.get(0)[1].toString();
        }
        Date currentDt = commonService.getServerDateTime();
        StringBuilder query = new StringBuilder();
        StringBuilder param = new StringBuilder();
        boolean isEnvelopeNotPublished=tenderFormService.getTenderEnvelopeByOpeningDateStatus(objectId[0], 1);
        boolean operFlag = false;
        boolean isTenderEnvelope = false;
        ArrayList<String> whereCondGovCol = new ArrayList<String>();
        for (int i = 0; i < lstProcess.size(); i++) {
            String tblName = (String) lstProcess.get(i);
            if ("TblTender".equals(tblName)) {
                query.delete(0, query.length());
                query.append("update TblTender set $fieldvalues where tenderId=$tenderId");
            } else if ("TblTenderCurrency".equals(tblName)) {
                query.delete(0, query.length());
                query.append("update TblTenderCurrency set isActive=$fieldvalues where tenderCurrencyId in ('$tenderCurrencyId')");

            } else if ("TblTenderForm".equals(tblName) && isEnvelopeNotPublished) {
                query.delete(0, query.length());
                query.append("update TblTenderForm set cstatus=$fieldvalues,$addlCols where formId in ('$formId')");

            } else if ("TblTenderEnvelope".equals(tblName) && isEnvelopeNotPublished) {
                query.delete(0, query.length());
                query.append("update TblTenderEnvelope set cstatus=$fieldvalues,openingDate='$tenderOpeningDt',$addlCols where envelopeId in ('$envelopeId')");

            } else if ("TblOfficerDocMapping".equals(tblName)) {
                query.delete(0, query.length());
                query.append("update TblOfficerDocMapping set cstatus=$fieldvalues,$addlCols where officerDocMappingId in ($officerDocMappingId)");

            }
//            Map<String, Map<String,Object>> params = new HashMap<String, Map<String,Object>>();
            
            for (int j = 0; j < lstCorrigendumDtls.size(); j++) {
                if (tblName.equals(lstCorrigendumDtls.get(j)[1])) {
                    if ("TblTender".equals(lstCorrigendumDtls.get(j)[1])) {
                        if ("openingDate".equals(lstCorrigendumDtls.get(j)[3])) {
                            isTenderEnvelope = true;
                            operFlag = true;
                            tenderOpeningDt = (String) lstCorrigendumDtls.get(j)[4];
                        }
                        param.append((String) lstCorrigendumDtls.get(j)[3]).append("=:").append((String) lstCorrigendumDtls.get(j)[3]).append(",");
                        
                        if((lstCorrigendumDtls.get(j)[3]).toString().equalsIgnoreCase("biddingVariant") && lstCorrigendumDtls.get(j)[4].toString().equals("2")) //19108 if variant is sell then rebate value will be 0.
                        {
                            param.append("isRebateForm").append("=:").append("isRebateForm").append(",");
                            tblTender.put("isRebateForm",0);
                        }
                        tblTender.put((String) lstCorrigendumDtls.get(j)[3],(String) lstCorrigendumDtls.get(j)[4]);
                    } else if ("TblTenderCurrency".equals(lstCorrigendumDtls.get(j)[1])) {
                        if ("cancel".equals(lstCorrigendumDtls.get(j)[2])) {
                            int indx = 0;
                            String regex = "[update TblTenderCurrency set isActive=2 where tenderCurrencyId in (]+['\\d',+]+?[)]+";
                            String tempHql = query.toString().replace("$fieldvalues", "2").replace("$tenderCurrencyId", regex);
                            for (int k = 0; k < lstQueries.size(); k++) {
                                if (lstQueries.get(k).toString().matches(regex)) {
                                    indx = k;
                                    break;
                                }
                            }
                            if (indx == 0) {
                                lstQueries.add(tempHql.replace(regex, String.valueOf(lstCorrigendumDtls.get(j)[0])));
                            } else {
                                tempHql = lstQueries.get(indx).toString().replace(")", ",'" + lstCorrigendumDtls.get(j)[0] + "')");
                                lstQueries.remove(indx);
                                lstQueries.add(indx, tempHql);
                            }
                        } else if ("insert".equals(lstCorrigendumDtls.get(j)[2])) {
                            int indx = 0;
                            String regex = "[update TblTenderCurrency set isActive=1 where tenderCurrencyId in (]+['\\d',+]+?[)]+";
                            String tempHql = query.toString().replace("$fieldvalues", "1").replace("$tenderCurrencyId", regex);

                            for (int k = 0; k < lstQueries.size(); k++) {
                                if (lstQueries.get(k).toString().matches(regex)) {
                                    indx = k;
                                    break;
                                }
                            }
                            if (indx == 0) {
                                lstQueries.add(tempHql.replace(regex, String.valueOf(lstCorrigendumDtls.get(j)[0])));
                            } else {
                                tempHql = lstQueries.get(indx).toString().replace(")", ",'" + lstCorrigendumDtls.get(j)[0] + "')");
                                lstQueries.remove(indx);
                                lstQueries.add(indx, tempHql);
                            }
                        }
                    } else if ("TblTenderForm".equals(lstCorrigendumDtls.get(j)[1])) {
                        String addiCols = null;
                        if ("cancel".equals(lstCorrigendumDtls.get(j)[2])) {
                            int indx = 0;
                            addiCols = "cancelledOn='" + currentDt + "',cancelledBy=" + objectId[2];
                            String regex = "[update TblTenderForm set cstatus=2,]+[cancelledOn=['\\d{4}\\-\\d{2}\\-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\.\\d{3}'],cancelledBy=[\\d] where formId in (]+['\\d',+]+?[)]+";
                            String tempHql = query.toString().replace("$fieldvalues", "2").replace("$addlCols", addiCols).replace("$formId", regex);
                            for (int k = 0; k < lstQueries.size(); k++) {
                                if (lstQueries.get(k).toString().matches(regex)) {
                                    indx = k;
                                    break;
                                }
                            }
                            if (indx == 0) {
                                lstQueries.add(tempHql.replace(regex, String.valueOf(lstCorrigendumDtls.get(j)[0])));
                            } else {
                                tempHql = lstQueries.get(indx).toString().replace(")", ",'" + lstCorrigendumDtls.get(j)[0] + "')");
                                lstQueries.remove(indx);
                                lstQueries.add(indx, tempHql);
                            }
                            whereCondGovCol.add(String.valueOf(lstCorrigendumDtls.get(j)[0]));
                        } else if ("insert".equals(lstCorrigendumDtls.get(j)[2])  && isEnvelopeNotPublished) {
                            int indx = 0;
                            addiCols = "publishedOn='" + currentDt + "',publishedBy=" + objectId[2];
                            String regex = "[update TblTenderForm set cstatus=1,]+[publishedOn=['\\d{4}\\-\\d{2}\\-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\.\\d{3}'],publishedBy=[\\d] where formId in (]+['\\d',+]+?[)]+";
                            String tempHql = query.toString().replace("$fieldvalues", "1").replace("$addlCols", addiCols).replace("$formId", regex);
                            for (int k = 0; k < lstQueries.size(); k++) {
                                if (lstQueries.get(k).toString().matches(regex)) {
                                    indx = k;
                                    break;
                                }
                            }
                            if (indx == 0) {
                                lstQueries.add(tempHql.replace(regex, String.valueOf(lstCorrigendumDtls.get(j)[0])));
                            } else {
                                tempHql = lstQueries.get(indx).toString().replace(")", ",'" + lstCorrigendumDtls.get(j)[0] + "')");
                                lstQueries.remove(indx);
                                lstQueries.add(indx, tempHql);
                            }
                        }
                        if ("update".equals(lstCorrigendumDtls.get(j)[2]) ) {//configured from organize form.
                        //    System.out.println(lstCorrigendumDtls.get(j)[3]+" " + lstCorrigendumDtls.get(j)[4]);
                            addiCols = "tbltenderform."+lstCorrigendumDtls.get(j)[3]+"=" + lstCorrigendumDtls.get(j)[4];
                            String directQuery = "update TblTenderForm tbltenderform set $addlCols $whereCluse";
                            String whereCluse= " where tbltenderform.formId="+lstCorrigendumDtls.get(j)[0];
                            String tempHql = directQuery.toString().replace("$addlCols", addiCols).replace("$whereCluse", whereCluse);
                            lstQueries.add(tempHql);
                     	}
                    } else if ("TblTenderEnvelope".equals(lstCorrigendumDtls.get(j)[1]) && isEnvelopeNotPublished) {
                    	if ("update".equals(lstCorrigendumDtls.get(j)[2]) ) {//configured from organize form.
                            String addiCols = "tbltenderenvelope."+lstCorrigendumDtls.get(j)[3]+"=" + lstCorrigendumDtls.get(j)[4];
                            String directQuery = "update TblTenderEnvelope tbltenderenvelope set $addlCols $whereCluse";
                            String whereCluse= " where tbltenderenvelope.envelopeId="+lstCorrigendumDtls.get(j)[0];
                            String tempHql = directQuery.toString().replace("$addlCols", addiCols).replace("$whereCluse", whereCluse);
                            lstQueries.add(tempHql);
                    	}
                    	if(!operFlag){
	                        isTenderEnvelope = true;
	                        operFlag = true;
                    	}
                    } else if ("TblOfficerDocMapping".equals(lstCorrigendumDtls.get(j)[1])) {
                        String addiCols = null;
                        if ("cancel".equals(lstCorrigendumDtls.get(j)[2])) {
                            int indx = 0;
                            addiCols = "";
                            String regex = "[update TblOfficerDocMapping set cstatus=2] where officerDocMappingId in (]+['\\d',+]+?[)]+";
                            String tempHql = query.toString().replace("$officerDocMappingId", ""+lstCorrigendumDtls.get(j)[0]+"").replace(",$addlCols", addiCols).replace("$fieldvalues", "2");
                            lstQueries.add(tempHql.replace(regex, String.valueOf(lstCorrigendumDtls.get(j)[0])));
                            whereCondGovCol.add(String.valueOf(lstCorrigendumDtls.get(j)[0]));
                            lstQueries.add("update TblCorrigendumDetail set oldValue='-',newValue='Reject' where objectId="+lstCorrigendumDtls.get(j)[0]+" and oldValue='Pending' and corrigendumId="+objectId[1]);
                        } else if ("insert".equals(lstCorrigendumDtls.get(j)[2])) {
                            int indx = 0;
                            addiCols = "approvedOn='" + currentDt + "',approvedBy=" + objectId[2];
                            String regex = "[update TblOfficerDocMapping set cstatus=1,]+[approvedOn=['\\d{4}\\-\\d{2}\\-\\d{2}\\s\\d{2}:\\d{2}:\\d{2}\\.\\d{3}'],approvedBy=[\\d] where officerDocMappingId in (]+['\\d',+]+?[)]+";
                            String tempHql = query.toString().replace("$officerDocMappingId", ""+lstCorrigendumDtls.get(j)[0]+"").replace("$addlCols", addiCols).replace("$fieldvalues", "1");
                            lstQueries.add(tempHql.replace(regex, String.valueOf(lstCorrigendumDtls.get(j)[0])));
                            lstQueries.add("update TblCorrigendumDetail set oldValue='-',newValue='Approved' where objectId="+lstCorrigendumDtls.get(j)[0]+" and oldValue='Pending' and corrigendumId="+objectId[1]);
                        }
                        if ("update".equals(lstCorrigendumDtls.get(j)[2]) ) {//configured from organize form.
//                            System.out.println(lstCorrigendumDtls.get(j)[3]+" " + lstCorrigendumDtls.get(j)[4]);
                        	if(lstCorrigendumDtls.get(j)[3].equals("ApproveNoticeDocument")){
                        		addiCols = "approvedOn='" + currentDt + "',approvedBy=" + objectId[2];
                        		query=new StringBuilder(query.toString().replace("$fieldvalues", "1"));
                        	}
                        	else{
                        		addiCols = "cancelledOn='" + lstCorrigendumDtls.get(j)[6] + "',cancelledBy=" + lstCorrigendumDtls.get(j)[5];
                        		query=new StringBuilder(query.toString().replace("$fieldvalues", "3"));
                        	}
                            String tempHql = query.toString().replace("$officerDocMappingId", ""+lstCorrigendumDtls.get(j)[0]+"").replace("$addlCols", addiCols);
                            lstQueries.add(tempHql);
                     	}
                    }
                }

                if (isTenderEnvelope) {
                    isTenderEnvelope = false;
                    StringBuilder tndrEnvelop = new StringBuilder();
                    tndrEnvelop.append("update TblTenderEnvelope set ");
                    if (envelopeType == 1) {
                        tndrEnvelop.append("openingDate = '").append(tenderOpeningDt).append("',")
                        /* Comment to Resolve Issue #38926*/
//                        	.append(" openingDatePublishedOn = case when openingDate <> '").append(tenderOpeningDt).append("' then '").append(currentDt).append("' when openingDatePublishedOn IS NULL then '").append(currentDt).append("' when openingDatePublishedOn IS NOT NULL then openingDatePublishedOn else null end,")
//                        	.append(" openingDatePublishedBy = case when openingDate <> '").append(tenderOpeningDt).append("' then '").append(objectId[2]).append("' when openingDatePublishedBy = 0 then ").append(objectId[2]).append(" when openingDatePublishedBy != 0 then openingDatePublishedBy else 0 end,")
//                        	.append(" openingDateStatus = 1, ")
//                        	.append(" publishedBy = case when cstatus = 4 then ").append(objectId[2]).append(" else publishedBy end,")
//                        	.append(" publishedOn = case when cstatus = 4 then '").append(currentDt).append("' else publishedOn end,")
   						/* Comment to Resolve Issue #38926*/
                        	.append(" remark = case when cstatus = 4 then '").append(remark).append("' else remark end,")
                        	.append(" cstatus = case when cstatus = 4 then 1 else cstatus end");
                    } else {
                        tndrEnvelop.append("openingDate = case when sortOrder = 1 then '").append(tenderOpeningDt).append("' else null end,")
                           		/* Comment to Resolve Issue #38926*/
//                        		.append(" openingDatePublishedOn = case when sortOrder = 1 and openingDate <> '").append(tenderOpeningDt).append("' then '").append(currentDt).append("' when sortOrder = 1 and openingDatePublishedOn IS NULL then '").append(currentDt).append("' when sortOrder = 1 and openingDatePublishedOn IS NOT NULL then openingDatePublishedOn else null end,")
//                              .append(" openingDatePublishedBy = case when sortOrder = 1 and openingDate <> '").append(tenderOpeningDt).append("' then '").append(objectId[2]).append("' when sortOrder = 1 and openingDatePublishedBy = 0 then ").append(objectId[2]).append(" when sortOrder = 1 and openingDatePublishedBy != 0 then openingDatePublishedBy else 0 end,")
//                              .append(" openingDateStatus = case when sortOrder = 1 then 1 else 0 end, ");
//                        		.append(" publishedBy = case when cstatus = 4 then ").append(objectId[2]).append(" else publishedBy end,")
//                        		.append(" publishedOn = case when cstatus = 4 then '").append(currentDt).append("' else publishedOn end,")
  								 /* Comment to Resolve Issue #38926*/
                        		.append(" remark = case when cstatus = 4 then '").append(remark).append("' else remark end,")
                        		.append(" cstatus = case when cstatus = 4 then 1 else cstatus end");
                    }
                    tndrEnvelop.append(" where tblTender.tenderId=").append(objectId[0]);
                    lstQueries.add(tndrEnvelop.toString());
                }
                if (j == (lstCorrigendumDtls.size() - 1)) {
                    if (param.length() != 0) {
                        String finalHqlQuery = query.toString().replace("$fieldvalues", param.replace(param.lastIndexOf(","), param.lastIndexOf(",") + 1, "")).replace("$tenderId", String.valueOf(objectId[0]));
                        param.delete(0, param.length());
                        lstQueries.add(finalHqlQuery);
                    }
                }
            }
        }
        if(whereCondGovCol.size() > 0){
        	StringBuffer tempHqlGovCol = new StringBuffer();
        	tempHqlGovCol.append("Delete FROM TblTenderGovColumn tblTenderGovColumn WHERE tblTenderGovColumn.tblTenderForm.formId in (");
        	for(String val :whereCondGovCol){
        		tempHqlGovCol.append(val).append(",");
        	}
        	tempHqlGovCol.deleteCharAt(tempHqlGovCol.lastIndexOf(","));
        	tempHqlGovCol.append(")");
        	lstQueries.add(tempHqlGovCol.toString());
        }
        
        if(tblTender!=null)
        {
        	if(!tblTender.isEmpty() && tblTender.size()>0)
            {
            	queryParameter.put("tblTender",tblTender);	
            }	
        }
        
        return lstQueries;
    }

    /**
     * @author urja
     * @param tenderId
     * @param corrigendumId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/uploadcorrigendumdoc/{tenderId}/{corrigendumId}/{enc}", method = RequestMethod.GET)
    public String corrigendumUploadDocument(@PathVariable("tenderId") int tenderId, @PathVariable("corrigendumId") int corrigendumId, ModelMap modelMap, HttpServletRequest request) {
        try {
            int clientId = abcUtility.getSessionClientId(request);
            tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(59, clientId);
            int allowedSize = 0;
            StringBuilder allowedExt = new StringBuilder();
            if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
                allowedSize = lstDocUploadConf.get(0).getMaxSize();
                allowedExt.append(lstDocUploadConf.get(0).getType());
                modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
            }
            int index = allowedExt.toString().indexOf(",");
            allowedExt.insert(index + 1, "*.");
            while (index >= 0) {
                index = allowedExt.toString().indexOf(",", index + ",".length());
                allowedExt.insert(index + 1, "*.");
            }

            modelMap.addAttribute("allowedExt", allowedExt);
            modelMap.addAttribute("allowedSize", allowedSize / 1024);
            modelMap.addAttribute("linkId", corrigendumUpload);
            modelMap.addAttribute("objectId", corrigendumId);
            modelMap.addAttribute("cStatusDoc", 0);         
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumUpload, uploadcorrigendum, tenderId, 0);
        }
        return "/etender/buyer/UploadCorrigendumTenderDocuments";
    }

    @RequestMapping(value = "/buyer/deletecorrigendum/{tenderId}/{corrigendumId}/{enc}", method = RequestMethod.GET)
    public String deletecorrigendum(@PathVariable("tenderId") int tenderId,@PathVariable("corrigendumId") int corrigendumId, ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        boolean delCheck=false;
        try{
        	TblCorrigendum tblCorrigendum = tenderCorrigendumService.getCorrigendumByCorrigendumId(corrigendumId).get(0);
        	//delCheck=tenderCorrigendumService.revertNoticeDocumentsChanges(tblCorrigendum);
        	if (tenderCorrigendumService.deletePendingCorrigendum(tenderId)) {
				List<Integer> lstEnvelopeId = eventCreationService.getEnvelopeIdList(tenderId);
        		for (int i = 0; i < lstEnvelopeId.size(); i++) {
                	eventCreationService.updateEnvelopeSortOrder(lstEnvelopeId.get(i), tenderId, i + 1);
                }
//        		tenderCorrigendumService.revertNoticeDocumentsChanges(tblCorrigendum);
            }else{
            	String msg = CommonKeywords.ERROR_MSG.toString();
            	List<TblCorrigendum> tblCorrigendumList = tenderCorrigendumService.getCorrigendumByCorrigendumId(corrigendumId) ;
            	if(tblCorrigendumList!=null && !tblCorrigendumList.isEmpty()){
            		tblCorrigendum = tblCorrigendumList.get(0);
            		if(tblCorrigendum.getCstatus()==1){
            			msg = "msg_corrigendum_already_published";
            		}
            	}else{
            		msg = "msg_corrigendum_already_deleted";
            	}
            	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), msg);
            }
        	retVal = "redirect:/etender/buyer/tenderdashboard/" + tenderId + "/4" + encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderId + "/4", request);
        }catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
        	if(delCheck)
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumDelete, deletepreparecorrigendum, tenderId, 0);
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), corrigendumDelete, deletecorrigendum, tenderId, 0);
        }
        return retVal;
    }
        /**
     * 
     * @param tenderDtBean
     * @param request
     * @param bindingResult
     * @param configParam1
     * @param tenderId
     * @throws Exception 
     */
    public void customValidation(TenderDtBean tenderDtBean, BindingResult bindingResult, Map<String, Object> configParam1,int tenderId) throws Exception {

        final String txtDocStartDate = "txtDocumentStartDate";
        final String txtDocEndDate = "txtDocumentEndDate";
        final String txtSubmissionStartDate = "txtSubmissionStartDate";
        final String txtSubmissionEndDate = "txtSubmissionEndDate";
        final String txtBidOpenDate = "txtBidOpenDate";
        final String txtPreBidStartDate = "txtPreBidStartDate";
        final String txtPreBidEndDate = "txtPreBidEndDate";
        final String txtQuestionAnswerStartDate = "txtQuestionAnswerStartDate";
        final String txtQuestionAnswerEndDate = "txtQuestionAnswerEndDate";
         if (tenderId > 0) {
            List<TblTender> oriTender = tblTenderDao.findTblTender("tenderId", Operation_enum.EQ, tenderId);

            if (oriTender != null && !oriTender.isEmpty()) {
            if (configParam1.containsKey("documentEndDate")) {
                if (oriTender.get(0).getDocumentEndDate() != null && !oriTender.get(0).getDocumentEndDate() .equals("")) {
                    int compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtDocumentEndDate(), Date.class), conversionService.convert(oriTender.get(0).getDocumentEndDate() , Date.class));
                    if (compareValue != 0) {
                        commonValidators.isNotBlank(tenderDtBean.getTxtDocumentEndDate(), txtDocEndDate, bindingResult);
                        if (tenderDtBean.getTxtDocumentStartDate() != null && !("").equals(tenderDtBean.getTxtDocumentStartDate())) {
                            compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtDocumentStartDate(), Date.class), conversionService.convert(tenderDtBean.getTxtDocumentEndDate(), Date.class));
                            if (compareValue > 0) {
                                bindingResult.rejectValue(txtDocEndDate, "msg_doc_download_enddate_grater_startdate");
                            }
                        }
                        if (!bindingResult.hasFieldErrors(txtDocEndDate)) {
                            compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class), conversionService.convert(tenderDtBean.getTxtDocumentEndDate(), Date.class));
                            if (compareValue < 0) {
                                bindingResult.rejectValue(txtDocEndDate, "msg_doc_download_enddate_le_submissionenddate");
                            }
                        }
                    }
                }
            }
            if (oriTender.get(0).getSubmissionEndDate()!= null && !oriTender.get(0).getSubmissionEndDate().equals("")) {
                int compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class), conversionService.convert(oriTender.get(0).getSubmissionEndDate(), Date.class));
                if (compareValue != 0) {
                    commonValidators.isNotBlank(tenderDtBean.getTxtSubmissionEndDate(), txtSubmissionEndDate, bindingResult);
                    if (!bindingResult.hasFieldErrors(txtSubmissionEndDate)) {
                    	if (tenderDtBean.getTxtSubmissionStartDate() != null  && !("").equals(tenderDtBean.getTxtSubmissionStartDate())) {
                            compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtSubmissionStartDate(), Date.class), conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class));
                            if (compareValue > 0) {
                                bindingResult.rejectValue(txtSubmissionEndDate, "msg_submission_enddate_gt_startdate");
                                if (!bindingResult.hasFieldErrors(txtSubmissionEndDate)) {
                                    compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class), conversionService.convert(tenderDtBean.getTxtDocumentEndDate(), Date.class));
                                    if (compareValue < 0 || compareValue == 0) {
                                        bindingResult.rejectValue(txtSubmissionEndDate, "msg_submission_enddate_gt_docdownload_enddate");
                                    }
                                }
                            }

                        }
                    }
                }
            }
            if (oriTender.get(0).getOpeningDate() != null && !oriTender.get(0).getOpeningDate().equals("")) {
                int compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtBidOpenDate(), Date.class), conversionService.convert(oriTender.get(0).getOpeningDate(), Date.class));
                if (compareValue != 0) {
                    if (!bindingResult.hasFieldErrors(txtBidOpenDate)) {
                        commonValidators.isNotBlank(tenderDtBean.getTxtBidOpenDate(), txtBidOpenDate, bindingResult);
                        if (tenderDtBean.getTxtSubmissionEndDate() != null && !"".equals(tenderDtBean.getTxtSubmissionEndDate()) && !bindingResult.hasFieldErrors(txtBidOpenDate)) {
                            int compVal = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class), conversionService.convert(tenderDtBean.getTxtBidOpenDate(), Date.class));
                            if (compVal > 0 || compVal == 0) {
                                bindingResult.rejectValue(txtBidOpenDate, "bidopendate_ge_bidsubmissiondate");
                            } else {
                                compVal = commonValidators.compareTwoDate(conversionService.convert(oriTender.get(0).getOpeningDate(), Date.class), conversionService.convert(tenderDtBean.getTxtBidOpenDate(), Date.class));
                                if (oriTender.get(0).getIsPastEvent() != 1 && compVal > 0) {
                                    bindingResult.rejectValue(txtBidOpenDate, "bidopendate_ge_bidopendate");
                                }
                            }

                        }
                    }
                }
            }

            if (tenderDtBean.getSelIsPreBidMeeting() == 1) {
                if (oriTender.get(0).getPreBidStartDate()!= null && !oriTender.get(0).getPreBidStartDate().equals("")) {
                    int compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtPreBidStartDate(), Date.class), conversionService.convert(oriTender.get(0).getPreBidStartDate(), Date.class));
                    if (compareValue != 0) {
                        if (!bindingResult.hasFieldErrors(txtPreBidStartDate)) {
                            commonValidators.isNotBlank(tenderDtBean.getTxtPreBidStartDate(), txtPreBidStartDate, bindingResult);
                            if (!bindingResult.hasFieldErrors(txtPreBidStartDate)) {
                                if (tenderDtBean.getIsPastEvent() == 0) {
                                    compareValue = commonValidators.compareWithSystemDate(conversionService.convert(tenderDtBean.getTxtPreBidStartDate(), Date.class));
                                    if (compareValue > 0) {
                                        bindingResult.rejectValue(txtPreBidStartDate, "msg_prebid_meeting_startdate_gt_sysdate");

                                    }
                                }
                                if (tenderDtBean.getTxtPreBidEndDate() != null && !"".equals(tenderDtBean.getTxtPreBidEndDate()) && !bindingResult.hasFieldErrors(txtPreBidStartDate)) {
                                    compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtPreBidStartDate(), Date.class), conversionService.convert(tenderDtBean.getTxtPreBidEndDate(), Date.class));
                                    if (compareValue > 0) {
                                        bindingResult.rejectValue(txtPreBidStartDate, "msg_prebidmeeting_satrtdate_lt_bidsubmission_enddate");
                                    }
                                }

                            }
                        }
                    }
                }
                if (oriTender.get(0).getPreBidEndDate() != null && !oriTender.get(0).getPreBidEndDate().equals("")) {
                    int compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtPreBidEndDate(), Date.class), conversionService.convert(oriTender.get(0).getPreBidEndDate(), Date.class));
                    if (compareValue != 0) {
                        if (!bindingResult.hasFieldErrors(txtPreBidEndDate)) {
                            commonValidators.isNotBlank(tenderDtBean.getTxtPreBidEndDate(), txtPreBidEndDate, bindingResult);
                            if (tenderDtBean.getTxtPreBidStartDate() != null && !"".equals(tenderDtBean.getTxtPreBidStartDate()) && !bindingResult.hasFieldErrors(txtPreBidEndDate)) {
                                int compVal = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtPreBidStartDate(), Date.class), conversionService.convert(tenderDtBean.getTxtPreBidEndDate(), Date.class));
                                if (compVal > 0) {
                                    bindingResult.rejectValue(txtPreBidEndDate, "msg_prebid_meeting_date_gt_prebid_meeting_startdate");
                                    if (tenderDtBean.getTxtSubmissionEndDate() != null && !"".equals(tenderDtBean.getTxtSubmissionEndDate()) && !bindingResult.hasFieldErrors(txtPreBidEndDate)) {
                                        compVal = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtPreBidEndDate(), Date.class), conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class));
                                        if (compVal > 0) {
                                            bindingResult.rejectValue(txtPreBidEndDate, "msg_prebid_meeting_enddate_lt_bidsubmission_enddate");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (tenderDtBean.getSelIsQuestionAnswer() == 1) {
                if (oriTender.get(0).getQuestionAnswerStartDate() != null && !oriTender.get(0).getQuestionAnswerStartDate().equals("")) {
                    int compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtQuestionAnswerStartDate(), Date.class), conversionService.convert(oriTender.get(0).getQuestionAnswerStartDate(), Date.class));
                    if (compareValue != 0) {
                        if (!bindingResult.hasFieldErrors(txtQuestionAnswerStartDate)) {
                            commonValidators.isNotBlank(tenderDtBean.getTxtQuestionAnswerStartDate(), txtQuestionAnswerStartDate, bindingResult);
                            if (!bindingResult.hasFieldErrors(txtQuestionAnswerStartDate)) {
                                if (tenderDtBean.getIsPastEvent() == 0) {
                                    compareValue = commonValidators.compareWithSystemDate(conversionService.convert(tenderDtBean.getTxtQuestionAnswerStartDate(), Date.class));
                                    if (compareValue > 0) {
                                        bindingResult.rejectValue(txtQuestionAnswerStartDate, "msg_queans_startdate_gt_currdate");

                                    }
                                }
                                if (tenderDtBean.getTxtSubmissionEndDate() != null && !"".equals(tenderDtBean.getTxtSubmissionEndDate()) && !bindingResult.hasFieldErrors(txtQuestionAnswerStartDate)) {
                                    compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtQuestionAnswerStartDate(), Date.class), conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class));
                                    if (compareValue > 0) { // if queStartDate less then submission end date then return -1,if it will return 1 then it is issue. 
                                        bindingResult.rejectValue(txtQuestionAnswerStartDate, "msg_queans_startdate_lt_bodsubmissionenddate");
                                    }
                                }
                            }

                        }
                    }
                }

                if (oriTender.get(0).getQuestionAnswerEndDate()!= null && !oriTender.get(0).getQuestionAnswerEndDate().equals("")) {
                    int compareValue = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtQuestionAnswerEndDate(), Date.class), conversionService.convert(oriTender.get(0).getQuestionAnswerEndDate(), Date.class));
                    if (compareValue != 0) {
                        if (!bindingResult.hasFieldErrors(txtQuestionAnswerEndDate)) {
                            commonValidators.isNotBlank(tenderDtBean.getTxtQuestionAnswerEndDate(), txtQuestionAnswerEndDate, bindingResult);
                            if (!bindingResult.hasFieldErrors(txtQuestionAnswerEndDate)) {
                                int compVal = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtQuestionAnswerStartDate(), Date.class), conversionService.convert(tenderDtBean.getTxtQuestionAnswerEndDate(), Date.class));
                                if (compVal > 0) {
                                    bindingResult.rejectValue(txtQuestionAnswerEndDate, "msg_submission_enddate_gt_startdate");
                                    if (tenderDtBean.getTxtSubmissionEndDate() != null && !"".equals(tenderDtBean.getTxtSubmissionEndDate()) && !bindingResult.hasFieldErrors(txtQuestionAnswerEndDate)) {
                                        compVal = commonValidators.compareTwoDate(conversionService.convert(tenderDtBean.getTxtQuestionAnswerEndDate(), Date.class), conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class));
                                        if (compVal > 0) {// if queStartDate less then submission end date then return -1,if it will return 1 then it is issue.
                                            bindingResult.rejectValue(txtQuestionAnswerEndDate, "msg_submission_enddate_gt_docdownload_enddate");
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
         }
       }
    }
      /**
     * 
     * @param tenderDtBean
     * @param request
     * @param userDetailId
     * @param labelMap
     * @return
     * @throws Exception 
     */
    public boolean prepareCorrigendumData(TenderDtBean tenderDtBean,int corrigendumId,int objectId,String[] lst,String currIdList,String currencyId,int envelopeType, int userDetailId, Map<String, Object> labelMap) throws Exception {
       
        String newValue = "";
        String oldValue = "";
        List<TblCorrigendumDetail> tblCorrigendumDetails = new ArrayList<TblCorrigendumDetail>();         
        
        if (objectId > 0) {
            List<TblTender> oriTender = tblTenderDao.findTblTender("tenderId", Operation_enum.EQ, objectId);
            int iAgree=tenderCorrigendumService.isIAgreeByTenderId(objectId);
            if (oriTender != null && !oriTender.isEmpty()) {
                if (labelMap.get("validityPeriod") != null) {
                    if ((!tenderDtBean.getTxtValidityPeriod().equals("") && !tenderDtBean.getTxtValidityPeriod().equals(0))) {
                        if (!tenderDtBean.getTxtValidityPeriod().equals(oriTender.get(0).getValidityPeriod().toString())) {
                            setCorrigendumDetailBean("validityPeriod", labelMap.get("validityPeriod").toString(), oriTender.get(0).getValidityPeriod().toString(), tenderDtBean.getTxtValidityPeriod(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                    }
                }
                if (labelMap.get("procurementNatureId") != null) {
                    if (tenderDtBean.getSelProcurementNatureId() != oriTender.get(0).getTblProcurementNature().getProcurementNatureId()) {
                        setCorrigendumDetailBean("procurementNatureId", labelMap.get("procurementNatureId").toString(), String.valueOf(oriTender.get(0).getTblProcurementNature().getProcurementNatureId()), String.valueOf(tenderDtBean.getSelProcurementNatureId()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                    if(tenderDtBean.getSelProcurementNatureId()==5){
                         if (!tenderDtBean.getTxtOtherProcNature().equals(oriTender.get(0).getOtherProcurementNature())) {
                                setCorrigendumDetailBean("otherProcurementNature",getTenderFieldLabel("field_otherProcurementNature"), oriTender.get(0).getOtherProcurementNature(), tenderDtBean.getTxtOtherProcNature() ,userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                         }
                      }
                }
                if (labelMap.get("projectDuration") != null) {
                    if (!tenderDtBean.getTxtProjectDuration().equals("") && !tenderDtBean.getTxtProjectDuration().equals(0)) {
                        if (!tenderDtBean.getTxtProjectDuration().equals(oriTender.get(0).getProjectDuration().toString())) {
                            setCorrigendumDetailBean("projectDuration", labelMap.get("projectDuration").toString(), oriTender.get(0).getProjectDuration().toString(), tenderDtBean.getTxtProjectDuration(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                    }
                }
                if (labelMap.get("downloadDocument") != null) {
                    if(oriTender.get(0).getDownloadDocument()!=3){
                        if (tenderDtBean.getSelDownloadDocument() != oriTender.get(0).getDownloadDocument()) {

                            if (tenderDtBean.getSelDownloadDocument() == 1) {
                                newValue = "label_beforelogin::1";
                            } else if (tenderDtBean.getSelDownloadDocument() == 2) {
                                newValue = "label_afterlogin::2";
                            } else {
                                newValue = "label_afterpayment::3";
                            }
                            if (oriTender.get(0).getDownloadDocument() == 1) {
                                oldValue = "label_beforelogin::1";
                            } else if (oriTender.get(0).getDownloadDocument() == 2) {
                                oldValue = "label_afterlogin::2";
                            } else {
                                oldValue = "label_afterpayment::3";
                            }
                            setCorrigendumDetailBean("downloadDocument", labelMap.get("downloadDocument").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                    }
                }
                if (labelMap.get("tenderValue") != null) {
                   if (!new BigDecimal(tenderDtBean.getTxtTenderValue()).setScale(5).toString().equals(oriTender.get(0).getTenderValue().toString())) {
                        setCorrigendumDetailBean("tenderValue", labelMap.get("tenderValue").toString(), oriTender.get(0).getTenderValue().toString(), tenderDtBean.getTxtTenderValue(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                
//   Change Request #17756             if (labelMap.get("decimalValueUpto") != null) {
//                    if (tenderDtBean.getSelDecimalValueUpto() != oriTender.get(0).getDecimalValueUpto()) {
//                        setCorrigendumDetailBean("decimalValueUpto", labelMap.get("decimalValueUpto").toString(), String.valueOf(oriTender.get(0).getDecimalValueUpto()), String.valueOf(tenderDtBean.getSelDecimalValueUpto()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
//                    }
//                }
                if (labelMap.get("isSplitPOAllowed") != null) {
                    if (!String.valueOf(tenderDtBean.getSelIsSplitPOAllowed()).equals(String.valueOf(oriTender.get(0).getIsSplitPOAllowed()))) {

                        if (tenderDtBean.getSelIsSplitPOAllowed() == 1) {
                            newValue = LABELALLOW;
                            oldValue =LABELDONTALLOW;
                        } else {
                            newValue = LABELDONTALLOW;
                            oldValue = LABELALLOW;
                        }
                        setCorrigendumDetailBean("isSplitPOAllowed", labelMap.get("isSplitPOAllowed").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (labelMap.get("isItemwiseWinner") != null) {
                    if (!String.valueOf(tenderDtBean.getSelIsItemwiseWinner()).equals(String.valueOf(oriTender.get(0).getIsItemwiseWinner()))) {
                        if (tenderDtBean.getSelIsItemwiseWinner() == 1) {
                            newValue = LABELALLOW;
                            oldValue = LABELDONTALLOW;
                        } else {
                            newValue = LABELDONTALLOW;
                            oldValue = LABELALLOW;
                        }
                        setCorrigendumDetailBean("isItemwiseWinner", labelMap.get("isItemwiseWinner").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (labelMap.get("tenderMode") != null && tenderDtBean.getSelTenderMode() != 0) {
                    if (!String.valueOf(tenderDtBean.getSelTenderMode()).equals(String.valueOf(oriTender.get(0).getTenderMode()))) {
                        if (tenderDtBean.getSelTenderMode() == 1) {
                            newValue = "label_open::1";
                        } else if (tenderDtBean.getSelTenderMode() == 2) {
                            newValue = "label_limited::2";

                        } else if (tenderDtBean.getSelTenderMode() == 3) {
                            newValue = "label_proprietary::3";

                        } else {
                            newValue = "label_Nomination::4";
                        }
                        if (oriTender.get(0).getTenderMode() == 1) {
                            oldValue = "label_open::1";
                        } else if (oriTender.get(0).getTenderMode() == 2) {
                            oldValue = "label_limited::2";

                        } else if (oriTender.get(0).getTenderMode() == 3) {
                            oldValue = "label_proprietary::3";

                        } else {
                            oldValue = "label_Nomination::4";
                        }
                        setCorrigendumDetailBean("tenderMode", labelMap.get("tenderMode").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }

                if (labelMap.get("isConsortiumAllowed") != null) {
                    //if (iAgree == 0) {
                        if (!String.valueOf(tenderDtBean.getSelIsConsortiumAllowed()).equals(String.valueOf(oriTender.get(0).getIsConsortiumAllowed()))) {
		                            if (tenderDtBean.getSelIsConsortiumAllowed() == 0) {
		                                newValue = LABELDONTALLOW;
		                                oldValue = LABELALLOW;
		                            } else {
		                                newValue = LABELALLOW;
		                                oldValue = LABELDONTALLOW;
		                            }
                            setCorrigendumDetailBean("isConsortiumAllowed", labelMap.get("isConsortiumAllowed").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                    //}
                }
                if (labelMap.get("isBidWithdrawal") != null) {
                    //if (iAgree == 0) { // CR:21343
                        if (!String.valueOf(tenderDtBean.getSelIsBidWithdrawal()).equals(String.valueOf(oriTender.get(0).getIsBidWithdrawal()))) {
                            if (tenderDtBean.getSelIsBidWithdrawal() == 0) {
                                newValue = LABELDONTALLOW;
                                oldValue = LABELALLOW;
                            } else {
                                newValue = LABELALLOW;
                                oldValue = LABELDONTALLOW;
                            }
                            setCorrigendumDetailBean("isBidWithdrawal", labelMap.get("isBidWithdrawal").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                    //}
                }
                if (labelMap.get("biddingVariant") != null) {
                    if (!String.valueOf(tenderDtBean.getSelBiddingVariant()).equals(String.valueOf(oriTender.get(0).getBiddingVariant()))) {
                        if (tenderDtBean.getSelBiddingVariant() == 1) {
                            newValue = "label_buy::1";
                            oldValue = "label_sell::2";
                        } else {
                            newValue = "label_sell::2";
                            oldValue = "label_buy::1";
                        }
                        setCorrigendumDetailBean("biddingVariant", labelMap.get("biddingVariant").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (labelMap.get("isPreBidMeeting") != null) {
                    if (!String.valueOf(tenderDtBean.getSelIsPreBidMeeting()).equals(String.valueOf(oriTender.get(0).getIsPreBidMeeting()))) {
                        if (tenderDtBean.getSelIsPreBidMeeting() == 0) {
                            newValue = LABELDONTALLOW;
                            oldValue = LABELALLOW;
                        } else {
                            newValue = LABELALLOW;
                            oldValue = LABELDONTALLOW;
                        }
                        setCorrigendumDetailBean("isPreBidMeeting", labelMap.get("isPreBidMeeting").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (labelMap.get("preBidMode") != null) {
                	if(oriTender.get(0).getIsPreBidMeeting()==0 && tenderDtBean.getSelIsPreBidMeeting()==1){
                		if (tenderDtBean.getSelPreBidMode() == 1) {
                			newValue = LABELONLINE;
                			oldValue = "-" ;
                		} else {
                			newValue = LABELOFFLINE;
                			oldValue ="-";
                		}
                		setCorrigendumDetailBean("preBidMode", labelMap.get("preBidMode").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                	}else{
                		if (!String.valueOf(tenderDtBean.getSelPreBidMode()).equals(String.valueOf(oriTender.get(0).getPreBidMode())) && tenderDtBean.getSelIsPreBidMeeting()!=0) {
                			if (tenderDtBean.getSelPreBidMode() == 1) {
                				newValue = LABELONLINE;
                				oldValue = LABELOFFLINE;
                			} else {
                				newValue = LABELOFFLINE;
                				oldValue =LABELONLINE;
                			}
                			setCorrigendumDetailBean("preBidMode", labelMap.get("preBidMode").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                		}
                	}	                	
                }
                if (labelMap.get("preBidAddress") != null) {
                	if(oriTender.get(0).getIsPreBidMeeting()!=0 && oriTender.get(0).getPreBidMode()==1 && tenderDtBean.getSelIsPreBidMeeting()==1 && tenderDtBean.getSelPreBidMode()==2){
                		oldValue = "";
                		setCorrigendumDetailBean("preBidAddress", labelMap.get("preBidAddress").toString(), oldValue, tenderDtBean.getTxtaPreBidAddress(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                	}else{
                		 if (!tenderDtBean.getTxtaPreBidAddress().equals(oriTender.get(0).getPreBidAddress()) && tenderDtBean.getSelIsPreBidMeeting()!=0 && tenderDtBean.getSelPreBidMode()==2) {
                             setCorrigendumDetailBean("preBidAddress", labelMap.get("preBidAddress").toString(), oriTender.get(0).getPreBidAddress(), tenderDtBean.getTxtaPreBidAddress(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);

                         }
                	}
                }
                if (labelMap.get("documentSubmission") != null) {
                    if (!tenderDtBean.getTxtaDocumentSubmission().equals(oriTender.get(0).getDocumentSubmission())) {
                        setCorrigendumDetailBean("documentSubmission", labelMap.get("documentSubmission").toString(), oriTender.get(0).getDocumentSubmission(), tenderDtBean.getTxtaDocumentSubmission(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
//                if (labelMap.get("isWorkflowRequired") != null) {
//                    if (!String.valueOf(tenderDtBean.getSelIsWorkflowRequired()).equals(String.valueOf(oriTender.get(0).getIsWorkflowRequired()))) {
//                        if (tenderDtBean.getSelIsWorkflowRequired() == 1) {
//                            newValue = "label_yes::1";
//                            oldValue = "label_no::0";
//                        } else {
//                            newValue = "label_no::0";
//                            oldValue = "label_yes::1";
//                        }
//                        setCorrigendumDetailBean("isWorkflowRequired", labelMap.get("isWorkflowRequired").toString(),oldValue,newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
//                    }
//                }
//                if (labelMap.get("workflowTypeId") != null) {
//                    if (!String.valueOf(tenderDtBean.getSelWorkflowType()).equals(String.valueOf(oriTender.get(0).getWorkflowTypeId()))) {
//                    	if (tenderDtBean.getSelWorkflowType() == 2) {
//                    		 newValue = "label_Financial_Limit_Base::2";
//                    	}else if(tenderDtBean.getSelWorkflowType() == 3){
//                    		 newValue = "label_Any_to_Any::3";
//                    	}else if(tenderDtBean.getSelWorkflowType() == 4){
//                    		 newValue = "label_Hierarchy_Base::4";
//                    	}else if(tenderDtBean.getSelWorkflowType() == 5){
//                    		newValue = "label_Financial_Limit_Base_And_Hierarchy_Base::5";
//                    	}
//                    	if (oriTender.get(0).getWorkflowTypeId() == 2) {
//                    		oldValue = "label_Financial_Limit_Base::2";
//	                   	}else if(oriTender.get(0).getWorkflowTypeId() == 3){
//	                   		oldValue = "label_Any_to_Any::3";
//	                   	}else if(oriTender.get(0).getWorkflowTypeId() == 4){
//	                   		oldValue = "label_Hierarchy_Base::4";
//	                   	}else if(tenderDtBean.getSelWorkflowType() == 5){
//                    		newValue = "label_Financial_Limit_Base_And_Hierarchy_Base::5";
//                    	}
//                    	setCorrigendumDetailBean("workflowTypeId", labelMap.get("workflowTypeId").toString(),oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
//                    }
//                }
                if (labelMap.get("isQuestionAnswer") != null) {
                    if (!String.valueOf(tenderDtBean.getSelIsQuestionAnswer()).equals(String.valueOf(oriTender.get(0).getIsQuestionAnswer()))) {
                        if (tenderDtBean.getSelIsQuestionAnswer() == 1) {
                            newValue = "label_yes::1";
                            oldValue = "label_no::0";
                        } else {
                            newValue = "label_no::0";
                            oldValue = "label_yes::1";
                        }
                        setCorrigendumDetailBean("isQuestionAnswer", labelMap.get("isQuestionAnswer").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
               
                if (labelMap.get("documentEndDate") != null) {
                    if (!tenderDtBean.getTxtDocumentEndDate().equals("")) {
                        if (!conversionService.convert(tenderDtBean.getTxtDocumentEndDate(), Date.class).equals(oriTender.get(0).getDocumentEndDate())) {
                            if(oriTender.get(0).getDocumentEndDate()==null){
                                setCorrigendumDetailBean("documentEndDate", labelMap.get("documentEndDate").toString(), "", CommonUtility.convertUtcTimezone(tenderDtBean.getTxtDocumentEndDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                            }
                            else{
                                setCorrigendumDetailBean("documentEndDate", labelMap.get("documentEndDate").toString(), oriTender.get(0).getDocumentEndDate().toString(), CommonUtility.convertUtcTimezone(tenderDtBean.getTxtDocumentEndDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                            }
                         }
                    }
                }
               
                if (!tenderDtBean.getTxtSubmissionEndDate().equals("")) {
                    if (!conversionService.convert(tenderDtBean.getTxtSubmissionEndDate(), Date.class).equals(oriTender.get(0).getSubmissionEndDate())) {
                         if(oriTender.get(0).getSubmissionEndDate()==null){
                            setCorrigendumDetailBean("submissionEndDate", getTenderFieldLabel("field_bidsubmissionenddate"),"", CommonUtility.convertUtcTimezone(tenderDtBean.getTxtSubmissionEndDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                         }
                         else{
                             setCorrigendumDetailBean("submissionEndDate", getTenderFieldLabel("field_bidsubmissionenddate"), oriTender.get(0).getSubmissionEndDate().toString(), CommonUtility.convertUtcTimezone(tenderDtBean.getTxtSubmissionEndDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                         }
                    }
                }
                if (labelMap.get("isPreBidMeeting") != null && tenderDtBean.getSelIsPreBidMeeting() == 1) {
                    if (!tenderDtBean.getTxtPreBidStartDate().equals("")) {
                        if (!conversionService.convert(tenderDtBean.getTxtPreBidStartDate(), Date.class).equals(oriTender.get(0).getPreBidStartDate())) {
                             if(oriTender.get(0).getPreBidStartDate()==null){
                                setCorrigendumDetailBean("preBidStartDate", getTenderFieldLabel("fields_prebidmeet_startdate"), "", CommonUtility.convertUtcTimezone(tenderDtBean.getTxtPreBidStartDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                             }
                             else{
                                 setCorrigendumDetailBean("preBidStartDate", getTenderFieldLabel("fields_prebidmeet_startdate"), oriTender.get(0).getPreBidStartDate().toString(), CommonUtility.convertUtcTimezone(tenderDtBean.getTxtPreBidStartDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                             }
                        }
                    }
                }
                if (labelMap.get("isPreBidMeeting") != null && tenderDtBean.getSelIsPreBidMeeting() == 1) {
                    if (!tenderDtBean.getTxtPreBidEndDate().equals("")) {
                        if (!conversionService.convert(tenderDtBean.getTxtPreBidEndDate(), Date.class).equals(oriTender.get(0).getPreBidEndDate())) {
                             if(oriTender.get(0).getPreBidEndDate()==null){
                                setCorrigendumDetailBean("preBidEndDate", getTenderFieldLabel("fields_prebidmeet_enddate"), "", CommonUtility.convertUtcTimezone(tenderDtBean.getTxtPreBidEndDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                             }
                             else{
                                 setCorrigendumDetailBean("preBidEndDate", getTenderFieldLabel("fields_prebidmeet_enddate"), oriTender.get(0).getPreBidEndDate().toString(), CommonUtility.convertUtcTimezone(tenderDtBean.getTxtPreBidEndDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                             }
                        }
                    }
                }
                if (tenderDtBean.getTxtEmdSubmissionEndDate() != null) {
                    if (!conversionService.convert(tenderDtBean.getTxtEmdSubmissionEndDate(), Date.class).equals(oriTender.get(0).getEmdSubmissionEndDate())) {
                         if(oriTender.get(0).getEmdSubmissionEndDate()==null){
                            setCorrigendumDetailBean("emdSubmissionEndDate", getTenderFieldLabel("lbl_emd_end_datetime"),"", CommonUtility.convertUtcTimezone(tenderDtBean.getTxtEmdSubmissionEndDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                         }
                         else{
                             setCorrigendumDetailBean("emdSubmissionEndDate", getTenderFieldLabel("lbl_emd_end_datetime"), oriTender.get(0).getEmdSubmissionEndDate().toString(), CommonUtility.convertUtcTimezone(tenderDtBean.getTxtEmdSubmissionEndDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                         }
                    }
                }
                if (!tenderDtBean.getTxtBidOpenDate().equals("")) {
                    if (!conversionService.convert(tenderDtBean.getTxtBidOpenDate(), Date.class).equals(oriTender.get(0).getOpeningDate())) {
                          if(oriTender.get(0).getOpeningDate()==null){
                            setCorrigendumDetailBean("openingDate", getTenderFieldLabel("field_bidopeningstartdate"), "", CommonUtility.convertUtcTimezone(tenderDtBean.getTxtBidOpenDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                          }
                          else{
                              setCorrigendumDetailBean("openingDate", getTenderFieldLabel("field_bidopeningstartdate"), oriTender.get(0).getOpeningDate().toString(), CommonUtility.convertUtcTimezone(tenderDtBean.getTxtBidOpenDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                          }
                    }
                }
                if (labelMap.get("isQuestionAnswer") != null && tenderDtBean.getSelIsQuestionAnswer() == 1) {
                    if (!tenderDtBean.getTxtQuestionAnswerStartDate().equals("")) {
                        if (!conversionService.convert(tenderDtBean.getTxtQuestionAnswerStartDate(), Date.class).equals(oriTender.get(0).getQuestionAnswerStartDate())) {
                            if(oriTender.get(0).getQuestionAnswerStartDate()==null){
                                setCorrigendumDetailBean("questionAnswerStartDate", getTenderFieldLabel("field_queans_startdate"), "", CommonUtility.convertUtcTimezone(tenderDtBean.getTxtQuestionAnswerStartDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                            }
                            else{
                                setCorrigendumDetailBean("questionAnswerStartDate", getTenderFieldLabel("field_queans_startdate"), oriTender.get(0).getQuestionAnswerStartDate().toString(), CommonUtility.convertUtcTimezone(tenderDtBean.getTxtQuestionAnswerStartDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                            }
                        }
                    }
                }
                if (labelMap.get("isQuestionAnswer") != null && tenderDtBean.getSelIsQuestionAnswer() == 1) {
                    if (!tenderDtBean.getTxtQuestionAnswerEndDate().equals("")) {
                        if (!conversionService.convert(tenderDtBean.getTxtQuestionAnswerEndDate(), Date.class).equals(oriTender.get(0).getQuestionAnswerEndDate())) {
                           if(oriTender.get(0).getQuestionAnswerEndDate()==null){
                                setCorrigendumDetailBean("questionAnswerEndDate", getTenderFieldLabel("field_queans_enddate"), "", CommonUtility.convertUtcTimezone(tenderDtBean.getTxtQuestionAnswerEndDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                           }
                           else{
                               setCorrigendumDetailBean("questionAnswerEndDate", getTenderFieldLabel("field_queans_enddate"), oriTender.get(0).getQuestionAnswerEndDate().toString(), CommonUtility.convertUtcTimezone(tenderDtBean.getTxtQuestionAnswerEndDate()), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                           }
                        }
                    }
                }
                if (labelMap.get("isDocfeesApplicable") != null) {
                    if (!String.valueOf(tenderDtBean.getSelIsDocfeesApplicable()).equals(String.valueOf(oriTender.get(0).getIsDocfeesApplicable()))) {
                    	newValue=tenderDtBean.getSelIsDocfeesApplicable()==1?LABELEVENTWISE:tenderDtBean.getSelIsDocfeesApplicable()==2?LABELITEMWISE:LABELNOTREQUIRED;
                    	oldValue=oriTender.get(0).getIsDocfeesApplicable()==1?LABELEVENTWISE:oriTender.get(0).getIsDocfeesApplicable()==2?LABELITEMWISE:LABELNOTREQUIRED;
                        setCorrigendumDetailBean("isDocfeesApplicable", labelMap.get("isDocfeesApplicable").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (tenderDtBean.getSelIsDocfeesApplicable() == 1 || tenderDtBean.getSelIsDocfeesApplicable() == 2) {
                    if (labelMap.get("docFeePaymentMode") != null) {
                        if (!String.valueOf(tenderDtBean.getSelDocFeePaymentMode()).equals(String.valueOf(oriTender.get(0).getDocFeePaymentMode()))) {
                        	newValue=tenderDtBean.getSelDocFeePaymentMode()==1?LABELONLINE:tenderDtBean.getSelDocFeePaymentMode()==2?LABELOFFLINE:tenderDtBean.getSelDocFeePaymentMode()==3?LABELBOTH:"-";
                        	oldValue=oriTender.get(0).getDocFeePaymentMode()==1?LABELONLINE:oriTender.get(0).getDocFeePaymentMode()==2?LABELOFFLINE:tenderDtBean.getSelDocFeePaymentMode()==3?LABELBOTH:"-";
                            setCorrigendumDetailBean("docFeePaymentMode", labelMap.get("docFeePaymentMode").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                        
                        // PT #38371 ** Start Here **
                        String docFessPaymentType[] = tenderDtBean.getSelDocFeePaymentType();
                        
                        List<TblEventPayment> oldDocFeesPayment= tblEventPaymentDao.findTblEventPayment("objectId", Operation_enum.EQ, objectId,"paymentFor", Operation_enum.EQ, 1,"moduleId",Operation_enum.EQ, 3,"isActive",Operation_enum.EQ,1);
                        List<Integer> oldDocFeesPaymentList = new ArrayList<Integer>();
                        List<String> oldDocFeesPaymentStringList = new ArrayList<String>();
                        if(oldDocFeesPayment != null){
	                        for (TblEventPayment eventPayment : oldDocFeesPayment) {
	                        	oldDocFeesPaymentList.add(Integer.valueOf(eventPayment.getTblPaymentType().getPaymentTypeId()));
	                        	oldDocFeesPaymentStringList.add(commonService.getPaymentTypeDetail(eventPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
							}
                        } else {
                        	oldDocFeesPaymentList.add(0);
                        }
                        
                        List<Integer> newDocFeesPaymentList = new ArrayList<Integer>();
                        List<String> newDocFeesPaymentStringList = new ArrayList<String>();
                        for (String pType : docFessPaymentType) {
                        	newDocFeesPaymentList.add(Integer.valueOf(pType));
                        	TblPaymentType payType= commonService.getPaymentTypeDetail(Integer.parseInt(pType));
                        	newDocFeesPaymentStringList.add(payType.getLang1());
                        }
                       
                        if (!newDocFeesPaymentList.equals(oldDocFeesPaymentList)) {
                        	oldValue = oldDocFeesPaymentStringList.toString().replace("[", "").replace("]", "");
                        	newValue = newDocFeesPaymentStringList.toString().replace("[", "").replace("]", "");
                        	setCorriDetailBeanForEventPayType("DocFeesPaymentType", "DocFeesPaymentType", oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                        //** END Here **
                    }
                }
                if (tenderDtBean.getSelIsDocfeesApplicable() == 1) {
                	 String txtDocAmtNew = new BigDecimal(tenderDtBean.getTxtDocumentFee()).setScale(2,BigDecimal.ROUND_UP).toString();
                	 String txtDocAmtOld =  oriTender.get(0).getIsDocfeesApplicable()==0?"-": new BigDecimal(oriTender.get(0).getDocumentFee()!=null && oriTender.get(0).getDocumentFee().length()!=0 ? oriTender.get(0).getDocumentFee() : "0.00").setScale(2,BigDecimal.ROUND_UP).toString();
                    if (!txtDocAmtNew.equals(String.valueOf(txtDocAmtOld))) {
                        setCorrigendumDetailBean("documentFee", getTenderFieldLabel("fields_fees_amt"), txtDocAmtOld, txtDocAmtNew, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (tenderDtBean.getSelIsDocfeesApplicable() == 1 && tenderDtBean.getSelDocFeePaymentMode()==2) {
                    if (!tenderDtBean.getTxtaDocFeePaymentAddress().equals(oriTender.get(0).getDocFeePaymentAddress())) {
                        setCorrigendumDetailBean("docFeePaymentAddress", getTenderFieldLabel("field_docfees_payableat"), oriTender.get(0).getDocFeePaymentAddress(), tenderDtBean.getTxtaDocFeePaymentAddress(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (labelMap.get("isSecurityfeesApplicable") != null) {
                    if (!String.valueOf(tenderDtBean.getSelIsSecurityfeesApplicable()).equals(String.valueOf(oriTender.get(0).getIsSecurityfeesApplicable()))) {
                        if (tenderDtBean.getSelIsSecurityfeesApplicable() == 1) {
                            newValue = LABELALLOW;
                            oldValue =LABELDONTALLOW;
                        } else {
                            newValue =LABELDONTALLOW;
                            oldValue = LABELALLOW;
                        }
                    	setCorrigendumDetailBean("isSecurityfeesApplicable", labelMap.get("isSecurityfeesApplicable").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (tenderDtBean.getSelIsSecurityfeesApplicable() == 1) {
                    if (labelMap.get("secFeePaymentMode") != null) {
                        if (!String.valueOf(tenderDtBean.getSelSecFeePaymentMode()).equals(String.valueOf(oriTender.get(0).getSecFeePaymentMode()))) {
                        	newValue=tenderDtBean.getSelSecFeePaymentMode()==1?LABELONLINE:tenderDtBean.getSelSecFeePaymentMode()==2?LABELOFFLINE:LABELBOTH;
                        	oldValue=oriTender.get(0).getSecFeePaymentMode()==1?LABELONLINE:oriTender.get(0).getSecFeePaymentMode()==2?LABELOFFLINE:LABELBOTH;
                            setCorrigendumDetailBean("secFeePaymentMode", labelMap.get("secFeePaymentMode").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                        
                        // PT #38371 ** Start Here **
                        String secPaymentTypes[] = tenderDtBean.getSelsecPaymentType();
                        
                        List<TblEventPayment> oldsecPaymentTypes= tblEventPaymentDao.findTblEventPayment("objectId", Operation_enum.EQ, objectId,"paymentFor", Operation_enum.EQ,10,"moduleId",Operation_enum.EQ, 3,"isActive",Operation_enum.EQ,1);
                        List<Integer> oldsecPaymentTypesList = new ArrayList<Integer>();
                        List<String> oldsecPaymentTypesStringList = new ArrayList<String>();
                        if(oldsecPaymentTypes != null){
	                        for (TblEventPayment eventPayment : oldsecPaymentTypes) {
	                        	oldsecPaymentTypesList.add(Integer.valueOf(eventPayment.getTblPaymentType().getPaymentTypeId()));
	                        	oldsecPaymentTypesStringList.add(commonService.getPaymentTypeDetail(eventPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
							}
                        } else {
                        	oldsecPaymentTypesList.add(0);
                        }
                        
                        List<Integer> newSecPaymentTypesList = new ArrayList<Integer>();
                        List<String> newSecPaymentTypesStringList = new ArrayList<String>();
                        for (String pType : secPaymentTypes) {
                        	newSecPaymentTypesList.add(Integer.valueOf(pType));
                        	TblPaymentType payType= commonService.getPaymentTypeDetail(Integer.parseInt(pType));
                        	newSecPaymentTypesStringList.add(payType.getLang1());
                        }
                        
                       if (!newSecPaymentTypesList.equals(oldsecPaymentTypesList)) {
                        	oldValue = oldsecPaymentTypesStringList.toString().replace("[", "").replace("]", "");
                        	newValue = newSecPaymentTypesStringList.toString().replace("[", "").replace("]", "");
                        	setCorriDetailBeanForEventPayType("SecurityFeesPaymentType", "SecurityFeesPaymentType", oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                       //	** END Here **
                    }
                }
                if (tenderDtBean.getSelIsSecurityfeesApplicable() == 1) {
                	String txtSecAmtNew = new BigDecimal(tenderDtBean.getTxtSecurityFee()).setScale(2,BigDecimal.ROUND_UP).toString();
               	 	String txtSecAmtOld = new BigDecimal(oriTender.get(0).getSecurityFee()!=null && oriTender.get(0).getSecurityFee().length()!=0 ? oriTender.get(0).getSecurityFee() : "0.00").setScale(2,BigDecimal.ROUND_UP).toString();
                    if (!txtSecAmtNew.equals(txtSecAmtOld)) {
                        setCorrigendumDetailBean("securityFee", getTenderFieldLabel("field_tendersec_fees_amt"), txtSecAmtOld, txtSecAmtNew, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (tenderDtBean.getSelIsSecurityfeesApplicable() == 1 && tenderDtBean.getSelSecFeePaymentMode()==2) {
                    if (!tenderDtBean.getTxtaSecFeePaymentAddress().equals(oriTender.get(0).getSecFeePaymentAddress())) {
                        setCorrigendumDetailBean("secFeePaymentAddress", getTenderFieldLabel("field_tendersec_fee_payment_at"), oriTender.get(0).getSecFeePaymentAddress(), tenderDtBean.getTxtaSecFeePaymentAddress(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (labelMap.get("isEMDApplicable") != null) {
                    if (!String.valueOf(tenderDtBean.getSelIsEMDApplicable()).equals(String.valueOf(oriTender.get(0).getIsEMDApplicable()))) {
                    	newValue=tenderDtBean.getSelIsEMDApplicable()==1?LABELEVENTWISE:tenderDtBean.getSelIsEMDApplicable()==2?LABELITEMWISE:tenderDtBean.getSelIsEMDApplicable()==3?LABELRANGE:LABELNOTREQUIRED;
                    	oldValue=oriTender.get(0).getIsEMDApplicable()==1?LABELEVENTWISE:oriTender.get(0).getIsEMDApplicable()==2?LABELITEMWISE:oriTender.get(0).getIsEMDApplicable()==3?LABELRANGE:LABELNOTREQUIRED;
                        setCorrigendumDetailBean("isEMDApplicable", labelMap.get("isEMDApplicable").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (tenderDtBean.getSelIsEMDApplicable() == 1 || tenderDtBean.getSelIsEMDApplicable() == 2 || tenderDtBean.getSelIsEMDApplicable() == 3) {
                    if (labelMap.get("emdPaymentMode") != null) {
                        if (!String.valueOf(tenderDtBean.getSelEmdPaymentMode()).equals(String.valueOf(oriTender.get(0).getEmdPaymentMode()))) {
                        	newValue=tenderDtBean.getSelEmdPaymentMode()==1?LABELONLINE:tenderDtBean.getSelEmdPaymentMode()==2?LABELOFFLINE:tenderDtBean.getSelEmdPaymentMode()==3?LABELBOTH:"-";
                        	oldValue=oriTender.get(0).getEmdPaymentMode()==1?LABELONLINE:oriTender.get(0).getEmdPaymentMode()==2?LABELOFFLINE:tenderDtBean.getSelEmdPaymentMode()==3?LABELBOTH:"-";
                            setCorrigendumDetailBean("emdPaymentMode", labelMap.get("emdPaymentMode").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                        
                        // PT #38371 ** Start Here **
                        String emdPaymentTypes[] = tenderDtBean.getSelemdPaymentType();

                        List<TblEventPayment> oldemdPaymentTypes= tblEventPaymentDao.findTblEventPayment("objectId", Operation_enum.EQ, objectId,"paymentFor", Operation_enum.EQ,2,"moduleId",Operation_enum.EQ, 3,"isActive",Operation_enum.EQ,1);
                        List<Integer> oldemdPaymentTypesList = new ArrayList<Integer>();
                        List<String> oldemdPaymentTypesStringList = new ArrayList<String>();
                        if(oldemdPaymentTypes != null){
	                        for (TblEventPayment eventPayment : oldemdPaymentTypes) {
	                        	oldemdPaymentTypesList.add(Integer.valueOf(eventPayment.getTblPaymentType().getPaymentTypeId()));
	                        	oldemdPaymentTypesStringList.add(commonService.getPaymentTypeDetail(eventPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
							}
                        } else {
                        	oldemdPaymentTypesList.add(0);
                        }
                        
                        List<Integer> newemdPaymentTypesList = new ArrayList<Integer>();
                        List<String> newemdPaymentTypesStringList = new ArrayList<String>();
                        for (String pType : emdPaymentTypes) {
                        	newemdPaymentTypesList.add(Integer.valueOf(pType));
                        	TblPaymentType payType= commonService.getPaymentTypeDetail(Integer.parseInt(pType));
                        	newemdPaymentTypesStringList.add(payType.getLang1());
                        }
                       
                        if (!newemdPaymentTypesList.equals(oldemdPaymentTypesList)) {
                        	oldValue = oldemdPaymentTypesStringList.toString().replace("[", "").replace("]", "");
                        	newValue = newemdPaymentTypesStringList.toString().replace("[", "").replace("]", "");
                        	setCorriDetailBeanForEventPayType("EMDPaymentType", "EMDPaymentType", oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                        //	** END Here **
                    }
                }
                if (tenderDtBean.getSelIsEMDApplicable() == 1) {
                	String txtEmdAmtNew = new BigDecimal(tenderDtBean.getTxtEmdAmount()).setScale(2,BigDecimal.ROUND_UP).toString();
                	String txtEmdAmtOld = oriTender.get(0).getIsEMDApplicable()==0?"-": new BigDecimal(oriTender.get(0).getEmdAmount()!=null && oriTender.get(0).getEmdAmount().length()!=0 ? oriTender.get(0).getEmdAmount() : "0.00").setScale(2,BigDecimal.ROUND_UP).toString();
                    if (!txtEmdAmtNew.equals(txtEmdAmtOld) &&  oriTender.get(0).getIsEMDApplicable() !=3 ) {
                        setCorrigendumDetailBean("emdAmount", getTenderFieldLabel("field_emdamt"), txtEmdAmtOld, txtEmdAmtNew, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }else if(oriTender.get(0).getIsEMDApplicable() ==3 ){
                    	String txtMinEmdAmtNew = new BigDecimal(0).setScale(2,BigDecimal.ROUND_UP).toString();
                    	String txtMinEmdAmtOld = oriTender.get(0).getIsEMDApplicable()!=3?"-": new BigDecimal(oriTender.get(0).getMinEmdAmt()!=null && oriTender.get(0).getMinEmdAmt().length()!=0 ? oriTender.get(0).getMinEmdAmt() : "0.00").setScale(2,BigDecimal.ROUND_UP).toString();
                        setCorrigendumDetailBean("minEmdAmt", getTenderFieldLabel("field_min_emdamt"), txtMinEmdAmtOld, txtMinEmdAmtNew, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        String txtMaxEmdAmtNew = new BigDecimal(0).setScale(2,BigDecimal.ROUND_UP).toString();
                    	String txtMaxEmdAmtOld = oriTender.get(0).getIsEMDApplicable()!=3?"-": new BigDecimal(oriTender.get(0).getMaxEmdAmt()!=null && oriTender.get(0).getMaxEmdAmt().length()!=0 ? oriTender.get(0).getMaxEmdAmt() : "0.00").setScale(2,BigDecimal.ROUND_UP).toString();
                        setCorrigendumDetailBean("maxEmdAmt", getTenderFieldLabel("field_max_emdamt"), txtMaxEmdAmtOld, txtMaxEmdAmtNew, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        setCorrigendumDetailBean("emdAmount", getTenderFieldLabel("field_emdamt"), txtEmdAmtOld, txtEmdAmtNew, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (tenderDtBean.getSelIsEMDApplicable() == 3) {
                	String txtMinEmdAmtNew = new BigDecimal(tenderDtBean.getTxtMinEmdAmt()).setScale(2,BigDecimal.ROUND_UP).toString();
                	String txtMinEmdAmtOld = oriTender.get(0).getIsEMDApplicable()==0?"-": new BigDecimal(oriTender.get(0).getMinEmdAmt()!=null && oriTender.get(0).getMinEmdAmt().length()!=0 ? oriTender.get(0).getMinEmdAmt() : "0.00").setScale(2,BigDecimal.ROUND_UP).toString();
                    if (!txtMinEmdAmtNew.equals(txtMinEmdAmtOld)) {
                        setCorrigendumDetailBean("minEmdAmt", getTenderFieldLabel("field_min_emdamt"), txtMinEmdAmtOld, txtMinEmdAmtNew, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                    String txtMaxEmdAmtNew = new BigDecimal(tenderDtBean.getTxtMaxEmdAmt()).setScale(2,BigDecimal.ROUND_UP).toString();
                	String txtMaxEmdAmtOld = oriTender.get(0).getIsEMDApplicable()==0?"-": new BigDecimal(oriTender.get(0).getMaxEmdAmt()!=null && oriTender.get(0).getMaxEmdAmt().length()!=0 ? oriTender.get(0).getMaxEmdAmt() : "0.00").setScale(2,BigDecimal.ROUND_UP).toString();
                    if (!txtMinEmdAmtNew.equals(txtMinEmdAmtOld)) {
                        setCorrigendumDetailBean("maxEmdAmt", getTenderFieldLabel("field_max_emdamt"), txtMaxEmdAmtOld, txtMaxEmdAmtNew, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if ((tenderDtBean.getSelIsEMDApplicable() == 1 || tenderDtBean.getSelIsEMDApplicable() == 3) && tenderDtBean.getSelEmdPaymentMode() == 2) {
                    if (!tenderDtBean.getTxtaEmdPaymentAddress().equals(oriTender.get(0).getEmdPaymentAddress())) {
                        setCorrigendumDetailBean("emdPaymentAddress", getTenderFieldLabel("field_emdpaymentat"), oriTender.get(0).getEmdPaymentAddress(), tenderDtBean.getTxtaEmdPaymentAddress(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (labelMap.get("isRegistrationCharges") != null) {
                    if (!String.valueOf(tenderDtBean.getSelIsRegistrationCharges()).equals(String.valueOf(oriTender.get(0).getIsRegistrationCharges()))) {
                    	newValue=tenderDtBean.getSelIsRegistrationCharges()==1?LABELEVENTWISE:tenderDtBean.getSelIsRegistrationCharges()==2?LABELITEMWISE:LABELNOTREQUIRED;
                    	oldValue=oriTender.get(0).getIsRegistrationCharges()==1?LABELEVENTWISE:oriTender.get(0).getIsRegistrationCharges()==2?LABELITEMWISE:LABELNOTREQUIRED;
                        setCorrigendumDetailBean("isRegistrationCharges", labelMap.get("isRegistrationCharges").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (tenderDtBean.getSelIsRegistrationCharges() == 1 || tenderDtBean.getSelIsRegistrationCharges() == 2) {
                    if (labelMap.get("registrationChargesMode") != null) {
                        if (!String.valueOf(tenderDtBean.getSelRegistrationChargesMode()).equals(String.valueOf(oriTender.get(0).getRegistrationChargesMode()))) {
                        	newValue=tenderDtBean.getSelRegistrationChargesMode()==1?LABELONLINE:tenderDtBean.getSelRegistrationChargesMode()==2?LABELOFFLINE:tenderDtBean.getSelRegistrationChargesMode()==3?LABELBOTH:"-";
                        	oldValue=oriTender.get(0).getRegistrationChargesMode()==1?LABELONLINE:oriTender.get(0).getRegistrationChargesMode()==2?LABELOFFLINE:tenderDtBean.getSelRegistrationChargesMode()==3?LABELBOTH:"-";
                            setCorrigendumDetailBean("registrationChargesMode", labelMap.get("registrationChargesMode").toString(), oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                        }
                    }
                    
                    // 	PT #38371 ** Start Here **
                    String regFeesPaymentTypes[] = tenderDtBean.getSelregPaymentType();
                    
                    List<TblEventPayment> oldRegFeesPaymentTypes= tblEventPaymentDao.findTblEventPayment("objectId", Operation_enum.EQ, objectId,"paymentFor", Operation_enum.EQ,8,"moduleId",Operation_enum.EQ, 3,"isActive",Operation_enum.EQ,1);
                    List<Integer> oldRegFeesPaymentTypesList = new ArrayList<Integer>();
                    List<String> oldRegFeesPaymentTypesStringList = new ArrayList<String>();
                    if(oldRegFeesPaymentTypes != null){
                        for (TblEventPayment eventPayment : oldRegFeesPaymentTypes) {
                        	oldRegFeesPaymentTypesList.add(Integer.valueOf(eventPayment.getTblPaymentType().getPaymentTypeId()));
                        	oldRegFeesPaymentTypesStringList.add(commonService.getPaymentTypeDetail(eventPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
						}
                    } else {
                    	oldRegFeesPaymentTypesList.add(0);
                    }
                    
                    List<Integer> newRegFeesPaymentTypesList = new ArrayList<Integer>();
                    List<String> newRegFeesPaymentTypesStringList = new ArrayList<String>();
                    for (String pType : regFeesPaymentTypes) {
                    	newRegFeesPaymentTypesList.add(Integer.valueOf(pType));
                    	TblPaymentType payType= commonService.getPaymentTypeDetail(Integer.parseInt(pType));
                    	newRegFeesPaymentTypesStringList.add(payType.getLang1());
                    }
                   
                    if (!newRegFeesPaymentTypesList.equals(oldRegFeesPaymentTypesList)) {
                    	oldValue = oldRegFeesPaymentTypesStringList.toString().replace("[", "").replace("]", "");
                    	newValue = newRegFeesPaymentTypesStringList.toString().replace("[", "").replace("]", "");
                    	setCorriDetailBeanForEventPayType("RegistrationChargesPaymentTypes", "RegistrationChargesPaymentTypes", oldValue, newValue, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                    //	** END Here **
                }
                if (tenderDtBean.getSelIsRegistrationCharges() == 1) {
                	String txtRegAmtNew = new BigDecimal(tenderDtBean.getTxtRegistrationCharges()).setScale(2,BigDecimal.ROUND_UP).toString();
               	 	String txtRegAmtOld = oriTender.get(0).getIsRegistrationCharges()==0?"-": new BigDecimal(oriTender.get(0).getRegistrationCharges()!=null && oriTender.get(0).getRegistrationCharges().length()!=0 ?oriTender.get(0).getRegistrationCharges() : "0.00").setScale(2,BigDecimal.ROUND_UP).toString();
                    if (!txtRegAmtNew.equals(txtRegAmtOld)) {
                        setCorrigendumDetailBean("registrationCharges", getTenderFieldLabel("fields_regfees_amt"), txtRegAmtOld, txtRegAmtNew, userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                    }
                }
                if (tenderDtBean.getTxtaKeyword() != null && !tenderDtBean.getTxtaKeyword().equalsIgnoreCase(oriTender.get(0).getKeywordText())) {
                    setCorrigendumDetailBean("keywordText", getTenderFieldLabel("fields_auc_keywords"), oriTender.get(0).getKeywordText(), tenderDtBean.getTxtaKeyword().substring(tenderDtBean.getTxtaKeyword().length()-1).equals(",") ? tenderDtBean.getTxtaKeyword().substring(0, tenderDtBean.getTxtaKeyword().length()-1) : tenderDtBean.getTxtaKeyword(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                }
                if (tenderDtBean.getTxtTenderNo() != null && !tenderDtBean.getTxtTenderNo().equalsIgnoreCase(oriTender.get(0).getTenderNo())) {
                    setCorrigendumDetailBean("tenderNo", getTenderFieldLabel("fields_refenceno"), oriTender.get(0).getTenderNo(), tenderDtBean.getTxtTenderNo(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                }
                if (tenderDtBean.getTxtaTenderBrief() != null && !tenderDtBean.getTxtaTenderBrief().equalsIgnoreCase(oriTender.get(0).getTenderBrief())) {
                    setCorrigendumDetailBean("tenderBrief", getTenderFieldLabel("field_brief"), oriTender.get(0).getTenderBrief(), tenderDtBean.getTxtaTenderBrief(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                }
                if (tenderDtBean.getRtfTenderDetail() != null && !tenderDtBean.getRtfTenderDetail().equalsIgnoreCase(oriTender.get(0).getTenderDetail())) {
                    setCorrigendumDetailBean("tenderDetail", getTenderFieldLabel("field_tender_detail"), oriTender.get(0).getTenderDetail(), tenderDtBean.getRtfTenderDetail(), userDetailId, corrigendumId, objectId, tblCorrigendumDetails);
                }
                
                List<Integer> oldEnvList = new ArrayList<Integer>();
                if (lst!=null && lst.length>0) {                    
                    for (int i = 0; i < lst.length; i++) {
                        oldEnvList.add(Integer.valueOf(lst[i]));
                    }
                } else {
                    oldEnvList.add(0);
                }
               
                List<String> currencyNewList = new ArrayList<String>();
                List<String> currencyOldList = new ArrayList<String>();
                List<Object> lstTenderDetail = eventCreationService.getTenderDetail(objectId);
                int baseCurrency = 0;
               
                    if (!String.valueOf(tenderDtBean.getSelCurrencyId()).equals(currencyId)) {
                        baseCurrency = tenderDtBean.getSelCurrencyId();
                    }
                    if (currIdList.length() > 0) {
                       String[] currentValue=   currIdList.split(",");
                       for(int i=0;i<currentValue.length;i++){
                           currencyNewList.add(currentValue[i]);
                       }
                    }
                    Map<Integer, BigDecimal> currencyMap = (Map<Integer, BigDecimal>) lstTenderDetail.get(1);
                    for (java.util.Map.Entry entry : currencyMap.entrySet()) { 
                         
                         currencyOldList.add(entry.getKey().toString());
                     }
               
                tenderCorrigendumService.saveCorrigendumData(tblCorrigendumDetails, corrigendumId, currencyOldList, currencyNewList, baseCurrency, oldEnvList, envelopeType, tenderDtBean.getSelFormType(), tenderDtBean.getTxtBidOpenDate(), objectId, userDetailId);
             }
        }
        return true;
    }
    /**
     * 
     * @param fieldName
     * @param fieldLabel
     * @param oldValue
     * @param newValue
     * @param userDetailId
     * @param corrigendumId
     * @param objectId
     * @param tblCorrigendumDetails 
     */
    private void setCorrigendumDetailBean(String fieldName, String fieldLabel, String oldValue, String newValue, int userDetailId, int corrigendumId, int objectId, List<TblCorrigendumDetail> tblCorrigendumDetails) {
        if (oldValue == null) {
            oldValue = "";
        }
        if (newValue == null) {
            newValue = "";
        }
        TblCorrigendumDetail tblCorrigendumDetail = new TblCorrigendumDetail();
        TblProcess tblProcess = new TblProcess(1);
        TblCorrigendum tblCorrigendum = new TblCorrigendum(corrigendumId);
        tblCorrigendumDetail.setFieldName(fieldName);
        tblCorrigendumDetail.setFieldLabel(fieldLabel);
        tblCorrigendumDetail.setOldValue(oldValue);
        tblCorrigendumDetail.setNewValue(newValue);
        tblCorrigendumDetail.setObjectId(objectId);
        tblCorrigendumDetail.setActionType(2);
        tblCorrigendumDetail.setTblProcess(tblProcess);
        tblCorrigendumDetail.setCreatedBy(userDetailId);
        tblCorrigendumDetail.setTblCorrigendum(tblCorrigendum);
        tblCorrigendumDetails.add(tblCorrigendumDetail);
    }
    
    /**
     * @author Hira Chaudhary
     * @param fieldName
     * @param fieldLabel
     * @param oldValue
     * @param newValue
     * @param userDetailId
     * @param corrigendumId
     * @param objectId
     * @param tblCorrigendumDetails 
     */
    private void setCorriDetailBeanForEventPayType(String fieldName, String fieldLabel, String oldValue, String newValue, int userDetailId, int corrigendumId, int objectId, List<TblCorrigendumDetail> tblCorrigendumDetails) {
        if (oldValue == null) {
            oldValue = "";
        }
        if (newValue == null) {
            newValue = "";
        }
        TblCorrigendumDetail tblCorrigendumDetail = new TblCorrigendumDetail();
        TblProcess tblProcess = new TblProcess(10);
        TblCorrigendum tblCorrigendum = new TblCorrigendum(corrigendumId);
        tblCorrigendumDetail.setFieldName(fieldName);
        tblCorrigendumDetail.setFieldLabel(fieldLabel);
        tblCorrigendumDetail.setOldValue(oldValue);
        tblCorrigendumDetail.setNewValue(newValue);
        tblCorrigendumDetail.setObjectId(objectId);
        tblCorrigendumDetail.setActionType(1);
        tblCorrigendumDetail.setTblProcess(tblProcess);
        tblCorrigendumDetail.setCreatedBy(userDetailId);
        tblCorrigendumDetail.setTblCorrigendum(tblCorrigendum);
        tblCorrigendumDetails.add(tblCorrigendumDetail);
    }
     private String getTenderFieldLabel(String data) {
        return messageSource.getMessage(data, null, LocaleContextHolder.getLocale());
    }
     
     /**
      * @author janak
      * @param clazz
      * @param value
      * @return
      * @throws ParseException 
      */
     private static Object toObject( Class clazz, String value ) throws ParseException {
 	    if( Boolean.class == clazz ) return Boolean.parseBoolean( value );
 	    if( boolean.class == clazz ) return Boolean.parseBoolean( value );
 	    if( Byte.class == clazz ) return Byte.parseByte( value );
 	    if( byte.class == clazz ) return Byte.parseByte( value );
 	    if( Integer.class == clazz ) return Integer.parseInt(value);
 	    if( int.class == clazz ) return Integer.parseInt(value);
 	    if( Double.class == clazz ) return Double.parseDouble( value );
 	    if( double.class == clazz ) return Double.parseDouble( value );
 	    if( BigDecimal.class == clazz ) return new BigDecimal( value );
 	    if( TblEventType.class == clazz ) return new TblEventType(Integer.parseInt(value));
 	    if( TblProcurementNature.class == clazz ) return new TblProcurementNature(Integer.parseInt(value));
 	    if( TblDepartment.class == clazz ) return new TblDepartment(Integer.parseInt(value));
 	    if(Date.class==clazz)
 	    {
 	    	DateFormat formatter = null;
 	        Date convertedDate = null;
 	    	String date = value;
 	        formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:SS");
 	        convertedDate = (Date) formatter.parse(date);
 	        return convertedDate;
 	    }	
 	    return value;
 	} 
     
     /**
      * @author janak
      * @return
      */
     private Map<String,List<String>> getCorrigendumStatus(){
     	Map<String,List<String>> map = new HashMap<String, List<String>>();
     	/*ArrayList<String> fees = new ArrayList<String>();
     	ArrayList<String> basicDetail = new ArrayList<String>();*/
     	ArrayList<String> dates = new ArrayList<String>();
     	
     	/*fees.add("docFeePaymentMode");
     	fees.add("secFeePaymentMode");
     	fees.add("emdPaymentMode");
     	fees.add("documentFee");
     	fees.add("docFeePaymentAddress");
     	fees.add("securityFee");
     	fees.add("secFeePaymentAddress");
     	fees.add("emdPaymentMode");
     	fees.add("emdAmount");
     	fees.add("emdClause");*/
     	
     	/*basicDetail.add("validityPeriod");
     	basicDetail.add("procurementNatureId");
     	basicDetail.add("projectDuration");
     	basicDetail.add("downloadDocument");
     	basicDetail.add("tenderValue");
     	basicDetail.add("tenderNo");
     	basicDetail.add("tenderBrief");
     	basicDetail.add("tenderDetail");
     	basicDetail.add("productId");
     	basicDetail.add("formContract");*/
     	
     	dates.add("documentStartDate");
     	dates.add("documentEndDate");
     	dates.add("submissionStartDate");
     	dates.add("submissionEndDate");
     	dates.add("preBidStartDate");
     	dates.add("preBidEndDate");
     	dates.add("openingDate");
     	
     	/*map.put("FEES", fees);*/
     	map.put("DATES", dates);
     	/*map.put("OTHERS", basicDetail);*/
     	return map;
     }
}