/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblDecryptionFail;
import java.util.List;

/**
 *
 * @author dipal
 */
public interface TblDecryptionFailDao  {

    public void addTblDecryptionFail(TblDecryptionFail tblDecryptionFail);

    public void deleteTblDecryptionFail(TblDecryptionFail tblDecryptionFail);

    public void updateTblDecryptionFail(TblDecryptionFail tblDecryptionFail);

    public List<TblDecryptionFail> getAllTblDecryptionFail();

    public List<TblDecryptionFail> findTblDecryptionFail(Object... values) throws Exception;

    public List<TblDecryptionFail> findByCountTblDecryptionFail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDecryptionFailCount();

    public void saveUpdateAllTblDecryptionFail(List<TblDecryptionFail> tblDecryptionFails);
}
