/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.MessageQueueService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.etender.daointerface.TblItemBidderMapDao;
import com.etl.eproc.etender.daointerface.TblTenderMapBidderHistoryDao;
import com.etl.eproc.etender.databean.TenderMapBidderDataBean;
import com.etl.eproc.etender.model.TblItemBidderMap;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBidderMap;
import com.etl.eproc.etender.model.TblTenderMapBidderHistory;
import com.etl.eproc.etender.model.TblTenderTable;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.EventBidderMapService;
import com.etl.eproc.etender.services.EventCreationService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderFormService;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 *
 * @author vipul
 */
@Controller
@RequestMapping("/etender")
public class EventBidderMapController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private EventBidderMapService eventBidderMapService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private MessageQueueService messageQueueService;
    @Autowired
    private EventCreationService eventCreationService;
    @Autowired
    private ModelToSelectItem modelToSelectItem;
    @Autowired
    private TblItemBidderMapDao itemBidderMapDao;
    @Autowired
    private TblTenderMapBidderHistoryDao tblTenderMapBidderHistoryDao;
    @Value("#{etenderAuditTrailProperties['getBidderMapping']}")
    private String getBidderMapping;
    @Value("#{etenderAuditTrailProperties['ajaxpostRetriveUnMappedBidder']}")
    private String ajaxpostRetriveUnMappedBidder;
    @Value("#{etenderAuditTrailProperties['postMapBidders']}")
    private String postMapBidders;
    @Value("#{etenderAuditTrailProperties['postRemoveMappedBidders']}")
    private String postRemoveMappedBidders;
    @Value("#{etenderAuditTrailProperties['getViewMappedBidders']}")
    private String getViewMappedBidders;
    @Value("#{etenderAuditTrailProperties['getItemWiseBidderMapping']}")
    private String getItemWiseBidderMapping;
    @Value("#{etenderAuditTrailProperties['getItemWiseMapBidder']}")
    private String getItemWiseMapBidder;
    @Value("#{etenderAuditTrailProperties['getBidderWiseItemMapping']}")
    private String getBidderWiseItemMapping;
    @Value("#{etenderAuditTrailProperties['getDisplayFormsForBidderMapping']}")
    private String getDisplayFormsForBidderMapping;
    @Value("#{etenderAuditTrailProperties['getBidderwiseItemMappingReport']}")
    private String getBidderwiseItemMappingReport;
    @Value("#{etenderAuditTrailProperties['getBidderwiseItemMappingDetail']}")
    private String getBidderwiseItemMappingDetail;
    @Value("#{etenderAuditTrailProperties['getMapBidderformDashboard']}")
    private String getMapBidderformDashboard;
    @Value("#{etenderAuditTrailProperties['getUnMapBidderWithAllLine']}")
    private String getUnMapBidderWithAllLine;
    @Value("#{etenderAuditTrailProperties['getMapUnMapBidderHistoryRemarkItemwise']}")
    private String getMapUnMapBidderHistoryRemarkItemwise;
    @Value("#{etenderAuditTrailProperties['getMapUnMapBidderHistoryRemarkGrandTotal']}")
    private String getMapUnMapBidderHistoryRemarkGrandTotal;
    @Value("#{etenderAuditTrailProperties['getMapUnMapBidderHistoryDetails']}")
    private String getMapUnMapBidderHistoryDetails;
    @Value("#{etenderAuditTrailProperties['getTenderLoginReport']}")
    private String getTenderLoginReport;
    @Value("#{etenderAuditTrailProperties['getSendBidderMail']}")
    private String getSendBidderMail;
    @Value("#{etenderAuditTrailProperties['postSendBidderMail']}")
    private String postSendBidderMail;
    @Value("#{tenderlinkProperties['notice_and_document_map']?:173}")
    private int linkMapBidder;
    @Value("#{tenderlinkProperties['notice_and_document_view_mapped_bidders']?:174}")
    private int linkViewMapBidder;
    @Value("#{tenderlinkProperties['notice_and_document_itemwise_bidder_mapping']?:289}")
    private int linkItemWiseBidderMapping;
    @Value("#{tenderlinkProperties['notice_and_document_bidderwise_item_mapping']?:290}")
    private int linkBidderWiseItemMapping;
    @Value("#{eauctionProperties['tender_itemwise']?:2}")
    private int itemWiseResult;
    @Value("#{linkProperties['report_map_unmap_history_itemwise_tender']?:63}")
    private int itemWiseMapUnMapBidderHistoryReportId;
    @Value("#{linkProperties['report_map_unmap_history_view_item_tender']?:64}")
    private int viewItemForMapUnMapBidderHistoryReportId;//Only for Item wise case
    @Value("#{linkProperties['report_map_unmap_history_grandtotal_tender']?:65}")
    private int grandTotalMapUnMapBidderHistoryReportId;
     @Value("#{linkProperties['tender_login_report']?:66}")
     private int loginReportId;
     @Value("#{tenderlinkProperties['report_bidderwise_item_mapping_report']?:587}")
     private int mapBidderLinkId;
     @Value("#{tenderlinkProperties['report_rfx_login_report']?:588}")
     private int loginReportLinkId;
     @Value("#{tenderlinkProperties['authorize_bidders_for_bid_submission_send_mail']?:664}")
    private int linkSendBidderMail;
     @Value("#{etenderProperties['publish_tender_sendbiddermail_templateId']?:93}")
    private String sendBidderMailTemplateId;
     @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
    private String queueName;
     @Value("#{etenderProperties['ten_brdmail_templateId']?:62}")
    private int tenBrdMailTempleteId;
     @Value("#{tenderlinkProperties['tender_create_tender']?:212}")
     private int tendercreationlink;
     
     @Value("#{tenderlinkProperties['notice_and_document_mapbidder_itemwise_event']?:4516}")
     private int linkMapBidderItemWise;
     
    private static final String TENDER_ID = "tenderId";
    private static final String FORM_ID = "formId";
    private static final String TABLE_ID = "tableId";
    private static final String MAPPING_TYPE = "mappingType";
    private static final int BIDDER_WISE_ITEM_MAPPING_REPORTID = 44;

    @RequestMapping(value = "/buyer/biddermapping/{tenderId}/{enc}", method = RequestMethod.GET)
    public String bidderMapping(@PathVariable(TENDER_ID) int tenderId, HttpServletRequest request, ModelMap modelMap) {
    	int tenderResult = 0;
    	try {
        	String keywordText = "";
        	List<SelectItem> lst  = new ArrayList<SelectItem>(); 
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("lstSearchOpt", eventBidderMapService.getSearchOption());
            modelMap.addAttribute("lstMappedBidders", tenderCommonService.getTenderMappedBidderDetails(tenderId, abcUtility.getSessionClientId(request), 1, 0, 0));
            //Start Project Task #49153  Nitin
        	List<Object[]> listEmailIds = commonService.getEmailIdBasedOnObjectId(tenderId,3);
        	modelMap.addAttribute("lstMappedBiddersEmails", listEmailIds);
        	
        	Date serverDate=commonService.getServerDateTime();
        	Date endDate = null;
			Object[] lstTender = commonService.getTenderFields(tenderId, "submissionStartDate,submissionEndDate");
			if(lstTender[1]!=null)
			{
				endDate=(Date)lstTender[1];
			}
			if(endDate!=null){
				boolean showlink =  (endDate).before(serverDate);
				modelMap.addAttribute("showlink", showlink);
			}
			else
            {
            	modelMap.addAttribute("showlink", false);
            }
        	//End Project Task #49153  Nitin
            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "keywordText,tenderMode,tenderResult");
            tenderResult = Integer.parseInt(tenderFields.get(0)[2].toString());
            if(tenderFields.get(0)[0]!=null){
        		keywordText = tenderFields.get(0)[0].toString();
        		if(keywordText.contains(",")){
        			String searchArry[] = keywordText.split(",");
                  	 for(int i=0;i<searchArry.length;i++){
                  		 lst.add(new SelectItem(searchArry[i].trim(),i));
                  	 }
        		}else{
        			 lst.add(new SelectItem(tenderFields.get(0)[0].toString(),1));
        		}
        	modelMap.put("categoryList", lst);
        	}else{
        		 modelMap.addAttribute("categoryList", modelToSelectItem.convertListIntoSelectItemList(eventBidderMapService.getCategoryList(tendercreationlink,tenderId), "categoryId", "categoryName"));
        	}
            
            modelMap.addAttribute(MAPPING_TYPE, "1");
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderResult == 2 ? linkMapBidderItemWise : linkMapBidder, getBidderMapping, tenderId, 0);
        }
        return "/etender/buyer/MapBidder";
    }

    /**
     *
     * @param txtSearchString
     * @param txtSearchOpt
     * @param txTenderId
     * @param txtRowId (Optional if MappingType=1)
     * @param txtMappingType (BidderMapping - 1,ItemwiseBidderMapping - 2, BidderwiseItemMapping - 3, UnMapBidderWithAllLine - 4)
     * @param txtCheckMappedBidder
     * @param request
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/buyer/searchunmappedbidder", method = RequestMethod.POST)
    public String retriveUnMappedBidder(@RequestParam("txtSearchString") String txtSearchString, @RequestParam("txtSearchOpt") int txtSearchOpt,
            @RequestParam("hdTenderId") int txTenderId, @RequestParam(value = "txtRowId", required = false) Integer txtRowId,
            @RequestParam("txtMappingType") int txtMappingType, @RequestParam(value = "txtTableId", required = false) Integer txtTableId,
            HttpServletRequest request, ModelMap modelMap) {
        int linkId = 0;
       try {
        	if(txtSearchString.contains("%26")){
        		txtSearchString.replaceAll("%26", "&");
        	}
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                int clientId = abcUtility.getSessionClientId(request);
                if (eventBidderMapService.isTenderBiddermapped(txTenderId, txtSearchString, txtMappingType, txtTableId == null ? 0 :  txtTableId, txtRowId == null ? 0 :  txtRowId)) {
                    modelMap.addAttribute("isBidderMapped", true);
                }
                    if (txtMappingType == 1) {
                        modelMap.addAttribute("lstUnmappedBidder", eventBidderMapService.getUnmappedBidder(txtSearchString, txTenderId, txtMappingType, txtSearchOpt, clientId));
                    } else if (txtMappingType == 2) {
                    	modelMap.addAttribute("lstUnmappedBidder", eventBidderMapService.getUnmappedBidder(txtSearchString, txTenderId, txtMappingType, txtSearchOpt, clientId, txtTableId, txtRowId));
                    } else if (txtMappingType == 4) {
                        modelMap.addAttribute("lstUnmappedBidder", eventBidderMapService.getUnmappedBidder(txtSearchString, txTenderId, txtMappingType, txtSearchOpt, clientId, txtTableId));
                    } else if (txtMappingType == 3) {
                        modelMap.addAttribute("itemHeader", tenderFormService.getTableColumnHeader(txtTableId, 1));
                        modelMap.addAttribute("lstBidderDetails", commonService.searchBidderDetails(clientId, txtSearchString, txtSearchOpt));
                        modelMap.addAttribute("lstItemBidderMap", tenderCommonService.getItemBidderMapDtls(txtTableId, true));
                    }
                modelMap.addAttribute("mappingtype", txtMappingType);
            } else {
                modelMap.addAttribute("sessionExpired", true);
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            linkId = (txtMappingType == 1) ? linkMapBidder : (txtMappingType == 3) ? linkBidderWiseItemMapping : linkItemWiseBidderMapping;
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, ajaxpostRetriveUnMappedBidder, txTenderId, 0);
        }
        return "etender/buyer/MapBidderSearchResult";
    }

    /**
     *
     * @param tenderMapBidderDataBean
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/buyer/mapbidder", method = RequestMethod.POST)
    public String mapBidders(@ModelAttribute TenderMapBidderDataBean tenderMapBidderDataBean, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        StringBuilder pageView = new StringBuilder();
        pageView.append("redirect:/sessionexpired");
        int linkId = 0;
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                pageView.delete(0, pageView.length());
                pageView.append("redirect:/etender/buyer/tenderdashboard/").append(tenderMapBidderDataBean.getHdTenderId()).append("/1");
                pageView.append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1), request));
                
                List<TblTenderBidderMap> lstTenderBidderMap = new ArrayList<TblTenderBidderMap>();
                List<TblTenderMapBidderHistory> lstTenderMapBidderHistory = new ArrayList<TblTenderMapBidderHistory>();
                List<TblItemBidderMap> lstItemBidderMap = new ArrayList<TblItemBidderMap>();
                int tenderMode = (Integer) tenderCommonService.getTenderField(tenderMapBidderDataBean.getHdTenderId(), "tenderMode");
                boolean isValid = true;
                int bidderMapping = (Integer) tenderCommonService.getTenderField(tenderMapBidderDataBean.getHdTenderId(), "bidderMapping");
                StringBuilder mappingPair = new StringBuilder();
                if (tenderMapBidderDataBean.getChkBidderId() != null && tenderMapBidderDataBean.getChkBidderId().length > 0) {
                    if (tenderMapBidderDataBean.getHdMappingType() == 1) {
                    	int tenderResult = (Integer) tenderCommonService.getTenderField(tenderMapBidderDataBean.getHdTenderId(), "tenderResult");
                    	if (tenderMode == 3 || tenderMode == 4) {
	                            if (tenderMapBidderDataBean.getChkBidderId().length > 1
	                                    || eventBidderMapService.isSingleBidderMapped(tenderMapBidderDataBean.getHdTenderId())) {
	                                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_tender_err_biddermul_mapping_nt_allowed");
	
	                                pageView.delete(0, pageView.length());
	                                pageView.append("redirect:/etender/buyer/biddermapping/").append(tenderMapBidderDataBean.getHdTenderId());
	    	                        pageView.append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1), request));
	                                isValid = false;
	                           }
	                    }
                    	if (isValid) {
	                        if(tenderResult == 2){
	                        	prepareMapBidderDTOItemWiseEvent(tenderMapBidderDataBean, lstTenderBidderMap, lstTenderMapBidderHistory, lstItemBidderMap,mappingPair, request, tenderMapBidderDataBean.getHdMappingType());
	                        }else{  	
	                        	prepareMapBidderDTO(tenderMapBidderDataBean, lstTenderBidderMap, lstTenderMapBidderHistory, lstItemBidderMap,mappingPair, request, tenderMapBidderDataBean.getHdMappingType());
	                        }
	                        	
                        	if (eventBidderMapService.getBidderMappingCount(mappingPair.length() > 1 ? mappingPair.toString().substring(0, mappingPair.length() - 1) : "", tenderMapBidderDataBean.getHdTenderId()) == 0) {
                                if (eventBidderMapService.addAllTenderBidderMap(lstTenderBidderMap, lstTenderMapBidderHistory, tenderMapBidderDataBean.getHdMappingType(), tenderResult == 2 ? lstItemBidderMap : null)) {
                                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_tender_biddersmapped_success");
                                } else {
                                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                                }
                            } else {
                                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_tender_biddermap_alreadymap");
                            }
                            pageView.delete(0, pageView.length());
                            pageView.append("redirect:/etender/buyer/biddermapping/").append(tenderMapBidderDataBean.getHdTenderId());
                            pageView.append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1), request));
                        }
                    } else if (tenderMapBidderDataBean.getHdMappingType() == 2 || tenderMapBidderDataBean.getHdMappingType() == 4
                            || tenderMapBidderDataBean.getHdMappingType() == 3) {

                        if (tenderMapBidderDataBean.getHdMappingType() == 2 || tenderMapBidderDataBean.getHdMappingType() == 3) {
                            prepareMapBidderDTO(tenderMapBidderDataBean, lstTenderBidderMap, lstTenderMapBidderHistory, lstItemBidderMap,
                                    mappingPair, request, tenderMapBidderDataBean.getHdMappingType());
                        } else {
                        	//for (int i = 0; i < tenderMapBidderDataBean.getHdRowId(); i++) {
                        	String[] chkBidderId = tenderMapBidderDataBean.getChkBidderId();
                        	String[] tempBidderId = new String[chkBidderId.length*tenderMapBidderDataBean.getHdRowId()];
                        	int counter=0;
                        	for (int i = 0; i < chkBidderId.length; i++) {                        		
                        		for (int j = 0; j < tenderMapBidderDataBean.getHdRowId(); j++) {
                        			tempBidderId[counter] = chkBidderId[i]+"_"+(j+1);
                        			counter++;
                        		}								
							}
                        	tenderMapBidderDataBean.setChkBidderId(tempBidderId);
                                prepareMapBidderDTO(tenderMapBidderDataBean, lstTenderBidderMap, lstTenderMapBidderHistory, lstItemBidderMap,
                                        mappingPair, request, tenderMapBidderDataBean.getHdMappingType());
                           // }
                        }

                        if ((eventBidderMapService.getItemBidderMapCount(mappingPair.length() > 1 ? mappingPair.toString().substring(0, mappingPair.length() - 1) : "", tenderMapBidderDataBean.getHdTableId())) == 0) {
                        	List<Integer> rowid = new ArrayList<Integer>();;
                        	 int selectedbidder=0;
                        	 for (String chkBidderId : tenderMapBidderDataBean.getChkBidderId())
                    		 {
                        		 selectedbidder=Integer.parseInt(chkBidderId.split("_")[0]);
                    		 }
                        	for(int i=0;i<lstItemBidderMap.size();i++)
                        	{
                        		
                        		rowid.add(lstItemBidderMap.get(i).getRowId());
                        	}
                        		 if(eventBidderMapService.getMapBidderValue(selectedbidder,tenderMapBidderDataBean.getHdTenderId(),rowid,tenderMapBidderDataBean.getHdTableId()))
                        		 {
                        			 redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_tender_biddermap_alreadymap");
                        		 }else{
                        			 if (eventBidderMapService.addAllTenderBidderMap(lstTenderBidderMap, lstTenderMapBidderHistory, tenderMapBidderDataBean.getHdMappingType(), lstItemBidderMap)) {
     	                                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_tender_biddersmapped_success");
     	                            } else {
     	                                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
     	                            }
                        		 }
                        } else {
                            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_tender_biddermap_alreadymap");
                        }
                        if (tenderMapBidderDataBean.getHdMappingType() == 2) {
                            pageView.delete(0, pageView.length());
                            pageView.append("redirect:/etender/buyer/itemwisemapbidder/").append(tenderMapBidderDataBean.getHdTenderId())
                                    .append("/").append(tenderMapBidderDataBean.getHdFormId()).append("/").append(tenderMapBidderDataBean.getHdTableId())
                                    .append("/").append(tenderMapBidderDataBean.getHdRowId());
                            pageView.append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1), request));
                        } else if (tenderMapBidderDataBean.getHdMappingType() == 4) {
                            pageView.delete(0, pageView.length());
                            pageView.append("redirect:/etender/buyer/unmapbidderwithallline/").append(tenderMapBidderDataBean.getHdTenderId())
                                    .append("/").append(tenderMapBidderDataBean.getHdFormId()).append("/").append(tenderMapBidderDataBean.getHdTableId())
                                    .append("/").append(tenderMapBidderDataBean.getHdRowId());
                            pageView.append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1), request));
                        } else if (tenderMapBidderDataBean.getHdMappingType() == 3) {
                            pageView.delete(0, pageView.length());
                            pageView.append("redirect:/etender/buyer/bidderwiseitemmapping/").append(tenderMapBidderDataBean.getHdTenderId())
                                    .append("/").append(tenderMapBidderDataBean.getHdFormId()).append("/").append(tenderMapBidderDataBean.getHdTableId());
                            pageView.append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1), request));
                        }
                    }
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            linkId = (tenderMapBidderDataBean.getHdMappingType() == 1) ? linkMapBidder
                    : (tenderMapBidderDataBean.getHdMappingType() == 3) ? linkBidderWiseItemMapping : linkItemWiseBidderMapping;
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postMapBidders, tenderMapBidderDataBean.getHdTenderId(), 0);
        }
        return pageView.toString();
    }

    /**
     *
     * @param tenderMapBidderDataBean
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/buyer/removemappedbidder", method = RequestMethod.POST)
    public String removeMappedBidders(@ModelAttribute TenderMapBidderDataBean tenderMapBidderDataBean, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        StringBuilder pageView = new StringBuilder();
        pageView.append("redirect:/sessionexpired");
        int linkId = 0;
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                StringBuilder objId = new StringBuilder();
                StringBuilder rejObjId = new StringBuilder();
                StringBuilder mapBddersIds=new StringBuilder();
                pageView.delete(0, pageView.length());
                pageView.append("redirect:/etender/buyer/tenderdashboard/").append(tenderMapBidderDataBean.getHdTenderId()).append("/1")
                        .append(encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/" + tenderMapBidderDataBean.getHdTenderId() + "/1",
                        request));

                List<TblTenderMapBidderHistory> lstTenderMapBidderHistory = new ArrayList<TblTenderMapBidderHistory>();
                StringBuilder companyName=new StringBuilder();
                Set<String> compSet=new HashSet<String>();
                if (tenderMapBidderDataBean.getChkMapBidderId() != null && tenderMapBidderDataBean.getChkMapBidderId().length > 0) {
                    for (String chkMapBidderId : tenderMapBidderDataBean.getChkMapBidderId()) {
                        objId.append("'").append(chkMapBidderId.split("_")[3]).append("'");
                        objId.append(",");
                        if (tenderMapBidderDataBean.getHdMappingType()==2 || tenderMapBidderDataBean.getHdMappingType()==4){
                        	if(tenderCommonService.isEventLive(tenderMapBidderDataBean.getHdTenderId())==1 && !tenderCommonService.isBidderAcceptTermsCondition(tenderMapBidderDataBean.getHdTenderId(), Integer.parseInt(chkMapBidderId.split("_")[3]))){
                        	mapBddersIds.append("'").append(chkMapBidderId.split("_")[4]).append("'");
                            mapBddersIds.append(",");
                        	}else if(tenderCommonService.isEventLive(tenderMapBidderDataBean.getHdTenderId())!=1){
                        		mapBddersIds.append("'").append(chkMapBidderId.split("_")[4]).append("'");
                                mapBddersIds.append(",");
                        	}else{
                        		compSet.add(commonService.getField("TblCompany", "companyName", "companyId", Integer.parseInt(chkMapBidderId.split("_")[3].toString())));
                        	}
                        	if(tenderCommonService.isBidderAcceptTermsCondition(tenderMapBidderDataBean.getHdTenderId(), Integer.parseInt(chkMapBidderId.split("_")[3]))){
                        		
                        		
                        		redirectAttributes.addFlashAttribute("bidderAcceptedTerms", "bidder_has_accepted_term_cond");
                        	}
                        }else if(tenderMapBidderDataBean.getHdMappingType()==3){
                        	if(tenderCommonService.isEventLive(tenderMapBidderDataBean.getHdTenderId())==1 && !tenderCommonService.isBidderAcceptTermsCondition(tenderMapBidderDataBean.getHdTenderId(), Integer.parseInt(chkMapBidderId.split("_")[3]))){
                        	mapBddersIds.append("'").append(chkMapBidderId.split("_")[5]).append("'");
                            mapBddersIds.append(",");
                        	}else if(tenderCommonService.isEventLive(tenderMapBidderDataBean.getHdTenderId())!=1){
                        		mapBddersIds.append("'").append(chkMapBidderId.split("_")[5]).append("'");
                                mapBddersIds.append(",");
                        	}else{
                        		compSet.add(commonService.getField("TblCompany", "companyName", "companyId", Integer.parseInt(chkMapBidderId.split("_")[3].toString())));
                        	}
                        	if(tenderCommonService.isBidderAcceptTermsCondition(tenderMapBidderDataBean.getHdTenderId(), Integer.parseInt(chkMapBidderId.split("_")[3]))){
                        		redirectAttributes.addFlashAttribute("bidderAcceptedTerms", "bidder_has_accepted_term_cond");
                        	}
                        	
                        }
                    }

                    if(compSet.size()>0){
                    	Iterator it=compSet.iterator();
                    	while(it.hasNext()){
                    		if(companyName.length()>0){
                    			companyName.append(",");
                    		}
                    		companyName.append(it.next());
                    	}
                    	redirectAttributes.addFlashAttribute("acceptedTermCondCompany", companyName);
                    }
                    List<Object> lstFinalSubmissionCompany = eventBidderMapService.getFinalSubmissionCompanyDtls(tenderMapBidderDataBean.getHdTenderId(),
                            objId.toString().substring(0, objId.length() - 1));

                    objId.delete(0, objId.length());

                    if (tenderMapBidderDataBean.getHdMappingType() == 4) {
                        for (int i = 0; i < tenderMapBidderDataBean.getHdRowId(); i++) {
                            prepareUnMapBidderDTO(tenderMapBidderDataBean, request, lstTenderMapBidderHistory, lstFinalSubmissionCompany, objId,
                                    rejObjId, (i + 1),redirectAttributes);
                        }
                    } else {
                        prepareUnMapBidderDTO(tenderMapBidderDataBean, request, lstTenderMapBidderHistory, lstFinalSubmissionCompany, objId, rejObjId, 0,redirectAttributes);
                    }

                    if (tenderMapBidderDataBean.getHdMappingType() == 1) {
                        pageView.delete(0, pageView.length());
                        pageView.append("redirect:/etender/buyer/biddermapping/").append(tenderMapBidderDataBean.getHdTenderId());
                        pageView.append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1), request));
                    } else if (tenderMapBidderDataBean.getHdMappingType() == 2) {
                        pageView.delete(0, pageView.length());
                        pageView.append("redirect:/etender/buyer/itemwisemapbidder/").append(tenderMapBidderDataBean.getHdTenderId())
                                .append("/").append(tenderMapBidderDataBean.getHdFormId()).append("/").append(tenderMapBidderDataBean.getHdTableId())
                                .append("/").append(tenderMapBidderDataBean.getHdRowId());
                        pageView.append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1), request));
                    } else if (tenderMapBidderDataBean.getHdMappingType() == 4) {
                        pageView.delete(0, pageView.length());
                        pageView.append("redirect:/etender/buyer/unmapbidderwithallline/").append(tenderMapBidderDataBean.getHdTenderId())
                                .append("/").append(tenderMapBidderDataBean.getHdFormId()).append("/").append(tenderMapBidderDataBean.getHdTableId())
                                .append("/").append(tenderMapBidderDataBean.getHdRowId());
                       pageView.append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1), request));
                    } else if (tenderMapBidderDataBean.getHdMappingType() == 3) {
                        pageView.delete(0, pageView.length());
                        pageView.append("redirect:/etender/buyer/bidderwiseitemmapping/").append(tenderMapBidderDataBean.getHdTenderId())
                                .append("/").append(tenderMapBidderDataBean.getHdFormId()).append("/").append(tenderMapBidderDataBean.getHdTableId());
                        pageView.append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1), request));
                    }
                    if (!lstFinalSubmissionCompany.isEmpty()) {
                        String companyNames = StringUtils.collectionToCommaDelimitedString(commonService.getLstCompanyName(abcUtility.getSessionClientId(request),
                                rejObjId.length() > 1 ? rejObjId.toString().substring(0, rejObjId.length() - 1) : ""));
                        redirectAttributes.addFlashAttribute("companyNames", companyNames);
                        redirectAttributes.addFlashAttribute("err_fs_completed", "err_fs_completed");
                    }
                    
                    //#73169 :: @Indrajit Maheshwari
                    int tenderMode = 0;
                    tenderMode =(Integer) tenderCommonService.getTenderField(tenderMapBidderDataBean.getHdTenderId(), "tenderMode");
                    int tenderStatus = 0;
                    tenderStatus = (Integer) tenderCommonService.getTenderField(tenderMapBidderDataBean.getHdTenderId(), "cstatus");
                    if(tenderMode == 2 && tenderStatus==1 && (eventBidderMapService.isSingleBidderMapped(tenderMapBidderDataBean.getHdTenderId()) || eventBidderMapService.getTenderBidderMap(tenderMapBidderDataBean.getHdTenderId()).size() == tenderMapBidderDataBean.getChkMapBidderId().length))
                    {
                    	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_no_bidder_mapped_with_tender");
                    }
                    else
                    {
                    	int delCount = eventBidderMapService.removeMappedBidders(objId.length() > 1 ? objId.toString().substring(0, objId.length() - 1) : "''",
                                tenderMapBidderDataBean.getHdMappingType(), lstTenderMapBidderHistory, tenderMapBidderDataBean.getHdTableId(),mapBddersIds.length() > 1 ? mapBddersIds.toString().substring(0, mapBddersIds.length() - 1) : "''");
                    	
                    	if (delCount > 0) {
                            redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_tender_bidderunmap_success");
                        }
                    }
					//:: @Indrajit Maheshwari
                    
                   /* if(tenderMapBidderDataBean.getHdMappingType()!=1){
                    long count=eventBidderMapService.getCountFromItemBidderMap(tenderMapBidderDataBean.getHdTenderId());
                    if(count==0){
                    	eventBidderMapService.deleteTenderBidderMap(tenderMapBidderDataBean.getHdTenderId());
                    }
                    }*/
                }
            }
        } catch (Exception e) {
           return exceptionHandlerService.writeLog(e);
        } finally {
            linkId = (tenderMapBidderDataBean.getHdMappingType() == 1) ? linkMapBidder
                    : (tenderMapBidderDataBean.getHdMappingType() == 3) ? linkBidderWiseItemMapping : linkItemWiseBidderMapping;
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postRemoveMappedBidders, tenderMapBidderDataBean.getHdTenderId(), 0);
        }
        return pageView.toString();
    }

    /**
     *
     * @param tenderId
     * @param isWorkFlow
     * @param request
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/buyer/viewmappedbidders/{tenderId}/{isWorkFlow}/{enc}", method = RequestMethod.GET)
    public String viewMappedBidders(@PathVariable(TENDER_ID) int tenderId, @PathVariable("isWorkFlow") int isWorkFlow, HttpServletRequest request, ModelMap modelMap) {
        try {
        	String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
        	int userDetailId = abcUtility.getSessionUserDetailId(request);
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            Date submissionEndDate=(Date)modelMap.get("endDateOfsubmission");
            Date currentDate= commonService.getServerDateTime();
            if(submissionEndDate!=null){
            	modelMap.addAttribute("isTenderArchive", (currentDate.after(submissionEndDate)));
            }
            //if whole event bidder mapped than bidder mapped in itemwise tender before adding bidding form (#64223) Rinju
            int bidderMapping = 0;
            int tenderresult = 0;
            int tenderMode = 0;
            int mapBidderId = 0;
            int companyId = 0;
            int createdBy = 0;
            int bidderUserDetailId = 0;
            	List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "bidderMapping,tenderResult,tenderMode");
            	if(tenderFields!=null && !tenderFields.isEmpty()){
                  bidderMapping = (Integer) tenderFields.get(0)[0];
                  tenderresult = (Integer) tenderFields.get(0)[1];
                  tenderMode = (Integer) tenderFields.get(0)[2];
            	}
            	if(bidderMapping == 0 && tenderresult == 2 && tenderMode == 2){
            		List<Object[]> mappedBidderLst = eventBidderMapService.getTenderBidderMap(tenderId);
            		List<Object> tableIdList = tenderFormService.getPriceBidTableLstByTenderId(tenderId);
            		for (Object[] mappedBidderLsts : mappedBidderLst) {
            			mapBidderId = (Integer) mappedBidderLsts[0];
            			companyId = (Integer) mappedBidderLsts[1];
            			bidderUserDetailId = (Integer) mappedBidderLsts[2];
            			createdBy = (Integer) mappedBidderLsts[3];
            			for(Object tableIds : tableIdList){
    						List<Object[]> tenderTableList = tenderFormService.getTenderTableDetails((Integer)tableIds);
    						int noOfRows = (Integer) tenderTableList.get(0)[6];
    						int hasGTRows = (Integer) tenderTableList.get(0)[9];
    						List<Object[]> itemList = eventCreationService.getItemBidderMapByTableidAndMapibidderid((Integer)tableIds,mapBidderId);
    						for(int i=1; i<=(noOfRows-hasGTRows); i++){
    							if(!itemList.contains(i)){
    								TblItemBidderMap tblItemBidderMap = new TblItemBidderMap();
	          	      	            tblItemBidderMap.setTblTenderBidderMap(new TblTenderBidderMap(mapBidderId));
	          	      		        tblItemBidderMap.setTblTenderTable(new TblTenderTable((Integer)tableIds));
	          	      	            tblItemBidderMap.setRowId(i);
	          	      	            tblItemBidderMap.setIpAddress(ipAddress);
	          	      	            tblItemBidderMap.setCreatedBy(userDetailId);
	          	      	            itemBidderMapDao.addTblItemBidderMap(tblItemBidderMap);
	          	      	                  
	          	      	            TblTenderMapBidderHistory tblTenderMapBidderHistory = new TblTenderMapBidderHistory();
	          	      	            tblTenderMapBidderHistory.setTblTender(new TblTender(tenderId));
	          	      	            tblTenderMapBidderHistory.setTblUserDetail(new TblUserDetail(bidderUserDetailId));
	          	      	            tblTenderMapBidderHistory.setCreatedBy(userDetailId);
	          	      	            tblTenderMapBidderHistory.setIsMapped(1);
	          	      	            tblTenderMapBidderHistory.setTblCompany(new TblCompany(companyId));
	          	      	            tblTenderMapBidderHistory.setTableId((Integer)tableIds);
	          	      	            tblTenderMapBidderHistory.setRowId(i);
	          	      	            tblTenderMapBidderHistoryDao.addTblTenderMapBidderHistory(tblTenderMapBidderHistory);
    						}
        						
        				}
    			}
            		}
            	}
            	//END
            	modelMap.addAttribute("lstMappedBidders", tenderCommonService.getTenderMappedBidderDetails(tenderId, abcUtility.getSessionClientId(request), 1, 0, 0));
                modelMap.addAttribute("lstMappedBidderItemList", eventBidderMapService.GetMappedItemsByTenderId(tenderId, 1));
                modelMap.addAttribute("isWorkFlow", isWorkFlow);
                //Start Project Task #49153  Nitin
                List<Object[]> listEmailIds = commonService.getEmailIdBasedOnObjectId(tenderId,3);
                modelMap.addAttribute("lstMappedBiddersEmails", listEmailIds);
                //End Project Task #49153  Nitin 
            
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkViewMapBidder, getViewMappedBidders, tenderId, 0);
        }
        return "/etender/buyer/ViewMappedBidders";
    }

    /**
     *
     * @param tenderId
     * @param formId
     * @param tableId
     * @param request
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/buyer/itemwisebiddermapping/{tenderId}/{formId}/{tableId}/{enc}", method = RequestMethod.GET)
    public String itemWiseBidderMapping(@PathVariable(TENDER_ID) int tenderId, @PathVariable(FORM_ID) int formId, @PathVariable(TABLE_ID) int tableId, HttpServletRequest request, ModelMap modelMap) {
        try {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> formList = tenderFormService.getTenderFormDetails(formId);
            if (formList != null && !formList.isEmpty()) {
                modelMap.addAttribute("formName", formList.get(0)[0]);
            }
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("tenderTableLst", tenderFormService.getTenderTableDetails(tableId));
            modelMap.addAttribute("tenderColLst", tenderFormService.getTenderColumnByTableId(tableId));
            modelMap.addAttribute("tenderFormItemdescLst", tenderFormService.getItemDescFormData(tableId));
            modelMap.addAttribute("tblCount",tenderFormService.getTableCountForSortOrder(formId));
            modelMap.addAttribute("frmCount",tenderFormService.getNoOfPriceBidForm(tenderId));
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkItemWiseBidderMapping, getItemWiseBidderMapping, tenderId, 0);
        }
        return "etender/buyer/SbItemWiseBidderMapping";
    }

    /**
     *
     * @param tenderId
     * @param formId
     * @param tableId
     * @param rowId
     * @param request
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/buyer/itemwisemapbidder/{tenderId}/{formId}/{tableId}/{rowId}/{enc}", method = RequestMethod.GET)
    public String itemWiseMapBidder(@PathVariable(TENDER_ID) int tenderId, @PathVariable(FORM_ID) int formId,
            @PathVariable(TABLE_ID) int tableId, @PathVariable("rowId") int rowId, HttpServletRequest request, ModelMap modelMap) {
        try {
            int clientId = abcUtility.getSessionClientId(request);
            String keywordText = "";
        	List<SelectItem> lst  = new ArrayList<SelectItem>(); 
            
            tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
            modelMap.addAttribute("lstSearchOpt", eventBidderMapService.getSearchOption());
            modelMap.addAttribute("lstMappedBidders", tenderCommonService.getTenderMappedBidderDetails(tenderId, clientId, 2, tableId, rowId));
            //Start Project Task #49153  Nitin
            List<Object[]> listEmailIds = commonService.getEmailIdBasedOnObjectId(tenderId,3);
            modelMap.addAttribute("lstMappedBiddersEmails", listEmailIds);
            
            Date serverDate=commonService.getServerDateTime();
            Date endDate = null;
            Object[] lstTender = commonService.getTenderFields(tenderId, "submissionStartDate,submissionEndDate");
            if(lstTender[1]!=null)
			{
				endDate=(Date)lstTender[1];
			}
            if(endDate!=null){
	            boolean showlink =  (endDate).before(serverDate);
	            modelMap.addAttribute("showlink", showlink);
            }
            else
            {
            	modelMap.addAttribute("showlink", false);
            }
            //End Project Task #49153  Nitin 
            List<Object[]> list=tenderCommonService.getItemNameWithFormNameAndTableName(formId, tableId, rowId);
            if(!list.isEmpty() && list.size()>0){
            	modelMap.addAttribute("formName",list.get(0)[0]);
            	modelMap.addAttribute("tableName", list.get(0)[1]);
            	modelMap.addAttribute("itemName", list.get(0)[2]);
            }
            
            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "keywordText,tenderMode");
            if(tenderFields.get(0)[0]!=null){
        		keywordText = tenderFields.get(0)[0].toString();
        		if(keywordText.contains(",")){
        			String searchArry[] = keywordText.split(",");
                  	 for(int i=0;i<searchArry.length;i++){
                  		 lst.add(new SelectItem(searchArry[i].trim(),i));
                  	 }
        		}else{
        			 lst.add(new SelectItem(tenderFields.get(0)[0].toString(),1));
        		}
        	modelMap.put("categoryList", lst);
        	}else{
        		 modelMap.addAttribute("categoryList", modelToSelectItem.convertListIntoSelectItemList(eventBidderMapService.getCategoryList(tendercreationlink,tenderId), "categoryId", "categoryName"));
        	}
            
            modelMap.addAttribute(MAPPING_TYPE, "2");
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkItemWiseBidderMapping, getItemWiseMapBidder, tenderId, 0);
        }
        return "etender/buyer/MapBidder";
    }

    /**
     *
     * @param tenderId
     * @param formId
     * @param tableId
     * @param rowId
     * @param request
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/buyer/unmapbidderwithallline/{tenderId}/{formId}/{tableId}/{rowCount}/{enc}", method = RequestMethod.GET)
    public String unMapBidderWithAllLine(@PathVariable(TENDER_ID) int tenderId, @PathVariable(FORM_ID) int formId,
            @PathVariable(TABLE_ID) int tableId, @PathVariable("rowCount") int rowCount, HttpServletRequest request, ModelMap modelMap) {
        try {
            int clientId = abcUtility.getSessionClientId(request);
            String keywordText = "";
        	List<SelectItem> lst  = new ArrayList<SelectItem>(); 
            
            tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
            modelMap.addAttribute("lstSearchOpt", eventBidderMapService.getSearchOption());
            modelMap.addAttribute("lstMappedBidders", tenderCommonService.getTenderMappedBidderDetails(tenderId, clientId, 4, tableId, 0));
            modelMap.addAttribute(MAPPING_TYPE, "4");
            
            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "keywordText,tenderMode");
            if(tenderFields.get(0)[0]!=null){
        		keywordText = tenderFields.get(0)[0].toString();
        		if(keywordText.contains(",")){
        			String searchArry[] = keywordText.split(",");
                  	 for(int i=0;i<searchArry.length;i++){
                  		 lst.add(new SelectItem(searchArry[i].trim(),i));
                  	 }
        		}else{
        			 lst.add(new SelectItem(tenderFields.get(0)[0].toString(),1));
        		}
        	modelMap.put("categoryList", lst);
        	}else{
        		 modelMap.addAttribute("categoryList", modelToSelectItem.convertListIntoSelectItemList(eventBidderMapService.getCategoryList(tendercreationlink,tenderId), "categoryId", "categoryName"));
        	}
            
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkItemWiseBidderMapping, getUnMapBidderWithAllLine, tenderId, 0);
        }
        return "etender/buyer/MapBidder";
    }

    /**
     *
     * @param tenderId
     * @param formId
     * @param tableId
     * @param request
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/buyer/bidderwiseitemmapping/{tenderId}/{formId}/{tableId}/{enc}", method = RequestMethod.GET)
    public String bidderWiseItemMapping(@PathVariable(TENDER_ID) int tenderId, @PathVariable(FORM_ID) int formId,
            @PathVariable(TABLE_ID) int tableId, HttpServletRequest request, ModelMap modelMap) {
        try {
        	String keywordText = "";
        	List<SelectItem> lst  = new ArrayList<SelectItem>(); 
        	
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("itemHeader", tenderFormService.getTableColumnHeader(tableId, 1));
            modelMap.addAttribute("lstSearchOpt", eventBidderMapService.getSearchOption());
            modelMap.addAttribute("lstItemBidderMap", tenderCommonService.getItemBidderMapDtls(tableId, false));
            modelMap.addAttribute("lstMappedBidders", tenderCommonService.getTenderMappedBidderDetails(tenderId, abcUtility.getSessionClientId(request), 3, tableId, 0));
            modelMap.addAttribute("tblCount",tenderFormService.getTableCountForSortOrder(formId));
            modelMap.addAttribute("frmCount",tenderFormService.getNoOfPriceBidForm(tenderId));
            modelMap.addAttribute(MAPPING_TYPE, "3");
            
            //Start Project Task #49153  Nitin
           	List<Object[]> listEmailIds = commonService.getEmailIdBasedOnObjectId(tenderId,3);
           	modelMap.addAttribute("lstMappedBiddersEmails", listEmailIds);
           	
           	Date serverDate=commonService.getServerDateTime();
           	Date endDate = null;
           	Object[] lstTender = commonService.getTenderFields(tenderId, "submissionStartDate,submissionEndDate");
           	if(lstTender[1]!=null)
			{
				endDate=(Date)lstTender[1];
			}
           	if(endDate!=null){
           		boolean showlink =  (endDate).before(serverDate);
               	modelMap.addAttribute("showlink", showlink);
           	}
            else
            {
            	modelMap.addAttribute("showlink", false);
            }
           	//End Project Task #49153  Nitin 
           	
            List<Object[]> list=tenderCommonService.getFormNameAndTableName(formId, tableId);
            if(!list.isEmpty() && list.size()>0){
            	modelMap.addAttribute("formName",list.get(0)[0]);
            	modelMap.addAttribute("tableName", list.get(0)[1]);
            }
            
            List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "keywordText,tenderMode");
            if(tenderFields.get(0)[0]!=null){
        		keywordText = tenderFields.get(0)[0].toString();
        		if(keywordText.contains(",")){
        			String searchArry[] = keywordText.split(",");
                  	 for(int i=0;i<searchArry.length;i++){
                  		 lst.add(new SelectItem(searchArry[i].trim(),i));
                  	 }
        		}else{
        			 lst.add(new SelectItem(tenderFields.get(0)[0].toString(),1));
        		}
        	modelMap.put("categoryList", lst);
        	}else{
        		 modelMap.addAttribute("categoryList", modelToSelectItem.convertListIntoSelectItemList(eventBidderMapService.getCategoryList(tendercreationlink,tenderId), "categoryId", "categoryName"));
        	}          
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkBidderWiseItemMapping, getBidderWiseItemMapping, tenderId, 0);
        }
        return "etender/buyer/TenderBidderWiseItemMapping";
    }

    /**
     *
     * @param tenderId
     * @param mappingType
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/buyer/tenderformsforbiddermapping/{tenderId}/{mappingType}/{enc}", method = RequestMethod.GET)
    public String displayFormsForBidderMapping(@PathVariable(TENDER_ID) int tenderId, @PathVariable(MAPPING_TYPE) int mappingType,
            HttpServletRequest request, ModelMap modelMap) {
        int linkId = 0;
        int formId = 0;
        int tableId = 0;
        int tableCount = 0;
        List<Object[]> formTableList = new ArrayList<Object[]>();
        StringBuilder pageView = new StringBuilder();
        try {
            pageView.append("etender/buyer/SbItemMappingFormList");
            // Bug #33322 Jitendra. 
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            formTableList = tenderFormService.getTenderTableCountAndFormList(tenderId,4);
            modelMap.addAttribute("tenderFormLst", formTableList);
            modelMap.addAttribute("tableList", tenderFormService.getTableLstByTenderId(tenderId));
            if(!formTableList.isEmpty()) {
	            List<Object[]> lstTable = tenderFormService.getTenderTableListByFormId(Integer.parseInt(formTableList.get(0)[0].toString()));
	            tableId = !lstTable.isEmpty() ? Integer.parseInt(lstTable.get(0)[0].toString()) : 0;
	            modelMap.addAttribute("tableId", tableId);
	            if(formTableList.size() == 1) {
	                formId = Integer.parseInt(formTableList.get(0)[0].toString());
	                tableCount = Integer.parseInt(formTableList.get(0)[2].toString());
	                 pageView.delete(0, pageView.length());
	                if(tableCount > 1) {
	                    pageView.append("redirect:/etender/buyer/mapbidderformdashboard/").append(tenderId).append("/").append(formId).append("/").append(mappingType)
	                        .append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1),
	                        request));
	                } else if(tableCount == 1) {
	                    if(mappingType == 2) {
	                       pageView.append("redirect:/etender/buyer/itemwisebiddermapping/").append(tenderId).append("/").append(formId).append("/").append(tableId)
	                        .append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1),
	                        request));
	                    } else {
	                       pageView.append("redirect:/etender/buyer/bidderwiseitemmapping/").append(tenderId).append("/").append(formId).append("/").append(tableId)
	                        .append(encryptDecryptUtils.generateRedirect(pageView.substring(pageView.indexOf("/")+1),
	                        request));
	                    }
	                }
	            }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            linkId = (mappingType == 1) ? linkMapBidder : (mappingType == 3) ? linkBidderWiseItemMapping : linkItemWiseBidderMapping;
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDisplayFormsForBidderMapping, tenderId, 0);
        }
//        return "etender/buyer/SbItemMappingFormList";
        return pageView.toString();
    }

    /**
     * Use to get form dashboard
     *
     * @author VIPULP
     * @param formId
     * @param tenderId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/mapbidderformdashboard/{tenderId}/{formId}/{mappingType}/{enc}", method = RequestMethod.GET)
    public String mapBidderformDashboard(@PathVariable(FORM_ID) int formId, @PathVariable(TENDER_ID) int tenderId,
            @PathVariable(MAPPING_TYPE) int mappingType, ModelMap modelMap, HttpServletRequest request) {
        String retVal = "etender/buyer/TenderMapBidderFormDashboard";
        int linkId = 0;
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> formList = tenderFormService.getTenderFormDetails(formId);
            if (formList != null && !formList.isEmpty()) {
                modelMap.addAttribute("formName", formList.get(0)[0]);
                modelMap.addAttribute("ispricebid", formList.get(0)[9]);
                modelMap.addAttribute("cstatus", formList.get(0)[15]);
            }
            modelMap.addAttribute("tblCount",tenderFormService.getNoOfPriceBidForm(tenderId));
            modelMap.addAttribute("tableList", tenderFormService.getTenderTableList(formId));
        } catch (Exception ex) {
            retVal = exceptionHandlerService.writeLog(ex);
        } finally {
            linkId = (mappingType == 1) ? linkMapBidder : (mappingType == 3) ? linkBidderWiseItemMapping : linkItemWiseBidderMapping;
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getMapBidderformDashboard, tenderId, formId);
        }
        return retVal;
    }

    /**
     *
     * @param tenderId
     * @param modelMap
     * @param request
     * @return to view
     */
    @RequestMapping(value = "/buyer/bidderwiseitemmappingreport/{tenderId}/{enc}", method = RequestMethod.GET)
    public String bidderWiseItemMappingReport(@PathVariable(TENDER_ID) int tenderId, ModelMap modelMap, HttpServletRequest request) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("reportId", BIDDER_WISE_ITEM_MAPPING_REPORTID);
            reportGeneratorService.getReportConfigDetails(BIDDER_WISE_ITEM_MAPPING_REPORTID, modelMap);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getBidderwiseItemMappingReport, tenderId, 0);
        }
        return "etender/buyer/TenderBidderWiseItemMapReport";
    }

    /**
     *
     * @param tenderId
     * @param mapBidderId
     * @param modelMap
     * @param request
     * @return to view
     */
    @RequestMapping(value = "/buyer/bidderwiseitemmappingdetail/{tenderId}/{mapBidderId}/{enc}", method = RequestMethod.GET)
    public String bidderWiseItemMappingDetail(@PathVariable(TENDER_ID) int tenderId, @PathVariable("mapBidderId") int mapBidderId,
            ModelMap modelMap, HttpServletRequest request) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            List<Object[]> lstMapBidderTblDtls = eventBidderMapService.GetMappedBidderTableDtls(mapBidderId);

            modelMap.addAttribute("userDetls", eventBidderMapService.getUserDtlsByMappedBidderId(mapBidderId, abcUtility.getSessionClientId(request)));
            modelMap.addAttribute("mappedBidderTblLst", prepareMappedBidderTblDTO(lstMapBidderTblDtls));

        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getBidderwiseItemMappingDetail, tenderId, 0);
        }
        return "etender/buyer/TenderBidderWiseItemMapDetail";
    }

    /**
    *
    * @param mapBidderDB
    * @param lstTenderBidderMap
    * @param lstTenderMapBidderHistory
    * @param lstItemBidderMap
    * @param mappingPair
    * @param request
    * @param params
    * @throws Exception
    */
   private void prepareMapBidderDTO(TenderMapBidderDataBean mapBidderDB, List<TblTenderBidderMap> lstTenderBidderMap,
           List<TblTenderMapBidderHistory> lstTenderMapBidderHistory, List<TblItemBidderMap> lstItemBidderMap,
           StringBuilder mappingPair, HttpServletRequest request, int... params) throws Exception {
       int userDetailId = abcUtility.getSessionUserDetailId(request);
       String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
       List<Object[]> mappedBidderLst = null;
       int bidderId=0;
       TblTenderBidderMap tblTenderBidderMap =null;
       if (params[0] != 1) {
           mappedBidderLst = eventBidderMapService.getTenderBidderMap(mapBidderDB.getHdTenderId());
       }
       for (String chkBidderId : mapBidderDB.getChkBidderId()) {
    	   if(bidderId!= Integer.parseInt(chkBidderId.split("_")[2])){ 
    	   tblTenderBidderMap = new TblTenderBidderMap();
    	   }
            boolean isNew = true;
           int mapBidderId = 0;
           if (params[0] == 1 || (mappedBidderLst == null && mappedBidderLst.isEmpty())) {
        	   tblTenderBidderMap.setTblTender(new TblTender(mapBidderDB.getHdTenderId()));
               tblTenderBidderMap.setTblCompany(new TblCompany(Integer.parseInt(chkBidderId.split("_")[2])));
               tblTenderBidderMap.setTblUserLogin(new TblUserLogin(Integer.parseInt(chkBidderId.split("_")[0])));
               tblTenderBidderMap.setTblUserDetail(new TblUserDetail(Integer.parseInt(chkBidderId.split("_")[1])));
               tblTenderBidderMap.setIpAddress(ipAddress);
               tblTenderBidderMap.setCreatedBy(userDetailId);
           } else {
               for (Object[] objects : mappedBidderLst) {
            	   if(Integer.parseInt(chkBidderId.split("_")[2]) == (Integer) objects[1]){
                       mapBidderId = (Integer) objects[0];
                       isNew = false;
                       break;
            	   }
               }
               if (isNew) {
                   tblTenderBidderMap.setTblTender(new TblTender(mapBidderDB.getHdTenderId()));
                   tblTenderBidderMap.setTblCompany(new TblCompany(Integer.parseInt(chkBidderId.split("_")[2])));
                   tblTenderBidderMap.setTblUserLogin(new TblUserLogin(Integer.parseInt(chkBidderId.split("_")[0])));
                   tblTenderBidderMap.setTblUserDetail(new TblUserDetail(Integer.parseInt(chkBidderId.split("_")[1])));
                   tblTenderBidderMap.setIpAddress(ipAddress);
                   tblTenderBidderMap.setCreatedBy(userDetailId);
               }
           }

           if (params[0] != 1) {
               TblItemBidderMap tblItemBidderMap = new TblItemBidderMap();
               if (lstTenderBidderMap != null && lstTenderBidderMap.indexOf(tblTenderBidderMap) != -1) {
                   tblTenderBidderMap = lstTenderBidderMap.get(lstTenderBidderMap.indexOf(tblTenderBidderMap));
               }
               tblItemBidderMap.setTblTenderBidderMap(isNew ? tblTenderBidderMap : new TblTenderBidderMap(mapBidderId));
               tblItemBidderMap.setTblTenderTable(new TblTenderTable(mapBidderDB.getHdTableId()));
               tblItemBidderMap.setRowId(params[0] == 2 ? mapBidderDB.getHdRowId() : params[0] == 4 ? Integer.parseInt(chkBidderId.split("_")[3]) : Integer.parseInt(chkBidderId.split("_")[3]));
               tblItemBidderMap.setIpAddress(ipAddress);
               tblItemBidderMap.setCreatedBy(userDetailId);

               lstItemBidderMap.add(tblItemBidderMap);
           }

           TblTenderMapBidderHistory tblTenderMapBidderHistory = new TblTenderMapBidderHistory();
           tblTenderMapBidderHistory.setTblTender(new TblTender(mapBidderDB.getHdTenderId()));
           tblTenderMapBidderHistory.setTblUserDetail(new TblUserDetail(Integer.parseInt(chkBidderId.split("_")[1])));
           tblTenderMapBidderHistory.setCreatedBy(userDetailId);
           tblTenderMapBidderHistory.setIsMapped(1);
           tblTenderMapBidderHistory.setTblCompany(new TblCompany(Integer.parseInt(chkBidderId.split("_")[2])));

           if (params[0] == 1) {
               tblTenderMapBidderHistory.setTableId(0);
               tblTenderMapBidderHistory.setRowId(0);

               mappingPair.append("(").append(chkBidderId.split("_")[2])
                       .append(")").append(",");
           } else {
               tblTenderMapBidderHistory.setTableId(mapBidderDB.getHdTableId());
               tblTenderMapBidderHistory.setRowId(params[0] == 2 ? mapBidderDB.getHdRowId() : params[0] == 4 ? Integer.parseInt(chkBidderId.split("_")[3]) : Integer.parseInt(chkBidderId.split("_")[3]));

               mappingPair.append("(").append(chkBidderId.split("_")[2]).append(",").append(mapBidderDB.getHdTableId())
                       .append(",").append(params[0] == 2 ? mapBidderDB.getHdRowId() : params[0] == 4 ? Integer.parseInt(chkBidderId.split("_")[3]) : Integer.parseInt(chkBidderId.split("_")[3]))
                       .append(")").append(",");
           }
           if (isNew) {
               if (lstTenderBidderMap != null && !lstTenderBidderMap.contains(tblTenderBidderMap)) {
                   lstTenderBidderMap.add(tblTenderBidderMap);
               }
           }
           lstTenderMapBidderHistory.add(tblTenderMapBidderHistory);
           bidderId=Integer.parseInt(chkBidderId.split("_")[2]);
       }
   }
   
   /**
   *
   * @param mapBidderDB
   * @param lstTenderBidderMap
   * @param lstTenderMapBidderHistory
   * @param lstItemBidderMap
   * @param mappingPair
   * @param request
   * @param params
   * @throws Exception
   */
  private void prepareMapBidderDTOItemWiseEvent(TenderMapBidderDataBean mapBidderDB, List<TblTenderBidderMap> lstTenderBidderMap,
          List<TblTenderMapBidderHistory> lstTenderMapBidderHistory, List<TblItemBidderMap> lstItemBidderMap,
          StringBuilder mappingPair, HttpServletRequest request, int... params) throws Exception {
	  
      int userDetailId = abcUtility.getSessionUserDetailId(request);
      String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
      List<Object[]> mappedBidderLst = null;
      int bidderId=0;
      TblTenderBidderMap tblTenderBidderMap =null;
      if (params[0] != 1) {
          mappedBidderLst = eventBidderMapService.getTenderBidderMap(mapBidderDB.getHdTenderId());
      }
      for (String chkBidderId : mapBidderDB.getChkBidderId()) {
   	   if(bidderId!= Integer.parseInt(chkBidderId.split("_")[2])){ 
   	   tblTenderBidderMap = new TblTenderBidderMap();
   	   }
           boolean isNew = true;
          int mapBidderId = 0;
          if (params[0] == 1 || (mappedBidderLst == null || mappedBidderLst.size() == 0)) {
       	   	  tblTenderBidderMap.setTblTender(new TblTender(mapBidderDB.getHdTenderId()));
              tblTenderBidderMap.setTblCompany(new TblCompany(Integer.parseInt(chkBidderId.split("_")[2])));
              tblTenderBidderMap.setTblUserLogin(new TblUserLogin(Integer.parseInt(chkBidderId.split("_")[0])));
              tblTenderBidderMap.setTblUserDetail(new TblUserDetail(Integer.parseInt(chkBidderId.split("_")[1])));
              tblTenderBidderMap.setIpAddress(ipAddress);
              tblTenderBidderMap.setCreatedBy(userDetailId);
          } else {
              for (Object[] objects : mappedBidderLst) {
           	   if(Integer.parseInt(chkBidderId.split("_")[2]) == (Integer) objects[1]){
                      mapBidderId = (Integer) objects[0];
                      isNew = false;
                      break;
           	   }
              }
              if (isNew) {
                  tblTenderBidderMap.setTblTender(new TblTender(mapBidderDB.getHdTenderId()));
                  tblTenderBidderMap.setTblCompany(new TblCompany(Integer.parseInt(chkBidderId.split("_")[2])));
                  tblTenderBidderMap.setTblUserLogin(new TblUserLogin(Integer.parseInt(chkBidderId.split("_")[0])));
                  tblTenderBidderMap.setTblUserDetail(new TblUserDetail(Integer.parseInt(chkBidderId.split("_")[1])));
                  tblTenderBidderMap.setIpAddress(ipAddress);
                  tblTenderBidderMap.setCreatedBy(userDetailId);
              }
          }

      	   List<Object[]> list =eventBidderMapService.getTenderFormTableAllItems(mapBidderDB.getHdTenderId());
      	   if(!isNew) {
      		   eventBidderMapService.removeMappedBiddersItemWise(mapBidderId);
      	   }
       	   for (Object[] objects : list) {
	        	  for (int i = 1; i <= (Integer)objects[1]; i++) {
	        		  TblItemBidderMap tblItemBidderMap = new TblItemBidderMap();
	                  if (lstTenderBidderMap != null && lstTenderBidderMap.indexOf(tblTenderBidderMap) != -1) {
	                      tblTenderBidderMap = lstTenderBidderMap.get(lstTenderBidderMap.indexOf(tblTenderBidderMap));
	                  }
	                  tblItemBidderMap.setTblTenderBidderMap(isNew ? tblTenderBidderMap : new TblTenderBidderMap(mapBidderId));
		              tblItemBidderMap.setTblTenderTable(new TblTenderTable((Integer)objects[2]));
	                  tblItemBidderMap.setRowId(i);
	                  tblItemBidderMap.setIpAddress(ipAddress);
	                  tblItemBidderMap.setCreatedBy(userDetailId);

	                  lstItemBidderMap.add(tblItemBidderMap);
	                  
	                  TblTenderMapBidderHistory tblTenderMapBidderHistory = new TblTenderMapBidderHistory();
	                  tblTenderMapBidderHistory.setTblTender(new TblTender(mapBidderDB.getHdTenderId()));
	                  tblTenderMapBidderHistory.setTblUserDetail(new TblUserDetail(Integer.parseInt(chkBidderId.split("_")[1])));
	                  tblTenderMapBidderHistory.setCreatedBy(userDetailId);
	                  tblTenderMapBidderHistory.setIsMapped(1);
	                  tblTenderMapBidderHistory.setTblCompany(new TblCompany(Integer.parseInt(chkBidderId.split("_")[2])));
	                  tblTenderMapBidderHistory.setTableId((Integer)objects[2]);
	                  tblTenderMapBidderHistory.setRowId(i);
	                  
	                  lstTenderMapBidderHistory.add(tblTenderMapBidderHistory);
	                  
	        	  }
       	   }
       	   
	      if (params[0] == 1) {
	         mappingPair.append("(").append(chkBidderId.split("_")[2])
	                    .append(")").append(",");
	      }
	       	
          if (isNew) {
              if (lstTenderBidderMap != null && !lstTenderBidderMap.contains(tblTenderBidderMap)) {
                  lstTenderBidderMap.add(tblTenderBidderMap);
              }
          }
          
          bidderId=Integer.parseInt(chkBidderId.split("_")[2]);
      }
  }

   private void prepareUnMapBidderDTO(TenderMapBidderDataBean tenderMapBidderDataBean, HttpServletRequest request,
           List<TblTenderMapBidderHistory> lstTenderMapBidderHistory, List<Object> lstFinalSubmissionCompany, StringBuilder objId,
           StringBuilder rejObjId, int rowId,RedirectAttributes redirectAttributes) throws Exception {
       int userDetailId = abcUtility.getSessionUserDetailId(request);
       Set<String> compSet=new HashSet<String>();
       StringBuilder companyName=new StringBuilder();
       for (String chkMapBidderId : tenderMapBidderDataBean.getChkMapBidderId()) {
           
           if (!lstFinalSubmissionCompany.isEmpty() && lstFinalSubmissionCompany.contains(Integer.parseInt(chkMapBidderId.split("_")[3]))) {
               rejObjId.append("'").append(chkMapBidderId.split("_")[3]).append("'")
                       .append(",");
           } else {
           	if(tenderCommonService.isEventLive(tenderMapBidderDataBean.getHdTenderId())==1 && !tenderCommonService.isBidderAcceptTermsCondition(tenderMapBidderDataBean.getHdTenderId(), Integer.parseInt(chkMapBidderId.split("_")[3]))){
               objId.append("'").append(chkMapBidderId.split("_")[0]).append("'")
                       .append(",");
           	}else if(tenderCommonService.isEventLive(tenderMapBidderDataBean.getHdTenderId())!=1){
           		 objId.append("'").append(chkMapBidderId.split("_")[0]).append("'")
                   .append(",");
           	}else{
           		compSet.add(commonService.getField("TblCompany", "companyName", "companyId", Integer.parseInt(chkMapBidderId.split("_")[3].toString())));
           	}
               if(tenderCommonService.isBidderAcceptTermsCondition(tenderMapBidderDataBean.getHdTenderId(), Integer.parseInt(chkMapBidderId.split("_")[3]))){
               	redirectAttributes.addFlashAttribute("bidderAcceptedTerms", "bidder_has_accepted_term_cond");
               }
           	   int tenderResult = (Integer) tenderCommonService.getTenderField(tenderMapBidderDataBean.getHdTenderId(), "tenderResult");
           	   if (tenderMapBidderDataBean.getHdMappingType() == 1 && tenderResult == 2) {
            	   List<Object[]> list =eventBidderMapService.getTenderFormTableAllItems(tenderMapBidderDataBean.getHdTenderId());
              	   for (Object[] objects : list) {
    	        	  for (int i = 1; i <= (Integer)objects[1]; i++) {
    	        		  TblTenderMapBidderHistory tblTenderMapBidderHistory = new TblTenderMapBidderHistory();
    	                  tblTenderMapBidderHistory.setTblTender(new TblTender(tenderMapBidderDataBean.getHdTenderId()));
    	                  tblTenderMapBidderHistory.setTblUserDetail(new TblUserDetail(Integer.parseInt(chkMapBidderId.split("_")[1])));
    	                  tblTenderMapBidderHistory.setCreatedBy(userDetailId);
    	                  tblTenderMapBidderHistory.setIsMapped(0);
    	                  tblTenderMapBidderHistory.setTableId((Integer)objects[2]);
    	                  tblTenderMapBidderHistory.setRowId(i);
    	                  tblTenderMapBidderHistory.setTblCompany(new TblCompany(Integer.parseInt(chkMapBidderId.split("_")[3])));
    	                  
    	                  lstTenderMapBidderHistory.add(tblTenderMapBidderHistory);
    	        	  }
              	   }
               }else{
            	   TblTenderMapBidderHistory tblTenderMapBidderHistory = new TblTenderMapBidderHistory();
                   tblTenderMapBidderHistory.setTblTender(new TblTender(tenderMapBidderDataBean.getHdTenderId()));
                   tblTenderMapBidderHistory.setTblUserDetail(new TblUserDetail(Integer.parseInt(chkMapBidderId.split("_")[1])));
                   tblTenderMapBidderHistory.setCreatedBy(userDetailId);
                   tblTenderMapBidderHistory.setIsMapped(0);
                   if (tenderMapBidderDataBean.getHdMappingType() == 1) {
                       tblTenderMapBidderHistory.setTableId(0);
                       tblTenderMapBidderHistory.setRowId(0);
                   } else if (tenderMapBidderDataBean.getHdMappingType() == 2 || tenderMapBidderDataBean.getHdMappingType() == 4
                           || tenderMapBidderDataBean.getHdMappingType() == 3) {
                       tblTenderMapBidderHistory.setTableId(tenderMapBidderDataBean.getHdTableId());
                       tblTenderMapBidderHistory.setRowId(tenderMapBidderDataBean.getHdMappingType() == 2 ? tenderMapBidderDataBean.getHdRowId()
                               : tenderMapBidderDataBean.getHdMappingType() == 4 ? rowId : Integer.parseInt(chkMapBidderId.split("_")[4]));
                   }
                   tblTenderMapBidderHistory.setTblCompany(new TblCompany(Integer.parseInt(chkMapBidderId.split("_")[3])));
                   lstTenderMapBidderHistory.add(tblTenderMapBidderHistory);
               }
           }
           
       }
       if (compSet.size() > 0) {
			Iterator it = compSet.iterator();
			while (it.hasNext()) {
				if (companyName.length() > 0) {
					companyName.append(",");
				}
				companyName.append(it.next());
			}
			redirectAttributes.addFlashAttribute("acceptedTermCondCompany", companyName);
		}
   }

    /**
     *
     * @param mappedBidderTblDtlLst
     * @return {@code List<Map>}
     * @throws Exception
     */
    private List<Map> prepareMappedBidderTblDTO(List<Object[]> mappedBidderTblDtlLst) throws Exception {
        List<Map> lstMappedBidderTblDTO = new ArrayList<Map>();
        Map mappedBidderTblDtlsBucket = new HashMap();
        List mappedItemLst = new ArrayList();
        int currentTblId = 0;
        int prevTblId = 0;
        if (!mappedBidderTblDtlLst.isEmpty()) {
            for (int i = 0; i < mappedBidderTblDtlLst.size(); i++) {
                Object[] obj = mappedBidderTblDtlLst.get(i);
                boolean isLastRecord = i == (mappedBidderTblDtlLst.size() - 1);

                if (i == 0) {
                    mappedBidderTblDtlsBucket = new HashMap();
                    mappedItemLst = new ArrayList();

                    currentTblId = (Integer) mappedBidderTblDtlLst.get(i)[0];
                    prevTblId = (Integer) mappedBidderTblDtlLst.get(i)[0];
                } else {
                    currentTblId = (Integer) mappedBidderTblDtlLst.get(i)[0];
                    prevTblId = (Integer) mappedBidderTblDtlLst.get(i - 1)[0];
                }
                if (currentTblId != prevTblId) {
                    mappedBidderTblDtlsBucket.put("itemLst", mappedItemLst);
                    lstMappedBidderTblDTO.add(mappedBidderTblDtlsBucket);

                    mappedBidderTblDtlsBucket = new HashMap();
                    mappedItemLst = new ArrayList();
                }

                mappedItemLst.add(obj[1]);
                mappedBidderTblDtlsBucket.put("tableId", obj[0]);
                mappedBidderTblDtlsBucket.put("tableName", obj[2]);
                mappedBidderTblDtlsBucket.put("columnHeader", obj[3]);

                if (isLastRecord) {
                    mappedBidderTblDtlsBucket.put("itemLst", mappedItemLst);
                    lstMappedBidderTblDTO.add(mappedBidderTblDtlsBucket);
                }
            }
        }
        return lstMappedBidderTblDTO;
    }
    /**
     * 
     * @param tableId
     * @param auctionId
     * @param auctionResult
     * @param modelMap
     * @param request
     * @return ]
     * 
     */
        @RequestMapping(value = "/buyer/managemapunmaphistory/{tenderResult}/{tenderId}/{enc}", method = RequestMethod.GET)
    public String manageMapUnMapHistory(@PathVariable("tenderResult") int tenderResult, @PathVariable(TENDER_ID) int tenderId, ModelMap modelMap, HttpServletRequest request) {
        String retVal = null;
        int reportId = itemWiseMapUnMapBidderHistoryReportId;
        String remarks = null;
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            if(tenderResult == itemWiseResult) {
                reportId = itemWiseMapUnMapBidderHistoryReportId;
                remarks = getMapUnMapBidderHistoryRemarkItemwise;
            } else {
                reportId = grandTotalMapUnMapBidderHistoryReportId;
                remarks = getMapUnMapBidderHistoryRemarkGrandTotal;
            }
            modelMap.addAttribute("reportId",reportId);
            reportGeneratorService.getReportConfigDetails(reportId, modelMap);
            retVal = "/etender/buyer/MapUnMapBidderHistory";
        } catch (Exception ex) {
            retVal = exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), mapBidderLinkId, remarks, tenderId, 0);
        }
        return retVal;
    }
         
        @RequestMapping(value = "/buyer/mapunmapbidderhistoryforeitem/{tenderId}/{userDetailId}/{enc}", method = RequestMethod.GET)
    public String mapUnMapBidderHistoryForItem(@PathVariable(TENDER_ID) int tenderId, @PathVariable("userDetailId") int userDetailId, ModelMap modelMap, HttpServletRequest request) {
        String retVal = null;
        int reportId = viewItemForMapUnMapBidderHistoryReportId;
        try {
            modelMap.addAttribute("reportId", reportId);
            reportGeneratorService.getReportConfigDetails(reportId, modelMap);
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            retVal = "/etender/buyer/ViewItemOfMapUnMapBidderHistory";
        } catch (Exception ex) {
            retVal = exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), mapBidderLinkId, getMapUnMapBidderHistoryDetails, tenderId, 0);
        }
        return retVal;
    }
        
      @RequestMapping(value = "/buyer/tenderLoginReport/{tenderId}/{enc}", method = RequestMethod.GET)
    public String tenderLoginReport(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request) {
        String retVal = null;
        int reportId = loginReportId;
        try {
            modelMap.addAttribute("reportId", reportId);
            reportGeneratorService.getReportConfigDetails(reportId, modelMap);
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            retVal = "/etender/buyer/TenderLoginReport";
        } catch (Exception ex) {
            retVal = exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), loginReportLinkId, getTenderLoginReport, tenderId, 0);
        }
        return retVal;
    }
      
      @RequestMapping(value="/buyer/sendbiddermail/{tenderId}/{isWorkFlow}/{userId}/{enc}",method= RequestMethod.GET)
    public String sendBidderMail(@PathVariable("tenderId") int tenderId,@PathVariable("isWorkFlow") int isWorkFlow, @PathVariable("userId") int userId,HttpServletRequest request,RedirectAttributes redirectAttributes){
            boolean isSuccess = false;
        try {
            int brdMode = 0;
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkSendBidderMail, getSendBidderMail, tenderId, userId);
            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
            messageConfigDatabean.setQueueName(queueName);
            messageConfigDatabean.setTemplateId(Integer.parseInt(sendBidderMailTemplateId));
            messageConfigDatabean.setUserId(userId);
            messageConfigDatabean.setClientId(abcUtility.getSessionClientId(request));
            messageConfigDatabean.setObjectId(tenderId);
            messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
            messageConfigDatabean.setContextPath(request.getContextPath());
            isSuccess = messageQueueService.sendMessage(messageConfigDatabean);
            brdMode = (Integer) tenderCommonService.getTenderField(tenderId, "brdMode");
            if(brdMode == 1) {
            isSuccess = eventCreationService.inviteBidderForParticipation(tenderId, abcUtility.getSessionUserId(request), abcUtility.getSessionClientId(request), 
                        			request.getRequestURL().toString (), request.getContextPath().toString(),false,clientBean.getTimeZoneAbbr(),userId );
            }
            if(isSuccess) {
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_mail_success");
            } else {
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
            }
//            mailContentUtillity.dynamicMailGeneration(sendBidderMailTemplateId, String.valueOf(userId), String.valueOf(tenderId), null, "");
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } finally {
            if(isSuccess) {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkSendBidderMail, postSendBidderMail, tenderId, userId);
            }
        }
        return "redirect:/etender/buyer/viewmappedbidders/"+tenderId+"/"+isWorkFlow+encryptDecryptUtils.generateRedirect("etender/buyer/viewmappedbidders/"+tenderId+"/"+isWorkFlow, request);
    }
}
