package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderBidOpenSign;

import java.util.List;

public interface TblTenderBidOpenSignDao  {

    public void addTblTenderBidOpenSign(TblTenderBidOpenSign tblTenderBidOpenSign);

    public void deleteTblTenderBidOpenSign(TblTenderBidOpenSign tblTenderBidOpenSign);

    public void updateTblTenderBidOpenSign(TblTenderBidOpenSign tblTenderBidOpenSign);

    public List<TblTenderBidOpenSign> getAllTblTenderBidOpenSign();

    public List<TblTenderBidOpenSign> findTblTenderBidOpenSign(Object... values) throws Exception;

    public List<TblTenderBidOpenSign> findByCountTblTenderBidOpenSign(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderBidOpenSignCount();

    public void saveUpdateAllTblTenderBidOpenSign(List<TblTenderBidOpenSign> tblTenderBidOpenSigns);
}