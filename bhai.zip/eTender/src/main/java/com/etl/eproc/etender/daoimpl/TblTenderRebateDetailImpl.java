package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderRebateDetailDao;
import com.etl.eproc.etender.model.TblTenderRebateDetail;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderRebateDetailImpl extends AbcAbstractClass<TblTenderRebateDetail> implements TblTenderRebateDetailDao {


    @Override
    public void addTblTenderRebateDetail(TblTenderRebateDetail tblTenderRebateDetail){
        super.addEntity(tblTenderRebateDetail);
    }

    @Override
    public void deleteTblTenderRebateDetail(TblTenderRebateDetail tblTenderRebateDetail) {
        super.deleteEntity(tblTenderRebateDetail);
    }

    @Override
    public void updateTblTenderRebateDetail(TblTenderRebateDetail tblTenderRebateDetail) {
        super.updateEntity(tblTenderRebateDetail);
    }

    @Override
    public List<TblTenderRebateDetail> getAllTblTenderRebateDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderRebateDetail> findTblTenderRebateDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderRebateDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderRebateDetail> findByCountTblTenderRebateDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderRebateDetail(List<TblTenderRebateDetail> tblTenderRebateDetails){
        super.updateAll(tblTenderRebateDetails);
    }
}
