package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblTenderRebate;
import com.etl.eproc.etender.daointerface.TblTenderRebateDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderRebateImpl extends AbcAbstractClass<TblTenderRebate> implements TblTenderRebateDao {


    @Override
    public void addTblTenderRebate(TblTenderRebate tblTenderRebate){
        super.addEntity(tblTenderRebate);
    }

    @Override
    public void deleteTblTenderRebate(TblTenderRebate tblTenderRebate) {
        super.deleteEntity(tblTenderRebate);
    }

    @Override
    public void updateTblTenderRebate(TblTenderRebate tblTenderRebate) {
        super.updateEntity(tblTenderRebate);
    }

    @Override
    public List<TblTenderRebate> getAllTblTenderRebate() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderRebate> findTblTenderRebate(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderRebateCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderRebate> findByCountTblTenderRebate(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderRebate(List<TblTenderRebate> tblTenderRebates){
        super.updateAll(tblTenderRebates);
    }
}
