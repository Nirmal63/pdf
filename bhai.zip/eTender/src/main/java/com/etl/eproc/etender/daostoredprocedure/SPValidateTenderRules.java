/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author shreyansh.shah
 */
@Component
public class SPValidateTenderRules extends StoredProcedure{
    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    
    private static final String SPROC_NAME = "apptender.P_ValidateTenderRules";
    
    public SPValidateTenderRules(){
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_ClientId",Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_SubModuleId",Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_OfficerId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_NewLinkId", Types.INTEGER));
    }
    
    public Map<String,Object> executeProcedure(int clientId,int tenderId,int subModuleId,int officerId) {
        Map inParams = new HashMap();
        inParams.put("@V_ClientId", clientId);
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_SubModuleId", subModuleId);
        inParams.put("@V_OfficerId",officerId);
        inParams.put("@V_NewLinkId",0);
        this.compile();
        return execute(inParams);
    }
}
