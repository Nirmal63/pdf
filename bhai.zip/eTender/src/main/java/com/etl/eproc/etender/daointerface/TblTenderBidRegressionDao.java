package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderBidRegression;
import java.util.List;

public interface TblTenderBidRegressionDao  {

    public void addTblTenderBidRegression(TblTenderBidRegression tblTenderBidRegression);

    public void deleteTblTenderBidRegression(TblTenderBidRegression tblTenderBidRegression);

    public void updateTblTenderBidRegression(TblTenderBidRegression tblTenderBidRegression);

    public List<TblTenderBidRegression> getAllTblTenderBidRegression();

    public List<TblTenderBidRegression> findTblTenderBidRegression(Object... values) throws Exception;

    public List<TblTenderBidRegression> findByCountTblTenderBidRegression(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderBidRegressionCount();

    public void saveUpdateAllTblTenderBidRegression(List<TblTenderBidRegression> tblTenderBidRegressions);
}