package com.etl.eproc.etender.daointerface;



/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TblBidDetail;

public interface TblBidDetailDao  {

    public void addTblBidDetail(TblBidDetail tblBidDetail);

    public void deleteTblBidDetail(TblBidDetail tblBidDetail);

    public void updateTblBidDetail(TblBidDetail tblBidDetail);

    public List<TblBidDetail> getAllTblBidDetail();

    public List<TblBidDetail> findTblBidDetail(Object... values) throws Exception;

    public List<TblBidDetail> findByCountTblBidDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidDetailCount();

    public void saveUpdateAllTblBidDetail(List<TblBidDetail> tblBidDetails);
}