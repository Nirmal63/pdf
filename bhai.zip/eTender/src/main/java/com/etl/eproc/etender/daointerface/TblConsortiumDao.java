/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;

/**
 *
 * @author dipal
 */

import com.etl.eproc.etender.model.TblConsortium;
import java.util.List;

public interface TblConsortiumDao  {

    public void addTblConsortium(TblConsortium tblConsortium);

    public void deleteTblConsortium(TblConsortium tblConsortium);

    public void updateTblConsortium(TblConsortium tblConsortium);

    public List<TblConsortium> getAllTblConsortium();

    public List<TblConsortium> findTblConsortium(Object... values) throws Exception;

    public List<TblConsortium> findByCountTblConsortium(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblConsortiumCount();

    public void saveUpdateAllTblConsortium(List<TblConsortium> tblConsortiums);
}
