package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblBidderApprovalHistory;
import com.etl.eproc.etender.daointerface.TblBidderApprovalHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblBidderApprovalHistoryImpl extends AbcAbstractClass<TblBidderApprovalHistory> implements TblBidderApprovalHistoryDao {

   

    @Override
    public void addTblBidderApprovalHistory(TblBidderApprovalHistory tblBidderApprovalHistory){
        super.addEntity(tblBidderApprovalHistory);
    }

    @Override
    public void deleteTblBidderApprovalHistory(TblBidderApprovalHistory tblBidderApprovalHistory) {
        super.deleteEntity(tblBidderApprovalHistory);
    }

    @Override
    public void updateTblBidderApprovalHistory(TblBidderApprovalHistory tblBidderApprovalHistory) {
        super.updateEntity(tblBidderApprovalHistory);
    }

    @Override
    public List<TblBidderApprovalHistory> getAllTblBidderApprovalHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBidderApprovalHistory> findTblBidderApprovalHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBidderApprovalHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBidderApprovalHistory> findByCountTblBidderApprovalHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBidderApprovalHistory(List<TblBidderApprovalHistory> tblBidderApprovalHistorys){
        super.updateAll(tblBidderApprovalHistorys);
    }
}
