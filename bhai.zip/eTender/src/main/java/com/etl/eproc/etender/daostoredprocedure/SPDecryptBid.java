/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author dipal
 */
@Component
public class SPDecryptBid extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderresult.P_DecryptBid";

    public SPDecryptBid() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_EnvelopeId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_FormId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_SessionUserId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_ClientId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_IpAddress", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_BidderIds", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_BidSignInsertStr", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_BidTableIds", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_FlagId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_SessionUserDetailId", Types.INTEGER));
    }


    public ArrayList<LinkedHashMap<String, Object>> executeProcedure(int tenderId, int envelopeId, int fomrId, int sessionUserId,int sessionUserDetailId, int clientId,String ipadd, String bidderIds, String bidSignInsertStr, String bidTableIds, int flag) throws Exception
    {
        Map inParams = new HashMap();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_EnvelopeId", envelopeId);
        inParams.put("@V_FormId", fomrId);
        inParams.put("@V_SessionUserId", sessionUserId);
        inParams.put("@V_ClientId", clientId);
        inParams.put("@V_IpAddress", ipadd);
        inParams.put("@V_ClientId", clientId);
        inParams.put("@V_BidderIds", bidderIds);
        inParams.put("@V_BidSignInsertStr", bidSignInsertStr);
        inParams.put("@V_BidTableIds", bidTableIds);
        inParams.put("@V_FlagId", flag);
        inParams.put("@V_SessionUserDetailId", sessionUserDetailId);
        this.compile();
        return (ArrayList<LinkedHashMap<String, Object>>) execute(inParams).get("#result-set-1");       
    }
}

