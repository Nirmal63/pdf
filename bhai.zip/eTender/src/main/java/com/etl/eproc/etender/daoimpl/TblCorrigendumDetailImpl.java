/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

/**
 *
 * @author urja.r
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.*;
import com.etl.eproc.etender.model.TblCorrigendumDetail;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository @Transactional
public class TblCorrigendumDetailImpl extends AbcAbstractClass<TblCorrigendumDetail> implements TblCorrigendumDetailDao {

  

    @Override
    public void addTblCorrigendumDetail(TblCorrigendumDetail tblCorrigendumDetail){
        super.addEntity(tblCorrigendumDetail);
    }

    @Override
    public void deleteTblCorrigendumDetail(TblCorrigendumDetail tblCorrigendumDetail) {
        super.deleteEntity(tblCorrigendumDetail);
    }

    @Override
    public void updateTblCorrigendumDetail(TblCorrigendumDetail tblCorrigendumDetail) {
        super.updateEntity(tblCorrigendumDetail);
    }

    @Override
    public List<TblCorrigendumDetail> getAllTblCorrigendumDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCorrigendumDetail> findTblCorrigendumDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCorrigendumDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCorrigendumDetail> findByCountTblCorrigendumDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCorrigendumDetail(List<TblCorrigendumDetail> tblCorrigendumDetails){
        super.updateAll(tblCorrigendumDetails);
    }

	@Override
	public void saveOrUpdateTblCorrigendumDetail(TblCorrigendumDetail tblCorrigendumDetail) {
		super.saveOrUpdateEntity(tblCorrigendumDetail);
	}
}