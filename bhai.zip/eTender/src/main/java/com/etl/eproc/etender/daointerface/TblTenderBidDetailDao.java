package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderBidDetail;

import java.util.List;

public interface TblTenderBidDetailDao  {

    public void addTblTenderBidDetail(TblTenderBidDetail tblTenderBidDetail);

    public void deleteTblTenderBidDetail(TblTenderBidDetail tblTenderBidDetail);

    public void updateTblTenderBidDetail(TblTenderBidDetail tblTenderBidDetail);

    public List<TblTenderBidDetail> getAllTblTenderBidDetail();

    public List<TblTenderBidDetail> findTblTenderBidDetail(Object... values) throws Exception;

    public List<TblTenderBidDetail> findByCountTblTenderBidDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderBidDetailCount();

    public void saveUpdateAllTblTenderBidDetail(List<TblTenderBidDetail> tblTenderBidDetails);
}