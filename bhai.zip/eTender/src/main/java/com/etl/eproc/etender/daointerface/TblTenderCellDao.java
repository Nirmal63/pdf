/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblTenderCell;
import java.util.List;

/**
 *
 * @author taher.tinwala
 */
public interface TblTenderCellDao  {

    public void addTblTenderCell(TblTenderCell tblTenderCell);

    public void deleteTblTenderCell(TblTenderCell tblTenderCell);

    public void updateTblTenderCell(TblTenderCell tblTenderCell);

    public List<TblTenderCell> getAllTblTenderCell();

    public List<TblTenderCell> findTblTenderCell(Object... values) throws Exception;

    public List<TblTenderCell> findByCountTblTenderCell(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblTenderCellCount();

    public void saveUpdateAllTblTenderCell(List<TblTenderCell> tblTenderCells);
}
