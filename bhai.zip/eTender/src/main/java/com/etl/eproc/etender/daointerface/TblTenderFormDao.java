package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderForm;
import java.util.List;

public interface TblTenderFormDao  {

    public void addTblTenderForm(TblTenderForm tblTenderForm);

    public void deleteTblTenderForm(TblTenderForm tblTenderForm);

    public void updateTblTenderForm(TblTenderForm tblTenderForm);

    public List<TblTenderForm> getAllTblTenderForm();

    public List<TblTenderForm> findTblTenderForm(Object... values) throws Exception;

    public List<TblTenderForm> findByCountTblTenderForm(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderFormCount();

    public void saveUpdateAllTblTenderForm(List<TblTenderForm> tblTenderForms);
}