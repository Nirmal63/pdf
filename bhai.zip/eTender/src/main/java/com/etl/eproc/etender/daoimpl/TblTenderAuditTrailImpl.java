package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderAuditTrailDao;
import com.etl.eproc.etender.model.TblTenderAuditTrail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderAuditTrailImpl extends AbcAbstractClass<TblTenderAuditTrail> implements TblTenderAuditTrailDao {


    @Override
    public void addTblTenderAuditTrail(TblTenderAuditTrail tblTenderAuditTrail){
        super.addEntity(tblTenderAuditTrail);
    }

    @Override
    public void deleteTblTenderAuditTrail(TblTenderAuditTrail tblTenderAuditTrail) {
        super.deleteEntity(tblTenderAuditTrail);
    }

    @Override
    public void updateTblTenderAuditTrail(TblTenderAuditTrail tblTenderAuditTrail) {
        super.updateEntity(tblTenderAuditTrail);
    }

    @Override
    public List<TblTenderAuditTrail> getAllTblTenderAuditTrail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderAuditTrail> findTblTenderAuditTrail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderAuditTrailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderAuditTrail> findByCountTblTenderAuditTrail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderAuditTrail(List<TblTenderAuditTrail> tblTenderAuditTrails){
        super.updateAll(tblTenderAuditTrails);
    }
}
