/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author purvesh
 */
@Component
public class SpBidWithdrawal extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderbid.P_BidWithdrawal";

    public SpBidWithdrawal() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_CompanyId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_BidderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_UserDetailId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_IPAddress", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_Remark", Types.VARCHAR));
    }

    public List<LinkedHashMap<String, Object>> executeProcedure(int tenderId, int companyId, int bidderId, int userDetailId, String ipAddress, String remark) throws Exception {
        Map<String, Object> inParams = new HashMap<String, Object>();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_CompanyId", companyId);
        inParams.put("@V_BidderId", bidderId);
        inParams.put("@V_UserDetailId", userDetailId);
        inParams.put("@V_IPAddress", ipAddress);
        inParams.put("@V_Remark", remark);

        this.compile();
        return (ArrayList<LinkedHashMap<String, Object>>) execute(inParams).get("#result-set-1");
    }
}
