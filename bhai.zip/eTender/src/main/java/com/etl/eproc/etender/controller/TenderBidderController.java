package com.etl.eproc.etender.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.NeftRtgsService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.model.TblCustomParameter;
import com.etl.eproc.common.model.TblEventEnquiry;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.utility.ClientBean;
import org.springframework.security.core.context.SecurityContextHolder;
import com.etl.eproc.common.services.MailBoxService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
/**
*
* @author purvesh
*/
@Controller
@RequestMapping("/etender/bidder")
public class TenderBidderController {
	
	 @Autowired
	 private ReportGeneratorService reportGeneratorService;
	 @Autowired
	 private ClientService clientService;
	 @Autowired
	 private AbcUtility abcUtility;
	 @Autowired
	 private ExceptionHandlerService exceptionHandlerService;
	 @Autowired
	 private AuditTrailService auditTrailService;
	 @Autowired
	 private NeftRtgsService neftService;
	 @Autowired
	 private MailBoxService mailBoxService; 
	 @Autowired
	 private LoginService loginService;
	 @Autowired
	 private MailContentUtillity mailContentUtillity;
	 @Autowired
	 private CommonService commonService;
	 @Autowired
	 private DepartmentUserService departmentUserService;
	 @Autowired
	 private TenderCommonService tenderCommonService;
	 @Autowired
	 private EncryptDecryptUtils encryptDecryptUtils;
	 @Value("#{etenderAuditTrailProperties['getBidderSearchTender']}")
	 private String getBidderSearchTender;
	 @Value("#{etenderAuditTrailProperties['getBidderMyTender']}")
	 private String getBidderMyTender;
	 
	 @Value("#{tenderlinkProperties['bidder_search_tender']?:277}")
	 private int bidderSearchTenderLinkId;
	 @Value("#{tenderlinkProperties['bidder_my_tenderr']?:278}")
	 private int bidderMyTenderLinkId;
	 @Value("#{linkProperties['report_tender_bidder_tender_listing']?:34}")
	 private int tenderListingReportId;
	 @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
	 private String queueName;
	 @Value("#{eauctionProperties['event_enquiry_mail']?:409}")
	 private String eventEnquiryMailTemplateId;
	 @Value("#{linkProperties['event_enq_mail']?:5554}")
	 private int eventEnqmail;

	/**
     * Method for displaying Tender Listing for bidder.
     *
     * @author purvesh
     * @param enc
     * @param map
     * @return
     */
	@RequestMapping(value = "/tenderlisting/{isMyTender}/{enc}", method = RequestMethod.GET)
	public String tenderListng(@PathVariable("isMyTender") int isMyTender,  ModelMap map, HttpServletRequest request){
		int linkId=bidderMyTenderLinkId;
		String auditTrailMessage = getBidderMyTender;
		/*Add for display reminder popup*/
    	ClientBean clientBean = null;
    	TblUserLogin tblUserLogin = null;
    	String userName = "";
    	userName = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
    	clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    	
		 try {
			 tblUserLogin = loginService.getUserLoginByLoginId(userName);
			 	if(isMyTender!=1){
			 		linkId=bidderSearchTenderLinkId;
			 		auditTrailMessage = getBidderSearchTender;
			 	}
			 	map.put("lstClientMarquee", clientService.getClientMarqueeAfterLogin((int) abcUtility.getSessionClientId(request)));/* For After Loging Marque */
	            map.addAttribute("reportId", tenderListingReportId);
	            map.addAttribute("isMyTender", isMyTender);
	            SessionBean sessionBean = request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
	        	  List<Object[]> lst = neftService.getBiderDetailForSendMail(abcUtility.getSessionClientId(request),sessionBean.getUserId());
	              List<Object[]> lstCmp = neftService.getCompanyDetailForSendMail(abcUtility.getSessionClientId(request),sessionBean.getUserId(),sessionBean.getCompanyId());
	              Object[] obj = null; 
	              String clientCode = null;
	              boolean isNeftRegister=false;
	              if(lst!=null && !lst.isEmpty()){
	                  obj = lst.get(0);
	                  //mailParams.put("paymentFor", "1".equals(obj[0].toString()) ? messageSource.getMessage("label_doc_fees", null, LocaleContextHolder.getLocale()) : messageSource.getMessage("label_emd", null, LocaleContextHolder.getLocale()));// 1 for docfees , 2 for emd
	                  map.addAttribute("paymentFor", obj[0].toString());// 1 for docfees , 2 for emd , 3 for docfees/emd
	                  map.addAttribute("tenderFor", obj[1].toString());
	                  map.addAttribute("benfAccName", obj[2].toString());
	                  map.addAttribute("benfBankBranch", obj[3].toString());
	                  map.addAttribute("benfIfscCode", obj[4].toString());
	                  map.addAttribute("deptName", obj[5].toString());
	              }
	            
	              if(lst!=null && !lst.isEmpty() && lstCmp!=null && !lstCmp.isEmpty()){
	                   for(int i =0;i<(lstCmp.size());i++){
	                	   Object [] objectCmp = lstCmp.get(i);
		                     String companyId = objectCmp[0].toString();
		                     String prefix = obj[7].toString();
	                	   //Bug #30199 In case of indusing bank
	                	   Object[] clientBnkDetail = neftService.getClientPGBank(abcUtility.getSessionClientId(request));
		                    int bankId = Integer.parseInt(clientBnkDetail[0].toString());
		                    String vendorCode = null;
		                  clientCode = neftService.getClientCode(abcUtility.getSessionClientId(request));
		                  String bidderCode="";
		                  if(bankId == 4)
	                      {
	                        bidderCode = objectCmp[0].toString();
	                        while(bidderCode.length()<=11){//Make 12-Digit Biddercode
	                        	bidderCode = "0" + bidderCode;
	                        }
	                       // vendorCode = "Z" + clientCode + "AB" +  bidderCode;
	                        vendorCode = neftService.generateVendorCode(bankId, clientCode, prefix) + bidderCode;
	                        bidderCode=vendorCode;
	                      }else{
	                    	  vendorCode = neftService.generateVendorCode(bankId, clientCode, prefix) + companyId;
	                    	  bidderCode=prefix+companyId;
	                      }
	                      String companyName = objectCmp[1].toString();
	                      map.addAttribute("clientCode", vendorCode);
	                      map.addAttribute("compName", companyName);
	                      map.addAttribute("bidderCode", bidderCode);
	                     // map.addAttribute("bidderCode", obj[7].toString()+companyId);
	                     if(Integer.parseInt(objectCmp[3].toString())>=2){
	                   		isNeftRegister=true;
	                     }
	                   }
	               }
	              map.addAttribute("availbleBal",neftService.getAvailableSecurityDeposit(sessionBean.getCompanyId(),abcUtility.getSessionClientId(request)));
	              map.addAttribute("isNeftRegister",isNeftRegister);
	            reportGeneratorService.getReportConfigDetails(tenderListingReportId, map);
	            setTaskListData(tblUserLogin.getUserId(),clientBean.getClientId(),request); /*used to display reminder pupup*/
	        } catch (Exception ex) {
	            return exceptionHandlerService.writeLog(ex);
	        } finally {
	            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrailMessage, isMyTender, 0);
	        }
	        return "/etender/common/TenderListing";
	}
	 private void setTaskListData(int userId, int clientId, HttpServletRequest request) throws Exception {
	     	String taskLists = new String();
	        String currentTask = "";
	        List<Object[]> taskListData = mailBoxService.getTaskListData(userId, clientId);
	        request.getSession().removeAttribute("taskLists");
	        request.getSession().removeAttribute("isFirstTime");
	        if(taskListData!=null && !taskListData.isEmpty()) {
	        	for(Object[] task : taskListData) {
	        		currentTask="";
	        		currentTask= task[0] +"|~|"+ task[1] +"|~|"+ task[2] +"|~|"+ CommonUtility.convertTimezoneToClientTimezone(task[3]) +"|~|"+ task[4]+"|~|"+ task[5]+"|~|"+ task[6]+ "|~|"+ CommonUtility.convertTimezoneToClientTimezone(task[7])+"|#|";

	        		taskLists+=currentTask;     
	        		  
	              		
	        	}        	        			 
	        	request.getSession().setAttribute("taskLists", taskLists);        	 	  
	        	request.getSession().setAttribute("isFirstTime", true);
	        	
	        }
	    }
	
	  @RequestMapping(value = "/ajaxcall/submitinterestalifnotexisttender", method = RequestMethod.POST)
	    @ResponseBody
	    public String interestAlreadyShown(@RequestParam("bidderId") int bidderId,@RequestParam("eventId") int eventId ,@RequestParam("moduleId") int moduleId, HttpServletRequest request , ModelMap modelMap,RedirectAttributes redirectAttributes) { 
		 	String result="";
			try {
				result = tenderCommonService.tenderInterested(bidderId,eventId,request,redirectAttributes,modelMap);
			} catch (Exception e) {
				exceptionHandlerService.writeLog(e);
			} finally {
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), eventEnqmail, "Access method for bidder inquiry.", eventId, 0);
	        }
			return result;
	    }
	  
	    @RequestMapping(value = {"/submittenderinterest/{tenderId}"} , method = RequestMethod.POST)
	    public String submitTenderInterest(HttpServletRequest request,@PathVariable("tenderId") int tenderId, ModelMap modelMap,HttpSession session,RedirectAttributes redirectAttributes) {
	    	try {
	    		tenderCommonService.tenderInterested(0,tenderId,request,redirectAttributes,modelMap);
	    	}catch(Exception e){
	    		exceptionHandlerService.writeLog(e);
	    	}finally{
	    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), eventEnqmail, "Access method for bidder inquiry.", tenderId, 0);
	    	}
	    	return "redirect:/";
	    }
}
