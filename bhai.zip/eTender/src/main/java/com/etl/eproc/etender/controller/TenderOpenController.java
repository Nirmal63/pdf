/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.databean.CRTable;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.etender.model.TblNotification;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.daointerface.TblDecryptionFailDao;
import com.etl.eproc.etender.daointerface.TblShareReportDao;
import com.etl.eproc.etender.model.TblDecryptionFail;
import com.etl.eproc.etender.model.TblDynReport;
import com.etl.eproc.common.services.NegotiationService;
import com.etl.eproc.etender.services.DynamicReportService;
import com.etl.eproc.etender.model.TblShareReport;
import com.etl.eproc.etender.model.TblShareReportDetail;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBidMatrix;
import com.etl.eproc.etender.model.TblTenderBidOpenSign;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderRebate;
import com.etl.eproc.etender.model.TblTenderRebateDetail;
import com.etl.eproc.etender.model.TblTenderReevaluation;
import com.etl.eproc.etender.model.TblTenderReport;
import com.etl.eproc.etender.model.TblTenderReportDetail;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.CommitteeFormationService;
import com.etl.eproc.etender.services.EventBidSubmissionService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderFormService;
import com.etl.eproc.etender.services.TenderOpenService;
import com.etl.eproc.etender.services.TenderReportService;

/**
 *
 * @author dipal
 */
@Controller
@RequestMapping("/etender")
public class TenderOpenController {
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private TenderReportService tenderReportService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private TenderOpenService tenderOpenService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private EventBidSubmissionService eventBidSubmissionService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private  CommitteeFormationService committeeFormationService;
    @Autowired
   	private DynamicReportService dynamicReportService;
    @Autowired
    private NegotiationService negotiationService;
    @Autowired
    private TblShareReportDao tblShareReportDao;
    
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    private static final String HIDDEN_TENDER_ID = "hdTenderId";
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    private static final String TENDER_DASHBOARD_URL = "etender/buyer/tenderdashboard/";
    
    @Value("#{tenderlinkProperties['bid_opening_individual_report']?:229}")   
    private int linkOpeningIndividaulReport;  
    @Value("#{tenderlinkProperties['bid_evaluation_individual_report']?:387}")   
    private int linkEvaluationIndividaulReport; 
    @Value("#{tenderlinkProperties['bidder_individual_report']?:393}")   
    private int linkBidderIndividaulReport; 
    
    @Value("#{tenderlinkProperties['bid_opening_comparative_report']?:230}")   
    private int linkOpeningComparativeReport;  
    @Value("#{tenderlinkProperties['negotiation_negotiation_process_invite_for_negotiation']?:602}")
    private int inviteBidderForNegotiationLinkIdTender;
    @Value("#{tenderlinkProperties['bid_evaluation_comparative_report']?:388}")   
    private int linkEvaluationComparativeReport;
    @Value("#{tenderlinkProperties['bidder_comparative_report']?:394}") 
    private int linkBidderComparativeReport;
    
    @Value("#{tenderlinkProperties['bid_opening_abstract_report']?:236}")   
    private int linkOpeningBidderWiseReport;
    @Value("#{tenderlinkProperties['bid_evaluation_abstract_report']?:389}")   
    private int linkEvaluationBidderWiseReport;
    @Value("#{tenderlinkProperties['bidder_abstract_report']?:395}")   
    private int linkBidderSideBidderWiseReport;
    @Value("#{tenderlinkProperties['negotiation_negotiation_process_invite_for_negotiation']?:602}")
    private int negotiation_negotiation_process_invite_for_negotiation;
    
    @Value("#{tenderlinkProperties['bid_opening_decrypt']?:227}")   
    private int linkBidOpeningDecrypt; 
    @Value("#{tenderlinkProperties['bid_opening_verify']?:228}")   
    private int linkBidOpeningVerify; 
    @Value("#{tenderlinkProperties['bid_opening_decrypt_rebate']?:329}")   
    private int linkRebeteOpeningDecrypt; 
    @Value("#{tenderlinkProperties['bid_evaluation_verify_bid']?:384}")   
    private int linkTenderVerifyBid; 
    
    @Autowired
    private TblDecryptionFailDao tblDecryptionFailDao;
    @Autowired
    private CommonService commonService;
    @Value("#{projectProperties['pki_enable']?:1}")   
    private int pkiEnable;
    @Value("#{projectProperties['pki_eventspecific']?:2}")   
    private int pkiEventSpecific;
    
    @Value("#{tenderlinkProperties['bid_opening_opening_report']?:232}")
    private int prepareTOCReportNameLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_evaluation_report']?:310}")
    private int prepareTECReportNameLinkId;
    @Value("#{tenderlinkProperties['bid_opening_upload']?:293}")
    private int prepareTOCReportLinkId;
    @Value("#{tenderlinkProperties['bid_opening_tocreport_consent']?:294}")
    private int prepareTOCReportConsentLinkId;
    @Value("#{tenderlinkProperties['bid_opening_tocreport_view']?:295}")
    private int viewPrepareTOCReportLinkId;
    @Value("#{tenderlinkProperties['bid_opening_pricebid_create']?:296}")
    private int createPriceBidOpeningDateLinkId;
    @Value("#{tenderlinkProperties['bid_opening_pricebid_edit']?:297}")
    private int editPriceBidOpeningDateLinkId;
    @Value("#{tenderlinkProperties['bid_opening_pricebid_view']?:298}")
    private int viewPriceBidOpeningDateLinkId;
    @Value("#{tenderlinkProperties['bid_opening_pricebid_publish']?:299}")
    private int publishPriceBidOpeningDateLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_tecreport_consent']?:312}")
    private int prepareTECReportConsentLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_tecreport_view']?:313}")
    private int viewPrepareTECReportLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_upload']?:311}")
    private int prepareTECReportLinkId;
    
    
    @Value("#{etenderAuditTrailProperties['getTenderOpeningIndividualReport']}")
    private String getTenderOpeningIndividualReport;
    @Value("#{etenderAuditTrailProperties['getTenderOpeningComparativeReport']}")
    private String getTenderOpeningComparativeReport;
    @Value("#{etenderAuditTrailProperties['getTenderOpeningBidderWiseAbstractReport']}")
    private String getTenderOpeningBidderWiseAbstractReport;
    @Value("#{etenderAuditTrailProperties['getBidDecryption']}")
    private String getBidDecryption;
    @Value("#{etenderAuditTrailProperties['getBidVerification']}")
    private String getBidVerification;
    @Value("#{etenderAuditTrailProperties['getRebateDecryption']}")
    private String getRebateDecryption;
    @Value("#{etenderAuditTrailProperties['ajaxFetchEncryptBidDetail']}")
    private String ajaxFetchEncryptBidDetail;
    @Value("#{etenderAuditTrailProperties['ajaxFetchSignBidDetail']}")
    private String ajaxFetchSignBidDetail;
    @Value("#{etenderAuditTrailProperties['ajaxFetchRebateBidDetail']}")
    private String ajaxFetchRebateBidDetail;
    @Value("#{etenderAuditTrailProperties['postBidDecryption']}")
    private String postBidDecryption;
    @Value("#{etenderAuditTrailProperties['postBidDecryptionFailed']}")
    private String postBidDecryptionFailed;
    @Value("#{etenderAuditTrailProperties['postBidVerification']}")
    private String postBidVerification;
    @Value("#{etenderAuditTrailProperties['postBidVerificationFailed']}")
    private String postBidVerificationFailed;
    @Value("#{etenderAuditTrailProperties['postRebateBidDecryption']}")
    private String postRebateBidDecryption;
    @Value("#{etenderAuditTrailProperties['postRebateBidDecryptionFailed']}")
    private String postRebateBidDecryptionFailed;
    @Value("#{etenderAuditTrailProperties['getViewConsortiumDetail']}")
    private String getViewConsortiumDetail;
    
    @Value("#{etenderAuditTrailProperties['getreportname']}")
    private String getReportName;
    @Value("#{etenderAuditTrailProperties['postreportname']}")
    private String postReportName;
    @Value("#{etenderAuditTrailProperties['getpreparetocreport']}")
    private String getPrepareTOCReport;
    @Value("#{etenderAuditTrailProperties['getpreparetecreport']}")
    private String getPrepareTECReport;
    @Value("#{etenderAuditTrailProperties['getgiveconsent']}")
    private String getGiveConsent;
    @Value("#{etenderAuditTrailProperties['postgiveconsent']}")
    private String postGiveConsent;
    @Value("#{etenderAuditTrailProperties['getviewtocreport']}")
    private String getViewTOCReport;
    @Value("#{etenderAuditTrailProperties['getviewtecreport']}")
    private String getViewTECReport;
    @Value("#{etenderAuditTrailProperties['getopeningdateconfg']}")
    private String getOpeningDateConfg;
    @Value("#{etenderAuditTrailProperties['geteditopeningdateconfg']}")
    private String getEditOpeningDateConfg;
    @Value("#{etenderAuditTrailProperties['getpublishopeningdateconfg']}")
    private String getPublishOpeningDateConfg;
    @Value("#{etenderAuditTrailProperties['getviewopeningdateconfg']}")
    private String getViewOpeningDateConfg;
    @Value("#{etenderAuditTrailProperties['postopeningdate']}")
    private String postOpeningDate;
    @Value("#{etenderAuditTrailProperties['posteditopeningdate']}")
    private String postEditOpeningDate;
    @Value("#{etenderAuditTrailProperties['postpublishopeningdate']}")
    private String postPublishOpeningDateConfg;
    @Value("#{etenderAuditTrailProperties['gettecreportname']}")
    private String getTecReportname;
    @Value("#{etenderAuditTrailProperties['posttecreportname']}")
    private String postTECReportName;
    @Value("#{etenderAuditTrailProperties['gettecgiveconsent']}")
    private String getTECGiveConsent;
    @Value("#{etenderAuditTrailProperties['posttecgiveconsent']}")
    private String postTECGiveConsent;
    @Value("#{etenderAuditTrailProperties['postTenderVerifyBid']}")
    private String postTenderVerifyBid;
    @Value("#{etenderAuditTrailProperties['postTenderResultSharing']}")
    private String postTenderResultSharing;
    @Value("#{etenderAuditTrailProperties['getDocfeeEmdDetail']}")
    private String getDocfeeEmdDetail;
    @Value("#{etenderAuditTrailProperties['ajaxEMDForfeitContent']}")
    private String ajaxEMDForfeitContent;
    @Value("#{etenderAuditTrailProperties['ajaxEMDtoPGContent']}")
    private String ajaxEMDtoPGContent;
    @Value("#{etenderAuditTrailProperties['ajaxEMDAuthorizeContent']}")
    private String ajaxEMDAuthorizeContent;
    @Value("#{etenderAuditTrailProperties['ajaxEMDReleaseContent']}")
    private String getEMDReleaseContent;
    @Value("#{etenderAuditTrailProperties['postEMDTransaction']}")
    private String postEMDTransaction;
    @Value("#{tenderlinkProperties['bid_opening_configure_result_sharing']?:400}")
    private int openConfigureResultSharingLinkId;
    @Value("#{tenderlinkProperties['bid_opening_edit_result_sharing']?:401}")
    private int openEditResultSharingLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_configure_result_sharing']?:403}")
    private int evalConfigureResultSharingLinkId;
    @Value("#{tenderlinkProperties['bid_opening_report_publish']?:3301}")
    private int bidOpeningReportPublishLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_report_publish']?:3309}")
    private int bidEvaluationReportPublishLinkId;
    @Value("#{tenderlinkProperties['bid_opening_report_upload']?:293}")
    private int bidOpeningReportUploadLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_report_upload']?:311}")
    private int bidEvaluationReportUploadLinkId;
    @Value("#{etenderAuditTrailProperties['bid_opening_report_published']}")
    private String bidOpeningReportPublished;
    @Value("#{etenderAuditTrailProperties['bid_evaluation_report_published']}")
    private String bidEvaluationReportPublished;
    @Value("#{etenderAuditTrailProperties['get_bid_opening_report_publish_page']}")
    private String getbidOpeningReportPublishPage;
    @Value("#{etenderAuditTrailProperties['get_bid_evaluation_report_publish_page']}")
    private String getbidEvaluationReportPublishPage;
    @Value("#{etenderAuditTrailProperties['getItemWiseBidSubmissionCount']}")
    private String getItemWiseBidSubmissionCount;
    @Value("#{tenderlinkProperties['upload_notification']?:3334}")
	private int upload_notificationLinkId;
    @Value("#{tenderlinkProperties['additional_notification_event']?:258}")
	private int additionalNotificationEventId;
    @Value("#{etenderAuditTrailProperties['getnotificationpageaceess']}")
    private String getnotificationpageaceess;
    @Value("#{projectProperties['doc_upload_path']}")
    private String doc_upload_path;
    @Value("#{etenderAuditTrailProperties['sendnotificationMail']}")
    private String sendnotificationMail;
    @Value("#{etenderAuditTrailProperties['getviewnotification']}")
    private String getviewnotification;
    @Value("#{etenderProperties['tender_opened_status']?:4}")
    private int TENDER_OPENED_STATUS;
    @Value("#{etenderAuditTrailProperties['getRegrettedItemsOfBidder']}")
    private String getRegrettedItemsOfBidder;
	@Value("#{clientProperties['bob_client_id']}")
	private String bobClientId;
	@Value("#{clientProperties['cgClient']}")
    private String cgClient;
	@Value("#{etenderAuditTrailProperties['getTenderCGReport2']}")
	private String getTenderCGReport2;
	@Value("#{tenderlinkProperties['cg_report_2']?:5525}")
    private int cgReport2;
	@Value("#{tenderlinkProperties['cg_report_1']?:5553}")
    private int cgReport1;
	@Value("#{etenderAuditTrailProperties['getTenderCGReport1']}")
	private String getTenderCGReport1;
    
    private static final String TENDERREPORT_TYPE= "tenderReportType";
    private static final String HDTENDERREPORT_TYPE= "hdTenderReportType";
    private static final String PUBLICKEY="publicKey";
    private static final String RESULTSET_1= "#result-set-1";
    private static final String RESULTSET_2= "#result-set-2";
    private static final String RESULTSET_3= "#result-set-3";
    private static final String RESULTSET_4= "#result-set-4";
    private static final String RESULTSET_5= "#result-set-5";
    private static final String RESULTSET_6= "#result-set-6";
    private static final String RESULTSET_7= "#result-set-7";
    private static final String RESULTSET_8= "#result-set-8";
    private static final String RESULTSET_9= "#result-set-9";
    private static final String RESULTSET_10= "#result-set-10";
    private static final String RESULTSET_11= "#result-set-11";
    private static final String RESULTSET_12= "#result-set-12";
    private static final String RESULTSET_13= "#result-set-13";
    private static final String RESULTSET_14= "#result-set-14";
    private static final String RESULTSET_15= "#result-set-15";
    
    
    /**
     * Use case: Result Sharing Of Opening process
     * @author nirav.modi
     * @param redirectAttributes
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/addtenderresultconfig", method = RequestMethod.POST)                       
    public String addTenderResultConfig(RedirectAttributes redirectAttributes, HttpServletRequest request){
    	String retVal=REDIRECT_SESSION_EXPIRED;
    	int tenderId=0;
    	int isForOpening=0;
    	int linkId=0;
    	boolean success = true;
    	String shareReport[]=null;
    	try{
    		int userId = abcUtility.getSessionUserId(request);
    		if(userId!=0){
    			tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID))?Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)):0;
    			isForOpening=StringUtils.hasLength(request.getParameter("hdIsForOpening"))?Integer.parseInt(request.getParameter("hdIsForOpening")):-1;
    			TblShareReport tblShareReport = new TblShareReport();
    			String shareDiffReports[] =null; 
    			if(isForOpening==1){//Only for Opening result configuration
    				String formIds = request.getParameter("hdFormIds");
    				if(tenderId!=0 && StringUtils.hasLength(formIds) && isForOpening!=-1){
    					tblShareReport.setCreatedBy(userId);
    					tblShareReport.setIsActive(1);
    					tblShareReport.setTblTender(new TblTender(tenderId));
        				if(formIds.length()>1 && formIds.toString().startsWith(",")){
        					formIds=formIds.substring(1,formIds.length());
        				}
        				List<TblShareReportDetail> tblShareReportDetails= new ArrayList<TblShareReportDetail>();
        				for (String formId:formIds.split(",")) {
        					if(formId.trim().equals("")){
        						continue;
        					}
        					TblShareReportDetail tblShareReportDetail= new TblShareReportDetail();
        					tblShareReportDetail.setTblTenderForm(new TblTenderForm(Integer.parseInt(formId)));
        					shareDiffReports = request.getParameterValues("chkShareReport_"+formId);
        					if(shareDiffReports!=null && shareDiffReports.length>0){
        						for(String value:shareDiffReports){
        							int reportType=Integer.parseInt(value);
        							if(reportType==1){
        								tblShareReportDetail.setShareIndividualReport(1);
        							}else if(reportType==2){
        								tblShareReportDetail.setShareComparativeReport(1);
        							}else if(reportType==3){
        								tblShareReportDetail.setShareDocument(1);
        							}
        						}
        					}
        					tblShareReportDetails.add(tblShareReportDetail);
    					}
        				shareReport= request.getParameterValues("rdShareReport");
        				if(shareReport!= null && shareReport.length>0){
        					tblShareReport.setShareReport(Integer.parseInt(shareReport[0]));
        				}
        				tblShareReport.setShowResultBeforeLogin(Integer.parseInt(request.getParameter("selShowResultBeforeLogin")));
        				if(request.getParameter("selShowL1Report")!=null && !request.getParameter("selShowL1Report").isEmpty()){
        				tblShareReport.setShowL1Report(Integer.parseInt(request.getParameter("selShowL1Report")));
        				 }
        				success=tenderOpenService.addTenderResultConfig(tblShareReport,tblShareReportDetails,true);
        				if(success){
	        				fileUploadService.approvePendingOfficerDoc(tenderId, openConfigureResultSharingLinkId);
	                  		fileUploadService.approvePendingOfficerDoc(tenderId, openEditResultSharingLinkId);
        				}
        				linkId=openConfigureResultSharingLinkId;
        				retVal=success? TENDER_DASHBOARD_URL+tenderId+"/7":TENDER_DASHBOARD_URL+tenderId+"/7";
        				retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
        			}
    			}else if(isForOpening==0 && tenderId!=0){//Only for Evaluation result configuration
    				linkId=evalConfigureResultSharingLinkId;
					tblShareReport.setIsActive(1);
					tblShareReport.setCreatedBy(userId);
					tblShareReport.setTblTender(new TblTender(tenderId));
					tblShareReport.setShowAbstractReport(0);//Currently not used
					tblShareReport.setShareBidderStatus(Integer.parseInt(request.getParameter("rdShareBidderStatus")));
					tblShareReport.setShareClarificationReport(Integer.parseInt(request.getParameter("rdShareClarificationReport")));
					tblShareReport.setShareEvaluationReport(Integer.parseInt(request.getParameter("rdShareEvaluationReport")));
					success=tenderOpenService.addTenderResultConfig(tblShareReport,null,false);
    				retVal=success? TENDER_DASHBOARD_URL+tenderId+"/8":TENDER_DASHBOARD_URL+tenderId+"/8";
    				retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    			}
    		}
    	}
    	catch(Exception ex){
    		retVal= exceptionHandlerService.writeLog(ex);
    	}
    	finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId,postTenderResultSharing,tenderId, 0);
    	}
    	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? isForOpening==1 ? Integer.parseInt(shareReport[0]) == 4 ? "msg_all_reg_bidders_update" : "msg_open_rslt_share_config" :"msg_eval_rslt_share_config" : CommonKeywords.ERROR_MSG_KEY.toString());
    	return retVal;
    }
    
    /**
     * Method use for get request of Individual Report for Tender Opening Process.
     * @author dipal
     * @param tenderId
     * @param envelopeId
     * @param formId
     * @param operation : 1: view report, 2: save as html , 3: save as word, 4:save as excel, 5:save as pdf
     * @param modelMap
     * @param request
     * @param session
     * @return  
     */
    @RequestMapping(value = {"/buyer/tenderindividualreport/{tenderId}/{envelopeId}/{formId}/{operation}/{commiteeType}/{enc}","/bidder/tenderindividualreport/{tenderId}/{envelopeId}/{formId}/{operation}/{commiteeType}/{enc}"}, method = RequestMethod.GET)
    public String showTenderOpeningIndividualReport(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("formId") int formId,@PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session,RedirectAttributes redirectAttributes) {
        String page="";  
        int linkId=linkOpeningIndividaulReport;
        Boolean showindividualreport = true;
        boolean forArchivalProcess = modelMap.get("forArchivalProcess") != null ? (Boolean) modelMap.get("forArchivalProcess") : false;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
                if(abcUtility.getSessionUserTypeId(request) == 2)
                {
                    linkId=linkBidderIndividaulReport;
                }
                else if(commiteeType != 1)
                {
                    linkId=linkEvaluationIndividaulReport;
                }
                List<Object[]> reportData=tenderOpenService.getShareReports(tenderId);
                if(abcUtility.getSessionUserTypeId(request) == 2 && (Integer)tenderCommonService.getTenderField(tenderId, "resultSharing") == 2 && (reportData != null && !reportData.isEmpty())){
            		List<Object[]> formReportsData=tenderOpenService.getShareReportDetailsByReportIdFormId((Integer)reportData.get(0)[7],formId);
            		if(formReportsData!=null && !formReportsData.isEmpty()){
            			if((Integer)reportData.get(0)[0] == 2 || (Integer)reportData.get(0)[0] == 3){
	            			if((Integer)formReportsData.get(0)[0] == 1){
	            				List<Object[]> bidderDetaillst = tenderOpenService.getParticipatedOrQualifiedBidderDetail(tenderId,abcUtility.getSessionUserId(request),envelopeId);
	            				if(bidderDetaillst != null && !bidderDetaillst.isEmpty()){
	            					if((Integer)reportData.get(0)[0] == 2 && (bidderDetaillst.get(0)[0] == null || (Byte) bidderDetaillst.get(0)[0] != 1 ))
	            						showindividualreport = false;
	            				}else {
	            					showindividualreport = false;
	            				}
	            			}else{
	            				showindividualreport = false;
	            			}
            			}else {
            				if((Integer)formReportsData.get(0)[0] != 1)
            					showindividualreport = false;
            			}
            		}
               	}
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                Map<String,Object> outMap= tenderOpenService.getIndividualReportDetail(tenderId,envelopeId,formId);
                modelMap.addAttribute("operation",operation);
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                 if((operation == 4 || operation ==3) && (request.getParameter("hdisPrintPriview")==null || request.getParameter("hdisPrintPriview").equalsIgnoreCase("0")))
                {
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender cell - Filled by Officer
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }
                    if(outMap.get(RESULTSET_5) !=null) // Tender bidder 
                    {
                        modelMap.addAttribute("lstCompanyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }
                    if(outMap.get(RESULTSET_6) !=null) // Tender bid 
                    {
                        modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                    }
                    if(outMap.get(RESULTSET_7) !=null) // Tender Form bidded multiple time 
                    {
                        modelMap.addAttribute("lstFormBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                    }
                    
                    if(outMap.get(RESULTSET_8) !=null) // Tender Table bidded multiple time by add row
                    {
                        modelMap.addAttribute("lstTableBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                    }   
                    
                    if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                    }
                    if(outMap.get(RESULTSET_10) !=null) // Upload Document details
                    {
                        modelMap.addAttribute("lstDocumentDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                    }
                    if(outMap.get(RESULTSET_12) !=null) // Tender Proxy column Details
                    {
                        modelMap.addAttribute("lstTenderProxyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_12) );
                    }
                    if(outMap.get(RESULTSET_13) !=null) // Item wise bidder Mapping Details
                    {
                        modelMap.addAttribute("lstItemWiseBidderMapDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_13) );
                    }
//                    if(outMap.get(RESULTSET_14) !=null) // Item wise bidder doc Details
//                    {
//                        modelMap.addAttribute("listItemWiseBidderDocDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_14) );
//                    } 
                    //get the itemwise doc
                     List<Object[]> itemWiseBidderDocList = tenderOpenService.getItemWiseDocMappingDetails(envelopeId,formId);
                     modelMap.addAttribute("listItemWiseBidderDocDtl",itemWiseBidderDocList);
                }
                modelMap.addAttribute("letestCstatusEncodeDecodeHistory", commonService.getLetestCstatusEncodeDecodeHistory(tenderId));
                if(showindividualreport) {
                	page = "/etender/common/TenderOpeningIndividualReport";
                }else {
                	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_not_allow_to_access");
    				page="redirect:/etender/bidder/biddingtenderdashboard/" + tenderId + "/7" + encryptDecryptUtils.generateRedirect("etender/bidder/biddingtenderdashboard/" + tenderId + "/7", request);;
                }             
            }
            else
            {
                page =  REDIRECT_SESSION_EXPIRED;
            }
        } catch (Exception e) {
        	if(forArchivalProcess) {
        		modelMap.addAttribute("Exception", e);
        	}
        	exceptionHandlerService.writeLog(e);
        } finally {
        	if(!forArchivalProcess) {
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderOpeningIndividualReport, tenderId, formId);
        	}	
        }
        return page;
    }
    
    
    /**
     * Method use for get request of Comparative Report for Tender Opening Process.
     * @author dipal
     * @param tenderId
     * @param envelopeId
     * @param formId
     * @param operation : 1: view report, 2: save as html , 3: save as word, 4:save as excel, 5:save as pdf
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */ 
    @RequestMapping(value = {"/buyer/tendercomparativereport/{tenderId}/{envelopeId}/{formId}/{operation}/{commiteeType}/{enc}","/bidder/tendercomparativereport/{tenderId}/{envelopeId}/{formId}/{operation}/{commiteeType}/{enc}"}, method = RequestMethod.GET)
    public String showTenderOpeningComparativeReport(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("formId") int formId, @PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session,RedirectAttributes redirectAttributes) {
        String page="";  
        int linkId=linkOpeningComparativeReport;
        Boolean showcomparativereport = true;
    try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
                if(abcUtility.getSessionUserTypeId(request) == 2)
                {
                    linkId=linkBidderComparativeReport;
                }
                else if(commiteeType != 1)
                {
                    linkId=linkEvaluationComparativeReport;
                }
                List<Object[]> reportData=tenderOpenService.getShareReports(tenderId);
                if(abcUtility.getSessionUserTypeId(request) == 2 && (Integer)tenderCommonService.getTenderField(tenderId, "resultSharing") == 2 && (reportData != null && !reportData.isEmpty())){
            		List<Object[]> formReportsData=tenderOpenService.getShareReportDetailsByReportIdFormId((Integer)reportData.get(0)[7],formId);
            		if(formReportsData!=null && !formReportsData.isEmpty()){
            			if((Integer)reportData.get(0)[0] == 2 || (Integer)reportData.get(0)[0] == 3){
	            			if((Integer)formReportsData.get(0)[1] == 1){
	            				List<Object[]> bidderDetaillst = tenderOpenService.getParticipatedOrQualifiedBidderDetail(tenderId,abcUtility.getSessionUserId(request),envelopeId);
	            				if(bidderDetaillst != null && !bidderDetaillst.isEmpty()){
	            					if((Integer)reportData.get(0)[0] == 2 && (bidderDetaillst.get(0)[0] == null || (Byte) bidderDetaillst.get(0)[0] != 1 ))
	            						showcomparativereport = false;
	            				}else {
	            					showcomparativereport = false;
	            				}
	            			}else{
	            				showcomparativereport = false;
	            			}
            			}else {
            				if((Integer)formReportsData.get(0)[1] != 1)
            					showcomparativereport = false;
            			}
            		}
               	}
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                Map<String,Object> outMap= tenderOpenService.getComparativeReportDetail(tenderId,envelopeId,formId);
                 modelMap.addAttribute("operation",operation);
                
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                
                List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                if(!lstClientDtls.isEmpty()){
                    modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                    modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                }
                
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender cell - Filled by Officer
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                        }
                    if(outMap.get(RESULTSET_5) !=null) // Tender bidder 
                    {
                        modelMap.addAttribute("lstCompanyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }
                    if(outMap.get(RESULTSET_6) !=null) // Tender bid 
                    {
                        modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                        
                        List<LinkedHashMap<String, Object>> lstBidDtl = (ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6);
                        Map<String,String> mapBidData = new HashMap<String, String>();
                        for (LinkedHashMap<String, Object> bidDtl : lstBidDtl) {
                            mapBidData.put(bidDtl.get("bidderId")+"_"+bidDtl.get("tableId")+"_"+bidDtl.get("columnId")+"_"+bidDtl.get("rowId"), bidDtl.get("cellValue").toString());
                        }
                        modelMap.addAttribute("mapBidData",mapBidData);
                        modelMap.addAttribute("lstBidDtl",lstBidDtl);
                    }
                    if(outMap.get(RESULTSET_7) !=null) // Tender Form bidded multiple time 
                    {
                        modelMap.addAttribute("lstFormBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                    }
                    
                    if(outMap.get(RESULTSET_8) !=null) // Tender Table bidded multiple time by add row
                    {
                        modelMap.addAttribute("lstTableBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                    }   
                    
                    if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                    }
                    if(outMap.get(RESULTSET_10) !=null) // Item wise bidder Mapping Details
                    {
                        //modelMap.addAttribute("lstItemWiseBidderMapDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_11) );
                        modelMap.addAttribute("lstMultiTableRowCount",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                    }
                    if(outMap.get(RESULTSET_11) !=null) // Tender Proxy column Details
                    {
                        modelMap.addAttribute("lstTenderProxyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_11) );
                    }
                }
                if(showcomparativereport) {
                	page = "/etender/common/TenderOpeningComparativeReport";
                }else {
                	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_not_allow_to_access");
    				page="redirect:/etender/bidder/biddingtenderdashboard/" + tenderId + "/7" + encryptDecryptUtils.generateRedirect("etender/bidder/biddingtenderdashboard/" + tenderId + "/7", request);;
                } 	
            }
            else
            {
                page =  REDIRECT_SESSION_EXPIRED;
            }
    } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
    } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderOpeningComparativeReport, tenderId, formId);
    }
        return page;
    }
    /**
     * Method use for get request of Comparative Report for Tender Opening Process.
     * @author heeral.soni
     * @param tenderId
     * @param envelopeId
     * @param formId
     * @param operation : 1: view report, 2: save as html , 3: save as word, 4:save as excel, 5:save as pdf
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */ 
    @RequestMapping(value = {"/buyer/tenderverticalcomparativereport/{tenderId}/{envelopeId}/{formId}/{operation}/{commiteeType}/{enc}","/bidder/tenderverticalcomparativereport/{tenderId}/{envelopeId}/{formId}/{operation}/{commiteeType}/{enc}"}, method = RequestMethod.GET)
    public String showTenderOpeningVerticalComparativeReport(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("formId") int formId, @PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        int linkId=linkOpeningComparativeReport;
        boolean forArchivalProcess = modelMap.get("forArchivalProcess") != null ? (Boolean) modelMap.get("forArchivalProcess") : false;
    try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
                if(abcUtility.getSessionUserTypeId(request) == 2)
                {
                    linkId=linkBidderComparativeReport;
                }
                else if(commiteeType != 1)
                {
                    linkId=linkEvaluationComparativeReport;
                }
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        		//Map<String,Object> outMap= tenderOpenService.getComparativeReportDetail(tenderId,envelopeId,formId); (Duplication SP apptenderresult.P_TenderOpeningReport Call Commented by Vivek in code review)
                 modelMap.addAttribute("operation",operation);
                
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                
                List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                if(!lstClientDtls.isEmpty()){
                    modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                    modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                }
                setReportDetails(tenderId,envelopeId,formId,modelMap);
                page = "/etender/common/TenderComparativeReport";
            }
            else
            {
                page =  REDIRECT_SESSION_EXPIRED;
            }
	    } catch (Exception e) {
	            exceptionHandlerService.writeLog(e);
	            if(forArchivalProcess) {
	            	modelMap.addAttribute("Exception", e);
	            }
	    } finally {
	    	if(!forArchivalProcess) { 
	    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderOpeningComparativeReport, tenderId, formId);
	    	}	
	    }
	        return page;
	}
    
    /**
     * used to set report details
     * @author Lipi Shah
     * @return 
     */ 
    private void setReportDetails(int tenderId,int envelopeId,int formId, ModelMap modelMap) throws Exception{
    	Map<String,Object> outMap= tenderOpenService.getComparativeReportDetail(tenderId,envelopeId,formId);
    	if(outMap != null && !outMap.isEmpty())
        {
            if(outMap.get(RESULTSET_1) !=null) // Tender Form
            {
                modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
            }
            if(outMap.get(RESULTSET_2) !=null) // Tender Table
            {
                modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
            }
            if(outMap.get(RESULTSET_3) !=null) // Tender Column
            {
                modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
            }
            if(outMap.get(RESULTSET_4) !=null) // Tender cell - Filled by Officer
            {
                modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
            }
            if(outMap.get(RESULTSET_5) !=null) // Tender bidder 
            {
                modelMap.addAttribute("lstCompanyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
            }
            if(outMap.get(RESULTSET_6) !=null) // Tender bid 
            {
                List<LinkedHashMap<String, Object>> lstBidDtl = (ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6);
                
                Map<String,String> mapBidData = new HashMap<String, String>();
                for (LinkedHashMap<String, Object> bidDtl : lstBidDtl) {
                    mapBidData.put(bidDtl.get("bidderId")+"_"+bidDtl.get("tableId")+"_"+bidDtl.get("columnId")+"_"+bidDtl.get("rowId"), bidDtl.get("cellValue").toString());
                }
                modelMap.addAttribute("mapBidData",mapBidData);
                modelMap.addAttribute("lstBidDtl",lstBidDtl);
                
                Map<String,String> mapBidMultiFillData = new HashMap<String, String>();
                Map<String,String> mapBidRowDetail = new HashMap<String, String>();
                for (LinkedHashMap<String, Object> multiFillBidDtl : lstBidDtl) {
                    mapBidMultiFillData.put(multiFillBidDtl.get("bidderId")+"_"+multiFillBidDtl.get("tableId")+"_"+multiFillBidDtl.get("columnId")+"_"+multiFillBidDtl.get("rowId")+"_"+multiFillBidDtl.get("bidTableId"), multiFillBidDtl.get("cellValue").toString());
                    mapBidRowDetail.put(multiFillBidDtl.get("bidderId")+"_"+multiFillBidDtl.get("tableId")+"_"+multiFillBidDtl.get("columnId")+"_"+multiFillBidDtl.get("rowId")+"_"+multiFillBidDtl.get("bidTableId"),multiFillBidDtl.get("rowId").toString());
                }
                modelMap.addAttribute("mapBidMultiFillData",mapBidMultiFillData);
                modelMap.addAttribute("mapBidRowDetail",mapBidRowDetail); // #26166 Resolve UI Issue in Multiple Filling Case
                modelMap.addAttribute("lstMultiFillBidDtl",lstBidDtl);
            }
            if(outMap.get(RESULTSET_7) !=null) // Tender Form bidded multiple time 
            {
                modelMap.addAttribute("lstFormBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
            }
            
            if(outMap.get(RESULTSET_8) !=null) // Tender Table bidded multiple time by add row
            {
                modelMap.addAttribute("lstTableBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
            }   
            
            if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
            {
                modelMap.addAttribute("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
            }
            if(outMap.get(RESULTSET_10) !=null) // Item wise bidder Mapping Details
            {
                modelMap.addAttribute("lstMultiTableRowCount",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
            }
            if(outMap.get(RESULTSET_11) !=null) // Tender Proxy column Details
            {
                modelMap.addAttribute("lstTenderProxyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_11) );
            }
            /*if(outMap.get(RESULTSET_11) !=null) // Item wise bidder Mapping Details
            {
                modelMap.addAttribute("lstItemWiseBidderMapDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_11) );
            }*/
        }
    }
    /**
     * Method use for get request of Comparative Report Column Wise for Tender Opening Process.
     * @author Lipi Shah
     * @param operation : 1: view report, 2: save as html , 3: save as word, 4:save as excel, 5:save as pdf
     * @return 
     */ 
    @RequestMapping(value = {"/buyer/tendercompcolumnwisereport/{tenderId}/{envelopeId}/{formId}/{operation}/{commiteeType}/{enc}",
    		"/bidder/tendercompcolumnwisereport/{tenderId}/{envelopeId}/{formId}/{operation}/{commiteeType}/{enc}"}, method = RequestMethod.GET)
    public String tenderCompColumnWiseReport(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("formId") int formId, @PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
                tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                modelMap.addAttribute("operation",operation);
                setReportDetails(tenderId,envelopeId,formId,modelMap);
                page = "/etender/common/TenderCompColumnWiseReport";
            }
            else{
                page =  REDIRECT_SESSION_EXPIRED;
            }
	    } catch (Exception e) {
	            exceptionHandlerService.writeLog(e);
	    } finally {
//	            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderOpeningComparativeReport, tenderId, formId);
	    }
	        return page;
	}
    
    /**
     * Method use for get request of Bidder wise abstract Report for Tender Opening Process.
     * @author dipal
     * @param tenderId
     * @param envelopeId
     * @param formId
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */ 
    @RequestMapping(value = {"/buyer/bidderwisereport/{tenderId}/{envelopeId}/{flag}/{operation}/{bidderConsId}/{commiteeType}/{enc}","/bidder/bidderwisereport/{tenderId}/{envelopeId}/{flag}/{operation}/{bidderConsId}/{commiteeType}/{enc}"}, method = RequestMethod.GET)
    public String showBidderWiseAbstractReport(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("flag") int flag,@PathVariable("operation") int operation, @PathVariable("bidderConsId") String bidderConsId, @PathVariable("commiteeType") int commiteeType,ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        int bidderId = 0;
        int consortiumId =0;
        int linkId=linkOpeningBidderWiseReport;
    try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
                if(abcUtility.getSessionUserTypeId(request) == 2)
                {
                    linkId=linkBidderSideBidderWiseReport;
                }
                else if(commiteeType != 1)
                {
                    linkId=linkEvaluationBidderWiseReport;
                }
                tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                modelMap.addAttribute("operation",operation);
                modelMap.addAttribute("bidderId",bidderConsId);
                modelMap.addAttribute("isItemWiseDocAllowed", tenderCommonService.isItemWiseDocAllowedEnvWise(tenderId,envelopeId));
                if(flag == 1) // consortium type
                {
                   consortiumId = Integer.parseInt(encryptDecryptUtils.decrypt(bidderConsId));
                   //modelMap.addAttribute("individualParticipation", eventBidSubmissionService.getSecondaryPartnerRequest(tenderId,consortiumId).size());
                }
                else
                {
                   bidderId = Integer.parseInt(encryptDecryptUtils.decrypt(bidderConsId));
                }
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                 if(operation == 2 && (request.getParameter("hdisPrintPriview")==null || request.getParameter("hdisPrintPriview").equalsIgnoreCase("0")))
                {
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
                Map<String,Object> outMap= tenderOpenService.getBidderWiseReportDetail(tenderId,envelopeId,bidderId,consortiumId);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender cell - Filled by Officer
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }
                    if(outMap.get(RESULTSET_5) !=null) // Tender bidder 
                    {
                        modelMap.addAttribute("lstCompanyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }
                    if(outMap.get(RESULTSET_6) !=null) // Tender bid 
                    {
                        modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                    }
                     if(outMap.get(RESULTSET_7) !=null) // Tender Form bidded multiple time 
                    {
                        modelMap.addAttribute("lstFormBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                        for (LinkedHashMap<String, Object> multiFillBidDtl : (ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7)) {
                            if(tenderFormService.getCountofActiveForm(Integer.parseInt(multiFillBidDtl.get("tenderId").toString()),Integer.parseInt(multiFillBidDtl.get("envelopeId").toString()),Integer.parseInt(multiFillBidDtl.get("bidderId").toString()))==0){
                            	modelMap.addAttribute("isCancelForm",1 );
                            }
                        }
                    }
                    
                    if(outMap.get(RESULTSET_8) !=null) // Tender Table bidded multiple time by add row
                    {
                        modelMap.addAttribute("lstTableBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                    }   
                    
                    if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                    }
                    if(outMap.get(RESULTSET_10) !=null) // Upload Document details
                    {
                        modelMap.addAttribute("lstDocumentDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                    }
                    if(outMap.get(RESULTSET_12) !=null) // Tender Proxy column Details
                    {
                        modelMap.addAttribute("lstTenderProxyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_12) );
                    }
                    if(outMap.get(RESULTSET_13) !=null) // Item wise bidder Mapping Details
                    {
                        modelMap.addAttribute("lstItemWiseBidderMapDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_13) );
                    }
                    if(outMap.get(RESULTSET_14) !=null) // Item wise bidder doc Details
                    {
                        modelMap.addAttribute("listItemWiseBidderDocDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_14) );
                    }
                }
                List<String> formTableBidderIdList = new ArrayList<String>();
                if(flag == 1) // consortium type
                {
                	List<Object> bidderIds = tenderCommonService.getTenderBidderIdByConsoritumId(consortiumId);
                	if(bidderIds!=null && !bidderIds.isEmpty()){
                		for(Object bidderIdObj : bidderIds){
                			bidderId = Integer.valueOf(bidderIdObj.toString());
                			List<String> formTableIdList=tenderCommonService.getTenderFormIdTableIdByTenderAndBidderId(tenderId,bidderId);

            				if(formTableIdList!=null && !formTableIdList.isEmpty()){
            				 for(int formCtr=0;formCtr<formTableIdList.size();formCtr++){
            					 formTableBidderIdList.add(formTableIdList.get(formCtr)+"_"+bidderId);
            	        	  }
            				 }
                		}
                	}
                }
                else{
				List<String> formTableIdList=tenderCommonService.getTenderFormIdTableIdByTenderAndBidderId(tenderId,bidderId);

				if(formTableIdList!=null && !formTableIdList.isEmpty()){
				 for(int formCtr=0;formCtr<formTableIdList.size();formCtr++){
					 formTableBidderIdList.add(formTableIdList.get(formCtr)+"_"+bidderId);
	        	  }
				 }
				}
				modelMap.addAttribute("formTableBidderIdList",formTableBidderIdList);
                
                page = "/etender/common/TenderOpeningBiderWiseReport";
            }
            else
            {
                page =  REDIRECT_SESSION_EXPIRED;
            }
    } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
    } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderOpeningBidderWiseAbstractReport, tenderId, bidderId);
    }
        return page;
    }

     /**
     * Method use to get Bidder list for decrypt Bid Data.
     * @author dipal
     * @param tenderId 
     * @param envelopeId
     * @param formId [In case of rebete it contains rebeteId instead of formId]
     * @param enc
     * @param model
     * @param httpSession
     * @param req
     * @return Return Decrypt Bidder page.
     */
    @RequestMapping(value = {"/buyer/getUserListForDecryptBid/{tenderId}/{envelopeId}/{formId}/{enc}","/buyer/getUserListForVerifyBid/{tenderId}/{envelopeId}/{formId}/{enc}","/buyer/getUserListForDecryptRebete/{tenderId}/{envelopeId}/{formId}/{enc}","/buyer/getUserListForVerifyRebete/{tenderId}/{envelopeId}/{formId}/{enc}"}, method = RequestMethod.GET)
    public String showUserListForDecryptBid(@PathVariable("tenderId") int tenderId, @PathVariable("envelopeId") int envelopeId,@PathVariable("formId") int formId, ModelMap model, HttpSession httpSession,HttpServletRequest req,RedirectAttributes redAtt)
    {
        /*
         * @Variable: Operation : 1 = Decrypt bid, 2 = Verify bid, 3 = Decrypt Rebet Bid, 4 = Verify Rebet Bid
         */
        int operation=0;
        int linkId=0;
        int bidderCount=0;
        String auditAction=getBidDecryption;
        if(req.getRequestURI().contains("getUserListForVerifyBid"))
        {
            operation=2;
            linkId=linkBidOpeningVerify;
            auditAction=getBidVerification;
            model.addAttribute("isVerification",true);
                   
        }
        else if(req.getRequestURI().contains("getUserListForDecryptRebete"))
        {
            operation=3;
            linkId=linkRebeteOpeningDecrypt;
            auditAction=getRebateDecryption;
        }
        else if(req.getRequestURI().contains("getUserListForVerifyRebete"))
        {
            operation=4;
            linkId=linkRebeteOpeningDecrypt;
            auditAction=getRebateDecryption;
            model.addAttribute("isVerification",true);
        }
        else
        {
            operation=1;
            linkId=linkBidOpeningDecrypt;
            model.addAttribute("isDecryptionReq", 1);
        }
        model.addAttribute("operation",operation);
        String page=REDIRECT_SESSION_EXPIRED;  
        boolean isCertiFound=true;
       
        if(model.get("msg")!=null)
        {
            redAtt.addFlashAttribute("msg",model.get("msg"));
        }
        try 
        {
            //page = encryptDecryptBid(tenderId,envelopeId,formId,isCertiFound,operation,model,httpSession,req,page);
            SessionBean sessionBean = (SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
            if(sessionBean !=null)
            {
                tenderCommonService.tenderSummary(tenderId, model, abcUtility.getSessionClientId(req));
                int userId = sessionBean.getUserId();
                Object objCertiReq=tenderCommonService.getTenderField(tenderId,"isCertRequired");
                int isCertRequired=(objCertiReq !=null)?(Integer)objCertiReq:0;
                int isDomainPKI=abcUtility.getSessionIsPkiEnabled(req);
                // GET PUBLIC KEY LOGIC
                if(isDomainPKI == pkiEnable)
                {
                    model.addAttribute("bidpkey", tenderOpenService.getTenderPublicKey(tenderId,userId));
                    model.addAttribute("isPkRequired",true);
                }
                else if (isDomainPKI == pkiEventSpecific && isCertRequired == 1) 
                {
                    if (!sessionBean.isEventSpecVerify()) 
                    {
                        isCertiFound = false;
                        if(operation == 2) /* verification */
                        {
                            page="common/buyer/attacheventspeccerti/etender,buyer,getUserListForVerifyBid,"+tenderId+","+envelopeId+","+formId;
                        }
                        if(operation == 3) /* Rebete Decrypt */
                        {
                            page="common/buyer/attacheventspeccerti/etender,buyer,getUserListForDecryptRebete,"+tenderId+","+envelopeId+","+formId;
                        }
                        if(operation == 4)
                        {
                            page="common/buyer/attacheventspeccerti/etender,buyer,getUserListForVerifyRebete,"+tenderId+","+envelopeId+","+formId;
                        }
                        else /* Bid Decrypt */
                        {
                            page="common/buyer/attacheventspeccerti/etender,buyer,getUserListForDecryptBid,"+tenderId+","+envelopeId+","+formId;
                        }
                    } 
                    else 
                    {
                        model.addAttribute("bidpkey", tenderOpenService.getTenderPublicKey(tenderId,userId));
                        model.addAttribute("isPkRequired",true);
                    }
                }
                
                if(isCertiFound)
                {
                    Map<String,Object> outMap = null;
                    if(operation == 2) /* verification */
                    {
                        outMap=tenderOpenService.getUserListForDecryptVerifyBid(tenderId,envelopeId,formId,userId,2,0);                
                    }
                    else if(operation == 3 || operation == 4) /* Rebete Decrypt / Verify */
                    {
                        outMap=tenderOpenService.getUserListForDecryptVerifyBid(tenderId,envelopeId,0,userId,0,formId);                
                    }
                    else /* Bid Decrypt */
                    {
                        outMap=tenderOpenService.getUserListForDecryptVerifyBid(tenderId,envelopeId,formId,userId,0,0);                
                    }
                    if(outMap !=null && !outMap.isEmpty() && outMap.get(RESULTSET_1) !=null)
                    {
                        if(outMap.get(RESULTSET_2) !=null)
                        {
                            model.addAttribute("tblTenderDetail",((ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2)).get(0));
                        }
                        ArrayList<LinkedHashMap<String, Object>> lst = (ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1);
                        bidderCount = lst.size();
                        model.addAttribute("lstUserDecrypt", lst);
                    }
                    page =  "etender/buyer/TenderOpeningDecryptBid";
                }// End of IF(isCertiFound)
                else
                {
                        page="redirect:/"+page+ encryptDecryptUtils.generateRedirect(page, req);
                }
//                
            } //END of is sessionexpired
            else
            {
                page =  REDIRECT_SESSION_EXPIRED;
            }
            
        } catch (Exception ex) {
            return  exceptionHandlerService.writeLog(ex);
        }
        finally{
            auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditAction, tenderId, formId);
        }
        return page;
    }
           
    /**
     * Method use to get Bidder encrypt bid detail for decrypt bid.
     * @author dipal
     * @param request
     * @param response
     * @param model
     * @return to Redirect to Decrypt Bidder Page
     */
    @RequestMapping(value = {"/buyer/ajax/getUserEncryptBidDtl/{from}","/buyer/ajax/getUserDetailstForVerifyBid/{from}","/buyer/ajax/getUserDetailstForRebeteDecryptBid/{from}"}, method = RequestMethod.POST) 
    public String getUserEncryptBidDtl(@PathVariable("from") int from,HttpServletRequest request,ModelMap model) 
    {
        String page = "etender/buyer/TenderOpeningBidderEncryptData";
        String auditAuction=ajaxFetchEncryptBidDetail;
        boolean isVerification=false;
        int linkId=0;
        int operation = 0;
        String str[]=null;
        if (request.getRequestURI().contains("getUserDetailstForVerifyBid")) {
            isVerification = true;
            operation = 2;
            linkId = linkBidOpeningVerify;
            auditAuction = ajaxFetchSignBidDetail;
        }
        else if (request.getRequestURI().contains("getUserDetailstForRebeteDecryptBid")) {
            operation = 3;
            linkId = linkRebeteOpeningDecrypt;
            auditAuction = ajaxFetchRebateBidDetail;
        }
        else {
            operation = 1;
            linkId = linkBidOpeningDecrypt;
            model.addAttribute("isDecryptionReq", 1);
        }
        model.addAttribute("operation",operation);
        model.addAttribute("from",from);
        if(request.getParameter("hdUserIdList[]")!=null)
        {
            str=request.getParameterValues("hdUserIdList[]");
        }
        
        int tenderId=StringUtils.hasLength("hdTenderId")?Integer.parseInt(request.getParameter("hdTenderId")):0;
        int envelopeId=StringUtils.hasLength("hdEnvelopeId")?Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
        int formId=StringUtils.hasLength("hdFormId")?Integer.parseInt(request.getParameter("hdFormId")):0;
        
        String userIdList="";
        try
        { 
            if (abcUtility.getSessionUserId(request) != 0)
            {
                int i=0;
                for(String ob: str)
                {
                    if(i != 0)
                    {
                        userIdList=userIdList+", "+ob;
                    }
                    else
                    {
                        userIdList=userIdList+ob;
                    }
                    i++;
                }
            
                int userId = abcUtility.getSessionUserId(request);
                model.addAttribute("tenderId",tenderId);
                model.addAttribute("envelopeId",envelopeId);
                model.addAttribute("formId",formId);
                model.addAttribute("userIdList",userIdList);
                model.addAttribute("isVerification",isVerification);
                Map<String,Object> outMap = null;
                if(operation == 3) /* Rebete Decrypt */
                {
                    outMap=tenderOpenService.getBidderBidDetailForDecryptVerifyBid(tenderId, envelopeId, 0,userId,userIdList,1,formId);
                }
                else if(operation == 2) /* verification */
                {
                    outMap=tenderOpenService.getBidderBidDetailForDecryptVerifyBid(tenderId, envelopeId, formId,userId,userIdList,3,0);
                }
                else /* Decrypt Bid */
                {
                   outMap=tenderOpenService.getBidderBidDetailForDecryptVerifyBid(tenderId, envelopeId, formId,userId,userIdList,1,0);
                }
                if(outMap !=null && !outMap.isEmpty() && outMap.get(RESULTSET_1) !=null)
                {
                    List<LinkedHashMap<String, Object>> lst=(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1);
                    if(lst!=null && !lst.isEmpty())
                    {
                        for(LinkedHashMap<String,Object> ob:lst)
                        {
                            ob.put("bidJson",ob.get("bidJson").toString().replaceAll("\"", "&quot;"));
                        }
                    }
                    model.addAttribute("lstUserEncryptData",lst);
                    boolean deleteSuccess= false;
              		TblTenderEnvelope tbltenderEnvelope = tenderFormService.getTblTenderEnvelopeByTenderIdEnvelopeId(tenderId,envelopeId);
              		List<Integer> reportIdLst = new ArrayList<Integer>();
              		int isReEvaluationReq=Integer.valueOf(tenderCommonService.getTenderField(tenderId, "isReEvaluationReq").toString());
              		if(tbltenderEnvelope!=null ){
                 		if(isReEvaluationReq==1){
                 			List<TblDynReport> dynReports = dynamicReportService.getDynReport(tenderId);
                 			int isNegotiationClosed=  negotiationService.isNegotiationClosed(tenderId,negotiation_negotiation_process_invite_for_negotiation);
                 			 if(dynReports!=null && !dynReports.isEmpty()){
   	   	                         for (TblDynReport tblDynReport : dynReports) {
   	   	                        	 if(tblDynReport.getReportOn()==1 || tblDynReport.getReportOn()==2 || tblDynReport.getReportOn()==6){
   	   	                        		 reportIdLst.add(tblDynReport.getReportId());
   	   	                        	 }
   	   	                        	 if(isNegotiationClosed==1 && (tblDynReport.getReportOn()==3 || tblDynReport.getReportOn()==4)){
   	   	                        		reportIdLst.add(tblDynReport.getReportId());
   	   	                        	 }
   	   							 }
                            }
                 			deleteSuccess =  dynamicReportService.deleteTblDynReportCellId(reportIdLst);
                 			if(isNegotiationClosed==1){
                 				negotiationService.updateNegotiationProcessNotRequired(tenderId, inviteBidderForNegotiationLinkIdTender,1);
                 				negotiationService.deleteNegotiationProcess(tenderId,inviteBidderForNegotiationLinkIdTender,0);
                 				negotiationService.deleteNegotiationResult(tenderId);
                 			}
                 		}
              		}
                    
                }
            }
            else
            {
                 page =  REDIRECT_SESSION_EXPIRED;
            }
            
        }
        catch (Exception ex) 
        {
            return  exceptionHandlerService.writeLog(ex);
        }
        finally{
           auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditAuction, tenderId, formId);
        }
        return page;
    }
    
    /**
     * Method use to store decrypted data in Tbl_RndConfirmation table. And recalculate BAR.
     * @author dipal
     * @param request
     * @param response
     * @param model
     * @return to Redirect to Decrypt Bidder Page
     */
    @RequestMapping(value = {"/buyer/submitDecryptedBidderData","/buyer/submitVerifiedBidderData","/buyer/submitDecryptedRebateData"}, method = RequestMethod.POST) 
    public String submitDecryptedBidderData(HttpServletRequest request, ModelMap model,HttpSession httpSession,RedirectAttributes redirectAttributes) 
    {
        String redirectUrl="/sessionexpired";
        int operation = 1;
        String auditAction=postBidDecryption;
        boolean isVerification=false;
        int linkId=linkBidOpeningDecrypt;
       
        int tenderId=StringUtils.hasLength("hdTenderId")?Integer.parseInt(request.getParameter("hdTenderId")):0;
        int envelopeId=StringUtils.hasLength("hdEnvelopeId")?Integer.parseInt(request.getParameter("hdEnvelopeId")):0;
        int formId=StringUtils.hasLength("hdFormId")?Integer.parseInt(request.getParameter("hdFormId")):0;
        int from=StringUtils.hasLength("hiddenFrom")?Integer.parseInt(request.getParameter("hiddenFrom")):0;
        
        if (request.getRequestURI().contains("submitVerifiedBidderData")) 
        {
                operation = 2;
                linkId = linkBidOpeningVerify;
                redirectUrl="etender/buyer/getUserListForVerifyBid/"+tenderId+"/"+envelopeId+"/"+formId;
                auditAction=postBidVerification;
        }
        else if (request.getRequestURI().contains("submitDecryptedRebateData")) {
           linkId = linkRebeteOpeningDecrypt;
           if(from == 4){ 
               // rebate verify case
               operation = 4;
               redirectUrl="etender/buyer/getUserListForVerifyRebete/"+tenderId+"/"+envelopeId+"/"+formId;
           }else{
                // rebate decrypt case
                operation = 3;
                redirectUrl="etender/buyer/getUserListForDecryptRebete/"+tenderId+"/"+envelopeId+"/"+formId;
           }
           auditAction=postRebateBidDecryption;
        }
        else
        {
             redirectUrl="etender/buyer/getUserListForDecryptBid/"+tenderId+"/"+envelopeId+"/"+formId;
        }
       
        int userId=abcUtility.getSessionUserId(request);
        int userDetailId=abcUtility.getSessionUserDetailId(request);
        if (userId != 0)
        {           
            String userIdList=""; 
            if(request.getParameter("hdUserIdList")!=null)
            {
                userIdList=request.getParameter("hdUserIdList");
            }
//            StringBuilder strInsertBidSign=new StringBuilder();
           
            StringBuilder strBidTableIds=null;
            List<String> bidTableIdsFailedList=new  ArrayList<String>();
            List<TblDecryptionFail> lsDecryptionFails =new ArrayList<TblDecryptionFail>();
            List<TblTenderRebateDetail> tblTenderRebateDetails = new ArrayList<TblTenderRebateDetail>();
            List<TblTenderBidOpenSign> tblTenderBidOpenSignLst = new ArrayList<TblTenderBidOpenSign>();
//            String[] hdBidTableIds = request.getParameterValues("hdbidTableId");
            try
            {
               int i=0;
               if(operation == 3 || operation == 4)
               {
//                   strInsertBidSign.append("INSERT INTO apptenderresult.tbl_TenderRebateDetail (tenderRebateId, rebateValue,decryptionLevel) VALUES");
                    for(String bidTableId :request.getParameterValues("hdbidTableId")) 
                    {
                        String jsonData=request.getParameterValues("bidJson")[i];
                        if(jsonData != null && !jsonData.equalsIgnoreCase(""))
                        {
//                            if(i!=0)
//                            {
//                                strInsertBidSign.append(" , ");
//                            }
//                            strInsertBidSign.append("(").append(bidTableId).append(",'").append(jsonData).append("',@V_UserEncryptionLevel)");
//                            if(strBidTableIds == null)
//                            {
//                                strBidTableIds=new StringBuilder();
//                                strBidTableIds.append(bidTableId);
//                            }
//                            else
//                            {
//                                strBidTableIds.append(",").append(bidTableId);
//                            }
                        	TblTenderRebateDetail rebateDetail = new TblTenderRebateDetail();
                        	rebateDetail.setTblTenderRebate(new TblTenderRebate(Integer.parseInt(bidTableId)));
                        	rebateDetail.setRebateValue(jsonData);
                        	List<Object> encLevel = committeeFormationService.getCommiteeEncryptionLevel(tenderId,envelopeId,userId);
                        	rebateDetail.setDecryptionLevel(encLevel !=null && !encLevel.isEmpty() ? (Integer) encLevel.get(0) : 0);
                        	tblTenderRebateDetails.add(rebateDetail);
                            if(strBidTableIds == null){
                                strBidTableIds=new StringBuilder();
                                strBidTableIds.append(bidTableId);
                            }else{
                                strBidTableIds.append(",").append(bidTableId);
                            }
                        }
                        else // Due to some decryption error data not decrypted properly make entry into decryptlog table.
                        {
                             TblDecryptionFail tblDecryptionFail=new TblDecryptionFail();
                             tblDecryptionFail.setCreatedBy(userDetailId);
                             tblDecryptionFail.setBidTableId(Integer.parseInt(bidTableId));
                             tblDecryptionFail.setCstatus(operation);
                             tblDecryptionFail.setTenderId(tenderId);
                             lsDecryptionFails.add(tblDecryptionFail);
                             bidTableIdsFailedList.add(bidTableId+"");
                        }
                        i++;     
                    }
               }
               else
               {
//                   strInsertBidSign.append("INSERT INTO apptenderresult.tbl_TenderBidOpenSign VALUES ");
                   for(String bidTableId :request.getParameterValues("hdbidTableId")) 
                    {
                        String jsonData=request.getParameterValues("bidJson")[i];
                        String jsonSignData=request.getParameterValues("signEncData")[i];
                        if((isVerification && jsonData.startsWith("[{\"")) || (!isVerification && jsonData != null && !jsonData.equalsIgnoreCase("")))
                        {
                        	TblTenderBidOpenSign bidOpenSign = new TblTenderBidOpenSign();
                        	bidOpenSign.setTblTenderBidMatrix(new TblTenderBidMatrix(Integer.parseInt(bidTableId)));
                        	bidOpenSign.setDecryptedBid(jsonData);
                        	bidOpenSign.setBidSignText(jsonSignData);
                        	bidOpenSign.setCreatedOn(commonService.getServerDateTime());
                        	bidOpenSign.setCreatedBy(userDetailId);
                        	tblTenderBidOpenSignLst.add(bidOpenSign);
                        	
                            if(strBidTableIds == null){
                                strBidTableIds=new StringBuilder();
                                strBidTableIds.append(bidTableId);
                            }else{
                                strBidTableIds.append(",").append(bidTableId);
                            }
//                                 if(i!=0)
//                                 {
//                                     strInsertBidSign.append(" , ");
//                                 }
//                                 strInsertBidSign.append("(").append(bidTableId).append(",'").append(jsonData).append("','").append(jsonSignData)
//                                                 .append("',@V_SysDateTime,").append(userDetailId).append(")");
                        }
                        else // Due to some decryption error data not decrypted properly make entry into decryptlog table.
                        {
                             TblDecryptionFail tblDecryptionFail=new TblDecryptionFail();
                             tblDecryptionFail.setCreatedBy(userDetailId);
                             tblDecryptionFail.setBidTableId(Integer.parseInt(bidTableId));
                             tblDecryptionFail.setCstatus(operation);
                             tblDecryptionFail.setTenderId(tenderId);
                             lsDecryptionFails.add(tblDecryptionFail);
                             bidTableIdsFailedList.add(bidTableId+"");
                        }
                        i++;     
                    }
               }
               
               boolean result=true;
               // System.out.println(strInsertBidSign);
               if(bidTableIdsFailedList.isEmpty()) // If decryption of all user data successed?
               {                           
                    String ipadd=request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
//                    String decryptResult=tenderOpenService.addDecryptBid(tenderId,envelopeId,formId,userId,userDetailId,ipadd,userIdList,strInsertBidSign.toString(),strBidTableIds.toString(),abcUtility.getSessionClientId(request),operation);
                    String decryptResult=tenderOpenService.addDecryptBid(tenderId,envelopeId,formId,userId,userDetailId,ipadd,userIdList,"".toString(),strBidTableIds.toString(),abcUtility.getSessionClientId(request),operation,tblTenderRebateDetails, tblTenderBidOpenSignLst);
                   // System.out.println(decryptResult);
                    if(!isVerification) /* Bid Decription */
                    {
                        if(decryptResult !=null && decryptResult.equalsIgnoreCase("msg_biddecrypt_another_user"))
                        {
                            result=false;
                            auditAction=postBidDecryptionFailed;
                            if(operation == 4){
                                redirectAttributes.addFlashAttribute("msg","msg_biddverification_another_user");
                            }else{
                                redirectAttributes.addFlashAttribute("msg","msg_biddecrypt_another_user");
                            }
                        }
                        else if(decryptResult !=null && decryptResult.equalsIgnoreCase("msg_bid_decrypt_failed"))
                        {
                             auditAction=postBidDecryptionFailed;
                             if(operation == 4){
                                 redirectAttributes.addFlashAttribute("msg","msg_bid_verified_failed");
                             }else{
                                redirectAttributes.addFlashAttribute("msg","msg_bid_decrypt_failed");
                             }
                        }
                        else if(decryptResult !=null && decryptResult.equalsIgnoreCase("msg_bid_decrypt_success"))
                        {
                            if(operation == 4){
                                redirectAttributes.addFlashAttribute("msg","msg_bid_verified_success");
                            }else{
                                redirectAttributes.addFlashAttribute("msg","msg_bid_decrypt_success");
                            }
                        }
                    }
                    else /* Bid Verification */
                    {
                        if(decryptResult !=null && decryptResult.equalsIgnoreCase("msg_biddverification_another_user"))
                        {
                            result=false;
                            auditAction=postBidVerificationFailed;
                            redirectAttributes.addFlashAttribute("msg","msg_biddverification_another_user");
                        }
                        else if(decryptResult !=null && decryptResult.equalsIgnoreCase("msg_bid_verified_failed"))
                        {
                             auditAction=postBidVerificationFailed;
                             redirectAttributes.addFlashAttribute("msg","msg_bid_verified_failed");
                        }
                        else if(decryptResult !=null && decryptResult.equalsIgnoreCase("msg_bid_verified_success"))
                        {
                           redirectAttributes.addFlashAttribute("msg","msg_bid_verified_success");
                        }
                    }

               }
               else // If decryption of any user data failed
                {
                    tblDecryptionFailDao.saveUpdateAllTblDecryptionFail(lsDecryptionFails);
                    if(!isVerification)
                    {
                        auditAction=postRebateBidDecryptionFailed;
                        redirectAttributes.addFlashAttribute("msg","msg_bid_decrypt_failed");
                    }
                    else
                    {
                        auditAction=postRebateBidDecryptionFailed;
                        redirectAttributes.addFlashAttribute("msg","msg_bid_verified_failed");
                    }
                }
               	
              	if(operation == 1){
              		// Bug #34024 By Jitendra. Update tender status when any envelope is decrypted from all the levels.
              		tenderFormService.updateTenderEvalutionStatusForOpening(tenderId, envelopeId, TENDER_OPENED_STATUS);
              		
              		// After bid decryption, mail should be send to respective bidders. Bug #32860 By Jitendra.
              		tenderCommonService.tenderSummary(tenderId, model, abcUtility.getSessionClientId(request));
              		HashMap<String, Object> msgParams = new HashMap<String, Object>();
              		msgParams.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
              		msgParams.put("EventId", tenderId);
              		msgParams.put("EventType", model.get("eventType"));
              		msgParams.put("ReferenceNo", model.get("tenderNo"));
              		msgParams.put("EventBrief", model.get("tenderBrief"));
              		String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/biddingtenderdashboard/"+tenderId+"/7");
                	String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                	msgParams.put("ClickHere", hrefStr);
                	mailContentUtillity.dynamicMailGeneration("186", String.valueOf(abcUtility.getSessionUserId(request)), String.valueOf(tenderId), msgParams, "");
             	}
            }
            catch (Exception ex) 
            {   
                if(!isVerification)
                {
                    auditAction=postBidDecryptionFailed;
                    redirectAttributes.addFlashAttribute("msg","msg_bid_decrypt_failed");
                }
                else
                {
                    auditAction=postBidVerificationFailed;
                    redirectAttributes.addFlashAttribute("msg","msg_bid_verified_failed");
                }
                return  exceptionHandlerService.writeLog(ex);

            }
            finally
            {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditAction, tenderId, formId);
                
            }
          
            redirectUrl="/"+redirectUrl+encryptDecryptUtils.generateRedirect(redirectUrl ,request);
        }
        else
        {
                    redirectUrl =  "/sessionexpired";
        }
        return "redirect:"+redirectUrl;
    }
    
    /**
     * to get prepare TOC report name
     * @param tenderId
     * @param envelopeId
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/buyer/preparetocreportname/{tenderId}/{envelopeId}/{tenderReportType}/{tenderReportId}/{opType}/{enc}", method = RequestMethod.GET)
    public String prepareTOCReportName(@PathVariable("tenderId") int tenderId, @PathVariable("envelopeId") int envelopeId,@PathVariable(TENDERREPORT_TYPE) int tenderReportType, @PathVariable("tenderReportId") int tenderReportId,@PathVariable("opType") String opType,HttpServletRequest request, ModelMap modelMap,RedirectAttributes redirectAttributes) {
		try {
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
			List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(tenderReportType == 1 ?78:80, abcUtility.getSessionClientId(request));
		    int allowedSize = 0;
		    StringBuilder allowedExt = new StringBuilder();
		    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
				allowedSize = lstDocUploadConf.get(0).getMaxSize();
				allowedExt.append(lstDocUploadConf.get(0).getType());
				modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
		    }
		    int index = allowedExt.toString().indexOf(",");
		    allowedExt.insert(index + 1, "*.");
		    while (index >= 0) {
				index = allowedExt.toString().indexOf(",", index + ",".length());
				allowedExt.insert(index + 1, "*.");
		    }
		    modelMap.addAttribute("allowedExt", allowedExt);
		    modelMap.addAttribute("allowedSize", allowedSize/1024);
		    modelMap.addAttribute("linkId", tenderReportType == 1 ? prepareTOCReportLinkId : prepareTECReportLinkId);
		    modelMap.addAttribute("tenderId", tenderId);
		    modelMap.addAttribute("objectId", tenderReportId);
		    modelMap.addAttribute("cStatusDoc", 0);
		    modelMap.addAttribute("cStatusDocView", 0);
		    modelMap.addAttribute("isPageReload", "N");
		    modelMap.addAttribute("opType", opType);
		    TblTenderReport tblTenderReport= tenderReportService.getTenderReportDetail(tenderReportId);
 			if(tblTenderReport!=null){
 				 modelMap.addAttribute("tenderReportName", tblTenderReport.getReportName());
 			}
		}catch (Exception e) {
		    return exceptionHandlerService.writeLog(e);
		}finally {
			int linkId=0;
			String msg="";
			if(tenderReportType == 1){
				linkId=prepareTOCReportNameLinkId;
				msg=getReportName;
			}else if(tenderReportType == 2){
				linkId=prepareTECReportNameLinkId; // Need to change new link id for tec
				msg=getTecReportname;
			}
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, tenderId, envelopeId);
		}
		return "etender/buyer/PrepareTOCReportName";
    }
    
    /**
     * to add toc report name
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/addtocreportname", method = RequestMethod.POST)
    public String addTOCReportName(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/sessionexpired";
        int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
        int envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")) : 0;
        int tenderReportType=StringUtils.hasLength(request.getParameter(HDTENDERREPORT_TYPE)) ? Integer.parseInt(request.getParameter(HDTENDERREPORT_TYPE)) : 0;
        String opType = StringUtils.hasLength(request.getParameter("hdOpType")) ? request.getParameter("hdOpType") : "";
        int tenderReportId=StringUtils.hasLength(request.getParameter("hdTenderReportId")) ? Integer.parseInt(request.getParameter("hdTenderReportId")) : 0;
        boolean success = false;
        int isReEvaluationReq = 0;
        String msg = CommonKeywords.ERROR_MSG.toString();
        try {
        	int userId=abcUtility.getSessionUserId(request);
        	if(userId != 0){
	              String reportName=StringUtils.hasLength(request.getParameter("txtReportName")) ? request.getParameter("txtReportName") : "";
	              List<Object[]> lstEnvelope = tenderFormService.getTenderEnvelopeList(tenderId);
		 			 int envelopeIdReport = 0;
		 			 for (int i=0;i<lstEnvelope.size();i++) {
		 				 int envelopeOpened = Integer.parseInt(lstEnvelope.get(i)[3].toString());
		 				 	if((tenderReportType==1 || tenderReportType==2 ) && envelopeOpened==1){
		 				            	envelopeIdReport=  Integer.parseInt(lstEnvelope.get(i)[2].toString());
		 				 	}
		 			 }
		 			 TblTenderReport tblTenderReport = null;
		 			if(tenderReportId !=0){
		 				   tblTenderReport= tenderReportService.getTenderReportDetail(tenderReportId);
		 			}
                      isReEvaluationReq=Integer.valueOf(tenderCommonService.getTenderField(tenderId,"isReEvaluationReq").toString());
                      boolean reEvaluation = true;
                      if(isReEvaluationReq == 1){
                        Integer[] ctatus={0,1};  
                        List<TblTenderReevaluation> getTblTenderReevaluation = tenderFormService.getTblTenderRevaluationStatusByEnvelopeId(tenderId,envelopeId,ctatus);
                        if(getTblTenderReevaluation!=null && !getTblTenderReevaluation.isEmpty()){
                             reEvaluation = false;
                        }
                      }
	              if("".equals(reportName)){
	            	  retVal="redirect:/etender/buyer/preparetocreportname/"+tenderId+"/"+envelopeId+"/"+tenderReportType+encryptDecryptUtils.generateRedirect("etender/buyer/preparetocreportname/"+tenderId+"/"+envelopeId+"/"+tenderReportType, request);  
	              }else if((isReEvaluationReq == 0 && envelopeIdReport!=envelopeId) || (isReEvaluationReq == 1 && reEvaluation && envelopeIdReport!=envelopeId )){
	            	  	retVal=tenderReportType == 1 ? TENDER_DASHBOARD_URL+tenderId+"/7":TENDER_DASHBOARD_URL+tenderId+"/8";
	    				retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
		 				msg =  tenderReportType==1?"msg_toc_report_not_allowed":"msg_tec_report_not_allowed";
		 			 }else if (opType.equals("update") && ( tblTenderReport.getCstatus()==1 || tblTenderReport.getCstatus()==3 || commonService.checkEntryTblWorkflow(tenderReportId, tenderId)==3)){
		 				retVal=tenderReportType == 1 ? TENDER_DASHBOARD_URL+tenderId+"/7":TENDER_DASHBOARD_URL+tenderId+"/8";
	    				retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	    				msg =   tblTenderReport.getCstatus()==1 ? (tenderReportType==1?"msg_toc_report_already_published":"msg_tec_report_already_published" ):"msg_workflow_already_proceed";
		 			 } else{
	            	  tblTenderReport=new TblTenderReport();
	            	  if(opType.equals("update")){
	            		  tblTenderReport.setTenderReportId(tenderReportId);
	            	  }
	            	  tblTenderReport.setReportName(reportName);
	            	  tblTenderReport.setTblTender(new TblTender(tenderId));
	            	  tblTenderReport.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
	            	  tblTenderReport.setTblUserLogin(new TblUserLogin(userId));
	            	  tblTenderReport.setCstatus(0);
	            	  tblTenderReport.setReportType(tenderReportType);
	            	  tblTenderReport.setRemark("");
	            	  tblTenderReport.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
	            		success=tenderOpenService.addReportName(tblTenderReport);
	            	  if(success){
	            		  String txtHidDocIds = CommonUtility.checkNull(request.getParameter("txtHidDocIds"));
	            		   tenderReportId = tblTenderReport.getTenderReportId();
                          if (!"".equalsIgnoreCase(txtHidDocIds)) {
                        	  success = fileUploadService.updateOfficerDocsObjectId(txtHidDocIds, tenderReportId);
                          }
                          if(tenderReportType == 1){
                    		  retVal = "etender/buyer/tenderdashboard/" + tenderId + "/"+ 7;
                    	  }else if(tenderReportType == 2){
                    		  retVal = "etender/buyer/tenderdashboard/" + tenderId + "/"+ 8;
                    	  }
                    	  retVal ="redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
	            	  }
	              }
	              redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_reportname" : msg);
        	}
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
        	int linkId=0;
			 msg="";
			if(tenderReportType == 1){
				linkId=prepareTOCReportNameLinkId;
				msg=postReportName;
			}else if(tenderReportType == 2){
				linkId=prepareTECReportNameLinkId; // Need to change new link id for tec
				msg=postTECReportName;
			}
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, tenderId, 0);
        }
        return retVal;
    }
    
    /**
     * to get prepare TOC report page at buyer side 
     * @param objectId
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/buyer/preparetocreport/{tenderId}/{envelopeId}/{tenderReportId}/{tenderReportType}/{enc}", method = RequestMethod.GET)
    public String prepareTOCReport(@PathVariable("tenderId") int tenderId, @PathVariable("envelopeId") int envelopeId,@PathVariable("tenderReportId") int tenderReportId,@PathVariable(TENDERREPORT_TYPE) int tenderReportType,HttpServletRequest request, ModelMap modelMap) {
		int clientId = 0;
		try {
		    clientId = abcUtility.getSessionClientId(request);
		    //int userId=abcUtility.getSessionUserId(request);
		    boolean isConstraintsAdded=false;
		    tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
		    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(78, clientId);
		    int allowedSize = 0;
		    StringBuilder allowedExt = new StringBuilder();
		    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
				allowedSize = lstDocUploadConf.get(0).getMaxSize();
				allowedExt.append(lstDocUploadConf.get(0).getType());
				modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
		    }
		    int index = allowedExt.toString().indexOf(",");
		    allowedExt.insert(index + 1, "*.");
		    while (index >= 0) {
				index = allowedExt.toString().indexOf(",", index + ",".length());
				allowedExt.insert(index + 1, "*.");
		    }
		    List<Object[]> committeeMemberList =tenderOpenService.getCommitteeMembers(tenderId, envelopeId,tenderReportId,tenderReportType);
		    for(Object[] data : committeeMemberList){
		    	if(Integer.parseInt(data[2].toString()) != 0 ){
		    		isConstraintsAdded=true;
		    	}
		    }
		    modelMap.addAttribute("isConstraintsAdded", isConstraintsAdded);
		    if(isConstraintsAdded){
		    	modelMap.addAttribute("isReadOnly", "Y");
		    }
		    modelMap.addAttribute("allowedExt", allowedExt);
		    modelMap.addAttribute("allowedSize", allowedSize/1024);
		    modelMap.addAttribute("linkId", tenderReportType == 1 ? prepareTOCReportLinkId : prepareTECReportLinkId);
		    modelMap.addAttribute("tenderId", tenderId);
		    modelMap.addAttribute("objectId", tenderReportId);
		    modelMap.addAttribute("cStatusDoc", 0);
		    modelMap.addAttribute("cStatusDocView", 0);
		    modelMap.addAttribute("isPageReload", "N");
		    modelMap.addAttribute("committeeMemberList",committeeMemberList);
		    modelMap.addAttribute("fileUploadSize", fileUploadService.getOfficerDocs(tenderReportId, clientId, tenderReportType == 1 ? prepareTOCReportLinkId : prepareTECReportLinkId,1).size());
		    modelMap.addAttribute("tenderEnvelopeDetailsList",tenderOpenService.getTenderEnvelopeDetailFromTenderReportId(tenderReportId, tenderReportType));
		}catch (Exception e) {
		    return exceptionHandlerService.writeLog(e);
		}finally {
			int linkId=0;
			String msg="";
			if(tenderReportType == 1){
				linkId=prepareTOCReportLinkId;
				msg=getPrepareTOCReport;
			}else if(tenderReportType == 2){
				linkId=prepareTECReportLinkId;
				msg=getPrepareTECReport;
			}
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, tenderId, tenderReportId);
		}
		return "etender/buyer/PrepareTOCReport";
    }
    
    
    /**
     * @author vivek.rajyaguru
     * @param tenderId
     * @param tenderReportId
     * @param tenderReportType
     * @param modelMap
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = {"/buyer/getPublishTOCReport/{tenderId}/{tenderReportId}/{tenderReportType}/{enc}","/buyer/getPublishTECReport/{tenderId}/{tenderReportId}/{tenderReportType}/{enc}"}, method = RequestMethod.GET)
    public String getPublishTOCTECReport(@PathVariable("tenderId") int tenderId, @PathVariable("tenderReportId") int tenderReportId,@PathVariable(TENDERREPORT_TYPE) int tenderReportType,ModelMap modelMap,HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	 int clientId = 0;
    	 String auditTrailMsg="";
    	 int linkId=0;
    	 String retVal = "redirect:/sessionexpired";
    	 boolean isCertFound = true;
 		 try {
 			 
 		  ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());	 
 		  clientId = abcUtility.getSessionClientId(request);
 		  SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
 		  tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
 		  modelMap.addAttribute("tenderId", tenderId);
 		  modelMap.addAttribute("tenderReportId", tenderReportId);
 		  modelMap.addAttribute("tenderReportType", tenderReportType);
 		  
 		 String certIds[] = null;
			if(clientBean.getIsPkiEnabled()==pkiEnable){
	             certIds = sessionBean.getCertId().split(",");
	     		if(certIds!=null && certIds.length!=0){
	     			modelMap.put("publicKeyForSign", commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
	             }
			}else if (clientBean.getIsPkiEnabled()==pkiEventSpecific && Integer.parseInt(modelMap.get("isCertRequired").toString()) == 1){
	 			if(!sessionBean.isEventSpecVerify()){
	 				isCertFound = false;
	 				if(tenderReportType==1){
	 					retVal="common/buyer/attacheventspeccerti/etender,buyer,getPublishTOCReport,"+tenderId+","+tenderReportId+","+tenderReportType+"";
	 				}else if (tenderReportType==2){
	 					retVal="common/buyer/attacheventspeccerti/etender,buyer,getPublishTECReport,"+tenderId+","+tenderReportId+","+tenderReportType+"";	
	 				}
	 			}else{
	 				certIds = sessionBean.getCertId().split(",");
	         		if(certIds!=null && certIds.length!=0){
	         			modelMap.put("publicKeyForSign", commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
	                 }
	             }
			}
			if(isCertFound){
				retVal="etender/buyer/PublishTocTecReports";
			}
			else {
				retVal="redirect:/"+retVal+ encryptDecryptUtils.generateRedirect(retVal, request);
			}
 		  
 		}catch (Exception e) {
		    return exceptionHandlerService.writeLog(e);
		}finally {
			if(tenderReportType == 1){
				linkId=bidOpeningReportPublishLinkId;
      			auditTrailMsg=getbidOpeningReportPublishPage;
      			modelMap.addAttribute("var_tab_id", 7);
			}else if(tenderReportType == 2){
				auditTrailMsg=getbidEvaluationReportPublishPage;
				modelMap.addAttribute("var_tab_id", 8);
      			linkId=bidEvaluationReportPublishLinkId;
			}
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrailMsg, tenderId, tenderReportId);
		}
    	return retVal;
    }
    
    
    
   
    /**
     * @author vivek.rajyaguru
     * @param request
     * @param modelMap
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value="/buyer/publishTOCTECReport", method=RequestMethod.POST)
    public String publishTOCTECReport(HttpServletRequest request, ModelMap modelMap,RedirectAttributes redirectAttributes) {
        String retVal = "redirect:/sessionexpired";
        boolean success = false;
        int linkId=0;
		String msg="";
		String auditTrailMsg="";
		String remarks = null;
		String signedRemarks = null;
		int tenderReportType=0;
		int tenderId=0;
		int tenderReportId=0;
		boolean isPkiReq = false;
                int isReEvaluationReq = 0;
	    try {
        	
        	int pki = abcUtility.getSessionIsPkiEnabled(request);	
        	int userDetailId=abcUtility.getSessionUserDetailId(request);
			remarks = request.getParameter("txtaRemarks");
			signedRemarks = StringUtils.hasLength(request.getParameter("skpSignText"))?request.getParameter("skpSignText"):"";
			int isCertRequired = StringUtils.hasLength(request.getParameter("hdIsCertRequired"))?Integer.parseInt(request.getParameter("hdIsCertRequired")):0;
			tenderReportType = StringUtils.hasLength(request.getParameter("hdTenderReportType"))?Integer.parseInt(request.getParameter("hdTenderReportType")):0;
			tenderId = StringUtils.hasLength(request.getParameter("hdTenderId"))?Integer.parseInt(request.getParameter("hdTenderId")):0;
			tenderReportId = StringUtils.hasLength(request.getParameter("hdTenderReportId"))?Integer.parseInt(request.getParameter("hdTenderReportId")):0;
			
			if(pki == pkiEnable || (pki == pkiEventSpecific && isCertRequired == 1)){
				isPkiReq = true;
			}
			
        	  int sessionUserId=abcUtility.getSessionUserId(request);
        	  List<Object[]> lstEnvelope = tenderFormService.getTenderEnvelopeList(tenderId);
	 			 int envelopeIdReport = 0;
	 			 for (int i=0;i<lstEnvelope.size();i++) {
	 				 int envelopeOpened = Integer.parseInt(lstEnvelope.get(i)[3].toString());
	 				 	if((tenderReportType==1 || tenderReportType==2 )  && envelopeOpened==1){
	 				            	envelopeIdReport=  Integer.parseInt(lstEnvelope.get(i)[2].toString());
	 				 	}
	 			 }
	 			TblTenderReport tblTenderReport= tenderReportService.getTenderReportDetail(tenderReportId);
                                isReEvaluationReq=Integer.valueOf(tenderCommonService.getTenderField(tenderId,"isReEvaluationReq").toString());
                                boolean reEvaluation = false;
                                if(isReEvaluationReq == 1){
                                  Integer[] ctatus={0,1};  
                                  List<TblTenderReevaluation> getTblTenderReevaluation = tenderFormService.getTblTenderRevaluationStatusByEnvelopeId(tenderId,tblTenderReport.getTblTenderEnvelope().getEnvelopeId(),ctatus);
                                  if(getTblTenderReevaluation!=null && !getTblTenderReevaluation.isEmpty()){
                                       reEvaluation = true;
                                  }
                                }
	 			if(tblTenderReport!=null){
		        	  if(tenderReportType == 1){
		      			linkId=bidOpeningReportPublishLinkId;
		      			msg="msg_toc_report_published";
		      			auditTrailMsg=bidOpeningReportPublished;
		      			if((tblTenderReport.getTblTenderEnvelope().getEnvelopeId()==envelopeIdReport && tblTenderReport.getCstatus()!=1) || reEvaluation){
		      				success= tenderOpenService.publishTOCTECReport(tenderReportId,sessionUserId,bidOpeningReportUploadLinkId,remarks,userDetailId);
		      			}else{
		      				if(tblTenderReport.getCstatus()==1){
		      					msg = "msg_toc_report_already_published";
		      				}else{
		      					msg = "msg_toc_tec_reprot_not_allowed_published";
		      				}
		      			}
		      			
		      		}else if(tenderReportType == 2){
		      			msg="msg_tec_report_published";
		      			auditTrailMsg=bidEvaluationReportPublished;
		      			linkId=bidEvaluationReportPublishLinkId;
		      			if((tblTenderReport.getTblTenderEnvelope().getEnvelopeId()==envelopeIdReport && tblTenderReport.getCstatus()!=1) || reEvaluation ){
		      				success= tenderOpenService.publishTOCTECReport(tenderReportId,sessionUserId,bidEvaluationReportUploadLinkId,remarks,userDetailId);
		      			}else{
		      				if(tblTenderReport.getCstatus()==1){
		      					msg = "msg_tec_report_already_published";
		      				}else{
		      					msg = "msg_tec_report_not_allowed";
		      				}
		      				
		      			}
		      		}
	 			}
        	  if(sessionUserId != 0){
        		  redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? msg : msg);
        		  if(success){
		              if(tenderReportType == 1){
		            	  retVal = "etender/buyer/tenderdashboard/" + tenderId + "/"+ 7;
	            	  }else if(tenderReportType == 2){
	            		  retVal = "etender/buyer/tenderdashboard/" + tenderId + "/"+ 8;
	            	  }
        		  }else{
        			  if(tenderReportType == 1){
        				  retVal = "etender/buyer/getPublishTOCReport/" + tenderId + "/" + tenderReportId+ "/"+ tenderReportType;
	            	  }else if(tenderReportType == 2){
	            		  retVal = "etender/buyer/getPublishTECReport/" + tenderId + "/" + tenderReportId+ "/"+ tenderReportType;
	            	  }
        		  }
            	  retVal ="redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
        	  }
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
        	if(isPkiReq){
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrailMsg, tenderId , tenderReportId, remarks, signedRemarks);
			}
			else {
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrailMsg, tenderId, tenderReportId);
			}
        }
        return retVal;
    }
    
    /*@RequestMapping(value = "/buyer/addtocreportconsent", method = RequestMethod.POST)
    public String addTOCReportconsent(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/sessionexpired";
        int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
        int envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")) : 0;
        int tenderReportId = StringUtils.hasLength(request.getParameter("hdTenderReportId")) ? Integer.parseInt(request.getParameter("hdTenderReportId")) : 0;
        int userId = StringUtils.hasLength(request.getParameter("hdUserId")) ? Integer.parseInt(request.getParameter("hdUserId")) : 0;
        String remarks=StringUtils.hasText(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") : "";
        int tenderReportType=StringUtils.hasLength(request.getParameter(HDTENDERREPORT_TYPE)) ? Integer.parseInt(request.getParameter(HDTENDERREPORT_TYPE)) : 0;
        int minReq=StringUtils.hasLength(request.getParameter("hdMinReq")) ? Integer.parseInt(request.getParameter("hdMinReq")) : 0;
        boolean success = false;
        try {
        	  int sessionUserId=abcUtility.getSessionUserId(request);
        	  if(sessionUserId != 0){
	              if("".equals(remarks)){
	            	  retVal="redirect:/etender/buyer/tocreportconsent/"+tenderId+"/"+envelopeId+"/"+tenderReportId+"/"+tenderReportType+"/"+minReq+encryptDecryptUtils.generateRedirect("etender/buyer/tocreportconsent/"+tenderId+"/"+envelopeId+"/"+tenderReportId+"/"+tenderReportType+"/"+minReq, request);  
	              }else{
	            	  TblTenderReportDetail tblTenderReportDetail=new TblTenderReportDetail();
	            	  tblTenderReportDetail.setRemark(remarks);
	            	  TblTenderReport tblTenderReport=new TblTenderReport();
	            	  tblTenderReport.setTenderReportId(tenderReportId);
	            	  tblTenderReportDetail.setTblTenderReport(tblTenderReport);
	            	  tblTenderReportDetail.setTblUserLogin(new TblUserLogin(userId));
	            	  tblTenderReportDetail.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
	            	  success=tenderOpenService.addTenderReportDetails(tblTenderReportDetail);
	            	  if(tenderOpenService.getTenderReportDetails(tenderReportId).size() >= minReq){
	            		  tenderOpenService.publishTOCReport(tenderReportId);
	            	  }
	            	  if(success){
	            		  retVal="redirect:/etender/buyer/viewtocreport/"+tenderId+"/"+envelopeId+"/"+tenderReportId+"/"+tenderReportType+encryptDecryptUtils.generateRedirect("etender/buyer/viewtocreport/"+tenderId+"/"+envelopeId+"/"+tenderReportId+"/"+tenderReportType, request);
	            	  }
	              }
	              redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_reportconsent" : CommonKeywords.ERROR_MSG_KEY.toString());
        	  }
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
        	int linkId=0;
			String msg="";
			if(tenderReportType == 1){
				linkId=prepareTOCReportConsentLinkId;
				msg=postGiveConsent;
			}else if(tenderReportType == 2){
				linkId=prepareTECReportConsentLinkId;
				msg=postTECGiveConsent;
			}
        	if(abcUtility.getSessionIsPkiEnabled(request) == 1 ){
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, tenderId, tenderReportId,remarks,StringUtils.hasLength(request.getParameter("skpSignText")) ? request.getParameter("skpSignText") : "");
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, tenderId, tenderReportId);
        	}
        }
        return retVal;
    }*/
    
    
    /**
     * used to view toc report
     * @param tenderId
     * @param envelopeId
     * @param tenderReportId
     * @param tenderReportType
     * @param request
     * @param modelMap
     * @return String
     */
    @RequestMapping(value = {"/buyer/viewtocreport/{tenderId}/{tenderReportId}/{tenderReportType}/{enc}","/buyer/viewtecreport/{tenderId}/{tenderReportId}/{tenderReportType}/{enc}","/buyer/viewtocreportforwrkflw/{tenderId}/{tenderReportId}/{tenderReportType}/{enc}","/buyer/viewtecreportforwrkflw/{tenderId}/{tenderReportId}/{tenderReportType}/{enc}"}, method = RequestMethod.GET)
    public String viewTOCReport(@PathVariable("tenderId") int tenderId,@PathVariable("tenderReportId") int tenderReportId,@PathVariable("tenderReportType") int tenderReportType,HttpServletRequest request, ModelMap modelMap) {
    	//int tenderReportType=0;
    	try {
			//tenderReportType=tenderCommitteeType==4?1:tenderCommitteeType;//Use only To manage go-back issue from evaluation tab. 4 means it come from evaluation tab for opening report
    		int tenderCommitteeType=0;
    		if(tenderReportType==4){
    			tenderCommitteeType=4;
    			tenderReportType=1;
    		}
		    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
		    modelMap.addAttribute("isReadOnly", "Y");
		    modelMap.addAttribute("linkId", tenderReportType == 1 ? prepareTOCReportLinkId : prepareTECReportLinkId);
		    modelMap.addAttribute("tenderId", tenderId);
		    modelMap.addAttribute("objectId", tenderReportId);
		    
		    TblTenderReport tblTenderReport = tenderReportService.getTenderReportDetail(tenderReportId);
		    if(tblTenderReport!=null){
		    	 modelMap.addAttribute("reportName", tblTenderReport.getReportName());
		    	 modelMap.addAttribute("cstatus", tblTenderReport.getCstatus());
		    }
		    	 if(tblTenderReport!=null && (tblTenderReport.getCstatus()==0 || tblTenderReport.getCstatus()==3) ){ //pending TOC/TEC Report View
						modelMap.addAttribute("cStatusDoc", 0);
						modelMap.addAttribute("cStatusDocView", 0);
					}else{
						 modelMap.addAttribute("cStatusDoc", 1);
						 modelMap.addAttribute("cStatusDocView", 1);
					}
		    modelMap.addAttribute("tenderEnvelopeDetailsList",tenderOpenService.getTenderEnvelopeDetailFromTenderReportId(tenderReportId,tenderReportType));
		    modelMap.addAttribute("tenderReportType", tenderCommitteeType==4?2:tenderReportType);
		    modelMap.addAttribute("tenderCommitteeType", tenderCommitteeType);
		    modelMap.addAttribute("workFlowFlag", 0);
		    if(request.getRequestURI().contains("/buyer/viewtocreportforwrkflw/") || request.getRequestURI().contains("/buyer/viewtecreportforwrkflw/")){
		    	modelMap.addAttribute("workFlowFlag", 1);
		    }
		    
		}catch (Exception e) {
		    return exceptionHandlerService.writeLog(e);
		}finally {
			int linkId=0;
			String msg="";
			if(tenderReportType == 1){
				linkId=viewPrepareTOCReportLinkId;
				msg=getViewTOCReport;
			}else if(tenderReportType == 2){
				linkId=viewPrepareTECReportLinkId;
				msg=getViewTECReport;
			}
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, tenderId, tenderReportId);
		}
    	modelMap.addAttribute("flagStatus", 1);
		return "etender/buyer/ViewTOCReport";
    }
    
    /**
     * to get price opening date configuration page
     * @param tenderId
     * @param envelopeId
     * @param oprType ==1 for create, oprType == 2 for edit,oprType ==3 for publish,oprType ==4 for view,
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = {"/buyer/pricebidopeningdate/{tenderId}/{envelopeId}/{previousEnvlpId}/{oprType}/{enc}","/buyer/editpricebidopeningdate/{tenderId}/{envelopeId}/{previousEnvlpId}/{oprType}/{enc}","/buyer/publishpricebidopeningdate/{tenderId}/{envelopeId}/{previousEnvlpId}/{oprType}/{enc}","/buyer/viewpricebidopeningdate/{tenderId}/{envelopeId}/{previousEnvlpId}/{oprType}/{enc}","/buyer/viewpricebidopeningdateforwrkflw/{tenderId}/{envelopeId}/{previousEnvlpId}/{oprType}/{enc}"}, method = RequestMethod.GET)
    public String getPriceBidOpeningDate(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("previousEnvlpId") int previousEnvlpId,@PathVariable("oprType") int oprType,HttpServletRequest request, ModelMap modelMap) {
    	String envelopeName="";
		try {
				List<Object[]> listObjects=tenderOpenService.getTenderEnvelopeDetails(envelopeId,1);
				if(!listObjects.isEmpty() && listObjects!=null){
					envelopeName=listObjects.get(0)[2].toString();
				}
				if(oprType!=1){
					modelMap.addAttribute("tenderEnvelopeDetailsList",listObjects);
				}
			
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
			if(request.getRequestURI().toString().contains("/buyer/viewpricebidopeningdateforwrkflw")){
				modelMap.addAttribute("workFlowViewFlag", 1);
			}else{
				modelMap.addAttribute("workFlowViewFlag", 0);
			}
		}catch (Exception e) {
		    return exceptionHandlerService.writeLog(e);
		}finally {
			int linkId=0;
			String message="";
			switch (oprType) {
				case 1:
					linkId=createPriceBidOpeningDateLinkId;
					message=MessageFormat.format(getOpeningDateConfg, envelopeName);
					break;
				case 2:
					linkId=editPriceBidOpeningDateLinkId;
					message=MessageFormat.format(getEditOpeningDateConfg, envelopeName);
					break;
				case 3:
					linkId=publishPriceBidOpeningDateLinkId;
					message=MessageFormat.format(getPublishOpeningDateConfg, envelopeName);
					break;
				case 4:
					linkId=viewPriceBidOpeningDateLinkId;
					message=MessageFormat.format(getViewOpeningDateConfg, envelopeName);
					break;
			
			}
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, message, tenderId, envelopeId);
		}
		return "etender/buyer/PriceBidOpeningDate";
    }
    
    /**
     * to update price bid opening date
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/updatepricebidopeningdate", method = RequestMethod.POST)
    public String updatePricebidOpeningDate(ModelMap modelMap,RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/sessionexpired";
        int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
        int envelopeId = StringUtils.hasLength(request.getParameter("hdEnvelopeId")) ? Integer.parseInt(request.getParameter("hdEnvelopeId")) : 0;
        int previousEnvlpId = StringUtils.hasLength(request.getParameter("hdPreviousEnvlpId")) ? Integer.parseInt(request.getParameter("hdPreviousEnvlpId")) : 0;
        int oprType = StringUtils.hasLength(request.getParameter("hdOprType")) ? Integer.parseInt(request.getParameter("hdOprType")) : 0;
        String envelopeName=StringUtils.hasLength(request.getParameter("hdEnvelopeName")) ? request.getParameter("hdEnvelopeName") : ""; 
        String priceOpeningDate=StringUtils.hasText(request.getParameter("txtPriceBidOpeningDate")) ? CommonUtility.convertUtcTimezone(request.getParameter("txtPriceBidOpeningDate")) : "";
        boolean success = false;
        try {
        	  int userId=abcUtility.getSessionUserId(request);
        	  int workflowActionId = commonService.checkEntryTblWorkflow(envelopeId, tenderId);
        	  boolean isServerSideValidate = true;
        	  if(userId != 0){
	              if("".equals(priceOpeningDate) && (oprType == 1 || oprType == 2)){
	            	  retVal="redirect:/etender/buyer/pricebidopeningdate/"+tenderId+"/"+envelopeId+"/"+previousEnvlpId+"/"+oprType+encryptDecryptUtils.generateRedirect("etender/buyer/pricebidopeningdate/"+tenderId+"/"+envelopeId+"/"+previousEnvlpId+"/"+oprType, request);  
	              }else if(oprType == 2 && (workflowActionId==3 || workflowActionId==5)){
	            	  isServerSideValidate = false;
	            	  retVal="redirect:/etender/buyer/pricebidopeningdate/"+tenderId+"/"+envelopeId+"/"+previousEnvlpId+"/"+oprType+encryptDecryptUtils.generateRedirect("etender/buyer/pricebidopeningdate/"+tenderId+"/"+envelopeId+"/"+previousEnvlpId+"/"+oprType, request);  
	              }else{
	            	  tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	            	  if(oprType == 1 || oprType == 2){//create/edit
	            		  success=tenderOpenService.updatePriceBidOpeningDate(tenderId,envelopeId,priceOpeningDate);
	            	  }else if(oprType == 3){//publish
	            		  success=tenderOpenService.publishPriceOpeningBid(tenderId,envelopeId,abcUtility.getSessionUserDetailId(request));
	            		  if(success){
	            			  Map<String,Object> mailParams=new HashMap<String, Object>();
	            			  mailParams.put("EventId", tenderId);
	            			  mailParams.put("tenderId", tenderId); // Added by Manoj Gadhavi to resolve bug # 22090
	            			  mailParams.put("EventType", modelMap.get("eventType"));
	            			  mailParams.put("ReferenceNo", modelMap.get("tenderNo"));
	            			  mailParams.put("EventBrief", modelMap.get("tenderBrief"));
	            			  mailParams.put("EnvelopeName", envelopeName);
	            			  mailParams.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
	            			  mailParams.put("EnvelopeOpeningDateTime", CommonUtility.convertTimezone(priceOpeningDate)); // updated by Manoj Gadhavi to resolve bug # 22090 to convert UTC timezone to clients timezone in mail

	            			  if(Integer.parseInt(bobClientId) == abcUtility.getSessionClientId(request)){
	                     		 int officerId =  (Integer) tenderCommonService.getTenderField(tenderId, "officerId");
	                     		 String deptOfficerLogin = commonService.getEmailByUserId(officerId);
	 		                        /*List<TblUserLogin> list = commonService.getUserLoginById(officerId);
	 		                        if(list!=null && !list.isEmpty()){
	 		                        	deptOfficerLogin = list.get(0).getLoginId();
	 		                        }*/
	                     		 if(deptOfficerLogin!=null && deptOfficerLogin.length()>0)
	                     			 mailParams.put("cc",deptOfficerLogin);
	                     	 }
	            			  String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/biddingtenderdashboard/"+tenderId+"/7");
	            			  String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
	            			  mailParams.put("link", hrefStr);
	            			  mailContentUtillity.dynamicMailGeneration("54", "0", String.valueOf(tenderId), mailParams, String.valueOf(previousEnvlpId),String.valueOf(envelopeId));
	            		  }
	            	  }
	            	  if(success){
	            		  retVal="redirect:/etender/buyer/tenderdashboard/"+tenderId+"/7"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/7", request);
	            	  }
	              }
	              redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? (oprType == 1 || oprType == 2) ? "msg_success_pricebidopeningdate" : "msg_success_pricebidopeningdatepublish" : !isServerSideValidate ? "msg_workflow_already_proceed" : CommonKeywords.ERROR_MSG_KEY.toString());
        	  }
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
        	int linkId=0;
			String message="";
			switch (oprType) {
				case 1:
					linkId=createPriceBidOpeningDateLinkId;
					message=MessageFormat.format(postOpeningDate, envelopeName);
					break;
				case 2:
					linkId=editPriceBidOpeningDateLinkId;
					message=MessageFormat.format(postEditOpeningDate, envelopeName);
					break;
				case 3:
					linkId=publishPriceBidOpeningDateLinkId;
					message=MessageFormat.format(postPublishOpeningDateConfg, envelopeName);
					break;
			
			}
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, message, tenderId, envelopeId);
        }
        return retVal;
    }
    
    /**
     * Method use for get consortium detail for view consortium
     * @author dipal
     * @param tenderId
     * @param envelopeId
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */
    @RequestMapping(value = {"/common/viewconsortium/{tenderId}/{consortiumId}/{enc}"}, method = RequestMethod.GET)
    public String showViewConsortiumDetail(@PathVariable("tenderId") int tenderId,@PathVariable("consortiumId") int consortiumId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        try {
            if (session !=null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null && session.getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) 
            {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                modelMap.addAttribute("lstConsortDtl", eventBidSubmissionService.getSecondaryPartnerRequest(tenderId, consortiumId));     
                page = "/etender/common/ViewConsortiumDetail";
            }
            else
            {
                page =  REDIRECT_SESSION_EXPIRED;
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getViewConsortiumDetail, tenderId, consortiumId);
        }
        return page;
    }
    
    /**
     * Method use for verify bid
     * @param tenderId
     * @param formId
     * @param bidderId
     * @param response
     * @param httpSession
     * @param request
     * @throws IOException 
     */
    @RequestMapping(value = {"/buyer/ajaxcall/verfiyBid"}, method = RequestMethod.POST)
    public void verifyBid(@RequestParam("hdTenderId") int tenderId, @RequestParam("txtFormId") int formId, @RequestParam("txtBidderId") int bidderId, HttpServletResponse response, HttpSession httpSession, HttpServletRequest request) throws IOException {
        String msg="failed";
        try {
            if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                if(tenderOpenService.verifyBidDetail(tenderId,formId,bidderId))
                {
                    msg="success";
                }
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkTenderVerifyBid, postTenderVerifyBid, tenderId, formId);
        }
        response.getWriter().write(msg);
    }

    
    @RequestMapping(value = {"/buyer/ajax/checkPreviousEnvelopeReportStatus"}, method = RequestMethod.POST)
    public void checkPreviousEnvelopeReportStatus(@RequestParam("tenderId") int tenderId, @RequestParam("envelopeId") int envelopeId, @RequestParam("envelopeIdReport") int envelopeIdReport, HttpServletResponse response, HttpSession httpSession, HttpServletRequest request) throws IOException {
        String statusPending="Published";
        try {
        	//System.out.println(tenderId + "tenderId " + envelopeIdReport + "envelopeId");
 			 if(envelopeIdReport!=envelopeId){
 				List<Object[]> tenderReportList = tenderOpenService.getTenderReportDetailFromEnvelopeId(tenderId, envelopeIdReport);
	 			for(int i =0 ; i < tenderReportList.size();i++)
	 			{
	 				int cstatus =  Integer.parseInt(tenderReportList.get(i)[1].toString());
	 				if(cstatus == 0 || cstatus == 3){
	 					statusPending = "Pending";
	 				}
	 			}
 			 }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        response.getWriter().write(statusPending);
    }
    
    @RequestMapping(value = "/buyer/itemwisebidsubmissioncountreport/{tenderId}/{enc}", method = RequestMethod.GET)
    public String itemWiseBidSubmissionCountReport(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            	List<Object[]> listItemWiseBidSubmissionCount = tenderOpenService.getItemWiseBidSubmissionCount(tenderId);
            	modelMap.addAttribute("listItemWiseBidSubmissionCount",listItemWiseBidSubmissionCount);
                page = "/etender/common/ItemWiseBidSubmissionCountReport";
            }
            else
            {
                page =  REDIRECT_SESSION_EXPIRED;
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getItemWiseBidSubmissionCount, tenderId, tenderId);
        }
        return page;
    }
    
    @RequestMapping(value="/buyer/Notification/{tenderId}/{enc}",method= RequestMethod.GET)
    public String viewnotification(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    	
    	 String page="etender/buyer/Notification";  
         try {
             if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
             {
            	 List<SelectItem> bidderNotification = new ArrayList<SelectItem>();
            	 bidderNotification.add(new SelectItem("All bidders", 2));
            	 bidderNotification.add(new SelectItem("Qualified bidders",1));
            	 bidderNotification.add(new SelectItem("Disqualified bidders", 0));
            	
            	int userId=abcUtility.getSessionUserId(request);
            	int clientId = abcUtility.getSessionClientId(request);
          	    tenderCommonService.tenderSummary(tenderId, modelMap, clientId);
          	    int envelopeId=tenderOpenService.getOpenedEnvelopId(tenderId);
          	    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(additionalNotificationEventId, clientId);
          	    List<Object[]> notificationhistory =  tenderOpenService.getNofiticationHistory(tenderId);
          	    int allowedSize = 0;
          	    StringBuilder allowedExt = new StringBuilder();
          	    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
          			allowedSize = lstDocUploadConf.get(0).getMaxSize();
          			allowedExt.append(lstDocUploadConf.get(0).getType());
          			modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
          	    }
          	    int index = allowedExt.toString().indexOf(",");
          	    allowedExt.insert(index + 1, "*.");
          	    while (index >= 0) {
          			index = allowedExt.toString().indexOf(",", index + ",".length());
          			allowedExt.insert(index + 1, "*.");
          	    }
          	    modelMap.addAttribute("isbidderNotification", 2);
          	    modelMap.addAttribute("bidderNotification",bidderNotification);
          	    modelMap.addAttribute("allowedExt", allowedExt);
          	    modelMap.addAttribute("allowedSize", allowedSize/1024);
          	    modelMap.addAttribute("linkId",upload_notificationLinkId);
          	    modelMap.addAttribute("tenderId", tenderId);
          	    modelMap.addAttribute("envelopeId", envelopeId);
          	    modelMap.addAttribute("isTenderDocDownload", "Y");
          	    modelMap.addAttribute("cStatusDoc", 0); //office upload doc status pending
            	modelMap.addAttribute("listhistorynotification", notificationhistory);
            	
            	//Bug #33252
            	String userSessionId="";
            	userSessionId = userId + "_" + session.getId();
            	fileUploadService.removeOfficerUplodedNotificationDoc(clientId, upload_notificationLinkId, userId, "", userSessionId);
             }
             else
             {
                 page =  REDIRECT_SESSION_EXPIRED;
             }
         } catch (Exception e) {
             exceptionHandlerService.writeLog(e);
         } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), upload_notificationLinkId, getnotificationpageaceess, tenderId, tenderId);
         }
         return page;
   	
    }
    
    @RequestMapping(value = "/buyer/sendNotificationMail", method = RequestMethod.POST)
    public String sendNotificationMail(ModelMap modelMap,RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/sessionexpired";
        int tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
       // int envelopeId=StringUtils.hasLength(request.getParameter("hdenvelopeId")) ? Integer.parseInt(request.getParameter("hdenvelopeId")) : 0;
        boolean success = false;
        try {
        	  int userId=abcUtility.getSessionUserId(request);
        	  int clientId = abcUtility.getSessionClientId(request);
        	  String msg="";
        	  tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	  if(userId!=0 && (abcUtility.getSessionUserTypeId(request) ==1 || abcUtility.getSessionUserTypeId(request) == 3)){
        		 String notificationMsg = StringUtils.hasLength(request.getParameter("txtanotificationname")) ? request.getParameter("txtanotificationname") : null;
        		 int status = StringUtils.hasLength(request.getParameter("rdbidderNotification")) ? Integer.parseInt(request.getParameter("rdbidderNotification")) : 0;
        		 String txtHidDocIds = CommonUtility.checkNull(request.getParameter("txtHidDocIds"));
        		 String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
        		 int envelopeId=tenderOpenService.getLatestBidderApprovalEnvelopeIdFromTenderId(tenderId);
        		 List<Object[]> listLoginIds=tenderOpenService.getBidderApprovalDetailFromEnvelopeId(tenderId, envelopeId, status);
        		 int docId = 1;
        		 StringBuilder loginIds=new StringBuilder();
        		 if(txtHidDocIds!=null && txtHidDocIds!=""){
        			 docId = fileUploadService.getOfficerDocId(txtHidDocIds);
        		 }
        		 
        		 if(docId != 0){
        			 if(listLoginIds != null && !(listLoginIds.isEmpty())){
            			 for(Object[] loginIdArray:listLoginIds){
            				 loginIds.append(loginIdArray[0]+",");
            			 }
            			 loginIds.deleteCharAt(loginIds.length()-1);
            			 success=true;
            		 }else{
            			 msg= "no_bidders_found";
            		 }
        			 
        			 if(success){
            			 TblNotification tblNotification=new TblNotification();
    	        		 if(status!=2){
    	        			 tblNotification.setEnvelopeId(envelopeId);
    	        		 }else{
    	        			 tblNotification.setEnvelopeId(0); //ALL BIDDER
    	        		 }
    	        		 tblNotification.setObjectId(tenderId);
    	        		 tblNotification.setBidderStatus(status);
    	        		 tblNotification.setNotificationMsg(notificationMsg);
    	        		 tblNotification.setSubmitedBy(userId);
    	        		 tblNotification.setIpAddress(ipAddress);
    	        		 success=tenderOpenService.saveNotificationMailData(tblNotification,txtHidDocIds,userId);
    	        		 if(success){
    	        			 if(txtHidDocIds!=null && txtHidDocIds!=""){
    		        			 fileUploadService.changeDocFolderByDocMappingId(txtHidDocIds);
    	        			 }
    	        			 Map<String,Object> mailParams=new HashMap<String, Object>();
    	        			 mailParams.put("to",loginIds.toString());
    	       		      	 mailParams.put("tenderId", tenderId);
    	       		      	 mailParams.put("notificationText", notificationMsg);
    	       		      	 mailParams.put("clientName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
    	       		      	 List<Object[]> listObjects=fileUploadService.getOfficerDocs(tblNotification.getNotificationId(),abcUtility.getSessionClientId(request),upload_notificationLinkId,1);
    	       		         List<String> attachmentList = new ArrayList<String>();	
    	       		      	 for(Object object[]:listObjects){
    	       		      		 attachmentList.add(doc_upload_path+"\\"+object[9].toString()+"\\"+object[1].toString());
    	       		      	 }
    	       		      	 if(attachmentList!=null && !(attachmentList.isEmpty())){
    	       		      		 mailParams.put("attachmentPath", attachmentList);
    	       		      		 mailContentUtillity.dynamicMailGeneration("258", String.valueOf(userId), String.valueOf(tenderId), mailParams, "");
    	       		      	 }else{
    	       		      		 mailContentUtillity.dynamicMailGeneration("259", String.valueOf(userId), String.valueOf(tenderId), mailParams, "");
    	       		      	 }
    	        		 }
            		 } //Bug #33252
            		 else {
            			fileUploadService.removeOfficerUplodedNotificationDoc(clientId, upload_notificationLinkId, userId, txtHidDocIds,"");
            		 }
        		 }else{
        			 msg="uploaded_document_not_found";
        		 }
       
        		 if(success){
        			 retVal="redirect:/etender/buyer/tenderdashboard/"+tenderId+"/7"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+tenderId+"/7", request);
        		 }else{
        			 retVal="redirect:/etender/buyer/Notification/"+tenderId+encryptDecryptUtils.generateRedirect("etender/buyer/Notification/"+tenderId, request);
        		 }
        	  }
        	  redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "mail_successfully_sent" : msg);
        } catch (Exception ex) {
        	retVal= exceptionHandlerService.writeLog(ex);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), upload_notificationLinkId, sendnotificationMail, tenderId, tenderId);
        }
        return retVal;
    }
    
    
    @RequestMapping(value="/bidder/getPublishedNotification/{tenderId}/{enc}",method= RequestMethod.GET)
    public String getPublishedNotification(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    	 String page="etender/bidder/Notification";  
         try {
             if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
             {
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request)); 
            	List<Object[]> listNotification=tenderOpenService.getBidderNofiticationHistory(tenderId,abcUtility.getSessionUserId(request));
                modelMap.addAttribute("listhistorynotification", listNotification);
             }
             else
             {
                 page =  REDIRECT_SESSION_EXPIRED;
             }
         } catch (Exception e) {
             exceptionHandlerService.writeLog(e);
         } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), upload_notificationLinkId, getviewnotification, tenderId, tenderId);
         }
         return page;
   	
    }
    
    
    
    /**
     * used to view toc report
     * @param tenderId
     * @param envelopeId
     * @param tenderReportId
     * @param tenderReportType
     * @param request
     * @param modelMap
     * @return String
     */
    @RequestMapping(value = {"/buyer/viewtocaudittrailreport/{tenderId}/{tenderReportId}/{tenderReportType}/{enc}","/buyer/viewtecaudittrailreport/{tenderId}/{tenderReportId}/{tenderReportType}/{enc}"}, method = RequestMethod.GET)
    public String viewTOCAuditTrailReport(@PathVariable("tenderId") int tenderId,@PathVariable("tenderReportId") int tenderReportId,@PathVariable("tenderReportType") int tenderReportType,HttpServletRequest request, ModelMap modelMap) {
    	//int tenderReportType=0;
    	try {
			//tenderReportType=tenderCommitteeType==4?1:tenderCommitteeType;//Use only To manage go-back issue from evaluation tab. 4 means it come from evaluation tab for opening report
    		int tenderCommitteeType=0;
    		if(tenderReportType==4){
    			tenderCommitteeType=4;
    			tenderReportType=1;
    		}
		    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
		    modelMap.addAttribute("isReadOnly", "Y");
		    modelMap.addAttribute("linkId", tenderReportType == 1 ? prepareTOCReportLinkId : prepareTECReportLinkId);
		    modelMap.addAttribute("tenderId", tenderId);
		    modelMap.addAttribute("objectId", tenderReportId);
		    
		    TblTenderReport tblTenderReport = tenderReportService.getTenderReportDetail(tenderReportId);
		    if(tblTenderReport!=null){
		    	 modelMap.addAttribute("reportName", tblTenderReport.getReportName());
		    	 modelMap.addAttribute("cstatus", tblTenderReport.getCstatus());
		    }
		    	 if(tblTenderReport!=null && (tblTenderReport.getCstatus()==0 || tblTenderReport.getCstatus()==3) ){ //pending TOC/TEC Report View
						modelMap.addAttribute("cStatusDoc", 0);
						modelMap.addAttribute("cStatusDocView", 0);
					}else{
						 modelMap.addAttribute("cStatusDoc", 1);
						 modelMap.addAttribute("cStatusDocView", 1);
					}
		    modelMap.addAttribute("tenderEnvelopeDetailsList",tenderOpenService.getTenderEnvelopeDetailFromTenderReportId(tenderReportId,tenderReportType));
		    modelMap.addAttribute("tenderReportType", tenderCommitteeType==4?2:tenderReportType);
		    modelMap.addAttribute("tenderCommitteeType", tenderCommitteeType);
		    modelMap.addAttribute("workFlowFlag", 0);
		    if(request.getRequestURI().contains("/buyer/viewtocreportforwrkflw/") || request.getRequestURI().contains("/buyer/viewtecreportforwrkflw/")){
		    	modelMap.addAttribute("workFlowFlag", 1);
		    }
		    
		}catch (Exception e) {
		    return exceptionHandlerService.writeLog(e);
		}finally {
			int linkId=0;
			String msg="";
			if(tenderReportType == 1){
				linkId=viewPrepareTOCReportLinkId;
				msg=getViewTOCReport;
			}else if(tenderReportType == 2){
				linkId=viewPrepareTECReportLinkId;
				msg=getViewTECReport;
			}
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, tenderId, tenderReportId);
		}
    	modelMap.addAttribute("flagStatus", 0);
		return "etender/buyer/ViewTOCReport";
    }
    /**
     * 
     * @param tenderId
     * @param envelopeId
     * @param companyId
     * @param bidderId
     * @param modelMap
     * @param request
     * @param session
     * @return
     */
    @RequestMapping(value ="/buyer/bidderAccessFormdetail/{tenderId}/{envelopeId}/{companyId}/{bidderId}/{enc}", method = RequestMethod.GET)
    public String bidderAcessFormdetail(@PathVariable("tenderId") int tenderId,@PathVariable("envelopeId") int envelopeId,@PathVariable("companyId") int companyId,@PathVariable("bidderId") int bidderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    	 String page="";  
    	 int consortiumId =0;
         int linkId=linkOpeningBidderWiseReport;
         try {
             if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
             {
                 if(abcUtility.getSessionUserTypeId(request) == 2)
                 {
                     linkId=linkBidderSideBidderWiseReport;
                 }
                 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                 if(request.getParameter("hdisPrintPriview")!=null)
                 {
                     modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                 }
                 List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                     if(!lstClientDtls.isEmpty()){
                         modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                         modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                     }
                 Map<String,Object> outMap= tenderOpenService.getBidderWiseReportDetail(tenderId,envelopeId,bidderId,consortiumId);
                 if(outMap != null && !outMap.isEmpty())
                 {
                     if(outMap.get(RESULTSET_1) !=null) // Tender Form
                     {
                         modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                     }
                     if(outMap.get(RESULTSET_2) !=null) // Tender Table
                     {
                         modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                     }
                     if(outMap.get(RESULTSET_3) !=null) // Tender Column
                     {
                         modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                     }
                     if(outMap.get(RESULTSET_4) !=null) // Tender cell - Filled by Officer
                     {
                         modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                     }
                     if(outMap.get(RESULTSET_5) !=null) // Tender bidder 
                     {
                         modelMap.addAttribute("lstCompanyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                     }
                     if(outMap.get(RESULTSET_6) !=null) // Tender bid 
                     {
                         modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                     }
                      if(outMap.get(RESULTSET_7) !=null) // Tender Form bidded multiple time 
                     {
                         modelMap.addAttribute("lstFormBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                         for (LinkedHashMap<String, Object> multiFillBidDtl : (ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7)) {
                             if(tenderFormService.getCountofActiveForm(Integer.parseInt(multiFillBidDtl.get("tenderId").toString()),Integer.parseInt(multiFillBidDtl.get("envelopeId").toString()),Integer.parseInt(multiFillBidDtl.get("bidderId").toString()))==0){
                             	modelMap.addAttribute("isCancelForm",1 );
                             }
                         }
                     }
                     if(outMap.get(RESULTSET_8) !=null) // Tender Table bidded multiple time by add row
                     {
                         modelMap.addAttribute("lstTableBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                     }   
                     
                     if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                     {
                         modelMap.addAttribute("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                     }
                     if(outMap.get(RESULTSET_10) !=null) // Upload Document details
                     {
                         modelMap.addAttribute("lstDocumentDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                     }
                     if(outMap.get(RESULTSET_12) !=null) // Tender Proxy column Details
                     {
                         modelMap.addAttribute("lstTenderProxyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_12) );
                     }
                     if(outMap.get(RESULTSET_13) !=null) // Item wise bidder Mapping Details
                     {
                         modelMap.addAttribute("lstItemWiseBidderMapDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_13) );
                     }
                     if(outMap.get(RESULTSET_14) !=null) // Item wise bidder doc Details
                     {
                         modelMap.addAttribute("listItemWiseBidderDocDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_14) );
                     }
                 }
                 List<String> formTableBidderIdList = new ArrayList<String>();
                 List<String> formTableIdList=tenderCommonService.getTenderFormIdTableIdByTenderAndBidderId(tenderId,bidderId);
 				 modelMap.addAttribute("CompanyName", commonService.getCompanyNameByCompanyId(companyId));
 				 if(formTableIdList!=null && !formTableIdList.isEmpty()){
 				 for(int formCtr=0;formCtr<formTableIdList.size();formCtr++){
 					 formTableBidderIdList.add(formTableIdList.get(formCtr)+"_"+bidderId);
 	        	  }
 				 }
 				modelMap.addAttribute("formTableBidderIdList",formTableBidderIdList);				
 				page = "/etender/common/BidderAccessFormdetail";
             }
             else
             {
                 page =  REDIRECT_SESSION_EXPIRED;
             }
     } catch (Exception e) {
             exceptionHandlerService.writeLog(e);
     } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderOpeningBidderWiseAbstractReport, tenderId, bidderId);
     }
         return page;
     }
    
    /**
     * @author meghna
     * @param tenderId
     * @param commiteeType
     * @param bidderConsId
     * @param modelMap
     * @param request
     * @param session
     * @return
     */
    @RequestMapping(value = "/buyer/getregretitemlist/{tenderId}/{commiteeType}/{bidderId}/{enc}", method = RequestMethod.GET)
    public String showRegretedItemsByBidser(@PathVariable("tenderId") int tenderId, @PathVariable("commiteeType") int commiteeType, @PathVariable("bidderId") String bidderConsId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page=REDIRECT_SESSION_EXPIRED;  
        int bidderId = 0;
        List<Object[]> lstRegrettedItems =null;
        List<Object[]> tableDetail =null;
        Map<Integer, List<Object>> itemMap = new HashMap<Integer, List<Object>>();
        Map<Integer, Map<Integer, List<Object>>> formMap = new HashMap<Integer, Map<Integer, List<Object>>>();
        List<Object> itemList = new ArrayList<Object>();
        List<Object[]> formList = null;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            	bidderId = Integer.parseInt(encryptDecryptUtils.decrypt(bidderConsId));
            	modelMap.addAttribute("commiteeType", commiteeType);
            	lstRegrettedItems = tenderOpenService.getRegretedItemsByBidder(tenderId,bidderId,2,1);
            	tableDetail = tenderOpenService.getRegretedItemsByBidder(tenderId, bidderId, 2,2);
            	formList = tenderOpenService.getTenderDecrypteddPriceBidForm(tenderId,bidderId);
            	if((!lstRegrettedItems.isEmpty() && lstRegrettedItems!=null) && (!formList.isEmpty() && formList!=null) && (!tableDetail.isEmpty() && tableDetail!=null)){
            			for(Object[] form : formList){
            				for(Object[] off : tableDetail){
            					if(form[0].toString().equals(off[2].toString())){
	                				for(Object[] obj : lstRegrettedItems){
	                					if(off[0].toString().equals(obj[4].toString()) && form[0].toString().equals(obj[6].toString())){
	                						itemList.add(obj);
	                					}
	                				}
	                				itemMap.put(Integer.parseInt(off[0].toString()), itemList);
	                				itemList = new ArrayList<Object>();
            					}
                			}
            				formMap.put(Integer.parseInt(form[0].toString()), itemMap);
            				itemMap = new HashMap<Integer, List<Object>>();
            			}
            	}
            	modelMap.addAttribute("formList", formMap);
            	page = "/etender/buyer/RegretedItems";
            }
    	}catch (Exception e) {
            exceptionHandlerService.writeLog(e);
    	} finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getRegrettedItemsOfBidder, tenderId, bidderId);
    	}
        return page;
    }
    
    @RequestMapping(value = {"/buyer/generateCGReport2/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String generateCGReport2(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    String page="";  
    int formId = 0;
    try {
        if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
        {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		Map<String, Object> outMap= tenderOpenService.getCGReport2Detail(tenderId, abcUtility.getSessionClientId(request));
    		if(outMap.get(RESULTSET_1) !=null) // Tender Form
            {
    			modelMap.addAttribute("lstBidderPriceDetail",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
            }
            if(outMap.get(RESULTSET_2) !=null) // Tender Table
            {
                modelMap.addAttribute("ColumnDetails",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
            }
            if(outMap.get(RESULTSET_3) !=null) // Tender Table
            {
                modelMap.addAttribute("FormName",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
            }
            page = "/etender/common/CGReport2";
        }
        else
        {
            page =  REDIRECT_SESSION_EXPIRED;
        }
    } catch (Exception e) {
        exceptionHandlerService.writeLog(e);
    } finally {
    	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), cgReport2, getTenderCGReport2, tenderId, 0);
    }
    return page;
	}
    
    @RequestMapping(value = {"/buyer/generateCGReport1/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String generateCGReport1(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    String page="";  
    int formId = 0;
    try {
        if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
        {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		Map<String, Object> outMap= tenderOpenService.getCGReport1Detail(tenderId, abcUtility.getSessionClientId(request));
    		if(outMap.get(RESULTSET_1) !=null) // Tender Form
            {
    			modelMap.addAttribute("lstBidderPriceDetail",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
            }
            if(outMap.get(RESULTSET_2) !=null) // Tender Table
            {
                modelMap.addAttribute("ColumnDetails",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
            }
            if(outMap.get(RESULTSET_3) !=null) // Tender Table
            {
                modelMap.addAttribute("FormName",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
            }
            page = "/etender/common/CGReport1";
        }
        else
        {
            page =  REDIRECT_SESSION_EXPIRED;
        }
    } catch (Exception e) {
        exceptionHandlerService.writeLog(e);
    } finally {
    	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), cgReport1, getTenderCGReport1, tenderId, 0);
    }
    return page;
	}
}
            