package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblArchiveExceptionLog;
import com.etl.eproc.etender.daointerface.TblArchiveExceptionLogDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblArchiveExceptionLogImpl extends AbcAbstractClass<TblArchiveExceptionLog> implements TblArchiveExceptionLogDao {

   

    @Override
    public void addTblArchiveExceptionLog(TblArchiveExceptionLog tblArchiveExceptionLog){
        super.addEntity(tblArchiveExceptionLog);
    }

    @Override
    public void deleteTblArchiveExceptionLog(TblArchiveExceptionLog tblArchiveExceptionLog) {
        super.deleteEntity(tblArchiveExceptionLog);
    }

    @Override
    public void updateTblArchiveExceptionLog(TblArchiveExceptionLog tblArchiveExceptionLog) {
        super.updateEntity(tblArchiveExceptionLog);
    }

    @Override
    public List<TblArchiveExceptionLog> getAllTblArchiveExceptionLog() {
        return super.getAllEntity();
    }

    @Override
    public List<TblArchiveExceptionLog> findTblArchiveExceptionLog(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblArchiveExceptionLogCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblArchiveExceptionLog> findByCountTblArchiveExceptionLog(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblArchiveExceptionLog(List<TblArchiveExceptionLog> tblArchiveExceptionLogs){
        super.updateAll(tblArchiveExceptionLogs);
    }
    
/*  @Override
    public void saveOrUpdateTblArchiveExceptionLog(TblArchiveExceptionLog tblArchiveExceptionLog){
        super.saveOrUpdateEntity(tblArchiveExceptionLog);
    }
*/
}
