/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblDecryptionFailDao;
import com.etl.eproc.etender.model.TblDecryptionFail;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;



@Repository @Transactional
public class TblDecryptionFailImpl extends AbcAbstractClass<TblDecryptionFail> implements TblDecryptionFailDao {


    @Override
    public void addTblDecryptionFail(TblDecryptionFail tblDecryptionFail){
        super.addEntity(tblDecryptionFail);
    }

    @Override
    public void deleteTblDecryptionFail(TblDecryptionFail tblDecryptionFail) {
        super.deleteEntity(tblDecryptionFail);
    }

    @Override
    public void updateTblDecryptionFail(TblDecryptionFail tblDecryptionFail) {
        super.updateEntity(tblDecryptionFail);
    }

    @Override
    public List<TblDecryptionFail> getAllTblDecryptionFail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDecryptionFail> findTblDecryptionFail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDecryptionFailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDecryptionFail> findByCountTblDecryptionFail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDecryptionFail(List<TblDecryptionFail> tblDecryptionFails){
        super.updateAll(tblDecryptionFails);
    }
}
