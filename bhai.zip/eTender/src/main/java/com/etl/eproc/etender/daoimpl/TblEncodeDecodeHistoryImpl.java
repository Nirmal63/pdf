package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblEncodeDecodeHistory;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblEncodeDecodeHistoryDao;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblEncodeDecodeHistoryImpl extends AbcAbstractClass<TblEncodeDecodeHistory> implements TblEncodeDecodeHistoryDao {


    @Override
    public void addTblEncodeDecodeHistory(TblEncodeDecodeHistory tblEncodeDecodeHistory){
        super.addEntity(tblEncodeDecodeHistory);
    }

    @Override
    public void deleteTblEncodeDecodeHistory(TblEncodeDecodeHistory tblEncodeDecodeHistory) {
        super.deleteEntity(tblEncodeDecodeHistory);
    }

    @Override
    public void updateTblEncodeDecodeHistory(TblEncodeDecodeHistory tblEncodeDecodeHistory) {
        super.updateEntity(tblEncodeDecodeHistory);
    }

    @Override
    public List<TblEncodeDecodeHistory> getAllTblEncodeDecodeHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblEncodeDecodeHistory> findTblEncodeDecodeHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblEncodeDecodeHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblEncodeDecodeHistory> findByCountTblEncodeDecodeHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblEncodeDecodeHistory(List<TblEncodeDecodeHistory> tblEncodeDecodeHistorys){
        super.updateAll(tblEncodeDecodeHistorys);
    }
}
