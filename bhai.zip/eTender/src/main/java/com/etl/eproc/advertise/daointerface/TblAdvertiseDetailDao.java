package com.etl.eproc.advertise.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.advertise.model.TblAdvertiseDetail;


import java.util.List;

public interface TblAdvertiseDetailDao  {

    public void addTblAdvertiseDetail(TblAdvertiseDetail tblAdvertiseDetail);

    public void deleteTblAdvertiseDetail(TblAdvertiseDetail tblAdvertiseDetail);

    public void updateTblAdvertiseDetail(TblAdvertiseDetail tblAdvertiseDetail);

    public List<TblAdvertiseDetail> getAllTblAdvertiseDetail();

    public List<TblAdvertiseDetail> findTblAdvertiseDetail(Object... values) throws Exception;

    public List<TblAdvertiseDetail> findByCountTblAdvertiseDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAdvertiseDetailCount();

    public void saveUpdateAllTblAdvertiseDetail(List<TblAdvertiseDetail> tblAdvertiseDetails);
}