package com.etl.eproc.etender.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblCentralizedCommittee;
import com.etl.eproc.common.model.TblCentralizedCommitteeUser;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.WorkflowService;
import java.util.Arrays;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.model.TblCommittee;
import com.etl.eproc.etender.model.TblCommitteeEnvelope;
import com.etl.eproc.etender.model.TblCommitteeUser;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.CommitteeFormationService;
import com.etl.eproc.etender.services.EventBidSubmissionService;
import com.etl.eproc.etender.services.EventCreationService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderFormService;

@Controller
@RequestMapping("/etender")
public class TenderCommitteeController {
	@Autowired
	private AbcUtility abcUtility;
	
	@Autowired
	private TenderCommonService tenderCommonService;
	@Autowired
	private WorkflowService workflowService;
	
	@Autowired
	private CommitteeFormationService committeeFormationService;
	
	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
	
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private AuditTrailService auditTrailService;
	@Autowired
	private EventCreationService eventCreationService;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private LoginService loginService;
    @Autowired
    private DepartmentUserService departmentUserService;
    @Autowired
    EventBidSubmissionService eventBidSubmissionService;
	@Value("#{projectProperties['pki_enable']?:1}")   
    private int pkiEnable;
	
    @Value("#{projectProperties['pki_eventspecific']?:2}")   
    private int pkiEventSpecific;
    
    @Value("#{projectProperties['price_envelope_type']?:'4,5'}")
    private String priceEnvelopeType;
	
	@Value("#{tenderlinkProperties['bid_opening_create']?:222}")
	private int tocCreateLinkId;
	
	 @Value("#{tenderlinkProperties['bid_opening_process_in_workflow']?:244}")
	    private int openingProcessWorkflowLinkId;
	 
	@Value("#{etenderAuditTrailProperties['get_create_toc_committee']}")
    private String getCreateTocCommittee;
	
	@Value("#{etenderAuditTrailProperties['get_bidopening_tocnote']}")
    private String getBidOpeningTocNote;
	
	@Value("#{etenderAuditTrailProperties['post_add_toc_committee']}")
    private String postAddTocCommittee;
	
	@Value("#{etenderAuditTrailProperties['get_edit_centralized_tec_committee']}")
    private String getEditCentralizedTecCommittee;
	@Value("#{etenderAuditTrailProperties['get_create_centralized_toc_committee']}")
    private String getCreateCentralizedTocCommittee;
	@Value("#{etenderAuditTrailProperties['get_edit_centralized_toc_committee']}")
    private String getEditCentralizedTocCommittee;
	@Value("#{etenderAuditTrailProperties['get_create_centralized_tec_committee']}")
    private String getCreateCentralizedTecCommittee;
	
	@Value("#{etenderAuditTrailProperties['post_edit_centralized_toc_committee']}")
    private String postEditCentralizedTocCommittee;
	@Value("#{etenderAuditTrailProperties['post_edit_centralized_tec_committee']}")
    private String postEditCentralizedTecCommittee;
	@Value("#{etenderAuditTrailProperties['post_add_centralized_toc_committee']}")
    private String postAddCentralizedTocCommittee;
	@Value("#{etenderAuditTrailProperties['post_add_centralized_tec_committee']}")
    private String postAddCentralizedTecCommittee;
	
	
	
	@Value("#{tenderlinkProperties['bid_opening_edit']?:223}")
	private int tocEditLinkId;
	
	@Value("#{tenderlinkProperties['bid_opening_edit_after_publish']?:327}")
	private int tocPublishedEditLinkId;
	
	@Value("#{etenderAuditTrailProperties['get_edit_toc_committee']}")
    private String getEditTocCommittee;
	
	@Value("#{etenderAuditTrailProperties['post_edit_toc_committee']}")
    private String postEditTocCommittee;
	
	@Value("#{etenderAuditTrailProperties['get_published_edit_toc_committee']}")
	private String getPublishedEditTocCommittee;
	
	@Value("#{etenderAuditTrailProperties['post_published_edit_toc_committee']}")
	private String postPublishedEditTocCommittee;
	
	@Value("#{tenderlinkProperties['bid_opening_publish']?:225}")
	private int tocPublishLinkId;
	
	@Value("#{etenderAuditTrailProperties['get_publish_toc_committee']}")
    private String getPublishTocCommittee;
	
	@Value("#{etenderAuditTrailProperties['post_publish_toc_committee']}")
    private String postPublishTocCommittee;
	
	@Value("#{tenderlinkProperties['bid_opening_view']?:224}")
	private int tocViewLinkId;
	
	@Value("#{etenderAuditTrailProperties['get_view_toc_committee']}")
    private String viewTocCommittee;
	
	@Value("#{etenderAuditTrailProperties['get_view_toc_committee_digitalCertificate']}")
    private String viewTocCommitteeDigiCert;
	
	@Value("#{tenderlinkProperties['bid_evaluation_create']?:205}")
	private int tecCreateLinkId;
	
	@Value("#{etenderAuditTrailProperties['get_create_tec_committee']}")
    private String getCreateTecCommittee;
	
	@Value("#{etenderAuditTrailProperties['post_add_tec_committee']}")
    private String postAddTecCommittee;
	
	@Value("#{tenderlinkProperties['bid_evaluation_edit']?:206}")
	private int tecEditLinkId;
	
	@Value("#{tenderlinkProperties['bid_evaluation_edit_after_publish']?:331}")
	private int tecPublishedEditLinkId;
	
	@Value("#{etenderAuditTrailProperties['get_edit_tec_committee']}")
    private String getEditTecCommittee;
	
	@Value("#{etenderAuditTrailProperties['post_edit_tec_committee']}")
    private String postEditTecCommittee;
	
	@Value("#{etenderAuditTrailProperties['get_published_edit_tec_committee']}")
	private String getPublishedEditTecCommittee;
	
	@Value("#{etenderAuditTrailProperties['post_published_edit_tec_committee']}")
	private String postPublishedEditTecCommittee;
	
	@Value("#{tenderlinkProperties['bid_evaluation_publish']?:208}")
	private int tecPublishLinkId;
	
	@Value("#{etenderAuditTrailProperties['get_publish_tec_committee']}")
    private String getPublishTecCommittee;
	
	@Value("#{etenderAuditTrailProperties['post_publish_tec_committee']}")
    private String postPublishTecCommittee;
	
	@Value("#{tenderlinkProperties['bid_evaluation_view']?:207}")
	private int tecViewLinkId;
	
	@Value("#{tenderlinkProperties['toc_centralized_manage']?:816}")
	private int tocCentralizeManage;
	
	@Value("#{tenderlinkProperties['tec_centralized_manage']?:817}")
	private int tecCentralizeManage;
	
	@Value("#{etenderAuditTrailProperties['get_view_tec_committee']}")
    private String viewTecCommittee;
	
	 @Value("#{projectProperties['opening.nonpki.singlestage.minimum.member.required']}")   
	 private int nonPkiSingleStageOpeningCommitee;
	 
	 @Value("#{projectProperties['opening.nonpki.twostage.minimum.member.required']}")   
	 private int nonPkiTwoStageOpeningCommitee;
	 
	 @Value("#{tenderlinkProperties['bid_opening_tocnote']?:2299}")
	 private int bidOpeningTocNote;
	 
	 @Value("#{projectProperties['evaluation.pki.multiple.level.twostage.minimum.member.required']}")   
	 private int evaPkiMultipleLevelTwoStageEvaluationCommitee;
	 
	 @Value("#{projectProperties['evaluation.pkinonpki.single.level.twostage.minimum.member.required']}")   
	 private int evaPkiNonPkiSingleLevelTwoStageEvaluationCommitee;
	 @Value("#{etenderAuditTrailProperties['getViewRegretBidFromBidOpeningTab']}")
	 private String getViewRegretBidFromBidOpeningTab;

	private static final int TAB_TENDER_OPENING = 7;
	private static final int TAB_EVALUATE_BID = 8;
	
	private static final String TENDER_ID = "tenderId";
	private static final String COMMITTEE_TYPE = "committeeType";
	private static final String IS_CERT_REQUIRED = "isCertRequired";
	private static final String ENCRYPTION_LEVEL = "encryptionLevel";
	private static final String ENV_LIST = "envList";
	private static final String IS_DECRYPTER_REQ = "isDecrypterReq";
	private static final String IS_2LEVEL_ENC = "is2LevelEnc";
	private static final String COMMITTEE_NAME = "committeeName";
	private static final String ENC_LEVEL = "encLevel_";
	private static final String MIN_APPROVAL_REQ = "minApprovalReq_";
	private static final String HD_IS_BIDENCRYPTED = "hdIsBidEncrypted";
	private static final String SESSIONEXPIRED = "sessionexpired";
        private static final String IS_MULTILEVEL_EVALUATION_REQ = "multiLevelEvaluationReq";
        private static final String IS_TWO_STAGE_EVALUATION = "isTwoStageEvaluation";
        private static final String IS_TWO_STAGE_OPENING = "isTwoStageOpening";
	
	
	/**
	 * author bhavin.patel
	 * @param tenderId
	 * @param committeeType
	 * @param request
	 * @param modelMap
	 * @return
	 * 
	 */
	@RequestMapping(value="/buyer/createcommittee/{tenderId}/{committeeType}/{enc}", method=RequestMethod.GET)
	public String createCommittee(@PathVariable(TENDER_ID) Integer tenderId, @PathVariable(COMMITTEE_TYPE) Integer committeeType, HttpServletRequest request , ModelMap modelMap){
		int envCount = 0;
		int isDecrypterReq = 0;
		int minMember = 1;
	    ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	    int isTWoStageOpening=0;
	    int validationMsgFlag=0;
		try {			
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));			
			
			List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "encryptionLevel,isCertRequired,isTwoStageEvaluation,multiLevelEvaluationReq,isTwoStageOpening,decryptorRequired");
			if(tenderFields != null && !tenderFields.isEmpty()){
				modelMap.put(IS_2LEVEL_ENC, tenderFields.get(0)[0]);	
				modelMap.put(IS_CERT_REQUIRED, tenderFields.get(0)[1]);
                                modelMap.put(IS_TWO_STAGE_EVALUATION, tenderFields.get(0)[2]);
				modelMap.put(IS_MULTILEVEL_EVALUATION_REQ, tenderFields.get(0)[3]);
                                modelMap.put(IS_TWO_STAGE_OPENING, tenderFields.get(0)[4]);
                                isTWoStageOpening=Integer.parseInt(tenderFields.get(0)[4].toString());
                                
				List<Object[]> envList = committeeFormationService.getTenderEnvelopesDetails(tenderId);
                                
                                if(Integer.parseInt(tenderFields.get(0)[2].toString())==1 || Integer.parseInt(tenderFields.get(0)[4].toString())==1){
                                    List<Object[]> userRoleList=committeeFormationService.getAllUserRole();
                                    modelMap.addAttribute("userRoleList",  abcUtility.convert(userRoleList));
                                }
                                if(committeeType==2){
                                    List<SelectItem> itemsmultilevel = new ArrayList<SelectItem>();
                                    itemsmultilevel.add(new SelectItem("Level 1", 1)); 
                                    itemsmultilevel.add(new SelectItem("Level 2", 2));
                                    modelMap.addAttribute("itemsmultilevel", itemsmultilevel);
                                }
				if(envList != null && !envList.isEmpty()){
					envCount = envList.size();
					if(committeeType == 1){
						for(Object[] objArray : envList){
							if(Integer.parseInt(objArray[5].toString()) > 0){
								isDecrypterReq = 1;//if isEnc = 1 for any form type, then isDecrypterReq = 1
								break;
							}
						}
						//minMember = 2;
					}
					modelMap.put(ENV_LIST, envList);
					modelMap.put("envCount", envCount);
					
					if((Integer)tenderFields.get(0)[1] == 0){
						isDecrypterReq = 0;
					}
				}
				
				modelMap.put(IS_DECRYPTER_REQ,isDecrypterReq);
				
					if(committeeType==1){	//opening committee
						if((clientBean.getIsPkiEnabled()==0 && isTWoStageOpening==1) || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 0 &&  clientBean.getIsPkiEnabled()==2 && isTWoStageOpening==1)){
							//Non-PKI Committee req member (case : Two stage opening applicable.)
							minMember=nonPkiTwoStageOpeningCommitee;
							validationMsgFlag=1;
						}else if((clientBean.getIsPkiEnabled()==0 && isTWoStageOpening==0) || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 0 &&  clientBean.getIsPkiEnabled()==2 && isTWoStageOpening==0)){
							//Non-PKI Committee req member (case : Two stage opening not applicable.)
							minMember=nonPkiSingleStageOpeningCommitee;
							validationMsgFlag=2;
						}else if((clientBean.getIsPkiEnabled()==1 || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 1 &&  clientBean.getIsPkiEnabled()==2)) && isTWoStageOpening==1 && (Integer.parseInt(tenderFields.get(0)[0].toString())==1)){
							//PKI Committee req member (case : Single Encryption Level Two stage opening applicable.)
							minMember=Integer.parseInt(tenderFields.get(0)[5].toString());
							if(isDecrypterReq==1){validationMsgFlag=3;}else{validationMsgFlag=1;};
						}else if((clientBean.getIsPkiEnabled()==1 || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 1 &&  clientBean.getIsPkiEnabled()==2)) && isTWoStageOpening==0 && (Integer.parseInt(tenderFields.get(0)[0].toString())==1)){
							//PKI Committee req member (case : Single Encryption Level Two stage opening not applicable.)
							minMember=Integer.parseInt(tenderFields.get(0)[5].toString());
							if(isDecrypterReq==1){validationMsgFlag=4;}else{validationMsgFlag=2;};
						}else if((clientBean.getIsPkiEnabled()==1 || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 1 &&  clientBean.getIsPkiEnabled()==2)) && isTWoStageOpening==1 && (Integer.parseInt(tenderFields.get(0)[0].toString())==2)){
							//PKI Committee req member (case : Multiple Encryption Level Two stage opening applicable.)
							minMember=Integer.parseInt(tenderFields.get(0)[5].toString());
							if(isDecrypterReq==1){validationMsgFlag=5;}else{validationMsgFlag=1;};
						}else if((clientBean.getIsPkiEnabled()==1 || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 1 &&  clientBean.getIsPkiEnabled()==2)) && isTWoStageOpening==0 && (Integer.parseInt(tenderFields.get(0)[0].toString())==2)){
							//PKI Committee req member (case : Multiple Encryption Level Two stage opening not applicable.)
							minMember=Integer.parseInt(tenderFields.get(0)[5].toString());
							if(isDecrypterReq==1){validationMsgFlag=6;}else{validationMsgFlag=2;};
						}
				 }else if(committeeType==2 && (Integer.parseInt(tenderFields.get(0)[3].toString())==1)){ //evaluation committee
						//## PKI/NONPKI evaluation Committee req member (case : Multiple Encryption Level Two stage opening applicable.)
						minMember=evaPkiMultipleLevelTwoStageEvaluationCommitee;
						validationMsgFlag=7;
				 }else if(committeeType==2 && (Integer.parseInt(tenderFields.get(0)[2].toString())==1)){
						//## PKI/NONPKI evaluation Committee req member (case Two stage opening applicable)
						minMember=evaPkiNonPkiSingleLevelTwoStageEvaluationCommitee;
				}
				 
				modelMap.put("minMember", minMember);
				modelMap.put("validationMsgFlag", validationMsgFlag);
				
				modelMap.put("minMember", minMember);
				modelMap.put("isCertRequiredStatus", Integer.parseInt(modelMap.get("isCertRequired").toString())==1 ? true : false);
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);			
		}
		finally{
			if(committeeType == 1){
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocCreateLinkId, getCreateTocCommittee, tenderId , 0);	
			}
			else if(committeeType == 2){
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tecCreateLinkId, getCreateTecCommittee, tenderId , 0);
			}
		}
		return "etender/buyer/CreateTocTec";
	}
	
	@RequestMapping(value="/buyer/tocnote/{tenderId}/{committeeType}/{enc}", method=RequestMethod.GET)
	public String createTocNote(@PathVariable(TENDER_ID) Integer tenderId, @PathVariable(COMMITTEE_TYPE) Integer committeeType, HttpServletRequest request , ModelMap modelMap) throws Exception
	{
		try
		{
			ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
			Integer isShowEncodedName=0;
			List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "tenderNo,publishedOn,submissionEndDate,openingDate,tenderMode,encryptionLevel,isTwoStageOpening,isTwoStageEvaluation,isConsortiumAllowed,isEncodedName");
			List <Object[]> regrettedBidderList = null ; // tenderCommonService.getActiveRegrettedBidder(tenderId);
			List <Object[]> rejectedBidderList = null ; // tenderCommonService.getActiveRegrettedBidder(tenderId);
			List <Object[]> envelopeDetails=null;
			Integer tocTecTab = 1,envelopeId=0,isConsortiumAllowed = 0;
			Byte envId=0;
			int count = 0;
			Boolean isPriceBid = false;
			List <Object[]> respondendNotRespondendList = null;
			List <Object[]>	notRespondedBidderList = new ArrayList<Object[]>();
			
			Object tenderDetail = null;
			Boolean isLimited = false;
			String dateFormatStr = "yyyy-MM-dd" + " HH:mm";
			SimpleDateFormat dbDateFormat = new SimpleDateFormat(dateFormatStr);
			SimpleDateFormat clientDateFormat = new SimpleDateFormat(CommonUtility.getClientDateFormat()+" HH:mm");
			Date date=null;
			
			if(tenderDetails!=null && !tenderDetails.isEmpty())
			{
				for(Object[] selectedTenderDetails : tenderDetails)
				{
					respondendNotRespondendList = tenderCommonService.getListOfRespondedBidders(tenderId,clientBean.getClientId(),(Integer) selectedTenderDetails[4],(Integer) selectedTenderDetails[9]);
					tenderDetail = selectedTenderDetails;
			        selectedTenderDetails[1] = CommonUtility.convertTimezoneToClientTimezone(selectedTenderDetails[1]);
			        selectedTenderDetails[2] = CommonUtility.convertTimezoneToClientTimezone(selectedTenderDetails[2]);	
			        selectedTenderDetails[3] = CommonUtility.convertTimezoneToClientTimezone(selectedTenderDetails[3]);	
					isConsortiumAllowed=(Integer) selectedTenderDetails[8];
					Integer tempIsLimited = (Integer) selectedTenderDetails[4];
					isShowEncodedName = (Integer)selectedTenderDetails[9] ;
					if(tempIsLimited.equals(1))
					{
						isLimited = false;
					}
					else
					{
						isLimited = true;
					}
				}	
			}
			
			if(respondendNotRespondendList!=null && !respondendNotRespondendList.isEmpty()){
			for(Object[] cancelledBidders : respondendNotRespondendList)
			{
				if(cancelledBidders[3] == null)
				{
					notRespondedBidderList.add(cancelledBidders);
				}
			}
		   }
			envelopeDetails = tenderCommonService.getFirstEnvelopeId(tenderId);
			if(envelopeDetails!=null && !envelopeDetails.isEmpty())
			{
				for(Object[] selectedEnvelopeDetails : envelopeDetails)
				{
					envelopeId = (Integer)selectedEnvelopeDetails[0];
					envId = (Byte)selectedEnvelopeDetails[3];
					if(envId == 4)
					{
						isPriceBid = true;
					}
				}
			}
			getRemarksData(tenderId, envelopeId, committeeType,isConsortiumAllowed,request, modelMap);
			if(committeeType == 1)
			{
				tocTecTab = 7;
			}
			else if(committeeType == 2)
			{
				tocTecTab = 8;
			}

			modelMap.put("tenderId", tenderId);
			modelMap.put("tocTecTab", tocTecTab);
			modelMap.put("bidderList", respondendNotRespondendList);
			modelMap.put("notRespondedBidderList", notRespondedBidderList);
			modelMap.put("tenderDetail", tenderDetail);
			modelMap.put("isView", true);
			modelMap.put("isLimited", isLimited);
			modelMap.put("isShowEncodedName",isShowEncodedName);
			modelMap.put("regrettedBidderList", regrettedBidderList);
			modelMap.put("rejectedBidderList", rejectedBidderList);
			modelMap.put("isPriceBid", isPriceBid);
			return "etender/buyer/TocNote";
		}
		catch(Exception e)
		{
			return exceptionHandlerService.writeLog(e);		
		}
		finally
		{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidOpeningTocNote, getBidOpeningTocNote, tenderId , 0);
		}
		
	}
    private void setIncrementOfficerData(int tenderId,int envelopeId,int committeeType,ModelMap modelMap){
  	  Map<Object,List<Object>> map = new HashMap<Object, List<Object>>();
		  List<Object> remarks = new ArrayList<Object>();
		  List<Object[]> incOffRemarksName = new ArrayList<Object[]>();
		  List<Object[]> incOffRemarksVal = new ArrayList<Object[]>();
	  
		  incOffRemarksName =  tenderFormService.getRemarksOfficer(tenderId,envelopeId,committeeType,0);
		  incOffRemarksVal =  tenderFormService.getIncrementOfficerRem(tenderId,envelopeId,committeeType,0);

		  modelMap.put("incOffRemarksName", incOffRemarksName);
		  
		  for(Object[] off : incOffRemarksName){
    		  for(Object[] obj : incOffRemarksVal){
    			  if(off[0].toString().equals(obj[0].toString())){
    				  remarks.add(obj[1].toString()+"@@"+obj[5].toString()+"###"+obj[3].toString());
    			  }
    		  }
    		  map.put(off[0].toString(), remarks);
    		  remarks = new ArrayList<Object>();
		  }
		  modelMap.put("incOfficerRemarks", map);
    }
	
    private void getRemarksData(Integer tenderId,Integer envelopeId,Integer committeeType,Integer isConsortiumAllowed,HttpServletRequest request,ModelMap modelMap)
    {
    	try {	
  		  int sessionUserId = abcUtility.getSessionUserId(request);       	
  		  tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
  		  
  		  List<Object[]> bidderList = tenderFormService.getApprovalBidderByEnvelope(tenderId,envelopeId,isConsortiumAllowed);
  		  modelMap.put("envelopename",tenderCommonService.getTenderEnvelopeById(envelopeId).getEnvelopeName());
  		  
  		  modelMap.put("biddersList", bidderList);
  		  setIncrementOfficerData(tenderId,envelopeId,committeeType,modelMap);
  		  String loginDtls = loginService.getUserLoginById(sessionUserId).getUserName();
  		  List<Object[]> committeeUserList=committeeFormationService.getCommiteeUserDetailsByTenderId(tenderId, envelopeId,committeeType);
  		  for (Object[] objects : committeeUserList) {
				if(sessionUserId == Integer.parseInt(objects[1].toString())){
					loginDtls = loginDtls + "@@" + objects[4].toString();
					loginDtls = loginDtls + "@@" + objects[3].toString();
				}
  		  }    	
  		  modelMap.put("loginUserName",loginDtls);
       } catch (Exception e) {
       }
    }
	/**
	 * author bhavin.patel
	 * @param committeeName
	 * @param committeeType
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/buyer/ajax/checkuniquecommitteename", method=RequestMethod.POST)
	@ResponseBody
	public String checkUniqueCommitteeName(@RequestParam("txtCommitteeName") String committeeName, @RequestParam("txtCommitteeType") int committeeType,  HttpServletRequest request){
		boolean isExist = false;
		String responseStr = SESSIONEXPIRED;
		try {
			if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
				int clientId = abcUtility.getSessionClientId(request);
				isExist = committeeFormationService.checkUniqueCommitteeName(committeeName, committeeType, clientId);
				responseStr = isExist+"";
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return responseStr;
	}
	
	/**
	 * author bhavin.patel
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/buyer/addcommittee", method=RequestMethod.POST)
	public String addCommittee(HttpServletRequest request, RedirectAttributes redirectAttributes){
		String redirect = "etender/buyer/createcommittee";
		String redirectMsg = null;
		String redirectFailMsg = null;
		int tenderId = 0;
		int committeeType = 0;
		int clientId = 0;
		int isStandard = 0;
		int createdBy = 0;
		int memberCount = 0;
		int envelopeCount = 0;
		int tabId = 0;
		int committeeId = 0;
                int twoStageEvaluation = 0;
                int twoStageOpening = 0;
                int multiLevelEvaluationReq = 0;
		boolean isSuccess = false;
		List<TblCommitteeUser> tblCommitteeUserList = new ArrayList<TblCommitteeUser>();
		
		try {
			if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
				clientId = abcUtility.getSessionClientId(request);
				createdBy = abcUtility.getSessionUserDetailId(request);
				tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
				committeeType = StringUtils.hasLength(request.getParameter("hdCommitteeTypeId")) ? Integer.parseInt(request.getParameter("hdCommitteeTypeId")) : 0;
				envelopeCount = StringUtils.hasLength(request.getParameter("hdEnvelopeCount")) ? Integer.parseInt(request.getParameter("hdEnvelopeCount")) : 0;
				memberCount = StringUtils.hasLength(request.getParameter("memberCount")) ? Integer.parseInt(request.getParameter("memberCount")) : 0;
				String committeeName = request.getParameter("txtCommitteeName");
				twoStageEvaluation = StringUtils.hasLength(request.getParameter("hdTwoStageEvaluation")) ? Integer.parseInt(request.getParameter("hdTwoStageEvaluation")) : 0;
                                twoStageOpening = StringUtils.hasLength(request.getParameter("hdTwoStageOpening")) ? Integer.parseInt(request.getParameter("hdTwoStageOpening")) : 0;
                                multiLevelEvaluationReq = StringUtils.hasLength(request.getParameter("hdMultiLevelEvaluationReq")) ? Integer.parseInt(request.getParameter("hdMultiLevelEvaluationReq")) : 0;
                                
				if(committeeFormationService.checkUniqueCommitteeName(committeeName, committeeType, clientId)){
					redirect = redirect + "/" + tenderId +"/"+committeeType+"";
					redirect = redirect + encryptDecryptUtils.generateRedirect(redirect, request);
					if(committeeType == 1){
						redirectFailMsg = "msg_toc_valid_comm_name";	
					}
					else if (committeeType == 2){
						redirectFailMsg = "msg_tec_valid_comm_name";
					}				
				}
				else {
					if(request.getParameter("chkIsStandard") != null){
						isStandard = Integer.parseInt(request.getParameter("chkIsStandard"));
					}
					TblCommittee tblCommittee = new TblCommittee();
					tblCommittee.setCommitteeName(committeeName);
					tblCommittee.setCommitteeType(committeeType);
					tblCommittee.setTblClient(new TblClient(clientId));
					tblCommittee.setTblTender(new TblTender(tenderId));
					tblCommittee.setIsStandard(isStandard);
					tblCommittee.setRemarks("");
					tblCommittee.setCreatedBy(createdBy);
					tblCommittee.setIsActive(1);
					
					String[] officerIds = request.getParameterValues("hdOfficerId");
					String[] userDetailIds = request.getParameterValues("hdUserDetailId");
					String[] tempOfficerIds = request.getParameterValues("tempOfficerId");
					String[] envelopeIds = request.getParameterValues("hdEnvelopeId");
					//Adde by Mitesh
                                        String eveLevel[] = null;
                                        String userRoles[] = null;
                                        if((committeeType==2 && twoStageEvaluation != 0) || (twoStageOpening != 0 && committeeType == 1)){
                                            userRoles=request.getParameterValues("selUserRole");
                                            if(committeeType == 2 && twoStageEvaluation == 1 && multiLevelEvaluationReq == 1){
                                                eveLevel=request.getParameterValues("selEveLevel");
                                            }
                                        }
					if(memberCount == officerIds.length){
						for (int i = 0; i < memberCount; i++) {
							int officerId = Integer.parseInt(officerIds[i]);
							int userDetailId = Integer.parseInt(userDetailIds[i]);
							int isDecryptor = 0;
							int encLevel = 0;
							int userRole = 0;
							String tempOfficerId = tempOfficerIds[i];
							//Start Changes Bug Id#28963
							if(committeeType==1){
								if(request.getParameter("isDecrypter_"+tempOfficerId+"") != null){
									isDecryptor = 1;
									
									if(request.getParameter(ENC_LEVEL+tempOfficerId) != null){
										encLevel = Integer.parseInt(request.getParameter(ENC_LEVEL+tempOfficerId));
									}
									else {
										encLevel = 1;
									}
								}else{
									isDecryptor = 0;
									if(request.getParameter(ENC_LEVEL+tempOfficerId) != null){
										encLevel = Integer.parseInt(request.getParameter(ENC_LEVEL+tempOfficerId));
									}
									else {
										encLevel = 1;
									}
								}
							}
							//End Changes Bug Id#28963
                                                        if((committeeType==2 && twoStageEvaluation != 0) || (twoStageOpening != 0 && committeeType == 1)){
                                                            userRole = Integer.parseInt(userRoles[i]);
                                                            if(committeeType == 2 && twoStageEvaluation == 1 && multiLevelEvaluationReq == 1){
                                                                encLevel=Integer.parseInt(eveLevel[i]);
                                                            }
                                                        }
                                                        if((committeeType == 1 && twoStageOpening == 0) || (committeeType == 2 && twoStageEvaluation == 0)){
                                                            userRole = 2;
                                                            if(committeeType == 2 && (twoStageEvaluation == 0 || multiLevelEvaluationReq == 0)){
                              								  encLevel=1;
                              							  }
                                                        }
							for (int j = 1; j <= envelopeCount; j++) {
								if(request.getParameter("envOpenMember_"+tempOfficerId+"_"+j+"") != null){
									TblCommitteeUser tblCommitteeUser = new TblCommitteeUser();
									tblCommitteeUser.setTblCommittee(tblCommittee);
									tblCommitteeUser.setTblUserLogin(new TblUserLogin(officerId));
									tblCommitteeUser.setTblUserDetail(new TblUserDetail(userDetailId));
									tblCommitteeUser.setChildId(Integer.parseInt(envelopeIds[j-1]));
									tblCommitteeUser.setIsDecryptor(isDecryptor);
									tblCommitteeUser.setEncryptionLevel(encLevel);
									tblCommitteeUser.setRemarks("");
									tblCommitteeUser.setCreatedBy(createdBy);
									tblCommitteeUser.setIsApproved(0);
                                                                        tblCommitteeUser.setUserRoleId(userRole);
									tblCommitteeUserList.add(tblCommitteeUser);
								}
							}
						}
						
						List<TblCommitteeEnvelope> tblCommitteeEnvelopeList = new ArrayList<TblCommitteeEnvelope>();
						for(int k=0;k<envelopeIds.length;k++){
							TblCommitteeEnvelope tblCommitteeEnvelope = new TblCommitteeEnvelope();
							if(request.getParameter(MIN_APPROVAL_REQ+(k+1)) != null){
								tblCommitteeEnvelope.setTblCommittee(tblCommittee);
								tblCommitteeEnvelope.setTblTenderEnvelope(new TblTenderEnvelope(Integer.parseInt(envelopeIds[k])));
								tblCommitteeEnvelope.setMinMemberApproval(Integer.parseInt(request.getParameter(MIN_APPROVAL_REQ+(k+1))));
								tblCommitteeEnvelopeList.add(tblCommitteeEnvelope);
							}
						}
						
						isSuccess = committeeFormationService.addCommittee(tblCommittee, tblCommitteeUserList, tblCommitteeEnvelopeList, committeeType, 0);
						if(isSuccess){
							committeeId = tblCommittee.getCommitteeId();
							if(committeeType == 1){
								tabId = TAB_TENDER_OPENING;
							}
							else if (committeeType == 2){
								tabId = TAB_EVALUATE_BID;
							}
							redirect = "etender/buyer/tenderdashboard/"+tenderId+"/"+tabId+"";
							redirect = redirect + encryptDecryptUtils.generateRedirect(redirect, request);
						}
						else {
							redirect = redirect + "/" + tenderId +"/"+committeeType+"";
							redirect = redirect + encryptDecryptUtils.generateRedirect(redirect, request);
							redirectFailMsg = CommonKeywords.ERROR_MSG_KEY.toString();
						}
					}
				}
			}
			else {
				redirect = SESSIONEXPIRED;
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		finally {
			if(committeeType == 1){
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocCreateLinkId, postAddTocCommittee, tenderId , committeeId);
				redirectMsg = "redirect_success_toc_created";
			}
			else if(committeeType == 2){ 
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tecCreateLinkId, postAddTecCommittee, tenderId , committeeId);
				redirectMsg = "redirect_success_tec_created";
			}
		}
		redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectMsg : redirectFailMsg);
		return "redirect:/" + redirect;
	}
	
	/**
	 * author bhavin.patel
	 * @param tenderId
	 * @param committeeType
	 * @param linkId
	 * @param request
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/buyer/editcommittee/{tenderId}/{committeeType}/{linkId}/{enc}", method=RequestMethod.GET)
	public String editCommittee(@PathVariable(TENDER_ID) Integer tenderId, @PathVariable(COMMITTEE_TYPE) Integer committeeType, @PathVariable("linkId") Integer linkId, HttpServletRequest request , ModelMap modelMap){
		int envCount = 0;
		int committeeId = 0;
		int isDecrypterReq = 0;
		String committeeName = null;
		int isStandard = 0;
		int isApproved = 0;
		int minMember = 1;
		ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	    int isTWoStageOpening=0;
	    int validationMsgFlag=0;
		try {			
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
			
			List<Object[]> committeeDetails = committeeFormationService.getCommitteeDetails(tenderId, committeeType, 0);
			committeeId = Integer.parseInt(committeeDetails.get(0)[0].toString());
			committeeName = committeeDetails.get(0)[1].toString();
			isStandard = Integer.parseInt(committeeDetails.get(0)[2].toString());
			isApproved = Integer.parseInt(committeeDetails.get(0)[3].toString());
                        
			
			modelMap.put("isEdit", true);
			
			List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "encryptionLevel,isCertRequired,isTwoStageEvaluation,multiLevelEvaluationReq,isTwoStageOpening,decryptorRequired");
			if(tenderFields != null && !tenderFields.isEmpty()){
				modelMap.put(IS_2LEVEL_ENC, tenderFields.get(0)[0]);	
				modelMap.put(IS_CERT_REQUIRED, tenderFields.get(0)[1]);
                                modelMap.put(IS_TWO_STAGE_EVALUATION, tenderFields.get(0)[2]);
				modelMap.put(IS_MULTILEVEL_EVALUATION_REQ, tenderFields.get(0)[3]);
        			modelMap.put(IS_TWO_STAGE_OPENING, tenderFields.get(0)[4]);
        			isTWoStageOpening=Integer.parseInt(tenderFields.get(0)[4].toString());
                                 
				List<Object[]> envList = committeeFormationService.getTenderEnvelopesDetails(tenderId);
				if(envList != null && !envList.isEmpty()){
					envCount = envList.size();
					if(committeeType == 1){
						for(Object[] objArray : envList){
							if(Integer.parseInt(objArray[5].toString()) > 0){
								isDecrypterReq = 1;//if isEnc = 1 for any form type, then isDecrypterReq = 1
								break;
							}
							if(Integer.parseInt(objArray[3].toString()) == 1 ){
								modelMap.put("isOpenedEvaluated", 1);
							}
						}
						//minMember = 2;
					}else if(committeeType == 2){
						for(Object[] objArray : envList){
							if( Integer.parseInt(objArray[4].toString()) == 1 ){
								modelMap.put("isOpenedEvaluated", 1);
							}
							
						}
					}
					modelMap.put("envCount", envCount);
					modelMap.put(ENV_LIST, envList);
				}
				if((Integer)tenderFields.get(0)[1] == 0){
					isDecrypterReq = 0;
				}
			}
			
			if(committeeType == 1){
				modelMap.put("isBidEncrypted", committeeFormationService.isBidEncrypted(tenderId));
			}
                        else if(committeeType == 2){
                              
                                List<SelectItem> itemsmultilevel = new ArrayList<SelectItem>();
                                itemsmultilevel.add(new SelectItem("Level 1", 1)); 
                                itemsmultilevel.add(new SelectItem("Level 2", 2));
                                modelMap.addAttribute("itemsmultilevel", itemsmultilevel);
                        }
                        if((committeeType ==2 && Integer.parseInt(tenderFields.get(0)[2].toString())==1) || (committeeType == 1 && Integer.parseInt(tenderFields.get(0)[4].toString())==1)){
                                    List<Object[]> userRoleList=committeeFormationService.getAllUserRole();
                                    modelMap.addAttribute("userRoleList",  abcUtility.convert(userRoleList));
                        }
			modelMap.put(IS_DECRYPTER_REQ,isDecrypterReq);
			modelMap.put("userDetails", committeeFormationService.getCommitteeUserDetails(tenderId, committeeId));
			modelMap.put("userEnvelopeDetails", committeeFormationService.getCommitteeUserEnvelopeDetails(committeeId));
			modelMap.put("userMinApproval", committeeFormationService.getCommitteeMinApproval(committeeId));
			modelMap.put("committeeId", committeeId);
			modelMap.put(COMMITTEE_NAME, committeeName);
			modelMap.put("isStandard", isStandard);
			modelMap.put("isApproved", isApproved);
			
			if(committeeType==1){	//opening committee
				if((clientBean.getIsPkiEnabled()==0 && isTWoStageOpening==1) || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 0 &&  clientBean.getIsPkiEnabled()==2 && isTWoStageOpening==1)){
					//Non-PKI Committee req member (case : Two stage opening applicable.)
					minMember=nonPkiTwoStageOpeningCommitee;
					validationMsgFlag=1;
				}else if((clientBean.getIsPkiEnabled()==0 && isTWoStageOpening==0) || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 0 &&  clientBean.getIsPkiEnabled()==2 && isTWoStageOpening==0)){
					//Non-PKI Committee req member (case : Two stage opening not applicable.)
					minMember=nonPkiSingleStageOpeningCommitee;
					validationMsgFlag=2;
				}else if((clientBean.getIsPkiEnabled()==1 || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 1 &&  clientBean.getIsPkiEnabled()==2)) && isTWoStageOpening==1 && (Integer.parseInt(tenderFields.get(0)[0].toString())==1)){
					//PKI Committee req member (case : Single Encryption Level Two stage opening applicable.)
					minMember=Integer.parseInt(tenderFields.get(0)[5].toString());
					if(isDecrypterReq==1){validationMsgFlag=3;}else{validationMsgFlag=1;};
				}else if((clientBean.getIsPkiEnabled()==1 || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 1 &&  clientBean.getIsPkiEnabled()==2)) && isTWoStageOpening==0 && (Integer.parseInt(tenderFields.get(0)[0].toString())==1)){
					//PKI Committee req member (case : Single Encryption Level Two stage opening not applicable.)
					minMember=Integer.parseInt(tenderFields.get(0)[5].toString());
					if(isDecrypterReq==1){validationMsgFlag=4;}else{validationMsgFlag=2;};
				}else if((clientBean.getIsPkiEnabled()==1 || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 1 &&  clientBean.getIsPkiEnabled()==2)) && isTWoStageOpening==1 && (Integer.parseInt(tenderFields.get(0)[0].toString())==2)){
					//PKI Committee req member (case : Multiple Encryption Level Two stage opening applicable.)
					minMember=Integer.parseInt(tenderFields.get(0)[5].toString());
					if(isDecrypterReq==1){validationMsgFlag=5;}else{validationMsgFlag=1;};
				}else if((clientBean.getIsPkiEnabled()==1 || ( Integer.parseInt(tenderFields.get(0)[1].toString()) == 1 &&  clientBean.getIsPkiEnabled()==2)) && isTWoStageOpening==0 && (Integer.parseInt(tenderFields.get(0)[0].toString())==2)){
					//PKI Committee req member (case : Multiple Encryption Level Two stage opening not applicable.)
					minMember=Integer.parseInt(tenderFields.get(0)[5].toString());
					if(isDecrypterReq==1){validationMsgFlag=6;}else{validationMsgFlag=2;};
				}
		   }else if(committeeType==2 && (Integer.parseInt(tenderFields.get(0)[3].toString())==1)){ //evaluation committee
				//## PKI/NONPKI evaluation Committee req member (case : Multiple Encryption Level Two stage opening applicable.)
				minMember=evaPkiMultipleLevelTwoStageEvaluationCommitee;
				validationMsgFlag=7;
		  }else if(committeeType==2 && (Integer.parseInt(tenderFields.get(0)[2].toString())==1)){
				//## PKI/NONPKI evaluation Committee req member (case Two stage opening applicable)
				minMember=evaPkiNonPkiSingleLevelTwoStageEvaluationCommitee;
		  }
			
			
			modelMap.put("minMember", minMember);
			modelMap.put("validationMsgFlag", validationMsgFlag);
			modelMap.put("linkId", linkId);
			if(Integer.parseInt(modelMap.get("isCertRequired").toString())==1 && committeeType==1){
				clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
				String openingDate = (modelMap.get("openingDate")!=null ? modelMap.get("openingDate").toString() : "");
				List<Object[]> userCertiStatus = committeeFormationService.getCommUserCertStatus(committeeId, clientBean.getIsDualCerti(),openingDate,1);//1-individual TOC
				modelMap.put("userCertiStatus", userCertiStatus);
			}
			boolean isCertRequiredStatus = false;
			if(committeeType==1){
				isCertRequiredStatus = Integer.parseInt(modelMap.get("isCertRequired").toString())==1 ? true : false;
			}
			modelMap.put("isCertRequiredStatus", isCertRequiredStatus);
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);			
		}
		finally{
			String remarks = "";
			if(committeeType == 1){
				if(linkId == tocEditLinkId){
					remarks = getEditTocCommittee;
				}
				else if (linkId == tocPublishedEditLinkId){
					remarks = getPublishedEditTocCommittee;
				}	
			}
			else if(committeeType == 2){
				if(linkId == tecEditLinkId){
					remarks = getEditTecCommittee;
				}
				else if (linkId == tecPublishedEditLinkId){
					remarks = getPublishedEditTecCommittee;
				}
			}
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, remarks, tenderId , committeeId);
		}
		return "etender/buyer/CreateTocTec";
	}
	
	/**
	 * author bhavin.patel
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/buyer/posteditcommittee", method=RequestMethod.POST)
	public String postEditCommittee(HttpServletRequest request, RedirectAttributes redirectAttributes){
		String redirect = "etender/buyer/editcommittee";
		String redirectSuccMsg = null;
		String redirectFailMsg = null;
		int tenderId = 0;
		int committeeType = 0;
		int committeeId = 0;
		int tabId = 0;
		int linkId = 0;
		boolean isSuccess = false;
		boolean isAllowEdit = true;
		boolean isBidEncrypted = false;
		boolean isEnvOpenEval = true;
		boolean isServerSideValidate = true;
                int twoStageEvaluation = 0;
                int multiLevelEvaluationReq = 0;
                int isTwoStageOpening = 0;
                boolean memRemovedOrNot = true;
		List<TblCommitteeUser> tblCommitteeUserList = new ArrayList<TblCommitteeUser>();
		
		try {
			if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
				tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
				committeeType = StringUtils.hasLength(request.getParameter("hdCommitteeTypeId")) ? Integer.parseInt(request.getParameter("hdCommitteeTypeId")) : 0;
				committeeId = StringUtils.hasLength(request.getParameter("hdCommitteeId")) ? Integer.parseInt(request.getParameter("hdCommitteeId")) : 0;
				if(committeeType == 1){
					isBidEncrypted = committeeFormationService.isBidEncrypted(tenderId);
					if(request.getParameter(HD_IS_BIDENCRYPTED) != null){
						if(request.getParameter(HD_IS_BIDENCRYPTED).equalsIgnoreCase("false") && isBidEncrypted){
							isAllowEdit = false;
						}
					}
				}
				
				List<Object[]> envList = committeeFormationService.getTenderEnvelopesDetails(tenderId);
				
				String envelopeName = "";
				if(request.getParameter("hdEnvOpenEvaluated") != null){
					String[] envOpenEval = request.getParameter("hdEnvOpenEvaluated").split("\\|");
					if(envList != null && !envList.isEmpty()){
						for(Object[] objArray : envList){
							for(int i=0;i<envOpenEval.length;i++){
								String[] tempArray = envOpenEval[i].split(",");
								if(committeeType == 1){
									if(objArray[2].toString().equals(tempArray[0]) && !objArray[3].toString().equals(tempArray[1])){
										isEnvOpenEval = false;
										envelopeName = objArray[1].toString();
										break;
									}	
								}
								else if (committeeType == 2){
									if(objArray[2].toString().equals(tempArray[0]) && !objArray[4].toString().equals(tempArray[1])){
										isEnvOpenEval = false;
										envelopeName = objArray[1].toString();
										break;
									}
								}
							}
						}
					}
				}
				
				 int isWorkflowRequired = (Integer) tenderCommonService.getTenderField(tenderId, "isWorkflowRequired");
				 if(isWorkflowRequired==1){
					 boolean isCommitteeApproved = committeeFormationService.isCommitteeApproved(committeeId);
					 if(isCommitteeApproved){
						 int workFlowId = commonService.checkEntryTblWorkflow(committeeId,tenderId);
							 if(workFlowId==3 || workFlowId==5){
								 isServerSideValidate = false;
							 }
					 }
				 }
				
				if(isAllowEdit && isEnvOpenEval && isServerSideValidate){
					int clientId = abcUtility.getSessionClientId(request);
					int createdBy = abcUtility.getSessionUserDetailId(request);
					int envelopeCount = StringUtils.hasLength(request.getParameter("hdEnvelopeCount")) ? Integer.parseInt(request.getParameter("hdEnvelopeCount")) : 0;
					int memberCount = StringUtils.hasLength(request.getParameter("memberCount")) ? Integer.parseInt(request.getParameter("memberCount")) : 0;
					int isApproved = StringUtils.hasLength(request.getParameter("hdIsApproved")) ? Integer.parseInt(request.getParameter("hdIsApproved")) : 0;
					linkId = StringUtils.hasLength(request.getParameter("hdLinkId")) ? Integer.parseInt(request.getParameter("hdLinkId")) : 0;
                                        twoStageEvaluation = StringUtils.hasLength(request.getParameter("hdTwoStageEvaluation")) ? Integer.parseInt(request.getParameter("hdTwoStageEvaluation")) : 0;
                                        multiLevelEvaluationReq = StringUtils.hasLength(request.getParameter("hdMultiLevelEvaluationReq")) ? Integer.parseInt(request.getParameter("hdMultiLevelEvaluationReq")) : 0;
                                        isTwoStageOpening = StringUtils.hasLength(request.getParameter("hdTwoStageOpening")) ? Integer.parseInt(request.getParameter("hdTwoStageOpening")) : 0;
					
					TblCommittee tblCommittee = new TblCommittee();
					if(isApproved == 1){
						tblCommittee.setCommitteeName(request.getParameter("hdCommitteeName"));
						tblCommittee.setCommitteeType(committeeType);
						tblCommittee.setTblClient(new TblClient(clientId));
						tblCommittee.setTblTender(new TblTender(tenderId));
						tblCommittee.setIsStandard(StringUtils.hasLength(request.getParameter("hdIsStandard")) ? Integer.parseInt(request.getParameter("hdIsStandard")) : 0);
						tblCommittee.setRemarks("");
						tblCommittee.setCreatedBy(createdBy);
					}
					else {				
						tblCommittee.setCommitteeId(committeeId);	
					}			
					
					String[] officerIds = request.getParameterValues("hdOfficerId");
					String[] userDetailIds = request.getParameterValues("hdUserDetailId");
					String[] tempOfficerIds = request.getParameterValues("tempOfficerId");
					String[] envelopeIds = request.getParameterValues("hdEnvelopeId");
					
					if(memberCount == officerIds.length){
						List<TblCommitteeUser> tblCommitteeUserApprovals = committeeFormationService.getCommitteeUserApprovalDetails(committeeId, 1);
						if(tblCommitteeUserApprovals != null && !tblCommitteeUserApprovals.isEmpty()){
							for(TblCommitteeUser tblCommitteeUser : tblCommitteeUserApprovals){
								if(Arrays.asList(officerIds).contains(String.valueOf(tblCommitteeUser.getTblUserLogin().getUserId()))){
									TblCommitteeUser tblCommitteeUser1 = new TblCommitteeUser();
									for (int i = 0; i < memberCount; i++) {
										int officerId = Integer.parseInt(officerIds[i]);
										String tempOfficerId = tempOfficerIds[i];
										if(committeeType==1 && officerId== tblCommitteeUser.getTblUserLogin().getUserId()){
											if(request.getParameter("isDecrypter_"+tempOfficerId+"") != null){
												tblCommitteeUser1.setIsDecryptor(1);
											}else{
												tblCommitteeUser1.setIsDecryptor(0);
											}
										}
									}
									tblCommitteeUser1.setTblCommittee(tblCommittee);
									tblCommitteeUser1.setTblUserLogin(tblCommitteeUser.getTblUserLogin());
									tblCommitteeUser1.setTblUserDetail(tblCommitteeUser.getTblUserDetail());
									tblCommitteeUser1.setChildId(tblCommitteeUser.getChildId());
									
									
									tblCommitteeUser1.setRemarks(tblCommitteeUser.getRemarks());
									tblCommitteeUser1.setApprovedOn(tblCommitteeUser.getApprovedOn());
									tblCommitteeUser1.setApprovedBy(tblCommitteeUser.getApprovedBy());
									tblCommitteeUser1.setCreatedOn(tblCommitteeUser.getCreatedOn());
									tblCommitteeUser1.setCreatedBy(tblCommitteeUser.getCreatedBy());
									tblCommitteeUser1.setIsApproved(tblCommitteeUser.getIsApproved());
									if((committeeType == 1 && isTwoStageOpening == 0) || (committeeType == 2 && twoStageEvaluation == 0)){
										tblCommitteeUser1.setUserRoleId(2);
                                        if(committeeType == 2 && (twoStageEvaluation == 0 || multiLevelEvaluationReq == 0)){
                                        	tblCommitteeUser1.setEncryptionLevel(1);
          							  	}else{
          								tblCommitteeUser1.setEncryptionLevel(tblCommitteeUser.getEncryptionLevel());
          							  	}
                                    }else{
                                    	tblCommitteeUser1.setUserRoleId(tblCommitteeUser.getUserRoleId());
                                    	tblCommitteeUser1.setEncryptionLevel(tblCommitteeUser.getEncryptionLevel());
                                    }
									tblCommitteeUserList.add(tblCommitteeUser1);	
								}else{
									memRemovedOrNot = false;
									isAllowEdit = false;
								}
							}
						}
                                                String eveLevel[] = null;
                                                String userRoles[] = null;
                                                if((committeeType == 1 && isTwoStageOpening !=0) || (committeeType == 2 && twoStageEvaluation != 0)){
                                                    userRoles=request.getParameterValues("selUserRole");
                                                    if( committeeType == 2 && twoStageEvaluation == 1 && multiLevelEvaluationReq == 1){
                                                        eveLevel=request.getParameterValues("selEveLevel");
                                                    }
                                                }
						for (int i = 0; i < memberCount; i++) {
							int officerId = Integer.parseInt(officerIds[i]);
							int userDetailId = Integer.parseInt(userDetailIds[i]);
							int isDecryptor = 0;
							int encLevel = 0;
							int userRole= 0;
							String tempOfficerId = tempOfficerIds[i];
							//Start Changes Bug Id#28963
							if(committeeType==1){
								if(request.getParameter("isDecrypter_"+tempOfficerId+"") != null){
									isDecryptor = 1;
									
									if(request.getParameter(ENC_LEVEL+tempOfficerId) != null){
										encLevel = Integer.parseInt(request.getParameter(ENC_LEVEL+tempOfficerId));
									}
									else {
										encLevel = 1;
									}
								}else{
									isDecryptor = 0;
									if(request.getParameter(ENC_LEVEL+tempOfficerId) != null){
										encLevel = Integer.parseInt(request.getParameter(ENC_LEVEL+tempOfficerId));
									}
									else {
										encLevel = 1;
									}
								}
							}
							//End Changes Bug Id#28963
							  if((committeeType == 1 && isTwoStageOpening !=0) || (committeeType == 2 && twoStageEvaluation != 0)){
                                                            userRole = Integer.parseInt(userRoles[i]);
                                                           if( committeeType == 2 && twoStageEvaluation == 1 && multiLevelEvaluationReq == 1){
                                                                encLevel=Integer.parseInt(eveLevel[i]);
                                                            }
                                                        }
							  if((committeeType == 1 && isTwoStageOpening == 0) || (committeeType == 2 && twoStageEvaluation == 0)){
                                  userRole = 2;
                                  if(committeeType == 2 && (twoStageEvaluation == 0 || multiLevelEvaluationReq == 0)){
    								  encLevel=1;
    							  }
                              }
							 
							for (int j = 1; j <= envelopeCount; j++) {
								if(request.getParameter("envOpenMember_"+tempOfficerId+"_"+j+"") != null){
									TblCommitteeUser tblCommitteeUser = new TblCommitteeUser();
									if(request.getParameter("envOpenApproved_"+tempOfficerId+"_"+j+"") == null){
										List<TblCommitteeUser> tblCommitteeUserApprovals1 = committeeFormationService.getCommitteeUserApprovalDetailForEditCommitee(committeeId,officerId,Integer.parseInt(envelopeIds[j-1]), 1);
										if(tblCommitteeUserApprovals1.isEmpty()){
										tblCommitteeUser.setTblCommittee(tblCommittee);
										tblCommitteeUser.setTblUserLogin(new TblUserLogin(officerId));
										tblCommitteeUser.setTblUserDetail(new TblUserDetail(userDetailId));
										tblCommitteeUser.setChildId(Integer.parseInt(envelopeIds[j-1]));
										tblCommitteeUser.setIsDecryptor(isDecryptor);
										tblCommitteeUser.setEncryptionLevel(encLevel);
										tblCommitteeUser.setRemarks("");
										tblCommitteeUser.setCreatedBy(createdBy);
										tblCommitteeUser.setIsApproved(0);
                                        tblCommitteeUser.setUserRoleId(userRole);
										tblCommitteeUserList.add(tblCommitteeUser);	
										}else{
											memRemovedOrNot= false;
											isAllowEdit = false;
										}
									}
								}else 
								{
									List<TblCommitteeUser> tblCommitteeUserApprovals1 = committeeFormationService.getCommitteeUserApprovalDetailForEditCommitee(committeeId,officerId,Integer.parseInt(envelopeIds[j-1]), 1);
									if(!tblCommitteeUserApprovals1.isEmpty()){
										memRemovedOrNot= false;
										isAllowEdit = false;
									}
								}
							}
						}
						
						List<TblCommitteeEnvelope> tblCommitteeEnvelopeList = new ArrayList<TblCommitteeEnvelope>();
						for(int k=0;k<envelopeIds.length;k++){
							TblCommitteeEnvelope tblCommitteeEnvelope = new TblCommitteeEnvelope();
							if(request.getParameter(MIN_APPROVAL_REQ+(k+1)) != null){
								tblCommitteeEnvelope.setTblCommittee(tblCommittee);
								tblCommitteeEnvelope.setTblTenderEnvelope(new TblTenderEnvelope(Integer.parseInt(envelopeIds[k])));
								tblCommitteeEnvelope.setMinMemberApproval(Integer.parseInt(request.getParameter(MIN_APPROVAL_REQ+(k+1))));
								tblCommitteeEnvelopeList.add(tblCommitteeEnvelope);
							}
						}
						
						if(isApproved == 1  && memRemovedOrNot){
							isSuccess = committeeFormationService.addCommittee(tblCommittee, tblCommitteeUserList, tblCommitteeEnvelopeList, committeeType, 0);
						}
						else if(memRemovedOrNot){
							isSuccess = committeeFormationService.addCommittee(tblCommittee, tblCommitteeUserList, tblCommitteeEnvelopeList, committeeType, 1);
						}
						if(isSuccess){
							if(committeeType == 1){
								tabId = TAB_TENDER_OPENING;
							}
							else if (committeeType == 2){
								tabId = TAB_EVALUATE_BID;
							}
							redirect = "etender/buyer/tenderdashboard/"+tenderId+"/"+tabId+"";
							redirect = redirect + encryptDecryptUtils.generateRedirect(redirect, request);
						}
						else {
							redirect = redirect + "/" + tenderId +"/"+committeeType+"/"+linkId;
							redirect = redirect + encryptDecryptUtils.generateRedirect(redirect, request);	
							redirectFailMsg = !memRemovedOrNot? "redirect_msg_consent_received" : CommonKeywords.ERROR_MSG_KEY.toString();
						}
					}
				}
				else {
					redirect = redirect + "/" + tenderId +"/"+committeeType+"/"+linkId;
					redirect = redirect + encryptDecryptUtils.generateRedirect(redirect, request);
					if(!isAllowEdit){
						redirectFailMsg = "redirect_msg_bid_encrypted";
					}
					if(!isEnvOpenEval){
						if(committeeType == 1){
							redirectAttributes.addFlashAttribute("openEvalFor", "TOC");
						}
						else if(committeeType == 2){
							redirectAttributes.addFlashAttribute("openEvalFor", "TEC");
						}
						redirectAttributes.addFlashAttribute("envName", envelopeName);					
						redirectFailMsg = "redirect_msg_opened_evaluated";
					}
					if(!isServerSideValidate){
						redirectFailMsg = "msg_workflow_complete";
					}
				}
			}
			else {
				redirect = SESSIONEXPIRED;
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		finally {
			String remarks = "";
			if(committeeType == 1){
				if(linkId == tocEditLinkId){
					remarks = postEditTocCommittee;
				}
				else if (linkId == tocPublishedEditLinkId){
					remarks = postPublishedEditTocCommittee;
				}
				redirectSuccMsg = "redirect_success_toc_updated";
			}
			else if(committeeType == 2){
				if(linkId == tecEditLinkId){
					remarks = postEditTecCommittee;
				}
				else if (linkId == tecPublishedEditLinkId){
					remarks = postPublishedEditTecCommittee;
				}
				redirectSuccMsg = "redirect_success_tec_updated";
			}
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, remarks, tenderId , committeeId);
		}
		redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectSuccMsg : redirectFailMsg);
		return "redirect:/" + redirect;
	}
	
	/**
	 * author bhavin.patel
	 * @param tenderId
	 * @param committeeType
	 * @param isWorkFlow
	 * @param request
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/buyer/viewcommittee/{tenderId}/{committeeType}/{isWorkFlow}/{enc}", method=RequestMethod.GET)
	public String viewCommittee(@PathVariable(TENDER_ID) Integer tenderId, @PathVariable(COMMITTEE_TYPE) Integer committeeType, @PathVariable("isWorkFlow") Integer isWorkFlow, HttpServletRequest request , ModelMap modelMap){
		int isDecrypterReq = 0;
		int envCount = 0;
		int committeeId = 0;
		int activeCommitteeId = 0;
		try {
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
			
			//int is2LevelEnc = (Integer) tenderCommonService.getTenderField(tenderId, ENCRYPTION_LEVEL);
			List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "encryptionLevel,isCertRequired,isTwoStageEvaluation,multiLevelEvaluationReq,isTwoStageOpening");
			if(tenderFields != null && !tenderFields.isEmpty()){
				modelMap.put(IS_2LEVEL_ENC, tenderFields.get(0)[0]);
				modelMap.put(IS_CERT_REQUIRED, tenderFields.get(0)[1]);
                                modelMap.put(IS_TWO_STAGE_EVALUATION, tenderFields.get(0)[2]);
				modelMap.put(IS_MULTILEVEL_EVALUATION_REQ, tenderFields.get(0)[3]);
				modelMap.put(IS_TWO_STAGE_OPENING, tenderFields.get(0)[4]);
                                
				List<Object[]> envList = committeeFormationService.getTenderEnvelopesDetails(tenderId);
				if(envList != null && !envList.isEmpty()){
					envCount = envList.size();
					if(committeeType == 1){
						for(Object[] objArray : envList){
							if(Integer.parseInt(objArray[5].toString()) > 0){
								isDecrypterReq = 1;//if isEnc = 1 for any form type, then isDecrypterReq = 1
								break;
							}
						}
					}
					modelMap.put(ENV_LIST, envList);
					
					if((Integer) tenderFields.get(0)[1] == 0){
						isDecrypterReq = 0;
					}
				}	
			}
			
			List<Object[]> committeeDetails = committeeFormationService.getCommitteeDetails(tenderId, committeeType, 1);
			List<List<Object[]>> userDetails = new ArrayList<List<Object[]>>();
			List<List<Object[]>> userEnvelopeDetails = new ArrayList<List<Object[]>>();
			List<List<Object[]>> userMinApproval = new ArrayList<List<Object[]>>();
			
			for(Object[] obj : committeeDetails){
				committeeId = Integer.parseInt(obj[0].toString());
				userDetails.add(committeeFormationService.getCommitteeUserDetails(tenderId, committeeId));
				userEnvelopeDetails.add(committeeFormationService.getCommitteeUserEnvelopeDetails(committeeId));
				userMinApproval.add(committeeFormationService.getCommitteeMinApproval(committeeId));
				if(Integer.parseInt(obj[4].toString())==1){
					activeCommitteeId = Integer.parseInt(obj[0].toString());
				}
			}
			
			String committeeName = committeeDetails.get(0)[1].toString();
			int isStandard = Integer.parseInt(committeeDetails.get(0)[2].toString());
//			if(committeeType==1){
//				modelMap.put("mapTOCCommWithEnv",committeeFormationService.checkCommMappedWithEnvlopeorNot(committeeType, tenderId, abcUtility.getSessionClientId(request)));
//			}else if(committeeType==2){
//				modelMap.put("mapTECCommWithEnv",committeeFormationService.checkCommMappedWithEnvlopeorNot(committeeType, tenderId, abcUtility.getSessionClientId(request)));
//			}
    		modelMap.put(IS_DECRYPTER_REQ, isDecrypterReq);
    		modelMap.put("isWorkFlow", isWorkFlow);
			modelMap.put("committeeDetails", committeeDetails);
			modelMap.put("userDetails", userDetails);
			modelMap.put("userEnvelopeDetails", userEnvelopeDetails);
			modelMap.put("userMinApproval", userMinApproval);
			modelMap.put(COMMITTEE_NAME, committeeName);
			modelMap.put("isStandard", isStandard);
			modelMap.put("envCount", envCount);
			if(Integer.parseInt(modelMap.get("isCertRequired").toString())==1 && committeeType==1){
				ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
				String openingDate = (modelMap.get("openingDate")!=null ? modelMap.get("openingDate").toString() : "");
				List<Object[]> userCertiStatus = committeeFormationService.getCommUserCertStatus(activeCommitteeId, clientBean.getIsDualCerti(),openingDate,1);//1-individual TOC
				modelMap.put("userCertiStatus", userCertiStatus);
			}
			boolean isCertRequired = false;
			if(committeeType==1){
				isCertRequired = Integer.parseInt(modelMap.get("isCertRequired").toString())==1 ? true : false;
			}
			modelMap.put("isCertRequiredStatus", isCertRequired);
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		finally {
			if(committeeType == 1){
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocViewLinkId, viewTocCommittee, tenderId , committeeId);	
			}
			else if(committeeType == 2){ 
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tecViewLinkId, viewTecCommittee, tenderId , committeeId);
			}
		}
		return "etender/buyer/ViewTocTec";
	}
	
	/**
	 * author bhavin.patel
	 * @param tenderId
	 * @param committeeType
	 * @param request
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value="/buyer/publishcommittee/{tenderId}/{committeeType}/{enc}", method=RequestMethod.GET)
	public String publishCommittee(@PathVariable(TENDER_ID) Integer tenderId, @PathVariable(COMMITTEE_TYPE) Integer committeeType, HttpServletRequest request , ModelMap modelMap){
		int envCount = 0;
		int isDecrypterReq = 0;
		int dumpAsTec = 0;
		boolean isCertFound = true;
		int isCertRequired = 0;
		int committeeId = 0;
		String retVal = "etender/buyer/PublishTocTec";
		
		try {
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
			
			List<Object[]> envList = committeeFormationService.getTenderEnvelopesDetails(tenderId);
			if(envList != null && !envList.isEmpty()){
				envCount = envList.size();
				if(committeeType == 1){
					for(Object[] objArray : envList){
						if(Integer.parseInt(objArray[5].toString()) > 0){
							isDecrypterReq = 1;//if isEnc = 1 for any form type, then isDecrypterReq = 1
							break;
						}
					}
				}
			}
			
			List<Object[]> committeeDetails = committeeFormationService.getCommitteeDetails(tenderId, committeeType, 0);			
			committeeId = Integer.parseInt(committeeDetails.get(0)[0].toString());
			String committeeName = committeeDetails.get(0)[1].toString();
			int isStandard = Integer.parseInt(committeeDetails.get(0)[2].toString());
			
    		/*if(abcUtility.getSessionIsPkiEnabled(request)==1){
    			String certIds[] = abcUtility.getSessionCertId(request).split(",");
    			if(certIds!=null && certIds.length!=0){
    				modelMap.put("publicKeyForSign", commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
    			}
    		}*/    		
    		
			SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
			
    		if (committeeType == 1){
    			List<Object[]> committeeCount = committeeFormationService.getCommitteeCountForTender(tenderId);
        		if(committeeCount != null && !committeeCount.isEmpty()){
        			if(Integer.parseInt(committeeCount.get(0)[0].toString()) > 2 || Integer.parseInt(committeeCount.get(0)[1].toString()) > 0){
        				dumpAsTec = 1;
        			}
        		}
        		modelMap.put("dumpAsTec", dumpAsTec);
    			modelMap.put("isBidEncrypted", committeeFormationService.isBidEncrypted(tenderId));
    		}
    		if(Integer.parseInt(modelMap.get("isCertRequired").toString())==1 && committeeType==1){
    			String openingDate = (modelMap.get("openingDate")!=null ? modelMap.get("openingDate").toString() : "");
				List<Object[]> userCertiStatus = committeeFormationService.getCommUserCertStatus(committeeId, clientBean.getIsDualCerti(),openingDate,1);//1-individual TOC
				modelMap.put("userCertiStatus", userCertiStatus);
			}
			boolean isCertRequiredStatus = false;
			if(committeeType==1){
				isCertRequiredStatus = Integer.parseInt(modelMap.get("isCertRequired").toString())==1 ? true : false;
			}
			modelMap.put("isCertRequiredStatus", isCertRequiredStatus);
    		List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "encryptionLevel,isCertRequired");
			if(tenderFields != null && !tenderFields.isEmpty()){
				modelMap.put(IS_2LEVEL_ENC, tenderFields.get(0)[0]);
				if(clientBean.getIsPkiEnabled()==pkiEventSpecific){
					isCertRequired = Integer.parseInt(tenderFields.get(0)[1].toString());
				}
				modelMap.put(IS_CERT_REQUIRED, isCertRequired);
			}
			
			String certIds[] = null;
			if(clientBean.getIsPkiEnabled()==pkiEnable){
                certIds = sessionBean.getCertId().split(",");
        		if(certIds!=null && certIds.length!=0){
        			modelMap.put("publicKeyForSign", commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                }
    		}else if (clientBean.getIsPkiEnabled()==pkiEventSpecific && isCertRequired == 1){
    			if(!sessionBean.isEventSpecVerify()){
    				isCertFound = false;
    				retVal="common/buyer/attacheventspeccerti/etender,buyer,publishcommittee,"+tenderId+","+committeeType+"";
    			}else{
    				certIds = sessionBean.getCertId().split(",");
            		if(certIds!=null && certIds.length!=0){
            			modelMap.put("publicKeyForSign", commonService.getPublicKeyById(Integer.parseInt(certIds[0])));
                    }
                }
            }
			int decryptorcount = 0;
			List<Object[]> userDetail  = committeeFormationService.getCommitteeUserDetails(tenderId, committeeId);
			if(userDetail!=null && !userDetail.isEmpty()){
				for(Object obj[] : userDetail){
					if(Integer.parseInt(obj[5].toString())==1){
						decryptorcount++;
					}
				}
			}
			if(isCertFound){
	    		modelMap.put(IS_DECRYPTER_REQ, isDecrypterReq);
				modelMap.put("envCount", envCount);
				modelMap.put(ENV_LIST, envList);
				modelMap.put("userDetails", committeeFormationService.getCommitteeUserDetails(tenderId, committeeId));
				modelMap.put("userEnvelopeDetails", committeeFormationService.getCommitteeUserEnvelopeDetails(committeeId));
				modelMap.put("userMinApproval", committeeFormationService.getCommitteeMinApproval(committeeId));
				modelMap.put("committeeId", committeeId);
				modelMap.put(COMMITTEE_NAME, committeeName);
				modelMap.put("isStandard", isStandard);
				modelMap.put("decryptorcount", decryptorcount);
			}
			else {
				retVal="redirect:/"+retVal+ encryptDecryptUtils.generateRedirect(retVal, request);
			}
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		finally {
			if(committeeType == 1){
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocPublishLinkId, getPublishTocCommittee, tenderId , committeeId);	
			}
			else if(committeeType == 2){ 
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tecPublishLinkId, getPublishTecCommittee, tenderId , committeeId);
			}
		}
		return retVal;
	}
	
	/**
	 * author bhavin.patel
	 * @param request
	 * @param httpSession
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/buyer/postpublishcommittee", method=RequestMethod.POST)
	public String postPublishCommittee(HttpServletRequest request, HttpSession httpSession, RedirectAttributes redirectAttributes){
		int tenderId = 0;
		int committeeType = 0;
		int committeeId = 0;
		int tabId = 0;
		String redirect = "etender/buyer/publishcommittee";
		String redirectSuccMsg = null;
		String redirectFailMsg = null;
		String remarks = null;
		String signedRemarks = null;
		boolean isSuccess = false;
		boolean isBidEncrypted = false;
		boolean isAllowPublish = true;
		boolean isPkiReq = false;
		String eventType=null;
		int eventTypeId = 0;
		String tenderBrief=null;
		int isWorkflowRequired=0;
		try {
			if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
				tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
				committeeType = StringUtils.hasLength(request.getParameter("hdCommitteeTypeId")) ? Integer.parseInt(request.getParameter("hdCommitteeTypeId")) : 0;
				eventType=StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
				eventTypeId = StringUtils.hasLength(request.getParameter("hdEventTypeId")) ? Integer.parseInt(request.getParameter("hdEventTypeId")) : 0;
				tenderBrief=StringUtils.hasLength(request.getParameter("hdTenderBrief")) ? request.getParameter("hdTenderBrief") : "";
				isWorkflowRequired = StringUtils.hasLength(request.getParameter("hdIsWorkflowRequired")) ? Integer.parseInt(request.getParameter("hdIsWorkflowRequired")) : 0;
				
				int pki = abcUtility.getSessionIsPkiEnabled(request);		
				int clientId = abcUtility.getSessionClientId(request);
				remarks = request.getParameter("txtaRemarks");
				signedRemarks = StringUtils.hasLength(request.getParameter("skpSignText"))?request.getParameter("skpSignText"):"";
				int isCertRequired = StringUtils.hasLength(request.getParameter("hdIsCertRequired"))?Integer.parseInt(request.getParameter("hdIsCertRequired")):0;
				if(committeeType == 1){
					isBidEncrypted = committeeFormationService.isBidEncrypted(tenderId);
					if(request.getParameter(HD_IS_BIDENCRYPTED) != null){
						if(request.getParameter(HD_IS_BIDENCRYPTED).equalsIgnoreCase("false") && isBidEncrypted){
							isAllowPublish = false;
						}
					}
				}
				
				if(pki == pkiEnable || (pki == pkiEventSpecific && isCertRequired == 1)){
					isPkiReq = true;
				}
				
				if(isAllowPublish){
					ClientBean clientBean = (ClientBean) httpSession.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
					int isDualCert = clientBean.getIsDualCerti();
					int publishedBy = abcUtility.getSessionUserDetailId(request);
					committeeId = StringUtils.hasLength(request.getParameter("hdCommitteeId")) ? Integer.parseInt(request.getParameter("hdCommitteeId")) : 0;				
					
					int dumpAsTec = 0;
					if(request.getParameter("chkSameAsTec") != null){
						dumpAsTec = StringUtils.hasLength(request.getParameter("chkSameAsTec")) ? Integer.parseInt(request.getParameter("chkSameAsTec")) : 0;
						
						List<Object[]> committeeCount = committeeFormationService.getCommitteeCountForTender(tenderId);
		        		if(committeeCount != null && !committeeCount.isEmpty()){
		        			if(Integer.parseInt(committeeCount.get(0)[0].toString()) > 2 || Integer.parseInt(committeeCount.get(0)[1].toString()) > 0){
		        				dumpAsTec = 0;
		        			}
		        		}
					}
					
					 Map<String, Object> paramMap = new HashMap<String, Object>();
					// paramMap.put("EventType", eventType);
					 paramMap.put("tenderId", tenderId);
//					 paramMap.put("tenderBrief",tenderBrief);
							
					// String encryptUrlStr = encryptDecryptUtils.encrypt("etender/buyer/viewcommittee/"+tenderId+"/"+committeeType+"/"+isWorkflowRequired);
					 String encryptUrlStr = encryptDecryptUtils.encrypt("etender/buyer/viewcommittee/"+tenderId+"/"+committeeType+"/"+0);					 
                     String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                     paramMap.put("link", hrefStr);
                     isWorkflowRequired = (Integer) tenderCommonService.getTenderField(tenderId, "isWorkflowRequired");
                     if(isWorkflowRequired == 1 && committeeType==1){
                    	 int checkEntryTblWorkflow = 0;
                    	 checkEntryTblWorkflow = workflowService.checkEntryTblWorkflow(eventTypeId,committeeId,openingProcessWorkflowLinkId,tenderId);
                         if(checkEntryTblWorkflow != 0){
                        	 isSuccess = committeeFormationService.publishCommittee(remarks, clientId, publishedBy, committeeId, committeeType, tenderId, dumpAsTec, isDualCert,paramMap);
                         } else {
                             tabId = TAB_TENDER_OPENING;
                             redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_workflow_reset_success_process_workflow");
                         }
                     }else{
			         isSuccess = committeeFormationService.publishCommittee(remarks, clientId, publishedBy, committeeId, committeeType, tenderId, dumpAsTec, isDualCert,paramMap);
                     }
					if(isSuccess){
						if(committeeType == 1){
							tabId = TAB_TENDER_OPENING;
							List<Object[]> envList = committeeFormationService.getTenderEnvelopesDetails(tenderId);
                            List<Object[]> envMinMemberList = committeeFormationService.getCommitteeEnvelopeDetails(committeeId);
                            Map<Integer,Integer> envIsevaluateMap=new HashMap<Integer, Integer>();
                            Map<Integer,Integer> envUpdateIsApprovedMap=new HashMap<Integer, Integer>();
                            Map<Integer,Integer> envUpdateIsEvaluatedMap=new HashMap<Integer, Integer>();
                            if(envList!=null){
                                for (Object[] objects : envList) {
                                    envIsevaluateMap.put(Integer.parseInt(objects[2].toString()), Integer.parseInt(objects[4].toString()));
                                }
                            }
                            if(envMinMemberList!=null){
                                for (Object[] objects : envMinMemberList) {
                                    //envMinMemberMap.put(Integer.parseInt(objects[0].toString()), Integer.parseInt(objects[1].toString()));
                                    if(envIsevaluateMap.containsKey(Integer.parseInt(objects[0].toString()))){
                                        if(envIsevaluateMap.get(Integer.parseInt(objects[0].toString())) == 1){ //is Evaluated=1
                                            if(Integer.parseInt(objects[1].toString()) == 0)//minMember consent is 0
                                            {
                                                envUpdateIsApprovedMap.put(Integer.parseInt(objects[0].toString()), 1);
                                            }
                                            else{
                                            	 envUpdateIsEvaluatedMap.put(Integer.parseInt(objects[0].toString()), envIsevaluateMap.get(Integer.parseInt(objects[0].toString())));
                                            }
                                        }
                                    }
                                }
                            }
                            committeeFormationService.updateEnvelopeIsEvaluated(envUpdateIsApprovedMap,envUpdateIsEvaluatedMap,committeeId);
						}
						else if (committeeType == 2){
							tabId = TAB_EVALUATE_BID;
                                                        //update isEvaluated code.
                                                        List<Object[]> envList = committeeFormationService.getTenderEnvelopesDetails(tenderId);
                                                        List<Object[]> envMinMemberList = committeeFormationService.getCommitteeEnvelopeDetails(committeeId);
                                                        Map<Integer,Integer> envIsevaluateMap=new HashMap<Integer, Integer>();
                                                        Map<Integer,Integer> envUpdateIsApprovedMap=new HashMap<Integer, Integer>();
                                                        Map<Integer,Integer> envUpdateIsEvaluatedMap=new HashMap<Integer, Integer>();
                                                        if(envList!=null){
                                                            for (Object[] objects : envList) {
                                                                envIsevaluateMap.put(Integer.parseInt(objects[2].toString()), Integer.parseInt(objects[4].toString()));
                                                            }
                                                        }
                                                        if(envMinMemberList!=null){
                                                            for (Object[] objects : envMinMemberList) {
                                                                //envMinMemberMap.put(Integer.parseInt(objects[0].toString()), Integer.parseInt(objects[1].toString()));
                                                                if(envIsevaluateMap.containsKey(Integer.parseInt(objects[0].toString()))){
                                                                    if(envIsevaluateMap.get(Integer.parseInt(objects[0].toString())) == 1){ //is Evaluated=1
                                                                        if(Integer.parseInt(objects[1].toString()) == 0)//minMember consent is 0
                                                                        {
                                                                            envUpdateIsApprovedMap.put(Integer.parseInt(objects[0].toString()), 1);
                                                                        }
                                                                        else{
                                                                            envUpdateIsEvaluatedMap.put(Integer.parseInt(objects[0].toString()),envIsevaluateMap.get(Integer.parseInt(objects[0].toString())));
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        committeeFormationService.updateEnvelopeIsEvaluated(envUpdateIsApprovedMap,envUpdateIsEvaluatedMap,committeeId);
						}
						redirect = "etender/buyer/tenderdashboard/"+tenderId+"/"+tabId+"";
						redirect = redirect + encryptDecryptUtils.generateRedirect(redirect, request);
						
					}
					else {
						redirect = redirect + "/" + tenderId +"/"+committeeType+"";
						redirect = redirect + encryptDecryptUtils.generateRedirect(redirect, request);
						redirectFailMsg = CommonKeywords.ERROR_MSG_KEY.toString();
					}
				}
				else {
					redirect = redirect + "/" + tenderId +"/"+committeeType+"";
					redirect = redirect + encryptDecryptUtils.generateRedirect(redirect, request);
					redirectFailMsg = "redirect_msg_bid_encrypted";
				}
			}
			else {
				redirect = SESSIONEXPIRED;
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		finally {
			if(committeeType == 1){
				if(isPkiReq){
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocPublishLinkId, postPublishTocCommittee, tenderId , committeeId, remarks, signedRemarks);
				}
				else {
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocPublishLinkId, postPublishTocCommittee, tenderId , committeeId);
				}
				redirectSuccMsg = "redirect_success_toc_published";
			}
			else if(committeeType == 2){ 
				if(isPkiReq){
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tecPublishLinkId, postPublishTecCommittee, tenderId , committeeId, remarks, signedRemarks);
				}
				else {
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tecPublishLinkId, postPublishTecCommittee, tenderId , committeeId);
				}
				redirectSuccMsg = "redirect_success_tec_published";
			}
		}
		redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectSuccMsg : redirectFailMsg);
		return "redirect:/" + redirect;
	}
	/**
	 * author Lipi Shah
	 * @param committeeType
	 * @param request
	 * @param modelMap
	 * @return
	 * 
	 */
	@RequestMapping(value="/buyer/managecentralizedcommittee/{committeeType}/{enc}", method=RequestMethod.GET)
	public String manageCentralizedcommittee(@PathVariable(COMMITTEE_TYPE) Integer committeeType,HttpServletRequest request , ModelMap modelMap){
		int isFrom = 1;
		try {	
				List<Object[]> userRoleList=committeeFormationService.getAllUserRole();
                modelMap.addAttribute("userRoleList",  abcUtility.convert(userRoleList));
                modelMap.addAttribute("minMember", 2);
                
                int clientId = abcUtility.getSessionClientId(request);
                TblCentralizedCommittee tblCentralizedCommittee = committeeFormationService.getCentralizedCommitteeDetails(committeeType,clientId);
                if(tblCentralizedCommittee!=null){
                	isFrom=2;
                }
                ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
                if(isFrom==2){//edit
                	modelMap.addAttribute("userDetails", committeeFormationService.getCentralizedCommUsers(committeeType,clientId));
                	if(clientBean.getIsDualCerti() !=0 && committeeType==1){
        				List<Object[]> userCertiStatus = committeeFormationService.getCommUserCertStatus(tblCentralizedCommittee.getCentralizedCommitteeId(), clientBean.getIsDualCerti(),"",2);//2-Centralized TOC
        				modelMap.put("userCertiStatus", userCertiStatus);
        			}
                }
                modelMap.put("isCertRequired", clientBean.getIsDualCerti() !=0 ? 1 : 0);
                modelMap.addAttribute("isFrom",isFrom);
                boolean isCertRequiredStatus = false;
    			if(committeeType==1){
    				isCertRequiredStatus = clientBean.getIsDualCerti() !=0 ? true : false;
    			}
    			modelMap.put("isCertRequiredStatus", isCertRequiredStatus);
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);			
		}
		finally{
			if(committeeType == 1){
				if(isFrom==1){
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocCentralizeManage, getCreateCentralizedTocCommittee, 0 , 0);
				}else if(isFrom==2){
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocCentralizeManage, getEditCentralizedTocCommittee, 0 , 0);
				}
			}
			else if(committeeType == 2){ 
				if(isFrom==1){
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tecCentralizeManage, getCreateCentralizedTecCommittee, 0 , 0);
				}else if(isFrom==2){
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tecCentralizeManage, getEditCentralizedTecCommittee, 0 , 0);
				}
			}
		}
		return "common/admin/CreateCentralizedTocTec";
	}
	/**
	 * author Lipi Shah
	 * @param request
	 * @param httpSession
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value="/buyer/addcentralizedcommittee", method=RequestMethod.POST)
	public String addCentralizedCommittee(HttpServletRequest request, HttpSession httpSession, RedirectAttributes redirectAttributes){
		String redirect = "";
		String redirectFailMsg = null;
		int committeeType = 0;
		int clientId = 0;
		int createdBy = 0;
		int memberCount = 0;
		int isFrom = 0;
		boolean isSuccess = false;
		String redirectSuccMsg = null;
		int centralizedCommitteeId = 0;
		String centralizedCommitteeUserId[] = null;
		int isApproved = 0;
		try {	
			if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
				clientId = abcUtility.getSessionClientId(request);
				createdBy = abcUtility.getSessionUserDetailId(request);
				committeeType = StringUtils.hasLength(request.getParameter("hdCommitteeTypeId")) ? Integer.parseInt(request.getParameter("hdCommitteeTypeId")) : 0;
				memberCount = StringUtils.hasLength(request.getParameter("trCount")) ? Integer.parseInt(request.getParameter("trCount")) : 0;
				isFrom = StringUtils.hasLength(request.getParameter("hdIsFrom")) ? Integer.parseInt(request.getParameter("hdIsFrom")) : 0;
				
				String committeeName = "";
				if(committeeFormationService.checkUniqueCommitteeName(committeeName, committeeType, clientId)){
					
					if(committeeType == 1){
						redirectFailMsg = "msg_toc_valid_comm_name";	
					}
					else if (committeeType == 2){
						redirectFailMsg = "msg_tec_valid_comm_name";
					}				
				}
				else {
					if(isFrom==1){
						if(committeeType==1){
							committeeName = "centralizedTOC";
						}else{
							committeeName = "centralizedTEC";
						}
						TblCentralizedCommittee tblCentralizedCommittee = new TblCentralizedCommittee();
						tblCentralizedCommittee.setCentralizedCommitteeName(committeeName);
						tblCentralizedCommittee.setCentralizedCommitteeType(committeeType);
						tblCentralizedCommittee.setTblClient(new TblClient(clientId));
						tblCentralizedCommittee.setCreatedBy(createdBy);
						tblCentralizedCommittee.setIsActive(1);
						isSuccess = committeeFormationService.addTblCentralizedCommittee(tblCentralizedCommittee);
						centralizedCommitteeId = tblCentralizedCommittee.getCentralizedCommitteeId();
					}
					if((isFrom==1 && isSuccess) || isFrom==2){
						if(centralizedCommitteeId==0){
							centralizedCommitteeId = StringUtils.hasLength(request.getParameter("hdCentralizedCommitteeId")) ? Integer.parseInt(request.getParameter("hdCentralizedCommitteeId")) : 0;
						}
						TblCentralizedCommitteeUser centralizedCommitteeUser = null;
						String[] officerIds = request.getParameterValues("hdOfficerId");
						String[] userDetailIds = request.getParameterValues("hdUserDetailId");
						
						if(centralizedCommitteeUserId == null){
							centralizedCommitteeUserId = request.getParameterValues("hdCentralizedCommitteeUserId");
						}
						for (int i = 0; i < memberCount; i++) {
							int officerId = Integer.parseInt(officerIds[i]);
							int userDetailId = Integer.parseInt(userDetailIds[i]);
							int userRole = StringUtils.hasLength(request.getParameter("txtUserRole_"+(i+1))) ? Integer.parseInt(request.getParameter("txtUserRole_"+(i+1))) : 0;
							centralizedCommitteeUser = new TblCentralizedCommitteeUser();
							if(isFrom==2){
								isApproved = StringUtils.hasLength(request.getParameter("txtIsApproved_"+(i+1))) ? Integer.parseInt(request.getParameter("txtIsApproved_"+(i+1))) : 0;
								if(isApproved == 0){//add User
									TblCentralizedCommitteeUser users = committeeFormationService.getCentralizedCommitteeUserDetails(centralizedCommitteeId,userDetailId);
									if(users!=null){
										centralizedCommitteeUser.setCentralizedCommitteeUserId(users.getCentralizedCommitteeUserId());
									}else{
										centralizedCommitteeUser.setCentralizedCommitteeUserId(0);
									}
									isApproved = 1;
								}else if(isApproved == 2){//remove User
									isApproved = 0;
									centralizedCommitteeUser.setCentralizedCommitteeUserId(Integer.parseInt(centralizedCommitteeUserId[i]));
								}else{
									centralizedCommitteeUser.setCentralizedCommitteeUserId(Integer.parseInt(centralizedCommitteeUserId[i]));
								}
							}else{
								isApproved = 1 ;
							}
							centralizedCommitteeUser.setUserRoleId(userRole);
							centralizedCommitteeUser.setIsApproved(isApproved);
							centralizedCommitteeUser.setTblCentralizedCommittee(new TblCentralizedCommittee(centralizedCommitteeId));
							centralizedCommitteeUser.setTblUserDetail(new TblUserDetail(userDetailId));
							centralizedCommitteeUser.setTblUserLogin(new TblUserLogin(officerId));
							isSuccess = committeeFormationService.addTblCentralizedCommitteeUser(centralizedCommitteeUser);//can not perform add and remove operation in one list 
						}
					}
					if(isFrom==1 && isSuccess){
						//map centralized opening/evaluation committee in all pending tenders
						TblCommittee tblCommittee = null;
						int userDetailId = abcUtility.getSessionUserDetailId(request);
						TblCentralizedCommittee tblCentralizedCommittee= committeeFormationService.getCentralizedCommitteeDetails(committeeType,clientId);
						if(tblCentralizedCommittee!=null){
							List<Object[]> data = committeeFormationService.getPendingTenderWithoutCreateComm(clientId);
							for(Object[] obj : data){
								List<TblCommitteeUser> tblCommitteeUserList = new ArrayList<TblCommitteeUser>();
								List<TblCommitteeEnvelope> tblCommitteeEnvelopes = new ArrayList<TblCommitteeEnvelope>();
								tblCommittee = new TblCommittee();
				        		tblCommittee.setCommitteeName(tblCentralizedCommittee.getCentralizedCommitteeName());
				        		tblCommittee.setCommitteeType(committeeType);
				        		tblCommittee.setTblClient(new TblClient(clientId));
				        		int pendingTenderId = Integer.parseInt(obj[0].toString());
				    			tblCommittee.setTblTender(new TblTender(pendingTenderId));
				    			tblCommittee.setIsStandard(0);
				    			tblCommittee.setRemarks("");
				    			tblCommittee.setCreatedBy(userDetailId);
				    			tblCommittee.setIsActive(1);
				    			
				    			List<TblCentralizedCommitteeUser> committeeUsers = committeeFormationService.getCentralizedCommitteeUsers(tblCentralizedCommittee.getCentralizedCommitteeId(),1);
								if(committeeUsers!=null && !committeeUsers.isEmpty()){
									for (TblCentralizedCommitteeUser users : committeeUsers) {
										TblCommitteeUser tblCommitteeUser = new TblCommitteeUser();
										tblCommitteeUser.setTblCommittee(tblCommittee);
										tblCommitteeUser.setTblUserLogin(new TblUserLogin(users.getTblUserLogin().getUserId()));
										tblCommitteeUser.setTblUserDetail(new TblUserDetail(users.getTblUserDetail().getUserDetailId()));
										tblCommitteeUser.setChildId(0);
										tblCommitteeUser.setIsDecryptor(0);
										tblCommitteeUser.setEncryptionLevel(0);
										tblCommitteeUser.setRemarks("");
										tblCommitteeUser.setCreatedBy(userDetailId);
										tblCommitteeUser.setIsApproved(0);
					                    tblCommitteeUser.setUserRoleId(users.getUserRoleId());
										tblCommitteeUserList.add(tblCommitteeUser);
									}
								}
								List<TblTenderEnvelope> lstTenderEnvelope = eventCreationService.getTblTenderEnvelopeList(pendingTenderId);
								//remain query
								for(TblTenderEnvelope envelopes: lstTenderEnvelope){
									TblCommitteeEnvelope committeeEnvelope = new TblCommitteeEnvelope();
									committeeEnvelope.setMinMemberApproval(0);
									committeeEnvelope.setTblCommittee(tblCommittee);
									committeeEnvelope.setTblTenderEnvelope(envelopes);
									tblCommitteeEnvelopes.add(committeeEnvelope);
								}
								isSuccess = committeeFormationService.addCommittee(tblCommittee, tblCommitteeUserList, tblCommitteeEnvelopes, committeeType, 0);
							}
			    		}
					}
				}
				redirect = "etender/buyer/managecentralizedcommittee/"+committeeType;
				redirect = redirect + encryptDecryptUtils.generateRedirect(redirect, request);
			}
			else {
				redirect = SESSIONEXPIRED;
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		finally {
			if(committeeType == 1){
				if(isFrom==1){
					redirectSuccMsg = "redirect_success_centralized_toc_created";
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocCentralizeManage, postAddCentralizedTocCommittee, 0 , centralizedCommitteeId);
				}else if(isFrom==2){
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocCentralizeManage, postEditCentralizedTocCommittee, 0 , centralizedCommitteeId);
					redirectSuccMsg = "redirect_success_centralized_toc_updated";
				}
			}
			else if(committeeType == 2){ 
				redirectSuccMsg = "";
				if(isFrom==1){
					redirectSuccMsg = "redirect_success_centralized_tec_created";
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tecCentralizeManage, postAddCentralizedTecCommittee, 0 , centralizedCommitteeId);
				}else if(isFrom==2){
					redirectSuccMsg = "redirect_success_centralized_tec_updated";
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tecCentralizeManage, postEditCentralizedTecCommittee, 0 , centralizedCommitteeId);
				}
			}
		}
		redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectSuccMsg : redirectFailMsg);
		return "redirect:/" + redirect;
	}
	/** Get the user's Certificate EndDate
	 * author Lipi
	 * @param userId
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/ajax/getUserCertDate", method = RequestMethod.POST)
	@ResponseBody
    public String getUserCertDate(@RequestParam("hdUserId") int userId,HttpServletRequest request) {
		String retVal = ""; 
        try {
        	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	retVal = committeeFormationService.getUserCertEndDate(userId,clientBean.getIsDualCerti());
        	retVal = (retVal != null && !retVal.isEmpty() ? CommonUtility.convertTimezone(retVal) : "");
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return retVal;
    }
	
	 /**
     * @author anjali
     * This method used to get Digital Certificate Details
     * @param modelMap
     * @param userId
     * @param clientId
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/digitalcertidetails/{userId}", method = RequestMethod.POST)
    public String digitalCerti(ModelMap modelMap,@PathVariable("userId") int userId,HttpServletRequest request) {
        try {
        	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	List<Object[]> certificateDetails= departmentUserService.getUnMapCertDetails(userId, clientBean.getClientId());
        	if(certificateDetails!=null && !certificateDetails.isEmpty() )
        	{
        		for (int i = 0; i < certificateDetails.size(); i++) {
        			Map<String,Object> certDetail= new HashMap<String, Object>();
            		Object[] object = certificateDetails.get(i);
            		certDetail.put("fullName", object[0]);
            		certDetail.put("deptName", object[1]);
            		certDetail.put("desiName", object[2]);
            		certDetail.put("loginId", object[3]);
            		certDetail.put("keyUsage", object[14]);
            		certDetail.put("subject", object[5]);
            		certDetail.put("issuer", object[6]);
            		certDetail.put("publicKey", object[7]);
            		certDetail.put("serialNumber", object[8]);
            		certDetail.put("validFrom", object[9]);
            		certDetail.put("validTo", object[10]);
            		certDetail.put("certId",object[11]);
            		certDetail.put("userCertId",object[12]);
            		certDetail.put("isDual",object[13]);
            		if((Integer)object[14] == 1){
        			modelMap.addAttribute("SigningCerti", certDetail);
            		}else if((Integer)object[14] == 2){
           			modelMap.addAttribute("EncryptionCerti", certDetail);
            		}
    			}
        	}
        	modelMap.addAttribute("clientId", clientBean.getClientId());
        	if(certificateDetails != null){
        		modelMap.addAttribute("rowSize", certificateDetails.size());// for count how many rows return	
        	}
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally{
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tocViewLinkId, viewTocCommitteeDigiCert,0,userId);	
        }
        return "/common/admin/DigitalCertificateDetails";
    }
    @RequestMapping(value="/buyer/viewregrettbid/{tenderId}/{enc}", method=RequestMethod.GET)
	public String viewRegretedBid(@PathVariable("tenderId") int tenderId,HttpServletRequest request , ModelMap modelMap){
		
		try {
			modelMap.addAttribute("RegBidderList", eventBidSubmissionService.viewRegretedBidDetails(tenderId));
			tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));	
			
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, getViewRegretBidFromBidOpeningTab, tenderId,0);
		}
		return "etender/buyer/ViewRegretBid";
	}
    @RequestMapping(value="/buyer/ajax/checkbidexists", method=RequestMethod.POST)
	@ResponseBody
	public String checkBidExists(@RequestParam("tenderId") int tenderId, @RequestParam("companyId") int companyId, @RequestParam("formId") int formId,  HttpServletRequest request){
		long isExist = 0;
		String responseStr = SESSIONEXPIRED;
		try {
			if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
				isExist = committeeFormationService.checkBidExists(tenderId, companyId, formId);
				Integer exists = new Integer((int) isExist);
				responseStr = exists.toString();
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return responseStr;
	}
}
