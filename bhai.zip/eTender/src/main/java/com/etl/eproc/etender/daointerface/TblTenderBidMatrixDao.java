/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblTenderBidMatrix;
import java.util.List;

/**
 *
 * @author taher.tinwala
 */
public interface TblTenderBidMatrixDao  {

    public void addTblTenderBidMatrix(TblTenderBidMatrix tblTenderBidMatrix);

    public void deleteTblTenderBidMatrix(TblTenderBidMatrix tblTenderBidMatrix);

    public void updateTblTenderBidMatrix(TblTenderBidMatrix tblTenderBidMatrix);

    public List<TblTenderBidMatrix> getAllTblTenderBidMatrix();

    public List<TblTenderBidMatrix> findTblTenderBidMatrix(Object... values) throws Exception;

    public List<TblTenderBidMatrix> findByCountTblTenderBidMatrix(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderBidMatrixCount();

    public void saveUpdateAllTblTenderBidMatrix(List<TblTenderBidMatrix> tblTenderBidMatrixs);
}
