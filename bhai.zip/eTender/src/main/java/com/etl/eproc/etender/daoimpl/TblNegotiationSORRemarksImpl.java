package com.etl.eproc.etender.daoimpl;
/**
*
* @author darshan.raval
*/
import com.etl.eproc.etender.daointerface.TblNegotiationSORRemarksDao;
import com.etl.eproc.etender.model.TblNegotiationSORRemarks;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

@Repository @Transactional
public class TblNegotiationSORRemarksImpl extends AbcAbstractClass<TblNegotiationSORRemarks> implements TblNegotiationSORRemarksDao {

  
    @Override
    public void addTblNegotiationSORRemarks(TblNegotiationSORRemarks tblNegotiationSORRemarks){
        super.addEntity(tblNegotiationSORRemarks);
    }

    @Override
    public void deleteTblNegotiationSORRemarks(TblNegotiationSORRemarks tblNegotiationSORRemarks) {
        super.deleteEntity(tblNegotiationSORRemarks);
    }

    @Override
    public void updateTblNegotiationSORRemarks(TblNegotiationSORRemarks tblNegotiationSORRemarks) {
        super.updateEntity(tblNegotiationSORRemarks);
    }

    @Override
    public List<TblNegotiationSORRemarks> getAllTblNegotiationSORRemarks() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNegotiationSORRemarks> findTblNegotiationSORRemarks(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNegotiationSORRemarksCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNegotiationSORRemarks> findByCountTblNegotiationSORRemarks(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNegotiationSORRemarks(List<TblNegotiationSORRemarks> tblNegotiationSORRemarkss){
        super.updateAll(tblNegotiationSORRemarkss);
    }
}
