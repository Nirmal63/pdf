/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;

/**
 *
 * @author darshan
 */

import com.etl.eproc.etender.model.TblPreBidReport;
import java.util.List;

public interface TblPreBidReportDao  {

    public void addTblPreBidReport(TblPreBidReport tblPreBidReport);

    public void deleteTblPreBidReport(TblPreBidReport tblPreBidReport);

    public void updateTblPreBidReport(TblPreBidReport tblPreBidReport);

    public List<TblPreBidReport> getAllTblPreBidReport();

    public List<TblPreBidReport> findTblPreBidReport(Object... values) throws Exception;

    public List<TblPreBidReport> findByCountTblPreBidReport(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblPreBidReportCount();

    public void saveUpdateAllTblPreBidReport(List<TblPreBidReport> tblPreBidReports);

	public void saveOrUpdateTblPreBidReport(TblPreBidReport tblprebidreport);
}