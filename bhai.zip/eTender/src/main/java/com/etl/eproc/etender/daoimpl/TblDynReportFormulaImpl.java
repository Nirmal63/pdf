/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblDynReportFormulaDao;
import com.etl.eproc.etender.model.TblDynReportFormula;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author shreyansh.shah
 */
@Repository @Transactional
public class TblDynReportFormulaImpl extends AbcAbstractClass<TblDynReportFormula> implements TblDynReportFormulaDao {


    @Override
    public void addTblDynReportFormula(TblDynReportFormula tblDynReportFormula){
        super.addEntity(tblDynReportFormula);
    }

    @Override
    public void deleteTblDynReportFormula(TblDynReportFormula tblDynReportFormula) {
        super.deleteEntity(tblDynReportFormula);
    }

    @Override
    public void updateTblDynReportFormula(TblDynReportFormula tblDynReportFormula) {
        super.updateEntity(tblDynReportFormula);
    }

    @Override
    public List<TblDynReportFormula> getAllTblDynReportFormula() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynReportFormula> findTblDynReportFormula(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynReportFormulaCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynReportFormula> findByCountTblDynReportFormula(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDynReportFormula(List<TblDynReportFormula> tblDynReportFormulas){
        super.updateAll(tblDynReportFormulas);
    }

	@Override
	public void saveOrUpdateTblDynReportFormula(TblDynReportFormula tbldynreportformula) {
		super.saveOrUpdateEntity(tbldynreportformula);
	}
}
