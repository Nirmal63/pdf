package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblRebateForm;
import java.util.List;

public interface TblRebateFormDao  {

    public void addTblRebateForm(TblRebateForm tblRebateForm);

    public void deleteTblRebateForm(TblRebateForm tblRebateForm);

    public void updateTblRebateForm(TblRebateForm tblRebateForm);

    public List<TblRebateForm> getAllTblRebateForm();

    public List<TblRebateForm> findTblRebateForm(Object... values) throws Exception;

    public List<TblRebateForm> findByCountTblRebateForm(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblRebateFormCount();

    public void saveUpdateAllTblRebateForm(List<TblRebateForm> tblRebateForms);
}