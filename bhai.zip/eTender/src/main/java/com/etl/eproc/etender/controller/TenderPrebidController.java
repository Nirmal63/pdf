/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblAnswer;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblQuestion;
import com.etl.eproc.common.model.TblSubModule;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.model.TblCommittee;
import com.etl.eproc.etender.model.TblCommitteeUser;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.CommitteeFormationService;
import com.etl.eproc.etender.services.PrebidService;
import com.etl.eproc.etender.services.TenderCommonService;

/**
 *
 * @author shreyansh.shah
 */
@Controller
@RequestMapping("/etender")
public class TenderPrebidController {

    @Autowired
    private CommitteeFormationService comitteFormationService;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private CommonService commonService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private PrebidService prebidService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private MessageSource messageSource;
    @Autowired
    private ClientService clientService;
    
    @Value("#{etenderAuditTrailProperties['getcreateprebidcomittee']}")
    private String getcreatePrebidComittee;
    @Value("#{etenderAuditTrailProperties['geteditprebidcomittee']}")
    private String getEditPrebidComittee;
    @Value("#{etenderAuditTrailProperties['postaddprebidcomittee']}")
    private String postAddPrebidComittee;
    @Value("#{etenderAuditTrailProperties['posteditprebidcomittee']}")
    private String postEditPrebidComittee;
    @Value("#{etenderAuditTrailProperties['viewprebidcomittee']}")
    private String viewPrebidComittee;
    @Value("#{etenderAuditTrailProperties['getapproveprebidcomittee']}")
    private String getApprovePrebidComittee;
    @Value("#{etenderAuditTrailProperties['postapproveprebidcomittee']}")
    private String postApprovePrebidComittee;
    @Value("#{etenderAuditTrailProperties['getjoinprebidmeeting']}")
    private String getJoinPrebidMeeting;
    @Value("#{etenderAuditTrailProperties['getprebidanswer']}")
    private String getPrebidAnswer;
    @Value("#{etenderAuditTrailProperties['postprebidanswer']}")
    private String postPrebidAnswer;
    @Value("#{etenderAuditTrailProperties['allprebidqusans']}")
    private String allPrebidQusAns;
    @Value("#{etenderAuditTrailProperties['getapproveprebidreport']}")
    private String getapproveprebidreport;
    @Value("#{etenderAuditTrailProperties['postapproveprebidreport']}")
    private String postapproveprebidreport;
    
    @Value("#{tenderlinkProperties['pre_bid_meeting_create']?:218}")
    private int createCommitteeLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_edit']?:219}")
    private int editCommitteeLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_view']?:220}")
    private int viewCommitteeLinkId;
    @Value("#{tenderlinkProperties['pre_bid_committee_publish']?:221}")
    private int publishCommitteeLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_join_meeting']?:214}")
    private int jointMeetingLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_view_all_question_answer']?:215}")
    private int viewAllQuestionAnswerLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_view_my_question_answer']?:240}")
    private int viewMyQuestionAnswerLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_upload']?:216}")
    private int uploadPrebidDocLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_submit_answer']?:344}")
    private int replyLinkId;
    @Value("#{projectProperties['future_release']}")
    private String futureRelease;
    @Value("#{etenderProperties['prebid_submoduleId']?:31}")
    private int prebidSubModuleId;
    
    private static final String HIDDEN_TENDER_ID = "hdTenderId";
    private static final String TENDER_ID = "tenderId";
    private static final String PREBIDOBJ = "preBidObj";
    private static final String HIDDEN_COMITTEE_ID = "hdCommitteeId";
    private static final String IS_APPROVED = "isApproved";
    private static final String CURRENT_DATE = "currentDate";
    private static final String VIEW_TYPE = "viewType";
    private static final String MSG_VIEW_ALL_ANSWER = "msg_view_all_answer";
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    private static final int TAB_PREBID = 3;
    private static final int PREBID_COMMITTEETYPE=3;
    private static final int PREBID_MODULETYPE=1;

    /**
     * Method to view display create committee
     * @Author Shreyansh shah
     * @param tenderId
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/buyer/getcreatecommitee/{tenderId}/{enc}", method = RequestMethod.GET)
    public String getCreateCommitee(@PathVariable(TENDER_ID) int tenderId, ModelMap modelMap, HttpServletRequest request) {
	try {
	    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	} catch (Exception ex) {
	    return exceptionHandlerService.writeLog(ex);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createCommitteeLinkId, getcreatePrebidComittee, tenderId, 0);
	}
	return "/etender/buyer/CreateCommitee";
    }

    /**
     * Method to view edit committee details page
     *
     * @Author Shreyansh shah
     * @param tenderId
     * @param comitteeId
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/buyer/geteditcommitee/{tenderId}/{committeeId}/{enc}", method = RequestMethod.GET)
    public String getEditCommitee(@PathVariable(TENDER_ID) int tenderId, @PathVariable("committeeId") int comitteeId, ModelMap modelMap, HttpServletRequest request) {
	try {
	    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	    List<Object[]> committeeDetails = comitteFormationService.getAllCommitteeMemberDetails(comitteeId);
	    modelMap.addAttribute("operType", "Edit");
	    modelMap.addAttribute("committeeDetails", committeeDetails);
	    modelMap.addAttribute("prebidCommitePublish",comitteFormationService.getPreBidCommiteePublish(tenderId, comitteeId, PREBID_COMMITTEETYPE));
	    
	    Map<Integer ,Integer> addedMember=new HashMap<Integer ,Integer>();
	    List<HashMap<Integer,Integer>> addedMemberDetail = comitteFormationService.getAddNewCommitteMemberDeatils(addedMember, comitteeId, tenderId, PREBID_COMMITTEETYPE);
	    modelMap.addAttribute("addedMemberDetail", addedMemberDetail);
	} catch (Exception ex) {
	    exceptionHandlerService.writeLog(ex);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editCommitteeLinkId, getEditPrebidComittee, tenderId, comitteeId);
	}
	return "/etender/buyer/CreateCommitee";
    }

    /**
     * Method to post committee details for both create and edit
     * @Author Shreyansh shah
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/submitprebidcomittee", method = RequestMethod.POST)
    public String submitPrebidComittee(HttpServletRequest request, RedirectAttributes redirectAttributes) {
	HttpSession session = request.getSession();
	String retVal = null;
	boolean isSuccess = false;
	boolean isServerSideValid = true;
	boolean approvedInWorkflow=true; 
	SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;
	int userId = abcUtility.getSessionUserId(request);
        int tenderId = 0;
        StringBuilder strQuery = new StringBuilder();
        tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
                    strQuery.append("redirect:/etender/buyer/tenderdashboard/").append(tenderId).append("/").append(TAB_PREBID)
		    .append(encryptDecryptUtils.generateRedirect(strQuery.substring(strQuery.indexOf("/")+1), request));
                    retVal = userId != 0 ? strQuery.toString() : REDIRECT_SESSION_EXPIRED;
	int committeeId = 0;
	int prevCommitteeId = 0;
	boolean isEdit = false;
	TblCommittee tblCommittee = null;
	String redirectMsg = "redirect_success_prebid_comittee";
	String errMsg = CommonKeywords.ERROR_MSG_KEY.toString();
	int linkId = createCommitteeLinkId;
	String opType = "";
	try {
            List<TblCommitteeUser> tblcommitteeusers = new ArrayList<TblCommitteeUser>();
            String userIds[];
            String userDetailIds[];
            userIds = request.getParameterValues("hduserId");
            userDetailIds = request.getParameterValues("hduserDetailId");
	    if (userId != 0 && (userIds != null && userDetailIds != null)) {
		committeeId = StringUtils.hasLength(request.getParameter(HIDDEN_COMITTEE_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_COMITTEE_ID)) : 0;
		prevCommitteeId = committeeId; 
		boolean isPreCommitePublish = comitteFormationService.getPreBidCommiteePublish(tenderId,committeeId,PREBID_COMMITTEETYPE);
		opType = StringUtils.hasLength(request.getParameter("hdOpType")) ? request.getParameter("hdOpType") : "";
		List<Object[]> lstPrebidObjArray = tenderCommonService.getTenderPrebidDetailByTenderId(tenderId);
		
		if(lstPrebidObjArray.get(0)[3]!=null){
			if(committeeId !=0 && (commonService.getServerDateTime().compareTo((Date) lstPrebidObjArray.get(0)[3])) > 0){
				isServerSideValid = false;
				errMsg = "redirect_success_prebid_comittee_time_is_over";
			}
		}
		if(isServerSideValid){
			int isWorkflowRequired = (Integer) tenderCommonService.getTenderField(tenderId, "isWorkflowRequired");
			if(isWorkflowRequired==1){
				boolean isCommitteeApproved = comitteFormationService.isCommitteeApproved(committeeId);
				if(isCommitteeApproved){
					int workFlowId = commonService.checkEntryTblWorkflow(committeeId,tenderId);
					if(workFlowId==3 || workFlowId==5){
						approvedInWorkflow = false;
						errMsg = "msg_workflow_complete";
					}
				}
			}
		}
		if(isServerSideValid && approvedInWorkflow){
			if(isPreCommitePublish){
				comitteFormationService.inActivePrevCommittee(tenderId,3);
				committeeId = 0;
			}
		}
		isEdit = committeeId != 0;
		if(isServerSideValid && approvedInWorkflow){
			if (!isEdit) {
			    tblCommittee = new TblCommittee();
			    tblCommittee.setCommitteeName("");
			    tblCommittee.setCommitteeType(PREBID_COMMITTEETYPE);
			    tblCommittee.setTblTender(new TblTender(tenderId));
			    tblCommittee.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
			    tblCommittee.setIsStandard(0);
			    tblCommittee.setRemarks("");
			    tblCommittee.setCreatedBy(sessionBean.getUserDetailId());
			    tblCommittee.setIsActive(1);
			    tblCommittee.setIsApproved(0);
			}
			int count = 0;
			
			List<TblCommitteeUser> getJoinCommiteApproveDeatils = null;
			if(prevCommitteeId != 0){
				getJoinCommiteApproveDeatils = comitteFormationService .getJoinCommiteeUserDetail(prevCommitteeId,1 , 3); 
			}
			
			for (count = 0; count < userDetailIds.length; count++) {
			
				boolean flag= true;
					
			    TblCommitteeUser tblCommitteeUser = new TblCommitteeUser();
			    tblCommitteeUser.setTblCommittee(isEdit ? new TblCommittee(committeeId) : tblCommittee);
			    	
			    if(getJoinCommiteApproveDeatils != null && !getJoinCommiteApproveDeatils.isEmpty()){
			    	for (TblCommitteeUser oldTblCommiteeUser : getJoinCommiteApproveDeatils) {
			    		 if(oldTblCommiteeUser.getTblUserLogin().getUserId() == Integer.parseInt(userIds[count]) && oldTblCommiteeUser.getTblUserDetail().getUserDetailId() == Integer.parseInt(userDetailIds[count])){
				   			 
			    			tblCommitteeUser.setTblUserLogin(oldTblCommiteeUser.getTblUserLogin());
							tblCommitteeUser.setTblUserDetail(oldTblCommiteeUser.getTblUserDetail());
							tblCommitteeUser.setChildId(oldTblCommiteeUser.getChildId());
							tblCommitteeUser.setIsDecryptor(oldTblCommiteeUser.getIsDecryptor());
							tblCommitteeUser.setEncryptionLevel(count);
							tblCommitteeUser.setRemarks(oldTblCommiteeUser.getRemarks());
							tblCommitteeUser.setApprovedOn(oldTblCommiteeUser.getApprovedOn());
							tblCommitteeUser.setApprovedBy(oldTblCommiteeUser.getApprovedBy());
							tblCommitteeUser.setCreatedOn(oldTblCommiteeUser.getCreatedOn());
							tblCommitteeUser.setCreatedBy(sessionBean.getUserDetailId());
							tblCommitteeUser.setIsApproved(oldTblCommiteeUser.getIsApproved());
								
							flag = false;
				   		 }
					}
			    }
			    	
				if(flag){
					tblCommitteeUser.setTblUserLogin(new TblUserLogin(Integer.parseInt(userIds[count])));
					tblCommitteeUser.setTblUserDetail(new TblUserDetail(Integer.parseInt(userDetailIds[count])));
					tblCommitteeUser.setChildId(0);
					tblCommitteeUser.setIsDecryptor(0);
					tblCommitteeUser.setEncryptionLevel(count);
					tblCommitteeUser.setRemarks("");
					tblCommitteeUser.setCreatedBy(sessionBean.getUserDetailId());
					tblCommitteeUser.setIsApproved(0);
			    	}
				    
					tblcommitteeusers.add(tblCommitteeUser);
				}
			
				if (isEdit) {
		                   isSuccess = comitteFormationService.updateRemoveCommitteeMembers(committeeId,tblcommitteeusers);
				} else {
			    	isSuccess = comitteFormationService.addTblCommitteeMember(tblCommittee, tblcommitteeusers);
		                   committeeId = tblCommittee.getCommitteeId();
				}
				if (isSuccess) {
		                   retVal = strQuery.toString();
				}
				if(isEdit || opType.equalsIgnoreCase("Edit")){
					linkId = editCommitteeLinkId;
					redirectMsg = "redirect_success_editprebid_comittee";
				}
		    }
	    }else{
	    	 retVal = strQuery.toString();
	    }
	} catch (Exception ex) {
	    retVal = exceptionHandlerService.writeLog(ex);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, (isEdit || opType.equalsIgnoreCase("Edit"))? postEditPrebidComittee : postAddPrebidComittee, tenderId, committeeId);
	}
	redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectMsg : errMsg);
	return retVal;
    }

    /**
     * Method to view committee details
     *
     * @Author Shreyansh shah
     * @param tenderId
     * @param comitteeId
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/buyer/viewcommitee/{tenderId}/{committeeId}/{isWorkFlow}/{enc}", method = RequestMethod.GET)
    public String viewCommitteeDetails(@PathVariable(TENDER_ID) int tenderId, @PathVariable("committeeId") int comitteeId, @PathVariable("isWorkFlow") int isWorkFlow, ModelMap modelMap, HttpServletRequest request) {
	try {
	    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	    modelMap.addAttribute("committeeDetails", comitteFormationService.getAllCommitteeMemberDetails(comitteeId));
	} catch (Exception ex) {
	    return exceptionHandlerService.writeLog(ex);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewCommitteeLinkId, viewPrebidComittee, tenderId, 0);
	}

	return "/etender/buyer/ViewPreBidCommittee";
    }

    /**
     * Method to view approve committee details
     * @Author Shreyansh shah
     * @param tenderId
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/buyer/viewapprovecommitee/{tenderId}/{committeeId}/{enc}", method = RequestMethod.GET)
    public String viewApproveCommitteeDetails(@PathVariable(TENDER_ID) int tenderId, @PathVariable("committeeId") int comitteeId, ModelMap modelMap, HttpServletRequest request) {
	try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	    modelMap.addAttribute("committeeDetails", comitteFormationService.getAllCommitteeMemberDetails(comitteeId));
	    modelMap.addAttribute("operType", "Approve");
	    modelMap.addAttribute("isWorkFlow", 0);
	} catch (Exception ex) {
	    return exceptionHandlerService.writeLog(ex);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), publishCommitteeLinkId, getApprovePrebidComittee, tenderId, comitteeId);
	}
	return "/etender/buyer/ViewPreBidCommittee";
    }

    /**
     * Method to post approve committee details
     *
     * @Author Shreyansh shah
     * @param committeeId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/approvecommitee", method = RequestMethod.POST)
    public String approveCommitteeDetails(@RequestParam("hdCommitteeId") int committeeId, ModelMap modelMap, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes) {
		boolean isSuccess = false;
		int tenderId = 0;
		String retVal = REDIRECT_SESSION_EXPIRED;
		String eventType = "";
		HashMap<String, Object> msgParams = new HashMap<String, Object>();
		SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;
        ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        try {
		    if (abcUtility.getSessionUserId(request) != 0) {
		    	String remarks = request.getParameter("txtaRemarks");
                tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
                eventType = StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
                isSuccess = comitteFormationService.approveCommittee(remarks, sessionBean.getUserDetailId(), committeeId);
                if (isSuccess) {
		            StringBuilder redirectUrl = new StringBuilder();
		            //Added By Lipi - Start
		            msgParams.put("EventType", eventType);
		            msgParams.put("EventId", tenderId);	  
		            msgParams.put("SubDomainName", clientService.getClientNameById(clientBean.getClientId()));
		            String encryptUrlStr = encryptDecryptUtils.encrypt("etender/buyer/viewcommitee/" + tenderId + "/" + committeeId + "/0");
	            	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
	            	msgParams.put("link", herfStr);
	            	//End
		            mailContentUtillity.dynamicMailGeneration("35", String.valueOf(sessionBean.getUserId()), String.valueOf(tenderId), msgParams, String.valueOf(committeeId));
		            redirectUrl.append("redirect:/etender/buyer/tenderdashboard/").append(tenderId).append("/").append(TAB_PREBID)
		            	.append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1), request));
		            retVal = redirectUrl.toString();
                }
		    }
		} catch (Exception ex) {
		    retVal = exceptionHandlerService.writeLog(ex);
		} finally {
		    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), publishCommitteeLinkId, postApprovePrebidComittee, tenderId, committeeId);
		}
		redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "redirect_success_prebid_committee_publish" : CommonKeywords.ERROR_MSG_KEY.toString());
		return retVal;
    }

    /**
     * Method to view joint meeting details page
     * @Author Shreyansh shah
     * @param tenderId
     * @param modelMap
     * @param request
     * @return to view
     */
    @RequestMapping(value = "/buyer/prebidmeeting/{tenderId}/{committeeUserId}/{isApproved}/{enc}", method = RequestMethod.GET)
    public String joinPrebidMeeting(@PathVariable(TENDER_ID) int tenderId, @PathVariable("committeeUserId") int committeeUserId, @PathVariable(IS_APPROVED) int isApproved, ModelMap modelMap, HttpServletRequest request, HttpSession session) {
	boolean isSuccess;
	try {
            int approvedFlag = isApproved;
	    SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;
	    isSuccess = comitteFormationService.approvePreBidComitteeMember(sessionBean.getUserDetailId(), committeeUserId);
	    if (isSuccess) {
		approvedFlag = 1;
	    }
	    List<Object[]> listArrObj = prebidService.getQuestionAnswers(sessionBean.getUserId(), sessionBean.getUserTypeId(), tenderId, true);
	    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));

	    modelMap.addAttribute(PREBIDOBJ, tenderCommonService.getTenderPrebidDetailByTenderId(tenderId));
	    modelMap.addAttribute(CURRENT_DATE, commonService.getServerDateTime());
	    modelMap.addAttribute("answerOption", prebidService.getAnswerOptions(futureRelease));
	    modelMap.addAttribute(VIEW_TYPE, "View all questions");
	    modelMap.addAttribute(IS_APPROVED, approvedFlag);
	    modelMap.addAttribute("totalRec", listArrObj.size());
	    modelMap.addAttribute("QusAnsList", listArrObj);
	} catch (Exception e) {
	    exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), jointMeetingLinkId, getJoinPrebidMeeting, tenderId, 0);
	}
	return "etender/buyer/PreBidMeeting";
    }

    /**
     * Method to post prebid answer
     * @param tenderId
     * @param tabId
     * @param modelMap
     * @param request
     * @return to view
     */
    @RequestMapping(value = "/buyer/postPrebidAnswer", method = RequestMethod.POST)
    public String postBidAnswer(ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes, HttpSession session) {
	int tenderId = 0;
	boolean isSuccess = false;
	String retVal = REDIRECT_SESSION_EXPIRED;
	SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;
	try {
	    if (abcUtility.getSessionUserId(request) != 0) {
		tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
		modelMap.addAttribute(PREBIDOBJ, tenderCommonService.getTenderPrebidDetailByTenderId(tenderId));
		modelMap.addAttribute(CURRENT_DATE, commonService.getServerDateTime());
		modelMap.addAttribute("qusAnsList", prebidService.getQuestionAnswers(sessionBean.getUserId(), sessionBean.getUserTypeId(), tenderId, true));
		modelMap.addAttribute(VIEW_TYPE, "View all questions");
		isSuccess = true;
		if (isSuccess) {
		    retVal = "redirect:/etender/buyer/prebidmeeting/" + tenderId + encryptDecryptUtils.generateRedirect("etender/buyer/prebidmeeting/" + tenderId, request);
		}
	    }
	} catch (Exception e) {
	    retVal = exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewAllQuestionAnswerLinkId, getPrebidAnswer, tenderId, 0);
	}
	redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_prebid_post_question" : CommonKeywords.ERROR_MSG_KEY.toString());
	return retVal;
    }

    /**
     *
     * @param tenderId
     * @param viewQueryType
     * @param viewQueryFrom
     * @param modelMap
     * @param request
     * @return ajaxView
     */
    @RequestMapping(value = "/buyer/viewAjaxQueries", method = RequestMethod.POST)
    public String viewAjaxQuestion(@RequestParam("hdTenderId") int tenderId, @RequestParam("hdViewType") int viewType, ModelMap modelMap, HttpServletRequest request, HttpSession session) {
        String retVal = REDIRECT_SESSION_EXPIRED;
	try {
	    SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;
	    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	    modelMap.addAttribute(PREBIDOBJ, tenderCommonService.getTenderPrebidDetailByTenderId(tenderId));
	    modelMap.addAttribute(CURRENT_DATE, commonService.getServerDateTime());
	    modelMap.addAttribute("totalRec", prebidService.getQuestionAnswers(sessionBean.getUserId(), sessionBean.getUserTypeId(), tenderId, (viewType == 1)).size());
	    modelMap.addAttribute("QusAnsList", prebidService.getQuestionAnswers(sessionBean.getUserId(), sessionBean.getUserTypeId(), tenderId, (viewType == 1)));
	    modelMap.addAttribute(VIEW_TYPE, (viewType == 1 ? messageSource.getMessage(MSG_VIEW_ALL_ANSWER, null, LocaleContextHolder.getLocale()) : messageSource.getMessage("view_my_answer", null, LocaleContextHolder.getLocale())));
            if(sessionBean != null) {
                retVal = "etender/common/ViewPrebidQuesAns";
            }
	} catch (Exception e) {
	    retVal = exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), (viewType == 1 ? viewAllQuestionAnswerLinkId : viewMyQuestionAnswerLinkId), (viewType == 1 ? "All " : "Own ") + allPrebidQusAns , tenderId, 0);
	}
	return retVal;
    }

    /**
     * Method to display all question,answer and my question answer viewType 1 -
     * All viewType 0 - My
     *
     * @param tenderId
     * @param viewType
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/viewQueries/{tenderId}/{isApproved}/{viewType}/{enc}", method = RequestMethod.GET)
    public String viewQuestions(@PathVariable(TENDER_ID) int tenderId, @PathVariable(VIEW_TYPE) int viewType, @PathVariable(IS_APPROVED) int isApproved, ModelMap modelMap, HttpServletRequest request, HttpSession session) {
	try {
	    SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;
	    tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
	    modelMap.addAttribute("answerOption", prebidService.getAnswerOptions(futureRelease));
	    modelMap.addAttribute(PREBIDOBJ, tenderCommonService.getTenderPrebidDetailByTenderId(tenderId));
	    modelMap.addAttribute(CURRENT_DATE, commonService.getServerDateTime());
	    modelMap.addAttribute("QusAnsList", prebidService.getQuestionAnswers(sessionBean.getUserId(), sessionBean.getUserTypeId(), tenderId, (viewType == 1)));
	    modelMap.addAttribute(IS_APPROVED, isApproved);
	    modelMap.addAttribute(VIEW_TYPE, (viewType == 1 ? messageSource.getMessage(MSG_VIEW_ALL_ANSWER, null, LocaleContextHolder.getLocale()) : messageSource.getMessage("view_my_answer", null, LocaleContextHolder.getLocale())));
	} catch (Exception e) {
	    return exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), (viewType == 1 ? viewAllQuestionAnswerLinkId : viewMyQuestionAnswerLinkId), (viewType == 1 ? messageSource.getMessage(MSG_VIEW_ALL_ANSWER, null, LocaleContextHolder.getLocale()) : messageSource.getMessage("view_my_answer", null, LocaleContextHolder.getLocale())) + allPrebidQusAns, tenderId, 0);
	}
	return "etender/buyer/PreBidMeeting";
    }

    /**
     * To display popup for prebid answer reply
     * @Author Shreyansh shah
     * @param modelMap
     * @param questionId
     * @param tenderId
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/viewupdateanswer", method = RequestMethod.POST)
    public String viewUpdateAnswer(ModelMap modelMap, @RequestParam("txtQuestionId") int questionId, @RequestParam("txtTenderId") int tenderId, HttpServletRequest request) {
        String retVal = REDIRECT_SESSION_EXPIRED;
	try {
            if (abcUtility.getSessionUserId(request) != 0) {
                TblQuestion tblQuestion =  prebidService.getQuestionById(questionId);
                modelMap.addAttribute("questionId", questionId);
                modelMap.addAttribute(TENDER_ID, tenderId);
                modelMap.addAttribute("question", tblQuestion.getQuestionText());
                modelMap.addAttribute("answerOption", prebidService.getAnswerOptions(futureRelease));
                retVal = "/etender/buyer/PrebidAnswer";
            }
	} catch (Exception ex) {
	    retVal = exceptionHandlerService.writeLog(ex);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), replyLinkId, getPrebidAnswer, tenderId, questionId);
	}
	return retVal;
    }

    /**
     * To post answer given by officer
     * @Author Shreyansh shah
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/submitanswer", method = RequestMethod.POST)
    public String submitAnswer(ModelMap modelMap, HttpServletRequest request, HttpSession session) {
	boolean isSuccess;
	int tenderId = 0;
	String retVal = REDIRECT_SESSION_EXPIRED;
	TblAnswer tblAnswer = null;
	try {
	    SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;
	    if (abcUtility.getSessionUserId(request) != 0) {
                int userTypeId = sessionBean.getUserTypeId();
                int userId = sessionBean.getUserId();
                int userDetailsId = sessionBean.getUserDetailId();
		tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
		int questionId = StringUtils.hasLength(request.getParameter("hdQuestionId")) ? Integer.parseInt(request.getParameter("hdQuestionId")) : 0;
		int answerType = StringUtils.hasLength(request.getParameter("selAnswerOption")) ? Integer.parseInt(request.getParameter("selAnswerOption")) : 0;
		int oldQuestionId = questionId;
		if (answerType == 3) {
		    TblQuestion question = new TblQuestion();
		    if (futureRelease.equalsIgnoreCase("true")) {
			question.setQuestionText(StringUtils.hasLength(request.getParameter("rtfRephraseQuestion")) ? request.getParameter("rtfRephraseQuestion") : "");
		    }
		    question.setObjectId(tenderId);
		    question.setTblSubModule(new TblSubModule(prebidSubModuleId));
		    question.setModuleType(PREBID_MODULETYPE);
		    question.setUserTypeId(userTypeId);
		    question.setTblUserLogin(new TblUserLogin(userId));
		    question.setTblUserDetail(new TblUserDetail(userDetailsId));
		    question.setParentQuestionId(questionId);
		    question.setParentId(0);
		    question.setCstatus(1);
		    isSuccess = prebidService.addTblQuestion(question);
		    if (isSuccess) {
			questionId = question.getQuestionId();
		    }
		    
		}
		String answer = StringUtils.hasLength(request.getParameter("rtfAnswer")) ? request.getParameter("rtfAnswer") : "";
		int answerId = 0;
		List<Object[]> tblans = prebidService.getAnswerById(questionId);
		 tblAnswer =  new TblAnswer();
		if(!tblans.isEmpty())
		{
			java.util.Iterator<Object[]> itr = tblans.iterator();			
				for(Object[] obj : tblans){			
					answerId =  Integer.parseInt(String.valueOf(obj[0]));		
				}				
			isSuccess =  prebidService.updateTblAnswerById(answerId, answer);
			
			tblAnswer.setAnswerId(answerId);				
		}
		else
		{
			 tblAnswer =  new TblAnswer();
			tblAnswer.setTblQuestion(new TblQuestion(questionId));
			tblAnswer.setAnswerText(answer);
			tblAnswer.setUserTypeId(userTypeId);
			tblAnswer.setTblUserLogin(new TblUserLogin(userId));
			tblAnswer.setTblUserDetail(new TblUserDetail(userDetailsId));
			tblAnswer.setCstatus(2);
			isSuccess = prebidService.addTblAnswer(tblAnswer);
			
		}	
		if (isSuccess) {
                    StringBuilder redirectUrl = new StringBuilder();
		    prebidService.updateTblQuestionById(oldQuestionId, answerType);
                    redirectUrl.append("redirect:/etender/buyer/viewQueries/").append(tenderId).append("/1/1")
		    .append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1), request));
                    retVal = redirectUrl.toString();
		}
		modelMap.addAttribute(PREBIDOBJ, tenderCommonService.getTenderPrebidDetailByTenderId(tenderId));
		modelMap.addAttribute(CURRENT_DATE, commonService.getServerDateTime());
		modelMap.addAttribute("questionlist", prebidService.getUnAnswerdQuestionList(0, tenderId));
		modelMap.put(TENDER_ID, tenderId);
		modelMap.put(VIEW_TYPE, messageSource.getMessage(MSG_VIEW_ALL_ANSWER, null, LocaleContextHolder.getLocale()));
	    }
	} catch (Exception ex) {
	    retVal = exceptionHandlerService.writeLog(ex);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), replyLinkId, postPrebidAnswer, tenderId, tblAnswer.getAnswerId());
	}
	return retVal;
    }

    /**
     * To Display list of unanswered question
     * @Author Shreyansh shah
     * @param tenderId
     * @param viewType
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/viewPendingQueries", method = RequestMethod.POST)
    public String viewPendingQuestion(@RequestParam("hdTenderId") int tenderId, ModelMap modelMap, HttpServletRequest request) {
        String retVal = REDIRECT_SESSION_EXPIRED;
	try {
            if (abcUtility.getSessionUserId(request) != 0) {
                modelMap.addAttribute(TENDER_ID, tenderId);
                modelMap.addAttribute("questionlist", prebidService.getUnAnswerdQuestionList(0, tenderId));
                retVal = "etender/buyer/ViewPendingQuestions";
            }
	} catch (Exception e) {
	    retVal = exceptionHandlerService.writeLog(e);
	} 
	return retVal;
    }

    @RequestMapping(value = "/buyer/viewApprovePrebidReport/{tenderId}/{prebidReportId}/{enc}",method= RequestMethod.GET)
    public String viewApprovePrebidReport(@PathVariable(TENDER_ID) int tenderId, @PathVariable("prebidReportId") int prebidReportId, ModelMap modelMap,HttpServletRequest request) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request)); 
            modelMap.addAttribute("linkId", uploadPrebidDocLinkId);
            modelMap.addAttribute("objectId", tenderId);
            modelMap.addAttribute("cStatusDocView", 1);
            modelMap.addAttribute("cStatusDoc", 1);
            modelMap.addAttribute("isReadOnly", "Y");
            return "etender/buyer/PublishPrebidReport";
        } catch(Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), uploadPrebidDocLinkId, getapproveprebidreport, tenderId, 0);
        }
    }
    
    @RequestMapping(value = "/buyer/approvePrebidReport", method = RequestMethod.POST)
    public String approvePrebidReport(@RequestParam("hdPrebidReportId") int prebidReportId, ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) {
	boolean isSuccess = false;
	int tenderId = 0;
	String retVal = REDIRECT_SESSION_EXPIRED;
	String eventType = "";
	HashMap<String, Object> msgParams = new HashMap<String, Object>();
	try {
            if(abcUtility.getSessionUserId(request)!=0) {
                tenderId = StringUtils.hasLength(request.getParameter(HIDDEN_TENDER_ID)) ? Integer.parseInt(request.getParameter(HIDDEN_TENDER_ID)) : 0;
                String remarks = StringUtils.hasLength(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") : "";
                eventType = StringUtils.hasLength(request.getParameter("hdEventType")) ? request.getParameter("hdEventType") : "";
                isSuccess = prebidService.approvePrebidReport(remarks, abcUtility.getSessionUserDetailId(request), prebidReportId);
                if (isSuccess) {
                    StringBuilder redirectUrl = new StringBuilder();
                    
                    /* Bug #32860 By Jitendra. */
                    msgParams.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
                    //Added By Lipi - Start
                    msgParams.put("eventType", eventType);
    	            msgParams.put("eventId", tenderId);	  
    	            String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/downloadtenderdocuments/" + tenderId);
                	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                	msgParams.put("link", herfStr);
                	//End
                    mailContentUtillity.dynamicMailGeneration("39", String.valueOf(abcUtility.getSessionUserId(request)), String.valueOf(tenderId), msgParams);
                    redirectUrl.append("redirect:/etender/buyer/tenderdashboard/").append(tenderId).append("/").append(TAB_PREBID)
                            .append(encryptDecryptUtils.generateRedirect(redirectUrl.substring(redirectUrl.indexOf("/")+1),request));
                    retVal = redirectUrl.toString();
                }
            }
	} catch (Exception e) {
	    retVal = exceptionHandlerService.writeLog(e);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), uploadPrebidDocLinkId, postapproveprebidreport, tenderId, prebidReportId);
	}
	redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "redirect_success_prebid_meeting_publish" : CommonKeywords.ERROR_MSG_KEY.toString());
	return retVal;
    }

    
}
