package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.model.TblSmboqdtls;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblSmboqdtls;
import com.etl.eproc.etender.daointerface.TblsmboqdtlsDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblsmboqdtlsImpl extends AbcAbstractClass<TblSmboqdtls> implements com.etl.eproc.etender.daointerface.TblsmboqdtlsDao {


    @Override
    public void addTblsmboqdtls(TblSmboqdtls tblsmboqdtls){
        super.addEntity(tblsmboqdtls);
    }

    @Override
    public void deleteTblsmboqdtls(TblSmboqdtls tblsmboqdtls) {
        super.deleteEntity(tblsmboqdtls);
    }

    @Override
    public void updateTblsmboqdtls(TblSmboqdtls tblsmboqdtls) {
        super.updateEntity(tblsmboqdtls);
    }

    @Override
    public List<TblSmboqdtls> getAllTblsmboqdtls() {
        return super.getAllEntity();
    }

    @Override
    public List<TblSmboqdtls> findTblsmboqdtls(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblsmboqdtlsCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblSmboqdtls> findByCountTblsmboqdtls(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblsmboqdtls(List<TblSmboqdtls> tblsmboqdtlss){
        super.updateAll(tblsmboqdtlss);
    }
}
