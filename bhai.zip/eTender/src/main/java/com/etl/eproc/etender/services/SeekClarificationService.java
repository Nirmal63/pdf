/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblCompanyDao;
import com.etl.eproc.common.daointerface.TblQuestionDao;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.etender.daointerface.TblBroadCastQuestionMappingDao;
import com.etl.eproc.etender.daointerface.TblClarificationBroadCastDao;
import com.etl.eproc.etender.daointerface.TblSeekClarificationDao;
import com.etl.eproc.etender.model.TblBroadCastQuestionMapping;
import com.etl.eproc.etender.model.TblClarificationBroadCast;
import com.etl.eproc.etender.model.TblSeekClarification;

/**
 *
 * @author shreyansh.shah
 */
@Service
public class SeekClarificationService{

    @Autowired
    private HibernateQueryDao hibernateQueryDao;    
    @Autowired
    private TblSeekClarificationDao tblSeekClarificationDao;
    @Autowired
    private TblClarificationBroadCastDao tblClarificationBroadCastDao;
    @Autowired
    private TblCompanyDao tblCompanyDao;
    @Autowired
    private TblQuestionDao tblQuestionDao;
    @Autowired
    private TblBroadCastQuestionMappingDao tblBroadCastQuestionMappingDao;
     

    /**
     * Add seekclarification date
     * @param tblseekclarification
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public  boolean addTblSeekClarification(TblSeekClarification tblseekclarification,String clarificationId) throws Exception{
    boolean bSuccess = false;             
        if(clarificationId == null) {
            tblSeekClarificationDao.addTblSeekClarification(tblseekclarification);
        } else {
            updateOldConfigureDate(Integer.parseInt(clarificationId));
            tblSeekClarificationDao.addTblSeekClarification(tblseekclarification);
        }
            bSuccess=true;        
        return bSuccess;

    }
    
     /**
     * get seekclarification details of clarification Id
     * @param clarificationId
     * @return
     * @throws Exception 
     */
    public  TblSeekClarification getSeekClarificationById(int clarificationId) throws Exception{
            List<TblSeekClarification> list = null;        
        list = tblSeekClarificationDao.findTblSeekClarification("clarificationId",Operation_enum.EQ,clarificationId);                
            return (list!=null && !list.isEmpty()) ? list.get(0) : null;            
    }
    
    /**
     * To get Response End date and company name for display
     * @param tenderId
     * @param envelopeId
     * @param companyId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getConfigureDateData(int tenderId,int envelopeId,int companyId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        var.put("companyId",companyId);
        list = hibernateQueryDao.createNewQuery("select tblseekclarification.clarificationId, tblseekclarification.responseEndDate, tblcompany.companyName from TblSeekClarification tblseekclarification inner join tblseekclarification.tblCompany tblcompany where tblseekclarification.tblTender.tenderId=:tenderId and tblseekclarification.tblTenderEnvelope.envelopeId=:envelopeId and tblseekclarification.tblCompany.companyId=:companyId and tblseekclarification.isActive=1",var);                
        return list;        

    }
    /**
     * get Comapny details
     * @param companyId
     * @return
     * @throws Exception 
     */
    public  TblCompany getCompanyById(int companyId) throws Exception{
            List<TblCompany> list = null;        
        list = tblCompanyDao.findTblCompany("companyId",Operation_enum.EQ,companyId);                
            return (list!=null && !list.isEmpty()) ? list.get(0) : null;            

    }
    
    /**
     * udpate status of  old date of selected clarificationId
     * @param clarificationId
     * @return
     * @throws Exception 
     */
    public boolean updateOldConfigureDate(int clarificationId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clarificationId",clarificationId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblSeekClarification set isActive=0 where clarificationId=:clarificationId",var);        
        return cnt!=0;

    }
    
    /**
     * get evaluate bidder list envelope wise
     * @param tenderId
     * @param envelopeId
     * @param envelopeType
     * @param sortOrder
     * @return
     * @throws Exception 
     */
    public List<Object[]> getEvaluateBidderList(int tenderId,int envelopeId,int envelopeType,int sortOrder) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        //var.put("envelopeType",envelopeType);
        StringBuilder query = new StringBuilder();
        if(envelopeType == 1 || (envelopeType == 2 && sortOrder == 1)){
	query.append("select tblseekclarification.clarificationId, tblcompany.companyId, tblcompany.companyName, tblseekclarification.responseEndDate, tblfinalsubmission.tblUserDetail.userDetailId ");
	query.append("from TblFinalSubmission tblfinalsubmission ");
	query.append("inner join tblfinalsubmission.tblCompany tblcompany ");
	query.append("left join tblcompany.tblSeekClarification tblseekclarification with tblseekclarification.tblTenderEnvelope.envelopeId =:envelopeId and tblseekclarification.isActive = 1 ");
	query.append("where tblfinalsubmission.tblTender.tenderId =:tenderId and tblfinalsubmission.isActive = 1 and tblfinalsubmission.partnerType <> 3");
        } else { 
//            var.put("sortOrder",sortOrder);
	query.append("select  tblseekclarification.clarificationId, tblcompany.companyId, tblcompany.companyName, tblseekclarification.responseEndDate,tblfinalsubmission.tblUserDetail.userDetailId ");
	query.append("from TblBidderApprovalDetail tblbidderapprovaldetail ");
	query.append("inner join tblbidderapprovaldetail.tblCompany tblcompany ");
	    query.append("inner join tblbidderapprovaldetail.tblTenderEnvelope tbltenderenvelope with tbltenderenvelope.sortOrder=").append(sortOrder-1).append(" ");
	query.append("inner join tblbidderapprovaldetail.tblFinalSubmission tblfinalsubmission ");
	query.append("left join tblcompany.tblSeekClarification tblseekclarification with tblseekclarification.tblTenderEnvelope.envelopeId=:envelopeId and tblseekclarification.isActive = 1 ");
	query.append("where tblbidderapprovaldetail.tblTender.tenderId=:tenderId and tblbidderapprovaldetail.isApproved = 1 and tblfinalsubmission.partnerType <> 3");
        }
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        

    }
    
     /**
     * get userId by clarification Id for sending mail
     * @param clarificationId
     * @return
     * @throws Exception 
     */
    public Object getUserIdClarificationId(int clarificationId) throws Exception{
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clarificationId",clarificationId);
        list = hibernateQueryDao.getSingleColQuery("select tbluserdetail.tblUserLogin.userId from  TblSeekClarification tblseekclarification  inner join  tblseekclarification.tblUserDetail tbluserdetail where tblseekclarification.clarificationId=:clarificationId",var);                
        return list != null && !list.isEmpty() ? list.get(0) : "0";

    }
    /**
     * Add Brodcast dtls
     * @param tblClarificationBroadCast
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public  boolean addTblClarificationBroadCast(TblClarificationBroadCast tblClarificationBroadCast) throws Exception{
    boolean bSuccess = false;             
    tblClarificationBroadCastDao.addTblClarificationBroadCast(tblClarificationBroadCast);
        bSuccess=true;        
        return bSuccess;
    }
    /**
     * Add Brodcast-Mapping dtls
     * @param tblBroadCastQuestionMappinglst
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public  boolean addTblBroadCastQuestionMapping(List<TblBroadCastQuestionMapping> tblBroadCastQuestionMappinglst) throws Exception{
    boolean bSuccess = false;             
    tblBroadCastQuestionMappingDao.saveUpdateAllTblBroadCastQuestionMapping(tblBroadCastQuestionMappinglst);
        bSuccess=true;        
        return bSuccess;
    }
    /**
     * get list for check is enrty or not
     * @return
     * @throws Exception 
     */
	public  List<TblSeekClarification> getSeekClarificationDtls(int tenderId,int envelopeId,int companyId) throws Exception{
        List<TblSeekClarification> list = null;        
        list = tblSeekClarificationDao.findTblSeekClarification("tblTender.tenderId",Operation_enum.EQ,tenderId,"tblTenderEnvelope.envelopeId",Operation_enum.EQ,envelopeId,"tblCompany.companyId",Operation_enum.EQ,companyId);                
        return list;            
	}
	/**
     * get list of broadcast for publish
     * @return
     * @throws Exception 
     */
	public  List<TblClarificationBroadCast> getBoradcastClarificationDtls(int tenderId,int envelopeId) throws Exception{
        List<TblClarificationBroadCast> list = null;        
        list = tblClarificationBroadCastDao.findTblClarificationBroadCast("tblTender.tenderId",Operation_enum.EQ,tenderId,"tblTenderEnvelope.envelopeId",Operation_enum.EQ,envelopeId,"cstatus",Operation_enum.EQ,0,"clariBroadCastId",Operation_enum.ORDERBY, Operation_enum.DESC);                
        return list;            
	}
	/**
     * update broadcastclarification and tblquestion cstatus for publish
     * @param clariBroadCastId
     * @return
     * @throws Exception 
     */
	public boolean updateBoradcastClarification(Integer[] clariBroadCastId) throws Exception{
        int cnt = 0;
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clariBroadCastId",clariBroadCastId);
   //     System.out.println(clariBroadCastId.toString());
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblClarificationBroadCast set cstatus=1 where clariBroadCastId IN(:clariBroadCastId)",var);
        if(cnt!=0){
        	StringBuilder query = new StringBuilder();
        	query.append("select tblQuestion.questionId,tblQuestion.cstatus from TblBroadCastQuestionMapping tblBroadCastQuestionMapping  ");
        	query.append("inner join tblBroadCastQuestionMapping.tblQuestion tblQuestion ");
        	query.append("where tblBroadCastQuestionMapping.tblClarificationBroadCast.clariBroadCastId in(:clariBroadCastId)");
        	list = hibernateQueryDao.createNewQuery(query.toString(),var);
        	var = null;
        }
        if(list!=null && !list.isEmpty()){
        	int counter = 0;
        	Integer[] questionIds = new Integer[list.size()];
        	for(Object[] obj : list){
        		questionIds[counter] = Integer.parseInt(obj[0].toString());
        		counter++;
        	}
        	var = new HashMap<String, Object>();
        	var.put("questionIds",questionIds);
        	cnt = hibernateQueryDao.updateDeleteNewQuery("update TblQuestion set cstatus=1 where questionId IN(:questionIds)",var);
        }
        return cnt!=0;
    }
	/**
     * view of clarification broadcast
     * @param clariBroadCastId
     * @return
     * @throws Exception 
     */
	public List<Object[]> getBroadcastBidders(int clariBroadCastId) throws Exception{
        StringBuilder query = new StringBuilder();
        query.append(" SELECT tblCompany.companyName as c0,tblSeekClarification.responseEndDate as c1,tblQuestion.isManDocReq as c2");
        query.append(" from apptenderresult.tbl_ClarificationBroadCast tblClarificationBroadCast");
        query.append(" inner join apptenderresult.Tbl_BroadCastQuestionMapping tblBroadCastQuestionMapping on tblClarificationBroadCast.clariBroadCastId = tblBroadCastQuestionMapping.clariBroadCastId");
        query.append(" inner join appcommon.Tbl_Question tblQuestion on tblQuestion.questionId = tblBroadCastQuestionMapping.questionId");
        query.append(" inner join apptenderresult.tbl_SeekClarification tblSeekClarification on tblSeekClarification.clarificationId = tblQuestion.parentId");
        query.append(" inner join appuser.tbl_Company tblCompany on tblCompany.companyId = tblSeekClarification.companyId");
        query.append(" where tblClarificationBroadCast.clariBroadCastId = ").append(clariBroadCastId);
        int nVarCharColumnIndex [] = {0,1};
        List<Object[]> list = hibernateQueryDao.createSQLQuery(query.toString(),null,nVarCharColumnIndex,3);
        return list!=null && !list.isEmpty() ? list : null;
    }

	public List<Object[]> getLstCompanyName(int clientId, String companyIds) throws Exception {
	       StringBuilder query = new StringBuilder();
	       Map<String, Object> var = new HashMap<String, Object>();
	       var.put("clientId", clientId);

	       query.append("select tblcompany.companyName,tbluserlogin.loginId from TblUserLogin tbluserlogin ")
	               .append(" inner join tbluserlogin.tblBidderStatus tblbidderstatus with ")
	               .append(" tblbidderstatus.tblClient.clientId=:clientId and tblbidderstatus.cstatus=1")
	               .append(" inner join tblbidderstatus.tblCompany tblcompany ")
	               .append(" where tblcompany.companyId in (").append(companyIds).append(")");

	       return hibernateQueryDao.createNewQuery(query.toString(), var);
	   }

	public List<Object[]> getResponseEndDateandCompayDetails(int clariBroadCastId)throws Exception 
	{
		  StringBuilder query = new StringBuilder();
	       Map<String, Object> var = new HashMap<String, Object>();
	       List<Object[]> list = null;
	       var.put("clariBroadCastId", clariBroadCastId);
	       query.append("select tblSeekClarification.clarificationId,tblCompany.companyId,tblCompany.companyName,tblSeekClarification.responseEndDate,tblQuestion.questionText,tblQuestion.questionId from TblBroadCastQuestionMapping  tblBroadCastQuestionMapping "); 
	       query.append("INNER JOIN tblBroadCastQuestionMapping.tblQuestion tblQuestion "); 
	       query.append("INNER JOIN tblBroadCastQuestionMapping.tblClarificationBroadCast tblClarificationBroadCast "); 
	       query.append("with tblClarificationBroadCast.clariBroadCastId =:clariBroadCastId,TblSeekClarification tblSeekClarification ");
	       query.append("INNER JOIN tblSeekClarification.tblCompany tblCompany where tblSeekClarification.clarificationId=tblQuestion.parentId");
	       list = hibernateQueryDao.createNewQuery(query.toString(),var); 
	       return list!=null && !list.isEmpty() ? list : null;
	}
	
	  /**
     * to get bidder Clarification docs to view
     * @param objectId
     * @param clientId
     * @param companyId
     * @param linkId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getBidderClarificationDocsLink(int objectId,int clientId,String linkId,int cStatus,int companyId, int questionId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("objectId",objectId);
        var.put("clientId",clientId);
        var.put("linkId",linkId);        
        StringBuilder query = new StringBuilder(" select tblbidderdocmapping.bidderDocMappingId, tblbidderdocument.docName, tblbidderdocument.description,tblbidderdocument.fileSize, tblbidderdocmapping.mappedOn,tblbidderdocmapping.cstatus ");
        query.append(" ,"+ questionId+ " as questionId");
        query.append(" from  TblBidderDocMapping tblbidderdocmapping  ");
        query.append(" inner join  tblbidderdocmapping.tblBidderDocument tblbidderdocument ");
        query.append(" where tblbidderdocmapping.objectId=:objectId and tblbidderdocument.tblClient.clientId=:clientId and tblbidderdocmapping.tblLink.linkId in (:linkId)  ");
        if(companyId !=0){
        	var.put("companyId",companyId);
        	query.append(" and tblbidderdocmapping.tblCompany.companyId=:companyId ");
        }
        if(cStatus >= 0){
        	var.put("cStatus",cStatus);
        	query.append(" and tblbidderdocmapping.cstatus=:cStatus ");
        }else{
        	if(cStatus == -1){
        		query.append(" and tblbidderdocmapping.cstatus!=2");
        	}else if(cStatus == -2){
        		query.append(" and tblbidderdocmapping.cstatus!=2 and tblbidderdocmapping.cstatus!=0");
        	}
        }
        query.append(" order by tblbidderdocmapping.mappedOn desc, tblbidderdocument.bidderDocId desc ");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        

    }
	
    /**
     * To get Response End date and company name for display
     * @param tenderId
     * @param companyId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getDocDetails(int tenderId,int companyId) throws Exception{
		List<Object[]> list = null;
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("tenderId", tenderId);
		/*var.put("clarificationId", clarificationId);*/
		var.put("companyId", companyId);
		String query = "select am.answerId,qm.questionId,am.cstatus " 
				+ "FROM appcommon.tbl_question qm "
				+ "INNER JOIN apptenderresult.tbl_seekclarification sc ON sc.clarificationId = qm.parentId   "
				+ "INNER JOIN appcommon.tbl_answer am ON am.questionId = qm.questionId "
				+ "where qm.objectId=:tenderId and sc.companyId=:companyId ";
				/*+ "and qm.parentId=:clarificationId ";*/
		list = hibernateQueryDao.createSQLQuery(query, var);
		return list != null && !list.isEmpty() ? list : null;
    }
}
