package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderSORDao;
import com.etl.eproc.etender.model.TblTenderSOR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderSORImpl extends AbcAbstractClass<TblTenderSOR> implements TblTenderSORDao {


    @Override
    public void addTblTenderSOR(TblTenderSOR tblTenderSOR) {
        super.addEntity(tblTenderSOR);
    }

    @Override
    public void deleteTblTenderSOR(TblTenderSOR tblTenderSOR) {
        super.deleteEntity(tblTenderSOR);
    }

    @Override
    public void updateTblTenderSOR(TblTenderSOR tblTenderSOR) {
        super.updateEntity(tblTenderSOR);
    }

    @Override
    public List<TblTenderSOR> getAllTblTenderSOR() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderSOR> findTblTenderSOR(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderSORCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderSOR> findByCountTblTenderSOR(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderSOR(List<TblTenderSOR> tblTenderSORs) {
        super.updateAll(tblTenderSORs);
    }
}
