/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;

/**
 *
 * @author taher.tinwala
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.etender.model.TblRebateDetail;
import java.util.List;

public interface TblRebateDetailDao  {

    public void addTblRebateDetail(TblRebateDetail tblRebateDetail);

    public void deleteTblRebateDetail(TblRebateDetail tblRebateDetail);

    public void updateTblRebateDetail(TblRebateDetail tblRebateDetail);

    public List<TblRebateDetail> getAllTblRebateDetail();

    public List<TblRebateDetail> findTblRebateDetail(Object... values) throws Exception;

    public List<TblRebateDetail> findByCountTblRebateDetail(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblRebateDetailCount();

    public void saveUpdateAllTblRebateDetail(List<TblRebateDetail> tblRebateDetails);
}
