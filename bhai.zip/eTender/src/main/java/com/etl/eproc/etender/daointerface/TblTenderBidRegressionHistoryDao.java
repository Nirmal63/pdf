package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblTenderBidRegressionHistory;
import java.util.List;

public interface TblTenderBidRegressionHistoryDao  {

    public void addTblTenderBidRegressionHistory(TblTenderBidRegressionHistory tblTenderBidRegressionHistory);

    public void deleteTblTenderBidRegressionHistory(TblTenderBidRegressionHistory tblTenderBidRegressionHistory);

    public void updateTblTenderBidRegressionHistory(TblTenderBidRegressionHistory tblTenderBidRegressionHistory);

    public List<TblTenderBidRegressionHistory> getAllTblTenderBidRegressionHistory();

    public List<TblTenderBidRegressionHistory> findTblTenderBidRegressionHistory(Object... values) throws Exception;

    public List<TblTenderBidRegressionHistory> findByCountTblTenderBidRegressionHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderBidRegressionHistoryCount();

    public void saveUpdateAllTblTenderBidRegressionHistory(List<TblTenderBidRegressionHistory> tblTenderBidRegressionHistorys);
}