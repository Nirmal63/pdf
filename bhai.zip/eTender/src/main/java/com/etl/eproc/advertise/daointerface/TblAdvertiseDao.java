/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.advertise.daointerface;

/**
 *
 * @author hiral
 */

import com.etl.eproc.advertise.model.TblAdvertise;
import java.util.List;

public interface TblAdvertiseDao  {

    public void addTblAdvertise(TblAdvertise tblAdvertise);

    public void deleteTblAdvertise(TblAdvertise tblAdvertise);

    public void updateTblAdvertise(TblAdvertise tblAdvertise);

    public List<TblAdvertise> getAllTblAdvertise();

    public List<TblAdvertise> findTblAdvertise(Object... values) throws Exception;

    public List<TblAdvertise> findByCountTblAdvertise(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAdvertiseCount();

    public void saveUpdateAllTblAdvertise(List<TblAdvertise> tblAdvertises);

	public void saveOrUpdateTblAdvertise(TblAdvertise tblAdvertise);
}