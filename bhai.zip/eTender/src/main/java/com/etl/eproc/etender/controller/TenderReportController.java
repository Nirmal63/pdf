/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TimeZone;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.MultiMap;
import org.apache.commons.collections.map.MultiValueMap;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.TblCellMasterDao;
import com.etl.eproc.common.daointerface.TblCouponHistoryDao;
import com.etl.eproc.common.daointerface.TblUserLoginDao;
import com.etl.eproc.common.model.TblCellMaster;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblCouponHistory;
import com.etl.eproc.common.model.TblNegotiationResult;
import com.etl.eproc.common.model.TblNegotiationSummary;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.NegotiationService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.NumberToWorldConversion;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.daointerface.TblTenderCellDao;
import com.etl.eproc.etender.databean.ItemWiseBreakupDataBean;
import com.etl.eproc.etender.model.TblCPPPXmlEntry;
import com.etl.eproc.etender.model.TblDynReport;
import com.etl.eproc.etender.model.TblDynReportColumn;
import com.etl.eproc.etender.model.TblDynReportFormMap;
import com.etl.eproc.etender.model.TblNegotiationSORRemarks;
import com.etl.eproc.etender.model.TblOverRuledReport;
import com.etl.eproc.etender.model.TblOverRuledReportDetail;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderReevaluation;
import com.etl.eproc.etender.model.TblTenderSaving;
import com.etl.eproc.etender.model.TblTenderTable;
import com.etl.eproc.etender.services.AdvertiseService;
import com.etl.eproc.etender.services.AuditTrailService;
import com.etl.eproc.etender.services.DynamicReportService;
import com.etl.eproc.etender.services.EventCreationService;
import com.etl.eproc.etender.services.TenderCommonService;
import com.etl.eproc.etender.services.TenderFormService;
import com.etl.eproc.etender.services.TenderOpenService;
import com.etl.eproc.etender.services.TenderReportService;
import com.etl.eproc.etender.services.TenderService;
import com.etl.eproc.vendor.services.VendorEnlistmentService;

/**
 *
 * @author dipal
 */
@Controller
@RequestMapping("/etender")
public class TenderReportController {
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private TenderReportService tenderReportService;
    @Autowired
    private MessageSource messageSource;
    @Autowired
    private ClientService clientService;
    @Autowired
    private NumberToWorldConversion numberToWorldConversion;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private CommonService commonService;
    @Autowired    
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private EventCreationService eventCreationService;  
    @Autowired
    private TenderOpenService tenderOpenService;
    @Autowired
    private TenderService tenderService;
    @Autowired
    private DynamicReportService dynamicReportService;
    @Autowired
    private NegotiationService negotiationService;
	@Autowired
	private ManageBidderService manageBidderService;
	@Autowired
	private ModelToSelectItem modelToSelectItem;
	@Autowired
	private VendorEnlistmentService vendorEnlistmentService; 
	@Autowired
	private AdvertiseService advertiseService;
	@Autowired
	private TblCouponHistoryDao tblCouponHistoryDao;
	@Autowired
	private TblTenderCellDao tblTenderCellDao;
	@Autowired
	private TblUserLoginDao tblUserLoginDao;
	
    @Value("#{tenderlinkProperties['bid_opening_l1h1_report']?:328}")
    private int linkOpeningL1H1Report;
    @Value("#{tenderlinkProperties['bid_evaluation_l1h1_report']?:390}")
    private int linkEvaluationL1H1Report;
    @Value("#{tenderlinkProperties['bidder_l1h1_report']?:396}")
    private int linkBidderL1H1Report;
    @Value("#{tenderlinkProperties['bid_opening_itemwise_evaluation_report']?:353}")
    private int linkOpeningItemEvalReport;
    @Value("#{tenderlinkProperties['bid_evaluation_itemwise_evaluation_report']?:397}")
    private int linkEvaluationItemEvalReport;
    @Value("#{tenderlinkProperties['bid_evaluation_itemwise_evaluation_report']?:397}")
    private int linkEvaluationItemBreakupReport;
    @Value("#{tenderlinkProperties['bid_evaluation_process_in_workflow']?:246}")
    private int bidEvalWFLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_process_in_workflow']?:196}")
    private int nitApprovalWFLinkId;
    @Value("#{tenderlinkProperties['corrigendum_process_in_workflow']?:179}")
    private int corriWFLinkId;
    @Value("#{tenderlinkProperties['pre_bid_committee_process_in_workflow']?:238}")
    private int preBidCommitteeWFLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_process_in_workflow']?:241}")
    private int preBidMeetingWFLinkId;
    @Value("#{tenderlinkProperties['bid_opening_process_in_workflow']?:244}")
    private int bidOpeningWFLinkId;
    @Value("#{tenderlinkProperties['bid_opening_process_process_in_workflow']?:1181}")
    private int bid_opening_process_process_in_workflow;
    @Value("#{tenderlinkProperties['notice_and_document_cancel_process_in_workflow']?:251}")
    private int cancelNoticeWFLinkId;
    @Value("#{tenderlinkProperties['report_tender_audit_trail']?:233}")
    private int tenderAuditTrialLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_customized_report']?:391}")
    private int linkEvalCustomizeReport;
    @Value("#{tenderlinkProperties['bid_opening_customized_report']?:385}")
    private int linkOpeningCustomizeReport;
    @Value("#{tenderlinkProperties['bid_opening_sor_report']?:386}")
    private int linkOpeningSORReport;
    @Value("#{tenderlinkProperties['bid_evaluation_sor_report']?:392}")
    private int linkEvaluationSORReport;
    @Value("#{tenderlinkProperties['bid_evaluation_sor_report']?:392}")
    private int linkMISReport;
    @Value("#{tenderlinkProperties['report_tender_mis_report']?:201}")
    private int linkTenderMISReport;
    @Value("#{linkProperties['tender_history_report']?:67}")
    private int tenderHistoryReportId;
    @Value("#{tenderlinkProperties['report_rfx_management_history']?:589}")
    private int rfxManagementHistoryLinkId;
    @Value("#{tenderlinkProperties['report_event_access_detail']?:678}")
    private int reportEventAccessDetail;
    @Value("#{tenderlinkProperties['link_weightage_l1_report']?:1129}")
    private int linkWeightageL1Report;
    @Value("#{etenderAuditTrailProperties['getL1H1Report']}")
    private String getL1H1Report;
    @Value("#{etenderAuditTrailProperties['getItemWiseEvalReport']}")
    private String getItemWiseEvalReport;
    @Value("#{etenderAuditTrailProperties['getItemWiseBreakupReport']}")
    private String getItemWiseBreakupReport;
    @Value("#{etenderAuditTrailProperties['gettenderaudittrialreport']}")
    private String getTenderAuditTrialReport;
    @Value("#{etenderAuditTrailProperties['getTenderCustomizeReort']}")
    private String getTenderCustomizeReort;
    @Value("#{etenderAuditTrailProperties['postTenderCustomizeReport']}")
    private String postTenderCustomizeReport;
    @Value("#{etenderAuditTrailProperties['getTenderSORReort']}")
    private String getTenderSORReort;
    @Value("#{etenderAuditTrailProperties['postTenderSORReport']}")
    private String postTenderSORReport;
    @Value("#{etenderAuditTrailProperties['getTenderMISReport']}")
    private String getTenderMISReport;
    @Value("#{etenderAuditTrailProperties['postTenderMISReport']}")
    private String postTenderMISReport;
    @Value("#{etenderAuditTrailProperties['getTenderHistory']}")
    private String getTenderHistory;
    @Value("#{etenderAuditTrailProperties['getEventAccessReport']}")
    private String getEventAccessReport;
    @Value("#{projectProperties['record_per_pages']?:10}")
    private int recordPerPage;
    @Value("#{etenderAuditTrailProperties['getManuaL1Report']}")
    private String getManuaL1Report;
    @Value("#{etenderAuditTrailProperties['generateManuaL1Report']}")
    private String generateManuaL1Report;
    @Value("#{etenderAuditTrailProperties['publishManuaL1Report']}")
    private String publishManuaL1Report;
    @Value("#{etenderAuditTrailProperties['getOverRuledReport']}")
    private String getOverRuledReport;
    @Value("#{etenderAuditTrailProperties['viewManagementReport']}")
    private String viewManagementReport;
    @Value("#{etenderAuditTrailProperties['viewCustomizeManagementReport']}")
    private String viewCustomizeManagementReport;
    @Value("#{etenderAuditTrailProperties['viewManagementReportVertical']}")
    private String viewManagementReportVertical;
    @Value("#{etenderAuditTrailProperties['viewCustomizeManagementReportVertical']}")
    private String viewCustomizeManagementReportVertical;
    @Value("#{etenderAuditTrailProperties['OpenItemwiseL1ReportAfterLoading']}")
    private String OpenItemwiseL1ReportAfterLoading;
    @Value("#{etenderAuditTrailProperties['viewItemwiseL1ReportAfterLoading']}")
    private String viewItemwiseL1ReportAfterLoading;
    @Value("#{etenderAuditTrailProperties['viewNegotiationSummaryReport']}")
    private String viewNegotiationSummaryReport;
    @Value("#{etenderAuditTrailProperties['viewL1ReportAfterNegotiation']}")
    private String viewL1ReportAfterNegotiation;
    @Value("#{etenderAuditTrailProperties['ViewWeightageL1ReportPage']}")
    private String addTenderSORRemarks;
    @Value("#{etenderAuditTrailProperties['addTenderSORRemarks']}")
    private String viewWeightageL1ReportPage;
    @Value("#{tenderlinkProperties['notice_and_document_brd_re_generate']?:517}")
	private int regenerateTenderBrd;
    @Value("#{projectProperties['rci_client_ids']}")
    private String rciClientIds;
    @Value("#{etenderAuditTrailProperties['getAdvertiseDetailReport']}")
    private String getAdvertiseDetailReport;
    @Value("#{tenderlinkProperties['Advertise_Detail_Report']?:2286}")
    private int linkAdvertiseDetailReport;
    @Value("#{tenderlinkProperties['bid_opening_report_process_in_workflow']?:3302}")
    private int bidOpeningReportProcessWFLinkId;
    @Value("#{linkProperties['bid_evaluation_report_process_in_workflow']?:3310}")
    private int bidEvaluationReportProcessWFLinkId;
    @Value("#{tenderlinkProperties['negotiation_create_committee_process_in_workflow']?:1184}")
    private int negotiationCreateCommitteeProcessInWFLinkId;
    @Value("#{tenderlinkProperties['negotiation_close_process_in_workflow']?:1191}")
    private int negotiation_close_process_in_workflow;
    @Value("#{tenderlinkProperties['offline_negotiation_process_in_workflow']?:1148}")
    private int offline_negotiation_process_in_workflow;
    @Value("#{linkProperties['po_process_in_workflow']?:886}")
    private int POProcessWFLinkId;
    @Value("#{linkProperties['po_amendment_process_in_workflow']?:888}")
    private int POAmendmentProcessWFLinkId;
    @Value("#{linkProperties['po_cancel_process_in_workflow']?:1227}")
    private int poCancelPIWLinkId;
    @Value("#{linkProperties['po_offline_process_in_workflow']?:887}")
    private int POOfflineProcessWFLinkId;
    @Value("#{linkProperties['po_offline_amendment_process_in_workflow']?:889}")
    private int POOfflineAmendmentProcessWFLinkId;
    @Value("#{linkProperties['po_offline_cancel_process_in_workflow']?:2279}")
    private int poOfflineCancelPIWLinkId;
    @Value("#{linkProperties['apo_process_in_workflow']?:882}")
    private int APOProcessWFLinkId;
    @Value("#{linkProperties['apo_amendment_process_in_workflow']?:884}")
    private int APOAmendmentProcessWFLinkId;
    @Value("#{linkProperties['apo_cancel_process_in_workflow']?:1226}")
    private int apoCancelPIWLinkId;    
    @Value("#{linkProperties['apo_offline_process_in_workflow']?:883}")
    private int APOOfflineProcessWFLinkId;
    @Value("#{linkProperties['apo_offline_amendment_process_in_workflow']?:885}")
    private int APOOfflineAmendmentProcessWFLinkId;
    @Value("#{linkProperties['apo_offline_cancel_process_in_workflow']?:2262}")
    private int apoOfflineCancelPIWLinkId;
    @Value("#{linkProperties['configuredate_process_in_workflow']?:2300}")
    private int ConfiguredateProcessWFLinkId;
    @Value("#{tenderlinkProperties['report_negotiated_l1']?:2300}")
    private int negotiatedL1Report;
    @Value("#{etenderProperties['bidder_multiplier']?:12500000}")
    private Double bidderMultiplier;
    @Value("#{linkProperties['downlaod_cppp_xml']?:3330}")
    private int linkDownloadCPPPXML;
    @Value("#{projectProperties['file.drive']}")
    private String drive;
    @Value("#{projectProperties['file.upload']}")
    private String upload;
    @Value("#{projectProperties['file.cpppxml']}")
    private String cpppxml;
    @Value("#{linkProperties['tender_data_report']?:4473}")
    private int tenderDataReportId;
    @Value("#{tenderlinkProperties['negotiation_negotiation_process_invite_for_negotiation']?:602}")
    private int inviteNegotiationTenderLinkId;

    @Value("#{etenderAuditTrailProperties['getEventBidSubmissionReport']}")
    private String getEventBidSubmissionReport;
    
    private static final String LINK_ID= "linkId";
    private static final String OBJECT_ID= "objectId";
    private static final String COMMITTEE_ID= "committeeId";
    private static final String COMMITTEE_TYPE= "committeeType";
    private static final String ENVELOPE_ID= "envelopeId";
    private static final String TENDERREPORT_ID= "tenderReportId";
    private static final String CORRIGENDUM_ID= "corrigendumId";
    private static final String REPORT_TYPE= "reportType";
    private static final String RESULTSET_1= "#result-set-1";
    private static final String RESULTSET_2= "#result-set-2";
    private static final String RESULTSET_3= "#result-set-3";
    private static final String RESULTSET_4= "#result-set-4";
    private static final String RESULTSET_5= "#result-set-5";
    private static final String RESULTSET_6= "#result-set-6";
    private static final String RESULTSET_7= "#result-set-7";
    private static final String RESULTSET_8= "#result-set-8";
    private static final String RESULTSET_9= "#result-set-9";
    private static final String RESULTSET_10= "#result-set-10";
    private static final String RESULTSET_11= "#result-set-11";
    private static final String RESULTSET_12= "#result-set-12";
    private static final String RESULTSET_13= "#result-set-13";
    private static final String RESULTSET_14= "#result-set-14";
    private static final String COMPANY_NAME= "companyName";
    private static final String ENVELOPE_NAME= "envelopeName";
    private static final String LABEL_LEAD= "label_lead";
    private static final String LABEL_CONSORT_WITH= "label_consort_with";
    private static final String LABEL_SECONDARY= "label_secondary";
    private static final Integer eventTypeId = 4;
    
    /**
    * Method use for get request of MIS Report
    * @author : heeral.soni since 10/23/2013
    */
    @RequestMapping(value = "/buyer/viewtendermisreport/{enc}", method = RequestMethod.GET)
    public String viewTenderMISReport(ModelMap map,HttpServletRequest request) {
        try{
            map.addAttribute("selContractType", getContractType());
            map.addAttribute("selBiddeingAccess", getBiddingAccessCombo());
            map.addAttribute("selBiddeingType", getBiddingTypeCombo());
            map.addAttribute("selStatus", getStatusCombo());
            map.addAttribute("selNumOperation", getSearch4Numeric());
            map.addAttribute("operation", 0);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkTenderMISReport, getTenderMISReport, 0, 0); 
        }
        return "/etender/buyer/MISReport";
    }
    
     public List<SelectItem> getContractType() {
        List<SelectItem> items = new ArrayList<SelectItem>();
        items.add(new SelectItem("Goods", 1));
        items.add(new SelectItem("Service", 2));
        items.add(new SelectItem("Works", 3));
        items.add(new SelectItem("Trunkey Projects", 4));
        items.add(new SelectItem("Others", 5));
        return items;
    }
     
     public List<SelectItem> getBiddingAccessCombo() {
        List<SelectItem> items = new ArrayList<SelectItem>();
        items.add(new SelectItem("Open", 1));
        items.add(new SelectItem("Limited", 2));
        items.add(new SelectItem("Proprietary", 3));
        items.add(new SelectItem("Nomination", 4));
        return items;
    }
     
     public List<SelectItem> getBiddingTypeCombo() {
        List<SelectItem> items = new ArrayList<SelectItem>();
        items.add(new SelectItem("NCB/Domestic", 1));
        items.add(new SelectItem("ICB/Global", 2));
        return items;
    }
     
     public List<SelectItem> getStatusCombo() {
        List<SelectItem> items = new ArrayList<SelectItem>();
        items.add(new SelectItem("All", 0));
        items.add(new SelectItem("Live", 1));
        items.add(new SelectItem("Pending", 2));
        items.add(new SelectItem("Archive", 3));
        items.add(new SelectItem("Cancelled Tenders", 4));
        return items;
    }
     
    public List<SelectItem> getSearch4Numeric() {
     List<SelectItem> items = new ArrayList<SelectItem>();
     items.add(new SelectItem("equal", 1));
     items.add(new SelectItem("not equal", 2));
     items.add(new SelectItem("less", 3));
     items.add(new SelectItem("less or equal", 4));
     items.add(new SelectItem("greater", 5));
     items.add(new SelectItem("greater or equal", 6));
     items.add(new SelectItem("between", 7));
     return items;
 }
    
    /**
     * @author manoj.gadhavi
     * @param map
     * @param request
     * @return
     */
    		
    
    @RequestMapping(value = "/buyer/viewvendorpqreport/{enc}", method = RequestMethod.GET)
    public String viewVendorPQReport(ModelMap map,HttpServletRequest request) {
        try{
            map.addAttribute("selStatus", getPQStatusCombo());
            
            List<Object[]> listAdmin = vendorEnlistmentService.getAdminAndVendorEnlistCommitteeUserByClientId(abcUtility.getSessionClientId(request));
            List<SelectItem> selAdmin = abcUtility.convert(listAdmin);
            
            map.addAttribute("selRegisteredIn", modelToSelectItem.convertListIntoSelectItemList(manageBidderService.getRegisteredIn(),"registeredInId","registeredIn"));
            map.addAttribute("selIndustryType", modelToSelectItem.convertListIntoSelectItemList(manageBidderService.getIndustryType(), "indTypeId", "indType"));
            map.addAttribute("selIndClassification", modelToSelectItem.convertListIntoSelectItemList(manageBidderService.getIndustryClassification(), "indClassificationId", "indClassification"));
            map.addAttribute("selAdmin", selAdmin);
            map.addAttribute("selNumOperation", getSearch4Numeric());
            map.addAttribute("operation", 0);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkTenderMISReport, getTenderMISReport, 0, 0); 
        }
        return "/enlistment/admin/VendorPQReport";
    }
    
    public List<SelectItem> getPQStatusCombo() {
        List<SelectItem> items = new ArrayList<SelectItem>();
        items.add(new SelectItem("Pending", 0));
        items.add(new SelectItem("Approved", 1));
        items.add(new SelectItem("Rejected", 2));
        items.add(new SelectItem("Expired", 5));
        return items;
    }

     /**
    * Method use for get request of MIS Report
    * @author heeral.soni
    * @param operation : 1: view report, 2: save as html , 3: save as word, 4:save as excel, 5:save as pdf
    * @param modelMap
    * @param request
    * @param session
    * @return
    */
    @RequestMapping(value = {"/buyer/searchmisreport"}, method = RequestMethod.POST)
    public String searchMISReport(ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        List<Short> showHideChk = new ArrayList<Short>();
        SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
        String page="";
        int colspan = 1;
        try
        {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null)
            {
                //set search criteria fields
                int pageNo = StringUtils.hasLength(request.getParameter("txtPageNo")) ? Integer.parseInt(request.getParameter("txtPageNo")) : 0;
                int deptId = StringUtils.hasLength(request.getParameter("txtDept")) ? Integer.parseInt(request.getParameter("txtDept")) : 0;
                int eventId = StringUtils.hasLength(request.getParameter("txtEventId")) ? Integer.parseInt(request.getParameter("txtEventId")) : 0;
                String refNo = StringUtils.hasLength(request.getParameter("txtRefNo")) ? request.getParameter("txtRefNo") : null;
                Date publishDateFrom = StringUtils.hasLength(request.getParameter("txtPublishDateFrom")) ? CommonUtility.getDateObj(request.getParameter("txtPublishDateFrom")) : null;
                Date publishDateTo = StringUtils.hasLength(request.getParameter("txtPublishDateTo")) ? CommonUtility.getDateObj(request.getParameter("txtPublishDateTo")) : null;
                double estValFrom = StringUtils.hasLength(request.getParameter("txtEstValFrom")) ? Double.parseDouble(request.getParameter("txtEstValFrom")) : 0;
                double estValTo = StringUtils.hasLength(request.getParameter("txtEstValTo")) ? Double.parseDouble(request.getParameter("txtEstValTo")) : 0;
                int estOpFrom = StringUtils.hasLength(request.getParameter("selNumOperationFrom")) ? Integer.parseInt(request.getParameter("selNumOperationFrom")) : 0;
                int pubDateOpFrom = StringUtils.hasLength(request.getParameter("selNumOpPublishDateFrom")) ? Integer.parseInt(request.getParameter("selNumOpPublishDateFrom")) : 0;
                int subDateOpFrom = StringUtils.hasLength(request.getParameter("selNumOpSubDateFrom")) ? Integer.parseInt(request.getParameter("selNumOpSubDateFrom")) : 0;
                Date bidDateFrom = StringUtils.hasLength(request.getParameter("txtBidDateFrom")) ? CommonUtility.getDateObj(request.getParameter("txtBidDateFrom")) : null;
                Date bidDateTo = StringUtils.hasLength(request.getParameter("txtBidDateTo")) ? CommonUtility.getDateObj(request.getParameter("txtBidDateTo")) : null;
                int contractType = StringUtils.hasLength(request.getParameter("selCotType")) ? Integer.parseInt(request.getParameter("selCotType")) : 0;
                int bidAccessType = StringUtils.hasLength(request.getParameter("selBidAccess")) ? Integer.parseInt(request.getParameter("selBidAccess")) : 0;
                int bidType = StringUtils.hasLength(request.getParameter("selBidType")) ? Integer.parseInt(request.getParameter("selBidType")) : 0;
                int status = StringUtils.hasLength(request.getParameter("selStatus")) ? Integer.parseInt(request.getParameter("selStatus")) : 0;
                int operation = StringUtils.hasLength(request.getParameter("txtOperation")) ? Integer.parseInt(request.getParameter("txtOperation")) : 0;
                int officerId = abcUtility.getSessionUserId(request);
                
                //set dynamic columns for headings
                showHideChk.add(Short.valueOf("1"));
                 if (request.getParameter("chkDept") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkEventId") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkRefNo") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkEstVal") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkEMD") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkDocFees") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkBidAccess") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkPreAllow") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkContractType") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkBidType") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkBidDate") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkPubDate") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkBidOpenDate") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkBidderMap") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkBidFinal") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkEnvOpen") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkPQEnv") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkEMDEnvOpen") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkEMDEnv") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkTechEnvOpen") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkTechEnv") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkPriceEnvOpen") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkPriceEnv") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkTCEnvOpen") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkTCEnv") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }  
                 if (request.getParameter("chkNameOfTenderOwner") != null) {
                     showHideChk.add(Short.valueOf("1"));
                     colspan++;
                  } else {
                     showHideChk.add(Short.valueOf("0"));
                  }
                  if (request.getParameter("chkEmailIdOfTenderOwner") != null) {
                     showHideChk.add(Short.valueOf("1"));
                     colspan++;
                  } else {
                     showHideChk.add(Short.valueOf("0"));
                  }
                if(refNo !=null && refNo != ""){
                	refNo = AbcUtility.replaceSpecialChars(refNo);
                } 
                Map<String, Object> dataMap = tenderReportService.getMISReport(eventId,refNo,publishDateFrom,publishDateTo,estValFrom,estOpFrom,estValTo,bidDateFrom,bidDateTo,contractType,bidAccessType,bidType,status,deptId,sessionBean.getTimeZoneOffset(),abcUtility.getCookieDateFormatConversionValue(request),recordPerPage,pageNo,abcUtility.getSessionClientId(request),officerId,pubDateOpFrom,subDateOpFrom,showHideChk);
                //System.out.println("dataMap =>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + dataMap.toString());
                if(dataMap.get("#result-set-1") != null){
                    int totalPages = Integer.parseInt(dataMap.get("@V_TotalPages").toString());
                    if (totalPages == 0){
                        totalPages = 1;
                    }
                    modelMap.addAttribute("listData",(ArrayList<LinkedHashMap<String, Object>>) dataMap.get("#result-set-1") );
                    modelMap.addAttribute("totalRecords", dataMap.get("@V_TotalRecords"));
                    modelMap.addAttribute("totalPages", totalPages);
                }
                Map<String, Object> dataMapPdf = tenderReportService.getMISReport(eventId,refNo,publishDateFrom,publishDateTo,estValFrom,estOpFrom,estValTo,bidDateFrom,bidDateTo,contractType,bidAccessType,bidType,status,deptId,sessionBean.getTimeZoneOffset(),abcUtility.getCookieDateFormatConversionValue(request),recordPerPage,-1,abcUtility.getSessionClientId(request),officerId,pubDateOpFrom,subDateOpFrom,showHideChk);
                if(dataMapPdf.get("#result-set-1") != null){
                    modelMap.addAttribute("listDataPdf",(ArrayList<LinkedHashMap<String, Object>>) dataMapPdf.get("#result-set-1") );
                }
                modelMap.addAttribute("pageNo", pageNo);
                modelMap.addAttribute("colspan", colspan);
                modelMap.addAttribute("operation", operation);
                modelMap.addAttribute("showHideChk", showHideChk);
                modelMap.addAttribute("selContractType", getContractType());
                modelMap.addAttribute("selBiddeingAccess", getBiddingAccessCombo());
                modelMap.addAttribute("selBiddeingType", getBiddingTypeCombo());
                modelMap.addAttribute("selStatus", getStatusCombo());
                modelMap.addAttribute("selNumOperation", getSearch4Numeric());
                page = "/etender/buyer/MISReport";
            }else{
                page =  "redirect:/sessionexpired";
            }
            
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkTenderMISReport, postTenderMISReport, 0, 0); 
        }
        return page;
    } 
    
    /**
     * @author manoj.gadhavi
     * @param modelMap
     * @param request
     * @param session
     * @return
     */
    @RequestMapping(value = {"/buyer/searchvendorpqreport"}, method = RequestMethod.POST)
    public String searchVendorPQReport(ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        List<Short> showHideChk = new ArrayList<Short>();
        SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
        String page="";
        int colspan = 1;
        try
        {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null)
            {
                //set search criteria fields
                int pageNo = StringUtils.hasLength(request.getParameter("txtPageNo")) ? Integer.parseInt(request.getParameter("txtPageNo")) : 0;
                int deptId = StringUtils.hasLength(request.getParameter("txtDept")) ? Integer.parseInt(request.getParameter("txtDept")) : 0;
                String fileNo = StringUtils.hasLength(request.getParameter("txtFileNo")) ? request.getParameter("txtFileNo") : null;
                String CompanyName = StringUtils.hasLength(request.getParameter("txtCompanyName")) ? request.getParameter("txtCompanyName") : null;
                int registeredIn = StringUtils.hasLength(request.getParameter("selRegisteredIn")) ? Integer.parseInt(request.getParameter("selRegisteredIn")) : 0;
                int IndustryType = StringUtils.hasLength(request.getParameter("selIndustryType")) ? Integer.parseInt(request.getParameter("selIndustryType")) : 0;
                int IndustryClassification = StringUtils.hasLength(request.getParameter("selIndustryClassification")) ? Integer.parseInt(request.getParameter("selIndustryClassification")) : 0;
                int status = StringUtils.hasLength(request.getParameter("selStatus")) ? Integer.parseInt(request.getParameter("selStatus")) : 9;
                int ActionTakenBy = StringUtils.hasLength(request.getParameter("selActionTakenBy")) ? Integer.parseInt(request.getParameter("selActionTakenBy")) : 0;
                int CertificateExpireOn = StringUtils.hasLength(request.getParameter("selCertificateExpireOn")) ? Integer.parseInt(request.getParameter("selCertificateExpireOn")) : 0;
                Date CertExpireDateFrom = StringUtils.hasLength(request.getParameter("txtCertExpireDateFrom")) ? CommonUtility.getDateObj(request.getParameter("txtCertExpireDateFrom")) : null;
                Date CertExpireDateTo = StringUtils.hasLength(request.getParameter("txtCertExpireDateTo")) ? CommonUtility.getDateObj(request.getParameter("txtCertExpireDateTo")) : null;
                int EffectiveDate = StringUtils.hasLength(request.getParameter("selEffectiveDate")) ? Integer.parseInt(request.getParameter("selEffectiveDate")) : 0;
                Date EffectiveDateFrom = StringUtils.hasLength(request.getParameter("txtEffectiveDateFrom")) ? CommonUtility.getDateObj(request.getParameter("txtEffectiveDateFrom")) : null;
                Date EffectiveDateTo = StringUtils.hasLength(request.getParameter("txtEffectiveDateTo")) ? CommonUtility.getDateObj(request.getParameter("txtEffectiveDateTo")) : null;
                
                int operation = StringUtils.hasLength(request.getParameter("txtOperation")) ? Integer.parseInt(request.getParameter("txtOperation")) : 0;
                int officerId = abcUtility.getSessionUserId(request);
                
                String sortBy = StringUtils.hasLength(request.getParameter("txtSortBy")) ? request.getParameter("txtSortBy") : null;
                String sortOrder = StringUtils.hasLength(request.getParameter("txtSortOrder")) ? request.getParameter("txtSortOrder") : null;
                
                //set dynamic columns for headings
                showHideChk.add(Short.valueOf("1"));
                 if (request.getParameter("chkFileNo") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkCompanyName") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkRegNo") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkIndustryType") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkIndustryClassification") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkCategory") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkDepartment") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkAdmin") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkDateOfSubmission") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkStatus") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkEffectiveDate") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkActionTakenBy") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkCertificateExpiringOn") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkAction") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 
                 //Map<String, Object> dataMap = tenderReportService.getVendorPQReport(287, officerId, deptId, fileNo, CompanyName, deptId, registeredIn, IndustryType, ActionTakenBy, IndustryClassification, EffectiveDate, EffectiveDateFrom, EffectiveDateTo,CertificateExpireOn,CertExpireDateFrom,CertExpireDateTo,status, sessionBean.getTimeZoneOffset(),abcUtility.getCookieDateFormatConversionValue(request), showHideChk, recordPerPage, pageNo);
                 Map<String, Object> dataMap = tenderReportService.getVendorPQReport(abcUtility.getSessionClientId(request), officerId, deptId, fileNo, CompanyName, deptId, registeredIn, IndustryType, ActionTakenBy, IndustryClassification, EffectiveDate, EffectiveDateFrom, EffectiveDateTo,CertificateExpireOn,CertExpireDateFrom,CertExpireDateTo,status, sessionBean.getTimeZoneOffset(),abcUtility.getCookieDateFormatConversionValue(request), showHideChk, recordPerPage, pageNo,sortBy,sortOrder);
                if(dataMap.get("#result-set-1") != null){
                    int totalPages = Integer.parseInt(dataMap.get("@V_TotalPages").toString());
                    if (totalPages == 0){
                        totalPages = 1;
                    }
                    modelMap.addAttribute("listData",(ArrayList<LinkedHashMap<String, Object>>) dataMap.get("#result-set-1") );
                    modelMap.addAttribute("totalRecords", dataMap.get("@V_TotalRecords"));
                    modelMap.addAttribute("totalPages", totalPages);
                }
                Map<String, Object> dataMapPdf = tenderReportService.getVendorPQReport(abcUtility.getSessionClientId(request), officerId, deptId, fileNo, CompanyName, deptId, registeredIn, IndustryType, ActionTakenBy, IndustryClassification, EffectiveDate, EffectiveDateFrom, EffectiveDateTo,CertificateExpireOn,CertExpireDateFrom,CertExpireDateTo,status, sessionBean.getTimeZoneOffset(),abcUtility.getCookieDateFormatConversionValue(request), showHideChk, recordPerPage, pageNo,sortBy,sortOrder);
                if(dataMapPdf.get("#result-set-1") != null){
                    modelMap.addAttribute("listDataPdf",(ArrayList<LinkedHashMap<String, Object>>) dataMapPdf.get("#result-set-1") );
                }
                modelMap.addAttribute("pageNo", pageNo);
                modelMap.addAttribute("colspan", colspan);
                modelMap.addAttribute("operation", operation);
                modelMap.addAttribute("showHideChk", showHideChk);
                modelMap.addAttribute("sortBy", sortBy);
                modelMap.addAttribute("sortOrder", sortOrder);
                modelMap.addAttribute("selStatus", getPQStatusCombo());
                
                List<Object[]> listAdmin = vendorEnlistmentService.getAdminAndVendorEnlistCommitteeUserByClientId(abcUtility.getSessionClientId(request));
                List<SelectItem> selAdmin = abcUtility.convert(listAdmin);
                
                modelMap.addAttribute("selRegisteredIn", modelToSelectItem.convertListIntoSelectItemList(manageBidderService.getRegisteredIn(),"registeredInId","registeredIn"));
                modelMap.addAttribute("selIndustryType", modelToSelectItem.convertListIntoSelectItemList(manageBidderService.getIndustryType(), "indTypeId", "indType"));
                modelMap.addAttribute("selIndClassification", modelToSelectItem.convertListIntoSelectItemList(manageBidderService.getIndustryClassification(), "indClassificationId", "indClassification"));
                modelMap.addAttribute("selAdmin", selAdmin);
                modelMap.addAttribute("selNumOperation", getSearch4Numeric());
                page = "/enlistment/admin/VendorPQReport";
            }else{
                page =  "redirect:/sessionexpired";
            }
            
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkTenderMISReport, postTenderMISReport, 0, 0); 
        }
        return page;
    } 
    
      /**
     * Method use for get request of Individual Report for Tender Opening Process.
     * @author dipal
     * @param tenderId
     * @param envelopeId
     * @param formId
     * @param operation : 1: view report, 2: save as html , 3: save as word, 4:save as excel, 5:save as pdf
     * @param modelMap
     * @param request
     * @param session
     * @return  
     */
    @RequestMapping(value = {"/buyer/l1h1report/{tenderId}/{operation}/{commiteeType}/{enc}","/bidder/l1h1report/{tenderId}/{operation}/{commiteeType}/{enc}"}, method = RequestMethod.GET)
    public String showTenderLHReport(@PathVariable("tenderId") int tenderId,@PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session,RedirectAttributes redirectAttributes) {
        String page="";  
        int linkId=linkOpeningL1H1Report;
        Boolean showl1report = true;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	List<Object[]> reportData=tenderOpenService.getShareReports(tenderId);
            	if(abcUtility.getSessionUserTypeId(request) == 2 && (Integer)tenderCommonService.getTenderField(tenderId, "resultSharing") == 2 && (reportData != null && !reportData.isEmpty())){
            		if((Integer)reportData.get(0)[2] == 1){
            			if((Integer)reportData.get(0)[0] == 2 || (Integer)reportData.get(0)[0] == 3){
            				int envelopeId=tenderCommonService.getPriceBidOrTechnoEnvelopeId(tenderId);
            				List<Object[]> bidderDetaillst = tenderOpenService.getParticipatedOrQualifiedBidderDetail(tenderId,abcUtility.getSessionUserId(request),envelopeId);
            				if(bidderDetaillst != null && !bidderDetaillst.isEmpty()){
            					if((Integer)reportData.get(0)[0] == 2 && (bidderDetaillst.get(0)[0] == null || (Byte) bidderDetaillst.get(0)[0] != 1 ))
            						showl1report = false;
            				}else {
            					showl1report = false;
            				}
            			}
            		}else{
            			showl1report = false;	
            		}
            	}
       	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                 modelMap.addAttribute("operation",operation);
                
                 if(abcUtility.getSessionUserTypeId(request) == 2) // If access by Bidder?
                 {
                     linkId=linkBidderL1H1Report;
                 }
                 else if(commiteeType != 1) // If access from evaluation committee member?
                 {
                     linkId=linkEvaluationL1H1Report;
                 }
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                 if(operation == 2 && (request.getParameter("hdisPrintPriview")==null || request.getParameter("hdisPrintPriview").equalsIgnoreCase("0")))
                {
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
                Map<String,Object> outMap= tenderReportService.getL1H1ReportDetail(tenderId);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form Details
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Bidder's Grand total Form Wise
                    {
                        modelMap.addAttribute("lstBidderFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Bidder Grand Total Details
                    {
                        modelMap.addAttribute("lstBidderGrandTotalDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }
                }
              
                //Start For Rebate L1 Report Generate
                if( Integer.parseInt(modelMap.get("tenderResult").toString()) == 1 && Integer.parseInt(modelMap.get("isRebateForm").toString()) == 1 && abcUtility.getSessionUserTypeId(request) == 3){
                	TblDynReport tblDynReport  = dynamicReportService.getDynReportById(tenderId,7);
       				if(tblDynReport!=null)
       					dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(),tenderId,abcUtility.getSessionUserId(request));
                }
                //End For Rebate L1 Report Generate
                if(showl1report) {
                	page = "/etender/common/TenderL1H1Report";
                }else {
                	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_not_allow_to_access");
    				page="redirect:/etender/bidder/biddingtenderdashboard/" + tenderId + "/7" + encryptDecryptUtils.generateRedirect("etender/bidder/biddingtenderdashboard/" + tenderId + "/7", request);;
                }
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getL1H1Report, tenderId, 0);
        }
        return page;
    }
    
    /**
     * Method use for get item wise evaluation report details.
     * @author dipal
     * @param eventId
     * @param formId
     * @param operation  1: view report, 2: save as html , 3: save as word, 4:save as excel, 5:save as pdf
     * @param commiteeType
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */
    @RequestMapping(value = {"/buyer/itemwiseevaluationreport/{eventId}/{formId}/{operation}/{commiteeType}/{enc}"}, method = RequestMethod.GET)
    public String showItemWiseEvaluationReport(@PathVariable("eventId") int eventId,@PathVariable("formId") int formId,@PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        int linkId=linkOpeningItemEvalReport;
        if(commiteeType != 1)
        {
            linkId=linkEvaluationItemEvalReport;
        }
        try {
             if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
        	tenderCommonService.tenderSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
                 modelMap.addAttribute("operation",operation);
                
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                 if(operation == 2 && (request.getParameter("hdisPrintPriview")==null || request.getParameter("hdisPrintPriview").equalsIgnoreCase("0")))
                {
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
                 ItemWiseBreakupDataBean itemWiseBreakupDataBean = new ItemWiseBreakupDataBean();
                 
                Map<String,Object> outMap= tenderReportService.getItemWiseBreakupReportDetail(eventId,formId,operation);
                if(outMap != null && !outMap.isEmpty())
                { 
                    if(outMap.get(RESULTSET_1) !=null) // Form Detail
                    {
                        itemWiseBreakupDataBean.setFormList((ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1));
                    }
                   
                     if(outMap.get(RESULTSET_2) !=null) // Table Detail
                    {
                        itemWiseBreakupDataBean.setTableList((ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2));
                        for (Iterator<LinkedHashMap<String, Object>> it = itemWiseBreakupDataBean.getTableList().iterator(); it.hasNext();) {
                            Map<String,Object> outMap1= tenderReportService.getTenderOpeningReportDetail(eventId,Integer.parseInt(it.next().get("tableId").toString()),operation);
                            if(outMap1 != null) {
                                if(outMap1.get(RESULTSET_1) !=null){
                                    if(itemWiseBreakupDataBean.getColumnRowList()!=null && !itemWiseBreakupDataBean.getColumnRowList().isEmpty()){
                                        List<LinkedHashMap<String, Object>> lhms = itemWiseBreakupDataBean.getColumnRowList();
                                        lhms.addAll((ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_1));
                                        itemWiseBreakupDataBean.setColumnRowList(lhms);
                                    }else{
                                        itemWiseBreakupDataBean.setColumnRowList((ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_1));
                                    }
                                }
                                if(outMap1.get(RESULTSET_2) !=null){
                                    if(itemWiseBreakupDataBean.getColumnRowDetailsList()!=null && !itemWiseBreakupDataBean.getColumnRowDetailsList().isEmpty()){
                                        List<LinkedHashMap<String, Object>> lhms = itemWiseBreakupDataBean.getColumnRowDetailsList();
                                        lhms.addAll((ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_2));
                                        itemWiseBreakupDataBean.setColumnRowDetailsList(lhms);
                                    }else{
                                        itemWiseBreakupDataBean.setColumnRowDetailsList((ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_2));
                                    }                                    
                                }
                            }
                        }
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Officer Column Detail
                    {
                        itemWiseBreakupDataBean.setColumnList((ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3));
                    }
                }
                modelMap.addAttribute("iteamWiseBreakupDataBean", itemWiseBreakupDataBean);
               
                page = "/etender/buyer/ItemWiseEvaluationReport";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getItemWiseEvalReport, eventId, formId);
        }
        return page;
    }
    
    /**
     * to get tender audit trial report
     * @param tenderId
     * @param modelMap
     * @param request
     * @param session
     * @return
     */
    @RequestMapping(value = {"/buyer/tenderaudittrialreport/{tenderId}/{operationType}/{reportType}/{enc}","/buyer/tenderdocument/{tenderId}/{operationType}/{reportType}/{enc}","/bidder/tenderdocument/{tenderId}/{operationType}/{reportType}/{enc}"}, method = RequestMethod.GET)
    public String getTenderAuditTrialReport(@PathVariable("tenderId") int tenderId,@PathVariable("operationType") int operationType,@PathVariable("reportType") int reportType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        boolean forArchivalProcess = modelMap.get("forArchivalProcess") != null ? (Boolean) modelMap.get("forArchivalProcess") : false;
        try{
            if (session !=null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null && session.getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) {
            	modelMap.addAttribute("operation",operationType);
            	SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            	String timeZoneOffset=sessionBean.getTimeZoneOffset();
            	Map<String,Object> outMap= tenderReportService.getTenderAuditTrialReportDetail(tenderId,timeZoneOffset,abcUtility.getCookieDateFormatConversionValue(request),1);
            	List<LinkedHashMap<String, Object>> corrigendumWorkflowDetails = new ArrayList<LinkedHashMap<String,Object>>();
            	List<LinkedHashMap<String, Object>> bidOpeningWorkflowDetails = new ArrayList<LinkedHashMap<String,Object>>();
            	List<LinkedHashMap<String, Object>> bidOpeningProcessWorkflowDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> bidEvalWorkflowDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> cancelNITDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> preBidMeetingWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> preBidCommitteeWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> bidTOCReportProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> bidTECReportProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> negotiationCommitteeWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> negotiationCloseCommitteeWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> offlineNegotiationProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> poProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> poAmendmentProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> poCancelPIWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> poOfflineProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> poOfflineAmendmentProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> poOfflineCancelPIWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> apoProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> apoAmendmentProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> apoCancelPIWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> apoOfflineProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> apoOfflineAmendmentProcessWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> apoOfflineCancelPIWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> configureOpeningDateWFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> negotiatedL1WFDetails = new ArrayList<LinkedHashMap<String,Object>>();
    			List<LinkedHashMap<String, Object>> reEvaluationBidderData=new ArrayList<LinkedHashMap<String,Object>>();
    			
    			boolean isDirectPO=true;
	            List<Object[]> listCMS=clientService.getEventTypeIdForCMSDefaultConfg(abcUtility.getSessionClientId(request));
	            if (listCMS != null) {
	                for (int i = 0; i < listCMS.size(); i++) {
	                	if(listCMS.get(i)[0].toString().equalsIgnoreCase("12")){
	                		isDirectPO=false;                		 
	                    }
	                }
	            }
				modelMap.addAttribute("isDirectPO",isDirectPO);
    			
    			if(operationType == 2){
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
            	if(outMap != null && !outMap.isEmpty()){
            		if(outMap.get("#result-set-33") !=null){ //cancel tender details
        				List<LinkedHashMap<String, Object>> cancelEventData =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-33");
        				if(cancelEventData != null && !cancelEventData.isEmpty() ){
        					modelMap.addAttribute("cancelEventDetails",cancelEventData.get(0));
        				}
            		}
            		if(outMap.get(RESULTSET_1) !=null){ // tender details
            			List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1);
                        modelMap.addAttribute("tenderDetails",data.get(0));
                    }
            		if(outMap.get(RESULTSET_2) !=null){ // NIT APPROVAL HISTORY , Corrigendum workflow history, bid evaluation process in workflow
            			List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2);
            			List<LinkedHashMap<String, Object>> committeeData =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-31");
            			List<LinkedHashMap<String, Object>> tocTecReportData =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-32");
            			List<LinkedHashMap<String, Object>> nitDetails = new ArrayList<LinkedHashMap<String,Object>>();
            			for (LinkedHashMap<String, Object> tempMap : data) {
            				if(bidEvalWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            					boolean bool=false;
            					for (LinkedHashMap<String, Object> tempCommitteeMap : committeeData) {
            						if(Integer.parseInt(tempMap.get(OBJECT_ID).toString()) == Integer.parseInt(tempCommitteeMap.get(COMMITTEE_ID).toString())){
            							bool=true;
            						}
            					}
            					if(bool){
            						bidEvalWorkflowDetails.add(tempMap);
            					}
            				}else if(nitApprovalWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString()) && tenderId == Integer.parseInt(tempMap.get(OBJECT_ID).toString())){
            					nitDetails.add(tempMap);
            				}else if(cancelNoticeWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            					cancelNITDetails.add(tempMap);
            				}else if(corriWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            					corrigendumWorkflowDetails.add(tempMap);
            				}else if(bidOpeningWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            					boolean bool=false; 
            					for (LinkedHashMap<String, Object> tempCommitteeMap : committeeData) {
            						if(Integer.parseInt(tempMap.get(OBJECT_ID).toString()) == Integer.parseInt(tempCommitteeMap.get(COMMITTEE_ID).toString())){
            							bool=true;
            						}
            					}
            					if(bool){
            						bidOpeningWorkflowDetails.add(tempMap);
            					}
            				}else if(bid_opening_process_process_in_workflow == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            					bidOpeningProcessWorkflowDetails.add(tempMap);
            				}else if(preBidMeetingWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            					preBidMeetingWFDetails.add(tempMap);
            				}else if(preBidCommitteeWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            					boolean bool=false;
            					for (LinkedHashMap<String, Object> tempCommitteeMap : committeeData) {
            						if(Integer.parseInt(tempMap.get(OBJECT_ID).toString()) == Integer.parseInt(tempCommitteeMap.get(COMMITTEE_ID).toString())){
            							bool=true;
            						}
            					}
            					if(bool){
            						preBidCommitteeWFDetails.add(tempMap);
            					}
            				}else if(bidOpeningReportProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            					boolean bool=false;
            					for (LinkedHashMap<String, Object> tempReportMap : tocTecReportData) {
            						if(Integer.parseInt(tempMap.get(OBJECT_ID).toString()) == Integer.parseInt(tempReportMap.get(TENDERREPORT_ID).toString())){
            							bool=true;
            						}
            					}
            					if(bool){
            						bidTOCReportProcessWFDetails.add(tempMap);
            					}
            				}else if(bidEvaluationReportProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            					boolean bool=false;
            					for (LinkedHashMap<String, Object> tempReportMap : tocTecReportData) {
            						if(Integer.parseInt(tempMap.get(OBJECT_ID).toString()) == Integer.parseInt(tempReportMap.get(TENDERREPORT_ID).toString())){
            							bool=true;
            						}
            					}
            					if(bool){
            						bidTECReportProcessWFDetails.add(tempMap);
            					}
            				}else if(negotiationCreateCommitteeProcessInWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						negotiationCommitteeWFDetails.add(tempMap);
            				}else if(negotiation_close_process_in_workflow == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            					    negotiationCloseCommitteeWFDetails.add(tempMap);
            				}else if(offline_negotiation_process_in_workflow == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						offlineNegotiationProcessWFDetails.add(tempMap);
            				}else if(POProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						poProcessWFDetails.add(tempMap);
            				}else if(POAmendmentProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						poAmendmentProcessWFDetails.add(tempMap);
            				}else if(poCancelPIWLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						poCancelPIWFDetails.add(tempMap);
            				}else if(POOfflineProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						poOfflineProcessWFDetails.add(tempMap);
            				}else if(POOfflineAmendmentProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						poOfflineAmendmentProcessWFDetails.add(tempMap);
            				}else if(poOfflineCancelPIWLinkId  == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						poOfflineCancelPIWFDetails.add(tempMap);
            				}else if(APOProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						apoProcessWFDetails.add(tempMap);
            				}else if(APOAmendmentProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						apoAmendmentProcessWFDetails.add(tempMap);
            				}else if(apoCancelPIWLinkId  == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						apoCancelPIWFDetails.add(tempMap);
            				}else if(APOOfflineProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						apoOfflineProcessWFDetails.add(tempMap);
            				}else if(APOOfflineAmendmentProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						apoOfflineAmendmentProcessWFDetails.add(tempMap);
            				}else if(apoOfflineCancelPIWLinkId  == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						apoOfflineCancelPIWFDetails.add(tempMap);
            				}else if(ConfiguredateProcessWFLinkId == Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						configureOpeningDateWFDetails.add(tempMap);
            				}else if(negotiatedL1Report ==Integer.parseInt(tempMap.get(LINK_ID).toString())){
            						negotiatedL1WFDetails.add(tempMap);
            				}
            				
            			}
                        modelMap.addAttribute("nitDetails",nitDetails);
                        modelMap.addAttribute("cancelNITDetails",cancelNITDetails);
                        modelMap.addAttribute("bidEvalWorkflowDetails",bidEvalWorkflowDetails);
                        modelMap.addAttribute("bidOpeningWorkflowDetails",bidOpeningWorkflowDetails); //bid opening committee
                        modelMap.addAttribute("bidOpeningProcessWorkflowDetails",bidOpeningProcessWorkflowDetails); //bid opening Process
                        modelMap.addAttribute("preBidCommitteeWFDetails",preBidCommitteeWFDetails);
                        modelMap.addAttribute("preBidMeetingWFDetails",preBidMeetingWFDetails);
                        modelMap.addAttribute("bidTOCReportProcessWFDetails",bidTOCReportProcessWFDetails); // toc Report
                        modelMap.addAttribute("bidTECReportProcessWFDetails",bidTECReportProcessWFDetails); // tec Report
                        modelMap.addAttribute("negotiationCommitteeWFDetails",negotiationCommitteeWFDetails); // negotiation open Committee
                        modelMap.addAttribute("negotiationCloseCommitteeWFDetails",negotiationCloseCommitteeWFDetails); // negotiation close Committee
                        modelMap.addAttribute("offlineNegotiationProcessWFDetails",offlineNegotiationProcessWFDetails); // offline Negotiation Process
                        modelMap.addAttribute("poProcessWFDetails",poProcessWFDetails); 
                        modelMap.addAttribute("poAmendmentProcessWFDetails",poAmendmentProcessWFDetails); 
                        modelMap.addAttribute("poCancelPIWFDetails",poCancelPIWFDetails); 
                        modelMap.addAttribute("poOfflineProcessWFDetails",poOfflineProcessWFDetails); 
                        modelMap.addAttribute("poOfflineAmendmentProcessWFDetails",poOfflineAmendmentProcessWFDetails); 
                        modelMap.addAttribute("poOfflineCancelPIWFDetails",poOfflineCancelPIWFDetails); 
                        modelMap.addAttribute("apoProcessWFDetails",apoProcessWFDetails); 
                        modelMap.addAttribute("apoAmendmentProcessWFDetails",apoAmendmentProcessWFDetails); 
                        modelMap.addAttribute("apoCancelPIWFDetails",apoCancelPIWFDetails); 
                        modelMap.addAttribute("apoOfflineProcessWFDetails",apoOfflineProcessWFDetails); 
                        modelMap.addAttribute("apoOfflineAmendmentProcessWFDetails",apoOfflineAmendmentProcessWFDetails); 
                        modelMap.addAttribute("apoOfflineCancelPIWFDetails",apoOfflineCancelPIWFDetails); 
                        modelMap.addAttribute("configureOpeningDateWFDetails",configureOpeningDateWFDetails); 
                        modelMap.addAttribute("negotiatedL1WFDetails",negotiatedL1WFDetails); 
                        modelMap.addAttribute("corrigendumWorkflowDetails",corrigendumWorkflowDetails);
                        modelMap.addAttribute("RegBidderList", tenderReportService.viewRegretedBidDetails(tenderId));

            		}
            		if(outMap.get(RESULTSET_3) !=null){ // Tender Documents
                        modelMap.addAttribute("tenderDocDetails",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                    }
            		if(outMap.get(RESULTSET_4) !=null){ // Tender Documents
                        modelMap.addAttribute("envlpDetails",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }
            		if(outMap.get("#result-set-26") !=null){ // Section of Negotiation Committee
            			modelMap.addAttribute("negotiationCommitteeDetails",(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-26") );
            		}
            		if(outMap.get("#result-set-27") !=null){ // Section of APO LOI Report when APO publish
            			modelMap.addAttribute("apoNLoiReportDetails",(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-27") );
            		}
            		if(outMap.get("#result-set-28") !=null){ // Section of PO Wo Report when PO publish
            			modelMap.addAttribute("poNWoReportDetails",(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-28") );
            		}
            		if(outMap.get("#result-set-29") !=null){ // Section of delegate Report
            			modelMap.addAttribute("delegateReportDetails",(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-29") );
            		}
            		if(outMap.get("#result-set-30") !=null){ // Section of published Report
            			modelMap.addAttribute("publishedReportDetails",(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-30") );
            		}
            		//By Keval Soni CR : 29758 Start
            		List<LinkedHashMap<String, Object>> lstTemplate=commonService.getBRDDetails(3,regenerateTenderBrd,tenderId,abcUtility.getSessionClientId(request),abcUtility.getCookieDateFormatConversionValue(request));
            		modelMap.addAttribute("lstTemplate", lstTemplate);
            		List<Object[]> tenderDet = tenderCommonService.getTenderFields(tenderId, "submissionStartDate,submissionEndDate,publishedOn,openingDate");
               	 	modelMap.addAttribute("BidSubStartDate", tenderDet.get(0)[0]);
                    modelMap.addAttribute("BidSubEndDate", tenderDet.get(0)[1]);
                    modelMap.addAttribute("BidSubPublishedDate", tenderDet.get(0)[2]);
                    modelMap.addAttribute("BidSubOpeningDate", tenderDet.get(0)[3]);
                    ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
                    modelMap.addAttribute("timeZone", clientBean.getTimeZoneAbbr());
                    modelMap.addAttribute("isPCFEnable",commonService.isRCIClient(rciClientIds,abcUtility.getSessionClientId(request)) == true ? false : true);
                    //By Keval Soni CR : 29758 End
            		if(outMap.get(RESULTSET_5) !=null){ // BIDDING FORMS
            			List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5);
            			int envelopeId=0;
            			int cnt=0;
            			List<LinkedHashMap<String, Object>> formData=new ArrayList<LinkedHashMap<String,Object>>();
            			List<HashMap<String, Object>> envelopeData=new ArrayList<HashMap<String,Object>>();
            			Map<String, Object> dataMap=new HashMap<String, Object>();
            			Map<String,Object> formMap = null;
            			List<HashMap<String, Object>> lstFormMap = new ArrayList<HashMap<String,Object>>(); 	// By Nirav Raval Project Task:20966
            			for (LinkedHashMap<String, Object> tempMap : data) {
            				formMap = new HashMap<String, Object>();
            				if(envelopeId != Integer.parseInt(tempMap.get(ENVELOPE_ID).toString())){
            					envelopeId=(Integer)tempMap.get(ENVELOPE_ID);
            					if(cnt!=0){
            						dataMap.put("formData", formData);
            						envelopeData.add((HashMap<String, Object>) dataMap);
            						dataMap=new HashMap<String, Object>();
            						formData=new ArrayList<LinkedHashMap<String,Object>>();
            					}
            					dataMap.put(ENVELOPE_NAME, tempMap.get(ENVELOPE_NAME));
            				}
            				formData.add(tempMap);
            				if(cnt==data.size()-1){
            					dataMap.put("formData", formData);
        						envelopeData.add((HashMap<String, Object>) dataMap);
            				}
            				// By Nirav Raval Project Task:20966 - Start
            				tenderFormService.setViewFormNFormula(Integer.parseInt(tempMap.get("formId").toString()), formMap, tenderId);
            				lstFormMap.add((HashMap<String, Object>) formMap);
            				// By Nirav Raval Project Task:20966 - End            				
            				cnt++;
            			}
                        modelMap.addAttribute("envelopeData",envelopeData);
                        modelMap.addAttribute("lstFormMap",lstFormMap);		// By Nirav Raval Project Task:20966
                    }
                    Map<Integer,Integer> reEvaluationBidderMap = new HashMap<Integer, Integer>();
                    if(outMap.get("#result-set-23") !=null){ // Re-Evaluation 
                            reEvaluationBidderData =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-23");
                            modelMap.addAttribute("reEvaluationBidderData",reEvaluationBidderData);	
                     }
            		if(outMap.get(RESULTSET_6) !=null){ // For publish toc,tec, committee details committeeType==3 for prebid, committeeType==1 for opening, committeeType==2 for evaluation,
            			List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6);
            			List<LinkedHashMap<String, Object>> envelopeData =(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4);
            			List<LinkedHashMap<String, Object>> dataResultSetSeven =(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7);
            			List<LinkedHashMap<String, Object>> bidderDetailsResultSet =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-13");
            			List<LinkedHashMap<String, Object>> openingBidderDetailsResultSet =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-20");
            			List<LinkedHashMap<String, Object>> preBidCommitteeMembers =new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> openingCommitteeMembers =new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> evaluationCommitteeMembers =new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> openingCommitteeMembersFinal =new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> evaluationCommitteeMembersFinal =new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> envelopeDataList=new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> committeeDataList=new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> bidderDetailsDataList=new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> openingBidderDetailsDataList=new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> publishedTOCDataList=new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> publishedTECDataList=new ArrayList<LinkedHashMap<String,Object>>();
                        for (LinkedHashMap<String, Object> tempMap : data) {
                        	for (LinkedHashMap<String, Object> tempMapSeven : dataResultSetSeven) {
                        		if(Integer.parseInt(tempMap.get(COMMITTEE_ID).toString()) == Integer.parseInt(tempMapSeven.get(COMMITTEE_ID).toString()) && Integer.parseInt(tempMap.get(COMMITTEE_TYPE).toString()) == 3){
                        			preBidCommitteeMembers.add(tempMapSeven);
                        		}else if(Integer.parseInt(tempMap.get(COMMITTEE_ID).toString()) == Integer.parseInt(tempMapSeven.get(COMMITTEE_ID).toString()) && Integer.parseInt(tempMap.get(COMMITTEE_TYPE).toString()) == 1){
                        			openingCommitteeMembers.add(tempMapSeven);
                        		}
                        		else if(Integer.parseInt(tempMap.get(COMMITTEE_ID).toString()) == Integer.parseInt(tempMapSeven.get(COMMITTEE_ID).toString()) && Integer.parseInt(tempMap.get(COMMITTEE_TYPE).toString()) == 2){
                        			evaluationCommitteeMembers.add(tempMapSeven);
                        		}
                        	}
                        	if(Integer.parseInt(tempMap.get(COMMITTEE_TYPE).toString()) == 3){
                        		committeeDataList.add(tempMap);
                        	}
                        	if(Integer.parseInt(tempMap.get(COMMITTEE_TYPE).toString()) == 1){
                        		publishedTOCDataList.add(tempMap);
                        	}else if(Integer.parseInt(tempMap.get(COMMITTEE_TYPE).toString()) == 2){
                        		publishedTECDataList.add(tempMap);
                        	}
                        }
                        modelMap.addAttribute("publishedTOCDataList",publishedTOCDataList);
                        modelMap.addAttribute("publishedTECDataList",publishedTECDataList);
                        modelMap.addAttribute("committeeDetails",committeeDataList);
                        modelMap.addAttribute("preBidCommitteeMembers",preBidCommitteeMembers);
                        //Map<String, Object> tempHashMap=new HashMap<String, Object>();
                        for (LinkedHashMap<String, Object> tempMap : envelopeData) {
                        	openingCommitteeMembersFinal=new ArrayList<LinkedHashMap<String,Object>>();
                        	evaluationCommitteeMembersFinal=new ArrayList<LinkedHashMap<String,Object>>();
                        	bidderDetailsDataList=new ArrayList<LinkedHashMap<String,Object>>();
                        	openingBidderDetailsDataList=new ArrayList<LinkedHashMap<String,Object>>();
                        	for (LinkedHashMap<String, Object> tempMapOpening : openingCommitteeMembers) {
                        		if(Integer.parseInt(tempMapOpening.get("childId").toString()) == Integer.parseInt(tempMap.get(ENVELOPE_ID).toString())){
                        			openingCommitteeMembersFinal.add(tempMapOpening);                        		}
                        	}
                        	for (LinkedHashMap<String, Object> tempMapEvaluation : evaluationCommitteeMembers) {
                        		if(Integer.parseInt(tempMapEvaluation.get("childId").toString()) == Integer.parseInt(tempMap.get(ENVELOPE_ID).toString())){
                        			evaluationCommitteeMembersFinal.add(tempMapEvaluation);                        		}
                        	}
                        	int bidderId = 0;		// By Nirav Raval Project Task:20966
                        	for (LinkedHashMap<String, Object> tempMapBidderDetails : bidderDetailsResultSet) {
                        		if(Integer.parseInt(tempMapBidderDetails.get(ENVELOPE_ID).toString()) == Integer.parseInt(tempMap.get(ENVELOPE_ID).toString())){
                        			String tempString=tempMapBidderDetails.get(COMPANY_NAME).toString();
                    				tempString=tempString.replace(LABEL_LEAD, messageSource.getMessage(LABEL_LEAD, null, LocaleContextHolder.getLocale()));
                    				tempString=tempString.replace(LABEL_CONSORT_WITH, messageSource.getMessage(LABEL_CONSORT_WITH, null, LocaleContextHolder.getLocale()));
                    				tempString=tempString.replace(LABEL_SECONDARY, messageSource.getMessage(LABEL_SECONDARY, null, LocaleContextHolder.getLocale()));
                    				tempMapBidderDetails.put(COMPANY_NAME, tempString.subSequence(0, tempString.length()-1));
                        			bidderDetailsDataList.add(tempMapBidderDetails);                        		
                        		}
                        	}
                                for(LinkedHashMap<String, Object> reEvaluationBidder : reEvaluationBidderData){
                                    if(Integer.parseInt(reEvaluationBidder.get(ENVELOPE_ID).toString()) == Integer.parseInt(tempMap.get(ENVELOPE_ID).toString())){
                                        reEvaluationBidderMap.put(Integer.parseInt(tempMap.get(ENVELOPE_ID).toString()), 1);
                                    } 
                                }
                                modelMap.addAttribute("reEvaluationBidderMap", reEvaluationBidderMap);
                        	Map<String,Object> formMapAbstractReport = null;
                			List<LinkedHashMap<String, Object>> listFormMapAbstractReport = new ArrayList<LinkedHashMap<String,Object>>(); 	// By Nirav Raval Project Task:20966
                        	for (LinkedHashMap<String, Object> tempMapOpeningBidderDetails : openingBidderDetailsResultSet) {
                        		if(Integer.parseInt(tempMapOpeningBidderDetails.get(ENVELOPE_ID).toString()) == Integer.parseInt(tempMap.get(ENVELOPE_ID).toString())){
                        			formMapAbstractReport = new LinkedHashMap<String, Object>();
                        			String tempString=tempMapOpeningBidderDetails.get(COMPANY_NAME).toString();
                        			bidderId=Integer.parseInt(tempMapOpeningBidderDetails.get("bidderId").toString());
                    				tempString=tempString.replace(LABEL_LEAD, messageSource.getMessage(LABEL_LEAD, null, LocaleContextHolder.getLocale()));
                    				tempString=tempString.replace(LABEL_CONSORT_WITH, messageSource.getMessage(LABEL_CONSORT_WITH, null, LocaleContextHolder.getLocale()));
                    				tempString=tempString.replace(LABEL_SECONDARY, messageSource.getMessage(LABEL_SECONDARY, null, LocaleContextHolder.getLocale()));
                    				tempMapOpeningBidderDetails.put(COMPANY_NAME, tempString.subSequence(0, tempString.length()-1));
                    				openingBidderDetailsDataList.add(tempMapOpeningBidderDetails);   
                    				formMapAbstractReport = bidderWiseAbstractReport(bidderId,tenderId,Integer.parseInt(tempMapOpeningBidderDetails.get(ENVELOPE_ID).toString()));
                    				listFormMapAbstractReport.add((LinkedHashMap<String, Object>) formMapAbstractReport);
                        		}
                        	}
                        	//tempHashMap=tempMap;
                        	tempMap.put("openingCommitteeMembers", openingCommitteeMembersFinal);
                        	tempMap.put("evaluationCommitteeMembers", evaluationCommitteeMembersFinal);
                        	tempMap.put("bidderDetailsDataList", bidderDetailsDataList);
                        	tempMap.put("openingBidderDetailsDataList", openingBidderDetailsDataList);
                        	tempMap.put("listFormMapAbstractReport", listFormMapAbstractReport);
                        	envelopeDataList.add(tempMap);
                        }
                        modelMap.addAttribute("envelopeDataList",envelopeDataList);
                        //modelMap.addAttribute("evaluationCommitteeMembers",evaluationCommitteeMembersFinal);
                    }
            		if(outMap.get(RESULTSET_8) !=null){ // Online bid submission
            			List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8);
            			List<LinkedHashMap<String, Object>> bidSubmissionDetails=new ArrayList<LinkedHashMap<String,Object>>();
            			for (LinkedHashMap<String, Object> tempMap : data) {
            				String tempString=tempMap.get(COMPANY_NAME).toString();
            				tempString=tempString.replace(LABEL_LEAD, messageSource.getMessage(LABEL_LEAD, null, LocaleContextHolder.getLocale()));
            				tempString=tempString.replace(LABEL_CONSORT_WITH, messageSource.getMessage(LABEL_CONSORT_WITH, null, LocaleContextHolder.getLocale()));
            				tempString=tempString.replace(LABEL_SECONDARY, messageSource.getMessage(LABEL_SECONDARY, null, LocaleContextHolder.getLocale()));
            				tempMap.put(COMPANY_NAME, tempString.subSequence(0, tempString.length()-1));
            				bidSubmissionDetails.add(tempMap);
            			}
                        modelMap.addAttribute("bidSubmissionDetails",bidSubmissionDetails);
                    }
            		if(outMap.get("#result-set-9") !=null){ // Online bid submission
            			List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-9");
            			List<LinkedHashMap<String, Object>> fieldData =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-10");
            			List<LinkedHashMap<String, Object>> typeData =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-11");
            			List<LinkedHashMap<String, Object>> documentData =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-12");
            			List<LinkedHashMap<String, Object>> corrigendumData = new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> corrigendumFieldData = new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> corrigendumTypeData = new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> corrigendumDocumentData = new ArrayList<LinkedHashMap<String,Object>>();
            			for (LinkedHashMap<String, Object> tempMap : data) {
            				for (LinkedHashMap<String, Object> tempFieldMap : fieldData) {
            					if(Integer.parseInt(tempMap.get(CORRIGENDUM_ID).toString()) == Integer.parseInt(tempFieldMap.get(CORRIGENDUM_ID).toString())){
            						corrigendumFieldData.add(tempFieldMap);
            					}
            				}
            				tempMap.put("corrigendumFieldData", corrigendumFieldData);
            				corrigendumFieldData=new ArrayList<LinkedHashMap<String,Object>>();
            				for (LinkedHashMap<String, Object> tempTypeMap : typeData) {
            					if(Integer.parseInt(tempMap.get(CORRIGENDUM_ID).toString()) == Integer.parseInt(tempTypeMap.get(CORRIGENDUM_ID).toString())){
            						corrigendumTypeData.add(tempTypeMap);
            					}
            				}
            				tempMap.put("corrigendumTypeData", corrigendumTypeData);
            				corrigendumTypeData=new ArrayList<LinkedHashMap<String,Object>>();
            				for (LinkedHashMap<String, Object> tempDocumentMap : documentData) {
            					if(Integer.parseInt(tempMap.get(CORRIGENDUM_ID).toString()) == Integer.parseInt(tempDocumentMap.get(OBJECT_ID).toString())){
            						corrigendumDocumentData.add(tempDocumentMap);
            					}
            				}
            				tempMap.put("corrigendumDocumentData", corrigendumDocumentData);
            				corrigendumDocumentData=new ArrayList<LinkedHashMap<String,Object>>();
            				corrigendumData.add(tempMap);
            			}
            			modelMap.addAttribute("corrigendumData",corrigendumData);
                    }
            		if(outMap.get("#result-set-14") !=null){ // pre bid documents
            			List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-14");
                        modelMap.addAttribute("preBidDocumentsDetails",data);
                    }
            		if(outMap.get("#result-set-15") !=null){ // opening & evaluation report details
            			List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-15");
            			List<LinkedHashMap<String, Object>> reportData =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-16");
            			List<LinkedHashMap<String, Object>> openingReportList=new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> evaluationReportList=new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> tenderOpeningReportList=new ArrayList<LinkedHashMap<String,Object>>();
            			List<LinkedHashMap<String, Object>> tenderEvaluationReportList=new ArrayList<LinkedHashMap<String,Object>>();
            			int count=0;
            			for (LinkedHashMap<String, Object> tempMap : data) {
            				if(count !=0){
            					openingReportList=new ArrayList<LinkedHashMap<String,Object>>();
            					evaluationReportList=new ArrayList<LinkedHashMap<String,Object>>();
            				}
            				for (LinkedHashMap<String, Object> tempReportMap : reportData) {
                				if(Integer.parseInt(tempMap.get(TENDERREPORT_ID).toString()) == Integer.parseInt(tempReportMap.get(TENDERREPORT_ID).toString()) && Integer.parseInt(tempMap.get(REPORT_TYPE).toString()) == 1){
                					openingReportList.add(tempReportMap);
                				}else if(Integer.parseInt(tempMap.get(TENDERREPORT_ID).toString()) == Integer.parseInt(tempReportMap.get(TENDERREPORT_ID).toString()) && Integer.parseInt(tempMap.get(REPORT_TYPE).toString()) == 2){
                					evaluationReportList.add(tempReportMap);
                				}
                			}
            				if(Integer.parseInt(tempMap.get(REPORT_TYPE).toString())==1){
            					tempMap.put("openingReportList", openingReportList);
            					tenderOpeningReportList.add(tempMap);
            				}else if(Integer.parseInt(tempMap.get(REPORT_TYPE).toString())==2){
            					tempMap.put("evaluationReportList", evaluationReportList);
            					tenderEvaluationReportList.add(tempMap);
            				}
            				count++;
            			}
            			modelMap.addAttribute("tenderOpeningReportList",tenderOpeningReportList);
            			modelMap.addAttribute("tenderEvaluationReportList",tenderEvaluationReportList);
                    }
            		if(outMap.get("#result-set-17") !=null){ // bid withdrawal
            			List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-17");
                        modelMap.addAttribute("bidWithdrawalDetails",data);
                    }
            		if(outMap.get("#result-set-18") !=null){ // clarification details
            			List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-18");
            			int envelopeId=0;
            			int cnt=0;
            			List<LinkedHashMap<String, Object>> clarificationData=new ArrayList<LinkedHashMap<String,Object>>();
            			List<HashMap<String, Object>> envelopeData=new ArrayList<HashMap<String,Object>>();
            			Map<String, Object> dataMap=new HashMap<String, Object>();
            			for (LinkedHashMap<String, Object> tempMap : data) {
            				if(envelopeId != Integer.parseInt(tempMap.get(ENVELOPE_ID).toString())){
            					envelopeId=(Integer)tempMap.get(ENVELOPE_ID);
            					if(cnt!=0){
            						dataMap.put("clarificationData", clarificationData);
            						envelopeData.add((HashMap<String, Object>) dataMap);
            						dataMap=new HashMap<String, Object>();
            						clarificationData=new ArrayList<LinkedHashMap<String,Object>>();
            					}
            					dataMap.put(ENVELOPE_NAME, tempMap.get(ENVELOPE_NAME));
            				}
            				clarificationData.add(tempMap);
            				if(cnt==data.size()-1){
            					dataMap.put("clarificationData", clarificationData);
        						envelopeData.add((HashMap<String, Object>) dataMap);
            				}
            				cnt++;
            			}
                        modelMap.addAttribute("clarificationDetails",envelopeData);
                    }
                }
            	/*if(outMap.get("#result-set-19") !=null){
            		List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-19");
            		int showH1L1Report=data != null && !data.isEmpty() ? (Integer)data.get(0).get("showH1L1Report") : 0;
            		if(showH1L1Report == 1){
		            	Map<String,Object> outMapResultL1H1= tenderReportService.getL1H1ReportDetail(tenderId);
		                if(outMapResultL1H1 != null && !outMapResultL1H1.isEmpty())
		                {
		                    if(outMapResultL1H1.get(RESULTSET_1) !=null) // L1H1 Report Detail
		                    {
		                        modelMap.addAttribute("lstReportDet",(ArrayList<LinkedHashMap<String, Object>>) outMapResultL1H1.get(RESULTSET_1) );
		                    }
		                    if(outMapResultL1H1.get(RESULTSET_2) !=null) // Tender Common Details
		                    {
		                        modelMap.addAttribute("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMapResultL1H1.get(RESULTSET_2) );
		                    }
		                }
            		}
            	}*/
            	if(outMap.get("#result-set-21") !=null){
            		List<LinkedHashMap<String, Object>> data =(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-21");
            		List<HashMap<String, Object>> dynamicReportData=new ArrayList<HashMap<String,Object>>();
            		for (LinkedHashMap<String, Object> tempMap : data) {
            			HashMap<String,Object> dataMap=new HashMap<String, Object>();
            			int reportFor=Integer.parseInt(tempMap.get("reportFor").toString());
            			Map<String,Object> dynamicReport = dynamicReportService.getDynamicL1H1Report(Integer.parseInt(tempMap.get("reportId").toString()),tenderId,abcUtility.getSessionUserId(request));
                        if(dynamicReport != null && !dynamicReport.isEmpty()) {
                        	dataMap.put("reportFor", reportFor);
                        	dataMap.put("reportColumnList", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-3"));
                        	dataMap.put("reportColumnHeaderList", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-2"));
                        	dataMap.put("reportFormHeader", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-1") );
                        	dataMap.put("reportHeader", (ArrayList<LinkedHashMap<String,Object>>) dynamicReport.get("#result-set-4") );
                        	dynamicReportData.add(dataMap);
                        }
            		}
            		modelMap.addAttribute("dynamicReportData",dynamicReportData);
            	}
            	int isFirstEnvOpened = 0;
            	if(outMap.get("#result-set-22") !=null){ // Tender Envelope Form with weightage marks detail
            		ArrayList<LinkedHashMap<String, Object>> lstIsFirstEnvOpened = (ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-22") ;
            		if(lstIsFirstEnvOpened != null && lstIsFirstEnvOpened.size() > 0){
            			isFirstEnvOpened = Integer.parseInt(lstIsFirstEnvOpened.get(0).get("isOpened").toString());
            		}
                }
            	modelMap.addAttribute("isFirstEnvOpened",isFirstEnvOpened);
            	if(outMap.get("#result-set-24") !=null){ // Tender Envelope with weightage score detail
                    modelMap.addAttribute("tenderEnvelopeList",(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-24") );
                    if(outMap.get("#result-set-25") !=null){ // Tender Envelope Form with weightage marks detail
                    	 modelMap.addAttribute("tenderEnvelopeFormList",(ArrayList<LinkedHashMap<String, Object>>) outMap.get("#result-set-25") );
                    }
                }
            	
            	modelMap.addAttribute("reportType",reportType);
            	int clientId = abcUtility.getSessionClientId(request);
                modelMap.addAttribute("userType", abcUtility.getSessionUserTypeId(request));            	
                modelMap.addAttribute("isWorkFlow", 0);
            	eventCreationService.tenderView(tenderId, modelMap, clientId);
            	TblTender tblTender = (TblTender) modelMap.get("tblTender");                
            	getCustomConfigData(modelMap, clientId, tblTender.getTblEventType().getEventTypeId(), "view");
            	modelMap.addAttribute("decimalValueUpto",tblTender.getDecimalValueUpto());
                //Project Task #33190 bug #33285
                 List<String> field = new ArrayList<String>();
			field.add("tenderNo");
       		List<Object[]> lstClientConfigFields = commonService.getClientConfigurationFields(clientId,eventTypeId,field);
            if (lstClientConfigFields != null) {
                for (int i = 0; i < lstClientConfigFields.size(); i++) {
                	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("tenderNo")){
                                modelMap.put("TenderReferenceLabel", lstClientConfigFields.get(i)[6].toString());
                    }
                }
            }
            
            /*Negotiated L1 Report Start*/
            int isItemwiseWinner=(Integer)tenderCommonService.getTenderField(tenderId, "isItemwiseWinner");
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	if(isItemwiseWinner==1){
	            	tenderFormService.negotiatedL1ReportData(modelMap,tenderId);
	            	negotiationService.gethorizontalviewlonereport(modelMap,tenderId);
        	}else if(isItemwiseWinner==0){
        		modelMap.addAttribute("tenderId",tenderId);
                modelMap.addAttribute("listTblNegotiationResults", negotiationService.getTblNegotiationResult(tenderId));
        	}
        	modelMap.put("isItemwiseWinner", isItemwiseWinner);
        	/*Negotiated L1 Report Start*/
        
        	/*Negotiated weightage L1 Report Start*/
        	boolean negWeighFlag=false;
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	int userRoleId = 1;
			if((Integer) modelMap.get("isTwoStageEvaluation") == 1 ){
				userRoleId = (Integer) modelMap.get("multiLevelEvaluationReq") == 1 ? 4 : 2;
			}
        	Map<String,Object> outMap1= tenderReportService.getWeightageL1Report(tenderId,userRoleId);
            if(outMap1 != null && !outMap1.isEmpty())
            {
            	if(outMap1.get(RESULTSET_1) !=null) // Tender Envelope
                {
                    modelMap.addAttribute("tenderEnvelopeList",(ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_1) );
                    negWeighFlag=true;
                }
            	if(outMap1.get(RESULTSET_2) !=null) // Evaluated Envelope Approved Bidder List
                {
                    modelMap.addAttribute("approvedBidderList",(ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_2) );
                    negWeighFlag=true;
                }
            	if(outMap1.get(RESULTSET_3) !=null) // get Approved Bidder Scoring Marks by envelopeId, bidderId
                {
                    modelMap.addAttribute("approvedBidderScoreList",(ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_3) );
                    negWeighFlag=true;
                }
            	if(outMap1.get(RESULTSET_4) !=null) // get Approved Bidder Scoring Marks by envelopeId, bidderId
                {
                    modelMap.addAttribute("approvedBidderL1List",(ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_4) );
                    negWeighFlag=true;
                }
            }
            modelMap.addAttribute("negWeighFlag",negWeighFlag);
            /*Negotiated weightage L1 Report end*/
        	
            /*L1 manual Report start*/
            modelMap.addAttribute("overRulesDetails", tenderReportService.getOverRuledReport(tenderId));
            /*L1 manual Report end*/
            
            
            /*Dynamic Report start*/
            	List<TblDynReport> dynReportList = dynamicReportService.getDynReportByTenderId(tenderId);
					if (dynReportList != null && !dynReportList.isEmpty()) {
						tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
						//IM
						boolean isOpeningDateLapsed = false;
						Date openingDate=(Date)tenderCommonService.getTenderField(tenderId, "openingDate");
						if(openingDate != null && openingDate.before(commonService.getServerDateTime())){
	    					isOpeningDateLapsed = true;
	    				}
						modelMap.addAttribute("isOpeningDateLapsed", isOpeningDateLapsed);
						
						boolean isPriceBidOpen = tenderCommonService.isPriceBidOpen(tenderId);
                           if(isPriceBidOpen){	//Decryption is pending for approved bidder or if not evaluation done then still decryption is pending for TenderOpen table (0,1 case)
                           	isPriceBidOpen = dynamicReportService.checkIsDecryptedAllApprovedBidderByTenderId(tenderId);
                           	 int isReEvaluationReq = (Integer) modelMap.get("isReEvaluationReq");
                                if(isReEvaluationReq == 1 && !isPriceBidOpen){
                                    Integer[] ctatus={0,1};
                                    List<TblTenderReevaluation> getTblTenderReevaluation = tenderFormService.getTblTenderEnvelopeRevaluationStatusByTenderId(tenderId,ctatus);
                                    if(getTblTenderReevaluation!=null && !getTblTenderReevaluation.isEmpty()){
                                   	 isPriceBidOpen = true;
                                    }
                                }
                           }
                        modelMap.addAttribute("isPriceBidOpen", isPriceBidOpen);
                        if(isPriceBidOpen && isOpeningDateLapsed)
                        {
                        	List finalDynamicReportList=new LinkedList();
    						for (TblDynReport tblDynReport : dynReportList) {
    							List dynamicReportList=new LinkedList();
    							Map<String, Object> dynamicReport = dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(), tenderId, abcUtility.getSessionUserId(request));
    							if (dynamicReport != null && !dynamicReport.isEmpty()) {
    								dynamicReportList.add((ArrayList<LinkedHashMap<String, Object>>) dynamicReport.get("#result-set-3")); //[0] reportColumnList
    								dynamicReportList.add((ArrayList<LinkedHashMap<String, Object>>) dynamicReport.get("#result-set-2")); //[1] reportColumnHeaderList
    								dynamicReportList.add((ArrayList<LinkedHashMap<String, Object>>) dynamicReport.get("#result-set-1")); //[2] reportFormHeader
    								dynamicReportList.add((ArrayList<LinkedHashMap<String, Object>>) dynamicReport.get("#result-set-4")); //[3] reportHeader
    								/*isFormMap	 status start*/
    								List<TblDynReportFormMap> formMapSize = dynamicReportService.getDynReporFormMaptById(tblDynReport.getReportId());
    								dynamicReportList.add((formMapSize != null && !formMapSize.isEmpty()) ? true : false); //[4] isFormMap
    								
    								String reportOP="";
    								boolean flag=true;
    								if(formMapSize != null && !formMapSize.isEmpty()){
    				        			List<TblDynReportColumn> columnList=dynamicReportService.getDynReportColumnByReportId(tblDynReport.getReportId(), 2);
    									Long countColumns =dynamicReportService.getFormulaColumnCount(tblDynReport.getReportId(),0);
    									reportOP=String.valueOf(columnList.size() != 0 && columnList.size() == countColumns ? -1 : 0);
    				        		}else{
    				        			reportOP=String.valueOf("1");
    				        		}
    								if(reportOP.equals("0")|| reportOP.equals("1")) {
    									flag=false;
    								}
    								dynamicReportList.add(flag); //[5] dynamic form Validation
    								
    								/*isFormMap	 status end*/
    								finalDynamicReportList.add(dynamicReportList);
    							}
    						}
    						modelMap.addAttribute("finalDynamicReportList",finalDynamicReportList);
                        }
					}
				/*Dynamic Report end*/
            
            
            // 0 and 1 for bid reports and 2 for audit trial reports
            	if(reportType == 0 || reportType == 1)
            	{
            		page = "/etender/common/TenderDocument";
            	}else{
            		page = "/etender/common/TenderAuditTrialReport";
            	}
                
            }else{
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
        	page= exceptionHandlerService.writeLog(e);
        	if(forArchivalProcess) {
				modelMap.addAttribute("Exception", e);
			}
        } finally {
        	if(!forArchivalProcess) {
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), tenderAuditTrialLinkId, getTenderAuditTrialReport, tenderId, 0);
        	}	
        }
        return page;
    }
    
    
    private Map<String,Object> bidderWiseAbstractReport(int bidderId, int tenderId, int envelopeId){ 
        String page="";  
        Map<String,Object> formMapAbstractReport = new LinkedHashMap<String, Object>();
        int consortiumId =0;
        try {
            
        	Map<String,Object> outMap= tenderOpenService.getBidderWiseReportDetail(tenderId,envelopeId,bidderId,consortiumId);
            if(outMap != null && !outMap.isEmpty())
            {
                if(outMap.get(RESULTSET_1) !=null) // Tender Form
                {
                	formMapAbstractReport.put("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                }
                if(outMap.get(RESULTSET_2) !=null) // Tender Table
                {
                	formMapAbstractReport.put("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                }
                if(outMap.get(RESULTSET_3) !=null) // Tender Column
                {
                	formMapAbstractReport.put("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                }
                if(outMap.get(RESULTSET_4) !=null) // Tender cell - Filled by Officer
                {
                	formMapAbstractReport.put("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                }
                if(outMap.get(RESULTSET_5) !=null) // Tender bidder 
                {
                	formMapAbstractReport.put("lstCompanyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                }
                if(outMap.get(RESULTSET_6) !=null) // Tender bid 
                {
                	formMapAbstractReport.put("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                }
                 if(outMap.get(RESULTSET_7) !=null) // Tender Form bidded multiple time 
                {
                	 formMapAbstractReport.put("lstFormBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                }
                
                if(outMap.get(RESULTSET_8) !=null) // Tender Table bidded multiple time by add row
                {
                	formMapAbstractReport.put("lstTableBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                }   
                
                if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                {
                	formMapAbstractReport.put("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                }
                if(outMap.get(RESULTSET_10) !=null) // Upload Document details
                {
                	formMapAbstractReport.put("lstDocumentDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                }
                if(outMap.get(RESULTSET_12) !=null) // Tender Proxy column Details
                {
                	formMapAbstractReport.put("lstTenderProxyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_12) );
                }
                if(outMap.get(RESULTSET_13) !=null) // Item wise bidder Mapping Details
                {
                	formMapAbstractReport.put("lstItemWiseBidderMapDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_13) );
                }
                if(outMap.get(RESULTSET_14) !=null) // Item wise bidder Mapping Details
                {
                	formMapAbstractReport.put("listItemWiseBidderDocDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_14) );
                }
                formMapAbstractReport.put("newEnvelopeId",envelopeId);
            }
            
	    } catch (Exception e) {
	            exceptionHandlerService.writeLog(e);
	    } 
	        return formMapAbstractReport;
	    }
    
    
    /**
     * get configuration data at admin side
     *
     * @param ModelMap modelMap
     * @param int clientId
     * @param int eventTypeId
     * @param String event
     */
    public void getCustomConfigData(ModelMap modelMap, int clientId, int eventTypeId, String event) throws Exception {
        Map<String, Object> configParam = new HashMap<String, Object>();
        Map<String, Object> hideConfigParam = new HashMap<String, Object>();
        List<SelectItem> lst = null;
        Map<String, Object> labelMap = new HashMap<String, Object>();
        Map<String, Object> valueMap = new HashMap<String, Object>();
        String data = "";
        List<Object[]> lstClientConfigFields = eventCreationService.getClientConfigurationFields(clientId, eventTypeId);
        if (lstClientConfigFields != null) {
            for (int i = 0; i < lstClientConfigFields.size(); i++) {
                if ((Integer) lstClientConfigFields.get(i)[0] == 1) {
                    if (lstClientConfigFields.get(i)[4] != null) {
                        configParam.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[4].toString());
                    } else {
                        configParam.put(lstClientConfigFields.get(i)[3].toString(), data);
                    }
                } else {
                    if (lstClientConfigFields.get(i)[4] != null) {
                        hideConfigParam.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[4].toString());
                    } else {
                        hideConfigParam.put(lstClientConfigFields.get(i)[3].toString(), data);
                    }
                }
                labelMap.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[6].toString());
                if (Integer.parseInt(lstClientConfigFields.get(i)[1].toString()) == 2) {
                    if (StringUtils.hasLength(lstClientConfigFields.get(i)[7].toString())) {
                        if (!event.equals("view")) {
                            valueMap.put(lstClientConfigFields.get(i)[3].toString(), generateList(lstClientConfigFields.get(i)[7].toString()));
                        } else {
                            valueMap.put(lstClientConfigFields.get(i)[3].toString(), generateDataMap(lstClientConfigFields.get(i)[7].toString()));
                        }
                    } else if (StringUtils.hasLength(lstClientConfigFields.get(i)[5].toString())) {
                        lst = abcUtility.convert(commonService.getExecuteQuery(lstClientConfigFields.get(i)[5].toString(), clientId));
                        valueMap.put(lstClientConfigFields.get(i)[3].toString(), lst);
                    }
                } else {
                    valueMap.put(lstClientConfigFields.get(i)[3].toString(), lstClientConfigFields.get(i)[7].toString());
                }
            }
        }
        modelMap.addAttribute("hideConfigParam", hideConfigParam);
        modelMap.addAttribute("configParam", configParam);
        modelMap.addAttribute("labelMap", labelMap);
        modelMap.addAttribute("valueMap", valueMap);
    }
    
    /**
     * generate List<SelectItem> for get value from tbl_Field for fill combo at
     * CreateTender.jsp page
     *
     * @param String data
     * @return List<SelectItem>
     */
    private List<SelectItem> generateList(String data) {
        String[] dataOne = data.split("~");
        List<SelectItem> dataList = new ArrayList<SelectItem>();
        for (String tempData : dataOne) {
            String[] dataTwo = tempData.split("::");
            dataList.add(new SelectItem(messageSource.getMessage(dataTwo[0], null, LocaleContextHolder.getLocale()), dataTwo[1]));
        }
        return dataList;
    }
    
    
    /**
     * generate Map for get value from tbl_Field for view value at
     * viewTender.jsp page
     *
     * @param String data
     * @return Map<Integer, String>
     */
    private Map<Integer, String> generateDataMap(String data) {
        String[] dataOne = data.split("~");
        Map<Integer, String> dataMap = new HashMap<Integer, String>();
        for (String tempData : dataOne) {
            String[] dataTwo = tempData.split("::");
            dataMap.put(Integer.parseInt(dataTwo[1]), messageSource.getMessage(dataTwo[0], null, LocaleContextHolder.getLocale()));
        }
        return dataMap;
    } 
    
    
    
    /**
     * Method use for get customized report configuration details
     * @param tenderId
     * @param formId
     * @param operation
     * @param commiteeType
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */
    @RequestMapping(value = {"/buyer/customizedreport/{tenderId}/{formId}/{operation}/{commiteeType}/{enc}"}, method = RequestMethod.GET)
    public String showTenderCustomizedReport(@PathVariable("tenderId") int tenderId,@PathVariable("formId") int formId,@PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        int linkId=linkOpeningCustomizeReport;
        if(commiteeType != 1)
        {
            linkId=linkEvalCustomizeReport;
        }
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                 modelMap.addAttribute("operation",operation);
                 modelMap.addAttribute("flag","1");
                
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                 if(operation == 2 && (request.getParameter("hdisPrintPriview")==null || request.getParameter("hdisPrintPriview").equalsIgnoreCase("0")))
                {
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
                Map<String,Object> outMap= tenderReportService.getCustomizeReportConfigDtl(tenderId,formId);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Form detail
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Table detail
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column Details
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender Row Details
                    {
                        modelMap.addAttribute("lstRowDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }
                    if(outMap.get(RESULTSET_5) !=null) // Bidder Details
                    {
                        modelMap.addAttribute("lstBidderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }
                }
                List<SelectItem> reportType = new ArrayList<SelectItem>();
                reportType.add(new SelectItem("Vertical", "1"));
                reportType.add(new SelectItem("Horizontal", "2"));
                modelMap.addAttribute("reportType", reportType);
                List<SelectItem> displayNobid = new ArrayList<SelectItem>();
                displayNobid.add(new SelectItem("With ‘No Bid’", "1"));
                displayNobid.add(new SelectItem("Without ‘No Bid’", "0"));
                modelMap.addAttribute("displayNobid", displayNobid);
                page = "/etender/buyer/TenderCustomizeReport";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderCustomizeReort, tenderId, formId);
        }
        return page;
    }
    
    /**
     * Method use for get customized report detail base on selection of filter criteria.
     * @param tenderId
     * @param formId
     * @param operation
     * @param commiteeType
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */
    @RequestMapping(value = {"/buyer/generatecustomizedreport/{tenderId}/{formId}/{operation}/{commiteeType}"}, method = RequestMethod.POST)
    public String generateCustomizeReport(@PathVariable("tenderId") int tenderId,@PathVariable("formId") int formId,@PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        int linkId=linkOpeningCustomizeReport;
        if(commiteeType != 1)
        {
            linkId=linkEvalCustomizeReport;
        }
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	int rowCnt=0;
            	int reportType = StringUtils.hasLength(request.getParameter("selreportType")) ? Integer.parseInt(request.getParameter("selreportType")) : 0;
            	int displayNobid = StringUtils.hasLength(request.getParameter("seldisplayNobid")) ? Integer.parseInt(request.getParameter("seldisplayNobid")) : 0;
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                 modelMap.addAttribute("operation",operation);
                 modelMap.addAttribute("flag","2");
                 modelMap.addAttribute("displayNobid",displayNobid);
                
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                if(!lstClientDtls.isEmpty()){
                    modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                    modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                }
                StringBuilder strRows=new StringBuilder("0"); 
                StringBuilder strColumns=new StringBuilder("0"); 
                StringBuilder strBidders=new StringBuilder("0"); 
                if(request.getParameter("chkbidder") !=null)
                {
                    for(String str:request.getParameterValues("chkbidder"))
                    {
                        strBidders.append(",").append(str);
                    }
                }
                else if (request.getParameter("hdStrBidder")!=null)
                {
                    strBidders.append(request.getParameter("hdStrBidder"));
                }
                modelMap.addAttribute("bidderIds",strBidders.toString());
                
                if(request.getParameter("chkrow") !=null)
                {
                    for(String str:request.getParameterValues("chkrow"))
                    {
                        strRows.append(",").append(str);
                        rowCnt++;
                    }
                }
                else if (request.getParameter("hdStrRow")!=null)
                {
                    strRows.append(request.getParameter("hdStrRow"));
                    rowCnt++;
                }
                modelMap.addAttribute("rowCnt",rowCnt);
                if(request.getParameter("chkcolumn") !=null)
                {
                    for(String str:request.getParameterValues("chkcolumn"))
                    {
                        strColumns.append(",").append(str);
                    }
                }
                else if (request.getParameter("hdStrColumn")!=null)
                {
                    strColumns.append(request.getParameter("hdStrColumn"));
                }
                modelMap.addAttribute("columnIds",strColumns.toString());
                 
                Map<String,Object> outMap= tenderReportService.getCustomizeReportDtl(tenderId,formId,strBidders.toString(),strColumns.toString(),strRows.toString());
                ArrayList<LinkedHashMap<String, Object>> tblTableDtl=null;
                ArrayList<LinkedHashMap<String, Object>> tblColumnDtl=null;
                ArrayList<LinkedHashMap<String, Object>> tblCompanyDtl=null;
                ArrayList<LinkedHashMap<String, Object>> lstBidDtl=null;
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        tblTableDtl=(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2);
                        modelMap.addAttribute("lstTableDtl",tblTableDtl );
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        tblColumnDtl=(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3);
                        modelMap.addAttribute("lstColumnDtl", tblColumnDtl);
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender cell - Filled by Officer
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }
                    if(outMap.get(RESULTSET_5) !=null) // Tender bidder 
                    {
                        tblCompanyDtl=(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5);
                        modelMap.addAttribute("lstCompanyDtl",tblCompanyDtl);
                    }
                    if(outMap.get(RESULTSET_6) !=null) // Tender bid 
                    {
                    	 lstBidDtl=(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6);
                         Map<String,String> mapBidData = new HashMap<String, String>();
                         Map<Integer,SortedSet<Integer>> custSelRow = new HashMap<Integer, SortedSet<Integer>>();
                         for (LinkedHashMap<String, Object> bidDtl : lstBidDtl) {
                             mapBidData.put(bidDtl.get("bidderId")+"_"+bidDtl.get("tableId")+"_"+bidDtl.get("columnId")+"_"+bidDtl.get("rowId"), bidDtl.get("cellValue").toString());
                             if(!custSelRow.isEmpty() && custSelRow.containsKey(Integer.parseInt(bidDtl.get("tableId").toString()))){
                             	SortedSet<Integer> oldSelRow = (SortedSet<Integer>) custSelRow.get(Integer.parseInt(bidDtl.get("tableId").toString()));
                             	oldSelRow.add(Integer.parseInt(bidDtl.get("rowId").toString()));
                             	custSelRow.put(Integer.parseInt(bidDtl.get("tableId").toString()), oldSelRow);
                             }else{
                             	SortedSet<Integer> newSelRow = new TreeSet<Integer>();
                             	newSelRow.add(Integer.parseInt(bidDtl.get("rowId").toString()));
                             	custSelRow.put(Integer.parseInt(bidDtl.get("tableId").toString()), newSelRow); 
                             }                            
                         }
                        modelMap.addAttribute("custSelRow",custSelRow);
                        modelMap.addAttribute("mapBidData",mapBidData);
                        modelMap.addAttribute("lstBidDtl",lstBidDtl);
                        
                        Map<String,String> mapBidMultiFillData = new HashMap<String, String>();
                        for (LinkedHashMap<String, Object> multiFillBidDtl : lstBidDtl) {
                            mapBidMultiFillData.put(multiFillBidDtl.get("bidderId")+"_"+multiFillBidDtl.get("tableId")+"_"+multiFillBidDtl.get("columnId")+"_"+multiFillBidDtl.get("rowId")+"_"+multiFillBidDtl.get("bidTableId"), multiFillBidDtl.get("cellValue").toString());
                        }
                        modelMap.addAttribute("mapBidMultiFillData",mapBidMultiFillData);
                        modelMap.addAttribute("lstMultiFillBidDtl",lstBidDtl);
                    }
                    if(outMap.get(RESULTSET_7) !=null) // Tender Form bidded multiple time 
                    {
                        modelMap.addAttribute("lstFormBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                    }
                    
                    if(outMap.get(RESULTSET_8) !=null) // Tender Table bidded multiple time by add row
                    {
                        modelMap.addAttribute("lstTableBid",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                    }   
                    
                    if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                    }
                    if(outMap.get(RESULTSET_10) !=null) // Multifilling Data 
                    {
                        modelMap.addAttribute("lstMultiTableRowCount",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                    }
                    if(outMap.get(RESULTSET_11) !=null) // Tender Proxy column Details
                    {
                        modelMap.addAttribute("lstTenderProxyDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_11) );
                    }
                    if(outMap.get(RESULTSET_12) !=null) // Item wise bidder Mapping Details
                    {
                        modelMap.addAttribute("lstItemWiseBidderMapDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_12) );
                    }
                    
                    // Set 0 value to grand total cell 
                    for(LinkedHashMap<String, Object> tableOb:tblTableDtl)
                    {
                        for(LinkedHashMap<String, Object> columnOb:tblColumnDtl)
                        {
                            if(columnOb.get("tableId").equals(tableOb.get("tableId")) && columnOb.get("formula")!=null && columnOb.get("formula").toString().contains("TOTAL"))
                            {
                                for(LinkedHashMap<String, Object> bidOb:lstBidDtl)
                                {
                                    if(bidOb.get("tableId").equals(columnOb.get("tableId")) && bidOb.get("columnId").equals(columnOb.get("columnId")) && bidOb.get("rowId").equals(tableOb.get("noOfRows")))
                                    {
                                        bidOb.put("cellValue", 0);
                                    }
                                }
                            }
                        }
                    }
                    
                    // Calculate Grand Total
                    for(LinkedHashMap<String, Object> tableOb:tblTableDtl)
                    {
                        for(LinkedHashMap<String, Object> columnOb:tblColumnDtl)
                        {
                            if(columnOb.get("tableId").equals(tableOb.get("tableId")) && columnOb.get("formula")!=null && columnOb.get("formula").toString().contains("TOTAL"))
                            {
                                for(LinkedHashMap<String, Object> bidOb:lstBidDtl)
                                {
                                    if(bidOb.get("tableId").equals(columnOb.get("tableId")) && bidOb.get("columnId").equals(columnOb.get("columnId")) && !bidOb.get("rowId").equals(tableOb.get("noOfRows")))
                                    {
                                        for(LinkedHashMap<String, Object> bidObSum:lstBidDtl)
                                        {
                                            if(bidObSum.get("bidId").equals(bidOb.get("bidId")) && bidObSum.get("bidTableId").equals(bidOb.get("bidTableId")) && bidObSum.get("tableId").equals(bidOb.get("tableId"))
                                              && bidObSum.get("columnId").equals(columnOb.get("columnId")) && bidObSum.get("rowId").equals(tableOb.get("noOfRows")))
                                            {
                                                bidObSum.put("cellValue",Double.parseDouble(bidOb.get("cellValue").toString()) + Double.parseDouble(bidObSum.get("cellValue").toString()));
                                            }
                                        } // ENd of bidder data loop
                                    }
                                } // ENd of bidder data loop
                            }
                        }// End of column loop
                        
                    }// End of table loop
                    
                    String wordColumnNo="";
                    // Calculate in words of grand total fileds
                    for(LinkedHashMap<String, Object> tableOb:tblTableDtl)
                    {
                        for(LinkedHashMap<String, Object> columnOb:tblColumnDtl)
                        {
                            if(columnOb.get("tableId").equals(tableOb.get("tableId")) && columnOb.get("formula")!=null && columnOb.get("formula").toString().contains("WORD"))
                            {
                                wordColumnNo=columnOb.get("formula").toString().substring(5, columnOb.get("formula").toString().length()-1);
                                for(LinkedHashMap<String, Object> bidOb:lstBidDtl)
                                {
                                    if(bidOb.get("tableId").equals(columnOb.get("tableId")) && bidOb.get("columnId").equals(columnOb.get("columnId")) && bidOb.get("rowId").equals(tableOb.get("noOfRows")))
                                    {
                                        for(LinkedHashMap<String, Object> bidObSum:lstBidDtl)
                                        {
                                            if(bidObSum.get("bidId").equals(bidOb.get("bidId")) && bidObSum.get("bidTableId").equals(bidOb.get("bidTableId")) && bidObSum.get("tableId").equals(bidOb.get("tableId"))
                                              && bidObSum.get("columnNo") !=null && bidObSum.get("columnNo").toString().equals(wordColumnNo) && bidObSum.get("rowId").equals(tableOb.get("noOfRows"))
                                               && bidObSum.get("cellValue")!=null && StringUtils.hasLength(bidObSum.get("cellValue").toString()))
                                            {
                                                bidOb.put("cellValue",numberToWorldConversion.doIt(new BigDecimal((bidObSum.get("cellValue").toString()))));
                                            }
                                        } // ENd of bidder data loop
                                    }
                                } // ENd of bidder data loop
                            }
                        }// End of column loop
                        
                    }// End of table loop
                    
                }
                if(reportType==2){
                	page = "/etender/buyer/CustRptHorizonalColWise";
                }else if(reportType==1){
                	page = "/etender/buyer/TenderCustomizeReport";
                }
                
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postTenderCustomizeReport, tenderId, formId);
        }
        return page;
    }
    
    /*
     * author : heeral.soni
     * used to generate tender sor report
     */
    @RequestMapping(value = {"/buyer/getsordetails/{tenderId}/{formId}/{commiteeType}/{enc}","buyer/negotiation/getsordetails/{tenderId}/{formId}/{commiteeType}/{enc}"}, method = RequestMethod.GET)
    public String getSORDetails(@PathVariable("tenderId") int tenderId,@PathVariable("formId") int formId,@PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String retVal =  "redirect:/sessionexpired";
        int singleColumnId = 0;
        int singleTableId = 0;
        int linkId=linkOpeningSORReport;
        if(commiteeType != 1)
        {
            linkId=linkEvaluationSORReport;
        }
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                modelMap.addAttribute("lstTenderFormDetail", tenderReportService.getTenderFormDetails(formId).get(0)); // for getting formname/header/footer
                modelMap.addAttribute("requestURL",request.getRequestURI().contains("/buyer/negotiation/getsordetails"));
                //modelMap.addAttribute("lstTenderFormDetail", tenderReportService.getTenderFormDetails(formId).get(0)); // for getting formname/header/footer
                List<Object[]> lstSORColumnDetail = tenderReportService.getSORColumnDetails(formId);//for get columnIds
                
                if(!lstSORColumnDetail.isEmpty()){
                        List<Integer> tableId = new ArrayList<Integer>();
                        for (Object[] tableList : lstSORColumnDetail) {
                            tableId.add((Integer)tableList[2]);
                            singleColumnId = (Integer)tableList[1];
                            singleTableId = (Integer)tableList[2];
                        }
                        List<Object[]> lstTenderTableDetail = tenderReportService.getTenderTableDetail(tableId);
                        modelMap.addAttribute("lstTenderTableDetail", lstTenderTableDetail);
                        
                        List<SelectItem> lstColumnDtl = null;
                        SelectItem s = null;
                        if(lstTenderTableDetail!=null && !lstTenderTableDetail.isEmpty())
                        {
                            for(Object[] lstT:lstTenderTableDetail)
                            {
                                lstColumnDtl = new ArrayList<SelectItem>();
                                for(Object[] lst:lstSORColumnDetail)
                                {
                                    if(lst[2].equals(lstT[0]))
                                    {
                                        s = new SelectItem(lst[0],lst[1]);
                                        lstColumnDtl.add(s);
                                    }
                                }
                                modelMap.addAttribute("lstColumnDtl_"+lstT[0], lstColumnDtl);
                            }
                            modelMap.addAttribute("formId",formId);
                        }
                        if(lstSORColumnDetail.size() == 1){
                    	retVal = "redirect:/etender/buyer/generatedirectsorreport/"+tenderId+"/"+formId+"/"+singleColumnId+"/"+singleTableId+"/"+commiteeType +encryptDecryptUtils.generateRedirect("etender/buyer/generatedirectsorreport/"+tenderId+"/"+formId+"/"+singleColumnId+"/"+singleTableId+"/"+commiteeType, request);
                    }else{
                    	retVal = "/etender/buyer/TenderSORColumn";//selection wise report generated
                    }
                }
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderSORReort, tenderId, formId);
        }
        return retVal;
    }
    
    @RequestMapping(value = {"/buyer/generatedirectsorreport/{tenderId}/{formId}/{columnId}/{tableId}/{commiteeType}/{enc}"}, method = RequestMethod.GET)
    public String generateDirectSORReport(@PathVariable("tenderId") int tenderId,@PathVariable("formId") int formId,@PathVariable("columnId") int columnId,@PathVariable("tableId") int tableId,@PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
     String retVal = "redirect:/sessionexpired";
     int linkId=linkOpeningSORReport;
        if(commiteeType != 1)
        {
            linkId=linkEvaluationSORReport;
        }
     try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                modelMap.addAttribute("lstTenderFormDetail", tenderReportService.getTenderFormDetails(formId).get(0)); // for getting formname/header/footer
                modelMap.addAttribute("lstTenderTableDetail", tenderCommonService.getTenderTableByFormId(formId));
                modelMap.addAttribute("commiteeType",commiteeType);
                modelMap.addAttribute("selectedColumnId_"+tableId, columnId);
                List<Object[]> lstSORColumnDetail = tenderReportService.getSORColumnDetails(formId);//for get columnIds
                
                if(!lstSORColumnDetail.isEmpty()){
                        List<Integer> tabId = new ArrayList<Integer>();
                        for (Object[] tableList : lstSORColumnDetail) {
                            tabId.add((Integer)tableList[2]);
                        }
                        List<Object[]> lstTenderTableDetail = tenderReportService.getTenderTableDetail(tabId);
                        modelMap.addAttribute("lstTenderTableDetail1", lstTenderTableDetail);
                }
                Map<String,Object> outMap= tenderReportService.getSORReportDtl(tenderId,formId,tableId,"",0,1,columnId);
                //System.out.println("outMap = " + outMap.toString());
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstTableDtl_"+tableId,(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstColumnDtl_"+tableId,(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }  
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstItemDtl_"+tableId,(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender Cell
                    {
                        modelMap.addAttribute("lstBidderDtl_"+tableId,(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }   
                }
                retVal = "/etender/buyer/ManageTenderSOR";
            }
         } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
         } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postTenderSORReport, tenderId, formId);
         }
        return retVal;
    }
    
    /**
     * Method use for get SOR report configuration details
     * @param tenderId
     * @param formId
     * @param operation
     * @param commiteeType
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */
    @RequestMapping(value = {"/buyer/sorreport/{tenderId}/{formId}/{operation}/{commiteeType}/{enc}", "buyer/negotiation/sorreport/{tenderId}/{formId}/{operation}/{commiteeType}/{enc}"}, method=RequestMethod.GET)
    public String showSORReport(@PathVariable("tenderId") int tenderId,@PathVariable("formId") int formId,@PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        int linkId=linkOpeningSORReport;
        if(commiteeType != 1)
        {
            linkId=linkEvaluationSORReport;
        }
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                 modelMap.addAttribute("operation",operation);
                 modelMap.addAttribute("flag","1");
                 modelMap.addAttribute("requestURL",request.getRequestURI().contains("/buyer/negotiation/sorreport"));
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                 if(operation == 2 && (request.getParameter("hdisPrintPriview")==null || request.getParameter("hdisPrintPriview").equalsIgnoreCase("0")))
                {
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
                Map<String,Object> outMap= tenderReportService.getSORReportConfigDtl(tenderId,formId);
                if(outMap != null && !outMap.isEmpty())
                {
                    ArrayList<LinkedHashMap<String, Object>> lstTable=null;
                    if(outMap.get(RESULTSET_1) !=null) // Form detail
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Table detail
                    {
                        lstTable=(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2);
                        modelMap.addAttribute("lstTableDtl", lstTable);
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column Details
                    {
                        ArrayList<LinkedHashMap<String, Object>> lstColumn=(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3);
                        List<SelectItem> lstColumnDtl = null;
                        SelectItem s = null;
                        if(lstTable!=null && !lstTable.isEmpty())
                        {
                            for(LinkedHashMap<String, Object> lstT:lstTable)
                            {
                                lstColumnDtl = new ArrayList<SelectItem>();
                                if(lstColumn !=null && !lstColumn.isEmpty())
                                {
                                    for(LinkedHashMap<String, Object> lst:lstColumn)
                                    {
                                        if(lst.get("tableId").equals(lstT.get("tableId")))
                                        {
                                            s = new SelectItem(lst.get("columnHeader"),lst.get("columnId"));
                                            lstColumnDtl.add(s);
                                        }
                                    }
                                }
                                modelMap.addAttribute("lstColumnDtl_"+lstT.get("tableId"), lstColumnDtl);
                            }
                        }
                        
                    }
                }
                page = "/etender/buyer/TenderSORReport";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getTenderSORReort, tenderId, formId);
        }
        return page;
    }
    
    /*
     * author : heeral.soni
     * 
     */
    @RequestMapping(value = {"/buyer/generatetendersorreport/{tenderId}/{formId}/{operation}/{committeeType}","/buyer/negotiation/generatetendersorreport/{tenderId}/{formId}/{operation}/{committeeType}"}, method = RequestMethod.POST)
    public String generateTenderSORReport(@PathVariable("tenderId") int tenderId,@PathVariable("formId") int formId,@PathVariable("operation") int operation,@PathVariable("committeeType") int committeeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
     String retVal = "redirect:/sessionexpired";
     int linkId=linkOpeningSORReport;
     if(committeeType != 1)
     {
        linkId=linkEvaluationSORReport;
     }
     try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
        	    modelMap.addAttribute("committeeType",committeeType);
                modelMap.addAttribute("operation",operation);
                modelMap.addAttribute("requestURL",request.getRequestURI().contains("/buyer/negotiation/generatetendersorreport"));
                modelMap.addAttribute("lstTenderFormDetail", tenderReportService.getTenderFormDetails(formId).get(0)); // for getting formname/header/footer
                List<TblTenderTable> lstTable=tenderCommonService.getTenderTableByFormId(formId);
                modelMap.addAttribute("lstTenderTableDetail", lstTable);
                TblNegotiationSORRemarks tblBidFormSORRemarks=tenderFormService.getTenderNegotiationSORRemarks(formId,60);
                TblNegotiationSORRemarks tblNegotiationSORRemarks=tenderFormService.getTenderNegotiationSORRemarks(formId,240);
            	if(tblBidFormSORRemarks!=null){
            	   modelMap.addAttribute("remarks",tblBidFormSORRemarks.getRemarks());
            	}
            	if(tblNegotiationSORRemarks!=null){
             	   modelMap.addAttribute("Negotiationremarks",tblNegotiationSORRemarks.getRemarks());
             	}
                List<Object[]> lstSORColumnDetail = tenderReportService.getSORColumnDetails(formId);//for get columnIds
                
                if(!lstSORColumnDetail.isEmpty()){
                        List<Integer> tableId = new ArrayList<Integer>();
                        for (Object[] tableList : lstSORColumnDetail) {
                            tableId.add((Integer)tableList[2]);
                        }
                        List<Object[]> lstTenderTableDetail = tenderReportService.getTenderTableDetail(tableId);
                        modelMap.addAttribute("lstTenderTableDetail1", lstTenderTableDetail);
                }
                
                if(lstTable!=null && !lstTable.isEmpty())
                {
                    int columnId = 0;
                    for(TblTenderTable tblTenderTable:lstTable)
                    {
                        if(request.getParameter("rdcolumn_"+tblTenderTable.getTableId()) !=null)
                        {
                            columnId = Integer.parseInt(request.getParameter("rdcolumn_"+tblTenderTable.getTableId()));
                        }
                        modelMap.addAttribute("selectedColumnId_"+tblTenderTable.getTableId(), columnId);
                        Map<String,Object> outMap= tenderReportService.getSORReportDtl(tenderId,formId,tblTenderTable.getTableId(),"",0,1,columnId);
                        //System.out.println("outMap = " + outMap.toString());
                        if(outMap != null && !outMap.isEmpty())
                        {
                            if(outMap.get(RESULTSET_1) !=null) // Tender Form
                            {
                                modelMap.addAttribute("lstTableDtl_"+tblTenderTable.getTableId(),(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                            }
                            if(outMap.get(RESULTSET_2) !=null) // Tender Table
                            {
                                modelMap.addAttribute("lstColumnDtl_"+tblTenderTable.getTableId(),(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                            }  
                            if(outMap.get(RESULTSET_3) !=null) // Tender Column
                            {
                                modelMap.addAttribute("lstItemDtl_"+tblTenderTable.getTableId(),(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                            }
                            if(outMap.get(RESULTSET_4) !=null) // Tender Cell
                            {
                                modelMap.addAttribute("lstBidderDtl_"+tblTenderTable.getTableId(),(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                            }   
                        }
                    } // end of for loop
                }
                retVal = "/etender/buyer/ManageTenderSOR";
            }
         } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
         } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postTenderSORReport, tenderId, formId);
         }
        return retVal;
    }
    
    
    
    /**
     * Method use for get generate SOR report.
     * @param tenderId
     * @param formId
     * @param operation
     * @param commiteeType
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */
    @RequestMapping(value = {"/buyer/generatesorreport/{tenderId}/{formId}/{operation}/{commiteeType}","/buyer/negotiation/generatesorreport/{tenderId}/{formId}/{operation}/{commiteeType}"}, method = RequestMethod.POST)
    public String generateSORReport(@PathVariable("tenderId") int tenderId,@PathVariable("formId") int formId,@PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        int linkId=linkOpeningSORReport;
        if(commiteeType != 1)
        {
            linkId=linkEvaluationSORReport;
        }
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	 tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                 modelMap.addAttribute("operation",operation);
                 modelMap.addAttribute("flag","2");
                 modelMap.addAttribute("commiteeType", commiteeType);
                 modelMap.addAttribute("requestURL",request.getRequestURI().contains("/buyer/negotiation/generatesorreport"));
                 TblNegotiationSORRemarks tblBidFormSORRemarks=tenderFormService.getTenderNegotiationSORRemarks(formId,60);
                 TblNegotiationSORRemarks tblBidnegotiationSORRemarks=tenderFormService.getTenderNegotiationSORRemarks(formId,240);
                 if(tblBidFormSORRemarks!=null)
                {
                 		modelMap.addAttribute("remarks",tblBidFormSORRemarks.getRemarks());
                }    
                 if(tblBidnegotiationSORRemarks!=null)
                 {
                	 modelMap.addAttribute("Negotiationremarks",tblBidnegotiationSORRemarks.getRemarks());
                 }
                 if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                 if(operation == 2 && (request.getParameter("hdisPrintPriview")==null || request.getParameter("hdisPrintPriview").equalsIgnoreCase("0")))
                {
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
                 
                StringBuilder strColumns=new StringBuilder("0"); 
                if(operation == 1)
                {
                    List<TblTenderTable> lstTable=tenderCommonService.getTenderTableByFormId(formId);
                    if(lstTable!=null && !lstTable.isEmpty())
                    {
                        for(TblTenderTable tblTenderTable:lstTable)
                        {
                             if(request.getParameter("rdcolumn_"+tblTenderTable.getTableId()) !=null)
                            {
                                strColumns.append(",").append(request.getParameter("rdcolumn_"+tblTenderTable.getTableId()));
                            }
                        }
                    }
                }
                else if (request.getParameter("hdStrColumn")!=null)
                {   
                    strColumns.append(request.getParameter("hdStrColumn"));
                }
                modelMap.addAttribute("columnIds",strColumns.toString());
                 
                //Map<String,Object> outMap= tenderReportService.getSORReportDtl(tenderId,formId,strColumns.toString());
                Map<String,Object> outMap= tenderReportService.getSORReportDtl(tenderId,formId,0,strColumns.toString(),0,0,0);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }  
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3  ) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender Cell
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }   
                    if(outMap.get(RESULTSET_5) !=null) // Bidder Data
                    {
                        modelMap.addAttribute("lstBidderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }   
                    if(outMap.get(RESULTSET_6) !=null) // Tender SOR Details
                    {
                        modelMap.addAttribute("lstSorDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                    }
                    if(outMap.get(RESULTSET_7) !=null) // Tender Bid Details
                    {
                        modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                    }
                    if(outMap.get(RESULTSET_8) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                    }
                }
                page = "/etender/buyer/TenderSORReport";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postTenderSORReport, tenderId, formId);
        }
        return page;
    }
    
    @RequestMapping(value = {"/buyer/addsorreportremarks/{tenderId}/{formId}/{operation}/{commiteeType}"}, method = RequestMethod.POST)
    public String addSORReportRemarks(@PathVariable("tenderId") int tenderId,@PathVariable("formId") int formId,@PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession sessio,RedirectAttributes redirectAttributes){
    	boolean success = false;
        String SORRemarks = null;
        boolean flag = false;
        String page = ""; 
        int UserId = abcUtility.getSessionUserId(request);
        TblNegotiationSORRemarks tblNegotiationSORRemarks =new TblNegotiationSORRemarks();
    	try{
    		SORRemarks = StringUtils.hasLength(request.getParameter("txtaRemarks")) ? request.getParameter("txtaRemarks") : null;
    		tblNegotiationSORRemarks.setParentId(tenderId);
            tblNegotiationSORRemarks.setObjectId(formId);
            tblNegotiationSORRemarks.setEventId(60);
            tblNegotiationSORRemarks.setRemarks(SORRemarks);
            /*if(!isEdit){*/
            	tblNegotiationSORRemarks.setCreatedBy(UserId);
                tblNegotiationSORRemarks.setCreatedOn(commonService.getServerDateTime());
            /*}*/
            tblNegotiationSORRemarks.setUpdatedBy(UserId);
            tblNegotiationSORRemarks.setUpdatedOn(commonService.getServerDateTime());
            success=tenderFormService.saveTblNegotiationSORRemarks(tblNegotiationSORRemarks);
            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "add_sorremarks_success_bidopen" : CommonKeywords.ERROR_MSG_KEY.toString());
    	}
    	catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, addTenderSORRemarks, tenderId, formId, null);
    	}
    	page="/etender/buyer/tenderdashboard/"+tenderId+"/7";
    	return "redirect:/" + page + encryptDecryptUtils.generateRedirect(page, request);
    	
    }
    
    @RequestMapping(value = {"/buyer/negotiation/addsorreportremarks/{tenderId}/{formId}/{operation}/{commiteeType}"}, method = RequestMethod.POST)
    public String addNegotiationSORReportRemarks(@PathVariable("tenderId") int tenderId,@PathVariable("formId") int formId,@PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession sessio,RedirectAttributes redirectAttributes){
    	boolean success = false;
        String SORRemarks = null;
        boolean flag = false;
        String page = ""; 
        int UserId = abcUtility.getSessionUserId(request);
        TblNegotiationSORRemarks tblNegotiationSORRemarks =new TblNegotiationSORRemarks();
    	try{
    		SORRemarks = StringUtils.hasLength(request.getParameter("txtaNegotiationremarks")) ? request.getParameter("txtaNegotiationremarks") : null;
    		tblNegotiationSORRemarks.setParentId(tenderId);
            tblNegotiationSORRemarks.setObjectId(formId);
            tblNegotiationSORRemarks.setEventId(240);
            tblNegotiationSORRemarks.setRemarks(SORRemarks);
            /*if(!isEdit){*/
            	tblNegotiationSORRemarks.setCreatedBy(UserId);
                tblNegotiationSORRemarks.setCreatedOn(commonService.getServerDateTime());
            /*}*/
            tblNegotiationSORRemarks.setUpdatedBy(UserId);
            tblNegotiationSORRemarks.setUpdatedOn(commonService.getServerDateTime());
            success=tenderFormService.saveTblNegotiationSORRemarks(tblNegotiationSORRemarks);
            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "add_sorremarks_success_bidopen" : CommonKeywords.ERROR_MSG_KEY.toString());
    	}
    	catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, addTenderSORRemarks, tenderId, formId, null);
    	}
    	//return "redirect:/etender/buyer/sorreport/" + tenderId + "/" + formId + "/"+ operation + "/"+ commiteeType +  encryptDecryptUtils.generateRedirect(new StringBuilder("etender/buyer/sorreport/").append(tenderId).append("/").append(formId).append("/").append(operation).append("/").append(commiteeType).toString(), request);
    	
    	page="/etender/buyer/tenderdashboard/"+tenderId+"/11";
    	 return "redirect:/" + page + encryptDecryptUtils.generateRedirect(page, request);
    	
    }
    
    
    @RequestMapping(value = {"/buyer/managementreport/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String managementReport(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        
        int linkId=1125;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                Map<String,Object> outMap= tenderReportService.getManagementReport(tenderId);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }  
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3  ) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender Cell
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }   
                    if(outMap.get(RESULTSET_5) !=null) // Bidder Data
                    {
                        modelMap.addAttribute("lstBidderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }   
                    if(outMap.get(RESULTSET_6) !=null) // Tender SOR Details
                    {
                        modelMap.addAttribute("lstSorDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                    }
                    if(outMap.get(RESULTSET_7) !=null) // Tender Bid Details
                    {
                        modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                    }
                    if(outMap.get(RESULTSET_8) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                    }
                    if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderNegotiationDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                    }
                    if(outMap.get(RESULTSET_10) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderNegotiationDtlTemp",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                    }
                }
                page = "/etender/buyer/ManagementReport";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewManagementReport, tenderId, 0);
        }
        return page;
    }
    
    @RequestMapping(value = {"/buyer/managementReportCustomize/{tenderId}"}, method = RequestMethod.POST)
    public String managementReportCustomize(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        
        int linkId=1125;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                
                Set<Integer> setForms = new HashSet<Integer>();
                Set<Map<String, Integer>> setFormTable = new HashSet<Map<String,Integer>>();
                Set<Map<String, Integer>> setFormTableColumn = new HashSet<Map<String,Integer>>();
                String[] chkColumn = request.getParameterValues("chkColumn");
                if(chkColumn != null){
	                for (int i = 0; i < chkColumn.length; i++) {
						String[] temp = chkColumn[i].split("_");
						int frmId = Integer.parseInt(temp[0]);
						int tableId = Integer.parseInt(temp[1]);
						int columnId = Integer.parseInt(temp[2]);
						setForms.add(frmId);
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						setFormTable.add(map);
						map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						map.put("columnId", columnId);
						setFormTableColumn.add(map);
					}
                }
                
                Set<Map<String, Integer>> setFormTableBidder = new HashSet<Map<String,Integer>>();
                String[] chkBidder = request.getParameterValues("chkBidder");
                if(chkBidder != null){
	                for (int i = 0; i < chkBidder.length; i++) {
	                	String[] temp = chkBidder[i].split("_");
						int frmId = Integer.parseInt(temp[0]);
						int tableId = Integer.parseInt(temp[1]);
						int bidderId = Integer.parseInt(temp[2]);
						setForms.add(frmId);
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						setFormTable.add(map);
						map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						map.put("bidderId", bidderId);
						setFormTableBidder.add(map);
					}
                }
                
                Set<Map<String, Integer>> setFormTableRow = new HashSet<Map<String,Integer>>();
                String[] chkItem = request.getParameterValues("chkItem");
                if(chkItem != null){
	                for (int i = 0; i < chkItem.length; i++) {
	                	String[] temp = chkItem[i].split("_");
						int frmId = Integer.parseInt(temp[0]);
						int tableId = Integer.parseInt(temp[1]);
						int rowId = Integer.parseInt(temp[2]);
						setForms.add(frmId);
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						setFormTable.add(map);
						map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						map.put("rowId", rowId);
						setFormTableRow.add(map);
					}
                }
                modelMap.addAttribute("setForms",setForms);
                modelMap.addAttribute("setFormTable",setFormTable);
                modelMap.addAttribute("setFormTableColumn",setFormTableColumn);
                modelMap.addAttribute("setFormTableBidder",setFormTableBidder);
                modelMap.addAttribute("setFormTableRow",setFormTableRow);
                Map<String,Object> outMap= tenderReportService.getManagementReport(tenderId);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }  
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3  ) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender Cell
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }   
                    if(outMap.get(RESULTSET_5) !=null) // Bidder Data
                    {
                        modelMap.addAttribute("lstBidderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }   
                    if(outMap.get(RESULTSET_6) !=null) // Tender SOR Details
                    {
                        modelMap.addAttribute("lstSorDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                    }
                    if(outMap.get(RESULTSET_7) !=null) // Tender Bid Details
                    {
                        modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                    }
                    if(outMap.get(RESULTSET_8) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                    }
                    if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderNegotiationDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                    }
                    if(outMap.get(RESULTSET_10) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderNegotiationDtlTemp",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                    }
                }
                page = "/etender/buyer/ManagementReportCustomize";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewCustomizeManagementReport, tenderId, 0);
        }
        return page;
    }
    
    @RequestMapping(value = {"/buyer/managementreportverticalview/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String managementReportVerticalview(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        
        int linkId=1125;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                 
                 
                Map<String,Object> outMap= tenderReportService.getManagementReport(tenderId);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }  
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3  ) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender Cell
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }   
                    if(outMap.get(RESULTSET_5) !=null) // Bidder Data
                    {
                        modelMap.addAttribute("lstBidderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }   
                    if(outMap.get(RESULTSET_6) !=null) // Tender SOR Details
                    {
                        modelMap.addAttribute("lstSorDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                    }
                    if(outMap.get(RESULTSET_7) !=null) // Tender Bid Details
                    {
                        modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                    }
                    if(outMap.get(RESULTSET_8) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                    }
                    if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderNegotiationDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                    }
                    if(outMap.get(RESULTSET_10) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderNegotiationDtlTemp",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                    }
                }
                page = "/etender/buyer/ManagementReportVerticalView";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewManagementReportVertical, tenderId, 0);
        }
        return page;
    }
    @RequestMapping(value = {"/buyer/managementReportVerticalviewCustomize/{tenderId}"}, method = RequestMethod.POST)
    public String managementReportVerticalviewCustomize(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        
        
        int linkId=1125;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                 
                Set<Integer> setForms = new HashSet<Integer>();
                Set<Map<String, Integer>> setFormTable = new HashSet<Map<String,Integer>>();
                Set<Map<String, Integer>> setFormTableColumn = new HashSet<Map<String,Integer>>();
                String[] chkColumn = request.getParameterValues("chkColumn");
                if(chkColumn != null){
	                for (int i = 0; i < chkColumn.length; i++) {
						String[] temp = chkColumn[i].split("_");
						int frmId = Integer.parseInt(temp[0]);
						int tableId = Integer.parseInt(temp[1]);
						int columnId = Integer.parseInt(temp[2]);
						setForms.add(frmId);
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						setFormTable.add(map);
						map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						map.put("columnId", columnId);
						setFormTableColumn.add(map);
					}
                }
                
                Set<Map<String, Integer>> setFormTableBidder = new HashSet<Map<String,Integer>>();
                String[] chkBidder = request.getParameterValues("chkBidder");
                if(chkBidder != null){
	                for (int i = 0; i < chkBidder.length; i++) {
	                	String[] temp = chkBidder[i].split("_");
						int frmId = Integer.parseInt(temp[0]);
						int tableId = Integer.parseInt(temp[1]);
						int bidderId = Integer.parseInt(temp[2]);
						setForms.add(frmId);
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						setFormTable.add(map);
						map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						map.put("bidderId", bidderId);
						setFormTableBidder.add(map);
					}
                }
                
                Set<Map<String, Integer>> setFormTableRow = new HashSet<Map<String,Integer>>();
                String[] chkItem = request.getParameterValues("chkItem");
                if(chkItem != null){
	                for (int i = 0; i < chkItem.length; i++) {
	                	String[] temp = chkItem[i].split("_");
						int frmId = Integer.parseInt(temp[0]);
						int tableId = Integer.parseInt(temp[1]);
						int rowId = Integer.parseInt(temp[2]);
						setForms.add(frmId);
						Map<String, Integer> map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						setFormTable.add(map);
						map = new HashMap<String, Integer>();
						map.put("formId", frmId);
						map.put("tableId", tableId);
						map.put("rowId", rowId);
						setFormTableRow.add(map);
					}
                }
                modelMap.addAttribute("setForms",setForms);
                modelMap.addAttribute("setFormTable",setFormTable);
                modelMap.addAttribute("setFormTableColumn",setFormTableColumn);
                modelMap.addAttribute("setFormTableBidder",setFormTableBidder);
                modelMap.addAttribute("setFormTableRow",setFormTableRow); 
                
                Map<String,Object> outMap= tenderReportService.getManagementReport(tenderId);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }  
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3  ) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender Cell
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }   
                    if(outMap.get(RESULTSET_5) !=null) // Bidder Data
                    {
                        modelMap.addAttribute("lstBidderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }   
                    if(outMap.get(RESULTSET_6) !=null) // Tender SOR Details
                    {
                        modelMap.addAttribute("lstSorDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                    }
                    if(outMap.get(RESULTSET_7) !=null) // Tender Bid Details
                    {
                        modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_7) );
                    }
                    if(outMap.get(RESULTSET_8) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_8) );
                    }
                    if(outMap.get(RESULTSET_9) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderNegotiationDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_9) );
                    }
                    if(outMap.get(RESULTSET_10) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderNegotiationDtlTemp",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_10) );
                    }
                }
                page = "/etender/buyer/ManagementReportVerticalViewCustomize";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewCustomizeManagementReportVertical, tenderId, 0);
        }
        return page;
    }
    @RequestMapping(value = {"/buyer/getitemwisel1reportafterloading/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String getItemwiseL1ReportAfterLoading(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        
        int linkId=1123;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                modelMap.addAttribute("flag","1");
                List<SelectItem> selectItems = new ArrayList<SelectItem>();
                SelectItem s = new SelectItem("Unit rate after loading",27);
                selectItems.add(s);
                s = new SelectItem("Total rate after loading",26);
                selectItems.add(s);
                modelMap.addAttribute("selRadio",selectItems);
                page = "/etender/buyer/ItemwiseL1ReportAfterLoading";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, OpenItemwiseL1ReportAfterLoading, tenderId, 0);
        }
        return page;
    }
    
    @RequestMapping(value = {"/buyer/itemwisel1reportafterloading/{tenderId}"}, method = RequestMethod.POST)
    public String itemwiseL1ReportAfterLoading(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    	int reportType = 1;
    	if(request.getParameter("rdReportType") !=null)
        {
    		reportType = Integer.parseInt(request.getParameter("rdReportType"));
        }
    	String page="";  
        
        int linkId=1123;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                 modelMap.addAttribute("flag","2");
                 
                 
                Map<String,Object> outMap= tenderReportService.getItemwiseL1ReportAfterLoading(tenderId,reportType);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Tender Table
                    {
                        modelMap.addAttribute("lstTableDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }  
                    if(outMap.get(RESULTSET_3) !=null) // Tender Column
                    {
                        modelMap.addAttribute("lstColumnDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3  ) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender Cell
                    {
                        modelMap.addAttribute("lstCellDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }   
                    if(outMap.get(RESULTSET_5) !=null) // Tender Bid Details
                    {
                        modelMap.addAttribute("lstBidDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_5) );
                    }
                    if(outMap.get(RESULTSET_6) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("lstTenderDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_6) );
                    }
                }
                modelMap.addAttribute("reportType",reportType);
                page = "/etender/buyer/ItemwiseL1ReportAfterLoading";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewItemwiseL1ReportAfterLoading, tenderId, 0);
        }
        return page;
    }
    
    @RequestMapping(value = {"/buyer/negotiationsummeryreport/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String negotiationSummeryReport(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    	String page="";  
        int linkId=602;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            	tenderFormService.setNegotiationSummeryData(modelMap,tenderId);
            	List<TblNegotiationResult> listgetNegotiationResult= negotiationService.getNegotiationResultIswinner(tenderId);
            	List<Object[]> govColumnData = new ArrayList<Object[]>();
            	govColumnData=negotiationService.getTenderGovColumn(tenderId);
            	HashMap<String, String> eventType = new HashMap<String, String>();
            	if(govColumnData!=null)
            	{
            		for(Object[] object:govColumnData)
            		{
            			eventType.put(object[2].toString(),object[3].toString());
            		}
            	}
            	Map<String, Boolean> negotiationResultMap = new HashMap<String, Boolean>();
            	if(listgetNegotiationResult != null){
	            	for (TblNegotiationResult tblNegotiationResult : listgetNegotiationResult) {
	            		negotiationResultMap.put(tblNegotiationResult.getCompanyId()+"_"+tblNegotiationResult.getFormId()+"_"+tblNegotiationResult.getTableId()+"_"+tblNegotiationResult.getRowId(), true);
					}
            	}
            	modelMap.addAttribute("winSelForNegotiationResult",negotiationResultMap);
            	modelMap.addAttribute("eventType",eventType);
            	page = "common/negotiation/buyer/NegotiationSummaryNew";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewNegotiationSummaryReport, tenderId, 0);
        }
        return page;
    }
    
    @RequestMapping(value = {"/buyer/savenegotiationsummeryreport/{tenderId}"}, method = RequestMethod.POST)
    public String savenNegotiationSummeryReport(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    	String page="";  
        int linkId=602;
        int dynReportColId=0;
		int reportId=0;
		int govColId=0;
		BigDecimal reNegotiatedRate=BigDecimal.ZERO;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	Enumeration<String> paramNames = request.getParameterNames();
            	List<String> listSelectedRadio = new ArrayList<String>();
            	List<String> listallValue= new ArrayList<String>();
            	while(paramNames.hasMoreElements()) {
            		String paramName = (String)paramNames.nextElement();
            		if(paramName.startsWith("rdSelecteL1")){
            			listSelectedRadio.add(paramName);
            		}
            		if(paramName.startsWith("hdallValue")){
            			listallValue.add(paramName);
            		}
            	}
            	Map<String,TblNegotiationResult> negotiationResultMap=new HashMap<String, TblNegotiationResult>();
            	List<TblNegotiationResult> listForSaveAllNegotiationResult=new ArrayList<TblNegotiationResult>();
            	List<TblNegotiationResult> listForUpdateSelectedTblNegotiationResults=new ArrayList<TblNegotiationResult>();
            	boolean isExist=negotiationService.isCheckNegotiationResultExist(tenderId);
            	if(!isExist)
            	{
            		for (String string : listallValue) 
	            	{
	            		String params = StringUtils.hasLength(request.getParameter(string)) ? request.getParameter(string) : "";
	            		String[] paramsAsArray = params.split("_");
						int companyId = StringUtils.hasLength(paramsAsArray[0]) ? Integer.parseInt(paramsAsArray[0]) : 0;
						int formId = StringUtils.hasLength(paramsAsArray[1]) ? Integer.parseInt(paramsAsArray[1]) : 0;
						int rowId = StringUtils.hasLength(paramsAsArray[2]) ? Integer.parseInt(paramsAsArray[2]) : 0;
						int tableId = StringUtils.hasLength(paramsAsArray[3]) ? Integer.parseInt(paramsAsArray[3]) : 0;
						int negotiationId=StringUtils.hasLength(paramsAsArray[4]) ? Integer.parseInt(paramsAsArray[4]) : 0;
						double L1Amount=StringUtils.hasLength(paramsAsArray[5]) ? Double.parseDouble(paramsAsArray[5]) : 0;
						double negotiatedL1Amount=StringUtils.hasLength(paramsAsArray[6]) ? Double.parseDouble(paramsAsArray[6]) : 0;
	            		TblNegotiationResult tblNegotiationResult=new TblNegotiationResult();
						tblNegotiationResult.setObjectId(tenderId);
	  					tblNegotiationResult.setNegotiationId(negotiationId);
	  					tblNegotiationResult.setCompanyId(companyId);
	  					tblNegotiationResult.setFormId(formId);
	  					tblNegotiationResult.setTableId(tableId);
	  					tblNegotiationResult.setRowId(rowId);
	  					tblNegotiationResult.setL1Amount(BigDecimal.valueOf(L1Amount));
	  					tblNegotiationResult.setNegotiatedL1Amount(BigDecimal.valueOf(negotiatedL1Amount));
	  					tblNegotiationResult.setIsWinner(0);
	  					tblNegotiationResult.setCreatedOn(commonService.getServerDateTime());
	  					tblNegotiationResult.setCreatedBy(abcUtility.getSessionUserId(request));
	  					tblNegotiationResult.setUpdatedOn(commonService.getServerDateTime());
	  					tblNegotiationResult.setUpdatedBy(abcUtility.getSessionUserId(request));
	  					listForSaveAllNegotiationResult.add(tblNegotiationResult);
	  					negotiationResultMap.put(tenderId+"~"+companyId+"~"+formId+"~"+tableId+"~"+rowId+"~"+negotiationId,tblNegotiationResult);
	            	}
            		negotiationService.saveUpdateAllTblNegotiationResult(listForSaveAllNegotiationResult);
            	}	
            	else
            	{
            		List<TblNegotiationResult> negotiationResultList=negotiationService.isCheckNegotiationResult(tenderId);
            		if(negotiationResultList!=null)
            		{
            			for (int i=0;i<negotiationResultList.size(); i++) 
    					{
    						negotiationResultMap.put(negotiationResultList.get(i).getObjectId()+"~"+negotiationResultList.get(i).getCompanyId()+"~"+negotiationResultList.get(i).getFormId()+"~"+negotiationResultList.get(i).getTableId()+"~"+negotiationResultList.get(i).getRowId()+"~"+negotiationResultList.get(i).getNegotiationId(),negotiationResultList.get(i));
    					}
            		}
            	}
            	double total_negotiatedL1Amount=0.0;
            	double total_L1Amount=0.0;
            	for (String string : listSelectedRadio) 
            	{
            		String[] temp = string.split("_");
            		int temp_tenderId=tenderId;
            		String params = StringUtils.hasLength(request.getParameter(string)) ? request.getParameter(string) : "";
            		String[] paramsAsArray = params.split("_");
            		int tableId = StringUtils.hasLength(temp[1]) ? Integer.parseInt(temp[1]) : 0;
					int rowId = StringUtils.hasLength(temp[2]) ? Integer.parseInt(temp[2]) : 0;
					int companyId = StringUtils.hasLength(paramsAsArray[0]) ? Integer.parseInt(paramsAsArray[0]) : 0;
					int formId = StringUtils.hasLength(paramsAsArray[1]) ? Integer.parseInt(paramsAsArray[1]) : 0;
					int negotiationid=StringUtils.hasLength(paramsAsArray[2]) ? Integer.parseInt(paramsAsArray[2]) : 0;
					double L1Amount=StringUtils.hasLength(paramsAsArray[3]) ? Double.parseDouble(paramsAsArray[3]) : 0;
					double negotiatedL1Amount=StringUtils.hasLength(paramsAsArray[4]) ? Double.parseDouble(paramsAsArray[4]) : 0;
					TblNegotiationResult tblNegotiationResult=new TblNegotiationResult();
            		tblNegotiationResult= negotiationResultMap.get(temp_tenderId+"~"+companyId+"~"+formId+"~"+tableId+"~"+rowId+"~"+negotiationid);
            		tblNegotiationResult.setUpdatedOn(commonService.getServerDateTime());
  					tblNegotiationResult.setUpdatedBy(abcUtility.getSessionUserId(request));
					tblNegotiationResult.setIsWinner(1);
					total_negotiatedL1Amount += tblNegotiationResult.getNegotiatedL1Amount().doubleValue();
					total_L1Amount+=tblNegotiationResult.getL1Amount().doubleValue();
					listForUpdateSelectedTblNegotiationResults.add(tblNegotiationResult);
				}
            	negotiationService.saveUpdateAllTblNegotiationResult(listForUpdateSelectedTblNegotiationResults);
				tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            	tenderFormService.negotiatedL1ReportData(modelMap,tenderId);
            	TblNegotiationSummary tblNegotiationSummary=negotiationService.askForNegotiation(tenderId,linkId);
            	tblNegotiationSummary.setNegotiatedRate(BigDecimal.valueOf(total_L1Amount));
            	tblNegotiationSummary.setRenegotiatedRate(BigDecimal.valueOf(total_negotiatedL1Amount));
                negotiationService.addTblNegotiationSummary(tblNegotiationSummary);
                
            	//Start Bug Id :#26540
            	/*boolean isGTCase=false;
                int isItemwiseWinner=(Integer)tenderCommonService.getTenderField(tenderId, "isItemwiseWinner");
                if(isItemwiseWinner == 0){
                	isGTCase=true;
                }
            	List<Object[]> reportData=negotiationService.getTenderReportId(tenderId);
                List<Object[]> govColData=negotiationService.getTenderGovColumn(tenderId);
                reportId=!reportData.isEmpty() ? Integer.parseInt(reportData.get(0)[0].toString()) : 0;
                dynReportColId=!reportData.isEmpty() ? Integer.parseInt(reportData.get(0)[1].toString()) : 0;
                govColId=!govColData.isEmpty() ? Integer.parseInt(govColData.get(0)[0].toString()) : 0;
                List<Map<String, Object>> negotiationSummaryMap=new ArrayList<Map<String, Object>>();
                negotiationSummaryMap = negotiationService.getReNegotiationRateForTender(reportId,dynReportColId,govColId,tenderId,linkId,isGTCase);
                if(negotiationSummaryMap!=null && !negotiationSummaryMap.isEmpty()){
                	if(negotiationSummaryMap.get(0).containsKey("reNegotiatedRate") && negotiationSummaryMap.get(0).get("reNegotiatedRate")!=null && !negotiationSummaryMap.get(0).get("reNegotiatedRate").equals("")){
                		reNegotiatedRate=new BigDecimal(negotiationSummaryMap.get(0).get("reNegotiatedRate").toString());*/
	    			/*}
                }*/
            	page="redirect:/etender/buyer/negotiatedl1report/"+tenderId+"/"+11+encryptDecryptUtils.generateRedirect("etender/buyer/negotiatedl1report/"+tenderId+"/11", request);
                
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewL1ReportAfterNegotiation, tenderId, 0);
        }
        return page;
    }
    
    @RequestMapping(value = {"/buyer/savenegotiationsummeryreportforgrandtotal/{tenderId}"}, method = RequestMethod.POST)
    public String savenNegotiationSummeryReportForGrandTotal(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    	String page="";  
        int linkId=602;
		try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
               String selectedRadioValues=request.getParameter("rdSelecteL1");
               if(selectedRadioValues!=null){
                	String[] temp = selectedRadioValues.split("_");
                	int companyId= Integer.parseInt(temp[1]);
                	negotiationService.updateNegotiationIsWinnerForGrandTotalToFalse(tenderId);
                	negotiationService.updateNegotiationIsWinnerForGrandTotal(tenderId,companyId,abcUtility.getSessionUserId(request));
                	TblNegotiationSummary tblNegotiationSummary=negotiationService.askForNegotiation(tenderId, linkId);
                	Enumeration<String> paramNames = request.getParameterNames();
                	List<String> listSelectedValues = new ArrayList<String>();
                	while(paramNames.hasMoreElements()) {
                		String paramName = (String)paramNames.nextElement();
                		if(paramName.startsWith("hd"+companyId+"_")){
                			String values[]=paramName.split("_");
                			listSelectedValues.add(values[1]);
                		}
                	}
                	tblNegotiationSummary.setNegotiatedRate(BigDecimal.valueOf(Double.parseDouble(listSelectedValues.get(1))));
                	tblNegotiationSummary.setRenegotiatedRate(BigDecimal.valueOf(Double.parseDouble(listSelectedValues.get(0))));
                	negotiationService.addTblNegotiationSummary(tblNegotiationSummary);
                }
               tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
               modelMap.addAttribute("tenderId",tenderId);
               modelMap.addAttribute("listTblNegotiationResults", negotiationService.getTblNegotiationResult(tenderId));
               page="redirect:/etender/buyer/negotiatedl1report/"+tenderId+"/"+11+encryptDecryptUtils.generateRedirect("etender/buyer/negotiatedl1report/"+tenderId+"/"+11, request);
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewL1ReportAfterNegotiation, tenderId, 0);
        }
        return page;
    }
    
    
    
    @RequestMapping(value = {"/buyer/negotiatedl1report/{tenderId}/{tabId}/{enc}"}, method = RequestMethod.GET)
    public String negotiatedL1Report(@PathVariable("tenderId") int tenderId,@PathVariable("tabId")int tabId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    	String page="";  
        int linkId=1132;
        int reportOn=0,tenderResult=0,isEncodedName=0,isEncodedForNegotiation=0;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	int isItemwiseWinner=(Integer)tenderCommonService.getTenderField(tenderId, "isItemwiseWinner");
            	/*Changes for PT #50381 to display encoded bidder name in Report*/
            	List<Object[]> encodeDetails = null;
            	encodeDetails = tenderCommonService.getTenderFields(tenderId, "tenderResult,isEncodedForNegotiation");
                if(encodeDetails!=null && !encodeDetails.isEmpty()){
    				tenderResult = Integer.parseInt(encodeDetails.get(0)[0].toString());
    				isEncodedForNegotiation = Integer.parseInt(encodeDetails.get(0)[1].toString());
    			}
                
            	int isEncoded=commonService.getLetestCstatusEncodeDecodeHistory(tenderId);
    			if(isEncodedForNegotiation==1 && isEncoded==1) {
    				isEncodedName=1;
    			}
                
            	int isNegotiationClosed = negotiationService.isNegotiationClosed(tenderId,inviteNegotiationTenderLinkId);
    		    if(isNegotiationClosed==1){
    		      /*Generate system generated Negotiation L1 Report*/
    		    	if(tenderResult==1){
                		reportOn = 3;
                	}else if(tenderResult==2){
                		reportOn = 4;
                	}
    		    TblDynReport tblDynReport = dynamicReportService.getDynReportById(tenderId,reportOn);
       			if(tblDynReport!=null){
       				 dynamicReportService.deleteTblDynReportCellId(tblDynReport.getReportId()); 	
            	     dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(),tenderId,abcUtility.getSessionUserId(request));
       			 }
    		    }
    		    
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            	modelMap.addAttribute("isEncodedName",isEncodedName);
            	if(isItemwiseWinner==1){
		            	tenderFormService.negotiatedL1ReportData(modelMap,tenderId);
		            	negotiationService.gethorizontalviewlonereport(modelMap,tenderId);
		                page = "common/negotiation/buyer/NegotiatedL1Report";
            	}else if(isItemwiseWinner==0){
            		modelMap.addAttribute("tenderId",tenderId);
                    modelMap.addAttribute("listTblNegotiationResults", negotiationService.getTblNegotiationResult(tenderId));
                    page = "common/negotiation/buyer/NegotiatedL1ReportForGrandTotal";
            	}
            	modelMap.addAttribute("tabId",tabId);
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewNegotiationSummaryReport, tenderId, 0);
        }
        return page;
    }
    
    /**
     * Method to get tender access details
     * @param tenderId
     * @param tenderType
     * @param modelMap
     * @param request
     * @return 
     */
    //reportType 1 for tender access Report 2 for bid submission report
    @RequestMapping(value = "/buyer/tenderaccessdetails/{reportType}/{tenderId}/{tenderType}/{enc}", method = RequestMethod.GET)
    public String tenderAccessDetails(@PathVariable("reportType") int reportType,@PathVariable("tenderId") int tenderId,@PathVariable("tenderType") int tenderType, ModelMap modelMap,HttpServletRequest request) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("tenderAccesslist", tenderReportService.getTenderAccessDetails(tenderId,tenderType));
            modelMap.addAttribute("reportType", reportType);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
        	String message = "";
        	if(reportType == 1){
        		message = getEventAccessReport;
        	}else if(reportType == 2){
        		message = getEventBidSubmissionReport;
        	}
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),reportEventAccessDetail, message, tenderId, 0);
        }
        return "/etender/buyer/TenderAccessDetails";
    }
    
    /**
     * Method to access user wise tender access details
     * @param tenderId
     * @param userDetailsId
     * @param companyId
     * @param modelMap
     * @param request
     * @return ]
     */
    @RequestMapping(value = "/buyer/userwisetenderaccessdetails/{tenderId}/{companyId}/{userId}/{enc}", method = RequestMethod.GET)
    public String userWiseTenderAccessDetails(@PathVariable("tenderId") int tenderId,@PathVariable("companyId") int companyId,@PathVariable("userId") int userId, ModelMap modelMap,HttpServletRequest request) {
        try {
            tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            modelMap.addAttribute("userTenderAccesslist", tenderReportService.getUserTenderAccessDetails(tenderId, companyId));
            modelMap.addAttribute("CompanyName", commonService.getCompanyNameByCompanyId(companyId));
            modelMap.addAttribute("bidderDocList", tenderCommonService.getTenderBidderDocs(tenderId, companyId));
            modelMap.addAttribute("companyId" ,companyId);
            modelMap.addAttribute("userId" ,userId);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),reportEventAccessDetail, getEventAccessReport, tenderId, companyId);
        }
        return "/etender/buyer/UserTenderAccessDetails";
    }
     @RequestMapping(value = "/buyer/getTenderHistory/{tenderId}/{enc}", method = RequestMethod.GET)
    public String getTenderHistory(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request) {
    	modelMap.addAttribute("reportId", tenderHistoryReportId);

    	try {
    		tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
    		reportGeneratorService.getReportConfigDetails(tenderHistoryReportId, modelMap);
    	} catch (Exception e) {
    		return exceptionHandlerService.writeLog(e);
    	}finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),rfxManagementHistoryLinkId, getTenderHistory, tenderId, 0);
    	}
    	return "etender/buyer/TenderManagementHistory";
    }
         /**
     * Method use for get item wise evaluation report details.
     * @author dipal
     * @param eventId
     * @param formId
     * @param operation  1: view report, 2: save as html , 3: save as word, 4:save as excel, 5:save as pdf
     * @param commiteeType
     * @param modelMap
     * @param request
     * @param session
     * @return 
     */
    @RequestMapping(value = {"/buyer/itemwisebreakupreport/{eventId}/{formId}/{operation}/{backType}/{enc}"}, method = RequestMethod.GET)
    public String showItemWiseBreakUpReport(@PathVariable("eventId") int eventId,@PathVariable("formId") int formId,@PathVariable("operation") int operation,@PathVariable("backType") int backType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        int linkId=linkEvaluationItemBreakupReport;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
        	tenderCommonService.tenderSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
                 modelMap.addAttribute("operation",operation);
                
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                 if(operation == 2 && (request.getParameter("hdisPrintPriview")==null || request.getParameter("hdisPrintPriview").equalsIgnoreCase("0")))
                {
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
                 ItemWiseBreakupDataBean itemWiseBreakupDataBean = new ItemWiseBreakupDataBean();
                 
                Map<String,Object> outMap= tenderReportService.getItemWiseBreakupReportDetail(eventId,formId,operation);
                if(outMap != null && !outMap.isEmpty())
                { 
                    if(outMap.get(RESULTSET_1) !=null) // Form Detail
                    {
                        itemWiseBreakupDataBean.setFormList((ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1));
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Table Detail
                    {
                        itemWiseBreakupDataBean.setTableList((ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2));
                        for (Iterator<LinkedHashMap<String, Object>> it = itemWiseBreakupDataBean.getTableList().iterator(); it.hasNext();) {
                            Map<String,Object> outMap1= tenderReportService.getTenderOpeningReportDetail(eventId,Integer.parseInt(it.next().get("tableId").toString()),operation);
                            if(outMap1 != null) {
                                if(outMap1.get(RESULTSET_1) !=null){
                                    if(itemWiseBreakupDataBean.getColumnRowList()!=null && !itemWiseBreakupDataBean.getColumnRowList().isEmpty()){
                                        List<LinkedHashMap<String, Object>> lhms = itemWiseBreakupDataBean.getColumnRowList();
                                        lhms.addAll((ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_1));
                                        itemWiseBreakupDataBean.setColumnRowList(lhms);
                                    }else{
                                        itemWiseBreakupDataBean.setColumnRowList((ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_1));
                                    }
                                }
                                if(outMap1.get(RESULTSET_2) !=null){
                                    if(itemWiseBreakupDataBean.getColumnRowDetailsList()!=null && !itemWiseBreakupDataBean.getColumnRowDetailsList().isEmpty()){
                                        List<LinkedHashMap<String, Object>> lhms = itemWiseBreakupDataBean.getColumnRowDetailsList();
                                        lhms.addAll((ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_2));
                                        itemWiseBreakupDataBean.setColumnRowDetailsList(lhms);
                                    }else{
                                        itemWiseBreakupDataBean.setColumnRowDetailsList((ArrayList<LinkedHashMap<String, Object>>) outMap1.get(RESULTSET_2));
                                    }                                    
                                }
                            }
                        }
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Officer Column Detail
                    {
                        itemWiseBreakupDataBean.setColumnList((ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3));
                    }
                }
                modelMap.addAttribute("iteamWiseBreakupDataBean", itemWiseBreakupDataBean);
               
                page = "/etender/buyer/ItemWiseBreakupReport";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getItemWiseBreakupReport, eventId, formId);
        }
        return page;
    }
    
    /**
     * Method use for get request of Manual L1 Report(Create/Edit)
     * @author : Lipi Shah since 10/12/2014
     */
    @RequestMapping(value = "/buyer/manuall1report/{tenderId}/{operationId}/{enc}", method = RequestMethod.GET)
    public String manualL1Report(@PathVariable("tenderId") int tenderId,@PathVariable("operationId") int operationId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    	String page="";
    	int linkId=0,isEncodedName=0,isEvaluationRequired=0;
    	try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            	/*Changes for Bug #50809*/
            	if(modelMap.get("isEvaluationRequired")!=null){//Changes for BUG #53254
            		isEvaluationRequired = Integer.valueOf(modelMap.get("isEvaluationRequired").toString());
            	}
            	if(tenderCommonService.getTenderField(tenderId,"isEncodedName")!=null){
            	  isEncodedName = Integer.valueOf(tenderCommonService.getTenderField(tenderId,"isEncodedName").toString());
            	}
            	int cStatus=commonService.getLetestCstatusEncodeDecodeHistory(tenderId);
            	
            	if(isEncodedName==1 && cStatus==2){
            		isEncodedName=0;
            	}
            	List<Object[]> rptDtls = tenderReportService.getManualReportDetails(tenderId,isEncodedName,isEvaluationRequired);
            	List<SelectItem> items = new ArrayList<SelectItem>();
                if (rptDtls != null) {
                    for (Object[] objects : rptDtls) {
                        if (objects.length >= 2) {
                            items.add(new SelectItem(objects[1], objects[0]+"_"+objects[2]));
                        }                
                    }
                }
                modelMap.addAttribute("comapanyDtls", items);
                if(operationId == 2){//Edit
                	modelMap.addAttribute("overRulesDetails", tenderReportService.getOverRuledReport(tenderId));
                }
                modelMap.addAttribute("decimalValueUpto", tenderCommonService.getTenderField(tenderId, "decimalValueUpto"));
            	page = "/etender/common/TenderManualL1Report";
            }else{
            	page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, getManuaL1Report, tenderId, 0, null);
        }
        return page;
    }
    
    /**
     * Method use for add/update Manual L1 Report
     * @author : Lipi Shah since 10/12/2014
     */
    @RequestMapping(value = {"/buyer/generatemanuall1report"}, method = RequestMethod.POST)
    public String generateManualL1Report(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	String page = ""; 
    	int companyId = 0;
    	int bidderId = 0;
    	int cnt = 0;
    	TblOverRuledReport overRuledReport = new TblOverRuledReport();
    	List<TblOverRuledReportDetail> overRuledReportDetailList = new ArrayList<TblOverRuledReportDetail>();
    	boolean flag = false;
    	int tenderId = 0;
        try {
        	SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            if (sessionBean != null){
            	tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
            	int operationId = StringUtils.hasLength(request.getParameter("hdOperationId")) ? Integer.parseInt(request.getParameter("hdOperationId")) : 0;
            	int reportId = StringUtils.hasLength(request.getParameter("hdreportId")) ? Integer.parseInt(request.getParameter("hdreportId")) : 0;
            	int userDetailId = sessionBean.getUserDetailId();
            	//
            	if(operationId==2){
            		overRuledReport.setOverRuledReportId(reportId);
            	}
        		overRuledReport.setCreatedBy(userDetailId);
        		overRuledReport.setCreatedOn(commonService.getServerDateTime());
        		overRuledReport.setPublishedBy(0);
        		overRuledReport.setCstatus(0);
            	overRuledReport.setUpdatedBy(userDetailId);
        		overRuledReport.setUpdatedOn(commonService.getServerDateTime());
        		overRuledReport.setTblTender(new TblTender(tenderId));
        		
            	String[] remarks = request.getParameterValues("txtRemarks");
            	String[] rates = request.getParameterValues("txtRate");
            	String[] companyDtls = request.getParameterValues("selCompany");
            	if(companyDtls != null){
		        	for(String company : companyDtls){
		        		TblOverRuledReportDetail overRuledReportDetail = new TblOverRuledReportDetail();
		        		if(company.contains("_")){
		        			companyId = Integer.parseInt(company.split("_")[0].toString());
		        			bidderId = Integer.parseInt(company.split("_")[1].toString());
		        			overRuledReportDetail.setTblCompany(new TblCompany(companyId));
		        			overRuledReportDetail.setTblUserLogin(new TblUserLogin(bidderId));
		        		}
		        		overRuledReportDetail.setTblOverRuledReport(overRuledReport);
		        		overRuledReportDetail.setAmount(new BigDecimal(rates[cnt]));
		        		overRuledReportDetail.setRemarks(remarks[cnt]);
		        		cnt++;
		        		overRuledReportDetailList.add(overRuledReportDetail);
		        	}
            	}
            	flag = tenderReportService.addUpdateOverRuledReport(overRuledReport,overRuledReportDetailList);
            	if(operationId == 2){//edit
            		redirectAttributes.addFlashAttribute(flag ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), flag ? "msg_manuall1rpt_update_success" : CommonKeywords.ERROR_MSG_KEY.toString());
            	}else if(operationId == 1){//create
            		redirectAttributes.addFlashAttribute(flag ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), flag ? "msg_manuall1rpt_create_success" : CommonKeywords.ERROR_MSG_KEY.toString());
            	}
            	page = "/etender/buyer/tenderdashboard/"+tenderId+"/9";
            }else{
            	page =  "redirect:/sessionexpired";
            }
	    } catch (Exception e) {
	        exceptionHandlerService.writeLog(e);
	    } finally {
	        auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, generateManuaL1Report, tenderId, 0, null);
	    }
	    return "redirect:/" + page + encryptDecryptUtils.generateRedirect(page, request);
    }
   
    /**
     * Method used for publish  Manual L1 Report
     * @author : Lipi Shah since 10/12/2014
     */
    @RequestMapping(value = {"/buyer/publishmanuall1report"}, method = RequestMethod.POST)
    public String publishManualL1Report(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
//    	System.out.println("publishManualL1Report");
    	String page = ""; 
    	boolean flag = false;
    	int tenderId = 0;
    	String orderBy="";
    	try {
        	SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            if (sessionBean != null){
            	int reportId = StringUtils.hasLength(request.getParameter("hdreportId")) ? Integer.parseInt(request.getParameter("hdreportId")) : 0;
            	tenderId = StringUtils.hasLength(request.getParameter("hdTenderId")) ? Integer.parseInt(request.getParameter("hdTenderId")) : 0;
            	int userDetailId = sessionBean.getUserDetailId();
            	TblOverRuledReport overRuledReport = new TblOverRuledReport();
            	overRuledReport.setOverRuledReportId(reportId);
            	overRuledReport.setPublishedBy(userDetailId);
            	overRuledReport.setPublishedOn(commonService.getServerDateTime());
        		overRuledReport.setCstatus(1);
            	overRuledReport.setUpdatedBy(userDetailId);
        		overRuledReport.setUpdatedOn(commonService.getServerDateTime());
        		overRuledReport.setTblTender(new TblTender(tenderId));
        		flag = tenderReportService.updateOverRuledReport(overRuledReport);
        		/*System generated Manual L1 Report*/
        		List<Object[]>	eventFields = tenderCommonService.getTenderFields(tenderId, "biddingVariant,tenderResult,isDemoTender");
        		if(flag && Integer.parseInt(eventFields.get(0)[2].toString())==0 ) //Not Consider Demo Event
        		{
        			if(Integer.parseInt(eventFields.get(0)[0].toString())==1){
                		orderBy="asc";
                	}else{
                		orderBy="desc";
                	}
                	
                	int isInsertFlag=0;
                	if(Integer.parseInt(eventFields.get(0)[1].toString())==1){
                		isInsertFlag=tenderFormService.checkTenderHasRebate(tenderId);
           			}else if(Integer.parseInt(eventFields.get(0)[1].toString())==2){
           				isInsertFlag=tenderFormService.checkHasTenderGovColumn(tenderId);
                	}
                	
                	if(isInsertFlag==-1){
                		List<Object[]> manualL1ReportDtls=tenderReportService.getOverRuledReport(tenderId,orderBy);
           				if( manualL1ReportDtls!=null && !manualL1ReportDtls.isEmpty() ){
               				TblTenderSaving tblTenderSaving=new TblTenderSaving();
               				tblTenderSaving.setObjectId(tenderId);
               				tblTenderSaving.setTblTender(new TblTender(tenderId));
               				tblTenderSaving.setTotalAmt(manualL1ReportDtls.get(0)[0].toString());
               				tblTenderSaving.setEstimatedAmt(manualL1ReportDtls.get(0)[1].toString());
               				tblTenderSaving.setSavingGainAmt(manualL1ReportDtls.get(0)[2].toString());
               				tblTenderSaving.setCreatedBy(abcUtility.getSessionUserId(request));
               				tblTenderSaving.setCStatus(0);
               				tenderReportService.addTblTenderSaving(tblTenderSaving);
           				}
                	}
        			tenderFormService.executeSPforGenerateL1Report(tenderId, 1, userDetailId,0,3);
        		}
        		if(flag){
        			redirectAttributes.addFlashAttribute(flag ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), flag ? "msg_manuall1rpt_publish_success" : CommonKeywords.ERROR_MSG_KEY.toString());
        		}
        		page = "/etender/buyer/tenderdashboard/"+tenderId+"/9";
            }else{
            	page =  "redirect:/sessionexpired";
            }
    	} catch (Exception e) {
    		exceptionHandlerService.writeLog(e);
    	} finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, publishManuaL1Report, tenderId, 0, null);
    	}
    	return "redirect:/" + page + encryptDecryptUtils.generateRedirect(page, request);
    }
    
    /**
     * Method use for get request of Manual L1 Report(View)
     * @author : Lipi Shah since 10/12/2014
     */
    @RequestMapping(value = "/buyer/overruledreport/{tenderId}/{operationId}/{enc}", method = RequestMethod.GET)
    public String getOverRuledReport(@PathVariable("tenderId") int tenderId,@PathVariable("operationId") int operationId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
    	String page="";
    	int isEncodedName=0;
    	try {
    		if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            	/*Changes for Bug #50809*/
            	isEncodedName = Integer.valueOf(tenderCommonService.getTenderField(tenderId,"isEncodedName").toString());
            	int cStatus=commonService.getLetestCstatusEncodeDecodeHistory(tenderId);
            	
            	if(isEncodedName==1 && cStatus==1){
            		modelMap.addAttribute("overRulesDetails", tenderReportService.getOverRuledReportWithEncodedBidder(tenderId));
            	}
            	else{
            		modelMap.addAttribute("overRulesDetails", tenderReportService.getOverRuledReport(tenderId));
            	}
                /*System generated Manual L1 Report*/
       			TblDynReport tblDynReport  = dynamicReportService.getDynReportById(tenderId,6);
       			if(tblDynReport!=null)
       				dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(),tenderId,abcUtility.getSessionUserId(request));
       			modelMap.addAttribute("decimalValueUpto", tenderCommonService.getTenderField(tenderId, "decimalValueUpto"));
            	page = "/etender/common/TenderManualL1ReportView";
            }else{
            	page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getOverRuledReport, tenderId, 0, null);
        }
        return page;
    }
    
    @RequestMapping(value = {"/buyer/getweightagel1report/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String getWeightageL1report(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        int linkId=linkWeightageL1Report;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            	int userRoleId = 1;
    			if((Integer) modelMap.get("isTwoStageEvaluation") == 1 ){
    				userRoleId = (Integer) modelMap.get("multiLevelEvaluationReq") == 1 ? 4 : 2;
    			}
            	Map<String,Object> outMap= tenderReportService.getWeightageL1Report(tenderId,userRoleId);
                if(outMap != null && !outMap.isEmpty())
                {
                	if(outMap.get(RESULTSET_1) !=null) // Tender Envelope
                    {
                        modelMap.addAttribute("tenderEnvelopeList",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                	if(outMap.get(RESULTSET_2) !=null) // Evaluated Envelope Approved Bidder List
                    {
                        modelMap.addAttribute("approvedBidderList",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }
                	if(outMap.get(RESULTSET_3) !=null) // get Approved Bidder Scoring Marks by envelopeId, bidderId
                    {
                        modelMap.addAttribute("approvedBidderScoreList",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                    }
                	if(outMap.get(RESULTSET_4) !=null) // get Approved Bidder Scoring Marks by envelopeId, bidderId
                    {
                        modelMap.addAttribute("approvedBidderL1List",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }
                }
                page = "/etender/buyer/WeightageL1Report";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewWeightageL1ReportPage, tenderId, 0);
        }
        return page;
    }
    
    /**
     * @author Darshan Raval
     * @return
     */
    public List<SelectItem> getAdvertiseCombo() {
        List<SelectItem> items = new ArrayList<SelectItem>();
        items.add(new SelectItem("Pending", 0));
        items.add(new SelectItem("Approved", 1));
        return items;
    }
    
    /**
     * @author vivek.rajyaguru
     * @param map
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/AdvertiseDetailReport/{enc}", method = RequestMethod.GET)
    public String viewAdvertiseDetailReport(ModelMap map,HttpServletRequest request) {
        try{
            map.addAttribute("selContractType", getContractType());
            map.addAttribute("selStatus", getAdvertiseCombo());
            map.addAttribute("selNumOperation", getSearch4Numeric());
            map.addAttribute("operation", 0);
            map.addAttribute("advertiseType", advertiseService.getAdvertiseType());
            map.addAttribute("deptId", 0);
            //CODE ONLY FOR IE9 BUG ID:#30310
            int ie9Flag=0;
            String userAgent=request.getHeader("user-agent");
            if(userAgent.contains("MSIE")){
            String substring=userAgent.substring(userAgent.indexOf("MSIE")).split(";")[0];
            String browserVer=substring.split(" ")[1];
            if(browserVer.equals("9.0"))
            		ie9Flag=1;
            }
            map.addAttribute("ie9Flag", ie9Flag);
          //CODE ONLY FOR IE9 BUG ID:#30310
            
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkAdvertiseDetailReport,getAdvertiseDetailReport, 0, 0); 
        }
        return "/etender/buyer/AdvertiseDetailReport";
    }
    

    /**
     * @author vivek.rajyaguru
     * @param modelMap
     * @param request
     * @param session
     * @return
     */
    @RequestMapping(value = {"/buyer/searchadvertiseDetailreport"}, method = RequestMethod.POST)
    public String searchAdvertiseDetailReport(ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        List<Short> showHideChk = new ArrayList<Short>();
        SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
        String page="";
        int colspan = 1;
        try
        {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null)
            {
                //set search criteria fields
                int pageNo = StringUtils.hasLength(request.getParameter("txtPageNo")) ? Integer.parseInt(request.getParameter("txtPageNo")) : 0;
              
                int deptId = StringUtils.hasLength(request.getParameter("txtDept")) ? Integer.parseInt(request.getParameter("txtDept")) : 0;
                int eventId = StringUtils.hasLength(request.getParameter("txtEventId")) ? Integer.parseInt(request.getParameter("txtEventId")) : 0;
                String txtAdvertiseNo = StringUtils.hasLength(request.getParameter("txtAdvertiseNo")) ? request.getParameter("txtAdvertiseNo") : null;
                String txtPaperAdvertisementNo = StringUtils.hasLength(request.getParameter("txtPaperAdvertisementNo")) ? request.getParameter("txtPaperAdvertisementNo") : null;
                int advertiseType = StringUtils.hasLength(request.getParameter("selAdvertiseType")) ? Integer.parseInt(request.getParameter("selAdvertiseType")) : 0;	
                
                int pubDateOpFrom = StringUtils.hasLength(request.getParameter("selPublishedOnOperator")) ? Integer.parseInt(request.getParameter("selPublishedOnOperator")) : 0;
                Date publishDateFrom = StringUtils.hasLength(request.getParameter("txtPublishedOnForm")) ? CommonUtility.getDateObj(request.getParameter("txtPublishedOnForm")) : null;
                Date publishDateTo = StringUtils.hasLength(request.getParameter("txtPublishedOnTo")) ? CommonUtility.getDateObj(request.getParameter("txtPublishedOnTo")) : null;
                int advStatus = StringUtils.hasLength(request.getParameter("selAdvCstatus")) ? Integer.parseInt(request.getParameter("selAdvCstatus")) : -1;
                
                int subDateOpFrom = StringUtils.hasLength(request.getParameter("selNumOpSubDateFrom")) ? Integer.parseInt(request.getParameter("selNumOpSubDateFrom")) : 0;
                Date bidDateFrom = StringUtils.hasLength(request.getParameter("txtBidDateFrom")) ? CommonUtility.getDateObj(request.getParameter("txtBidDateFrom")) : null;
                Date bidDateTo = StringUtils.hasLength(request.getParameter("txtBidDateTo")) ? CommonUtility.getDateObj(request.getParameter("txtBidDateTo")) : null;

                int  downloadDocumentDateOperator = StringUtils.hasLength(request.getParameter("selDownloadDocumentDateOperator")) ? Integer.parseInt(request.getParameter("selDownloadDocumentDateOperator")) : 0;
                Date downloadDocumentDateFrom = StringUtils.hasLength(request.getParameter("txtDownloadDocumentDateFrom")) ? CommonUtility.getDateObj(request.getParameter("txtDownloadDocumentDateFrom")) : null;
                Date downloadDocumentDateTo = StringUtils.hasLength(request.getParameter("txtDownloadDocumentDateTo")) ? CommonUtility.getDateObj(request.getParameter("txtDownloadDocumentDateTo")) : null;

                int  openingDateFromOperator = StringUtils.hasLength(request.getParameter("selOpeningDateFromOperator")) ? Integer.parseInt(request.getParameter("selOpeningDateFromOperator")) : 0;
                Date openingDateFrom  = StringUtils.hasLength(request.getParameter("txtOpeningDateFrom")) ? CommonUtility.getDateObj(request.getParameter("txtOpeningDateFrom")) : null;
                Date openingDateTo  = StringUtils.hasLength(request.getParameter("txtOpeningDateTo")) ? CommonUtility.getDateObj(request.getParameter("txtOpeningDateTo")) : null;
                
                int estOpFrom = StringUtils.hasLength(request.getParameter("selNumOperationFrom")) ? Integer.parseInt(request.getParameter("selNumOperationFrom")) : 0;
                Double estValFrom = StringUtils.hasLength(request.getParameter("txtEstValFrom")) ? Double.parseDouble(request.getParameter("txtEstValFrom")) : null;
                Double estValTo = StringUtils.hasLength(request.getParameter("txtEstValTo")) ? Double.parseDouble(request.getParameter("txtEstValTo")) : null;
                
                int officerId =StringUtils.hasLength(request.getParameter("selDeptOfficial")) ? Integer.parseInt(request.getParameter("selDeptOfficial")) : 0;
                int contractType = StringUtils.hasLength(request.getParameter("selCotType")) ? Integer.parseInt(request.getParameter("selCotType")) : 0;
                int operation = StringUtils.hasLength(request.getParameter("txtOperation")) ? Integer.parseInt(request.getParameter("txtOperation")) : 0;
               
                
                //set dynamic columns for headings
                showHideChk.add(Short.valueOf("1"));
                 if (request.getParameter("chkDept") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkadvertisementType") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkadvertiseNo") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkPaperadvertiseNo") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkpaperName") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkadvertDate") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkEMD") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkDocFees") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chksystemId") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkRefNo") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkbriefScopeWork") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkprojectDuration") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkestimatedValue") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkbidSubEndDate") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkbidOpen") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkdocDownload") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                 if (request.getParameter("chkContractType") != null) {
                    showHideChk.add(Short.valueOf("1"));
                    colspan++;
                 } else {
                    showHideChk.add(Short.valueOf("0"));
                 }
                
                Map<String, Object> dataMap = tenderReportService.getAdvertiseDetailReport(abcUtility.getSessionClientId(request), deptId, eventId, txtAdvertiseNo, txtPaperAdvertisementNo, advertiseType, pubDateOpFrom, publishDateFrom, publishDateTo, advStatus, subDateOpFrom, bidDateFrom, bidDateTo, downloadDocumentDateOperator, downloadDocumentDateFrom, downloadDocumentDateTo, openingDateFromOperator, openingDateFrom, openingDateTo, estOpFrom, estValFrom, estValTo, officerId, contractType, sessionBean.getTimeZoneOffset(),abcUtility.getCookieDateFormatConversionValue(request), showHideChk, recordPerPage, pageNo);
                 
                if(dataMap.get("#result-set-1") != null){
                    int totalPages = Integer.parseInt(dataMap.get("@V_TotalPages").toString());
                    if (totalPages == 0){
                        totalPages = 1;
                    }
                    modelMap.addAttribute("listData",(ArrayList<LinkedHashMap<String, Object>>) dataMap.get("#result-set-1") );
                    modelMap.addAttribute("totalRecords", dataMap.get("@V_TotalRecords"));
                    modelMap.addAttribute("totalPages", totalPages);
                }
              
                Map<String, Object> dataMapPdf = tenderReportService.getAdvertiseDetailReport(abcUtility.getSessionClientId(request), deptId, eventId, txtAdvertiseNo, txtPaperAdvertisementNo, advertiseType, pubDateOpFrom, publishDateFrom, publishDateTo, advStatus, subDateOpFrom, bidDateFrom, bidDateTo, downloadDocumentDateOperator, downloadDocumentDateFrom, downloadDocumentDateTo, openingDateFromOperator, openingDateFrom, openingDateTo, estOpFrom, estValFrom, estValTo, officerId, contractType, sessionBean.getTimeZoneOffset(),abcUtility.getCookieDateFormatConversionValue(request), showHideChk, recordPerPage, -1);
                if(dataMapPdf.get("#result-set-1") != null){
                    modelMap.addAttribute("listDataPdf",(ArrayList<LinkedHashMap<String, Object>>) dataMapPdf.get("#result-set-1") );
                }
	              //CODE ONLY FOR IE9 BUG ID:#30310
	                int ie9Flag=0;
	                String userAgent=request.getHeader("user-agent");
	                if(userAgent.contains("MSIE")){
	                String substring=userAgent.substring(userAgent.indexOf("MSIE")).split(";")[0];
	                String browserVer=substring.split(" ")[1];
	                if(browserVer.equals("9.0"))
	                		ie9Flag=1;
	                }
	                modelMap.addAttribute("ie9Flag", ie9Flag);
	              //CODE ONLY FOR IE9 BUG ID:#30310
                
                modelMap.addAttribute("pageNo", pageNo);
                modelMap.addAttribute("colspan", colspan);
                modelMap.addAttribute("operation", operation);
                modelMap.addAttribute("showHideChk", showHideChk);
                modelMap.addAttribute("selContractType", getContractType());
                modelMap.addAttribute("selStatus", getAdvertiseCombo());
                modelMap.addAttribute("selNumOperation", getSearch4Numeric());
                modelMap.addAttribute("advertiseType", advertiseService.getAdvertiseType());
                modelMap.addAttribute("deptId", deptId);
                modelMap.addAttribute("officerId",officerId);
                
               
                page = "/etender/buyer/AdvertiseDetailReport";
            }else{
                page =  "redirect:/sessionexpired";
            }
            
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkTenderMISReport, postTenderMISReport, 0, 0); 
        }
        return page;
    }
    
    /**
     * @author janak.dhanani
     * @param modelMap
     * @param request
     * @param session
     * @return
     */
    @RequestMapping(value = {"/buyer/getBidderAllocationReport/{tenderId}/{enc}"}, method = RequestMethod.GET)
    public String getBidderAllocationReport(@PathVariable("tenderId") int tenderId, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";
        int linkId=linkWeightageL1Report;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
            	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
            	Double si = bidderMultiplier;
            	List<Object[]> bidderWisecellValueLst = tenderReportService.getTenderPricebidData(tenderId);
            	if(bidderWisecellValueLst != null && !bidderWisecellValueLst.isEmpty()){
            		MultiMap multiMap = new MultiValueMap();
            		for (Object[] bidderWisecellValue : bidderWisecellValueLst) {
            			double key = new Double(bidderWisecellValue[2].toString());
            			String value= bidderWisecellValue[3].toString() + "@" + bidderWisecellValue[0].toString()+ "@" + bidderWisecellValue[1].toString() + "@" + bidderWisecellValue[4].toString();
            	        multiMap.put(key, value);
					}
            		Set<Double> uRatekeySet = new TreeSet<Double>(multiMap.keySet()).descendingSet();
        	        Map<String,List<String>> finalAllocatedAmountMap = new LinkedHashMap<String,List<String>>();
        	        List<List<String>> finalAllocatedAmountList= new LinkedList<List<String>>();
        	        Double totalAllocatedAmount = 0.0;
        	        for (Double uRateKey : uRatekeySet) {
        	            Collection<String> totRateBid = (Collection<String>) multiMap.get(uRateKey);
        	            for (String strTotRateBid : totRateBid) {
                            Double currTot = new Double(strTotRateBid.split("@")[0]);
                            Double allocatedTot = new Double(0);
                            if(si <= 0.0){
                            	allocatedTot = new Double(0);
                            }else if(si >= currTot){
                            	allocatedTot = currTot;
                            	totalAllocatedAmount += currTot;
                            	si = si - currTot;
                            }else if(si < currTot){
                            	allocatedTot = si;
                            	totalAllocatedAmount += si;
                            	si = si-si;
                            }
                            List<String> utm= new LinkedList<String>();
    	                    utm.add(strTotRateBid.split("@")[1]);
    	                    utm.add(strTotRateBid.split("@")[2]);
    	                    utm.add(uRateKey.toString());
    	                    utm.add(strTotRateBid.split("@")[0]);
    	                    utm.add(allocatedTot.toString());
    	                    utm.add(strTotRateBid.split("@")[3]); 
    	                    finalAllocatedAmountList.add(utm);
                        }
        	        }
        	        modelMap.addAttribute("finalAllocatedAmountList",finalAllocatedAmountList);
        	        modelMap.addAttribute("totalAllocatedAmount",totalAllocatedAmount);
            	}
                page = "/etender/buyer/BidderAllocationReport";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewWeightageL1ReportPage, tenderId, 0);
        }
        return page;
    }   
    
    /**
     * @author Hira Chaudhary
     * @param map
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/getCPPPXMLEvents/{enc}", method = RequestMethod.GET)
    public String getCPPPXMLEvents(ModelMap map,HttpServletRequest request) {
        try{
        	int clientId = abcUtility.getSessionClientId(request);
        	map.addAttribute("CPPPXmlType", tenderReportService.getCPPPXMLType());
        	map.addAttribute("clientId", clientId);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkDownloadCPPPXML, "", 0, 0);
        }
        return "/etender/buyer/GetCPPPXMLEvents";
    }
   

	
	
	 /**
     * @author Hira Chaudhary
     * @param modelMap
     * @param request
     * @param session
     * @return
     */
    @RequestMapping(value = {"/buyer/searchCPPPEvent"}, method = RequestMethod.POST)
    public String searchCPPPEvent(ModelMap  map, HttpServletRequest request,HttpSession session) {
        String retVal="";
        List<Object[]> list = null;
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:SS ");
        try
        {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null)
            {
            	int clientId = abcUtility.getSessionClientId(request);
            	String startDate = StringUtils.hasLength(request.getParameter("txtStartDate")) ? request.getParameter("txtStartDate") : null; 
            	String endDate = StringUtils.hasLength(request.getParameter("txtEndDate")) ? request.getParameter("txtEndDate") : null;
            	int cpppXMLType = StringUtils.hasLength(request.getParameter("selCPPPXMLType")) ? Integer.parseInt(request.getParameter("selCPPPXMLType")) : 1;
            	int eventId = StringUtils.hasLength(request.getParameter("txtEventId")) ? Integer.parseInt(request.getParameter("txtEventId")) : 0;
            	
            	if(startDate!=null && startDate!=""){
            		startDate = formatter.format(CommonUtility.getDateObj(startDate));
            	}
            	if(endDate!=null && endDate!=""){
            		endDate = formatter.format(CommonUtility.getDateObj(endDate));
            	}
            	
            	if(cpppXMLType == 1){
            		list = tenderReportService.getCPPPTenderEvent(clientId,cpppXMLType, eventId, startDate, endDate);
                }else if(cpppXMLType == 2){
                	list = tenderReportService.getCPPPCorrigendumEvent(clientId,cpppXMLType, eventId, startDate, endDate);
                }else if(cpppXMLType == 3){
                	list = tenderReportService.getCPPPAOCEvent(clientId, cpppXMLType, eventId, startDate, endDate);
                }else if(cpppXMLType == 4){
                	list = tenderReportService.getCPPPAuctionEvent(clientId, cpppXMLType, eventId, startDate, endDate);
                }
            	
            	map.addAttribute("eventsList", list);
            	map.addAttribute("clientId", clientId);
            	map.addAttribute("TypeId", cpppXMLType);
            	map.addAttribute("startDate", StringUtils.hasLength(request.getParameter("txtStartDate")) ? request.getParameter("txtStartDate") : "");
            	map.addAttribute("endDate", StringUtils.hasLength(request.getParameter("txtEndDate")) ? request.getParameter("txtEndDate") : "");
            	map.addAttribute("eventId", StringUtils.hasLength(request.getParameter("txtEventId")) ? Integer.parseInt(request.getParameter("txtEventId")) : "");
            	map.addAttribute("CPPPXmlType", tenderReportService.getCPPPXMLType());
            	
            	retVal = "/etender/buyer/GetCPPPXMLEvents";
            }else{
            	retVal =  "redirect:/sessionexpired";
            }
    	} catch (Exception e) {
    		exceptionHandlerService.writeLog(e);
    	} finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkDownloadCPPPXML, "", 0, 0);
    	}
        return retVal;
    }
	
    /**
     * @author Hira.Chaudhary
     * @param modelMap
     * @param request
     * @param response
     * @param session
     * @return
     */
    @RequestMapping(value = {"/buyer/generatexmlforcppp"}, method = RequestMethod.POST)
    public void generateXMLForCPPPEvents(ModelMap modelMap,HttpServletRequest request,HttpServletResponse response,HttpSession session) {
    	String retVal="";
    	String fileName = "";
    	StringBuilder filePath = new StringBuilder();
    	StringBuilder strDocList = new StringBuilder();
    	TblCPPPXmlEntry cpppXmlEntry = new TblCPPPXmlEntry();
    	FileWriter fw = null;
    	try {
    		int userId = abcUtility.getSessionUserId(request);
    		String[] txtTendersIds = request.getParameterValues("chkCPPPEventId")!=null?request.getParameterValues("chkCPPPEventId"):null;
    		int typeId = request.getParameter("hdTypeId")!=null?Integer.parseInt(request.getParameter("hdTypeId")):0;
    		int clientId = request.getParameter("hdclientId")!=null?Integer.parseInt(request.getParameter("hdclientId")):0;
    			
    		filePath.append(drive).append(upload).append(cpppxml).append("\\").append(clientId).append("\\");
    		File folder = new File(filePath.toString());
            if(!folder.exists()){
            	folder.mkdirs(); 
            }
           
            Date now = new Date(); 
            SimpleDateFormat sdf = new SimpleDateFormat("dd_MM_yyyy_HH_mm_ss");
            sdf.setTimeZone(TimeZone.getTimeZone("GMT+5:30"));
            String currDate=sdf.format(now);
          
            if(typeId == 1){
            	fileName = "CPPPTenderXml_"+currDate+".xml";
            }else if(typeId == 2){    		
    			fileName = "CPPPCorrigendumXml_"+currDate+".xml";
    		}else if(typeId == 3){
    			fileName = "CPPPAOCXml_"+currDate+".xml";
    		}else if(typeId == 4){
    			fileName = "CPPPAuctionXml_"+currDate+".xml";
    		}
    		
            cpppXmlEntry.setFileName(fileName);
            cpppXmlEntry.setFilePath(filePath.toString());
    		cpppXmlEntry.setTypeId(typeId);
    		cpppXmlEntry.setClientId(clientId);
    		cpppXmlEntry.setCreatedOn(commonService.getServerDateTime());
    		cpppXmlEntry.setCreatedBy(userId);
    		cpppXmlEntry.setDownloadedOn(commonService.getServerDateTime());
    		
    		String eventIds = "";
      		for (int i = 0; i < txtTendersIds.length; i++) {
      			eventIds += txtTendersIds[i]+",";
      		}
      		eventIds = eventIds.substring(0, eventIds.lastIndexOf(','));
    		
      		List<Map<String,Object>> outMap = (List<Map<String,Object>>) tenderReportService.getGenerateCPPPXML(clientId,typeId,eventIds).get(RESULTSET_1);;
    		strDocList.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    		strDocList.append(AbcUtility.replaceSpecialChars(AbcUtility.reverseReplaceSpecialCharsForCPPPXml(outMap.get(0).get("cpppXmlData").toString())));
    		fw = new FileWriter(filePath.toString() + fileName);
            fw.append(strDocList.toString());
            if(fw != null){
				fw.flush();
				fw.close();	
			}
            File file = new File(filePath.toString()+fileName);
            if(file.exists()){
                tenderReportService.insertCPPPXmlEntry(txtTendersIds,cpppXmlEntry);
                response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition","attachment; filename=\"" + fileName + "\"");
				OutputStream w = response.getOutputStream();
				FileInputStream fis = new FileInputStream(file);
				int i;
				while ((i = fis.read()) != -1) {
					w.write(i);
				}
				fis.close();
				w.flush();
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
    }
    /**
     * @author Suresh.K	
     * @param ModelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "buyer/searchtenderdatadetails", method = RequestMethod.POST)
    @ResponseBody
    public String searchtenderDataDetails(ModelMap modelMap, HttpServletRequest request,@RequestParam("tenderdate")String tenderDate,@RequestParam("demotender")String demoTender) {
    	JSONObject jsonObject=null;
    	JSONArray jsonArray=null;
    	try {
    		jsonArray = new JSONArray();
    		Date modifiedDate = CommonUtility.converTotUtcTimezone(tenderDate);
    		String[] clienTimeZone = abcUtility.getSessionClientTimeZone(request).split(":");
    		int hours = Integer.parseInt(clienTimeZone[0].substring(1));
    		int min = Integer.parseInt(clienTimeZone[1]);
    	    Calendar cal = 	Calendar.getInstance();
    		cal.setTime(modifiedDate);
    		cal.add(Calendar.HOUR_OF_DAY,hours);
    		cal.add(Calendar.MINUTE,min);
    		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    		List<Object[]> lstTender = tenderService.getTenderDetailsOfCurrentDate(sdf.format(cal.getTime()), demoTender);
    		clienTimeZone=null;
    		cal = null;
    		if(lstTender.size()>0 && lstTender!=null){
    			 for(Object[] obj : lstTender){
    				 jsonObject = new JSONObject();
    				 String url = request.getContextPath()+"/etender/buyer/viewtenderdetail/"+obj[0].toString()+encryptDecryptUtils.generateRedirect("etender/buyer/viewtenderdetail/"+obj[0].toString(), request);
    				 String finalPath = "<a href='"+url+"' target='_blank'>"+obj[0].toString()+"</a>"; 
     				 jsonObject.put("tenderId",finalPath);
     				 jsonObject.put("domainName",obj[1].toString());
     				 jsonObject.put("startDate",CommonUtility.convertTimezone((obj[2].toString())));
     				 jsonObject.put("endDate",CommonUtility.convertTimezone(obj[3].toString()));
     				 jsonObject.put("department",obj[4].toString());
     				 jsonObject.put("biddingAccess",obj[5].toString());
     				 jsonObject.put("bidEvaluation",obj[6].toString());
     				 jsonObject.put("eventType",obj[7].toString());
     				 jsonObject.put("tenderStatus",obj[8].toString());
     				 jsonObject.put("noofbidder", tenderService.getnoofBidder(Integer.parseInt(obj[0].toString())));
     				 jsonArray.put(jsonObject);
    			}
    		}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
    	finally{
    		 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),tenderDataReportId,messageSource.getMessage("tender_data_report_search",null,LocaleContextHolder.getLocale()), 0, 0);
    	}
    	return jsonArray.toString();
    }
    /**
     * Displays the Check  Data Report
     * @author Suresh.K
     * @param ModelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "buyer/tenderdatareport/{enc}", method = RequestMethod.GET)
    public String tenderDataReport(ModelMap modelMap, HttpServletRequest request) {
    	int clientId = 0;
    	try{	
    		clientId = abcUtility.getSessionClientId(request);
    		List<SelectItem> demoTender = eventCreationService.getyesNo();
        	modelMap.addAttribute("demoTender", demoTender);
        	List<Object[]> eventTypes = eventCreationService.getEventType(clientId);
            List<SelectItem> lstSelectItems = abcUtility.convert(eventTypes);
			modelMap.addAttribute("lstTenderType", lstSelectItems);
    	}
    	catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}
    	finally{
    		  auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),tenderDataReportId,messageSource.getMessage("tender_data_report_access",null,LocaleContextHolder.getLocale()), 0, 0);	
    	}
       return "/etender/buyer/TenderDataReport";
    }
    @RequestMapping(value = "/allowcatedProperties", method = RequestMethod.POST)
    public String allowcatedProperties(ModelMap modelMap, HttpServletRequest request) {
    	try{
    		String tenderId = request.getParameter("tenderId");
    		List<Object> bidderId =  tenderCommonService.getTblFinalSubmission(tenderId);
    		int propertyCount = tenderCommonService.getCountOfProperty(tenderId);
    		List<Object[]> cellData =  tenderCommonService.getCellDataByTenderId(Integer.parseInt(tenderId));
    		Map<String, String> drwMap = CommonUtility.eDraw(Integer.parseInt(tenderId),bidderId,cellData);
    		for (Map.Entry<String,String> entry : drwMap.entrySet())  
    			tenderCommonService.updateTblCouponHistory(entry.getKey(),Integer.parseInt(entry.getValue()));
    	}
    	catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}
    	finally{
    		  auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),tenderDataReportId,messageSource.getMessage("tender_data_report_access",null,LocaleContextHolder.getLocale()), 0, 0);	
    	}
       return "/etender/buyer/TenderDataReport";
    }
    
    @RequestMapping(value = "propertyAllocation/{companyId}/{propertyId}/{tenderId}/{enc}", method = RequestMethod.GET)
    public String propertyAllocation(@PathVariable("tenderId") int tenderId,@PathVariable("companyId") int companyId, @PathVariable("propertyId") int propertyId,ModelMap modelMap, HttpServletRequest request) {
    	try{
//    		String companyName = request.getParameter("jhdcompanyName");
//    		String propertyName = request.getParameter("jhdpropertyName");
    		List<TblUserLogin> tblUserLogin = tblUserLoginDao.findTblUserLogin("userId", Operation_enum.EQ, companyId);
    		List<TblTenderCell> tblTenderCell = tblTenderCellDao.findTblTenderCell("cellId", Operation_enum.EQ, propertyId);
            StringBuilder couponCode = new StringBuilder(); 
            couponCode.append(tenderId+"O"+companyId);
    		modelMap.addAttribute("companyName",tblUserLogin.get(0).getUserName());
             modelMap.addAttribute("propertyName",tblTenderCell.get(0).getCellValue());
             modelMap.addAttribute("couponCode",couponCode.toString());
    	}
    	catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}
    	finally{
    		  auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),tenderDataReportId,messageSource.getMessage("tender_data_report_access",null,LocaleContextHolder.getLocale()), 0, 0);	
    	}
       return "/etender/common/propertyAllocation";
    }
    @RequestMapping(value = "/buyer/edrawreport/{tenderId}/{operation}/{commiteeType}/{enc}", method = RequestMethod.GET)
    public String showTenderEDrawReport(@PathVariable("tenderId") int tenderId,@PathVariable("operation") int operation, @PathVariable("commiteeType") int commiteeType, ModelMap modelMap, HttpServletRequest request,HttpSession session) {
        String page="";  
        int linkId=linkOpeningL1H1Report;
        try {
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) 
            {
        	tenderCommonService.tenderSummary(tenderId, modelMap, abcUtility.getSessionClientId(request));
                 modelMap.addAttribute("operation",operation);
                
                 if(abcUtility.getSessionUserTypeId(request) == 2) // If access by Bidder?
                 {
                     linkId=linkBidderL1H1Report;
                 }
                 else if(commiteeType != 1) // If access from evaluation committee member?
                 {
                     linkId=linkEvaluationL1H1Report;
                 }
                if(request.getParameter("hdisPrintPriview")!=null)
                {
                    modelMap.addAttribute("isPrintPriview",request.getParameter("hdisPrintPriview"));
                }
                 if(operation == 2 && (request.getParameter("hdisPrintPriview")==null || request.getParameter("hdisPrintPriview").equalsIgnoreCase("0")))
                {
                    List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(abcUtility.getSessionClientId(request));
                    if(!lstClientDtls.isEmpty()){
                        modelMap.addAttribute("deptName",(String) lstClientDtls.get(0)[0]);
                        modelMap.addAttribute("domainName",(String) lstClientDtls.get(0)[1]);
                    }
                }
                Map<String,Object> outMap= tenderReportService.getL1H1ReportDetail(tenderId);
                if(outMap != null && !outMap.isEmpty())
                {
                    if(outMap.get(RESULTSET_1) !=null) // Tender Form Details
                    {
                        modelMap.addAttribute("lstFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_1) );
                    }
                    if(outMap.get(RESULTSET_2) !=null) // Bidder's Grand total Form Wise
                    {
                        modelMap.addAttribute("lstBidderFormDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_2) );
                    }
                    if(outMap.get(RESULTSET_3) !=null) // Bidder Grand Total Details
                    {
                        modelMap.addAttribute("lstBidderGrandTotalDtl",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_3) );
                    }
                    if(outMap.get(RESULTSET_4) !=null) // Tender Common Details
                    {
                        modelMap.addAttribute("tblTender",(ArrayList<LinkedHashMap<String, Object>>) outMap.get(RESULTSET_4) );
                    }
                }
              
                //Start For Rebate L1 Report Generate
                if( Integer.parseInt(modelMap.get("tenderResult").toString()) == 1 && Integer.parseInt(modelMap.get("isRebateForm").toString()) == 1 && abcUtility.getSessionUserTypeId(request) == 3){
                	TblDynReport tblDynReport  = dynamicReportService.getDynReportById(tenderId,7);
       				if(tblDynReport!=null)
       					dynamicReportService.getDynamicL1H1Report(tblDynReport.getReportId(),tenderId,abcUtility.getSessionUserId(request));
                }
                //End For Rebate L1 Report Generate
               List<Object[]> celldata = tenderCommonService.getCellDataByTenderId(tenderId);
               List<Object[]> CouponCodes = tenderCommonService.getTblCouponHistoryByTenderId(tenderId);
               boolean isDraw = false;
               if(CouponCodes.size()>0){
            	   isDraw = true;
               }
               modelMap.addAttribute("celldata",celldata);
               modelMap.addAttribute("CouponCodes",CouponCodes);
               modelMap.addAttribute("isDraw",isDraw);
			if(abcUtility.getSessionUserTypeId(request) == 2){
				modelMap.addAttribute("isBidder",true);
			}else{
				modelMap.addAttribute("isBidder",false);
			}
			page = "/etender/common/TenderLotteryReport";
            }
            else
            {
                page =  "redirect:/sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getL1H1Report, tenderId, 0);
        }
        return page;
    }
}