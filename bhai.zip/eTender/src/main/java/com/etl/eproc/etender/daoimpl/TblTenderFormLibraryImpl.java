package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblTenderFormLibrary;
import com.etl.eproc.etender.daointerface.TblTenderFormLibraryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderFormLibraryImpl extends AbcAbstractClass<TblTenderFormLibrary> implements TblTenderFormLibraryDao {

 

    @Override
    public void addTblTenderFormLibrary(TblTenderFormLibrary tblTenderFormLibrary){
        super.addEntity(tblTenderFormLibrary);
    }

    @Override
    public void deleteTblTenderFormLibrary(TblTenderFormLibrary tblTenderFormLibrary) {
        super.deleteEntity(tblTenderFormLibrary);
    }

    @Override
    public void updateTblTenderFormLibrary(TblTenderFormLibrary tblTenderFormLibrary) {
        super.updateEntity(tblTenderFormLibrary);
    }

    @Override
    public List<TblTenderFormLibrary> getAllTblTenderFormLibrary() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderFormLibrary> findTblTenderFormLibrary(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderFormLibraryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderFormLibrary> findByCountTblTenderFormLibrary(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderFormLibrary(List<TblTenderFormLibrary> tblTenderFormLibrarys){
        super.updateAll(tblTenderFormLibrarys);
    }

	@Override
	public void deleteAllTblTenderFormLibrary(List<TblTenderFormLibrary> tblTenderFormLibraryList) {
		super.deleteAll(tblTenderFormLibraryList);
	}
}
