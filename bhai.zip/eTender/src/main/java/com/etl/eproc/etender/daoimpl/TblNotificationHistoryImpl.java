package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblNotificationHistory;
import com.etl.eproc.etender.daointerface.TblNotificationHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblNotificationHistoryImpl extends AbcAbstractClass<TblNotificationHistory> implements TblNotificationHistoryDao {

    @Override
    public void addTblNotificationHistory(TblNotificationHistory tblNotificationHistory){
        super.addEntity(tblNotificationHistory);
    }

    @Override
    public void deleteTblNotificationHistory(TblNotificationHistory tblNotificationHistory) {
        super.deleteEntity(tblNotificationHistory);
    }

    @Override
    public void updateTblNotificationHistory(TblNotificationHistory tblNotificationHistory) {
        super.updateEntity(tblNotificationHistory);
    }

    @Override
    public List<TblNotificationHistory> getAllTblNotificationHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNotificationHistory> findTblNotificationHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNotificationHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNotificationHistory> findByCountTblNotificationHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNotificationHistory(List<TblNotificationHistory> tblNotificationHistorys){
        super.updateAll(tblNotificationHistorys);
    }
}
