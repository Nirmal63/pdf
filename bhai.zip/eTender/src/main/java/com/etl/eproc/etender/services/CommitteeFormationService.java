/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblCentralizedCommitteeDao;
import com.etl.eproc.common.daointerface.TblCentralizedCommitteeUserDao;
import com.etl.eproc.common.daointerface.TblUserRoleDao;
import com.etl.eproc.common.model.TblCentralizedCommittee;
import com.etl.eproc.common.model.TblCentralizedCommitteeUser;
import com.etl.eproc.common.model.TblUserLogin;
import java.util.Iterator;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.etender.daointerface.TblCommitteeDao;
import com.etl.eproc.etender.daointerface.TblCommitteeEnvelopeDao;
import com.etl.eproc.etender.daointerface.TblCommitteeUserDao;
import com.etl.eproc.etender.daostoredprocedure.SPDumpEvaluationCommittee;
import com.etl.eproc.etender.model.TblCommittee;
import com.etl.eproc.etender.model.TblCommitteeEnvelope;
import com.etl.eproc.etender.model.TblCommitteeUser;

/**
 *
 * @author shreyansh.shah
 */
@Service
public class CommitteeFormationService{

    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    
    @Autowired
    private TblCommitteeDao tblCommitteeDao;
    
    @Autowired
    private TblCommitteeUserDao tblCommitteeUserDao;
    
    @Autowired
    private TblCommitteeEnvelopeDao tblCommitteeEnvelopeDao;
    
    @Autowired
    private SPDumpEvaluationCommittee spDumpEvaluationCommittee;
    
    @Autowired
	private MailContentUtillity mailContentUtillity;

    @Autowired
    private TblUserRoleDao tblUserRoleDao;
    
    @Autowired
    private TblCentralizedCommitteeDao tblCentralizedCommitteeDao;
    
    @Autowired
    private TblCentralizedCommitteeUserDao tblCentralizedCommitteeUserDao;
    @Autowired
   	private ClientService clientService;
    @Autowired
   	private TenderCommonService tenderCommonService;
   
    /**
     * author Lipi Shah
     * @param TblCentralizedCommittee
     * @return
     * @throws Exception 
     */
    @Transactional(propagation= Propagation.REQUIRED,rollbackFor=Exception.class)
	    public  boolean addTblCentralizedCommittee(TblCentralizedCommittee tblCentralizedCommittee) throws Exception{
	    boolean bSuccess = false;             
	    tblCentralizedCommitteeDao.addTblCentralizedCommittee(tblCentralizedCommittee);
	    bSuccess=true;        
	    return bSuccess;
    }
    
    /**
     * author Lipi Shah
     * @param tblCentralizedCommitteeUserList
     * @return
     * @throws Exception 
     */
    @Transactional(propagation= Propagation.REQUIRED,rollbackFor=Exception.class)
    public  boolean addTblCentralizedCommitteeUser(TblCentralizedCommitteeUser tblCentralizedCommitteeUsers) throws Exception{
	    boolean bSuccess = false;             
	    tblCentralizedCommitteeUserDao.saveOrUpdateTblCentralizedCommitteeUser(tblCentralizedCommitteeUsers);
	    bSuccess=true;        
	    return bSuccess;
    }
    
    /**
     * author Lipi Shah
     * @param committeeType
     * @return
     * @throws Exception 
     */
    public List<Object[]> getCentralizedCommUsers(int committeeType,int clientId) throws Exception{
    	Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeType",committeeType);
        var.put("clientId",clientId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append(" SELECT tblUserDetail.userName,tblUserDetail.deptName,tblUserDetail.designation")
        		.append(" ,tblCentralizedCommitteeUser.tblUserLogin.userId,tblCentralizedCommitteeUser.tblUserDetail.userDetailId,tblCentralizedCommitteeUser.userRoleId")
        		.append(" ,tblCentralizedCommittee.centralizedCommitteeId,tblCentralizedCommitteeUser.centralizedCommitteeUserId,tblCentralizedCommitteeUser.tblUserLogin.loginId")
                .append(" FROM TblCentralizedCommittee tblCentralizedCommittee")
                .append(" INNER JOIN tblCentralizedCommittee.tblCentralizedCommitteeUser tblCentralizedCommitteeUser")
                .append(" INNER JOIN tblCentralizedCommitteeUser.tblUserDetail tblUserDetail")
                .append(" WHERE tblCentralizedCommittee.centralizedCommitteeType=:committeeType AND tblCentralizedCommittee.isActive=1 AND tblCentralizedCommitteeUser.isApproved=1")
        		.append(" AND tblCentralizedCommittee.tblClient.clientId=:clientId")
        		.append(" ORDER BY tblCentralizedCommitteeUser.centralizedCommitteeUserId");
        return hibernateQueryDao.createNewQuery(strQuery.toString(),var);  
    }
    
    /**
     * 
     * @author Lipi Shah
     * @param centralizedCommitteeUserId
     * @param isApproved
     * @return
     * @throws Exception 
     */
    public TblCentralizedCommitteeUser getCentralizedCommitteeUserDetails(int centralizedCommitteeId,int userDetailId) throws Exception{
    	List<TblCentralizedCommitteeUser> list = new ArrayList<TblCentralizedCommitteeUser>();
    	list = tblCentralizedCommitteeUserDao.findTblCentralizedCommitteeUser("tblCentralizedCommittee.centralizedCommitteeId", Operation_enum.EQ, centralizedCommitteeId, "tblUserDetail.userDetailId", Operation_enum.EQ, userDetailId);
    	return (list!=null && !list.isEmpty()) ? list.get(0) : null; 
    }
    /**
     * 
     * @author Lipi Shah
     * @param centralizedCommitteeId
     * @param isApproved
     * @return
     * @throws Exception 
     */
    public List<TblCentralizedCommitteeUser> getCentralizedCommitteeUsers(int centralizedCommitteeId,int isApproved) throws Exception{
    	return tblCentralizedCommitteeUserDao.findTblCentralizedCommitteeUser("tblCentralizedCommittee.centralizedCommitteeId", Operation_enum.EQ, centralizedCommitteeId, "isApproved", Operation_enum.EQ, isApproved);
    }
    
    /**
     * 
     * @author Lipi Shah
     * @param centralizedCommitteeType
     * @param isApproved
     * @return
     * @throws Exception 
     */
    public TblCentralizedCommittee getCentralizedCommitteeDetails(int centralizedCommitteeType,int clientId) throws Exception{
    	List<TblCentralizedCommittee> list = new ArrayList<TblCentralizedCommittee>();
    	list = tblCentralizedCommitteeDao.findTblCentralizedCommittee("centralizedCommitteeType", Operation_enum.EQ, centralizedCommitteeType,"tblClient.clientId",Operation_enum.EQ,clientId);
    	return (list!=null && !list.isEmpty()) ? list.get(0) : null; 
    }
    /**
     * 
     * @author Lipi Shah
     * @param clientId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getPendingTenderWithoutCreateComm(int clientId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId",clientId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append(" SELECT tblTender.tenderId,tblDepartment.tblClient.clientId")
                .append(" FROM TblCommittee tblCommittee RIGHT JOIN tblCommittee.tblTender tblTender ")
                .append(" LEFT JOIN tblTender.tblDepartment tblDepartment ")
                .append(" WHERE tblTender.cstatus=0 AND tblCommittee.committeeId IS NULL AND tblDepartment.tblClient.clientId=:clientId");
        return hibernateQueryDao.createNewQuery(strQuery.toString(),var);
    }
    /**
     * @author Lipi Shah
     * @return
     * @throws Exception 
     */
    public List<Object[]> getCommUserCertStatus(int committeeId,int isDualCerti,String tenderOpeningDateTime,int from) throws Exception{
        StringBuilder query = new StringBuilder(" SELECT tblCommitteeUser.officerId AS c0,uc.userId AS c1,uc.certId AS c2,c.endDate AS c3,");
        query.append(" CASE WHEN (c.endDate IS NOT NULL) and c.endDate<getutcdate() THEN 'true' ELSE 'false' END AS c4,");
        query.append(" CASE WHEN (c.endDate IS NOT NULL) and DATEDIFF(DAY, getutcdate(), c.endDate)>=0 THEN 'true' ELSE 'false' END AS c5,");
        query.append(" CASE WHEN (tblCrlDetail.serialNo IS NOT NULL and tblCrlMaster.issuer IS NOT NULL) THEN 'true' ELSE 'false' END AS c6,");
        query.append(" CASE WHEN (uc.certId IS null) THEN 'true' ELSE 'false' END AS c7");
        query.append(" ,GETUTCDATE() as c8");
        if(from==1){//1-individual TOC
        	query.append(" ,CASE WHEN (c.endDate IS NOT NULL) and c.endDate<'" + (!tenderOpeningDateTime.isEmpty() ? CommonUtility.convertUtcTimezone(tenderOpeningDateTime) : "") + "' THEN 'true' ELSE 'false' END AS c9");
        	query.append(" ,tblCommitteeUser.isDecryptor AS c10");
        }
        if(from==1){//1-individual TOC
        	query.append(" FROM apptender.tbl_CommitteeUser tblCommitteeUser ");
        }else{//2-centralized TOC
        	query.append(" FROM apptender.tbl_CentralizedCommitteeUser tblCommitteeUser ");
        }
        query.append(" INNER JOIN appuser.tbl_UserLogin tblUserLogin ON tblUserLogin.userId = tblCommitteeUser.officerId");
        query.append(" LEFT JOIN appuser.tbl_UserCertificate uc ON uc.userId = tblUserLogin.userId and uc.keyUsage=2");
        query.append(" LEFT JOIN appuser.tbl_Certificate c ON uc.certId = c.certId");
        query.append(" LEFT JOIN appclient.tbl_CrlDetail tblCrlDetail ON tblCrlDetail.serialNo = c.serialNumber");
        query.append(" LEFT JOIN appclient.tbl_CrlMaster tblCrlMaster ON  c.issuer = tblCrlMaster.issuer and  tblCrlMaster.crlId   = tblCrlDetail.crlId");
        if(from==1){
        	query.append(" WHERE tblCommitteeUser.committeeId = "+committeeId+"");
        }else{
        	query.append(" WHERE tblCommitteeUser.centralizedCommitteeId = "+committeeId+" AND tblCommitteeUser.isApproved=1");
        }
        query.append(" AND (CASE WHEN uc.isDualCert IS NULL THEN 0 ELSE uc.isDualCert END )IN("+isDualCerti+",0)");
        query.append(" GROUP BY tblCommitteeUser.officerId,uc.userId,uc.certId,c.endDate,tblCrlDetail.serialNo, tblCrlMaster.issuer");
        if(from==1){
        	query.append(" ,tblCommitteeUser.isDecryptor ORDER BY MAX(tblCommitteeUser.committeeUserId)");
        }else{
        	query.append(" ORDER BY MAX(tblCommitteeUser.centralizedCommitteeUserId)");
        }
        if(from==1){
        	int nVarCharColumnIndex [] = {3,9};
        	return hibernateQueryDao.createSQLQuery(query.toString(),null,nVarCharColumnIndex,11);
        }else{
        	int nVarCharColumnIndex [] = {3};
        	return hibernateQueryDao.createSQLQuery(query.toString(),null,nVarCharColumnIndex,8);
        }
    }
     
    
    /**
     * 
     * @param tblcommittee
     * @return
     * @throws Exception 
     */
    @Transactional(propagation= Propagation.REQUIRED,rollbackFor=Exception.class)
    public  boolean addTblCommitteeMember(TblCommittee tblcommittee,List<TblCommitteeUser> tblcommitteeuser) throws Exception{
    boolean bSuccess = false;             
                tblCommitteeDao.addTblCommittee(tblcommittee);
                tblCommitteeUserDao.saveUpdateAllTblCommitteeUser(tblcommitteeuser);
            bSuccess=true;        
        return bSuccess;

    }


    /**
     * 
     * @param tblcommitteeuser
     * @return
     * @throws Exception 
     */
    public  boolean addTblCommitteeUser(List<TblCommitteeUser> tblcommitteeuser) throws Exception{
    boolean bSuccess = false;             
                tblCommitteeUserDao.saveUpdateAllTblCommitteeUser(tblcommitteeuser);
            bSuccess=true;        
        return bSuccess;

    }
    
         /**
     * 
     * @param committeeId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getAllCommitteeMemberDetails(int committeeId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId",committeeId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append("select tbluserdetail.tblUserLogin.userId, tbluserdetail.loginId, tbluserdetail.userName, tbluserdetail.deptName, ")
                .append("tbluserdetail.designation, tblcommitteeuser.approvedOn, tbluserdetail.userDetailId ")
                .append("from TblCommitteeUser tblcommitteeuser inner join tblcommitteeuser.tblUserDetail tbluserdetail ")
                .append("where tblcommitteeuser.tblCommittee.committeeId=:committeeId");
        return hibernateQueryDao.createNewQuery(strQuery.toString(),var);                
    }
    
        /**
     * 
     * @param remarks
     * @param userId
     * @param committeeId
     * @param publishedOn
     * @return
     * @throws Exception 
     */
    public boolean approveCommittee(String remarks,int userDetailsId,int committeeId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("remarks",remarks);
        var.put("userDetailsId",userDetailsId);
        var.put("committeeId",committeeId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append("update TblCommittee set isApproved=1 , publishedBy=:userDetailsId , publishedOn=getutcdate(), ")
                .append("isActive=1, remarks=:remarks where committeeId=:committeeId");
        cnt = hibernateQueryDao.updateDeleteNewQuery(strQuery.toString(),var);        
        return cnt!=0;

    }
    
        /**
     * 
     * @param committeeId
     * @return
     * @throws Exception 
     */
    public boolean deleteMembersByComitteeId(int committeeId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId",committeeId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblCommitteeUser tblcommitteeuser where tblcommitteeuser.tblCommittee.committeeId=:committeeId",var);        
        return cnt!=0;

    }
    
    /**
     * 
     * @param committeeId
     * @param tblCommitteeUser
     * @return
     * @throws Exception 
     */
    @Transactional(propagation= Propagation.REQUIRED,rollbackFor=Exception.class)
    public boolean updateRemoveCommitteeMembers(int committeeId,List<TblCommitteeUser> tblCommitteeUser) throws Exception{
        int cnt = 0;
        boolean isSuccess = false;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId",committeeId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblCommitteeUser tblcommitteeuser where tblcommitteeuser.tblCommittee.committeeId=:committeeId",var);        
        if(cnt!=0) {
          isSuccess =  addTblCommitteeUser(tblCommitteeUser);
        }
        return isSuccess;

    }
        /**
     * 
     * @param approvedBy
     * @param approvedOn
     * @param committeeUserId
     * @return
     * @throws Exception 
     */
    public boolean approvePreBidComitteeMember(int approvedBy,int committeeUserId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("approvedBy",approvedBy);
        var.put("committeeUserId",committeeUserId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblCommitteeUser set isApproved=1 , approvedBy=:approvedBy , approvedOn=getutcdate() where committeeUserId=:committeeUserId",var);        
        return cnt!=0;

    }
    
    /**
     * 
     * @author bhavin.patel
     * @param tblcommittee
     * @param tblcommitteeusers
     * @param tbltenderenvelopes
     * @param committeeType
     * @param action 0 = Add Committee, 1 = Edit Committee
     * @return
     * @throws Exception 
     */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public boolean addCommittee(TblCommittee tblCommittee, List<TblCommitteeUser> tblCommitteeUsers, List<TblCommitteeEnvelope> tblCommitteeEnvelopes, int committeeType, int action) throws Exception {
		boolean bSuccess = false;
		if(action == 0){
			tblCommitteeDao.addTblCommittee(tblCommittee);
		}
		else if(action == 1){
			deleteMembersByComitteeId(tblCommittee.getCommitteeId());
			deleteCommitteeEnvelope(tblCommittee.getCommitteeId());			
		}
		tblCommitteeUserDao.saveUpdateAllTblCommitteeUser(tblCommitteeUsers);
		tblCommitteeEnvelopeDao.saveUpdateAllTblCommitteeEnvelope(tblCommitteeEnvelopes);
		bSuccess = true;
		return bSuccess;
	}
     
      /**
      * @auther Mitesh
      * @param envupdateMap
      * @return
      * @throws Exception 
      */
     public boolean updateEnvelopeIsEvaluated(Map<Integer,Integer> envUpdateIsApprovedMap,Map<Integer,Integer> envUpdateIsEvaluatedMap,int committeeId) throws Exception{
        int cnt = 0;
        //update comitteeUser isApproved
        Set<Integer> s=envUpdateIsApprovedMap.keySet();
         for (Integer key : s) {
              Map<String, Object> var = new HashMap<String, Object>();
              var.put("isApproved",envUpdateIsApprovedMap.get(key));
              var.put("envelopeId",key);
              var.put("committeeId",committeeId);
              cnt = hibernateQueryDao.updateDeleteNewQuery("update TblCommitteeUser tblCommitteeUser set tblCommitteeUser.isApproved=:isApproved where tblCommitteeUser.tblCommittee.committeeId=:committeeId and tblCommitteeUser.childId=:envelopeId",var);        
         }
       //update tenderEnvelope isEvaulated=1
         s=envUpdateIsEvaluatedMap.keySet();
         for (Integer key : s) {
              Map<String, Object> var = new HashMap<String, Object>();
              var.put("isEvaluated",envUpdateIsEvaluatedMap.get(key));
              var.put("envelopeId",key);
              cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope tblTenderEnvelope set tblTenderEnvelope.isEvaluated =:isEvaluated where tblTenderEnvelope.envelopeId=:envelopeId",var);        
         }
        return cnt!=0;

    }
      
	/**
	 * 
     * @author bhavin.patel
     * @param committeeId
     * @return
     * @throws Exception 
     */
    public boolean deleteCommitteeEnvelope(int committeeId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId",committeeId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblCommitteeEnvelope tblcommitteeenvelope where tblcommitteeenvelope.tblCommittee.committeeId=:committeeId",var);        
        return cnt!=0;

    }
    
    /**
	 * 
     * @author bhavin.patel
     * @param remarks
     * @param clientId
     * @param publishedBy
     * @param committeeId
     * @param committeeType
     * @param tenderId
     * @param dumpAsTec
     * @param isDualCertd
     * @return
     * @throws Exception 
     */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
	public boolean publishCommittee(String remarks, int clientId, int publishedBy, int committeeId, int committeeType, int tenderId, int dumpAsTec, int isDualCert,Map<String, Object> paramMap) throws Exception {
		boolean bSuccess = false;
		String mailTempId = null;
		inActivePrevCommittee(tenderId, committeeType);
		approveCommittee(remarks, publishedBy, committeeId);
		updateMinApprovalForEnvelope(committeeId, committeeType);
		if(committeeType == 1){
			if(!isBidEncrypted(tenderId)){
				deleteTenderPublicKey(tenderId);
				addDecryptorPublicKey(committeeId, tenderId, publishedBy, isDualCert);
			}
			mailTempId = "38";
		}
		else if (committeeType == 2){
			mailTempId = "40";
		}
		
		if(dumpAsTec == 1){
			spDumpEvaluationCommittee.executeProcedure(clientId, publishedBy, committeeId, tenderId);
		}
		Map<String,String> addedMember=new HashMap<String, String>();
                Map<String,String> removedMember=new HashMap<String, String>();
//		mailContentUtillity.dynamicMailGeneration(mailTempId, String.valueOf(publishedBy), String.valueOf(tenderId), paramMap, String.valueOf(committeeId));		
                processCommiteeEditSendMail(addedMember,removedMember,tenderId, committeeType,committeeId,String.valueOf(publishedBy),paramMap,clientId);
		bSuccess = true;
		return bSuccess;
	}
    
    /**
     * @auther Priyanka Dalwadi
     * @param addedMember
     * @param removedMember
     * @param tenderId
     * @param committeeType
     * @param committeeId
     * @throws Exception 
     */
    private void processCommiteeEditSendMail(Map<String,String> addedMember,Map<String,String> removedMember, int tenderId, int committeeType, int committeeId,String publishedBy,Map<String, Object> paramMap,int clientId) throws Exception {
        List<Object[]> lastCommiteeeId =null;
        int oldCommiteeId=0;
        String envelopeName = "";
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("committeeType", committeeType);
        StringBuilder query= new StringBuilder();
        query.append("select tblCommittee.committeeId,tblCommittee.tblTender.tenderId ");
        query.append(" from TblCommittee tblCommittee where tblCommittee.tblTender.tenderId=:tenderId and tblCommittee.committeeType=:committeeType");
        query.append(" order by tblCommittee.committeeId desc");
        lastCommiteeeId = hibernateQueryDao.createNewQuery(query.toString(), var); 
        if(lastCommiteeeId!=null && lastCommiteeeId.size() > 1){
                oldCommiteeId =Integer.parseInt(lastCommiteeeId.get(1)[0].toString());
        }
        //1)create the map with envlopeId,envelopeName
        Map<String,String> envMap=new HashMap<String, String>();
        var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query= new StringBuilder();
        query.append("select tblTenderEnvelope.envelopeId,tblTenderEnvelope.envelopeName ");
        query.append("from TblTenderEnvelope tblTenderEnvelope where tblTenderEnvelope.tblTender.tenderId=:tenderId");
        List<Object[]> envData= hibernateQueryDao.createNewQuery(query.toString(), var); 
        for (Object[] envObject : envData) {
            envMap.put(envObject[0].toString(), envObject[1].toString());
        }
        //2)get the old commitee data
        List<TblCommitteeUser> oldTblCommitteeUser = null;
        List<TblCommitteeUser> newTblCommitteeUser = null;
        if(oldCommiteeId!=0){
            oldTblCommitteeUser = tblCommitteeUserDao.findTblCommitteeUser("tblCommittee", Operation_enum.EQ, new TblCommittee(oldCommiteeId));        
        }
        newTblCommitteeUser = tblCommitteeUserDao.findTblCommitteeUser("tblCommittee", Operation_enum.EQ, new TblCommittee(committeeId));
        if(oldTblCommitteeUser!=null && newTblCommitteeUser!=null){
            if(oldTblCommitteeUser.size()>0 && newTblCommitteeUser.size() > 0){
                for (TblCommitteeUser tblCommiteeUser : newTblCommitteeUser) {
                    boolean exitMemer=false;
                    for(TblCommitteeUser oldTblCommiteeUser : oldTblCommitteeUser){
                        if(oldTblCommiteeUser.getTblUserLogin().getUserId() == tblCommiteeUser.getTblUserLogin().getUserId() && oldTblCommiteeUser.getChildId()==tblCommiteeUser.getChildId()){
                            exitMemer = true;
                        }
                    }
                    if(!exitMemer){
                    	String role="";
                    	if(tblCommiteeUser.getUserRoleId()==1){
                    		role = "Chairperson";
                    	}else{
                    		role = "Member";
                    	}
                    	if(envelopeName!=""){
                    		envelopeName = envelopeName + ",";
                    	}
                    	envelopeName = envelopeName + "" +envMap.get(String.valueOf(tblCommiteeUser.getChildId())) ;
                        addedMember.put(tblCommiteeUser.getTblUserLogin().getUserId()+":~"+tblCommiteeUser.getTblUserLogin().getLoginId()+":~"+role, envelopeName+"");
                    }
                }
                //removed
                for (TblCommitteeUser tblCommiteeUser : oldTblCommitteeUser) {
                    boolean exitMemer=false;
                    for(TblCommitteeUser oldTblCommiteeUser : newTblCommitteeUser){
                        if(oldTblCommiteeUser.getTblUserLogin().getUserId() == tblCommiteeUser.getTblUserLogin().getUserId() && oldTblCommiteeUser.getChildId()==tblCommiteeUser.getChildId()){
                            exitMemer = true;
                        }
                    }
                    if(!exitMemer){
                    	String role="";
                    	if(tblCommiteeUser.getUserRoleId()==1 ){
                    		role = "Chairperson";
                    	}else{
                    		role = "Member";
                    	}
                        removedMember.put(tblCommiteeUser.getTblUserLogin().getUserId()+":~"+tblCommiteeUser.getTblUserLogin().getLoginId()+":~"+role, tblCommiteeUser.getChildId()+"");
                    }
                }
            }
        }
        //4) get the designation role map
        Map<String, String> desigRoleIdMap=new HashMap<String, String>();
       
        //3)send mail to added member
        String encryptUrlStr = "https://"+clientService.getClientNameById(clientId);					 
        String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\"> "+clientService.getClientNameById(clientId)+"  </a>"; 
        Map<String, Object> dataMap=null;
        Set<String> s=addedMember.keySet();
        Iterator iter = s.iterator();
        while(iter.hasNext()){
            String key=(String)iter.next();
            String keyArray[]=key.split(":~");
            dataMap = new HashMap<String, Object>();
            dataMap.put("to", keyArray[1]);
            dataMap.put("EventId", tenderId);
            dataMap.put("EventBrief", paramMap.get("tenderBrief"));
            dataMap.put("EventOpeningDate", paramMap.get("EventOpeningDate"));
            dataMap.put("ReferenceNo", tenderCommonService.getTenderField(tenderId, "tenderNo"));
            dataMap.put("Envelop", envelopeName);
          //  System.out.println(keyArray[2]);
            dataMap.put("Role", keyArray[2]);
            dataMap.put("SubDomainName", hrefStr);
            dataMap.put("comiteeType", committeeType==1?"opening":"evaluation");
            mailContentUtillity.dynamicMailGeneration(committeeType==1?"263":"264", publishedBy, String.valueOf(tenderId), dataMap, "");
        }
        //4)send mail to removed mener
        s=removedMember.keySet();
        iter = s.iterator();
        while(iter.hasNext()){
            String key=(String)iter.next();
            String keyArray[]=key.split(":~");
            dataMap = new HashMap<String, Object>();
            dataMap.put("to", keyArray[1]);
            dataMap.put("EventId", tenderId);
            dataMap.put("EventBrief", paramMap.get("tenderBrief"));
            dataMap.put("Envelop", envMap.get(removedMember.get(key)));
            dataMap.put("Role", keyArray[2]);
            dataMap.put("SubDomainName", hrefStr);
            dataMap.put("comiteeType", committeeType==1?"opening":"evaluation");
            mailContentUtillity.dynamicMailGeneration(committeeType==1?"265":"266", publishedBy, String.valueOf(tenderId), dataMap, "");
        }
        if(oldCommiteeId==0 ){
        	String mailTempId = null;
        	if(committeeType == 1){
    			mailTempId = "38";
    		}
    		else if (committeeType == 2){
    			mailTempId = "40";
    		}
        	mailContentUtillity.dynamicMailGeneration(mailTempId, String.valueOf(publishedBy), String.valueOf(tenderId), paramMap, String.valueOf(committeeId));	
        }
    }
	
	/**
     * 
     * @author bhavin.patel
     * @param committeeId
     * @param tenderId
     * @param publishedBy
     * @param isDualCert
     * @return
     * @throws Exception 
     */
    public boolean addDecryptorPublicKey(int committeeId, int tenderId, int publishedBy, int isDualCert) throws Exception{
    	int cnt = 0;
    	StringBuffer query = new StringBuffer();
    	query.append("INSERT INTO apptender.tbl_TenderPublicKey (tenderId, officerId, certId, publicKey, createdBy) ");
    	query.append("SELECT DISTINCT :tenderId, tcu.officerId, uc.certId, tc.publicKey, :publishedBy FROM apptender.tbl_CommitteeUser tcu ");
    	query.append("INNER JOIN appuser.tbl_UserCertificate uc ON tcu.officerId = uc.userId AND uc.isDualCert = :isDualCert AND uc.keyUsage = :isDualCert ");
    	query.append("INNER JOIN appuser.tbl_Certificate tc ON uc.certId = tc.certId WHERE tcu.committeeId = :committeeId AND tcu.isDecryptor = 1 ");
    	
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId",committeeId);
        var.put("tenderId",tenderId);
        var.put("publishedBy",publishedBy);
        var.put("isDualCert", isDualCert);
        cnt = hibernateQueryDao.updateDeleteSQLQuery(query.toString(), var);
        return cnt!=0;
    }
	
	/**
	 * 
     * @author bhavin.patel
     * @param tenderId
     * @param committeeType
     * @return
     * @throws Exception 
     */
	public boolean inActivePrevCommittee(int tenderId, int committeeType) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("committeeType",committeeType);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblCommittee tblcommittee set tblcommittee.isActive=0 where tblcommittee.tblTender.tenderId=:tenderId and tblcommittee.committeeType=:committeeType",var);        
        return cnt!=0;
    }
	
	/**
     * 
     * @author bhavin.patel
     * @param committeeId
     * @param committeeType
     * @return
     * @throws Exception 
     */
    public void updateMinApprovalForEnvelope(int committeeId, int committeeType) throws Exception{
    	List<TblCommitteeEnvelope> tblCommitteeEnvelopes = tblCommitteeEnvelopeDao.findTblCommitteeEnvelope("tblCommittee", Operation_enum.EQ, new TblCommittee(committeeId));

    	if(tblCommitteeEnvelopes != null && !tblCommitteeEnvelopes.isEmpty()){
    		for(TblCommitteeEnvelope tblCommitteeEnvelope : tblCommitteeEnvelopes){
    			Map<String, Object> map = new HashMap<String, Object>();
    			map.put("minMemberApproval", tblCommitteeEnvelope.getMinMemberApproval());
    			map.put("envelopeId", tblCommitteeEnvelope.getTblTenderEnvelope().getEnvelopeId());		
    			if(committeeType == 1){
    				hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minOpeningMember = :minMemberApproval where envelopeId = :envelopeId ", map);
    	    	}
    	    	else if (committeeType == 2){
    	    		hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minEvaluator = :minMemberApproval where envelopeId = :envelopeId ", map);
    	    	}
    		}
    	}
    }
    
    /**
     * @author bhavin.patel
     * @param committeeId
     * @param envelopeId
     * @return
     * @throws Exception 
     */
    public int getMinApprovalCount(int committeeId,int envelopeId) throws Exception{
        int data=0;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId",committeeId);
        var.put("envelopeId",envelopeId);
        list = hibernateQueryDao.getSingleColQuery("select tblcommitteeenvelope.minMemberApproval from TblCommitteeEnvelope tblcommitteeenvelope where tblcommitteeenvelope.tblTenderEnvelope.envelopeId=:envelopeId and tblcommitteeenvelope.tblCommittee.committeeId=:committeeId",var);
        if(list != null && !list.isEmpty()){
        	data = (Integer) list.get(0);
        }
        return data;
    }
    
    /**
	 * 
     * @author bhavin.patel
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public boolean deleteTenderPublicKey(int tenderId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderPublicKey tbltenderbublickey where tbltenderbublickey.tblTender.tenderId = :tenderId",var);        
        return cnt!=0;

    }
    
    /**
     * 
     * @author bhavin.patel
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderEnvelopesDetails(int tenderId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuffer query = new StringBuffer();
        query.append(" select tbltenderenvelope.tblEnvelope.envId, tbltenderenvelope.envelopeName,");
        query.append(" tbltenderenvelope.envelopeId, tbltenderenvelope.isOpened, tbltenderenvelope.isEvaluated, sum(tbltenderform.isEncryptionReq)");
        query.append(" from TblTenderForm tbltenderform");
        query.append(" inner join tbltenderform.tblTenderEnvelope tbltenderenvelope");
        query.append(" where tbltenderenvelope.tblTender.tenderId =:tenderId");
        query.append(" group by tbltenderenvelope.tblEnvelope.envId, tbltenderenvelope.envelopeName, tbltenderenvelope.envelopeId, tbltenderenvelope.isOpened, tbltenderenvelope.isEvaluated, tbltenderenvelope.sortOrder");
        query.append(" order by tbltenderenvelope.sortOrder");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;
    }
    
    /** Get the CommitteeEnvelope Details by committeeId,envelopeId
     * @auther Mitesh
     * @param committeeId
     * @param envelopeId
     * @return
     * @throws Exception 
     */
     public List<Object[]> getCommitteeEnvelopeDetails(int committeeId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId",committeeId);
        StringBuffer query = new StringBuffer();
        query.append(" select tblCommitteeEnvelope.tblTenderEnvelope.envelopeId, tblCommitteeEnvelope.minMemberApproval ");
        query.append(" from TblCommitteeEnvelope tblCommitteeEnvelope ");
        query.append("where tblCommitteeEnvelope.tblCommittee.committeeId =:committeeId ");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;
    }
    /**
     * 
     * @author bhavin.patel
     * @param committeeName
     * @param committeeType
     * @param clientId
     * @return
     * @throws Exception 
     */
    public boolean checkUniqueCommitteeName(String committeeName,int committeeType,int clientId) throws Exception{
        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeName",committeeName);
        var.put("committeeType",committeeType);
        var.put("clientId",clientId);
        count = hibernateQueryDao.countForNewQuery("TblCommittee tblcommittee inner join tblcommittee.tblClient tblclient ","tblcommittee.committeeId ","tblcommittee.committeeName=:committeeName and tblcommittee.committeeType=:committeeType and tblcommittee.tblClient.clientId=:clientId",var);
        return count!=0;
    }
    
    /**
     * 
     * @author Lipi shah
     * @param tenderId
     * @param committeeType
     * @param clientId
     * @return
     * @throws Exception 
     */
//    public boolean checkCommMappedWithEnvlopeorNot(int committeeType,int tenderId,int clientId) throws Exception{
//        long count=0;
//        Map<String, Object> var = new HashMap<String, Object>();
//        var.put("tenderId",tenderId);
//        var.put("committeeType",committeeType);
//        var.put("clientId",clientId);
//        count = hibernateQueryDao.countForNewQuery("TblCommitteeUser tblCommitteeUser INNER JOIN tblCommitteeUser.tblCommittee CM ","tblCommitteeUser.committeeUserId ","CM.committeeType=:committeeType AND CM.tblTender.tenderId=:tenderId AND CM.tblClient.clientId=:clientId AND CM.isActive=1 AND tblCommitteeUser.childId=0",var);
//        return count!=0;
//    }
    
    
    /**
     * 
     * @author bhavin.patel
     * @param tenderId
     * @param committeeType
     * @param isView 0=Get active committee, 1=View
     * @return
     * @throws Exception 
     */
    public List<Object[]> getCommitteeDetails(int tenderId, int committeeType, int isView) throws Exception{
        List<Object[]> list = null;
        StringBuffer query = new StringBuffer();
        query.append("select tblcommittee.committeeId, tblcommittee.committeeName, tblcommittee.isStandard, tblcommittee.isApproved, tblcommittee.isActive, (select tbluserdetail.userName from TblUserDetail tbluserdetail where tbluserdetail.userDetailId = tblcommittee.publishedBy), tblcommittee.publishedOn ");
        query.append("from TblCommittee tblcommittee where tblcommittee.tblTender.tenderId=:tenderId and tblcommittee.committeeType=:committeeType ");
        query.append("order by tblcommittee.committeeId desc ");
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("committeeType",committeeType);
        if(isView == 1){
        	list = hibernateQueryDao.createNewQuery(query.toString(), var);
        }
        else {
        	list = hibernateQueryDao.createNewQuery(query.toString(), var);
        }
        return list;
    }
    
    /**
     * 
     * @author bhavin.patel
     * @param tenderId
     * @param committeeId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getCommitteeUserDetails(int tenderId, int committeeId) throws Exception{
        List<Object[]> list = null;
        StringBuffer query = new StringBuffer();
        query.append("select tbluserdetail.userName, tbluserdetail.deptName, tbluserdetail.designation, tblcommitteeuser.tblUserLogin.userId, tblcommitteeuser.tblUserDetail.userDetailId, tblcommitteeuser.isDecryptor, ");
        query.append("tblcommitteeuser.encryptionLevel, MAX(tbltenderpublickey.tenderPublicKeyId),tblcommitteeuser.userRoleId,");
        query.append("(select tblUserRole.userRole from TblUserRole tblUserRole where tblUserRole.userRoleId=tblcommitteeuser.userRoleId),tblcommitteeuser.tblUserDetail.loginId");
        query.append(" from TblCommitteeUser tblcommitteeuser inner join ");
        query.append("tblcommitteeuser.tblUserDetail tbluserdetail inner join tblcommitteeuser.tblUserLogin tbluserlogin left join tbluserlogin.tblTenderPublicKey tbltenderpublickey with ");
        query.append("tbltenderpublickey.tblTender.tenderId = :tenderId where tblcommitteeuser.tblCommittee.committeeId = :committeeId group by tbluserdetail.userName, tbluserdetail.deptName, tbluserdetail.designation, ");
        query.append("tblcommitteeuser.tblUserLogin.userId, tblcommitteeuser.tblUserDetail.userDetailId, tblcommitteeuser.isDecryptor, tblcommitteeuser.encryptionLevel,tblcommitteeuser.userRoleId,tblcommitteeuser.tblUserDetail.loginId order by MAX(tblcommitteeuser.committeeUserId) ");
        
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("committeeId",committeeId);
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;
    }
    
    /**
     * 
     * @author bhavin.patel
     * @param committeeId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getCommitteeMinApproval(int committeeId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId",committeeId);
        list = hibernateQueryDao.createNewQuery("select tblcommitteeuser.childId, count(tblcommitteeuser.tblUserLogin.userId) as totalApproval, tblcommitteeenvelope.minMemberApproval, tbltenderenvelope.isOpened, tbltenderenvelope.isEvaluated,(select count(c.isApproved) from  TblCommitteeUser c where c.tblCommittee.committeeId =:committeeId and c.childId = tblcommitteeuser.childId and c.isApproved =1) from TblCommittee tblcommittee inner join tblcommittee.tblCommitteeUser tblcommitteeuser inner join tblcommittee.tblCommitteeEnvelope tblcommitteeenvelope inner join tblcommitteeenvelope.tblTenderEnvelope tbltenderenvelope where tblcommitteeuser.childId = tblcommitteeenvelope.tblTenderEnvelope.envelopeId and tblcommittee.committeeId = :committeeId group by tblcommitteeuser.childId, tblcommitteeenvelope.minMemberApproval, tbltenderenvelope.isOpened, tbltenderenvelope.isEvaluated order by tblcommitteeuser.childId",var);                
        return list;
    }  
    
    /**
     * 
     * @author Priyanka Dalwadi
     * @param committeeId
     * @param isApproved
     * @return
     * @throws Exception 
     */
    public List<TblCommitteeUser> getCommitteeUserApprovalDetailForEditCommitee(int committeeId, int officerid,int childId,int isApproved) throws Exception{
        return tblCommitteeUserDao.findTblCommitteeUser("tblCommittee", Operation_enum.EQ, new TblCommittee(committeeId),"childId",Operation_enum.EQ,childId,"tblUserLogin",Operation_enum.EQ,new TblUserLogin(officerid), "isApproved", Operation_enum.EQ, isApproved);        
    }
    
    
    /**
     * 
     * 
     * 
     * @author bhavin.patel
     * @param committeeId
     * @param isApproved
     * @return
     * @throws Exception 
     */
    public List<TblCommitteeUser> getCommitteeUserApprovalDetails(int committeeId, int isApproved) throws Exception{
        return tblCommitteeUserDao.findTblCommitteeUser("tblCommittee", Operation_enum.EQ, new TblCommittee(committeeId), "isApproved", Operation_enum.EQ, isApproved);        
    }
        
    /**
     * 
     * @author bhavin.patel
     * @param committeeId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getCommitteeUserEnvelopeDetails(int committeeId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId",committeeId);
        list = hibernateQueryDao.createNewQuery("select tblcommitteeuser.tblUserLogin.userId, tblcommitteeuser.childId, tblcommitteeuser.isApproved from TblCommitteeUser tblcommitteeuser where tblcommitteeuser.tblCommittee.committeeId=:committeeId",var);                
        return list;
    }
    
    /**
     * 
     * @author bhavin.patel
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getCommitteeCountForTender(int tenderId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        list = hibernateQueryDao.createNewQuery("select SUM(case when tblcommittee.committeeType = 1 then 1 else 0 end),SUM(case when tblcommittee.committeeType = 2 then 1 else 0 end) from TblCommittee tblcommittee where tblcommittee.tblTender.tenderId = :tenderId",var);               
        return list;
    }    
    
    /**
     * 
     * @author bhavin.patel
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public boolean isBidEncrypted(int tenderId) throws Exception{
        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        count = hibernateQueryDao.countForNewQuery("TblTenderBid tbltenderbid inner join tbltenderbid.tblTenderForm tbltenderform","tbltenderform.formId","tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isEncryptionReq = 1 and tbltenderform.cstatus != 2",var);
        return count!=0;
    }
    
    /**
     * @auther Mitesh
     * @return
     * @throws Exception 
     */
     public List<Object[]> getAllUserRole() throws Exception{
        List<Object[]> list = null;
        list = hibernateQueryDao.createNewQuery("select tblUserRole.userRoleId,tblUserRole.userRole from TblUserRole tblUserRole",null);               
        return list;
    }  
     
     /** Get the CommitteeDetails for the committeRemarks.
      * @auther Mitesh
      * @param tenderId
      * @param envelopeId
      * @return
      * @throws Exception 
      */
     public List<Object[]> getCommiteeUserDetailsByTenderId(int tenderId,int envelopeId,int committeeType) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("childId",envelopeId);
        var.put("committeeType",committeeType);
        
        StringBuilder query=new StringBuilder();
        query.append(" select tblCommitteeUser.committeeUserId,tblCommitteeUser.tblUserLogin.userId,tblCommitteeUser.userRoleId, ");
        query.append(" (case tblCommitteeUser.userRoleId  when '1' then 'Chairperson/Checker' when '2' then 'Member/Maker' when '0' then '' end),tblCommitteeUser.encryptionLevel,tblCommitteeUser.tblUserDetail.userName,tblCommittee.committeeId ");
        query.append(" from TblCommittee tblCommittee ");
        query.append(" inner join tblCommittee.tblCommitteeUser tblCommitteeUser with tblCommitteeUser.childId=:childId ");
        query.append(" where tblCommittee.tblTender.tenderId=:tenderId and tblCommittee.committeeType=:committeeType");
        query.append(" AND tblCommittee.isActive=1");
        query.append(" order by tblCommitteeUser.encryptionLevel asc ,tblCommitteeUser.userRoleId desc");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);               
        return list;
    }  
     
    /** Get the commiteeRemarks details for the remarks page.
     * @auther Mitesh
     * @param tenderId
     * @param envelopeId
     * @return
     * @throws Exception 
     */ 
    public List<Object[]> getCommiteeRemarksDetails(int tenderId,int envelopeId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        StringBuilder query=new StringBuilder();
        query.append(" select tblCommitteeRemarks.committeeRemarksId,tblCommitteeRemarks.tblCompany.companyId,tblCommitteeRemarks.bidderId,tblCommitteeRemarks.tblUserLogin.userId, ");
        query.append("tblCommitteeRemarks.remarks,tblCommitteeRemarks.isCPRemarks,tblCommitteeRemarks.childId from TblCommitteeRemarks tblCommitteeRemarks ");
        query.append("where tblCommitteeRemarks.tblTender.tenderId=:tenderId and tblCommitteeRemarks.tblTenderEnvelope.envelopeId=:envelopeId and tblCommitteeRemarks.isActive=1");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);               
        return list;
    }
    
    /** Get the user's Certificate EndDate
     * @auther Lipi 
     * @param userId
     * @param isDualCert
     * @return
     * @throws Exception 
     */ 
    public String getUserCertEndDate(int userId,int isDualCert) throws Exception{
        String data=null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId",userId);
        var.put("isDualCert",isDualCert);
        StringBuilder query=new StringBuilder();
        query.append("SELECT tblCertificate.endDate");
        query.append(" FROM TblUserCertificate tblUserCertificate");
        query.append(" INNER JOIN tblUserCertificate.tblCertificate tblCertificate");
        query.append(" WHERE tblUserCertificate.tblUserLogin.userId=:userId AND tblUserCertificate.isDualCert=:isDualCert");
        List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(),var);                
        if(list!=null && !list.isEmpty()){            
            data = list.get(0).toString();
        }
        return data;
    }
    /** Get the user encryption level
     * @author Lipi
     * @param tenderId
     * @param envelopeId
     * @param sessionUserId
     * @return
     * @throws Exception 
     */ 
    public List<Object> getCommiteeEncryptionLevel(int tenderId,int envelopeId,int sessionUserId) throws Exception{
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId", envelopeId);
    	var.put("sessionUserId", sessionUserId);
    	var.put("tenderId", tenderId);
        StringBuilder query=new StringBuilder();
        query.append(" SELECT  tblCommitteeUser.encryptionLevel ");
    	query.append(" FROM TblCommitteeUser tblCommitteeUser");
    	query.append(" INNER JOIN tblCommitteeUser.tblCommittee tblCommittee");
    	query.append(" WHERE  tblCommittee.tblTender.tenderId=:tenderId");
    	query.append(" AND tblCommittee.isActive=1 AND tblCommitteeUser.isDecryptor = 1");
    	query.append(" AND tblCommitteeUser.childId=:envelopeId AND tblCommitteeUser.tblUserLogin.userId =:sessionUserId");
    	
        list = hibernateQueryDao.singleColQuery(query.toString(),var);               
        return list;
    }
   	/**
   	 * get pending committee
   	 * @author dipika
   	 */
   	public TblCommittee getPeningCommittee(int tenderId,int committeeType,int isActive,int isApproved) throws Exception {
           List<TblCommittee> list=tblCommitteeDao.findTblCommittee("tblTender.tenderId",Operation_enum.EQ,tenderId,"committeeType",Operation_enum.EQ,committeeType,"isActive",Operation_enum.EQ,isActive,"isApproved",Operation_enum.EQ,isApproved);
           return list!=null && !list.isEmpty()?list.get(0):null;
       }

	public List<Object> getUserIdfromTECMembers(int tenderId) 
	{
		List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder query=new StringBuilder();
        query.append("select tblCommitteeUser.tblUserLogin.loginId from TblCommitteeUser tblCommitteeUser ");
        query.append("INNER JOIN tblCommitteeUser.tblUserLogin tblUserLogin ");
        query.append("INNER JOIN tblCommitteeUser.tblCommittee tblCommittee ");
        query.append("where tblCommittee.tblTender.tenderId=:tenderId and tblCommittee.committeeType=2 ");
        query.append("group by tblCommitteeUser.tblUserLogin.loginId");
    	list = hibernateQueryDao.singleColQuery(query.toString(),var);               
        return list;
	}
	
	/**
   	 * get Consent Received or not for Active Committee
   	 * @author priyanka
   	 * @param tenderId
   	 */
	
	 public boolean getActiveCommiteeConsentReceived(int tenderId,int committeeType) throws Exception{
	        List<Object> list = null;
	        Map<String, Object> var = new HashMap<String, Object>();
	    	var.put("tenderId", tenderId);
	    	var.put("committeeType", committeeType);
	        StringBuilder query=new StringBuilder();
	        query.append(" SELECT tblcommittee.committeeId FROM TblCommittee  tblcommittee ");
	        query.append(" INNER JOIN tblcommittee.tblCommitteeUser tblcommitteeUser  ");
	        query.append(" WHERE tblcommittee.tblTender.tenderId = :tenderId and tblcommittee.isActive=1 and tblcommittee.isApproved=1 and tblcommitteeUser.isApproved=1 and tblcommittee.committeeType=:committeeType");
	        list = hibernateQueryDao.singleColQuery(query.toString(),var);               
	        return (list!=null && !list.isEmpty()) ? true : false;
	    }
		
	 /**
      * check committee is published or not
      * @author meghna
      * @param committeeId
      * @return
      * @throws Exception
      */
	 public boolean isCommitteeApproved(int committeeId) throws Exception {
	        long count = 0;
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put("committeeId", committeeId);
	        count = hibernateQueryDao.countForNewQuery("TblCommittee tblCommittee ", "tblCommittee.committeeId ", "tblCommittee.committeeId=:committeeId and tblCommittee.isActive=1 and tblCommittee.isApproved=1", var);
	        return count == 0;
	    }
	 
		 /**
	   * Method get Publish Pre-Bid Commitee 
	   * @author Hira Chaudhary
	   * @param tenderId
	   * @param committeeId
	   * @param committeeType
	   * @return
	   * @throws Exception
	   */
	  public boolean getPreBidCommiteePublish(int tenderId,int committeeId,int committeeType) throws Exception {
		   long count=0;
	      Map<String, Object> var = new HashMap<String, Object>();
	      var.put("tenderId",tenderId);
	      var.put("committeeType",committeeType);
	      var.put("isApproved",1);
	      if(committeeId != 0){
	   	   var.put("committeeId",committeeId);
	   	   count = hibernateQueryDao.countForNewQuery("TblCommittee tblcommittee","tblcommittee.committeeId","tblcommittee.tblTender.tenderId=:tenderId and tblcommittee.committeeId =:committeeId and tblcommittee.committeeType=:committeeType and tblcommittee.isApproved=:isApproved",var);  
	      }else {
	   	   count = hibernateQueryDao.countForNewQuery("TblCommittee tblcommittee","tblcommittee.committeeId","tblcommittee.tblTender.tenderId=:tenderId and tblcommittee.committeeType=:committeeType and tblcommittee.isApproved=:isApproved",var);
	      }
	      return count!=0;
	  }
	
	  /**
	   * Method get Join CommiteeUser Detail
	   * @author Hira Chaudhary
	   * @param committeeId
	   * @param isApproved
	   * @param committeeType
	   * @return
	   * @throws Exception
	   */
	public List<TblCommitteeUser> getJoinCommiteeUserDetail(int committeeId,int isApproved,int committeeType) throws Exception {
	   	return tblCommitteeUserDao.findTblCommitteeUser("tblCommittee", Operation_enum.EQ, new TblCommittee(committeeId), "isApproved", Operation_enum.EQ, isApproved);
	}
	
	 /**
	   * Method get Add New CommiteeUSer
	   * @author Hira Chaudhary
	   * @param committeeId
	   * @param tenderId
	   * @param committeeType
	   * @return
	   * @throws Exception
	   */
	public List<HashMap<Integer, Integer>> getAddNewCommitteMemberDeatils(Map<Integer,Integer> addedMember,int committeeId, int tenderId, int committeeType) throws Exception {
		List<Object[]> lastCommiteeeId =null;
		List<HashMap<Integer, Integer>> userIds = new ArrayList<HashMap<Integer, Integer>>();
		HashMap<Integer, Integer> tempMap = new HashMap<Integer, Integer>();
	    int oldCommiteeId=0;
	    Map<String, Object> var = new HashMap<String, Object>();
	    var.put("tenderId", tenderId);
	    var.put("committeeType", committeeType);
	    StringBuilder query= new StringBuilder();
	    query.append("select tblCommittee.committeeId,tblCommittee.tblTender.tenderId ");
	    query.append(" from TblCommittee tblCommittee where tblCommittee.tblTender.tenderId=:tenderId and tblCommittee.committeeType=:committeeType");
	    query.append(" order by tblCommittee.committeeId desc");
	    lastCommiteeeId = hibernateQueryDao.createNewQuery(query.toString(), var); 
	    if(lastCommiteeeId!=null && lastCommiteeeId.size() > 1){
	    	oldCommiteeId =Integer.parseInt(lastCommiteeeId.get(1)[0].toString());
	    }
	    
	    //2)get the old commitee data
	    List<TblCommitteeUser> oldTblCommitteeUser = null;
	    List<TblCommitteeUser> newTblCommitteeUser = null;
	    if(oldCommiteeId!=0){
	    	oldTblCommitteeUser = tblCommitteeUserDao.findTblCommitteeUser("tblCommittee", Operation_enum.EQ, new TblCommittee(oldCommiteeId));        
	    }
	    newTblCommitteeUser = tblCommitteeUserDao.findTblCommitteeUser("tblCommittee", Operation_enum.EQ, new TblCommittee(committeeId));
	    if(oldTblCommitteeUser!=null && newTblCommitteeUser!=null){
	    	if(oldTblCommitteeUser.size()>0 && newTblCommitteeUser.size() > 0){
	    		for (TblCommitteeUser tblCommiteeUser : newTblCommitteeUser) {
	    			boolean exitMemer=false;
	                for(TblCommitteeUser oldTblCommiteeUser : oldTblCommitteeUser){
	                	if(oldTblCommiteeUser.getTblUserLogin().getUserId() == tblCommiteeUser.getTblUserLogin().getUserId() && oldTblCommiteeUser.getTblUserDetail().getUserDetailId() == tblCommiteeUser.getTblUserDetail().getUserDetailId()){
	                		exitMemer = true;
	                	}
	                }
	                if(!exitMemer){
	                	tempMap.put(tblCommiteeUser.getTblUserLogin().getUserId(), tblCommiteeUser.getTblUserDetail().getUserDetailId());
	                }
	    		}
	    		userIds.add(tempMap);
	    	}
	    }
	    if(oldTblCommitteeUser==null && !getPreBidCommiteePublish(tenderId, committeeId, 3)){
	    	for (TblCommitteeUser tblCommiteeUser : newTblCommitteeUser) {
	    		tempMap.put(tblCommiteeUser.getTblUserLogin().getUserId(),tblCommiteeUser.getTblUserDetail().getUserDetailId());
	    	}
	    	userIds.add(tempMap);
	    }
	    return userIds; 	
	}
	public long checkBidExists(int tenderId,int companyId, int formId) throws Exception{
        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
        var.put("formId", formId);
        count = hibernateQueryDao.countForNewQuery("TblTenderBid tbltenderbid inner join tbltenderbid.tblTenderForm tbltenderform","tbltenderform.formId","tbltenderbid.tblTender.tenderId=:tenderId and tbltenderform.formId=:formId and tbltenderform.cstatus = 1 and tbltenderbid.tblCompany.companyId=:companyId ",var);
        return count;
    }
}
