/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;


import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblBidderStatusDao;
import com.etl.eproc.common.daointerface.TblEmdTransactionDetailDao;
import com.etl.eproc.common.daointerface.TblNeftTransactionHistoryDao;
import com.etl.eproc.common.daointerface.TblTransactionCSVDetailDao;
import com.etl.eproc.common.model.TblBidderStatus;
import com.etl.eproc.etender.model.TblNotification;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SignerVerify;
import com.etl.eproc.etender.daointerface.TblNotificationDao;
import com.etl.eproc.etender.daointerface.TblShareReportDao;
import com.etl.eproc.etender.daointerface.TblShareReportDetailDao;
import com.etl.eproc.etender.daointerface.TblTenderBidDetailDao;
import com.etl.eproc.etender.daointerface.TblTenderBidOpenSignDao;
import com.etl.eproc.etender.daointerface.TblTenderOpenDao;
import com.etl.eproc.etender.daointerface.TblTenderRebateDetailDao;
import com.etl.eproc.etender.daointerface.TblTenderReportDao;
import com.etl.eproc.etender.daointerface.TblTenderReportDetailDao;
import com.etl.eproc.etender.daostoredprocedure.SPBidderListForDecryption;
import com.etl.eproc.etender.daostoredprocedure.SPDecryptBid;
import com.etl.eproc.etender.daostoredprocedure.SPGetCGMPReport;
import com.etl.eproc.etender.daostoredprocedure.SPGetCGMPReport2;
import com.etl.eproc.etender.daostoredprocedure.SPTenderOpening;
import com.etl.eproc.etender.daostoredprocedure.SPTenderOpeningReport;
import com.etl.eproc.etender.model.TblShareReport;
import com.etl.eproc.etender.model.TblShareReportDetail;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBidDetail;
import com.etl.eproc.etender.model.TblTenderBidOpenSign;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderOpen;
import com.etl.eproc.etender.model.TblTenderRebateDetail;
import com.etl.eproc.etender.model.TblTenderReport;
import com.etl.eproc.etender.model.TblTenderReportDetail;

/**
 *
 * @author dipal
 */
@Service
public class TenderOpenService {
     private Map syncHM;
    private static final Integer  MUTEX=1;
    
    @Autowired 
    private SPTenderOpeningReport sPTenderOpeningReport;
    @Autowired
    private SPTenderOpening spTenderOpening;
    @Autowired
    private SPBidderListForDecryption sPBidderListForDecryption;
    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    @Autowired
    private TblTenderReportDao tblTenderReportDao;
    @Autowired
    private SPDecryptBid sPDecryptBid;   
    @Autowired
    private MessageSource messageSource;
    @Autowired
    private TblShareReportDao tblShareReportDao;
    @Autowired
    private TblShareReportDetailDao tblShareReportDetailDao;
    @Autowired
    private TblTenderReportDetailDao tblTenderReportDetailDao;
    @Autowired
    private SignerVerify signerVerify;
    @Autowired
    private TblEmdTransactionDetailDao tblEmdTransactionDetailDao;
    @Autowired
    private TblTransactionCSVDetailDao tblTransactionCSVDetailDao;
    @Autowired
    private TblNeftTransactionHistoryDao tblNeftTransactionHistoryDao;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private TblBidderStatusDao tblBidderStatusDao;
    @Autowired
    private CommonService commonService;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private TblTenderOpenDao tblTenderOpenDao;
    @Autowired
    private TblTenderBidOpenSignDao tblTenderBidOpenSignDao;
    @Autowired
    private TblTenderRebateDetailDao tenderRebateDetailDao;
    @Autowired
    private TblTenderBidDetailDao  tblTenderBidDetailDao;
    @Autowired
    private  CommitteeFormationService committeeFormationService;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private TblNotificationDao tblNotificationDao;
    @Autowired 
    private SPGetCGMPReport sPGetCGMPReport;
    @Autowired 
    private SPGetCGMPReport2 sPGetCGMPReport2;
    
    public TenderOpenService()
    {
        syncHM = Collections.synchronizedMap(new HashMap<String, String>());
    }
    
    /**
     * Use case: Result sharing for opening / Evaluation process
     * Used to get form details by shareReportId
     * @author nirav.modi
     * @param shareReportId
     * @return {@codeList<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getShareReportDetailsByReportId(int shareReportId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("shareReportId",shareReportId);
        list = hibernateQueryDao.createNewQuery("select tblsharereportdetail.shareIndividualReport, tblsharereportdetail.shareComparativeReport, tblsharereportdetail.shareDocument, tblsharereportdetail.shareReportDetailId, tblsharereportdetail.tblTenderForm.formId from TblShareReportDetail tblsharereportdetail where tblsharereportdetail.tblShareReport.shareReportId=:shareReportId order by tblsharereportdetail.tblTenderForm.formId ",var);                
        return list;        
    }
    
    /**
     * Use case: Result sharing for opening / Evaluation process
     * @author nirav.modi
     * @param reportId
     * @return boolean
     * @throws Exception 
     */
    public boolean deActivateShareReport(int shareReportId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("shareReportId",shareReportId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblShareReport set isActive=0 where shareReportId=:shareReportId",var);        
        return cnt!=0;
    }
    
    /**
     * Use case: Result sharing for opening / Evaluation process
     * @author nirav.modi
     * @param tenderId
     * @return {@codeList<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getShareReports(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" select tblsharereport.shareReport, tblsharereport.showResultBeforeLogin, tblsharereport.showL1Report, tblsharereport.showAbstractReport, tblsharereport.shareBidderStatus, tblsharereport.shareClarificationReport, tblsharereport.shareEvaluationReport, tblsharereport.shareReportId,tblsharereport.createdBy from TblShareReport tblsharereport where tblsharereport.tblTender.tenderId=:tenderId and tblsharereport.isActive=1 ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);                
    }
    
    /**
     * Use case: Result sharing for opening / Evaluation process
     * @author nirav.modi
     * @param tblShareReport
     * @param tblShareReportDetails
     * @param isForOpening
     * @return boolean
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addTenderResultConfig(TblShareReport tblShareReport,List<TblShareReportDetail> tblShareReportDetails,boolean isForOpening) throws Exception{
    	boolean bSuccess = false;
    	List<Object[]> shareReportsData=getShareReports(tblShareReport.getTblTender().getTenderId());
		if(shareReportsData!=null && !shareReportsData.isEmpty()){// If update case
			Object[] data= shareReportsData.get(0);
			tblShareReport.setIsActive(1);
			if(isForOpening){
				/*
				 * Below Evaluation data will save as it is 
				 */
				tblShareReport.setShowAbstractReport((Integer)data[3]);
				tblShareReport.setShareBidderStatus((Integer)data[4]);
				tblShareReport.setShareClarificationReport((Integer)data[5]);
				tblShareReport.setShareEvaluationReport((Integer)data[6]);
				tblShareReport.setShareReportId((Integer)data[7]);
				deActivateShareReport(tblShareReport.getShareReportId());//old data deactivate
				
				/*
				 *Here For opening process insertion is : Old data deactivate and new insertion for tblsharereport table and also for  tblShareReportDetail
				 */
				tblShareReport.setShareReportId(0);
				tblShareReportDao.addTblShareReport(tblShareReport);
	    		for (int i = 0; i < tblShareReportDetails.size(); i++) {
	    			tblShareReportDetails.get(i).setTblShareReport(tblShareReport);
				}
	        	tblShareReportDetailDao.saveUpdateAllTblShareReportDetail(tblShareReportDetails);
	    	}else{
	    		tblShareReport.setShareReport((Integer)data[0]);
				tblShareReport.setShowResultBeforeLogin((Integer)data[1]);
				tblShareReport.setShowL1Report((Integer)data[2]);
				tblShareReport.setShareReportId((Integer)data[7]);
				tblShareReport.setCreatedBy((Integer)data[8]);
	    		tblShareReportDao.saveOrUpdateTblShareReport(tblShareReport);
	    	}
		}else{// If Add case
			if(isForOpening){
				//By default value of evaluation field is do not share
				tblShareReport.setShowAbstractReport(0);
				tblShareReport.setShareBidderStatus(4);
				tblShareReport.setShareClarificationReport(4);
				tblShareReport.setShareEvaluationReport(4);
	    		tblShareReportDao.addTblShareReport(tblShareReport);
	    		for (int i = 0; i < tblShareReportDetails.size(); i++) {
	    			tblShareReportDetails.get(i).setTblShareReport(tblShareReport);
				}
	        	tblShareReportDetailDao.saveUpdateAllTblShareReportDetail(tblShareReportDetails);
	    	}else{
	    		tblShareReportDao.addTblShareReport(tblShareReport);
	    	}
		}
    	bSuccess=true;        
    	return bSuccess;

    }
    
    /**
     * Use case : Result Sharing of Opening Process
     * @author nirav.modi
     * @return
     * @throws Exception 
     */
    public  List<SelectItem> getChartList() throws Exception{
        List<SelectItem> criteriaList = new ArrayList<SelectItem>();
        criteriaList.add(new SelectItem(messageSource.getMessage("label_indivi_chrt", null, LocaleContextHolder.getLocale()),1));
        criteriaList.add(new SelectItem(messageSource.getMessage("label_cmp_chrt", null, LocaleContextHolder.getLocale()),2));
        criteriaList.add(new SelectItem(messageSource.getMessage("field_sup_doc",  null, LocaleContextHolder.getLocale()),3));
        return criteriaList;        
    }
    
    /**
     * Use case : Result Sharing of Opening Process
     * @author nirav.modi
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderFormForResultShare(int tenderId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" select tbltenderform.formId,tbltenderform.formName,tbltenderform.tblTenderEnvelope.envelopeId, tbltenderform.sortOrder");
        query.append(" from TblTenderForm tbltenderform where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus=1 order by tbltenderform.formId");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        
    }
    
    /**
     * @author nirav.modi
     * Use Case : Tender Opening/Evaluation Process
     * @param tenderId
     * @param committeeType
     * @return {@code<Map<String, Object>>}
     * @throws Exception 
     */
    public Map<String, Object> getTenderOpeningDetails(int tenderId,int tab) throws Exception{
    	return spTenderOpening.executeProcedure(tenderId,tab);
    }
    
    /**
     * Method use for get Individual Report Detail from Store procedure.
     * @author dipal
     * @param tenderId
     * @param envelopId
     * @param formId
     * @return {@code<Map<String, Object>>}
     */
    public Map<String,Object> getIndividualReportDetail(int tenderId, int envelopId, int formId) throws Exception
    {
        return sPTenderOpeningReport.executeProcedure(tenderId, envelopId, 0, 0,formId, 1);
    }  
     /**
     * Method use for get Comparative Report Detail from Store procedure.
     * @author dipal
     * @param tenderId
     * @param envelopId
     * @param formId
     * @return {@code<Map<String, Object>>}
     */
    public Map<String,Object> getComparativeReportDetail(int tenderId, int envelopId, int formId) throws Exception
    {
        return sPTenderOpeningReport.executeProcedure(tenderId, envelopId, 0,0, formId, 2);
    }
    
    /**
     * Method use for get Bidder wise abstract Report Detail from Store procedure.
     * @author dipal
     * @param tenderId
     * @param envelopId
     * @param formId
     * @param consortiumId
     * @return {@code<Map<String, Object>>}
     */
    public Map<String,Object> getBidderWiseReportDetail(int tenderId, int envelopId, int bidderId, int consortiumId) throws Exception
    {
        return sPTenderOpeningReport.executeProcedure(tenderId, envelopId, bidderId, consortiumId,0, 3);
    }
    
    /**
     * Method use for get bidder list for decrypt bid.
     * @author dipal
     * @param tenderId
     * @param envelopeId
     * @param formId
     * @param sessionUserId
     * @param flag =0: get bidder list for decrypt bid, 3 : get bidder list for verify bid.
     * @return {@code Map<String,Object>}
     */
    public  Map<String,Object> getUserListForDecryptVerifyBid(int tenderId, int envelopeId, int formId,int sessionUserId,int flag,int rebeteId) throws Exception
    {
       return sPBidderListForDecryption.executeProcedure(tenderId, envelopeId,formId,sessionUserId,flag,"",rebeteId);
    }    
    
    /**
     * Method use for get bidder encrypted detail for decrypt bid.
     * @author dipal
     * @param tenderId
     * @param envelopeId
     * @param formId
     * @param sessionUserId
     * @param userIdList
     * @param flag
     * @return {@code Map<String,Object>}
     * @throws Exception 
     */
    public Map<String,Object> getBidderBidDetailForDecryptVerifyBid(int tenderId, int envelopeId, int formId, int sessionUserId,String userIdList,int flag,int rebeteId) throws Exception
    {
        return sPBidderListForDecryption.executeProcedure(tenderId, envelopeId,formId,sessionUserId,flag,userIdList,rebeteId);
    }
    
    /**
     * 
     * @param clientId
     * @param tenderId
     * @param envelopeId
     * @param tenderReportType==committeeType
     * @return
     * @throws Exception 
     */
    public List<Object[]> getCommitteeMembers(int tenderId,int envelopeId,int tenderReportId,int tenderReportType) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        var.put("tenderReportId",tenderReportId);
        var.put("committeeType",tenderReportType);
        StringBuilder query=new StringBuilder(" SELECT tbluserlogin.userName,tbluserlogin.userId,ISNULL(tbltenderreportdetail.tenderReportDetailId, 0) as tenderReportDetailId,tbltenderreportdetail.remark,tbltenderreportdetail.createdOn "); 
        query.append(" FROM TblCommitteeUser tblcommitteeuser ");
        query.append(" INNER JOIN tblcommitteeuser.tblCommittee tblcommittee ");
        query.append(" INNER JOIN tblcommitteeuser.tblUserLogin tbluserlogin ");
        query.append(" LEFT JOIN tbluserlogin.tblTenderReportDetail tbltenderreportdetail with tbltenderreportdetail.tblTenderReport.tenderReportId=:tenderReportId ");
        query.append(" where tblcommittee.tblTender.tenderId=:tenderId and tblcommitteeuser.childId=:envelopeId and tblcommittee.committeeType=:committeeType and tblcommittee.isActive=1 and tblcommittee.isApproved=1 ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);        
    }
    
    /**
     * to add report name
     * @param tblTenderReport
     * @return
     * @throws Exception 
     */
    public boolean addReportName(TblTenderReport tblTenderReport) throws Exception{
    	boolean bSuccess = false;             
    	tblTenderReportDao.saveOrUpdateTblTenderReport(tblTenderReport);
        bSuccess=true;        
        return bSuccess;
    }
    
    /**
     * to get tender envelope details
     * @param tenderId
     * @param envelopeId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderEnvelopeDetails(int envelopeId,int reportType) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId",envelopeId);
        StringBuilder query=new StringBuilder("select ");
        if(reportType == 1){
        	query.append(" tbltenderenvelope.minOpeningMember ");
        }else if(reportType == 2){
        	query.append(" tbltenderenvelope.minEvaluator ");
        }
        query.append(" , tbltenderenvelope.cstatus,tbltenderenvelope.envelopeName,tbltenderenvelope.openingDate from TblTenderEnvelope tbltenderenvelope where  tbltenderenvelope.envelopeId=:envelopeId ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);        
    }
    
    

    
    /**
     * method use for persist decrypted bid data into database.
     * @author dipal
     * @param tenderId
     * @param envelopeId
     * @param formId
     * @param sessionUserId
     * @param ipaddress
     * @param userIdList
     * @param bidSignInsert
     * @param strBidTableIds
     * @param clientId
     * @return String 
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public String addDecryptBid(int tenderId, int envelopeId, int formId, int sessionUserId,int sessionUserDetailId,String ipaddress,String userIdList,String bidSignInsert,String strBidTableIds,int clientId,int flag,List<TblTenderRebateDetail> tblTenderRebateDetails,List<TblTenderBidOpenSign> tblTenderBidOpenSignLst) throws Exception
    {
        String res=null;
        int isOpeningByCommittee = 0;
        int isEncryptionReq = 0;
        int isPriceBid = 0;
        int cStatus = 0;
        boolean isVerified = false;
        synchronized(MUTEX)
        {
            if(!syncHM.containsKey(tenderId+"_"+envelopeId+"_"+formId))
            {
                syncHM.put(tenderId+"_"+envelopeId+"_"+formId,tenderId+"_"+envelopeId+"_"+formId);
            }
        }
        synchronized(syncHM.get(tenderId+"_"+envelopeId+"_"+formId))
        {            
//            List<LinkedHashMap<String, Object>> lst=sPDecryptBid.executeProcedure(tenderId,envelopeId,formId,sessionUserId,sessionUserDetailId,clientId,ipaddress,userIdList,bidSignInsert,strBidTableIds,flag);
        	res=decryptBid(tenderId,envelopeId,formId,sessionUserId,sessionUserDetailId,clientId,ipaddress,userIdList,bidSignInsert,strBidTableIds,flag);
//            if(lst != null && !lst.isEmpty() && lst.get(0).get("resultMessage")!= null)
//            {
//                res=lst.get(0).get("resultMessage").toString();
//            }
            syncHM.remove(tenderId+"_"+envelopeId+"_"+formId);
        	if(res != null && res.equalsIgnoreCase("msg_bid_verified_success")){
        		isOpeningByCommittee = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isOpeningByCommittee").toString());
        		if(isOpeningByCommittee == 0){
	        		Object[] list = tenderFormService.getTenderFormDetails(formId).get(0);
	        		if(list != null){
	        			isEncryptionReq = Integer.parseInt(list[5].toString());
	        			isPriceBid = Integer.parseInt(list[9].toString());
	        			cStatus = Integer.parseInt(list[15].toString());
	        		}
        		}
        		isVerified = isEncryptionReq == 0 && isPriceBid == 1 && cStatus == 1 ? true : false;
        	}
            if(res !=null && res.equalsIgnoreCase("msg_bid_decrypt_success") || isVerified){
            	addBidOpenData(tblTenderRebateDetails, tblTenderBidOpenSignLst,tenderId,formId);
            }
        }      
        return res;
    }
   
    
    /*
	 * Get Selected and Bidded Items 
     * @author Priyanka
     * @throws Exception 
     */
    public List<Object[]> getBidSelectedandBidded(List<Object> formId,int companyId) throws Exception{
    	Map<String, Object> var = new HashMap<String, Object>();
    	StringBuilder query= new StringBuilder();
    	List<Object[]> list = null;
       	var.put("formId", formId);
    	var.put("companyId", companyId);
       	query.append(" select tc.cellId as c0 from apptenderbid.tbl_itemselection it  ");
		query.append("  inner join  apptender.tbl_TenderColumn TCC ON tcc.formId=it.formId and it.tableId=tcc.tableId  AND TCC.filledBy in (2,3) ");
		query.append(" INNER JOIN APPtender.tbl_TenderCell tc on  tcc.columnId = tc.columnId  and tc.formId = tcc.formId and tcc.tableId = tc.tableId AND tc.rowID = it.rowId ");
		query.append("	WHERE it.formId in (:formId) and it.isSelected=1 and it.isBidded=1 and it.companyId = :companyId ");
        list = hibernateQueryDao.createSQLQuery(query.toString(), var,new int[]{0},1);
    	return list;
    }
    
     /** decrypt bid for 2 level encryption
     * @author Lipi
     * @return
     * @throws Exception 
     */
    public String decryptBid(int tenderId, int envelopeId, int formId, int sessionUserId,int sessionUserDetailId, int clientId,String ipAddress, String bidderIds, String bidSignInsertStr, String bidTableIds, int flag) throws Exception{
    	List<Object[]> list = null;
    	List<Object>listOfSingCol = null;
    	int encryptionLevelType=0;
    	int tenderResult=0;
    	int	tenderEnvelopeType=0;
    	int userEncryptionLevel=0;
    	long	cnt = 0;
    	String resultMessage = flag == 2 ?"msg_bid_verified_failed":"msg_bid_decrypt_failed";
    	StringBuilder query= new StringBuilder();
    	Map<String, Object> var = new HashMap<String, Object>();
    	List<Integer> bidderId = new ArrayList<Integer>();
    	if(bidderIds.contains(",")){
		for (String s : bidderIds.trim().split(",")){
    		bidderId.add(new Integer(s.trim()));
    	}}else{
    		bidderId.add(new Integer(bidderIds.trim()));
    	}
    	var.clear();
    	query.delete(0, query.length());
    	List<Object[]> tenderFields = tenderCommonService.getTenderFields(tenderId, "encryptionLevel,tenderResult,envelopeType");
    	if(tenderFields!=null && !tenderFields.isEmpty()){
    		encryptionLevelType=(Integer)tenderFields.get(0)[0];
    		tenderResult=(Integer)tenderFields.get(0)[1];
    		tenderEnvelopeType=(Integer)tenderFields.get(0)[2];
    	}
        /** get logged in officer's encryption level  code start */
        if(flag!=2 && encryptionLevelType == 2){ 
        	listOfSingCol = committeeFormationService.getCommiteeEncryptionLevel(tenderId,envelopeId,sessionUserId);
        	if(listOfSingCol!=null && !listOfSingCol.isEmpty()){
        		userEncryptionLevel = (Integer) listOfSingCol.get(0); 
            }
        }else{
        	encryptionLevelType = 1;
        	userEncryptionLevel = 1; 
        }
        /** get logged in officer's encryption level  code End */
        
        /** Check decryption done for given set of bidders code  start*/
        var.clear();
    	query.delete(0, query.length());
    	var.put("envelopeId", envelopeId);
    	var.put("tenderId", tenderId);
    	var.put("formId", formId);
    	var.put("bidderIds", bidderId);
    	var.put("decryptionLevel", userEncryptionLevel);
    	query.append(" tblTenderOpen.tblTender.tenderId=:tenderId");
    	query.append(" AND tblTenderOpen.tblTenderEnvelope.envelopeId=:envelopeId AND tblTenderOpen.tblTenderForm.formId=:formId");
    	query.append(" AND tblTenderOpen.decryptionLevel=:decryptionLevel"); 
    	query.append(" AND tblTenderOpen.tblUserLogin.userId in (:bidderIds)");
    	cnt = hibernateQueryDao.countForNewQuery("TblTenderOpen tblTenderOpen", "tblTenderOpen.tenderOpenId", query.toString(), var);	    		    		 	        
    	if(cnt > 0){ 
    		resultMessage = flag != 2 ? "msg_biddecrypt_another_user":"msg_biddverification_another_user";  
    	}else{
    		if(flag!=3){
    			/*** Make entry into apptenderresult.tbl_TenderOpen ***/
    			if(flag==2 || (encryptionLevelType == userEncryptionLevel) || encryptionLevelType == 1 ){
    				List<TblTenderOpen> tenderOpens = new ArrayList<TblTenderOpen>();
    				Object[] objArrayOfBidderId = bidderId.toArray(new Object[bidderId.size()]);
    				List<TblBidderStatus> tblBidderStatuses = tblBidderStatusDao.findTblBidderStatus("tblUserLogin.userId",Operation_enum.IN,objArrayOfBidderId,"tblClient.clientId",Operation_enum.EQ,clientId);
    				for (Integer userId : bidderId) {	    					
    					TblBidderStatus bidderStatus = null;
    					for(TblBidderStatus tblBidderStatus : tblBidderStatuses) {
	    					if(tblBidderStatus.getTblUserLogin().getUserId() == userId){
	    						 bidderStatus = tblBidderStatus;
	    					}
    					}
    					if(bidderStatus != null){
	    					TblTenderOpen tblTenderOpen = new TblTenderOpen();
	    					tblTenderOpen.setTblTender(new TblTender(tenderId));
	    					tblTenderOpen.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
	    					tblTenderOpen.setTblTenderForm(new TblTenderForm(formId));
	    					tblTenderOpen.setTblCompany(bidderStatus.getTblCompany());
	    					tblTenderOpen.setTblUserLogin(bidderStatus.getTblUserLogin());
	    					tblTenderOpen.setDecryptionLevel(userEncryptionLevel);
	    					tblTenderOpen.setIpAddress(ipAddress);
	    					tblTenderOpen.setCreatedBy(sessionUserDetailId);
	    					tblTenderOpen.setCreatedOn(commonService.getServerDateTime());
	    					tenderOpens.add(tblTenderOpen);
    					}
					}
    				tblTenderOpenDao.saveUpdateAllTblTenderOpen(tenderOpens);
    			}else{
    				var.clear();
    		    	query.delete(0, query.length());
    		    	var.put("envelopeId", envelopeId);
    		    	var.put("tenderId", tenderId);
    		    	var.put("formId", formId);
    		    	var.put("bidderIds", bidderId);
    		    	var.put("decryptionLevel", userEncryptionLevel);
    		    	var.put("ipAddress", ipAddress);
    		    	var.put("createdBy", sessionUserDetailId);
    		    	var.put("createdOn", commonService.getServerDateTime());
    		    	query.append(" UPDATE TblTenderOpen tblTenderOpen SET ");
    		    	query.append(" tblTenderOpen.decryptionLevel=:decryptionLevel,tblTenderOpen.ipAddress=:ipAddress,");
    		    	query.append(" tblTenderOpen.createdBy=:createdBy,tblTenderOpen.createdOn=:createdOn "); 
    		    	query.append(" WHERE tblTenderOpen.tblUserLogin.userId in (:bidderIds) AND tblTenderOpen.tblTender.tenderId=:tenderId ");
    		    	query.append(" AND tblTenderOpen.tblTenderEnvelope.envelopeId=:envelopeId AND tblTenderOpen.tblTenderForm.formId=:formId ");
    		    	hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
    			}
    		}
    		resultMessage=flag==2? "msg_bid_verified_success":"msg_bid_decrypt_success";
    	}
    	/** Check decryption done for given set of bidders code  End**/
        return resultMessage;       
    }
    /** decrypt bid 
     * @author Lipi
     * @return
     * @throws Exception 
     */
    public boolean addBidOpenData(List<TblTenderRebateDetail> tblTenderRebateDetails,List<TblTenderBidOpenSign> tblTenderBidOpenSignLst,int tenderId,int formId) throws Exception{
    	boolean bSuccess = false;
    	int companyId = 0;
    	List<TblTenderBidDetail> tblTenderBidDetails = new ArrayList<TblTenderBidDetail>();
    	if(!tblTenderRebateDetails.isEmpty()){
    		tenderRebateDetailDao.saveUpdateAllTblTenderRebateDetail(tblTenderRebateDetails);
    	}
    	if(!tblTenderBidOpenSignLst.isEmpty()){
    		tblTenderBidOpenSignDao.saveUpdateAllTblTenderBidOpenSign(tblTenderBidOpenSignLst);
    		List<Object> formIds = new ArrayList<Object>();
	    	formIds.add(formId);
	    	int isItemSelectionPageRequired = Integer.parseInt(tenderCommonService.getTenderField(tenderId, "isItemSelectionPageRequired").toString());
	    	 boolean isPriceBid= tenderFormService.getIsPriceBidForm(formId);
    		for (TblTenderBidOpenSign bidOpenSign : tblTenderBidOpenSignLst) {
    			companyId = Integer.parseInt(getTenderCompanyId(bidOpenSign.getTblTenderBidMatrix().getBidTableId()).toString());
    			List<Object[]> cellIds= getBidSelectedandBidded(formIds,companyId);
    			boolean isValidJson = false;
    			JSONArray jsnArr = null;
				try {
                    jsnArr = new JSONArray(bidOpenSign.getDecryptedBid());
                    isValidJson = true;
                } catch (Exception ex1) {}
    			if(isValidJson && jsnArr!=null){
    				for (int i = 0; i < jsnArr.length(); i++) {
						JSONObject jsonObject =  jsnArr.getJSONObject(i);
						Iterator<?> keys = jsonObject.keys();
						while( keys.hasNext() ) {
					    	String key = (String)keys.next();
					    	 if(isItemSelectionPageRequired==1 && isPriceBid){
					    		 if(cellIds!=null && !cellIds.isEmpty()){
					    			 if(cellIds.contains(key.toString().split("_")[0])){
					    					TblTenderBidDetail bidDetail = new TblTenderBidDetail();
									    	bidDetail.setTblTenderBidMatrix(bidOpenSign.getTblTenderBidMatrix());
									    	bidDetail.setCellNo(Integer.parseInt(key.toString().split("_")[1]));
									    	bidDetail.setCellValue((String)jsonObject.get(key));
									    	bidDetail.setTblTenderCell(new TblTenderCell(Integer.parseInt(key.toString().split("_")[0])));
									    	tblTenderBidDetails.add(bidDetail);
					    			 }
					    		 }
					    	 }else{
					    			TblTenderBidDetail bidDetail = new TblTenderBidDetail();
							    	bidDetail.setTblTenderBidMatrix(bidOpenSign.getTblTenderBidMatrix());
							    	bidDetail.setCellNo(Integer.parseInt(key.toString().split("_")[1]));
							    	bidDetail.setCellValue((String)jsonObject.get(key));
							    	bidDetail.setTblTenderCell(new TblTenderCell(Integer.parseInt(key.toString().split("_")[0])));
							    	tblTenderBidDetails.add(bidDetail);
					    	 }
						}
					}
    			}
    		}
    		tblTenderBidDetailDao.saveUpdateAllTblTenderBidDetail(tblTenderBidDetails);
    	}    	    	
        bSuccess=true;        
        return bSuccess;
    }
    
    /**
     * 
     * @param tblTenderReportDetail
     * @return
     * @throws Exception 
     */
    public boolean addTenderReportDetails(TblTenderReportDetail tblTenderReportDetail) throws Exception{
    	boolean bSuccess = false;             
        tblTenderReportDetailDao.addTblTenderReportDetail(tblTenderReportDetail);
        bSuccess=true;        
        return bSuccess;

    }
    
    /**
     * to get tender reportDetail id count to check whether min req condition satisfy or not for the publish of the report
     * @param tenderReportId
     * @return
     * @throws Exception 
     */
    public List<Object> getTenderReportDetails(int tenderReportId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderReportId",tenderReportId);
        return hibernateQueryDao.getSingleColQuery("select tbltenderreportdetail.tblTenderReport.tenderReportId from TblTenderReportDetail tbltenderreportdetail where tbltenderreportdetail.tblTenderReport.tenderReportId=:tenderReportId",var);        
    }
    
    /**
     * to publish TOC Report
     * @author vivek.rajyaguru
     * @param tenderReportId
     * @param userId
     * @param linkId
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean publishTOCTECReport(int tenderReportId,int userId,int linkId,String remark,int userDetailId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderReportId",tenderReportId);
        var.put("userId",userId);
        var.put("linkId",linkId);
        cnt =hibernateQueryDao.updateDeleteNewQuery("update TblOfficerDocMapping set cstatus=1,approvedOn=GETUTCDATE(),approvedBy=:userId  where objectId=:tenderReportId and tblLink.linkId=:linkId and cstatus=0 ",var);
        if(cnt>0){
        	var.clear();
        	cnt=0;
            var.put("tenderReportId",tenderReportId);
            var.put("userId",userId);
            cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderReport set cstatus=1,approvedOn=GETUTCDATE(),approvedBy=:userId  where tenderReportId=:tenderReportId",var);
        	if(cnt>0){
        	  TblTenderReportDetail tblTenderReportDetail=new TblTenderReportDetail();
          	  tblTenderReportDetail.setRemark(remark);
          	  TblTenderReport tblTenderReport=new TblTenderReport();
          	  tblTenderReport.setTenderReportId(tenderReportId);
          	  tblTenderReportDetail.setTblTenderReport(tblTenderReport);
          	  tblTenderReportDetail.setTblUserLogin(new TblUserLogin(userId));
          	  tblTenderReportDetail.setTblUserDetail(new TblUserDetail(userDetailId));
              tblTenderReportDetailDao.addTblTenderReportDetail(tblTenderReportDetail);
        	}
        }
        return cnt!=0;
    }

    /**
     * to update price bid opening date
     * @param tenderId
     * @param envelopeId
     * @param openingDate
     * @return
     * @throws Exception 
     */
    public boolean updatePriceBidOpeningDate(int tenderId,int envelopeId,String openingDate) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        var.put("openingDate",openingDate);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set openingDate=:openingDate where envelopeId=:envelopeId and tblTender.tenderId=:tenderId",var);        
        return cnt!=0;
    }
    
    /**
     * 
     * @param tenderId
     * @param envelopeId
     * @return
     * @throws Exception 
     */
    public boolean publishPriceOpeningBid(int tenderId,int envelopeId,int userDetailId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        var.put("userDetailId",userDetailId);
        //cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set cstatus=1, publishedOn=getutcdate() where envelopeId=:envelopeId and tblTender.tenderId=:tenderId",var);        
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set openingDateStatus=1, openingDatePublishedOn=getutcdate(),openingDatePublishedBy=:userDetailId where envelopeId=:envelopeId and tblTender.tenderId=:tenderId",var);        
        return cnt!=0;

    }
    /**
     * MEthod use for get public key for given tender and user.
     * @param tenderId
     * @param userId
     * @return 
     */
    public String getTenderPublicKey(int tenderId, int userId)
    {
        String data=null;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("userId",userId);
        list = hibernateQueryDao.getSingleColQuery("select tpk.publicKey from TblTenderPublicKey tpk where tpk.tblTender.tenderId=:tenderId and tpk.tblUserLogin.userId=:userId",var);                
        if(!list.isEmpty()){            
            data = list.get(0).toString();
        }
        return data;
    }
    
    public String getTenderCompanyId(int bidtableId)
    {
        String data=null;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidtableId",bidtableId);
        list = hibernateQueryDao.getSingleColQuery("select tbltenderbid.tblCompany.companyId from TblTenderBid tbltenderbid inner join tbltenderbid.tblTenderBidMatrix tbm where tbm.bidTableId = :bidtableId",var);                
        if(!list.isEmpty()){            
            data = list.get(0).toString();
        }
        return data;
    }
    
    /**
     * Method use for verify bid
     * @param tenderId
     * @param formId
     * @param bidderId
     * @return true if bid verified successfully else return false.
     * @throws Exception 
     */
    public boolean verifyBidDetail(int tenderId,int formId, int bidderId) throws Exception
    {
        boolean res=true;
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("bidderId",bidderId);
        var.put("formId",formId);
        StringBuilder query=new StringBuilder("");
        query.append(" SELECT TBOS.tblTenderBidMatrix.bidTableId, TBOS.bidSignText ");
        query.append(" FROM TblTenderBidOpenSign TBOS ");
        query.append(" INNER JOIN TBOS.tblTenderBidMatrix TBM ");
        query.append(" INNER JOIN TBM.tblTenderBid TB  ");
        query.append(" WHERE TB.tblTenderForm.formId = :formId AND TB.tblUserLogin.userId=:bidderId AND TB.tblTender.tenderId=:tenderId AND TBOS.bidSignText != '' AND TBOS.bidSignText IS NOT NULL");
        
        list=hibernateQueryDao.createNewQuery(query.toString(),var);
        if(list!=null && !list.isEmpty())
        {
            for(Object[] objArr:list)
            {
                Object[] objSing=signerVerify.verify(objArr[1].toString());
                if(objSing != null && objSing[1]!=null && objSing[1].equals(true))
                {
                	 try {
                         new JSONObject(objSing[2]);
                     } catch (Exception ex1) {
                         res=false;
                         break;
                     }   
                }
            }
        }
        return res;
    }
    
    /**
     * Method use for get JSON string from tender bid detail table for given bidTableId.
     * @param bidTableId
     * @return String containing JsonString.
     * @throws JSONException 
     */
       public String getJSONFromBidDetail(int bidTableId) throws JSONException 
       {
        StringBuilder query=new StringBuilder("");
        StringBuilder jsonStr=new StringBuilder("");
        query.append(" SELECT TBD.tblTenderCell.cellId,TBD.cellNo,TBD.cellValue,'{\"'+convert(varchar(10),TBD.tblTenderCell.cellId)+'_'+convert(varchar(10),TBD.cellNo)+'\":\"'+TBD.cellValue+'\"}' ");
        query.append(" FROM TblTenderBidDetail TBD ");
        query.append(" WHERE TBD.tblTenderBidMatrix.bidTableId = :bidTableId");
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidTableId",bidTableId);
        list=hibernateQueryDao.createNewQuery(query.toString(),var);
        if(list!=null && !list.isEmpty())
        {
            jsonStr.append("[");
            for(Object[] objArr:list)
            {
                jsonStr.append(objArr[3]).append(",");
            }
            if(jsonStr.toString().endsWith(","))
            {
                jsonStr = new StringBuilder(jsonStr.deleteCharAt(jsonStr.lastIndexOf(",")));
            }
            jsonStr.append("]");
        }
        return jsonStr.toString();
      }
    
    /**
     * @auther Mitesh
     * @param envelopeId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getItemWiseDocMappingDetails(int envelopeId,int formId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId", envelopeId);
         var.put("formId", formId);
        StringBuffer sb = new StringBuffer();
        sb.append(" SELECT TT.tableId as c0, BDM.childId as c1,BD.bidderDocId as c2, BDM.bidderDocMappingId as c3, BD.docName as c4,");
        sb.append(" BD.description as c5, BD.path as c6, BD.isEncryptionReq as c7,BDM.companyId as c8,BDM.objectId as c9");
	sb.append(" FROM appuser.tbl_BidderDocMapping BDM  ");
	sb.append(" INNER JOIN appuser.tbl_BidderDocument BD ON BDM.bidderDocId = BD.bidderDocId  ");
	sb.append(" INNER JOIN apptender.tbl_TenderForm TF ON TF.cstatus = 1 and TF.isItemWiseDocAllowed=1 ");
	sb.append(" INNER JOIN apptender.tbl_TenderTable TT ON TT.formId = TF.formId ");
	sb.append(" inner join apptenderbid.tbl_TenderBid tb on tb.formId = TF.formId ");
	sb.append(" inner join apptenderbid.tbl_TenderBidMatrix tbm on tbm.bidId=tb.bidId and tbm.bidTableId = BDM.objectId ");
	sb.append(" WHERE BDM.linkId = 808 AND BDM.cstatus = 1 and TF.envelopeId=:envelopeId and TF.formId=:formId");
	sb.append(" ORDER BY TF.formId, TT.tableId, BDM.childId");
        list = hibernateQueryDao.createSQLQuery(sb.toString(), var,new int[]{4,5,6},10);
        return list;
    }
    
    /**
     * @author Lipi
     * @param formId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getFormLodingOrNot(int formId) throws Exception {
    	List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId", formId);
        StringBuffer query = new StringBuffer();
        query.append(" SELECT tblTenderColumn.tblColumnType.columnTypeId,tblTenderTable.tblTenderForm.formId");
        query.append(" FROM TblTenderEnvelope tblTenderEnvelope");
        query.append(" INNER JOIN tblTenderEnvelope.tblTenderForm  tblTenderForm");
        query.append(" INNER JOIN tblTenderForm.tblTenderTable tblTenderTable");
        query.append(" INNER JOIN tblTenderTable.tblTenderColumn tblTenderColumn");
        query.append(" WHERE tblTenderTable.tblTenderForm.formId=:formId AND tblTenderColumn.tblColumnType.columnTypeId = 23");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);     
        return (list!=null && !list.isEmpty()) ? list : null;
    }
    
    
    
    /**
     * @author vivek.rajyaguru
     * @param tenderReportId
     * @param reportType
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderEnvelopeDetailFromTenderReportId(int tenderReportId,int reportType) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderReportId",tenderReportId);
        StringBuilder query=new StringBuilder("select ");
        if(reportType == 1){
        	query.append(" tblTenderReport.tblTenderEnvelope.minOpeningMember ");
        }else if(reportType == 2){
        	query.append(" tblTenderReport.tblTenderEnvelope.minEvaluator ");
        }
        query.append(" , tblTenderReport.tblTenderEnvelope.cstatus,tblTenderReport.tblTenderEnvelope.envelopeName,tblTenderReport.tblTenderEnvelope.openingDate from TblTenderReport tblTenderReport where  tblTenderReport.tenderReportId=:tenderReportId ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);        
    }
    
    /**
     * @author priyanka.dalwadi
     * @param envelopeId
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderReportDetailFromEnvelopeId(int tenderId,int envelopeId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        StringBuilder query=new StringBuilder("select ");
        query.append(" tenderReportId,cstatus ");
        query.append("  from TblTenderReport tblTenderReport where  tblTenderReport.tblTender.tenderId=:tenderId and tblTenderReport.tblTenderEnvelope.envelopeId=:envelopeId  ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);        
    }
    
    public List<Object[]> getItemWiseBidSubmissionCount(int tenderId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();        
        var.put("tenderId", tenderId);
        StringBuffer sb = new StringBuffer();
		sb.append(" select TC.cellValue as c0,COUNT(i.rowId) as c1 from apptenderbid.tbl_ItemSelection i  ");
		sb.append(" join apptender.tbl_TenderCell TC on TC.rowId = i.rowId AND TC.tableId = i.tableId ");
		sb.append(" join apptender.tbl_tendercolumn tcc on tcc.columnId = tc.columnId ");
		sb.append(" join apptender.tbl_TenderForm TF ON TF.formId = I.formId ");
		sb.append(" join apptenderbid.tbl_FinalSubmission f on f.tenderId = i.tenderId and f.companyId = i.companyId and f.bidderId = i.bidderId ");
		//sb.append(" where i.tenderId =:tenderId and TCC.columnTypeId = 1 AND TF.isPriceBid = 1 AND I.isSelected = 1 "); 
		sb.append(" where i.tenderId =:tenderId and TCC.columnTypeId = 1 AND TF.isPriceBid = 1 AND I.isBidded = 1 and I.isSelected=1 "); // Bug #37050 By Jitendra.
		sb.append(" group by i.tableId,i.rowId,TC.cellValue ");
		sb.append(" order by I.tableId,i.rowId ");
        list = hibernateQueryDao.createSQLQuery(sb.toString(), var,new int[]{0},2);
        return list;
    }
    
    public List<Object[]> getNofiticationHistory(int tenderId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();        
        var.put("tenderId", tenderId);
        StringBuffer sb = new StringBuffer();
		sb.append(" select tenderId as c0,tn.notificationMsg as c1,case tn.bidderStatus when 2 then 'All' when 1 then 'Qualified' when 0 then 'Disqualified ' end as c2,tn.submitedon as c3,tn.submitedby as c4,od.docName as c5,od.path as c6,odm.officerdocmappingId as c7,od.officerdocid as c8,tn.notificationId as c9 ");
		sb.append(" from apptender.tbl_tender tt ");
		sb.append("	INNER JOIN apptender.tbl_Notification tn ON tn.objectId=tt.tenderId and tt.tenderId=:tenderId ");
		sb.append(" LEFT OUTER JOIN appuser.tbl_OfficerDocMapping odm ON odm.objectId=tn.notificationId and odm.cstatus=1 and odm.linkId=3334");
		sb.append(" LEFT OUTER JOIN appuser.tbl_officerDocument od ON odm.officerDocId=od.officerDocId order by tn.notificationId desc");
        list = hibernateQueryDao.createSQLQuery(sb.toString(), var,new int[]{1,5,6},10);
        return list;
    }
    
    /**
     * @author vivek.rajyaguru
     * @param tblNotification
     * @param docId
     * @param userId
     * @return
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean saveNotificationMailData(TblNotification tblNotification,String docId,int userId){
    	tblNotificationDao.saveOrUpdateTblNotification(tblNotification);
    	if(tblNotification.getNotificationId()!=0 && docId!=null && docId!=""){
	    	Map<String, Object> var = new HashMap<String, Object>();
	        List<Integer> docIds = new ArrayList<Integer>(); 
	        for (int i = 0; i < docId.split(",").length; i++) {
				docIds.add(Integer.parseInt(docId.split(",")[i]));
			}
	        var.put("docId", docIds);
	        var.put("userId", userId);
	        var.put("objectId",tblNotification.getNotificationId());
	        hibernateQueryDao.updateDeleteNewQuery("update TblOfficerDocMapping set objectId=:objectId,cstatus=1,approvedOn=getutcdate(),approvedBy=:userId where officerDocMappingId in (:docId)",var);
    	}
        return tblNotification.getNotificationId()!=0;
    }
    
    
    /**
     * @param tenderId
     * @return
     */
    public Integer getOpenedEnvelopId(int tenderId)
    {
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("tenderId", tenderId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append(" select TTO.envelopeId,TTO.tenderId from apptender.tbl_TenderEnvelope TE  ");
        strQuery.append(" INNER JOIN apptenderresult.tbl_TenderOpen TTO ON TE.envelopeId=TTO.envelopeId and TE.isOpened=1 and TTO.decryptionLevel=1 ");
        strQuery.append(" and TE.tenderId=:tenderId order by TTO.createdOn,TE.sortOrder desc");
        List<Object[]> ls = hibernateQueryDao.createSQLQuery(strQuery.toString(),parameters);
        if (ls != null && !ls.isEmpty()) {
        	return Integer.parseInt(ls.get(0)[0].toString());
        }
        return 0;
    }
    
    /**
     * @param tenderId
     * @param envelopeId
     * @param bidderStatus
     * @return
     */
    public List<Object[]> getBidderApprovalDetailFromEnvelopeId(int tenderId,int envelopeId,int bidderStatus){
    	StringBuffer sb = new StringBuffer();
    	List<Object[]> list = null;
    	Map<String, Object> var = new HashMap<String, Object>();
    	var.put("tenderId", tenderId);
    	
    	sb.append(" SELECT distinct UD.loginId as c0,UD.userId as c1  ");
		sb.append(" FROM apptenderbid.tbl_FinalSubmission fs  ");
		sb.append(" INNER JOIN apptender.tbl_TenderEnvelope te on fs.tenderId=:tenderId and te.tenderId = fs.tenderId and fs.isActive=1  and te.cstatus=1 and fs.partnerType in (0,1,2)   ");
		if(bidderStatus != 2)
		{
			var.put("envelopeId", envelopeId);
			sb.append(" and  te.envelopeId=:envelopeId ");
		}
		sb.append(" INNER JOIN apptenderbid.tbl_TenderBidConfirmation bc ON bc.tenderId = fs.tenderId and bc.companyId=fs.companyId   ");
		if(bidderStatus != 2)
			{
			  var.put("bidderStatus", bidderStatus);
			  sb.append(" INNER JOIN apptenderresult.tbl_BidderApprovalDetail bad on bad.tenderId = fs.tenderId and te.envelopeId=bad.envelopeId and fs.bidderId=bad.bidderId and bad.isApproved =:bidderStatus  ");
			}
		sb.append(" INNER JOIN appuser.tbl_UserDetail UD ON fs.userDetailId = UD.userDetailId ");
		list = hibernateQueryDao.createSQLQuery(sb.toString(), var,new int[]{0,1},2);
		return list;
    }
    
    
    /**
     * @param tenderId
     * @return
     */
    public Integer getLatestBidderApprovalEnvelopeIdFromTenderId(int tenderId)
    {
        Map<String, Object> parameters = new HashMap<String, Object>();
        parameters.put("tenderId", tenderId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append(" select top 1 a.envelopeId,a.tenderId from apptenderresult.tbl_BidderApprovalDetail a where a.tenderId=:tenderId  order by a.createdOn desc");
        List<Object[]> ls = hibernateQueryDao.createSQLQuery(strQuery.toString(),parameters);
        if (ls != null && !ls.isEmpty()) {
        	return Integer.parseInt(ls.get(0)[0].toString());
        }
        return 0;
    }
    
    /**
     * @param tenderId
     * @param bidderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getBidderNofiticationHistory(int tenderId,int bidderId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();        
        var.put("tenderId", tenderId);
        var.put("bidderId", bidderId);
        StringBuffer sb = new StringBuffer();
		sb.append(" select tt.tenderId as c0,tn.notificationMsg as c1,case tn.bidderStatus when 1 then 'Qualified' when 0 then 'Disqualified ' end as c2,tn.submitedon as c3,tn.submitedby as c4,od.docName as c5,od.path as c6,odm.officerdocmappingId as c7,od.officerdocid as c8,tn.notificationId as c9  ");
		sb.append(" from apptender.tbl_tender tt  ");
		sb.append("	INNER JOIN apptender.tbl_Notification tn ON tn.objectId=tt.tenderId and tt.tenderId=:tenderId ");
		sb.append("	INNER JOIN apptenderresult.tbl_BidderApprovalDetail BAD ON BAD.isApproved=tn.bidderStatus and BAD.envelopeId=tn.envelopeId and tn.objectId=BAD.tenderId and BAD.bidderId=:bidderId ");
		sb.append(" LEFT OUTER JOIN appuser.tbl_OfficerDocMapping odm ON odm.objectId=tn.notificationId and odm.cstatus=1 and odm.linkId=3334");
		sb.append(" LEFT OUTER JOIN appuser.tbl_officerDocument od ON odm.officerDocId=od.officerDocId ");
		sb.append(" UNION ");
		sb.append(" select tt.tenderId as c0,tn.notificationMsg as c1,case tn.bidderStatus when 2 then 'All' end as c2,tn.submitedon as c3,tn.submitedby as c4,od.docName as c5,od.path as c6,odm.officerdocmappingId as c7,od.officerdocid as c8,tn.notificationId as c9  ");
		sb.append(" from apptender.tbl_tender tt ");
		sb.append("	INNER JOIN apptender.tbl_Notification tn ON tn.objectId=tt.tenderId and tt.tenderId=:tenderId and tn.bidderStatus=2 ");
		sb.append(" LEFT OUTER JOIN appuser.tbl_OfficerDocMapping odm ON odm.objectId=tn.notificationId and odm.cstatus=1 and odm.linkId=3334");
		sb.append(" LEFT OUTER JOIN appuser.tbl_officerDocument od ON odm.officerDocId=od.officerDocId order by c9 desc");
        list = hibernateQueryDao.createSQLQuery(sb.toString(), var,new int[]{1,5,6},10);
        return list;
    }
    
    /**
     * @param tenderId
     * @param companyid
     * @param envelopeId
     * @return
     * @throws Exception
     */
    public List<TblTenderOpen> getTenderOpenDetailBidderEnvelope(int tenderId,int companyId,int envelopeId) throws Exception {
    	List<TblTenderOpen> tblTenderOpen = tblTenderOpenDao.findTblTenderOpen("tblTender.tenderId",Operation_enum.EQ,tenderId,"tblCompany.companyId",Operation_enum.EQ,companyId,"tblTenderEnvelope.envelopeId",Operation_enum.EQ,envelopeId);
    	return tblTenderOpen;
    }
    
    public List<TblTenderBidOpenSign> getTenderBidOpenSign(int bidTableId) throws Exception {
    	List<TblTenderBidOpenSign> tblTenderBidOpenSign = tblTenderBidOpenSignDao.findTblTenderBidOpenSign("tblTenderBidMatrix.bidTableId",Operation_enum.EQ,bidTableId);
    	return tblTenderBidOpenSign;
    }
    
    public List<TblTenderBidDetail> getTenderBidDetails(int bidTableId) throws Exception {
    	List<TblTenderBidDetail> tblTenderBidDetail = tblTenderBidDetailDao.findTblTenderBidDetail("tblTenderBidMatrix.bidTableId",Operation_enum.EQ,bidTableId);
    	return tblTenderBidDetail;
    }
    
    /**
     * @author Nitin.w 
     * @param formId
     * @return
     * @throws Exception
     */
    public boolean getCountOfBidByFormId(int formId) throws Exception{
    	int patnertype = 0;
    	boolean partnerFlag = false;
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        StringBuilder query = new StringBuilder();
        query.append(" select COUNT(*) AS C1,1 from TblTender tblTender");
        query.append(" INNER JOIN tblTender.tblTenderBid tblTenderBid  ");
        query.append(" INNER JOIN tblTender.tblFinalSubmission tblFinalSubmission ");
        query.append(" WHERE tblTenderBid.tblCompany.companyId = tblFinalSubmission.tblCompany.companyId AND tblTenderBid.tblTenderForm.formId = :formId ");
        list = hibernateQueryDao.createQuery(query.toString(), var);
        if(list!=null && !list.isEmpty()){
        	patnertype= Integer.parseInt(list.get(0)[0].toString());
        	if(patnertype>=1)
        	{
        		partnerFlag = true;
        	}
	      }
        return partnerFlag;
    }
    /**
     * Delete entry from tbl_TenderOpen(for nextEnvelope) and tbl_BidderApprovalDetail for bidder 
     * which are rejected while doing reevealution
     * @author anjali
     * @param tenderId
     * @param envelopeId
     * @param bidderId
     * @return boolean
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean deleteRejectedBidder(int tenderId,int envelopeId,int bidderId) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("envelopeId", envelopeId);
        var.put("bidderId", bidderId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("DELETE FROM TblTenderOpen WHERE tblTender.tenderId=:tenderId AND tblTenderEnvelope.envelopeId=:envelopeId AND tblUserLogin.userId=:bidderId",var);
        cnt = hibernateQueryDao.updateDeleteNewQuery("DELETE FROM TblBidderApprovalDetail WHERE tblTender.tenderId=:tenderId AND tblTenderEnvelope.envelopeId=:envelopeId AND tblUserLogin.userId=:bidderId",var);
        return cnt != 0;
    }
    
    /**
     * Get items which are regretted by bidder 
     * @author meghna
     * @param tenderId
     * @param bidderId
     * @param regretType
     * @param isItems
     * @return
     * @throws Exception
     */
    public List<Object[]> getRegretedItemsByBidder(int tenderId,int bidderId,int regretType,int isItems) throws Exception{
    	Map<String, Object> var = new HashMap<String, Object>();
    	StringBuilder query= new StringBuilder();
    	List<Object[]> list = null;
       	var.put("tenderId", tenderId);
    	var.put("bidderId", bidderId);
    	var.put("regretType", regretType);
    	if(isItems==1){
    		query.append(" select tc.cellValue as c0,tbr.remarks as c1,ul.userName as c2,tbr.companyId as c3,tbr.tableId as c4,tt.tableName as c5,tf.formId as c6,tf.formName as c7");
    	}else{
    		query.append(" select distinct tbr.tableId as c0,tt.tableName as c1,tf.formId as c2");
    	}
		query.append(" from apptenderbid.tbl_TenderBidRegression tbr");
		query.append(" INNER JOIN apptender.tbl_TenderForm tf on  tbr.formId = tf.formId");
		query.append(" INNER JOIN apptender.tbl_TenderTable tt on tf.formid=tt.formId and tbr.tableId = tt.tableId");
		query.append(" INNER JOIN apptender.tbl_TenderColumn tcm on tf.formId = tcm.formId and tt.tableId = tcm.tableId and tcm.columnTypeId=1");
		query.append(" INNER JOIN apptender.tbl_TenderCell tc on  tc.tableid=tt.tableid and tcm.columnId = tc.columnId and tbr.rowId = tc.rowId");
		query.append(" INNER JOIN appuser.tbl_UserLogin ul on tbr.bidderId = ul.userId");
		query.append(" where tbr.tenderId=:tenderId and tbr.isActive=1 and tbr.regretType=:regretType and tbr.bidderId=:bidderId");
		if(isItems==1){
			list = hibernateQueryDao.createSQLQuery(query.toString(), var,new int[]{0,1,2,5,7},8);
		}else{
			list = hibernateQueryDao.createSQLQuery(query.toString(), var,new int[]{1},3);
		}	
    	return list;
    }
    
    /**
     * @author meghna
     * @param tenderId
     * @param bidderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderDecrypteddPriceBidForm(int tenderId,int bidderId) throws Exception{
    	Map<String,Object> var = new HashMap<String,Object>();
        StringBuilder query = new StringBuilder();
        var.put("tenderId", tenderId);
        var.put("bidderId", bidderId);
        query.append("select DISTINCT tblTenderForm.formId,tblTenderForm.formName ");
        query.append(" from TblTenderForm tblTenderForm");
        query.append(" INNER JOIN tblTenderForm.tblTenderOpen tblTenderOpen");
        query.append(" where  tblTenderOpen.decryptionLevel = 1 and tblTenderOpen.tblTenderEnvelope.envelopeId = tblTenderForm.tblTenderEnvelope.envelopeId");
        query.append(" AND tblTenderForm.tblTender.tenderId=:tenderId AND tblTenderForm.cstatus = 1 AND tblTenderForm.isPriceBid=1 AND tblTenderOpen.tblUserLogin.userId=:bidderId");
        return hibernateQueryDao.createQuery(query.toString(), var);
    }
    
    public Map<String,Object> getCGReport2Detail(int tenderId,int clientId) throws Exception
    {
    	return sPGetCGMPReport2.executeProcedure(tenderId, clientId);
    }
    
    public Map<String, Object> getCGReport1Detail(int tenderId,int clientId) throws Exception
    {
    	return sPGetCGMPReport.executeProcedure(tenderId, clientId);
    }
    
    public List<Object[]> getParticipatedOrQualifiedBidderDetail(int tenderId,int userId,int envelopeId)throws Exception{
    	Map<String, Object> var = new HashMap<String, Object>();
    	StringBuilder query= new StringBuilder();
    	List<Object[]> list = null;
       	var.put("tenderId", tenderId);
       	var.put("bidderId", userId);
       	var.put("envelopeId", envelopeId);       	
       	query.append(" SELECT BAD.isApproved AS c0,FS.bidderId AS c1 ");
       	query.append(" from apptenderbid.tbl_FinalSubmission FS ");
       	query.append(" left join apptenderresult.tbl_BidderApprovalDetail BAD on BAD.tenderId=FS.tenderId and BAD.bidderId=FS.bidderId and BAD.envelopeId=:envelopeId ");
       	query.append(" where FS.tenderId=:tenderId and FS.bidderId=:bidderId and FS.isActive=1 ");
       	list = hibernateQueryDao.createSQLQuery(query.toString(), var);
    	return list!=null && !list.isEmpty() ? list : null;
    }
    
    public List<Object[]> getShareReportDetailsByReportIdFormId(int shareReportId,int formId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("shareReportId",shareReportId);
        var.put("formId", formId);
        list = hibernateQueryDao.createNewQuery("select tblsharereportdetail.shareIndividualReport, tblsharereportdetail.shareComparativeReport, tblsharereportdetail.shareDocument, tblsharereportdetail.shareReportDetailId, tblsharereportdetail.tblTenderForm.formId from TblShareReportDetail tblsharereportdetail where tblsharereportdetail.tblShareReport.shareReportId=:shareReportId and tblsharereportdetail.tblTenderForm.formId=:formId order by tblsharereportdetail.tblTenderForm.formId ",var);                
        return list!=null && !list.isEmpty() ? list : null;        
    }
}
