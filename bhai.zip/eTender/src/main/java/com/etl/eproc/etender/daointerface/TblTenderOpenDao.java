/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;

import com.etl.eproc.etender.model.TblTenderOpen;
import java.util.List;

/**
 *
 * @author dipal
 */

public interface TblTenderOpenDao  {

    public void addTblTenderOpen(TblTenderOpen tblTenderOpen);

    public void deleteTblTenderOpen(TblTenderOpen tblTenderOpen);

    public void updateTblTenderOpen(TblTenderOpen tblTenderOpen);

    public List<TblTenderOpen> getAllTblTenderOpen();

    public List<TblTenderOpen> findTblTenderOpen(Object... values) throws Exception;

    public List<TblTenderOpen> findByCountTblTenderOpen(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderOpenCount();

    public void saveUpdateAllTblTenderOpen(List<TblTenderOpen> tblTenderOpens);
}