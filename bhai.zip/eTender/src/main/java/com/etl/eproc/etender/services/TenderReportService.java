/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblOverRuledReportDao;
import com.etl.eproc.common.daointerface.TblOverRuledReportDetailDao;
import com.etl.eproc.etender.daointerface.TblCPPPXmlEntryDao;
import com.etl.eproc.etender.daointerface.TblTenderReportDao;
import com.etl.eproc.etender.daointerface.TblTenderSavingDao;
import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.etender.daostoredprocedure.SPGenerateCustomReport;
import com.etl.eproc.etender.daostoredprocedure.SPGetAdvertiseDetailReport;
import com.etl.eproc.etender.daostoredprocedure.SPGetTenderMisReport;
import com.etl.eproc.etender.daostoredprocedure.SPGetVendorPQReport;
import com.etl.eproc.etender.daostoredprocedure.SPItemwiseL1ReportAfterLoading;
import com.etl.eproc.etender.daostoredprocedure.SPManagementReport;
import com.etl.eproc.etender.daostoredprocedure.SPSORReport;
import com.etl.eproc.etender.daostoredprocedure.SPTenderAuditTrialReport;
import com.etl.eproc.etender.daostoredprocedure.SPTenderOpeningReportDetails;
import com.etl.eproc.etender.daostoredprocedure.SPTenderReport;
import com.etl.eproc.etender.daostoredprocedure.SPWeightatgeL1Report;
import com.etl.eproc.etender.daostoredprocedure.sPGetCPPPXMLData;
import com.etl.eproc.etender.model.TblCPPPXmlEntry;
import com.etl.eproc.etender.model.TblOverRuledReport;
import com.etl.eproc.etender.model.TblOverRuledReportDetail;
import com.etl.eproc.etender.model.TblTenderReport;
import com.etl.eproc.etender.model.TblTenderSaving;

/**
 *
 * @author dipal
 */
@Service
public class TenderReportService {
    @Autowired
    private SPTenderReport spTenderReport;
    @Autowired
    private SPTenderAuditTrialReport spTenderAuditTrialReport;
    @Autowired
    private SPGenerateCustomReport sPGenerateCustomReport;
    @Autowired
    private SPSORReport sPSORReport;
    @Autowired
    private SPManagementReport sPManagementReport;
    @Autowired
    private SPItemwiseL1ReportAfterLoading itemwiseL1ReportAfterLoading;
    @Autowired
    private SPWeightatgeL1Report weightageL1Report;
    @Autowired
    private SPGetTenderMisReport sPGetTenderMisReport;
    @Autowired
    private SPGetVendorPQReport sPGetVendorPQReport; 
    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    @Autowired
    private SPTenderOpeningReportDetails sPTenderOpeningReportDetails;
    @Autowired
    private TblOverRuledReportDao tblOverRuledReportDao;
    @Autowired
    private TblOverRuledReportDetailDao tblOverRuledReportDetailDao;
    @Autowired
    private TblTenderReportDao tblTenderReportDao;
    @Autowired
    private SPGetAdvertiseDetailReport sPGetAdvertiseDetailReport;
    @Autowired
    private sPGetCPPPXMLData sPGetCPPPXMLData;
    @Autowired
    private TblCPPPXmlEntryDao cpppXmlEntryDao;
    @Autowired
    private TblTenderSavingDao tblTenderSavingDao;
    
    /**
     * Method use for get L1H1 Report Detail from Store procedure.
     * @author dipal
     * @param tenderId
     * @param envelopId
     * @param formId
     * @return {@code<Map<String, Object>>}
     */
    public Map<String,Object> getL1H1ReportDetail(int tenderId) throws Exception
    {
        return spTenderReport.executeProcedure(tenderId,0,1);
    }
    /**
     * Method use for get Item Wise L1H1 report for SealedBid
     * @author dipal
     * @param tenderId
     * @param formId
     * @return {@code<Map<String, Object>>}
     * @throws Exception 
     */
    public Map<String,Object> getItemWiseEvaluationReportDetail(int eventId,int formId) throws Exception
    {
        return spTenderReport.executeProcedure(eventId,formId,2);
    }
    /**
     * Method use for get Item Wise L1H1 report for SealedBid
     * @author dipal
     * @param tenderId
     * @param formId
     * @return {@code<Map<String, Object>>}
     * @throws Exception 
     */
    public Map<String,Object> getItemWiseBreakupReportDetail(int eventId,int formId,int operation) throws Exception
    {
        return spTenderReport.executeProcedure(eventId,formId,operation);
    }
    /**
     * 
     * @param eventId
     * @param tableId
     * @return
     * @throws Exception 
     */
    public Map<String,Object> getTenderOpeningReportDetail(int eventId,int tableId,int operation) throws Exception
    {
        return sPTenderOpeningReportDetails.executeProcedure(eventId,tableId,operation);
    }
    
    /**
     * to get tender audit trial report
     * @param tenderId
     * @param timeZoneOffset
     * @param conversionValue
     * @param langId
     * @return {@code<Map<String, Object>>}
     * @throws Exception
     */
    public Map<String,Object> getTenderAuditTrialReportDetail(int tenderId,String timeZoneOffset,int conversionValue,int langId) throws Exception
    {
        return spTenderAuditTrialReport.executeProcedure(tenderId,timeZoneOffset,conversionValue,langId);
    }
    
    /**
     * Method use for get customized report configuration detail for generate customize report base on selection of filters.
     * @author dipal
     * @param tenderId
     * @param formId
     * @return {@code<Map<String, Object>>}
     */
    public Map<String,Object> getCustomizeReportConfigDtl(int tenderId,int formId) throws Exception
    {
        return sPGenerateCustomReport.executeProcedure(tenderId,formId,1,"","","");
    }
    
    /**
     * Method use for generate Customize report base on given filter criteria.
     * @param tenderId
     * @param formId
     * @param bidderIds
     * @param columnIds
     * @param rowIds
     * @return {@code<Map<String, Object>>}
     * @throws Exception 
     */
     public Map<String,Object> getCustomizeReportDtl(int tenderId,int formId,String bidderIds, String columnIds, String rowIds) throws Exception
    {
        return sPGenerateCustomReport.executeProcedure(tenderId,formId,2,bidderIds,columnIds,rowIds);
    }
    
     /**
     * Method use for get configuration detail for generate SOR report.
     * @author dipal
     * @param tenderId
     * @param formId
     * @return {@code<Map<String, Object>>}
     */
    public Map<String,Object> getSORReportConfigDtl(int tenderId,int formId) throws Exception
    {
        //return sPSORReport.executeProcedure(tenderId,formId,"",1);
        return sPSORReport.executeProcedure(tenderId,formId,0,"",1,0,0);
    }
     
     /**
     * Method use for generate SOR report.
     * @param tenderId
     * @param formId
     * @param columnIds
     * @return {@code<Map<String, Object>>}
     * @throws Exception 
     */
     public Map<String,Object> getSORReportDtl(int tenderId,int formId,int tableId,String columnIds,int flag,int reportType,int columnId) throws Exception
    {
        return sPSORReport.executeProcedure(tenderId,formId,tableId,columnIds,flag,reportType,columnId);
    }
     
     /**
      * @author manoj.gadhavi
      * Method use for generate Management report.
      * @param tenderId
      * @return {@code<Map<String, Object>>}
      * @throws Exception 
      */
      public Map<String,Object> getManagementReport(int tenderId) throws Exception
     {
         return sPManagementReport.executeProcedure(tenderId);
     }
     
      /**
       * @author manoj.gadhavi
       * Method use for generate Itemwise L1 report After Loading.
       * @param tenderId
       * @return {@code<Map<String, Object>>}
       * @throws Exception 
       */
       public Map<String,Object> getItemwiseL1ReportAfterLoading(int tenderId,int reportType) throws Exception
      {
          return itemwiseL1ReportAfterLoading.executeProcedure(tenderId,reportType);
      }
     
      
     /**
     * Method use for generate Tender MIS report.
     * author: heeral.soni since 10/25/2013
     * @throws Exception 
     */
     public Map<String,Object> getMISReport(int eventId,String refNo,Date eventPubDateFrom, Date eventPubDateTo,double estValFrom,int estOpFrom,double estValTo,Date bidSubDateFrom, Date bidSubDateTo,int typeOfContract,int biddingAccess,int biddingType,int status,int departmentId,String timeZoneOffset,int conversionValue,int recordPerPage,int pageNo,int clientId,int officerId,int pubDateOpFrom,int subDateOpFrom,List<Short> showHide) throws Exception
     {
        int langId = Integer.parseInt(WebUtils.getCookie(getServletRequest(), "locale").getValue());
        return sPGetTenderMisReport.executeProcedure(clientId,eventId,officerId,departmentId,refNo,pubDateOpFrom,eventPubDateFrom,eventPubDateTo,estOpFrom,estValFrom,estValTo,subDateOpFrom,bidSubDateFrom,bidSubDateTo,typeOfContract,biddingAccess,biddingType,status,timeZoneOffset,conversionValue,langId,showHide,recordPerPage,pageNo) ;          
     }
     
     public Map<String,Object> getVendorPQReport(int clientId,int officerId,int deptId,
     		String fileNo,String companyName,int departmentId,int registeredIn
     		,int indTypeId,int actionTakenId,int indClassificationId,
     		int effectiveDateOperator,Date effectiveDateFrom,Date effectiveDateTo,int expiredOnOperator,Date expiredOnFrom,Date expiredOnTo,
     		int status,String timeZoneOffset,int conversionValue,List<Short> showHide,int recordPerPage,int pageNo,String sortBy,String sortOrder) throws Exception
     {
        return sPGetVendorPQReport.executeProcedure(clientId,officerId,deptId,fileNo,companyName,departmentId,registeredIn,indTypeId,actionTakenId,indClassificationId,effectiveDateOperator,effectiveDateFrom,effectiveDateTo,expiredOnOperator,expiredOnFrom,expiredOnTo,status,timeZoneOffset,conversionValue,showHide,recordPerPage,pageNo,sortBy,sortOrder);          
     }
     
      /**
     * Method to get tender access details of both limited tender as well as open tender
     * @param tenderId
     * @param tenderType - 2 for limited tender and 1 for open
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderAccessDetails(int tenderId, int tenderType) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        StringBuilder strQuery = new StringBuilder();
        var.put("tenderId", tenderId);
        strQuery.append("select tbluserdetail.companyName, tbltenderbidconfirmation.bidConfirmationId, tblfinalsubmission.finalSubmissionId, ")
                .append("tblfinalsubmission.ipAddress, tblfinalsubmission.createdOn, tbluserdetail.userDetailId, tblcompany.companyId, tbluserdetail.loginId, ")
                .append(" (select count(tblbidderdocmapping.bidderDocMappingId) from TblBidderDocMapping tblbidderdocmapping  ")
                .append(" where tblbidderdocmapping.tblCompany.companyId=tblcompany.companyId and tblbidderdocmapping.tblLink.linkId=524  and tblbidderdocmapping.objectId=:tenderId) , ");
        if (tenderType == 2) {
        	strQuery.append("tbltenderbiddermap.tblUserLogin.userId ")
            		.append("from TblTenderBidderMap tbltenderbiddermap ")
                    .append("inner join tbltenderbiddermap.tblUserDetail tbluserdetail ")
                    .append("inner join tbltenderbiddermap.tblCompany tblcompany ")
                    .append("left join tblcompany.tblTenderBidConfirmation tbltenderbidconfirmation with tbltenderbidconfirmation.tblTender.tenderId=:tenderId ")
                    .append("left join tblcompany.tblFinalSubmission tblfinalsubmission with tblfinalsubmission.tblTender.tenderId=:tenderId ")
                    .append("where tbltenderbiddermap.tblTender.tenderId=:tenderId ");
        } else {
        	strQuery.append("tbltenderbidconfirmation.tblUserLogin.userId ")
            		.append("from  TblTenderBidConfirmation tbltenderbidconfirmation ")
                    .append("inner join tbltenderbidconfirmation.tblCompany tblcompany ")
                    .append("inner join tbltenderbidconfirmation.tblUserDetail tbluserdetail ")
                    .append("left join tblcompany.tblFinalSubmission tblfinalsubmission with tblfinalsubmission.tblTender.tenderId=:tenderId ")
                    .append("where tbltenderbidconfirmation.tblTender.tenderId=:tenderId");
        }


        list = hibernateQueryDao.createNewQuery(strQuery.toString(), var);
        return list;

    }
    
    /**
     * 
     * @param tenderId
     * @param userDetailsId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getUserTenderAccessDetails(int tenderId,int companyId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
        StringBuilder strQuery = new StringBuilder();
        strQuery.append("select tblTenderEnvelope.envelopeName,tbltenderform.formName,tbltenderform.isMandatory, tbltenderbid.bidId,tbltenderbid.tblCompany.companyId,tbltenderform.formId,tblTenderEnvelope.envelopeId ")
        .append("from  TblTenderEnvelope tblTenderEnvelope ")
        .append("inner join  tblTenderEnvelope.tblTenderForm tbltenderform ")
        .append("left join  tbltenderform.tblTenderBid tbltenderbid with tbltenderbid.tblCompany.companyId=:companyId ")
        .append("where tblTenderEnvelope.tblTender.tenderId=:tenderId ");
        list = hibernateQueryDao.createNewQuery(strQuery.toString(),var);                
        return list;        

    }
    
     /**
     * author : heeral.soni
     * @param formId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getSORColumnDetails(int formId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        StringBuilder query = new StringBuilder();
        query.append(" select tbltendercolumn.columnHeader,tbltendercolumn.columnId,tbltendercolumn.tblTenderTable.tableId");
        query.append(" from TblTenderColumn tbltendercolumn");
        query.append(" where tbltendercolumn.tblTenderForm.formId=:formId and tbltendercolumn.tblColumnType.columnTypeId in (4,5)");
        //System.out.println("query = " + query.toString());
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        
    }

    /**
     * author : heeral.soni
     * used to get tender form details
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderFormDetails(int formId) throws Exception {
        Map<String,Object> var = new HashMap<String,Object>();
        var.put("formId", formId);
        return hibernateQueryDao.createNewQuery("select tbltenderform.formName,tbltenderform.formHeader,tbltenderform.formFooter from TblTenderForm tbltenderform where tbltenderform.formId=:formId", var);
    }
    /**
     * author : heeral.soni
     * @param formId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderTableDetail(List<Integer> tableId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId",tableId);
        StringBuilder query = new StringBuilder();
        query.append(" select tbltendertable.tableId,tbltendertable.tableHeader,tbltendertable.tableFooter");
        query.append(" from TblTenderTable tbltendertable");
        query.append(" where tbltendertable.tableId in (:tableId)");
//        System.out.println("query getTenderTableDetails= " + query.toString());
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        //System.out.println("list = " + list.size());
        return list;        
    }
    public HttpServletRequest getServletRequest() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return attr.getRequest();
    }
    
    /**
     * author : Lipi Shah
     * get Manual L1 Report for create
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getManualReportDetails(int tenderId,int isEncodedName,int isEvaluationRequired) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        /*Changes for Bug #50809*/
        if(isEvaluationRequired==0){
        	if(isEncodedName==1){
	        	query.append(" SELECT tblFinalSubmission.tblCompany.companyId,tblTenderBidConfirmation.encodedName,tblFinalSubmission.tblUserLogin.userId");
	            query.append(" FROM TblFinalSubmission tblFinalSubmission ,TblTenderBidConfirmation tblTenderBidConfirmation ");
	            query.append(" WHERE tblFinalSubmission.tblTender.tenderId =:tenderId ");
	            query.append(" AND tblTenderBidConfirmation.tblTender.tenderId =:tenderId ");
	            query.append(" AND tblTenderBidConfirmation.tblCompany.companyId=tblFinalSubmission.tblCompany.companyId");
        	}
        	else{
        		query.append(" SELECT tblFinalSubmission.tblCompany.companyId,tbluserdetail.companyName,tblFinalSubmission.tblUserLogin.userId");
                query.append(" FROM TblFinalSubmission tblFinalSubmission");
                query.append(" INNER JOIN tblFinalSubmission.tblUserDetail tbluserdetail");
                query.append(" WHERE tblFinalSubmission.tblTender.tenderId =:tenderId ");
        	}
        }
        else{
        if(isEncodedName==1){
        	query.append(" SELECT tblbidderapprovaldetail.tblCompany.companyId,tblTenderBidConfirmation.encodedName,tblbidderapprovaldetail.tblUserLogin.userId");
            query.append(" FROM TblBidderApprovalDetail tblbidderapprovaldetail,TblTenderBidConfirmation tblTenderBidConfirmation ");
            query.append(" WHERE tblbidderapprovaldetail.tblTender.tenderId =:tenderId AND tblbidderapprovaldetail.tblTenderEnvelope.envelopeId = ");
            query.append(" (SELECT MAX(tbltenderenvelope.envelopeId) FROM TblTenderEnvelope tbltenderenvelope WHERE tbltenderenvelope.tblTender.tenderId=:tenderId)");
            query.append(" AND tblbidderapprovaldetail.isApproved = 1 AND tblTenderBidConfirmation.tblTender.tenderId =:tenderId ");
            query.append(" AND tblTenderBidConfirmation.tblCompany.companyId=tblbidderapprovaldetail.tblCompany.companyId");
        }
        else{
	        query.append(" SELECT tblbidderapprovaldetail.tblCompany.companyId,tbluserdetail.companyName,tblbidderapprovaldetail.tblUserLogin.userId");
	        query.append(" FROM TblBidderApprovalDetail tblbidderapprovaldetail");
	        query.append(" INNER JOIN tblbidderapprovaldetail.tblUserDetail tbluserdetail");
	        query.append(" WHERE tblbidderapprovaldetail.tblTender.tenderId =:tenderId AND tblbidderapprovaldetail.tblTenderEnvelope.envelopeId = ");
	        query.append(" (SELECT MAX(tbltenderenvelope.envelopeId) FROM TblTenderEnvelope tbltenderenvelope WHERE tbltenderenvelope.tblTender.tenderId=:tenderId)");
	        query.append(" AND tblbidderapprovaldetail.isApproved = 1 ");
        }
        }
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    /**
     * author : Lipi Shah
     * get Manual L1 Report for edit/view
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getOverRuledReport(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" SELECT tbloverruledreportdetail.tblCompany.companyId,tblcompany.companyName,tbloverruledreportdetail.tblUserLogin.userId," +
        		"tbloverruledreportdetail.amount,tbloverruledreportdetail.remarks,tbloverruledreport.overRuledReportId");
        query.append(" FROM TblOverRuledReport tbloverruledreport");
        query.append(" INNER JOIN tbloverruledreport.tblOverRuledReportDetail tbloverruledreportdetail");
        query.append(" INNER JOIN tbloverruledreportdetail.tblCompany tblcompany");
        query.append(" WHERE tbloverruledreport.tblTender.tenderId=:tenderId ORDER BY tbloverruledreportdetail.amount");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    /**
     * @author vivek.rajyaguru
     * @param tenderId
     * @param orderBy
     * @return
     * @throws Exception
     */
    public List<Object[]> getOverRuledReport(int tenderId,String orderBy) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" SELECT tbloverruledreportdetail.amount as totalAmt, tblTender.tenderValue as estimatedAmt, ");
        query.append(" CASE WHEN tblTender.tenderValue = 0 THEN tblTender.tenderValue ELSE CASE WHEN tblTender.biddingVariant=1  ");
        query.append(" THEN tblTender.tenderValue - tbloverruledreportdetail.amount ");
        query.append(" ELSE tbloverruledreportdetail.amount - tblTender.tenderValue END END as savingGainAmt");
        query.append(" FROM   apptenderresult.Tbl_OverRuledReport tbloverruledreport INNER JOIN apptender.tbl_Tender tblTender ON tblTender.tenderId=tbloverruledreport.tenderId and tblTender.tenderId=:tenderId ");
        query.append(" INNER JOIN apptenderresult.tbl_OverRuledReportDetail tbloverruledreportdetail ON tbloverruledreport.overRuledReportId=tbloverruledreportdetail.overRuledReportId order by tbloverruledreportdetail.amount "+orderBy);
        return hibernateQueryDao.createSQLQuery(query.toString(), var);
    }
    
    /**
     * author : Lipi Shah
     * get Manual L1 Report for edit/view
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public Object[] getOverRuledReport(int tenderId,int companyId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
        StringBuilder query = new StringBuilder();
        List<Object[]> list = null;
        query.append(" SELECT tbloverruledreportdetail.tblCompany.companyId,tbloverruledreportdetail.amount");
        query.append(" FROM TblOverRuledReport tbloverruledreport");
        query.append(" INNER JOIN tbloverruledreport.tblOverRuledReportDetail tbloverruledreportdetail");
        query.append(" INNER JOIN tbloverruledreportdetail.tblCompany tblcompany");
        query.append(" WHERE tbloverruledreport.tblTender.tenderId=:tenderId AND tbloverruledreportdetail.tblCompany.companyId=:companyId ORDER BY tbloverruledreportdetail.amount");
        list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return (list!=null && !list.isEmpty()) ? list.get(0) : null;
    }
    
    /**
     * author : Lipi Shah
     * Manual L1 Report for add/update
     * @param tenderId
     * @return
     * @throws Exception 
     */
    @Transactional(propagation= Propagation.REQUIRED,rollbackFor=Exception.class)
	public boolean addUpdateOverRuledReport(TblOverRuledReport overRuledReport,List<TblOverRuledReportDetail> tblOverRuledReportDetails) {
    	boolean bSuccess = false;
		tblOverRuledReportDao.saveOrUpdateTblOverRuledReport(overRuledReport);
		if(tblOverRuledReportDetails !=null && !tblOverRuledReportDetails.isEmpty()){
			Map<String, Object> var = new HashMap<String, Object>();
			var.put("overRuledReportId", overRuledReport.getOverRuledReportId());
			hibernateQueryDao.updateDeleteQuery("DELETE FROM TblOverRuledReportDetail where overRuledReportId =:overRuledReportId",var);
			tblOverRuledReportDetailDao.saveUpdateAllTblOverRuledReportDetail(tblOverRuledReportDetails);
		}
    	bSuccess=true;     
		return bSuccess;
	}
    
    /**
     * author : Lipi Shah
     * Manual L1 Report for publish
     * @param tenderId
     * @return
     * @throws Exception 
     */
    @Transactional(propagation= Propagation.REQUIRED,rollbackFor=Exception.class)
	public boolean updateOverRuledReport(TblOverRuledReport overRuledReport) {
		int cnt = 0;
		Map<String, Object> var = new HashMap<String, Object>();
		StringBuilder query = new StringBuilder();
		var.put("updatedOn",overRuledReport.getUpdatedOn());
		var.put("updatedBy",overRuledReport.getUpdatedBy());
		var.put("publishedOn",overRuledReport.getPublishedOn());
		var.put("publishedBy",overRuledReport.getPublishedBy());
		var.put("cstatus",overRuledReport.getCstatus());
		var.put("tenderId",overRuledReport.getTblTender().getTenderId());
        query.append(" update TblOverRuledReport tbloverruledreport set ");
        query.append(" updatedOn=:updatedOn ,updatedBy=:updatedBy ,publishedOn=:publishedOn,publishedBy=:publishedBy,cstatus=:cstatus");
        query.append(" WHERE tbloverruledreport.tblTender.tenderId=:tenderId");
        cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);        
        return cnt!=0;
	}
    
    @Transactional(propagation= Propagation.REQUIRED,rollbackFor=Exception.class)
	public boolean updateOverRuledReportinReevaluation(int tenderId,int cstatus) {
		int cnt = 0;
		Map<String, Object> var = new HashMap<String, Object>();
		StringBuilder query = new StringBuilder();
		var.put("cstatus",0);
		var.put("tenderId",tenderId);
        query.append(" update TblOverRuledReport tbloverruledreport set ");
        query.append(" cstatus=:cstatus");
        query.append(" WHERE tbloverruledreport.tblTender.tenderId=:tenderId");
        cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);        
        return cnt!=0;
	}
    
    /**
     * author : Lipi Shah
     * check is OverRuled Report Entry exits or not
     * @param tenderId
     * @return
     * @throws Exception 
     */
	public boolean isOverRuleReportExits(int tenderId,int status) throws Exception{
		long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        if(status == 1){//for create 
        	count = hibernateQueryDao.countForQuery("TblOverRuledReport tbloverruledreport", "tbloverruledreport.tblTender.tenderId", "tbloverruledreport.tblTender.tenderId = :tenderId", var);	
        }else if(status == 2){//for edit or published
        	count = hibernateQueryDao.countForQuery("TblOverRuledReport tbloverruledreport", "tbloverruledreport.tblTender.tenderId", "tbloverruledreport.tblTender.tenderId = :tenderId AND tbloverruledreport.cstatus=1", var);
        }
        return count != 0;
	}
	
	/**
     * author : Lipi Shah
     * check manual report is configuration is done or not(winningReportMode=2)
     * @param tenderId
     * @return
     * @throws Exception 
     */
	public boolean isManualReportsConfig(int tenderId) throws Exception{
		long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        count = hibernateQueryDao.countForQuery("TblTender tbltender", "tbltender.winningReportMode", "tbltender.tenderId = :tenderId AND tbltender.winningReportMode=2", var);	
        return count != 0;
	}
	

    /**
     * @author janak dhanani
     * Method use for generate weightage Evaluation L1 Report.
     * @param tenderId
     * @param userRoleId 
     * @return {@code<Map<String, Object>>}
     * @throws Exception 
     */
     public Map<String,Object> getWeightageL1Report(int tenderId, int userRoleId) throws Exception
    {
        return weightageL1Report.executeProcedure(tenderId,userRoleId);
    }
     
     
     /**
     * @author vivek.rajyaguru
     * @param clientId
     * @param deptId
     * @param eventId
     * @param txtAdvertiseNo
     * @param txtPaperAdvertisementNo
     * @param advertiseType
     * @param pubDateOpFrom
     * @param publishDateFrom
     * @param publishDateTo
     * @param advStatus
     * @param subDateOpFrom
     * @param bidDateFrom
     * @param bidDateTo
     * @param downloadDocumentDateOperator
     * @param downloadDocumentDateFrom
     * @param downloadDocumentDateTo
     * @param openingDateFromOperator
     * @param openingDateFrom
     * @param openingDateTo
     * @param estOpFrom
     * @param estValFrom
     * @param estValTo
     * @param officerId
     * @param contractType
     * @param timeZoneOffset
     * @param conversionValue
     * @param showHide
     * @param recordPerPage
     * @param pageNo
     * @return
     * @throws Exception
     */
    public Map<String,Object> getAdvertiseDetailReport(int clientId,int deptId,int eventId,String txtAdvertiseNo,String txtPaperAdvertisementNo,int advertiseType,
    		 int pubDateOpFrom,
     		Date publishDateFrom,Date publishDateTo,
     		int advStatus,int subDateOpFrom,Date bidDateFrom,Date bidDateTo,int downloadDocumentDateOperator,Date downloadDocumentDateFrom,Date downloadDocumentDateTo,int openingDateFromOperator,
     		Date openingDateFrom,Date openingDateTo,
     		int estOpFrom,Double estValFrom,Double estValTo,int officerId,int contractType,String timeZoneOffset,int conversionValue,List<Short> showHide,int recordPerPage,int pageNo) throws Exception
     {
        int langId = Integer.parseInt(WebUtils.getCookie(getServletRequest(), "locale").getValue());
        return sPGetAdvertiseDetailReport.executeProcedure(clientId, deptId, eventId, txtAdvertiseNo, txtPaperAdvertisementNo, advertiseType, pubDateOpFrom, publishDateFrom, publishDateTo, advStatus, subDateOpFrom, bidDateFrom, bidDateTo, downloadDocumentDateOperator, downloadDocumentDateFrom, downloadDocumentDateTo, openingDateFromOperator, openingDateFrom, openingDateTo, estOpFrom, estValFrom, estValTo, officerId, contractType, timeZoneOffset, conversionValue, langId, showHide, recordPerPage, pageNo);    
     }

    /**
     * @author janak.dhanani
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderPricebidData(int tenderId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuffer sb = new StringBuffer();
        sb.append(" SELECT * FROM ( ");
        sb.append(" SELECT  bidderId as c0, companyName as c1, [4] as c2, [5] as c3 , createdOn as c4");
        sb.append(" FROM ( ");
	        sb.append(" SELECT TB.bidderId, c.companyName, ISNULL(TBD.cellValue,0) as cellValue, TCC.columnTypeId, fs.createdOn ");
			sb.append(" FROM apptenderresult.tbl_TenderBidDetail TBD ");
			sb.append(" INNER JOIN apptender.tbl_TenderCell TC on TBD.cellId = TC.cellId ");
			sb.append(" INNER JOIN apptender.tbl_TenderColumn TCC on TCC.columnId = TC.columnId and TCC.columnTypeId in (4,5) ");
			sb.append(" INNER JOIN apptenderbid.tbl_TenderBidMatrix TBM ON TBM.bidTableId = TBD.bidTableId ");
	        sb.append(" INNER JOIN apptenderbid.tbl_TenderBid TB ON TB.bidId = TBM.bidId ");
	        sb.append(" INNER JOIN apptenderresult.tbl_TenderOpen TOA ON TOA.tenderId = TB.tenderId AND TOA.formId = TC.formId and TOA.bidderId = TB.bidderId and TOA.decryptionLevel = 1 ");
			sb.append(" INNER JOIN apptender.tbl_tenderForm TTF on TTF.formId = TOA.formId and TTF.isPriceBid =1 and TTF.cstatus=1 ");
			sb.append(" INNER JOIN apptenderbid.tbl_FinalSubmission fs on tb.companyId=fs.companyId and fs.tenderid=tb.tenderid ");
			sb.append(" INNER JOIN appuser.tbl_UserDetail C ON fs.userDetailId=C.userDetailId ");
			sb.append(" WHERE TB.tenderId=:tenderId) up ");
		sb.append(" PIVOT (max(cellValue) FOR columnTypeId IN ([4], [5])) AS pvt  ");
		sb.append(" ) as a order by a.c4 ");
		int nVarCharColumnIndex [] = {1,2,3,4};
		list = hibernateQueryDao.createSQLQuery(sb.toString(), var, nVarCharColumnIndex, 5);
        return list;        
    }
    
    /**
     * @author priyanka.dalwadi
     * @param tenderReportId
     * @return
     * @throws Exception
     */
 
    public TblTenderReport getTenderReportDetail(int tenderReportId) throws Exception{
        List<TblTenderReport> list =  tblTenderReportDao.findTblTenderReport("tenderReportId",Operation_enum.EQ,tenderReportId);
        return list.isEmpty()?null:list.get(0);       
    }
    
    /**
	 * @author Hira.chaudhary
	 * @return
	 * @throws Exception
	 */
    public List<SelectItem> getCPPPXMLType() {
		List<SelectItem> items = new ArrayList<SelectItem>();
			items.add(new SelectItem("Tender", 1));
	        items.add(new SelectItem("Corrigendum ", 2));
	        items.add(new SelectItem("AOC ", 3));
	        items.add(new SelectItem("Auction ", 4));
	    return items;
	}
    
	/**
	 * @author Hira.chaudhary
	 * @param clientId
	 * @param eventId
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> getCPPPTenderEvent(int clientId,int cpppXMLTypeId, int eventId, String startDate, String endDate) {
		List<Object[]> list = null;
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("clientId", clientId);
		var.put("cpppXMLTypeId", cpppXMLTypeId);
		StringBuffer query = new StringBuffer();
		query.append(" select TA.tenderId As c0, TA.tenderBrief As c1,ISNULL(TCPP.eventId,0) As c2, TCPP.downloadedOn As c3");
		query.append(" from  apptender.tbl_Tender TA");
		query.append(" inner join appclient.tbl_Department TDEPT on TA.deptId = TDEPT.deptId and TA.cstatus IN (1,4,5) and TDEPT.clientId = :clientId");
		query.append(" left join apptender.tbl_CPPPXmlEntry TCPP on TA.tenderId=TCPP.eventId and TCPP.typeId=:cpppXMLTypeId WHERE 1=1");
		if (startDate != null && startDate != "" && endDate != null && endDate != "") {
			var.put("startDate", startDate);
			var.put("endDate", endDate);
			query.append(" AND TA.publishedOn BETWEEN :startDate and :endDate");
		}
		
		if (eventId != 0) {
			var.put("tenderId", eventId);
			query.append(" AND TA.tenderId=:tenderId");
		}
		query.append(" ORDER BY TA.tenderId DESC");
		list = hibernateQueryDao.createSQLQuery(query.toString(), var, new int[] {1, 3}, 4);
		return list;
	}

	/**
	 * @author Hira.chaudhary
	 * @param clientId
	 * @param eventId
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> getCPPPCorrigendumEvent(int clientId,int cpppXMLTypeId, int eventId, String startDate, String endDate) {
		List<Object[]> list = null;
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("clientId", clientId);
		var.put("cpppXMLTypeId", cpppXMLTypeId);
		StringBuffer query = new StringBuffer();
		query.append(" select distinct TA.tenderId As c0, TA.tenderBrief As c1,ISNULL(TCPP.eventId,0) As c2,TCPP.downloadedOn As c3");
		query.append(" from  apptender.tbl_Tender TA");
		query.append(" inner join appclient.tbl_Department TDEPT on TA.deptId = TDEPT.deptId and TA.cstatus IN (1,4,5) and TDEPT.clientId =:clientId");
		query.append(" inner join apptender.tbl_Corrigendum TCORR on TA.tenderId=TCORR.objectId and  TCORR.cstatus = 1 and TCORR.processId = 1");
		query.append(" inner join apptender.Tbl_CorrigendumDetail TCORRDE on TCORR.corrigendumId=TCORRDE.corrigendumId");
		query.append(" left join apptender.tbl_CPPPXmlEntry TCPP on TA.tenderId=TCPP.eventId and TCPP.typeId=:cpppXMLTypeId WHERE 1=1");
		if (startDate != null && startDate != "" && endDate != null && endDate != "") {
			var.put("startDate", startDate);
			var.put("endDate", endDate);
			query.append(" AND TCORR.publishedOn BETWEEN :startDate and :endDate ");
		}
		
		if (eventId != 0) {
			var.put("tenderId", eventId);
			query.append(" AND TA.tenderId=:tenderId ");
		}
		query.append(" AND TCORRDE.fieldName IN ('documentStartDate','documentEndDate','submissionEndDate','preBidStartDate','openingDate')");
		query.append(" ORDER BY TA.tenderId DESC");
		list = hibernateQueryDao.createSQLQuery(query.toString(), var, new int[] {1, 2}, 4);
		return list;
	}

	/**
	 * @author Hira.chaudhary
	 * @param clientId
	 * @param eventId
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> getCPPPAOCEvent(int clientId,int cpppXMLTypeId, int eventId,String startDate, String endDate) {
		List<Object[]> list = null;
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("clientId", clientId);
		var.put("cpppXMLTypeId", cpppXMLTypeId);
		StringBuffer query = new StringBuffer();
		query.append(" SELECT distinct  TA.tenderId As c0, TA.tenderBrief As c1,ISNULL(TCPP.eventId,0) As c2,TCPP.downloadedOn As c3 ");
		query.append(" FROM  apptender.tbl_Tender TA");
		query.append(" INNER JOIN appclient.tbl_Department TDEPT on TA.deptId = TDEPT.deptId AND TDEPT.clientId = :clientId");
		query.append(" INNER JOIN appcontract.tbl_PurchaseOrder TPO on ta.tenderId=TPO.objectId AND TPO.cstatus=1");
		query.append(" LEFT JOIN appcontract.tbl_OnlinePurchaseOrder TOPO on TPO.poId=TOPO.poId");
		query.append(" LEFT JOIN appcontract.tbl_OfflinePurchaseOrder TOPA on  TPO.poId=TOPA.poId");
		query.append(" INNER JOIN appuser.tbl_Company TCO on TPO.companyId=TCO.companyId");
		query.append(" INNER JOIN apptenderbid.tbl_FinalSubmission TFM on TA.tenderId=TFM.tenderId AND TFM.isActive=1");
		query.append(" LEFT JOIN apptender.tbl_CPPPXmlEntry TCPP on TA.tenderId=TCPP.eventId and TCPP.typeId=:cpppXMLTypeId WHERE 1=1");
		if (startDate != null && startDate != "" && endDate != null && endDate != "") {
			var.put("startDate", startDate);
			var.put("endDate", endDate);
			query.append(" AND TPO.publishedOn BETWEEN :startDate AND :endDate");
		}
		
		if (eventId != 0) {
			var.put("tenderId", eventId);
			query.append(" AND TA.tenderId=:tenderId");
		}
		query.append(" ORDER BY TA.tenderId DESC");
		list = hibernateQueryDao.createSQLQuery(query.toString(), var, new int[] {1, 2}, 4);
		return list;
	}
	
	/**
	 * @author Nikhil.jani
	 * @param clientId
	 * @param eventId
	 * @param startDate
	 * @param endDate
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> getCPPPAuctionEvent(int clientId,int cpppXMLTypeId, int eventId,String startDate, String endDate) {
		
		List<Object[]> list = null;
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("clientId", clientId);
		var.put("cpppXMLTypeId", cpppXMLTypeId);
		StringBuffer query = new StringBuffer();
		query.append(" select AU.auctionId As c0, AU.auctionBrief As c1,ISNULL(TCPP.eventId,0) As c2, TCPP.downloadedOn As c3");
		query.append(" from  appauction.tbl_Auction AU");
		query.append(" inner join appclient.tbl_Department TDEPT on AU.deptId = TDEPT.deptId and AU.cstatus IN (1) and TDEPT.clientId = :clientId");
		query.append(" left join apptender.tbl_CPPPXmlEntry TCPP on AU.auctionId=TCPP.eventId and TCPP.typeId=:cpppXMLTypeId WHERE 1=1");
		if (startDate != null && startDate != "" && endDate != null && endDate != "") {
			var.put("startDate", startDate);
			var.put("endDate", endDate);
			query.append(" AND AU.createdOn BETWEEN :startDate and :endDate");
		}
		
		if (eventId != 0) {
			var.put("auctionId", eventId);
			query.append(" AND AU.auctionId=:auctionId");
		}
		query.append(" ORDER BY AU.auctionId DESC");
		list = hibernateQueryDao.createSQLQuery(query.toString(), var, new int[] {1, 3}, 4);
		return list;
	}

	/**
	 * @author Hira.Chaudhary 
	 * Method use for generate CPPP XML.
	 * @param clientId
	 * @param typeId
	 * @param eventIds
	 * @return {@code<Map<String, Object>>}
	 * @throws Exception
	 */
	public Map<String, Object> getGenerateCPPPXML(int clientId, int typeId, String eventIds) throws Exception {
		return sPGetCPPPXMLData.executeProcedure(clientId, typeId, eventIds);
	}

	/**
	 * @author Hira.Chaudhary
	 * @param eventId
	 * @throws Exception
	 */
	public void insertCPPPXmlEntry(String eventIds[], TblCPPPXmlEntry cpppXmlEntry) throws Exception {
		long count = 0;	
		StringBuilder query = null;
		Map<String, Object> var = new HashMap<String, Object>();
		for (int j = 0; j < eventIds.length; j++) {
			var.put("typeId", cpppXmlEntry.getTypeId());
			var.put("eventId", eventIds[j]);
			count = hibernateQueryDao.countForNewQuery("TblCPPPXmlEntry tblCPPPXmlEntry", "tblCPPPXmlEntry.eventId","tblCPPPXmlEntry.typeId=:typeId AND tblCPPPXmlEntry.eventId=:eventId", var);
			if (count != 0) {
				var.put("fileName", cpppXmlEntry.getFileName());
				query = new StringBuilder();
				query.append("UPDATE TblCPPPXmlEntry tblCPPPXmlEntry SET");
				query.append(" tblCPPPXmlEntry.isDownloaded = 1, tblCPPPXmlEntry.fileName =:fileName, tblCPPPXmlEntry.downloadedOn='"+cpppXmlEntry.getDownloadedOn()+"'");
				query.append(" WHERE tblCPPPXmlEntry.typeId=:typeId AND tblCPPPXmlEntry.eventId=:eventId");
				hibernateQueryDao.updateDeleteQuery(query.toString(), var);
			} else {
				cpppXmlEntry.setEventId(eventIds[j]);
				cpppXmlEntryDao.addTblCPPPXmlEntry(cpppXmlEntry);
			}
			var.clear();
			query=null;
			count = 0;
		}
	}
    
	/**
	 * @author vivek.rajyaguru
	 * @param tblTenderSaving
	 * @throws Exception
	 */
	public void addTblTenderSaving(TblTenderSaving tblTenderSaving)throws Exception {
		tblTenderSavingDao.addTblTenderSaving(tblTenderSaving);
	}
	
	
	/**
	 * @author vivek.rajyaguru
	 * @param tenderId
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> calculateAndGetTenderSavingDtlsItemWiseCase(int tenderId)throws Exception {
		StringBuilder query = new StringBuilder();
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("tenderId", tenderId);
		query.append(" select ISNULL(sum(convert(decimal(38,5),cellValue)),0) as totalAmt,ISNULL(sum(convert(decimal(38,5),sorCellValue)),0)  as estimatedAmt,ISNULL(sum(convert(decimal(38,5),CASE WHEN biddingVariant=1 THEN  convert(decimal(38,5),sorCellValue)- convert(decimal(38,5),cellValue) ELSE  convert(decimal(38,5),cellValue)- convert(decimal(38,5),sorCellValue) END)),0)  as savingGainAmt from  ");
		query.append(" (select distinct TT.tenderId,DRCC.cellValue,TSR.cellValue as sorCellValue,DRCC.tableId,DRCC.rowId,TT.biddingVariant ");
		query.append(" from  apptender.tbl_Tender TT  ");
		query.append(" INNER JOIN apptenderresult.tbl_DynReport DR ON DR.tenderId=TT.tenderId and TT.tenderId=:tenderId ");
		query.append(" INNER JOIN apptenderresult.tbl_DynReportColumn DRC ON DR.reportId=DRC.reportId and DR.reportOn=2 and DR.reportType=2 and DRC.isGovcolumn=1 and DR.tenderId=TT.tenderId ");
		query.append(" INNER JOIN apptenderresult.tbl_DynReportCell DRCC ON DRC.columnId = DRCC.columnId and ISNUMERIC(appcommon.F_GetNumeric(DRCC.cellValue)) = 1 ");
		query.append(" INNER JOIN (select DRCC1.companyId,DRCC1.tableId,DRCC1.rowId,DRCC1.reportId from apptenderresult.tbl_DynReport DR1 ");
		query.append(" INNER JOIN apptenderresult.tbl_DynReportColumn DRC1 ON DR1.reportId=DRC1.reportId and DR1.reportOn=2 and DR1.reportType=2 and DRC1.filledBy=3 and DR1.tenderId=:tenderId ");
		query.append(" INNER JOIN apptenderresult.tbl_DynReportCell DRCC1 ON DRC1.columnId=DRCC1.columnId and DRC1.reportId=DRCC1.reportId and ISNUMERIC(appcommon.F_GetNumeric(DRCC1.cellValue)) = 1 AND DRCC1.cellValue = '1' ) as l1detail ");
		query.append(" ON  DRCC.tableId=l1detail.tableId and DRCC.rowId=l1detail.rowId and DRCC.reportId=l1detail.reportId and DRCC.companyId=l1detail.companyId ");
		query.append(" INNER JOIN apptender.tbl_TenderGovColumn TGC ON TT.tenderId=TGC.tenderId and TGC.tenderId=:tenderId ");
		query.append(" INNER JOIN apptender.tbl_TenderForm TF ON TF.formId=TGC.formId and TF.cstatus=1  ");
		query.append(" INNER JOIN apptender.tbl_TenderColumn TC ON TF.formId=TC.formId  and TGC.columnId=TC.columnId and TGC.tableId=TC.tableId ");
		query.append(" INNER JOIN apptender.tbl_TenderCell TCC ON TCC.columnId=TGC.columnId and TCC.rowId=l1detail.rowId and DRCC.rowId=TCC.rowId and TCC.tableId=l1detail.tableId ");
		query.append(" LEFT JOIN apptender.tbl_TenderSOR TSR ON TCC.cellId=TSR.cellId ");
		query.append(" )finalData ");
		return hibernateQueryDao.createSQLQuery(query.toString(), var);
	}
	/**
     * author : anjali.c
     * get Manual L1 Report for edit/view when bidder name is encoded
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getOverRuledReportWithEncodedBidder(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" SELECT tbloverruledreportdetail.tblCompany.companyId,tblTenderBidConfirmation.encodedName,tbloverruledreportdetail.tblUserLogin.userId," +
        		"tbloverruledreportdetail.amount,tbloverruledreportdetail.remarks,tbloverruledreport.overRuledReportId ");
        query.append(" FROM TblOverRuledReport tbloverruledreport,TblTenderBidConfirmation tblTenderBidConfirmation ");
        query.append(" INNER JOIN tbloverruledreport.tblOverRuledReportDetail tbloverruledreportdetail ");
        query.append(" WHERE tbloverruledreport.tblTender.tenderId=:tenderId and tblTenderBidConfirmation.tblTender.tenderId=:tenderId ");
        query.append(" and tblTenderBidConfirmation.tblCompany.companyId=tbloverruledreportdetail.tblCompany.companyId ORDER BY tbloverruledreportdetail.amount");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    public List<Object[]> viewRegretedBidDetails(int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();
		 var.put("tenderId", tenderId);
		 var.put("regretType", 1);
		 String query="select  TC.companyName as c0,TBR.remarks as c1,T.cstatus as c2,TBR.createdOn as c3 from apptender.tbl_Tender T INNER JOIN apptenderbid.tbl_TenderBidRegression TBR ON T.tenderId=TBR.tenderId INNER JOIN appuser.tbl_Company TC ON TBR.companyId=TC.companyId where T.tenderId=:tenderId and regretType=:regretType";
		 int nVarCharColumnIndex [] = {0,1,3};
         return hibernateQueryDao.createSQLQuery(query.toString(), var, nVarCharColumnIndex, 4); 
	}   
	
}
