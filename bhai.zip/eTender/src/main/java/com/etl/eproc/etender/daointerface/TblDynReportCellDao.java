/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblDynReportCell;
import java.util.List;

/**
 *
 * @author shreyansh.shah
 */
public interface TblDynReportCellDao  {

    public void addTblDynReportCell(TblDynReportCell tblDynReportCell);

    public void deleteTblDynReportCell(TblDynReportCell tblDynReportCell);

    public void updateTblDynReportCell(TblDynReportCell tblDynReportCell);

    public List<TblDynReportCell> getAllTblDynReportCell();

    public List<TblDynReportCell> findTblDynReportCell(Object... values) throws Exception;

    public List<TblDynReportCell> findByCountTblDynReportCell(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynReportCellCount();

    public void saveUpdateAllTblDynReportCell(List<TblDynReportCell> tblDynReportCells);
}
