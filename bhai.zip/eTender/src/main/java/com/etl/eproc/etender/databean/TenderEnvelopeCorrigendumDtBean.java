package com.etl.eproc.etender.databean;

/**
 * @author urja
 */
public class TenderEnvelopeCorrigendumDtBean {

    private String envelopeName;
    private String action;

    public String getEnvelopeName() {
        return envelopeName;
    }

    public void setEnvelopeName(String envelopeName) {
        this.envelopeName = envelopeName;
    }

   
    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
}