package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TblShareReport;

public interface TblShareReportDao  {

    public void addTblShareReport(TblShareReport tblShareReport);

    public void deleteTblShareReport(TblShareReport tblShareReport);

    public void updateTblShareReport(TblShareReport tblShareReport);

    public List<TblShareReport> getAllTblShareReport();

    public List<TblShareReport> findTblShareReport(Object... values) throws Exception;

    public List<TblShareReport> findByCountTblShareReport(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblShareReportCount();

    public void saveUpdateAllTblShareReport(List<TblShareReport> tblShareReports);

	public void saveOrUpdateTblShareReport(TblShareReport tblShareReport);
}