/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author dipal
 */
@Component
public class SPSORReport extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderresult.P_SORReport";

    public SPSORReport() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_FormId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_TableId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_ColumnIds", Types.VARCHAR));        
        this.declareParameter(new SqlParameter("@V_Flag", Types.INTEGER)); 
        this.declareParameter(new SqlParameter("@V_ReportType", Types.INTEGER)); 
        this.declareParameter(new SqlParameter("@V_ColumnId", Types.INTEGER)); 
    }

    /**
     * Method use for call store procedure generate SOR Report
     * @param tenderId
     * @param formId
     * @param columnId
     * @param flag
     * @return {@code Map<String,Object>}
     * @throws Exception 
     */
    public Map<String,Object> executeProcedure(int tenderId, int formId,int tableId,String columnIds,int flag,int reportType,int columnId) throws Exception
    {
        Map inParams = new HashMap();
        /*System.out.println("tenderId = " + tenderId);
        System.out.println("formId = " + formId);
        System.out.println("tableId = " + tableId);
        System.out.println("flag = " + flag);
        System.out.println("reportType = " + reportType);
        System.out.println("columnId = " + columnId);*/
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_FormId", formId);
        inParams.put("@V_TableId", tableId);
        inParams.put("@V_ColumnIds", columnIds);
        inParams.put("@V_Flag", flag);
        inParams.put("@V_ReportType", reportType);
        inParams.put("@V_ColumnId", columnId);
        this.compile();

        return execute(inParams);
    }
}


