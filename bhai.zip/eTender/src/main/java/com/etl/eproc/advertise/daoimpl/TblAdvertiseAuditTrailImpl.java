package com.etl.eproc.advertise.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.advertise.model.TblAdvertiseAuditTrail;
import com.etl.eproc.advertise.daointerface.TblAdvertiseAuditTrailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblAdvertiseAuditTrailImpl extends AbcAbstractClass<TblAdvertiseAuditTrail> implements TblAdvertiseAuditTrailDao {

    @Override
    public void addTblAdvertiseAuditTrail(TblAdvertiseAuditTrail tblAdvertiseAuditTrail){
        super.addEntity(tblAdvertiseAuditTrail);
    }

    @Override
    public void deleteTblAdvertiseAuditTrail(TblAdvertiseAuditTrail tblAdvertiseAuditTrail) {
        super.deleteEntity(tblAdvertiseAuditTrail);
    }

    @Override
    public void updateTblAdvertiseAuditTrail(TblAdvertiseAuditTrail tblAdvertiseAuditTrail) {
        super.updateEntity(tblAdvertiseAuditTrail);
    }

    @Override
    public List<TblAdvertiseAuditTrail> getAllTblAdvertiseAuditTrail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAdvertiseAuditTrail> findTblAdvertiseAuditTrail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAdvertiseAuditTrailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAdvertiseAuditTrail> findByCountTblAdvertiseAuditTrail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAdvertiseAuditTrail(List<TblAdvertiseAuditTrail> tblAdvertiseAuditTrails){
        super.updateAll(tblAdvertiseAuditTrails);
    }
}
