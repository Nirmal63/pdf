package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblCancelRequest;
import java.util.List;

public interface TblCancelRequestDao  {

    public void addTblCancelRequest(TblCancelRequest tblCancelRequest);

    public void deleteTblCancelRequest(TblCancelRequest tblCancelRequest);

    public void updateTblCancelRequest(TblCancelRequest tblCancelRequest);

    public List<TblCancelRequest> getAllTblCancelRequest();

    public List<TblCancelRequest> findTblCancelRequest(Object... values) throws Exception;

    public List<TblCancelRequest> findByCountTblCancelRequest(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCancelRequestCount();

    public void saveUpdateAllTblCancelRequest(List<TblCancelRequest> tblCancelRequests);
}