/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author Janak Dhanani
 */
@Component
public class SPWeightatgeL1Report extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderresult.P_WeightageL1Report";

    public SPWeightatgeL1Report() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_UserRoleId", Types.INTEGER));
    }

    /**
     * Method use for call store procedure generate Weightage L1 Report
     * @param tenderId
     * @param userRoleId 
     * @return {@code Map<String,Object>}
     * @throws Exception 
     */
    public Map<String,Object> executeProcedure(int tenderId, int userRoleId) throws Exception
    {
        Map inParams = new HashMap();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_UserRoleId", userRoleId);
        this.compile();
        return execute(inParams);
    }
}


