/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author Nirav Modi
 * @param @V_Tab : 1 for opening tab , 2 for Evaluation tab, 3 for Result tab
 */
@Component
public class SPTenderOpening extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderresult.P_TenderOpening";

    public SPTenderOpening() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_Tab", Types.TINYINT));
    }


    /**
     * Use case : Tender Opening / Evaluation Process
     * @author nirav.modi
     * @param tenderId
     * @param tabId
     * @return Map{@code<String,Object>}
     * @throws Exception
     */
    public Map<String,Object> executeProcedure(int tenderId,int tab) throws Exception
    {
        Map inParams = new HashMap();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_Tab", tab);
        this.compile();
        return execute(inParams);
    }
}
