/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.controller;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.advertise.model.TblAdvertise;
import com.etl.eproc.advertise.model.TblAdvertiseDetail;
import com.etl.eproc.advertise.model.TblAdvertiseTenderMap;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblOfficerDocMapping;
import com.etl.eproc.common.model.TblOfficerDocument;
import com.etl.eproc.common.model.TblProcess;
import com.etl.eproc.advertise.services.AuditTrailService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.services.WorkflowService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.model.TblCorrigendum;
import com.etl.eproc.etender.model.TblCorrigendumDetail;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.services.AdvertiseService;
import com.etl.eproc.etender.services.TenderCommonService;

/**
 *
 * @author hiral
 */
@Controller
@RequestMapping("/advertise")
public class AdvertiseController {
    @Autowired 
    private AdvertiseService advertiseService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private CommonService commonService;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private WorkflowService workflowService;
    @Autowired
    private FileUploadService fileUploadService;
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    @Value("#{advertiseAuditTrailProperties['get_create_advertise']}")
    private String getCreateAdvertise;
    @Value("#{advertiseAuditTrailProperties['get_create_advertise_extention']}")
    private String getCreateAdvertiseExtention;
    @Value("#{advertiseAuditTrailProperties['get_edit_advertise']}")
    private String getEditAdvertise;
    @Value("#{advertiseAuditTrailProperties['get_edit_advertise_extention']}")
    private String getEditAdvertiseExtention;
    @Value("#{advertiseAuditTrailProperties['post_create_advertise']}")
    private String postCreateAdvertise;
    @Value("#{advertiseAuditTrailProperties['post_create_extention_advertise']}")
    private String postCreateExtentionAdvertise;
    @Value("#{advertiseAuditTrailProperties['post_edit_advertise']}")
    private String postEditAdvertise;
    @Value("#{advertiseAuditTrailProperties['post_edit_extention_advertise']}")
    private String postEditExtentionAdvertise;
    @Value("#{advertiselinkProperties['report_create_advertise']?:90}")
    private int createAdvertiseReportId;
    @Value("#{advertiselinkProperties['report_create_advertise_extention']?:91}")
    private int createAdvertiseExtentionReportId;
    @Value("#{advertiseAuditTrailProperties['getpublishadvertise']}")
    private String getPublishAdvertise;
    @Value("#{advertiseAuditTrailProperties['postpublishadvertise']}")
    private String postPublishAdvertise;
    @Value("#{advertiseAuditTrailProperties['postpublishextendsionadvertise']}")
    private String postPublishExtensionAdvertise;
    
    @Value("#{tenderlinkProperties['manage_avdevrtise_reportId']?:92}")
    private int manageAdvertiseReportId;
    @Value("#{etenderProperties['fld_doc_end_date']?:documentEndDate}")
    private String FieldDocEndDate;
    @Value("#{etenderProperties['fld_sub_end_date']?:submissionEndDate}")
    private String FieldSubmissionEndDate;
    @Value("#{etenderProperties['fld_bid_open_date']?:openingDate}")
    private String FieldOpeningDate;
    @Value("#{etenderProperties['fld_lbl_doc_end_date']}")
    private String FieldLBLDocEndDate;
    @Value("#{etenderProperties['fld_lbl_sub_end_date']}")
    private String FieldLBLSubmissionEndDate;
    @Value("#{etenderProperties['fld_lbl_bid_open_date']}")
    private String FieldLBLBidOpeningDate;
    @Value("#{advertiselinkProperties['upload_document']?:2287}")
    private int uploadDocLinkId;
    @Value("#{advertiselinkProperties['advertise_document']?:247}")
    private int uploadDocEventId;
    @Value("#{projectProperties['doc_upload_path']}")
	private String docUploadPath;
    @Value("#{tenderlinkProperties['notice_and_document_upload']?:175}")
    private int noticeAndDocumentUpload;
   
    
    

    /*
     * author : heeral.soni
     * used to create advertise
     */
    @RequestMapping(value = "buyer/createadvertise/{flagTemp}/{enc}", method = RequestMethod.GET)
    public String createAdvertise(ModelMap modelMap,@PathVariable("flagTemp") int flag, HttpServletRequest request) {
        try {
            modelMap.addAttribute("advertiseType", advertiseService.getAdvertiseType());
            modelMap.addAttribute("reportId", flag==0?createAdvertiseReportId:createAdvertiseExtentionReportId);
            reportGeneratorService.getReportConfigDetails(flag==0?createAdvertiseReportId:createAdvertiseExtentionReportId, modelMap);
            
          //Code for doc Upload
            //Nikhil Jani CR :24795
            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(uploadDocEventId, abcUtility.getSessionClientId(request));
		    int allowedSize = 0;
		    StringBuilder allowedExt = new StringBuilder();
		    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
		            allowedSize = lstDocUploadConf.get(0).getMaxSize();
		            allowedExt.append(lstDocUploadConf.get(0).getType());
		            modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
		    }
		    int index = allowedExt.toString().indexOf(",");
		    allowedExt.insert(index + 1, "*.");
		    while (index >= 0) {
		            index = allowedExt.toString().indexOf(",", index + ",".length());
		            allowedExt.insert(index + 1, "*.");
		    }
		
		    modelMap.addAttribute("allowedExt", allowedExt);
		    modelMap.addAttribute("allowedSize", allowedSize/1024);
		    modelMap.addAttribute("linkId",uploadDocLinkId);
		  //  modelMap.addAttribute(OBJECTID, objectId);    		    
		    modelMap.addAttribute("cStatusDoc", 0);    		    
            modelMap.addAttribute("allowFileExist","Y");
            
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, flag==0?getCreateAdvertise:getCreateAdvertiseExtention, 0, 0);
        }
        return "/advertise/CreateAdvertise";
    }
    /*
     * author : heeral.soni
     * used to create/edit advertise/extntion
     */
    @RequestMapping(value = "buyer/editadvertise/{advertiseId}/{flagTemp}/{enc}", method = RequestMethod.GET)
    public String editAdvertise(ModelMap modelMap,@PathVariable("advertiseId") int advertiseId,@PathVariable("flagTemp") int flag, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", flag==0?createAdvertiseReportId:createAdvertiseExtentionReportId);
            reportGeneratorService.getReportConfigDetails(flag==0?createAdvertiseReportId:createAdvertiseExtentionReportId, modelMap);
            modelMap.addAttribute("advertiseTenderMapList", advertiseService.getAdvertiseTenderMapDetails(advertiseId));
            modelMap.addAttribute("opType", flag==0?"edit":"editExtent");
            modelMap.addAttribute("advertiseType", advertiseService.getAdvertiseType());
            TblAdvertise tblAdvertise = advertiseService.getAdvertiseDetailId(advertiseId);
            modelMap.addAttribute("tblAdvertise", tblAdvertise);
            modelMap.addAttribute("corrigendumText", tblAdvertise.getCorrigendumText());
            
           //Nikhil Jani for Document Upload 
            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(uploadDocEventId, abcUtility.getSessionClientId(request));
		    int allowedSize = 0;
		    StringBuilder allowedExt = new StringBuilder();
		    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
		            allowedSize = lstDocUploadConf.get(0).getMaxSize();
		            allowedExt.append(lstDocUploadConf.get(0).getType());
		            modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
		    }
		    int index = allowedExt.toString().indexOf(",");
		    allowedExt.insert(index + 1, "*.");
		    while (index >= 0) {
		            index = allowedExt.toString().indexOf(",", index + ",".length());
		            allowedExt.insert(index + 1, "*.");
		    }
		
		    modelMap.addAttribute("allowedExt", allowedExt);
		    modelMap.addAttribute("allowedSize", allowedSize/1024);
		    modelMap.addAttribute("linkId",uploadDocLinkId);
		    modelMap.addAttribute("objectId", advertiseId);    		    
		    modelMap.addAttribute("cStatusDoc", 0);    		    
            modelMap.addAttribute("allowFileExist","Y");
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally { 
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, flag==0?getEditAdvertise:getEditAdvertiseExtention, advertiseId, 0);
        }
        return "/advertise/CreateAdvertise";
    }
    
    /*
     * author : heeral.soni
     * used to save advertise/extntion
     */
    @RequestMapping(value = "buyer/saveadvertise", method = RequestMethod.POST)
    public String saveAdvertise(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
        String retVal = REDIRECT_SESSION_EXPIRED;
        //Added by Nikhil jani BUG ID : 29520
       // int flag=1;
        int flag = StringUtils.hasLength(request.getParameter("hdFlagTemp")) ? Integer.parseInt(request.getParameter("hdFlagTemp")) : 0;
        /*String flg=request.getParameter("hdFlag"); 
        if(flg.equals("true"))
        {
        	flag=0;
        }*/
        //Ends here
        int advertiseId = StringUtils.hasLength(request.getParameter("hdAdvertiseId")) ? Integer.parseInt(request.getParameter("hdAdvertiseId")) : 0;
        String advertiseExtended = StringUtils.hasLength(request.getParameter("hdIsAdvertiseExtended")) ? request.getParameter("hdIsAdvertiseExtended") : "false";
        SessionBean sessionBean = request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
        try {
            if (sessionBean != null) {
            	boolean isInserted = false;
                int clientId = abcUtility.getSessionClientId(request);
                String advertiseNo = StringUtils.hasLength(request.getParameter("hdAdvertiseNo")) ? request.getParameter("hdAdvertiseNo") : "";
                String docstartDate=request.getParameter("txtDocumentStartDate");
                String docendDate=request.getParameter("txtDocumentEndDate");
                String submissionstartDate = request.getParameter("txtSubmissionStartDate");
                String submissionendDate=request.getParameter("txtSubmissionEndDate");
                String openingDate=request.getParameter("txtOpeningDate");
                String tenderIds[] = request.getParameterValues("hdSelectedTender");
                String officerDocIds = request.getParameter("txtHidDocIds");
                
                //set data for advertise
                TblAdvertise tblAdvertise = new TblAdvertise();
                if(advertiseId!=0){
                    tblAdvertise.setAdvertiseId(advertiseId);
                    tblAdvertise.setUpdatedBy(abcUtility.getSessionUserDetailId(request));
                }
                if(advertiseId==0){
                    tblAdvertise.setAdvertiseNo(" ");//update it latter
                }else{
                    tblAdvertise.setAdvertiseNo(advertiseNo);
                }
                tblAdvertise.setAdvertiseType(StringUtils.hasLength(request.getParameter("selAdvertiseType")) ? Integer.parseInt(request.getParameter("selAdvertiseType")) : 0);
                if(flag==0){
                    tblAdvertise.setCorrigendumText(" ");
                    String startDate=request.getParameter("txtDocumentStartDate");
                   // String subStartDate=request.getParameter("txtSubmissionStartDate");
                    tblAdvertise.setDocumentStartDate(conversionService.convert(startDate, Date.class));
                    //tblAdvertise.setSubmissionStartDate(conversionService.convert(subStartDate, Date.class));
                }else{
                    tblAdvertise.setCorrigendumText(request.getParameter("txtaCorrigendumText"));
                }
                tblAdvertise.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                tblAdvertise.setCstatus(0);
                tblAdvertise.setDocumentStartDate(conversionService.convert(docstartDate,Date.class));
                tblAdvertise.setDocumentEndDate(conversionService.convert(docendDate, Date.class));
                tblAdvertise.setSubmissionStartDate(conversionService.convert(submissionstartDate, Date.class));
                tblAdvertise.setSubmissionEndDate(conversionService.convert(submissionendDate, Date.class));
                tblAdvertise.setOpeningDate(conversionService.convert(openingDate, Date.class));
                tblAdvertise.setIsExtended(flag==0?0:1);
                tblAdvertise.setUpdatedOn(commonService.getServerDateTime());
                tblAdvertise.setTblClient(new TblClient(clientId));
               
                
                // set data for advertiseTenderMap
                if(tenderIds!=null){
                    List<TblAdvertiseTenderMap> tblAdvertiseTenderMaps = new ArrayList<TblAdvertiseTenderMap>();
                    for (int i = 0; i < tenderIds.length; i++) {
                        TblAdvertiseTenderMap tblAdvertiseTenderMap = new TblAdvertiseTenderMap();
                        if(advertiseId!=0){
                            tblAdvertiseTenderMap.setTblAdvertise(new TblAdvertise(advertiseId));
                        }else{
                            tblAdvertiseTenderMap.setTblAdvertise(tblAdvertise);
                        }
                        tblAdvertiseTenderMap.setTblTender(new TblTender(Integer.parseInt(tenderIds[i].toString())));
                        tblAdvertiseTenderMaps.add(tblAdvertiseTenderMap);
                    }
                    isInserted = advertiseService.addAdvertise(tblAdvertise, tblAdvertiseTenderMaps,advertiseId);
                    if(isInserted && officerDocIds.length()>0){
                    	String [] officerDocsIds=officerDocIds.split(",");
                    	Object []officerDocMappingId = new Object[officerDocsIds.length];
                    	int cnt=0;
                    	for (Object object : officerDocsIds) {
                    		officerDocMappingId[cnt]=Integer.parseInt(object.toString());
                    		cnt++;
						}
                    	advertiseService.updateOfficerDocMappingobjectId(officerDocMappingId,tblAdvertise.getAdvertiseId(),uploadDocLinkId);
                    }
         			}
                if(isInserted){
                    if(flag==0 && advertiseId==0){
                        redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? "msg_advertise_success" : CommonKeywords.ERROR_MSG_KEY.toString());    
                    }else if(flag==0 && advertiseId!=0){
                        redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? "msg_advertise_update_success" : CommonKeywords.ERROR_MSG_KEY.toString());
                    }else if("true".equalsIgnoreCase(advertiseExtended)){
                        redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? "msg_advertiseExtent_update_success" : CommonKeywords.ERROR_MSG_KEY.toString());
                    }else{
                        redirectAttributes.addFlashAttribute(isInserted ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isInserted ? "msg_advertiseExtent_success" : CommonKeywords.ERROR_MSG_KEY.toString());
                    }
                }else{
                    redirectAttributes.addFlashAttribute("errorMsg", CommonKeywords.ERROR_MSG_KEY.toString());
                }    
                retVal="redirect:/advertise/buyer/manageadvertise"+ encryptDecryptUtils.generateRedirect("advertise/buyer/manageadvertise", request);
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            if(flag==0 && advertiseId==0){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postCreateAdvertise, advertiseId, 0);
            }else if(flag==0 && advertiseId!=0){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postEditAdvertise, advertiseId, 0);
            }else if("true".equalsIgnoreCase(advertiseExtended)){
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postEditExtentionAdvertise, advertiseId, 0);
            }else{
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postCreateExtentionAdvertise, advertiseId, 0);
            }
        }
        return retVal;
    }

    /** Get controller for the publish advertise.
     * @author mitesh
     * @param modelMap
     * @param advertiseId
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/getpublishadvertise/{advertiseId}/{enc}", method = RequestMethod.GET)
    public String getPublishAdvertise(ModelMap modelMap,@PathVariable("advertiseId") int advertiseId, HttpServletRequest request) {
        try {
        	TblAdvertise advertise=advertiseService.getAdvertiseDetailId(advertiseId);
        	modelMap.addAttribute("advertiseObj", advertise);
        } catch (Exception e) {
        	exceptionHandlerService.writeLog(e);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getPublishAdvertise, advertiseId, 0);
        }
        return "/advertise/PublishAdvertise";
    }
    
    /** Post Controller for the publish advertise.
     * @author mitesh
     * @param response
     * @param request
     * @param modelMap
     * @return
     * @throws ParseException 
     */
    @RequestMapping(value = "/buyer/publishadvertise", method = RequestMethod.POST)
    public String publishAdvertise(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap,RedirectAttributes redirectAttributes) throws ParseException {
    	String retVal=REDIRECT_SESSION_EXPIRED;
    	List<Object[]> commonData;
    	String documentEndDate,submissionEndDate,openingDate,/*Bug id 30057 Nikhil Jani*/submissionStartDate=null,documentStartDate = null;
    	int userDetailId = abcUtility.getSessionUserDetailId(request);
    	int publishedBy=abcUtility.getSessionUserDetailId(request);
    	/*Date publishedOn = null;*/
    	int advertiseId = 0;
    	boolean result=false;
    	int isExtended=0;
    	int clientId=abcUtility.getSessionClientId(request);
    	 SessionBean sessionBean = request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
    	try {
    		if (sessionBean != null) {
	    		isExtended = StringUtils.hasLength(request.getParameter("hdIsExtended")) ? Integer.parseInt(request.getParameter("hdIsExtended")) : 0;
	    		advertiseId = StringUtils.hasLength(request.getParameter("hdAdvertiseId")) ? Integer.parseInt(request.getParameter("hdAdvertiseId")) : 0;
	    		String paperName[]=request.getParameterValues("txtAdvertPaperName");
	    		String advertiseNo[]=request.getParameterValues("txtAdvertNo");
	    		String advertiseDate[]=request.getParameterValues("txtAdvertDate");
	    		//Date createdOn=commonService.getServerDateTime();    		
	    		List<TblAdvertiseDetail> listAdvDetails=new ArrayList<TblAdvertiseDetail>();
	    		if(paperName!=null && paperName.length>0){
	    			for(int i=0;i<paperName.length;i++){
	    				TblAdvertiseDetail advertiseDetail = new TblAdvertiseDetail();  				
		    			advertiseDetail.setTblAdvertise(new TblAdvertise(advertiseId));
		    			advertiseDetail.setPaperName(paperName[i]);
		    			advertiseDetail.setAdvertiseNo(advertiseNo[i]);
		    			advertiseDetail.setAdvertiseDate(new SimpleDateFormat(WebUtils.getCookie(request, "dateFormat").getValue().replace("D", "d").replace("Y", "y")).parse(advertiseDate[i]));
		    			advertiseDetail.setCreatedBy(userDetailId);
		    			//advertiseDetail.setCreatedOn(createdOn);
		    			listAdvDetails.add(advertiseDetail);
	    			}
	    		}
	    		
	    		commonData=advertiseService.getAdvertiseDates(advertiseId);
	    		Object[] tenderIds=new Object[commonData.size()];
	    		if(commonData!=null && commonData.size()>0)
	    		{
	    				int i=0;
	    				for (Object[] object : commonData) {
	    					tenderIds[i++]=object[0];
						}
	    				
	    				documentEndDate=commonData.get(0)[2].toString();
	    				submissionEndDate=commonData.get(0)[3].toString();
	    				openingDate=commonData.get(0)[4].toString();
	    	/*Bug id 30057 Nikhil Jani*/
	    				
	    				List<TblCorrigendum> listTblCorrigendum=null;
	    				List<TblCorrigendumDetail> corrigendumDetailsList=null;
	    				if(isExtended==1){
	    					listTblCorrigendum = new ArrayList<TblCorrigendum>();
	    					corrigendumDetailsList = new ArrayList<TblCorrigendumDetail>();
		    				//take the tender date for the old date
		    				List<Object[]> tenderDetails=advertiseService.getTenderDates(tenderIds);
		    				Map<Integer, Object[]> tenderDetailsSet=new HashMap<Integer, Object[]>();
		    				if(tenderDetails!=null){
		    					for (Object[] tenderData : tenderDetails) {
		    						Object arrayTemp[]=new Object[4];
		    						arrayTemp[0]=tenderData[1]; //documentEndDate
		    						arrayTemp[1]=tenderData[2]; //submissionEndDate
		    						arrayTemp[2]=tenderData[3]; //openingDate
		    						/*Bug id 30057 Nikhil Jani*/arrayTemp[3]=tenderData[4]; //submissionStartDate
		    						tenderDetailsSet.put(Integer.parseInt(tenderData[0].toString()),arrayTemp);
								}
		    				}
		    				TblCorrigendum corrigendum=null;//create the corrigendum object
		    				for(i=0;i<tenderIds.length;i++)
		    				{
		    					corrigendum=new TblCorrigendum();
		    					corrigendum.setTblProcess(new TblProcess(1));
		    					corrigendum.setObjectId(Integer.parseInt(tenderIds[i].toString()));
		    					corrigendum.setCorrigendumText(commonData.get(0)[5].toString());
		    					corrigendum.setRemarks("");
		    					corrigendum.setPublishedBy(0);
	//	    					corrigendum.setCreatedOn(createdOn);
		    					corrigendum.setCreatedBy(userDetailId);
		    					corrigendum.setCstatus(0);
		    					listTblCorrigendum.add(corrigendum);	    					    			
		    				
								for(int j=0;j<3;j++){
									TblCorrigendumDetail  corrigendumDetails=new TblCorrigendumDetail();
									corrigendumDetails.setTblCorrigendum(corrigendum);
									corrigendumDetails.setTblProcess(new TblProcess(1));
									corrigendumDetails.setObjectId(corrigendum.getObjectId());
									corrigendumDetails.setActionType(2);
	//								corrigendumDetails.setCreatedOn(createdOn);
									corrigendumDetails.setCreatedBy(userDetailId);
									switch (j) {
									case 0:
										if(tenderDetailsSet.get(corrigendum.getObjectId())[0]!=null){
											corrigendumDetails.setFieldName(FieldDocEndDate);
											corrigendumDetails.setFieldLabel(FieldLBLDocEndDate);
											corrigendumDetails.setOldValue(tenderDetailsSet.get(corrigendum.getObjectId())[0].toString());
											corrigendumDetails.setNewValue(documentEndDate);
											corrigendumDetailsList.add(corrigendumDetails);	
										}
										break;
									case 1:
										if(tenderDetailsSet.get(corrigendum.getObjectId())[1]!=null){
											corrigendumDetails.setFieldName(FieldSubmissionEndDate);
											corrigendumDetails.setFieldLabel(FieldLBLSubmissionEndDate);
											corrigendumDetails.setOldValue(tenderDetailsSet.get(corrigendum.getObjectId())[1].toString());
											corrigendumDetails.setNewValue(submissionEndDate);
											corrigendumDetailsList.add(corrigendumDetails);	
										}
										break;
									case 2:
										if(tenderDetailsSet.get(corrigendum.getObjectId())[2]!=null){
											corrigendumDetails.setFieldName(FieldOpeningDate);
											corrigendumDetails.setFieldLabel(FieldLBLBidOpeningDate);
											corrigendumDetails.setOldValue(tenderDetailsSet.get(corrigendum.getObjectId())[2].toString());
											corrigendumDetails.setNewValue(openingDate);
											corrigendumDetailsList.add(corrigendumDetails);	
										}
										break;
									}
								}
							}
	    				}
	    				else{
	    					documentStartDate=commonData.get(0)[1].toString();
	    					submissionStartDate=commonData.get(0)[6].toString();
	    				}
	    				result=advertiseService.publishAdvertise(advertiseId, tenderIds, documentStartDate, documentEndDate, submissionStartDate, submissionEndDate, openingDate, isExtended,listAdvDetails,listTblCorrigendum,corrigendumDetailsList,publishedBy);
	    				advertiseService.updateDocStatus(advertiseId, uploadDocLinkId);
	    				this.copyDocumentAdvertiseToNIT(advertiseId,tenderIds,clientId,uploadDocLinkId,1);
	    				retVal="redirect:/advertise/buyer/manageadvertise"+ encryptDecryptUtils.generateRedirect("advertise/buyer/manageadvertise", request);
	    				if(isExtended==0){
	    					redirectAttributes.addFlashAttribute(result ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), result ? "msg_publish_advertise_success" : CommonKeywords.ERROR_MSG_KEY.toString());
	    				}
	    				else{
	    					redirectAttributes.addFlashAttribute(result ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), result ? "msg_publish_extension_advertise_success" : CommonKeywords.ERROR_MSG_KEY.toString());
	    				}
	    		}
	    		else{
	    			
	    			retVal="redirect:/advertise/buyer/getpublishadvertise/"+advertiseId+ encryptDecryptUtils.generateRedirect("advertise/buyer/getpublishadvertise/"+advertiseId, request);	
	    			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_map_tender_first");
    					
    					//redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_advertise_can_not_be_moved");
    				
	    		}
	    		
    		}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
    	finally{
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0,isExtended==0?postPublishAdvertise:postPublishExtensionAdvertise, advertiseId, 0);
    	}
    	return retVal;
    }
    
    /*
     * author : Dipika
     * used to view advertise
     * param : advertiseId
     */
    @RequestMapping(value = "/buyer/viewAdvertise/{advertiseId}/{enc}", method = RequestMethod.GET)
    public String viewAdvertise(ModelMap modelMap,@PathVariable("advertiseId") int advertiseId, HttpServletRequest request) {
        try {
        	getAdvertiseDetails(modelMap,advertiseId);
        	modelMap.addAttribute("objectIdNew", advertiseId);
			 modelMap.addAttribute("linkId", uploadDocLinkId);
			 int userTypeId=abcUtility.getSessionUserTypeId(request);
			    if(userTypeId == 2){
			    	modelMap.addAttribute("cStatusDoc", -2);
				    modelMap.addAttribute("cStatusDocView", -2);
			    }else{
				    modelMap.addAttribute("cStatusDoc", -1);
				    modelMap.addAttribute("cStatusDocView", -1);
			    }
			 modelMap.addAttribute("isReadOnly","Y");
			 modelMap.addAttribute("isTenderDocDownload", "Y");
        } catch (Exception e) {
            //exceptionHandlerService.writeLog(e);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEmdTenderWiseLinkId, getemddocdetail, tenderId, 0);
        }
        return "/advertise/ViewAdvertiseDetails";
    }
    
    /**
     * @author nirav.prajapati
     * @param response
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/viewadvertisetenderwise/{tenderId}/{enc}", method = RequestMethod.GET)
    public String viewAdvertisementTenderWise(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap,@PathVariable("tenderId")int tenderId) {
    	String pageName="advertise/ViewAdvertiseTenderWise";
    	List<Object[]> advertiseLst = null;
    	List<Object[]> advertiseDetailLst = null;
    	StringBuilder advertisementIds = new StringBuilder();
    	try {
    		advertiseLst = advertiseService.getAdvertiseByTender(tenderId);
    		if(advertiseLst != null && !advertiseLst.isEmpty())
    		{
    			for (int i = 0; i < advertiseLst.size(); i++) {
    				advertisementIds.append(advertiseLst.get(i)[0]);
    				if ( i != advertiseLst.size()-1){
    					advertisementIds.append(", ");
    				}
    			}
    			advertiseDetailLst = advertiseService.getAdvertiseByAdvertiseIds(advertisementIds.toString());
    			modelMap.put("advertiseDetailLst", advertiseDetailLst);
    		}
    		modelMap.put("advertiseLst", advertiseLst);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return pageName;
    }
    
    /**
     * @author SULABH
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/buyer/manageadvertise/{enc}", method = RequestMethod.GET)
    public String manageAdvertise(ModelMap modelMap, HttpServletRequest request) {
    	try {
			reportGeneratorService.getReportConfigDetails(manageAdvertiseReportId, modelMap);
			modelMap.addAttribute("reportId", manageAdvertiseReportId);
			/*System.out.println("kk: "+request.getParameter("RejectedAdvertisement"));
			modelMap.addAttribute("RejectedAdvertisement", request.getParameter("RejectedAdvertisement"));*/
			modelMap.addAttribute("clientId", abcUtility.getSessionClientId(request));
    	} catch (Exception e) {
    		exceptionHandlerService.writeLog(e);
		}
    	return "/advertise/ManageAdvertise";
    }
    /*
     * author : Lipi
     * used to view advertise report
     * param : advertiseId
     */
    @RequestMapping(value = "/buyer/advertiseDetailsReport/{advertiseId}/{enc}", method = RequestMethod.GET)
    public String advertiseDetailsReport(ModelMap modelMap,@PathVariable("advertiseId") int advertiseId, HttpServletRequest request) {
        try {
        	getAdvertiseDetails(modelMap,advertiseId);
        } catch (Exception e) {
            //exceptionHandlerService.writeLog(e);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createEmdTenderWiseLinkId, getemddocdetail, tenderId, 0);
        }
        return "/advertise/AdvertiseDetailsReport";
    }
    private void getAdvertiseDetails(ModelMap modelMap,int advertiseId) throws Exception{
    	modelMap.addAttribute("tblAdvertise",advertiseService.getAdvertiseDetailId(advertiseId));
    	modelMap.addAttribute("advertiseDetails",advertiseService.getAdvertiseDetails(advertiseId));
    	modelMap.addAttribute("lstAdvertiseTenderMap",advertiseService.getAdvertiseTenderMapDetails(advertiseId));
    		
    }

    
    /*author : Nikhil jani
     * Used when Advertisement is moving from Approved tab to Pending, It will check condition 
     * If tender is published or not and workflow is done or not 
     */
    @SuppressWarnings("null")
	@RequestMapping(value="/buyer/moveApproveToPending",method = RequestMethod.POST)
    public String moveAdvertisementToPending(ModelMap modelMap,HttpServletRequest request,RedirectAttributes redirectAttributes){
    	String retVal = "";
    	try{
    	 int cstatus=0;
    	 int isWorkflow=0;
    	 int result;
    	 int isWorkFlowStart=0;
    	 //String tenderIds[] = null;//request.getParameterValues("hdSelectedTender");
    	 String advertiseNos[] = request.getParameterValues("SelectedAdvertise");
    
    	 List<Object> advertiseNoList = new ArrayList<Object>();
    	 //For Bug 30027 Nikhil Jani
    	 List<Integer> advIdsList = new ArrayList<Integer>();
    	 //Ends Bug 30027
    	 for(int i=0;i<advertiseNos.length;i++)
    	 {
    		 advertiseNoList.add(advertiseNos[i]);
    	 }
    	 List<Object[]> tenderAdvertiseDetails = advertiseService.getAdvertiseTenderMap(advertiseNoList);
    	 List<Object[]> tenderDetails = new ArrayList<Object[]>();
    	 for(int i=0;i<tenderAdvertiseDetails.size() ; i++){
    		 tenderDetails = tenderCommonService.getTenderFields(Integer.parseInt(tenderAdvertiseDetails.get(i)[0].toString()), "cstatus,isWorkflowRequired");
	 		 cstatus = Integer.parseInt(tenderDetails.get(0)[0].toString());
	 		 isWorkflow = Integer.parseInt(tenderDetails.get(0)[1].toString());
	 		advIdsList.add(Integer.parseInt(tenderAdvertiseDetails.get(i)[10].toString()));
	 			if(isWorkflow==1){
	 				isWorkFlowStart=workflowService.isWorkFlowStartOrNot(Integer.parseInt(tenderAdvertiseDetails.get(i)[0].toString()),Integer.parseInt(tenderAdvertiseDetails.get(i)[0].toString()),196);
	 				//invalidAdvertisemenNo.append(tenderAdvertiseDetails.get(i)[9]);
	 				break;
	 			}
	 			if(cstatus==1){
	 				//invalidAdvertisemenNo.append(tenderAdvertiseDetails.get(i)[9]);
	 				break;
	 			}
	 	}
	   if(cstatus==0 && isWorkFlowStart!=1){
			
			result=this.advertiseOfficeDocUpdateAndDelete(advertiseNoList,advIdsList,tenderAdvertiseDetails,abcUtility.getSessionClientId(request));
			
			reportGeneratorService.getReportConfigDetails(manageAdvertiseReportId, modelMap);
			modelMap.addAttribute("reportId", manageAdvertiseReportId);
			modelMap.addAttribute("clientId", abcUtility.getSessionClientId(request));
			
			redirectAttributes.addFlashAttribute(result>0 ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString() , result>0 ? "msg_suc_move_to_pending" : CommonKeywords.ERROR_MSG_KEY.toString());
			retVal  ="redirect:/advertise/buyer/manageadvertise"+encryptDecryptUtils.generateRedirect("advertise/buyer/manageadvertise", request);
		} else{
			//modelMap.addAttribute("RejectedAdvertisement", invalidAdvertisemenNo);
        	 //redirectAttributes.addFlashAttribute("errorMsg", CommonKeywords.ERROR_MSG_KEY.toString());
        	 redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_advertise_can_not_be_moved");
        	 retVal  ="redirect:/advertise/buyer/manageadvertise"+encryptDecryptUtils.generateRedirect("advertise/buyer/manageadvertise", request);
        }
    }
    	catch (Exception e){
    		exceptionHandlerService.writeLog(e);
    	}
    	return retVal;
    }
    
    /**
     * @author vivek.rajyaguru
     * @param advertiseId
     * @param tenderIds
     * @param clientId
     * @param linkId
     * @throws Exception
     */
    private void copyDocumentAdvertiseToNIT(int advertiseId,Object[] tenderIds,int clientId,int linkId,int cstatus) throws Exception{
    	List<Object[]> list=advertiseService.getUploadedAdvertisementDocumentDetail(advertiseId, linkId, clientId,cstatus);
    	for (Object tenderId : tenderIds) {
	    	for (Object[] objects : list) {
	    		String path="\\"+clientId+"\\TenderId"+"\\"+tenderId.toString();
	    		
	             File sourceFile = new File(docUploadPath+objects[2].toString()+"\\"+objects[1].toString());
	             File targetFile = new File(docUploadPath+path+"\\"+objects[1].toString());
	             File tempDir=new File(docUploadPath+path);
	             if(!tempDir.exists()){
	               	 tempDir.mkdir();
	             }
	             if(!targetFile.exists()){
	            	 //copy file from one location to other
	            	 sourceFile = abcUtility.CheckDirExist(sourceFile);
	            	 if(sourceFile.exists()){
	            		 FileUtils.copyFile(sourceFile, targetFile);
	            	 }
	            	 TblOfficerDocument tblOfficerDocument = new TblOfficerDocument();
		        	 tblOfficerDocument.setDocName(objects[1].toString());
		             tblOfficerDocument.setTblClient(new TblClient(clientId));
		             tblOfficerDocument.setOfficerFolderId(Integer.parseInt(objects[0].toString()));
		             tblOfficerDocument.setPath(path);
		             tblOfficerDocument.setDescription(objects[3].toString());
		             tblOfficerDocument.setFileSize(Integer.parseInt(objects[4].toString()));
		             tblOfficerDocument.setCreatedBy(Integer.parseInt(objects[7].toString()));
		             tblOfficerDocument.setCstatus(Integer.parseInt(objects[6].toString()));
		             tblOfficerDocument.setIsEncryptionReq(Integer.parseInt(objects[5].toString()));
		             TblOfficerDocMapping tblOfficerDocMapping = new TblOfficerDocMapping();
		             tblOfficerDocMapping.setObjectId(Integer.parseInt(tenderId.toString()));
		             tblOfficerDocMapping.setTblLink(new TblLink(noticeAndDocumentUpload));
		             tblOfficerDocMapping.setMappedBy(Integer.parseInt(objects[7].toString()));
		             tblOfficerDocMapping.setCstatus(0);
		             tblOfficerDocMapping.setChildId(0);
		             fileUploadService.addOfficerDocument(tblOfficerDocument,tblOfficerDocMapping);
	    		}
	             
	             	
	        }
    	}
    	
    	
    }
    
    /**
     * @author vivek.rajyaguru
     * @param tenderAdvertiseDetails
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class) 
    private int advertiseOfficeDocUpdateAndDelete(List<Object> advertiseNoList,List<Integer> advIdsList,List<Object[]> tenderAdvertiseDetails,int clientId) throws Exception{
    	
    	int sucess=0;
    	sucess=advertiseService.updateAdvertise(advertiseNoList);
    	
    	//For Bug 30027 Nikhil Jani
    		advertiseService.updateDocStatusForMoveToPending(advIdsList, uploadDocLinkId); //Changes Bug Id#30574
		//Ends Bug 30027
    	
    	//For deleting entries from TblAdvertiseTenderMap & TblAdvertiseDetails
		if(sucess>0){
			advertiseService.deleteTblAdvertiseTenderMapWhileMoveToPending(advIdsList);
			advertiseService.deleteTblAdvertiseDetailsWhileMoveToPending(advIdsList);
		}
		//Ends here deleting entries from TblAdvertiseTenderMap & TblAdvertiseDetails
    	
    	
    	//Remove NIT Document Start
    	List<Object> officerDocIds=new ArrayList<Object>();
    	for (Object[] tenderAdvertiseDetail : tenderAdvertiseDetails) {
    		List<Object[]> list=advertiseService.getUploadedAdvertisementDocumentDetail(Integer.parseInt(tenderAdvertiseDetail[0].toString()), noticeAndDocumentUpload, clientId,0);
    		for (Object[] objects : list) {
    			File targetFile = new File(docUploadPath+objects[2].toString()+"\\"+objects[1].toString());
    			targetFile = abcUtility.CheckDirExist(targetFile);
    			if(targetFile.exists()){
    				targetFile.delete(); //Delete document 
    				officerDocIds.add(objects[8]);
    			}
        	}
    	}
    	
    	if(!officerDocIds.isEmpty() && officerDocIds.size()>0){
    		sucess=advertiseService.deleteOfficeDoc(officerDocIds.toArray(),clientId); //Delete officer document entry from TblOfficerDocument and TblOfficerDocMapping
    	}
    	
    	//Remove NIT Document End
    	
     return sucess;	
    }
    
}
