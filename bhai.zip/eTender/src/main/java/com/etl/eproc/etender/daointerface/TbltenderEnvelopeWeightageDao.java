/**
 * 
 */
package com.etl.eproc.etender.daointerface;

/**
 * @author janak
 *
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TbltenderEnvelopeWeightage;

public interface TbltenderEnvelopeWeightageDao  {

    public void addTbltenderEnvelopeWeightage(TbltenderEnvelopeWeightage tbltenderEnvelopeWeightage);

    public void deleteTbltenderEnvelopeWeightage(TbltenderEnvelopeWeightage tbltenderEnvelopeWeightage);

    public void updateTbltenderEnvelopeWeightage(TbltenderEnvelopeWeightage tbltenderEnvelopeWeightage);

    public List<TbltenderEnvelopeWeightage> getAllTbltenderEnvelopeWeightage();

    public List<TbltenderEnvelopeWeightage> findTbltenderEnvelopeWeightage(Object... values) throws Exception;

    public List<TbltenderEnvelopeWeightage> findByCountTbltenderEnvelopeWeightage(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTbltenderEnvelopeWeightageCount();

    public void saveUpdateAllTbltenderEnvelopeWeightage(List<TbltenderEnvelopeWeightage> tbltenderEnvelopeWeightages);
}