/**
 * 
 */
package com.etl.eproc.etender.daoimpl;

/**
 * @author janak
 *
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TbltenderEnvelopeWeightageDao;
import com.etl.eproc.etender.model.TbltenderEnvelopeWeightage;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TbltenderEnvelopeWeightageImpl extends AbcAbstractClass<TbltenderEnvelopeWeightage> implements TbltenderEnvelopeWeightageDao {

  
    @Override
    public void addTbltenderEnvelopeWeightage(TbltenderEnvelopeWeightage tbltenderEnvelopeWeightage){
        super.addEntity(tbltenderEnvelopeWeightage);
    }

    @Override
    public void deleteTbltenderEnvelopeWeightage(TbltenderEnvelopeWeightage tbltenderEnvelopeWeightage) {
        super.deleteEntity(tbltenderEnvelopeWeightage);
    }

    @Override
    public void updateTbltenderEnvelopeWeightage(TbltenderEnvelopeWeightage tbltenderEnvelopeWeightage) {
        super.updateEntity(tbltenderEnvelopeWeightage);
    }

    @Override
    public List<TbltenderEnvelopeWeightage> getAllTbltenderEnvelopeWeightage() {
        return super.getAllEntity();
    }

    @Override
    public List<TbltenderEnvelopeWeightage> findTbltenderEnvelopeWeightage(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTbltenderEnvelopeWeightageCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TbltenderEnvelopeWeightage> findByCountTbltenderEnvelopeWeightage(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTbltenderEnvelopeWeightage(List<TbltenderEnvelopeWeightage> tbltenderEnvelopeWeightages){
        super.updateAll(tbltenderEnvelopeWeightages);
    }
}
