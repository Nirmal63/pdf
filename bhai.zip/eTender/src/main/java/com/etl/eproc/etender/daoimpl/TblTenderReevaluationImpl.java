/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.etender.model.TblTenderReevaluation;
import com.etl.eproc.etender.daointerface.TblTenderReevaluationDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author mittal
 */
@Repository @Transactional
public class TblTenderReevaluationImpl extends AbcAbstractClass<TblTenderReevaluation> implements TblTenderReevaluationDao {


    @Override
    public void addTblTenderReevaluation(TblTenderReevaluation tblTenderReevaluation){
        super.addEntity(tblTenderReevaluation);
    }

    @Override
    public void deleteTblTenderReevaluation(TblTenderReevaluation tblTenderReevaluation) {
        super.deleteEntity(tblTenderReevaluation);
    }

    @Override
    public void updateTblTenderReevaluation(TblTenderReevaluation tblTenderReevaluation) {
        super.updateEntity(tblTenderReevaluation);
    }

    @Override
    public List<TblTenderReevaluation> getAllTblTenderReevaluation() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderReevaluation> findTblTenderReevaluation(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderReevaluationCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderReevaluation> findByCountTblTenderReevaluation(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderReevaluation(List<TblTenderReevaluation> tblTenderReevaluations){
        super.updateAll(tblTenderReevaluations);
    }
}

