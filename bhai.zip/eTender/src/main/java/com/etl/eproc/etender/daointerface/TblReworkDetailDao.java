package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TblReworkDetail;

public interface TblReworkDetailDao  {

    public void addTblReworkDetail(TblReworkDetail tblReworkDetail);

    public void deleteTblReworkDetail(TblReworkDetail tblReworkDetail);

    public void updateTblReworkDetail(TblReworkDetail tblReworkDetail);

    public List<TblReworkDetail> getAllTblReworkDetail();

    public List<TblReworkDetail> findTblReworkDetail(Object... values) throws Exception;

    public List<TblReworkDetail> findByCountTblReworkDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblReworkDetailCount();

    public void saveUpdateAllTblReworkDetail(List<TblReworkDetail> tblReworkDetails);
}