package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblBidDetailDao;
import com.etl.eproc.etender.model.TblBidDetail;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblBidDetailImpl extends AbcAbstractClass<TblBidDetail> implements TblBidDetailDao {

    

    @Override
    public void addTblBidDetail(TblBidDetail tblBidDetail){
        super.addEntity(tblBidDetail);
    }

    @Override
    public void deleteTblBidDetail(TblBidDetail tblBidDetail) {
        super.deleteEntity(tblBidDetail);
    }

    @Override
    public void updateTblBidDetail(TblBidDetail tblBidDetail) {
        super.updateEntity(tblBidDetail);
    }

    @Override
    public List<TblBidDetail> getAllTblBidDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBidDetail> findTblBidDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBidDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBidDetail> findByCountTblBidDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBidDetail(List<TblBidDetail> tblBidDetails){
        super.updateAll(tblBidDetails);
    }
}
