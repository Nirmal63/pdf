package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblDynReportFormMap;
import java.util.List;

public interface TblDynReportFormMapDao  {

    public void addTblDynReportFormMap(TblDynReportFormMap tblDynReportFormMap);

    public void deleteTblDynReportFormMap(TblDynReportFormMap tblDynReportFormMap);

    public void updateTblDynReportFormMap(TblDynReportFormMap tblDynReportFormMap);

    public List<TblDynReportFormMap> getAllTblDynReportFormMap();

    public List<TblDynReportFormMap> findTblDynReportFormMap(Object... values) throws Exception;

    public List<TblDynReportFormMap> findByCountTblDynReportFormMap(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynReportFormMapCount();

    public void saveUpdateAllTblDynReportFormMap(List<TblDynReportFormMap> tblDynReportFormMaps);
}