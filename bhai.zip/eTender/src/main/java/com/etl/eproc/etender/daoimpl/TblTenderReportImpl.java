package com.etl.eproc.etender.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderReportDao;
import com.etl.eproc.etender.model.TblTenderReport;

/**
*
* @author Nihar
*/
@Repository @Transactional
public class TblTenderReportImpl extends AbcAbstractClass<TblTenderReport> implements TblTenderReportDao {


   @Override
   public void addTblTenderReport(TblTenderReport tblTenderReport){
       super.addEntity(tblTenderReport);
   }

   @Override
   public void deleteTblTenderReport(TblTenderReport tblTenderReport) {
       super.deleteEntity(tblTenderReport);
   }

   @Override
   public void updateTblTenderReport(TblTenderReport tblTenderReport) {
       super.updateEntity(tblTenderReport);
   }

   @Override
   public List<TblTenderReport> getAllTblTenderReport() {
       return super.getAllEntity();
   }

   @Override
   public List<TblTenderReport> findTblTenderReport(Object... values) throws Exception {
       return super.findEntity(values);
   }

   @Override
   public long getTblTenderReportCount() {
       return super.getEntityCount();
   }

   @Override
   public List<TblTenderReport> findByCountTblTenderReport(int firstResult, int maxResult, Object... values) throws Exception {
       return super.findByCountEntity(firstResult, maxResult, values);
   }

   @Override
   public void saveUpdateAllTblTenderReport(List<TblTenderReport> tblTenderReports){
       super.updateAll(tblTenderReports);
   }

@Override
public void saveOrUpdateTblTenderReport(TblTenderReport tblTenderReport) {
	super.saveOrUpdateEntity(tblTenderReport);
}
}

