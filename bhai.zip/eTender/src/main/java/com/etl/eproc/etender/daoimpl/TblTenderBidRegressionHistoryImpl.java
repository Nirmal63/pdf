package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.etender.model.TblTenderBidRegressionHistory;
import com.etl.eproc.etender.daointerface.TblTenderBidRegressionHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderBidRegressionHistoryImpl extends AbcAbstractClass<TblTenderBidRegressionHistory> implements TblTenderBidRegressionHistoryDao {


    @Override
    public void addTblTenderBidRegressionHistory(TblTenderBidRegressionHistory tblTenderBidRegressionHistory){
        super.addEntity(tblTenderBidRegressionHistory);
    }

    @Override
    public void deleteTblTenderBidRegressionHistory(TblTenderBidRegressionHistory tblTenderBidRegressionHistory) {
        super.deleteEntity(tblTenderBidRegressionHistory);
    }

    @Override
    public void updateTblTenderBidRegressionHistory(TblTenderBidRegressionHistory tblTenderBidRegressionHistory) {
        super.updateEntity(tblTenderBidRegressionHistory);
    }

    @Override
    public List<TblTenderBidRegressionHistory> getAllTblTenderBidRegressionHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderBidRegressionHistory> findTblTenderBidRegressionHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderBidRegressionHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderBidRegressionHistory> findByCountTblTenderBidRegressionHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderBidRegressionHistory(List<TblTenderBidRegressionHistory> tblTenderBidRegressionHistorys){
        super.updateAll(tblTenderBidRegressionHistorys);
    }
}
