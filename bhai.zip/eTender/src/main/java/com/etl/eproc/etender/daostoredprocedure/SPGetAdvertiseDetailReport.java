/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author Vivek Rajyaguru
 */
@Component
public class SPGetAdvertiseDetailReport extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "appreport.P_AdvertiseDetailReport";

    public SPGetAdvertiseDetailReport() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_ClientId", Types.SMALLINT));
        this.declareParameter(new SqlParameter("@V_EventId", Types.INTEGER));
       // this.declareParameter(new SqlParameter("@V_OfficerId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_DeptId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_AdvertiseNo", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_AdvertiseType", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_PaperAdvertisementNo", Types.VARCHAR));
        
        
        this.declareParameter(new SqlParameter("@V_PublishedOnOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_PublishedOnForm", Types.DATE));
        this.declareParameter(new SqlParameter("@V_PublishedOnTo", Types.DATE));
        
        this.declareParameter(new SqlParameter("@V_AdvCstatus", Types.INTEGER));

        this.declareParameter(new SqlParameter("@V_SubmissionEndDateOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_SubmissionEndDateFrom", Types.DATE));
        this.declareParameter(new SqlParameter("@V_SubmissionEndDateTo", Types.DATE));
        
        this.declareParameter(new SqlParameter("@V_DownloadDocumentDateOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_DownloadDocumentDateFrom", Types.DATE));
        this.declareParameter(new SqlParameter("@V_DownloadDocumentDateTo", Types.DATE));
        
        this.declareParameter(new SqlParameter("@V_OpeningDateFromOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_OpeningDateFrom", Types.DATE));
        this.declareParameter(new SqlParameter("@V_OpeningDateTo", Types.DATE));
        
        this.declareParameter(new SqlParameter("@V_EstimatedValueOperator", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_EstimatedValueFrom", Types.DOUBLE));
        this.declareParameter(new SqlParameter("@V_EstimatedValueTo", Types.DOUBLE));
        
        this.declareParameter(new SqlParameter("@V_ResponsibleOfficerId", Types.INTEGER));
        
        this.declareParameter(new SqlParameter("@V_TypeOfContract", Types.TINYINT));
        this.declareParameter(new SqlParameter("@V_LangId", Types.TINYINT));
        
        this.declareParameter(new SqlParameter("@V_TimeZoneOffset", Types.VARCHAR));
        this.declareParameter(new SqlParameter("@V_ConversionValue", Types.VARCHAR));
        
        
       
        this.declareParameter(new SqlParameter("@V_ShowDepartment", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowAdvertiseNo", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowAdvertiseType", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowPaperName", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowPaperAdvertiseNo", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowAdvertiseDate", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowEMD", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowDocFees", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowSystemId", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowReferenceNo", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowBriefScope", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowProjectDuration", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowEstimatedValue", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowSubmissionEndDate", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowOpeningDate", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowDocumentDownloadDate", Types.BIT));
        this.declareParameter(new SqlParameter("@V_ShowTypeOfContract", Types.BIT));
        
        
        
        this.declareParameter(new SqlParameter("@V_RecordsPerPage", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_PageNo", Types.INTEGER));
        
        this.declareParameter(new SqlOutParameter("@V_TotalPages", Types.INTEGER));
        this.declareParameter(new SqlOutParameter("@V_TotalRecords", Types.INTEGER));
        
        
    }

    
    /**
     * @param clientId
     * @param eventId
     * @param officerId
     * @param departmentId
     * @param refNo
     * @param publishDateOperator
     * @param eventPubDateFrom
     * @param eventPubDateTo
     * @param estOpFrom
     * @param estValFrom
     * @param estValTo
     * @param submissionEndDateOperator
     * @param bidSubDateFrom
     * @param bidSubDateTo
     * @param typeOfContract
     * @param biddingAccess
     * @param biddingType
     * @param status
     * @param timeZoneOffset
     * @param conversionValue
     * @param langId
     * @param showHide
     * @param recordPerPage
     * @param pageNo
     * @return
     * @throws Exception
     */
    public Map<String,Object> executeProcedure(int clientId,int deptId,int eventId,String txtAdvertiseNo,String txtPaperAdvertisementNo,int advertiseType,int pubDateOpFrom,
    		Date publishDateFrom,Date publishDateTo,int advStatus,int subDateOpFrom,Date bidDateFrom,Date bidDateTo,int downloadDocumentDateOperator,Date downloadDocumentDateFrom,Date downloadDocumentDateTo,int openingDateFromOperator,
    		Date openingDateFrom,Date openingDateTo,
    		int estOpFrom,Double estValFrom,Double estValTo,int officerId,int contractType,String timeZoneOffset,int conversionValue,int langId,List<Short> showHide,int recordPerPage,int pageNo) throws Exception
    {
        Map inParams = new HashMap();        
        inParams.put("@V_ClientId",clientId);
        inParams.put("@V_EventId",eventId);
        
        inParams.put("@V_DeptId", deptId);
        inParams.put("@V_AdvertiseNo",txtAdvertiseNo);
        inParams.put("@V_AdvertiseType", advertiseType);
        inParams.put("@V_PaperAdvertisementNo", txtPaperAdvertisementNo);
        
        inParams.put("@V_PublishedOnOperator", pubDateOpFrom);
        inParams.put("@V_PublishedOnForm", publishDateFrom);
        inParams.put("@V_PublishedOnTo", publishDateTo);
        
        inParams.put("@V_AdvCstatus", advStatus);
      
       
        
        inParams.put("@V_SubmissionEndDateOperator",subDateOpFrom);
        inParams.put("@V_SubmissionEndDateFrom",bidDateFrom);
        inParams.put("@V_SubmissionEndDateTo", bidDateTo);

        inParams.put("@V_DownloadDocumentDateOperator",downloadDocumentDateOperator);
        inParams.put("@V_DownloadDocumentDateFrom",downloadDocumentDateFrom);
        inParams.put("@V_DownloadDocumentDateTo", downloadDocumentDateTo);
        

        inParams.put("@V_OpeningDateFromOperator",openingDateFromOperator);
        inParams.put("@V_OpeningDateFrom",openingDateFrom);
        inParams.put("@V_OpeningDateTo", openingDateTo);
        
        inParams.put("@V_EstimatedValueOperator", estOpFrom);
        inParams.put("@V_EstimatedValueFrom", estValFrom);
        inParams.put("@V_EstimatedValueTo",estValTo );
        
        inParams.put("@V_ResponsibleOfficerId",officerId );
        
        inParams.put("@V_TypeOfContract", contractType);
        inParams.put("@V_LangId", langId);
        inParams.put("@V_TimeZoneOffset", timeZoneOffset);
        inParams.put("@V_ConversionValue", conversionValue);
       
        
        if(showHide.size()>0){                              
            //inParams.put("@V_IsShowSrNo", showHide.get(0));  
            inParams.put("@V_ShowDepartment", showHide.get(1));         
            inParams.put("@V_ShowAdvertiseNo", showHide.get(2));
            inParams.put("@V_ShowAdvertiseType", showHide.get(3));
            inParams.put("@V_ShowPaperName", showHide.get(4));
            inParams.put("@V_ShowPaperAdvertiseNo", showHide.get(5));
            inParams.put("@V_ShowAdvertiseDate", showHide.get(6));
            inParams.put("@V_ShowEMD", showHide.get(7));
            inParams.put("@V_ShowDocFees", showHide.get(8));
            inParams.put("@V_ShowSystemId", showHide.get(9));  
            inParams.put("@V_ShowReferenceNo", showHide.get(10));         
            inParams.put("@V_ShowBriefScope", showHide.get(11));
            inParams.put("@V_ShowProjectDuration", showHide.get(12));
            inParams.put("@V_ShowEstimatedValue", showHide.get(13));
            inParams.put("@V_ShowSubmissionEndDate", showHide.get(14));
            inParams.put("@V_ShowOpeningDate", showHide.get(15));
            inParams.put("@V_ShowDocumentDownloadDate", showHide.get(16));
            inParams.put("@V_ShowTypeOfContract", showHide.get(17));
            
           
        }
        inParams.put("@V_RecordsPerPage", recordPerPage);
        inParams.put("@V_PageNo", pageNo);
        this.compile();
        return execute(inParams);
    }
}

