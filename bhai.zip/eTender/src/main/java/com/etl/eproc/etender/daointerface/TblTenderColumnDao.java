package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderColumn;
import java.util.List;

public interface TblTenderColumnDao  {

    public void addTblTenderColumn(TblTenderColumn tblTenderColumn);

    public void deleteTblTenderColumn(TblTenderColumn tblTenderColumn);

    public void updateTblTenderColumn(TblTenderColumn tblTenderColumn);

    public List<TblTenderColumn> getAllTblTenderColumn();

    public List<TblTenderColumn> findTblTenderColumn(Object... values) throws Exception;

    public List<TblTenderColumn> findByCountTblTenderColumn(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderColumnCount();

    public void saveUpdateAllTblTenderColumn(List<TblTenderColumn> tblTenderColumns);
}