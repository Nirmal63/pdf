/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;

/**
 *
 * @author urja.r
 */

import com.etl.eproc.etender.model.TblCorrigendumDetail;
import java.util.List;

public interface TblCorrigendumDetailDao  {

    public void addTblCorrigendumDetail(TblCorrigendumDetail tblCorrigendumDetail);

    public void deleteTblCorrigendumDetail(TblCorrigendumDetail tblCorrigendumDetail);

    public void updateTblCorrigendumDetail(TblCorrigendumDetail tblCorrigendumDetail);

    public List<TblCorrigendumDetail> getAllTblCorrigendumDetail();

    public List<TblCorrigendumDetail> findTblCorrigendumDetail(Object... values) throws Exception;

    public List<TblCorrigendumDetail> findByCountTblCorrigendumDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCorrigendumDetailCount();

    public void saveUpdateAllTblCorrigendumDetail(List<TblCorrigendumDetail> tblCorrigendumDetails);

	public void saveOrUpdateTblCorrigendumDetail(TblCorrigendumDetail tblCorrigendumDetail);
}