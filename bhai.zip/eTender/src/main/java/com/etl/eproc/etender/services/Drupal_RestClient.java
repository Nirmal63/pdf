package com.etl.eproc.etender.services;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.jsoup.Jsoup;
//import org.w3c.dom.Document;
//import org.w3c.dom.Element;
//import org.w3c.dom.Node;
//import org.w3c.dom.NodeList;

import nic.otc.CallCorrTen2cppp;
import nic.otc.Cppp_RestXMLClient;
import nic.otc.Tender_Status_task;
import nic.otc.Tenders2cppp;
import nic.otc.Tenders2cppp_history;
import nic.otc.Tenders2cppp_uniqid;

public class Drupal_RestClient {

	public Drupal_RestClient(SessionFactory sessionFactory, String transfer_method, String ipaddress, String run_limit,
			String module_info) {
		this.sessionFactory = sessionFactory;
		this.transfer_method = transfer_method;
		this.ipaddress = ipaddress;
		this.run_limit = run_limit;
		this.module_info = module_info;

	}

	public Drupal_RestClient(SessionFactory sessionFactory, String transfer_method, String ipaddress, String run_limit,
			String xml_userid, String login_id, String xml_userpassword, String module_info) {
		this.sessionFactory = sessionFactory;
		this.transfer_method = transfer_method;
		this.ipaddress = ipaddress;
		this.run_limit = run_limit;
		this.xml_userid = xml_userid;
		this.login_id = login_id;
		this.xml_userpassword = xml_userpassword;
		this.module_info = module_info;

	}

	static Connection conn = null;
	static String driverClassName = null;
	static String url = null;
	static String username = null;
	static String password = null;
	static String dialect = null;
	static int run_count = 0;
	static int def_count = 10;
//    @Autowired
	SessionFactory sessionFactory;
	Tenders2cppp ten2cpp;
	Tenders2cppp_uniqid tend2cpppuniqid;
	List<Tenders2cppp> ten2cpplist = new ArrayList();
	static Logger log = Logger.getLogger(Drupal_RestClient.class.toString());
//    @Value("#{projectProperties['transfer_method']}")
	String transfer_method;
//    @Value("#{projectProperties['ip_address_info']}")
	String ipaddress;
//    @Value("#{projectProperties['run_limit']}")
	String run_limit;
//    @Value("#{projectProperties['xml_userid']}")
	String xml_userid;
//    @Value("#{projectProperties['loginid']}")
	String login_id;
//    @Value("#{projectProperties['xml_userpassword']}")
	String xml_userpassword;
//    @Value("#{projectProperties['module_info']}")
	String module_info;

	public void Main(String xml_userid, String login_id, String xml_userpassword) {
		System.out.println("Welcome");
		Drupal_RestClient ob = new Drupal_RestClient(sessionFactory, transfer_method, ipaddress, run_limit, xml_userid,
				login_id, xml_userpassword, module_info);

		if ((transfer_method == null) || (transfer_method.equals("")) || (ipaddress == null) || (ipaddress.equals(""))
				|| (run_limit == null) || (run_limit.equals("")) || (xml_userid == null) || (xml_userid.equals(""))
				|| (xml_userpassword == null) || (xml_userpassword.equals("")) || (module_info == null)
				|| (module_info.equals("")) || (login_id == null) || (login_id.equals(""))) {
			System.out.println("cppptransfer.properties details empty");
			log.severe("cppptransfer.properties details empty");
		} else {
			ipaddress = ipaddress.trim();
			module_info = module_info.trim();
			try {
				run_count = Integer.parseInt(run_limit.trim());
				if (run_count > 0) {
					System.out.println("valid number ");
				} else {
					System.out.println("Negative number ");
					log.severe("Negative number given. so default limit taken");
					run_count = def_count;
				}
			} catch (NumberFormatException ne) {
				System.out.println("Invalid number :" + ne.getMessage());
				log.severe("Invalid number given. so default limit taken");
				run_count = def_count;
			}
			System.out.println("run count :" + run_count);
			if (transfer_method.trim().equals("DB Access")) {
				System.out.println("Your request for DB access is processing. Please Wait !");
				ob.callclient(ipaddress, module_info, xml_userid.trim(), login_id.trim(), xml_userpassword.trim());
			} else if (transfer_method.trim().equals("xmlfile")) {
				System.out.println("Your request for XMl file is processing. Please Wait !");
				File file = new File(System.getProperty("user.dir") + File.separator + "cpppxmldata.xml");
				System.out.println("File name :" + file);
				boolean exists = file.exists();
				if (exists) {
					Cppp_RestXMLClient cppxml = new Cppp_RestXMLClient();
					cppxml.callXMLclient(ipaddress, module_info, file, xml_userid, login_id, xml_userpassword);
				} else {
					System.out.println("XML file does not exist! please try again later ");
					log.severe("XML file does not exist!");
				}
			} else {
				System.out.println("Invalid input. Request should be DB Access / xmlfile. ");
				log.severe("Invalid input. Request should be DB Access / xmlfile.");
			}
		}
	}

	private void callclient(String ipaddress, String module_info, String xml_userid, String login_id,
			String xml_userpassword) {
		Document document = null;
		Element rootElement = null;
		PostMethod method = null;
		String get_data = null;
		String data = "";
		String prebid_datee = null;
		String docsale_download_enddatee = null;
		String tmp = "";
		String key = "";
		String sessid = null;
		String SessionId = null;
		String Status = null;
		InputStream is = null;
		String xml_user_id = null;
		String tender_refno = null;
		String tender_title = null;
		String tender_desc = null;
		String prequalification = null;
		String tender_location = null;
		String tender_pincode = null;
		String tia_details = null;
		String tia_address = null;
		String product_subcategory = null;
		String return_url = null;
		String remarks = null;

		int count = 0;
		int spl_char_count = 0;

		String error_desc = null;

		NameValuePair[] login_details = { new NameValuePair("username", login_id),
				new NameValuePair("password", xml_userpassword) };

		SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd hh:mm aaa");

		HttpClient client = new HttpClient();

		method = new PostMethod("http://" + ipaddress + "/" + module_info + "/xml_data/user/login.xml");
		method.setRequestBody(login_details);

		String getxml = callresponse(client, method);
		try {
			is = new ByteArrayInputStream(getxml.trim().getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			System.out.println("Encoder exception in getxml:" + e.getMessage());
		}
		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			// Document doc = db.parse(is);
			// doc.getDocumentElement().normalize();
			// NodeList nodeLst = doc.getElementsByTagName("result");
			/*
			 * for (int s = 0; s < nodeLst.getLength(); s++) { Node fstNode =
			 * nodeLst.item(s); if (fstNode.getNodeType() == 1) { Element fstElmnt =
			 * (Element) fstNode; NodeList nl1 =
			 * fstElmnt.getElementsByTagName("sessid").item(0).getChildNodes(); sessid =
			 * nl1.item(0).getNodeValue().toString(); NodeList nl2 =
			 * fstElmnt.getElementsByTagName("session_name").item(0).getChildNodes(); String
			 * session_name = nl2.item(0).getNodeValue().toString();
			 * System.out.println("sessid :" + sessid + "2 " + "session_name " +
			 * session_name); } }
			 */
		} catch (Exception e) {
			System.out.println("Xmlread error :" + e.getMessage());
		}

		int n1 = 0;
		int n = 0;

		Transaction transaction = null;
		Session session = sessionFactory.openSession();
		try {
			transaction = session.beginTransaction();
			Query count_tend2cppp = session.createQuery("from Tenders2cppp where xml_user_id=:xml_user_id ");
			count_tend2cppp.setString("xml_user_id", xml_userid);
			int row_count = count_tend2cppp.list().size();
			System.out.println("Total rows in Tenders2cppp: " + row_count);
			if (row_count > 0) {
				System.out.println("valid user");

				if (row_count >= run_count) {
					n = row_count / run_count;
					n1 = row_count % run_count;

					if (n1 > 0) {
						n++;
					}
				} else {
					run_count = row_count;
					n++;
				}
				System.out.println("run_count   :" + run_count);

				for (int ii = 0; ii < n; ii++) {
					count = 0;

					DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
					DocumentBuilder documentBuilder = null;
					try {
						documentBuilder = documentBuilderFactory.newDocumentBuilder();
					} catch (ParserConfigurationException ex) {
						System.out.println("ParserConfigurationException :" + ex.getMessage());
					}
					// document = documentBuilder.newDocument();
					// rootElement = document.createElement("CPPPTENDER");
					// document.appendChild(rootElement);

					Query sel_qry = session
							.createQuery("from Tenders2cppp ten2cppp order by xml_user_id,tender_refno,tid ");
					sel_qry.setMaxResults(run_count);

					System.out.println("Max count :" + run_count);
					Date startdate = new Date();
					ten2cpplist = sel_qry.list();

					for (Iterator it = ten2cpplist.iterator(); it.hasNext();) {
						count++;
						spl_char_count = 0;
						ten2cpp = ((Tenders2cppp) it.next());
						if (ten2cpp == null) {
							System.out.println("XML_USER_ID/ TENDER_REFNO / TID should not null");
							log.severe("XML_USER_ID/ TENDER_REFNO / TID should not null");
						}

						tend2cpppuniqid = ten2cpp.getTend2cpppuniqid();
						xml_user_id = replaceSpecialCharAndHtmlTags(tend2cpppuniqid.getXml_user_id());
						String tid = tend2cpppuniqid.getTid();
						tender_refno = replaceSpecialCharAndHtmlTags(tend2cpppuniqid.getTender_refno());
						tender_title = replaceSpecialCharAndHtmlTags(ten2cpp.getTender_title());
						tender_desc = replaceSpecialCharAndHtmlTags(ten2cpp.getTender_desc());
						prequalification = replaceSpecialCharAndHtmlTags(ten2cpp.getPrequalification());
						tender_location = replaceSpecialCharAndHtmlTags(ten2cpp.getTender_location());
						tender_pincode = ten2cpp.getTender_pincode();
						Double tender_fee = ten2cpp.getTender_fee();
						Double tender_value = ten2cpp.getTender_value();
						Double emd = ten2cpp.getEmd();
						Timestamp published_date = ten2cpp.getPublished_date();
						Timestamp prebid_date = ten2cpp.getPrebid_date();
						Timestamp docsale_download_startdate = ten2cpp.getDocsale_download_startdate();
						Timestamp docsale_download_enddate = ten2cpp.getDocsale_download_enddate();
						Timestamp bid_submission_startdate = ten2cpp.getBid_submission_startdate();
						Timestamp bid_submission_enddate = ten2cpp.getBid_submission_enddate();
						Timestamp bid_opening_date = ten2cpp.getBid_opening_date();
						tia_details = replaceSpecialCharAndHtmlTags(ten2cpp.getTia_details());
						tia_address = replaceSpecialCharAndHtmlTags(ten2cpp.getTia_address());
						Long prod_id = ten2cpp.getProd_id();
						product_subcategory = ten2cpp.getProduct_subcategory();
						return_url = replaceSpecialCharAndHtmlTags(ten2cpp.getReturn_url());
						Long tender_type = ten2cpp.getTender_type();
						Long tender_category = ten2cpp.getTender_category();
						Long form_contract = ten2cpp.getForm_contract();
						Long tender_sector = ten2cpp.getTender_sector();
						Long tender_state = ten2cpp.getTender_state();
						remarks = ten2cpp.getRemarks();
						Character currency = ten2cpp.getCurrency();

						if (tender_fee == null) {
							tender_fee = Double.valueOf(0.0D);
						}
						if (tender_value == null) {
							tender_value = Double.valueOf(0.0D);
						}
						if (emd == null) {
							emd = Double.valueOf(0.0D);
						}
						if (currency == null) {
							currency = Character.valueOf(' ');
						}

						key = xml_user_id + tender_refno + tid;
						if (tmp.equals(key)) {
							System.out.println("duplicate Unique values ");
							count--;
							write_data_history(xml_user_id, tender_refno, tid, tender_title, tender_desc,
									prequalification, tender_location, tender_pincode, tender_fee.doubleValue(),
									tender_value.doubleValue(), emd.doubleValue(), published_date, prebid_date,
									docsale_download_startdate, docsale_download_enddate, bid_submission_enddate,
									bid_opening_date, tia_details, tia_address, prod_id, product_subcategory,
									return_url, tender_type, tender_category, form_contract, tender_sector,
									tender_state, remarks, currency.charValue(), bid_submission_startdate,
									"xmluserid && tender_refno && tender_id is not unique");
						} else {
							System.out.println("Unique values ");
							String[] spl_char_check = new String[8];
							spl_char_check[0] = xml_user_id;
							spl_char_check[1] = tender_refno;
							spl_char_check[2] = tender_title;
							spl_char_check[3] = tender_desc;
							spl_char_check[4] = tender_location;
							spl_char_check[5] = tia_details;
							spl_char_check[6] = tia_address;
							spl_char_check[7] = return_url;

							if ((tender_title == null) || (tender_title.equals("NULL"))) {
								error_desc = "tender_title ";
							}
							if ((tender_desc == null) || (tender_desc.equals("NULL"))) {
								error_desc = "tender_desc ";
							}
							if ((tender_location == null) || (tender_location.equals("NULL"))) {
								error_desc = "tender_location ";
							}
							if ((tia_details == null) || (tia_details.equals("NULL"))) {
								error_desc = "tia_details ";
							}
							if ((tia_address == null) || (tia_address.equals("NULL"))) {
								error_desc = "tia_address ";
							}
							if ((return_url == null) || (return_url.equals("NULL"))) {
								error_desc = "return_url ";
							}
							if (prod_id == null) {
								error_desc = "prod_id ";
							}
							if (tender_type == null) {
								error_desc = "tender_type ";
							}
							if (tender_category == null) {
								error_desc = "tender_category ";
							}
							if (tender_sector == null) {
								error_desc = "tender_sector ";
							}
							if (tender_state == null) {
								error_desc = "tender_state ";
							}
							if (published_date == null) {
								error_desc = "published_date ";
							}
							if (bid_submission_startdate == null) {
								error_desc = "bid_submission_startdate ";
							}
							if (bid_submission_enddate == null) {
								error_desc = "bid_submission_enddate ";
							}
							if (bid_opening_date == null) {
								error_desc = "bid_opening_date ";
							}
							if (error_desc != null) {
								System.out.println(error_desc + " contains null value ");
								count--;
								write_data_history(xml_user_id, tender_refno, tid, tender_title, tender_desc,
										prequalification, tender_location, tender_pincode, tender_fee.doubleValue(),
										tender_value.doubleValue(), emd.doubleValue(), published_date, prebid_date,
										docsale_download_startdate, docsale_download_enddate, bid_submission_enddate,
										bid_opening_date, tia_details, tia_address, prod_id, product_subcategory,
										return_url, tender_type, tender_category, form_contract, tender_sector,
										tender_state, remarks, currency.charValue(), bid_submission_startdate,
										error_desc + "column contains null value ");
								error_desc = null;
							} else {
								/*
								 * System.out.println("Fine data"); for (int i = 0; i < spl_char_check.length;
								 * i++) { Pattern p = Pattern.compile("[^a-zA-Z0-9%&?=\\[\\]/():;,._\\s@#-]");
								 * Matcher m = p.matcher(spl_char_check[i]); if (m.find()) {
								 * System.out.println("specail chr vle ::" + spl_char_check[i]);
								 * spl_char_count++; } } System.out.println("spl_char_count :" +
								 * spl_char_count); if (spl_char_count > 0) {
								 * System.out.println("string containd special characters "); count--;
								 * write_data_history(xml_user_id, tender_refno, tid, tender_title, tender_desc,
								 * prequalification, tender_location, tender_pincode, tender_fee.doubleValue(),
								 * tender_value.doubleValue(), emd.doubleValue(), published_date, prebid_date,
								 * docsale_download_startdate, docsale_download_enddate, bid_submission_enddate,
								 * bid_opening_date, tia_details, tia_address, prod_id, product_subcategory,
								 * return_url, tender_type, tender_category, form_contract, tender_sector,
								 * tender_state, remarks, currency.charValue(), bid_submission_startdate,
								 * "Data contains special characters"); } else { write_data_history(xml_user_id,
								 * tender_refno, tid, tender_title, tender_desc, prequalification,
								 * tender_location, tender_pincode, tender_fee.doubleValue(),
								 * tender_value.doubleValue(), emd.doubleValue(), published_date, prebid_date,
								 * docsale_download_startdate, docsale_download_enddate, bid_submission_enddate,
								 * bid_opening_date, tia_details, tia_address, prod_id, product_subcategory,
								 * return_url, tender_type, tender_category, form_contract, tender_sector,
								 * tender_state, remarks, currency.charValue(), bid_submission_startdate,
								 * error_desc);
								 * 
								 * if (prequalification == null) { prequalification = ""; } if (tender_pincode
								 * == null) { tender_pincode = ""; } if (product_subcategory == null) {
								 * product_subcategory = ""; } String currencyy; // String currencyy; if
								 * (currency.charValue() == ' ') { currencyy = ""; } else { currencyy =
								 * Character.toString(currency.charValue()); } String form_contractt; // String
								 * form_contractt; if (form_contract == null) { form_contractt = ""; } else {
								 * form_contractt = form_contract.toString(); }
								 * 
								 * if (remarks == null) { remarks = ""; }
								 * 
								 * System.out.println("No of Xml Records :" + count);
								 * 
								 * //Element emn = document.createElement("TENDERS"); // Element dn22 =
								 * document.createElement("XML_USER_ID"); //
								 * dn22.appendChild(document.createTextNode(xml_user_id)); //
								 * emn.appendChild(dn22); Element em = document.createElement("T_REF_NO");
								 * em.appendChild(document.createTextNode(tender_refno)); emn.appendChild(em);
								 * Element dn2 = document.createElement("T_ID");
								 * dn2.appendChild(document.createTextNode(tid)); emn.appendChild(dn2); Element
								 * em1 = document.createElement("T_TITLE");
								 * em1.appendChild(document.createTextNode(tender_title)); emn.appendChild(em1);
								 * Element em2 = document.createElement("T_DESC");
								 * em2.appendChild(document.createTextNode(tender_desc)); emn.appendChild(em2);
								 * Element tn2 = document.createElement("T_PRE_QUAL");
								 * tn2.appendChild(document.createTextNode(prequalification));
								 * emn.appendChild(tn2); Element em3 = document.createElement("T_LOCATION");
								 * em3.appendChild(document.createTextNode(tender_location));
								 * emn.appendChild(em3); Element vn2 = document.createElement("T_PINCODE");
								 * vn2.appendChild(document.createTextNode(tender_pincode));
								 * emn.appendChild(vn2); Element vn3 = document.createElement("T_CURRENCY");
								 * vn3.appendChild(document.createTextNode(currencyy)); emn.appendChild(vn3);
								 * String tender_feee; // String tender_feee; if (tender_fee == null) { //
								 * tender_feee = ""; } else { // tender_feee = tender_fee.toString(); }
								 * 
								 * Element em4 = document.createElement("T_FEE");
								 * em4.appendChild(document.createTextNode(tender_feee)); emn.appendChild(em4);
								 * String tender_valuee; // String tender_valuee; if (tender_value == null) {
								 * tender_valuee = ""; } else { tender_valuee = tender_value.toString(); }
								 * 
								 * Element em5 = document.createElement("T_VALUE");
								 * em5.appendChild(document.createTextNode(tender_valuee));
								 * emn.appendChild(em5); String emdd; // String emdd; if (emd == null) { emdd =
								 * ""; } else { emdd = emd.toString(); }
								 * 
								 * Element curdoor = document.createElement("T_EMD");
								 * curdoor.appendChild(document.createTextNode(emdd)); emn.appendChild(curdoor);
								 * System.out.println("published date :" + published_date); String
								 * published_datee = sd.format(published_date);
								 * System.out.println("published_datee :" + published_datee); Element curst =
								 * document.createElement("T_PUB_DATE");
								 * curst.appendChild(document.createTextNode(published_datee));
								 * emn.appendChild(curst); if (prebid_date == null) { prebid_datee = ""; } else
								 * { prebid_datee = sd.format(prebid_date); } Element curarea =
								 * document.createElement("T_PREBID_DATE");
								 * curarea.appendChild(document.createTextNode(prebid_datee));
								 * emn.appendChild(curarea); String docsale_download_startdatee; // String
								 * docsale_download_startdatee; if (docsale_download_startdate == null) {
								 * docsale_download_startdatee = ""; } else { docsale_download_startdatee =
								 * sd.format(docsale_download_startdate); } Element curvn =
								 * document.createElement("T_DOC_START_DATE");
								 * curvn.appendChild(document.createTextNode(docsale_download_startdatee));
								 * emn.appendChild(curvn); if (docsale_download_enddate == null) {
								 * docsale_download_enddatee = ""; } else { docsale_download_enddatee =
								 * sd.format(docsale_download_enddate); } Element curtn =
								 * document.createElement("T_DOC_END_DATE");
								 * curtn.appendChild(document.createTextNode(docsale_download_enddatee));
								 * emn.appendChild(curtn);
								 * 
								 * String bid_submission_startdatee = sd.format(bid_submission_startdate);
								 * Element curdn = document.createElement("T_BIDSUB_START_DATE");
								 * curdn.appendChild(document.createTextNode(bid_submission_startdatee));
								 * emn.appendChild(curdn);
								 * 
								 * String bid_submission_enddatee = sd.format(bid_submission_enddate); Element
								 * statename = document.createElement("T_BIDSUB_END_DATE");
								 * statename.appendChild(document.createTextNode(bid_submission_enddatee));
								 * emn.appendChild(statename);
								 * 
								 * String bid_opening_datee = sd.format(bid_opening_date); Element curpincode =
								 * document.createElement("T_BID_OPEN_DATE");
								 * curpincode.appendChild(document.createTextNode(bid_opening_datee));
								 * emn.appendChild(curpincode); Element em7 =
								 * document.createElement("T_INVITING_OFFICER");
								 * em7.appendChild(document.createTextNode(tia_details)); emn.appendChild(em7);
								 * Element em8 = document.createElement("T_INVITING_OFF_ADDRESS");
								 * em8.appendChild(document.createTextNode(tia_address)); emn.appendChild(em8);
								 * String prod_idd = prod_id.toString(); Element em11 =
								 * document.createElement("T_PROD_CAT");
								 * em11.appendChild(document.createTextNode(prod_idd)); emn.appendChild(em11);
								 * Element em9 = document.createElement("T_PROD_SUB_CAT");
								 * em9.appendChild(document.createTextNode(product_subcategory));
								 * emn.appendChild(em9); String tender_typee = tender_type.toString(); Element
								 * em12 = document.createElement("T_TENDER_TYPE");
								 * em12.appendChild(document.createTextNode(tender_typee));
								 * emn.appendChild(em12); String tender_categorye = tender_category.toString();
								 * Element em13 = document.createElement("T_TENDER_CATEGORY");
								 * em13.appendChild(document.createTextNode(tender_categorye));
								 * emn.appendChild(em13);
								 * 
								 * Element em14 = document.createElement("T_FORM_CONTRACT");
								 * em14.appendChild(document.createTextNode(form_contractt));
								 * emn.appendChild(em14); String tender_sectorr = tender_sector.toString();
								 * Element em15 = document.createElement("T_SECTOR");
								 * em15.appendChild(document.createTextNode(tender_sectorr));
								 * emn.appendChild(em15); String tender_statee = tender_state.toString();
								 * Element em16 = document.createElement("T_STATE");
								 * em16.appendChild(document.createTextNode(tender_statee));
								 * emn.appendChild(em16); Element em10 = document.createElement("T_RETURN_URL");
								 * em10.appendChild(document.createTextNode(return_url)); emn.appendChild(em10);
								 * Element em101 = document.createElement("T_REMARKS");
								 * em101.appendChild(document.createTextNode(remarks)); emn.appendChild(em101);
								 * 
								 * rootElement.appendChild(emn); }
								 * 
								 */}

						}

						tmp = key;
					}

					Date endate = new Date();

					//DOMSource source = new DOMSource(document);
					StringWriter writer = new StringWriter();
					StreamResult result = new StreamResult(writer);
					TransformerFactory transformerFactory = TransformerFactory.newInstance();
					Transformer transformer = null;
					try {
						transformer = transformerFactory.newTransformer();
						//transformer.transform(source, result);
					} catch (TransformerException ex) {
						System.out.println("Error in TransformerException :" + ex.getMessage());
					}
					data = writer.toString();
					System.out.println("Count : " + count + " XML file :" + data);

					if (count > 0) {
						callpostxml(ipaddress, module_info, data, client, method, startdate, endate, count);
					} else {
						System.out.println("All the records are faild in validation");
						del_tenders2cppdetails();
					}
				}

			} else {
				System.out.println("No records in DB / Mismatch XML user id in the Property and Database");
			}
		} catch (RuntimeException se) {
			System.out.println("SQL Error in : " + se.getMessage());
			if (transaction != null) {
				transaction.rollback();
			}
		} finally {
			session.flush();
			session.close();
		}

		CallCorrTen2cppp corrten2cpp = new CallCorrTen2cppp();
		corrten2cpp.callcorrTen2cppp(ipaddress, module_info, run_count, sessionFactory, xml_userid, client);

		/*
		 * CallAoc2cppp callaoc2cppp = new CallAoc2cppp();
		 * callaoc2cppp.callAoc2cppp(ipaddress, module_info, run_count, sessionFactory,
		 * xml_userid, client);
		 * 
		 * CallCorrAoc2cppp callcorraoc2cppp = new CallCorrAoc2cppp();
		 * callcorraoc2cppp.callcorrAoc2cppp(ipaddress, module_info, run_count,
		 * sessionFactory, xml_userid, client);
		 */

		method = new PostMethod("http://" + ipaddress + "/" + module_info + "/xml_data/user/logout");

		method.setRequestBody(sessid);
		String ses_logout = callresponse(client, method);
	}

	private String callresponse(HttpClient client, PostMethod method) {
		String response = null;
		try {
			int returnCode = client.executeMethod(method);
			System.out.println("Return code is-->" + returnCode);
			if (returnCode == 200) {
				response = method.getResponseBodyAsString();
				System.out.println("Response -->" + response);
				log.info("Response :" + response);
			} else if (returnCode == 401) {
				log.severe("You are not a registered user! Plz register and try again");
				System.out.println("You are not a registered user! Plz register and try again");
			} else {
				response = method.getResponseBodyAsString();
				System.out.println("Response -->" + response);
				log.severe("Error Code :" + returnCode + "\nResponse :" + response);
			}
		} catch (Exception e) {
			System.out.println("Response call Error :" + e.getMessage());
			log.severe("Response call Error :" + e.getMessage());
		} finally {
			method.releaseConnection();
		}
		return response;
	}

	private void callpostxml(String ipaddress, String module_info, String data, HttpClient client, PostMethod method,
			Date startdate, Date endate, int count) {
		String finalxmldata = null;
		String getdata = null;
		InputStream is = null;
		String insert_id = null;
		String error_id = null;

		int insert_up_count = 0;
		int error_up_count = 0;
		int insertid_count = 0;
		int errorid_count = 0;
		try {
			finalxmldata = URLEncoder.encode("tender_value") + "=" + URLEncoder.encode(data, "UTF-8");
		} catch (UnsupportedEncodingException ue) {
			System.out.println("Encoder exception in postdata :" + ue.getMessage());
			log.severe("Encoder exception in postdata :" + ue.getMessage());
		}

		method = new PostMethod("http://" + ipaddress + "/" + module_info + "/xml_data/xmlservice");

		method.setRequestBody(finalxmldata);
		method.setRequestHeader("Accept",
				"text/html,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5");

		Timestamp stdate = new Timestamp(startdate.getTime());
		Timestamp enddate = new Timestamp(endate.getTime());
		try {
			int returnCode = client.executeMethod(method);
			System.out.println("Return code is-->" + returnCode);
			if (returnCode == 200) {
				getdata = method.getResponseBodyAsString();
				System.out.println("Response -->" + getdata);

				log.info("Response :" + getdata);
				try {
					is = new ByteArrayInputStream(getdata.trim().getBytes("UTF-8"));
				} catch (UnsupportedEncodingException e) {
					System.out.println("Encoder exception in getxml:" + e.getMessage());
				}
				try {
					/*
					 * DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
					 * DocumentBuilder db = dbf.newDocumentBuilder(); Document doc = db.parse(is);
					 * doc.getDocumentElement().normalize(); NodeList nodeLst =
					 * doc.getElementsByTagName("result"); System.out.println("Length :" +
					 * nodeLst.getLength());
					 * 
					 * for (int s = 0; s < nodeLst.getLength(); s++) { Node fstNode =
					 * nodeLst.item(s);
					 * 
					 * if (fstNode.getNodeType() == 1) { Element fstElmnt = (Element) fstNode;
					 * NodeList nl1 =
					 * fstElmnt.getElementsByTagName("Insert_Id").item(0).getChildNodes(); if
					 * (nl1.getLength() > 0) { insert_id = nl1.item(0).getNodeValue().toString();
					 * String[] succ_var = insert_id.split("&&"); for (int i = 0; i <
					 * succ_var.length; i++) { insertid_count++; String get_success = succ_var[i];
					 * String[] getsucc_val = get_success.split("@#"); String xml_user_id =
					 * getsucc_val[0]; String tender_refno = getsucc_val[1]; String tid =
					 * getsucc_val[2]; String error_desc = getsucc_val[3]; insert_up_count =
					 * update_tenders2cpppdetailshistory(error_desc, xml_user_id, tender_refno,
					 * tid); } } else { System.out.println("Insert_Id tag empty"); } NodeList nl2 =
					 * fstElmnt.getElementsByTagName("Error_Id").item(0).getChildNodes(); if
					 * (nl2.getLength() > 0) { error_id = nl2.item(0).getNodeValue().toString();
					 * String[] fail_var = error_id.split("&&"); for (int i = 0; i <
					 * fail_var.length; i++) { errorid_count++; String get_failure = fail_var[i];
					 * String[] getfail_val = get_failure.split("@#"); String xml_user_id =
					 * getfail_val[0]; String tender_refno = getfail_val[1]; String tid =
					 * getfail_val[2]; String error_desc = getfail_val[3]; error_up_count =
					 * update_tenders2cpppdetailshistory(error_desc, xml_user_id, tender_refno,
					 * tid); } } else { System.out.println("Error_Id tag empty"); } }
					 * 
					 * int cnt = insertid_count + errorid_count;
					 * System.out.println("count equal check :" + cnt + " count :" + count);
					 * 
					 * del_tenders2cppdetails(); }
					 * 
					 */} catch (Exception e) {
					System.out.println("Xmlread error in server response :" + e.getMessage());
				}
			} else {
				getdata = method.getResponseBodyAsString();
				System.out.println("Response -->" + getdata);
				log.severe("Response :" + getdata);
			}
		} catch (Exception e) {
			System.out.println("Response call to server Error :" + e.getMessage());
			log.severe("Response call to server Error :" + e.getMessage());
		} finally {
			method.releaseConnection();
		}

		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();

			Tender_Status_task st = new Tender_Status_task(count, stdate, enddate);
			session.save(st);
			transaction.commit();
		} catch (RuntimeException se) {
			System.out.println("SQL Error in tenders status_task insert table: " + se.getMessage());
			log.severe("SQL Error in tenders status_task insert table : " + se.getMessage());
			if (transaction != null) {
				transaction.rollback();
			}
		} finally {
			session.flush();
			session.close();
		}
	}

	private void write_data_history(String xml_user_id, String tender_refno, String tid, String tender_title,
			String tender_desc, String prequalification, String tender_location, String tender_pincode,
			double tender_fee, double tender_value, double emd, Timestamp published_date, Timestamp prebid_date,
			Timestamp docsale_download_startdate, Timestamp docsale_download_enddate, Timestamp bid_submission_enddate,
			Timestamp bid_opening_date, String tia_details, String tia_address, Long prod_id,
			String product_subcategory, String return_url, Long tender_type, Long tender_category, Long form_contract,
			Long tender_sector, Long tender_state, String remarks, char currency, Timestamp bid_submission_startdate,
			String error_desc) {
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Tenders2cppp_history ten2cpp_his = new Tenders2cppp_history();
			ten2cpp_his.setXml_user_id(xml_user_id);
			ten2cpp_his.setTender_refno(tender_refno);
			ten2cpp_his.setTid(tid);
			ten2cpp_his.setTender_title(tender_title);
			ten2cpp_his.setTender_desc(tender_desc);
			ten2cpp_his.setPrequalification(prequalification);
			ten2cpp_his.setTender_location(tender_location);
			ten2cpp_his.setTender_pincode(tender_pincode);
			ten2cpp_his.setTender_fee(Double.valueOf(tender_fee));
			ten2cpp_his.setTender_value(Double.valueOf(tender_value));
			ten2cpp_his.setEmd(Double.valueOf(emd));
			ten2cpp_his.setPublished_date(published_date);
			ten2cpp_his.setPrebid_date(prebid_date);
			ten2cpp_his.setDocsale_download_startdate(docsale_download_startdate);
			ten2cpp_his.setDocsale_download_enddate(docsale_download_enddate);
			ten2cpp_his.setBid_submission_startdate(bid_submission_startdate);
			ten2cpp_his.setBid_submission_enddate(bid_submission_enddate);
			ten2cpp_his.setBid_opening_date(bid_opening_date);
			ten2cpp_his.setTia_details(tia_details);
			ten2cpp_his.setTia_address(tia_address);
			ten2cpp_his.setProd_id(prod_id);
			ten2cpp_his.setProduct_subcategory(product_subcategory);
			ten2cpp_his.setReturn_url(return_url);
			ten2cpp_his.setTender_type(tender_type);
			ten2cpp_his.setTender_category(tender_category);
			ten2cpp_his.setForm_contract(form_contract);
			ten2cpp_his.setTender_sector(tender_sector);
			ten2cpp_his.setTender_state(tender_state);
			ten2cpp_his.setRemarks(remarks);
			ten2cpp_his.setCurrency(currency);
			ten2cpp_his.setError_desc(error_desc);
			session.save(ten2cpp_his);
			transaction.commit();
		} catch (RuntimeException se) {
			System.out.println("SQL Error in insert history() : " + se.getMessage());
			log.severe("SQL Error in insert history() : " + se.getMessage());
			if (transaction != null) {
				transaction.rollback();
			}
		} finally {
			session.flush();
			session.close();
		}
	}

	private int update_tenders2cpppdetailshistory(String error_desc, String xml_user_id, String tender_refno,
			String tid) {
		int up_count = 0;
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Query query = session.createQuery(
					"update Tenders2cppp_history set error_desc = :error_desc where xml_user_id= :xml_user_id and tender_refno= :tender_refno and tid= :tid and error_desc is null");
			query.setParameter("error_desc", error_desc);
			query.setParameter("xml_user_id", xml_user_id);
			query.setParameter("tender_refno", tender_refno);
			query.setParameter("tid", tid);
			up_count += query.executeUpdate();
			transaction.commit();
		} catch (RuntimeException se) {
			System.out.println("SQL error in update() :" + se.getMessage());
			log.severe("SQL error in update() : " + se.getMessage());
			if (transaction != null) {
				transaction.rollback();
			}
		} finally {
			session.flush();
			session.close();
		}

		return up_count;
	}

	private void del_tenders2cppdetails() {
		int del_count = 0;
		Session session = sessionFactory.openSession();
		Transaction transaction = null;
		try {
			System.out.println("ten2cpplist size :" + ten2cpplist.size());
			for (Iterator it = ten2cpplist.iterator(); it.hasNext();) {
				ten2cpp = ((Tenders2cppp) it.next());
				transaction = session.beginTransaction();
				Query del_query = session.createQuery(
						"delete from Tenders2cppp ten2cppp where xml_user_id=:xml_user_id and tender_refno=:tender_refno and tid=:tid");
				del_query.setString("xml_user_id", ten2cpp.getTend2cpppuniqid().getXml_user_id());
				del_query.setString("tender_refno", ten2cpp.getTend2cpppuniqid().getTender_refno());
				del_query.setString("tid", ten2cpp.getTend2cpppuniqid().getTid());
				del_query.setMaxResults(run_count);
				del_count += del_query.executeUpdate();
				transaction.commit();
			}
			System.out.println("Deleted no. of rows :" + del_count);
		} catch (RuntimeException se) {
			System.out.println("SQL error in del():" + se.getMessage());
			log.severe("SQL error in del() : " + se.getMessage());
			if (transaction != null) {
				transaction.rollback();
			}
		} finally {
			session.flush();
			session.close();
		}
	}

	/**
	 * @author janak
	 * @return
	 */
	public boolean isCpppAvailable(String ipAddress) {
		boolean flag = false;
		try {
//        	flag = getRespCodeHTTP("http://www.google.com/") == 200;
			flag = getRespCodeHTTP(ipAddress) == 200;
		} catch (MalformedURLException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		return flag;
	}

	/**
	 * @author janak
	 * @param urlString
	 * @return
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	public static int getRespCodeHTTP(String urlString) throws MalformedURLException, IOException {
		int code = 0;
		try {
			URL u = new URL(urlString);
			HttpURLConnection huc = (HttpURLConnection) u.openConnection();
			huc.setRequestMethod("GET");
			huc.setRequestProperty("User-Agent",
					"Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 (.NET CLR 3.5.30729)");
			huc.connect();
			code = huc.getResponseCode();
		} catch (SocketException e) {
			code = 500;
			System.out.println("EE : " + e);
		}
		return code;
	}

	public String replaceSpecialCharAndHtmlTags(String repHtmlSpeChar) {
		org.jsoup.nodes.Document doc = Jsoup.parse(repHtmlSpeChar);
		String replaced = doc.text().replaceAll("[^a-zA-Z0-9%&?=\\[\\]/():;,._\\s@#-]", " ");
		return replaced;
	}

}