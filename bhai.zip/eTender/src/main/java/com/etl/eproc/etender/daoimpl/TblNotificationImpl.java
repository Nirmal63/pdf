package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblNotification;
import com.etl.eproc.etender.daointerface.TblNotificationDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblNotificationImpl extends AbcAbstractClass<TblNotification> implements TblNotificationDao {


    @Override
    public void addTblNotification(TblNotification tblNotification){
        super.addEntity(tblNotification);
    }

    @Override
    public void deleteTblNotification(TblNotification tblNotification) {
        super.deleteEntity(tblNotification);
    }

    @Override
    public void updateTblNotification(TblNotification tblNotification) {
        super.updateEntity(tblNotification);
    }

    @Override
    public List<TblNotification> getAllTblNotification() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNotification> findTblNotification(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNotificationCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNotification> findByCountTblNotification(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNotification(List<TblNotification> tblNotification){
        super.updateAll(tblNotification);
    }

	@Override
	public void saveOrUpdateTblNotification(TblNotification tblNotification) {
		super.saveOrUpdateEntity(tblNotification);
	}
}
