package com.etl.eproc.etender.services;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.etender.daostoredprocedure.SPGetTenderListForBidderonMobile;
import com.etl.eproc.etender.daostoredprocedure.SPGetTenderListForMobile;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.etender.model.TblTender;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import org.springframework.beans.factory.annotation.Value;

import javax.net.ssl.HttpsURLConnection;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;



import org.jsoup.Jsoup;

@Service
public class TenderService {
	 @Autowired
	 private SPGetTenderListForMobile spGetTenderListForMobile;
	 @Autowired
	 private HibernateQueryDao hibernateQueryDao;
	 @Autowired
	 private SPGetTenderListForBidderonMobile spGetTenderListForBidderonMobile;
	 @Autowired
	 private TenderCorrigendumService tenderCorrigendumService;
	 @Autowired
	 private CommonService commonService;
	 @Autowired
	 private ReloadableResourceBundleMessageSource messageSource;
	 @Autowired
	 private AbcUtility abcUtility; 
	 @Value("#{projectProperties['abc_generatepdf_path']}")
	 private String abcgeneratepdfpath;
	 @Value("#{projectProperties['abc_client_Logo_path']}")
	 private String abcclientLogopath;
	 @Value("#{projectProperties['mobileapp_pdffont']}")
	 private String mobileapppdffont;
	 @Value("#{projectProperties['mobileapp.defaultAPClientId']?:1}")
	 private int defaultAPClientId;
	       
	 
	  

	 /**
	  * get tender list for abcprocure mobile app homepage
	  * @author Dhruvil.panchal
	  * @param tabId
	  * @param keyWords
	  * @param timeZoneOffset
	  * @param conversionValue
	  * @param recordPerPage
	  * @param pageNo
	  * @return
	  * @throws Exception
	  */
	 
	 public Map<String, Object> getTenderListForMobile(int tabId, String keyWords,
				String timeZoneOffset,int conversionValue , 
				int recordPerPage , int pageNo) throws Exception{
		 return spGetTenderListForMobile.executeProcedure(tabId, keyWords, timeZoneOffset, conversionValue, recordPerPage, pageNo);
	 }
	 
	 /**
	  * GET keyword for abcprocure app
	  * @author Dhruvil.panchal
	  * @param companId
	  * @return
	  */
	public List<Object[]> getkeywordtext(int companId){
		List<Object[]> lstkeyword = null;  
		Map<String, Object> var = new HashMap<String, Object>();        
	    var.put("companId",companId);
	    StringBuffer sb = new StringBuffer();
	    sb.append(" select companyId as c0 ,keywordText as c1 from appuser.tbl_Company where companyId =:companId");
	    lstkeyword =hibernateQueryDao.createSQLQuery(sb.toString(), var,new int[]{0,1},2);
	    return lstkeyword; 
	 }
	
	/**Get companyid abc mobileapp
	 * @author Dhruvil.panchal
	 * @param userId
	 * @param clientId
	 * @return
	 */
	public int getcompanyid(int userId ,int clientId){
		int companyid = 0;
		 Map<String, Object> var = new HashMap<String, Object>();
	     var.put("userId", userId);        
	     var.put("clientId", clientId);
		 List<Object> lst = hibernateQueryDao.singleColQuery("select tblbidderstatus.tblCompany.companyId from TblBidderStatus tblbidderstatus where tblbidderstatus.tblUserLogin.userId=:userId and tblbidderstatus.tblClient.clientId=:clientId ", var);
		 if(!lst.isEmpty()){
			 companyid=(Integer) lst.get(0); //companyid
	      }
		return companyid;
	}
	
	/**
	 * @author Dhruvil.panchal
	 * @param companyId
	 * @param keywordText
	 * @return
	 */
	public boolean  updatekeywordtext(int companyId,String keywordText){
		int cnt = 0;
	    boolean flag = false;
		Map<String, Object> var = new HashMap<String, Object>();
    	var.put("companyId",companyId);
    	var.put("keywordText",keywordText);
	    cnt = hibernateQueryDao.updateDeleteNewQuery("update TblCompany set keywordText=:keywordText  where companyId=:companyId",var);
    	return flag = cnt!=0;
	}
	
	/**Get tender list after bidder login in abcprocure app
	 * @author Dhruvil.panchal
	 * @param tabId
	 * @param keyWords
	 * @param timeZoneOffset
	 * @param conversionValue
	 * @param recordPerPage
	 * @param pageNo
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	public Map<String, Object> getTenderListafterloginMobile(int tabId, String keyWords,
		String timeZoneOffset,int conversionValue , 
		int recordPerPage , int pageNo,int userId) throws Exception{
	 return spGetTenderListForBidderonMobile.executeProcedure(tabId, keyWords, timeZoneOffset, conversionValue, recordPerPage, pageNo,userId);
 }

	/**
	 * Get Tender view abcprocure app
	 * @author Dhruvil.panchal
	 * @param tenderId
	 * @return
	 */
	public List<Object[]> getTenderdetailById(int tenderId) {
		 List<Object[]> lsttenderdetail = null;
		 Map<String, Object> var = new HashMap<String, Object>();
		 var.put("tenderId", tenderId);
		 StringBuffer sb = new StringBuffer();
		 sb.append(" select tt.tenderId  as c0,tt.tenderBrief as c1 , ");
		 sb.append(" case tt.biddingType when 1 then 'Open' when 2 then 'Limited' when 3 then 'Proprietary' when 4 then 'Nomination' end as c2 ," );
		 sb.append(" tt.documentFee as c3 , tt.emdAmount as c4 , tt.registrationCharges as c5 , appmaster.F_ToDateTime(tt.documentStartDate, '+05:30', 103) AS c6, 	 " );
		 sb.append(" appmaster.F_ToDateTime(tt.documentEndDate, '+05:30', 103) AS c7 ,appmaster.F_ToDateTime(tt.submissionStartDate, '+05:30', 103) AS c8 ,appmaster.F_ToDateTime(tt.submissionEndDate, '+05:30', 103) AS c9,appmaster.F_ToDateTime(tt.openingDate, '+05:30', 103) AS c10, tt.corrigendumCount as c11 ,tc.clientName as c12,tt.isdocfeesapplicable as c13 ," );
		 sb.append(" appmaster.F_ToDateTime (TCC.createdOn, '+05:30', 103) AS c14 ,TCC.remark as c15 , case when tt.documentEndDate >= getutcdate() then '1' when tt.documentEndDate < getutcdate() then '0' when  tt.documentEndDate is null then '0'  end as c16,tc.clientId as c17 from apptender.tbl_tender tt  " );
		 sb.append(" INNER JOIN appclient.tbl_Department td on td.deptId=tt.deptid " );
		 sb.append(" INNER JOIN appclient.tbl_Client tc on td.clientId=tc.clientId");
	     sb.append(" LEFT JOIN apptender.tbl_cancelrequest TCC on TCC.objectId = tt.tenderid" );
	     sb.append(" where tt.tenderId =:tenderId" );
		 lsttenderdetail= hibernateQueryDao.createSQLQuery(sb.toString(), var,new int[]{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16},18);
		 return lsttenderdetail;
	}
	

	/**view tender document abcprocure app
	 * @author Dhruvil.panchal
	 * @param tenderId
	 * @param linkId
	 * @return
	 */
	public List<Object[]> getTenderDocument(int tenderId,List<Integer> linkId) {
		List<Object[]> lstTenderdocument = null;
		int cstatus = 1; //Approve
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("tenderId", tenderId);
		var.put("linkId", linkId);
		var.put("cstatus", cstatus);
		StringBuffer sb = new StringBuffer();
		sb.append("select tod.officerDocMappingId as c0, tt.tenderid as c1 , td.docName as c2, td.description as c3 from apptender.tbl_tender tt ");
		sb.append("INNER JOIN  appuser.tbl_OfficerDocmapping tod ON tod.objectid =tt.tenderid ");
		sb.append("INNER JOIN appuser.tbl_OfficerDocument td ON td.officerDocId= tod.officerDocId ");
		sb.append("where tt.tenderId =:tenderId and tod.linkId in (:linkId) and tod.cstatus =:cstatus ");
		lstTenderdocument= hibernateQueryDao.createSQLQuery(sb.toString(), var,new int[]{0,1,2,3},4);
		return lstTenderdocument;
	}
	/**Check bidder pay docfee related tender
	 * @author Dhruvil.panchal
	 * @param tenderId
	 * @param paymentFor
	 * @param cstatus
	 * @param userId
	 * @return
	 */
	public int checkdocfee(int tenderId,int paymentFor,int cstatus ,int userId){
		int paymentId= 0;
		 Map<String, Object> var = new HashMap<String, Object>();
		 var.put("tenderId", tenderId);
		 var.put("userId", userId);
		 var.put("paymentFor",paymentFor);
		 var.put("cstatus",cstatus);
		 List<Object> lst =  hibernateQueryDao.singleColQuery("select  paymentId  from TblPayment tblpayment where  tblpayment.objectId=:tenderId and tblpayment.tblUserLogin.userId=:userId and tblpayment.paymentFor=:paymentFor and tblpayment.cstatus=:cstatus " ,var);		 		
		 if(!lst.isEmpty()){
			 paymentId=(Integer) lst.get(0); //paymentId
	      }
		return paymentId;	
	}
	
	 /**
     * To update Notification as Read or Clear.
     * @author Priyanka Dalwadi
     * @param notificationHistoryId
     * @param isActive
     * @param userId
     * @return
     * @throws Exception
     */
	
		public boolean  updateNotification(int notificationHistoryId,int isActive,int userId){
		int cnt = 0;
		Map<String, Object> var = new HashMap<String, Object>();
		StringBuffer query = new StringBuffer();
		query.append(" update TblNotificationHistory set isActive=:isActive  where ");
		if(notificationHistoryId!=0){
			var.put("notificationHistoryId",notificationHistoryId);
			query.append("  notificationHistoryId=:notificationHistoryId ");
		}else{
			var.put("userId",userId);
			query.append("  tblUserLogin.userId=:userId ");
		}
    	var.put("isActive",isActive);
	    cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
    	return cnt!=0;
	}
		/**
		 * Generate PDF for mobile Application
		 * @param tenderId
		 * @param tblClient
		 * @param tbldepartment
		 * @param parentdepartment
		 * @param tblTender
		 * @param personName
		 * @param currency
		 * @param envelopename
		 * @return
		 * @throws IOException
		 */
			public String generatePDF(int tenderId ,TblClient tblClient,TblDepartment tbldepartment,TblDepartment parentdepartment,TblTender tblTender,String personName,String currency,StringBuilder envelopename) throws IOException{
				String path =abcgeneratepdfpath+"\\EventNotice_"+tenderId+".pdf";
				boolean filedirectory = true;
				boolean logoexist =true;
				try {
					File f = new File(abcgeneratepdfpath);
					if(!f.exists()){
						if(!f.mkdir()){
							filedirectory =false;
						}
					}
					if(filedirectory){
					File file = new File(path);
					if (file.exists()){
							file.delete();
					}
					Document document = new Document(PageSize.A4,20, 20, 45, 30);
					PdfWriter pw = PdfWriter.getInstance(document,new FileOutputStream(path));
					BaseFont bf = BaseFont.createFont(mobileapppdffont, BaseFont.WINANSI, BaseFont.NOT_EMBEDDED);
					document.open();
					PdfPTable table = new PdfPTable(3);
			        PdfPCell cell = new PdfPCell(new Phrase("Domain : ", new Font(bf, 10)));
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase(tblClient.getDomainName(),new Font(bf, 10)));
			        table.addCell(cell);
			        String logo = abcclientLogopath+"\\"+tblClient.getClientId().toString()+"\\"+tblClient.getLogo();
			        File logoimage = new File(logo);
					if(!logoimage.exists()){
						logoexist =false;
					}
				  // String clientlogourl ="http://"+tblClient.getDomainName()+":8080/EPROC/resources/static-images/Logo/"+tblClient.getClientId().toString()+"/"+tblClient.getLogo();
			      //  HttpURLConnection con = (HttpURLConnection) new URL(clientlogourl).openConnection();
			        if(logoexist){
			        	  String logopath = abcclientLogopath+"\\"+tblClient.getClientId().toString()+"\\"+tblClient.getLogo();	
			        	  Image im=Image.getInstance(logopath);	
			        	  im.scalePercent(25);
					      PdfPCell cell23 = new PdfPCell(im);
					      cell23.setPaddingTop(4);
					      cell23.setPaddingLeft(20);
					      cell23.setColspan(1);
						  cell23.setRowspan(2);
					      table.addCell(cell23);
			        }else{
			        	 PdfPCell cell23 = new PdfPCell(new Phrase(""));
			        	 cell23.setColspan(1);
					     cell23.setRowspan(2);
					     table.addCell(cell23);
			        }
			        cell = new PdfPCell(new Phrase("Parent Department :",new Font(bf, 10)));
			        cell.setFixedHeight(25f);
			        table.addCell(cell);
			        cell = new PdfPCell(new Phrase(parentdepartment.getDeptName(),new Font(bf, 10)));
			        cell.setBorder(Rectangle.NO_BORDER);
			        table.addCell(cell);
			        document.add(table);
			        PdfPTable table1 = new PdfPTable(4);
			        PdfPCell cell1 = new PdfPCell(new Phrase("Department :",new Font(bf, 10)));
			        cell.setFixedHeight(25f);		        
			        table1.addCell(cell1);
			        cell1 = new PdfPCell(new Phrase(tbldepartment.getDeptName(),new Font(bf, 10)));
			        table1.addCell(	cell1);
			        cell1 = new PdfPCell(new Phrase("Department officer : ",new Font(bf, 10)));
			        table1.addCell(cell1);
			        cell1 = new PdfPCell(new Phrase(abcUtility.reverseReplaceSpecialChars(personName),new Font(bf, 10)));
			        table1.addCell(cell1);
			        cell1 = new PdfPCell(new Phrase("Event :",new Font(bf, 10)));
			        table1.addCell(cell1);
			        cell1 = new PdfPCell(new Phrase(tblTender.getTenderId()+"",new Font(bf, 10)));
			        table1.addCell(cell1);
			        cell1 = new PdfPCell(new Phrase("Reference number : ",new Font(bf, 10)));
			        table1.addCell(cell1);
			        cell1 = new PdfPCell(new Phrase(abcUtility.reverseReplaceSpecialChars(tblTender.getTenderNo()),new Font(bf, 10)));
			        table1.addCell(cell1);
			        document.add(table1);
			        PdfPTable table2 = new PdfPTable(2);
			        PdfPCell cell2 = new PdfPCell(new Phrase("Brief scope of work :",new Font(bf, 10)));
			        table2.addCell(cell2);
			        cell2 = new PdfPCell(new Phrase(abcUtility.reverseReplaceSpecialChars(tblTender.getTenderBrief()),new Font(bf, 10)));
			        cell2.setFixedHeight(36f);
			        table2.addCell(cell2);
			        cell2 = new PdfPCell(new Phrase("Details :",new Font(bf, 10)));
			        cell.setFixedHeight(20f);
			        table2.addCell(cell2);
			        cell2 = new PdfPCell(new Phrase(Jsoup.parse(tblTender.getTenderDetail()).text(),new Font(bf, 10)));
			        table2.addCell(cell2);
			        cell2 = new PdfPCell(new Phrase("Product / service / work keywords :",new Font(bf, 10)));
			        cell2.setFixedHeight(20f);
			        table2.addCell(cell2);
			        if(tblTender.getKeywordText() !=null || tblTender.getKeywordText() != ""){
			        	cell2 = new PdfPCell(new Phrase(tblTender.getKeywordText(),new Font(bf, 10)));
			        }else{
			        	cell2 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        }
			        table2.addCell(cell2);
			        document.add(table2);
			        PdfPTable table3 = new PdfPTable(4);
			        PdfPCell cell3 = new PdfPCell(new Phrase("Stage :",new Font(bf, 10)));
			        table3.addCell(cell3);
			        switch(tblTender.getEnvelopeType()){    
			        case 1:    
			        	cell3 = new PdfPCell(new Phrase("Single",new Font(bf, 10)));
			        break;  
			        default:    
			        	cell3 = new PdfPCell(new Phrase("Multiple",new Font(bf, 10)));
			         break;   
			        }
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase("Envelope :",new Font(bf, 10)));
			        cell3.setFixedHeight(36f);
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase(envelopename.toString(),new Font(bf, 10)));
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase("Bid validity period (in days) :",new Font(bf, 10)));
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase(tblTender.getValidityPeriod()+"",new Font(bf, 10)));
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase("Type of contract :",new Font(bf, 10)));
			        table3.addCell(cell3);
			        switch(tblTender.getTblProcurementNature().getProcurementNatureId()){
			        case 1:
			        	cell3 = new PdfPCell(new Phrase("Goods ",new Font(bf, 10)));
			        	break;
			        case 2:
			        	cell3 = new PdfPCell(new Phrase("Service ",new Font(bf, 10)));
			        	break;
			        case 3:
			        	cell3 = new PdfPCell(new Phrase("Works ",new Font(bf, 10)));
			        	break;
			        case 4:
			        	cell3 = new PdfPCell(new Phrase("Turnkey Project ",new Font(bf, 10)));
			        	break;
			        default :
			        	cell3 = new PdfPCell(new Phrase("Other ",new Font(bf, 10)));
			        	break;
			        }
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase("Project duration / delivery or completion period (in days) :",new Font(bf, 10)));
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase(tblTender.getProjectDuration()+"",new Font(bf, 10)));
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase("Download document :",new Font(bf, 10)));
			        table3.addCell(cell3);
			        switch(tblTender.getDownloadDocument()){
			        case 1:
			        	cell3 = new PdfPCell(new Phrase("Before login ",new Font(bf, 10)));
			        	break;
			        case 2:
			        	cell3 = new PdfPCell(new Phrase("After login ",new Font(bf, 10)));
			        	break;
			        case 3:
			        	cell3 = new PdfPCell(new Phrase("After payment",new Font(bf, 10)));
			        	break;
			        default :	
			        	cell3 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        	break;
			        }
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase("Event value :",new Font(bf, 10)));
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase(tblTender.getTenderValue()+"",new Font(bf, 10)));
			        table3.addCell(cell3);
			        cell3 = new PdfPCell(new Phrase("Digital certificate required :",new Font(bf, 10)));
			        table3.addCell(cell3);
			        switch(tblTender.getIsCertRequired()){    
			        case 0:    
			        	cell3 = new PdfPCell(new Phrase("No",new Font(bf, 10)));
			        break;  
			        case 1:    
			        	cell3 = new PdfPCell(new Phrase("Yes",new Font(bf, 10)));
			         break;   
			         default :
			        	 cell3 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
				         break;   
			        }
			        table3.addCell(cell3);
			        document.add(table3);
			        PdfPTable table4 = new PdfPTable(1);
			        PdfPCell cell4 = new PdfPCell(new Phrase("Bid submission configuration",new Font(bf, 12)));
			        cell4.setBackgroundColor(new BaseColor(232,232, 232));
			        cell4.setFixedHeight(30f);
			        table4.addCell(cell4);
			        document.add(table4);
			        PdfPTable table5 = new PdfPTable(4);
			        PdfPCell cell5 = new PdfPCell(new Phrase("Distribution of PO :",new Font(bf, 10)));
			        
			        table5.addCell(cell5);
			        switch(tblTender.getIsSplitPOAllowed()){    
			        case 0:    
			        	cell5 = new PdfPCell(new Phrase("Don't allow",new Font(bf, 10)));
			        break;  
			        case 1:    
			        	cell5 = new PdfPCell(new Phrase("Allow",new Font(bf, 10)));
			         break;
			         default:
			        	 cell5= new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        }
			        table5.addCell(cell5);
			        cell5 = new PdfPCell(new Phrase("Bid evaluation : ",new Font(bf, 10)));
			        
			        table5.addCell(cell5);
			        switch(tblTender.getIsItemwiseWinner()){    
			        case 0:    
			        	cell5 = new PdfPCell(new Phrase("Grand total wise",new Font(bf, 10)));
			        break;  
			        case 1:    
			        	cell5 = new PdfPCell(new Phrase("Item wise",new Font(bf, 10)));
			         break;   
			        case 2:    
			        	cell5 = new PdfPCell(new Phrase("Loot",new Font(bf, 10)));
			        break;   
			        }
			        table5.addCell(cell5);
			        cell5 = new PdfPCell(new Phrase("Mode of bid submission :",new Font(bf, 10)));
			        
			        table5.addCell(cell5);
			        switch(tblTender.getSubmissionMode()){    
			        case 1:    
			        	cell5 = new PdfPCell(new Phrase("Online",new Font(bf, 10)));
			        break;  
			        default :    
			        	cell5 = new PdfPCell(new Phrase("Offline",new Font(bf, 10)));
			         break;   
			        }
			        table5.addCell(cell5);
			        cell5 = new PdfPCell(new Phrase("Bidding access :",new Font(bf, 10)));
			        
			        table5.addCell(cell5);
			        switch(tblTender.getTenderMode()){    
			        case 1:    
			        	cell5 = new PdfPCell(new Phrase("Open",new Font(bf, 10)));
			        break;  
			        case 2:    
			        	cell5 = new PdfPCell(new Phrase("Limited",new Font(bf, 10)));
			         break;
			        case 3:    
			        	cell5 = new PdfPCell(new Phrase("Proprietary",new Font(bf, 10)));
			         break;
			        default :    
			        	cell5 = new PdfPCell(new Phrase("Nomination",new Font(bf, 10)));
			         break;
			        }
			        table5.addCell(cell5);
			        cell5 = new PdfPCell(new Phrase("Base currency :",new Font(bf, 10)));
			        
			        table5.addCell(cell5);
			        cell5 = new PdfPCell(new Phrase(currency,new Font(bf, 10)));
			        table5.addCell(cell5);
			        cell5 = new PdfPCell(new Phrase("Bidding type :",new Font(bf, 10)));
			        
			        table5.addCell(cell5);
			        switch(tblTender.getBiddingType()){    
			        case 1:    
			        	cell5 = new PdfPCell(new Phrase("NCB/Domestic",new Font(bf, 10)));
			        break;  
			        default :    
			        	cell5 = new PdfPCell(new Phrase("ICB/Global",new Font(bf, 10)));
			         break;   	
			        }
			        table5.addCell(cell5);
			        cell5 = new PdfPCell(new Phrase("Consortium :",new Font(bf, 10)));
			        
			        table5.addCell(cell5);
			        switch(tblTender.getIsConsortiumAllowed()){    
			        case 1:    
			        	cell5 = new PdfPCell(new Phrase("Allow",new Font(bf, 10)));
			        break;  
			        default :    
			        	cell5 = new PdfPCell(new Phrase("Don't allow",new Font(bf, 10)));
			         break;   
			        }
			        table5.addCell(cell5);
			        cell5 = new PdfPCell(new Phrase("Bid withdrawal :",new Font(bf, 10)));
			        
			        table5.addCell(cell5);
			        switch(tblTender.getIsBidWithdrawal()){    
			        case 1:    
			        	cell5 = new PdfPCell(new Phrase("Allow",new Font(bf, 10)));
			        break;  
			        default:    
			        	cell5 = new PdfPCell(new Phrase("Don't allow",new Font(bf, 10)));
			         break;   
			        }
			        table5.addCell(cell5);
			        document.add(table5);
			        PdfPTable table6 = new PdfPTable(1);
			        PdfPCell cell6 = new PdfPCell(new Phrase("Key configuration",new Font(bf, 12)));
			        cell6.setBackgroundColor(new BaseColor(232,232, 232));
			        cell6.setFixedHeight(30f);
			        table6.addCell(cell6);
			        document.add(table6);
			        PdfPTable table7= new PdfPTable(4);
			        PdfPCell cell7 = new PdfPCell(new Phrase("Bidding variant :",new Font(bf, 10)));
			        table7.addCell(cell7);
			        switch(tblTender.getBiddingVariant()){    
			        case 1:    
			        	cell7 = new PdfPCell(new Phrase("Open",new Font(bf, 10)));
			        break;  
			        default:    
			        	cell7 = new PdfPCell(new Phrase("Sell",new Font(bf, 10)));
			         break;   
			        }
			        table7.addCell(cell7);
			        cell7 = new PdfPCell(new Phrase("Pre-bid meeting : ",new Font(bf, 10)));
			        cell5.setFixedHeight(20f);
			        table7.addCell(cell7);
			        switch(tblTender.getIsPreBidMeeting()){    
			        case 1:    
			        	cell7 = new PdfPCell(new Phrase("Allow",new Font(bf, 10)));
			        break;  	
			        default:    
			        	cell7 = new PdfPCell(new Phrase("Don't allow",new Font(bf, 10)));
			         break;   
			        }
			        table7.addCell(cell7);
			        cell7= new PdfPCell(new Phrase("Workflow requires :",new Font(bf, 10)));
			        table7.addCell(cell7);
			        switch(tblTender.getIsWorkflowRequired()){    
			        case 1:    
			        	cell7 = new PdfPCell(new Phrase("Allow",new Font(bf, 10)));
			        	
			        break;  
			        default:    
			        	cell7 = new PdfPCell(new Phrase("Don't allow",new Font(bf, 10)));
			         break;   
			        }
			        table7.addCell(cell7);
			        if(tblTender.getIsWorkflowRequired() == 1){
			        	switch(tblTender.getWorkflowTypeId()){    
				        case 2:    
				        	cell7 = new PdfPCell(new Phrase("Workflow type :",new Font(bf, 10)));
				        	table7.addCell(cell7);
				        	cell7 = new PdfPCell(new Phrase("Financial Limit Base",new Font(bf, 10)));
				        	table7.addCell(cell7);
				        break;  
				        case 1:
				        	cell7 = new PdfPCell(new Phrase("Workflow type :",new Font(bf, 10)));
				        	table7.addCell(cell7);
				        	cell7 = new PdfPCell(new Phrase("Role Base",new Font(bf, 10)));
				        	table7.addCell(cell7);
				         break;
				        case 3:    
				        	cell7 = new PdfPCell(new Phrase("Workflow type :",new Font(bf, 10)));
				        	table7.addCell(cell7);
				        	cell7 = new PdfPCell(new Phrase("Any to Any",new Font(bf, 10)));
				        	table7.addCell(cell7);
				         break;
				        case 4:    
				        	cell7 = new PdfPCell(new Phrase("Workflow type :",new Font(bf, 10)));
				        	table7.addCell(cell7);
				        	cell7 = new PdfPCell(new Phrase("Hierarchy Base",new Font(bf, 10)));
				        	table7.addCell(cell7);
				         break;
				        default:    
				        	cell7 = new PdfPCell(new Phrase("Workflow type :",new Font(bf, 10)));
				        	table7.addCell(cell7);
				        	cell7 = new PdfPCell(new Phrase("Financial Limit and Hierarchy Base",new Font(bf, 10)));
				        	table7.addCell(cell7);
				         break;
				        }
			        }
			        cell7 = new PdfPCell(new Phrase("Question / Answer requires :",new Font(bf, 10)));
			        table7.addCell(cell7);
			        switch(tblTender.getIsQuestionAnswer()){    
			        case 1:    
			        	cell7 = new PdfPCell(new Phrase("Allow",new Font(bf, 10)));
			        break;  
			        default:    
			        	cell7 = new PdfPCell(new Phrase("Don't allow",new Font(bf, 10)));
			         break;   
			        }
			        table7.addCell(cell7);
			        document.add(table7);
			        PdfPTable table8 = new PdfPTable(1);
			        PdfPCell cell8 = new PdfPCell(new Phrase("Dates configuration",new Font(bf, 12)));
			        cell8.setBackgroundColor(new BaseColor(232,232, 232));
			        cell8.setFixedHeight(30f);
			        table8.addCell(cell8);
			        document.add(table8);
			        PdfPTable table9= new PdfPTable(2);
			        PdfPCell cell9;
			        Map<String, Object> var = new HashMap<String, Object>();
						var.put("clientId",defaultAPClientId);
						
						List<Object[]> data= hibernateQueryDao.createQuery("select  tbldateformat.dateFormat,tbltimezone.value " +
		             		"from  TblClient tblclient  inner join  tblclient.tblDateFormat tbldateformat" +
		             		" inner join  tblclient.tblTheme tbltheme   inner join  tblclient.tblTimeZone tbltimezone "+
		             		" where tblclient.clientId=:clientId",var);
						String dateFormat ="";
						String timeZone ="";
						 if (data != null && !data.isEmpty()) {
							 dateFormat=data.get(0)[0].toString();
							 timeZone=data.get(0)[1].toString();
						 }
			        if(tblTender.getIsQuestionAnswer()==1){
			        		cell9 = new PdfPCell(new Phrase("Question / Answer start date :",new Font(bf, 10)));
			        		cell9.setFixedHeight(20f);
			        		table9.addCell(cell9);
			        	if(tblTender.getQuestionAnswerStartDate() != null ){
			        		cell9 = new PdfPCell(new Phrase(CommonUtility.convertTimezonefromMobile(tblTender.getQuestionAnswerStartDate(), dateFormat,timeZone),new Font(bf, 10)));
			        	}else{
			        		cell9 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        	}
			        		table9.addCell(cell9);
			        		cell9 = new PdfPCell(new Phrase("Question / Answer End date :",new Font(bf, 10)));
			        		cell9.setFixedHeight(20f);
			        		table9.addCell(cell9);
			        			if(tblTender.getQuestionAnswerEndDate() != null){
			        					cell9 = new PdfPCell(new Phrase(CommonUtility.convertTimezonefromMobile(tblTender.getQuestionAnswerEndDate(), dateFormat,timeZone),new Font(bf, 10)));
			        				}else{
			        						cell9 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        				}
			        			table9.addCell(cell9);
			        }
			        if(tblTender.getIsPreBidMeeting()==1){
			        cell9 = new PdfPCell(new Phrase("Pre-bid meeting start date :",new Font(bf, 10)));
			        cell9.setFixedHeight(20f);
			        table9.addCell(cell9);
			        if(tblTender.getPreBidStartDate() != null){
			        	cell9 = new PdfPCell(new Phrase(CommonUtility.convertTimezonefromMobile(tblTender.getPreBidStartDate(), dateFormat,timeZone),new Font(bf, 10)));
			        }else{
			        	cell9 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        }
			        table9.addCell(cell9);
			        cell9 = new PdfPCell(new Phrase("Pre-bid meeting End date :",new Font(bf, 10)));
			        cell9.setFixedHeight(20f);
			        table9.addCell(cell9);
			        if(tblTender.getPreBidEndDate() != null){
			        	cell9 = new PdfPCell(new Phrase(CommonUtility.convertTimezonefromMobile(tblTender.getPreBidEndDate(), dateFormat,timeZone),new Font(bf, 10)));
			        }else{
			        	cell9 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        }
			        table9.addCell(cell9);
			        }
			        cell9 = new PdfPCell(new Phrase("Document downloading start date :",new Font(bf, 10)));
			        cell9.setFixedHeight(20f);
			        cell9.setFixedHeight(20f);
			        table9.addCell(cell9);
			        if(tblTender.getDocumentStartDate() != null){
			        	cell9 = new PdfPCell(new Phrase(CommonUtility.convertTimezonefromMobile(tblTender.getDocumentStartDate(), dateFormat,timeZone),new Font(bf, 10)));
			        }else{
			        	cell9 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        }
			        table9.addCell(cell9);
			        cell9 = new PdfPCell(new Phrase("Document downloading End date :",new Font(bf, 10)));
			        cell9.setFixedHeight(20f);
			        table9.addCell(cell9);
			        if(tblTender.getDocumentEndDate() != null){
			        	cell9 = new PdfPCell(new Phrase(CommonUtility.convertTimezonefromMobile(tblTender.getDocumentEndDate(), dateFormat,timeZone),new Font(bf, 10)));
			        	
			        }else{
			        	cell9 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        }
			        table9.addCell(cell9);
			        cell9 = new PdfPCell(new Phrase("Bid submission start date :",new Font(bf, 10)));
			        cell9.setFixedHeight(20f);
			        table9.addCell(cell9);
			        if(tblTender.getSubmissionStartDate() != null){
			        	cell9 = new PdfPCell(new Phrase(CommonUtility.convertTimezonefromMobile(tblTender.getSubmissionStartDate(), dateFormat,timeZone),new Font(bf, 10)));
			        }else{
			        	cell9 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        }
			        table9.addCell(cell9);
			        cell9 = new PdfPCell(new Phrase("Bid submission end date :",new Font(bf, 10)));
			        cell9.setFixedHeight(20f);
			        table9.addCell(cell9);
			        if(tblTender.getSubmissionEndDate() != null){
			        	cell9 = new PdfPCell(new Phrase(CommonUtility.convertTimezonefromMobile(tblTender.getSubmissionEndDate(), dateFormat,timeZone),new Font(bf, 10)));
			        }else{
			        	cell9 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        }
			        table9.addCell(cell9);
			        cell9 = new PdfPCell(new Phrase("Bid opening date :",new Font(bf, 10)));
			        cell9.setFixedHeight(20f);
			        table9.addCell(cell9);
			        if(tblTender.getOpeningDate() != null){
				        cell9 = new PdfPCell(new Phrase(CommonUtility.convertTimezonefromMobile(tblTender.getOpeningDate(), dateFormat,timeZone),new Font(bf, 10)));
			        }else{
			        	cell9 = new PdfPCell(new Phrase("-",new Font(bf, 10)));
			        }
			        table9.addCell(cell9);
			        document.add(table9);
			        PdfPTable table10 = new PdfPTable(1);
			        PdfPCell cell10= new PdfPCell(new Phrase("Document / EMD / Security fee detail",new Font(bf, 12)));
			        cell10.setBackgroundColor(new BaseColor(232,232, 232));
			        cell10.setFixedHeight(30f);
			        table10.addCell(cell10);
			        document.add(table10);
			        PdfPTable table11= new PdfPTable(4);
			        PdfPCell cell11 = new PdfPCell(new Phrase("Document fees :",new Font(bf, 10)));
			        table11.addCell(cell11);
			        switch(tblTender.getIsDocfeesApplicable()){    
			        case 1:    
			        	cell11 = new PdfPCell(new Phrase("Event wise",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	cell11 = new PdfPCell(new Phrase("Mode of document fees payment  : ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	if(tblTender.getDocFeePaymentMode()==1){
			        		cell11 = new PdfPCell(new Phrase("Online",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Document fees amount :",new Font(bf, 10))); 
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getDocumentFee()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else if(tblTender.getDocFeePaymentMode()==2){
			        		cell11 = new PdfPCell(new Phrase("Offline",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("Document fees payable at :",new Font(bf, 10))); 
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getDocFeePaymentAddress(),new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Document fees amount :",new Font(bf, 10))); 
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getDocumentFee()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else {
			        		cell11 = new PdfPCell(new Phrase("Both",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("Document fees payable at :",new Font(bf, 10))); 
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getDocFeePaymentAddress(),new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Document fees amount :",new Font(bf, 10))); 
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getDocumentFee()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}
			        break;  
			        case 0:    
			        	cell11 = new PdfPCell(new Phrase("Not required ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			         break;   
			        default :    
			        	cell11 = new PdfPCell(new Phrase("Item wise",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	cell11 = new PdfPCell(new Phrase("Mode of document fees payment  : ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	if(tblTender.getDocFeePaymentMode()==1){
			        		cell11 = new PdfPCell(new Phrase("Online",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Document fees amount :",new Font(bf, 10))); 
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getDocumentFee()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else if(tblTender.getDocFeePaymentMode()==2){
			        		cell11 = new PdfPCell(new Phrase("Offline",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase(tblTender.getDocFeePaymentAddress(),new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Document fees amount :",new Font(bf, 10))); 
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getDocumentFee()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else {
			        		cell11 = new PdfPCell(new Phrase("Both",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Document fees payable at :",new Font(bf, 10))); 
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getDocFeePaymentAddress(),new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Document fees amount :",new Font(bf, 10))); 
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getDocumentFee()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}
			         break;   
			        }
			        cell11 = new PdfPCell(new Phrase("Security fee :",new Font(bf, 10)));
			        table11.addCell(cell11);
			        switch(tblTender.getIsSecurityfeesApplicable()){    
			        case 1:    
			        	cell11 = new PdfPCell(new Phrase("Allow ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	cell11 = new PdfPCell(new Phrase("Mode of security fee payment  : ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	if(tblTender.getSecFeePaymentMode()==1){
			        		cell11 = new PdfPCell(new Phrase("Online",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Event security fees amount : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getSecurityFee()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else if(tblTender.getSecFeePaymentMode()==2){
			        		cell11 = new PdfPCell(new Phrase("Offline",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("Security fee payable at ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getSecFeePaymentAddress(),new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Event security fees amount : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getSecurityFee()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else {
			        		cell11 = new PdfPCell(new Phrase("Both",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("Security fee payable at ",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase(tblTender.getSecFeePaymentAddress(),new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Event security fees amount ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getSecurityFee()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}
			        break;  
			        default:    
			        	cell11 = new PdfPCell(new Phrase("Don't Allow",new Font(bf, 10)));
			        	table11.addCell(cell11);
			         break;   
			        }
			        cell11 = new PdfPCell(new Phrase("EMD ",new Font(bf, 10)));
			        table11.addCell(cell11);
			        switch(tblTender.getIsEMDApplicable()){    
			        case 1:    
			        	cell11 = new PdfPCell(new Phrase("Event wise",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	cell11 = new PdfPCell(new Phrase("Mode of EMD payment  : ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	if(tblTender.getEmdPaymentMode()==1){
			        		cell11 = new PdfPCell(new Phrase("Online",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("EMD amount : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getEmdAmount()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else if(tblTender.getEmdPaymentMode()==2){
			        		cell11 = new PdfPCell(new Phrase("Offline",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("EMD payable at :",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getEmdPaymentAddress(),new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("EMD amount : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getEmdAmount()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else {
			        		cell11 = new PdfPCell(new Phrase("Both",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("EMD payable at : ",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase(tblTender.getEmdPaymentAddress(),new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("EMD amount : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getEmdAmount()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}
			        break;  
			        case 0:    
			        	cell11 = new PdfPCell(new Phrase("Not required ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			         break;   
			        case 2:    
			        	cell11 = new PdfPCell(new Phrase("Item wise",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	cell11 = new PdfPCell(new Phrase("Mode of EMD payment  : ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	if(tblTender.getEmdPaymentMode()==1){
			        		cell11 = new PdfPCell(new Phrase("Online",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("EMD amount : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getEmdAmount()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else if(tblTender.getEmdPaymentMode()==2){
			        		cell11 = new PdfPCell(new Phrase("Offline",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("EMD payable at :",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getEmdPaymentAddress(),new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("EMD amount : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getEmdAmount()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else {
			        		cell11 = new PdfPCell(new Phrase("Both",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("EMD payable at : ",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase(tblTender.getEmdPaymentAddress(),new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("EMD amount : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getEmdAmount()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}
			         break; 
			        default:    
			        	cell11 = new PdfPCell(new Phrase("Range",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        break; 
			        }
			        cell11 = new PdfPCell(new Phrase("Event wise registration charges applicable :",new Font(bf, 10)));
			        table11.addCell(cell11);
			        switch(tblTender.getIsRegistrationCharges()){    
			        case 1:    
			        	cell11 = new PdfPCell(new Phrase("Event wise",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	cell11 = new PdfPCell(new Phrase("Registration charges payment mode : ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	if(tblTender.getRegistrationChargesMode()==1){
			        		cell11 = new PdfPCell(new Phrase("Online",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Registration charges : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getRegistrationCharges()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else if(tblTender.getRegistrationChargesMode()==2){
			        		cell11 = new PdfPCell(new Phrase("Offline",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("Registration charges : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getRegistrationCharges()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else {
			        		cell11 = new PdfPCell(new Phrase("Both",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("Registration charges : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getRegistrationCharges()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}
			        break;  
			        case 0:    
			        	cell11 = new PdfPCell(new Phrase("Not required ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			         break;   
			        case 2:    
			        	cell11 = new PdfPCell(new Phrase("Item wise",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	cell11 = new PdfPCell(new Phrase("Registration charges payment mode : ",new Font(bf, 10)));
			        	table11.addCell(cell11);
			        	if(tblTender.getRegistrationChargesMode()==1){
			        		cell11 = new PdfPCell(new Phrase("Online",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("Registration charges : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getRegistrationCharges()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else if(tblTender.getEmdPaymentMode()==2){
			        		cell11 = new PdfPCell(new Phrase("Offline",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("Registration charges : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getRegistrationCharges()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}else {
			        		cell11 = new PdfPCell(new Phrase("Both",new Font(bf, 10)));
			        		table11.addCell(cell11);	
			        		cell11 = new PdfPCell(new Phrase("Registration charges : ",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase(tblTender.getRegistrationCharges()+"",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        		cell11 = new PdfPCell(new Phrase("",new Font(bf, 10)));
			        		table11.addCell(cell11);
			        	}
			         break;   
			        }
			        document.add(table11);
			        document.close();
					} 
				} catch (FileNotFoundException e ) {
					e.printStackTrace();
				}catch (DocumentException e ) {
					e.printStackTrace();
				}
				return path;
			}
			/**
			 * @author suresh.k
			 * @param date
			 * @param demoTender
			 * @return
			 * @throws Exception
			 */
			public List<Object[]>getTenderDetailsOfCurrentDate(String date,String demoTender)throws Exception
			{
				StringBuilder query = new StringBuilder();
				query.append(" select t.tenderid as c0,tc.domainName as c1 ,t.submissionStartDate as c2,t.submissionEndDate as c3 ,td.deptName as c4, ");
				query.append(" case t.tenderMode when 0 then '-' when 1 then 'Open' when 2 then 'Limited' when 3 then 'Proprietary' when 4 then 'Nomination' end as c5 , ");
				query.append(" case t.tenderResult when 0 then 'Not Set' when 1 then 'Grand Total' when 2 then 'Itemwise' when 3 then 'Lotwise'  end as c6, ");
				query.append(" case t.eventtypeId when 3 then 'PQ' when 4 then 'Tender' when 5 then 'RFQ/Sealed Bid' when 6 then 'RFP' when 7 then 'RFI' when 8 then 'REOI' end as c7, ");
				query.append(" (case when t.cstatus = 1 AND t.submissionStartDate <= GETUTCDATE() AND t.submissionEndDate >= GETUTCDATE() then 'Live' "); 
				query.append("	when t.cstatus = 1 AND t.submissionEndDate < GETUTCDATE() then 'Archive' ");
				query.append(" when t.cstatus = 2 then 'Cancelled' end) as c8 ");
				query.append(" from apptender.tbl_tender t ");
				query.append(" inner join appclient.tbl_Department td on td.deptId =t.deptId ");
				query.append(" inner join appclient.tbl_Client tc on tc.deptId = tc.deptId and t.deptId=tc.deptId join (select tenderid from  apptender.tbl_Tenderenvelope te  where te.publishedOn != '' and te.publishedBy !='' group by tenderid) as t1  on t1.tenderId = t.tenderId ");
				query.append(" where CONVERT(VARCHAR(25),t.submissionEndDate, 126) LIKE :endDate and t.isDemoTender =:demoTender and t.cstatus > 0");
				Map<String, Object> var = new HashMap<String, Object>();
				var.put("endDate",date+"%");
				var.put("demoTender",Integer.parseInt(demoTender));
				List<Object[]> lstcolumnname = hibernateQueryDao.createSQLQuery(query.toString(), var,new int[]{0,1,2,3,4,5,6,7,8},9);
				return lstcolumnname;
			}
			/**
			 * @author suresh.k
			 * @param tenderId
			 * @return
			 */
				public int getnoofBidder(int tenderId){
				int nobidder=0;
				 Map<String, Object> var = new HashMap<String, Object>();
			     var.put("tenderId", tenderId);        
				 List<Object> lst = hibernateQueryDao.singleColQuery("select finalSubmissionId from TblFinalSubmission tblFinalSubmission where tblFinalSubmission.tblTender.tenderId=:tenderId", var);
				 if(!lst.isEmpty()){
					 nobidder= lst.size();
			      }
				return nobidder;
			}
				
				public List<Object[]> getTendersByClient(int clientId){
			    	   StringBuilder builder= new StringBuilder();
			    	   builder.append(" select tblTender.tenderId,tblTender.isDemoTender from TblTender tblTender");
			    	   builder.append(" inner join tblTender.tblDepartment tblDepartment");
			    	   builder.append(" inner join tblDepartment.tblClient tblClient");
			    	   builder.append(" where tblClient.clientId =:clientId and tblTender.isDemoTender=0");
			       	   Map<String,Object> var = new HashMap<String, Object>();
			           var.put("clientId",clientId);
			       	   List<Object[]> lst= hibernateQueryDao.createQuery(builder.toString(), var);
			           return lst;
			       }	
}
