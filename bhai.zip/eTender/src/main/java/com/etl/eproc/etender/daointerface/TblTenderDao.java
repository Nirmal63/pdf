package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTender;
import java.util.List;

public interface TblTenderDao  {

    public void addTblTender(TblTender tblTender);

    public void deleteTblTender(TblTender tblTender);

    public void updateTblTender(TblTender tblTender);

    public List<TblTender> getAllTblTender();

    public List<TblTender> findTblTender(Object... values) throws Exception;

    public List<TblTender> findByCountTblTender(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderCount();

    public void saveUpdateAllTblTender(List<TblTender> tblTenders);
}
