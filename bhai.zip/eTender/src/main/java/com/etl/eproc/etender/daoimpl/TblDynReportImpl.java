package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.etender.model.TblDynReport;
import com.etl.eproc.etender.daointerface.TblDynReportDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblDynReportImpl extends AbcAbstractClass<TblDynReport> implements TblDynReportDao {


    @Override
    public void addTblDynReport(TblDynReport tblDynReport){
        super.addEntity(tblDynReport);
    }

    @Override
    public void deleteTblDynReport(TblDynReport tblDynReport) {
        super.deleteEntity(tblDynReport);
    }

    @Override
    public void updateTblDynReport(TblDynReport tblDynReport) {
        super.updateEntity(tblDynReport);
    }

    @Override
    public List<TblDynReport> getAllTblDynReport() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynReport> findTblDynReport(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynReportCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynReport> findByCountTblDynReport(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDynReport(List<TblDynReport> tblDynReports){
        super.updateAll(tblDynReports);
    }

	@Override
	public void saveOrUpdateTblDynReport(TblDynReport tblDynReport) {
		super.saveOrUpdateEntity(tblDynReport);
	}
}

