package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblBidderPresenceDao;
import com.etl.eproc.etender.model.TblBidderPresence;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblBidderPresenceImpl extends AbcAbstractClass<TblBidderPresence> implements TblBidderPresenceDao {


    @Override
    public void addTblBidderPresence(TblBidderPresence tblBidderPresence){
        super.addEntity(tblBidderPresence);
    }

    @Override
    public void deleteTblBidderPresence(TblBidderPresence tblBidderPresence) {
        super.deleteEntity(tblBidderPresence);
    }

    @Override
    public void updateTblBidderPresence(TblBidderPresence tblBidderPresence) {
        super.updateEntity(tblBidderPresence);
    }

    @Override
    public List<TblBidderPresence> getAllTblBidderPresence() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBidderPresence> findTblBidderPresence(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBidderPresenceCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBidderPresence> findByCountTblBidderPresence(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBidderPresence(List<TblBidderPresence> tblBidderPresences){
        super.updateAll(tblBidderPresences);
    }
}
