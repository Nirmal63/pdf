/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.etl.eproc.common.model.TblAuditTrail;
import com.etl.eproc.etender.daointerface.TblTenderAuditTrailDao;
import com.etl.eproc.etender.daointerface.TblTenderDigitalSignHistoryDao;
import com.etl.eproc.etender.model.TblTenderAuditTrail;
import com.etl.eproc.etender.model.TblTenderDigitalSignHistory;

/**
 *
 * @author TaherT
 */
@Service("TenderAuditTrailService")
public class AuditTrailService {

	@Autowired
	private TblTenderAuditTrailDao tblTenderAuditTrailDao;
	@Autowired
	private TblTenderDigitalSignHistoryDao tblTenderDigitalSignHistoryDao;

	/**
	 * To make Audit in eProc
	 *
	 * @param audit object set in Filter comprising trackLoginId and url
	 * @param linkId url accessed by user
	 * @param remarks status for the action
	 * @param TenderId it contains TenderId
	 * @param objectId it is the primary key of respective table
	 * @param remarkSign remarks from remarks Box and/or signed text generated(in case of pki) 
	 * controller
	 */
	public void makeAuditTrail(Object audit, int linkId, String remarks, Integer tenderId,Integer objectId,String... remarkSign) {
		RequestContextHolder.getRequestAttributes().setAttribute("helpLinkId", linkId, RequestAttributes.SCOPE_REQUEST);// To use to generate help content.
		if (audit != null && audit instanceof TblAuditTrail) {
			TblAuditTrail auditMasterAdmin = (TblAuditTrail) audit;
			TblTenderAuditTrail auditMaster = new TblTenderAuditTrail();
			auditMaster.setPageUrl(auditMasterAdmin.getPageUrl());
			auditMaster.setTblTrackLogin(auditMasterAdmin.getTblTrackLogin());
			auditMaster.setRemark(remarks != null ? remarks : "");
			auditMaster.setLinkId(linkId);
			auditMaster.setTenderId(tenderId==null ? 0 : tenderId);
			auditMaster.setObjectId(objectId==null ? 0 : objectId);
			tblTenderAuditTrailDao.addTblTenderAuditTrail(auditMaster);                
			if (remarkSign != null && remarkSign.length!=0) {
				TblTenderDigitalSignHistory signHistory = new TblTenderDigitalSignHistory();
				signHistory.setRemark(remarkSign[0]);
				if (remarkSign.length == 2) {
					signHistory.setSignText(remarkSign[1]);
				}                
				signHistory.setTblTenderAuditTrail(auditMaster);
				tblTenderDigitalSignHistoryDao.addTblTenderDigitalSignHistory(signHistory);
			}
		}
	}
}                
