package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblEvaluationReworkDao;
import com.etl.eproc.etender.model.TblEvaluationRework;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblEvaluationReworkImpl extends AbcAbstractClass<TblEvaluationRework> implements TblEvaluationReworkDao {


    @Override
    public void addTblEvaluationRework(TblEvaluationRework tblEvaluationRework){
        super.addEntity(tblEvaluationRework);
    }

    @Override
    public void deleteTblEvaluationRework(TblEvaluationRework tblEvaluationRework) {
        super.deleteEntity(tblEvaluationRework);
    }

    @Override
    public void updateTblEvaluationRework(TblEvaluationRework tblEvaluationRework) {
        super.updateEntity(tblEvaluationRework);
    }

    @Override
    public List<TblEvaluationRework> getAllTblEvaluationRework() {
        return super.getAllEntity();
    }

    @Override
    public List<TblEvaluationRework> findTblEvaluationRework(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblEvaluationReworkCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblEvaluationRework> findByCountTblEvaluationRework(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblEvaluationRework(List<TblEvaluationRework> tblEvaluationReworks){
        super.updateAll(tblEvaluationReworks);
    }
}
