/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.databean;

import java.util.LinkedHashMap;
import java.util.List;

/**
 *
 * @author shreyansh.shah
 */
public class ItemWiseBreakupDataBean {
 private List<LinkedHashMap<String, Object>> formList ;
 private List<LinkedHashMap<String, Object>> tableList ;
 private List<LinkedHashMap<String, Object>> columnList ;
 private List<LinkedHashMap<String, Object>> columnRowList ;
 private List<LinkedHashMap<String, Object>> columnRowDetailsList ;

    public List<LinkedHashMap<String, Object>> getFormList() {
        return formList;
    }

    public void setFormList(List<LinkedHashMap<String, Object>> formList) {
        this.formList = formList;
    }


    public List<LinkedHashMap<String, Object>> getTableList() {
        return tableList;
    }

    public void setTableList(List<LinkedHashMap<String, Object>> tableList) {
        this.tableList = tableList;
    }

    public List<LinkedHashMap<String, Object>> getColumnList() {
        return columnList;
    }

    public void setColumnList(List<LinkedHashMap<String, Object>> columnList) {
        this.columnList = columnList;
    }

    public List<LinkedHashMap<String, Object>> getColumnRowList() {
        return columnRowList;
    }

    public void setColumnRowList(List<LinkedHashMap<String, Object>> columnRowList) {
        this.columnRowList = columnRowList;
    }

    public List<LinkedHashMap<String, Object>> getColumnRowDetailsList() {
        return columnRowDetailsList;
    }

    public void setColumnRowDetailsList(List<LinkedHashMap<String, Object>> columnRowDetailsList) {
        this.columnRowDetailsList = columnRowDetailsList;
    }
 
}
