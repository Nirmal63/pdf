package com.etl.eproc.etender.services;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblComboDetailDao;
import com.etl.eproc.common.daointerface.TblCommitteeRemarksDao;
import com.etl.eproc.common.daointerface.TblDocumentDao;
import com.etl.eproc.common.daointerface.TblOfficerDocMappingDao;
import com.etl.eproc.common.model.TblCellMaster;
import com.etl.eproc.common.model.TblColumnMaster;
import com.etl.eproc.common.model.TblComboDetail;
import com.etl.eproc.common.model.TblCommitteeRemarks;
import com.etl.eproc.common.model.TblDocument;
import com.etl.eproc.common.model.TblFormMaster;
import com.etl.eproc.common.model.TblMasterBid;
import com.etl.eproc.common.model.TblOfficerDocMapping;
import com.etl.eproc.common.model.TblProcess;
import com.etl.eproc.common.model.TblTableMaster;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.MasterFormService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.etender.daointerface.TblBidDetailDao;
import com.etl.eproc.etender.daointerface.TblBidderApprovalDetailDao;
import com.etl.eproc.etender.daointerface.TblBidderApprovalHistoryDao;
import com.etl.eproc.etender.daointerface.TblBidderItemsDao;
import com.etl.eproc.etender.daointerface.TblBidderweightageScoreDao;
import com.etl.eproc.etender.daointerface.TblCommitteeDao;
import com.etl.eproc.etender.daointerface.TblCommitteeUserDao;
import com.etl.eproc.etender.daointerface.TblCorrigendumDetailDao;
import com.etl.eproc.etender.daointerface.TblEvaluationReworkDao;
import com.etl.eproc.etender.daointerface.TblFinalSubmissionDao;
import com.etl.eproc.etender.daointerface.TblItemSelectionDao;
import com.etl.eproc.etender.daointerface.TblLoadingFactorProcessDao;
import com.etl.eproc.etender.daointerface.TblNegotiationSORRemarksDao;
import com.etl.eproc.etender.daointerface.TblRebateDao;
import com.etl.eproc.etender.daointerface.TblRebateFormDao;
import com.etl.eproc.etender.daointerface.TblReworkDetailDao;
import com.etl.eproc.etender.daointerface.TblTenderBidDetailDao;
import com.etl.eproc.etender.daointerface.TblTenderBidMatrixDao;
import com.etl.eproc.etender.daointerface.TblTenderBidOpenSignDao;
import com.etl.eproc.etender.daointerface.TblTenderCellDao;
import com.etl.eproc.etender.daointerface.TblTenderColumnDao;
import com.etl.eproc.etender.daointerface.TblTenderEnvelopeDao;
import com.etl.eproc.common.daointerface.TblEventFeesDao;
import com.etl.eproc.etender.daointerface.TblTenderFormDao;
import com.etl.eproc.etender.daointerface.TblTenderFormLibraryDao;
import com.etl.eproc.etender.daointerface.TblTenderFormulaDao;
import com.etl.eproc.etender.daointerface.TblTenderGovColumnDao;
import com.etl.eproc.etender.daointerface.TblTenderMatrixJsonDao;
import com.etl.eproc.etender.daointerface.TblTenderOpenDao;
import com.etl.eproc.etender.daointerface.TblTenderProxyBidDao;
import com.etl.eproc.etender.daointerface.TblTenderReevaluationDao;
import com.etl.eproc.etender.daointerface.TblTenderSORDao;
import com.etl.eproc.etender.daointerface.TblTenderTableDao;
import com.etl.eproc.etender.daointerface.TbltenderEnvelopeWeightageDao;
import com.etl.eproc.etender.daointerface.TbltenderFormWeightageDao;
import com.etl.eproc.etender.daostoredprocedure.SPGenerateL1ReportForNegotiation;
import com.etl.eproc.etender.daostoredprocedure.SPGetBidderListForEvaluation;
import com.etl.eproc.etender.daostoredprocedure.SPReviveTender;
import com.etl.eproc.etender.model.TblBidderApprovalDetail;
import com.etl.eproc.etender.model.TblBidderApprovalHistory;
import com.etl.eproc.etender.model.TblBidderItems;
import com.etl.eproc.etender.model.TblBidderweightageScore;
import com.etl.eproc.etender.model.TblCommitteeUser;
import com.etl.eproc.etender.model.TblCorrigendum;
import com.etl.eproc.etender.model.TblCorrigendumDetail;
import com.etl.eproc.etender.model.TblEvaluationRework;
import com.etl.eproc.etender.model.TblFinalSubmission;
import com.etl.eproc.etender.model.TblItemSelection;
import com.etl.eproc.etender.model.TblLoadingFactorProcess;
import com.etl.eproc.etender.model.TblNegotiationSORRemarks;
import com.etl.eproc.etender.model.TblRebate;
import com.etl.eproc.etender.model.TblRebateForm;
import com.etl.eproc.etender.model.TblReworkDetail;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBid;
import com.etl.eproc.etender.model.TblTenderBidDetail;
import com.etl.eproc.etender.model.TblTenderBidMatrix;
import com.etl.eproc.etender.model.TblTenderBidOpenSign;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderColumn;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblEventFees;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderFormLibrary;
import com.etl.eproc.etender.model.TblTenderFormula;
import com.etl.eproc.etender.model.TblTenderGovColumn;
import com.etl.eproc.etender.model.TblTenderMatrixJson;
import com.etl.eproc.etender.model.TblTenderOpen;
import com.etl.eproc.etender.model.TblTenderProxyBid;
import com.etl.eproc.etender.model.TblTenderSOR;
import com.etl.eproc.etender.model.TblTenderTable;
import com.etl.eproc.etender.model.TbltenderEnvelopeWeightage;
import com.etl.eproc.etender.model.TbltenderFormWeightage;
import com.etl.eproc.etender.model.TblTenderReevaluation;

@Service
public class TenderFormService {

	@Autowired
	private SPReviveTender spReviveTender;
    @Autowired
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private TblTenderFormDao tblTenderFormDao;
    @Autowired
    private TblTenderFormulaDao tblTenderFormulaDao;
    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    @Autowired
    private TblTenderTableDao tblTenderTableDao;
    @Autowired
    private TblTenderColumnDao tblTenderColumnDao;
    @Autowired
    private TblTenderCellDao tblTenderCellDao;
    @Autowired
    private TblTenderMatrixJsonDao tblTenderMatrixJsonDao;
    @Autowired
    private TblTenderGovColumnDao tblTenderGovColumnDao;    
    @Autowired
    private TblRebateDao tblRebateDao;
    @Autowired
    private TblRebateFormDao tblRebateFormDao;
    @Autowired
    private TblDocumentDao tblDocumentDao;
    @Autowired
    private TblBidderApprovalDetailDao tblBidderApprovalDetailDao;
    @Autowired
    private TblBidderApprovalHistoryDao tblBidderApprovalHistoryDao;
    @Autowired
    private TblComboDetailDao tblComboDetailDao;
    @Autowired
    private TblTenderProxyBidDao tblTenderProxyBidDao;
    @Autowired
    private TblTenderSORDao tblTenderSORDao;
    @Autowired
    private SPGetBidderListForEvaluation sPGetBidderListForEvaluation;
    @Autowired
    private TblTenderOpenDao tblTenderOpenDao;
    @Autowired
    private TblTenderBidOpenSignDao tblTenderBidOpenSignDao;
    @Autowired
    private TblTenderBidDetailDao tblTenderBidDetailDao;
    @Autowired
    private SPGenerateL1ReportForNegotiation sPGenerateL1ReportForNegotiation;
    @Autowired
    private TblItemSelectionDao tblItemSelectionDao;
    @Autowired
    private TblBidderItemsDao tblBidderItemsDao;
    @Autowired
    private TblBidDetailDao tblBidDetailDao;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private TblCorrigendumDetailDao tblCorrigendumDetailDao;
    @Value("#{projectProperties['future_release']?:false}")
    private Boolean isFutureRelease;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private TblCommitteeUserDao tblCommitteeUserDao;
    @Autowired
    private TblEvaluationReworkDao tblEvaluationReworkDao;
    @Autowired
    private TblTenderBidMatrixDao tblTenderBidMatrixDao;
    @Autowired
    private TblEventFeesDao tblEventFeesDao;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private TblCommitteeRemarksDao tblCommitteeRemarksDao;
    @Autowired
    private TblFinalSubmissionDao tblFinalSubmissionDao;
    @Autowired
    private TblReworkDetailDao tblReworkDetailDao;
    @Autowired
    private TblTenderEnvelopeDao tblTenderEnvelopeDao;
    @Autowired
    private TbltenderEnvelopeWeightageDao tbltenderEnvelopeWeightageDao;
    @Autowired
    private TblBidderweightageScoreDao tblBidderweightageScoreDao;
    @Autowired
    private TbltenderFormWeightageDao tbltenderFormWeightageDao;
    @Autowired
    private TblCommitteeDao tblCommitteeDao;
    @Autowired
    private TblOfficerDocMappingDao tblOfficerDocMappingDao;
    @Autowired
    private TblNegotiationSORRemarksDao negotiationSORRemarksDao;
    @Autowired
    private TblTenderReevaluationDao tblTenderReevaluationDao;
    @Autowired
    private EventCreationService eventCreationService;
    @Autowired
    private EventBidSubmissionService eventBidSubmissionService;
    @Autowired
    private TblLoadingFactorProcessDao tblLoadingFactorProcessDao;
    
    private final String TABLEID = "tableId";
    private final String FORMID = "formId";
    private final String COLUMNID = "columnId";
    private final String SORTORDER = "sortOrder";
    private final String ENVELOPE_ID = "envelopeId";
    private final String TENDER_ID = "tenderId";
    private final int ISAPPROVEYES = 1;
    private final String FEILD_MIN_FORMS_REQ_FOR_BIDDING="minFormsReqForBidding";
    private final String FEILD_MIN_TECH_FORMS_REQ_FOR_BIDDING="minTechFormsReqForBidding";
    
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private TenderCorrigendumService tenderCorrigendumService;
    @Autowired
    private TblTenderFormLibraryDao tblTenderFormLibraryDao;
    @Value("#{etenderProperties['datatype_smalltext']?:1}")
    private int smalltext;
    @Value("#{etenderProperties['datatype_longtext']?:2}")
    private int longtext;
    @Value("#{etenderProperties['datatype_numeric']?:3}")
    private int numeric;
    @Value("#{etenderProperties['datatype_money']?:4}")
    private int money;
    @Value("#{etenderProperties['datatype_money_all']?:5}")
    private int moneyall;
    @Value("#{etenderProperties['datatype_combo']?:6}")
    private int combobox;
    @Value("#{etenderProperties['datatype_date']?:7}")
    private int date;
    @Value("#{etenderProperties['datatype_master_field']?:8}")
    private int masterField;
    @Value("#{etenderProperties['datatype_listbox']?:9}")
    private int listBox;
    @Value("#{etenderProperties['datatype_autonumber']?:10}")
    private int autoNumber;
    @Value("#{etenderProperties['filledby_officer']?:1}")
    private int officer;
    @Value("#{etenderProperties['filledby_bidder']?:2}")
    private int bidder;
    @Value("#{etenderProperties['filledby_auto']?:3}")
    private int auto;
    @Value("#{etenderProperties['filledby_proxy']?:4}")
    private int proxy;
    @Value("#{etenderProperties['bidding_form_document_fees']?:9}")
    private int documentFeesId;
    @Value("#{etenderProperties['bidding_form_emd_amount']?:10}")
    private int emdAmountId;
    @Value("#{etenderProperties['bidding_form_processing_fees']?:11}")
    private int processingFeesId;
    @Value("#{etenderProperties['bidding_form_emd_by_officer_fees']?:18}")
    private int emdAmountByOfficerId;
    @Value("#{etenderProperties['bidding_form_document_fees_by_officer']?:31}")
    private int documentFeesByOfficerId;
    @Value("#{etenderProperties['bidding_form_participation_fees_by_officer']?:32}")
    private int participationFeesByOfficerId;
    @Value("#{etenderProperties['bidding_form_encr_not_req']?:20}")
    private int notEncrReqId;
    @Value("#{tenderlinkProperties['manage_bidder_master_data_for_bidder']?:161}")
    private int bidderMasterField;
    @Value("#{etenderProperties['load_no_of_items']?:50}")
    private int loadNoOfItems;
    @Value("#{etenderProperties['increment_items']?:20}")
    private int incrementItems;
    private static final String TOTAL = "TOTAL(";
    @Value("#{etenderProperties['bidding_form_loading_factor']?:23}")
    private int loadingFactor;

    /**
     * TO add form detail
     *
     * @author nirav.modi
     * @param tblTenderForm
     * @return boolean
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addTenderForm(TblTenderForm tblTenderForm,int userDetailId,int tenderId,boolean isForCreate,int isBiddingFormPublishWithTender) throws Exception {
        boolean bSuccess = false;
        if(tblTenderForm.getFormId()!=0){
        	int cnt = 0;
            Map<String, Object> var = new HashMap<String, Object>();
            var.put(FORMID,tblTenderForm.getFormId());
            var.put("isMultipleFilling",tblTenderForm.getIsMultipleFilling());
            var.put("isEncryptionReq",tblTenderForm.getIsEncryptionReq());
            var.put("isEvaluationReq",tblTenderForm.getIsEvaluationReq());
            var.put("isDocumentReq",tblTenderForm.getIsDocumentReq());
            var.put("isEncryptedDocument",tblTenderForm.getIsEncryptedDocument());
            var.put("isMandatory",tblTenderForm.getIsMandatory());
            var.put("isSecondary",tblTenderForm.getIsSecondary());
            var.put("isPriceBid",tblTenderForm.getIsPriceBid());
            var.put(SORTORDER,tblTenderForm.getSortOrder());
            var.put(ENVELOPE_ID,tblTenderForm.getTblTenderEnvelope().getEnvelopeId());
            var.put("formFooter",tblTenderForm.getFormFooter());
            var.put("formName",tblTenderForm.getFormName());
            var.put("formHeader",tblTenderForm.getFormHeader());
            var.put("isItemWiseDocAllowed",tblTenderForm.getIsItemWiseDocAllowed());
            StringBuilder query = new StringBuilder();
            query.append(" update TblTenderForm set ");
            query.append(" isMultipleFilling=:isMultipleFilling , isEncryptionReq=:isEncryptionReq , isEvaluationReq=:isEvaluationReq , isDocumentReq=:isDocumentReq , isEncryptedDocument=:isEncryptedDocument ,");
            query.append(" isMandatory=:isMandatory , isSecondary=:isSecondary , isPriceBid=:isPriceBid , sortOrder=:sortOrder , tblTenderEnvelope.envelopeId=:envelopeId , formFooter=:formFooter , formName=:formName , formHeader=:formHeader , isItemWiseDocAllowed=:isItemWiseDocAllowed ");
            query.append(" where formId=:formId ");
            cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
            if(cnt!=0 && tblTenderForm.getIsDocumentReq()==0){
            	List<TblDocument> docs = commonService.getDocumentsByObjectIdLinkWise(tblTenderForm.getFormId(),317);
            	if(docs!=null && !docs.isEmpty()){
            		var.clear();
            		var.put(FORMID,tblTenderForm.getFormId());
            		hibernateQueryDao.updateDeleteNewQuery("DELETE FROM TblDocument tblDocument WHERE tblDocument.objectId=:formId AND tblDocument.tblLink.linkId=317",var);
            	}
            }
            if(tblTenderForm.getIsMandatory()==0 && tblTenderForm.getIsPriceBid()==1) {
            	var.clear();
            	var.put("formId", tblTenderForm.getFormId());
            	hibernateQueryDao.updateDeleteNewQuery("delete TblRebateForm where tblTenderForm.formId=:formId", var);
            }
            return cnt!=0;
        }else{
        	tblTenderFormDao.addTblTenderForm(tblTenderForm);
        }
        if(isForCreate){
        	tenderCorrigendumService.insertCorrigendumNewForm(tblTenderForm.getFormId(),userDetailId,tenderId,isBiddingFormPublishWithTender);
        }
        bSuccess = true;
        return bSuccess;
    }

    /**
     * To get list of envelope
     *
     * @author nirav.modi
     * @return List {@code<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getTenderEnvelopeList(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDER_ID, tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" select tbltenderenvelope.tblEnvelope.envId, tbltenderenvelope.envelopeName,tbltenderenvelope.envelopeId,");
        query.append(" tbltenderenvelope.isOpened,CASE WHEN tbltenderenvelope.openingDate <= GETUTCDATE() AND tbltenderenvelope.cstatus = 1 THEN 1 ELSE 0 END,");
        query.append(" tbltenderenvelope.isEvaluated,tbltenderenvelope.minOpeningMember,tbltenderenvelope.minEvaluator,tbltenderenvelope.tblEnvelope.envId ");
        query.append(" from TblTenderEnvelope tbltenderenvelope");
        query.append(" where tbltenderenvelope.tblTender.tenderId=:tenderId");
        query.append(" ORDER BY tbltenderenvelope.sortOrder ");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    public List<Object[]> getTenderEnvelopeListForEditForm(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDER_ID, tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" select tblEnvelope.lang1, tbltenderenvelope.tblEnvelope.envId, tbltenderenvelope.envelopeName,tbltenderenvelope.envelopeId,");
        query.append(" tbltenderenvelope.isOpened,CASE WHEN tbltenderenvelope.openingDate <= GETUTCDATE() AND tbltenderenvelope.cstatus = 1 THEN 1 ELSE 0 END,");
        query.append(" tbltenderenvelope.isEvaluated,tbltenderenvelope.minOpeningMember,tbltenderenvelope.minEvaluator,tbltenderenvelope.tblEnvelope.envId ");
        query.append(" from TblTenderEnvelope tbltenderenvelope");
        query.append(" INNER JOIN tbltenderenvelope.tblEnvelope tblEnvelope");
        query.append(" where tbltenderenvelope.tblTender.tenderId=:tenderId");
        query.append(" ORDER BY tbltenderenvelope.sortOrder ");
        return  hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    public List<Object[]> getUserRole(int tenderId,int envelopeId,int userId,int committeeType) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDER_ID, tenderId);
        var.put("envelopeId", envelopeId);
        var.put("userId", userId);
        StringBuilder query = new StringBuilder();
        query.append(" select tblcommitteeuser.encryptionLevel,tblcommitteeuser.userRoleId,tblcommitteeuser.tblUserLogin.userId");
        query.append(" from TblCommitteeUser tblcommitteeuser ");
        query.append(" inner join tblcommitteeuser.tblCommittee tblcommittee");
        query.append(" where tblcommittee.tblTender.tenderId=:tenderId and tblcommittee.isActive=1 and tblcommitteeuser.isApproved=1 and tblcommitteeuser.childId=:envelopeId and tblcommitteeuser.tblUserLogin.userId=:userId and tblcommittee.committeeType=2");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    public List<Object[]> getDistinctBidderItems(int tenderId,List<Object> prevUserId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("prevUserId", prevUserId);
        StringBuilder query = new StringBuilder();
        query.append(" select tblbidderitems.tblCompany.companyId,COUNT(distinct tblbidderitems.createdBy)");
        query.append(" from TblBidderItems tblbidderitems");
        query.append(" where tblbidderitems.tblTender.tenderId=:tenderId and tblbidderitems.childId=0");
        if(prevUserId!=null){
            //System.out.println("prevUserId = " + prevUserId.toString());
            var.put("prevUserId", prevUserId);
            query.append("  and tblbidderitems.createdBy in (:prevUserId)");
        }
        query.append(" group by tblbidderitems.tblCompany.companyId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    public List<Object[]> getLoadingBeforeFormsOnOpening(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" SELECT tbltenderproxybid.tblCompany.companyId,COUNT(distinct tbltenderproxybid.tblTenderTable.tblTenderForm.formId) ");
        query.append(" from TblTenderProxyBid tbltenderproxybid");
        query.append(" where tbltenderproxybid.tblTender.tenderId=:tenderId and tbltenderproxybid.isUpdatedFrom=2");
        query.append(" group by tbltenderproxybid.tblCompany.companyId");
        query.append(" order by tbltenderproxybid.tblCompany.companyId asc");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
     public List<Object[]> getLoadingBeforeForms(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" SELECT tpb.companyId AS c0, COUNT(DISTINCT tis.formId) AS c1");
        query.append(" FROM apptenderbid.Tbl_TenderProxyBid AS tpb ");
        query.append(" LEFT JOIN apptender.tbl_TenderTable AS tt ON  tt.tableId = tpb.tableId  ");
        query.append(" LEFT JOIN apptender.Tbl_TenderForm AS tf ON tf.formId = tt.formId ");
        query.append(" LEFT JOIN apptenderbid.tbl_ItemSelection AS tis ON tis.formId = tf.formId AND tis.companyId=tpb.companyId  ");
        query.append(" WHERE tpb.tenderId =:tenderId AND (tpb.isUpdatedFrom=1 or tpb.isUpdatedFrom=2) AND tf.cstatus = 1 AND tis.isBidded = 1 ");
        query.append(" GROUP BY tpb.companyId ");
        query.append(" ORDER BY tpb.companyId ASC ");
        return hibernateQueryDao.createSQLQuery(query.toString(), var);
    }
     
     public List<Object[]> getLoadingBeforeFormsMultipleSingleCase( int tenderId, Set<Integer> loadingCompanySet) throws Exception{
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         if(loadingCompanySet != null && ! loadingCompanySet.isEmpty())
        	 var.put("loadingCompanySet", loadingCompanySet);
         StringBuilder query = new StringBuilder();
         query.append(" SELECT tpb.companyId AS c0, COUNT(DISTINCT tis.formId) AS c1");
         query.append(" FROM apptenderbid.Tbl_TenderProxyBid AS tpb ");
         query.append(" INNER JOIN apptender.tbl_TenderTable AS tt ON  tt.tableId = tpb.tableId  ");
         query.append(" INNER JOIN apptender.Tbl_TenderForm AS tf ON tf.formId = tt.formId ");
         query.append(" INNER JOIN apptenderbid.tbl_ItemSelection AS tis ON tis.formId = tf.formId AND tis.companyId=tpb.companyId  ");
         query.append(" INNER JOIN apptenderbid.tbl_finalsubmission AS tfs ON tfs.bidderId = tis.bidderId  AND tfs.tenderId = tpb.tenderId  ");
         query.append(" WHERE tpb.tenderId =:tenderId AND (tpb.isUpdatedFrom=1 or tpb.isUpdatedFrom=2) AND tf.cstatus = 1 AND tis.isBidded = 1 ");
         if(loadingCompanySet != null && ! loadingCompanySet.isEmpty())
        	 query.append(" AND tpb.companyId in (:loadingCompanySet)");
         query.append(" GROUP BY tpb.companyId ");
         query.append(" ORDER BY tpb.companyId ASC ");
         return hibernateQueryDao.createSQLQuery(query.toString(), var);
     }
     
     public List<Object[]> getLoadingProgressForms(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" SELECT tblloadingfactorprocess.companyId,COUNT(distinct tblloadingfactorprocess.formId) ");
        query.append(" from TblLoadingFactorProcess tblloadingfactorprocess");
        query.append(" where tblloadingfactorprocess.tenderId=:tenderId");
        query.append(" group by tblloadingfactorprocess.companyId");
        query.append(" order by tblloadingfactorprocess.companyId asc");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
     
    public List<Object[]> getLoadingFormCompanyWise(int envelopeId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId", envelopeId);
        StringBuilder query = new StringBuilder();
        query.append(" select tblloadingfactorprocess.companyId,COUNT(tblloadingfactorprocess.formId)");
        query.append(" from TblLoadingFactorProcess tblloadingfactorprocess,TblBidderApprovalDetail tblbidderpprovaldetail,TblTenderForm tf");
        query.append(" where tblloadingfactorprocess.companyId = tblbidderpprovaldetail.tblCompany.companyId and tblbidderpprovaldetail.isApproved=1 and tblbidderpprovaldetail.tblTenderEnvelope.envelopeId=:envelopeId");
        query.append("  and tf.tblTender.tenderId = tblbidderpprovaldetail.tblTender.tenderId and tf.isPriceBid=1 and tf.formId = tblloadingfactorprocess.formId");
        query.append(" group by tblloadingfactorprocess.companyId ");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    public List<Object[]> getDistinctEvaluationRemark(int committeeType,int envelopeId,List<Object> prevUserId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeType", committeeType);
        var.put("envelopeId", envelopeId);
        
        StringBuilder query = new StringBuilder();
        query.append(" select tblcommitteeremarks.tblCompany.companyId,COUNT(distinct tblcommitteeremarks.createdBy)");
        query.append(" from TblCommitteeRemarks tblcommitteeremarks");
        query.append(" where tblcommitteeremarks.childId=0 and tblcommitteeremarks.committeeType=:committeeType and tblcommitteeremarks.tblTenderEnvelope.envelopeId=:envelopeId ");
        //Tender :: Bid Evalution :: System is not showing data for evalution to officer. Bug #33030 By Jitendra. 
        if(prevUserId!=null && !prevUserId.isEmpty()){
            var.put("prevUserId", prevUserId);
            //System.out.println("prevUserId = " + prevUserId);
            query.append(" and tblcommitteeremarks.tblUserLogin.userId in (:prevUserId)");
        }
        query.append(" group by tblcommitteeremarks.tblCompany.companyId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
     public int getReworkId(int companyId,int envelopeId,int askToLevel) throws Exception {
        int data = 0;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId", envelopeId);
        var.put("askToLevel", askToLevel);
        StringBuilder query = new StringBuilder();
        if(companyId==0){
            query.append(" select tblevaluationrework.evalReworkId");
            query.append(" from TblEvaluationRework tblevaluationrework");
            query.append(" where tblevaluationrework.cstatus=0 and tblevaluationrework.envelopeId=:envelopeId and tblevaluationrework.officerIdAskedTo=:askToLevel");
        }else{
            var.put("companyId", companyId);
            query.append(" select tblevaluationrework.evalReworkId");
            query.append(" from TblReworkDetail tblreworkdetail");
            query.append(" inner join tblreworkdetail.tblEvaluationRework tblevaluationrework");
            query.append(" where tblreworkdetail.companyId=:companyId and tblreworkdetail.cstatus=0 and tblevaluationrework.envelopeId=:envelopeId and tblevaluationrework.officerIdAskedTo=:askToLevel");
        }
        
        
        list = hibernateQueryDao.singleColQuery(query.toString(), var);
        if (!list.isEmpty()) {
            data =(Integer) list.get(0);
        }
        return data;
    }
     public int getTempReworkId(int askToLevel,int envelopeId) throws Exception {
        int data = 0;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId", envelopeId);
        var.put("askToLevel", askToLevel);
        StringBuilder query = new StringBuilder();
        query.append(" select tblevaluationrework.evalReworkId");
        query.append(" from TblEvaluationRework tblevaluationrework");
        query.append(" where tblevaluationrework.envelopeId=:envelopeId and tblevaluationrework.askedToLevel=:askToLevel and tblevaluationrework.cstatus=0");
        list = hibernateQueryDao.singleColQuery(query.toString(), var);
        if (!list.isEmpty()) {
            data =(Integer) list.get(0);
        }
        return data;
    }
     public int getCommitteeId(int tenderId) throws Exception {
        int data = 0;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" select tblcommittee.committeeId");
        query.append(" from TblCommittee tblcommittee");
        query.append(" where tblcommittee.tblTender.tenderId=:tenderId and tblcommittee.committeeType=2 and tblcommittee.isActive=1 and tblcommittee.isApproved=1 ");
        list = hibernateQueryDao.singleColQuery(query.toString(), var);
        if (!list.isEmpty()) {
            data =(Integer) list.get(0);
        }
        return data;
    }
     
     public long getBidderItemCount(int tenderId,int userId,int companyId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("userId", userId);
        var.put("companyId", companyId);
        count = hibernateQueryDao.countForNewQuery("TblBidderItems tblbidderitems ", "tblbidderitems.bidderItemId ", "tblbidderitems.tblTender.tenderId=:tenderId and tblbidderitems.tblCompany.companyId=:companyId and tblbidderitems.createdBy=:userId and tblbidderitems.childId=0", var);
        return count;
    }
     
     public long getEvaluationRemarkCount(int envelopeId,int userId,int committeeType) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId", envelopeId);
        var.put("userId", userId);
        var.put("committeeType", committeeType);
        long count = hibernateQueryDao.countForNewQuery("TblCommitteeRemarks tblcommitteeremarks ", "tblcommitteeremarks.committeeRemarksId ", "tblcommitteeremarks.committeeType=:committeeType and tblcommitteeremarks.tblTenderEnvelope.envelopeId=:envelopeId and tblcommitteeremarks.tblUserLogin.userId=:userId and tblcommitteeremarks.childId=0", var);
        return count;
    }
     public List<Object> getCommitteeOfficerCount(int committeeId,int encryptionLevel,int userRoleId,int envelopeId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("committeeId", committeeId);
        var.put("userRoleId", userRoleId);
        var.put("encryptionLevel", encryptionLevel);
        var.put("envelopeId", envelopeId);
        return hibernateQueryDao.singleColQuery("select distinct tblcommitteeuser.tblUserLogin.userId from TblCommitteeUser tblcommitteeuser where tblcommitteeuser.tblCommittee.committeeId=:committeeId and tblcommitteeuser.encryptionLevel=:encryptionLevel and tblcommitteeuser.userRoleId=:userRoleId and tblcommitteeuser.childId=:envelopeId", var);        
    }
    
    public int showItemSelection(int userId,int envelopeId,int askedToLevel,int companyId,int tenderId,int totalCmpCount) throws Exception {
        int showLink = 0;//hide link
        int reworkId=getReworkId(companyId,envelopeId,userId);
//        int reworkId=getReworkId(companyId,envelopeId,askedToLevel);
        int tempReworkId = getTempReworkId(askedToLevel-1,envelopeId);
        int committeeId = getCommitteeId(tenderId);
        List<Object> prevUser = null;
        long committeeOfficerCount = 0;
        if(askedToLevel-1 ==1){
            prevUser = getCommitteeOfficerCount(committeeId,1,2,envelopeId);
            committeeOfficerCount = prevUser.size();
        }else if(askedToLevel-1 == 2){
            prevUser =getCommitteeOfficerCount(committeeId,1,1,envelopeId);
            committeeOfficerCount =prevUser.size();
        }else if(askedToLevel-1 == 3){
            prevUser =getCommitteeOfficerCount(committeeId,2,2,envelopeId);
            committeeOfficerCount = prevUser.size();
        }else if(askedToLevel-1 == 4){
            prevUser =getCommitteeOfficerCount(committeeId,2,1,envelopeId);
            committeeOfficerCount = prevUser.size();
        }
        List<Object[]> lstBidderItems = getDistinctBidderItems(tenderId,prevUser);
        long bidderItemCount = getBidderItemCount(tenderId,userId,companyId);
        switch(askedToLevel){
            case 1 :
                if(reworkId==0 && bidderItemCount==0){
                    showLink = 1;//show link
                }else if(reworkId==0 && bidderItemCount>0){
                    showLink = 2;//show label Evaluated
                }else if(reworkId>0){
                    showLink = 1;//show link
                }
                break;
            case 2 :
            case 3 :
                boolean isPrevRemarksReceived2=false;
                if(lstBidderItems!=null && !lstBidderItems.isEmpty() && lstBidderItems.size()>=totalCmpCount){
                    int cnt = 0;
                    for(int i=0;i<lstBidderItems.size();i++){
                        long bidderWiseCount = Long.parseLong(lstBidderItems.get(i)[1].toString());
                        if(bidderWiseCount==committeeOfficerCount){
                            cnt = cnt+1;
                        }
                    }
                    if(cnt==lstBidderItems.size()){
                        isPrevRemarksReceived2=true;
                    }
                }
                
                if(isPrevRemarksReceived2){
                    if(reworkId==0 && bidderItemCount==0){
                        showLink = 1;//shoe link
                    }else if(reworkId==0 && bidderItemCount>0){
                        showLink = 2;//show label Evaluated
                    }else if(reworkId>0){
                        showLink = 1;
                    }
                    if(tempReworkId!=0){
                        showLink=0;//hide link
                    }
                }
                break;
            case 4 :
                boolean isPrevRemarksReceived4=false;
                if(lstBidderItems!=null && !lstBidderItems.isEmpty() && lstBidderItems.size()>=totalCmpCount){
                    int cnt = 0;
                    for(int i=0;i<lstBidderItems.size();i++){
                        long bidderWiseCount = Long.parseLong(lstBidderItems.get(i)[1].toString());
                        if(bidderWiseCount==committeeOfficerCount){
                            cnt = cnt+1;
                        }
                    }
                    if(cnt==lstBidderItems.size()){
                        isPrevRemarksReceived4=true;
                    }
                }
                if(isPrevRemarksReceived4){
                    if(bidderItemCount==0){
                        showLink = 1;//show link
                    }else if(bidderItemCount>0){
                        showLink = 2;//show label Evaluated
                    }
                    if(tempReworkId!=0){
                        showLink=0;//hide link
                    }
                }
                break;
        }
        //System.out.println("showLink =============:::::::::::> " + showLink);
        return showLink;
    }    
    
    public boolean showEvaluationRemark(int userId,int envelopeId,int askedToLevel,int committeeType,int tenderId) throws Exception {
        boolean showLink = false;
        //int reworkId=getReworkId(0,envelopeId,askedToLevel);
        int reworkId=getReworkId(0,envelopeId,userId);
        int tempReworkId = getTempReworkId(askedToLevel-1,envelopeId);
        int committeeId = getCommitteeId(tenderId);
        List<Object> prevUser = null;
        long committeeOfficerCount = 0;
        if(askedToLevel-1 ==1){
            prevUser = getCommitteeOfficerCount(committeeId,1,2,envelopeId);
            committeeOfficerCount = prevUser.size();
        }else if(askedToLevel-1 == 2){
            prevUser =getCommitteeOfficerCount(committeeId,1,1,envelopeId);
            committeeOfficerCount =prevUser.size();
        }else if(askedToLevel-1 == 3){
            prevUser =getCommitteeOfficerCount(committeeId,2,2,envelopeId);
            committeeOfficerCount = prevUser.size();
        }else if(askedToLevel-1 == 4){
            prevUser =getCommitteeOfficerCount(committeeId,2,1,envelopeId);
            committeeOfficerCount = prevUser.size();
        }
        List<Object[]> lstRemarks = getDistinctEvaluationRemark(committeeType,envelopeId,prevUser);
        switch(askedToLevel){
            case 1 :
                if(reworkId==0 && getEvaluationRemarkCount(envelopeId,userId,committeeType)==0){
                    showLink = true;
                }else if(reworkId>0){
                    showLink = true;
                }
                break;
            case 2 :
            case 3 :
                boolean isPrevRemarksReceived2=false;
                if(lstRemarks!=null && !lstRemarks.isEmpty()){
                    int cnt = 0;
                    for(int i=0;i<lstRemarks.size();i++){
                        long bidderWiseCount = Long.parseLong(lstRemarks.get(i)[1].toString());
                        if(bidderWiseCount==committeeOfficerCount){
                            cnt = cnt+1;
                        }
                    }
                    if(cnt==lstRemarks.size()){
                        isPrevRemarksReceived2=true;
                    }
                }
                if(isPrevRemarksReceived2){
                    if(reworkId==0 && getEvaluationRemarkCount(envelopeId,userId,committeeType)==0){
                        showLink = true;
                    }else if(reworkId>0){
                        showLink = true;
                    }
                    if(tempReworkId!=0){
                        showLink=false;
                    }
                }
                break;
            case 4 :
                boolean isPrevRemarksReceived4=false;
                if(lstRemarks!=null && !lstRemarks.isEmpty()){
                    int cnt = 0;
                    for(int i=0;i<lstRemarks.size();i++){
                        long bidderWiseCount = Long.parseLong(lstRemarks.get(i)[1].toString());
                        if(bidderWiseCount==committeeOfficerCount){
                            cnt = cnt+1;
                        }
                    }
                    if(cnt == lstRemarks.size()){
                        isPrevRemarksReceived4 = true;
                    }
                }
                if(isPrevRemarksReceived4){
                    if(getEvaluationRemarkCount(envelopeId,userId,committeeType)==0){
                        showLink = true;
                    }
                    if(tempReworkId!=0){
                        showLink=false;
                    }
                }
                break;
        }
        //System.out.println("showLink remark= " + showLink);
        return showLink;
    }    

    /**
     * To get form detail by formId
     *
     * @author nirav.modi
     * @param formId
     * @return TblTenderForm
     * @throws Exception
     */
    public TblTenderForm getTenderFormById(int formId) throws Exception {
        List<TblTenderForm> list = null;
        list = tblTenderFormDao.findTblTenderForm(FORMID, Operation_enum.EQ, formId);
        return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
    /**
     * To get form detail by formId
     *
     * @author nirav.modi
     * @param formId
     * @return TblTenderForm
     * @throws Exception
     */
    public List<TblFinalSubmission> getTblFinalSubmission(int tenderId) throws Exception {
        return tblFinalSubmissionDao.findTblFinalSubmission("tblTender.tenderId", Operation_enum.EQ, tenderId);
    }
    
    /**
     * Found whether entry matching given formId in TblRebateForm
     * 
     * @author purvesh
     * @param formId
     * @return
     * @throws Exception 
     */
    public boolean getRebateFormByFormId(int formId) throws Exception{

        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        count = hibernateQueryDao.countForNewQuery("TblRebateForm tblrebateform ","tblrebateform.tblTenderForm.formId ","tblrebateform.tblTenderForm.formId=:formId",var);
        return count!=0;
    }

    /**
     * Delete From
     * 
     * @author purvesh
     * @param tenderId
     * @param formId
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean deleteForm(int tenderId,int formId) throws Exception{
        int cnt = 0;
        //Start Bug Id  BUG ID : 25551 
        int isGrandTotalCase=1;
        Map<String, Object> varGrandTotalWise = new HashMap<String, Object>();
        varGrandTotalWise.put(TENDER_ID,tenderId);
        List<Object> tableListForItemwiseWinner = hibernateQueryDao.singleColQuery("select isItemwiseWinner from TblTender where tenderId=:tenderId", varGrandTotalWise);
        if(!tableListForItemwiseWinner.isEmpty()){
        	isGrandTotalCase=(Integer) tableListForItemwiseWinner.get(0); //isGrandTotalCase-0 GrandTotalcase,isGrandTotalCase-1 Itemwise
        }
        //End Bug Id  BUG ID : 25551 
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(FORMID,formId);
        List<Object> tableList = hibernateQueryDao.singleColQuery("select tbltendertable.tableId from TblTenderTable tbltendertable where tbltendertable.tblTenderForm.formId=:formId", var);
        if(!tableList.isEmpty()){
            var.clear();
            var.put(TENDER_ID, tenderId);        
            var.put(TABLEID,tableList.toArray());
            StringBuilder query = new StringBuilder();
            query.append("select tbltenderbiddermap.mapBidderId from TblTenderBidderMap tbltenderbiddermap left join tbltenderbiddermap.tblItemBidderMap tblitembiddermap ");
            query.append("with tblitembiddermap.tblTenderTable.tableId not in (:tableId) where tbltenderbiddermap.tblTender.tenderId=:tenderId and tblitembiddermap.mapBidderItemId is NULL");
            List<Object> mappedBidder = hibernateQueryDao.singleColQuery(query.toString(), var);
            var.clear();
            var.put(FORMID,formId);
            hibernateQueryDao.updateDeleteNewQuery("delete  from TblItemBidderMap tblitembiddermap where tblitembiddermap.tblTenderTable.tableId in (select tbltendertable.tableId from TblTenderTable tbltendertable where tbltendertable.tblTenderForm.formId=:formId)",var);
            //Condition Modified because of BUG ID : 25551 
            /*if(!mappedBidder.isEmpty() && isGrandTotalCase != 0){
                var.clear();
                var.put("mapBidderId", mappedBidder.toArray());
                hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderBidderMap tbltenderbiddermap where tbltenderbiddermap.mapBidderId in (:mapBidderId)", var);
            }*/
        }
        var.clear();
        var.put(FORMID,formId);
        hibernateQueryDao.updateDeleteNewQuery("delete  from TblDynReportFormMap tblDynReportFormMap where tblDynReportFormMap.tblTenderForm.formId=:formId",var);
        var.clear();
        var.put(FORMID,formId);
        var.put(TENDER_ID,tenderId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderForm tbltenderform where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.formId=:formId",var);        
        return cnt!=0;

    }
    /**
     * To get consortium column
     *
     * @author nirav.modi
     * @param tenderId
     * @return String
     * @throws Exception
     */
    public String isConsortiumAllowed(int tenderId) throws Exception {
        String data = null;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDER_ID, tenderId);
        list = hibernateQueryDao.getSingleColQuery("select tbltender.isConsortiumAllowed from TblTender tbltender where tbltender.tenderId=:tenderId", var);
        if (!list.isEmpty()) {
            data = list.get(0).toString();
        }
        return data;
    }

    /**
     * To get max sort order of tender
     *
     * @author nirav.modi
     * @param tenderId
     * @return String
     * @throws Exception
     */
    public int getFormMaxSortOrder(int tenderId,int envId) throws Exception {
        int data = 0;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDER_ID, tenderId);
        var.put("envId", envId);
        StringBuilder query = new StringBuilder();
        query.append(" select isnull(max(tbltenderform.sortOrder),0) from TblTenderForm tbltenderform ");
        query.append(" inner join tbltenderform.tblTenderEnvelope tbltenderenvelope ");
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderenvelope.tblEnvelope.envId=:envId ");
        list = hibernateQueryDao.singleColQuery(query.toString(), var);
        if (!list.isEmpty()) {
            data =(Integer) list.get(0);
        }
        return data;
    }

    /**
     * To publish envelope
     *
     * @author nirav.modi
     * @param formIds
     * @return boolean
     * @throws Exception
     */
    public boolean publishTenderEnvelope(String formIds,int userDetailId) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("userDetailId", userDetailId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderForm set cstatus=1, publishedBy=:userDetailId , publishedOn=getUTCDate() where formId in(" + formIds + ") ", var);
        return cnt != 0;
    }

    /**
     * to get no of tables filed from the table tbl_TenderForm
     *
     * @param formId
     * @return
     * @throws Exception
     */
    public List<Object> getNoOfTables(int formId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(FORMID, formId);
        return hibernateQueryDao.getSingleColQuery("select tbltenderform.noOfTables from TblTenderForm tbltenderform where tbltenderform.formId=:formId", var);
    }

    /**
     * To get all tender table by form id Use on tender form dashboard listing
     *
     * @author nirav.modi
     * @param formId
     * @return List {@code <Object[]>}
     * @throws Exception
     */
    public List<Object[]> getTenderTableList(int formId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(FORMID, formId);
        StringBuilder query = new StringBuilder();
        query.append("select tbltendertable.tableId, tbltenderform.formName, tbltendertable.tableName, ")
                .append("(select COUNT(tblTenderColumn.columnId) from TblTenderColumn tblTenderColumn where tblTenderColumn.tblTenderTable.tableId = tbltendertable.tableId), ")
                .append("(select COUNT(tblTenderColumn1.columnId) from TblTenderColumn tblTenderColumn1 where tblTenderColumn1.filledBy=4 and tblTenderColumn1.tblColumnType.columnTypeId !=").append(loadingFactor).append(" and tblTenderColumn1.tblTenderTable.tableId = tbltendertable.tableId), ")
                .append("(select COUNT(tblTenderCell.cellId) from TblTenderCell tblTenderCell where tblTenderCell.tblTenderTable.tableId = tbltendertable.tableId), ")
                .append("(select COUNT(tblTenderColumn2.columnId) from TblTenderColumn tblTenderColumn2 where tblTenderColumn2.tblTenderTable.tableId=tbltendertable.tableId and filledBy in (").append(bidder).append(",").append(auto).append(") AND dataType in (").append(numeric).append(",").append(money).append(",").append(moneyall).append(")), ")
                .append("(select count(tblTenderColumn.columnId) from TblTenderColumn tblTenderColumn where tblTenderColumn.tblTenderTable.tableId=tbltendertable.tableId and tblTenderColumn.tblTenderForm.formId=:formId and tblTenderColumn.filledBy!=2) ,")
                .append("(select COUNT(tbltenderformula.formulaId) from TblTenderFormula tbltenderformula  where tbltenderformula.tblTenderTable.tableId=tbltendertable.tableId), ")
                .append("(select COUNT(tblTenderColumn3.columnId) from TblTenderColumn tblTenderColumn3 where tblTenderColumn3.tblTenderTable.tableId=tbltendertable.tableId and filledBy in (").append(auto).append(") AND dataType in (").append(numeric).append(",").append(money).append(",").append(moneyall).append(")) ")
                .append("from  TblTenderTable tbltendertable inner join  tbltendertable.tblTenderForm tbltenderform where tbltendertable.tblTenderForm.formId=:formId order by tbltendertable.tableId ");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     * To get all tender list
     *
     * @author nirav.modi
     * @return List {@code <Object[]>}
     * @throws Exception
     */
    public List<Object[]> getTenderList() throws Exception {
        return hibernateQueryDao.createNewQuery("select tbltender.tenderId, tbltender.tenderNo from TblTender tbltender", null);
    }

    /**
     *
     * @param tenderTableList
     * @return
     * @throws Exception
     */
    public boolean addTenderTable(List<TblTenderTable> tenderTableList) throws Exception {
        boolean bSuccess = false;
        tblTenderTableDao.saveUpdateAllTblTenderTable(tenderTableList);
        bSuccess = true;
        return bSuccess;
    }

    /**
     *Get TblTenderTable details
     * @param formId
     * @param tableId
    * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getTableDetails(int formId, int tableId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(FORMID, formId);
        var.put("tableId", tableId);
        list = hibernateQueryDao.createNewQuery("select tbltendertable.noOfRows, tbltendertable.noOfCols, tbltendertable.tableName, tbltendertable.tableHeader, tbltendertable.tableFooter,tbltendertable.hasGTRow from TblTenderTable tbltendertable where tbltendertable.tblTenderForm.formId=:formId and tbltendertable.tableId=:tableId", var);
        return list;

    }

    /**
     *Get TenderTable Formula List
     * @param tableId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getFormulaColId(int tableId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId", tableId);
        list = hibernateQueryDao.createNewQuery("select tbltenderformula.tblTenderColumn.columnId, tbltenderformula.cellId, tbltenderformula.formula,tbltenderformula.formulaId, tbltenderformula.displayFormula,tbltenderformula.columnNo,tbltenderformula.validationMessage,tbltenderformula.formulaType,tbltenderformula.cellNo from TblTenderFormula tbltenderformula where tbltenderformula.tblTenderTable.tableId=:tableId", var);
        return list;

    }

    /**
     * Get Form FilledBy List
     *
     * @return {@code List<SelectItem>}
     */
    public List<SelectItem> getFilledBy(boolean isLoadingFacPresent) {
        List<SelectItem> filledBy = new ArrayList<SelectItem>();
        filledBy.add(new SelectItem("Officer", officer));
        filledBy.add(new SelectItem("Bidder", bidder));
        filledBy.add(new SelectItem("Auto", auto));
        if(isLoadingFacPresent){
        	filledBy.add(new SelectItem("Proxy Bid Column", proxy));
        }
        return filledBy;
    }

    /**
     * Get Form DataType List
     *
     * @return {@code List<SelectItem>}
     */
    public List<SelectItem> getDataType() {
        List<SelectItem> dataType = new ArrayList<SelectItem>();
        dataType.add(new SelectItem("Small Text", smalltext));
        dataType.add(new SelectItem("Long Text", longtext));
        dataType.add(new SelectItem("+No. without (.)", numeric));//Numeric
        dataType.add(new SelectItem("+No. with (.)", money));//Money (Positive)
        dataType.add(new SelectItem("All Numbers", moneyall));//Money (All)
        dataType.add(new SelectItem("Combo Box", combobox));
        dataType.add(new SelectItem("Date", date));
        dataType.add(new SelectItem("List Box", listBox));
        if(isFutureRelease){
            dataType.add(new SelectItem("Master Field", masterField));            
        }
        dataType.add(new SelectItem("Auto Number", autoNumber));
        return dataType;
    }

    /**
     * Get Form Show/Hide List
     *
     * @return {@code List<SelectItem>}
     */
    public List<SelectItem> getShowHide() {
        List<SelectItem> showHide = new ArrayList<SelectItem>();
        showHide.add(new SelectItem("Show", 1));
        showHide.add(new SelectItem("Hide", 0));
        return showHide;
    }

    public List<SelectItem> getCurrConv() {
        List<SelectItem> currConv = new ArrayList<SelectItem>();
        currConv.add(new SelectItem("No", 0));
        currConv.add(new SelectItem("Yes", 1));
        return currConv;
    }

    /**
     * Get ColumnType Master Data
     *
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getColumnType() throws Exception {
        return hibernateQueryDao.createNewQuery("select tblcolumntype.columnTypeId, tblcolumntype.lang" + WebUtils.getCookie(getServletRequest(), "locale").getValue() + " from TblColumnType tblcolumntype where tblcolumntype.isActive=1 order by tblcolumntype.lang" + WebUtils.getCookie(getServletRequest(), "locale").getValue() , null);
    }

    public HttpServletRequest getServletRequest() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return attr.getRequest();
    }

    /**
     * Method user for get Tender Column Details base on given tableId.
     *
     * @param tableId
     * @return {@code List<TblTenderColumn>}
     * @throws Exception
     */
    public List<TblTenderColumn> getTenderColumnByTableId(int tableId) throws Exception {
        return tblTenderColumnDao.findTblTenderColumn("tblTenderTable", Operation_enum.EQ, new TblTenderTable(tableId), "sortOrder", Operation_enum.ORDERBY, Operation_enum.ASC);
    }
    
    /**
     *Get Gov Columns for the Table
     * @param tableId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getGovColumn(int tableId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId", tableId);
        list = hibernateQueryDao.createNewQuery("select tbltendergovcolumn.tblTenderColumn.columnId, tbltendergovcolumn.columnNo, tbltendergovcolumn.cellId from TblTenderGovColumn tbltendergovcolumn where tbltendergovcolumn.tblTenderTable.tableId=:tableId", var);
        return list;

    }

    /**
     * Updates description of Matrix Headers and Cells
     * @param colHead List of Map(tenderColumnId,tenderColumnHeader)
     * @param cellVal List of Map(tenderCellId,tenderCellValue)
     * @param biddercell List of Map(tenderCellId,tenderCellDataType)
     * @param tableId
     * @return true for success; false for fail
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean updateFormHeadNCell(List<Map<Integer, String>> colHead, List<Map<Integer, String>> cellVal, List<Map<Integer, Integer[]>> biddercell, int tableId) throws Exception {
        boolean flag = colHead.isEmpty() && cellVal.isEmpty();
        int isTenderCellUpdated = 0;
        for (Map<Integer, String> col : colHead) {
            Set<Integer> colIds = col.keySet();
            for (Integer colId : colIds) {
                flag = updateColumnHeader(colId, col.get(colId));
            }
        }
        for (Map<Integer, String> cell : cellVal) {
            Set<Integer> cellIds = cell.keySet();
            for (Integer cellId : cellIds) {
                flag = updateCellValue(cellId, cell.get(cellId));
                isTenderCellUpdated = flag ? isTenderCellUpdated + 1 : isTenderCellUpdated;
            }
        }
        for (Map<Integer, Integer[]> cell : biddercell) {
            Set<Integer> cellIds = cell.keySet();
            for (Integer cellId : cellIds) {
                Integer[] data = cell.get(cellId);
                flag = updateCellDataType(cellId, data[0], data[1]);
                isTenderCellUpdated = flag ? isTenderCellUpdated + 1 : isTenderCellUpdated;
            }
        }
        if (isTenderCellUpdated != 0) {
            updateTableJson(tableId, tenderTabletoJSON(getTenderCellByTableId(tableId, 0)));
        }
        return flag;
    }

    /**
     *
     * @param columnId
     * @param columnHeader
     * @return
     * @throws Exception
     */
    public boolean updateColumnHeader(int columnId, String columnHeader) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("columnId", columnId);
        var.put("columnHeader", columnHeader);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderColumn set columnHeader=:columnHeader where columnId=:columnId", var);
        return cnt != 0;

    }

    /**
     *
     * @param cellId
     * @param cellValue
     * @return
     * @throws Exception
     */
    public boolean updateCellValue(int cellId, String cellValue) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("cellId", cellId);
        var.put("cellValue", cellValue);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderCell set cellValue=:cellValue where cellId=:cellId", var);
        return cnt != 0;

    }

    /**
     *
     * @param cellId
     * @param dataType
     * @param objectId
     * @return
     * @throws Exception
     */
    public boolean updateCellDataType(int cellId, int dataType, int objectId) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("cellId", cellId);
        var.put("dataType", dataType);
        var.put("objectId", objectId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderCell set dataType=:dataType , objectId=:objectId where cellId=:cellId", var);
        return cnt != 0;

    }

    /**
     * Create Form Matrix for the Tender Table
     * @param params map(operation_param_name,operation_param_value)
     * @param operation map(operation_name,flag)
     * @return true for success;false for fail
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addFormMatrix(Map<String, Object> params, Map<String, Boolean> operation) throws Exception {
        boolean flag = false;
        if (operation.containsKey("deleteFormCell")) {
        	if(Boolean.parseBoolean(params.get("isPriceBid").toString()) == true){ //Condition Added because of changes bugId:31783 
	            Map<String,Object> var = new HashMap<String, Object>();
	            var.put(TENDER_ID, (Integer) params.get("tenderId"));
	            var.put(TABLEID, (Integer) params.get("tableId"));
	            StringBuilder query = new StringBuilder();
	            query.append("select tbltenderbiddermap.mapBidderId from TblTenderBidderMap tbltenderbiddermap left join tbltenderbiddermap.tblItemBidderMap tblitembiddermap ");
	            query.append("with tblitembiddermap.tblTenderTable.tableId!=:tableId where tbltenderbiddermap.tblTender.tenderId=:tenderId and tblitembiddermap.mapBidderItemId is NULL");
	            List<Object> mappedBidder = hibernateQueryDao.singleColQuery(query.toString(), var);
	            var.clear();
	            var.put(TABLEID, (Integer) params.get("tableId"));
	            hibernateQueryDao.updateDeleteNewQuery("delete from TblItemBidderMap tblitembiddermap where tblitembiddermap.tblTenderTable.tableId=:tableId", var);
	            if(!mappedBidder.isEmpty()){
	                var.clear();
	                var.put("mapBidderId", mappedBidder.toArray());
	                hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderBidderMap tbltenderbiddermap where tbltenderbiddermap.mapBidderId in (:mapBidderId)", var);
	            }
        	}		
            deleteFormCell((Integer) params.get("tableId"));
            deleteSpecialFormula((Integer) params.get("formId"));            
        }

        if(operation.containsKey("updateIsGTFlag")) {
        	 Map<String,Object> var = new HashMap<String, Object>();
             var.put(TABLEID, (Integer) params.get("tableId"));
             hibernateQueryDao.updateDeleteNewQuery("update TblTenderTable set hasGTRow=0 where tableId=:tableId", var);
        }
        
        if (operation.containsKey("deleteFormula")) {
            if((Boolean) params.get("isGTWise")){
                if (operation.containsKey("delFormulaCell")) {
                    deleteCell((Integer) params.get("tableId"), (Integer) params.get("row"), 0, -1, true, (Integer) params.get("tenderId"));
                }else{
                    Map<String,Object> var = new HashMap<String, Object>();
                    var.put(TABLEID, (Integer) params.get("tableId"));
                    hibernateQueryDao.updateDeleteNewQuery("update TblTenderTable set hasGTRow=0 where tableId=:tableId", var);
                }
            }
            deleteFormula((Boolean) params.get("isGTWise"), (Integer) params.get("tableId"), (Set<Long>) params.get("changedColId"),
                    (Integer) params.get("row"), (String) params.get("formulaColId"));
        }

        if (operation.containsKey("addFormMatrix")) {
            addFormMatrix((List<TblTenderColumn>) params.get("tblTenderColumns"), (List<TblTenderCell>) params.get("tblTenderCells"),
                    (Integer) params.get("noOfRows"), (Integer) params.get("noOfCols"), (Integer) params.get("createdBy"), (Boolean) params.get("isEdit"));
        }

        if (operation.containsKey("updateGovCellId")) {
            updateGovCellId((Long) params.get("govColumnId"), (Long) params.get("cellId"));
        }
        
        if (operation.containsKey("addFormulaCell")) {
            addFormulaCell((List<TblTenderCell>) params.get("gtTenderCells"),  (Integer) params.get("gtRows"), (Integer) params.get("noOfCols"), (Integer) params.get("createdBy"));
        }

        /*if (operation.containsKey("deleteTenderProxyBid")) {
         deleteTenderProxyBid((String) params.get("proxyColId"));
         }

         if (operation.containsKey("updateBidderColumn")) {
         updateBidderColumn((String) params.get("bidderColId"));
         }

         if (operation.containsKey("updateOnFormRowDelete")) {
         updateOnFormRowDelete((Integer) params.get("tenderId"), (String) params.get("rowIds"), (Integer) params.get("createdBy"));
         }*/
        if (operation.containsKey("deleteFormCell") || operation.containsKey("deleteFormula")) {
	        List<Object[]> lst = getTenderNRebateCell((Integer) params.get("tenderId"));
	    	List<Integer> rebateCellId = new ArrayList<Integer>();
	    		for(Object[] cells : lst){
	    			if(cells[0]==null && cells[1]!=null){
	    				rebateCellId.add(Integer.parseInt(cells[1].toString()));
	    			}
	    		}
	    		if(rebateCellId.size() != 0)
	    			deleteRebateCellById(rebateCellId);
	    	
	    		if(getCountTblRebateForm((Integer) params.get("tenderId"))==0){
	    			deleteTblRebate((Integer) params.get("tenderId"));
	    		}
        }
        flag = true;
        return flag;
    }

    public String tenderTabletoJSON(List<TblTenderCell> cells) throws JSONException {
        JSONArray jSONArray = new JSONArray();
        int counter = 0;
        for (TblTenderCell tcm : cells) {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put(new StringBuilder().append(tcm.getCellNo()).append("_").append(tcm.getTblTenderColumn().getColumnNo())
                    .append("_").append(tcm.getRowId()).append("_").append(tcm.getDataType()).append("_")
                    .append(tcm.getTblTenderTable().getTableId()).append("_").append(tcm.getTblTenderColumn().getColumnId())
                    .append("_").append(tcm.getCellId()).append("_").append(tcm.getObjectId()).toString(),
                        (tcm.getDataType() == combobox || tcm.getDataType() == masterField || tcm.getDataType() == listBox) ? tcm.getObjectId() : tcm.getCellValue().replace("\t", " ").replace("\\r\\n", "<br/>"));
            jSONArray.put(counter, jSONObject);
            counter++;
        }
        return jSONArray.toString();
    }

    /**
     * Converts json into List
     * @param json
     * @return
     * @throws JSONException 
     */
    public List<TblTenderCell> _toCellMasters(String json) throws JSONException {
        List<TblTenderCell> cellMasters = new ArrayList<TblTenderCell>();
        if (json != null && !json.isEmpty()) {
            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jSONObject = jsonArray.getJSONObject(i);
                for (Iterator it = jSONObject.keys(); it.hasNext();) {
                    String key = it.next().toString();
                    String[] values = key.split("_");
                    cellMasters.add(new TblTenderCell(Integer.parseInt(values[6]), Integer.parseInt(values[0]), new TblTenderColumn(Integer.parseInt(values[5])), Integer.parseInt(values[3]), Integer.parseInt(values[2]), new TblTenderTable(Integer.parseInt(values[4])), jSONObject.getString(key),values.length==8 ? Integer.parseInt(values[7]) : 0));
                }
            }
        }
        return cellMasters;
    }

    /**
     *
     * @param tableId
     * @return
     * @throws Exception
     */
    public boolean deleteFormCell(int tableId) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId", tableId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderCell tbltendercell where tbltendercell.tblTenderTable.tableId=:tableId", var);
        return cnt != 0;

    }

    /**
     *
     * @param columnId
     * @return
     * @throws Exception
     */
    public boolean deleteFormula(int columnId) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("columnId", columnId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderFormula tbltenderformula where tbltenderformula.tblTenderColumn.columnId=:columnId", var);
        return cnt != 0;

    }

    /**
     *
     * @param tblTenderColumns
     * @param tblTenderCells
     * @param noOfRows
     * @param noOfCols
     * @param updatedBy
     * @param isEdit
     * @return
     * @throws Exception
     */
    public boolean addFormMatrix(List<TblTenderColumn> tblTenderColumns, List<TblTenderCell> tblTenderCells, int noOfRows, int noOfCols, int updatedBy, boolean isEdit) throws Exception {
        boolean bSuccess = false;
        int tableId = !tblTenderColumns.isEmpty() ? tblTenderColumns.get(0).getTblTenderTable().getTableId() : 0;
        if (isEdit) {
            deleteFormMatrix(tableId);
        }
        tblTenderColumnDao.saveUpdateAllTblTenderColumn(tblTenderColumns);
        tblTenderCellDao.saveUpdateAllTblTenderCell(tblTenderCells);
        if (noOfRows != 0 && noOfCols != 0) {
            bSuccess = updateTableRowCol(tableId, noOfRows, noOfCols, updatedBy) != 0;
        }
        if (!tblTenderColumns.isEmpty()) {
            List<TblTenderCell> tenderCells = getTenderCellByTableId(tblTenderColumns.get(0).getTblTenderTable().getTableId(), 0);
            Map<String, Object> var = new HashMap<String, Object>();
            var.put(TABLEID, tblTenderColumns.get(0).getTblTenderTable().getTableId());
            String jsonData = tenderTabletoJSON(tenderCells);
            var.put("jsonData", jsonData);
            int updated = hibernateQueryDao.updateDeleteNewQuery("update TblTenderMatrixJson set jsonData=:jsonData where tblTenderTable.tableId=:tableId", var);
            if (updated == 0) {
                TblTenderMatrixJson matrixJson = new TblTenderMatrixJson();
                matrixJson.setJsonData(jsonData);
                matrixJson.setTblTenderForm(new TblTenderForm(tblTenderColumns.get(0).getTblTenderForm().getFormId()));
                matrixJson.setTblTenderTable(new TblTenderTable(tblTenderColumns.get(0).getTblTenderTable().getTableId()));
                tblTenderMatrixJsonDao.addTblTenderMatrixJson(matrixJson);
            }
        }
        bSuccess = true;
        return bSuccess;
    }

    /**
     * Delete Formula
     *
     * @param isGTWise
     * @param tableId
     * @param changedColId
     * @param row
     * @param formulaColId
     * @return true/false for success/failure
     * @throws Exception
     */
    public boolean deleteFormula(boolean isGTWise, int tableId, Set<Long> changedColId, int row, String formulaColId) throws Exception {
        boolean flag = false;
        if (isGTWise) {
            List<Object[]> govCol = getGovColumn(tableId);
            if (!govCol.isEmpty()) {
                long columnId = changedColId.contains((Integer) govCol.get(0)[0]) ? (Integer) govCol.get(0)[0] : 0;
                if (columnId != 0) {
                    changeGovCol(tableId, columnId, isGTWise, row);
                }
            }
        }
        deleteFormula(formulaColId.substring(0, formulaColId.length() - 1));
        flag = true;
        return flag;
    }

    /**
     *
     * @param columnId
     * @param cellId
     * @return
     * @throws Exception
     */
    public boolean updateGovCellId(long columnId, long cellId) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("columnId", columnId);
        var.put("cellId", cellId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderGovColumn set cellId=:cellId where tblTenderColumn.columnId=:columnId", var);
        return cnt != 0;

    }

    /**
     * Remove Governing Column and Managing Cells for Grand Total Wise
     *
     * @param tableId
     * @param columnId
     * @param isGTW
     * @param rowCount
     * @return true/false for success/failure
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean changeGovCol(int tableId, long columnId, boolean isGTW, int rowCount) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        if (isGTW) {
            var.clear();
            var.put(TABLEID, tableId);
            var.put(COLUMNID, columnId);
            cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderGovColumn tbltendergovcolumn where tbltendergovcolumn.tblTenderTable.tableId=:tableId and tbltendergovcolumn.tblTenderColumn.columnId=:columnId", var);
        } else {
            var.clear();
            var.put(TABLEID, tableId);
            cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderGovColumn tbltendergovcolumn where tbltendergovcolumn.tblTenderTable.tableId=:tableId", var);
        }
        return cnt != 0;
    }

    /**
     * Delete Form Column from Form Matrix
     *
     * @param tableId
     * @return true/false for success/failure
     * @throws Exception
     */
    public boolean deleteFormMatrix(int tableId) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TABLEID, tableId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderColumn tbltendercolumn where tbltendercolumn.tblTenderTable.tableId=:tableId", var);
        return cnt != 0;

    }

    /**
     *
     * @param tableId
     * @param noOfRows
     * @param noOfCols
     * @param updatedBy
     * @return
     * @throws Exception
     */
    public int updateTableRowCol(int tableId, int noOfRows, int noOfCols, int updatedBy) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId", tableId);
        var.put("noOfRows", noOfRows);
        var.put("noOfCols", noOfCols);
        var.put("updatedBy", updatedBy);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderTable set noOfRows=:noOfRows , noOfCols=:noOfCols , updatedBy=:updatedBy , updatedOn=GETUTCDATE() where tableId=:tableId", var);
        return cnt;

    }

    /**
     * Delete Form formula
     *
     * @param columnId
     * @return true/false for success/failure
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean deleteFormula(String columnId) throws Exception {
        int cnt = 0;
        Map<String, Object> map = new HashMap<String, Object>();
        List<Integer> colIds = new ArrayList<Integer>();
        for (String colId : columnId.split(",")) {
            colIds.add(Integer.parseInt(colId));
        }
        map.put(COLUMNID, colIds);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderFormula tbltenderformula where tbltenderformula.tblTenderColumn.columnId in (:columnId)", map);
        return cnt != 0;

    }

    /**
     *
     * @param tblTenderTable
     * @return to add tender table details
     * @throws Exception
     */
    public boolean addTenderTable(TblTenderTable tblTenderTable) throws Exception {
        boolean bSuccess = false;
        List<TblTenderTable> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        
        int formId = tblTenderTable.getTblTenderForm().getFormId();
        tblTenderTableDao.addTblTenderTable(tblTenderTable);
	 	list = tblTenderTableDao.findTblTenderTable("tblTenderForm.formId",Operation_enum.EQ,formId);
      
        var.put("formId",formId);
        if(list!=null && !list.isEmpty()){
       	 var.put("noOfTables",list.size());
        } 
        hibernateQueryDao.updateDeleteNewQuery("update TblTenderForm set noOfTables=:noOfTables where formId=:formId",var);
        bSuccess=true;        
        return bSuccess;

    }

    /**
     *
     * @param formId
     * @return to get total no of table count for that table id
     * @throws Exception
     */
    public long getTableCountForSortOrder(int formId) throws Exception {

        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(FORMID, formId);
        count = hibernateQueryDao.countForNewQuery("TblTenderTable tbltendertable ", "tbltendertable.tableId ", "tbltendertable.tblTenderForm.formId=:formId", var);
        return count;
    }

    /**
     *To get tender table details on the basis of the table id
     * @param tableId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getTenderTableDetails(int tableId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId", tableId); 
        list = hibernateQueryDao.createNewQuery("select tbltendertable.tableId, tbltendertable.tblTenderForm.formId, tbltendertable.tableName, tbltendertable.tableHeader, tbltendertable.tableFooter,tbltendertable.isMultipleFilling,tbltendertable.noOfRows,tbltendertable.noOfCols,tbltendertable.sortOrder,tbltendertable.hasGTRow,(select count(tbltendercell.cellId) from TblTenderCell tbltendercell where tbltendercell.tblTenderTable.tableId=:tableId),tbltendertable.isMandatory,tbltendertable.isPartialFillingAllowed from TblTenderTable tbltendertable where tbltendertable.tableId=:tableId", var);
        return list;
    }

    /**
     * to update tender table details
     *
     * @param tblTenderTable
     * @return
     * @throws Exception
     */
    public boolean updateTenderTable(TblTenderTable tblTenderTable) throws Exception {
        boolean bSuccess = false;
        tblTenderTableDao.updateTblTenderTable(tblTenderTable);
        bSuccess = true;
        return bSuccess;
    }

    /**
     *Get Dynamic Combos created in client
     * @param clientId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getClientCombo(int clientId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId", clientId);
        list = hibernateQueryDao.createNewQuery("select tblcombo.comboId, tblcombo.comboName,tblcombo.comboType from TblCombo tblcombo where tblcombo.tblClient.clientId=:clientId and tblcombo.isActive=1", var);
        return list;

    }

    /**
     *Get MasterFields created for bidder master fields
     * @param linkId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getBidderMasterField(int linkId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("linkId", linkId);
        list = hibernateQueryDao.createNewQuery("select tblclientfield.clientFieldId, tbldynfield.fieldName from  TblClientField tblclientfield  inner join  tblclientfield.tblDynField tbldynfield where tblclientfield.tblLink.linkId=:linkId and tblclientfield.isActive=1", var);
        return list;

    }

    /**
     *Get TenderTable Formulas
     * @param tableId
     * @return{@code List<TblTenderFormula>}
     * @throws Exception
     */
    public List<TblTenderFormula> getTenderFormulaByTableId(int tableId) throws Exception {
        List<TblTenderFormula> list = null;
        list = tblTenderFormulaDao.findTblTenderFormula("tblTenderTable", Operation_enum.EQ, new TblTenderTable(tableId));
        return list;

    }   

    /**
     *Get TblTenderCell data is form of Json
     * @param tableId
     * @return Json String
     * @throws Exception
     */
    public String getTableJson(int tableId) throws Exception {
        String data = null;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId", tableId);
        list = hibernateQueryDao.getSingleColQuery("select tbltendermatrixjson.jsonData from TblTenderMatrixJson tbltendermatrixjson where tbltendermatrixjson.tblTenderTable.tableId=:tableId", var);
        if (!list.isEmpty()) {
            data = list.get(0).toString().replace("\\r\\n", "<br/>");
        }
        return data;
    }

    /**
     * Get Total Formula for GrandTotal Wise
     *
     * @param tableId
     * @param columnId
     * @return true/false for success/failure
     * @throws Exception
     */
    /*public boolean getTotalFormula(int tableId, int columnId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TABLEID, tableId);
        var.put(COLUMNID, columnId);
        count = hibernateQueryDao.countForNewQuery("TblTenderFormula tbltenderformula ", "tbltenderformula.formulaId ", "tbltenderformula.tblTenderColumn.columnId=:columnId and tbltenderformula.tblTenderTable.tableId=:tableId and formula like 'Total(%'", var);
        return count != 0;
    }*/

    /**
     * Get Governing CellId for RowId
     *
     * @param columnId
     * @param rowId
     * @return cellId
     * @throws Exception
     */
    /*public int getGovCell(int columnId, int rowId) throws Exception {
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(COLUMNID, columnId);
        var.put("rowId", rowId);
        list = hibernateQueryDao.getSingleColQuery("select tbltendercell.cellId from TblTenderCell tbltendercell where tbltendercell.tblTenderColumn.columnId=:columnId and tbltendercell.rowId=:rowId", var);
        return !list.isEmpty() ? (Integer) list.get(0) : 0;

    }*/
        
    /**
     * Create Formula for Form Matrix
     * @param tblTenderFormula  to be saved in DB
     * @param formulaCellAdd Total formula Cell to be added?
     * @param tblTenderCells formulaCellAdd ? add tblTenderCells : nothing
     * @param noOfRows Table row count
     * @param noOfCols Table column count
     * @param updatedBy 
     * @return true/false for success/failure
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addFormula(List<TblTenderFormula> tblTenderFormula, /*TblTenderGovColumn tblTenderGovColumn,//remgovcol*/
            boolean formulaCellAdd, List<TblTenderCell> tblTenderCells, int noOfRows, int noOfCols, int updatedBy) throws Exception {
        boolean bSuccess = false;
//        int actualCellId = 0;//remgovcol
        if (formulaCellAdd) {
            addFormulaCell(tblTenderCells, noOfRows, noOfCols, updatedBy);
            /*for (TblTenderCell tblTenderCell : tblTenderCells) {//remgovcol
                if (tblTenderGovColumn != null && tblTenderCell.getTblTenderColumn().getColumnId() == tblTenderGovColumn.getTblTenderColumn().getColumnId()) {
                    actualCellId = tblTenderCell.getCellId();
                }
            }*/
        }
        if (tblTenderFormula != null && !tblTenderFormula.isEmpty()) {
            tblTenderFormulaDao.saveUpdateAllTblTenderFormula(tblTenderFormula);
        }
        /*if (tblTenderGovColumn != null) {//remgovcol
            if (tblTenderGovColumn.getCellId() == 0) {
                tblTenderGovColumn.setCellId(actualCellId);
            }
            tblTenderGovColumnDao.addTblTenderGovColumn(tblTenderGovColumn);
        }*/
        bSuccess = true;
        return bSuccess;

    }

    /**
     * Add Extra Cells For GrandTotal
     *
     * @param tblTenderCells to be saved in DB
     * @param noOfRows
     * @param noOfCols
     * @param updatedBy
     * @return true/false for success/failure
     * @throws Exception
     */
    public boolean addFormulaCell(List<TblTenderCell> tblTenderCells, int noOfRows, int noOfCols, int updatedBy) throws Exception {
        boolean flag = false;
        int tableId = !tblTenderCells.isEmpty() ? tblTenderCells.get(0).getTblTenderTable().getTableId() : 0;
        tblTenderCellDao.saveUpdateAllTblTenderCell(tblTenderCells);
        flag = updateFormRowCol(tableId, noOfRows, noOfCols, updatedBy) != 0;
        List<TblTenderCell> cells = getTenderCellByTableId(tableId, 0);
        updateTableJson(tableId, tenderTabletoJSON(cells));
        return flag;
    }

    /**
     * Update Row, Column Count of Form Format
     *
     * @param tableId
     * @param noOfRows
     * @param noOfCols
     * @param updatedBy
     * @return no of DB rows update
     * @throws Exception
     */
    public int updateFormRowCol(int tableId, int noOfRows, int noOfCols, int updatedBy) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TABLEID, tableId);
        var.put("noOfRows", noOfRows);
        var.put("noOfCols", noOfCols);
        var.put("updatedBy", updatedBy);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderTable set noOfRows=:noOfRows , noOfCols=:noOfCols , updatedBy=:updatedBy , updatedOn=GETUTCDATE(),hasGTRow=1 where tableId=:tableId", var);
        return cnt;

    }

    /**
     *
     * @param tableId
     * @param jsonData
     * @return
     * @throws Exception
     */
    public boolean updateTableJson(int tableId, String jsonData) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId", tableId);
        var.put("jsonData", jsonData);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderMatrixJson set jsonData=:jsonData where tblTenderTable.tableId=:tableId", var);
        return cnt != 0;

    }

    /**
     * Delete From Formula     
     * @param formulaId
     * @param tableId
     * @param rowcount
     * @param columnId
     * @param isGTW
     * @return true/false for success/failure
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean deleteFormula(int formulaId, int tableId, int rowcount, long columnId, boolean isGTW,boolean deleteRebate,int tenderId) throws Exception {
        int cnt = 0;
        if (isGTW) {
            deleteCell(tableId, rowcount, columnId, formulaId,deleteRebate,tenderId);
        }
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formulaId", formulaId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderFormula tbltenderformula where tbltenderformula.formulaId=:formulaId", var);
        return cnt != 0;
    }

    private void deleteCell(int tableId, int rowCount, long columnId, int formulaId,boolean deleteRebate,int tenderId) throws Exception {
        boolean isdelCell = false;
        int formId = 0;
        List<Object[]> totalCols = getTotalFormula(tableId);
        if ((formulaId==-1 && totalCols.size() != 0) || (totalCols.size() == 1 && (Integer) totalCols.get(0)[0] == columnId && (Integer) totalCols.get(0)[1] == formulaId)) {
            formId = (Integer)totalCols.get(0)[2];            
            isdelCell = true;
        }
        if (isdelCell) {
            Map<String, Object> var = new HashMap<String, Object>();
            if(columnId!=0){
                var.put(TABLEID, tableId);
                var.put(COLUMNID, columnId);
                hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderGovColumn tbltendergovcolumn where tbltendergovcolumn.tblTenderTable.tableId=:tableId and tbltendergovcolumn.tblTenderColumn.columnId=:columnId", var);
            }
            if(deleteRebate){
                var.clear();
                var.put(TENDER_ID, tenderId);            
                hibernateQueryDao.updateDeleteNewQuery("delete from TblRebate tblrebate where tblrebate.tblTender.tenderId=:tenderId", var);
            }
            var.clear();
            var.put(TABLEID, tableId);
            var.put("rowId", rowCount);
            hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderCell tbltendercell where tbltendercell.tblTenderTable.tableId=:tableId and tbltendercell.rowId=:rowId", var);
            deleteSpecialFormula(formId);
            var.clear();
            var.put(TABLEID, tableId);
            hibernateQueryDao.updateDeleteNewQuery("update TblTenderTable set noOfRows=noOfRows-1,hasGTRow=0 where tableId=:tableId", var);
            List<TblTenderCell> cells = getTenderCellByTableId(tableId, 0);
            updateTableJson(tableId, tenderTabletoJSON(cells));
        }
    }

    /**
     * Get Total Formula for GrandTotal Wise
     *
     * @param tableId
     * @param columnId
     * @return true/false for success/failure
     * @throws Exception
     */
    public List<Object[]> getTotalFormula(int tableId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TABLEID, tableId);
        return hibernateQueryDao.createNewQuery("select tbltenderformula.tblTenderColumn.columnId,tbltenderformula.formulaId,tbltenderformula.tblTenderForm.formId from TblTenderFormula tbltenderformula where tbltenderformula.tblTenderTable.tableId=:tableId and tbltenderformula.formula like 'Total(%'", var);
    }

    /**
     *
     * @param formId
     * @return
     * @throws Exception
     */
    public List<TblTenderTable> getTenderTableByFormId(int formId) throws Exception {
        List<TblTenderTable> list = null;
        list = tblTenderTableDao.findTblTenderTable("tblTenderForm", Operation_enum.EQ, new TblTenderForm(formId));
        return list;

    }

    
    /**
     * @param formId
     * @return
     * @throws Exception
     */
    public List<TblTenderTable> getTenderTableByFormId(Object[] formId) throws Exception {
        List<TblTenderTable> list = null;
        list = tblTenderTableDao.findTblTenderTable("tblTenderForm.formId",Operation_enum.IN, formId);
        return list;

    }
    
    
    
    /**
     *
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderCurrency(int tenderId) throws Exception {
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        list = hibernateQueryDao.createNewQuery("select tblcurrency.currencyId, tblcurrency.lang1, case when tbltendercurrency.isDefault=1 then tblcurrency.currencyId else NULL end from  TblTenderCurrency tbltendercurrency  inner join  tbltendercurrency.tblCurrency tblcurrency where tbltendercurrency.tblTender.tenderId=:tenderId and tbltendercurrency.isActive=1", var);
        return list;
    }

    /**
     * to update the form status e.g cancel or approve
     *
     * @param formId
     * @param cStatus
     * @return boolean
     * @throws Exception
     */
    public boolean updateFormStatus(int formId, int cStatus,int actionBy) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(FORMID, formId);
        var.put("cstatus", cStatus);
        var.put("actionBy", actionBy);
        StringBuilder query = new StringBuilder();
        query.append("update TblTenderForm set cstatus=:cstatus,");
        if(cStatus==2){
            query.append("cancelledBy=:actionBy,cancelledOn=GETUTCDATE()");
        }else if(cStatus==1){
            query.append("publishedBy=:actionBy,publishedOn=GETUTCDATE()");
        }
        query.append(" where formId=:formId");                        
        cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
        return cnt != 0;
    }

    /**
     * @author nirav.modi
     * @param formId
     * @return  List<Object[]> 
     * @throws Exception 
     */
    public List<Object[]> getTenderFormDetails(int formId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(FORMID,formId);
        StringBuilder query = new StringBuilder();
        query.append("select tbltenderform.formName,tbltenderform.formHeader,tbltenderform.formFooter ,tbltenderform.isDocumentReq ,tbltenderform.isEncryptedDocument, ");
        query.append(" tbltenderform.isEncryptionReq ,tbltenderform.isEvaluationReq,tbltenderform.isMandatory,tbltenderform.isMultipleFilling,tbltenderform.isPriceBid,tbltenderform.isSecondary, ");
        query.append(" tbltenderform.noOfTables,tbltenderenvelope.envelopeId,tblenvelope.envId,tbltenderform.sortOrder,tbltenderform.cstatus,tbltenderform.isItemWiseDocAllowed from TblTenderForm tbltenderform ");
        query.append(" inner join tbltenderform.tblTenderEnvelope tbltenderenvelope");
        query.append(" inner join tbltenderenvelope.tblEnvelope tblenvelope");
        query.append(" where tbltenderform.formId=:formId  ");
        return hibernateQueryDao.createNewQuery(query.toString(),var); 
    }

    /**
     * Use case:Form Publish
     * @author nirav.modi
     * @param objectId
     * @return List{@code<Object[]>} 
     * @throws Exception
     */
    public List<Object[]> getTenderEnvelopeForPublish(int tenderId,boolean... isForResultSharing) throws Exception{
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDER_ID,tenderId);
        query.append("select distinct tbltenderenvelope.envelopeId,tbltenderenvelope.envelopeName,tbltenderenvelope.sortOrder from TblTenderEnvelope tbltenderenvelope ");
    	query.append(" inner join tbltenderenvelope.tblTenderForm tbltenderform ");
    	query.append(" where tbltenderenvelope.tblTender.tenderId=:tenderId ");
    	if(!(isForResultSharing.length>1)){
    		if(isForResultSharing[0]){
        		query.append(" and tbltenderform.cstatus = 1");    		
        	}else{
        		query.append(" and tbltenderform.cstatus = 0 ");
        	}	
    	}
    	query.append(" order by tbltenderenvelope.sortOrder");
        return  hibernateQueryDao.createNewQuery(query.toString(),var);                
    }
    /**
     *
     * @author urja.r
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getOrganizeTenderFormByTenderId(int tenderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select tbltenderform.formId,tbltenderform.formName,tbltenderform.tblTenderEnvelope.envelopeId,tbltenderform.isMandatory,tbltenderform.isSecondary,tbltenderform.sortOrder,tbltenderform.isPriceBid,tbltenderform.cstatus,tbltenderform.minTablesReqForBidding,tbltenderform.tblTenderEnvelope.tblEnvelope.envId")
                .append(" from TblTenderForm tbltenderform where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus!=2 order by tbltenderform.tblTenderEnvelope.envelopeId,tbltenderform.sortOrder");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     *
     * @author urja.r
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderEnvelopeFormCount(int tenderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select count(tbltenderform.formId),tbltenderform.tblTenderEnvelope.envelopeId")
                .append(" from TblTenderForm tbltenderform where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus!=2 group by tbltenderform.tblTenderEnvelope.envelopeId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    /**
     * @autehr mitesh
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderEnvelopeMinFormRequiredCount(int tenderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select tblTenderEnvelope.envelopeId, tblTenderEnvelope.minFormsReqForBidding,tblTenderEnvelope.minTechFormsReqForBidding ")
        .append(" from TblTenderEnvelope tblTenderEnvelope where tblTenderEnvelope.tblTender.tenderId=:tenderId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     * @author urja.r
     * @param request
     * @return
     * @throws Exception 
     */
    public boolean updateTederForm(HttpServletRequest request) throws Exception {
    	
   	 int corrigendumId = StringUtils.hasLength(request.getParameter("hdCorrigendumId")) ? Integer.parseInt(request.getParameter("hdCorrigendumId")) : 0;
   	 Map<String, Object> var = new HashMap<String, Object>();
   	 
        List<Integer> formIds=new ArrayList<Integer>();
	        for (int i = 1; i < Integer.parseInt(request.getParameter("hdtotalFeild")); i++) {
	        	formIds.add(Integer.parseInt(request.getParameter("hdformId" + i).toString()));
	        	if (request.getParameter("hdformId" + i) != null) {
	                var.put(FORMID, request.getParameter("hdformId" + i));
	            }
	        }
	        var.clear();
	       var.put("formId",formIds);
	       long count = hibernateQueryDao.countForNewQuery("TblTenderForm tbltenderform","tbltenderform.formId ","tbltenderform.formId in (:formId)",var);
        if(count!=formIds.size())
            return false;
        List<Integer> nonMandatoryForms=new ArrayList<Integer>();
        if(count==formIds.size()){
       	 var.clear();
       	 if(corrigendumId != 0){
       		 corrigendumIsMandatory(request,corrigendumId);
       	 }
       	 else
       	 {
       		 for (int i = 1; i < Integer.parseInt(request.getParameter("hdtotalFeild")); i++) {

       			 var = new HashMap<String, Object>();
       			 if (request.getParameter("hdformId" + i) != null) {
       				 var.put(FORMID, request.getParameter("hdformId" + i));
       			 }
       			 if (request.getParameter("selsortorder" + i) != null) {
       				 var.put("sortOrder", request.getParameter("selsortorder" + i));
       			 }
       			 if (request.getParameter("chkmandatory" + i) != null) {
       				 var.put("isMandatory", request.getParameter("chkmandatory" + i));
       			 }else if(request.getParameter("chktechmandatory" + i) != null){
       				 var.put("isMandatory", request.getParameter("chktechmandatory" + i));
       			 }
       			 else {
       				 var.put("isMandatory", 0);
       			 }
       			 if (request.getParameter("chksecondary" + i) != null) {
       				 var.put("isSecondary", request.getParameter("chksecondary" + i));
       			 } else {
       				 var.put("isSecondary", 0);
       			 }
       			 if (request.getParameter("selminTablesReqForBidding" + i) != null) {
       				 var.put("minTablesReqForBidding", request.getParameter("selminTablesReqForBidding" + i));
       			 } else {
       				 var.put("minTablesReqForBidding", 0);
       			 }
       			 hibernateQueryDao.updateDeleteNewQuery("update TblTenderForm set sortOrder=:sortOrder,isMandatory=:isMandatory,isSecondary=:isSecondary,minTablesReqForBidding=:minTablesReqForBidding where formId=:formId", var);
       			if(Integer.parseInt(var.get("isMandatory").toString())==0 && Integer.parseInt(var.get(FORMID).toString()) != 0) {
       				nonMandatoryForms.add(Integer.parseInt(var.get(FORMID).toString()));
       			}
       		 }
       	 }
        }
        if(nonMandatoryForms.size()>0) {
        	 var.clear();
        	 var.put("formIds", nonMandatoryForms);
        	 hibernateQueryDao.updateDeleteNewQuery("delete TblRebateForm  where tblTenderForm.formId in (:formIds)", var);
        }
       return true;
   }
    
    
    /**
     * @author Vijay
     * @param request
     * @return
     * @throws Exception
     * for corrigendum pending 
     */
    public boolean corrigendumIsMandatory(HttpServletRequest request,int corrigendumId) throws Exception {
    	List<TblCorrigendumDetail> corrigendumDetailsList=new ArrayList<TblCorrigendumDetail>();
    	List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        if(corrigendumId != 0){
	          String fieldName = "isMandatory";
	          hibernateQueryDao.updateDeleteNewQuery("delete from TblCorrigendumDetail tblCorrigendumDetail where tblCorrigendumDetail.tblCorrigendum.corrigendumId='"+corrigendumId+"' and fieldName in ('"+fieldName+"')", var);
        }
        for (int i = 0; i < Integer.parseInt(request.getParameter("hdtotalFeild")); i++)
        {
        	 if(request.getParameter("hdformId" + i)!=null)
        	 {
        	var = new HashMap<String, Object>();
            var.put("formid",request.getParameter("hdformId" + i));
            StringBuilder query = new StringBuilder();
            query.append("SELECT tbltenderform.isMandatory from ");
            query.append("TblTenderForm tbltenderform  where tbltenderform.formId=:formid and tbltenderform.cstatus=1 ");
            list = hibernateQueryDao.singleColQuery(query.toString(), var);
        	
            /*secondary partener problem solution*/
            if (request.getParameter("chksecondary" + i) != null) {
                var.put("isSecondary", request.getParameter("chksecondary" + i));
            } else {
                var.put("isSecondary", 0);
            }
            hibernateQueryDao.updateDeleteNewQuery("update TblTenderForm set isSecondary=:isSecondary where formId=:formid", var); 
            var.clear();
        	
        	if(corrigendumId!=0)//case of corrigendum
             { 
        	 if (request.getParameter("chkmandatory" + i) != null) 
            	 {
        		 if(list!=null && !list.isEmpty())
        		  {
	        		 if(Integer.parseInt(list.get(0).toString()) != Integer.parseInt(request.getParameter("chkmandatory" + i).toString()))
	             	  {
			        	 TblCorrigendumDetail corrigendumDetail=new TblCorrigendumDetail();
			             corrigendumDetail.setObjectId(Integer.parseInt(request.getParameter("hdformId" + i)));
			             corrigendumDetail.setActionType(2);
			             corrigendumDetail.setTblProcess(new TblProcess(4));
			             corrigendumDetail.setFieldLabel("");
			             corrigendumDetail.setFieldName("isMandatory");
			             corrigendumDetail.setOldValue("0");
			             corrigendumDetail.setNewValue(request.getParameter("chkmandatory" + i));
			             corrigendumDetail.setTblCorrigendum(new TblCorrigendum(corrigendumId));
			             corrigendumDetail.setCreatedBy(abcUtility.getSessionUserDetailId(request));
			             corrigendumDetailsList.add(corrigendumDetail);
	        	     } 
        	   }
        	}
          }
        tblCorrigendumDetailDao.saveUpdateAllTblCorrigendumDetail(corrigendumDetailsList);
        }
   	 
      }
        return true;
    
        }
    
    
    /**
	 * 
	 * @param tenderId
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> getTenderFormByTenderId(int tenderId) throws Exception
	{
		List<Object[]> list = null;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
      	query.append("select tblTenderForm.parentFormId,tblTenderForm.formId from TblTenderForm tblTenderForm where tblTenderForm.tblTender.tenderId=:tenderId and tblTenderForm.cstatus in (0,1)");
      	list=hibernateQueryDao.createQuery(query.toString(), var);
            return list;
	}
	
    /**
     * Feature:12239 Use case : Map Form from Form Library
     *
     * @param clientId
     * @param tenderId
     * @param envelopeId
     * @param formId
     * @param ipAddress
     * @param userId
     * @return boolean
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean mapTenderForm(int clientId, int tenderId, int envelopeId, String[]formIds, String ipAddress, int userDetailId,int isCopyForm) throws Exception {
    	boolean status = false;
    	for (String formId : formIds) {   
    		List<Map<String, Object>> list = jdbcTemplate.queryForList("EXEC [apptender].[P_ReviveBiddingForm] ?,?,?,?,?,?,?", clientId, tenderId, envelopeId, Integer.parseInt(formId), ipAddress, userDetailId,isCopyForm);
	        int newFormId=(Integer) list.get(0).get("result");
	        int isBiddingFormPublishWithTender = 0;
	        if(newFormId!=0){
	                List<Object[]> clientConfigList=commonService.getClientConfigurations(clientId);
	                if(!clientConfigList.isEmpty() && clientConfigList.size()>0){
	                    isBiddingFormPublishWithTender = Integer.parseInt(clientConfigList.get(0)[3].toString());
	                }
	                //if publishWithTender = allow than make entry in corridetail else
	                if(isBiddingFormPublishWithTender==1){
	                    tenderCorrigendumService.insertCorrigendumNewForm(newFormId,userDetailId,tenderId,isBiddingFormPublishWithTender);
	                }else{
	                	List<Object[]> tenderenvelopePublishCheck = getTenderEnvelopeForPublish(tenderId,true);
							if(tenderenvelopePublishCheck!=null && !tenderenvelopePublishCheck.isEmpty()){
								tenderCorrigendumService.insertCorrigendumNewForm(newFormId,userDetailId,tenderId,isBiddingFormPublishWithTender);
							}
	                }
	        	List<TblTenderTable> tables = getTenderTableByFormId(newFormId);
	        	for(TblTenderTable table : tables){
	        		List<TblTenderCell> tenderCells = getTenderCellByTableId(table.getTableId(), 0);
	        		String jsonData = tenderTabletoJSON(tenderCells);
	        		TblTenderMatrixJson matrixJson = new TblTenderMatrixJson();
	        		matrixJson.setJsonData(jsonData);
	        		matrixJson.setTblTenderForm(new TblTenderForm(newFormId));
	        		matrixJson.setTblTenderTable(new TblTenderTable(table.getTableId()));
	        		tblTenderMatrixJsonDao.addTblTenderMatrixJson(matrixJson);
	        	}
	        	status=true;
	        }
    	}
	    return status;
    }
    
    /**
     * This method is used for copy table functionality. PT : 33257.
     * @author jitendra
     * @param clientId
     * @param tenderId
     * @param formId
     * @param tableId
     * @param ipAddress
     * @param userDetailId
     * @param isCopywithValue
     * @return
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean mapTenderTable(int clientId, int tenderId, int formId, int envelopeId, int tableId, String ipAddress, int userDetailId, int isCopyTable) throws Exception {
    	boolean status = false;
    	List<Map<String, Object>> list = jdbcTemplate.queryForList("EXEC [apptender].[P_ReviveBiddingTable] ?,?,?,?,?,?,?,?", clientId, tenderId, envelopeId, formId, tableId, ipAddress, userDetailId, isCopyTable);
    	int newTableId = (Integer) list.get(0).get("result");
    	
    	if(newTableId != 0){
    		List<TblTenderCell> tenderCells = getTenderCellByTableId(newTableId, 0);
    		String jsonData = tenderTabletoJSON(tenderCells);
    		TblTenderMatrixJson matrixJson = new TblTenderMatrixJson();
    		matrixJson.setJsonData(jsonData);
    		matrixJson.setTblTenderForm(new TblTenderForm(formId));
    		matrixJson.setTblTenderTable(new TblTenderTable(newTableId));
    		tblTenderMatrixJsonDao.addTblTenderMatrixJson(matrixJson);
    		status = true;
    	}
    	return status;
    }
    
    /**
     * @Use To revive tender
     * @author nirav.modi
     * @param tenderId
     * @param createdBy
     * @param eventCount  number of tender to revive
     * @return boolean
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public String reviveTender(int tenderId,int createdBy,int userId,int isDocRevive,int clientId,int eventCount,int isFormRequire,int isDateRequire,int isEvaluateBidderRevive,int isTOCRevive,int isTECRevive) throws Exception{
    	boolean bSuccess = false; 
    	String newTenderId="";
    	Map<String, Object>  result= spReviveTender.executeProcedure(tenderId, createdBy,userId,isDocRevive,clientId,eventCount,isFormRequire,isDateRequire,isEvaluateBidderRevive,isTOCRevive,isTECRevive);
    	if(result !=null && !result.isEmpty()){
    		@SuppressWarnings("unchecked")
			List<Map<String, Object>> map= (List<Map<String, Object>>) result.get("#result-set-1");
    		if(map!=null && !map.isEmpty()){
    			String formIds= (String) map.get(0).get("formIds");
    			newTenderId=map.get(0).get("newTenderId").toString();
    			if(formIds!=null && !"".equalsIgnoreCase(formIds)){
	    			String formIdArr [] = formIds.split(",");
	    			for(int i=0;i<formIdArr.length;i++){
	    				int newFormId=Integer.parseInt(formIdArr[i].trim());
	    				if(newFormId!=0){
	    		        	List<TblTenderTable> tables = getTenderTableByFormId(newFormId);
	    		        	for(TblTenderTable table : tables){
	    		        		List<TblTenderCell> tenderCells = getTenderCellByTableId(table.getTableId(), 0);	    		        		
	    		        		String jsonData = tenderTabletoJSON(tenderCells);	    		        		
	    		        		TblTenderMatrixJson matrixJson = new TblTenderMatrixJson();
	    		        		matrixJson.setJsonData(jsonData);
	    		        		matrixJson.setTblTenderForm(new TblTenderForm(newFormId));
	    		        		matrixJson.setTblTenderTable(new TblTenderTable(table.getTableId()));
	    		        		tblTenderMatrixJsonDao.addTblTenderMatrixJson(matrixJson);
	    		        	}
	    		        }
	    			}
	    			bSuccess=true;
    			}else{
    				bSuccess=true;
    			}
    		}
    	}
    	return bSuccess?newTenderId:"";
    }
    /***
     * Get List of TblTenderCell
     * @param tableId
     * @param rowId
     * @return {@code List<TblTenderCell>}
     */
    public List<TblTenderCell> getTenderCellByTableId(int tableId, int rowId) throws Exception{
        StringBuilder query = new StringBuilder();
        Map<String,Object> var = new HashMap<String, Object>();
        var.put(TABLEID, tableId);
        query.append("select tbltendercell.cellId,tbltendercell.tblTenderForm.formId,tbltendercell.tblTenderTable.tableId,")
                .append("tbltendercell.tblTenderColumn.columnId,tbltendercell.rowId,tbltendercell.cellValue,tbltendercell.cellNo,tbltendercell.dataType,")
                .append("tbltendercell.objectId,tbltendercolumn.columnNo,tbltendercolumn.sortOrder ")
                .append("from TblTenderCell tbltendercell inner join tbltendercell.tblTenderColumn tbltendercolumn where ")
                .append("tbltendercell.tblTenderTable.tableId=:tableId");
        if (rowId != 0) {
          query.append(" and tbltendercell.rowId!=:rowId");
          var.put("rowId", rowId);
        }
        query.append(" order by tbltendercolumn.sortOrder,tbltendercell.rowId asc");
        List<Object[]> tableDesc = getTenderTableDetails(tableId);
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);
        List<TblTenderCell> tenderCells = toTenderCell(list);
//        System.out.println("GT : "+tableDesc.get(0)[9]);
        if(!tableDesc.isEmpty() && (Integer)tableDesc.get(0)[9]==1 && rowId==0){
            List<TblTenderCell> tempTenderCells = new ArrayList<TblTenderCell>();
            for (int i = 0; i < tenderCells.size(); i++) {
//                System.out.println("ROW : "+tableDesc.get(0)[6]);
                if((Integer)tableDesc.get(0)[6] == tenderCells.get(i).getRowId()){
//                    System.out.println("tenderCells : "+tenderCells);
                    tempTenderCells.add(tenderCells.get(i));
                    tenderCells.remove(i);
                }
            }
            tenderCells.addAll(tempTenderCells);
        }
        return tenderCells;
    }    
    
    /**
     * Get TenderCell List for Form 1st Row
     *
     * @param tableId
     * @return {@code List<TblTenderCell>}
     * @throws Exception
     */
    public List<TblTenderCell> getTenderCellByTableIdOneRow(int tableId) throws Exception {
        StringBuilder query = new StringBuilder();
        query.append("select tbltendercell.cellId,tbltendercell.tblTenderForm.formId,tbltendercell.tblTenderTable.tableId,")
                .append("tbltendercell.tblTenderColumn.columnId,tbltendercell.rowId,tbltendercell.cellValue,tbltendercell.cellNo,tbltendercell.dataType,")
                .append("tbltendercell.objectId,tbltendercolumn.columnNo,tbltendercolumn.sortOrder ")
                .append("from TblTenderCell tbltendercell inner join tbltendercell.tblTenderColumn tbltendercolumn where ")
                .append("tbltendercell.tblTenderTable.tableId=:tableId and tbltendercell.rowId=1")        
                .append(" order by tbltendercolumn.sortOrder,tbltendercell.rowId asc");       
        Map<String,Object> var = new HashMap<String, Object>();        
        var.put(TABLEID, tableId);
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);      
        return toTenderCell(list);
    }
    
    private List<TblTenderCell> toTenderCell(List<Object[]> list){
        List<TblTenderCell> tenderCells = new ArrayList<TblTenderCell>();
        for (Object[] cells : list) {
            TblTenderCell tblTenderCell = new TblTenderCell();
            tblTenderCell.setCellId((Integer)cells[0]);
            tblTenderCell.setTblTenderForm(new TblTenderForm((Integer)cells[1]));
            tblTenderCell.setTblTenderTable(new TblTenderTable((Integer)cells[2]));
            TblTenderColumn tblTenderColumn = new TblTenderColumn((Integer)cells[3]);
            tblTenderColumn.setColumnNo((Integer)cells[9]);
            tblTenderColumn.setSortOrder((Integer)cells[10]);
            tblTenderCell.setTblTenderColumn(tblTenderColumn);
            tblTenderCell.setRowId((Integer)cells[4]);
            tblTenderCell.setCellValue(cells[5].toString());
            tblTenderCell.setCellNo((Integer)cells[6]);
            tblTenderCell.setDataType((Integer)cells[7]);
            tblTenderCell.setObjectId((Integer)cells[8]);
            tenderCells.add(tblTenderCell);
        }
        return tenderCells;
    }
    
    /**
     * Set Form/Formula GET     
     * @param formId
     * @param modelMap
     * @param tenderId
     * @throws Exception 
     */
    public void setViewFormNFormula(int formId, Map<String, Object> modelMap, int tenderId) throws Exception {
    	List<Integer> tableIds = new ArrayList<Integer>();
        TblTenderForm tblTenderForm = getTenderFormById(formId);
        modelMap.put("tblTenderForm", tblTenderForm);
        modelMap.put("formName", tblTenderForm.getFormName());
        modelMap.put("formHeader", tblTenderForm.getFormHeader());
        modelMap.put("formFooter", tblTenderForm.getFormFooter());
        modelMap.put("noOfTables", tblTenderForm.getNoOfTables());
        modelMap.put("itemsToLoad", tblTenderForm.getLoadNoOfItems());
        modelMap.put("itemsIncremental", tblTenderForm.getIncrementItems());
        modelMap.put("encryptionReq", tblTenderForm.getIsEncryptionReq());
        modelMap.put("itemWiseDocAllowed",tblTenderForm.getIsItemWiseDocAllowed()==1?true:false);
        List<TblTenderTable> tables = getTenderTableByFormId(formId);
        if(tables.size()>0)
        	{
        		Collections.sort(tables);
        	}
        List<String> activatetableRows = new ArrayList<String>();
        List<String> itemSelectionList = new ArrayList<String>();
        List<Object[]> visibleRows = new ArrayList<Object[]>();
        List<Object[]> activateItems = new ArrayList<Object[]>();
        List<SelectItem> currency = null;
        Set<Integer> comboBoxs = new HashSet<Integer>();
        Set<Integer> listBoxs = new HashSet<Integer>();
        Set<Integer> masterFields = new HashSet<Integer>();
        List<Integer> formulaColId = new ArrayList<Integer>();        
        List<Integer> emdColId = new ArrayList<Integer>();
        List<Integer> emdColOfficerId = new ArrayList<Integer>();
        List<Integer> participationColOfficerId = new ArrayList<Integer>();
        List<Integer> notEncrColId = new ArrayList<Integer>(); 
        List<Integer> docColId = new ArrayList<Integer>();
        List<Integer> docColOfficerId = new ArrayList<Integer>();
        List<Integer> processColId = new ArrayList<Integer>();        
        List<Integer> emdCellId = new ArrayList<Integer>(); 
        List<Integer> docCellOfficerId = new ArrayList<Integer>(); 
        List<Integer> emdCellOfficerId = new ArrayList<Integer>();
        List<Integer> participationCellOfficerId = new ArrayList<Integer>(); 
        List<Integer> notEncrCellId = new ArrayList<Integer>();
        List<Integer> docCellId = new ArrayList<Integer>();        
        List<Integer> processCellId = new ArrayList<Integer>();        
        List<Integer> formulaColNo = new ArrayList<Integer>();
        List<Integer> negotiationLoadingCells = new ArrayList<Integer>();
        List<Integer> negotiationLoadingColumns = new ArrayList<Integer>();
        List<Map<String, Object>> tableList = new ArrayList<Map<String, Object>>();   
        Map<Integer,String> proxyData = new HashMap<Integer, String>();
        List<String> mappedBidderRows = new ArrayList<String>();
        int bidId = 0;
        boolean showDownload = true;
        boolean fromBidForm = false;
        boolean frombidfactor = false;
        boolean negotiationBuyerForLoading = false;
        boolean negotiationBidderForLoading = false;
        boolean isExcelAutoSubmitAllowed = true;
        List<TblTenderBidMatrix> bidMatrixs = null;                        
        List<TblMasterBid> masterBids = null;             
        if(modelMap.get("fromBidForm")!=null){
            fromBidForm = (Boolean)modelMap.get("fromBidForm");            
        }
        if(modelMap.get("negotiationBuyerForLoading")!=null){ 		//Start CR : 25886
        	negotiationBuyerForLoading = (Boolean)modelMap.get("negotiationBuyerForLoading");            
        }
        if(modelMap.get("negotiationBidderForLoading")!=null){
        	negotiationBidderForLoading = (Boolean)modelMap.get("negotiationBidderForLoading");            
        } //End CR : 25886
        if(modelMap.get("isItemSelectionPageRequired")!=null && (Integer) modelMap.get("isItemSelectionPageRequired")==1){
            if(tblTenderForm.getIsPriceBid()==1){
               visibleRows = getSelectedRowsForBidding(formId, (Integer) modelMap.get("companyId"));
            }else{
                modelMap.put("isItemSelectionPageRequired", 0);
            }
        }else{            
            modelMap.put("isItemSelectionPageRequired", 0);
        }
		if (modelMap.get("isItemwiseRegretAllowed") != null && ((Integer) modelMap.get("isItemwiseRegretAllowed") == 1
				|| (Integer) modelMap.get("isItemwiseRegretAllowed") == 3)) {

			if (tblTenderForm.getIsPriceBid() == 1) {

				activateItems = eventBidSubmissionService.getRegretActivateItem(tenderId, formId, 0,
						(Integer) modelMap.get("companyId"));

				modelMap.put("isItemwiseRegretAllowed", 1);

			} else {

				modelMap.put("isItemwiseRegretAllowed", 0);

			}

		}

	       if(modelMap.get("bidId")!=null && (Integer)modelMap.get("bidId")!=0){
            bidId = (Integer)modelMap.get("bidId");
            bidMatrixs = getTenderBidMatrixByBidId(bidId);
        }
        if(fromBidForm && bidId==0 && tblTenderForm.getMasterFormId()!=0){
            masterBids = masterFormService.getMasterBid(tblTenderForm.getMasterFormId(),(Integer) modelMap.get("companyId"));
        }
        if(modelMap.get("frombidfactor")!=null){
            frombidfactor = (Boolean)modelMap.get("frombidfactor");            
        }
        boolean isBidRowLimited = false;
        List<Object[]> bidTableRow = null;
        List<Object> itemBidderTableList = new ArrayList<Object>();
        List<Object> itemTableList = new ArrayList<Object>();
        //Below Condition Modified Because of bug id : #25751
        if(fromBidForm && ((Integer)modelMap.get("tenderMode")==2 || (Integer)modelMap.get("tenderMode")==3 || (Integer)modelMap.get("tenderMode")==4) && (Integer)modelMap.get("tenderResult")==2 && tblTenderForm.getIsPriceBid()==1){
            isBidRowLimited = true;
            bidTableRow = getBidderItem(tenderId, (Integer)modelMap.get("bidderId"));
            
           // #PT :Map bidder for the whole event
            for(TblTenderTable tblTenderTable:tables) {
            	itemTableList.add(tblTenderTable.getTableId());
            }
            itemBidderTableList=getBidderTables(tenderId, (Integer)modelMap.get("bidderId"),itemTableList);
            if(itemBidderTableList!=null && !itemBidderTableList.isEmpty()) {
            	 tables=null;
                 tables=this.getTblTenderTables(itemBidderTableList.toArray());
                 int minTablesReqForBidding=0;
                 for(TblTenderTable tblTenderTable:tables) {
                 	if(tblTenderTable.getIsMandatory()==1) {
                 		minTablesReqForBidding++;
                 	}
                 }
                 tblTenderForm.setMinTablesReqForBidding(minTablesReqForBidding);
            }
          // #PT :Map bidder for the whole event
        }    
        int isFillByBidder = 0;
        boolean isFillByBidderColumnExist=false;
        modelMap.put("isBidRowLimited", isBidRowLimited);
        for (TblTenderTable tenderTable : tables) {
            Map<String, Object> tableInfo = new HashMap<String, Object>();
            boolean isGTWise = tenderTable.getHasGTRow() == 1;
            List<Object[]> allFormula = getFormulaColId(tenderTable.getTableId());
            for (Object[] formula : allFormula) {
                if (formula[2].toString().startsWith(TOTAL)) {
                    formulaColId.add((Integer) formula[0]);
                    formulaColNo.add((Integer) formula[5]);
                }
            }            
            /*if(bidId!=0){
                List<String> bidDatas = new ArrayList<String>();
                List<String> bidTableIds = new ArrayList<String>();
                List<Object[]> itemWiseDocs = new ArrayList<Object[]>();
                Map<String,List<Object[]>> docMap = new HashMap<String, List<Object[]>>();
                for (TblTenderBidMatrix tblTenderBidMatrix : bidMatrixs) {
                      if(tblTenderBidMatrix.getTblTenderTable().getTableId() == tenderTable.getTableId()){
                          bidDatas.add(tblTenderBidMatrix.getBidJson());
                          bidTableIds.add(encryptDecryptUtils.encrypt(String.valueOf(tblTenderBidMatrix.getBidTableId())));
                          itemWiseDocs = getItemWiseDocs(tblTenderBidMatrix.getBidTableId());
                          for(Object[] docs : itemWiseDocs){
                        	  List<Object[]> list = null;
                        	  if(docMap.containsKey(encryptDecryptUtils.encrypt(docs[1].toString())+"_"+docs[3].toString())){
                        		 list = docMap.get(encryptDecryptUtils.encrypt(docs[1].toString())+"_"+docs[3].toString());                        		 
                        	  }else{
                        		  list = new ArrayList<Object[]>();                        		  
                        	  }
                        	  if(list!=null){
	                        	  list.add(docs);
	                     		  docMap.put(encryptDecryptUtils.encrypt(docs[1].toString())+"_"+docs[3].toString(), list);
                        	  }
                          }
                      }
                }
                tableInfo.put("bidData", bidDatas);
                tableInfo.put("bidTableId", bidTableIds);
                tableInfo.put("itemWiseDocs", docMap);
            }*/
            if(isExcelAutoSubmitAllowed != false && (tenderTable.getIsPartialFillingAllowed() == 1 || tenderTable.getIsMandatory() == 0)) {
            	isExcelAutoSubmitAllowed = false;
            }
            getDetailEncryptBidMatrix(bidMatrixs, tenderTable, bidId, tableInfo);
            List<Integer> visibleRow = new ArrayList<Integer>();
            for (Object[] rows : visibleRows) {
                if((Integer)rows[0] == tenderTable.getTableId()){
                    visibleRow.add((Integer)rows[1]);
                    itemSelectionList.add(tenderTable.getTableId()+"_"+(Integer.parseInt(rows[1].toString())-1));
                }
            }
            List<Integer> activateItem = new ArrayList<Integer>();
            for (Object[] rows : activateItems) {
                if((Integer)rows[1] == tenderTable.getTableId()){
                	activateItem.add(Integer.parseInt(rows[2].toString()));
                	activatetableRows.add(tenderTable.getTableId()+"_"+(Integer.parseInt(rows[2].toString())-1));
                }
            }
            
            /* PT : #51983 By Jitendra. Start */
            List<Object[]> bidderRowDetails = new ArrayList<Object[]>();
            List<Integer> biddedRow = new ArrayList<Integer>();
            if(modelMap.get("isFromItemWise") != null && (Boolean)modelMap.get("isFromItemWise") && (Integer)modelMap.get("isPartialFillingAllowed")==1){
            	bidderRowDetails = getBiddedRowDetails(tenderTable.getTableId());
            }
            for(Object[] rows : bidderRowDetails){
            	if((Integer)rows[0] == tenderTable.getTableId()){
            		biddedRow.add((Integer)rows[1]);
            	}
            }
            tableInfo.put("biddedRow", biddedRow);
            /* PT : #51983 By Jitendra. End */
            
            tableInfo.put("visibleRow", visibleRow);
            tableInfo.put("activateItem", activateItem);
            tableInfo.put("rowcount", isGTWise ? (tenderTable.getNoOfRows() - 1) : tenderTable.getNoOfRows());
            tableInfo.put("multipleFill", tenderTable.getIsMultipleFilling());
            tableInfo.put("colcount", tenderTable.getNoOfCols());
            tableInfo.put("tableName", tenderTable.getTableName());
            tableInfo.put("tableHeader", tenderTable.getTableHeader());
            tableInfo.put("tableFooter", tenderTable.getTableFooter());
            tableInfo.put(TABLEID, tenderTable.getTableId());
            tableIds.add(tenderTable.getTableId());
            tableInfo.put("formulaColId", formulaColId);
            tableInfo.put("formulaColNo", formulaColNo);
            tableInfo.put("isGTWise", isGTWise);
            tableInfo.put("formulas", allFormula);
            tableInfo.put("isPartialFillingAllowed", tenderTable.getIsPartialFillingAllowed());
            tableInfo.put("isMandatory", tenderTable.getIsMandatory());
            Map<Integer,Integer> colVsSortNoMap = new HashMap<Integer, Integer>();
            List<Integer> dateColSortNo = new ArrayList<Integer>();
            List<TblTenderColumn> columns = getTenderColumnByTableId(tenderTable.getTableId());
            boolean isCurrency = false;
            boolean hasProxyCol = false;
            StringBuilder colFilledBy = new StringBuilder();
            for (TblTenderColumn tblTenderColumn : columns) {
	            	if(negotiationBuyerForLoading==true || negotiationBidderForLoading==true) //For Negotiation Loading Factor Condition  //Start CR : 25886
	            	{
	            		if(tblTenderColumn.getTblColumnType().getColumnTypeId()==23 || tblTenderColumn.getTblColumnType().getColumnTypeId()==26 || tblTenderColumn.getTblColumnType().getColumnTypeId()==27){
	            			tblTenderColumn.setIsShown(1);
	            			if(negotiationBidderForLoading==true){
	                			negotiationLoadingColumns.add(tblTenderColumn.getColumnId());
	                		}
	            		}
	            		tableInfo.put("negotiationLoadingColumns", negotiationLoadingColumns);
	            	}
	            	 //End CR : 25886
                colFilledBy.append("'").append(tblTenderColumn.getColumnNo()).append("@@").append(tblTenderColumn.getFilledBy()).append("_").append(tblTenderColumn.getTblColumnType().getColumnTypeId()).append("_").append(tblTenderColumn.getIsShown()).append("'").append(",");
                if (tblTenderColumn.getTblColumnType().getColumnTypeId() == 8) {
                    isCurrency = true;                    
                }
//                for (Integer columnId : formulaColId) {
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == processingFeesId) {
                        processColId.add(tblTenderColumn.getColumnId());
                    }            
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == documentFeesId) {
                        docColId.add(tblTenderColumn.getColumnId());
                        isFillByBidder=1;
                        isFillByBidderColumnExist=true;
                    }
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == documentFeesByOfficerId) {
                        docColOfficerId.add(tblTenderColumn.getColumnId());
                        isFillByBidder=2;
                    }  
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == emdAmountId) {
                        emdColId.add(tblTenderColumn.getColumnId());
                        isFillByBidder=1;
                        isFillByBidderColumnExist=true;
                    }
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == emdAmountByOfficerId) {
                        emdColOfficerId.add(tblTenderColumn.getColumnId());
                        isFillByBidder=2;
                    }
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == participationFeesByOfficerId) {
                    	participationColOfficerId.add(tblTenderColumn.getColumnId());
                        isFillByBidder=2;
                    }
                    
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == notEncrReqId) {
                        notEncrColId.add(tblTenderColumn.getColumnId());
                    }
                    
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == loadingFactor && tblTenderColumn.getFilledBy() == 4) {
                    	if(modelMap.containsKey("loadingFactorForm"))
                    	{
                    		Map<Object,Object> loadingFactorForm = (Map<Object, Object>) modelMap.get("loadingFactorForm");
                    		loadingFactorForm.put(tblTenderColumn.getTblTenderForm().getFormId(), tblTenderColumn.getTblTenderForm().getFormId());
                    	}else{
                    		Map<Object,Object> loadingFactorForm = new HashMap<Object, Object>();
                    		loadingFactorForm.put(tblTenderColumn.getTblTenderForm().getFormId(), tblTenderColumn.getTblTenderForm().getFormId());
                    		modelMap.put("loadingFactorForm",loadingFactorForm);
                    	}
                    	if(modelMap.containsKey("loadingFactorTable"))
                    	{
                    		Map<Object,Object> loadingFactorTable= (Map<Object, Object>) modelMap.get("loadingFactorTable");
                    		loadingFactorTable.put(tblTenderColumn.getTblTenderTable().getTableId(), tblTenderColumn.getTblTenderTable().getTableId());
                    	}else{
                    		Map<Object,Object> loadingFactorTable = new HashMap<Object, Object>();
                    		loadingFactorTable.put(tblTenderColumn.getTblTenderTable().getTableId(), tblTenderColumn.getTblTenderTable().getTableId());
                    		modelMap.put("loadingFactorTable",loadingFactorTable);
                    	}
                    }
//                }
                if (tblTenderColumn.getFilledBy() == proxy) {
                    hasProxyCol = true;                    
                }
                if((isFillByBidder==1 ||  isFillByBidder == 2) && modelMap.get("companyId")!=null ){
                	List <TblEventFees> lstTenderFees= new ArrayList<TblEventFees>();
                	if(bidId!=0){
                		lstTenderFees = getTenderFeesPaymentDetail(tenderId,(Integer)modelMap.get("companyId"),formId, tblTenderColumn.getTblTenderTable().getTableId(),-1, bidId,0);
                	}else{
                    		lstTenderFees = getTenderFeesPaymentDetail(tenderId,(Integer)modelMap.get("companyId"),formId, tblTenderColumn.getTblTenderTable().getTableId(),-1, 0,0);	
                	}
                		if(lstTenderFees!=null && !lstTenderFees.isEmpty()  ){
            			  Map<String,Integer> rowId = new HashMap<String,Integer>();
	            			for (TblEventFees tblTenderFees :lstTenderFees){
	            					rowId.put(tblTenderFees.getRowId()+"_"+tblTenderFees.getFeeType(),tblTenderFees.getFeeType());
	            			}
	            			modelMap.put("rowId",rowId);
            			}
            		}
                colVsSortNoMap.put(tblTenderColumn.getColumnNo(), tblTenderColumn.getSortOrder());
                if(tblTenderColumn.getDataType() == 7) {
                	dateColSortNo.add(tblTenderColumn.getSortOrder());
                }
            }
            JSONObject colVsSortNoMapObj = new JSONObject(colVsSortNoMap);
            tableInfo.put("colVsSortNoMap", colVsSortNoMapObj.toString());
            tableInfo.put("dateColSortNo", dateColSortNo);
            if (colFilledBy.length() != 0) {
                tableInfo.put("colFilledBy", colFilledBy.delete(colFilledBy.length() - 1, colFilledBy.length()));                
                //System.out.println(tableInfo.get("colFilledBy"));
            }
            if(hasProxyCol && (fromBidForm || frombidfactor)){
                List<Object[]> proxyColData = getProxyCellData(tenderTable.getTableId(), (Integer)modelMap.get("companyId"));                                
                JSONArray jSONArray = new JSONArray();        
                for (int i=0;i<proxyColData.size();i++) {
                    Object[] proxyD = proxyColData.get(i);
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put(proxyD[0].toString(),proxyD[1].toString());
                    if(frombidfactor){
                        proxyData.put((Integer)proxyD[0], proxyD[1].toString());
                    }
                    jSONArray.put(i, jSONObject);
                }
                tableInfo.put("proxyData", jSONArray.toString());
                tableInfo.put("cellValueProxyData",proxyData); //For NegotiationHistory  //Start CR : 25886
            }
            if (isCurrency) {
                showDownload=false;
                if(currency==null){                    
                    currency = fromBidForm ? abcUtility.convert(getBidderCurrency(tenderId, (Integer)modelMap.get("companyId"))) : abcUtility.convertSelected(getTenderCurrency(tenderId));
                }
                tableInfo.put("tenderCurrency", currency);
            }
            tableInfo.put("columns", columns);
            if (!columns.isEmpty()) {
//                    List<TblTenderCell> cells = getCellMasterByTableId(tenderTable.getTableId(), isGTWise ? (rowCount) : 0);
                String tableJson = getTableJson(tenderTable.getTableId());                
                tableInfo.put("tableJson", tableJson);
                List<TblTenderCell> cells = _toCellMasters(tableJson);
                List<TblTenderCell> bidcells = new ArrayList<TblTenderCell>();
                Set<Integer>  bidderRow = new TreeSet<Integer>();                                
                for (TblTenderCell tenderCell : cells) {
                	
                	if(negotiationBidderForLoading==true) //For Negotiation Loading Factor Condition  Start CR : 25886
                	{
                		for(Integer column :negotiationLoadingColumns){
                			if(column==tenderCell.getTblTenderColumn().getColumnId()){
                				negotiationLoadingCells.add(tenderCell.getCellId());
                			}
                		}
                		tableInfo.put("negotiationLoadingCells", negotiationLoadingCells);
                	}  //End CR : 25886
                	if(isBidRowLimited && bidTableRow!=null){
                        for (Object[] bidcell: bidTableRow) {
                            if((Integer)bidcell[0] == tenderTable.getTableId() && (Integer)bidcell[1] == tenderCell.getRowId()){                                
                                bidderRow.add(tenderCell.getRowId());
                                bidcells.add(tenderCell);
                            }
                        }
                        if(isGTWise && tenderTable.getNoOfRows() == tenderCell.getRowId()){
                            bidderRow.add(tenderCell.getRowId());
                            bidcells.add(tenderCell);
                        }
                    }
                    if(tenderCell.getDataType()==combobox){
                        comboBoxs.add(tenderCell.getObjectId());
                    }else if(tenderCell.getDataType()==masterField){                        
                        masterFields.add(tenderCell.getObjectId());
                    }else if(tenderCell.getDataType()==listBox){                        
                        listBoxs.add(tenderCell.getObjectId());
                    }
                    for (Integer emd : emdColId) {
                        boolean gotGTCell = false;
                        if(formulaColId.contains(emd) && tenderCell.getTblTenderColumn().getColumnId() == emd) {
                            if(tenderCell.getDataType()==0){
                                emdCellId.add(tenderCell.getCellId());
                            }
                            gotGTCell=true;
                        }
                        if(!gotGTCell){
                            if(tenderCell.getTblTenderColumn().getColumnId() == emd){
                                emdCellId.add(tenderCell.getCellId());
                            }
                        }
                    }
                    for (Integer emd : emdColOfficerId) {
                        boolean gotGTCell = false;
                        if(formulaColId.contains(emd) && tenderCell.getTblTenderColumn().getColumnId() == emd) {
                            if(tenderCell.getDataType()==0){
                                emdCellOfficerId.add(tenderCell.getCellId());
                            }
                            gotGTCell=true;
                        }
                        if(!gotGTCell){
                            if(tenderCell.getTblTenderColumn().getColumnId() == emd){
                            	emdCellOfficerId.add(tenderCell.getCellId());
                            }
                        }
                    }
                    for (Integer participation : participationColOfficerId) {
                        boolean gotGTCell = false;
                        if(formulaColId.contains(participation) && tenderCell.getTblTenderColumn().getColumnId() == participation) {
                            if(tenderCell.getDataType()==0){
                                participationCellOfficerId.add(tenderCell.getCellId());
                            }
                            gotGTCell=true;
                        }
                        if(!gotGTCell){
                            if(tenderCell.getTblTenderColumn().getColumnId() == participation){
                            	participationCellOfficerId.add(tenderCell.getCellId());
                            }
                        }
                    }
                    
                    for (Integer doc : docColId) {
                        boolean gotGTCell = false;
                        if(formulaColId.contains(doc) && tenderCell.getTblTenderColumn().getColumnId() == doc) {
                            if(tenderCell.getDataType()==0){
                                docCellId.add(tenderCell.getCellId());
                            }
                            gotGTCell=true;
                        }
                        if(!gotGTCell){
                            if(tenderCell.getTblTenderColumn().getColumnId() == doc){
                                docCellId.add(tenderCell.getCellId());
                            }
                        }
                    }
                    for (Integer doc : docColOfficerId) {
                        boolean gotGTCell = false;
                        if(formulaColId.contains(doc) && tenderCell.getTblTenderColumn().getColumnId() == doc) {
                            if(tenderCell.getDataType()==0){
                                docCellOfficerId.add(tenderCell.getCellId());
                            }
                            gotGTCell=true;
                        }
                        if(!gotGTCell){
                            if(tenderCell.getTblTenderColumn().getColumnId() == doc){
                            	docCellOfficerId.add(tenderCell.getCellId());
                            }
                        }
                    }
                    
                    for (Integer process : processColId) {
                        boolean gotGTCell = false;
                        if(formulaColId.contains(process) && tenderCell.getTblTenderColumn().getColumnId() == process) {
                            if(tenderCell.getDataType()==0){                                
                                processCellId.add(tenderCell.getCellId());
                            }
                            gotGTCell=true;
                        }
                        if(!gotGTCell){
                            if(tenderCell.getTblTenderColumn().getColumnId() == process){
                                processCellId.add(tenderCell.getCellId());
                            }
                        }
                    }
                    for (Integer nonEnc : notEncrColId) {
                        if(tenderCell.getTblTenderColumn().getColumnId() == nonEnc) {
                             notEncrCellId.add(tenderCell.getCellId());
                        }
                    }
                }
                Object[] bd =  bidderRow.toArray();
                Set<Integer>  bidderRowFinal = new TreeSet<Integer>();                
                for (int i = 0; i < bd.length; i++) {
                    if(i>=tblTenderForm.getLoadNoOfItems()){
                        bidderRowFinal.add((Integer)bd[i]);
                    }                    
                }
                if(isBidRowLimited && bidTableRow != null) {

                    List<Integer> mappedItem = new ArrayList<Integer>();

                    for (Object[] rows : bidTableRow) {

                        if((Integer)rows[0] == tenderTable.getTableId()){

                            mappedItem.add(Integer.parseInt(rows[1].toString()));

                        }

                    }

                    tableInfo.put("mappedItem", mappedItem);

                }

                tableInfo.put("bidderRow", bidderRowFinal);                
                tableInfo.put("emdCellId", emdCellId);
                tableInfo.put("notEncrCellId", notEncrCellId);
                tableInfo.put("docCellId", docCellId);
                tableInfo.put("processCellId", processCellId);
                tableInfo.put("emdCellOfficerId", emdCellOfficerId);
                tableInfo.put("participationCellOfficerId", participationCellOfficerId);
                tableInfo.put("docCellOfficerId", docCellOfficerId);
                if(isBidRowLimited && !fromBidForm){                    
                    int bidCellCnt=0;
                    for (Object[] bidcell: bidTableRow) {
                        if((Integer)bidcell[0] == tenderTable.getTableId()){
                               bidCellCnt++;
                        }
                    }    
                    tableInfo.put("rowcount", bidCellCnt);//todo
                    tableInfo.put("cells", bidcells);
                }else{                    
                    tableInfo.put("cells", cells);
                }
            }
            if(fromBidForm && bidId==0 && tblTenderForm.getMasterFormId()!=0){
                List<String> bidDatas = new ArrayList<String>();
                for (TblMasterBid masterBid : masterBids) {
                    if (masterBid.getTblTableMaster().getSortOrder() == tenderTable.getSortOrder()) {                        
                        bidDatas.add(replaceCellId(masterBid.getBidJson(),tableInfo.get("tableJson").toString()));
//                        System.out.println(replaceCellId(masterBid.getBidJson(),tableInfo.get("tableJson").toString()));
                    }
                }
                tableInfo.put("bidData", bidDatas);
                if(!bidDatas.isEmpty()){
                    modelMap.put("masterbid", true);
                }
            }
            
            // Bug #32568 By Jitendra. The item selection page shows only table rows which is mapped to bidders.
            //Bug #72703 BY Rinju. isbidRowLimited for able to upload excel file if tabe is mandatory 
            if(isBidRowLimited ||modelMap.containsKey("formItemSelection") && modelMap.get("formItemSelection") != null && modelMap.get("formItemSelection").equals("Yes")){
            	List<Object> rowIds = getBidderMappedRows(tenderId, (Integer)modelMap.get("bidderId"), tenderTable.getTableId());
            	if(rowIds != null && !rowIds.isEmpty()){
            		for(int i=0;i<rowIds.size();i++){
            			mappedBidderRows.add(tenderTable.getTableId()+"_"+(Integer.parseInt(rowIds.get(i).toString())-1));
            		}
            		tableInfo.put("bidderMappedRows", abcUtility.converObjectArrayToCommas(rowIds));
            	}
            }
            tableList.add(tableInfo);
        }
        
        // Bug #32568 By Jitendra. 
        TblTender tblTender = tenderCommonService.getTenderById(tenderId);
        boolean showBidderMappedRows = false;
        if((tblTender.getTenderMode() == 2 || tblTender.getTenderMode() == 3 || tblTender.getTenderMode() == 4) && tblTender.getTenderResult() == 2 && tblTenderForm.getIsPriceBid()==1){
        	showBidderMappedRows = true;
        }
        modelMap.put("showBidderMappedRows", showBidderMappedRows);
        
        if(!comboBoxs.isEmpty()){            
            modelMap.put("comboList", getComboDetailByComboId(comboBoxs.toArray()));
        }
        if(!proxyData.isEmpty()){            
            modelMap.put("proxyData", proxyData);
        }
        if(!listBoxs.isEmpty()){
            showDownload=false;
            modelMap.put("listboxList", getComboDetailByComboId(listBoxs.toArray()));
        }
        if(!masterFields.isEmpty()){
            showDownload=false;
            HttpServletRequest request = getServletRequest();            
            modelMap.put("masterFieldList", getBidderMasterFieldValue(abcUtility.getSessionUserId(request),masterFields.toArray(),bidderMasterField)); 
        }
        // BPCL - doc upload/download for Tech Env - start
        if(tblTenderForm.getIsPriceBid()==0 && !tableIds.isEmpty()){
        	List<Object[]> lstDocumentDetails = fileUploadService.getOfficerDocs(tableIds, abcUtility.getSessionClientId(getServletRequest()), 183, 1);
        	if(lstDocumentDetails!=null && !lstDocumentDetails.isEmpty()){
        		modelMap.put("isItemWiseDocAvail", true);
                Map<String, List<Object[]>> docsMaps = new HashMap<String, List<Object[]>>();
            	for(Object[] objDocs : lstDocumentDetails){
            		List<Object[]> lstDocs = null;
            		if(docsMaps.containsKey(objDocs[1].toString()+"_"+objDocs[3].toString())){
            			lstDocs = docsMaps.get(objDocs[1].toString()+"_"+objDocs[3].toString()); 
            		}else{
            			lstDocs = new ArrayList<Object[]>();
            		}
            		lstDocs.add(objDocs);
            		docsMaps.put(objDocs[1].toString()+"_"+objDocs[3].toString(), lstDocs);
            	}
            	modelMap.put("listOfDocs", docsMaps);
        	}
        	else{
        		modelMap.put("isItemWiseDocAvail", false);
        	}
        }
        //BPCL - doc upload/download for Tech Env - End
        modelMap.put("showDownload", showDownload);
        modelMap.put("tableList", tableList);
        modelMap.put("isFillByBidder",isFillByBidder);
        modelMap.put("isFillByBidderColumnExist",isFillByBidderColumnExist);
        modelMap.put("itemSelectionList", itemSelectionList);
        modelMap.put("activatetableRows", activatetableRows);
        modelMap.put("isExcelAutoSubmitAllowed",isExcelAutoSubmitAllowed);
        modelMap.put("mappedBidderRows", mappedBidderRows);
    }
    
    
    
    /**
     * @param formId
     * @param modelMap
     * @param tenderId
     * @throws Exception
     */
    public void setViewFormNFormula(Object[] formId, Map<String, Object> modelMap, int tenderId) throws Exception {
    	List<Integer> tableIds = new ArrayList<Integer>();
        TblTenderForm tblTenderForm = getTenderFormById((Integer)formId[0]);
        modelMap.put("tblTenderForm", tblTenderForm);
        modelMap.put("formName", tblTenderForm.getFormName());
        modelMap.put("formHeader", tblTenderForm.getFormHeader());
        modelMap.put("formFooter", tblTenderForm.getFormFooter());
        modelMap.put("noOfTables", tblTenderForm.getNoOfTables());
        modelMap.put("itemsToLoad", tblTenderForm.getLoadNoOfItems());
        modelMap.put("itemsIncremental", tblTenderForm.getIncrementItems());
        modelMap.put("encryptionReq", tblTenderForm.getIsEncryptionReq());
        modelMap.put("itemWiseDocAllowed",tblTenderForm.getIsItemWiseDocAllowed()==1?true:false);
        List<TblTenderTable> tables = getTenderTableByFormId(formId);
        if(tables.size()>0)
    	{
    		Collections.sort(tables);
    	}
        List<Object[]> visibleRows = new ArrayList<Object[]>();
        List<SelectItem> currency = null;
        Set<Integer> comboBoxs = new HashSet<Integer>();
        Set<Integer> listBoxs = new HashSet<Integer>();
        Set<Integer> masterFields = new HashSet<Integer>();
        List<Integer> formulaColId = new ArrayList<Integer>();        
        List<Integer> emdColId = new ArrayList<Integer>();
        List<Integer> notEncrColId = new ArrayList<Integer>(); 
        List<Integer> docColId = new ArrayList<Integer>();        
        List<Integer> processColId = new ArrayList<Integer>();        
        List<Integer> emdCellId = new ArrayList<Integer>();        
        List<Integer> notEncrCellId = new ArrayList<Integer>();
        List<Integer> docCellId = new ArrayList<Integer>();        
        List<Integer> processCellId = new ArrayList<Integer>();        
        List<Integer> formulaColNo = new ArrayList<Integer>();
        List<Map<String, Object>> tableList = new ArrayList<Map<String, Object>>();   
        Map<Integer,String> proxyData = new HashMap<Integer, String>();
        int bidId = 0;
        boolean showDownload = true;
        boolean fromBidForm = false;
        boolean frombidfactor = false;
        List<TblTenderBidMatrix> bidMatrixs = null;                        
        List<TblMasterBid> masterBids = null;                        
        if(modelMap.get("fromBidForm")!=null){
            fromBidForm = (Boolean)modelMap.get("fromBidForm");            
        }
        if(modelMap.get("isItemSelectionPageRequired")!=null && (Integer) modelMap.get("isItemSelectionPageRequired")==1){
            if(tblTenderForm.getIsPriceBid()==1){
               visibleRows = getSelectedRowsForBidding(formId, (Integer) modelMap.get("companyId"));
            }else{
                modelMap.put("isItemSelectionPageRequired", 0);
            }
        }else{            
            modelMap.put("isItemSelectionPageRequired", 0);
        }
        if(modelMap.get("bidId")!=null && (Integer)modelMap.get("bidId")!=0){
            bidId = (Integer)modelMap.get("bidId");
            bidMatrixs = getTenderBidMatrixByBidId(bidId);
        }
        if(fromBidForm && bidId==0 && tblTenderForm.getMasterFormId()!=0){
            masterBids = masterFormService.getMasterBid(tblTenderForm.getMasterFormId(),(Integer) modelMap.get("companyId"));
        }
        if(modelMap.get("frombidfactor")!=null){
            frombidfactor = (Boolean)modelMap.get("frombidfactor");            
        }
        boolean isBidRowLimited = false;
        List<Object[]> bidTableRow = null;
        if(fromBidForm && (Integer)modelMap.get("tenderMode")==2 && (Integer)modelMap.get("tenderResult")==2 && tblTenderForm.getIsPriceBid()==1){
            isBidRowLimited = true;
            bidTableRow = getBidderItem(tenderId, (Integer)modelMap.get("bidderId"));
        }    
        modelMap.put("isBidRowLimited", isBidRowLimited);
        for (TblTenderTable tenderTable : tables) {
            Map<String, Object> tableInfo = new HashMap<String, Object>();
            boolean isGTWise = tenderTable.getHasGTRow() == 1;
            List<Object[]> allFormula = getFormulaColId(tenderTable.getTableId());
            for (Object[] formula : allFormula) {
                if (formula[2].toString().startsWith(TOTAL)) {
                    formulaColId.add((Integer) formula[0]);
                    formulaColNo.add((Integer) formula[5]);
                }
            }            
            if(bidId!=0){
                List<String> bidDatas = new ArrayList<String>();
                List<String> bidTableIds = new ArrayList<String>();
                List<Object[]> itemWiseDocs = new ArrayList<Object[]>();
                Map<String,List<Object[]>> docMap = new HashMap<String, List<Object[]>>();
                for (TblTenderBidMatrix tblTenderBidMatrix : bidMatrixs) {
                      if(tblTenderBidMatrix.getTblTenderTable().getTableId() == tenderTable.getTableId()){
                          bidDatas.add(tblTenderBidMatrix.getBidJson());
                          bidTableIds.add(encryptDecryptUtils.encrypt(String.valueOf(tblTenderBidMatrix.getBidTableId())));
                          itemWiseDocs = getItemWiseDocs(tblTenderBidMatrix.getBidTableId());
                          for(Object[] docs : itemWiseDocs){
                        	  List<Object[]> list = null;
                        	  if(docMap.containsKey(encryptDecryptUtils.encrypt(docs[1].toString())+"_"+docs[3].toString())){
                        		 list = docMap.get(encryptDecryptUtils.encrypt(docs[1].toString())+"_"+docs[3].toString());                        		 
                        	  }else{
                        		  list = new ArrayList<Object[]>();                        		  
                        	  }
                        	  if(list!=null){
	                        	  list.add(docs);
	                     		  docMap.put(encryptDecryptUtils.encrypt(docs[1].toString())+"_"+docs[3].toString(), list);
                        	  }
                          }
                      }
                }
                tableInfo.put("bidData", bidDatas);
                tableInfo.put("bidTableId", bidTableIds);
                tableInfo.put("itemWiseDocs", docMap);
            }
            List<Integer> visibleRow = new ArrayList<Integer>();
            for (Object[] rows : visibleRows) {
                if((Integer)rows[0] == tenderTable.getTableId()){
                    visibleRow.add((Integer)rows[1]);
                }
            }
            tableInfo.put("rowcount", isGTWise ? (tenderTable.getNoOfRows() - 1) : tenderTable.getNoOfRows());
            tableInfo.put("multipleFill", tenderTable.getIsMultipleFilling());
            tableInfo.put("colcount", tenderTable.getNoOfCols());
            tableInfo.put("tableName", tenderTable.getTableName());
            tableInfo.put("tableHeader", tenderTable.getTableHeader());
            tableInfo.put("tableFooter", tenderTable.getTableFooter());
            tableInfo.put(TABLEID, tenderTable.getTableId());
            tableIds.add(tenderTable.getTableId());
            tableInfo.put("formulaColId", formulaColId);
            tableInfo.put("formulaColNo", formulaColNo);
            tableInfo.put("isGTWise", isGTWise);
            tableInfo.put("formulas", allFormula);
            tableInfo.put("isPartialFillingAllowed", tenderTable.getIsPartialFillingAllowed());
            tableInfo.put("isMandatory", tenderTable.getIsMandatory());
            List<TblTenderColumn> columns = getTenderColumnByTableId(tenderTable.getTableId());
            List<Integer> dateColSortNo = new ArrayList<Integer>();
            boolean isCurrency = false;
            boolean hasProxyCol = false;
            StringBuilder colFilledBy = new StringBuilder();
            for (TblTenderColumn tblTenderColumn : columns) {
                colFilledBy.append("'").append(tblTenderColumn.getColumnNo()).append("@@").append(tblTenderColumn.getFilledBy()).append("_").append(tblTenderColumn.getTblColumnType().getColumnTypeId()).append("_").append(tblTenderColumn.getIsShown()).append("'").append(",");                
                if (tblTenderColumn.getTblColumnType().getColumnTypeId() == 8) {
                    isCurrency = true;                    
                }
//                for (Integer columnId : formulaColId) {
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == processingFeesId) {
                        processColId.add(tblTenderColumn.getColumnId());
                    }            
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == documentFeesId) {
                        docColId.add(tblTenderColumn.getColumnId());
                    }            
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == emdAmountId) {
                        emdColId.add(tblTenderColumn.getColumnId());
                    }
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == notEncrReqId) {
                        notEncrColId.add(tblTenderColumn.getColumnId());
                    }
                    
                    if (tblTenderColumn.getTblColumnType().getColumnTypeId() == loadingFactor && tblTenderColumn.getFilledBy() == 4) {
                    	if(modelMap.containsKey("loadingFactorForm"))
                    	{
                    		Map<Object,Object> loadingFactorForm = (Map<Object, Object>) modelMap.get("loadingFactorForm");
                    		loadingFactorForm.put(tblTenderColumn.getTblTenderForm().getFormId(), tblTenderColumn.getTblTenderForm().getFormId());
                    	}else{
                    		Map<Object,Object> loadingFactorForm = new HashMap<Object, Object>();
                    		loadingFactorForm.put(tblTenderColumn.getTblTenderForm().getFormId(), tblTenderColumn.getTblTenderForm().getFormId());
                    		modelMap.put("loadingFactorForm",loadingFactorForm);
                    	}
                    	if(modelMap.containsKey("loadingFactorTable"))
                    	{
                    		Map<Object,Object> loadingFactorTable= (Map<Object, Object>) modelMap.get("loadingFactorTable");
                    		loadingFactorTable.put(tblTenderColumn.getTblTenderTable().getTableId(), tblTenderColumn.getTblTenderTable().getTableId());
                    	}else{
                    		Map<Object,Object> loadingFactorTable = new HashMap<Object, Object>();
                    		loadingFactorTable.put(tblTenderColumn.getTblTenderTable().getTableId(), tblTenderColumn.getTblTenderTable().getTableId());
                    		modelMap.put("loadingFactorTable",loadingFactorTable);
                    	}
                    }
//                }
                if (tblTenderColumn.getFilledBy() == proxy) {
                    hasProxyCol = true;                    
                }
                if(tblTenderColumn.getDataType() == 7) {
                	dateColSortNo.add(tblTenderColumn.getSortOrder());
                }
            }
            tableInfo.put("dateColSortNo", dateColSortNo);
            if (colFilledBy.length() != 0) {
                tableInfo.put("colFilledBy", colFilledBy.delete(colFilledBy.length() - 1, colFilledBy.length()));                
                //System.out.println(tableInfo.get("colFilledBy"));
            }
            if(hasProxyCol && (fromBidForm || frombidfactor)){
                List<Object[]> proxyColData = getProxyCellData(tenderTable.getTableId(), (Integer)modelMap.get("companyId"));                                
                JSONArray jSONArray = new JSONArray();        
                for (int i=0;i<proxyColData.size();i++) {
                    Object[] proxyD = proxyColData.get(i);
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put(proxyD[0].toString(),proxyD[1].toString());
                    if(frombidfactor){
                        proxyData.put((Integer)proxyD[0], proxyD[1].toString());
                    }
                    jSONArray.put(i, jSONObject);
                }
                tableInfo.put("proxyData", jSONArray.toString());
            }
            if (isCurrency) {
                showDownload=false;
                if(currency==null){                    
                    currency = fromBidForm ? abcUtility.convert(getBidderCurrency(tenderId, (Integer)modelMap.get("companyId"))) : abcUtility.convertSelected(getTenderCurrency(tenderId));
                }
                tableInfo.put("tenderCurrency", currency);
            }
            tableInfo.put("columns", columns);
            if (!columns.isEmpty()) {
//                    List<TblTenderCell> cells = getCellMasterByTableId(tenderTable.getTableId(), isGTWise ? (rowCount) : 0);
                String tableJson = getTableJson(tenderTable.getTableId());                
                tableInfo.put("tableJson", tableJson);
                List<TblTenderCell> cells = _toCellMasters(tableJson);
                List<TblTenderCell> bidcells = new ArrayList<TblTenderCell>();
                Set<Integer>  bidderRow = new TreeSet<Integer>();                                
                for (TblTenderCell tenderCell : cells) {
                    if(isBidRowLimited && bidTableRow!=null){
                        for (Object[] bidcell: bidTableRow) {
                            if((Integer)bidcell[0] == tenderTable.getTableId() && (Integer)bidcell[1] == tenderCell.getRowId()){                                
                                bidderRow.add(tenderCell.getRowId());
                                bidcells.add(tenderCell);
                            }
                        }
                        if(isGTWise && tenderTable.getNoOfRows() == tenderCell.getRowId()){
                            bidderRow.add(tenderCell.getRowId());
                            bidcells.add(tenderCell);
                        }
                    }
                    if(tenderCell.getDataType()==combobox){
                        comboBoxs.add(tenderCell.getObjectId());
                    }else if(tenderCell.getDataType()==masterField){                        
                        masterFields.add(tenderCell.getObjectId());
                    }else if(tenderCell.getDataType()==listBox){                        
                        listBoxs.add(tenderCell.getObjectId());
                    }
                    for (Integer emd : emdColId) {
                        boolean gotGTCell = false;
                        if(formulaColId.contains(emd) && tenderCell.getTblTenderColumn().getColumnId() == emd) {
                            if(tenderCell.getDataType()==0){
                                emdCellId.add(tenderCell.getCellId());
                            }
                            gotGTCell=true;
                        }
                        if(!gotGTCell){
                            if(tenderCell.getTblTenderColumn().getColumnId() == emd){
                                emdCellId.add(tenderCell.getCellId());
                            }
                        }
                    }
                    for (Integer doc : docColId) {
                        boolean gotGTCell = false;
                        if(formulaColId.contains(doc) && tenderCell.getTblTenderColumn().getColumnId() == doc) {
                            if(tenderCell.getDataType()==0){
                                docCellId.add(tenderCell.getCellId());
                            }
                            gotGTCell=true;
                        }
                        if(!gotGTCell){
                            if(tenderCell.getTblTenderColumn().getColumnId() == doc){
                                docCellId.add(tenderCell.getCellId());
                            }
                        }
                    }
                    for (Integer process : processColId) {
                        boolean gotGTCell = false;
                        if(formulaColId.contains(process) && tenderCell.getTblTenderColumn().getColumnId() == process) {
                            if(tenderCell.getDataType()==0){                                
                                processCellId.add(tenderCell.getCellId());
                            }
                            gotGTCell=true;
                        }
                        if(!gotGTCell){
                            if(tenderCell.getTblTenderColumn().getColumnId() == process){
                                processCellId.add(tenderCell.getCellId());
                            }
                        }
                    }
                    for (Integer nonEnc : notEncrColId) {
                        if(tenderCell.getTblTenderColumn().getColumnId() == nonEnc) {
                             notEncrCellId.add(tenderCell.getCellId());
                        }
                    }
                }
                Object[] bd =  bidderRow.toArray();
                Set<Integer>  bidderRowFinal = new TreeSet<Integer>();                
                for (int i = 0; i < bd.length; i++) {
                    if(i>=tblTenderForm.getLoadNoOfItems()){
                        bidderRowFinal.add((Integer)bd[i]);
                    }                    
                }
                tableInfo.put("bidderRow", bidderRowFinal);                
                tableInfo.put("emdCellId", emdCellId);
                tableInfo.put("notEncrCellId", notEncrCellId);
                tableInfo.put("docCellId", docCellId);
                tableInfo.put("processCellId", processCellId);
                if(isBidRowLimited){                    
                    int bidCellCnt=0;
                    for (Object[] bidcell: bidTableRow) {
                        if((Integer)bidcell[0] == tenderTable.getTableId()){
                               bidCellCnt++;
                        }
                    }    
                    tableInfo.put("rowcount", bidCellCnt);//todo
                    tableInfo.put("cells", bidcells);
                }else{                    
                    tableInfo.put("cells", cells);
                }
            }
            if(fromBidForm && bidId==0 && tblTenderForm.getMasterFormId()!=0){
                List<String> bidDatas = new ArrayList<String>();
                for (TblMasterBid masterBid : masterBids) {
                    if (masterBid.getTblTableMaster().getSortOrder() == tenderTable.getSortOrder()) {                        
                        bidDatas.add(replaceCellId(masterBid.getBidJson(),tableInfo.get("tableJson").toString()));
//                        System.out.println(replaceCellId(masterBid.getBidJson(),tableInfo.get("tableJson").toString()));
                    }
                }
                tableInfo.put("bidData", bidDatas);
                if(!bidDatas.isEmpty()){
                    modelMap.put("masterbid", true);
                }
            }
            tableList.add(tableInfo);
        }
        if(!comboBoxs.isEmpty()){            
            modelMap.put("comboList", getComboDetailByComboId(comboBoxs.toArray()));
        }
        if(!proxyData.isEmpty()){            
            modelMap.put("proxyData", proxyData);
        }
        if(!listBoxs.isEmpty()){
            showDownload=false;
            modelMap.put("listboxList", getComboDetailByComboId(listBoxs.toArray()));
        }
        if(!masterFields.isEmpty()){
            showDownload=false;
            HttpServletRequest request = getServletRequest();            
            modelMap.put("masterFieldList", getBidderMasterFieldValue(abcUtility.getSessionUserId(request),masterFields.toArray(),bidderMasterField)); 
        }
        // BPCL - doc upload/download for Tech Env - start
        if(tblTenderForm.getIsPriceBid()==0 && !tableIds.isEmpty()){
        	List<Object[]> lstDocumentDetails = fileUploadService.getOfficerDocs(tableIds, abcUtility.getSessionClientId(getServletRequest()), 183, 1);
        	if(lstDocumentDetails!=null && !lstDocumentDetails.isEmpty()){
        		modelMap.put("isItemWiseDocAvail", true);
                Map<String, List<Object[]>> docsMaps = new HashMap<String, List<Object[]>>();
            	for(Object[] objDocs : lstDocumentDetails){
            		List<Object[]> lstDocs = null;
            		if(docsMaps.containsKey(objDocs[1].toString()+"_"+objDocs[3].toString())){
            			lstDocs = docsMaps.get(objDocs[1].toString()+"_"+objDocs[3].toString()); 
            		}else{
            			lstDocs = new ArrayList<Object[]>();
            		}
            		lstDocs.add(objDocs);
            		docsMaps.put(objDocs[1].toString()+"_"+objDocs[3].toString(), lstDocs);
            	}
            	modelMap.put("listOfDocs", docsMaps);
        	}
        	else{
        		modelMap.put("isItemWiseDocAvail", false);
        	}
        }
        //BPCL - doc upload/download for Tech Env - End
        modelMap.put("showDownload", showDownload);
        modelMap.put("tableList", tableList);
    }
    
    /**
     * author priyanka dalwadi
     * @param tenderId
     * @param companyId
     * @param formId
     * @param tableId
     * @param rowId
     * @return
     * @throws Exception
     */
    public List<TblEventFees> getTenderFeesPaymentDetail(int tenderId, int companyId, int formId, int tableId,int rowId,int bidId,int feeType) throws Exception {
         List<TblEventFees> list = new ArrayList<TblEventFees>();
         if(bidId !=0){
        	  if(rowId!=-1){
		         list = tblEventFeesDao.findTblEventFees("objectId", Operation_enum.EQ,tenderId,"bidId", Operation_enum.EQ,bidId,"tblCompany.companyId", Operation_enum.EQ,companyId,"formId", Operation_enum.EQ,formId,"tableId", Operation_enum.EQ,tableId,"rowId", Operation_enum.EQ,rowId,"cstatus", Operation_enum.EQ,1,"feeType",Operation_enum.EQ,feeType);
		      }else{
		         list = tblEventFeesDao.findTblEventFees("objectId", Operation_enum.EQ,tenderId,"bidId", Operation_enum.EQ,bidId,"tblCompany.companyId", Operation_enum.EQ,companyId,"formId", Operation_enum.EQ,formId,"tableId", Operation_enum.EQ,tableId,"cstatus", Operation_enum.EQ,1);
		      }
         }else{
        	 if(rowId!=-1){
		         list = tblEventFeesDao.findTblEventFees("objectId", Operation_enum.EQ,tenderId,"tblCompany.companyId", Operation_enum.EQ,companyId,"formId", Operation_enum.EQ,formId,"tableId", Operation_enum.EQ,tableId,"rowId", Operation_enum.EQ,rowId,"cstatus", Operation_enum.EQ,1,"feeType",Operation_enum.EQ,feeType);
		      }else{
		        	 list = tblEventFeesDao.findTblEventFees("objectId", Operation_enum.EQ,tenderId,"tblCompany.companyId", Operation_enum.EQ,companyId,"formId", Operation_enum.EQ,formId,"tableId", Operation_enum.EQ,tableId,"cstatus", Operation_enum.EQ,1);
		      }
         }
        return list;
    }
    
    public List<TblEventFees> getEventFeesCheckPayment(int tenderId, int companyId, int formId, int tableId,int rowId,int bidId,int isActive) throws Exception {
        List<TblEventFees> list = new ArrayList<TblEventFees>();
        if(bidId !=0){
       	  if(rowId!=-1){
		         list = tblEventFeesDao.findTblEventFees("objectId", Operation_enum.EQ,tenderId,"bidId", Operation_enum.EQ,bidId,"tblCompany.companyId", Operation_enum.EQ,companyId,"formId", Operation_enum.EQ,formId,"tableId", Operation_enum.EQ,tableId,"rowId", Operation_enum.EQ,rowId,"cstatus", Operation_enum.EQ,0);
		      }else{
		         list = tblEventFeesDao.findTblEventFees("objectId", Operation_enum.EQ,tenderId,"bidId", Operation_enum.EQ,bidId,"tblCompany.companyId", Operation_enum.EQ,companyId,"formId", Operation_enum.EQ,formId,"tableId", Operation_enum.EQ,tableId,"cstatus", Operation_enum.EQ,0);
		      }
        }else{
       	 if(rowId!=-1){
		         list = tblEventFeesDao.findTblEventFees("objectId", Operation_enum.EQ,tenderId,"tblCompany.companyId", Operation_enum.EQ,companyId,"formId", Operation_enum.EQ,formId,"tableId", Operation_enum.EQ,tableId,"rowId", Operation_enum.EQ,rowId,"cstatus", Operation_enum.EQ,0,"isActive",Operation_enum.EQ,isActive);
		      }else{
		        	 list = tblEventFeesDao.findTblEventFees("objectId", Operation_enum.EQ,tenderId,"tblCompany.companyId", Operation_enum.EQ,companyId,"formId", Operation_enum.EQ,formId,"tableId", Operation_enum.EQ,tableId,"cstatus", Operation_enum.EQ,0);
		      }
        }
       return list;
   }
    
    /**
     * author Priyanka
     * get item wise payment pending
     * @return
     */
     public List<Object[]> getPaymentPending(int tenderId, int companyId, int formId, int tableId,int rowId,int bidId,int feetype){
     	 StringBuilder query = new StringBuilder();
          Map<String, Object> var = new HashMap<String, Object>();
          var.put("objectId",tenderId);
          var.put("companyId",companyId);
          var.put("formId",formId);
          var.put("tableId",tableId);
          var.put("rowId",rowId);
          var.put("bidId",bidId);
          var.put("feeType",feetype);
          query.append("select tblEventFees.eventFeeId from TblEventFees tblEventFees")
          .append(" where tblEventFees.objectId=:objectId and tblEventFees.tblCompany.companyId=:companyId and tblEventFees.formId=:formId and tblEventFees.tableId=:tableId and tblEventFees.rowId=:rowId and tblEventFees.bidId=:bidId and tblEventFees.feeType=:feeType and tblEventFees.cstatus=0 and tblEventFees.isActive=1 ");
          return hibernateQueryDao.createNewQuery(query.toString(),var);
     }
    
    /**
    * author Lipi
    * @param bidTableId
    * get item wise documents
    * @return
    */
    private List<Object[]> getItemWiseDocs(int bidTableId){
    	 StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("bidTableId",bidTableId);
         query.append("select tblbidderdocument.bidderDocId,tblbidderdocmapping.objectId,tblbidderdocument.description,tblbidderdocmapping.childId ")
         		.append(" from TblBidderDocMapping tblbidderdocmapping ")
         		.append(" inner join tblbidderdocmapping.tblBidderDocument tblbidderdocument ")
         		.append(" where tblbidderdocmapping.cstatus=1 and tblbidderdocmapping.objectId=:bidTableId and tblbidderdocmapping.tblLink.linkId=808");
         return hibernateQueryDao.createNewQuery(query.toString(),var);
    }
    
    /**
     *
     * @param bidId
     * @return
     * @throws Exception
     */
    public List<TblTenderBidMatrix> getTenderBidMatrixByBidId(int bidId) throws Exception {
        List<TblTenderBidMatrix> list = null;
        list = tblTenderBidMatrixDao.findTblTenderBidMatrix("tblTenderBid", Operation_enum.EQ, new TblTenderBid(bidId));
        return list;

    }
     public List<Object[]> toBidData(String json) throws JSONException {
        List<Object[]> bidDatas = new ArrayList<Object[]>();
        if (StringUtils.hasLength(json)) {
            JSONArray jsonArray = new JSONArray(json);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jSONObject = jsonArray.getJSONObject(i);
                for (Iterator it = jSONObject.keys(); it.hasNext();) {
                    String key = it.next().toString();
                    String[] Ids = key.split("_");
                    bidDatas.add(new Object[]{Integer.parseInt(Ids[0]),Integer.parseInt(Ids[1]),jSONObject.getString(key)});
                }
            }
        }
        return bidDatas;
    }
     /**
      * to get form detail for rebate
      * @author Krunal.patel
      * @param tenderId
      * @param rebateId
      * @return List{@code<Object[]>} 
      * @throws Exception
      * modified by heeral to add condition isOpeningByCommittee=1 if dual-certi
      */ 
     public List<Object[]> getFormList(int tenderId,int rebateId,boolean isDualCerti,int isOpeningByCommittee) throws Exception{
         StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("rebateId",rebateId);
         query.append("SELECT tbltenderform.formId, tbltenderenvelope.envelopeName, tbltenderform.formName,tbltendertable.tableId,tbltendertable.tableName,tbltendercolumn.columnId,tbltendercolumn.columnHeader, tbltendercell.cellId,tblrebateform.rebateFormId ")
                 .append("FROM TblTenderEnvelope tbltenderenvelope ")
                 .append("INNER JOIN tbltenderenvelope.tblTenderForm tbltenderform WITH tbltenderform.cstatus != 2 AND tbltenderform.isPriceBid = 1 and tbltenderform.isMandatory=1 ")
                 .append(isDualCerti == true && isOpeningByCommittee == 1 ? "and tbltenderform.isEncryptionReq = 1 " : "")
                 .append("INNER JOIN tbltenderform.tblTenderTable tbltendertable WITH tbltendertable.hasGTRow = 1 AND tbltendertable.isMandatory = 1")
                 .append("INNER JOIN tbltendertable.tblTenderFormula tbltenderformula WITH tbltenderformula.formula LIKE 'TOTAL(%' ")
                 .append("INNER JOIN tbltenderformula.tblTenderColumn tbltendercolumn ")
                 .append("INNER JOIN tbltendercolumn.tblTenderCell tbltendercell ")
                 .append("LEFT JOIN tbltendercell.tblRebateForm tblrebateform with tblrebateform.tblRebate.rebateId=:rebateId ")
                 .append("WHERE tbltenderenvelope.tblTender.tenderId = :tenderId and tbltendertable.noOfRows = tbltendercell.rowId ");
         return hibernateQueryDao.createNewQuery(query.toString(),var);                
     }
     
     public List<Object[]> getLoadingFactor(int tenderId) throws Exception{
         StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         query.append("select case when (select COUNT(formId) from apptender.tbl_TenderForm tf where tenderId=:tenderId and isPriceBid=1 and cstatus=1)= 0 then '0' else '1' end isPriceBidForm, ");
         query.append("case when (select COUNT(columnId) from apptender.tbl_TenderForm tf inner join apptender.tbl_TenderColumn tc on tf.formId=tc.formId where tc.columnTypeId=20 and cstatus=1 and tenderId=:tenderId and isPriceBid=1)= 0 then '0' else '1' end isEncNotRequire, ");
         query.append("case when (select COUNT(columnId) from apptender.tbl_TenderForm tf inner join apptender.tbl_TenderColumn tc on tf.formId=tc.formId where tc.columnTypeId=23 and cstatus=1 and tenderId=:tenderId and isPriceBid=1)= 0 then '0' else '1' end isLoadingFactor, ");
         query.append("case when (select COUNT(columnId) from apptender.tbl_TenderForm tf inner join apptender.tbl_TenderColumn tc on tf.formId=tc.formId where tc.columnTypeId=26 and cstatus=1 and tenderId=:tenderId and isPriceBid=1)= 0 then '0' else '1' end isAutoLoadingTotal, ");
         query.append("case when (select COUNT(columnId) from apptender.tbl_TenderForm tf inner join apptender.tbl_TenderColumn tc on tf.formId=tc.formId where tc.columnTypeId=27 and cstatus=1 and tenderId=:tenderId and isPriceBid=1)= 0 then '0' else '1' end isUnitRateAfterLoading ");
         //query.append("WHERE tbltenderenvelope.tblTender.tenderId=:tenderId and tbltendertable.noOfRows = tbltendercell.rowId ");
         //System.out.println("query = " + query.toString());
         List<Object[]> list = hibernateQueryDao.nativeSQLQuery(query.toString(), var);
        return list!=null && !list.isEmpty() ? list : null;
     }
     /**
      * to get form detail for rebate edit
      * @author Krunal.patel
      * @param  rebateId
      * @return List{@code<Object[]>} 
      * @throws Exception
      */ 
     public List<Object[]> getEditFormListForRebate(int rebateId) throws Exception{
         StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("rebateId",rebateId);
         
         query.append("SELECT tblrebate.rebateId, tblrebate.reportName, tblrebate.isRebateForm, tblrebateform.rebateFormId,tblrebateform.tblTenderCell.cellId ")
                 .append("FROM TblRebate tblrebate ")
                 .append("INNER JOIN tblrebate.tblRebateForm tblrebateform ")
                 .append("WHERE tblrebate.rebateId = :rebateId ");
         return hibernateQueryDao.createNewQuery(query.toString(),var);                
     }
     /**
      * 
      * @param tenderId
      * @return
      * @throws Exception 
      */
     public List<Object[]> getCancelFormDtls(int tenderId) throws Exception{
    	 StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         
         query.append("SELECT tblcorrigendumdetail.objectId FROM TblCorrigendum tblcorrigendum ")
         .append("INNER JOIN tblcorrigendum.tblCorrigendumDetail tblcorrigendumdetail with tblcorrigendumdetail.tblProcess.processId = 4 ")
         .append("AND tblcorrigendumdetail.actionType = 3 ")
         .append("WHERE tblcorrigendum.objectId = :tenderId ")
         .append("AND tblcorrigendum.cstatus = 0 ")
         .append("AND tblcorrigendum.tblProcess.processId = 1");
         return hibernateQueryDao.createNewQuery(query.toString(),var);                
     }

     /**
      * Use to add details for Rebate Configuration 
      * @author Krunal.patel
      * @param TblRebate
      * @param List<TblRebateForm>
      * @return boolean
      * @throws Exception 
      */
     @Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
     public boolean addRebateDetail(TblRebate tblRebate,List<TblRebateForm> tblRebateForms) throws Exception{
         boolean bSuccess = false;   
         			 Map<String, Object> var = new HashMap<String, Object>();
         			 var.put("tenderId", tblRebate.getTblTender().getTenderId());
         			 hibernateQueryDao.updateDeleteNewQuery("delete from TblRebate where tblTender.tenderId=:tenderId",var);
                     tblRebateDao.addTblRebate(tblRebate);
                     tblRebateFormDao.saveUpdateAllTblRebateForm(tblRebateForms);
                 bSuccess=true;        
             return bSuccess;

         }
     
     /**
      * @author Krunal.patel
      * @param rebateId
      * @return tblRebate
      * @throws Exception 
      */
     public  TblRebate getRebateById(int rebateId) throws Exception{
             List<TblRebate> list = null;        
         list = tblRebateDao.findTblRebate("rebateId",Operation_enum.EQ,rebateId);                
             return (list!=null && !list.isEmpty()) ? list.get(0) : null;            

     }
     /**
      * @author Krunal.patel
      * @param tenderId
      * @param companyId
      * @return List{@code<Object[]>}
      * @throws Exception 
      */
     public List<Object[]> getRebateByTenderNCompanyId(int tenderId,int companyId) throws Exception{
         StringBuilder query = new StringBuilder();
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("companyId",companyId);
         query.append("select tblrebate.rebateId,tblrebate.reportName,tblrebate.isRebateForm,isnull(tbltenderrebate.tenderRebateId,0) ")
         .append("from TblRebate tblrebate ")
         .append("left join tblrebate.tblTenderRebate tbltenderrebate with tbltenderrebate.tblCompany.companyId = :companyId ")
         .append("where tblrebate.tblTender.tenderId = :tenderId ");
         
         return hibernateQueryDao.createNewQuery(query.toString(),var);
     }
     /**
      * @author Krunal.patel
      * @param tblRebate
      * @param tblRebateForms
      * @return Boolean
      * @throws Exception 
      */
     @Transactional(propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
     public boolean editRebateDetail(TblRebate tblRebate,List<TblRebateForm> tblRebateForms) throws Exception{
     boolean bSuccess = false;
                 tblRebateDao.updateTblRebate(tblRebate);
                 Map<String, Object> var = new HashMap<String, Object>();
                 var.put("rebateId", tblRebate.getRebateId());
                 hibernateQueryDao.updateDeleteNewQuery("delete from TblRebateForm tblrebateform where tblrebateform.tblRebate.rebateId=:rebateId", var);
                 tblRebateFormDao.saveUpdateAllTblRebateForm(tblRebateForms);
             bSuccess=true;
             return bSuccess;
     }
     /**
      * @author Krunal.patel
      * @param rebateId
      * @return boolean
      * @throws Exception 
      */
     public boolean deleteRebateReport(int rebateId) throws Exception{
         int cnt = 0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("rebateId",rebateId);
         cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblRebate tblrebate where tblrebate.rebateId=:rebateId",var);        
         return cnt!=0;

     }
     /**
      * @author Krunal.patel
      * @param tenderId
      * @return List<Object[]>
      * @throws Exception 
      */
     public List<Object[]> getRebateForm(int rebateId) throws Exception{
     	 StringBuilder query = new StringBuilder();
         List<Object[]> list = null;
         Map<String, Object> var = new HashMap<String, Object>();
        // var.put("rebateId",rebateId);
         var.put("rebateId",rebateId);
         query.append("select tblrebate.isRebateForm, tblrebate.reportName,tbltenderform.formName,tbltendertable.tableName, tbltendercolumn.columnHeader ")
         .append("FROM TblRebate tblrebate ")
         .append("INNER JOIN tblrebate.tblRebateForm tblrebateform ")
         .append("INNER JOIN tblrebateform.tblTenderForm tbltenderform with tbltenderform.cstatus in (0,1) ")
         .append("INNER JOIN tblrebateform.tblTenderCell tbltendercell ")
         .append("INNER JOIN tbltendercell.tblTenderColumn tbltendercolumn ")
         .append("INNER JOIN tbltendercolumn.tblTenderTable tbltendertable with tbltendertable.isMandatory=1 ")
         .append("WHERE tblrebate.rebateId = :rebateId");
         list = hibernateQueryDao.createNewQuery(query.toString(),var);
         return list;        

     }
     
     /**
      * @author Krunal.patel
      * @param tblDocuments
      * @return boolean
      * @throws Exception 
      */
     public boolean addReqDocuments(List<TblDocument> tblDocuments) throws Exception{
     boolean bSuccess = false;             
                 tblDocumentDao.saveUpdateAllTblDocument(tblDocuments);
             bSuccess=true;        
         return bSuccess;

     }
     /**
      * @author Krunal.patel
      * @param formId
      * @param tblDocuments
      * @return boolean
      * @throws Exception 
      */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean updateReqDocuments(int formId,List<TblDocument> tblDocuments) throws Exception{
     boolean bSuccess = false;
     
     			/*** Delete all old record **/
     			bSuccess = deleteDocumentByObjectId(formId);
     			
     			/*** Insert new record after delete all records **/
     			if(bSuccess){
     				tblDocumentDao.saveUpdateAllTblDocument(tblDocuments);
     				bSuccess=true;
     			}	
             return bSuccess;
     }
     /**
      * @author Krunal.patel
      * @param objectId
      * @return TblDocument List
      * @throws Exception 
      */
     public List<TblDocument> getDocumentsByObjectId(int objectId) throws Exception{
         List<TblDocument> list = null;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("objectId",objectId);
         list = tblDocumentDao.findTblDocument("objectId",Operation_enum.EQ,objectId);
         return list;
     }
     
     /**
      * @author Krunal.patel
      * @param objectId
      * @return boolean
      * @throws Exception 
      */
     public boolean deleteDocumentByObjectId(int objectId) throws Exception{
         int cnt = 0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("objectId",objectId);
         cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblDocument tbldocument where tbldocument.objectId=:objectId",var);        
         return cnt!=0;
     }
     
     /*
      * author : heeral.soni
      * used to check minEvaluator 
      */
     public List<Object[]>  getTenderEnvelopeData(int tenderId,int envelopeId) throws Exception{
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("envelopeId",envelopeId);
         var.put("tenderId",tenderId);
         StringBuilder query = new StringBuilder();
         query.append("select tbltenderenvelope.minEvaluator,tbltenderenvelope.minOpeningMember ");
         query.append("from TblTenderEnvelope tbltenderenvelope ");
         query.append("where tbltenderenvelope.tblTender.tenderId=:tenderId and tbltenderenvelope.envelopeId=:envelopeId");
         return hibernateQueryDao.createNewQuery(query.toString(),var);
     }
     
     /**
      * @author Krunal.patel
      * @param tenderId
      * @param envelopId
      * @param committeeUserId
      * @param committeeId
      * @param approvedBy
      * @param remark
      * @param minOpeningMember
      * @param committeeType
      * @return boolean
      * @throws Exception 
      */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean updateUserComiteByComiteUserId(int tenderId,int envelopeId,int committeeUserId,int committeeId, int approvedBy,String remark,int minOpeningMember,int committeeType) throws Exception{
    	 boolean success=false;
    	 int cnt = 0;
    	 int isOpenCount = 0;
         int minEvaluator = -1;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("committeeUserId",committeeUserId);
         var.put("approvedBy",approvedBy);
         var.put("remark",remark);
         var.put("isApproved",ISAPPROVEYES);
         
         /*** Code to update TblCommitteeUser **/
         cnt = hibernateQueryDao.updateDeleteNewQuery("update TblCommitteeUser set isApproved=:isApproved , approvedBy=:approvedBy , approvedOn=getutcdate() , remarks=:remark where committeeUserId=:committeeUserId",var); 
         
         if(cnt!=0){
        	
        	 /*** Services Call to get CommitteeUser by envelopeId and CommitteeId where is approved status is yes like 1**/
        	 isOpenCount = getComiteUserByComiteIdAndEnvId(committeeId, envelopeId, ISAPPROVEYES);
                 
        	 if(minOpeningMember == isOpenCount){
    			 
        		 /*** Services Call for update status in TblTenderEnvelope table**/
        		 success = updateTenderEnvelopeByEnvId(envelopeId, ISAPPROVEYES,committeeType);
        		 int committeCreated = tenderCommonService.getActiveCommittee(tenderId,2);
                         List<Object[]> lstEnvelope = getTenderEnvelopeData(tenderId,envelopeId);
                         if(!lstEnvelope.isEmpty()){
                             minEvaluator = Integer.parseInt(lstEnvelope.get(0)[0].toString());
                         }
                         if(success && committeeType==1 && minEvaluator==0 && committeCreated!=0){
                        	 	 boolean isCommitteePublished = getPendingCommittee(tenderId,2,0);
//	                             int tenderStage = (Integer)tenderCommonService.getTenderField(tenderId,"envelopeType");
//	                             if(tenderStage==2){
	                                 // multiple stage(manual opening and auto evaluation)
	                                 autoOpeningEvaluation(tenderId,envelopeId,approvedBy,"fromEvaluatioTab",isCommitteePublished);
//	                             }else{
	                                 // single stage(manual opening and auto evaluation)
//	                                 autoOpeningEvaluation(tenderId,envelopeId,approvedBy,"fromEvaluatioTab",isCommitteePublished);
//	                             }
                        }
        		 return success;
    		 }
        	 success = true;
        	 return success;
         }
         return success;
     }
     
          
     /*
      * author : heeral.soni
      * used to auto update in opening and evaluation for auto opening/evaluation
      */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class}) 
     public boolean autoOpeningEvaluation(int tenderId,int envelopeId,int userDetailId,String from,boolean isCommitteePublished) throws Exception{
         boolean bSuccess = false;
         updateTenderEnvelope(tenderId,envelopeId,from,isCommitteePublished);
         updateCommitteeUser(tenderId,envelopeId,userDetailId,from,isCommitteePublished);
         bSuccess = true;
         return bSuccess;
     }
     
    public boolean isPriceBidFormDecrypted(int tenderId,int envelopeId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("envelopeId", envelopeId);
        count = hibernateQueryDao.countForNewQuery("TblTenderOpen tbltenderopen ", "tbltenderopen.tenderOpenId ", "tbltenderopen.tblTender.tenderId=:tenderId and tbltenderopen.tblTenderEnvelope.envelopeId=:envelopeId", var);
        return count != 0;
    }
     /*
      * author : heeral.soni
      * used to update appTenderEnvelope when auto opening/evaluation case
      */
     public boolean updateTenderEnvelope(int tenderId,int envelopeId,String from,boolean isCommitteePublished) throws Exception{
         Map<String, Object> var = new HashMap<String, Object>();
         StringBuilder query = null;
         if("fromOpeningTab".equalsIgnoreCase(from)){
            //auto opening and manual evaluation case
             var.put("envelopeId",envelopeId);
             query = new StringBuilder();
            query.append("update TblTenderEnvelope set isOpened=1 where envelopeId=:envelopeId");	  
         } else if("fromAuto".equalsIgnoreCase(from)){
            //auto opening as well as auto evaluation case
             var.put("envelopeId",envelopeId);
             query = new StringBuilder();
            query.append("update TblTenderEnvelope set isOpened=1,isEvaluated=1 where envelopeId=:envelopeId");	 
         } else if("fromEvaluatioTab".equalsIgnoreCase(from) && !isCommitteePublished){
            //set isevaluated=1 for particular envelope - manual opening and auto evaluation case(multiple stage)
             var.put("envelopeId",envelopeId);
             query = new StringBuilder();
            query.append("update TblTenderEnvelope set isEvaluated=1 where envelopeId=:envelopeId");	   
         } else if("fromEvaluatioTabSingleStage".equalsIgnoreCase(from) && !isCommitteePublished){
            //set isevaluated=1 for all envelope base on tenderid - manual opening and auto evaluation case(single stage)
            var.put("tenderId",tenderId);
            query = new StringBuilder();
            query.append("update TblTenderEnvelope tbltenderenvelope set tbltenderenvelope.isEvaluated=1 where tbltenderenvelope.tblTender.tenderId=:tenderId");	   
         }
         if(query!=null){
        	 int cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
        	 return cnt!=0;
         }
         return true;
         //System.out.println("cnt updateTenderEnvelope= " + cnt);
         

     }
     /*
      * author : heeral.soni
      * used to update TblCommitteeUser when auto opening/evaluation case
      */
     public boolean updateCommitteeUser(int tenderId,int envelopeId,int userDetailId,String from,boolean isCommitteePublished) throws Exception{
         Map<String, Object> var = new HashMap<String, Object>();
         StringBuilder query = null;
         var.put("userDetailId", userDetailId);
         if("fromOpeningTab".equalsIgnoreCase(from)){
             //auto opening and manual evaluation case
             var.put("tenderId",tenderId);
             var.put("envelopeId",envelopeId);
             query = new StringBuilder();
             query.append("update TblCommitteeUser tblcommitteeuser ");	 
             query.append("set tblcommitteeuser.isApproved=1,tblcommitteeuser.approvedOn=getutcdate(),tblcommitteeuser.approvedBy=:userDetailId ");	 
             query.append("where tblcommitteeuser.childId=:envelopeId and tblcommitteeuser.tblCommittee.committeeId in (");	 
             query.append("select tblcommittee.committeeId from TblCommittee tblcommittee where tblcommittee.tblTender.tenderId=:tenderId and tblcommittee.committeeType=1)");
         }else if("fromEvaluatioTab".equalsIgnoreCase(from) && !isCommitteePublished){
             //manual opening and auto evaluation case(multiple stage)
             var.put("tenderId",tenderId);
             var.put("envelopeId",envelopeId);
             query = new StringBuilder();
             query.append("update TblCommitteeUser tblcommitteeuser ");	 
             query.append("set tblcommitteeuser.isApproved=1,tblcommitteeuser.approvedOn=getutcdate(),tblcommitteeuser.approvedBy=:userDetailId ");	 
             query.append("where tblcommitteeuser.childId=:envelopeId and tblcommitteeuser.tblCommittee.committeeId in (");	 
             query.append("select tblcommittee.committeeId from TblCommittee tblcommittee where tblcommittee.tblTender.tenderId=:tenderId and tblcommittee.committeeType=2)");
         }else if("fromEvaluatioTabSingleStage".equalsIgnoreCase(from) && !isCommitteePublished){
             //manual opening and auto evaluation case(single stage)
             var.put("tenderId",tenderId);
             query = new StringBuilder();
             query.append("update TblCommitteeUser tblcommitteeuser ");	 
             query.append("set tblcommitteeuser.isApproved=1,tblcommitteeuser.approvedOn=getutcdate(),tblcommitteeuser.approvedBy=:userDetailId ");	 
             query.append("where tblcommitteeuser.tblCommittee.committeeId in (");	 
             query.append("select tblcommittee.committeeId from TblCommittee tblcommittee where tblcommittee.tblTender.tenderId=:tenderId and tblcommittee.committeeType=2)");
         }else if(!isCommitteePublished){
             //auto opening as well as auto evaluation case
             var.put("envelopeId",envelopeId);
             query = new StringBuilder();
             query.append("update TblCommitteeUser tblcommitteeuser set tblcommitteeuser.isApproved=1,tblcommitteeuser.approvedOn=getutcdate(),tblcommitteeuser.approvedBy=:userDetailId  where tblcommitteeuser.childId=:envelopeId");	 
         }
         if(query!=null){
        	 int cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);
        	 return cnt!=0;
         }
         return true;
         //System.out.println("cnt updateCommitteeUser= " + cnt);
         

     }
     /**
      * @author Krunal.patel
      * @param committeeId
      * @param envelopeId
      * @param isApproved
      * @return Integer
      * @throws Exception 
      */
     public int getComiteUserByComiteIdAndEnvId(int committeeId,int envelopeId,int isApproved) throws Exception{
         int data=0;
         List<Object> list = null;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("committeeId",committeeId);
         var.put("envelopeId",envelopeId);
         var.put("isApproved",isApproved);
         list = hibernateQueryDao.getSingleColQuery("select tblcommitteeuser.isApproved, tblcommitteeuser.tblCommittee.committeeId, tblcommitteeuser.childId from TblCommitteeUser tblcommitteeuser where tblcommitteeuser.tblCommittee.committeeId=:committeeId and tblcommitteeuser.childId=:envelopeId and tblcommitteeuser.isApproved=:isApproved",var);
         if(list != null && ! list.isEmpty()){
        	 data = list.size();
         }
 return data;

     }
     
     /**
      * @author Krunal.patel
      * @param envelopeId
      * @param isOpened
      * @return boolean
      * @throws Exception 
      */
     public boolean updateTenderEnvelopeByEnvId(int envelopeId,int isOpened,int committeeType) throws Exception{
         int cnt = 0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("envelopeId",envelopeId);
         StringBuilder query = new StringBuilder();
         
         if(committeeType == 1){
        	 var.put("isOpened",isOpened);
        	 query.append("update TblTenderEnvelope set isOpened=:isOpened where envelopeId=:envelopeId");	 
         }
         else if(committeeType == 2){
        	 var.put("isEvaluated",isOpened);
        	 query.append("update TblTenderEnvelope set isEvaluated=:isEvaluated where envelopeId=:envelopeId");
         }
         
         cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);        
         return cnt!=0;

     }
     /**
     * author : heeral.soni 
     * used to get envelope name based on envelope id
     * @param envelopeId
     * @return
     * @throws Exception 
     */
    public List<Object> getEnvelopeNameById(int envelopeId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId",envelopeId);
        List<Object> list = hibernateQueryDao.getSingleColQuery("select tbltenderenvelope.envelopeName from  TblTenderEnvelope tbltenderenvelope where tbltenderenvelope.envelopeId=:envelopeId",var);                
        return list;        
    }
     
     /**
      * @author heeral.soni
      * Use to update envelope name from bidding form tab
      * @return boolean
      * @throws Exception 
      */
     public boolean updateTenderEnvelopeName(int envelopeId,String envelopeName) throws Exception{
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("envelopeId",envelopeId);
         var.put("envelopeName",envelopeName);
         StringBuilder query = new StringBuilder();
         query.append(" update TblTenderEnvelope set envelopeName=:envelopeName where envelopeId=:envelopeId");
         int cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);        
         return cnt!=0;

     }
     /**
      * @author Krunal.patel
      * @param tenderId
      * @param envelopeId
      * @param preEnvelopeId
      * @param envelopeType
      * @param IsConsortiumAllowed
      * @param sortOrder
      * @param createEditFlage 
      * @return Map<String,Object>
      * @throws Exception 
      */
     public Map<String,Object> getEvaluateBiddersList(int tenderId,int envelopeId,int preEnvelopeId,int envelopeType,int IsConsortiumAllowed,int sortOrder,int createEditFlage) throws Exception{
    	 Map<String,Object> list;
    	 list = sPGetBidderListForEvaluation.executeProcedure(tenderId,envelopeId,preEnvelopeId,envelopeType,IsConsortiumAllowed,sortOrder,createEditFlage);
		return list;        
     }
     /**
      * @author Krunal.patel
      * @param tenderId
      * @param envelopeId
      * @return boolean
      * @throws Exception 
      */
     public  boolean checkEntryBidderAppDtls(int tenderId,int envelopeId) throws Exception{
             List<TblBidderApprovalDetail> list = null;        
             list = tblBidderApprovalDetailDao.findTblBidderApprovalDetail("tblTender.tenderId",Operation_enum.EQ,tenderId,"tblTenderEnvelope.envelopeId",Operation_enum.EQ,envelopeId);                
             if(!list.isEmpty()){
            	 return false;
             }else{
            	 return true;
             }             

     } 
     /**
      * @author Krunal.patel
      * @param tblBidderApprovalDetails
      * @return boolean
      * @throws Exception 
      */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean addBidderAprvalDtls(List<TblBidderApprovalDetail> tblBidderApprovalDetails) throws Exception{
     boolean bSuccess = false;    
     				/*** Code to insert row in TblBidderApprovalDetail by list **/
                 tblBidderApprovalDetailDao.saveUpdateAllTblBidderApprovalDetail(tblBidderApprovalDetails);
                 
                 /*** Code to insert row in TblBidderApprovalDetail history table **/
                 bSuccess = addBidderAprvalDtlsHist(tblBidderApprovalDetails,0);
         return bSuccess;
     }
     /**
      * @author Krunal.patel
      * @param tblBidderApprovalDetails
      * @return boolean
      * @throws Exception 
      */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean addBidderAprvalDtls(List<TblBidderApprovalDetail> tblBidderApprovalDetails,List<TblTenderOpen> tblTenderOpenList,List<TblTenderBidOpenSign> tblTenderBidOpenSignList,List<TblTenderBidDetail> tblTenderBidDetailList) throws Exception{
     boolean bSuccess = false;    
     				/*** Code to insert row in TblBidderApprovalDetail by list **/
                 tblBidderApprovalDetailDao.saveUpdateAllTblBidderApprovalDetail(tblBidderApprovalDetails);
                 
                 /*** Code to insert row in TblBidderApprovalDetail history table **/
                 bSuccess = addBidderAprvalDtlsHist(tblBidderApprovalDetails,0);
                 
                 /*** Code to insert row in TblTenderOpen ,TblTenderBidOpenSign, TblTenderBidDetail **/
                 if(tblTenderOpenList != null && !tblTenderOpenList.isEmpty() &&
                	tblTenderBidOpenSignList != null && !tblTenderBidOpenSignList.isEmpty() &&
                	tblTenderBidDetailList != null && !tblTenderBidDetailList.isEmpty()){
                	 addTenderBidOpenDetails(tblTenderOpenList, tblTenderBidOpenSignList, tblTenderBidDetailList);	 
                 }
                 
                 
         return bSuccess;
     }
      /**
      * @author Mitesh Patel
      * @param tblCommitteeRemarks
      * @return boolean
      * @throws Exception 
      */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean addCommiteeRemarksDetails(List<TblCommitteeRemarks> tblCommitteeRemarks,int... parameters) throws Exception{
     boolean bSuccess = true;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", parameters[0]);
        var.put("envelopeId", parameters[1]);
        var.put("officerId", parameters[2]);
        //1
        query.append("update TblCommitteeRemarks tblCommitteeRemarks set tblCommitteeRemarks.isActive=0 where tblCommitteeRemarks.tblTender.tenderId=:tenderId and ")
                .append(" tblCommitteeRemarks.tblTenderEnvelope.envelopeId=:envelopeId and  tblCommitteeRemarks.tblUserLogin.userId=:officerId ");
         int result = hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
         //2
         tblCommitteeRemarksDao.saveUpdateAllTblCommitteeRemarks(tblCommitteeRemarks);
         //3
         if(parameters[3]!=0){
            query = new StringBuilder();
            var = new HashMap<String, Object>();
            var.put("evalReworkId", parameters[3]);
            query.append("update TblEvaluationRework tblEvaluationRework set tblEvaluationRework.cstatus=1 where tblEvaluationRework.evalReworkId=:evalReworkId ");                
            result = hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
            query = new StringBuilder();
            query.append("update TblReworkDetail tblReworkDetail set tblReworkDetail.cstatus=1 where tblReworkDetail.tblEvaluationRework.evalReworkId=:evalReworkId ");                
            result = hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
         }
        return bSuccess;
     }
     
     /**
      * method to save data it is create in this services because of complex logic in bhavin code
      * author bhavin.patel/krunal.patel 
      * @param tblTenderOpenList
      * @param tblTenderBidOpenSignList
      * @param tblTenderBidDetailList
      * @return
      * @throws Exception
      */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean addTenderBidOpenDetails(List<TblTenderOpen> tblTenderOpenList, List<TblTenderBidOpenSign> tblTenderBidOpenSignList, List<TblTenderBidDetail> tblTenderBidDetailList) throws Exception {
         boolean bSuccess = false;
         if(!tblTenderOpenList.isEmpty() && !tblTenderBidDetailList.isEmpty()){
         	tblTenderOpenDao.saveUpdateAllTblTenderOpen(tblTenderOpenList);
         	tblTenderBidOpenSignDao.saveUpdateAllTblTenderBidOpenSign(tblTenderBidOpenSignList);
         	tblTenderBidDetailDao.saveUpdateAllTblTenderBidDetail(tblTenderBidDetailList);
         }
         bSuccess = true;
         return bSuccess;
     }
     /**
      * Insert record in TblBidderApprovalDetail when rejected bidder is approved while doing reevaluation, 
      * when envelope type is multiple and nonpki domain
      * author anjali 
      * @param tblTenderBidDetailList
      * @return
      * @throws Exception
      */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean addTenderBidOpenDetails(List<TblTenderOpen> tblTenderOpenList) throws Exception {
         boolean bSuccess = false;
         tblTenderOpenDao.saveUpdateAllTblTenderOpen(tblTenderOpenList);
         bSuccess = true;
         return bSuccess;
     }
     /**
      * @author Krunal.patel
      * @param envelopeId
      * @param tblBidderApprovalDetails
      * @return boolean
      * @throws Exception 
      */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean updateBidderAprvalDtls(int envelopeId,List<TblBidderApprovalDetail> tblBidderApprovalDetails) throws Exception{
     boolean bSuccess = false;
     
			     /*** Code to get all row from TblBidderApprovalDetail by envelopeId and insert in history table **/
     			bSuccess = addBidderAprvalDtlsHist(tblBidderApprovalDetails,0);
			    
     			/*** Code to delete all row from TblBidderApprovalDetail by envelopeId **/
     			if(bSuccess){
     				bSuccess = deleteBiderAprvalDtlsByEnvelopeId(envelopeId);	
     			}else{
     				bSuccess = false;
     			}
     			
     			/*** Code to add new row in TblBidderApprovalDetail by list **/
     			if(bSuccess){
     				tblBidderApprovalDetailDao.saveUpdateAllTblBidderApprovalDetail(tblBidderApprovalDetails);	
     			}else{
     				bSuccess = false;
     			}
             return bSuccess;

     }
     /**
      * @author Krunal.patel
      * @param envelopeId
      * @param tblBidderApprovalDetails
      * @return boolean
      * @throws Exception 
      */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean updateBidderAprvalDtls(int envelopeId,List<TblBidderApprovalDetail> tblBidderApprovalDetails,int tenderReEvalId) throws Exception{
     boolean bSuccess = false;
     
			     /*** Code to get all row from TblBidderApprovalDetail by envelopeId and insert in history table **/
     			bSuccess = addBidderAprvalDtlsHist(tblBidderApprovalDetails,tenderReEvalId);
			    
     			/*** Code to delete all row from TblBidderApprovalDetail by envelopeId **/
     			if(bSuccess){
     				bSuccess = deleteBiderAprvalDtlsByEnvelopeId(envelopeId);	
     			}else{
     				bSuccess = false;
     			}
     			
     			/*** Code to add new row in TblBidderApprovalDetail by list **/
     			if(bSuccess){
     				tblBidderApprovalDetailDao.saveUpdateAllTblBidderApprovalDetail(tblBidderApprovalDetails);	
     			}else{
     				bSuccess = false;
     			}
             return bSuccess;

     }
     
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean updateBidderAprvalDtlsForReevaluation(int envelopeId,List<TblBidderApprovalDetail> tblBidderApprovalDetails,int tenderReEvalId,List<TblTenderOpen> tblTenderOpenList,List<TblTenderBidOpenSign> tblTenderBidOpenSignList,List<TblTenderBidDetail> tblTenderBidDetailList) throws Exception{
     boolean bSuccess = false;
     
			     /*** Code to get all row from TblBidderApprovalDetail by envelopeId and insert in history table **/
     			bSuccess = addBidderAprvalDtlsHist(tblBidderApprovalDetails,tenderReEvalId);
     			
			    
     			/*** Code to delete all row from TblBidderApprovalDetail by envelopeId **/
     			if(bSuccess){
     				bSuccess = deleteBiderAprvalDtlsByEnvelopeId(envelopeId);	
     			}else{
     				bSuccess = false;
     			}
     			
     			/*** Code to add new row in TblBidderApprovalDetail by list **/
     			if(bSuccess){
     				tblBidderApprovalDetailDao.saveUpdateAllTblBidderApprovalDetail(tblBidderApprovalDetails);	
     			}else{
     				bSuccess = false;
     			}
    			 if(tblTenderOpenList != null && !tblTenderOpenList.isEmpty() &&
             	tblTenderBidOpenSignList != null && !tblTenderBidOpenSignList.isEmpty() &&
             	tblTenderBidDetailList != null && !tblTenderBidDetailList.isEmpty()){
             	 addTenderBidOpenDetails(tblTenderOpenList, tblTenderBidOpenSignList, tblTenderBidDetailList);	 
    			 }
    			 else if(tblTenderOpenList != null && !tblTenderOpenList.isEmpty()){
    				 addTenderBidOpenDetails(tblTenderOpenList);
    			 }
             return bSuccess;

     }
     /**
      * @author Lipi Shah
      * @param envelopeId
      * @return List<TblTenderEnvelope>
      * @throws Exception 
      */
     public  TblTenderEnvelope getEnvlopeIdAsSortorder(int sortOrder,int tenderId) throws Exception{
         List<TblTenderEnvelope> list = null;        
         list = tblTenderEnvelopeDao.findTblTenderEnvelope("sortOrder",Operation_enum.EQ,sortOrder,"tblTender.tenderId",Operation_enum.EQ,tenderId);                
         return (list!=null && !list.isEmpty()) ? list.get(0) : null;  

     }
     /**
      * @author Krunal.patel
      * @param envelopeId
      * @return List<TblBidderApprovalDetail>
      * @throws Exception 
      */
     public  List<TblBidderApprovalDetail> getBidderApprovalDetail(int envelopeId) throws Exception{
             List<TblBidderApprovalDetail> list = null;        
         list = tblBidderApprovalDetailDao.findTblBidderApprovalDetail("tblTenderEnvelope.envelopeId",Operation_enum.EQ,envelopeId,"isApproved",Operation_enum.EQ,1);                
             return list;

     }
     /**
      * @author Krunal.patel
      * @param envelopeId
      * @return boolean
      * @throws Exception 
      */
     public boolean deleteBiderAprvalDtlsByEnvelopeId(int envelopeId) throws Exception{
         int cnt = 0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("envelopeId",envelopeId);
         cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblBidderApprovalDetail tblbidderapprovaldetail where tblbidderapprovaldetail.tblTenderEnvelope.envelopeId=:envelopeId",var);        
         return cnt!=0;

     }
     
     /**
      * @author Krunal.patel
      * @param bidderApprovalDtlsHist
      * @return boolean
      * @throws Exception 
      */
     public boolean addBidderAprvalDtlsHist(List<TblBidderApprovalDetail> tblBidderApprovalDetails,int tenderReEvalId) throws Exception{
     boolean bSuccess = false; 
     
     List<TblBidderApprovalHistory> tblBidderAprvlHistList = new ArrayList<TblBidderApprovalHistory>();
     
     for(TblBidderApprovalDetail tblBidderApprovalDtls:tblBidderApprovalDetails){
    	 TblBidderApprovalHistory tblBidderAprvlHist = new TblBidderApprovalHistory();
    	 //tblBidderAprvlHist.setBidderApprovalHistoryId();
    	 tblBidderAprvlHist.setTenderId(tblBidderApprovalDtls.getTblTender().getTenderId());
    	 tblBidderAprvlHist.setEnvelopeId(tblBidderApprovalDtls.getTblTenderEnvelope().getEnvelopeId());
    	 tblBidderAprvlHist.setCompanyId(tblBidderApprovalDtls.getTblCompany().getCompanyId());
    	 tblBidderAprvlHist.setBidderId(tblBidderApprovalDtls.getTblUserLogin().getUserId());
    	 tblBidderAprvlHist.setUserDetailId(tblBidderApprovalDtls.getTblUserDetail().getUserDetailId());
    	 tblBidderAprvlHist.setFinalSubmissionId(tblBidderApprovalDtls.getTblFinalSubmission().getFinalSubmissionId());
    	 tblBidderAprvlHist.setRemarks(tblBidderApprovalDtls.getRemarks());
    	 //tblBidderAprvlHist.setCreatedOn();
    	 tblBidderAprvlHist.setCreatedBy(tblBidderApprovalDtls.getCreatedBy());
    	 tblBidderAprvlHist.setIsApproved(tblBidderApprovalDtls.getIsApproved());
    	 tblBidderAprvlHist.setTenderReEvalId(tenderReEvalId);
    	 tblBidderAprvlHistList.add(tblBidderAprvlHist);
     }
                 tblBidderApprovalHistoryDao.saveUpdateAllTblBidderApprovalHistory(tblBidderAprvlHistList);
             bSuccess=true;        
         return bSuccess;

     }
     
     /**
     * Get Combo (Id,Value) pair for comboId
     * @param comboId
     * @return  {@code List<TblComboDetail>}
     * @throws Exception 
     */
    public  List<TblComboDetail> getComboDetailByComboId(Object[] comboId) throws Exception{
        return  tblComboDetailDao.findTblComboDetail("tblCombo.comboId",Operation_enum.IN,comboId,"tblCombo.comboId",Operation_enum.ORDERBY,Operation_enum.ASC);
//        List<TblComboDetail> comboDetails = new ArrayList<TblComboDetail>();        
//        Map<String, Object> var = new HashMap<String, Object>();
//        var.put("comboId",comboId);
//        List<Object[]> list = hibernateQueryDao.createNewQuery("select tblcombodetail.isDefault,tblcombodetail.optionName,tblcombodetail.optionValue,tblcombodetail.tblCombo.comboId,tblcombodetail.comboDetailId from TblComboDetail tblcombodetail where tblcombodetail.tblCombo.comboId in (:comboId) order by tblcombodetail.tblCombo.comboId asc", var);
//        for (Object[] obj : list) {
//            TblComboDetail comboDetail = new TblComboDetail();
//            comboDetail.setComboDetailId((Integer)obj[4]);
//            comboDetail.setIsDefault((Integer)obj[0]);
//            comboDetail.setOptionName(obj[1].toString());
//            comboDetail.setOptionValue(obj[2].toString());
//            comboDetail.setTblCombo((new TblCombo((Integer)obj[3])));
//            comboDetails.add(comboDetail);
//        }
//        return comboDetails;

    }

    
    /**
     * 
     * @param userId
     * @param clientFieldId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getBidderMasterFieldValue(int userId,Object[] clientFieldId,int linkId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId",userId);
        var.put("clientFieldId",clientFieldId);
        var.put("linkId",linkId);
        StringBuilder query = new StringBuilder();
        query.append("select tblclientfield.clientFieldId,tbldynfield.tblDynControlType.controlTypeId,tbldynfield.defaultValues,tbldynfield.selectedValue,tblfieldvalue.value ");
        query.append("from  TblDynField tbldynfield inner join  tbldynfield.tblClientField tblclientfield left join tblclientfield.tblFieldValue tblfieldvalue ");
        query.append("with tblfieldvalue.objectId=:userId and tblfieldvalue.isActive=1 ");
        query.append("where tblclientfield.tblLink.linkId=:linkId and tblclientfield.isActive=1 and tblclientfield.clientFieldId in (:clientFieldId)");        
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        
    }
    
     /**
     * Check where TenderForm is PriceBid
     * @param formId
     * @return true for Yes; false for No
     * @throws Exception 
     */
    public boolean getIsPriceBidForm(int formId) throws Exception{
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(FORMID,formId);
        list = hibernateQueryDao.getSingleColQuery("select tbltenderform.isPriceBid from TblTenderForm tbltenderform where tbltenderform.formId=:formId",var);
        return list.isEmpty() ? false : (Integer)list.get(0)==1;
    }
    
    /**
     * to get tender governing columns based on the tender id
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderGovCols(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query=new StringBuilder("select tbltenderform.formName,tbltendertable.tableName,tbltendercolumn.columnHeader,tbltenderform.formId,tbltendertable.tableId,");
        query.append(" tbltendercolumn.columnId,tbltendercolumn.columnNo,tbltendercell.cellId,tbltendergovcolumn.tblTenderColumn.columnId ");
        query.append(" from TblTenderForm tbltenderform ");
        query.append(" inner join tbltenderform.tblTenderTable tbltendertable ");
        query.append(" inner join tbltendertable.tblTenderColumn tbltendercolumn ");
        query.append(" inner join tbltendercolumn.tblTenderCell tbltendercell ");
        query.append(" inner join tbltendercolumn.tblTenderFormula tbltenderformula ");
        query.append(" left join tbltendercolumn.tblTenderGovColumn tbltendergovcolumn ");
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltendercell.rowId=tbltendertable.noOfRows and tbltenderform.isPriceBid=1 and  tbltenderform.cstatus!=2 ");
        query.append(" and tbltendertable.hasGTRow=1 and tbltenderformula.formula like 'TOTAL(%' ");
        query.append(" order by tbltenderform.sortOrder,tbltendertable.sortOrder desc ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);        

    }
    
    /**
     * to get tender governing columns based on the tender id for view
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderGovColsForView(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query=new StringBuilder("select tbltenderform.formName,tbltendertable.tableName,tbltendercolumn.columnHeader,tbltenderform.formId,tbltendertable.tableId,");
        query.append(" tbltendercolumn.columnId,tbltendercolumn.columnNo,tbltendercell.cellId,tbltendergovcolumn.tblTenderColumn.columnId ");
        query.append(" from TblTenderForm tbltenderform ");
        query.append(" inner join tbltenderform.tblTenderTable tbltendertable ");
        query.append(" inner join tbltendertable.tblTenderColumn tbltendercolumn ");
        query.append(" inner join tbltendercolumn.tblTenderCell tbltendercell ");
        query.append(" inner join tbltendercolumn.tblTenderFormula tbltenderformula ");
        query.append(" inner join tbltendercolumn.tblTenderGovColumn tbltendergovcolumn ");
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltendercell.rowId=tbltendertable.noOfRows and tbltenderform.isPriceBid=1 and  tbltenderform.cstatus!=2 ");
        query.append(" and tbltendertable.hasGTRow=1 and tbltenderformula.formula like 'TOTAL(%' ");
        query.append(" order by tbltenderform.sortOrder,tbltendertable.sortOrder desc ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);        

    }
    
    /**
     * to get tender governing columns item wise based on the tender id
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderGovColsItemWise(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query=new StringBuilder("select tbltenderform.formName,tbltendertable.tableName,tbltendercolumn.columnHeader,tbltenderform.formId,tbltendertable.tableId,");
        query.append(" tbltendercolumn.columnId,tbltendercolumn.columnNo,0 as cellId,tbltendergovcolumn.tblTenderColumn.columnId ");
        query.append(" from TblTenderForm tbltenderform ");
        query.append(" inner join tbltenderform.tblTenderTable tbltendertable ");
        query.append(" inner join tbltendertable.tblTenderColumn tbltendercolumn ");
        query.append(" left join tbltendercolumn.tblTenderGovColumn tbltendergovcolumn ");
        //query.append(" inner join tbltendercolumn.tblTenderCell tbltendercell ");
        //query.append(" inner join tbltendercolumn.tblTenderFormula tbltenderformula ");
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isPriceBid=1 ");
        query.append(" and  tbltenderform.cstatus!=2 and tbltendercolumn.tblColumnType.columnTypeId in (4,5) ");
        query.append(" order by tbltenderform.sortOrder,tbltendertable.sortOrder desc ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);        

    }
    
    /**
     * to get tender governing columns item wise based on the tender id for view
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderGovColsItemWiseForView(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query=new StringBuilder("select tbltenderform.formName,tbltendertable.tableName,tbltendercolumn.columnHeader,tbltenderform.formId,tbltendertable.tableId,");
        query.append(" tbltendercolumn.columnId,tbltendercolumn.columnNo,0 as cellId,tbltendergovcolumn.tblTenderColumn.columnId ");
        query.append(" from TblTenderForm tbltenderform ");
        query.append(" inner join tbltenderform.tblTenderTable tbltendertable ");
        query.append(" inner join tbltendertable.tblTenderColumn tbltendercolumn ");
        query.append(" inner join tbltendercolumn.tblTenderGovColumn tbltendergovcolumn ");
        //query.append(" inner join tbltendercolumn.tblTenderCell tbltendercell ");
        //query.append(" inner join tbltendercolumn.tblTenderFormula tbltenderformula ");
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isPriceBid=1 ");
        query.append(" and  tbltenderform.cstatus!=2 and tbltendercolumn.tblColumnType.columnTypeId in (4,5) ");
        query.append(" order by tbltenderform.sortOrder,tbltendertable.sortOrder desc ");
        return hibernateQueryDao.createNewQuery(query.toString(),var);        

    }
    
    /**
     * to add tender governing column list
     * @param tblTenderGovColumnList
     * @return
     * @throws Exception 
     */
    public boolean addGovColumns(List<TblTenderGovColumn> tblTenderGovColumnList) throws Exception{
    	boolean bSuccess = false;             
        tblTenderGovColumnDao.saveUpdateAllTblTenderGovColumn(tblTenderGovColumnList);
        bSuccess=true;        
        return bSuccess;
    }


    /**
     * 
     * @param tenderId
     * @param tblTenderGovColumnList
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean editGovColumns(int tenderId,List<TblTenderGovColumn> tblTenderGovColumnList) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderGovColumn tbltendergovcolumn where tbltendergovcolumn.tblTender.tenderId=:tenderId",var);
        addGovColumns(tblTenderGovColumnList);
        return cnt!=0;
    }    
    
    /**
     * @author VIPULP
     * @param tableId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getItemDescFormData(int tableId) throws Exception{
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId",tableId);
        
        query.append("select tbltendercell.tblTenderTable.tableId,tbltendercolumn.columnId,tbltendercell.tblTenderForm.formId,")
                .append("tbltendercell.rowId,tbltendercell.cellValue ")
                .append(" from TblTenderCell tbltendercell ")
                .append("inner join tbltendercell.tblTenderColumn tbltendercolumn with tbltendercolumn.tblColumnType.columnTypeId=1 ")
                .append("where tbltendercell.tblTenderTable.tableId=:tableId");
        
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    
    /**
     * 
     * @param tableId
     * @param companyId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getProxyCellData(int tableId,int companyId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId",tableId);
        var.put("companyId",companyId);
        list = hibernateQueryDao.createNewQuery("select tbltenderproxybid.tblTenderCell.cellId, tbltenderproxybid.cellValue from TblTenderProxyBid tbltenderproxybid where tbltenderproxybid.tblCompany.companyId=:companyId and tbltenderproxybid.tblTenderTable.tableId=:tableId",var);                
        return list;        

    }
    
    /**
     * 
     * @param tenderId
     * @param userId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getBidderItem(int tenderId,int userId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("userId",userId);
        list = hibernateQueryDao.createNewQuery("select tblitembiddermap.tblTenderTable.tableId,tblitembiddermap.rowId from  TblItemBidderMap tblitembiddermap  inner join  tblitembiddermap.tblTenderBidderMap tbltenderbiddermap where tbltenderbiddermap.tblTender.tenderId=:tenderId and tbltenderbiddermap.tblUserLogin.userId=:userId",var);                
        return list;        

    }
    
    public List<Object> getBidderTables(int tenderId,int userId,List<Object> tableIds) throws Exception{
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("userId",userId);
        var.put("tableIds",tableIds);
        list=hibernateQueryDao.getSingleColQuery("select tblitembiddermap.tblTenderTable.tableId from  TblItemBidderMap tblitembiddermap  inner join  tblitembiddermap.tblTenderBidderMap tbltenderbiddermap where tbltenderbiddermap.tblTender.tenderId=:tenderId and tbltenderbiddermap.tblUserLogin.userId=:userId and tblitembiddermap.tblTenderTable.tableId in (:tableIds)", var);
        return list;        

    }

    
    /**
     * Use Case : Add to standard form in form library
     * @author nirav.modi
     * @param formId
     * @param isStandardForm
     * @return boolean
     * @throws Exception 
     */
    public boolean addFormToStandard(int formId,int isStandardForm) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(FORMID,formId);
        var.put("isStandardForm",isStandardForm);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblTenderForm set isStandardForm=:isStandardForm where formId=:formId",var);        
        return cnt!=0;
    }

    
    /**
     * @author VIPULP
     * @param tableId
     * @param columnTypeId
     * @return String
     */
    public String getTableColumnHeader(int tableId,int columnTypeId) throws Exception{
        String columnHeader = null;
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId",tableId);
        var.put("columnTypeId",columnTypeId);
        
        query.append("select columnHeader from TblTenderColumn tbltendercolumn ")
                .append("where tbltendercolumn.tblTenderTable.tableId=:tableId and tbltendercolumn.tblColumnType.columnTypeId=:columnTypeId");
        
        List<Object> lstColHeader= hibernateQueryDao.getSingleColQuery(query.toString(), var);
        if(!lstColHeader.isEmpty()){
            columnHeader = (String) lstColHeader.get(0);
        }
        return columnHeader;
    }

    
    /**
     *  Get List of Grand Total Wise Mapped Bidders
     * 
     * @author purvesh
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getGrandTotalWiseBidders(int tenderId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append("select tbluserlogin.loginId, tblcompany.companyName, tblcompany.companyId, tbltenderproxybid.proxyBidId ")
        	 .append("from TblTenderBidderMap tblTenderBidderMap ")
        	 .append("inner join tblTenderBidderMap.tblUserLogin  tbluserlogin ")
        	 .append("inner join tblTenderBidderMap.tblCompany  tblcompany ")
        	 .append("left join tblcompany.tblTenderProxyBid tbltenderproxybid with tbltenderproxybid.tblTender.tenderId=:tenderId ")
        	 .append("where tblTenderBidderMap.tblTender.tenderId=:tenderId");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        

    }
    
    /**
     * Get List of Item Wise Mapped Bidders
     * 
     * @author purvesh
     * @param tableId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getItemWiseBidders(int tenderId, int tableId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("tableId",tableId);
        StringBuilder query = new StringBuilder();
        query.append("select tbluserlogin.loginId, tblcompany.companyName, tblcompany.companyId, COUNT(DISTINCT tbltenderproxybid.proxyBidId) ")
        	 .append("from TblItemBidderMap tblItemBidderMap ")
             .append("inner join tblItemBidderMap.tblTenderBidderMap tbltenderbiddermap ")
             .append("inner join tbltenderbiddermap .tblUserLogin tbluserlogin ")
             .append("inner join tbltenderbiddermap .tblCompany  tblcompany ")
             .append("left join tblcompany.tblTenderProxyBid tbltenderproxybid with tbltenderproxybid.tblTender.tenderId=:tenderId ")
             .append("where tblItemBidderMap.tblTenderTable.tableId=:tableId ")
             .append("group by tbluserlogin.loginId, tblcompany.companyName, tblcompany.companyId");        
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        
    }

    /**
     * Get FormName, Table Header and Table Footer
     * 
     * @author purvesh
     * @param tableId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getFormTableDetails(int tableId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId",tableId);
        StringBuilder query = new StringBuilder();
        query.append("select tbltenderform.formName, tblTenderTable.tableHeader, tblTenderTable.tableFooter from TblTenderTable tblTenderTable ")
             .append("inner join tblTenderTable.tblTenderForm tbltenderform ")
             .append("where tblTenderTable.tableId=:tableId");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        

    }
	
    /**
     * Get Items list For ProxyBid
     * 
     * @author purvesh
     * @param tableId
     * @param comapanyId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getItemListForProxyBid(int tableId,int companyId, int tenderResult) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId",tableId);
        var.put("companyId",companyId);
        StringBuilder query = new StringBuilder();
        query.append("SELECT tbltendercolumn.columnId, tbltendercell.rowId, tbltendercell.cellId,")
             .append("(case when tbltenderproxybid.proxyBidId is null then tbltendercell.cellValue else tbltenderproxybid.cellValue end) as cellValue,")
             .append(" tbltenderproxybid.proxyBidId,  tbltendercell.dataType, tbltendercell.objectId, tbltendercolumn.columnHeader from TblTenderTable tbltendertable ")
             .append(" inner join tbltendertable.tblTenderColumn tbltendercolumn ")
             .append(" inner join tbltendercolumn.tblTenderCell tbltendercell ");
        if(tenderResult!=1){
        	 query.append(" inner join tbltendertable.tblItemBidderMap tblitembiddermap ")
        	 	  .append("inner join tblitembiddermap.tblTenderBidderMap tbltenderbiddermap with tbltenderbiddermap.tblCompany.companyId=:companyId");
        }
        query.append(" left join tbltendercell.tblTenderProxyBid tbltenderproxybid with tbltenderproxybid.tblCompany.companyId=:companyId ")
             .append(" where tbltendertable.tableId = :tableId and tbltendercell.rowId <= (case when tbltendertable.hasGTRow = 1 THEN (tbltendertable.noOfRows - 1) ELSE tbltendertable.noOfRows end ) and ");
        if(tenderResult!=1){     
             query.append(" tblitembiddermap.rowId = tbltendercell.rowId and ");
        }
        query.append(" ((tbltendercolumn.tblColumnType.columnTypeId=1 and tbltendercolumn.filledBy=1) or (tbltendercolumn.filledBy=4 and  tbltendercolumn.tblColumnType.columnTypeId !=").append(loadingFactor).append(" )) ")
             .append(" order by tbltendercolumn.sortOrder, tbltendercell.rowId ");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        

    }

    /**
     * add/update Proxy Bid
     * 
     * @author purvesh
     * @param lstTblTenderProxyBid
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addUpdateProxyBid(List<TblTenderProxyBid> lstTblTenderProxyBid, boolean isEditMode,List<Integer> lstTblTenderProxyBids) throws Exception{
    	int cnt = 0;
    	boolean bSuccess = false;
    	if(isEditMode){
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put("lstTblTenderProxyBids",lstTblTenderProxyBids);
	        StringBuilder query = new StringBuilder();
	        query.append("delete  from TblTenderProxyBid tbltenderproxybid where tbltenderproxybid.proxyBidId in (:lstTblTenderProxyBids)");
	        cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);        
    	}
        if(cnt!=0 || !isEditMode){
	    	tblTenderProxyBidDao.saveUpdateAllTblTenderProxyBid(lstTblTenderProxyBid);
	        bSuccess=true;
        }
        return bSuccess;
    }


    /**
     * Get Combo which has been marked as combo for calculation
     * @param comboId
     * @return{@code List<Object>}
     * @throws Exception 
     */
    public List<Object> getCalculationCombo(List<Integer> comboId) throws Exception{
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("comboId",comboId);
        list = hibernateQueryDao.getSingleColQuery("select tblcombo.comboId from TblCombo tblcombo where tblcombo.comboId in (:comboId) and tblcombo.forCalculation=1",var);
        return list;        

    }

    /**
     * @author VIPULP
     * @param tenderId
     * @return {@code List<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getTableCountByTenderId(int tenderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);

        query.append("select tbltenderform.formId,COUNT(tbltendertable.tableId) from TblTenderForm tbltenderform")
                .append(" inner join tbltenderform.tblTenderTable tbltendertable ")
                .append(" where tbltenderform.tblTender.tenderId=:tenderId group by tbltenderform.formId");
        
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    /**
     * 
     * @param tenderId
     * @param companyId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getBidderCurrency(int tenderId,int companyId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
        list = hibernateQueryDao.createNewQuery("select tblcurrency.lang1,tblcurrency.lang1 from  TblTenderCurrency tbltendercurrency  inner join  tbltendercurrency.tblCurrency tblcurrency   inner join  tbltendercurrency.tblTenderBidCurrency tbltenderbidcurrency where tbltendercurrency.tblTender.tenderId=:tenderId and tbltenderbidcurrency.tblCompany.companyId=:companyId",var);                
        return list;        

    }
    
     /**
     * Add Tender SOR
     * @param tbltendersor
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
    public  boolean addTblTenderSOR(List<TblTenderSOR> tbltendersor) throws Exception{
        boolean bSuccess = false;
        if(!tbltendersor.isEmpty()){            
            deleteTenderSOR(tbltendersor.get(0).getTblTenderForm().getFormId());
            tblTenderSORDao.saveUpdateAllTblTenderSOR(tbltendersor);
            bSuccess=true;
        }
        return bSuccess;
    }
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
    public boolean addTblTenderSOR(List<TblTenderSOR> tenderSORs,TblNegotiationSORRemarks tblNegotiationSORRemarks) throws Exception 
	{
    	boolean bSuccess = false;
    	bSuccess = addTblTenderSOR(tenderSORs);
    	if(bSuccess){
    		bSuccess = saveTblNegotiationSORRemarks(tblNegotiationSORRemarks);
    		bSuccess=true;
    	}
		return bSuccess;
	}
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
    public boolean saveTblNegotiationSORRemarks(TblNegotiationSORRemarks tblNegotiationSORRemarks)
    {
    	boolean bSuccess = false;
    	negotiationSORRemarksDao.addTblNegotiationSORRemarks(tblNegotiationSORRemarks);
    	bSuccess=true;
    	return bSuccess;
    }
    public List<TblTenderSOR> getTenderSORByFormId(int formId) throws Exception{
        return tblTenderSORDao.findTblTenderSOR("tblTenderForm",Operation_enum.EQ,new TblTenderForm(formId));
    }
    
    public boolean deleteTenderSOR(int formId)throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId", formId);
        int cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderSOR tbltendersor where tbltendersor.tblTenderForm.formId=:formId", var);
        return cnt!=0;
    }
    
    public List<Object[]> getTenderCellRebateGT(Set<Integer> columnId){
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("columnId", columnId);       
        return hibernateQueryDao.createNewQuery("select tbltendercell.tblTenderColumn.columnId,tbltendercell.cellId from TblRebateForm tblrebateform inner join tblrebateform.tblTenderCell tbltendercell where tbltendercell.tblTenderColumn.columnId in (:columnId) and tbltendercell.dataType=0", var);
    }
    
    public int checkTenderHasRebate(int tenderId){        
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        List<Object> list = hibernateQueryDao.singleColQuery("select tblrebate.isRebateForm from TblRebate tblrebate where  tblrebate.tblTender.tenderId=:tenderId", var);
        return list.isEmpty() ? -1 : (Integer)list.get(0);
    }
    
    public List<SelectItem> getFormulaType(){
        List<SelectItem> list = new ArrayList<SelectItem>();
        list.add(new SelectItem("Copy cell",1));
        list.add(new SelectItem("Validate cell",2));
        list.add(new SelectItem("Validate column",3));
        return list;
    }
    
    public boolean addFormula(TblTenderFormula tblTenderFormula) throws Exception {
        boolean bSuccess = false;
        tblTenderFormulaDao.addTblTenderFormula(tblTenderFormula);
        bSuccess = true;
        return bSuccess;

    }
    
    public boolean deleteSpecialFormula(int formId){
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId", formId); 
        return hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderFormula tbltenderformula where tbltenderformula.tblTenderForm.formId=:formId and (tbltenderformula.formula like 'SPF_%' or tbltenderformula.formula like 'VCF_%')", var)!=0;
    }
    
    /**
     * @author VIPULP
     * @param tenderId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getTableLstByTenderId(int tenderId) throws Exception{
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);

        query.append("select tbltenderform.formId,tbltendertable.tableId from TblTenderForm tbltenderform")
                .append(" inner join tbltenderform.tblTenderTable tbltendertable ")
                .append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.noOfTables=1 order by tbltenderform.formId");
        
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    public List<Object> getPriceBidTableLstByTenderId(int tenderId) throws Exception{
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select tbltendertable.tableId from TblTenderForm tbltenderform")
        .append(" inner join tbltenderform.tblTenderTable tbltendertable ")
        .append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isPriceBid=1 group by tbltendertable.tableId");
        return hibernateQueryDao.getSingleColQuery(query.toString(), var);
    }
    
    /**
     * Method user for get Tender Column Details base on given tableId.
     *
     * @param tableId
     * @return {@code List<TblTenderColumn>}
     * @throws Exception
     */
    public List<Object[]> getTenderColumn(int tableId, int formId) throws Exception {
    	StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        List<Object []> list = null;
        var.put("tableId", tableId);
        var.put("formId", formId);
        var.put("filledBy", 2); // 2 for Bidder
        query.append("select tbltendercolumn.columnHeader, tbltendercolumn.columnId, tbltendercolumn.isShown ") 
             .append("from TblTenderColumn tbltendercolumn ")
             .append("where tbltendercolumn.tblTenderTable.tableId=:tableId and tbltendercolumn.tblTenderForm.formId=:formId and tbltendercolumn.filledBy!=:filledBy order by tbltendercolumn.sortOrder");
        list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return list;
    }
    
    /**
     * @author purvesh
     *
     * Check whether any bid on particular tender by bidder (company).
     *
     * @param temderId
     * @param companyId
     * @return
     * @throws Exception
     */
    public boolean isBidderHasBid(int tenderId, int companyId) throws Exception {
    	StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("companyId", companyId);
        query.append("select tbltenderbid.tblTender.tenderId, tbltenderbid.tblCompany.companyId from TblTenderBid tbltenderbid where tbltenderbid.tblTender.tenderId=:tenderId and tbltenderbid.tblCompany.companyId=:companyId");
        return hibernateQueryDao.createNewQuery(query.toString(), var).size()!=0;
    }
    
    /**
     * update show/hide field
     * @author purvesh
     * @param isShown
     * @param columnIds
     * @return
     */
    public boolean updateshowHideColumns(int isShown, List<Integer> columnIds){
    	StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("isShown", isShown);
        var.put("columnIds", columnIds);
        query.append("update TblTenderColumn tbltendercolumn set tbltendercolumn.isShown=:isShown where tbltendercolumn.columnId in (:columnIds)");
        return hibernateQueryDao.updateDeleteNewQuery(query.toString(), var)!=0;
    }
    
    /**
     * Method user for get Tender Column Details base on given tableId.
     *
     * @param tableId
     * @return {@code List<TblTenderColumn>}
     * @throws Exception
     */
    public List<Object[]> getTenderColumn(int tableId) throws Exception {
    	StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        List<Object []> list = null;
        var.put("tableId", tableId);
        query.append("select tbltendercolumn.columnHeader, tbltendercolumn.filledBy,tbltendercolumn.isShown,tbltendercolumn.columnNo,tbltendercolumn.sortOrder,tbltendercolumn.dataType ") 
             .append("from TblTenderColumn tbltendercolumn ")
             .append("where tbltendercolumn.tblTenderTable.tableId=:tableId order by tbltendercolumn.sortOrder");
        list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return list;
    }
    /***
     * Get List of TblTenderCell
     * @param tableId
     * @param rowId
     * @return {@code List<TblTenderCell>}
     */
    public List<TblTenderCell> getTenderCellByTableIdNewOrderBy(int tableId, int rowId){
        StringBuilder query = new StringBuilder();
        Map<String,Object> var = new HashMap<String, Object>();
        var.put(TABLEID, tableId);
        query.append("select tbltendercell.cellId,tbltendercell.tblTenderForm.formId,tbltendercell.tblTenderTable.tableId,")
                .append("tbltendercell.tblTenderColumn.columnId,tbltendercell.rowId,tbltendercell.cellValue,tbltendercell.cellNo,tbltendercell.dataType,")
                .append("tbltendercell.objectId,tbltendercolumn.columnNo,tbltendercolumn.sortOrder ")
                .append("from TblTenderCell tbltendercell inner join tbltendercell.tblTenderColumn tbltendercolumn where ")
                .append("tbltendercell.tblTenderTable.tableId=:tableId");
        if (rowId != 0) {
          query.append(" and tbltendercell.rowId!=:rowId");
          var.put("rowId", rowId);
        }
        query.append(" order by tbltendercell.rowId,tbltendercolumn.sortOrder asc");
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);      
        return toTenderCell(list);
    }   
    
    @Autowired
    private MasterFormService masterFormService;
    @Autowired
    private CommonService commonService;
            
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = {Exception.class})
    public boolean dumpMasterForm(int tenderId,int envelopeId,int masterFormId,int userDetailId,int isBiddingFormPublishWithTender) throws Exception{
        boolean flag=false;
        TblFormMaster formMaster = masterFormService.getFormMasterById(masterFormId);
        TblTenderForm tenderForm = new TblTenderForm();
        BeanUtils.copyProperties(formMaster, tenderForm);
        tenderForm.setTblTender(new TblTender(tenderId));
        tenderForm.setCreatedBy(userDetailId);
        tenderForm.setFormId(0);
        tenderForm.setMasterFormId(masterFormId);
        tenderForm.setPublishedBy(0);
        tenderForm.setPublishedOn(commonService.getServerDateTime());
        tenderForm.setTblTenderEnvelope(new TblTenderEnvelope(envelopeId));
        tenderForm.setLoadNoOfItems(loadNoOfItems);
        tenderForm.setIncrementItems(incrementItems);
        tenderForm.setCstatus(0);//For Pending
        List<TblTenderTable> tblTenderTables = new ArrayList<TblTenderTable>();
        List<TblTableMaster> tableMasters = masterFormService.getTableMasterByFormId(masterFormId);
        List<TblTenderColumn> tenderColumns = new ArrayList<TblTenderColumn>();
        List<TblTenderCell> tenderCells = new ArrayList<TblTenderCell>();                
        for (TblTableMaster tblTableMaster : tableMasters) {
            TblTenderTable tenderTable = new TblTenderTable();
            BeanUtils.copyProperties(tblTableMaster, tenderTable);
            tenderTable.setTblTenderForm(tenderForm);
            tenderTable.setCreatedBy(userDetailId);
            tenderTable.setTableId(0);
            tblTenderTables.add(tenderTable);
            List<TblColumnMaster> columnMasters = masterFormService.getColumnMasterByTableId(tblTableMaster.getTableId());            
            List<TblTenderColumn> dummyColumns = new ArrayList<TblTenderColumn>();            
            for (TblColumnMaster tblColumnMaster : columnMasters) {
                TblTenderColumn tblTenderColumn = new TblTenderColumn();
                BeanUtils.copyProperties(tblColumnMaster, tblTenderColumn);
                tblTenderColumn.setTblTenderForm(tenderForm);
                tblTenderColumn.setTblTenderTable(tenderTable);
                tblTenderColumn.setColumnId(0);
                tenderColumns.add(tblTenderColumn);                
                dummyColumns.add(tblTenderColumn);                
            }
            List<TblCellMaster> cellMasters = masterFormService.getCellMasterByTableId(tblTableMaster.getTableId(), 0);
            for (TblCellMaster tblCellMaster : cellMasters) {
                TblTenderCell tblTenderCell = new TblTenderCell();
                BeanUtils.copyProperties(tblCellMaster, tblTenderCell);
                tblTenderCell.setTblTenderForm(tenderForm);
                tblTenderCell.setTblTenderTable(tenderTable);
                tblTenderCell.setCellId(0);
                int colIndex=0;
                for (TblColumnMaster tblColumnMaster : columnMasters) {
                    colIndex++;
                    if(tblColumnMaster.getColumnId()==tblCellMaster.getTblColumnMaster().getColumnId()){
                        break;
                    }
                }
//                System.out.println(colIndex-1);
                tblTenderCell.setTblTenderColumn(dummyColumns.get(colIndex-1));
                tenderCells.add(tblTenderCell);
            }
        }
        tblTenderFormDao.addTblTenderForm(tenderForm);
        tblTenderTableDao.saveUpdateAllTblTenderTable(tblTenderTables);
        tblTenderColumnDao.saveUpdateAllTblTenderColumn(tenderColumns);
        tblTenderCellDao.saveUpdateAllTblTenderCell(tenderCells);
        List<TblTenderMatrixJson> matrixJsons = new ArrayList<TblTenderMatrixJson>();
        for (TblTenderTable tblTenderTable : tblTenderTables) {
            TblTenderMatrixJson matrixJson = new TblTenderMatrixJson();
            List<TblTenderCell> ttcs = new ArrayList<TblTenderCell>();
            for (TblTenderCell tblTenderCell : tenderCells) {
                if(tblTenderCell.getTblTenderTable().getTableId()==tblTenderTable.getTableId()){
                    ttcs.add(tblTenderCell);
                }
            }
            matrixJson.setJsonData(tenderTabletoJSON(ttcs));
            matrixJson.setTblTenderForm(tenderForm);
            matrixJson.setTblTenderTable(tblTenderTable);
            matrixJsons.add(matrixJson);            
        }
        tblTenderMatrixJsonDao.saveUpdateAllTblTenderMatrixJson(matrixJsons);
        tenderCorrigendumService.insertCorrigendumNewForm(tenderForm.getFormId(),userDetailId,tenderId,isBiddingFormPublishWithTender);
        flag = true;
        return flag;
    }
    
    public String replaceCellId(String bidJson,String tableJson) throws JSONException{
        List<TblTenderCell> cells = _toCellMasters(tableJson);                
        JSONArray jsonArray = new JSONArray(bidJson);
        JSONArray jsonNew = new JSONArray();
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject jSONObject = jsonArray.getJSONObject(i);
            for (Iterator it = jSONObject.keys(); it.hasNext();) {
                String key = it.next().toString();
                String[] values = key.split("_");
                for (TblTenderCell cell : cells) {
                    if(cell.getCellNo() == Integer.parseInt(values[1])){
                        JSONObject jSONObjectNew = new JSONObject();
                        jSONObjectNew.put(cell.getCellId()+"_"+cell.getCellNo(), jSONObject.getString(key));
                        jsonNew.put(jSONObjectNew);
                        break;
                    }
                }
            }
        }
        return jsonNew.toString();
    }
    /**
     * To get list of envelope
     *
     * @author nirav.modi
     * @return List {@code<Object[]>}
     * @throws Exception
     */
    public List<Object[]> getMasterFormEnvlopList(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDER_ID, tenderId);
        return hibernateQueryDao.createNewQuery("select tbltenderenvelope.tblEnvelope.envId, tbltenderenvelope.envelopeName,tbltenderenvelope.envelopeId from TblTenderEnvelope tbltenderenvelope where tbltenderenvelope.tblTender.tenderId=:tenderId and tbltenderenvelope.tblEnvelope.envId not in (4)", var);
    }
    
    /**
     * To get form list and table count of mapped bidder
     * author : Shreyansh.shah
     * @param tenderId
     * @param envelopeId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderTableCountAndFormList(int tenderId,int envelopeId) throws Exception {
        Map<String,Object> var = new HashMap<String,Object>();
        StringBuilder queryString = new StringBuilder();
        var.put(TENDER_ID, tenderId);
//        var.put("envelopeId", envelopeId);
        queryString.append("select tbltenderform.formId,tbltenderform.formName, COUNT(distinct tbltendertable.tableId) ")
                .append("from TblTenderEnvelope tblTenderEnvelope ")
                .append("inner join tblTenderEnvelope.tblTenderForm tbltenderform ")
                .append("inner join tbltenderform.tblTenderTable tbltendertable ")
                .append("where tblTenderEnvelope.tblEnvelope.envId in (4,5) and tbltenderform.isPriceBid = 1 and tblTenderEnvelope.tblTender.tenderId =:tenderId and tbltenderform.cstatus != 2")
                .append("group by tbltenderform.formId,tbltenderform.formName ");
        	//Above query modified add tbltenderform.cstatus for Bug id : 24545
        return hibernateQueryDao.createNewQuery(queryString.toString(), var);
    }
    /**
     * get table details by formId
     * author : Shreyansh.shah
     * @param tenderId
     * @param envelopeId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getTenderTableListByFormId(int formId) throws Exception {
        Map<String,Object> var = new HashMap<String,Object>();
        var.put(FORMID, formId);
        return hibernateQueryDao.createNewQuery("select tblTenderTable.tableId,tblTenderTable.tableName from TblTenderTable tblTenderTable where tblTenderTable.tblTenderForm.formId =:formId", var);
    }
    
    /**
     * To get no of price bid forms are available for tender
     * @author SULABH
     * @param tenderId
     * @return
     */
    
    public int getNoOfPriceBidForm(int tenderId) throws Exception{
    	int count=0;
    	Map<String,Object> var = new HashMap<String,Object>();
        var.put("tenderId", tenderId);
    	StringBuffer selectHQL=new StringBuffer("select COUNT(isPriceBid)from TblTenderForm where tenderId=:tenderId and isPriceBid=1 and cstatus=1");
    	List<Object> list=hibernateQueryDao.singleColQuery(selectHQL.toString(), var);
    	if(!list.isEmpty()){
    		count=Integer.parseInt(list.get(0).toString());
    	}
    	return count;
    }
    
    public int getNoOfEncryptedPriceBidForm(int tenderId) throws Exception{
    	int count=0;
    	Map<String,Object> var = new HashMap<String,Object>();
        var.put("tenderId", tenderId);
    	StringBuffer selectHQL=new StringBuffer("select COUNT(isPriceBid)from TblTenderForm where tenderId=:tenderId and isPriceBid=1 and isEncryptionReq=0");
    	List<Object> list=hibernateQueryDao.singleColQuery(selectHQL.toString(), var);
    	if(!list.isEmpty()){
    		count=Integer.parseInt(list.get(0).toString());
    	}
    	return count;
    }
    
    /**
     * This method is use to get no of Price bid Forms for particular sealbid
     * @author SULABH
     * @param tenderId
     * @return
     */
    
    public List<Object[]> getTenderPriceBidForm(int tenderId) throws Exception{
    	Map<String,Object> var = new HashMap<String,Object>();
        StringBuilder queryString = new StringBuilder();
        var.put("tenderId", tenderId);
        //queryString.append("select formId,formName from TblTenderForm where tenderId=:tenderId and isPriceBid=1 and noOfTables=1 and cstatus=1");
        
        queryString.append("select tbltenderform.formId , tbltenderform.formName,tbltenderform.tblTenderEnvelope.envelopeId,tbltenderform.tblTenderEnvelope.minFormsReqForBidding,tbltenderform.tblTenderEnvelope.sortOrder ");
        queryString.append(" from TblTenderForm tbltenderform");
        queryString.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isPriceBid=1 and tbltenderform.cstatus=1 ");
        queryString.append(" and (select count(tbltendertable.tableId) from TblTenderTable tbltendertable");
        queryString.append(" where tbltendertable.tblTenderForm.formId = tbltenderform.formId) = 1");
        return hibernateQueryDao.createNewQuery(queryString.toString(), var);
    }
    
    /**
     * @author bharat
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderApprovedPriceBidForm(int tenderId) throws Exception{
    	Map<String,Object> var = new HashMap<String,Object>();
        StringBuilder queryString = new StringBuilder();
        var.put("tenderId", tenderId);
        queryString.append("select tbltenderform.formId , tbltenderform.formName,tbltenderform.tblTenderEnvelope.envelopeId,tbltenderform.tblTenderEnvelope.minFormsReqForBidding,tbltenderform.tblTenderEnvelope.sortOrder ");
        queryString.append(" from TblTenderForm tbltenderform");
        queryString.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isPriceBid=1 and tbltenderform.cstatus=1 ");
        return hibernateQueryDao.createNewQuery(queryString.toString(), var);
    }
    
    
    /**
     * get Envlop form details which have table column 
     * author : Krunal.Patel
     * @param tenderId
     * @return List<Object[]>
     * @throws Exception 
     */
    public List<Object[]> getFormColumnType(int formId) throws Exception {
        StringBuilder query = new StringBuilder();
    	Map<String,Object> var = new HashMap<String,Object>();
        var.put(FORMID, formId);
        
		query.append("select tblTenderColumn.tblTenderForm.formId,tblTenderColumn.tblColumnType.columnTypeId  ");
		query.append("from TblTenderColumn tblTenderColumn ");
		query.append("where tblTenderColumn.tblTenderForm.formId=:formId and tblTenderColumn.tblColumnType.columnTypeId in(1,2,3,4) ");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    
    /**
     * Delete Tender Table and also delete rebate and update noOftables in tblTenderForm
     * 
     * @author nirav.prajapati
     * @param tenderId
     * @param formId
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean deleteTenderTable(int tableId,int tenderId,int formId)throws Exception{
        boolean bSuccess = false;
        List<TblTenderTable> list = null; 
        Map<String, Object> var = new HashMap<String, Object>();
        Map<String, Object> var2 = new HashMap<String, Object>();
        Map<String, Object> var1 = new HashMap<String, Object>();
        
        var.put("tenderId",tenderId);
        hibernateQueryDao.updateDeleteNewQuery("delete from TblRebate tblrebate where tblrebate.tblTender.tenderId=:tenderId", var);
        var.clear();
        var.put("tableId",tableId);
        hibernateQueryDao.updateDeleteNewQuery("delete from TblItemBidderMap tblItemBidderMap where tblItemBidderMap.tblTenderTable.tableId=:tableId", var);
        var2.put("tableId",tableId);
        hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderTable tbltendertable where tbltendertable.tableId=:tableId",var2);
        var1.put("formId",formId);
        list =  tblTenderTableDao.findTblTenderTable("tblTenderForm.formId",Operation_enum.EQ,formId);
        if(list != null && !list.isEmpty()){
        	var1.put("noOfTables",list.size());
		} else {
        	var1.put("noOfTables",0);
        }	
        hibernateQueryDao.updateDeleteNewQuery("update TblTenderForm set noOfTables=:noOfTables where formId=:formId",var1);
        bSuccess = true;
        return bSuccess; 		
    }

    /*
     * author : heeral.soni
     * used to get count for tendet form publish or not for "I Agree" button
     */
    public boolean getApprovedFormCount(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        long count = hibernateQueryDao.countForNewQuery("TblTenderForm tbltenderform ","tbltenderform.formId ","tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus=1",var);
        return count!=0;
    }
    
    /**
     * author : shreyansh.shah
     * To check pricebid form exist for given tender
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public long getPriceBidFormCount(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        long count = hibernateQueryDao.countForNewQuery("TblTenderForm tbltenderform ","tbltenderform.formId ","tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus=1 and tbltenderform.isPriceBid=1",var);
        return count;
    }
   
    public int getPriceLoadingFormCount(int tenderId) throws Exception {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        int count = 0;
        StringBuilder query = new StringBuilder();
        query.append(" select count(distinct tbltenderform.formId) ");
        query.append(" from TblTenderColumn tbltendercolumn");
        query.append(" inner join tbltendercolumn.tblTenderForm tbltenderform");
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltendercolumn.filledBy=4 and tbltendercolumn.tblColumnType.columnTypeId=23 and tbltenderform.cstatus=1");
        List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(), var);
        if(list!=null && list.size()>0)
        {
            count = Integer.parseInt(list.get(0).toString());
        }
        return count;
    }

    /**
     * @Issue issue generated in mbpt, for report generate issue when publish notice without formapprove. 
     * @author bharat
     * @param tenderId
     * @param tenderResult
     * @param userDetailId
     * @param fromCorrigendum
     * @throws Exception
     */
	public void executeSPforGenerateL1Report(int tenderId, int tenderResult,int userDetailId,int fromCorrigendum,int fromType) throws Exception {
		// TODO Auto-generated method stub
		sPGenerateL1ReportForNegotiation.executeProcedure(tenderId, tenderResult, userDetailId,fromCorrigendum,fromType);
		
	}
	
	
	/**
     * 
     */
    public List<Object[]> getFormCompleteStatus(int formId) throws Exception{

    	List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        StringBuilder query = new StringBuilder();
        query.append("SELECT A.formId, SUM(A.rowsColsCnt) isTablesComplete, SUM(A.formulaCnt) isFormulaComplete, COUNT(DISTINCT A.tableId) isTablesCreated "); 
        query.append(" FROM (SELECT TFM.formId, TT.tableId, (CASE WHEN TT.noOfCols * TT.noOfRows != COUNT(DISTINCT TC.cellId) THEN 1 ELSE 0 END) rowsColsCnt, ");
        query.append(" CASE WHEN (COUNT(DISTINCT TCM.columnId) - COUNT(DISTINCT TF.columnId)) > 0 THEN 1 ELSE 0 END formulaCnt FROM apptender.tbl_TenderForm TFM   ");
        query.append(" LEFT OUTER JOIN apptender.tbl_TenderTable TT ON TFM.formId = TT.formId  ");
        query.append(" LEFT OUTER JOIN apptender.tbl_TenderCell TC ON TT.tableId = TC.tableId ");
        query.append(" LEFT OUTER JOIN apptender.tbl_TenderColumn TCM ON TT.tableId = TCM.tableId AND TCM.filledBy = 3 AND TCM.dataType <> 10 ");
        query.append(" LEFT OUTER JOIN apptender.tbl_TenderFormula TF ON TCM.columnId = TF.columnId AND TF.formula NOT LIKE 'TOTAL(%'  ");
        query.append(" WHERE TFM.formId=:formId GROUP BY TFM.formId, TT.tableId, TT.noOfCols, TT.noOfRows ) A GROUP BY A.formId  ");
		
        list = hibernateQueryDao.nativeSQLQuery(query.toString(), var);
        return list;
    }
    /** This service create the Corrigendum for the new envelope added through Corrigendum.else update minFormsReq to tbltenderenvelope.
     * @author mitesh
     * @param request
     * @return
     * @throws Exception
     */
    public boolean updateNoOfMandatoryBiddingForms(HttpServletRequest request) throws Exception{
    	  String envelopeIds[]=request.getParameterValues("hdEnvelopeId");
    	  String minFormCount[]=request.getParameterValues("txtNoOfFormMand");
    	  String minTechFormCount[]=request.getParameterValues("txtNoOfTechFormMand");
          int cStatus;
          String minActualFormCount;
          String minActualTechFormCount;
          int corrigendumId = StringUtils.hasLength(request.getParameter("hdCorrigendumId")) ? Integer.parseInt(request.getParameter("hdCorrigendumId")) : 0;
          Map<String, Object> var = new HashMap<String, Object>();
          if(corrigendumId != 0){
	          var.put("corrigendumId",corrigendumId);
	          List<String> fieldName = new ArrayList<String>();
	          fieldName.add(FEILD_MIN_FORMS_REQ_FOR_BIDDING);
	          fieldName.add(FEILD_MIN_TECH_FORMS_REQ_FOR_BIDDING);
	          var.put("fieldName",fieldName);
	          hibernateQueryDao.updateDeleteNewQuery("delete from TblCorrigendumDetail tblCorrigendumDetail where tblCorrigendumDetail.tblCorrigendum.corrigendumId=:corrigendumId and fieldName in (:fieldName)", var);
          }
    	  if(envelopeIds !=null && envelopeIds.length>0){
              List<TblCorrigendumDetail> corrigendumDetailsList=new ArrayList<TblCorrigendumDetail>();
    		  for (int i=0 ; i<envelopeIds.length; i++) {
    			     TblTenderEnvelope tblTenderEnvelope = tenderCommonService.getTenderEnvelopeById(Integer.parseInt(envelopeIds[i]));
                        if(corrigendumId!=0)//case of corrigendum
                        {   
                            i++;     
                            cStatus = StringUtils.hasLength(request.getParameter("hdEnvCstatus_"+i)) ? Integer.parseInt(request.getParameter("hdEnvCstatus_"+i)) : 0;
                            minActualFormCount = StringUtils.hasLength(request.getParameter("hdMinFormCount_"+i)) ? request.getParameter("hdMinFormCount_"+i): "0";
                            i--;
                            if(cStatus==1){//insert into corrigundum.
                             if(minFormCount != null && minFormCount.length > i){
                            	 if(Integer.parseInt(minActualFormCount.toString()) != Integer.parseInt(minFormCount[i].toString()))
                            	 {
                                TblCorrigendumDetail corrigendumDetail=new TblCorrigendumDetail();
                                corrigendumDetail.setObjectId(Integer.parseInt(envelopeIds[i]));
                                corrigendumDetail.setActionType(2);
                                corrigendumDetail.setTblProcess(new TblProcess(3));
                                corrigendumDetail.setFieldLabel("");
                                corrigendumDetail.setFieldName(FEILD_MIN_FORMS_REQ_FOR_BIDDING);
                                corrigendumDetail.setOldValue(minActualFormCount);
                                corrigendumDetail.setNewValue(minFormCount[i]);
                                corrigendumDetail.setTblCorrigendum(new TblCorrigendum(corrigendumId));
                                corrigendumDetail.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                                corrigendumDetailsList.add(corrigendumDetail);
                                }
                             }
                             // For technical form 
                             if(tblTenderEnvelope.getTblEnvelope().getEnvId() == 5 && minTechFormCount != null && minTechFormCount.length > 0)
                                {
                            	 if(Integer.parseInt(minActualFormCount.toString()) != Integer.parseInt(minFormCount[i].toString()))
                            	 {
                                	minActualTechFormCount = StringUtils.hasLength(request.getParameter("hdMinTechFormCount_"+i)) ? request.getParameter("hdMinTechFormCount_"+i): "0";
                                	TblCorrigendumDetail corrigendumDetail1=new TblCorrigendumDetail();
                                	corrigendumDetail1.setObjectId(Integer.parseInt(envelopeIds[i]));
                                	corrigendumDetail1.setActionType(2);
                                	corrigendumDetail1.setTblProcess(new TblProcess(3));
                                	corrigendumDetail1.setFieldLabel("");
                                    corrigendumDetail1.setFieldName(FEILD_MIN_TECH_FORMS_REQ_FOR_BIDDING);
                                    corrigendumDetail1.setOldValue(minActualTechFormCount);
                                    corrigendumDetail1.setNewValue(minTechFormCount[0]);
                                    corrigendumDetail1.setTblCorrigendum(new TblCorrigendum(corrigendumId));
                                    corrigendumDetail1.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                                    corrigendumDetailsList.add(corrigendumDetail1);	
                            	 }
                                }
                            }
                            
                            else if(cStatus==4){
                               var = new HashMap<String, Object>();
                               if(minFormCount != null && minFormCount.length > i){
                                var.put("envelopeId",Integer.parseInt(envelopeIds[i]));
                                var.put("minFormsReqForBidding",Integer.parseInt(minFormCount[i]));
                                hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minFormsReqForBidding=:minFormsReqForBidding where envelopeId=:envelopeId", var);
                               }
                               if(tblTenderEnvelope.getTblEnvelope().getEnvId() == 5 && minTechFormCount != null && minTechFormCount.length > 0)
                                {
                                	minActualTechFormCount = StringUtils.hasLength(request.getParameter("hdMinTechFormCount_"+i)) ? request.getParameter("hdMinTechFormCount_"+i): "0";
                                	var.clear();
                                	var.put("envelopeId",Integer.parseInt(envelopeIds[i]));
                                    var.put("minTechFormsReqForBidding",Integer.parseInt(minTechFormCount[0]));
                                    hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minTechFormsReqForBidding=:minTechFormsReqForBidding where envelopeId=:envelopeId", var);
                                }
                            }
                           }
                        
                        else{ //in case when tender publish time.Not case of corrigundum.
                          var = new HashMap<String, Object>();
	                      if(minFormCount != null && minFormCount.length > i){
	                        var.put("envelopeId",Integer.parseInt(envelopeIds[i]));
	                        var.put("minFormsReqForBidding",Integer.parseInt(minFormCount[i]));
	                        hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minFormsReqForBidding=:minFormsReqForBidding where envelopeId=:envelopeId", var);
	                       }
	                      if(tblTenderEnvelope.getTblEnvelope().getEnvId() == 5 && minTechFormCount != null && minTechFormCount.length > 0)
                           {
                            	minActualTechFormCount = StringUtils.hasLength(request.getParameter("hdMinTechFormCount_"+i)) ? request.getParameter("hdMinTechFormCount_"+i): "0";
	                        	var.clear();
	                        	var.put("envelopeId",Integer.parseInt(envelopeIds[i]));
		                        var.put("minTechFormsReqForBidding",Integer.parseInt(minTechFormCount[0]));
		                        hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minTechFormsReqForBidding=:minTechFormsReqForBidding where envelopeId=:envelopeId", var);
	                        }
                        }
                }
                tblCorrigendumDetailDao.saveUpdateAllTblCorrigendumDetail(corrigendumDetailsList);
    	  }
    	  return true;
    }
    /** This service method get the EnvelopeId by formId.
     * @auther Mitesh
     * @param formId
     * @return
     * @throws Exception 
     */
     public int getEnvelopeIdByFormId(int formId) throws Exception{    	
    	List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        StringBuilder query = new StringBuilder();
        query.append("select tblTenderForm.tblTenderEnvelope.envelopeId from TblTenderForm  tblTenderForm where tblTenderForm.formId=:formId");
        list = hibernateQueryDao.getSingleColQuery(query.toString(), var);
        if(list!=null && list.size()>0)
        {
            Object temp=list.get(0);
            return Integer.parseInt(temp.toString());
        }
        return 0;
  }
     
     /** This service method is used for to isEnvelope Pending or not.1 return for pending,0 for not pending.
      * @auther Mitesh
      * @param envelopeId
      * @return
      * @throws Exception 
      */
      public boolean isEnvelopePending(int envelopeId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId", envelopeId);
        count = hibernateQueryDao.countForNewQuery("TblTenderEnvelope tblTenderEnvelope ", "tblTenderEnvelope.envelopeId ", "tblTenderEnvelope.envelopeId=:envelopeId and  tblTenderEnvelope.cstatus=4", var);
        return count != 0;
    }
      /** This service method is used to check weather the bidding form is published or not(before the corrigendum is published)
       * @auther Nitin
       * @param envelopeId
       * @return
       * @throws Exception 
       */
       public boolean isEnvelopePublishPending(int envelopeId) throws Exception {
         long count = 0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("envelopeId", envelopeId);
         count = hibernateQueryDao.countForNewQuery("TblTenderEnvelope tblTenderEnvelope ", "tblTenderEnvelope.envelopeId ", "tblTenderEnvelope.envelopeId=:envelopeId and  tblTenderEnvelope.publishedOn is null", var);
         return count != 0;
     }
      
    /** This service method is used for the Get & update the minFormsReqforBidding where form mandatory is 1 by envelopeId
     * @auther Mitesh
     * @param envelopeId
     * @return
     * @throws Exception 
     */
    public boolean getAndUpdateNoOfMandatoryBiddingForms(int envelopeId) throws Exception{    	
    	long mandatoryCount=0;
    	int result=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId",envelopeId);
        var.put("isMandatory",1);
        TblTenderEnvelope tblTenderEnvelope = tenderCommonService.getTenderEnvelopeById(envelopeId);
    	if(tblTenderEnvelope.getTblEnvelope().getEnvId()!=5){ 
        mandatoryCount = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm", "tblTenderForm.formId", "tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.isMandatory=:isMandatory and tblTenderForm.cstatus!=2", var);
        var = new HashMap<String, Object>();
		var.put("envelopeId",envelopeId);
		var.put("minFormsReqforBidding",mandatoryCount);
		result= hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minFormsReqforBidding=:minFormsReqforBidding where envelopeId=:envelopeId", var);
    	}
    	// If envelope is Technocommercial then update count seperate for pricebid and technicalbid forms
    	else{
    	mandatoryCount = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm", "tblTenderForm.formId", "tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.isMandatory=:isMandatory and tblTenderForm.cstatus!=2 and tblTenderForm.isPriceBid=1", var);
    	var = new HashMap<String, Object>();
    	var.put("envelopeId",envelopeId);
    	var.put("minFormsReqforBidding",mandatoryCount);
    	result= hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minFormsReqforBidding=:minFormsReqforBidding where envelopeId=:envelopeId", var);
    	
    	var = new HashMap<String, Object>();
    	var.put("envelopeId",envelopeId);
        var.put("isMandatory",1);  
    	mandatoryCount = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm", "tblTenderForm.formId", "tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.isMandatory=:isMandatory and tblTenderForm.cstatus!=2 and tblTenderForm.isPriceBid=0", var);
    	var = new HashMap<String, Object>();
    	var.put("envelopeId",envelopeId);
    	var.put("minTechFormsReqForBidding",mandatoryCount);
    	result= hibernateQueryDao.updateDeleteNewQuery("update TblTenderEnvelope set minTechFormsReqForBidding=:minTechFormsReqForBidding where envelopeId=:envelopeId", var);
    	
    	}
		
  	  return result!=0?true:false;
  }
    /***  This service method is used for the Get & update the minFormsReqforBidding where form mandatory is 1 by formId
     * @auther Mitesh
     * @param formId
     * @return
     * @throws Exception
     */
    public boolean getAndUpdateNoOfMandatoryBiddingTables(int formId) throws Exception{    	
    	long mandatoryCount=0;
    	int result=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        var.put("isMandatory",1);               
        mandatoryCount = hibernateQueryDao.countForNewQuery("TblTenderTable tblTenderTable", "tblTenderTable.tableId", "tblTenderTable.tblTenderForm.formId=:formId and tblTenderTable.isMandatory=:isMandatory", var);
        var = new HashMap<String, Object>();
		var.put("formId",formId);
		var.put("minTablesReqForBidding",mandatoryCount);
		result= hibernateQueryDao.updateDeleteNewQuery("update TblTenderForm set minTablesReqForBidding=:minTablesReqForBidding where formId=:formId", var);
	  return result!=0?true:false;
  }
    /** Get the tenderFormdetails by tenderId
     * @auther Mitesh
     * @param tenderId
     * @return
     * @throws Exception 
     */
     public List<Object[]> getMandatoryTableDetails(int tenderId) throws Exception{
    	List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append("select tblTenderForm.formId,tblTenderForm.tblTender.tenderId,tblTenderForm.tblTenderEnvelope.envelopeId,tblTenderForm.formName,");
        query.append(" tblTenderForm.isMandatory,tblTenderForm.minTablesReqForBidding, ");
        query.append(" (select COUNT(tblTenderTable.tableId) from TblTenderTable tblTenderTable where tblTenderTable.tblTenderForm.formId=tblTenderForm.formId ), ");
        query.append(" (select COUNT(tblTenderTable.isMandatory) from TblTenderTable tblTenderTable where tblTenderTable.tblTenderForm.formId=tblTenderForm.formId  and tblTenderTable.isMandatory=1)");
        query.append(" from TblTenderForm tblTenderForm where tblTenderForm.tblTender.tenderId=:tenderId ");
		
        list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return list;
    }
     
     
     /**
      * 
      * @author bharat
      * @param tenderId
      * @return
      * @throws Exception
      */
      public List<Object[]> getItemsByTenderIdForValueWithoutEnc(int tenderId) throws Exception{
          StringBuilder query = new StringBuilder();
          Map<String, Object> var = new HashMap<String, Object>();
          var.put("tenderId", tenderId);
          
          query.append(" select tbltendercell.cellId,tbltenderform.formId,tbltendertable.tableId,tbltendercolumn.columnId,tbltendercell.rowId,tbltendercell.cellValue,tbltenderform.cstatus,tbltenderform.formName,tbltendertable.tableName,tbltenderform.tblTenderEnvelope.envelopeId,tbltendercolumn.tblColumnType.columnTypeId,tbltendercolumn.columnHeader");
          query.append(" from TblTenderForm  tbltenderform ");
          query.append(" inner join tbltenderform.tblTenderTable tbltendertable ");
          query.append(" inner join tbltendertable.tblTenderColumn tbltendercolumn   ");
          query.append(" inner join tbltendercolumn.tblTenderCell tbltendercell  ");
          query.append(" where tbltenderform.isPriceBid=1 and tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus = 1 and tbltendercell.tblTenderColumn.dataType != 0 and  tbltendercolumn.tblColumnType.columnTypeId in (20) ");
          query.append(" order by tbltenderform.formId ");
          return hibernateQueryDao.createNewQuery(query.toString(), var);
      }
      /**
       * 
       * @author bharat
       * @param tenderId
       * @param companyId
       * @return
       * @throws Exception
       */
      public List<Object[]> getItemsByTenderId(int tenderId,int companyId) throws Exception{
          StringBuilder query = new StringBuilder();
          Map<String, Object> var = new HashMap<String, Object>();
          var.put("tenderId", tenderId);
          var.put("companyId", companyId);
          query.append(" select tbltendercell.cellId,tbltenderform.formId,tbltendertable.tableId,tbltendercolumn.columnId,tbltendercell.rowId,tbltendercell.cellValue,tbltenderform.cstatus,tbltenderform.formName,tbltendertable.tableName,tbltenderform.tblTenderEnvelope.envelopeId,tbltendercolumn.tblColumnType.columnTypeId,tbltendercolumn.columnHeader ");
          query.append(" from TblTenderForm  tbltenderform ");
          query.append(" inner join tbltenderform.tblTenderTable tbltendertable ");
          query.append(" inner join tbltendertable.tblTenderColumn tbltendercolumn  with tbltendercolumn.tblColumnType.columnTypeId = 1 ");
          query.append(" inner join tbltendercolumn.tblTenderCell tbltendercell  ");
          query.append(" inner join tbltenderform.tblTenderBid tbltenderbid with tbltenderbid.tblCompany.companyId=:companyId");
          query.append(" where tbltenderform.isPriceBid=1 and tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus = 1 and tbltendercell.tblTenderColumn.dataType != 0 ");
          query.append(" order by tbltenderform.sortOrder,tbltendertable.sortOrder");
          return hibernateQueryDao.createNewQuery(query.toString(), var);
      }
      
      /**
       * 
       * @author bharat
       * @param TblItemSelection
       * @param envelopeId
       * @param companyId
       * @param loginUserId
       * @param formId
       * @return
       * @throws Exception
       */
      @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
      public boolean addTblItemSelection(List<TblItemSelection> TblItemSelection,int envelopeId,int companyId,int loginUserId,int formId) throws Exception{
          boolean bSuccess = false;         
          deleteTblItemSelection(envelopeId,loginUserId,companyId,formId);
          tblItemSelectionDao.saveUpdateAllTblItemSelection(TblItemSelection);
          bSuccess = true;
          return bSuccess;
      }
      
    /**
     * 
     * @param tblBidderItems
     * @param envelopeId
     * @param bidderId
     * @param companyId
     * @param loginUserId
     * @param formId
     * @param childId
     * @return
     * @throws Exception
     */
      @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
      public boolean addtblBidderItems(List<TblBidderItems> tblBidderItems,int priceBidenvelopeId,int bidderId,int companyId,int loginUserId,int formId,int childId,int tenderId) throws Exception{
          boolean bSuccess = false;
          Object existChildId = 0;
          if(childId != 0){
        	  existChildId = getBidderItemsChildId(priceBidenvelopeId,bidderId,companyId,loginUserId);
          }
          if(existChildId.equals(childId)){
        	  deleteTblBidderItems(priceBidenvelopeId,loginUserId,companyId,formId);
          }else{
        	  updateTblBidderItems(priceBidenvelopeId,loginUserId,bidderId,companyId,existChildId);
          }
          updateEvaluationReworkDetail(tenderId,loginUserId,companyId,childId);
          doUpdateIFReworkDetailDone(childId);
          
          tblBidderItemsDao.saveUpdateAllTblBidderItems(tblBidderItems);
          bSuccess = true;
          return bSuccess;
      }

	private void doUpdateIFReworkDetailDone(int childId) throws Exception {
    	  boolean isReworkDone = true;
    	  StringBuilder query = new StringBuilder();
    	  
          Map<String, Object> var = new HashMap<String, Object>();
          var.put("childId", childId);
          /*query.append(" select count(cstatus) TblReworkDetail where cstatus = 0 and tblEvaluationRework.evalReworkId=:childId ");
          List<Object[]> object = hibernateQueryDao.createNewQuery(query.toString(), var);*/
          long count =	hibernateQueryDao.countForNewQuery("TblReworkDetail tblreworkdetail","cstatus", "cstatus = 0 and tblEvaluationRework.evalReworkId=:childId", var);
          if(count != 0)
          {
        	  isReworkDone = false;
          }
          if(isReworkDone)
          {
        	  query = new StringBuilder();
        	  query.append(" update  TblEvaluationRework set cstatus = 1 where evalReworkId=:childId ");
              hibernateQueryDao.updateDeleteQuery(query.toString(), var);
        	  
          }
	}

	private void updateEvaluationReworkDetail(int tenderId, int loginUserId,int companyId,int childId) {
    	Map<String, Object> var = new HashMap<String, Object>();
        var.put("childId", childId);
        var.put("companyId", companyId);
		StringBuilder query = new StringBuilder();
		query.append(" update TblReworkDetail tblReworkDetail set cstatus = 1 where tblReworkDetail.tblEvaluationRework.evalReworkId=:childId and tblReworkDetail.companyId = :companyId");
		hibernateQueryDao.updateDeleteQuery(query.toString(), var);
	}

	private void updateTblBidderItems(int envelopeId, int loginUserId,
    		  int bidderId,int companyId,Object childId) {
    	  StringBuilder query = new StringBuilder();
          Map<String, Object> var = new HashMap<String, Object>();
          var.put("envelopeId", envelopeId);
          var.put("companyId", companyId);
          var.put("loginUserId",loginUserId);
          var.put("childId",childId);
          var.put("bidderId",bidderId);
          
          query.append(" update TblBidderItems tblbidderitems set tblbidderitems.isActive = 0 ");
          query.append(" where tblbidderitems.tblTenderEnvelope.envelopeId=:envelopeId ");
          query.append(" and tblbidderitems.createdBy=:loginUserId and  tblbidderitems.tblCompany.companyId=:companyId and tblbidderitems.tblUserLogin.userId=:bidderId and tblbidderitems.isActive= 1 and tblbidderitems.childId=:childId ");
          hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);
	}

	private Object getBidderItemsChildId(int envelopeId,int bidderId,int companyId,int loginUserId) {
    	  Object childId = 0;
    	  StringBuilder query = new StringBuilder();
          Map<String, Object> var = new HashMap<String, Object>();
          var.put("envelopeId", envelopeId);
          var.put("companyId", companyId);
          var.put("loginUserId",loginUserId);
          var.put("bidderId",bidderId);
          query.append(" select distinct tblbidderitems.childId ");
          query.append(" from TblBidderItems tblbidderitems where tblbidderitems.tblTenderEnvelope.envelopeId=:envelopeId ");
          query.append(" and tblbidderitems.createdBy=:loginUserId and  tblbidderitems.tblCompany.companyId=:companyId  and tblbidderitems.tblUserLogin.userId=:bidderId and tblbidderitems.isActive= 1 ");
          List<Object> object = hibernateQueryDao.singleColQuery(query.toString(), var);
          if(object != null && !object.isEmpty())
          {
        	  childId = object.get(0);
        	  
          }
		return childId;
	}

	/**
       * 
       * @author bharat
       * @param envelopeId
       * @param userId
       * @param companyId
       * @param formId
       * @return
       * @throws Exception
       */
       public boolean deleteTblItemSelection(int envelopeId,int userId,int companyId,int formId) throws Exception{
          Map<String, Object> var = new HashMap<String, Object>();
          var.put("envelopeId",envelopeId);
          var.put("userId",userId);
          var.put("companyId",companyId);
          if(formId != 0){
       	   var.put("formId",formId);
          }
          StringBuilder query = new StringBuilder();
          query.append(" delete from TblItemSelection tblItemSelection");
          query.append(" where tblItemSelection.tblTenderEnvelope.envelopeId=:envelopeId and tblItemSelection.createdBy=:userId and tblItemSelection.tblCompany.companyId=:companyId ");
          query.append(" and tblItemSelection.tblTenderForm.formId in (select formId from TblTenderForm where tblTenderEnvelope.envelopeId=:envelopeId and isPriceBid=1 )");
          if(formId != 0)
          {
       	   query.append(" and tblItemSelection.tblTenderForm.formId=:formId");
          }
          int cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);        
          return cnt!=0;
      }

       /**
        * 
        * @author bharat
        * @param envelopeId
        * @param userId
        * @param companyId
        * @param formId
        * @return
        * @throws Exception
        */
        public boolean deleteTblBidderItems(int envelopeId,int userId,int companyId,int formId) throws Exception{
           Map<String, Object> var = new HashMap<String, Object>();
           var.put("envelopeId",envelopeId);
           var.put("userId",userId);
           var.put("companyId",companyId);
           if(formId != 0){
        	   var.put("formId",formId);
           }
           StringBuilder query = new StringBuilder();
           query.append(" delete from TblBidderItems tblbidderitems");
           query.append(" where tblbidderitems.tblTenderEnvelope.envelopeId=:envelopeId and tblbidderitems.createdBy=:userId and tblbidderitems.tblCompany.companyId=:companyId ");
           if(formId != 0)
           {
        	   query.append(" and tblbidderitems.tblTenderForm.formId =:formId");
           }
           int cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);        
           return cnt!=0;
       }

       
       /**
        * @author bharat
        * @param tenderId
        * @return
        */
      public List<Object[]> getBidderItems(int tenderId,int bidderId,int formId,boolean isSelectedReq) {
   		 StringBuilder query = new StringBuilder();
           Map<String, Object> var = new HashMap<String, Object>();
           var.put("tenderId", tenderId);
           var.put("bidderId", bidderId);
           if(formId != 0){
           	var.put("formId", formId);
           }
           query.append(" select tblItemSelection.tblTenderForm.formId,tblItemSelection.tblTenderTable.tableId,tblItemSelection.rowId,tblItemSelection.isSelected,tblItemSelection.tblUserLogin.userId,tblItemSelection.createdBy,tblItemSelection.isBidded,tblItemSelection.bidderItemId ");
           query.append(" from TblItemSelection tblItemSelection where tblItemSelection.tblTender.tenderId=:tenderId ");
           query.append(" and tblItemSelection.tblUserLogin.userId=:bidderId and tblItemSelection.tblTenderForm.isPriceBid= 1 ");
           if(isSelectedReq){
         	query.append(" and tblItemSelection.isSelected=1  ");
           }
         	if(formId != 0){
         		query.append(" and tblItemSelection.tblTenderForm.formId=:formId");
         	}
           return hibernateQueryDao.createQuery(query.toString(), var);
   	}
      
      /**
       * @author bharat
       * @param tenderId
       * @return
       */
     public List<Object[]> getBidderItemssByOfficer(int tenderId,int bidderId,List<Integer> userLoginId) {
   		 StringBuilder query = new StringBuilder();
          Map<String, Object> var = new HashMap<String, Object>();
          var.put("tenderId", tenderId);
          if(bidderId != 0){
        	  var.put("bidderId", bidderId);
          }
          var.put("userLoginId", userLoginId);
          query.append(" select tblbidderitems.tblTenderForm.formId,tblbidderitems.tblTenderTable.tableId,tblbidderitems.rowId,tblbidderitems.isActive,tblbidderitems.tblUserLogin.userId,tblbidderitems.createdBy,tblbidderitems.isApproved");
          query.append(" from TblBidderItems tblbidderitems where tblbidderitems.tblTender.tenderId=:tenderId and tblbidderitems.isActive=1 ");
          if(bidderId != 0){
        	  query.append(" and tblbidderitems.tblUserLogin.userId=:bidderId ");
          }
          query.append(" and tblbidderitems.createdBy in (:userLoginId) ");
          return hibernateQueryDao.createQuery(query.toString(), var);
   	}

     public void getBidDetailTblValue(int envelopformId,Map<Object, String> encReqFieldValue,int companyId,List<Object> cellIdList) {
   		// TODO Auto-generated method stub
   		StringBuilder query = new StringBuilder();
           Map<String, Object> var = new HashMap<String, Object>();
           var.put("formId", envelopformId);
           var.put("companyId", companyId);
           query.append(" select tblBidDetail.cellId,tblBidDetail.cellValue ");
           query.append(" from TblBidDetail tblBidDetail where tblBidDetail.formId=:formId and tblBidDetail.companyId=:companyId ");
           List<Object[]> resultList = hibernateQueryDao.createQuery(query.toString(), var);
           if(resultList != null && !resultList.isEmpty())
           {
           	for(Object[] obj : resultList){
           		encReqFieldValue.put(obj[0], obj[1].toString());
           		cellIdList.add(obj[0]);
           	}
           }
   	}
   	
   	/**
        * 
        * @author bharat
        * @param tenderId
        * @return
        * @throws Exception
        */
       
       public List<Object[]> getApprovedPriceBidForm(int tenderId) throws Exception{
       	Map<String,Object> var = new HashMap<String,Object>();
           StringBuilder queryString = new StringBuilder();
           var.put("tenderId", tenderId);
           queryString.append("select tbltenderform.formId , tbltenderform.formName,tbltenderform.tblTenderEnvelope.envelopeId,tbltenderform.tblTenderEnvelope.minFormsReqForBidding,tbltenderform.tblTenderEnvelope.envelopeName,tbltenderform.isMandatory ");
           queryString.append(" from TblTenderForm tbltenderform");
           queryString.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.isPriceBid=1 and tbltenderform.cstatus=1 ");
           return hibernateQueryDao.createNewQuery(queryString.toString(), var);
       }      

     
     /**
      * @author nirav.prajapati
      * @param clientId
      * @param eventTypeId
      * @return
      */
     public List<Object[]> getColumnDetailByClient(int clientId,int eventTypeId)
     {
     	StringBuilder query = new StringBuilder();
      	Map<String,Object> var = new HashMap<String,Object>();
         var.put("clientId", clientId);
         var.put("eventTypeId", eventTypeId);
  		query.append("select tblClientColumnType.tblColumnType.columnTypeId,tblClientColumnType.tblColumnType.lang1,tblClientColumnType.isMandatory from TblClientColumnType tblClientColumnType left join tblClientColumnType.tblColumnType tblColumnType where tblClientColumnType.tblClient.clientId=:clientId and tblClientColumnType.tblEventType.eventTypeId=:eventTypeId and tblClientColumnType.isActive=1");
         return hibernateQueryDao.createNewQuery(query.toString(), var);
     }
     
         /**
     * 
     * @param formId
     * @param companyId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getSelectedRowsForBidding(int formId,int companyId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        var.put("companyId",companyId);
        return hibernateQueryDao.createNewQuery("select tblitemselection.tblTenderTable.tableId, tblitemselection.rowId from TblItemSelection tblitemselection where tblitemselection.tblCompany.companyId=:companyId and tblitemselection.tblTenderForm.formId=:formId and tblitemselection.isSelected=1",var);                
    }
    
    /**
     * 
     * @param formId
     * @param companyId
     * @return
     * @throws Exception 
     */
    public List<Object[]> getSelectedRowsForBidding(Object[] formId,int companyId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        var.put("companyId",companyId);
        return hibernateQueryDao.createNewQuery("select tblitemselection.tblTenderTable.tableId, tblitemselection.rowId from TblItemSelection tblitemselection where tblitemselection.tblCompany.companyId=:companyId and tblitemselection.tblTenderForm.formId in (:formId) and tblitemselection.isSelected=1",var);                
    }
    
     /**
      * @author bharat
      * @param committeeId
      * @param envelopId
      * @return
      */
    public List<Object[]> getUserRoleByCommiteeIdEnvelopId(int committeeId,int envelopId) {
 		 StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("committeeId", committeeId);
         var.put("envelopId", envelopId);
         query.append(" select tblCommitteeUser.tblUserLogin.userId,tblCommitteeUser.userRoleId,tblCommitteeUser.tblUserDetail.userName,tblCommitteeUser.encryptionLevel ");
         query.append(" from TblCommitteeUser tblCommitteeUser ");
         query.append(" where tblCommitteeUser.childId=:envelopId and tblCommitteeUser.tblCommittee.committeeId=:committeeId order by tblCommitteeUser.encryptionLevel asc,tblCommitteeUser.userRoleId desc");
         return hibernateQueryDao.createNewQuery(query.toString(), var);
 	}

    
    /**
     * Get officer name and role mapping
     * @param userRole
     * @param modelMap
     * @param loginuserid
     */
	public void setOfficerRoleNameMapping(List<Object[]> userRole,ModelMap modelMap,int loginuserid,int tenderId) {

 	 Map<String,ArrayList<String>> roleMap = new LinkedHashMap<String, ArrayList<String>>();
   	 Map<String,String> userNameMap = new LinkedHashMap<String, String>();
   	 for(Object[] roleObject : userRole)
   	 {
   		 String rolLevel="0";
   		 userNameMap.put(roleObject[0].toString(),roleObject[2].toString());
   		 
   		 if(roleObject[3].equals(1) && roleObject[1].equals(2))
   		 {
   			 rolLevel = "1"; 
   		 }else if(roleObject[3].equals(1) && roleObject[1].equals(1))
   		 {
   			 rolLevel = "2"; 
   		 }else if(roleObject[3].equals(2) && roleObject[1].equals(2))
   		 {
   			 rolLevel = "3"; 
   		 }else if(roleObject[3].equals(2) && roleObject[1].equals(1))
   		 {
   			 rolLevel = "4"; 
   		 }
   		 if(roleMap.containsKey(rolLevel)){
   			 roleMap.get(rolLevel).add(roleObject[0].toString());
   		 }else{
   			 ArrayList<String> arr = new ArrayList<String>();
   			 arr.add(roleObject[0].toString());
   			 roleMap.put(rolLevel,arr);
   			 
   			 ArrayList<String> arr1 = new ArrayList<String>();
   			 arr1.add(roleObject[0].toString());
   			 
   		 }
   		 if(loginuserid == Integer.parseInt(roleObject[0].toString()))
   		 {
   			 modelMap.addAttribute("loginUserRole",rolLevel);
   		 }
   	 }
   	 modelMap.addAttribute("userNameMap",userNameMap);
   	 modelMap.addAttribute("roleMap",roleMap);
   	 int currentUserRole =Integer.parseInt(modelMap.get("loginUserRole").toString());
   	 if(currentUserRole > 1){
   		modelMap.addAttribute("allowReworkLink",isReworkLinkAllow(currentUserRole,tenderId));
   	 }else{
   		modelMap.addAttribute("allowReworkLink",false);
   	 }
		
		
	}

	public boolean isReworkLinkAllow(int currentUserRole,int tenderId) {
		boolean flag = true;
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("currentUserRole",currentUserRole);
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append("select reworkDetailId from TblReworkDetail tblreworkdetail where tblreworkdetail.tblEvaluationRework.askedToLevel <:currentUserRole and tblreworkdetail.cstatus = 0 and tblreworkdetail.tblEvaluationRework.tenderId=:tenderId ");
        List<Object[]> object =  hibernateQueryDao.createNewQuery(query.toString(),var);
        if(object != null && !object.isEmpty())
        {
        	flag = false;
        }
        return flag;
		
	}

	/*private List<Object> getOfficerRoleBelowCurrent(Map<String, ArrayList<String>> roleMap,
			int currentUserRole) {
		List<Object> userRole = new ArrayList<Object>();
		for(int i = 1; i < currentUserRole; i++)
		{
			userRole.add(roleMap.get(i));
		}
		return userRole; 
	}*/

	/**
     * 
     * @author Lipi Shah
     * @return
     * @throws Exception 
     */
    public TblCommitteeUser getCommitteeUserDtlByEnvelope(int userId, int envelopeId,int committeeId) throws Exception{
    	List<TblCommitteeUser> list = tblCommitteeUserDao.findTblCommitteeUser("tblUserLogin.userId", Operation_enum.EQ, userId, "childId", Operation_enum.EQ, envelopeId,"tblCommittee.committeeId",Operation_enum.EQ,committeeId);
    	return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
    /**
     * @author Lipi Shah
     * @return
     * @throws Exception 
     */
    public TblEvaluationRework getTblEvaluationReworkByLevel(int askedToLevel,int tenderId) throws Exception{
    	List<TblEvaluationRework> list = null; 
    	list = tblEvaluationReworkDao.findTblEvaluationRework("askedToLevel", Operation_enum.EQ, askedToLevel,"cstatus", Operation_enum.EQ, 0,"tenderId",Operation_enum.EQ,tenderId);
    	return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
    
    /**
    * author Lipi shah
    * @param tblEvaluationReworkList
    * @return
    * @throws Exception
    */
   public boolean addTblEvaluationRework(List<TblEvaluationRework> tblEvaluationReworkList) throws Exception {
       boolean bSuccess = false;
       tblEvaluationReworkDao.saveUpdateAllTblEvaluationRework(tblEvaluationReworkList);
       bSuccess = true;
       return bSuccess;
   }
   /**
    * author Lipi shah
    * @param tblEvaluationReworkList
    * @return
    * @throws Exception
    */
   public boolean addTblReworkDetail(List<TblReworkDetail> tsblReworkDetailList) throws Exception {
       boolean bSuccess = false;
       tblReworkDetailDao.saveUpdateAllTblReworkDetail(tsblReworkDetailList);
       bSuccess = true;
       return bSuccess;
   }

     

    /**
     * 	
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getProxyColumnData(int tenderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("loadingFactor",loadingFactor);
        StringBuilder query = new StringBuilder();
        query.append("select b.tableId,c.columnId,d.cellId,d.rowId from apptender.tbl_TenderForm a inner join apptender.tbl_TenderTable b on a.formId=b.formId ");
        query.append(" inner join  apptender.tbl_TenderColumn c on b.tableId=c.tableId and c.filledBy=4 and c.columnTypeId=:loadingFactor");
        query.append(" inner join apptender.tbl_TenderCell d on c.columnId=d.columnId where a.tenderId=:tenderId  and a.cstatus = 1 ");
        return hibernateQueryDao.createSQLQuery(query.toString(),var);        
    }

    /**
     * 	
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getProxyColumnData(int tenderId,List<Integer> formIds) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("loadingFactor",loadingFactor);
        if(formIds != null && !formIds.isEmpty()){
        	var.put("formIds",formIds);
        }
        StringBuilder query = new StringBuilder();
        query.append("select b.tableId,c.columnId,d.cellId,d.rowId from apptender.tbl_TenderForm a inner join apptender.tbl_TenderTable b on a.formId=b.formId ");
        query.append(" inner join  apptender.tbl_TenderColumn c on b.tableId=c.tableId and c.filledBy=4 and c.columnTypeId=:loadingFactor");
        query.append(" inner join apptender.tbl_TenderCell d on c.columnId=d.columnId where a.tenderId=:tenderId and a.cstatus = 1 ");
        if(formIds != null && !formIds.isEmpty()){
        	query.append(" and  a.formId in (:formIds) ");
        }
        return hibernateQueryDao.createSQLQuery(query.toString(),var);        
    }
    /**
	 * 
	 * @param tenderId
	 * @param companyId
	 * @return
	 */
	public List<Object[]> getProxyBidTblValue(int tenderId, int companyId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("companyId", companyId);
        StringBuilder query = new StringBuilder();
        query.append(" select tbltenderproxybid.tblTenderCell.cellId,cellValue,tbltenderproxybid.tblTenderTable.tblTenderForm.formId,tbltenderproxybid.tblTenderTable.tableId,tbltenderproxybid.rowId,tbltenderproxybid.isUpdatedFrom ");
        query.append(" from TblTenderProxyBid tbltenderproxybid where tbltenderproxybid.tblTender.tenderId=:tenderId and tbltenderproxybid.isUpdatedFrom !=0 and tbltenderproxybid.tblCompany.companyId=:companyId and tbltenderproxybid.tblTenderTable.tblTenderForm.cstatus=1");
        return hibernateQueryDao.createQuery(query.toString(), var);
	}
	
	/**
	 * 
	 * @param proxyDetail
	 * @param companyId
	 * @return
	 * @throws Exception
	 */

    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
    public  boolean updateBidderFactor(Map<Integer,String> proxyDetail,int companyId) throws Exception{
        boolean bSuccess = false;
        for (Integer cellId : proxyDetail.keySet()) {
            Map<String, Object> var = new HashMap<String, Object>();        
            var.put("cellId",cellId);
            var.put("cellValue",proxyDetail.get(cellId));
            var.put("companyId",companyId);
            hibernateQueryDao.updateDeleteNewQuery("update TblTenderProxyBid set cellValue=:cellValue,isUpdatedFrom=2 where tblTenderCell.cellId=:cellId and tblCompany.companyId=:companyId", var);
            bSuccess=true;
        }
        return bSuccess;
    }

    /**
     * 
     * @param cellIdList
     * @param encReqFormMap
     * @param encReqTableMap
     */
	public void getFormTableMap(List<Object> cellIdList, Map<Object,Object> encReqFormMap,Map<Object,Object> encReqTableMap) {
		
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("cellIdList", cellIdList);
        StringBuilder query = new StringBuilder();
        query.append(" select distinct tbltendercell.tblTenderTable.tableId,tbltendercell.tblTenderForm.formId ");
        query.append(" from TblTenderCell tbltendercell where tbltendercell.cellId in (:cellIdList) ");
        List<Object[]> resultList = hibernateQueryDao.createQuery(query.toString(), var);
        if(resultList != null && !resultList.isEmpty())
        {
        	for(Object[] obj : resultList){
        		encReqFormMap.put(obj[1], obj[1]);
        		encReqTableMap.put(obj[0], obj[0]);
        	}
        	
        }
		
	}
	
	   /*
     * author : Lipi Shah
     * used to get approved forms as per envid
     */
    public List<Object[]> getApprovedForms(int tenderId,int companyId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
        StringBuilder query = new StringBuilder();
        query.append("SELECT distinct tbltenderproxybid.tblTenderTable.tblTenderForm.formId,tbltenderproxybid.tblTenderTable.tblTenderForm.formName from TblTenderProxyBid tbltenderproxybid ");
        query.append(" where tbltenderproxybid.tblCompany.companyId=:companyId and tbltenderproxybid.tblTender.tenderId=:tenderId and tbltenderproxybid.isUpdatedFrom=2 and tbltenderproxybid.tblTenderTable.tblTenderForm.cstatus=1 ");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
	
    public List<Object[]> getApprovedFormsAfterLoading(int tenderId,int companyId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
        StringBuilder query = new StringBuilder();
        query.append("SELECT DISTINCT tt.formId AS c0,tf.formName AS c1");
        query.append(" FROM apptender.tbl_TenderTable AS tt ");
	        query.append(" LEFT JOIN apptender.Tbl_TenderForm AS tf ON tt.formId = tf.formId ");
	        query.append(" LEFT JOIN apptenderbid.Tbl_TenderProxyBid AS tpb ON tpb.tableId = tt.tableId ");
	        query.append(" LEFT JOIN apptenderbid.tbl_ItemSelection AS tis ON tis.formId = tt.formId AND tis.companyId=tpb.companyId ");
        query.append(" WHERE tpb.companyId =:companyId AND tpb.tenderId =:tenderId AND tpb.isUpdatedFrom=2 AND tf.cstatus = 1 AND tis.isBidded = 1 ");
        int nVarCharColumnIndex [] = {1};
    	return hibernateQueryDao.createSQLQuery(query.toString(), var,nVarCharColumnIndex,2);
    }
    
    public List<Object[]> getApprovedFormsBeforeAfterLoading(int tenderId,int companyId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
        StringBuilder query = new StringBuilder();
        query.append("SELECT DISTINCT tt.formId AS c0,tf.formName AS c1");
        query.append(" FROM apptender.tbl_TenderTable AS tt ");
	        query.append(" LEFT JOIN apptender.Tbl_TenderForm AS tf ON tt.formId = tf.formId ");
	        query.append(" LEFT JOIN apptenderbid.Tbl_TenderProxyBid AS tpb ON tpb.tableId = tt.tableId ");
	        query.append(" LEFT JOIN apptenderbid.tbl_ItemSelection AS tis ON tis.formId = tt.formId AND tis.companyId=tpb.companyId ");
        query.append(" WHERE tpb.companyId =:companyId AND tpb.tenderId =:tenderId AND (tpb.isUpdatedFrom=1 or tpb.isUpdatedFrom=2) AND tf.cstatus = 1 AND tis.isBidded = 1 ");
        int nVarCharColumnIndex [] = {1};
    	return hibernateQueryDao.createSQLQuery(query.toString(), var,nVarCharColumnIndex,2);
    }
    public List<Object[]> getBidderBid(int companyId,int formId){
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();        
        var.put("companyId",companyId);
        var.put("formId",formId);
        StringBuilder query = new StringBuilder();
        query.append("select tbltenderbiddetail.tblTenderCell.cellId, tbltenderbiddetail.cellValue,tbltenderbid.bidId,tbltenderbidmatrix.bidTableId from TblTenderBid tbltenderbid inner join tbltenderbid.tblTenderBidMatrix tbltenderbidmatrix inner join tbltenderbidmatrix.tblTenderBidDetail tbltenderbiddetail where tbltenderbid.tblTenderForm.formId=:formId and tbltenderbid.tblCompany.companyId=:companyId"); 
        list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return list;
    }
    /**
     * 
     * @param bidDetail
     * @param companyId
     * @param bidTableId
     * @return
     * @throws Exception
     */
    
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
    public  boolean updateBidderDetailFactor(Map<Integer,String> bidDetail,int companyId,List<Integer> bidTableId) throws Exception{
        boolean bSuccess = false;
        for (Integer cellId : bidDetail.keySet()) {
            Map<String, Object> var = new HashMap<String, Object>();        
            var.put("cellId",cellId);
            var.put("cellValue",bidDetail.get(cellId));
            var.put("bidTableId",bidTableId);
            hibernateQueryDao.updateDeleteNewQuery("update TblTenderBidDetail set cellValue=:cellValue where tblTenderCell.cellId=:cellId and tblTenderBidMatrix.bidTableId in (:bidTableId)", var);
            bSuccess=true;
        }
        
        return bSuccess;
    }
    /**
     * 
     * @param tblLoadingFactorProcess
     */

	public void updateLoadingFactorProcess(TblLoadingFactorProcess tblLoadingFactorProcess) {
		tblLoadingFactorProcessDao.saveOrUpdateTblLoadingFactorProcess(tblLoadingFactorProcess);
	}

	@Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public void deleteLoadingFactorProcess(int tenderId, int companyId, Integer formId ) {
			
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("tenderId",tenderId);
	    var.put("companyId",companyId);
	    if(formId != 0){
    	  var.put("formId",formId);
	    }
	    StringBuilder query = new StringBuilder();
	    query.append("delete from TblLoadingFactorProcess where companyId=:companyId and tenderId=:tenderId");
	    if(formId != 0){
	    	query.append(" and formId=:formId  ");
	    }
        hibernateQueryDao.updateDeleteNewQuery(query.toString(), var);        
	}
	/**
	 * 
	 * @param formId
	 * @param companyId
	 * @return
	 */
	public List<Object[]> getLoadingFactorProcessDetail(int tenderId,Integer formId,
			Integer companyId) {
		  List<Object[]> list = null;
	      Map<String, Object> var = new HashMap<String, Object>();        
	      var.put("companyId",companyId);
	      if(formId != 0){
	    	  var.put("formId",formId);
	      }
	      var.put("tenderId",tenderId);
	      
	      StringBuilder query = new StringBuilder();
	      query.append("select loadingFactorProcessId,formId from TblLoadingFactorProcess where companyId=:companyId and tenderId=:tenderId");
	      if(formId != 0){
	    	  query.append(" and formId=:formId  ");
	      }
	      list = hibernateQueryDao.createNewQuery(query.toString(), var);
	      return list;
	}
	  public List<Object[]> getCompanyIdForDecryptVerify(int tenderId){
	        List<Object[]> list = null;
	        Map<String, Object> var = new HashMap<String, Object>();        
	        var.put("tenderId",tenderId);
	        StringBuilder query = new StringBuilder();
	        query.append("SELECT tblTenderProxyBid.tblCompany.companyId,COUNT(tblTenderProxyBid.proxyBidId)");
	        query.append(" FROM TblTenderProxyBid tblTenderProxyBid ");
	        query.append(" WHERE tblTenderProxyBid.isUpdatedFrom=2 and tblTenderProxyBid.tblTender.tenderId=:tenderId"); 
	        query.append(" GROUP BY tblTenderProxyBid.tblCompany.companyId");
	        list = hibernateQueryDao.createNewQuery(query.toString(), var);
	        return list;
	    }

	  /*
	     * author : Lipi Shah
	     * used to get bidders list for evaluate (A/R) as per item evaluation for technical
	     */
	    public List<Object[]> getAllBidders(int tenderId,int userId) throws Exception{
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put("tenderId",tenderId);
	        var.put("userId",userId);
	        StringBuilder query = new StringBuilder();
	        query.append(" SELECT distinct(tblbidderitems.tblCompany.companyId),tblbidderitems.tblUserLogin.userId");
	        query.append(" FROM TblBidderItems tblbidderitems");
	        query.append(" WHERE tblbidderitems.tblTender.tenderId=:tenderId");
	        query.append(" AND tblbidderitems.isApproved = 1 and tblbidderitems.isActive = 1 ");
	        query.append(" AND tblbidderitems.createdBy=:userId");
	        return hibernateQueryDao.createNewQuery(query.toString(), var);
	    }

		/** Get the tablename form wise by tenderId
           * @mitesh
           * @param tenderId
           * @return 
           */
           public List<Object[]> getTableDetailsByTenderId(int tenderId){
	        List<Object[]> list = null;
	        Map<String, Object> var = new HashMap<String, Object>();        
	        var.put("tenderId",tenderId);
	        StringBuilder query = new StringBuilder();
	        query.append(" select tblTenderForm.formId,tblTenderTable.tableName,tblTenderTable.isMandatory from TblTenderForm tblTenderForm ");
                query.append("inner join tblTenderForm.tblTenderTable tblTenderTable ");
                query.append("where tblTenderForm.tblTender.tenderId=:tenderId ");
	        list = hibernateQueryDao.createNewQuery(query.toString(), var);
	        return list;
	    }

           public long getLoadingBeforeFormsCompanyWise(int tenderId,int companyId) throws Exception{
               Map<String, Object> var = new HashMap<String, Object>();
               var.put("tenderId",tenderId);
               if(companyId != 0){
               	var.put("companyId",companyId);
               }
               StringBuilder query = new StringBuilder();
               long count = 0;
               query.append(" SELECT COUNT(tbltenderproxybid.proxyBidId) ");
               query.append(" from TblTenderProxyBid tbltenderproxybid");
               query.append(" where tbltenderproxybid.tblTender.tenderId=:tenderId and tbltenderproxybid.isUpdatedFrom=2");
               if(companyId != 0){
               	query.append(" and tbltenderproxybid.tblCompany.companyId=:companyId ");
               }
               //query.append(" order by tbltenderproxybid.tblCompany.companyId asc");
               List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(), var);
               if(list!=null && !list.isEmpty()){
                   count = Integer.parseInt(list.get(0).toString());
               }
                //System.out.println("getLoadingBeforeFormsCompanyWise count= " +count);
               return count;
           }

           public List<Object[]> isBidderBidWithLoadingFactor(int tenderId,int companyId) throws Exception {
               Map<String, Object> var = new HashMap<String, Object>();
               var.put("tenderId", tenderId);
               StringBuilder query = new StringBuilder();
               query.append(" select distinct tb.companyId");
               query.append(" from apptender.tbl_TenderColumn tc");
               query.append(" inner join apptenderbid.tbl_TenderBidMatrix tbm on tc.tableId = tbm.tableId and tc.columnTypeId=23 and tc.filledBy=4");
               query.append(" inner join apptenderbid.tbl_TenderBid tb on tb.bidId=tbm.bidId and tb.cstatus=2");
               //query.append(" inner join apptenderbid.tbl_TenderBid tb on tc.formId=tb.formId and tc.columnTypeId=23 and tc.filledBy=4");
               query.append(" where tb.tenderId=:tenderId");        
               if(companyId!=0){
                   var.put("companyId", companyId);
                   query.append(" and companyId=:companyId");
               }
               List<Object[]> list = hibernateQueryDao.nativeSQLQuery(query.toString(), var);
               return list!=null && !list.isEmpty() ? list : null;
           }

           /** Get the company Id & form Id details for the Loding save report.
            * @auther Janak
            * @param tenderId
            * @return
            * @throws Exception 
            */
           public List<Object[]> getCompanyFormDetails(int tenderId) throws Exception{
               Map<String, Object> var = new HashMap<String, Object>();
               List<Object> priceEnvIds;
               var.put("tenderId", tenderId);
               StringBuilder query=new StringBuilder();
               
               query.append(" select distinct a.companyId,b.formId from apptenderbid.tbl_TenderProxyBid a ");
               query.append(" inner join apptender.tbl_TenderTable b on a.tableId=b.tableId ");
               query.append(" left join apptenderresult.tbl_LoadingFactorProcess lfp on lfp.formId=b.formId and lfp.companyId=a.companyId  ");
               query.append("where a.tenderId=:tenderId and isUpdatedFrom=2 AND lfp.formId IS NULL ");
               
               List<Object[]> list = hibernateQueryDao.nativeSQLQuery(query.toString(), var);
               return (list != null && !list.isEmpty()) ? list :null;
           }
           
           /**
            * @author janak
            * @param tenderId
            * @return
            */
          public List<Object[]> getBidderFromItemSelection(int tenderId,int bidderId,int formId,boolean isSelectedReq,boolean isBiddedReq) {
       		 StringBuilder query = new StringBuilder();
               Map<String, Object> var = new HashMap<String, Object>();
               var.put("tenderId", tenderId);
               if(formId != 0){
               	var.put("formId", formId);
               }
               query.append(" select tblItemSelection.tblTenderForm.formId,tblItemSelection.tblTenderTable.tableId,tblItemSelection.rowId,tblItemSelection.isSelected,tblItemSelection.tblUserLogin.userId,tblItemSelection.createdBy,tblItemSelection.isBidded ");
               query.append(" from TblItemSelection tblItemSelection where tblItemSelection.tblTender.tenderId=:tenderId and tblItemSelection.tblTenderForm.isPriceBid= 1 and tblItemSelection.tblTenderForm.cstatus=1 ");
               if(bidderId!=0){
                   var.put("bidderId", bidderId);
                query.append(" and tblItemSelection.tblUserLogin.userId=:bidderId  ");
               }
               if(isSelectedReq){
             	query.append(" and tblItemSelection.isSelected=1  ");
               }
               if(isBiddedReq){
            	   query.append(" and tblItemSelection.isBidded=1  ");
               }
               if(formId != 0){
            	   query.append(" and tblItemSelection.tblTenderForm.formId=:formId");
               }
               return hibernateQueryDao.createQuery(query.toString(), var);
       	}
          
          public List<Object[]> getTenderOpeningBidderDetails(int tenderId) throws Exception, Exception {

     		 int isConsortiumAllowed = Integer.parseInt(isConsortiumAllowed(tenderId));
     		 
     		 Map<String, Object> var = new HashMap<String, Object>();
     	     var.put("tenderId",tenderId);
     	     StringBuilder query=new StringBuilder("");
     	     
     	     query.append(" SELECT ");
     	     if(isConsortiumAllowed == 1)
     	    	query.append(" A.companyName as c0, ");
     	     else 
     	    	query.append(" UD.companyName+'','' as c0, ");
     	    query.append(" fs.bidderId as c1,fs.companyId as c2, te.envelopeId as c3,fs.consortiumId as c4,bad.isApproved as c5,bc.encodedName as c6,fs.partnerType as c7,bad.remarks as c8, "); 
     	    query.append(" (case when (te.sortOrder) > 1 then (select b.isApproved from apptenderresult.tbl_BidderApprovalDetail b where b.companyId=fs.companyId ");
     	    query.append("  and  b.envelopeId in (select c.envelopeId from apptender.tbl_TenderEnvelope c where c.tenderId=fs.tenderId and c.sortOrder=te.sortOrder-1)) Else -1 End) as c9 ");
     	    query.append(" FROM apptenderbid.tbl_FinalSubmission fs ");
     	    query.append(" INNER JOIN apptender.tbl_TenderEnvelope te on te.tenderId = fs.tenderId ");
     	    query.append(" INNER JOIN apptenderbid.tbl_TenderBidConfirmation bc ON bc.tenderId = fs.tenderId and bc.companyId=fs.companyId ");
     	    query.append(" LEFT JOIN apptenderresult.tbl_BidderApprovalDetail bad on bad.tenderId = fs.tenderId and te.envelopeId=bad.envelopeId and fs.bidderId=bad.bidderId ");
     	     
     	    if(isConsortiumAllowed == 1){
     		    query.append(" CROSS APPLY ( ");
     		    		query.append("	SELECT ' ' + UD.companyName +  CASE FS1.partnerType WHEN 2 THEN ' label_consort_with ' ELSE ',' END ");
     		    		query.append(" FROM apptenderbid.tbl_FinalSubmission FS1 ");
     		    		query.append(" INNER JOIN appuser.tbl_UserDetail UD ON FS1.userDetailId = UD.userDetailId ");
     		    		query.append(" WHERE fs.consortiumId = FS1.consortiumId ");
     					query.append(" ORDER BY FS1.partnerType, FS1.createdOn ");
     					query.append(" FOR XML PATH('') ");
     			query.append(" ) A (companyName) ");
     	   }else {
    	    	query.append(" INNER JOIN appuser.tbl_UserDetail UD ON fs.userDetailId = UD.userDetailId ");
     	   }
     	     
     	    query.append(" WHERE fs.tenderId=:tenderId  and fs.isActive=1 ");
     	   if(isConsortiumAllowed == 1){
    	    	query.append(" and fs.partnerType in (1,2) ");
     	   }else{ 
    	    	query.append(" ORDER BY te.envelopeId,fs.consortiumId,fs.partnerType ");
     	   }
     	  
     	  int nVarCharColumnIndex [] = {0,6,8};
     	  return hibernateQueryDao.createSQLQuery(query.toString(), var, nVarCharColumnIndex,10);
     	}
          /** Used for Publish Envlope link shown or not at Bidding Form
           * Lipi
           * @param tenderId
           * @return 
           */
//     public boolean getStatusForPublishEnv(int tenderId)throws Exception{
//   	        List<Object[]> list = null;
//   	        Map<String, Object> var = new HashMap<String, Object>();        
//   	        var.put("tenderId",tenderId);
//   	        long count = 0;
//   	        StringBuilder query = new StringBuilder();
//   	        query.append(" SELECT tblTenderForm.formId,tblTenderForm.cstatus ");
//   	        query.append(" FROM TblTender tblTender");
//   	        query.append(" INNER JOIN tblTender.tblTenderForm tblTenderForm ");
//   	        query.append(" WHERE tblTender.tenderId=:tenderId AND tblTender.cstatus=1 AND tblTenderForm.cstatus=1");
//   	        list = hibernateQueryDao.createNewQuery(query.toString(), var);
//   	        if(list!=null && !list.isEmpty()){
//   	        	count = hibernateQueryDao.countForNewQuery("TblCorrigendum tblCorrigendum ", "tblCorrigendum.corrigendumId ", "tblCorrigendum.objectId=:tenderId and tblCorrigendum.tblProcess.processId=1 and tblCorrigendum.cstatus=0", var);	        
//   	       }
//   	       if(count!=0){
//   	    	   return false;
//   	       }
//   	       return true;
//    	    }
     
     
     public List<Object[]> getTblNegotiationDetailByobjectIdAndCstatus(int tenderId)throws Exception{
		    Map<String, Object> var= new HashMap<String, Object>();
		    StringBuilder selectHQL=new StringBuilder();
		    var.put("objectId", tenderId);
		    selectHQL.append(" select tblNegotiationDetail.formId,tblNegotiationDetail.tableId,tblNegotiationDetail.rowId,tblNegotiationDetail.tblNegotiation.roundNo,tblNegotiationDetail.tblNegotiation.tblCompany.companyId, tblNegotiationDetail.tblNegotiation.tblCompany.companyName,tblNegotiationDetail.tblNegotiation.endDate,tblNegotiationDetail.isWinner,tblNegotiationDetail.tblNegotiation.isRebateReq, tblNegotiationDetail.tblNegotiation.rebateValue,tblNegotiationDetail.tblNegotiation.negotiationId  ");
		    selectHQL.append(" from TblNegotiationDetail tblNegotiationDetail,TblTenderForm tblTenderForm,TblTenderTable tblTenderTable ");
		    //selectHQL.append(" where tblNegotiationDetail.tblNegotiation.objectId = :objectId and tblNegotiationDetail.tblNegotiation.cstatus = 4 and tblNegotiationDetail.tblNegotiation.isRenegotiated = 0 order by 4,3 ");
		    selectHQL.append(" where tblTenderForm.formId = tblNegotiationDetail.formId and tblTenderTable.tableId = tblNegotiationDetail.tableId and tblNegotiationDetail.tblNegotiation.objectId = :objectId and tblNegotiationDetail.tblNegotiation.cstatus = 4 ");
		    selectHQL.append(" order by tblTenderForm.sortOrder,tblTenderTable.sortOrder,3 ");
		    List<Object[]> lst=hibernateQueryDao.createNewQuery(selectHQL.toString(), var);
		    return lst;
	  }
	  public List<Object[]> getNegotiatedL1ReportData(int tenderId)throws Exception{
			    Map<String, Object> var= new HashMap<String, Object>();
			    StringBuilder selectHQL=new StringBuilder();
			    var.put("objectId", tenderId);
			   /* selectHQL.append(" select tblNegotiationDetail.formId,tblNegotiationDetail.tableId,tblNegotiationDetail.rowId,tblNegotiationDetail.tblNegotiation.roundNo,tblNegotiationDetail.tblNegotiation.tblCompany.companyId, tblNegotiationDetail.tblNegotiation.tblCompany.companyName,tblNegotiationDetail.tblNegotiation.endDate ");
			    selectHQL.append(" from TblNegotiationDetail tblNegotiationDetail,TblTenderForm tblTenderForm,TblTenderTable tblTenderTable ");
			    selectHQL.append(" where tblTenderForm.formId = tblNegotiationDetail.formId and tblTenderTable.tableId = tblNegotiationDetail.tableId and tblNegotiationDetail.tblNegotiation.objectId = :objectId and tblNegotiationDetail.tblNegotiation.cstatus = 4 and tblNegotiationDetail.isWinner = 1  ");
			    selectHQL.append(" order by tblTenderForm.sortOrder,tblTenderTable.sortOrder,3 ");*/
			    selectHQL.append(" select tblNegotiationResult.formId,tblNegotiationResult.tableId,tblNegotiationResult.rowId,tblCompany.companyId,tblCompany.companyName,tblNegotiationResult.isWinner,tblNegotiationResult.negotiationId,tblTenderBidConfirmation.encodedName  ");
			    selectHQL.append(" from TblNegotiationResult tblNegotiationResult,TblCompany tblCompany,TblTenderBidConfirmation tblTenderBidConfirmation, TblBidderApprovalDetail tblBidderApprovalDetail ");
			    selectHQL.append(" where tblNegotiationResult.objectId=:objectId and tblCompany.companyId=tblNegotiationResult.companyId ");
			    selectHQL.append(" and tblTenderBidConfirmation.tblTender.tenderId=:objectId and tblTenderBidConfirmation.tblCompany.companyId=tblCompany.companyId and tblBidderApprovalDetail.tblCompany.companyId=tblCompany.companyId and tblBidderApprovalDetail.isApproved=1 and tblBidderApprovalDetail.tblTender.tenderId=:objectId ");
			    selectHQL.append(" order by tblNegotiationResult.formId,tblNegotiationResult.tableId,tblNegotiationResult.rowId asc ,tblNegotiationResult.isWinner desc");
			    List<Object[]> lst=hibernateQueryDao.createNewQuery(selectHQL.toString(), var);
			    return lst;
		  }
	  public List<Object[]> getcellIdAndValue(int tenderId)throws Exception{
			    Map<String, Object> var= new HashMap<String, Object>();
			    StringBuilder selectHQL=new StringBuilder();
			    var.put("objectId", tenderId);
			    selectHQL.append(" select tblTenderCell.cellId,tblTenderCell.cellValue,tblTenderCell.rowId,tblTenderCell.tblTenderTable.tableId,tblTenderCell.tblTenderColumn.tblColumnType.columnTypeId,tblTenderCell.tblTenderColumn.isShown  from TblTenderCell tblTenderCell ");
			    selectHQL.append(" where tblTenderCell.tblTenderForm.tblTender.tenderId = :objectId  and tblTenderCell.tblTenderColumn.tblColumnType.columnTypeId in (1,2) and tblTenderCell .dataType <> 0 order by 3,5 ");
			    List<Object[]> lst=hibernateQueryDao.createNewQuery(selectHQL.toString(), var);
			    return lst;
	  }
	  
	  public List<Object[]> getFilledByBidder(int tenderId)throws Exception{
			    Map<String, Object> var= new HashMap<String, Object>();
			    StringBuilder selectHQL=new StringBuilder();
			    var.put("objectId", tenderId);
			    selectHQL.append(" select tblTenderBidDetail.tblTenderCell.cellId,tblTenderBidDetail.cellValue,tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblCompany.companyId,tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblCompany.companyName,tblTenderBidDetail.tblTenderCell.rowId,tblTenderBidDetail.tblTenderCell.tblTenderColumn.tblColumnType.columnTypeId,tblTenderBidDetail.tblTenderCell.tblTenderTable.tableId,tblTenderBidDetail.tblTenderCell.tblTenderColumn.isShown ");
			    selectHQL.append(" from TblTenderBidDetail tblTenderBidDetail ");
			    selectHQL.append(" where tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblTender.tenderId = :objectId and tblTenderBidDetail.tblTenderCell.tblTenderColumn.tblColumnType.columnTypeId in (4,5,26,27) and tblTenderBidDetail.tblTenderCell.dataType <> 0 ");
			    List<Object[]> lst=hibernateQueryDao.createNewQuery(selectHQL.toString(), var);
			    return lst;
		  }
	  public List<Object[]> getNegotiationBid(int tenderId)throws Exception{
			    Map<String, Object> var= new HashMap<String, Object>();
			    StringBuilder selectHQL=new StringBuilder();
			    var.put("objectId", tenderId);
			    selectHQL.append(" select tblNegotiationBidDetail.cellId,tblNegotiationBidDetail.cellValue,tblNegotiationBidDetail.tblNegotiation.tblCompany.companyId,tblNegotiationBidDetail.tblNegotiation.roundNo,tblNegotiationBidDetail.tblNegotiation.negotiationId ");
			    selectHQL.append(" from TblNegotiationBidDetail tblNegotiationBidDetail, TblNegotiationSummary tblNegotiationSummary ");
			    selectHQL.append(" where tblNegotiationBidDetail.tblNegotiation.objectId = :objectId and tblNegotiationBidDetail.tblNegotiation.cstatus = 4 and tblNegotiationBidDetail.tblNegotiation.objectId = tblNegotiationSummary.objectId and tblNegotiationSummary.cstatus = 3 ");
			    List<Object[]> lst=hibernateQueryDao.createNewQuery(selectHQL.toString(), var);
			    return lst;
		  }
		public int updateNegotiationIsWinner(int tenderId,int companyId,int rowId,int tableId) throws Exception {
		      Map<String, Object> var = new HashMap<String, Object>();
		     // var.put("tenderId", tenderId);
		      var.put("companyId", companyId);
		      var.put("rowId", rowId);
		      var.put("tableId", tableId);
		      StringBuilder selectHQL=new StringBuilder();
				 // selectHQL.append(" update appcommon.tbl_NegotiationDetail set iswinner = 1  ");
				 // selectHQL.append(" where rowId = :rowId and tableId =:tableId and negotiationId = (select top 1 negotiationId from appcommon.tbl_Negotiation where objectId = :tenderId and cstatus = 4 and companyId = :companyId) ");
		      selectHQL.append(" update appcommon.tbl_NegotiationDetail set iswinner = 1 where negotiationdetailid = (select top 1 nd.negotiationdetailid from appcommon.tbl_NegotiationDetail nd join appcommon.tbl_Negotiation n on n.negotiationId = nd.negotiationId where nd.tableid = :tableId and nd.rowId = :rowId and n.companyid = :companyId and n.cstatus = 4 order by n.negotiationid desc)  ");
		      return hibernateQueryDao.updateDeleteSQLNewQuery(selectHQL.toString(),var);
		 }
		public int updateNegotiationIsWinnerToFalse(int tenderId) throws Exception {
		    Map<String, Object> var = new HashMap<String, Object>();
		    var.put("tenderId", tenderId);
		    StringBuilder selectHQL=new StringBuilder();
				    selectHQL.append(" update nd set iswinner = 0 from appcommon.tbl_NegotiationDetail nd join appcommon.tbl_Negotiation n on n.negotiationId = nd.negotiationId ");
				    selectHQL.append(" where n.objectId = :tenderId ");
		    return hibernateQueryDao.updateDeleteSQLNewQuery(selectHQL.toString(),var);
		}
	public List<Object[]> getLoadingColumns(int tenderId)throws Exception{
	    Map<String, Object> var= new HashMap<String, Object>();
	    StringBuilder selectHQL=new StringBuilder();
	    var.put("objectId", tenderId);
	    selectHQL.append(" select tblTenderColumn.columnId,tblTenderColumn.columnHeader,tblTenderColumn.tblColumnType.columnTypeId,tblTenderColumn.tblTenderTable.tableId  ");
	    selectHQL.append("  from TblTenderColumn tblTenderColumn ");
	    selectHQL.append(" where tblTenderColumn.tblTenderForm.tblTender.tenderId = :objectId and tblTenderColumn.tblColumnType.columnTypeId in (26,27)  order by tblTenderColumn.tblColumnType.columnTypeId desc ");
	    List<Object[]> lst=hibernateQueryDao.createNewQuery(selectHQL.toString(), var);
	    return lst;
}
public void negotiatedL1ReportData(Map<String, Object> modelMap, int tenderId){
	   	try {
				List<Object[]> lst = this.getNegotiatedL1ReportData(tenderId);
				List<Object[]> lst1 = this.getcellIdAndValue(tenderId);
				Set<Map<String, Object>> lstTblForm = new LinkedHashSet<Map<String,Object>>();
			    Set<Map<String, Object>> set = new LinkedHashSet<Map<String,Object>>();
			    for (Object[] objects : lst) {
			    	Map<String, Object> map = new HashMap<String, Object>();
			    	map.put("formId", objects[0]);
			    	TblTenderForm tblTenderForm = getTenderFormById((Integer)objects[0]);
			    	map.put("formName", tblTenderForm.getFormName());
			    	map.put("formHeader", tblTenderForm.getFormHeader());
			    	map.put("formFooter", tblTenderForm.getFormFooter());
			    	lstTblForm.add(map);
			    	TblTenderTable tblTenderTable = tblTenderTableDao.findTblTenderTable("tableId",Operation_enum.EQ,objects[1]).get(0);
			    	map = new HashMap<String, Object>();
			    	map.put("tableId", objects[1]);
			    	map.put("formId", objects[0]);
			    	map.put("tableName", tblTenderTable.getTableName());
			    	map.put("tableHeader", tblTenderTable.getTableHeader());
			    	map.put("tableFooter", tblTenderTable.getTableFooter());
			    	set.add(map);
			    	map = null;
				}
			    modelMap.put("lstFormList",lstTblForm);
			    modelMap.put("lstTableList",set);
			    modelMap.put("lstFilledByOfficer",lst1);
			    modelMap.put("lstItems",lst);
			    modelMap.put("filledByBidder", this.getFilledByBidder(tenderId));
			    modelMap.put("negotiationBid", this.getNegotiationBid(tenderId));
			    lst = null;
			    lst1 = null;
			    lstTblForm = null;
			    set = null;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	   }

	public List<Object[]> getDataFromBid(int tenderId) throws Exception {
	    Map<String, Object> var = new HashMap<String, Object>();
	    var.put(TENDER_ID, tenderId);
	    StringBuilder query = new StringBuilder();
	    /*Changes for showing encoded name in Negotiation summary PT #50381*/
	    int isEncodedForNegotiation = Integer.valueOf(tenderCommonService.getTenderField(tenderId,"isEncodedForNegotiation").toString());  
	   
	   
    	int isEncoded=commonService.getLetestCstatusEncodeDecodeHistory(tenderId);
		int isEncodedName=0;
		if(isEncodedForNegotiation==1 && isEncoded==1) {
			isEncodedName=1;
		}
	    
	    query.append(" select tblTenderBidDetail.tblTenderCell.tblTenderForm.formId, ");
		query.append(" tblTenderBidDetail.tblTenderCell.tblTenderTable.tableId, ");
		query.append(" tblTenderBidDetail.tblTenderCell.rowId, ");
		query.append(" tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblCompany.companyId, ");
		if(isEncodedName==1){
		  query.append(" tblTenderBidConfirmation.encodedName ");
		}
		else{
			query.append(" tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblCompany.companyName ");
		}
        query.append(" from TblTenderBidDetail tblTenderBidDetail ,TblFinalSubmission tblFinalSubmission, TblBidderApprovalDetail tblBidderApprovalDetail");
        if(isEncodedName==1){
        	query.append(",TblTenderBidConfirmation tblTenderBidConfirmation");
        }
		query.append(" where tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblTender.tenderId =:tenderId ");
		query.append(" AND tblFinalSubmission.tblTender.tenderId = tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblTender.tenderId ");
		query.append(" AND tblFinalSubmission.tblCompany.companyId = tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblCompany.companyId ");
		query.append(" AND tblFinalSubmission.isActive  =1 ");
		query.append(" and tblTenderBidDetail.tblTenderCell.dataType <> 0 ");
		query.append(" AND tblTenderBidDetail.tblTenderCell.tblTenderForm.isPriceBid = 1  ");
		query.append(" AND tblTenderBidDetail.tblTenderCell.tblTenderForm.cstatus = 1 ");
		query.append(" AND tblBidderApprovalDetail.tblCompany.companyId=tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblCompany.companyId AND tblBidderApprovalDetail.isApproved=1 AND tblBidderApprovalDetail.tblTender.tenderId=:tenderId ");
		if(isEncodedName==1){
		 query.append(" AND tblTenderBidConfirmation.tblTender.tenderId = tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblTender.tenderId ");
		 query.append(" AND tblTenderBidConfirmation.tblCompany.companyId = tblTenderBidDetail.tblTenderBidMatrix.tblTenderBid.tblCompany.companyId ");
		}
		return hibernateQueryDao.createNewQuery(query.toString(), var);
	}
	@SuppressWarnings("unchecked")
	public void setNegotiationSummeryData(Map<String, Object> modelMap, int tenderId){
		 try {
			List<Object[]> lstAllData = this.getDataFromBid(tenderId);
			List<Object[]> lst = this.getTblNegotiationDetailByobjectIdAndCstatus(tenderId);
			List<Object[]> lst1 = this.getcellIdAndValue(tenderId);
			Set<Map<String, Object>> lstTblForm = new LinkedHashSet<Map<String,Object>>();
		    Set<Map<String, Object>> set = new LinkedHashSet<Map<String,Object>>();
		    for (Object[] objects : lstAllData) {
		    	Map<String, Object> map = new HashMap<String, Object>();
		    	map.put("formId", objects[0]);
		    	TblTenderForm tblTenderForm = getTenderFormById((Integer)objects[0]);
		    	map.put("formName", tblTenderForm.getFormName());
		    	map.put("formHeader", tblTenderForm.getFormHeader());
		    	map.put("formFooter", tblTenderForm.getFormFooter());
		    	lstTblForm.add(map);
		    	TblTenderTable tblTenderTable = tblTenderTableDao.findTblTenderTable("tableId",Operation_enum.EQ,objects[1]).get(0);
		    	map = new HashMap<String, Object>();
		    	map.put("tableId", objects[1]);
		    	map.put("formId", objects[0]);
		    	map.put("tableName", tblTenderTable.getTableName());
		    	map.put("tableHeader", tblTenderTable.getTableHeader());
		    	map.put("tableFooter", tblTenderTable.getTableFooter());
		    	set.add(map);
		    	map = null;
			}
		   List<Map<String, Object>> lstCompany = new ArrayList<Map<String,Object>>();
		   
		    for (Map<String, Object> map : set) {
		    	int max = 0;
		    	Set<Map<String, Object>> setCompanyIds = new HashSet<Map<String, Object>>();
		    	Set<Map<String, Object>> setRowIds = new LinkedHashSet<Map<String, Object>>();
		    	for (Object[] objects : lstAllData) {
		    		if(map.get("tableId").toString().trim().equals(objects[1].toString().trim())){
		    			Map<String, Object> map1 = new HashMap<String, Object>();
		    			map1.put("companyId", objects[3]);
		    			map1.put("companyName", objects[4]);
		    			setCompanyIds.add(map1);
		    			map1 = new HashMap<String, Object>();
		    			for (Object[] objects1 : lst1) {
		    				if(map.get("tableId").toString().trim().equals(objects1[3].toString().trim()) && objects[2].toString().trim().equals(objects1[2].toString().trim())){
		    					if(objects1[4].toString().trim().equals("1")){
	     		    			map1.put("rowId", objects1[2]);
	     		    			map1.put("itemName", objects1[1]);
	     		    			map1.put("isShownitemName", objects1[5]);
		    					}else{
		    						map1.put("quantity", objects1[1]);
		    						map1.put("isShownquantity", objects1[5]);
		    					}
		    				}
		    			}
		    			setRowIds.add(map1);
		    			map1 = null;
		    			for (Object[] objects12 : lst) {
		    				if(map.get("tableId").toString().trim().equals(objects12[1].toString().trim())){
		    					if(Integer.parseInt(objects12[3].toString()) > max){
			    				max = Integer.parseInt(objects12[3].toString());
		    					}
		    				}
		    			}
		    		}
		    	}
		    	Map<String, Object> map1 = new HashMap<String, Object>();
		    	map1.put("maxRound", max);
		    	map1.put("tableId", map.get("tableId"));
		    	map1.put("rowIds", setRowIds);
		    	Set<Map<String, Object>> list = new HashSet<Map<String,Object>>();
		    	for (Map<String, Object> map2 : setRowIds) {
		    		Map<String, Object> map3 = new HashMap<String, Object>();
		    		map3.put("rowId", map2.get("rowId"));
		    		Set<Map<String, Object>> list2 = new HashSet<Map<String,Object>>();
		    		for (Object[] objects : lstAllData) {
		    			Map<String, Object> map4 = new HashMap<String, Object>();
		    			if(map.get("tableId").toString().trim().equals(objects[1].toString().trim()) && objects[2].toString().trim().equals(map2.get("rowId").toString().trim())){
		    				map4.put("companyId", objects[3]);
		    				map4.put("companyName", objects[4]);
		    				//map4.put("isWinner", objects[7]);
		    			list2.add(map4);
		    			map4 = null;
		    			}
		    		}
		    		map3.put("companyList", list2);
		    		list2 = null;
		    		list.add(map3);
		    		map3 = null;
				}
		    	map1.put("companyIds", list);
		    	Set<Map<String, Object>> set2 = new HashSet<Map<String,Object>>();
		    	for (Map<String, Object> map4 : list) {
	    			for (Map<String, Object> sets : (Set<Map<String, Object>>)map4.get("companyList")) {
	    				Map<String, Object> map2 = new HashMap<String, Object>();
	    				map2.put("rowId", map4.get("rowId"));
	    				map2.put("companyId", sets.get("companyId"));
	    				for (Object[] objects : lst) {
	    					if(map4.get("rowId").toString().trim().equals(objects[2].toString().trim()) && sets.get("companyId").toString().trim().equals(objects[4].toString().trim())){
	    						map2.put("endDate", objects[6]);
	    					}
	    				}
	    				set2.add(map2);
	    				map2 = null;
	    			}
				}
		    	map1.put("endDates", set2);
		    	set2 = new HashSet<Map<String,Object>>();
		    	for (Map<String, Object> map4 : list) {
	    			for (Map<String, Object> sets : (Set<Map<String, Object>>)map4.get("companyList")) {
	    				Map<String, Object> map2 = new HashMap<String, Object>();
	    				map2.put("rowId", map4.get("rowId"));
	    				map2.put("companyId", sets.get("companyId"));
	    				for (Object[] objects : lst) {
	    					if(map4.get("rowId").toString().trim().equals(objects[2].toString().trim()) && sets.get("companyId").toString().trim().equals(objects[4].toString().trim())){
	    						map2.put("isRebateReq", objects[8]);
	    						map2.put("rebateValue", objects[9]);
	    					}
	    				}
	    				set2.add(map2);
	    				map2 = null;
	    			}
				}
		    	map1.put("rebate", set2);
		    	set2 = null;
		    	lstCompany.add(map1);
		    	map1 = null;
		    	list = null;
			}
		    modelMap.put("negotiatedRows",lst);
		    modelMap.put("lstFormList",lstTblForm);
		    modelMap.put("lstTableList",set);
		    modelMap.put("lstCompany",lstCompany);
		    modelMap.put("filledByBidder", this.getFilledByBidder(tenderId));
		    modelMap.put("negotiationBid", this.getNegotiationBid(tenderId));
		    modelMap.put("loadingColumns", this.getLoadingColumns(tenderId));
		    modelMap.put("lstAll", this.getTblNegotiationDetailByobjectIdAndCstatus(tenderId));
		   lst = null;
		   lst1 = null;
		   lstTblForm = null;
		   set = null;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
     /**
      * To get list of envelope
      *
      * @author janak dhanani
      * @return List {@code<Object[]>}
      * @throws Exception
      */
     public List<Object[]> getTenderEnvelopeListForWeightageScore(int tenderId, int isRequiredApproved) throws Exception {
         Map<String, Object> var = new HashMap<String, Object>();
         var.put(TENDER_ID, tenderId);
         StringBuilder query = new StringBuilder();
         query.append(" select tbltenderenvelope.envelopeId,  tbltenderenvelope.envelopeName, tbltenderenvelope.tblEnvelope.envId, ");
         query.append(" tbltenderenvelope.isOpened,tbltenderenvelope.isEvaluated,tbltenderenvelope.minOpeningMember,tbltenderenvelope.minEvaluator,tbltenderenvelope.tblEnvelope.envId, ");
         query.append(" CASE WHEN tbltenderenvelope.openingDate <= GETUTCDATE() AND tbltenderenvelope.cstatus = 1 THEN 1 ELSE 0 END, ");
         query.append(" tbltenderEnvelopeWeightage.scoringMarks, tbltenderEnvelopeWeightage.passingMarks, tbltenderEnvelopeWeightage.isconfigured ");
         query.append(" from TblTenderEnvelope tbltenderenvelope ");
         query.append(" left join tbltenderenvelope.tbltenderEnvelopeWeightage tbltenderEnvelopeWeightage ");
         query.append(" where tbltenderenvelope.tblTender.tenderId=:tenderId ");
         if(isRequiredApproved ==1)
        	 query.append(" and tbltenderenvelope.cstatus=1 ");
         else
        	 query.append(" and (tbltenderenvelope.cstatus = 0 or tbltenderenvelope.cstatus=1) ");
         query.append(" ORDER BY tbltenderenvelope.sortOrder ");
         return hibernateQueryDao.createNewQuery(query.toString(), var);
     }
     
     /**
 	 * 
 	 * @param updateEnvelopeWeightageScore
 	 * @param List TbltenderEnvelopeWeightage
 	 * @author janak
 	 * @return
 	 * @throws Exception
 	 */
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public boolean updateEnvelopeWeightageScore(List<TbltenderEnvelopeWeightage> tbltenderEnvelopeWeightageList) {
		 boolean bSuccess = false;
		 if(tbltenderEnvelopeWeightageList != null && !tbltenderEnvelopeWeightageList.isEmpty())
		 {
			 tbltenderEnvelopeWeightageDao.saveUpdateAllTbltenderEnvelopeWeightage(tbltenderEnvelopeWeightageList);
			 bSuccess = true;
		 }
		return bSuccess;
	}
    
   
	public TbltenderFormWeightage getFormWeightageScore(int formId, int envelopeId) throws Exception {
		List<TbltenderFormWeightage> list = tbltenderFormWeightageDao.findTbltenderFormWeightage("tblTenderForm.formId", Operation_enum.EQ, formId, "tblTenderEnvelope.envelopeId", Operation_enum.EQ, envelopeId);
		return (list != null && !list.isEmpty()) ? list.get(0) : null;
	}

	@Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public boolean updateFormWeightageMarks(List<TbltenderFormWeightage> tblTbltenderFormWeightageList) {
		 boolean bSuccess = false;
		 if(tblTbltenderFormWeightageList != null && !tblTbltenderFormWeightageList.isEmpty())
		 {
			 tbltenderFormWeightageDao.saveUpdateAllTbltenderFormWeightage(tblTbltenderFormWeightageList);
			 bSuccess = true;
		 }
		return bSuccess;
		
	}
    /**
 	 * 
 	 * @param Envelope Weightage Score By Envelope id
 	 * @param TbltenderEnvelopeWeightage
 	 * @author janak
 	 * @return
 	 * @throws Exception
 	 */
	public TbltenderEnvelopeWeightage getEnvelopeWeightageScoreByEnvelope(int envelopeId) throws Exception {
		List<TbltenderEnvelopeWeightage> list = tbltenderEnvelopeWeightageDao.findTbltenderEnvelopeWeightage("tblTenderEnvelope.envelopeId", Operation_enum.EQ, envelopeId);
    	return (list != null && !list.isEmpty()) ? list.get(0) : null;
	}

	public List<Object[]> getApprovedFormListForBidderWeightageEvaluation(int tenderId,
			int envelopeId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        StringBuilder query = new StringBuilder();
        query.append(" select tbltenderform.formId, tbltenderform.formName, tbltenderFormWeightage.formMarks  ");
        query.append(" from TblTenderForm tbltenderform ");
        query.append(" inner join tbltenderform.tblTenderEnvelope tbltenderenvelope ");
        query.append(" inner join tbltenderform.tbltenderFormWeightage tbltenderFormWeightage ");
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderenvelope.envelopeId=:envelopeId and tbltenderform.cstatus = 1");
        query.append(" order by tbltenderform.sortOrder ");
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return (list != null && !list.isEmpty()) ? list :null;
	}
	
	/**
 	 * 
 	 * @param updateEnvelopeWeightageScore
 	 * @param List TbltenderEnvelopeWeightage
 	 * @author janak
 	 * @return
 	 * @throws Exception
 	 */
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public boolean insertBidderweightageScore(List<TblBidderweightageScore> tblBidderweightageScoreList) {
		 boolean bSuccess = false;
		 if(tblBidderweightageScoreList != null && !tblBidderweightageScoreList.isEmpty())
		 {
			 tblBidderweightageScoreDao.saveUpdateAllTblBidderweightageScore(tblBidderweightageScoreList);
			 bSuccess = true;
		 }
		return bSuccess;
	}
    /**
     * Delete From
     * 
     * @author purvesh
     * @param tenderId
     * @param formId
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean deleteBidderweightageScore(int tenderId,int envelopeId, int userId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        if(userId != 0){
        	var.put("userId",userId);
        	cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblBidderweightageScore tblBidderweightageScore where tblBidderweightageScore.tblTender.tenderId=:tenderId and tblBidderweightageScore.tblTenderEnvelope.envelopeId=:envelopeId and tblBidderweightageScore.tblUserLogin.userId =:userId",var);
        }else{
        	cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblBidderweightageScore tblBidderweightageScore where tblBidderweightageScore.tblTender.tenderId=:tenderId and tblBidderweightageScore.tblTenderEnvelope.envelopeId=:envelopeId",var);
        }        
        return cnt!=0;

    }
    
    public List<TblBidderweightageScore> getBidderweightageScore(int tenderId,int envelopeId) throws Exception {
		List<TblBidderweightageScore> list = tblBidderweightageScoreDao.findTblBidderweightageScore("tblTender.tenderId", Operation_enum.EQ, tenderId,"tblTenderEnvelope.envelopeId", Operation_enum.EQ, envelopeId);
    	return (list != null && !list.isEmpty()) ? list : null;
	}
    public List<TblBidderweightageScore> getBidderweightageScore(int tenderId,int envelopeId,int officerId) throws Exception {
		List<TblBidderweightageScore> list = tblBidderweightageScoreDao.findTblBidderweightageScore("tblTender.tenderId", Operation_enum.EQ, tenderId,"tblTenderEnvelope.envelopeId", Operation_enum.EQ, envelopeId,"tblUserLogin.userId",Operation_enum.EQ,officerId);
    	return (list != null && !list.isEmpty()) ? list : null;
	}
    
    public boolean getBidderweightageScoreCount(int tenderId,int envelopeId,int officerId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("envelopeId", envelopeId);
        if(officerId!=0)
        	var.put("officerId", officerId);
        StringBuilder whereClause = new StringBuilder("tblBidderweightageScore.tblTender.tenderId=:tenderId and tblBidderweightageScore.tblTenderEnvelope.envelopeId=:envelopeId and tblBidderweightageScore.CStatus = 1");
        if(officerId!=0)
        	whereClause.append(" AND tblBidderweightageScore.tblUserLogin.userId=:officerId");
        count = hibernateQueryDao.countForNewQuery("TblBidderweightageScore tblBidderweightageScore ", "tblBidderweightageScore.bidweightageID ", whereClause.toString(), var);
        if(count!=0){
        	return true;
	    }
	    return false;
    }
    
    public List<Object[]> getBidderBiddedFormList(int tenderId,	int envelopeId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        if(envelopeId != 0){
        	var.put("envelopeId",envelopeId);
        }
        StringBuilder query = new StringBuilder();
        query.append(" select  distinct tblItemSelection.tblUserLogin.userId ,tblItemSelection.tblTenderForm.formId, tblItemSelection.isBidded,tblItemSelection.tblTenderEnvelope.envelopeId ");
        query.append(" from TblItemSelection tblItemSelection ");
        query.append(" where tblItemSelection.tblTender.tenderId=:tenderId and tblItemSelection.isBidded =1 and tblItemSelection.tblTenderForm.cstatus=1");
        if (envelopeId != 0) {
        	query.append(" and tblItemSelection.tblTenderEnvelope.envelopeId =:envelopeId ");
		}
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return (list != null && !list.isEmpty()) ? list :null;
	}

	public List<Object[]> getTenderFormListForWeightageScore(int tenderId,List<Integer> envelopeIdsList,int isRequiredApproved) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeIds",envelopeIdsList);
        StringBuilder query = new StringBuilder();
        query.append(" select tbltenderform.formId, tbltenderform.formName, tbltenderenvelope.envelopeId, tbltenderFormWeightage.formMarks,tbltenderform.isMandatory ");
        query.append(" from TblTenderForm tbltenderform ");
        query.append(" left join tbltenderform.tblTenderEnvelope tbltenderenvelope ");
        query.append(" left join tbltenderform.tbltenderFormWeightage tbltenderFormWeightage ");
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tbltenderenvelope.envelopeId in (:envelopeIds) and ");
        if(isRequiredApproved==1){
        	query.append(" tbltenderform.cstatus = 1 ");
        }else{
        	query.append(" (tbltenderform.cstatus = 0 or tbltenderform.cstatus = 1) ");
        }
        query.append(" order by tbltenderform.sortOrder ");
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return (list != null && !list.isEmpty()) ? list :null;
	}

	 /**
	  * view bidder weightage score 
	  * @author priyanka
	  *  @param tenderId
	  * @param envelopeIdsList
	  *  @param bidderId
	 * @param userRoleId 
	  * @param request
	  * @param redirectAttributes
	  * @return
	  * used to view bidder weightage score
	  */
	public List<Object[]> getTenderBidderListForWeightageScore(int tenderId,List<Integer> envelopeIdsList,int bidderId, int userRoleId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("bidderId",bidderId);
        var.put("userRoleId",userRoleId);
        StringBuilder query = new StringBuilder();  
        query.append(" select  tbltenderenvelope.envelopeName,tbltenderform.formName,tblbidderweightagescore.tblTenderEnvelope.envelopeId,tbltenderformweightage.tblTenderForm.formId,tblbidderweightagescore.bidderMarks,tbltenderenvelopeweightage.scoringMarks,tbltenderenvelopeweightage.passingMarks  ");
        query.append(" from TblBidderweightageScore tblbidderweightagescore");
        query.append(" inner join  tblbidderweightagescore.tblTenderEnvelope tbltenderenvelope");
        query.append(" inner join tbltenderenvelope.tbltenderEnvelopeWeightage tbltenderenvelopeweightage");
        query.append(" inner join tblbidderweightagescore.tblTenderForm tbltenderform ");       
        query.append(" inner join tbltenderform.tbltenderFormWeightage tbltenderformweightage");
        query.append(" where tbltenderform.tblTender.tenderId=:tenderId and tblbidderweightagescore.bidderId=:bidderId and tblbidderweightagescore.userRoleId =:userRoleId "); 
        query.append(" and tblbidderweightagescore.tblTenderEnvelope.envelopeId in (select tblbidderapprovaldetail.tblTenderEnvelope.envelopeId from TblBidderApprovalDetail tblbidderapprovaldetail where tbltenderenvelopeweightage.tblTenderEnvelope.envelopeId = tblbidderapprovaldetail.tblTenderEnvelope.envelopeId) ");
        query.append(" order by tbltenderenvelope.envelopeId, tbltenderform.formId");
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);     
        return (list != null && !list.isEmpty()) ? list :null;
	}
	
	public List<Object[]> getWeightageTotalMarksForAllForm(int tenderId,List<Integer> envelopeIdsList) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeIds",envelopeIdsList);
        StringBuilder query = new StringBuilder();
        query.append("select tbltenderenvelope.envelopeId, SUM(isnull(tbltenderFormWeightage.formMarks,0)) ");
        query.append("from TblTenderForm tbltenderform ");
        query.append("left join tbltenderform.tblTenderEnvelope tbltenderenvelope ");
        query.append("left join tbltenderform.tbltenderFormWeightage tbltenderFormWeightage ");
        query.append("where tbltenderform.tblTender.tenderId=:tenderId and tbltenderenvelope.envelopeId in (:envelopeIds) and tbltenderform.cstatus = 1 ");
        query.append("group by tbltenderenvelope.envelopeId ");
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(), var);
        return (list != null && !list.isEmpty()) ? list :null;
	}
	
	public Map<Integer, Boolean> getBidderWeightageEvaluationApproveDetail(int tenderId, int envelopeId, ArrayList<String> bidderIdList,int officerId) throws Exception {
		
		TbltenderEnvelopeWeightage tbltenderEnvelopeWeightage = getEnvelopeWeightageScoreByEnvelope(envelopeId);
		Map<Integer, Boolean> bidderEvaluation = new HashMap<Integer, Boolean>();
		if(tbltenderEnvelopeWeightage != null )
		{
			BigDecimal scoringMarks = tbltenderEnvelopeWeightage.getScoringMarks();
			BigDecimal passingMarks = tbltenderEnvelopeWeightage.getPassingMarks();
			
			Set<Integer> bidderIdsSet = new HashSet<Integer>();
			
			for (String bidderIdStr : bidderIdList) {
				bidderIdsSet.add(Integer.parseInt(bidderIdStr));
			}
			List<Object[]> bidderTotMarks = getBidderTotalWeightageScoreByBidderIds(tenderId,envelopeId,bidderIdsSet,officerId);
			if(bidderTotMarks != null && !bidderTotMarks.isEmpty())
			{
				for (Object[] bidderMarks : bidderTotMarks) {
					BigDecimal bMark = new BigDecimal(bidderMarks[1].toString());
					BigDecimal bPer  = (bMark.multiply(scoringMarks)).divide(new BigDecimal(100));
					int res = bPer.compareTo(passingMarks);
					bidderEvaluation.put(Integer.parseInt(bidderMarks[0].toString()), res == -1  ? false : true);
				}
			}
		}
		
		return bidderEvaluation;
	}

	private List<Object[]> getBidderTotalWeightageScoreByBidderIds(int tenderId, int envelopeId, Set<Integer> bidderIdsSet,int officerId) {
		Map<String, Object> var = new HashMap<String, Object>();
	    var.put("tenderId",tenderId);
	    var.put("envelopeId",envelopeId);
	    if(bidderIdsSet != null && ! bidderIdsSet.isEmpty())
	   	 	var.put("bidderIdsSet", bidderIdsSet);
	    if(officerId!=0)
	    	var.put("officerId",officerId);
	    StringBuilder query = new StringBuilder();
	    query.append(" select tbws.bidderId, ISNULL(SUM(bidderMarks), 0)  ");
	    query.append(" from apptenderresult.tbl_BidderweightageScore tbws  ");
	    query.append(" left join apptender.tbl_TenderForm tf on tbws.formId=tf.formId  ");
	    query.append(" where tbws.tenderId=:tenderId and tbws.envelopeId=:envelopeId and tbws.bidderId in (:bidderIdsSet) ");
	    query.append(" and tbws.cStatus=1 and tf.cstatus=1 ");
	    if(officerId!=0)
	    	query.append(" and tbws.officerId=:officerId");
	    query.append(" group by tbws.bidderId ");
	    return hibernateQueryDao.createSQLQuery(query.toString(), var);
	}
	
	public boolean getBidderWeightageScoreOfApprovedBidderId(int tenderId, int envelopeId, int previousEnvelopeId) {
		Map<String, Object> var = new HashMap<String, Object>();
	    var.put("tenderId",tenderId);
	    var.put("envelopeId",envelopeId);
	    var.put("previousEnvelopeId",previousEnvelopeId);
	    
	    StringBuilder query = new StringBuilder();
	    query.append(" select bad.bidderApprovalId from apptenderresult.tbl_BidderApprovalDetail bad ");
	    query.append(" inner join apptenderbid.tbl_FinalSubmission  tblFinalSubmission on bad.finalSubmissionId = tblFinalSubmission.finalSubmissionId and tblFinalSubmission.partnerType in (0,1,2) " );
	    query.append(" left join apptenderresult.tbl_BidderweightageScore bws on bad.tenderId = bws.tenderId and bad.bidderId = bws.bidderId  ");
	    query.append(" and bws.envelopeId  = :envelopeId  ");
	    query.append(" inner join  apptender.tbl_TenderForm tf on tf.envelopeId = bad.envelopeId and tf.cstatus = 1   ");
	    query.append(" where bad.tenderId = :tenderId and bad.envelopeId = :previousEnvelopeId and bad.isApproved = 1 and bidweightageID is null ");
	    List<Object[]> list =  hibernateQueryDao.createSQLQuery(query.toString(), var);
	    return (list != null && !list.isEmpty()) ? true :false;
	}
	
	public boolean isEvaluationStartedForWeightageEvaluation(int tenderId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        count = hibernateQueryDao.countForNewQuery("TblBidderweightageScore tblBidderweightageScore", "tblBidderweightageScore.bidweightageID ", "tblBidderweightageScore.tblTender.tenderId=:tenderId and tblBidderweightageScore.CStatus = 1 ", var);
        if(count!=0){
        	return true;
	    }
	    return false;
    }
	
	public boolean getWeightageEvaluationForReConfig(int tenderId) throws Exception {
        int count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append("select TFW.tenderFormWeightageId from apptender.tbl_tenderFormweightage TFW Left join apptender.tbl_tenderEnvelope TE on TE.envelopeId = TFW.envelopeId where TE.tenderId = :tenderId and TE.cStatus = 1 ");
        List<Object[]> list = hibernateQueryDao.createSQLQuery(query.toString(), var);
        if(list!=null && !list.isEmpty()){
            count = list.size();
        }
        if(count!=0){
        	return true;
	    }
	    return false;
    }
	
	/**
     * is Weightage Evaluation And Evaluation Started by checking entry in bidder approval Detail table
     * 
     * @author janak
     * @param tenderId
     * @return
     * @throws Exception 
     */
	public boolean isWeightageEvaluationAndEvaluationStarted(int tenderId) throws Exception {
        long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        count = hibernateQueryDao.countForNewQuery("TblBidderApprovalDetail tblBidderApprovalDetail", "tblBidderApprovalDetail.bidderApprovalId ", "tblBidderApprovalDetail.tblTender.tenderId=:tenderId", var);
        if(count!=0){
        	return true;
	    }
	    return false;
    }

   	/**
   	 * get pending TblTenderEnvelope
   	 * @author dipika
   	 */
   	public boolean getTenderEnvelopeByOpeningDateStatus(int tenderId,int openingDateStatus) throws Exception {
           long count = 0;
           Map<String, Object> var = new HashMap<String, Object>();
           var.put("openingDateStatus", openingDateStatus);
           var.put("tenderId", tenderId);
           count = hibernateQueryDao.countForNewQuery("TblTenderEnvelope tblTenderEnvelope INNER JOIN tblTenderEnvelope.tblTenderForm ", "tblTenderEnvelope.envelopeId ", "tblTenderEnvelope.tblTender.tenderId=:tenderId and tblTenderEnvelope.openingDateStatus=:openingDateStatus", var);
           if(count!=0){
           	return true;
   	    }
   	    return false;
    }


/**
 * @author Vivek
 * @param tenderId
 * @return
 * @throws Exception 
 */
public void deleteMapBidderEntryForItemWiseCase(int tenderId){
	
	List<Object> tableList=getTableDtlsFromCancelledFormForItemWiseCase(tenderId);
	Map<String, Object> var = new HashMap<String, Object>();

	if(tableList != null && !tableList.isEmpty()){
			    var.put(TENDER_ID, tenderId);        
			    var.put(TABLEID,tableList.toArray());
			    StringBuilder query = new StringBuilder();
			    query.append("select tbltenderbiddermap.mapBidderId from TblTenderBidderMap tbltenderbiddermap left join tbltenderbiddermap.tblItemBidderMap tblitembiddermap ");
			    query.append("with tblitembiddermap.tblTenderTable.tableId not in (:tableId) where tbltenderbiddermap.tblTender.tenderId=:tenderId and tblitembiddermap.mapBidderItemId is NULL");
			    List<Object> mappedBidder = hibernateQueryDao.singleColQuery(query.toString(), var);
			    var.clear();
			   
			   if(!mappedBidder.isEmpty()){
				   Map<String, Object> tenderData = new HashMap<String, Object>();
				   tenderData.put(TENDER_ID,tenderId);
				   List<Object> bidderMapping= hibernateQueryDao.singleColQuery("select bidderMapping from TblTender where tenderId=:tenderId", tenderData);
				   if(bidderMapping.get(0).equals(1)) {
				    	var.put("mapBidderId",mappedBidder.toArray());
				    	var.put(TABLEID,tableList.toArray());
				    	hibernateQueryDao.updateDeleteNewQuery("delete  from TblItemBidderMap tblitembiddermap where tblitembiddermap.mapBidderItemId in (select tblitembiddermap.mapBidderItemId from TblTenderBidderMap tbltenderbiddermap inner join tbltenderbiddermap.tblItemBidderMap tblitembiddermap where tbltenderbiddermap.mapBidderId in (:mapBidderId) and tblitembiddermap.tblTenderTable.tableId in (:tableId)) ",var);
				    	var.clear();
				    	var.put("mapBidderId",mappedBidder.toArray());
				    	hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderBidderMap tbltenderBidderMap where tbltenderBidderMap.mapBidderId in (:mapBidderId) ",var);
				    	var.clear();
				    	var.put(TABLEID,tableList.toArray()); 
				    	hibernateQueryDao.updateDeleteNewQuery("update TblTenderMapBidderHistory tblTenderMapBidderHistory set isMapped=0 where tableId in (:tableId)",var);
				    	var.clear();
//				    	var.put("mapBidderId", mappedBidder.toArray());
//				    	hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderBidderMap tbltenderbiddermap where tbltenderbiddermap.mapBidderId in (:mapBidderId)", var);
				   }
			    }
			 }
}


/**
 * @author Vivek
 * @param tenderId
 * @return
 * @throws Exception 
 */
public List<Object> getTableDtlsFromCancelledFormForItemWiseCase(int tenderId)
{
	/*tbl_Tender.tenderResult 0 for Not Set, 1 for Grand Total, 2 for Itemwise,3 for Lotwise*/
	/*tbl_TenderForm.cstatus 0 for Pending, 1 for Approved, 2 for Cancelled*/
	/*tbl_Tender.tenderMode 0 for Not Set, 1 for Open, 2 for Limited, 3 for Proprietary, 4 for Nomination*/
	Map<String, Object> var = new HashMap<String, Object>();
    var.put("tenderId", tenderId);
    StringBuilder query = new StringBuilder();
    query.append(" select tblTenderTable.tableId from TblTenderTable tblTenderTable inner join tblTenderTable.tblTenderForm tblTenderForm inner join tblTenderForm.tblTender tbl_Tender");
    query.append(" where tblTenderForm.cstatus=2 and tbl_Tender.tenderId =:tenderId and tbl_Tender.tenderResult=2 and tbl_Tender.tenderMode in (2,3,4) ");
    List<Object> list=hibernateQueryDao.singleColQuery(query.toString(), var);
	return (list != null && !list.isEmpty()) ? list :null;
}
           /**
            * @Foram
            */
           public List<Object[]> getUserRoleId(int tenderId,int envlopeId,int committeeType,int officerId){
      	        List<Object[]> list = null;
       	        Map<String, Object> var = new HashMap<String, Object>();        
       	        var.put("tenderId",tenderId);
       	        var.put("childId",envlopeId);
       	        var.put("committeeType",committeeType);
       	        if(officerId!=0){
       	        	var.put("officerId",officerId);
       	        }
       	        StringBuilder query = new StringBuilder();
       	        	   query.append("SELECT tblCommitteeUser.userRoleId,tblCommitteeUser.encryptionLevel,tblCommitteeUser.tblUserLogin.userId,tblCommitteeUser.isDecryptor");
       	        	   query.append(" FROM TblCommittee tblCommittee");
                       query.append(" INNER JOIN tblCommittee.tblCommitteeUser tblCommitteeUser");
                       query.append(" WHERE tblCommittee.tblTender.tenderId =:tenderId");
                       query.append(" AND tblCommittee.isActive = 1 AND tblCommittee.committeeType=:committeeType");
                       query.append(" AND tblCommitteeUser.childId=:childId");
                       if(officerId!=0){
                    	   query.append(" AND tblCommitteeUser.tblUserLogin.userId=:officerId");
                       }else{
                    	   query.append(" ORDER BY tblCommitteeUser.userRoleId DESC");
                       }
                       
       	        list = hibernateQueryDao.createNewQuery(query.toString(), var);
       	        return list;
       	    }
       /**
        * @Foram
        */
       public List<Object[]> getApprovalBidderByEnvelope(int tenderId,int envlopeId,int isConsortiumAllowed) throws Exception{
           StringBuilder query = new StringBuilder();
       		query.append(" SELECT ");
       		if(isConsortiumAllowed == 1)
       			query.append(" A.companyName as c0, ");
       		else 
       			query.append(" UD.companyName as c0, ");
	        query.append(" tblFinalSubmission.bidderId as c1,tblFinalSubmission.companyId as c2, tblTenderEnvelope.envelopeId as c3,"); 
	        query.append(" tblFinalSubmission.consortiumId as c4,tblBidderApprovalDetail.isApproved as c5,tblTenderBidConfirmation.encodedName as c6, tblFinalSubmission.partnerType as c7");
	        query.append(" ,(case when (tblTenderEnvelope.sortOrder) > 1 then (select b.isApproved from apptenderresult.tbl_BidderApprovalDetail b where b.companyId=tblFinalSubmission.companyId");
	        query.append(" and  b.envelopeId in (select c.envelopeId from apptender.tbl_TenderEnvelope c where c.tenderId=tblFinalSubmission.tenderId and c.sortOrder=tblTenderEnvelope.sortOrder-1)) Else -1 End) as c8,");
	        query.append(" (SELECT COUNT(tblTenderForm.formId) FROM apptenderbid.Tbl_TenderBid tblTenderBid ");
	        query.append(" INNER JOIN apptender.tbl_TenderForm tblTenderForm  on  tblTenderForm.formId = tbltenderbid.formId ");
	        query.append("  WHERE tblTenderForm.tenderId=").append(tenderId).append(" AND tblTenderForm.cstatus = 1 AND tblTenderForm.envelopeId=tblTenderEnvelope.envelopeId "); 
	        query.append("  AND tblTenderBid.bidderId=tblFinalSubmission.bidderId) as c9  ");
	        query.append(" FROM apptenderbid.tbl_FinalSubmission tblFinalSubmission");
	        query.append(" INNER JOIN apptender.tbl_TenderEnvelope tblTenderEnvelope on tblTenderEnvelope.tenderId = tblFinalSubmission.tenderId");
	        query.append(" INNER JOIN apptenderbid.tbl_TenderBidConfirmation tblTenderBidConfirmation ON tblTenderBidConfirmation.tenderId = tblFinalSubmission.tenderId");
	        query.append(" AND tblTenderBidConfirmation.companyId=tblFinalSubmission.companyId");
	        query.append(" LEFT JOIN apptenderresult.tbl_BidderApprovalDetail tblBidderApprovalDetail on tblBidderApprovalDetail.tenderId = tblFinalSubmission.tenderId");
	        query.append(" AND tblTenderEnvelope.envelopeId=tblBidderApprovalDetail.envelopeId");
	        query.append(" AND tblFinalSubmission.bidderId=tblBidderApprovalDetail.bidderId");
	        if(isConsortiumAllowed == 1){
	        	query.append(" CROSS APPLY ( ");
	     		query.append("	SELECT ' ' + UD.companyName +  CASE FS1.partnerType WHEN 2 THEN ' in consortium with  ' ELSE ',' END ");
	     		query.append(" FROM apptenderbid.tbl_FinalSubmission FS1 ");
	     		query.append(" INNER JOIN appuser.tbl_UserDetail UD ON FS1.userDetailId = UD.userDetailId ");
	     		query.append(" WHERE tblFinalSubmission.consortiumId = FS1.consortiumId ");
	     		query.append(" ORDER BY FS1.partnerType, FS1.createdOn ");
	     		query.append(" FOR XML PATH('') ");
	     		query.append(" ) A (companyName) ");
	        }else{
	        	query.append(" INNER JOIN appuser.tbl_UserDetail UD ON tblFinalSubmission.userDetailId = UD.userDetailId");
	        }
	        query.append(" WHERE tblFinalSubmission.tenderId =").append(tenderId).append(" AND tblFinalSubmission.isActive=1 AND tblTenderEnvelope.envelopeId =").append(envlopeId);
	        if(isConsortiumAllowed == 1)
    	    	query.append("  AND tblFinalSubmission.partnerType in (1,2) ");
	        else
	        	query.append("  ORDER BY tblTenderEnvelope.envelopeId,tblFinalSubmission.consortiumId,tblFinalSubmission.partnerType");
           int nVarCharColumnIndex [] = {0,6};
           List<Object[]> list = hibernateQueryDao.createSQLQuery(query.toString(),null,nVarCharColumnIndex,10);
           return list!=null && !list.isEmpty() ? list : null;
       }
       /**
        * author Foram
        * used to get remarks for View
        */
       public List<Object[]> getRemarks(int tenderId,int officerId,int committeeType,int envelopeId,int userRoleId,int isCPRemarks,int otherRoleId){
	        List<Object[]> list = null;
	        List<Integer> userRoleIds = new ArrayList<Integer>();
	        Map<String, Object> var = new HashMap<String, Object>();        
	        var.put("tenderId",tenderId);
	        if(officerId!=0){
	        	var.put("officerId",officerId);
	        }else{
	        	userRoleIds.add(userRoleId);
	        	if(otherRoleId != -1)
	        		userRoleIds.add(otherRoleId);
	        	var.put("userRoleId",userRoleIds);
	        }
	        var.put("committeeType",committeeType);
	        var.put("envelopeId",envelopeId);
	        if(isCPRemarks!=-1){
	        	var.put("isCPRemarks",isCPRemarks);
	        }
	        
	        StringBuilder query = new StringBuilder();
	        	if(officerId!=0){
		           query.append("SELECT tblCommitteeRemarks.bidderId,tblCommitteeRemarks.remarks");
		        }else{
		        	query.append(" SELECT distinct(tblCommitteeRemarks.tblUserLogin.userId),tblCommitteeRemarks.userRoleId");
		        }
	           query.append(" FROM TblCommitteeRemarks tblCommitteeRemarks");
               query.append(" WHERE tblCommitteeRemarks.tblTender.tenderId=:tenderId and tblCommitteeRemarks.isActive=1");
               if(officerId!=0){
             	  query.append(" AND tblCommitteeRemarks.tblUserLogin.userId=:officerId ");
               }
               query.append(" AND tblCommitteeRemarks.committeeType=:committeeType");
               query.append(" AND tblCommitteeRemarks.tblTenderEnvelope.envelopeId=:envelopeId");
               if(officerId==0){
             	  query.append(" AND tblCommitteeRemarks.userRoleId in (:userRoleId)");
               }
               if(isCPRemarks!=-1){
            	   query.append(" AND tblCommitteeRemarks.isCPRemarks=:isCPRemarks");
               }
	        list = hibernateQueryDao.createNewQuery(query.toString(), var);
	        return list;
	    }
       /**
        * author Foram
        * @param committeeremarks
        * @return
        * @throws Exception
        */
       public boolean addRemarksDetails(List<TblCommitteeRemarks> committeeremarks) throws Exception {
           boolean bSuccess = false;
           tblCommitteeRemarksDao.saveUpdateAllTblCommitteeRemarks(committeeremarks);
           bSuccess = true;
           return bSuccess;
       }
       public boolean addRemarksDetails(TblCommitteeRemarks committeeremarks) throws Exception {
           boolean bSuccess = false;
           tblCommitteeRemarksDao.saveOrUpdateTblCommitteeRemarks(committeeremarks);
           bSuccess = true;
           return bSuccess;
       }
       /**
        * Used to count member count as per enc level wise
        * @author Lipi Shah
        * @throws Exception
        */
       public int getCommCountMemLevelWise(int tenderId,int envelopeId,int committeeType,int userRoleId,int encryptionLevel,int isDecryptor){
 	        List<Object[]> list = null;
   	        Map<String, Object> var = new HashMap<String, Object>();        
   	        var.put("tenderId",tenderId);
   	        var.put("envelopeId",envelopeId);
   	        var.put("committeeType",committeeType);
   	        var.put("userRoleId",userRoleId);
   	        if(committeeType==2 && isDecryptor!=1){
   	        	var.put("encryptionLevel",encryptionLevel);
   	        }
   	        StringBuilder query = new StringBuilder();
   	        	   query.append("SELECT distinct(tblCommitteeUser.tblUserLogin.userId),tblCommitteeUser.tblUserDetail.userDetailId");
   	        	   query.append(" FROM TblCommittee tblCommittee");
                   query.append(" INNER JOIN tblCommittee.tblCommitteeUser tblCommitteeUser");
                   query.append(" WHERE tblCommittee.tblTender.tenderId =:tenderId");
                   query.append(" AND tblCommittee.isActive = 1 AND tblCommittee.committeeType=:committeeType");
                   query.append(" AND tblCommitteeUser.childId=:envelopeId AND tblCommitteeUser.userRoleId=:userRoleId");
                   if(committeeType==2 && isDecryptor!=1){
                	   query.append(" AND tblCommitteeUser.encryptionLevel=:encryptionLevel");
                   }
   	        list = hibernateQueryDao.createNewQuery(query.toString(), var);
   	        return list!=null && !list.isEmpty() ? list.size() : 0;
   	    }     
       /**
        * Used to count member count as per enc level wise
        * @author Lipi Shah
        * @throws Exception
        */
       public List<Object[]> getIncrementOfficerRem(int tenderId,int envelopeId,int committeeType,int officerId){
   	        Map<String, Object> var = new HashMap<String, Object>();        
   	        var.put("tenderId",tenderId);
   	        var.put("envelopeId",envelopeId);
   	        var.put("committeeType",committeeType);
   	        if(officerId!=0){
   	        	var.put("officerId",officerId);
   	        }
   	        StringBuilder query = new StringBuilder();
        		query.append("SELECT tblCommitteeRemarks.tblUserLogin.userId,tblCommitteeRemarks.bidderId,tblCommitteeRemarks.tblCompany.companyId");
        		query.append(" ,tblCommitteeRemarks.remarks,tblUserDetail.userName");
        		query.append(" ,tblCommitteeRemarks.isApproved");
        		query.append(" FROM TblCommitteeRemarks tblCommitteeRemarks");
        		query.append(" INNER JOIN tblCommitteeRemarks.tblUserLogin tblUserLogin,TblUserDetail tblUserDetail ");
        		query.append(" WHERE tblCommitteeRemarks.tblTender.tenderId =:tenderId");
        		query.append(" AND tblCommitteeRemarks.isActive = 1 AND tblCommitteeRemarks.committeeType=:committeeType");
        		query.append(" AND tblCommitteeRemarks.tblTenderEnvelope.envelopeId=:envelopeId and tblUserDetail.userDetailId=tblCommitteeRemarks.createdBy ");
        		if(officerId!=0){
        			query.append(" AND tblCommitteeRemarks.tblUserLogin.userId!=:officerId");
        		}
   	        return hibernateQueryDao.createNewQuery(query.toString(), var);
   	    } 
       /*
        * author : Lipi Shah
        * used to get count for cp is give remarks or not from opening tab
        */
       public boolean getCountForCPRemarks(int tenderId,int envelopeId,int committeeType) throws Exception {
           Map<String, Object> var = new HashMap<String, Object>();
           var.put("tenderId",tenderId);
	        var.put("envelopeId",envelopeId);
	        var.put("committeeType",committeeType);
	        StringBuilder query = new StringBuilder();
	        query.append("tblCommitteeRemarks.tblTender.tenderId =:tenderId AND tblCommitteeRemarks.isActive = 1");
	        query.append(" AND tblCommitteeRemarks.tblTenderEnvelope.envelopeId=:envelopeId AND tblCommitteeRemarks.committeeType=:committeeType");
	        query.append(" AND tblCommitteeRemarks.isCPRemarks=1");
           long count = hibernateQueryDao.countForNewQuery("TblCommitteeRemarks tblCommitteeRemarks ","tblCommitteeRemarks.committeeRemarksId ",query.toString(),var);
           return count!=0;
       }
       /**
        * Used to count member count as per enc level wise
        * @author Lipi Shah
        * @throws Exception
        */
       public List<Object[]> getRemarksOfficer(int tenderId,int envelopeId,int committeeType,int officerId){
   	        Map<String, Object> var = new HashMap<String, Object>();        
   	        var.put("tenderId",tenderId);
   	        var.put("envelopeId",envelopeId);
   	        var.put("committeeType",committeeType);
   	        if(officerId!=0){
   	        	var.put("officerId",officerId);
   	        }
   	        StringBuilder query = new StringBuilder();
//        		query.append("SELECT distinct(tblCommitteeRemarks.tblUserLogin.userId),tblUserLogin.userName,tblCommitteeRemarks.userRoleId");
//        		query.append(" ,tblCommitteeUser.encryptionLevel,tblCommitteeRemarks.bidderId");
//        		query.append(" FROM TblCommitteeRemarks tblCommitteeRemarks,TblCommitteeUser tblCommitteeUser");
//        		query.append(" INNER JOIN tblCommitteeUser.tblCommittee tblCommittee");
//        		query.append(" INNER JOIN tblCommitteeRemarks.tblUserLogin tblUserLogin");
//        		query.append(" WHERE tblCommitteeRemarks.tblTender.tenderId =:tenderId");
//        		query.append(" AND tblCommitteeRemarks.isActive = 1 AND tblCommitteeRemarks.committeeType=:committeeType");
//        		query.append(" AND tblCommitteeRemarks.tblTenderEnvelope.envelopeId=:envelopeId");
//        		if(officerId!=0){
//        			query.append(" AND tblCommitteeRemarks.tblUserLogin.userId!=:officerId");
//        			query.append(" AND tblCommitteeUser.tblUserLogin.userId=:officerId");
//        		}
//        		query.append(" AND tblCommitteeUser.tblCommittee.committeeId=tblCommittee.committeeId AND tblCommitteeUser.childId=:envelopeId");
//        		query.append(" AND tblCommittee.tblTender.tenderId =:tenderId AND tblCommittee.isActive=1 AND tblCommittee.committeeType=:committeeType");
   	        
   	     query.append("SELECT distinct(tblCommitteeRemarks.officerid) as c0,tbl_UserDetail.userName as c1,tblCommitteeRemarks.userRoleId as c2");
   	     query.append(" ,tblCommitteeUser.encryptionLevel as c3,tblCommitteeRemarks.bidderId as c4");
   	     query.append(" FROM apptenderresult.Tbl_CommitteeRemarks tblCommitteeRemarks");
   	     query.append(" INNER JOIN appuser.Tbl_UserLogin tblUserLogin ON tblUserLogin.userId=tblCommitteeRemarks.officerid");
	     query.append(" INNER JOIN apptender.Tbl_Committee tblCommittee ON tblCommittee.tenderId = tblCommitteeRemarks.tenderId");
	     query.append(" INNER JOIN apptender.Tbl_CommitteeUser tblCommitteeUser ON tblCommitteeUser.committeeId=tblCommittee.committeeId");
	     query.append(" INNER JOIN appuser.tbl_UserDetail tbl_UserDetail ON tbl_UserDetail.userDetailId=tblCommitteeUser.userDetailId ");
	     query.append(" WHERE tblCommitteeRemarks.tenderId=:tenderId AND tblCommitteeRemarks.envelopeId=:envelopeId");
   	     query.append(" AND tblCommittee.isActive = 1 AND tblCommitteeRemarks.committeeType=:committeeType");
   	     query.append(" AND tblCommittee.committeeType=:committeeType");
   	     if(officerId!=0)
   	    	 query.append(" AND tblCommitteeRemarks.officerid!=:officerId");
   	     query.append(" AND tblCommitteeRemarks.officerid=tblCommitteeUser.officerid");
   	     
   	        return hibernateQueryDao.createSQLQuery(query.toString(), var,new int[]{1},5);
   	    }     
		
	public List<Object[]> ChkandgetItemWiseEvaluationData(int tenderId,int envelopeId, int sessionUserId, int bidderId) {
		Map<String, Object> var = new HashMap<String, Object>();        
       var.put("tenderId",tenderId);
       var.put("envelopeId",envelopeId);
       var.put("sessionUserId",sessionUserId);
       var.put("bidderId",bidderId);
       StringBuilder query = new StringBuilder();
       query.append("select tblBidderItems.bidderItemId,tblBidderItems.rowId,tblBidderItems.remarks,tblBidderItems.tblTenderForm.formId,ISNULL(tblBidderItems.tblTenderTable.tableId,0),tblBidderItems.isApproved from TblBidderItems tblBidderItems ");
       query.append("inner join tblBidderItems.tblTender tblTender ");
       query.append("inner join tblBidderItems.tblUserLogin tblUserLogin ");
       query.append("inner join tblBidderItems.tblTenderEnvelope tblTenderEnvelope ");
       query.append("where tblBidderItems.tblTender.tenderId =:tenderId and tblBidderItems.tblUserLogin.userId =:bidderId and tblBidderItems.createdBy =:sessionUserId and tblTenderEnvelope.envelopeId =:envelopeId ");
       List<Object[]> chkdata=hibernateQueryDao.createNewQuery(query.toString(), var);
       return chkdata;
	}
	 /**
    * @author keval.soni
    * @param tblBidderItems
    * @return
    * @throws Exception
    */
     @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
     public boolean saveAllTblBidderItemsWiseEvaluation(List<TblBidderItems> tblBidderItems) throws Exception{
         boolean bSuccess = false;
         tblBidderItemsDao.saveUpdateAllTblBidderItems(tblBidderItems);
         bSuccess = true;
         return bSuccess;
     }

     /**
      * @author keval.soni
      * @param tenderId
      * @param bidderId
      * @return finalSubmissionId
      * @throws Exception
      */
	public int getFinalSubmissionId(int tenderId, int bidderId) {
		Map<String, Object> var = new HashMap<String, Object>();        
       var.put("tenderId",tenderId);
       var.put("bidderId",bidderId);
       StringBuilder query = new StringBuilder();
       query.append("select tblFinalSubmission.finalSubmissionId from TblFinalSubmission tblFinalSubmission ");
       query.append("inner join tblFinalSubmission.tblTender tblTender ");
       query.append("inner join tblFinalSubmission.tblUserLogin tblUserLogin ");
       query.append("where tblTender.tenderId =:tenderId and tblUserLogin.userId =:bidderId and tblFinalSubmission.isActive=1 ");
       List<Object> chkdata=hibernateQueryDao.getSingleColQuery(query.toString(), var);
       return chkdata!=null && !chkdata.isEmpty() ? Integer.parseInt(chkdata.get(0).toString()) : 0;
	}

	public boolean addEachBidderAprvalDtls(List<TblBidderApprovalDetail> tblBidderApprovalDtls) {
		tblBidderApprovalDetailDao.saveUpdateAllTblBidderApprovalDetail(tblBidderApprovalDtls);
		return true;
	}
	/**
     * Get the Officer which put Remarks for bidder wise Evaluation
     * @author Keval.soni
     * @throws Exception
     */
	public List<Object[]> getIncrementBidderWiseOfficer(int tenderId,int envelopeId, int bidderId, int officerId) {
			Map<String, Object> var = new HashMap<String, Object>();        
	       var.put("tenderId",tenderId);
	       var.put("bidderId",bidderId);
	       var.put("envelopeId",envelopeId);
	       if(officerId!=0){
  	        	var.put("officerId",officerId);
  	        }
	       StringBuilder query = new StringBuilder();
	       query.append("select tblUserLogin.userId,tblUserLogin.userName from TblUserLogin tblUserLogin");
	       query.append(" where tblUserLogin.userId in (select tblBidderItems.createdBy from TblBidderItems tblBidderItems where ");
	       query.append("tblBidderItems.tblTender.tenderId =:tenderId and tblBidderItems.tblTenderEnvelope.envelopeId =:envelopeId and tblBidderItems.tblUserLogin.userId =:bidderId");
	       if(officerId!=0){
   				query.append(" AND tblBidderItems.createdBy!=:officerId");
   			}
	       query.append(") "); 
	       return hibernateQueryDao.createNewQuery(query.toString(), var);
	}

	/**
     * Get the Officer wise remarks for bidder wise Evaluation
     * @author Keval.soni
     * @throws Exception
     */
	public List<Object[]> getRemarksBidderWiseOfficer(int tenderId,int envelopeId, int bidderId,  int officerId) {
			Map<String, Object> var = new HashMap<String, Object>();        
	       var.put("tenderId",tenderId);
	       var.put("bidderId",bidderId);
	       var.put("envelopeId",envelopeId);
	       if(officerId!=0){
	        	var.put("officerId",officerId);
	        }
	       StringBuilder query = new StringBuilder();
	       query.append("select tblBidderItems.createdBy,tblBidderItems.tblTenderForm.formId,ISNULL(tblBidderItems.tblTenderTable.tableId,0),tblBidderItems.rowId,tblBidderItems.remarks,tblBidderItems.isApproved,tblBidderItems.userRoleId,tblUserLogin.userName,tblBidderItems.tblUserLogin.userId ");
	       query.append("from TblBidderItems tblBidderItems,TblUserLogin tblUserLogin where ");
	       query.append("tblBidderItems.tblTender.tenderId =:tenderId and tblBidderItems.tblTenderEnvelope.envelopeId =:envelopeId and tblBidderItems.tblUserLogin.userId =:bidderId");
	       query.append(" and tblUserLogin.userId=tblBidderItems.createdBy");
	       if(officerId!=0){
				query.append(" AND tblBidderItems.createdBy!=:officerId");
			}
	       query.append(") "); 
	       return hibernateQueryDao.createNewQuery(query.toString(), var);
	}

	/**
     * Get the BidderId if Remarks is there 
     * @author Keval.soni
     * @throws Exception
     */
	public List<Integer> getBiddersForShowLink(int tenderId, int envelopeId,int encryptionLevel, int officerId, int orgUserRoleId) {
			Map<String, Object> var = new HashMap<String, Object>();        
			var.put("tenderId",tenderId);
			var.put("envelopeId",envelopeId);
			if(officerId!=0){
	    	   var.put("officerId",officerId);
	        }
			var.put("orgUserRoleId",orgUserRoleId);
			StringBuilder query = new StringBuilder();
			query.append("select tblBidderItems.tblUserLogin.userId from TblBidderItems tblBidderItems ");
			query.append("where tblBidderItems.tblTender.tenderId =:tenderId and tblBidderItems.tblTenderEnvelope.envelopeId =:envelopeId ");
			query.append("and tblBidderItems.userRoleId =:orgUserRoleId ");
			if(officerId!=0){
	    	   query.append("and tblBidderItems.createdBy =:officerId ");
			}
			query.append("and tblBidderItems.isActive=1 group by tblBidderItems.tblUserLogin.userId ");
			List<Integer> bidder=(List<Integer>)(List<?>)hibernateQueryDao.getSingleColQuery(query.toString(), var);
			return bidder;
	}
	/**
     * Get the Technical Envlope Data
     * @author Keval.soni
	 * @param envelopeId
	 * @param bidderId
	 * @param createdBy
     * @throws Exception
     */
	public List<Object[]> getApprovalDetlsOfTechnicalEnvlop(int tenderId, int envelopeId,int bidderId,int createdBy) {
			Map<String, Object> var = new HashMap<String, Object>();
			List<Object> EnvlopeIds= new ArrayList<Object>();
			 StringBuilder query = new StringBuilder();
			 var.put("tenderId",tenderId);
			 if(envelopeId==0){
			 query.append("select tblTenderEnvelope.envelopeId from TblTenderEnvelope tblTenderEnvelope where tblTenderEnvelope.tblTender.tenderId =:tenderId and tblTenderEnvelope.openingDateStatus=1 and tblTenderEnvelope.tblEnvelope.envId not in(4,5) group by tblTenderEnvelope.envelopeId, ");
		     query.append("tblTenderEnvelope.tblEnvelope.envId having max(tblTenderEnvelope.tblEnvelope.envId)=tblTenderEnvelope.tblEnvelope.envId order by tblTenderEnvelope.tblEnvelope.envId desc"); 
		     EnvlopeIds = hibernateQueryDao.getSingleColQuery(query.toString(), var);
			     if(EnvlopeIds!=null && !EnvlopeIds.isEmpty()){
				     var.put("envelopeId",EnvlopeIds.get(0));
			     }
			 }else{
					 var.put("envelopeId",envelopeId);
			}
			query = new StringBuilder();
			if(bidderId!=0){
				var.put("bidderId",bidderId);
				var.put("createdBy",createdBy);
		     }
		     query.append("select tblBidderApprovalDetail.tblUserLogin.userId,tblBidderApprovalDetail.isApproved,tblBidderApprovalDetail.remarks,tblBidderApprovalDetail.createdBy,tblUserDetail.tblUserLogin.userId");
		     query.append(" from TblBidderApprovalDetail tblBidderApprovalDetail,TblUserDetail tblUserDetail");
		     query.append(" inner join tblBidderApprovalDetail.tblTenderEnvelope tblTenderEnvelope");		     
		     query.append(" where tblUserDetail.userDetailId = tblBidderApprovalDetail.createdBy and ");
		     if(bidderId!=0){
		    	 query.append("tblBidderApprovalDetail.tblUserLogin.userId =:bidderId and tblBidderApprovalDetail.createdBy =:createdBy and");
		     }
//		     query.append("tblBidderApprovalDetail.tblTenderEnvelope.envelopeId in (select tblTenderEnvelope.envelopeId from TblTenderEnvelope tblTenderEnvelope where tblTenderEnvelope.tblTender.tenderId =:tenderId ");
		     if(envelopeId==0){
		    	 if(EnvlopeIds!=null && !EnvlopeIds.isEmpty()){
		    		 query.append(" tblTenderEnvelope.envelopeId =:envelopeId and ");
		    	 }
		     }else{
		    	 query.append(" tblTenderEnvelope.envelopeId =:envelopeId and ");
		     }
//		     query.append("and tblTenderEnvelope.cstatus =1)");
		     query.append(" tblTenderEnvelope.tblTender.tenderId =:tenderId and tblTenderEnvelope.cstatus =1"); 
		     return hibernateQueryDao.createNewQuery(query.toString(), var);
	}
	 /** This service method is used for to isOnlyOneEnvlop in particular Tender.
     * @auther Keval Soni
     * @param tenderId
     * @return
     * @throws Exception 
     */
	public boolean isOnlyOneEnvelopBuTenderId(int tenderId) throws Exception {
		 long count = 0;
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put("tenderId", tenderId);
	        count = hibernateQueryDao.countForNewQuery("TblTenderEnvelope tblTenderEnvelope ", "tblTenderEnvelope.envelopeId ", "tblTenderEnvelope.tblTender.tenderId=:tenderId and  tblTenderEnvelope.cstatus=1", var);
	       return count == 1 ? true : false;
	}

	public List<Object[]> getBidderIdForOnlyOneEnvelop(int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();        
		var.put("tenderId",tenderId);
		 StringBuilder query = new StringBuilder();
	     query.append("select tblFinalSubmission.tblUserLogin.userId,1 from TblFinalSubmission tblFinalSubmission where tblFinalSubmission.tblTender.tenderId =:tenderId ");
	     return hibernateQueryDao.createNewQuery(query.toString(), var);
	}  
	public List<Object[]> getOverAllRemarks(int tenderId, int envelopeId,int bidderId,int comitteeType) {
		Map<String, Object> var = new HashMap<String, Object>();
		 StringBuilder query = new StringBuilder();
		 var.put("tenderId",tenderId);
		 var.put("envelopeId",envelopeId);
		 var.put("bidderId",bidderId);
		 var.put("comitteeType",comitteeType);
	     query.append("SELECT tblCommitteeRemarks.remarks,tblUserDetail.userName,tblCommitteeRemarks.userRoleId,tblUserDetail.tblUserLogin.userName,tblCommitteeRemarks.tblUserLogin.userId,tblCommitteeRemarks.isApproved");
	     query.append(" FROM TblCommitteeRemarks tblCommitteeRemarks,TblUserDetail tblUserDetail");
	     query.append(" WHERE tblCommitteeRemarks.createdBy=tblUserDetail.userDetailId AND tblCommitteeRemarks.tblTender.tenderId=:tenderId AND tblCommitteeRemarks.tblTenderEnvelope.envelopeId =:envelopeId ");
	     query.append(" AND tblCommitteeRemarks.bidderId =:bidderId AND tblCommitteeRemarks.committeeType=:comitteeType");
	     return hibernateQueryDao.createNewQuery(query.toString(), var);
	}
	public List<Object> getEnvelopeId(int tenderId,int envelopeId) throws Exception {        
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId", envelopeId);
        var.put("tenderId", tenderId);
        StringBuilder query = new StringBuilder();
            query.append(" SELECT tblTenderEnvelope.envelopeId");
            query.append(" FROM TblTenderEnvelope tblTenderEnvelope");
            query.append(" WHERE tblTenderEnvelope.cstatus=1 AND tblTenderEnvelope.envelopeId NOT IN (:envelopeId) AND tblTenderEnvelope.tblTender.tenderId=:tenderId");
        
        list = hibernateQueryDao.singleColQuery(query.toString(), var);
        return list;
    }
	public List<Integer> getCommitteeUserForNextLevel(int tenderId, int encryptionLevel,int envelopeId) {
		Map<String, Object> var = new HashMap<String, Object>();
		StringBuilder query = new StringBuilder();
		var.put("tenderId",tenderId);
		var.put("encryptionLevel",encryptionLevel);
		var.put("envelopeId",envelopeId);
		
		query.append("select tblCommitteeUser.tblUserLogin.userId from TblCommittee tblCommittee inner join tblCommittee.tblCommitteeUser tblCommitteeUser ");
		query.append("where tblCommittee.tblTender.tenderId =:tenderId and tblCommittee.committeeType = 2 and tblCommitteeUser.userRoleId = 2 and tblCommitteeUser.encryptionLevel =:encryptionLevel and tblCommittee.isActive=1 and tblCommitteeUser.childId=:envelopeId group by tblCommitteeUser.tblUserLogin.userId");
		List<Integer> list=(List<Integer>)(List<?>)hibernateQueryDao.getSingleColQuery(query.toString(), var);
		return list;
	}
	public List<Integer> getEvaluatedOfficeForNextLevel(int tenderId,int envelopeId, int roleId) {
		Map<String, Object> var = new HashMap<String, Object>();
		StringBuilder query = new StringBuilder();
		var.put("tenderId",tenderId);
		var.put("envelopeId",envelopeId);
		var.put("roleId",roleId);
		query.append("select tblBidderItems.createdBy,tblBidderItems.tblUserLogin.userId from TblBidderItems tblBidderItems where tblBidderItems.tblTender.tenderId =:tenderId and ");
		query.append("tblBidderItems.tblTenderEnvelope.envelopeId =:envelopeId and tblBidderItems.userRoleId =:roleId and tblBidderItems.isActive=1 group by tblBidderItems.createdBy,tblBidderItems.tblUserLogin.userId");
		List<Integer> list=(List<Integer>)(List<?>)hibernateQueryDao.getSingleColQuery(query.toString(), var);
		return list;
	}

	public List<Object[]> getChairpersonApprovedRejectData(int tenderId, int userRoleId,int bidderId) {
		Map<String, Object> var = new HashMap<String, Object>();
		 StringBuilder query = new StringBuilder();
		 var.put("tenderId",tenderId);
		 var.put("userRoleId",userRoleId);
		 var.put("bidderId",bidderId);
	     query.append("select ISNULL(tblBidderItems.tblTenderTable.tableId,0),tblBidderItems.rowId,tblBidderItems.isApproved from TblBidderItems tblBidderItems where tblBidderItems.tblTender.tenderId =:tenderId ");
	     query.append("and tblBidderItems.userRoleId =:userRoleId  and tblBidderItems.tblUserLogin.userId =:bidderId and tblBidderItems.isActive =1 ");
	     return hibernateQueryDao.createNewQuery(query.toString(), var);
	}
	/**
     * @author Lipi Shah
     * @param tenderId
     * @param envelopeId
     * @param bidderId
     * @return boolean
     * @throws Exception 
     */
    public  boolean checkEntryBidderAppDtlsBidderWise(int tenderId,int envelopeId,int bidderId) throws Exception{
            List<TblBidderApprovalDetail> list = null;        
            list = tblBidderApprovalDetailDao.findTblBidderApprovalDetail("tblTender.tenderId",Operation_enum.EQ,tenderId,"tblTenderEnvelope.envelopeId",Operation_enum.EQ,envelopeId,"tblUserLogin.userId",Operation_enum.EQ,bidderId);                
            if(!list.isEmpty()){
           	 return false;
            }else{
           	 return true;
            }             

    }
    /**
     * @author Lipi Shah
     * @param tenderId
     * @return boolean
     * @throws Exception 
     */
    public  boolean checkEntryBidderAppDtls(int tenderId) throws Exception{
    	List<TblBidderApprovalDetail> list = null;        
    	list = tblBidderApprovalDetailDao.findTblBidderApprovalDetail("tblTender.tenderId",Operation_enum.EQ,tenderId);                
    	if(!list.isEmpty()){
    		return false;
    	}else{
    		return true;
    	}             
    }
    
    public Map<Integer, Boolean> getRejectedBidderAppDtls(int tenderId) throws Exception{
    	Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("isApproved", 0);
        StringBuilder query = new StringBuilder();
        query.append(" SELECT DISTINCT tblBidderApprovalDetail.tblUserLogin.userId");
        query.append(" FROM TblBidderApprovalDetail tblBidderApprovalDetail");
        query.append(" WHERE tblBidderApprovalDetail.tblTender.tenderId =:tenderId AND tblBidderApprovalDetail.isApproved =:isApproved ");
        List<Object> rejectedBidderlist = hibernateQueryDao.singleColQuery(query.toString(),var);
        Map<Integer, Boolean> rejectedBidderMap = new HashMap<Integer, Boolean>();
        for (Object bidderId : rejectedBidderlist) {
        	rejectedBidderMap.put((Integer) bidderId, true);
		}
        return rejectedBidderMap;
    }
    /**
     * 
     * @author Lipi Shah
     * @param tenderId
     * @return
     * @throws Exception 
     */
    public List<Object> isTenderEnvOpened(int tenderId) throws Exception{
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        list = hibernateQueryDao.getSingleColQuery("select SUM(isOpened) FROM TblTenderEnvelope tblTenderEnvelope where tblTenderEnvelope.tblTender.tenderId=:tenderId",var);               
        return list;
    }
    /**
     * @author Lipi Shah
     * @return
     * @throws Exception 
     */
    public boolean getPendingCommittee(int tenderId,int committeeType,int isApproved) throws Exception {
    	List<Object> list = null;
    	Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("committeeType",committeeType);
        var.put("isApproved", isApproved);
        list = hibernateQueryDao.getSingleColQuery("SELECT tblCommittee.committeeId FROM TblCommittee tblCommittee WHERE tblCommittee.tblTender.tenderId=:tenderId AND committeeType=:committeeType AND isApproved=:isApproved ORDER BY tblCommittee.committeeId",var);
        return list!=null && !list.isEmpty()?true:false;
    }
    public List<Object[]> getBidderDetailsByTenderId(int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();
		 StringBuilder query = new StringBuilder();
		 var.put("tenderId",tenderId);
	     query.append("select tblFinalSubmission.tblUserLogin.userId,tblCompany.companyName from TblFinalSubmission tblFinalSubmission inner join tblFinalSubmission.tblCompany tblCompany where tblFinalSubmission.tblTender.tenderId =:tenderId and tblFinalSubmission.isActive =1");
	     return hibernateQueryDao.createNewQuery(query.toString(), var);
	}
	public List<Object[]> getOverAllRemarksForViewBidderEvaluation(int tenderId, boolean isTwoStageEvaluation) {
		Map<String, Object> var = new HashMap<String, Object>();
		 StringBuilder query = new StringBuilder();
		 var.put("tenderId",tenderId);
		 if(isTwoStageEvaluation){
			 query.append("select tblCommitteeRemarks.remarks,tblUserDetail.userName,tblCommitteeRemarks.userRoleId,tblCommitteeRemarks.tblUserLogin.userId,tblCommitteeRemarks.tblTenderEnvelope.envelopeId,tblCommitteeRemarks.bidderId,");
		     query.append("tblCommitteeRemarks.isApproved from TblCommitteeRemarks tblCommitteeRemarks inner join tblCommitteeRemarks.tblUserLogin tblUserLogin inner join tblCommitteeRemarks.tblTenderEnvelope tblTenderEnvelope,TblUserDetail tblUserDetail  ");
		     query.append("where tblCommitteeRemarks.tblTender.tenderId =:tenderId and tblCommitteeRemarks.committeeType = 2 and tblCommitteeRemarks.isActive=1 and tblUserDetail.userDetailId=tblCommitteeRemarks.createdBy"); 
		 }else{
			 query.append("select tblBidderApprovalDetail.remarks,(select tblUserDetail.userName from TblUserDetail tblUserDetail where tblUserDetail.userDetailId=tblBidderApprovalDetail.createdBy),0,tblBidderApprovalDetail.createdBy,tblTenderEnvelope.envelopeId,");
		     query.append("tblBidderApprovalDetail.tblUserLogin.userId,tblBidderApprovalDetail.isApproved from TblBidderApprovalDetail tblBidderApprovalDetail ");
		     query.append("inner join tblBidderApprovalDetail.tblTenderEnvelope tblTenderEnvelope where tblBidderApprovalDetail.tblTender.tenderId =:tenderId");
		 } 
	     return hibernateQueryDao.createNewQuery(query.toString(), var);
	}
	 /**
     * @author priyanka
     * @param tenderId
     * @param isTwoStageEvaluation
     * @return
     * @throws Exception 
     */
	public List<Object[]> getOverAllRemarksForViewBidderReEvaluation(int tenderId, boolean isTwoStageEvaluation) {
		Map<String, Object> var = new HashMap<String, Object>();
		List<Object[]> list = null;
		 StringBuilder query = new StringBuilder();
		 var.put("tenderId",tenderId);
		
			 query.append("select tblBidderApprovalHistory.remarks as c0,(select tblUserDetail.userName from appuser.tbl_UserDetail tblUserDetail where tblUserDetail.userDetailId=tblBidderApprovalHistory.createdBy) as c1,0 as c2,tblBidderApprovalHistory.createdBy as c3,tblBidderApprovalHistory.envelopeId as c4,");
		     query.append("tblBidderApprovalHistory.bidderId as c5,tblBidderApprovalHistory.isApproved as c6,tblBidderApprovalHistory.tenderReevalId as c7 from appreport.tbl_BidderApprovalHistory tblBidderApprovalHistory ");
		     query.append("inner join apptender.tbl_TenderEnvelope tblTenderEnvelope on tblTenderEnvelope.envelopeId = tblBidderApprovalHistory.envelopeId where tblBidderApprovalHistory.tenderId =:tenderId order by tblTenderEnvelope.sortOrder");
		     int nVarCharColumnIndex [] = {0,1};
		        list = hibernateQueryDao.createSQLQuery(query.toString(), var,nVarCharColumnIndex,8);
				return list;
	}
	public List<Object[]> getReEvaluationRemark(int tenderId,int envelopeId) {
		Map<String, Object> var = new HashMap<String, Object>();
		List<Object[]> list = null;
		 StringBuilder query = new StringBuilder();
		 var.put("tenderId",tenderId);
		 var.put("envelopeId",envelopeId);
			 query.append("select tblBidderApprovalHistory.tenderReevalId as c0 ,tbltenderreevaluation.remarks as c1, tbltenderreevaluation.updatedOn as c2 from appreport.tbl_BidderApprovalHistory tblBidderApprovalHistory ");
		     query.append("  left join  apptenderresult.tbl_tenderreevaluation tbltenderreevaluation on tblBidderApprovalHistory.envelopeId = tbltenderreevaluation.envelopeId ");
		     query.append(" and   tblBidderApprovalHistory.tenderReEvalId =  tbltenderreevaluation.tenderReEvalId ");
		     query.append(" where tblBidderApprovalHistory.tenderId =:tenderId and tblBidderApprovalHistory.envelopeId =:envelopeId "); 
		     query.append("  group by tblBidderApprovalHistory.tenderReevalId,tbltenderreevaluation.remarks, tbltenderreevaluation.updatedOn order by tblBidderApprovalHistory.tenderReevalId desc");
		     int nVarCharColumnIndex [] = {1,2};
		        list = hibernateQueryDao.createSQLQuery(query.toString(), var,nVarCharColumnIndex,3);
				return list;
	}
	
	public List<Object[]> getAllEnvelopWiseEvaluationDone(int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();
		List<Object[]> list = null;
		StringBuilder query = new StringBuilder();
			var.put("tenderId",tenderId);
			query.append("select (select COUNT(envelopeId) From apptender.tbl_TenderEnvelope where tenderId=:tenderId)As c1,");
			query.append("(select COUNT (distinct envelopeId) From apptenderresult.Tbl_BidderApprovalDetail where tenderId=:tenderId) As c2");
			int nVarCharColumnIndex [] = {};
	        list = hibernateQueryDao.createSQLQuery(query.toString(), var,nVarCharColumnIndex,0);
		return list;
	}
	

	public  TblTenderEnvelope getTblTenderEnvelopeByTenderIdSortOrder(int tenderId,int sortOrder) throws Exception{
		Integer[] envId={4,5};
		List<TblTenderEnvelope> list = null;        
        list = tblTenderEnvelopeDao.findTblTenderEnvelope("tblTender.tenderId",Operation_enum.EQ,tenderId,"tblEnvelope.envId",Operation_enum.IN,envId,"sortOrder",Operation_enum.EQ,sortOrder,"tblEnvelope.envId",Operation_enum.ORDERBY,Operation_enum.DESC);                
        return (list!=null && !list.isEmpty()) ? list.get(0) : null;  
    }
	public  TblTenderEnvelope getTblTenderEnvelopeByTenderIdEnvelopeId(int tenderId,int envelopeId) throws Exception{
		Integer[] envId={4,5};
		List<TblTenderEnvelope> list = null;        
        list = tblTenderEnvelopeDao.findTblTenderEnvelope("tblTender.tenderId",Operation_enum.EQ,tenderId,"tblEnvelope.envId",Operation_enum.IN,envId,"envelopeId",Operation_enum.EQ,envelopeId,"tblEnvelope.envId",Operation_enum.ORDERBY,Operation_enum.DESC);                
        return (list!=null && !list.isEmpty()) ? list.get(0) : null;  
    }
	public  TblTenderEnvelope getTblTenderEnvelopeRevaluationByTenderId(int tenderId) throws Exception{
	    List<TblTenderEnvelope> list = null;        
	    list = tblTenderEnvelopeDao.findTblTenderEnvelope("tblTender.tenderId",Operation_enum.EQ,tenderId,"isOpened",Operation_enum.EQ,1,"envelopeId",Operation_enum.ORDERBY,Operation_enum.DESC);                
	    return (list!=null && !list.isEmpty()) ? list.get(0) : null;  
	}
	public   List<TblTenderReevaluation> getTblTenderEnvelopeRevaluationStatusByTenderId(int tenderId,Integer[] cstatus) throws Exception{
	    List<TblTenderReevaluation> list = null; 
	    list = tblTenderReevaluationDao.findTblTenderReevaluation("tblTender.tenderId",Operation_enum.EQ,tenderId,"cstatus",Operation_enum.IN,cstatus);                
	    return list;  
	}
	public   List<TblTenderReevaluation> getTblTenderRevaluationStatusByEnvelopeId(int tenderId,int envelopeId,Integer[] cstatus) throws Exception{
	    List<TblTenderReevaluation> list = null; 
	    list = tblTenderReevaluationDao.findTblTenderReevaluation("tblTender.tenderId",Operation_enum.EQ,tenderId,"tblTenderEnvelope.envelopeId",Operation_enum.EQ,envelopeId,"cstatus",Operation_enum.IN,cstatus);                
	    return list;  
	}

	public int checkIsEvaluationDone(int tenderId,int envelopeType) throws Exception {
		Map<String, Object> var = new HashMap<String, Object>();
		List<Object> data = new ArrayList<Object>();
		StringBuilder query = new StringBuilder();
		long secondLastEnvDetailscount = 0;
		long finalSubCnt = 0 ;
		var.put("tenderId",tenderId);
	    query.append("select envelopeId from TblTenderEnvelope tblTenderEnvelope where tblTenderEnvelope.tblTender.tenderId =:tenderId order by tblTenderEnvelope.sortOrder desc");
	    
	    data = hibernateQueryDao.getSingleColQuery(query.toString(), var);
	    int lastEnvelopeId = Integer.parseInt(data.get(0).toString());
	    if(data.size() > 1){//condition for only one envelope in tender
	    	int secondLastEnvelopeId = Integer.parseInt(data.get(1).toString());
		    if(envelopeType==1){
		    	finalSubCnt = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblFinalSubmission ", "tblFinalSubmission.tblUserLogin.userId ", "tblFinalSubmission.tblTender.tenderId =:tenderId and tblFinalSubmission.isActive = 1", var);
			    if(finalSubCnt == 0){
			    	return 0;
			    }
		    }else{
		    	var.put("envelopId",secondLastEnvelopeId);
		    	secondLastEnvDetailscount = hibernateQueryDao.countForNewQuery("TblBidderApprovalDetail tblBidderApprovalDetail inner join tblBidderApprovalDetail.tblTenderEnvelope tblTenderEnvelope ", "tblBidderApprovalDetail.tblUserLogin.userId ", "tblTenderEnvelope.tblTender.tenderId =:tenderId and tblTenderEnvelope.envelopeId =:envelopId AND tblBidderApprovalDetail.isApproved=1", var);
		    }
	    }else{
	    	finalSubCnt = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblFinalSubmission ", "tblFinalSubmission.tblUserLogin.userId ", "tblFinalSubmission.tblTender.tenderId =:tenderId and tblFinalSubmission.isActive = 1", var);
		    if(finalSubCnt == 0){
		    	return 0;
		    }
	    }
	    
	    var.put("envelopId",lastEnvelopeId);
	    long lastEnvDetailscount = hibernateQueryDao.countForNewQuery("TblBidderApprovalDetail tblBidderApprovalDetail inner join tblBidderApprovalDetail.tblTenderEnvelope tblTenderEnvelope ", "tblBidderApprovalDetail.tblUserLogin.userId ", "tblTenderEnvelope.tblTender.tenderId =:tenderId and tblTenderEnvelope.envelopeId =:envelopId", var);
	    if(envelopeType==1){
	    	return lastEnvDetailscount == finalSubCnt ? 1 : 0;
	    }else{
	    	return (lastEnvDetailscount!=0 && secondLastEnvDetailscount!=0 && lastEnvDetailscount == secondLastEnvDetailscount) ? 1 : 0;
	    }
	}

	public List<TblOfficerDocMapping> getAllOfficerDocMapping(Integer[] envIdsArr) throws Exception {
		Map<String, Object> var = new HashMap<String, Object>();
		return tblOfficerDocMappingDao.findTblOfficerDocMapping("tblLink.linkId",Operation_enum.EQ,210,"objectId",Operation_enum.IN,envIdsArr,"cstatus",Operation_enum.EQ,1);
	}

	public List<Object[]> getCommitteeMember(int tenderId, int committeeType) {
		List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("committeeType", committeeType);
        StringBuilder query = new StringBuilder();
        query.append("select tblCommitteeUser.tblUserLogin.userId,tblCommitteeUser.tblUserDetail.userName from TblCommitteeUser tblCommitteeUser inner join tblCommitteeUser.tblCommittee tblCommittee ");
        query.append("where tblCommittee.tblTender.tenderId =:tenderId and tblCommittee.committeeType =:committeeType and tblCommittee.isActive = 1 group by tblCommitteeUser.tblUserLogin.userId,tblCommitteeUser.tblUserDetail.userName");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);
        return list;
	}

	public List<Object[]> getBidderweightageScoreDetails(int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();
		 StringBuilder query = new StringBuilder();
		 var.put("tenderId",tenderId);
		 query.append("select tblBidderweightageScore.tblUserLogin.userId,tblBidderweightageScore.bidderId,tblBidderweightageScore.tblTenderEnvelope.envelopeId,tblBidderweightageScore.tblTenderForm.formId,");
		 query.append("tblUserDetail.userName,tblBidderweightageScore.bidderMarks from TblBidderweightageScore tblBidderweightageScore,TblUserDetail tblUserDetail where tblBidderweightageScore.tblTender.tenderId =:tenderId and tblUserDetail.userDetailId=tblBidderweightageScore.createdBy order by tblBidderweightageScore.tblTenderEnvelope.envelopeId,tblBidderweightageScore.tblTenderForm.sortOrder");
	     return hibernateQueryDao.createNewQuery(query.toString(), var);
	}

	public List<Object[]> getTenderEnvelopeWeightage(Integer[] envIdsArr) {
		Map<String, Object> var = new HashMap<String, Object>();
		 StringBuilder query = new StringBuilder();
		 var.put("envIdsArr",envIdsArr);
		 query.append("select tbltenderEnvelopeWeightage.tblTenderEnvelope.envelopeId,tbltenderEnvelopeWeightage.scoringMarks,tbltenderEnvelopeWeightage.passingMarks from TbltenderEnvelopeWeightage tbltenderEnvelopeWeightage ");
		 query.append("where tbltenderEnvelopeWeightage.tblTenderEnvelope.envelopeId in (:envIdsArr)");
	     return hibernateQueryDao.createNewQuery(query.toString(), var);
	}

	public long checkIsWeightageStart(int tenderId) throws Exception {
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("tenderId",tenderId);
	    long appDetailscount = hibernateQueryDao.countForNewQuery("TblBidderweightageScore tblBidderweightageScore ", "tblBidderweightageScore.bidweightageID ", "tblBidderweightageScore.tblTender.tenderId =:tenderId", var);
		return appDetailscount != 0 ? 1 : 0;
	}
	 /**
     * @author Lipi Shah
     * @param tenderId
     * @throws Exception 
     */
    public List<Object[]> getRebateFormByTenderId(int tenderId) throws Exception{
        StringBuilder query = new StringBuilder();
   	 	Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        query.append("SELECT tbltenderform.formId,tbltenderform.formName ")
        	.append("FROM TblRebate tblrebate ")
        	.append("INNER JOIN tblrebate.tblRebateForm tblrebateform ")
        	.append("INNER JOIN tblrebateform.tblTenderForm tbltenderform ")
        	.append("WHERE tblrebate.tblTender.tenderId=:tenderId AND tbltenderform.cstatus = 1");
        return hibernateQueryDao.createNewQuery(query.toString(),var);
    }
    /**
     * @author Lipi Shah
     * @param tenderId
     * @throws Exception 
     */
    public List<Object> getTenderEvaluatedBidders(int envelopeId,int officerId) throws Exception{
        StringBuilder query = new StringBuilder();
   	 	Map<String, Object> var = new HashMap<String, Object>();
        var.put("envelopeId",envelopeId);
        var.put("officerId",officerId);
        query.append("SELECT distinct(tblBidderItems.tblUserLogin.userId)")
        	.append("FROM TblBidderItems tblBidderItems ")
        	.append("WHERE tblBidderItems.tblTenderEnvelope.envelopeId=:envelopeId AND tblBidderItems.createdBy=:officerId");
        return hibernateQueryDao.singleColQuery(query.toString(),var);
    }

	public List<Object[]> getBidderDetailsForPriceBidEnvelopByTenderId(
			int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();
		 StringBuilder query = new StringBuilder();
		 var.put("tenderId",tenderId);
	     query.append("select tblBidderApprovalDetail.tblUserLogin.userId,tblcompany.companyName,tblBidderApprovalDetail.isApproved from TblBidderApprovalDetail tblBidderApprovalDetail inner join tblBidderApprovalDetail.tblTenderEnvelope tblTenderEnvelope ");
	     query.append("inner join tblBidderApprovalDetail.tblCompany tblcompany where tblBidderApprovalDetail.tblTender.tenderId =:tenderId and tblTenderEnvelope.tblEnvelope.envId in (4,5)");
	     return hibernateQueryDao.createNewQuery(query.toString(), var);
	}
	/**
	 * Get Datatypes for view Form
	 * @author keval.soni
	 * @param formId
	 * @return
	 * @throws Exception
	 */
	public List<Object> getDataTypesByFormId(int formId) throws Exception{
        StringBuilder query = new StringBuilder();
   	 	Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        query.append("SELECT tblTenderColumn.dataType ")
        	.append("FROM TblTenderColumn tblTenderColumn ")
        	.append("WHERE tblTenderColumn.tblTenderForm.formId=:formId ORDER BY tblTenderColumn.dataType");
        return hibernateQueryDao.singleColQuery(query.toString(),var);
    }
	/**
	 * @author keval.soni
	 * Get Bidder list of already evaluated
	 * @param tenderId
	 * @param envelopeId
	 * @return
	 */
	public List<Object> getAlreadyEvaluationDoneBidderList(int tenderId,
			int envelopeId,int createdBy) {
		StringBuilder query = new StringBuilder();
		List<Object> list = new ArrayList<Object>();
   	 	Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
   	 	var.put("envelopeId",envelopeId);
   	 	var.put("createdBy",createdBy);
        query.append("select tblBidderItems.tblUserLogin.userId from TblBidderItems tblBidderItems where tblBidderItems.tblTender.tenderId =:tenderId and tblBidderItems.tblTenderEnvelope.envelopeId =:envelopeId and tblBidderItems.createdBy =:createdBy");
        list = hibernateQueryDao.singleColQuery(query.toString(),var);
        return list;
	}
	/**
	 * Check isEnvelopeWiseEvaluationDone
	 * @author keval.soni
	 * @param tenderId
	 * @param envelopeId
	 * @param finalSubmissionCnt 
	 * @return
	 */
	public Integer isEnvelopeWiseEvaluationDone(int tenderId, int envelopeId, long finalSubmissionCnt) {
		StringBuilder query = new StringBuilder();
		List<Object> list = new ArrayList<Object>();
   	 	Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        var.put("finalSubmissionCnt",finalSubmissionCnt);
        query.append("SELECT DISTINCT CASE WHEN (:finalSubmissionCnt) = ");
        query.append("(SELECT COUNT(tblBidderApprovalDetail.bidderApprovalId) FROM TblBidderApprovalDetail tblBidderApprovalDetail WHERE tblBidderApprovalDetail.tblTender.tenderId =:tenderId AND ");
        query.append("tblBidderApprovalDetail.tblTenderEnvelope.envelopeId =:envelopeId) THEN 1 ELSE 0 END FROM TblFinalSubmission tblFinalSubmission");
        list = hibernateQueryDao.singleColQuery(query.toString(),var);
		return list.size() != 0 && !list.isEmpty() ? Integer.parseInt(list.get(0).toString()) : 0 ;
	}
	public long getCountofFinalSubmission(int tenderId) throws Exception {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
		long finalSubCnt = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblFinalSubmission ", "tblFinalSubmission.tblUserLogin.userId ", "tblFinalSubmission.tblTender.tenderId =:tenderId and tblFinalSubmission.isActive = 1", var);
		return finalSubCnt;
	}
	public Integer isEnvelopeWiseEvaluationDone(int tenderId, int envelopeId,
			long finalSubmissionCnt, int previousEnvId) {
		if(previousEnvId == -1 || previousEnvId == 0){
			return isEnvelopeWiseEvaluationDone(tenderId,envelopeId,finalSubmissionCnt);
		}else{
			StringBuilder query = new StringBuilder();
			List<Object> list = new ArrayList<Object>();
	   	 	Map<String, Object> var = new HashMap<String, Object>();
	   	 	var.put("tenderId",tenderId);
	        var.put("envelopeId",envelopeId);
	        var.put("prevEnvelopeId",previousEnvId);
			query.append("SELECT DISTINCT CASE WHEN (SELECT COUNT(tblBidderApprovalDetail.bidderApprovalId) FROM TblBidderApprovalDetail tblBidderApprovalDetail WHERE tblBidderApprovalDetail.tblTender.tenderId =:tenderId AND ");
			query.append("tblBidderApprovalDetail.tblTenderEnvelope.envelopeId =:prevEnvelopeId AND tblBidderApprovalDetail.isApproved = 1) = ");
	        query.append("(SELECT COUNT(tblBidderApprovalDetail.bidderApprovalId) FROM TblBidderApprovalDetail tblBidderApprovalDetail WHERE tblBidderApprovalDetail.tblTender.tenderId =:tenderId AND ");
	        query.append("tblBidderApprovalDetail.tblTenderEnvelope.envelopeId =:envelopeId) THEN 1 ELSE 0 END FROM TblFinalSubmission tblFinalSubmission");
	        list = hibernateQueryDao.singleColQuery(query.toString(),var);
	        return list.size() != 0 && !list.isEmpty() ? Integer.parseInt(list.get(0).toString()) : 0 ;
		}
	}
	
	public Integer isEnvelopeWiseEvaluationDoneForViewWeightage(int tenderId, int envelopeId,
			long finalSubmissionCnt, int previousEnvId) {
		if(previousEnvId == -1 || previousEnvId == 0){
			return isEnvelopeWiseEvaluationDone(tenderId,envelopeId,finalSubmissionCnt);
		}else{
			StringBuilder query = new StringBuilder();
			List<Object> list = new ArrayList<Object>();
	   	 	Map<String, Object> var = new HashMap<String, Object>();
	   	 	var.put("tenderId",tenderId);
	        var.put("envelopeId",envelopeId);
	        var.put("prevEnvelopeId",previousEnvId);
			query.append("SELECT DISTINCT CASE WHEN (SELECT COUNT(tblBidderApprovalDetail.bidderApprovalId) FROM TblBidderApprovalDetail tblBidderApprovalDetail WHERE tblBidderApprovalDetail.tblTender.tenderId =:tenderId AND ");
			query.append("tblBidderApprovalDetail.tblTenderEnvelope.envelopeId =:prevEnvelopeId AND tblBidderApprovalDetail.isApproved = 1) = ");
	        query.append("(SELECT COUNT(tblBidderApprovalDetail.bidderApprovalId) FROM TblBidderApprovalDetail tblBidderApprovalDetail WHERE tblBidderApprovalDetail.tblTender.tenderId =:tenderId AND ");
	        query.append("tblBidderApprovalDetail.tblTenderEnvelope.envelopeId =:envelopeId AND tblBidderApprovalDetail.isApproved = 1) THEN 1 ELSE 0 END FROM TblFinalSubmission tblFinalSubmission");
	        list = hibernateQueryDao.singleColQuery(query.toString(),var);
	        return list.size() != 0 && !list.isEmpty() ? Integer.parseInt(list.get(0).toString()) : 0 ;
		}
	}
	
	/**
	 * Created the same function as above for solving the bug Bug :  38234
	 * @author nitin.w
	 * @param tenderId
	 * @param envelopeId
	 * @param finalSubmissionCnt
	 * @param previousEnvId
	 * @return
	 */
	public Integer isEnvelopeWiseEvaluationCompleted(int tenderId, int envelopeId,
			long finalSubmissionCnt, int previousEnvId) {
		if(previousEnvId == -1 || previousEnvId == 0){
			return isEnvelopeWiseEvaluationDone(tenderId,envelopeId,finalSubmissionCnt);
		}else{
			StringBuilder query = new StringBuilder();
			List<Object> list = new ArrayList<Object>();
	   	 	Map<String, Object> var = new HashMap<String, Object>();
	   	 	var.put("tenderId",tenderId);
	        var.put("envelopeId",envelopeId);
	        var.put("prevEnvelopeId",previousEnvId);
			query.append("SELECT DISTINCT CASE WHEN (SELECT COUNT(tblBidderApprovalDetail.bidderApprovalId) FROM TblBidderApprovalDetail tblBidderApprovalDetail WHERE tblBidderApprovalDetail.tblTender.tenderId =:tenderId AND ");
			query.append("tblBidderApprovalDetail.tblTenderEnvelope.envelopeId =:prevEnvelopeId AND tblBidderApprovalDetail.isApproved = 1) = ");
	        query.append("(SELECT COUNT(tblBidderApprovalDetail.bidderApprovalId) FROM TblBidderApprovalDetail tblBidderApprovalDetail WHERE tblBidderApprovalDetail.tblTender.tenderId =:tenderId AND ");
	        query.append("tblBidderApprovalDetail.tblTenderEnvelope.envelopeId =:envelopeId) THEN 1 ELSE 0 END FROM TblFinalSubmission tblFinalSubmission");
	        list = hibernateQueryDao.singleColQuery(query.toString(),var);
	        return list.size() != 0 && !list.isEmpty() ? Integer.parseInt(list.get(0).toString()) : 0 ;
		}
	}
	/**
	 * Check Approved forms 
	 * @author Priyanka Dalwadi
	 * @param tenderId
	 * @param envelopeId
	 * @param bidderId 
	 * @return
	 */
	public long getCountofActiveForm(int tenderId,int envelopeId,int bidderId) throws Exception {
		     Map<String, Object> map = new HashMap<String, Object>();
		     StringBuilder query = new StringBuilder();
		     map.put("tenderId",tenderId);
		     map.put("envelopeId",envelopeId);
		     map.put("bidderId",bidderId);
		     query.append("SELECT COUNT(tblTenderForm.formId) FROM TblTenderBid tblTenderBid INNER JOIN tblTenderBid.tblTenderForm tblTenderForm ");
		     query.append("WHERE tblTenderForm.tblTender.tenderId=:tenderId AND tblTenderForm.cstatus = 1 AND tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId ");
		     query.append("AND tblTenderBid.tblUserLogin.userId=:bidderId");
		     List<Object> list = hibernateQueryDao.singleColQuery(query.toString(),map);
		     return !list.isEmpty() ? Long.parseLong(list.get(0).toString()) : 0;
	     } 
		 /**
		 * Check Bidder Status In Approved Forms
		 * @author Priyanka Dalwadi
		 * @param tenderId
		 * @param envelopeId
		 * @param bidderId 
		 * @return
		 */
	 public List<Object> getBidStatusOfApprovedForm(int tenderId, int envelopeId,int bidderId) throws Exception  {
	    	 Map<String, Object> var = new HashMap<String, Object>();
			 StringBuilder query = new StringBuilder();
			 var.put("tenderId",tenderId);
			 var.put("bidderId",bidderId);
			 var.put("envelopeId",envelopeId);
			 query.append(" SELECT COUNT(tblTenderForm.formId) FROM TblTenderBid tblTenderBid ");
			 query.append("  INNER JOIN tblTenderBid.tblTenderForm tblTenderForm  ");
			 query.append(" WHERE tblTenderForm.tblTender.tenderId=:tenderId AND tblTenderForm.cstatus = 1 AND tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId "); 
			 query.append(" AND tblTenderBid.tblUserLogin.userId=:bidderId "); 
			 return hibernateQueryDao.getSingleColQuery(query.toString(), var);
	     }
	     
	public List<Object[]> getTenderNRebateCell(int tenderId) throws Exception {
		StringBuilder query = new StringBuilder();
		List<Object[]> list = new ArrayList<Object[]>();
   	 	Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        query.append("SELECT  tblTenderCell.cellId,tblRebateForm.tblTenderCell.cellId");
        query.append(" FROM TblRebateForm tblRebateForm");
        query.append(" INNER JOIN tblRebateForm.tblRebate tblRebate");
        query.append(" LEFT JOIN tblRebateForm.tblTenderCell tblTenderCell");
        query.append(" WHERE tblRebate.tblTender.tenderId =:tenderId");
        list = hibernateQueryDao.createNewQuery(query.toString(),var);
        return list;
	}
	public boolean deleteRebateCellById(List<Integer> cellId) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("cellId", cellId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("DELETE FROM TblRebateForm tblRebateForm where tblRebateForm.tblTenderCell.cellId IN(:cellId)", var);
        return cnt != 0;
    }
	public long getCountTblRebateForm(int tenderId) throws Exception {
		StringBuilder query = new StringBuilder();
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        List<Object> list = new ArrayList<Object>();
        query.append("SELECT  COUNT(tblRebateForm.tblTenderCell.cellId)");
        query.append(" FROM TblRebateForm tblRebateForm");
        query.append(" INNER JOIN tblRebateForm.tblRebate tblRebate");
        query.append(" WHERE tblRebate.tblTender.tenderId =:tenderId");
        list = hibernateQueryDao.singleColQuery(query.toString(),var);
		return list.size() != 0 && !list.isEmpty() ? Integer.parseInt(list.get(0).toString()) : 0 ;
	}
	public boolean deleteTblRebate(int tenderId) throws Exception {
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("DELETE FROM TblRebate tblRebate where tblRebate.tblTender.tenderId =:tenderId", var);
        return cnt != 0;

    }
	@Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public TblNegotiationSORRemarks getTenderNegotiationSORRemarks(int formId, int eventId) throws Exception {
		Map<String, Object> parameters = new HashMap<String, Object>();
	    List<TblNegotiationSORRemarks> ls = negotiationSORRemarksDao.findTblNegotiationSORRemarks("objectId", Operation_enum.EQ, formId,"eventId", Operation_enum.EQ, eventId);
	    if (ls != null && !ls.isEmpty()) {
	           return ls.get(0);
	       }
		return null;
	}
	@Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
	public boolean deleteTenderSORRemarks(int formId, Integer[] eventIds) 
	{
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId", formId);
        var.put("eventId", eventIds);
        int cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblNegotiationSORRemarks tblNegotiationSORRemarks where tblNegotiationSORRemarks.objectId=:formId and tblNegotiationSORRemarks.eventId in (:eventId)", var);
        return cnt!=0;
	}
	
	/**
	 * Check form is published
	 * @author Vivek Rajyaguru
	 * @param formId
	 * @return
	 * @throws Exception
	 */
	public boolean isFormPublished(int formId) throws Exception{
		List<TblTenderForm> list = null;
	    list = tblTenderFormDao.findTblTenderForm(FORMID, Operation_enum.EQ, formId,"cstatus",Operation_enum.EQ, 1);
	    return (list != null && !list.isEmpty()) ? true : false;
	}
	
	/**
	 * Get Bid Withdrawal Count
	 * @author Keval soni
	 * @param tenderId
	 * @param integer 
	 * @return
	 * @throws Exception
	 */
	public int getBidWithdrawalCount(int tenderId, int isConsortiumAllowed) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder query = new StringBuilder();
        if(isConsortiumAllowed == 0){
        	query.append("SELECT BW.companyId,BW.bidderId from apptenderbid.tbl_BidWithdrawal BW LEFT JOIN apptenderbid.tbl_FinalSubmission FS ");
            query.append("ON BW.companyId = FS.companyId AND BW.tenderId = FS.tenderId ");
            query.append("where BW.tenderId =:tenderId AND FS.finalsubmissionId IS NULL group by BW.companyId,BW.bidderId");
        }else{
        	query.append("select companyId,bidderId from apptenderbid.tbl_BidWithdrawal where companyId in (select cd.companyId from apptenderbid.tbl_Consortium c inner join apptenderbid.tbl_ConsortiumDetail cd on c.consortiumId = cd.consortiumId ");
        	query.append("left join apptenderbid.tbl_FinalSubmission fs on c.consortiumId = fs.consortiumId where c.tenderId =:tenderId and cd.partnerType in (1,2) and c.isActive = 1 and fs.finalsubmissionId IS NULL) and tenderId =:tenderId group by companyId,bidderId");
        }
        list = hibernateQueryDao.createSQLQuery(query.toString(), var);
        return list != null && !list.isEmpty() ? list.size() : 0;
	}
	/**
	 * Get Custom Parameter Field value
	 * @author Keval soni
	 * @param tenderId
	 * @return
	 * @throws Exception
	 */
	public List<Object> getCustomParameterFieldValues(int clientId,int moduleId,int eventTypeId) {
			StringBuilder query = new StringBuilder();
			List<Object> list = new ArrayList<Object>();
	   	 	Map<String, Object> var = new HashMap<String, Object>();
	   	 	var.put("clientId",clientId);
	        var.put("moduleId",moduleId);
	        var.put("eventTypeId",eventTypeId);
	        var.put("field","showNoOfBidders");
			query.append("SELECT tblCustomParameter.isShown FROM TblCustomParameter tblCustomParameter WHERE tblCustomParameter.tblClient.clientId =:clientId AND tblCustomParameter.tblModule.moduleId =:moduleId ");
			query.append("AND tblCustomParameter.tblEventType.eventTypeId =:eventTypeId AND tblCustomParameter.field =:field");
			list = hibernateQueryDao.singleColQuery(query.toString(), var);
	        return list;
	}

	public List<Object[]> getBidWithdrawalDetails(Integer tenderId, int clientId,int isConsortiumAllowed) {
		List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("clientId", clientId);
        StringBuilder query = new StringBuilder();
        if(isConsortiumAllowed == 0){
        	query.append("SELECT CM.companyId as c0,BW.bidderId as c1,CM.companyName as c2,BW.remark as c3,BW.createdOn as c4 from apptenderbid.tbl_BidWithdrawal BW INNER JOIN appuser.tbl_UserLogin UL on BW.bidderId = UL.userId ");
            query.append("INNER JOIN appuser.tbl_BidderStatus BS on UL.userId = BS.userId and BS.clientId =:clientId INNER JOIN appuser.tbl_Company CM ON BS.companyId = CM.companyId LEFT JOIN ");
            query.append("apptenderbid.tbl_FinalSubmission FS ON BW.companyId = FS.companyId AND BW.tenderId = FS.tenderId where BW.tenderId =:tenderId AND FS.finalsubmissionId IS NULL order by BW.bidWithdrawalId");
        }else{
        	query.append("select CM.companyId as c0,BW.bidderId as c1,CM.companyName as c2,BW.remark as c3,BW.createdOn as c4  from apptenderbid.tbl_BidWithdrawal BW INNER JOIN appuser.tbl_UserLogin UL on BW.bidderId = UL.userId ");
        	query.append("INNER JOIN appuser.tbl_BidderStatus BS on UL.userId = BS.userId and BS.clientId =:clientId INNER JOIN appuser.tbl_Company CM ON BS.companyId = CM.companyId ");
        	query.append("where BW.companyId in (select cd.companyId from apptenderbid.tbl_Consortium c inner join apptenderbid.tbl_ConsortiumDetail cd on c.consortiumId = cd.consortiumId ");
        	query.append("left join apptenderbid.tbl_FinalSubmission fs on c.consortiumId = fs.consortiumId where c.tenderId =:tenderId and cd.partnerType in (1,2) and c.isActive = 1 and fs.finalsubmissionId IS NULL) and tenderId =:tenderId order by BW.bidWithdrawalId ");
        }
        int nVarCharColumnIndex [] = {2,3};
        list = hibernateQueryDao.createSQLQuery(query.toString(), var,nVarCharColumnIndex,5);
		return list;
	}

	public List<Object[]> getTenderModeofCorriegendum(int tenderId) {
		List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder query = new StringBuilder();
    	query.append("SELECT substring(CD.newValue,charindex('::',CD.newValue)+2,len(CD.newValue)) as c0,CM.corrigendumId as c1 FROM apptender.tbl_Corrigendum CM INNER JOIN apptender.tbl_CorrigendumDetail CD ON ");
        query.append("CM.corrigendumId = CD.corrigendumId AND CM.cstatus=0 AND CM.processId = 1 WHERE CM.objectId =:tenderId AND CD.fieldName like 'tenderMode'");
        int nVarCharColumnIndex [] = {0};
        list = hibernateQueryDao.createSQLQuery(query.toString(), var,nVarCharColumnIndex,2);
		return list;
		
	}
	public long getCountofFinalSubmissionWithConsourtium(int tenderId, int isConsortiumAllowed) throws Exception {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        String whereCondition = isConsortiumAllowed == 1 ? "tblFinalSubmission.tblTender.tenderId =:tenderId and tblFinalSubmission.isActive = 1 and tblFinalSubmission.partnerType in (1,2,3)" : "tblFinalSubmission.tblTender.tenderId =:tenderId and tblFinalSubmission.isActive = 1";
		long finalSubCnt = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblFinalSubmission ", "tblFinalSubmission.tblUserLogin.userId ", whereCondition, var);
		return finalSubCnt;
	}
	public long getCountofFinalSubmissionWithConsourtiumForViewWeightage(int tenderId, int isConsortiumAllowed) throws Exception {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        String whereCondition = isConsortiumAllowed == 1 ? "tblFinalSubmission.tblTender.tenderId =:tenderId and tblFinalSubmission.isActive = 1 and tblFinalSubmission.partnerType in (1,2)" : "tblFinalSubmission.tblTender.tenderId =:tenderId and tblFinalSubmission.isActive = 1";
		long finalSubCnt = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblFinalSubmission ", "tblFinalSubmission.tblUserLogin.userId ", whereCondition, var);
		return finalSubCnt;
	}
	public List<Object[]> getAllEnvelopeTypeByTenderId(int tenderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select tblTenderEnvelope.envelopeId,tblTenderEnvelope.tblEnvelope.envId from TblTenderEnvelope tblTenderEnvelope where tblTenderEnvelope.tblTender.tenderId=:tenderId and tblTenderEnvelope.cstatus = 1 order by tblTenderEnvelope.tblEnvelope.envId");
        List<Object[]> data = hibernateQueryDao.createNewQuery(query.toString(), var);
        return data;
    }
	
	public  TblTenderEnvelope getTblTenderEnvelopeByTenderId(int tenderId) throws Exception{
        List<TblTenderEnvelope> list = null;        
        list = tblTenderEnvelopeDao.findTblTenderEnvelope("tblTender.tenderId",Operation_enum.EQ,tenderId,"isOpened",Operation_enum.EQ,1,"isEvaluated",Operation_enum.EQ,1,"tblEnvelope.envId",Operation_enum.ORDERBY,Operation_enum.DESC);                
        return (list!=null && !list.isEmpty()) ? list.get(0) : null;  

    }
	public  TblTenderEnvelope getTblTenderEnvelopeByTenderIdAndEnvelopeId(int tenderId,int envelopeId) throws Exception{
        List<TblTenderEnvelope> list = null;        
        list = tblTenderEnvelopeDao.findTblTenderEnvelope("tblTender.tenderId",Operation_enum.EQ,tenderId,"envelopeId",Operation_enum.NE,envelopeId,"isOpened",Operation_enum.EQ,1,"isEvaluated",Operation_enum.EQ,1,"tblEnvelope.envId",Operation_enum.ORDERBY,Operation_enum.DESC);                
        return (list!=null && !list.isEmpty()) ? list.get(0) : null;  

    }
	public List<Object> getTblBidderApprovalDetailCountByTenderId(int tenderId,int envelopeId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("envelopeId", envelopeId);
        query.append(" SELECT COUNT(DISTINCT tblBidderApprovalDetail.tblUserLogin.userId) FROM TblBidderApprovalDetail tblBidderApprovalDetail ");
        query.append(" WHERE tblBidderApprovalDetail.tblTender.tenderId =:tenderId AND tblBidderApprovalDetail.tblFinalSubmission.partnerType <> 3 ");
        query.append(" AND tblBidderApprovalDetail.tblFinalSubmission.isActive = 1 AND tblBidderApprovalDetail.tblTenderEnvelope.envelopeId =:envelopeId ");
        List<Object> data = hibernateQueryDao.singleColQuery(query.toString(), var);
        return data;
    }
	
	public List<Object> getTblFinalSubmissionCountByTenderId(int tenderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append(" SELECT COUNT(DISTINCT tblFinalSubmission.tblUserLogin.userId) FROM TblFinalSubmission tblFinalSubmission ");
        query.append(" WHERE tblFinalSubmission.tblTender.tenderId =:tenderId AND tblFinalSubmission.partnerType <> 3 ");
        query.append(" AND tblFinalSubmission.isActive = 1 ");
        List<Object> data = hibernateQueryDao.singleColQuery(query.toString(), var);
        return data;
    }
	//#bug #33249 Weightage Evaluation Form  with tender Form compare 
	public boolean getTenderFormCount(int tenderId){
		boolean count;
		int c = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        StringBuilder query = new StringBuilder();
        query.append("SELECT tf.formId AS FormIdNotConfigured from  apptender.Tbl_TenderForm tf LEFT OUTER JOIN apptender.Tbl_tenderFormWeightage fw on fw.formid=tf.formid where tf.tenderid =:tenderId and fw.formId is null and tf.cstatus = 1 ");
        List<Object[]> list = hibernateQueryDao.createSQLQuery(query.toString(), var);
        if(list!=null && !list.isEmpty()){
            return false;
        }
        return true;	
	}	
       /**
	 * @author Mittal
	 * @param tenderId
	 * @return
	 * @throws Exception
	 */ 
       public boolean addTenderReevaluation(TblTenderReevaluation tblTenderReevaluation) throws Exception {
        boolean bSuccess = false;
        tblTenderReevaluationDao.addTblTenderReevaluation(tblTenderReevaluation);
        bSuccess = true;
        return bSuccess;

    }
      /**
      * @author Mittal
      * Use to update re-evaluation 
      * @return boolean
      * @throws Exception 
      */
     public boolean updateTenderReEvaluation(int envelopeId,int tenderId) throws Exception{
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("envelopeId",envelopeId);
         var.put("tenderId",tenderId);
         StringBuilder query = new StringBuilder();
         query.append(" update TblTenderReevaluation set cstatus=1 ,updatedOn=GETUTCDATE() where tblTenderEnvelope.envelopeId=:envelopeId and tblTender.tenderId=:tenderId and cstatus = 0");
         int cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);        
         return cnt!=0;

     }
     
     /**
      * This method is used to update tender status when envelope is opened & opening committee consent is received. PT : #33589
      * @author jitendra
      * @param tenderId
      * @param envelopeId
      * @param status
      * @return
      * @throws Exception
      */
     public boolean updateTenderEvalutionStatusForOpening(int tenderId, int envelopeId, int status) throws Exception {
    	 List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "envelopeType,isTwoStageOpening,isCertRequired");
    	 int pki = abcUtility.getSessionIsPkiEnabled(getServletRequest()); 
    	 int envelopeType = 0;
    	 int isTwoStageOpening = 0;
    	 int isCertRequired = 0;
    	 if(tenderDetails!= null && !tenderDetails.isEmpty()){
    		 envelopeType =Integer.parseInt(tenderDetails.get(0)[0].toString());
    		 isTwoStageOpening = Integer.parseInt(tenderDetails.get(0)[1].toString());
    		 isCertRequired = Integer.parseInt(tenderDetails.get(0)[2].toString());
    		 
    		 boolean isEnvOpened = isEnvelopeOpened(tenderId, envelopeId, envelopeType);
        	 boolean isConsentRecieved = checkConsentForOpenedEnvelop(tenderId, envelopeId, isTwoStageOpening);
        	 List<Object[]>	obj= getAllEnvelopWiseEvaluationDone(tenderId);
        	 if(isEnvOpened && isConsentRecieved && (pki == 0 || isCertRequired == 0) && !obj.get(0)[0].equals(obj.get(0)[1])){
        		 return eventCreationService.updateTenderEvalutionStatus(tenderId, status);
        	 }else if(isEnvOpened && isConsentRecieved && (pki == 1 || isCertRequired == 1) && isEnvelopeDecrypted(tenderId, envelopeId) && !obj.get(0)[0].equals(obj.get(0)[1])){
        		 return eventCreationService.updateTenderEvalutionStatus(tenderId, status);
        	 }
    	 }
    	 return false;
     }
     
     /**
      * This method is used to check envelope opened or not for single stage or multi stage. PT : #33589.
      * @author jitendra
      * @param tenderId
      * @param envelopeId
      * @param envelopeType
      * @return
      * @throws Exception
      */
     public boolean isEnvelopeOpened(int tenderId,int envelopeId, int envelopeType) throws Exception {
         long count = 0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("envelopeId", envelopeId);
         var.put("tenderId", tenderId);
         StringBuilder query = new StringBuilder();
         query.append("tblTenderEnvelope.tblTender.tenderId=:tenderId and tblTenderEnvelope.envelopeId=:envelopeId and tblTenderEnvelope.isOpened=1");
         if(envelopeType == 2){
        	 query.append(" and tblTenderEnvelope.sortOrder=1");
         }
         count = hibernateQueryDao.countForNewQuery("TblTenderEnvelope tblTenderEnvelope ", "tblTenderEnvelope.envelopeId ", query.toString(), var);
         return count!=0;
     }
     
     /**
      * This method is used to check consent of opened envelope for single stage or multiple stage opening. PT : #33589.
      * @author jitendra  
      * @param tenderId
      * @param envelopeId
      * @param isTwoStageOpening
      * @return
      * @throws Exception
      */
     public boolean checkConsentForOpenedEnvelop(int tenderId, int envelopeId, int isTwoStageOpening) throws Exception {
    	 long memberConsentcount = 0;
    	 long chairManConsentcount = 0;
    	 Map<String, Object> var = new HashMap<String, Object>();
    	 var.put("tenderId", tenderId);
    	 var.put("envelopeId", envelopeId);
    	 
    	// For two stage opening, check consent for member & chairperson. For single stage opening, check consent for member only.
    	 if(isTwoStageOpening == 1){
    		 memberConsentcount = hibernateQueryDao.countForNewQuery("TblCommitteeUser tblCommitteeUser INNER JOIN tblCommitteeUser.tblCommittee tblCommittee", "tblCommitteeUser.committeeUserId ", "tblCommittee.tblTender.tenderId=:tenderId and tblCommitteeUser.childId=:envelopeId and tblCommittee.committeeType=1 and tblCommitteeUser.userRoleId=2 and tblCommitteeUser.isApproved=1", var);
    		 chairManConsentcount = hibernateQueryDao.countForNewQuery("TblCommitteeUser tblCommitteeUser INNER JOIN tblCommitteeUser.tblCommittee tblCommittee", "tblCommitteeUser.committeeUserId ", "tblCommittee.tblTender.tenderId=:tenderId and tblCommitteeUser.childId=:envelopeId and tblCommittee.committeeType=1 and tblCommitteeUser.userRoleId=1 and tblCommitteeUser.isApproved=1", var);
    		 return memberConsentcount != 0 && chairManConsentcount != 0;
    	 }else{
    		 // Bug #33956 By Jitendra
    		 memberConsentcount = hibernateQueryDao.countForNewQuery("TblCommitteeUser tblCommitteeUser INNER JOIN tblCommitteeUser.tblCommittee tblCommittee", "tblCommitteeUser.committeeUserId ", "tblCommittee.tblTender.tenderId=:tenderId and tblCommitteeUser.childId=:envelopeId and tblCommittee.committeeType=1 and tblCommitteeUser.isApproved=1", var);
    		 return memberConsentcount != 0;
    	 }
     }
     
     /**
      * This method is used to check whether evaluation of all tender envelop is done or not. PT : #33589.
      * @author jitendra
      * @param tenderId
      * @return
      * @throws Exception
      */
     public boolean isEvaluationDone(int tenderId)throws Exception{
    	 List<TblTenderEnvelope> envList = eventCreationService.getTblTenderEnvelopeList(tenderId);
    	 long finalSubmissionCnt = getCountofFinalSubmission(tenderId);
    	 List<Object[]> tenderDetails = tenderCommonService.getTenderFields(tenderId, "isTwoStageEvaluation,isItemwiseWinner");
    	 int isTwoStageEvaluation = 0;
    	 if(tenderDetails!= null && !tenderDetails.isEmpty()){
    		 isTwoStageEvaluation = Integer.parseInt(tenderDetails.get(0)[0].toString());
    	 }
    	 int evaluationDoneEnv = 0;
    	 if(envList.size() == 1){
    		 evaluationDoneEnv = isEnvelopeWiseEvaluationDone(tenderId,envList.get(0).getEnvelopeId(),finalSubmissionCnt);
    	 }else{
    		 int previousEnvId = 0;
    		 for(TblTenderEnvelope tenderEnvelop : envList){
    			 evaluationDoneEnv = isEnvelopeWiseEvaluationDone(tenderId,tenderEnvelop.getEnvelopeId(),finalSubmissionCnt,isTwoStageEvaluation == 1 ? -1 : previousEnvId);
    			 previousEnvId = evaluationDoneEnv == 1 ? envList.get(0).getEnvelopeId() : 0;
    		 }
    	 }
    	 return evaluationDoneEnv!=0 ? true : false; 
 	 }
     
     /**
      * This method is used to check whether any envelope is decrypted or not from all the levels. PT : #33589.
      * @author jitendra
      * @param tenderId
      * @param envelopeId
      * @return
      * @throws Exception
      */
     public boolean isEnvelopeDecrypted(int tenderId,int envelopeId) throws Exception {
         long count = 0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId", tenderId);
         count = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblfinalSubmission ", "tblfinalSubmission.finalSubmissionId ", "tblfinalSubmission.tblTender.tenderId=:tenderId and tblfinalSubmission.isActive=1", var);
         if(count > 0){
        	 var.put("envelopeId", envelopeId);
        	 count = hibernateQueryDao.countForNewQuery("TblTenderOpen tbltenderopen ", "tbltenderopen.tenderOpenId ", "tbltenderopen.tblTender.tenderId=:tenderId and tbltenderopen.tblTenderEnvelope.envelopeId=:envelopeId and decryptionLevel=1", var);
         }else{
        	 count = 1;
         }
         return count != 0;
     }
     
     /**
      * This method is used to check whether Evelopewise Evaluation done in case of consortium 
      * @author anjali
      * @param tenderId
      * @param envelopeId
      * @param finalSubmissionCnt
      * @param envelopeType
      * @return
      * @throws Exception
      */
     public Integer isEnvelopeWiseEvaluationDoneWithConsortium(int tenderId,int envelopeId,long finalSubmissionCnt,int envelopeType) throws Exception {
    	 StringBuilder query = new StringBuilder();
 		 List<Object> list = new ArrayList<Object>();
    	 Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("envelopeId",envelopeId);
         var.put("finalSubmissionCnt",finalSubmissionCnt);
         query.append("SELECT DISTINCT CASE WHEN (:finalSubmissionCnt) = ");
         query.append("(SELECT COUNT(tblBidderApprovalDetail.bidderApprovalId) FROM TblBidderApprovalDetail tblBidderApprovalDetail INNER JOIN ");
         query.append("tblBidderApprovalDetail.tblFinalSubmission tblFinalSubmission WHERE ");
         query.append("tblBidderApprovalDetail.tblTender.tenderId =:tenderId AND ");
         query.append("tblBidderApprovalDetail.tblTenderEnvelope.envelopeId =:envelopeId AND tblFinalSubmission.isActive=1 ");
         if(envelopeType == 4 || envelopeType == 5){
         query.append("AND (tblFinalSubmission.partnerType in (1 , 2 ))) ");
         }
         else {
        	 query.append("AND (tblFinalSubmission.partnerType in (1 , 2, 3 ))) "); 
         }
         query.append(" THEN 1 ELSE 0 END FROM TblFinalSubmission tblFinalSubmission");
         list = hibernateQueryDao.singleColQuery(query.toString(),var);
 		 return list.size() != 0 && !list.isEmpty() ? Integer.parseInt(list.get(0).toString()) : 0 ;
 	}
    
     /**
      * This method is used to get total count of bidderId's whose evaluation done evelopewise when consortium is applicable
      * @author anjali
      * @param tenderId
      * @param envelopeId
      * @param envelopeType
      * @return
      * @throws Exception
      */
     public long getCountofFinalSubmissionWithConsortiumEnvelopeWise(int tenderId,int envelopeId,int envelopeType) throws Exception {
 		Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("envelopeId",envelopeId);
       
    	 StringBuilder query = new StringBuilder();
    	
    	 query.append("SELECT COUNT(tblFinalSubmission.tblUserLogin.userId) FROM TblBidderApprovalDetail ");
    	 query.append("WHERE tblFinalSubmission.tblTender.tenderId=:tenderId AND tblFinalSubmission.isActive=1 AND ");
    	 if(envelopeType == 4 || envelopeType == 5){
    	 query.append("tblFinalSubmission.partnerType IN (1,2) ");
    	 }
    	 else{
    		 query.append("tblFinalSubmission.partnerType IN (1,2,3) "); 
    	 }
    	 query.append("AND tblTenderEnvelope.envelopeId=:envelopeId");
    	 
    	 List<Object> list =  hibernateQueryDao.singleColQuery(query.toString(),var);
    	 return !list.isEmpty() ? Long.parseLong(list.get(0).toString()) : 0;
 	}
     
     /**
      * Set Form/Formula GET     
      * @param formId
      * @param modelMap
      * @param tenderId
      * @throws Exception 
      */
     public void setViewFormNFormula(int formId, Map<String, Object> modelMap, int tenderId,Map<Object, Object> comboList) throws Exception {
     	List<Integer> tableIds = new ArrayList<Integer>();
         TblTenderForm tblTenderForm = getTenderFormById(formId);
         modelMap.put("tblTenderForm", tblTenderForm);
         modelMap.put("formName", tblTenderForm.getFormName());
         modelMap.put("formHeader", tblTenderForm.getFormHeader());
         modelMap.put("formFooter", tblTenderForm.getFormFooter());
         modelMap.put("noOfTables", tblTenderForm.getNoOfTables());
         modelMap.put("itemsToLoad", tblTenderForm.getLoadNoOfItems());
         modelMap.put("itemsIncremental", tblTenderForm.getIncrementItems());
         modelMap.put("encryptionReq", tblTenderForm.getIsEncryptionReq());
         modelMap.put("itemWiseDocAllowed",tblTenderForm.getIsItemWiseDocAllowed()==1?true:false);
         List<TblTenderTable> tables = getTenderTableByFormId(formId);
         if(tables.size()>0)
         	{
         		Collections.sort(tables);
         	}
         List<Object[]> visibleRows = new ArrayList<Object[]>();
         List<SelectItem> currency = null;
         Set<Integer> comboBoxs = new HashSet<Integer>();
         Set<Integer> listBoxs = new HashSet<Integer>();
         Set<Integer> masterFields = new HashSet<Integer>();
         List<Integer> formulaColId = new ArrayList<Integer>();        
         List<Integer> emdColId = new ArrayList<Integer>();
         List<Integer> emdColOfficerId = new ArrayList<Integer>();
         List<Integer> participationColOfficerId = new ArrayList<Integer>();
         List<Integer> notEncrColId = new ArrayList<Integer>(); 
         List<Integer> docColId = new ArrayList<Integer>();
         List<Integer> docColOfficerId = new ArrayList<Integer>();
         List<Integer> processColId = new ArrayList<Integer>();        
         List<Integer> emdCellId = new ArrayList<Integer>(); 
         List<Integer> docCellOfficerId = new ArrayList<Integer>(); 
         List<Integer> emdCellOfficerId = new ArrayList<Integer>();
         List<Integer> participationCellOfficerId = new ArrayList<Integer>(); 
         List<Integer> notEncrCellId = new ArrayList<Integer>();
         List<Integer> docCellId = new ArrayList<Integer>();        
         List<Integer> processCellId = new ArrayList<Integer>();        
         List<Integer> formulaColNo = new ArrayList<Integer>();
         List<Integer> negotiationLoadingCells = new ArrayList<Integer>();
         List<Integer> negotiationLoadingColumns = new ArrayList<Integer>();
         List<Map<String, Object>> tableList = new ArrayList<Map<String, Object>>();   
         Map<Integer,String> proxyData = new HashMap<Integer, String>();
         int bidId = 0;
         boolean showDownload = true;
         boolean fromBidForm = false;
         boolean frombidfactor = false;
         boolean negotiationBuyerForLoading = false;
         boolean negotiationBidderForLoading = false;
         List<TblTenderBidMatrix> bidMatrixs = null;                        
         List<TblMasterBid> masterBids = null;             
         if(modelMap.get("fromBidForm")!=null){
             fromBidForm = (Boolean)modelMap.get("fromBidForm");            
         }
         if(modelMap.get("negotiationBuyerForLoading")!=null){ 		//Start CR : 25886
         	negotiationBuyerForLoading = (Boolean)modelMap.get("negotiationBuyerForLoading");            
         }
         if(modelMap.get("negotiationBidderForLoading")!=null){
         	negotiationBidderForLoading = (Boolean)modelMap.get("negotiationBidderForLoading");            
         } //End CR : 25886
         if(modelMap.get("isItemSelectionPageRequired")!=null && (Integer) modelMap.get("isItemSelectionPageRequired")==1){
             if(tblTenderForm.getIsPriceBid()==1){
                visibleRows = getSelectedRowsForBidding(formId, (Integer) modelMap.get("companyId"));
             }else{
                 modelMap.put("isItemSelectionPageRequired", 0);
             }
         }else{            
             modelMap.put("isItemSelectionPageRequired", 0);
         }
         if(modelMap.get("bidId")!=null && (Integer)modelMap.get("bidId")!=0){
             bidId = (Integer)modelMap.get("bidId");
             bidMatrixs = getTenderBidMatrixByBidId(bidId);
         }
         if(fromBidForm && bidId==0 && tblTenderForm.getMasterFormId()!=0){
             masterBids = masterFormService.getMasterBid(tblTenderForm.getMasterFormId(),(Integer) modelMap.get("companyId"));
         }
         if(modelMap.get("frombidfactor")!=null){
             frombidfactor = (Boolean)modelMap.get("frombidfactor");            
         }
         boolean isBidRowLimited = false;
         List<Object[]> bidTableRow = null;
         //Below Condition Modified Because of bug id : #25751
         if(fromBidForm && ((Integer)modelMap.get("tenderMode")==2 || (Integer)modelMap.get("tenderMode")==3 || (Integer)modelMap.get("tenderMode")==4) && (Integer)modelMap.get("tenderResult")==2 && tblTenderForm.getIsPriceBid()==1){
             isBidRowLimited = true;
             bidTableRow = getBidderItem(tenderId, (Integer)modelMap.get("bidderId"));
         }    
         int isFillByBidder = 0;
         modelMap.put("isBidRowLimited", isBidRowLimited);
         for (TblTenderTable tenderTable : tables) {
             Map<String, Object> tableInfo = new HashMap<String, Object>();
             boolean isGTWise = tenderTable.getHasGTRow() == 1;
             List<Object[]> allFormula = getFormulaColId(tenderTable.getTableId());
             for (Object[] formula : allFormula) {
                 if (formula[2].toString().startsWith(TOTAL)) {
                     formulaColId.add((Integer) formula[0]);
                     formulaColNo.add((Integer) formula[5]);
                 }
             }            
             if(bidId!=0){
                 List<String> bidDatas = new ArrayList<String>();
                 List<String> bidTableIds = new ArrayList<String>();
                 List<Object[]> itemWiseDocs = new ArrayList<Object[]>();
                 Map<String,List<Object[]>> docMap = new HashMap<String, List<Object[]>>();
                 for (TblTenderBidMatrix tblTenderBidMatrix : bidMatrixs) {
                       if(tblTenderBidMatrix.getTblTenderTable().getTableId() == tenderTable.getTableId()){
                           bidDatas.add(tblTenderBidMatrix.getBidJson());
                           bidTableIds.add(encryptDecryptUtils.encrypt(String.valueOf(tblTenderBidMatrix.getBidTableId())));
                           itemWiseDocs = getItemWiseDocs(tblTenderBidMatrix.getBidTableId());
                           for(Object[] docs : itemWiseDocs){
                         	  List<Object[]> list = null;
                         	  if(docMap.containsKey(encryptDecryptUtils.encrypt(docs[1].toString())+"_"+docs[3].toString())){
                         		 list = docMap.get(encryptDecryptUtils.encrypt(docs[1].toString())+"_"+docs[3].toString());                        		 
                         	  }else{
                         		  list = new ArrayList<Object[]>();                        		  
                         	  }
                         	  if(list!=null){
 	                        	  list.add(docs);
 	                     		  docMap.put(encryptDecryptUtils.encrypt(docs[1].toString())+"_"+docs[3].toString(), list);
                         	  }
                           }
                       }
                 }
                 tableInfo.put("bidData", bidDatas);
                 tableInfo.put("bidTableId", bidTableIds);
                 tableInfo.put("itemWiseDocs", docMap);
             }
             List<Integer> visibleRow = new ArrayList<Integer>();
             for (Object[] rows : visibleRows) {
                 if((Integer)rows[0] == tenderTable.getTableId()){
                     visibleRow.add((Integer)rows[1]);
                 }
             }
             tableInfo.put("visibleRow", visibleRow);
             tableInfo.put("rowcount", isGTWise ? (tenderTable.getNoOfRows() - 1) : tenderTable.getNoOfRows());
             tableInfo.put("multipleFill", tenderTable.getIsMultipleFilling());
             tableInfo.put("colcount", tenderTable.getNoOfCols());
             tableInfo.put("tableName", tenderTable.getTableName());
             tableInfo.put("tableHeader", tenderTable.getTableHeader());
             tableInfo.put("tableFooter", tenderTable.getTableFooter());
             tableInfo.put(TABLEID, tenderTable.getTableId());
             tableIds.add(tenderTable.getTableId());
             tableInfo.put("formulaColId", formulaColId);
             tableInfo.put("formulaColNo", formulaColNo);
             tableInfo.put("isGTWise", isGTWise);
             tableInfo.put("formulas", allFormula);
             tableInfo.put("isPartialFillingAllowed", tenderTable.getIsPartialFillingAllowed());
             tableInfo.put("isMandatory", tenderTable.getIsMandatory());
             List<TblTenderColumn> columns = getTenderColumnByTableId(tenderTable.getTableId());
             boolean isCurrency = false;
             boolean hasProxyCol = false;
             List<Integer> dateColSortNo = new ArrayList<Integer>();
             StringBuilder colFilledBy = new StringBuilder();
             for (TblTenderColumn tblTenderColumn : columns) {
 	            	if(negotiationBuyerForLoading==true || negotiationBidderForLoading==true) //For Negotiation Loading Factor Condition  //Start CR : 25886
 	            	{
 	            		if(tblTenderColumn.getTblColumnType().getColumnTypeId()==23 || tblTenderColumn.getTblColumnType().getColumnTypeId()==26 || tblTenderColumn.getTblColumnType().getColumnTypeId()==27){
 	            			tblTenderColumn.setIsShown(1);
 	            			if(negotiationBidderForLoading==true){
 	                			negotiationLoadingColumns.add(tblTenderColumn.getColumnId());
 	                		}
 	            		}
 	            		tableInfo.put("negotiationLoadingColumns", negotiationLoadingColumns);
 	            	}
 	            	 //End CR : 25886
                 colFilledBy.append("'").append(tblTenderColumn.getColumnNo()).append("@@").append(tblTenderColumn.getFilledBy()).append("_").append(tblTenderColumn.getTblColumnType().getColumnTypeId()).append("_").append(tblTenderColumn.getIsShown()).append("'").append(",");
                 if (tblTenderColumn.getTblColumnType().getColumnTypeId() == 8) {
                     isCurrency = true;                    
                 }
//                 for (Integer columnId : formulaColId) {
                     if (tblTenderColumn.getTblColumnType().getColumnTypeId() == processingFeesId) {
                         processColId.add(tblTenderColumn.getColumnId());
                     }            
                     if (tblTenderColumn.getTblColumnType().getColumnTypeId() == documentFeesId) {
                         docColId.add(tblTenderColumn.getColumnId());
                         isFillByBidder=1;
                     }
                     if (tblTenderColumn.getTblColumnType().getColumnTypeId() == documentFeesByOfficerId) {
                         docColOfficerId.add(tblTenderColumn.getColumnId());
                         isFillByBidder=2;
                     }  
                     if (tblTenderColumn.getTblColumnType().getColumnTypeId() == emdAmountId) {
                         emdColId.add(tblTenderColumn.getColumnId());
                         isFillByBidder=1;
                     }
                     if (tblTenderColumn.getTblColumnType().getColumnTypeId() == emdAmountByOfficerId) {
                         emdColOfficerId.add(tblTenderColumn.getColumnId());
                         isFillByBidder=2;
                     }
                     if (tblTenderColumn.getTblColumnType().getColumnTypeId() == participationFeesByOfficerId) {
                     	participationColOfficerId.add(tblTenderColumn.getColumnId());
                         isFillByBidder=2;
                     }
                     
                     if (tblTenderColumn.getTblColumnType().getColumnTypeId() == notEncrReqId) {
                         notEncrColId.add(tblTenderColumn.getColumnId());
                     }
                     
                     if (tblTenderColumn.getTblColumnType().getColumnTypeId() == loadingFactor && tblTenderColumn.getFilledBy() == 4) {
                     	if(modelMap.containsKey("loadingFactorForm"))
                     	{
                     		Map<Object,Object> loadingFactorForm = (Map<Object, Object>) modelMap.get("loadingFactorForm");
                     		loadingFactorForm.put(tblTenderColumn.getTblTenderForm().getFormId(), tblTenderColumn.getTblTenderForm().getFormId());
                     	}else{
                     		Map<Object,Object> loadingFactorForm = new HashMap<Object, Object>();
                     		loadingFactorForm.put(tblTenderColumn.getTblTenderForm().getFormId(), tblTenderColumn.getTblTenderForm().getFormId());
                     		modelMap.put("loadingFactorForm",loadingFactorForm);
                     	}
                     	if(modelMap.containsKey("loadingFactorTable"))
                     	{
                     		Map<Object,Object> loadingFactorTable= (Map<Object, Object>) modelMap.get("loadingFactorTable");
                     		loadingFactorTable.put(tblTenderColumn.getTblTenderTable().getTableId(), tblTenderColumn.getTblTenderTable().getTableId());
                     	}else{
                     		Map<Object,Object> loadingFactorTable = new HashMap<Object, Object>();
                     		loadingFactorTable.put(tblTenderColumn.getTblTenderTable().getTableId(), tblTenderColumn.getTblTenderTable().getTableId());
                     		modelMap.put("loadingFactorTable",loadingFactorTable);
                     	}
                     }
//                 }
                 if (tblTenderColumn.getFilledBy() == proxy) {
                     hasProxyCol = true;                    
                 }
                 if((isFillByBidder==1 ||  isFillByBidder == 2) && modelMap.get("companyId")!=null ){
                 	List <TblEventFees> lstTenderFees= new ArrayList<TblEventFees>();
                 	if(bidId!=0){
                 		lstTenderFees = getTenderFeesPaymentDetail(tenderId,(Integer)modelMap.get("companyId"),formId, tblTenderColumn.getTblTenderTable().getTableId(),-1, bidId,0);
                 	}else{
                     		lstTenderFees = getTenderFeesPaymentDetail(tenderId,(Integer)modelMap.get("companyId"),formId, tblTenderColumn.getTblTenderTable().getTableId(),-1, 0,0);	
                 	}
                 		if(lstTenderFees!=null && !lstTenderFees.isEmpty()  ){
             			  Map<String,Integer> rowId = new HashMap<String,Integer>();
 	            			for (TblEventFees tblTenderFees :lstTenderFees){
 	            					rowId.put(tblTenderFees.getRowId()+"_"+tblTenderFees.getFeeType(),tblTenderFees.getFeeType());
 	            			}
 	            			modelMap.put("rowId",rowId);
             			}
             		}
                 if(tblTenderColumn.getDataType() == 7) {
                 	dateColSortNo.add(tblTenderColumn.getSortOrder());
                 }
             }
             tableInfo.put("dateColSortNo", dateColSortNo);
             if (colFilledBy.length() != 0) {
                 tableInfo.put("colFilledBy", colFilledBy.delete(colFilledBy.length() - 1, colFilledBy.length()));                
                 //System.out.println(tableInfo.get("colFilledBy"));
             }
             if(hasProxyCol && (fromBidForm || frombidfactor)){
                 List<Object[]> proxyColData = getProxyCellData(tenderTable.getTableId(), (Integer)modelMap.get("companyId"));                                
                 JSONArray jSONArray = new JSONArray();        
                 for (int i=0;i<proxyColData.size();i++) {
                     Object[] proxyD = proxyColData.get(i);
                     JSONObject jSONObject = new JSONObject();
                     jSONObject.put(proxyD[0].toString(),proxyD[1].toString());
                     if(frombidfactor){
                         proxyData.put((Integer)proxyD[0], proxyD[1].toString());
                     }
                     jSONArray.put(i, jSONObject);
                 }
                 tableInfo.put("proxyData", jSONArray.toString());
                 tableInfo.put("cellValueProxyData",proxyData); //For NegotiationHistory  //Start CR : 25886
             }
             if (isCurrency) {
                 showDownload=false;
                 if(currency==null){                    
                     currency = fromBidForm ? abcUtility.convert(getBidderCurrency(tenderId, (Integer)modelMap.get("companyId"))) : abcUtility.convertSelected(getTenderCurrency(tenderId));
                 }
                 tableInfo.put("tenderCurrency", currency);
             }
             tableInfo.put("columns", columns);
             if (!columns.isEmpty()) {
//                     List<TblTenderCell> cells = getCellMasterByTableId(tenderTable.getTableId(), isGTWise ? (rowCount) : 0);
                 String tableJson = getTableJson(tenderTable.getTableId());                
                 tableInfo.put("tableJson", tableJson);
                 List<TblTenderCell> cells = _toCellMasters(tableJson);
                 List<TblTenderCell> bidcells = new ArrayList<TblTenderCell>();
                 Set<Integer>  bidderRow = new TreeSet<Integer>();                                
                 for (TblTenderCell tenderCell : cells) {
                 	
                 	if(negotiationBidderForLoading==true) //For Negotiation Loading Factor Condition  Start CR : 25886
                 	{
                 		for(Integer column :negotiationLoadingColumns){
                 			if(column==tenderCell.getTblTenderColumn().getColumnId()){
                 				negotiationLoadingCells.add(tenderCell.getCellId());
                 			}
                 		}
                 		tableInfo.put("negotiationLoadingCells", negotiationLoadingCells);
                 	}  //End CR : 25886
                 	if(isBidRowLimited && bidTableRow!=null){
                         for (Object[] bidcell: bidTableRow) {
                             if((Integer)bidcell[0] == tenderTable.getTableId() && (Integer)bidcell[1] == tenderCell.getRowId()){                                
                                 bidderRow.add(tenderCell.getRowId());
                                 bidcells.add(tenderCell);
                             }
                         }
                         if(isGTWise && tenderTable.getNoOfRows() == tenderCell.getRowId()){
                             bidderRow.add(tenderCell.getRowId());
                             bidcells.add(tenderCell);
                         }
                     }
                     if(tenderCell.getDataType()==combobox){
                         comboBoxs.add(tenderCell.getObjectId());
                     }else if(tenderCell.getDataType()==masterField){                        
                         masterFields.add(tenderCell.getObjectId());
                     }else if(tenderCell.getDataType()==listBox){                        
                         listBoxs.add(tenderCell.getObjectId());
                     }
                     for (Integer emd : emdColId) {
                         boolean gotGTCell = false;
                         if(formulaColId.contains(emd) && tenderCell.getTblTenderColumn().getColumnId() == emd) {
                             if(tenderCell.getDataType()==0){
                                 emdCellId.add(tenderCell.getCellId());
                             }
                             gotGTCell=true;
                         }
                         if(!gotGTCell){
                             if(tenderCell.getTblTenderColumn().getColumnId() == emd){
                                 emdCellId.add(tenderCell.getCellId());
                             }
                         }
                     }
                     for (Integer emd : emdColOfficerId) {
                         boolean gotGTCell = false;
                         if(formulaColId.contains(emd) && tenderCell.getTblTenderColumn().getColumnId() == emd) {
                             if(tenderCell.getDataType()==0){
                                 emdCellOfficerId.add(tenderCell.getCellId());
                             }
                             gotGTCell=true;
                         }
                         if(!gotGTCell){
                             if(tenderCell.getTblTenderColumn().getColumnId() == emd){
                             	emdCellOfficerId.add(tenderCell.getCellId());
                             }
                         }
                     }
                     for (Integer participation : participationColOfficerId) {
                         boolean gotGTCell = false;
                         if(formulaColId.contains(participation) && tenderCell.getTblTenderColumn().getColumnId() == participation) {
                             if(tenderCell.getDataType()==0){
                                 participationCellOfficerId.add(tenderCell.getCellId());
                             }
                             gotGTCell=true;
                         }
                         if(!gotGTCell){
                             if(tenderCell.getTblTenderColumn().getColumnId() == participation){
                             	participationCellOfficerId.add(tenderCell.getCellId());
                             }
                         }
                     }
                     
                     for (Integer doc : docColId) {
                         boolean gotGTCell = false;
                         if(formulaColId.contains(doc) && tenderCell.getTblTenderColumn().getColumnId() == doc) {
                             if(tenderCell.getDataType()==0){
                                 docCellId.add(tenderCell.getCellId());
                             }
                             gotGTCell=true;
                         }
                         if(!gotGTCell){
                             if(tenderCell.getTblTenderColumn().getColumnId() == doc){
                                 docCellId.add(tenderCell.getCellId());
                             }
                         }
                     }
                     for (Integer doc : docColOfficerId) {
                         boolean gotGTCell = false;
                         if(formulaColId.contains(doc) && tenderCell.getTblTenderColumn().getColumnId() == doc) {
                             if(tenderCell.getDataType()==0){
                                 docCellOfficerId.add(tenderCell.getCellId());
                             }
                             gotGTCell=true;
                         }
                         if(!gotGTCell){
                             if(tenderCell.getTblTenderColumn().getColumnId() == doc){
                             	docCellOfficerId.add(tenderCell.getCellId());
                             }
                         }
                     }
                     
                     for (Integer process : processColId) {
                         boolean gotGTCell = false;
                         if(formulaColId.contains(process) && tenderCell.getTblTenderColumn().getColumnId() == process) {
                             if(tenderCell.getDataType()==0){                                
                                 processCellId.add(tenderCell.getCellId());
                             }
                             gotGTCell=true;
                         }
                         if(!gotGTCell){
                             if(tenderCell.getTblTenderColumn().getColumnId() == process){
                                 processCellId.add(tenderCell.getCellId());
                             }
                         }
                     }
                     for (Integer nonEnc : notEncrColId) {
                         if(tenderCell.getTblTenderColumn().getColumnId() == nonEnc) {
                              notEncrCellId.add(tenderCell.getCellId());
                         }
                     }
                 }
                 Object[] bd =  bidderRow.toArray();
                 Set<Integer>  bidderRowFinal = new TreeSet<Integer>();                
                 for (int i = 0; i < bd.length; i++) {
                     if(i>=tblTenderForm.getLoadNoOfItems()){
                         bidderRowFinal.add((Integer)bd[i]);
                     }                    
                 }
                 tableInfo.put("bidderRow", bidderRowFinal);                
                 tableInfo.put("emdCellId", emdCellId);
                 tableInfo.put("notEncrCellId", notEncrCellId);
                 tableInfo.put("docCellId", docCellId);
                 tableInfo.put("processCellId", processCellId);
                 tableInfo.put("emdCellOfficerId", emdCellOfficerId);
                 tableInfo.put("participationCellOfficerId", participationCellOfficerId);
                 tableInfo.put("docCellOfficerId", docCellOfficerId);
                 if(isBidRowLimited){                    
                     int bidCellCnt=0;
                     for (Object[] bidcell: bidTableRow) {
                         if((Integer)bidcell[0] == tenderTable.getTableId()){
                                bidCellCnt++;
                         }
                     }    
                     tableInfo.put("rowcount", bidCellCnt);//todo
                     tableInfo.put("cells", bidcells);
                 }else{                    
                     tableInfo.put("cells", cells);
                 }
             }
             if(fromBidForm && bidId==0 && tblTenderForm.getMasterFormId()!=0){
                 List<String> bidDatas = new ArrayList<String>();
                 for (TblMasterBid masterBid : masterBids) {
                     if (masterBid.getTblTableMaster().getSortOrder() == tenderTable.getSortOrder()) {                        
                         bidDatas.add(replaceCellId(masterBid.getBidJson(),tableInfo.get("tableJson").toString()));
//                         System.out.println(replaceCellId(masterBid.getBidJson(),tableInfo.get("tableJson").toString()));
                     }
                 }
                 tableInfo.put("bidData", bidDatas);
                 if(!bidDatas.isEmpty()){
                     modelMap.put("masterbid", true);
                 }
             }
             tableList.add(tableInfo);
         }
         if(!comboBoxs.isEmpty()){    
         	comboList.put("Combo_"+formId, getComboDetailByComboId(comboBoxs.toArray()));
         }
         if(!proxyData.isEmpty()){            
             modelMap.put("proxyData", proxyData);
         }
         if(!listBoxs.isEmpty()){
             showDownload=false;
             comboList.put("List_"+formId, getComboDetailByComboId(listBoxs.toArray()));
         }
         if(!masterFields.isEmpty()){
             showDownload=false;
             HttpServletRequest request = getServletRequest();            
             modelMap.put("masterFieldList", getBidderMasterFieldValue(abcUtility.getSessionUserId(request),masterFields.toArray(),bidderMasterField)); 
         }
         // BPCL - doc upload/download for Tech Env - start
         if(tblTenderForm.getIsPriceBid()==0 && !tableIds.isEmpty()){
         	List<Object[]> lstDocumentDetails = fileUploadService.getOfficerDocs(tableIds, abcUtility.getSessionClientId(getServletRequest()), 183, 1);
         	if(lstDocumentDetails!=null && !lstDocumentDetails.isEmpty()){
         		modelMap.put("isItemWiseDocAvail", true);
                 Map<String, List<Object[]>> docsMaps = new HashMap<String, List<Object[]>>();
             	for(Object[] objDocs : lstDocumentDetails){
             		List<Object[]> lstDocs = null;
             		if(docsMaps.containsKey(objDocs[1].toString()+"_"+objDocs[3].toString())){
             			lstDocs = docsMaps.get(objDocs[1].toString()+"_"+objDocs[3].toString()); 
             		}else{
             			lstDocs = new ArrayList<Object[]>();
             		}
             		lstDocs.add(objDocs);
             		docsMaps.put(objDocs[1].toString()+"_"+objDocs[3].toString(), lstDocs);
             	}
             	modelMap.put("listOfDocs", docsMaps);
         	}
         	else{
         		modelMap.put("isItemWiseDocAvail", false);
         	}
         }
         //BPCL - doc upload/download for Tech Env - End
         modelMap.put("showDownload", showDownload);
         modelMap.put("tableList", tableList);
         modelMap.put("isFillByBidder",isFillByBidder);
     }
     /**
      * @author meghna
      * @param tenderId
      * @param committeeType
      * @return
      * @throws Exception
      */
     public int getLatestCommitteeId(int tenderId, int committeeType) throws Exception {
     	int committeeId = 0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId", tenderId);
         var.put("committeeType", committeeType);
         List<Object[]> list = hibernateQueryDao.createSQLQuery("SELECT top 1 tblCommittee.committeeId,tblCommittee.tenderId FROM apptender.tbl_committee tblCommittee WHERE tblCommittee.tenderId=:tenderId AND tblCommittee.committeeType=:committeeType order by tblCommittee.committeeId desc", var);
         if(list!=null && !list.isEmpty()){
         	committeeId = Integer.parseInt(list.get(0)[0].toString());
         }
         return committeeId;
     }
     
     /**
      * This method is used to get only that FormId and FormName of Price Bid Form for which bidder has done bidding
      * @author anjali
      * @param tenderId
      * @param bidderId
      * @param envelopeId
      * @throws Exception 
      */
     public List<Object[]> getFormByTenderIdBidderIdEnvelopeId(int tenderId,int bidderId,int envelopeId) throws Exception{
         StringBuilder query = new StringBuilder();
    	 	Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("bidderId",bidderId);
         var.put("envelopeId",envelopeId);
         
         query.append("SELECT formId,formName FROM TblTenderForm ")
         	.append("WHERE cstatus = 1 AND isPriceBid = 1 AND formId IN")
            .append("(SELECT tblTenderForm.formId FROM TblTenderBid WHERE tblTender.tenderId=:tenderId AND ")
            .append("tblUserLogin.userId=:bidderId AND tblTenderEnvelope.envelopeId=:envelopeId AND cstatus = 2)");
         return hibernateQueryDao.createNewQuery(query.toString(),var);
     }
     
     /**
      * This method is used to fetch table rowIds which is mapped to particular bidder.  For Bug : #32568.
      * @param tenderId
      * @param userId
      * @param tableId
      * @return
      * @throws Exception
      */
     public List<Object> getBidderMappedRows(int tenderId,int userId, int tableId) throws Exception{
         List<Object> list = null;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("userId",userId);
         var.put("tableId",tableId);
         list = hibernateQueryDao.singleColQuery("select tblitembiddermap.rowId from TblItemBidderMap tblitembiddermap inner join tblitembiddermap.tblTenderBidderMap tbltenderbiddermap where tbltenderbiddermap.tblTender.tenderId=:tenderId and tbltenderbiddermap.tblUserLogin.userId=:userId and tblitembiddermap.tblTenderTable.tableId=:tableId",var);                
         return list;        
     }
     
     /**
     *
     * @author anjali
     * @param tenderId
     * @return
     * @throws Exception
     */
    public List<Object[]> getTenderEnvelopePriceBidFormCount(int tenderId) throws Exception {
        StringBuilder query = new StringBuilder();
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        query.append("select count(tbltenderform.formId),tbltenderform.tblTenderEnvelope.envelopeId")
                .append(" from TblTenderForm tbltenderform where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus!=2 and tbltenderform.isPriceBid=1 and tbltenderform.tblTenderEnvelope.tblEnvelope.envId=5 group by tbltenderform.tblTenderEnvelope.envelopeId");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
   
    /**
    *
    * @author anjali
    * @param tenderId
    * @return
    * @throws Exception
    */
   public List<Object[]> getTenderEnvelopeTechnicalFormCount(int tenderId) throws Exception {
       StringBuilder query = new StringBuilder();
       Map<String, Object> var = new HashMap<String, Object>();
       var.put("tenderId", tenderId);
       query.append("select count(tbltenderform.formId),tbltenderform.tblTenderEnvelope.envelopeId")
               .append(" from TblTenderForm tbltenderform where tbltenderform.tblTender.tenderId=:tenderId and tbltenderform.cstatus!=2 and tbltenderform.isPriceBid=0 and tbltenderform.tblTenderEnvelope.tblEnvelope.envId=5 group by tbltenderform.tblTenderEnvelope.envelopeId");
       return hibernateQueryDao.createNewQuery(query.toString(), var);
   }
   
   /**
    * This method is used to get envelopeId based tenderId & envId. PT : #38138.
    * @author jitendra
    * @param tenderId
    * @param envId
    * @return
    * @throws Exception
    */
   	public int getEnvelopeIdByTenderIdAndEnvId(int tenderId, int envId) throws Exception {
   		int envelopeId = 0;
   		List<Object> list = null;
    	Map<String, Object> var = new HashMap<String, Object>();
    	var.put("tenderId",tenderId);
    	var.put("envId", envId);
    	list = hibernateQueryDao.getSingleColQuery("select tblTenderEnvelope.envelopeId from TblTenderEnvelope tblTenderEnvelope WHERE tblTenderEnvelope.tblTender.tenderId=:tenderId and tblTenderEnvelope.tblEnvelope.envId=:envId",var);                   	
    	envelopeId = (list!=null && !list.isEmpty()) ? Integer.parseInt(list.get(0).toString()) : 0;
    	return envelopeId;
   	}
   
   	/**
   	 * This method is used to check whether form exist for given envelope. PT : #38138.
   	 * @param tenderId
   	 * @param envelopeId
   	 * @return
   	 * @throws Exception
   	 */
   	public boolean checkFormExist(int tenderId, int envelopeId) throws Exception {
   		long count = 0;
	    Map<String, Object> var = new HashMap<String, Object>();
	    var.put("tenderId", tenderId);
	    var.put("envelopeId", envelopeId);
	    count = hibernateQueryDao.countForNewQuery("TblTenderForm tblTenderForm ", "tblTenderForm.formId ", "tblTenderForm.tblTender.tenderId=:tenderId and tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId", var);
	    return count!=0;
   	}
   	
   	/**
   	 * It is used to get price bid formId. PT : #38138.
   	 * @param tenderId
   	 * @param envelopeId
   	 * @return
   	 */
   	public int getPriceBidFormId(int tenderId, int envelopeId) {
   		int formId = 0;
   		List<Object> list = null;
   		Map<String, Object> var = new HashMap<String, Object>();
    	var.put("tenderId",tenderId);
    	var.put("envelopeId", envelopeId);
    	list = hibernateQueryDao.getSingleColQuery("SELECT tblTenderForm.formId FROM TblTenderForm tblTenderForm WHERE tblTenderForm.tblTender.tenderId=:tenderId and tblTenderForm.tblTenderEnvelope.envelopeId=:envelopeId and tblTenderForm.isPriceBid=1", var);
    	formId = (list!=null && !list.isEmpty()) ? Integer.parseInt(list.get(0).toString()) : 0;
    	return formId;
   	}
   	
   	/**
   	 * This method is used to get price summary details. PT : #38138.
   	 * @param formId
   	 * @return
   	 * @throws Exception
   	 */
   	public List<Object[]> getPriceSummaryDetails(int formId) throws Exception {
   		List<Object[]> list = null;
   		StringBuilder query = new StringBuilder();
   		Map<String, Object> var = new HashMap<String, Object>();
   		var.put("formId", formId);
   		query.append("select TCC.columnTypeId as c0, R.reportName as c1, R.isRebateForm as c2 from apptender.tbl_Rebate R ");
   		query.append("INNER JOIN apptender.tbl_RebateForm RF ON R.rebateId=RF.rebateId and RF.formId=:formId ");
   		query.append("INNER JOIN apptender.tbl_TenderTable TT ON RF.formId=TT.formId ");
   		query.append("INNER JOIN apptender.tbl_TenderCell TC ON TT.tableId=TC.tableId and dataType=0 and TC.cellId=RF.cellId ");
   		query.append("INNER JOIN apptender.tbl_TenderColumn TCC ON TCC.columnId=TC.columnId");
   		int nVarCharColumnIndex [] = {1};
   		list = hibernateQueryDao.createSQLQuery(query.toString(), var, nVarCharColumnIndex, 3);
   		return list;
   	}
   	
   	/**
   	 * This method is used to get cell details for price summary. PT : #38138.
   	 * @param formId
   	 * @param columnTypeId
   	 * @return
   	 * @throws Exception
   	 */
   	public List<Object[]> getPriceSumaryCellDetails(int formId, int columnTypeId) throws Exception {
   		List<Object[]> list = null;
   		StringBuilder query = new StringBuilder();
   		Map<String, Object> var = new HashMap<String, Object>();
   		var.put("formId", formId);
   		var.put("columnTypeId", columnTypeId);
   		query.append("SELECT TCC.columnId, TCC.columnNo, TC.cellId from apptender.tbl_TenderColumn TCC ");
   		query.append("INNER JOIN apptender.tbl_TenderCell TC ON TCC.tableId=TC.tableId and TCC.columnTypeId=:columnTypeId ");
   		query.append("and TCC.formId=TC.formId and TC.columnId = TCC.columnId and TCC.formId=:formId and TC.dataType=0");
   		list = hibernateQueryDao.createSQLQuery(query.toString(), var);
   		return list;
   	}
   	
   	/**
   	 * It is used to get column type for governing column. PT : #38138.
   	 * @param formId
   	 * @return
   	 * @throws Exception
   	 */
   	public List<Object[]> getColumnTypeForGovColumn(int formId) throws Exception {
   		List<Object[]> list = null;
   		StringBuilder query = new StringBuilder();
   		Map<String, Object> var = new HashMap<String, Object>();
   		var.put("formId", formId);
   		query.append("select TC.formId, TC.columnTypeId from apptender.tbl_TenderGovColumn TGC ");
   		query.append("INNER JOIN apptender.tbl_TenderTable TT ON TT.tableId=TGC.tableId and TT.formId=TGC.formId and TGC.formId=:formId ");
   		query.append("INNER JOIN apptender.tbl_TenderColumn TC ON TT.tableId=TC.tableId and TGC.columnId=TC.columnId");
   		list = hibernateQueryDao.createSQLQuery(query.toString(), var);
   		return list;
   	}
   	
   	/**
   	 * It is used to get governing column details. PT : #38138.
   	 * @param formId
   	 * @param columnTypeId
   	 * @return
   	 * @throws Exception
   	 */
   	public List<Object[]> getGovColumnDetails(int formId, int columnTypeId) throws Exception {
   		List<Object[]> list = null;
   		StringBuilder query = new StringBuilder();
   		Map<String, Object> var = new HashMap<String, Object>();
   		var.put("formId", formId);
   		var.put("columnTypeId", columnTypeId);
   		query.append("select tableId, columnId, columnNo from apptender.tbl_TenderColumn where columnTypeId=:columnTypeId and formId=:formId");
   		list = hibernateQueryDao.createSQLQuery(query.toString(), var);
   		return list;
   	}
   	
   	
   	
   	/**
   	 * @author vivek.rajyaguru
   	 * @param tenderId
   	 * @return
   	 */
   	public int checkHasTenderGovColumn(int tenderId) throws Exception {        
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        List<Object> list = hibernateQueryDao.singleColQuery("select tblTenderGovColumn.govColumnId from TblTenderGovColumn tblTenderGovColumn where  tblTenderGovColumn.tblTender.tenderId=:tenderId", var);
        return list.isEmpty() ? -1 : (Integer)list.get(0);
    }
   	
   	
   	/**
   	 * @author vivek.rajyaguru
   	 * @param tenderId
   	 * @return
   	 * @throws Exception
   	 */
   	public int compareTenderSorAndTenderFormCounts(int tenderId)throws Exception{
   		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder query = new StringBuilder();
        query.append(" SELECT CASE WHEN COUNT(distinct TS.tblTenderForm.formId)=0 THEN 0 ELSE CASE WHEN COUNT(distinct TS.tblTenderForm.formId)=COUNT(distinct TF.formId) THEN 1 ELSE 0 END END ");
        query.append(" FROM TblTender TT INNER JOIN TT.tblTenderForm TF with TF.isPriceBid=1 and TF.cstatus=1 and TF.isMandatory=1 LEFT JOIN TF.tblTenderSOR TS where  TT.tenderId=:tenderId ");
        List<Object> list = hibernateQueryDao.singleColQuery(query.toString(), var);
        return list.isEmpty() ? 0 : (Integer)list.get(0);
   	}
   	
   	/**
   	 * It is used to fetch bidded rows. PT : #51983
   	 * @author jitendra
   	 * @param tableId
   	 * @return
   	 * @throws Exception
   	 */
   	public List<Object[]> getBiddedRowDetails(int tableId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId",tableId);
        return hibernateQueryDao.createNewQuery("select tblitemselection.tblTenderTable.tableId, tblitemselection.rowId from TblItemSelection tblitemselection where tblitemselection.tblTenderTable.tableId=:tableId and tblitemselection.isSelected=1 and tblitemselection.isBidded=1",var);                
    }
   	
   	public boolean verifyEncryptBidMatrix(int bidId, int formId) throws Exception {
		boolean verify = false;
		List<TblTenderBidMatrix> bidMatrixs = null;
		if (bidId != 0) {
			bidMatrixs = getTenderBidMatrixByBidId(bidId);
			List<TblTenderTable> tables = getTenderTableByFormId(formId);
			Map<String, Object> tableInfo = new HashMap<String, Object>();
			for (TblTenderTable tenderTable : tables) {
				getDetailEncryptBidMatrix(bidMatrixs, tenderTable, bidId, tableInfo);
			}
			if (!bidMatrixs.isEmpty())
				verify = true;
		}
		System.out.println(verify);
		return verify;
	}
   	
   	public void getDetailEncryptBidMatrix(List<TblTenderBidMatrix> bidMatrixs, TblTenderTable tenderTable, int bidId,
			Map<String, Object> tableInfo) {
		if (bidId != 0) {
			List<String> bidDatas = new ArrayList<String>();
			List<String> bidTableIds = new ArrayList<String>();
			List<Object[]> itemWiseDocs = new ArrayList<Object[]>();
			Map<String, List<Object[]>> docMap = new HashMap<String, List<Object[]>>();
			for (TblTenderBidMatrix tblTenderBidMatrix : bidMatrixs) {
				if (tblTenderBidMatrix.getTblTenderTable().getTableId() == tenderTable.getTableId()) {
					bidDatas.add(tblTenderBidMatrix.getBidJson());
					bidTableIds.add(encryptDecryptUtils.encrypt(String.valueOf(tblTenderBidMatrix.getBidTableId())));
					itemWiseDocs = getItemWiseDocs(tblTenderBidMatrix.getBidTableId());
					for (Object[] docs : itemWiseDocs) {
						List<Object[]> list = null;
						if (docMap.containsKey(
								encryptDecryptUtils.encrypt(docs[1].toString()) + "_" + docs[3].toString())) {
							list = docMap
									.get(encryptDecryptUtils.encrypt(docs[1].toString()) + "_" + docs[3].toString());
						} else {
							list = new ArrayList<Object[]>();
						}
						if (list != null) {
							list.add(docs);
							docMap.put(encryptDecryptUtils.encrypt(docs[1].toString()) + "_" + docs[3].toString(),
									list);
						}
					}
				}
			}
			tableInfo.put("bidData", bidDatas);
			tableInfo.put("bidTableId", bidTableIds);
			tableInfo.put("itemWiseDocs", docMap);
		}
	}
	
	 public String getEncodedName(int tenderId,int bidderId) throws Exception {
        String data = null;
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("bidderId", bidderId);
        list = hibernateQueryDao.getSingleColQuery("select encodedName from TblTenderBidConfirmation where tblTender.tenderId=:tenderId and tblUserLogin.userId=:bidderId", var);
        if (!list.isEmpty()) {
            data = list.get(0).toString();
        }
        return data;
    }
   	
   	/**
     * Project Task #55777 
     * Use to add or remove Form from user's my library 
     * @author Hardik Gohil
     * @param userId
     * @param formId
     * @param isLibraryForm
     * @return boolean
     * @throws Exception 
     */
    public boolean addFormToMyLibrary(int userId,int formId,int isLibraryForm) throws Exception{
    	boolean success= false;
    	List<TblTenderFormLibrary> tblTenderFormLibraryList=tblTenderFormLibraryDao.findTblTenderFormLibrary("tblUserLogin.userId",Operation_enum.EQ,userId,"tblTenderForm.formId",Operation_enum.EQ,formId);
    	if(tblTenderFormLibraryList!=null && tblTenderFormLibraryList.size()!=0) {
    		TblTenderFormLibrary tblTenderFormLibrary =tblTenderFormLibraryList.get(0);
    		tblTenderFormLibrary.setIsLibraryForm(isLibraryForm);
    		tblTenderFormLibrary.setUpdatedOn(commonService.getServerDateTime());
    		tblTenderFormLibraryDao.updateTblTenderFormLibrary(tblTenderFormLibrary);
    		success=true;
    	}else {
    		TblTenderFormLibrary tblTenderFormLibrary =new TblTenderFormLibrary();
    		tblTenderFormLibrary.setIsLibraryForm(isLibraryForm);
    		tblTenderFormLibrary.setTblUserLogin(new TblUserLogin(userId));
    		tblTenderFormLibrary.setTblTenderForm(new TblTenderForm(formId));
    		tblTenderFormLibraryDao.addTblTenderFormLibrary(tblTenderFormLibrary);
    		success=true;
    	}
    	return success;
    }
    
    /**
     * Project Task #55777 
     * Use to delete Form TblTenderFormLibrary  
     * @author Hardik Gohil
     * @param formId
     * @return boolean
     * @throws Exception 
     */
    public boolean deleteTblTenderFormLibrary(int formId) throws Exception{
    	boolean success= false;
    	List<TblTenderFormLibrary> tblTenderFormLibraryList=tblTenderFormLibraryDao.findTblTenderFormLibrary("tblTenderForm.formId",Operation_enum.EQ,formId);
    	if(tblTenderFormLibraryList!=null && tblTenderFormLibraryList.size()!=0) {
    		tblTenderFormLibraryDao.deleteAllTblTenderFormLibrary(tblTenderFormLibraryList);
    	}
    	success= true;
    	return success;
    }
	
	
	 
	 
	 public List<TblTenderTable> getTblTenderTables(Object[] tables) throws Exception{
		 return tblTenderTableDao.findTblTenderTable("tableId",Operation_enum.IN,tables);
	 }

	public List<Object[]> getCorrigendumDetailByObjectId(int objectId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("objectId", objectId);
		return hibernateQueryDao.createNewQuery("select objectId,oldValue,newValue,fieldName,actionType,tblProcess.processId from TblCorrigendumDetail tblcorrigendumdetail where tblcorrigendumdetail.objectId=:objectId and tblcorrigendumdetail.tblProcess.processId in (3) and tblcorrigendumdetail.actionType in (2) order by tblcorrigendumdetail.corrigendumDetailId asc", var);
	}

	public List<Object[]> getInviteRowsForBidder(int tenderId, int companyId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("objectId", tenderId);
        var.put("companyId", companyId);
		return hibernateQueryDao.createNewQuery("select tblNegotiationDetail.tableId,tblNegotiationDetail.rowId from TblNegotiationDetail tblNegotiationDetail  where tblNegotiationDetail.tblNegotiation.objectId=:objectId and tblNegotiationDetail.tblNegotiation.tblCompany.companyId=:companyId",var);
	}
	
    public Map<String, Object> getDateColumnNoRowNoByFormId(int formId) throws Exception {
	    Map<String, Object> var = new HashMap<String, Object>(); 
        var.put("formId", formId);
	    StringBuilder query = new StringBuilder();
	    query.append(" SELECT DISTINCT TC.tableId,TC.columnNo, TCell.rowId");
        query.append(" FROM apptender.tbl_TenderCell TCell");
        query.append(" INNER JOIN apptender.tbl_TenderColumn TC ON TC.columnId=TCell.columnId");
        query.append(" WHERE TCell.formId=:formId AND TCell.dataType=7");
        List<Object[]> dataCellList = hibernateQueryDao.createSQLQuery(query.toString(),var);
        Map<String, Object> dateCellsMap = new HashMap<String, Object>();
        if((dataCellList!=null && !dataCellList.isEmpty())){
        	for (Object[] cellObj : dataCellList) {
        		dateCellsMap.put(cellObj[0].toString() + "_" + cellObj[1].toString() + "_" + cellObj[2].toString(), true);
    		}
        }
        return dateCellsMap;
	}
}
