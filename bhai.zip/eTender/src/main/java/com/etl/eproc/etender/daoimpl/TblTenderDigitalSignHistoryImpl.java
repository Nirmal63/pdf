package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderDigitalSignHistoryDao;
import com.etl.eproc.etender.model.TblTenderDigitalSignHistory;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderDigitalSignHistoryImpl extends AbcAbstractClass<TblTenderDigitalSignHistory> implements TblTenderDigitalSignHistoryDao {

    @Override
    public void addTblTenderDigitalSignHistory(TblTenderDigitalSignHistory tblTenderDigitalSignHistory){
        super.addEntity(tblTenderDigitalSignHistory);
    }

    @Override
    public void deleteTblTenderDigitalSignHistory(TblTenderDigitalSignHistory tblTenderDigitalSignHistory) {
        super.deleteEntity(tblTenderDigitalSignHistory);
    }

    @Override
    public void updateTblTenderDigitalSignHistory(TblTenderDigitalSignHistory tblTenderDigitalSignHistory) {
        super.updateEntity(tblTenderDigitalSignHistory);
    }

    @Override
    public List<TblTenderDigitalSignHistory> getAllTblTenderDigitalSignHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderDigitalSignHistory> findTblTenderDigitalSignHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderDigitalSignHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderDigitalSignHistory> findByCountTblTenderDigitalSignHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderDigitalSignHistory(List<TblTenderDigitalSignHistory> tblTenderDigitalSignHistorys){
        super.updateAll(tblTenderDigitalSignHistorys);
    }
}
