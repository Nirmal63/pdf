/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderGovColumnDao;
import com.etl.eproc.etender.model.TblTenderGovColumn;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderGovColumnImpl extends AbcAbstractClass<TblTenderGovColumn> implements TblTenderGovColumnDao {

  

    @Override
    public void addTblTenderGovColumn(TblTenderGovColumn tblTenderGovColumn){
        super.addEntity(tblTenderGovColumn);
    }

    @Override
    public void deleteTblTenderGovColumn(TblTenderGovColumn tblTenderGovColumn) {
        super.deleteEntity(tblTenderGovColumn);
    }

    @Override
    public void updateTblTenderGovColumn(TblTenderGovColumn tblTenderGovColumn) {
        super.updateEntity(tblTenderGovColumn);
    }

    @Override
    public List<TblTenderGovColumn> getAllTblTenderGovColumn() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderGovColumn> findTblTenderGovColumn(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderGovColumnCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderGovColumn> findByCountTblTenderGovColumn(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderGovColumn(List<TblTenderGovColumn> tblTenderGovColumns){
        super.updateAll(tblTenderGovColumns);
    }
}

