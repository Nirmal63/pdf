/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author shreyansh shah
 */
@Component
public class SPDynamicReport extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderresult.P_DynamicL1H1Report";

    public SPDynamicReport() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@v_reportID", Types.INTEGER));
        this.declareParameter(new SqlParameter("@v_tenderID",Types.INTEGER));
        this.declareParameter(new SqlParameter("@v_officerId",Types.INTEGER));
    }

    /**
     * Method use for grand total or item wise dynamic report.
     * @param reportId
     * @return {@code Map<String,Object>}
     * @throws Exception 
     */
    public Map<String,Object> executeProcedure(int reportId,int tenderId,int officerId) throws Exception
    {
        Map inParams = new HashMap();
        inParams.put("@v_reportID", reportId);
        inParams.put("@v_tenderID",tenderId);
        inParams.put("@v_officerId", officerId);
        this.compile();
        return execute(inParams);
    }
}

