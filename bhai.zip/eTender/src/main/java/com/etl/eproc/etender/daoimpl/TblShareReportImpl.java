package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblShareReportDao;
import com.etl.eproc.etender.model.TblShareReport;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblShareReportImpl extends AbcAbstractClass<TblShareReport> implements TblShareReportDao {

    

    @Override
    public void addTblShareReport(TblShareReport tblShareReport){
        super.addEntity(tblShareReport);
    }

    @Override
    public void deleteTblShareReport(TblShareReport tblShareReport) {
        super.deleteEntity(tblShareReport);
    }

    @Override
    public void updateTblShareReport(TblShareReport tblShareReport) {
        super.updateEntity(tblShareReport);
    }

    @Override
    public List<TblShareReport> getAllTblShareReport() {
        return super.getAllEntity();
    }

    @Override
    public List<TblShareReport> findTblShareReport(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblShareReportCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblShareReport> findByCountTblShareReport(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblShareReport(List<TblShareReport> tblShareReports){
        super.updateAll(tblShareReports);
    }

	@Override
	public void saveOrUpdateTblShareReport(TblShareReport tblShareReport) {
		super.saveOrUpdateEntity(tblShareReport);
	}
}
