/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

/**
 *
 * @author urja.r
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.*;
import com.etl.eproc.etender.model.TblCorrigendum;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository @Transactional
public class TblCorrigendumImpl extends AbcAbstractClass <TblCorrigendum> implements TblCorrigendumDao {

 

    @Override
    public void addTblCorrigendum(TblCorrigendum tblCorrigendum){
        super.addEntity(tblCorrigendum);
    }

    @Override
    public void deleteTblCorrigendum(TblCorrigendum tblCorrigendum) {
        super.deleteEntity(tblCorrigendum);
    }

    @Override
    public void updateTblCorrigendum(TblCorrigendum tblCorrigendum) {
        super.updateEntity(tblCorrigendum);
    }

    @Override
    public List<TblCorrigendum> getAllTblCorrigendum() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCorrigendum> findTblCorrigendum(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCorrigendumCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCorrigendum> findByCountTblCorrigendum(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCorrigendum(List<TblCorrigendum> tblCorrigendums){
        super.updateAll(tblCorrigendums);
    }

	@Override
	public void saveOrUpdateTblCorrigendum(TblCorrigendum tblCorrigendum) {
		super.saveOrUpdateEntity(tblCorrigendum);
	}
}