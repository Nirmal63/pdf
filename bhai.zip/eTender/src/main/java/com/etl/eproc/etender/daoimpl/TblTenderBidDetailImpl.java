package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderBidDetailDao;
import com.etl.eproc.etender.model.TblTenderBidDetail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderBidDetailImpl extends AbcAbstractClass<TblTenderBidDetail> implements TblTenderBidDetailDao {


    @Override
    public void addTblTenderBidDetail(TblTenderBidDetail tblTenderBidDetail){
        super.addEntity(tblTenderBidDetail);
    }

    @Override
    public void deleteTblTenderBidDetail(TblTenderBidDetail tblTenderBidDetail) {
        super.deleteEntity(tblTenderBidDetail);
    }

    @Override
    public void updateTblTenderBidDetail(TblTenderBidDetail tblTenderBidDetail) {
        super.updateEntity(tblTenderBidDetail);
    }

    @Override
    public List<TblTenderBidDetail> getAllTblTenderBidDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderBidDetail> findTblTenderBidDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderBidDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderBidDetail> findByCountTblTenderBidDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderBidDetail(List<TblTenderBidDetail> tblTenderBidDetails){
        super.updateAll(tblTenderBidDetails);
    }
}
