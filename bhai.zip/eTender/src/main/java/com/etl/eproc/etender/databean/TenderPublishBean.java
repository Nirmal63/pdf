/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.databean;

/**
 *
 * @author vanita
 */
public class TenderPublishBean {
    private String txtDocumentStartDate;
    private String txtDocumentEndDate;
    private String txtSubmissionStartDate;
    private String txtSubmissionEndDate;
    private String txtPreBidStartDate;
    private String txtBidOpenDate;
    private String txtQuestionAnswerStartDate;
    private String txtQuestionAnswerEndDate;
    private String hdEventTypeId;
    private String txtPreBidEndDate;
    private String txtaRemarks;
    private String skpSignText;
    private String hdIsCertRequired;
    private String txtaTenderBrief;
    private String hdEnvlopeType;
    private String txtTenderNo;
    private String txtEmdSubmissionEndDate;

    public String getHdEnvlopeType() {
        return hdEnvlopeType;
    }

    public void setHdEnvlopeType(String hdEnvlopeType) {
        this.hdEnvlopeType = hdEnvlopeType;
    }

    public String getSkpSignText() {
        return skpSignText;
    }

    public void setSkpSignText(String skpSignText) {
        this.skpSignText = skpSignText;
    }

    public String getHdIsCertRequired() {
        return hdIsCertRequired;
    }

    public void setHdIsCertRequired(String hdIsCertRequired) {
        this.hdIsCertRequired = hdIsCertRequired;
    }
    

    public String getTxtaRemarks() {
        return txtaRemarks;
    }

    public void setTxtaRemarks(String txtaRemarks) {
        this.txtaRemarks = txtaRemarks;
    }
    
    public String getTxtDocumentStartDate() {
        return txtDocumentStartDate;
    }

    public void setTxtDocumentStartDate(String txtDocumentStartDate) {
        this.txtDocumentStartDate = txtDocumentStartDate;
    }

    public String getTxtDocumentEndDate() {
        return txtDocumentEndDate;
    }

    public void setTxtDocumentEndDate(String txtDocumentEndDate) {
        this.txtDocumentEndDate = txtDocumentEndDate;
    }

    public String getTxtSubmissionStartDate() {
        return txtSubmissionStartDate;
    }

    public void setTxtSubmissionStartDate(String txtSubmissionStartDate) {
        this.txtSubmissionStartDate = txtSubmissionStartDate;
    }

    public String getTxtSubmissionEndDate() {
        return txtSubmissionEndDate;
    }

    public void setTxtSubmissionEndDate(String txtSubmissionEndDate) {
        this.txtSubmissionEndDate = txtSubmissionEndDate;
    }

    public String getTxtPreBidStartDate() {
        return txtPreBidStartDate;
    }

    public void setTxtPreBidStartDate(String txtPreBidStartDate) {
        this.txtPreBidStartDate = txtPreBidStartDate;
    }

    public String getTxtBidOpenDate() {
        return txtBidOpenDate;
    }

    public void setTxtBidOpenDate(String txtBidOpenDate) {
        this.txtBidOpenDate = txtBidOpenDate;
    }

    public String getTxtQuestionAnswerStartDate() {
        return txtQuestionAnswerStartDate;
    }

    public void setTxtQuestionAnswerStartDate(String txtQuestionAnswerStartDate) {
        this.txtQuestionAnswerStartDate = txtQuestionAnswerStartDate;
    }

    public String getTxtQuestionAnswerEndDate() {
        return txtQuestionAnswerEndDate;
    }

    public void setTxtQuestionAnswerEndDate(String txtQuestionAnswerEndDate) {
        this.txtQuestionAnswerEndDate = txtQuestionAnswerEndDate;
    }

    public String getHdEventTypeId() {
        return hdEventTypeId;
    }

    public void setHdEventTypeId(String hdEventTypeId) {
        this.hdEventTypeId = hdEventTypeId;
    }

    public String getTxtPreBidEndDate() {
        return txtPreBidEndDate;
    }

    public void setTxtPreBidEndDate(String txtPreBidEndDate) {
        this.txtPreBidEndDate = txtPreBidEndDate;
    }

	public String getTxtaTenderBrief() {
		return txtaTenderBrief;
	}

	public void setTxtaTenderBrief(String txtaTenderBrief) {
		this.txtaTenderBrief = txtaTenderBrief;
	}

	public String getTxtTenderNo() {
		return txtTenderNo;
	}

	public void setTxtTenderNo(String txtTenderNo) {
		this.txtTenderNo = txtTenderNo;
	}

	public String getTxtEmdSubmissionEndDate() {
		return txtEmdSubmissionEndDate;
	}

	public void setTxtEmdSubmissionEndDate(String txtEmdSubmissionEndDate) {
		this.txtEmdSubmissionEndDate = txtEmdSubmissionEndDate;
	}
    
}
