/**
 * 
 */
package com.etl.eproc.etender.daointerface;

/**
 * @author janak
 *
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TbltenderFormWeightage;

public interface TbltenderFormWeightageDao  {

    public void addTbltenderFormWeightage(TbltenderFormWeightage tbltenderFormWeightage);

    public void deleteTbltenderFormWeightage(TbltenderFormWeightage tbltenderFormWeightage);

    public void updateTbltenderFormWeightage(TbltenderFormWeightage tbltenderFormWeightage);

    public List<TbltenderFormWeightage> getAllTbltenderFormWeightage();

    public List<TbltenderFormWeightage> findTbltenderFormWeightage(Object... values) throws Exception;

    public List<TbltenderFormWeightage> findByCountTbltenderFormWeightage(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTbltenderFormWeightageCount();

    public void saveUpdateAllTbltenderFormWeightage(List<TbltenderFormWeightage> tbltenderFormWeightages);
}