/**
 * 
 */
package com.etl.eproc.etender.daoimpl;

/**
 * @author janak
 *
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TbltenderFormWeightageDao;
import com.etl.eproc.etender.model.TbltenderFormWeightage;

@Repository @Transactional
public class TbltenderFormWeightageImpl extends AbcAbstractClass<TbltenderFormWeightage> implements TbltenderFormWeightageDao {


    @Override
    public void addTbltenderFormWeightage(TbltenderFormWeightage tbltenderFormWeightage){
        super.addEntity(tbltenderFormWeightage);
    }

    @Override
    public void deleteTbltenderFormWeightage(TbltenderFormWeightage tbltenderFormWeightage) {
        super.deleteEntity(tbltenderFormWeightage);
    }

    @Override
    public void updateTbltenderFormWeightage(TbltenderFormWeightage tbltenderFormWeightage) {
        super.updateEntity(tbltenderFormWeightage);
    }

    @Override
    public List<TbltenderFormWeightage> getAllTbltenderFormWeightage() {
        return super.getAllEntity();
    }

    @Override
    public List<TbltenderFormWeightage> findTbltenderFormWeightage(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTbltenderFormWeightageCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TbltenderFormWeightage> findByCountTbltenderFormWeightage(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTbltenderFormWeightage(List<TbltenderFormWeightage> tbltenderFormWeightages){
        super.updateAll(tbltenderFormWeightages);
    }
}
