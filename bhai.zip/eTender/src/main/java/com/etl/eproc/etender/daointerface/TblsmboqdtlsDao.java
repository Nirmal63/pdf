package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.common.model.TblSmboqdtls;
import java.util.List;

public interface TblsmboqdtlsDao  {

    public void addTblsmboqdtls(TblSmboqdtls tblsmboqdtls);

    public void deleteTblsmboqdtls(TblSmboqdtls tblsmboqdtls);

    public void updateTblsmboqdtls(TblSmboqdtls tblsmboqdtls);

    public List<TblSmboqdtls> getAllTblsmboqdtls();

    public List<TblSmboqdtls> findTblsmboqdtls(Object... values) throws Exception;

    public List<TblSmboqdtls> findByCountTblsmboqdtls(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblsmboqdtlsCount();

    public void saveUpdateAllTblsmboqdtls(List<TblSmboqdtls> tblsmboqdtlss);
}