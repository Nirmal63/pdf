package com.etl.eproc.advertise.daoimpl;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import com.etl.eproc.advertise.daointerface.TblAdvertiseDetailDao;
import com.etl.eproc.advertise.model.TblAdvertiseDetail;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblAdvertiseDetailImpl extends AbcAbstractClass<TblAdvertiseDetail> implements TblAdvertiseDetailDao {



    @Override
    public void addTblAdvertiseDetail(TblAdvertiseDetail tblAdvertiseDetail){
        super.addEntity(tblAdvertiseDetail);
    }

    @Override
    public void deleteTblAdvertiseDetail(TblAdvertiseDetail tblAdvertiseDetail) {
        super.deleteEntity(tblAdvertiseDetail);
    }

    @Override
    public void updateTblAdvertiseDetail(TblAdvertiseDetail tblAdvertiseDetail) {
        super.updateEntity(tblAdvertiseDetail);
    }

    @Override
    public List<TblAdvertiseDetail> getAllTblAdvertiseDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAdvertiseDetail> findTblAdvertiseDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAdvertiseDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAdvertiseDetail> findByCountTblAdvertiseDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAdvertiseDetail(List<TblAdvertiseDetail> tblAdvertiseDetails){
        super.updateAll(tblAdvertiseDetails);
    }
}
