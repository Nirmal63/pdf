package com.etl.eproc.etender.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblMaterialMasterDao;
import com.etl.eproc.common.daointerface.TblOfficerDocMappingDao;
import com.etl.eproc.common.daointerface.TblOfficerDocumentDao;
import com.etl.eproc.common.model.TblColumnType;
import com.etl.eproc.common.model.TblCurrency;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblEventType;
import com.etl.eproc.common.model.TblMaterialMaster;
import com.etl.eproc.common.model.TblOfficerDocMapping;
import com.etl.eproc.common.model.TblOfficerDocument;
import com.etl.eproc.common.model.TblProcurementNature;
import com.etl.eproc.common.model.TblSmboq;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.daointerface.TblSmboqDao;
import com.etl.eproc.etender.daointerface.TblTenderCellDao;
import com.etl.eproc.etender.daointerface.TblTenderColumnDao;
import com.etl.eproc.etender.daointerface.TblTenderCurrencyDao;
import com.etl.eproc.etender.daointerface.TblTenderDao;
import com.etl.eproc.etender.daointerface.TblTenderEnvelopeDao;
import com.etl.eproc.etender.daointerface.TblTenderFormDao;
import com.etl.eproc.etender.daointerface.TblTenderMatrixJsonDao;
import com.etl.eproc.etender.daointerface.TblTenderTableDao;
import com.etl.eproc.etender.daointerface.TblsmboqdtlsDao;
import com.etl.eproc.etender.daostoredprocedure.SPManageMaterialMaster;
import com.etl.eproc.etender.daostoredprocedure.SPProjectReport;
import com.etl.eproc.etender.databean.SpaceMatrixDtBean;
import com.etl.eproc.etender.model.TblEnvelope;
import com.etl.eproc.etender.model.TblRebateForm;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderColumn;
import com.etl.eproc.etender.model.TblTenderCurrency;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderFormula;
import com.etl.eproc.etender.model.TblTenderMatrixJson;
import com.etl.eproc.etender.model.TblTenderTable;

/**
 * @author pranav.gandharva
 *
 */
@Service
public class SMClientTenderService {

	@Autowired
	private TblTenderDao tenderDao;
	@Autowired
	private TblTenderEnvelopeDao tblTenderEnvelopeDao;
	@Autowired
	private TblTenderCurrencyDao tblTenderCurrencyDao;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private CommonService commonService;
	@Autowired
	private ConversionService conversionService;
	@Autowired
	private EventCreationService eventCreationService;
	@Autowired
	private TblTenderFormDao tblTenderFormDao;
	@Autowired
	private TblTenderTableDao tblTenderTableDao;
	@Autowired
	private TblTenderColumnDao tblTenderColumnDao;
	@Autowired
	private TblTenderCellDao tblTenderCellDao;
	@Autowired
	private TblTenderMatrixJsonDao tblTenderMatrixJsonDao;
	@Autowired
	private TenderFormService tenderFormService;
	@Autowired
	private TblMaterialMasterDao tblMaterialMasterDao; 
	@Autowired
	private SPProjectReport spProjectReport;
	@Autowired
	private SPManageMaterialMaster spManageMaterialMaster; 
	@Value("#{etenderProperties['datatype_combo']?:6}")
	private int combobox;
	@Value("#{etenderProperties['datatype_master_field']?:8}")
	private int masterField;
	@Value("#{etenderProperties['datatype_listbox']?:9}")
	private int listBox;
	@Value("#{etenderProperties['sap_prNo']}")
	private String prNo; 
	@Value("#{etenderProperties['sap_prItem']}")
	private String prItem;
	@Value("#{etenderProperties['sap_itemName']}")
	private String itemName;
	@Value("#{etenderProperties['sap_description']}")
	private String description;
	@Value("#{etenderProperties['sap_boqType']}")
	private String boqType;
	@Value("#{etenderProperties['sap_boqNo']}")
	private String boqNo;
	@Value("#{etenderProperties['sap_qtyInBoq']}")
	private String qtyInBoq;
	@Value("#{etenderProperties['sap_uom']}")
	private String unitOfMeasurement;
	@Value("#{etenderProperties['sap_unitRate']}")
	private String unitRate;
	@Value("#{etenderProperties['sap_netAmount']}")
	private String netAmount;
	@Value("#{etenderProperties['sap_formula_display']}")
	private String formulaToDisplay;
	@Value("#{etenderProperties['sap_formula_column']}")
	private String formulaColumn;	
	@Autowired
	private TblOfficerDocMappingDao tblOfficerDocMappingDao;
	@Autowired
	private TblOfficerDocumentDao tblOfficerDocumentDao;
	@Autowired
	private TblSmboqDao tblSmboqDao;
	@Autowired
	private HibernateQueryDao hibernateQueryDao;
	@Autowired
	private TblsmboqdtlsDao  tblsmboqdtlsDao;
	@Autowired
	private FileUploadService fileUploadService;
	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
  
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = { Exception.class })
	public boolean addTenderAllDetails(SpaceMatrixDtBean spaceMatrixDtBean) throws JSONException {
		boolean success = false;

		if (null != spaceMatrixDtBean.getTblTender()) {
			tenderDao.addTblTender(spaceMatrixDtBean.getTblTender());
		}
		if (null != spaceMatrixDtBean.getTblTenderCurrency()) {
			addTenderBaseCurrency(spaceMatrixDtBean.getTblTenderCurrency());
		}
		if (null != spaceMatrixDtBean.getTblTender()) {
			addTenderEnvelopeList(spaceMatrixDtBean.getLstTenderEnvelope());
		}

		if (null != spaceMatrixDtBean.getTblTenderForm()) {
			tblTenderFormDao.addTblTenderForm(spaceMatrixDtBean.getTblTenderForm());
		}
		if (null != spaceMatrixDtBean.getTblTenderTable()) {
			tblTenderTableDao.addTblTenderTable(spaceMatrixDtBean.getTblTenderTable());
		}
        if (null != spaceMatrixDtBean.getTblSmboqdtls()){
        	tblsmboqdtlsDao.addTblsmboqdtls(spaceMatrixDtBean.getTblSmboqdtls());
        }
		tblTenderColumnDao.saveUpdateAllTblTenderColumn(spaceMatrixDtBean.getTenderColumns());
		tblTenderCellDao.saveUpdateAllTblTenderCell(spaceMatrixDtBean.getTenderCells());

		String jsonData = tenderTabletoJSON(spaceMatrixDtBean.getTenderCells());
		TblTenderMatrixJson matrixJson = new TblTenderMatrixJson();
		matrixJson.setJsonData(jsonData);
		matrixJson.setTblTenderForm(new TblTenderForm(spaceMatrixDtBean.getTblTenderForm().getFormId()));
		matrixJson.setTblTenderTable(new TblTenderTable(spaceMatrixDtBean.getTblTenderTable().getTableId()));
		tblTenderMatrixJsonDao.addTblTenderMatrixJson(matrixJson);
			
		success = true;
		return success;
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = { Exception.class })
	private boolean addTenderEnvelopeList(List<TblTenderEnvelope> lstTenderEnvelope) {
		boolean bSuccess = false;
		tblTenderEnvelopeDao.saveUpdateAllTblTenderEnvelope(lstTenderEnvelope);
		bSuccess = true;
		return bSuccess;
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = { Exception.class })
	private boolean addTenderBaseCurrency(TblTenderCurrency tblTenderCurrency) {
		boolean bSuccess = false;
		tblTenderCurrencyDao.addTblTenderCurrency(tblTenderCurrency);
		bSuccess = true;
		return bSuccess;
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = { Exception.class })
	public boolean setAllSpaceMatrixData(SpaceMatrixDtBean spDtBean, HttpServletRequest request,int objectId,SessionBean session) {
		int userId = abcUtility.getSessionUserId(request);
		int userDetailId = abcUtility.getSessionUserDetailId(request);
		int clientId = abcUtility.getSessionClientId(request);
		TblTender tblTender = spDtBean.getTblTender();
		TblProcurementNature tblProcurementNature = spDtBean.getTblProcurementNature();
		TblEventType tblEventType = spDtBean.getTblEventType();
		TblTenderCurrency tblTenderCurrency = spDtBean.getTblTenderCurrency();
		TblCurrency tblCurrency = spDtBean.getTblCurrency();
		TblTenderEnvelope tblTenderEnvelope = null;
		List<TblTenderEnvelope> lstTenderEnvelope = new ArrayList<TblTenderEnvelope>();
		Map<String, Object> configParam = new HashMap<String, Object>();
		String data = null;
		boolean success = true;
		final String TOTAL = "TOTAL(";
		String str = "";
		String str1 = "";
		String str2 = "";
		int colcount = 10;
		boolean formulaCellAdd = true;
		try{
		List<Object[]> lstClientConfigFields = eventCreationService.getClientConfigurationFields(clientId, 6);
		if (lstClientConfigFields != null) {
			for (int i = 0; i < lstClientConfigFields.size(); i++) {
				if (lstClientConfigFields.get(i)[4] != null) {
					configParam.put(lstClientConfigFields.get(i)[3].toString(),
							lstClientConfigFields.get(i)[4].toString());
					if (lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isNextEnvOpeningDateAuto")) {
						tblTender.setIsNextEnvOpeningDateAuto(
								Integer.parseInt(lstClientConfigFields.get(i)[4].toString()));
					}
					if (lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("nextEnvOpeningDateSetAfter")) {
						tblTender.setNextEnvOpeningDateSetAfter(
								Integer.parseInt(lstClientConfigFields.get(i)[4].toString()));
					}

				} else {
					configParam.put(lstClientConfigFields.get(i)[3].toString(), data);
				}

			}

		}
		tblTender.setTenderResult(1);
		tblTender.setTblDepartment(new TblDepartment(session.getDeptId()));
		tblTender.setOfficerId(userId);
		tblTender.setCstatus(0);
		tblTender.setCreatedBy(userDetailId);
		tblTender.setAssignUserId(userId);
		tblTender.setUpdatedBy(userDetailId);
		tblTender.setKeywordText("Safe Box"); ////////// Not dc//////////
		if (configParam.containsKey("formContract") && configParam.get("formContract") != null) {
			tblTender.setFormContract(Integer.parseInt(configParam.get("formContract").toString()));
		}
		tblTender.setProductId(0);
		tblTender.setPrequalification("");
		tblTender.setTenderDetail("<p>" + spDtBean.getTblTender().getTenderBrief() + "</p>");
		if (configParam.containsKey("biddingVariant") && configParam.get("biddingVariant") != null) {
			tblTender.setBiddingType(Integer.parseInt(configParam.get("biddingVariant").toString()));
		}
		tblTender.setEnvelopeType(1);
		if (configParam.containsKey("procurementNatureId") && configParam.get("procurementNatureId") != null) {
			tblProcurementNature
					.setProcurementNatureId(Integer.parseInt(configParam.get("procurementNatureId").toString()));
		}
		tblTender.setOtherProcurementNature("");
		tblTender.setTblProcurementNature(tblProcurementNature);
		if (configParam.containsKey("workflowTypeId") && configParam.get("workflowTypeId") != null) {
			tblTender.setWorkflowTypeId(Integer.parseInt(configParam.get("workflowTypeId").toString()));
		}
		if (configParam.containsKey("downloadDocument") && configParam.get("downloadDocument") != null) {
			tblTender.setDownloadDocument(Integer.parseInt(configParam.get("downloadDocument").toString()));
		}
		tblTender.setRemark("");
		tblTender.setUpdatedOn(commonService.getServerDateTime());
		tblTender.setTenderValue(new BigDecimal(10.00)); ///////// Not given
															///////// (decimal
															///////// Upto take)
															///////// ////////
		if(configParam.containsKey("isRegretAllow") && configParam.get("isRegretAllow") != null){
			tblTender.setIsRegretAllow(Integer.parseInt(configParam.get("isRegretAllow").toString()));
		}else{
			tblTender.setIsRegretAllow(0);
		}
		if (configParam.containsKey("validityPeriod") && configParam.get("validityPeriod") != null) {
			tblTender.setValidityPeriod(Integer.parseInt(configParam.get("validityPeriod").toString()));
		}
		if (configParam.containsKey("isSplitPOAllowed") && configParam.get("isSplitPOAllowed") != null) {
			tblTender.setIsSplitPOAllowed(Integer.parseInt(configParam.get("isSplitPOAllowed").toString()));
		}
		if (configParam.containsKey("isItemwiseWinner") && configParam.get("isItemwiseWinner") != null) {
			tblTender.setIsItemwiseWinner(Integer.parseInt(configParam.get("isItemwiseWinner").toString()));
		}
		if (tblTender.getIsItemwiseWinner() == 0) // If notice is grandtotal
													// wise then it is not
													// applicable.
		{
			tblTender.setIsItemSelectionPageRequired(0);
		}
		if (configParam.containsKey("submissionMode") && configParam.get("submissionMode") != null) {
			tblTender.setSubmissionMode(Integer.parseInt(configParam.get("submissionMode").toString()));
		}
		if (configParam.containsKey("biddingVariant") && configParam.get("biddingVariant") != null) {
			tblTender.setBiddingVariant(Integer.parseInt(configParam.get("biddingVariant").toString()));
		}
		if (tblTender.getBiddingVariant() == 2) // bug: 19108 // if variant is
												// for sell then rebate value
												// will be 0.
		{
			tblTender.setIsRebateForm(0);
		}
		if (configParam.containsKey("tenderMode") && configParam.get("tenderMode") != null) {
			tblTender.setTenderMode(Integer.parseInt(configParam.get("tenderMode").toString()));
		}
		tblEventType.setEventTypeId(6);
		tblTender.setTblEventType(tblEventType);
		tblTender.setProjectDuration("10"); //////////////// Not given
											//////////////// //////////////
		tblTender.setDocumentSubmission("");
		if (configParam.containsKey("isConsortiumAllowed") && configParam.get("isConsortiumAllowed") != null) {
			tblTender.setIsConsortiumAllowed(Integer.parseInt(configParam.get("isConsortiumAllowed").toString()));
		}
		if (configParam.containsKey("isBidWithdrawal") && configParam.get("isBidWithdrawal") != null) {
			tblTender.setIsBidWithdrawal(Integer.parseInt(configParam.get("isBidWithdrawal").toString()));
		}
		if (configParam.containsKey("isPreBidMeeting") && configParam.get("isPreBidMeeting") != null) {
			tblTender.setIsPreBidMeeting(Integer.parseInt(configParam.get("isPreBidMeeting").toString()));
		}
		if (configParam.containsKey("preBidMode") && configParam.get("preBidMode") != null) {
			tblTender.setPreBidMode(Integer.parseInt(configParam.get("preBidMode").toString()));
		}
		if (configParam.containsKey("isQuestionAnswer") && configParam.get("isQuestionAnswer") != null) {
			tblTender.setIsQuestionAnswer(Integer.parseInt(configParam.get("isQuestionAnswer").toString()));
		}
		if (configParam.containsKey("isWorkflowRequired") && configParam.get("isWorkflowRequired") != null) {
			tblTender.setIsWorkflowRequired(Integer.parseInt(configParam.get("isWorkflowRequired").toString()));
		}
		if (configParam.containsKey("isDocfeesApplicable") && configParam.get("isDocfeesApplicable") != null) {
			tblTender.setIsDocfeesApplicable(Integer.parseInt(configParam.get("isDocfeesApplicable").toString()));
		}
		if (configParam.containsKey("isRegistrationCharges") && configParam.get("isRegistrationCharges") != null) {
			tblTender.setIsRegistrationCharges(Integer.parseInt(configParam.get("isRegistrationCharges").toString()));
		}
		if (tblTender.getIsRegistrationCharges() == 0) {
			tblTender.setRegistrationChargesMode(0);
			tblTender.setRegistrationCharges("");
		}
		tblTender.setDocFeePaymentMode(0);
		tblTender.setDocFeePaymentAddress("");
		tblTender.setDocumentFee("");
		tblTender.setPreBidAddress("");
		tblTender.setSecurityFee("");
		
		if (configParam.containsKey("isSecurityfeesApplicable")
				&& configParam.get("isSecurityfeesApplicable") != null) {
			tblTender.setIsSecurityfeesApplicable(
					Integer.parseInt(configParam.get("isSecurityfeesApplicable").toString()));
		}
		tblTender.setSecFeePaymentMode(0);
		tblTender.setSecFeePaymentAddress("");
		if (configParam.containsKey("isEMDApplicable") && configParam.get("isEMDApplicable") != null) {
			tblTender.setIsEMDApplicable(Integer.parseInt(configParam.get("isEMDApplicable").toString()));
		}
		tblTender.setEmdPaymentMode(0);
		tblTender.setEmdAmount("");
		tblTender.setEmdPaymentAddress("");
		tblTender.setMaxEmdAmt("");
		tblTender.setMinEmdAmt("");
		tblTender.setCurrencyId(1);
		tblCurrency.setCurrencyId(1);
		tblTenderCurrency = new TblTenderCurrency();
		tblTenderCurrency.setTblTender(tblTender);
		tblTenderCurrency.setTblCurrency(tblCurrency);
		tblTenderCurrency.setIsDefault(1);
		tblTenderCurrency.setIsActive(1);
		tblTenderCurrency.setExchangeRate(BigDecimal.ONE);

		tblTenderEnvelope = new TblTenderEnvelope();
		tblTenderEnvelope.setEnvelopeName(eventCreationService.getEnvelopeNameById(Integer.parseInt("4")));
		tblTenderEnvelope.setTblTender(tblTender);
		tblTenderEnvelope.setTblEnvelope((new TblEnvelope(Integer.parseInt("4"))));
		tblTenderEnvelope.setSortOrder(0 + 1);
		tblTenderEnvelope.setNoOfFormsReq(0);
		tblTenderEnvelope.setMinOpeningMember(0);
		tblTenderEnvelope.setMinEvaluator(0);
		tblTenderEnvelope.setIsOpened(0);
		tblTenderEnvelope.setIsEvaluated(0);
		tblTenderEnvelope.setCreatedBy(userDetailId);
		tblTenderEnvelope.setCstatus(1);
		tblTenderEnvelope.setRemark("");
		tblTenderEnvelope.setMinFormsReqForBidding(1);
		lstTenderEnvelope.add(tblTenderEnvelope);
		spDtBean.setLstTenderEnvelope(lstTenderEnvelope);

		if (configParam.containsKey("isOpeningByCommittee") && configParam.get("isOpeningByCommittee") != null) {
			tblTender.setIsOpeningByCommittee(Integer.parseInt(configParam.get("isOpeningByCommittee").toString()));
		}
		if (configParam.containsKey("isPartialFillingAllowed") && configParam.get("isPartialFillingAllowed") != null) {
			tblTender.setIsPartialFillingAllowed(
					Integer.parseInt(configParam.get("isPartialFillingAllowed").toString()));
		}
		if (configParam.containsKey("isEvaluationByCommittee") && configParam.get("isEvaluationByCommittee") != null) {
			tblTender.setIsEvaluationByCommittee(
					Integer.parseInt(configParam.get("isEvaluationByCommittee").toString()));
		}
		if (configParam.containsKey("multiLevelEvaluationReq") && configParam.get("multiLevelEvaluationReq") != null) {
			tblTender.setMultiLevelEvaluationReq(
					Integer.parseInt(configParam.get("multiLevelEvaluationReq").toString()));
		}

		if (configParam.containsKey("forHomePage") && configParam.get("forHomePage") != null) {
			tblTender.setForHomePage(Integer.parseInt(configParam.get("forHomePage").toString()));
		}
		if (configParam.containsKey("isWorkflowReq") && configParam.get("isWorkflowReq") != null) {
			tblTender.setIsWorkflowRequired(0);
		}

		if (configParam.containsKey("biddingVariant") && configParam.get("biddingVariant") != null) {
			tblTender.setBiddingVariant(Integer.parseInt(configParam.get("biddingVariant").toString()));
		}

		if (configParam.containsKey("isEncodedName") && configParam.get("isEncodedName") != null) {
			tblTender.setIsEncodedName(Integer.parseInt(configParam.get("isEncodedName").toString()));
		}

		if (configParam.containsKey("isMandatoryDocument") && configParam.get("isMandatoryDocument") != null) {
			tblTender.setIsMandatoryDocument(Integer.parseInt(configParam.get("isMandatoryDocument").toString()));
		}

		if (configParam.containsKey("isEncDocumentOnly") && configParam.get("isEncDocumentOnly") != null) {
			tblTender.setIsEncDocumentOnly(Integer.parseInt(configParam.get("isEncDocumentOnly").toString()));
		}
		if (configParam.containsKey("isSORApplicable") && configParam.get("isSORApplicable") != null) {
			tblTender.setIsSORApplicable(Integer.parseInt(configParam.get("isSORApplicable").toString()));
		}
		if (configParam.containsKey("sorVariation") && configParam.get("sorVariation") != null) {
			tblTender.setSorVariation(new BigDecimal(configParam.get("sorVariation").toString()));
		}
		if (configParam.containsKey("isRebateForm") && configParam.get("isRebateForm") != null) {
			tblTender.setIsRebateForm(Integer.parseInt(configParam.get("isRebateForm").toString()));
		}

		if (configParam.containsKey("isNegotiationAllowed") && configParam.get("isNegotiationAllowed") != null) {
			tblTender.setIsNegotiationAllowed(Integer.parseInt(configParam.get("isNegotiationAllowed").toString()));
		}

		if (configParam.containsKey("isReEvaluationReq") && configParam.get("isReEvaluationReq") != null) {
			tblTender.setIsReEvaluationReq(Integer.parseInt(configParam.get("isReEvaluationReq").toString()));
		}
		if (configParam.containsKey("isFinalPriceSheetReq") && configParam.get("isFinalPriceSheetReq") != null) {
			tblTender.setIsFinalPriceSheetReq(Integer.parseInt(configParam.get("isFinalPriceSheetReq").toString()));
		}
		if (configParam.containsKey("decryptorRequired") && configParam.get("decryptorRequired") != null) {
			tblTender.setDecryptorRequired(Integer.parseInt(configParam.get("decryptorRequired").toString()));
		}
		if (configParam.containsKey("isDisplayClarificationDoc")
				&& configParam.get("isDisplayClarificationDoc") != null) {
			tblTender.setIsDisplayClarificationDoc(
					Integer.parseInt(configParam.get("isDisplayClarificationDoc").toString()));
		}
		if (configParam.containsKey("isCreateAuction") && configParam.get("isCreateAuction") != null) {
			tblTender.setIsCreateAuction(Integer.parseInt(configParam.get("isCreateAuction").toString()));
		}
		if (configParam.containsKey("encryptionLevel") && configParam.get("encryptionLevel") != null) {
			tblTender.setEncryptionLevel(Integer.parseInt(configParam.get("encryptionLevel").toString()));
		}

		tblTender.setIsCertRequired(0);

		if (configParam.containsKey("resultSharing") && configParam.get("resultSharing") != null) {
			tblTender.setResultSharing(Integer.parseInt(configParam.get("resultSharing").toString()));
		}
		if (configParam.containsKey("isPastEvent") && configParam.get("isPastEvent") != null) {
			tblTender.setIsPastEvent(Integer.parseInt(configParam.get("isPastEvent").toString()));
		}
		if (configParam.containsKey("showBidDetail") && configParam.get("showBidDetail") != null) {
			tblTender.setShowBidDetail(Integer.parseInt(configParam.get("showBidDetail").toString()));
		}
		if (configParam.containsKey("isEMDByBidder") && configParam.get("isEMDByBidder") != null) {
			tblTender.setIsEMDByBidder(Integer.parseInt(configParam.get("isEMDByBidder").toString()));
		}
		if (configParam.containsKey("isRestOfEventMoney") && configParam.get("isRestOfEventMoney") != null) {
			tblTender.setIsRestOfEventMoney(Integer.parseInt(configParam.get("isRestOfEventMoney").toString()));
		}
		if (configParam.containsKey("isParticipationFeesBy") && configParam.get("isParticipationFeesBy") != null) {
			tblTender.setIsParticipationFeesBy(Integer.parseInt(configParam.get("isParticipationFeesBy").toString()));
		}
		if (configParam.containsKey("isProcessingFeeByBidder") && configParam.get("isProcessingFeeByBidder") != null) {
			tblTender.setIsProcessingFeeByBidder(
					Integer.parseInt(configParam.get("isProcessingFeeByBidder").toString()));
		}
		if (configParam.containsKey("isDocumentFeeByBidder") && configParam.get("isDocumentFeeByBidder") != null) {
			tblTender.setIsDocumentFeeByBidder(Integer.parseInt(configParam.get("isDocumentFeeByBidder").toString()));
		}
		if (configParam.containsKey("isEvaluationRequired") && configParam.get("isEvaluationRequired") != null) {
			tblTender.setIsEvaluationRequired(Integer.parseInt(configParam.get("isEvaluationRequired").toString()));
		}
		if (configParam.containsKey("isWeightageEvaluationRequired")
				&& configParam.get("isWeightageEvaluationRequired") != null) {
			tblTender.setIsWeightageEvaluationRequired(
					Integer.parseInt(configParam.get("isWeightageEvaluationRequired").toString()));
		}

		if (configParam.containsKey("decimalValueUpto") && configParam.get("decimalValueUpto") != null) {
			tblTender.setDecimalValueUpto(Integer.parseInt(configParam.get("decimalValueUpto").toString()));
		}
		if (configParam.containsKey("isItemSelectionPageRequired")
				&& configParam.get("isItemSelectionPageRequired") != null) {
			tblTender.setIsItemSelectionPageRequired(
					Integer.parseInt(configParam.get("isItemSelectionPageRequired").toString()));
			tblTender.setIsItemSelectionPageRequired(0);
		}
		if (configParam.containsKey("isDemoTender") && configParam.get("isDemoTender") != null) {
			tblTender.setIsDemoTender(Integer.parseInt(configParam.get("isDemoTender").toString()));
		}
		if (configParam.containsKey("showNoOfBidders") && configParam.get("showNoOfBidders") != null) {
			tblTender.setShowNoOfBidders(Integer.parseInt(configParam.get("showNoOfBidders").toString()));
		}

		if (configParam.containsKey("workflowForBidOpening") && configParam.get("workflowForBidOpening") != null) {
			tblTender.setWorkflowForBidOpening(Integer.parseInt(configParam.get("workflowForBidOpening").toString()));
		}
		if (configParam.containsKey("workflowForNegotiation") && configParam.get("workflowForNegotiation") != null) {
			tblTender.setWorkflowForNegotiation(Integer.parseInt(configParam.get("workflowForNegotiation").toString()));
		}
		if (configParam.containsKey("brdMode") && configParam.get("brdMode") != null) {
			tblTender.setBrdMode(Integer.parseInt(configParam.get("brdMode").toString()));
		}
		if (configParam.containsKey("isEvaluationRequired") && configParam.get("isEvaluationRequired") != null) {
			tblTender.setIsEvaluationRequired(Integer.parseInt(configParam.get("isEvaluationRequired").toString()));
		}
		if (configParam.containsKey("showResultOnHomePage") && configParam.get("showResultOnHomePage") != null) {
			tblTender.setShowResultOnHomePage(Integer.parseInt(configParam.get("showResultOnHomePage").toString()));
		}

		if (configParam.containsKey("winningReportMode") && configParam.get("winningReportMode") != null) {
			tblTender.setWinningReportMode(Integer.parseInt(configParam.get("winningReportMode").toString()));
		}

		if (configParam.containsKey("isReworkRequired") && configParam.get("isReworkRequired") != null) {
			tblTender.setIsReworkRequired((Integer.parseInt(configParam.get("isReworkRequired").toString())));
		}
		if (configParam.containsKey("isCentralizedTOCRequired")
				&& configParam.get("isCentralizedTOCRequired") != null) {
			tblTender.setIsCentralizedTOCRequired(
					Integer.parseInt(configParam.get("isCentralizedTOCRequired").toString()));
		}
		if (configParam.containsKey("isCentralizedTECRequired")
				&& configParam.get("isCentralizedTECRequired") != null) {
			tblTender.setIsCentralizedTECRequired(
					Integer.parseInt(configParam.get("isCentralizedTECRequired").toString()));
		}
		if (configParam.containsKey("isTwoStageEvaluation") && configParam.get("isTwoStageEvaluation") != null) {
			tblTender.setIsTwoStageEvaluation(Integer.parseInt(configParam.get("isTwoStageEvaluation").toString()));
		}
		if (configParam.containsKey("isTwoStageOpening") && configParam.get("isTwoStageOpening") != null) {
			tblTender.setIsTwoStageOpening(Integer.parseInt(configParam.get("isTwoStageOpening").toString()));
		}
		if (configParam.containsKey("POType") && configParam.get("POType") != null) {
			tblTender.setPOType((Integer.parseInt(configParam.get("POType").toString())));
		}
		if (configParam.containsKey("workflowForTOC") && configParam.get("workflowForTOC") != null) {
			tblTender.setWorkflowForTOC(Integer.parseInt(configParam.get("workflowForTOC").toString()));
		}
		if (configParam.containsKey("workflowForTEC") && configParam.get("workflowForTEC") != null) {
			tblTender.setWorkflowForTEC(Integer.parseInt(configParam.get("workflowForTEC").toString()));
		}
		spDtBean.setTblTender(tblTender);
		spDtBean.setTblCurrency(tblCurrency);
		spDtBean.setTblTenderCurrency(tblTenderCurrency);
		spDtBean.getTblTenderForm().setTblTender(tblTender);
		spDtBean.getTblTenderForm().setFormHeader("");
		spDtBean.getTblTenderForm().setFormFooter("");
		spDtBean.getTblTenderForm().setNoOfTables(1);
		spDtBean.getTblTenderForm().setTblTenderEnvelope(tblTenderEnvelope);
		spDtBean.getTblTenderForm().setIsDocumentReq(0);
		spDtBean.getTblTenderForm().setIsEncryptedDocument(0);
		spDtBean.getTblTenderForm().setIsEncryptionReq(0);
		spDtBean.getTblTenderForm().setIsMandatory(1);
		spDtBean.getTblTenderForm().setIsMultipleFilling(0);
		spDtBean.getTblTenderForm().setIsSecondary(0);
		spDtBean.getTblTenderForm().setIsPriceBid(1);
		spDtBean.getTblTenderForm().setSortOrder(1);
		spDtBean.getTblTenderForm().setLoadNoOfItems(100);
		spDtBean.getTblTenderForm().setIncrementItems(50);
		spDtBean.getTblTenderForm().setIsItemWiseDocAllowed(0);
		spDtBean.getTblTenderForm().setMinTablesReqForBidding(1);
		spDtBean.getTblTenderForm()
				.setCreatedOn(conversionService.convert(commonService.getServerDateTime(), Date.class));
		spDtBean.getTblTenderForm().setCreatedBy(userDetailId);

		spDtBean.getTblTenderTable().setHasGTRow(0);
		spDtBean.getTblTenderTable().setSortOrder(1);
		spDtBean.getTblTenderTable().setIsMultipleFilling(0);
		spDtBean.getTblTenderTable().setNoOfCols(10);
		spDtBean.getTblTenderTable().setNoOfRows(spDtBean.getMapForColumnValues().get(2).size());
		spDtBean.getTblTenderTable().setCreatedBy(userId);
		spDtBean.getTblTenderTable().setTableFooter("");
		spDtBean.getTblTenderTable().setTableHeader("");
		spDtBean.getTblTenderTable().setTblTenderForm(spDtBean.getTblTenderForm());
		spDtBean.getTblTenderTable().setUpdatedBy(userId);
		spDtBean.getTblTenderTable().setUpdatedOn(commonService.getServerDateTime());
		spDtBean.getTblTenderTable().setIsPartialFillingAllowed(0);
		spDtBean.getTblTenderTable().setIsMandatory(1);

		List<TblTenderColumn> tenderColumns = new ArrayList<TblTenderColumn>();
		List<TblTenderCell> tenderCells = new ArrayList<TblTenderCell>();
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		map.put(0,prNo); 
		map.put(1,prItem);
		map.put(2,itemName);
		map.put(3,description);
		map.put(4,boqType);
		map.put(5,boqNo);
		map.put(6,qtyInBoq);
		map.put(7,unitOfMeasurement);
		map.put(8,unitRate);
		map.put(9,netAmount);

		int cellNo = 0;
		int rowcount = spDtBean.getMapForColumnValues().get(3).size();
		int cellNumber = colcount * rowcount;
		for (int i = 0; i < 10; i++) {
			TblTenderColumn tenderColumn = new TblTenderColumn();
			tenderColumn.setColumnHeader(map.get(i).split("_")[0]);
			tenderColumn.setTblTenderForm(spDtBean.getTblTenderForm());
			tenderColumn.setDataType(Integer.parseInt(map.get(i).split("_")[1]));
			tenderColumn.setFilledBy(Integer.parseInt(map.get(i).split("_")[2]));
			tenderColumn.setIsShown(1);
			tenderColumn.setIsCurrConvReq(0);
			tenderColumn.setColumnNo(i + 1);
			tenderColumn.setSortOrder(i + 1);
			tenderColumn.setTblTenderTable(spDtBean.getTblTenderTable());
			tenderColumn.setTblColumnType(new TblColumnType(Integer.parseInt(map.get(i).split("_")[3])));

			if (null != spDtBean.getMapForColumnValues() && spDtBean.getMapForColumnValues().size() > 0) {
				for (int j = 0; j < spDtBean.getMapForColumnValues().get(2).size(); j++) {
					TblTenderCell tenderCell = new TblTenderCell();
					tenderCell.setCellNo(cellNo);
					tenderCell.setTblTenderForm(spDtBean.getTblTenderForm());
					tenderCell.setRowId(j + 1);
					tenderCell.setTblTenderColumn(tenderColumn);
					tenderCell.setTblTenderTable(spDtBean.getTblTenderTable());
					if (null != spDtBean.getMapForColumnValues().get(i)) {
						tenderCell.setCellValue(spDtBean.getMapForColumnValues().get(i).get(j));
					} else {
						tenderCell.setCellValue("");
					}
					tenderCell.setDataType(tenderColumn.getDataType());
					tenderCells.add(tenderCell);
					cellNo++;
				}
			}

			tenderColumns.add(tenderColumn);
		}
		spDtBean.setTenderColumns(tenderColumns);
		spDtBean.setTenderCells(tenderCells);
		spDtBean.getTblSmboqdtls().setTblTender(tblTender);
		spDtBean.getTblSmboqdtls().setCreatedBy(userDetailId);
		spDtBean.getTblSmboqdtls().setCreatedOn(conversionService.convert(commonService.getServerDateTime(), Date.class));
		success = addTenderAllDetails(spDtBean);
		if (success) {
			updateTblSmBoq(objectId,userDetailId, 1);
			fileUploadService.updateOfficerDocDetailsForRemove(objectId, 1);
		}
		for (TblTenderColumn tblTenderColumn : tenderColumns) {
			str += tblTenderColumn.getColumnId() + ",";
			str1 += tblTenderColumn.getSortOrder() + ",";
			str2 += tblTenderColumn.getColumnHeader() + ",";
		}
		String[] colIdArr = str.split(",");
		String[] colSortArr = str1.split(",");
		String[] colHeadArr = str2.split(",");

		List<TblTenderFormula> tenderFormulas = new ArrayList<TblTenderFormula>();
		TblTenderFormula tenderFormula = new TblTenderFormula();
		tenderFormula.setCellId(0);
		tenderFormula.setCellNo(0);
		tenderFormula.setFormulaType(1);
		tenderFormula.setColumnNo(10);
		tenderFormula.setDisplayFormula(formulaToDisplay);
		tenderFormula.setFormula(formulaColumn);
		tenderFormula.setColFormula(formulaColumn);
		tenderFormula.setTblTenderColumn(new TblTenderColumn(Integer.parseInt(colIdArr[9])));
		tenderFormula.setTblTenderForm(new TblTenderForm(spDtBean.getTblTenderForm().getFormId()));
		tenderFormula.setTblTenderTable(new TblTenderTable(spDtBean.getTblTenderTable().getTableId()));
		tenderFormulas.add(tenderFormula);
		List<TblTenderCell> tenderCell1 = new ArrayList<TblTenderCell>();
		for (int i = 0; i < colcount; i++) {
			TblTenderCell tenderCell = new TblTenderCell();
			tenderCell.setCellNo(cellNumber + (Integer.parseInt(colSortArr[i]) - 1));
			tenderCell.setRowId(rowcount + 1);
			tenderCell.setTblTenderColumn(
					new TblTenderColumn(Integer.parseInt(colIdArr[Integer.parseInt(colSortArr[i]) - 1])));
			tenderCell.setTblTenderTable(new TblTenderTable(spDtBean.getTblTenderTable().getTableId()));
			tenderCell.setTblTenderForm(new TblTenderForm(spDtBean.getTblTenderForm().getFormId()));
			tenderCell.setCellValue("");
			tenderCell.setDataType(0);
			tenderCell.setObjectId(0);
			tenderCell1.add(tenderCell);
		}
		tenderFormula = new TblTenderFormula();
		tenderFormula.setCellId(0);
		tenderFormula.setCellNo(0);
		tenderFormula.setFormulaType(1);
		tenderFormula.setColumnNo(10);
		String formulaCol = colHeadArr[9];
		tenderFormula.setDisplayFormula(TOTAL + formulaCol + ")");
		tenderFormula.setFormula(TOTAL + 10 + ")");
		tenderFormula.setColFormula(TOTAL + 10 + ")");
		tenderFormula.setTblTenderColumn(new TblTenderColumn(Integer.parseInt(colIdArr[9])));
		tenderFormula.setTblTenderTable(new TblTenderTable(spDtBean.getTblTenderTable().getTableId()));
		tenderFormula.setTblTenderForm(new TblTenderForm(spDtBean.getTblTenderForm().getFormId()));
		tenderFormulas.add(tenderFormula);
		formulaCellAdd = true;
		spDtBean.setTblTenderFormula(tenderFormulas);
		success = tenderFormService.addFormula(spDtBean.getTblTenderFormula(), formulaCellAdd, tenderCell1,
				rowcount + 1, colcount, spDtBean.getTblTenderTable().getTableId());

		spDtBean.getTblRebate().setReportName("Price summary");
		spDtBean.getTblRebate().setTblTender(new TblTender(spDtBean.getTblTender().getTenderId()));
		spDtBean.getTblRebate().setIsRebateForm(0);
		String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR")
				: request.getRemoteAddr();
		spDtBean.getTblRebate().setIpAddress(ipAddress);
		userId = abcUtility.getSessionUserDetailId(request);
		spDtBean.getTblRebate().setCreatedBy(userId);
		List<Object[]> cellsId = tenderFormService.getPriceSumaryCellDetails(spDtBean.getTblTenderForm().getFormId(),
				5);

		List<TblRebateForm> tblRebateFormList = new ArrayList<TblRebateForm>();
		spDtBean.getTblRebateForm().setTblRebate(spDtBean.getTblRebate());
		spDtBean.getTblRebateForm().setTblTenderForm(new TblTenderForm(spDtBean.getTblTenderForm().getFormId()));
		spDtBean.getTblRebateForm().setTblTenderCell(new TblTenderCell((Integer) cellsId.get(0)[2]));
		spDtBean.getTblRebateForm().setIpAddress(ipAddress);
		spDtBean.getTblRebateForm().setCreatedBy(userId);
		tblRebateFormList.add(spDtBean.getTblRebateForm());

		success = tenderFormService.addRebateDetail(spDtBean.getTblRebate(), tblRebateFormList);

	}catch(Exception e){
		exceptionHandlerService.writeLog(e);
	}
        return success;
	}     
    
   
   

	public String tenderTabletoJSON(List<TblTenderCell> cells) throws JSONException {
		JSONArray jSONArray = new JSONArray();
		int counter = 0;
		for (TblTenderCell tcm : cells) {
			JSONObject jSONObject = new JSONObject();
			jSONObject.put(new StringBuilder().append(tcm.getCellNo()).append("_")
					.append(tcm.getTblTenderColumn().getColumnNo()).append("_").append(tcm.getRowId()).append("_")
					.append(tcm.getDataType()).append("_").append(tcm.getTblTenderTable().getTableId()).append("_")
					.append(tcm.getTblTenderColumn().getColumnId()).append("_").append(tcm.getCellId()).append("_")
					.append(tcm.getObjectId()).toString(),
					(tcm.getDataType() == combobox || tcm.getDataType() == masterField || tcm.getDataType() == listBox)
							? tcm.getObjectId() : tcm.getCellValue().replace("\t", " ").replace("\\r\\n", "<br/>"));
			jSONArray.put(counter, jSONObject);
			counter++;
		}
		return jSONArray.toString();
	}

	 /**
	  * @author vivek.rajyaguru
	 * @param tblOfficerDocument
	 * @param tblOfficerDocMapping
	 * @param tblSmboq
	 * @return
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
	public boolean addTblSmBoqAndOfficeDocDetail(TblOfficerDocument tblOfficerDocument,TblOfficerDocMapping tblOfficerDocMapping,TblSmboq tblSmboq,String path)throws Exception{
		boolean flag=false;
		tblSmboqDao.addTblsmboq(tblSmboq);
		tblOfficerDocument.setPath(path+"\\"+tblSmboq.getSmboqId());
		tblOfficerDocumentDao.addTblOfficerDocument(tblOfficerDocument);
		tblOfficerDocMapping.setObjectId(tblSmboq.getSmboqId());
		tblOfficerDocMapping.setTblOfficerDocument(new TblOfficerDocument(tblOfficerDocument.getOfficerDocId()));
		tblOfficerDocMappingDao.addTblOfficerDocMapping(tblOfficerDocMapping);
		flag=true;
		return flag;
	 }
	
	/**
	 * @author vivek.rajyaguru
	 * @param smboqId
	 * @param userDetailId
	 * @param cstatus
	 * @return
	 * @throws Exception
	 */
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
	public int updateTblSmBoq(int smboqId,int userDetailId,int cstatus)throws Exception{
		 Map<String, Object> var = new HashMap<String, Object>();
		 var.put("smboqId",smboqId);
	     var.put("updatedBy",userDetailId);
     	 var.put("cstatus",cstatus);
     	return hibernateQueryDao.updateDeleteNewQuery("update TblSmboq set cstatus=:cstatus,updatedBy=:updatedBy,updatedOn=GETUTCDATE() where smboqId=:smboqId",var);
		
	}
	
	
	/**
	 * @param smboqId
	 * @param cstatus
	 * @return
	 * @throws Exception
	 */
	public boolean getFileStatus(int smboqId,int cstatus) throws Exception{
	boolean status=true;
	List<TblSmboq> list=tblSmboqDao.findTblsmboq("smboqId",Operation_enum.EQ,smboqId,"cstatus",Operation_enum.EQ,cstatus);
		if(list != null && !list.isEmpty()) {
		     status=false;
		 }
	return status;
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = { Exception.class })
	public String getMaterialDescriptionByPlant(String materialNumber, String plantCode)
			throws Exception {
		List<TblMaterialMaster> list = tblMaterialMasterDao.findTblMaterialMaster(
				"materialNumber", Operation_enum.EQ, materialNumber, "plant",
				Operation_enum.EQ, plantCode,"isActive" , Operation_enum.EQ , 1);
		String materialDescription = "";
		if (list != null && !list.isEmpty()) {
			for (TblMaterialMaster tblMaterialMaster : list) {
			 	materialDescription = tblMaterialMaster.getMaterialDescription()+","
			    +(!tblMaterialMaster.getCharacteristic1().isEmpty() && tblMaterialMaster.getCharacteristic1() != "" ? "<br>"+tblMaterialMaster.getCharacteristic1().replace("?","")+" &#45; " : "")
			    +(!tblMaterialMaster.getCharacteristicValue1().isEmpty() && tblMaterialMaster.getCharacteristicValue1() != "" ? tblMaterialMaster.getCharacteristicValue1().replace("?","") : "")
			    +(!tblMaterialMaster.getCharacteristic2().isEmpty()  && tblMaterialMaster.getCharacteristic2() != "" ? ","+"<br>"+tblMaterialMaster.getCharacteristic2().replace("?","")+" &#45; " : "")
			    +(!tblMaterialMaster.getCharacteristicValue2().isEmpty() && tblMaterialMaster.getCharacteristicValue2() != "" ? tblMaterialMaster.getCharacteristicValue2().replace("?", "") : "")
			    +(!tblMaterialMaster.getCharacteristic3().isEmpty() && tblMaterialMaster.getCharacteristic3() != "" ? ","+"<br>"+tblMaterialMaster.getCharacteristic3().replace("?", "")+" &#45; " : "")
			    +(!tblMaterialMaster.getCharacteristicValue3().isEmpty() && tblMaterialMaster.getCharacteristicValue3() != "" ? tblMaterialMaster.getCharacteristicValue3().replace("?", "") : "")
			    +(!tblMaterialMaster.getCharacteristic4().isEmpty() && tblMaterialMaster.getCharacteristic4() != "" ? ","+"<br>"+tblMaterialMaster.getCharacteristic4().replace("?", "")+" &#45; " : "")
			    +(!tblMaterialMaster.getCharacteristicValue4().isEmpty() && tblMaterialMaster.getCharacteristicValue4() != ""? tblMaterialMaster.getCharacteristicValue4().replace("?", "") : "")
			    +(!tblMaterialMaster.getCharacteristic5().isEmpty() && tblMaterialMaster.getCharacteristic5() != ""? ","+"<br>"+tblMaterialMaster.getCharacteristic5().replace("?", "")+" &#45; " : "")
			    +(!tblMaterialMaster.getCharacteristicValue5().isEmpty() && tblMaterialMaster.getCharacteristicValue5() != "" ? tblMaterialMaster.getCharacteristicValue5().replace("?", "") : "")
			    +(!tblMaterialMaster.getCharacteristic6().isEmpty() && tblMaterialMaster.getCharacteristic6() != "" ? ","+"<br>"+tblMaterialMaster.getCharacteristic6().replace("?", "")+" &#45; " : "")
			    +(!tblMaterialMaster.getCharacteristicValue6().isEmpty() && tblMaterialMaster.getCharacteristicValue6() != "" ? tblMaterialMaster.getCharacteristicValue6().replace("?", "") : "")
			    +(!tblMaterialMaster.getHsnCode().isEmpty() && tblMaterialMaster.getHsnCode() != "" ?   ","+"<br>"+"Hsn code"+" &#45; "+tblMaterialMaster.getHsnCode() : "")
			    +(!tblMaterialMaster.getPOtext().isEmpty() && tblMaterialMaster.getPOtext() != ""? ","+"<br>"+"PO Text"+" &#45; "+ tblMaterialMaster.getPOtext() : "")
			    +(!tblMaterialMaster.getManufacturingPartNumber().isEmpty() && tblMaterialMaster.getManufacturingPartNumber() != "" ? ","+"<br>"+"manufacturing part number"+" &#45; "+ tblMaterialMaster.getManufacturingPartNumber() : "");
			    
			}  
		}
		
		return abcUtility.replaceSpecialChars(materialDescription);
	}

	/**
	 * @param smboqId
	 * @return
	 */
	public List<Object[]> getSapBoqDetails(int smboqId){
		Map<String, Object> var = new HashMap<String, Object>();
		var.put("smboqId", smboqId);
		return hibernateQueryDao.createNewQuery("select tbltender.tenderBrief,tblUserDetail.userName ,tbltender.tenderId from TblSmboq tblsmboq inner join tblsmboq.tblsmboqdtls tblSmboqdtls inner join tblSmboqdtls.tblTender tbltender,TblUserDetail tblUserDetail  where tblsmboq.cstatus=1 and tblsmboq.smboqId=:smboqId and tbltender.createdBy=tblUserDetail.userDetailId", var);
	}
	
	/**
	 * @author pranav.gandharva
	 * @param tenderId
	 * @return
	 * @throws Exception
	 */
	public Map<String,Object> getProjectReport(int tenderId,String projectId,String companyName,String responsibleUser,int clientId,int dateOperator,Date publishDateFrom,Date publishDateTo,int recordsPerPage,int pageNo) throws Exception {
		Map<String,Object> result = null;
    	result = spProjectReport.executeProcedure(tenderId,projectId,companyName,responsibleUser,clientId,dateOperator,publishDateFrom,publishDateTo,recordsPerPage,pageNo);
    	return result;

	}
	/**
	 * @author pranav.gandharva
	 * @param plant
	 * @param itemCategory
	 * @param purchGrp
	 * @param materialNumber
	 * @param recordsPerPage
	 * @param pageNo
	 * @return
	 * @throws Exception
	 */
	public Map<String,Object> getMaterialMaster(String industrialSector,String materialType,String plant,String itemCategory,String purchGrp,String materialNumber,int recordsPerPage,int pageNo) throws Exception {
		Map<String,Object> result = null;
    	result = spManageMaterialMaster.executeProcedure(industrialSector,materialType ,plant, itemCategory, purchGrp, materialNumber, recordsPerPage, pageNo);
    	return result;
	}
	
	 public boolean updateVendorStatus(int isfirstlogin,int workflowId,int userId,int clientId){
    	 boolean success = false;
    	 Map<String, Object> var = new HashMap<String, Object>();
    	 Map<String, Object> var1 = new HashMap<String, Object>();
         var.put("isFirstLogin",isfirstlogin);
         var.put("userId",userId);
         var.put("clientId",clientId);
         var1.put("registrationWorkflowId",workflowId);
         var1.put("userId",userId);
         var1.put("clientId",clientId);
         
    	 hibernateQueryDao.updateDeleteNewQuery("update TblUserLogin tblUserLogin set tblUserLogin.isFirstLogin=:isFirstLogin where tblUserLogin.userId=:userId and tblUserLogin.tblClient.clientId=:clientId", var);
    	 hibernateQueryDao.updateDeleteNewQuery("update TblBidderStatus tblBidderStatus set tblBidderStatus.tblRegistrationWorkflow.registrationWorkflowId=:registrationWorkflowId where tblBidderStatus.tblUserLogin.userId=:userId and tblBidderStatus.tblClient.clientId=:clientId", var1);
         success = true;
         return success;
     }
}
