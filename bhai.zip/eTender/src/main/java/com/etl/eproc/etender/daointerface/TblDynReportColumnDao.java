/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daointerface;


import com.etl.eproc.etender.model.TblDynReportColumn;
import java.util.List;

/**
 *
 * @author shreyansh.shah
 */
public interface TblDynReportColumnDao  {

    public void addTblDynReportColumn(TblDynReportColumn tblDynReportColumn);

    public void deleteTblDynReportColumn(TblDynReportColumn tblDynReportColumn);

    public void updateTblDynReportColumn(TblDynReportColumn tblDynReportColumn);

    public List<TblDynReportColumn> getAllTblDynReportColumn();

    public List<TblDynReportColumn> findTblDynReportColumn(Object... values) throws Exception;

    public List<TblDynReportColumn> findByCountTblDynReportColumn(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynReportColumnCount();

    public void saveUpdateAllTblDynReportColumn(List<TblDynReportColumn> tblDynReportColumns);
}