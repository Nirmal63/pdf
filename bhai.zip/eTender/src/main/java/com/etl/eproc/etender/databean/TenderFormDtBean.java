package com.etl.eproc.etender.databean;

import javax.servlet.http.HttpServletRequest;

import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.etender.model.TblEnvelope;
import com.etl.eproc.etender.model.TblTenderEnvelope;
import com.etl.eproc.etender.model.TblTenderForm;


/**
 * 26 june 2013
 * @author nirav.modi
 */
public class TenderFormDtBean {

	private String txtaFormName;        
	private String rtfFormHeader;        
	private String rtfFormFooter;        
	private String selEnvId;        
	private String txtNoOfTables;        
	private String selIsMultipleFilling;        
	private String selIsEncryptionReq;        
	private String selIsEvaluationReq;        
	private String selIsDocumentReq;        
	private String selIsEncryptedDocument;        
	private String selIsMandatory;        
	private String selIsSecondary;
	private String selIsPriceBid;
	private CommonValidators commonValidators;
	private boolean isCertRequired; 
	private boolean isOpeningByCommittee;
	private boolean isConsortiumAllowed;
	
	public boolean isConsortiumAllowed() {
		return isConsortiumAllowed;
	}

	public void setConsortiumAllowed(boolean isConsortiumAllowed) {
		this.isConsortiumAllowed = isConsortiumAllowed;
	}

	public boolean isOpeningByCommittee() {
		return isOpeningByCommittee;
	}

	public void setOpeningByCommittee(boolean isOpeningByCommittee) {
		this.isOpeningByCommittee = isOpeningByCommittee;
	}

	public boolean isCertRequired() {
		return isCertRequired;
	}

	public void setCertRequired(boolean isCertRequired) {
		this.isCertRequired = isCertRequired;
	}

	public String getTxtaFormName() {
		return this.txtaFormName;
	}

	public void setTxtaFormName(String txtaFormName) {
		this.txtaFormName = txtaFormName;
	}        
	public String getRtfFormHeader() {
		return this.rtfFormHeader;
	}

	public void setRtfFormHeader(String rtfFormHeader) {
		this.rtfFormHeader = rtfFormHeader;
	}        
	public String getRtfFormFooter() {
		return this.rtfFormFooter;
	}

	public void setRtfFormFooter(String rtfFormFooter) {
		this.rtfFormFooter = rtfFormFooter;
	}        
	       
	public String getSelEnvId() {
		return selEnvId;
	}

	public void setSelEnvId(String selEnvId) {
		this.selEnvId = selEnvId;
	}

	public String getTxtNoOfTables() {
		return this.txtNoOfTables;
	}

	public void setTxtNoOfTables(String txtNoOfTables) {
		this.txtNoOfTables = txtNoOfTables;
	}        
	public String getSelIsMultipleFilling() {
		return this.selIsMultipleFilling;
	}

	public void setSelIsMultipleFilling(String selIsMultipleFilling) {
		this.selIsMultipleFilling = selIsMultipleFilling;
	}        
	public String getSelIsEncryptionReq() {
		return this.selIsEncryptionReq;
	}

	public void setSelIsEncryptionReq(String selIsEncryptionReq) {
		this.selIsEncryptionReq = selIsEncryptionReq;
	}        
	public String getSelIsEvaluationReq() {
		return this.selIsEvaluationReq;
	}

	public void setSelIsEvaluationReq(String selIsEvaluationReq) {
		this.selIsEvaluationReq = selIsEvaluationReq;
	}        
	public String getSelIsDocumentReq() {
		return this.selIsDocumentReq;
	}

	public void setSelIsDocumentReq(String selIsDocumentReq) {
		this.selIsDocumentReq = selIsDocumentReq;
	}        
	public String getSelIsEncryptedDocument() {
		return this.selIsEncryptedDocument;
	}

	public void setSelIsEncryptedDocument(String selIsEncryptedDocument) {
		this.selIsEncryptedDocument = selIsEncryptedDocument;
	}        
	public String getSelIsMandatory() {
		return this.selIsMandatory;
	}

	public void setSelIsMandatory(String selIsMandatory) {
		this.selIsMandatory = selIsMandatory;
	}        
	public String getSelIsSecondary() {
		return this.selIsSecondary;
	}

	public void setSelIsSecondary(String selIsSecondary) {
		this.selIsSecondary = selIsSecondary;
	}        
	
	public String getSelIsPriceBid() {
		return selIsPriceBid;
	}

	public void setSelIsPriceBid(String selIsPriceBid) {
		this.selIsPriceBid = selIsPriceBid;
	}

	public CommonValidators getCommonValidators() {
		return commonValidators;
	}

	public void setCommonValidators(CommonValidators commonValidators) {
		this.commonValidators = commonValidators;
	}
	
	public void validate(BindingResult result,int rtf_length_limit){
		if(!commonValidators.isNotBlank(getTxtaFormName())){
			result.rejectValue("txtaFormName","msg_please_enter_value");
		}else{
			commonValidators.validateLength(getTxtaFormName(),500, "txtaFormName", result);
		}
		//Nikhil has Commented this validation  for the CR :28651
		//commonValidators.validateLength(getRtfFormHeader(),rtf_length_limit, "rtfFormHeader", result);   /*CR:28161 Max length changes*/ 
		//commonValidators.validateLength(getRtfFormFooter(),rtf_length_limit, "rtfFormFooter", result);	/*CR:28161 Max length changes*/ 

		if(!commonValidators.isNotBlank(getTxtNoOfTables())){
			result.rejectValue("txtNoOfTables","msg_please_enter_value");
		}else if("0".equals(getTxtNoOfTables())){
			result.rejectValue("txtNoOfTables","msg_invalid_nooftables");
		}else if(!commonValidators.isNumeric(getTxtNoOfTables())){
			result.rejectValue("txtNoOfTables","msg_js_common_validations_only_numeric");
		}else{
			commonValidators.rangeValidation(Integer.parseInt(getTxtNoOfTables()), 1, 99, "txtNoOfTables", result);
		}
		if(!isConsortiumAllowed()){
			setSelIsSecondary("0");
		}
	}
	
	private void encryptionValidation(boolean isCertRequired,boolean isOpeningByCommittee){
		HttpServletRequest request = getServletRequest();
		int pkiEnable=getSessionIsPkiEnabled(request);
		int isPasswordEncryptionReq=getSessionIsPasswordEncryptionReq(request);
		if("4".equals(getSelEnvId())){//Price Bid Envelope
			setSelIsPriceBid("1");// It is mandatory that if price bid envelope than IsPriceBid=yes
			setSelIsMultipleFilling("0");// It is mandatory that if price bid envelope than IsMultipleFilling=No
			//if(pkiEnable==1 || pkiEnable==2 || (isPasswordEncryptionReq==1)){Condition for non pki domain set 0 value as no encryption for non pki domain 
			/*** Change Request #17889  
			if(pkiEnable==1){
				setSelIsEncryptionReq("1");// It is mandatory that if price bid envelope than IsEncryptionReq=Yes
			}else{
				setSelIsEncryptionReq("0");
			}
			**/
			setSelIsSecondary("0");//Always No for secondary partner
			setSelIsEvaluationReq("0");
		}else if("5".equals(getSelEnvId())){//Techno Commercial Envelope
			if("1".equals(getSelIsPriceBid())){//If price bid=yes form then encryption require = yes
				//if(pkiEnable==1 || pkiEnable==2 || (isPasswordEncryptionReq==1)){Condition for non pki domain set 0 value as no encryption for non pki domain
				/*** Change Request #17889
				if(pkiEnable==1){
					setSelIsEncryptionReq("1");// It is mandatory that if price bid envelope than IsEncryptionReq=Yes
				}else{
					setSelIsEncryptionReq("0");
				}
				**/
				setSelIsMultipleFilling("0");
				setSelIsSecondary("0");//Always No for secondary partner
				setSelIsEvaluationReq("0");
			}else{
				if(!(pkiEnable==1 || (pkiEnable==2 && isCertRequired) || (isPasswordEncryptionReq==1))){
					if(!(pkiEnable==2 && !isCertRequired)){
						setSelIsEncryptionReq("0");
					}
				}
			}
		}else{
			setSelIsPriceBid("0");// It is mandatory that if other envelope than IsPriceBid=No
			if(!(pkiEnable==1 || (pkiEnable==2 && isCertRequired) || (isPasswordEncryptionReq==1))){
				if(!(pkiEnable==2 && !isCertRequired)){
					setSelIsEncryptionReq("0");
				} 
			}
		}
		if(pkiEnable==1 || pkiEnable==2 || (isPasswordEncryptionReq==1)){
			if("0".equals(getSelIsEncryptionReq()) || "0".equals(getSelIsDocumentReq())){
				setSelIsEncryptedDocument("0");
			}
		}else{
			setSelIsEncryptedDocument("0");
		}
		
		if(!isOpeningByCommittee){
			setSelIsEncryptionReq("0");
			setSelIsEncryptedDocument("0");
		}
	}
	
	public TblTenderForm toTblTenderForm(){
		encryptionValidation(isCertRequired(),isOpeningByCommittee());
		TblTenderForm tblTenderForm = new TblTenderForm();
		tblTenderForm.setFormName(getTxtaFormName());
		tblTenderForm.setFormHeader(getRtfFormHeader());
		tblTenderForm.setFormFooter(getRtfFormFooter());

		if(StringUtils.hasLength(getTxtNoOfTables()) && commonValidators.isNumeric(getTxtNoOfTables())){
			tblTenderForm.setNoOfTables(Integer.parseInt(getTxtNoOfTables()));
		}
		if(commonValidators.isNotBlank(getSelEnvId())){
			TblTenderEnvelope envelope= new TblTenderEnvelope();
			envelope.setTblEnvelope(new TblEnvelope(Integer.parseInt(getSelEnvId())));
			tblTenderForm.setTblTenderEnvelope(envelope);
		}
		if(commonValidators.isNotBlank(getSelIsDocumentReq())){
			tblTenderForm.setIsDocumentReq(Integer.parseInt(getSelIsDocumentReq()));
		}
		if(commonValidators.isNotBlank(getSelIsEncryptedDocument())){
			tblTenderForm.setIsEncryptedDocument(Integer.parseInt(getSelIsEncryptedDocument()));
		}
		if(commonValidators.isNotBlank(getSelIsEncryptionReq())){
			tblTenderForm.setIsEncryptionReq(Integer.parseInt(getSelIsEncryptionReq()));
		}
		if(commonValidators.isNotBlank(getSelIsEvaluationReq())){
			tblTenderForm.setIsEvaluationReq(Integer.parseInt(getSelIsEvaluationReq()));
		}
		if(commonValidators.isNotBlank(getSelIsMandatory())){
			tblTenderForm.setIsMandatory(Integer.parseInt(getSelIsMandatory()));
		}
		if(commonValidators.isNotBlank(getSelIsMultipleFilling())){
			tblTenderForm.setIsMultipleFilling(Integer.parseInt(getSelIsMultipleFilling()));
		}
		if(commonValidators.isNotBlank(getSelIsSecondary())){
			tblTenderForm.setIsSecondary(Integer.parseInt(getSelIsSecondary()));
		}
		if(commonValidators.isNotBlank(getSelIsPriceBid())){
			tblTenderForm.setIsPriceBid(Integer.parseInt(getSelIsPriceBid()));
		}
		return tblTenderForm;  
	}
	public HttpServletRequest getServletRequest() {
		ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
		return attr.getRequest();
	}

	public int getSessionIsPkiEnabled(HttpServletRequest request) {
		int isPkiEnabled = 0;
		ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
		if(clientBean != null) {
			isPkiEnabled = clientBean.getIsPkiEnabled();
		}
		return isPkiEnabled;
	}
	
	public int getSessionIsPasswordEncryptionReq(HttpServletRequest request) {
		int isPasswordEncryptionReq = 0;
		ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
		if(clientBean != null) {
			isPasswordEncryptionReq = clientBean.getIsPasswordEncryptionReq();
		}
		return isPasswordEncryptionReq;
	}
}