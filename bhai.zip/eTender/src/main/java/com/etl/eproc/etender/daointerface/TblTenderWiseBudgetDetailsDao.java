package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblTenderWiseBudgetDetails;
import java.util.List;

public interface TblTenderWiseBudgetDetailsDao  {

    public void addTblTenderWiseBudgetDetails(TblTenderWiseBudgetDetails tblTenderWiseBudgetDetails);

    public void deleteTblTenderWiseBudgetDetails(TblTenderWiseBudgetDetails tblTenderWiseBudgetDetails);

    public void updateTblTenderWiseBudgetDetails(TblTenderWiseBudgetDetails tblTenderWiseBudgetDetails);

    public List<TblTenderWiseBudgetDetails> getAllTblTenderWiseBudgetDetails();

    public List<TblTenderWiseBudgetDetails> findTblTenderWiseBudgetDetails(Object... values) throws Exception;

    public List<TblTenderWiseBudgetDetails> findByCountTblTenderWiseBudgetDetails(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderWiseBudgetDetailsCount();

    public void saveUpdateAllTblTenderWiseBudgetDetails(List<TblTenderWiseBudgetDetails> tblTenderWiseBudgetDetailss);

	public void saveOrUpdateTblTenderWiseBudgetDetails(TblTenderWiseBudgetDetails tbltenderwisebudgetdetails);
}