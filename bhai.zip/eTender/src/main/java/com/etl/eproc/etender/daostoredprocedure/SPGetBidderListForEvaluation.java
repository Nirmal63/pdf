/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author Krunal.patel
 */
@Component
public class SPGetBidderListForEvaluation extends StoredProcedure{
    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    
    private static final String SPROC_NAME = "apptenderresult.P_GetBidderListForEvaluation";
    
    public SPGetBidderListForEvaluation(){
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_EnvelopeId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_PreEnvelopeId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_EnvelopeType", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_IsConsortiumAllowed", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_SortOrder", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_IsCreatEditFlag", Types.INTEGER));
    }
    
    public Map<String,Object> executeProcedure(int tenderId,int envelopeId,int preEnvelopeId,int envelopeType,int IsConsortiumAllowed,int sortOrder,int isCreatEditFlag) {
        Map inParams = new HashMap();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_EnvelopeId",envelopeId);
        inParams.put("@V_PreEnvelopeId",preEnvelopeId);
        inParams.put("@V_EnvelopeType",envelopeType);
        inParams.put("@V_IsConsortiumAllowed",IsConsortiumAllowed);
        inParams.put("@V_SortOrder",sortOrder);
        inParams.put("@V_IsCreatEditFlag",isCreatEditFlag);
        this.compile();
        return execute(inParams);
    }
}
