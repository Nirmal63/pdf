/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderBidMatrixDao;
import com.etl.eproc.etender.model.TblTenderBidMatrix;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author taher.tinwala
 */
/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderBidMatrixImpl extends AbcAbstractClass<TblTenderBidMatrix> implements TblTenderBidMatrixDao {

    @Override
    public void addTblTenderBidMatrix(TblTenderBidMatrix tblTenderBidMatrix){
        super.addEntity(tblTenderBidMatrix);
    }

    @Override
    public void deleteTblTenderBidMatrix(TblTenderBidMatrix tblTenderBidMatrix) {
        super.deleteEntity(tblTenderBidMatrix);
    }

    @Override
    public void updateTblTenderBidMatrix(TblTenderBidMatrix tblTenderBidMatrix) {
        super.updateEntity(tblTenderBidMatrix);
    }

    @Override
    public List<TblTenderBidMatrix> getAllTblTenderBidMatrix() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderBidMatrix> findTblTenderBidMatrix(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderBidMatrixCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderBidMatrix> findByCountTblTenderBidMatrix(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderBidMatrix(List<TblTenderBidMatrix> tblTenderBidMatrixs){
        super.updateAll(tblTenderBidMatrixs);
    }
}

