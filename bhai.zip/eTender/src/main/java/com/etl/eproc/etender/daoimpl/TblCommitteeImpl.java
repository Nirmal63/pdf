/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblCommitteeDao;
import com.etl.eproc.etender.model.TblCommittee;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author shreyansh.shah
 */
@Repository @Transactional
public class TblCommitteeImpl extends AbcAbstractClass<TblCommittee> implements TblCommitteeDao {

   
    @Override
    public void addTblCommittee(TblCommittee tblCommittee){
        super.addEntity(tblCommittee);
    }

    @Override
    public void deleteTblCommittee(TblCommittee tblCommittee) {
        super.deleteEntity(tblCommittee);
    }

    @Override
    public void updateTblCommittee(TblCommittee tblCommittee) {
        super.updateEntity(tblCommittee);
    }

    @Override
    public List<TblCommittee> getAllTblCommittee() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCommittee> findTblCommittee(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCommitteeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCommittee> findByCountTblCommittee(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCommittee(List<TblCommittee> tblCommittees){
        super.updateAll(tblCommittees);
    }
}
