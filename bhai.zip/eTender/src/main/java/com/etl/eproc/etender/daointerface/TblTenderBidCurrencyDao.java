package com.etl.eproc.etender.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.*;
import java.util.List;

public interface TblTenderBidCurrencyDao  {

    public void addTblTenderBidCurrency(TblTenderBidCurrency tblTenderBidCurrency);

    public void deleteTblTenderBidCurrency(TblTenderBidCurrency tblTenderBidCurrency);

    public void updateTblTenderBidCurrency(TblTenderBidCurrency tblTenderBidCurrency);

    public List<TblTenderBidCurrency> getAllTblTenderBidCurrency();

    public List<TblTenderBidCurrency> findTblTenderBidCurrency(Object... values) throws Exception;

    public List<TblTenderBidCurrency> findByCountTblTenderBidCurrency(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblTenderBidCurrencyCount();

    public void saveUpdateAllTblTenderBidCurrency(List<TblTenderBidCurrency> tblTenderBidCurrencys);
}