/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlOutParameter;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author Krunal.patel
 */
@Component
public class SPBoqDump extends StoredProcedure{
    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    
    private static final String SPROC_NAME = "appcommon.P_BoqDump";
    
    public SPBoqDump(){
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_indentId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_eventId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_linkId", Types.INTEGER));
        this.declareParameter(new SqlOutParameter("@V_formId", Types.INTEGER));
    }
    
    public Map<String,Object> executeProcedure(int indentId,int eventId,int linkId) {
        Map inParams = new HashMap();
        inParams.put("@V_indentId", indentId);
        inParams.put("@V_eventId",eventId);
        inParams.put("@V_linkId",linkId);
        this.compile();
        return execute(inParams);
    }
}
