package com.etl.eproc.etender.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblTenderFormulaDao;
import com.etl.eproc.etender.model.TblTenderFormula;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblTenderFormulaImpl extends AbcAbstractClass<TblTenderFormula> implements TblTenderFormulaDao {


    @Override
    public void addTblTenderFormula(TblTenderFormula tblTenderFormula) {
        super.addEntity(tblTenderFormula);
    }

    @Override
    public void deleteTblTenderFormula(TblTenderFormula tblTenderFormula) {
        super.deleteEntity(tblTenderFormula);
    }

    @Override
    public void updateTblTenderFormula(TblTenderFormula tblTenderFormula) {
        super.updateEntity(tblTenderFormula);
    }

    @Override
    public List<TblTenderFormula> getAllTblTenderFormula() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTenderFormula> findTblTenderFormula(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTenderFormulaCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTenderFormula> findByCountTblTenderFormula(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTenderFormula(List<TblTenderFormula> tblTenderFormulas) {
        super.updateAll(tblTenderFormulas);
    }
}
