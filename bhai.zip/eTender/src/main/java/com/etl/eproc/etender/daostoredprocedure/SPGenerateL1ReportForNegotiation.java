/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.daostoredprocedure;

import java.sql.Types;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.StoredProcedure;
import org.springframework.stereotype.Component;

/**
 *
 * @author Krunal.Patel
 */
@Component
public class SPGenerateL1ReportForNegotiation extends StoredProcedure {

    @Autowired
    @Qualifier("dataSource")
    public void init(BasicDataSource factory) {
        setDataSource(factory);
    }
    private static final String SPROC_NAME = "apptenderresult.P_GenerateL1ReportForNegotiation";

    public SPGenerateL1ReportForNegotiation() {
        super.setSql(SPROC_NAME);
        this.declareParameter(new SqlParameter("@V_TenderId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_TenderResult", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_UserDetailId", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_FromCorrigendum", Types.INTEGER));
        this.declareParameter(new SqlParameter("@V_FromType", Types.INTEGER));
    }

    /**
     * Method use for call store procedure to Generate L1 Report For Negotiation.
     * @param tenderId
     * @param reportTypeId
     * @return {@code Map<String,Object>}
     * @throws Exception 
     */
    public Map<String,Object> executeProcedure(int tenderId, int tenderResult,int userDetailId,int fromCorrigendum,int fromType) throws Exception
    {
        Map inParams = new HashMap();
        inParams.put("@V_TenderId", tenderId);
        inParams.put("@V_TenderResult", tenderResult);
        inParams.put("@V_UserDetailId", userDetailId);
        inParams.put("@V_FromCorrigendum", fromCorrigendum);
        inParams.put("@V_FromType", fromType);        
        this.compile();

        return execute(inParams);
    }
}

