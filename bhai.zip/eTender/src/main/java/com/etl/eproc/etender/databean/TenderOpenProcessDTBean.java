package com.etl.eproc.etender.databean;

import java.util.LinkedHashMap;
import java.util.List;

public class TenderOpenProcessDTBean {
	private List<LinkedHashMap<String, Object>> envelopeList ;
	private List<LinkedHashMap<String, Object>> committeeMemeberList ;
	private List<LinkedHashMap<String, Object>> bidderDetailList ;
	private List<LinkedHashMap<String, Object>> verifyList ;
	private List<LinkedHashMap<String, Object>> tenderDetailsList ;
	private LinkedHashMap<String, Object> tblShareReportMap;
	private List<LinkedHashMap<String, Object>> tenderReportDetailsList ;
	private int reportConfigurationCount;//Use only for Report Configuration link 
	
	public int getReportConfigurationCount() {
		return reportConfigurationCount;
	}
	public void setReportConfigurationCount(int reportConfigurationCount) {
		this.reportConfigurationCount = reportConfigurationCount;
	}
	public List<LinkedHashMap<String, Object>> getTenderReportDetailsList() {
		return tenderReportDetailsList;
	}
	public void setTenderReportDetailsList(
			List<LinkedHashMap<String, Object>> tenderReportDetailsList) {
		this.tenderReportDetailsList = tenderReportDetailsList;
	}
	public LinkedHashMap<String, Object> getTblShareReportMap() {
		return tblShareReportMap;
	}
	public void setTblShareReportMap(LinkedHashMap<String, Object> tblShareReportMap) {
		this.tblShareReportMap = tblShareReportMap;
	}
	public List<LinkedHashMap<String, Object>> getTenderDetailsList() {
		return tenderDetailsList;
	}
	public void setTenderDetailsList(
			List<LinkedHashMap<String, Object>> tenderDetailsList) {
		this.tenderDetailsList = tenderDetailsList;
	}
	public List<LinkedHashMap<String, Object>> getEnvelopeList() {
		return envelopeList;
	}
	public void setEnvelopeList(List<LinkedHashMap<String, Object>> envelopeList) {
		this.envelopeList = envelopeList;
	}
	public List<LinkedHashMap<String, Object>> getCommitteeMemeberList() {
		return committeeMemeberList;
	}
	public void setCommitteeMemeberList(
			List<LinkedHashMap<String, Object>> committeeMemeberList) {
		this.committeeMemeberList = committeeMemeberList;
	}
	public List<LinkedHashMap<String, Object>> getBidderDetailList() {
		return bidderDetailList;
	}
	public void setBidderDetailList(
			List<LinkedHashMap<String, Object>> bidderDetailList) {
		this.bidderDetailList = bidderDetailList;
	}
	public List<LinkedHashMap<String, Object>> getVerifyList() {
		return verifyList;
	}
	public void setVerifyList(List<LinkedHashMap<String, Object>> verifyList) {
		this.verifyList = verifyList;
	}
}
