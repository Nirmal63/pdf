package com.etl.eproc.etender.daoimpl;

/**
* @author Lipi Shah
*/
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblBroadCastQuestionMappingDao;
import com.etl.eproc.etender.model.TblBroadCastQuestionMapping;

/**
 *
 * @author taher
 */
@Repository @Transactional
public class TblBroadCastQuestionMappingImpl extends AbcAbstractClass<TblBroadCastQuestionMapping> implements TblBroadCastQuestionMappingDao {

    

    @Override
    public void addTblBroadCastQuestionMapping(TblBroadCastQuestionMapping tblBroadCastQuestionMapping){
        super.addEntity(tblBroadCastQuestionMapping);
    }

    @Override
    public void deleteTblBroadCastQuestionMapping(TblBroadCastQuestionMapping tblBroadCastQuestionMapping) {
        super.deleteEntity(tblBroadCastQuestionMapping);
    }

    @Override
    public void updateTblBroadCastQuestionMapping(TblBroadCastQuestionMapping tblBroadCastQuestionMapping) {
        super.updateEntity(tblBroadCastQuestionMapping);
    }

    @Override
    public List<TblBroadCastQuestionMapping> getAllTblBroadCastQuestionMapping() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBroadCastQuestionMapping> findTblBroadCastQuestionMapping(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBroadCastQuestionMappingCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBroadCastQuestionMapping> findByCountTblBroadCastQuestionMapping(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBroadCastQuestionMapping(List<TblBroadCastQuestionMapping> tblBroadCastQuestionMappings){
        super.updateAll(tblBroadCastQuestionMappings);
    }
}
