/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.etender.services;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.HibernateQueryDao;
import com.etl.eproc.common.daointerface.TblEventFeesDao;
import com.etl.eproc.common.daointerface.TblOnlinePaymentDao;
import com.etl.eproc.common.daointerface.TblPaymentDao;
import com.etl.eproc.common.daointerface.TblUserLoginDao;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.etender.daointerface.TblBidDetailDao;
import com.etl.eproc.etender.daointerface.TblBidderPresenceDao;
import com.etl.eproc.etender.daointerface.TblChallanDao;
import com.etl.eproc.etender.daointerface.TblConsortiumDao;
import com.etl.eproc.etender.daointerface.TblConsortiumDetailDao;
import com.etl.eproc.etender.daointerface.TblItemSelectionDao;
import com.etl.eproc.etender.daointerface.TblRebateDetailDao;
import com.etl.eproc.etender.daointerface.TblTenderBidConfirmationDao;
import com.etl.eproc.etender.daointerface.TblTenderBidCurrencyDao;
import com.etl.eproc.etender.daointerface.TblTenderBidDao;
import com.etl.eproc.etender.daointerface.TblTenderBidDetailDao;
import com.etl.eproc.etender.daointerface.TblTenderBidMatrixDao;
import com.etl.eproc.etender.daointerface.TblTenderBidOpenSignDao;
import com.etl.eproc.etender.daointerface.TblTenderBidRegressionDao;
import com.etl.eproc.etender.daointerface.TblTenderBidRegressionHistoryDao;
import com.etl.eproc.etender.daointerface.TblTenderDao;
import com.etl.eproc.etender.daointerface.TblTenderOpenDao;
import com.etl.eproc.etender.daointerface.TblTenderProxyBidDao;
import com.etl.eproc.etender.daointerface.TblTenderRebateDao;
import com.etl.eproc.etender.daointerface.TblTenderTableDao;
import com.etl.eproc.etender.daostoredprocedure.SPResetConsortium;
import com.etl.eproc.etender.daostoredprocedure.SpBidWithdrawal;
import com.etl.eproc.etender.model.TblBidDetail;
import com.etl.eproc.etender.model.TblBidderPresence;
import com.etl.eproc.etender.model.TblChallan;
import com.etl.eproc.etender.model.TblConsortium;
import com.etl.eproc.etender.model.TblConsortiumDetail;
import com.etl.eproc.etender.model.TblEventFees;
import com.etl.eproc.etender.model.TblItemSelection;
import com.etl.eproc.etender.model.TblRebateDetail;
import com.etl.eproc.etender.model.TblTender;
import com.etl.eproc.etender.model.TblTenderBid;
import com.etl.eproc.etender.model.TblTenderBidConfirmation;
import com.etl.eproc.etender.model.TblTenderBidCurrency;
import com.etl.eproc.etender.model.TblTenderBidDetail;
import com.etl.eproc.etender.model.TblTenderBidMatrix;
import com.etl.eproc.etender.model.TblTenderBidOpenSign;
import com.etl.eproc.etender.model.TblTenderBidRegression;
import com.etl.eproc.etender.model.TblTenderBidRegressionHistory;
import com.etl.eproc.etender.model.TblTenderCell;
import com.etl.eproc.etender.model.TblTenderForm;
import com.etl.eproc.etender.model.TblTenderOpen;
import com.etl.eproc.etender.model.TblTenderProxyBid;
import com.etl.eproc.etender.model.TblTenderRebate;
import com.etl.eproc.etender.model.TblTenderTable;

/**
 *
 * @author TaherT
 */
@Service
public class EventBidSubmissionService {

    @Autowired
    private HibernateQueryDao hibernateQueryDao;
    @Autowired
    private TblTenderBidMatrixDao tblTenderBidMatrixDao;
    @Autowired
    private TblTenderBidDao tblTenderBidDao;   
    @Autowired
    private TblTenderBidConfirmationDao tblTenderBidConfirmationDao;
    @Autowired
    private TblTenderBidCurrencyDao tblTenderBidCurrencyDao; 
    @Autowired
    private TblBidderPresenceDao tblBidderPresenceDao;
    @Autowired
    private CommonService commonService;
    @Autowired
    private TblConsortiumDetailDao tblConsortiumDetailDao;
    @Autowired
    private TblConsortiumDao tblConsortiumDao;
    @Autowired
    private TblRebateDetailDao tblRebateDetailDao;
    @Autowired
    private SpBidWithdrawal spBidWithdrawal;
    @Autowired
    private SPResetConsortium sPResetConsortium;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private TblTenderRebateDao tblTenderRebateDao;
    @Autowired
    private TblPaymentDao tblPaymentDao;
    @Autowired
    private TblOnlinePaymentDao tblOnlinePaymentDao;
    @Autowired
    private TblEventFeesDao tblEventFeesDao;
    @Autowired
    private TblChallanDao tblChallanDetailsDao;
    @Autowired
    private TblTenderOpenDao tblTenderOpenDao;
    @Autowired
    private TblTenderBidOpenSignDao tblTenderBidOpenSignDao;
    @Autowired
    private TblTenderBidDetailDao tblTenderBidDetailDao;
    @Autowired
    private TblBidDetailDao tblBidDetailDao;
    @Autowired
    private TblItemSelectionDao tblItemSelectionDao;
    @Autowired
    private TblTenderProxyBidDao tblTenderProxyBidDao;
    @Autowired
    private TenderCommonService tenderCommonService;
    @Autowired
    private TenderOpenService tenderOpenService;
    @Autowired
    private TenderFormService tenderFormService;
    @Autowired
    private TblTenderBidRegressionDao tblTenderBidRegretDao;
    @Autowired
    private TblTenderBidRegressionDao tblTenderBidRegressionDao;
    @Autowired
    public TblTenderBidRegressionHistoryDao tblTenderBidRegressionHistoryDao;
    @Autowired
    TblUserLoginDao tblUserLoginDao;
    @Autowired
    TblTenderDao tbltenderDao;
    @Autowired
    TblTenderTableDao tblTenderTableDao;
    private static final String TENDERID = "tenderId";
    private static final String USERID =  "userId";
    private static final String COMPANYID =  "companyId";
    /**
     * Add Bidder bid for the Tender Form
     * @param tblTenderBid
     * @param tblTenderBidMatrixs
     * @param tblRebateDetails
     * @return true for success; false for fail
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addBidderBid(TblTenderBid tblTenderBid, List<TblTenderBidMatrix> tblTenderBidMatrixs,List<TblRebateDetail> tblRebateDetails,List<TblEventFees> tblEventFeeses,List<TblBidDetail> bidDetails,List<TblItemSelection> itemSelections,boolean iscgClient,boolean isPriceBid) throws Exception {
        boolean bSuccess = false;
        if(tblTenderBid!=null){
            tblTenderBidDao.addTblTenderBid(tblTenderBid);
        }else{
            if(!tblTenderBidMatrixs.isEmpty()){
                deleteBidFees(tblTenderBidMatrixs.get(0).getTblTenderBid().getBidId());
                deleteBid(tblTenderBidMatrixs.get(0).getTblTenderBid().getBidId());
            }
        }
        tblTenderBidMatrixDao.saveUpdateAllTblTenderBidMatrix(tblTenderBidMatrixs);
        if(!tblRebateDetails.isEmpty()){
            tblRebateDetailDao.saveUpdateAllTblRebateDetail(tblRebateDetails);
        }
        if(!tblEventFeeses.isEmpty()){
        	if(tblTenderBid!=null){
        	 for (TblEventFees tblEventFees : tblEventFeeses) {
        		 tblEventFees.setBidId(tblTenderBid.getBidId());
        	 }
        	}
            tblEventFeesDao.saveUpdateAllTblEventFees(tblEventFeeses);
        }
        if(!bidDetails.isEmpty()){
            Map<String, Object> var = new HashMap<String, Object>();
            var.put("companyId",bidDetails.get(0).getCompanyId());
            var.put("formId",bidDetails.get(0).getFormId());
            hibernateQueryDao.updateDeleteNewQuery("delete from TblBidDetail where companyId=:companyId and formId=:formId", var);
            tblBidDetailDao.saveUpdateAllTblBidDetail(bidDetails);
        }      
        if(!itemSelections.isEmpty()){
        	if(iscgClient && isPriceBid && itemSelections.get(0).getIsSelected()==1){
	            
	                Map<String, Object> var = new HashMap<String, Object>();
	                var.put("companyId",itemSelections.get(0).getTblCompany().getCompanyId());
	                var.put("formId",itemSelections.get(0).getTblTenderForm().getFormId());
	                Map<Integer,List<Integer>> tableRows = new HashMap<Integer, List<Integer>>();
	                for (TblItemSelection tblItemSelection : itemSelections) {
	                    List<Integer> rowId = null;
	                    if(tableRows.containsKey(tblItemSelection.getTblTenderTable().getTableId())){
	                        rowId = tableRows.get(tblItemSelection.getTblTenderTable().getTableId());
	                    }else{                        
	                        rowId = new ArrayList<Integer>();
	                    }
	                    rowId.add(tblItemSelection.getRowId());
	                    tableRows.put(tblItemSelection.getTblTenderTable().getTableId(), rowId);
	                }
	                //Set<Integer> keys=tableRows.keySet();
	               // Object[] tableIds=keys.toArray();
	                Map<String, Object> var1 = new HashMap<String, Object>();
	                var1.put("companyId",itemSelections.get(0).getTblCompany().getCompanyId());
	                var1.put("formId",itemSelections.get(0).getTblTenderForm().getFormId());
	                //var1.put("tableIds",tableIds);
	                hibernateQueryDao.updateDeleteNewQuery("update TblItemSelection set isBidded=0 where tblTenderForm.formId=:formId and tblCompany.companyId=:companyId  ", var1);
	                tblItemSelectionDao.saveUpdateAllTblItemSelection(itemSelections);
	                
	            
        	}else{
    			if(itemSelections.get(0).getIsSelected()==-1){
                    Map<String, Object> var = new HashMap<String, Object>();
                    var.put("companyId",itemSelections.get(0).getTblCompany().getCompanyId());
                    var.put("formId",itemSelections.get(0).getTblTenderForm().getFormId());
                    Map<Integer,List<Integer>> tableRows = new HashMap<Integer, List<Integer>>();
                    for (TblItemSelection tblItemSelection : itemSelections) {
                        List<Integer> rowId = null;
                        if(tableRows.containsKey(tblItemSelection.getTblTenderTable().getTableId())){
                            rowId = tableRows.get(tblItemSelection.getTblTenderTable().getTableId());
                        }else{                        
                            rowId = new ArrayList<Integer>();
                        }
                        rowId.add(tblItemSelection.getRowId());
                        tableRows.put(tblItemSelection.getTblTenderTable().getTableId(), rowId);
                    }
                    //Set<Integer> keys=tableRows.keySet();
                   // Object[] tableIds=keys.toArray();
                    Map<String, Object> var1 = new HashMap<String, Object>();
                    var1.put("companyId",itemSelections.get(0).getTblCompany().getCompanyId());
                    var1.put("formId",itemSelections.get(0).getTblTenderForm().getFormId());
                    //var1.put("tableIds",tableIds);
                    hibernateQueryDao.updateDeleteNewQuery("update TblItemSelection set isBidded=0 where tblTenderForm.formId=:formId and tblCompany.companyId=:companyId  ", var1);
                    for (Integer tableId : tableRows.keySet()) {
                    	var.put("tableId",tableId);
                        var.put("rowId",tableRows.get(tableId));
                        hibernateQueryDao.updateDeleteNewQuery("update TblItemSelection set isBidded=1 where tblTenderForm.formId=:formId and tblCompany.companyId=:companyId and tblTenderTable.tableId=:tableId and rowId in (:rowId)", var);
                    }
                    
                }else{
                    Map<String, Object> var = new HashMap<String, Object>();
                    var.put("companyId",itemSelections.get(0).getTblCompany().getCompanyId());
                    var.put("formId",itemSelections.get(0).getTblTenderForm().getFormId());
                    hibernateQueryDao.updateDeleteNewQuery("delete from TblItemSelection where tblTenderForm.formId=:formId and tblCompany.companyId=:companyId", var);
                    tblItemSelectionDao.saveUpdateAllTblItemSelection(itemSelections);
                }
        	}
        }
        if(!tblTenderBidMatrixs.isEmpty()){
            Map<String, Object> var = new HashMap<String, Object>();
            var.put("bidId",tblTenderBidMatrixs.get(0).getTblTenderBid().getBidId());
            var.put("ipAddress",tblTenderBidMatrixs.get(0).getTblTenderBid().getIpAddress());
            var.put("cstatus",tblTenderBidMatrixs.get(0).getTblTenderBid().getCstatus());
            hibernateQueryDao.updateDeleteNewQuery("update TblTenderBid set ipAddress=:ipAddress,cstatus=:cstatus where bidId=:bidId", var);
        }
        bSuccess = true;
        return bSuccess;

    }
    public boolean deletetenderFeesBid(int bidId,int feetype) throws Exception{
    	   Map<String, Object> var = new HashMap<String, Object>();
    	   int cnt = 0;
    	   var.put("bidId",bidId);
    	   var.put("feeType",feetype);
    	   cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblEventFees tblEventFees  where tblEventFees.bidId=:bidId and tblEventFees.cstatus=0 and tblEventFees.feeType=:feeType ",var);
    	   return cnt!=0;
    }
    /**
     * 
     * @param bidId
     * @return
     * @throws Exception 
     */
    public boolean deleteBid(int bidId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidId",bidId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderBidMatrix tbltenderbidmatrix where tbltenderbidmatrix.tblTenderBid.bidId=:bidId",var);        
        return cnt!=0;

    }
    

    /**
     * Get Officer/Decryptor public key
     * @param tenderId
     * @param envelopeId
     * @return{@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getOfficerPublicKey(int tenderId,int envelopeId) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID,tenderId);
//        var.put("envelopeId",envelopeId);
        list = hibernateQueryDao.createNewQuery("select distinct tbltenderpublickey.publicKey,tblcommitteeuser.encryptionLevel from TblCommittee tblcommittee inner join tblcommittee.tblTender tbltender inner join tblcommittee.tblCommitteeUser tblcommitteeuser inner join tbltender.tblTenderPublicKey tbltenderpublickey where tbltender.tenderId=:tenderId and tblcommittee.committeeType=1 and tblcommittee.isActive=1 and tblcommittee.isApproved=1 and tblcommitteeuser.tblUserLogin.userId=tbltenderpublickey.tblUserLogin.userId",var);                
        //list = hibernateQueryDao.createNewQuery("select tbltenderpublickey.publicKey,tblcommitteeuser.encryptionLevel from TblCommittee tblcommittee inner join tblcommittee.tblTender tbltender inner join tblcommittee.tblCommitteeUser tblcommitteeuser inner join tbltender.tblTenderPublicKey tbltenderpublickey where tbltender.tenderId=:tenderId and tblcommittee.committeeType=1 and tblcommittee.isActive=1 and tblcommittee.isApproved=1 and tblcommitteeuser.tblUserLogin.userId=tbltenderpublickey.tblUserLogin.userId and tblcommitteeuser.childId=:envelopeId",var);                
        return list;        

    }
    /**
     * 
     * @param tenderBidConfirmation
     * @param tblTenderBidCurrency
     * @return
     * @throws Exception 
     */
  @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addTenderBidConfm(TblTenderBidConfirmation tenderBidConfirmation, List<TblTenderProxyBid>lstTblTenderProxyBid ) throws Exception{
		boolean bSuccess = false;
		tblTenderBidConfirmationDao.addTblTenderBidConfirmation(tenderBidConfirmation);
		if(lstTblTenderProxyBid != null && !lstTblTenderProxyBid.isEmpty()){
			tblTenderProxyBidDao.saveUpdateAllTblTenderProxyBid(lstTblTenderProxyBid);
		}
		bSuccess = true;
		return bSuccess;
  }
     
      /**
       * 
       * @param tblTenderBidCurrency
       * @return
       * @throws Exception 
       */
      public boolean addTenderBidCurrency(TblTenderBidCurrency tblTenderBidCurrency) throws Exception{
      boolean bSuccess = false;             
         tblTenderBidCurrencyDao.addTblTenderBidCurrency(tblTenderBidCurrency);
         bSuccess=true;        
         return bSuccess;

      }  
      
      /**
       * 
       * @param eventTypeId 
       * @param Object>
       * @return
       * @throws Exception 
       */
      public List<Object[]> getTenderBidConfirmForm(int tenderId, ModelMap modelMap,int sessionClientId, String languageId, int eventTypeId ) throws Exception{
      	StringBuilder query = new StringBuilder();
  		 Map<String, Object> map = new HashMap<String, Object>();
  	        map.put("clientId",sessionClientId);
  	        map.put("languageId", languageId);
  	        map.put("isActive", 1);
  	        map.put("eventTypeId", eventTypeId);
  	        query.append("select tblclientbidterm.clientBidTermId ,tblclientbidterm.bidTerm ")
             .append(" from  TblClientBidTerm tblclientbidterm ")
             .append(" inner join tblclientbidterm.tblEventType tblEventType ")
             .append(" inner join tblclientbidterm.tblLanguage tblLanguage ")
             .append(" inner join tblclientbidterm.tblClient tblClient ")
             .append(" where tblclientbidterm.tblEventType.eventTypeId=:eventTypeId and  tblLanguage.languageId=:languageId ")
             .append(" and tblclientbidterm.isActive=:isActive and tblClient.clientId=:clientId ");   
  			return hibernateQueryDao.createNewQuery(query.toString(),map);
      }
      
      /**
       * 
       * @param tenderId
       * @return biddingtype
       * @throws Exception 
       */
       public int getBiddingType(int tenderId) throws Exception{        
          StringBuilder query = new StringBuilder();
          Map<String, Object> var = new HashMap<String, Object>();
          var.put(TENDERID,tenderId);
          query.append("select tbltender.biddingType from TblTender tbltender where tbltender.tenderId=:tenderId");
          List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(),var);
          return   list.isEmpty() ? 0 : (Integer) list.get(0);

      }
       /**
        * 
        * @param tenderId
        * @return
        * @throws Exception 
        */
       public List<Object[]> getCurrencies(int tenderId, int companyId, boolean isBidCurrency) throws Exception{    	 
  		 StringBuilder query = new StringBuilder();
  		 Map<String, Object> map = new HashMap<String, Object>();
  		 map.put(TENDERID, tenderId);
  		 map.put("isActive", 1);
  		 
  		 query.append("select tbltendercurrency.tenderCurrencyId,tblcurrency.lang")
  		 	  .append(WebUtils.getCookie(getServletRequest(), "locale").getValue());
  		 if(isBidCurrency){
  			query.append(",tbltenderbidcurrency.bidCurrencyId ");
  		 }
  		query.append(" from TblTenderCurrency tbltendercurrency")
  		 	  .append(" inner join tbltendercurrency.tblCurrency tblcurrency  ");				
  		 if(isBidCurrency){
  			 map.put("companyId", companyId);
  			 query.append("inner join tbltendercurrency.tblTenderBidCurrency tbltenderbidcurrency with tbltenderbidcurrency.tblCompany.companyId=:companyId");
  		 }
  		 query.append(" where tbltendercurrency.tblTender.tenderId=:tenderId and tbltendercurrency.isActive=:isActive");		 		 
  		 return hibernateQueryDao.createNewQuery(query.toString(),map);    
       }
       /**
        * 
        * @param tenderId
        * @return eventTypeId
        * @throws Exception 
        */
       public int getEventTypeId(int tenderId) throws Exception{
           StringBuilder query = new StringBuilder();
           Map<String, Object> var = new HashMap<String, Object>();
           var.put(TENDERID,tenderId);
           query.append(" select tblEventType.eventTypeId from TblTender tbltender ")
           	  .append(" inner join tbltender.tblEventType tblEventType")
           	  .append(" where tbltender.tenderId=:tenderId");
           List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(),var);                
           return list.isEmpty() ? 0 : (Integer) list.get(0);
       }
       
       /**
        * 
        * @param tenderId
        * @param bidderId
        * @return
        * @throws Exception 
        */
       public boolean isTenderIdRepeated(int tenderId,int bidderId) throws Exception{

           long count=0;
           Map<String, Object> var = new HashMap<String, Object>();
           var.put(TENDERID,tenderId);
           var.put("bidderId",bidderId);
           count = hibernateQueryDao.countForNewQuery("TblTenderBidConfirmation tbltenderbidconfirmation ","tbltenderbidconfirmation.bidConfirmationId ","tbltenderbidconfirmation.tblUserLogin.userId=:bidderId and tbltenderbidconfirmation.tblTender.tenderId=:tenderId",var);
           return count!=0;
       }
       
       
       /**
        * @author purvesh
        * @param tenderId
        * @param bidderId
        * @param userDetailedId 
        * @param comppanydId
        * @param remarks
        * @param ipAddress
        * @return
        * @throws Exception 
        */
       @Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
       public boolean withdrawBid(int tenderId, int bidderId, int userDetailId, int companyId, String remark, String ipAddress) throws Exception {
    	   int result=0;
           List<LinkedHashMap<String, Object>> lstBidWithdrawal = spBidWithdrawal.executeProcedure(tenderId, companyId, bidderId, userDetailId, ipAddress, remark);
           if (lstBidWithdrawal != null && !lstBidWithdrawal.isEmpty() && lstBidWithdrawal.get(0).get("result") != null) {
               result = Integer.parseInt(lstBidWithdrawal.get(0).get("result").toString());
           }
           deleteBidOpenData(tenderId, companyId);
           deleteTenderRebateDetails(tenderId, companyId);
           return result!=0;
       }
       
       /**
        * @author purvesh
        * @param tenderId
        * @param comppanydId
        * @return
        * @throws Exception 
        */
       public boolean isFinalSubmissionDone(int tenderId, int companyId) throws Exception {
	      	long count = 0;
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put(TENDERID, tenderId);
	        var.put(COMPANYID, companyId);
	        count = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblfinalsubmission ", "tblfinalsubmission.finalSubmissionId ", "tblfinalsubmission.tblCompany.companyId=:companyId and tblfinalsubmission.tblTender.tenderId=:tenderId and tblfinalsubmission.isActive=1", var);
	        return count != 0;
       }   
       /**
        * @author dharmesh
        * @param tenderId
        * @param comppanydId
        * @return
        * @throws Exception 
        */
       public boolean isBidWithdrawal(int tenderId, int companyId) throws Exception {
	      	long count = 0;
	        Map<String, Object> var = new HashMap<String, Object>();
	        var.put(TENDERID, tenderId);
	        var.put(COMPANYID, companyId);
	        count = hibernateQueryDao.countForNewQuery("TblBidWithdrawal tblBidWithdrawal ", "tblBidWithdrawal.bidWithdrawalId ", "tblBidWithdrawal.tblCompany.companyId=:companyId and tblBidWithdrawal.tblTender.tenderId=:tenderId ", var);
	        return count != 0;
       }
    public HttpServletRequest getServletRequest() {
           ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
           return attr.getRequest();
       }
    /**
     * 
     * @param tblBidderPresence
     * @return
     * @throws Exception 
     */
    public boolean remarkForTenderOpening(TblBidderPresence tblBidderPresence) throws Exception{
		boolean bSuccess = false;
		tblBidderPresenceDao.addTblBidderPresence(tblBidderPresence);
		bSuccess = true;
		return bSuccess;
    }

    /**
     * Method use for get consortiumIds secondary partner request.
     * @author dipal
     * @param userId
     * @param tenderId
     * @return {@code List<Object>}
     */
    public List<Object> getConsDtlForSecondPartReq(int tenderId,int userId)
    {
        StringBuilder query=new StringBuilder();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(TENDERID, tenderId);
        map.put("userId", userId);
        
        query.append(" SELECT CO.consortiumId ");
        query.append(" FROM TblConsortium CO ");
        query.append(" INNER JOIN CO.tblConsortiumDetail  CD  ");
        query.append(" WHERE CO.tblTender.tenderId=:tenderId AND CO.isActive!=2 AND CD.tblUserLogin.userId=:userId AND (CD.cstatus = 0 OR (CD.cstatus = 1 AND CD.partnerType=3))");
        query.append(" ORDER BY CD.cstatus DESC");
        return hibernateQueryDao.singleColQuery(query.toString(),map); 
    }
    
    
    /**
     * Method use for check consortium reset by lead partner if secondary partner have already accepted request.
     * @author dipal
     * @param userId
     * @param tenderId
     * @return {@code List<Object>}
     */
    public List<Object> checkConsortiumResetForSecondaryPartner(int tenderId,int userId)
    {
        StringBuilder query=new StringBuilder();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(TENDERID, tenderId);
        map.put("userId", userId);
        
        query.append(" SELECT CO.consortiumId ");
        query.append(" FROM TblConsortium CO ");
        query.append(" INNER JOIN CO.tblConsortiumDetail  CD  ");
        query.append(" WHERE CO.tblTender.tenderId=:tenderId AND CO.isActive=2 AND CD.tblUserLogin.userId=:userId AND CD.cstatus = 1 AND CD.partnerType=3");
        query.append(" AND CO.consortiumId > ").append(" (SELECT ISNULL(MAX(CCO.consortiumId),0) FROM TblConsortium CCO INNER JOIN CCO.tblConsortiumDetail CCD WHERE CCO.tblTender.tenderId=:tenderId AND CCO.isActive!=2 AND CCD.tblUserLogin.userId=:userId)");
        return hibernateQueryDao.singleColQuery(query.toString(),map); 
    }
    
    /**
     * Method use for get consortium detail.
     * @author dipal
     * @param userId
     * @param tenderId
     * @return {@code List<Object[]>} 
     */
    public List<Object[]> getSecondaryPartnerRequest(int tenderId,int consortiumId)
    {
        StringBuilder query=new StringBuilder();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(TENDERID, tenderId);
        map.put("consortiumId", consortiumId);
        
        query.append(" select C.companyName, ");
        query.append(" CASE WHEN CD.partnerType = 1 THEN 'Individual'  WHEN CD.partnerType = 2 THEN 'Lead'  ELSE 'Secondary' END as partnerType, CD.partnerStake, ");
        query.append(" CASE WHEN CD.cstatus = 0 THEN 'Pending' WHEN CD.cstatus = 1 THEN 'Accepted' WHEN CD.cstatus = 2 THEN 'Rejected' END AS reqStatus,");
        query.append(" CD.remarks, CD.tblUserLogin.userId  ");
        query.append(" FROM TblConsortium CO ");
        query.append(" INNER JOIN CO.tblConsortiumDetail  CD  ");
        query.append(" INNER JOIN  CD.tblCompany C ");
        query.append(" WHERE CO.tblTender.tenderId=:tenderId AND CO.isActive!=2 AND CO.consortiumId = :consortiumId order by CD.partnerType,CD.consortiumDetailId ");
        return hibernateQueryDao.createNewQuery(query.toString(),map); 
    }
    
    /**
     * Method use to check request for secondary partner already send?
     * @author dipal
     * @param loginId
     * @param consortiumId
     * @param tenderId
     * @return boolean [true indicated request already send to bidder , false= no request send to bidder for consortium ]
     */
    public boolean checkSecondaryPartenerReqAlreadySend(String loginId, int consortiumId,int tenderId)
    {
        StringBuilder query=new StringBuilder();
        List<Object> res=null;
        boolean exist=false;
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("consortiumId", consortiumId);
        map.put("loginId", loginId);
        
        /* already send request */
        query.append(" select count(C.consortiumId) from TblConsortiumDetail CD ");
        query.append(" INNER JOIN CD.tblConsortium C ");
        query.append(" INNER JOIN CD.tblUserLogin UL ");
        query.append(" WHERE UL.loginId =:loginId AND C.consortiumId=:consortiumId AND CD.cstatus!=2 AND C.isActive != 2");
        res = hibernateQueryDao.singleColQuery(query.toString(),map); 
        if(res !=null && !res.isEmpty() && (Long)res.get(0) > 0)
        {
            exist = true;
        }
        else
        {
            exist = false;
        }
        return exist;
    }

    /**
     * Method use to check weather consortium final process done or not?
     * @param consortiumId
     * @return return true if pending else return false.
     * @throws Exception 
     */
    public boolean checkConsortiumFinalProcessPending(int consortiumId) throws Exception
    {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId",consortiumId);
        return (hibernateQueryDao.countForNewQuery("TblConsortium tblconsortium ","tblconsortium.consortiumId ","tblconsortium.consortiumId =:consortiumId and tblconsortium.isActive = 0",var)!= 0);
    }
    
     /**
     * Method use to check all consortium request are processed?
     * @param consortiumId
     * @return return true if pending else return false.
     * @throws Exception 
     */
    public boolean checkAllConsortiumRequestProcessed(int consortiumId) throws Exception
    {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId",consortiumId);
        return (hibernateQueryDao.countForNewQuery("TblConsortiumDetail tblconsortiumdetail ","tblconsortiumdetail.consortiumDetailId ","tblconsortiumdetail.tblConsortium.consortiumId =:consortiumId and tblconsortiumdetail.cstatus = 0",var)== 0);
    }
    
    /**
     * Method use to get user detail for send secondary partner request.
     * @author dipal
     * @param loginId
     * @param consortiumId
     * @param tenderId
     * @param clientId
      @return {@code List<Object[]>}
     */
    public List<Object[]> findSecondaryPartner(String loginId, int tenderId,int clientId)
    {
        StringBuilder query=new StringBuilder();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(TENDERID, tenderId);
        map.put("loginId", loginId);
        map.put("clientId", clientId);
        
        /* check user already with other consortium */
        query.append(" select UL.userId,C.companyId,C.companyName from TblUserLogin UL ");
        query.append(" inner join UL.tblBidderStatus BS WITH BS.tblClient.clientId=:clientId AND BS.cstatus=1 ");
        query.append(" inner join BS.tblCompany C ");
        query.append(" WHERE UL.loginId = :loginId ");
        query.append(" and C.companyId NOT IN ");
        query.append(" ( ");
        query.append("   select CD.tblCompany.companyId FROM TblConsortiumDetail CD ");
        query.append("   INNER JOIN CD.tblConsortium CO  ");
        query.append("   WHERE CO.tblTender.tenderId = :tenderId AND CD.cstatus = 1  AND CO.isActive!= 2 ");
        query.append(" ) ");
        return  hibernateQueryDao.createNewQuery(query.toString(),map);    
    }
    
    /**
     * Method use for get consortium detail in tabular form.
     * @author dipal
     * @param tenderId
     * @param consortiumId
     * @return StringBuilder
     */
    public StringBuilder getConsortiumDetailTable(int tenderId,int consortiumId,HttpServletRequest req)
    {
        StringBuilder res=new StringBuilder();
        List<Object[]> lst=getSecondaryPartnerRequest(tenderId,consortiumId);
        if(lst!=null && !lst.isEmpty())
        {
            for(Object[] ob: lst)
            {
                res.append("<tr><td style='text-align: center;' width='30%'><a href='").append(req.getServletContext().getContextPath()).append("/common/admin/viewbidderprofile/").append(ob[5]).append(encryptDecryptUtils.generateRedirect("common/admin/viewbidderprofile/"+ob[5], req)).append("' target='blank'>").append(ob[0]).append("</a></td>")
                .append("<td style='text-align: center;' width='10%'>").append(ob[1]).append("</td>")
                .append("<td style='text-align: center;' width='10%' ");
                if(ob[1]!=null && ob[1].toString().equalsIgnoreCase("Lead"))
                {
                    res.append(" id='cellLeadStake' ");
                }
                else if(ob[1]!=null && ob[1].toString().equalsIgnoreCase("Rejected"))
                {
                    res.append(" id='cellStake' ");
                }
                res.append(">").append(ob[2]).append("</td>");
                res.append("<td style='text-align: center;' width='15%'>").append(ob[3]);
                if (ob[3] != null && ob[3].toString().equalsIgnoreCase("Pending"))
                {
                        res.append(" | <a href='javascript:void(0);' onclick='deleteBidder(\"").append(ob[5]).append("\");'>").append("Delete").append("</a>");
                }
                res.append("</td><td width='35%'>").append(ob[4]).append("</td></tr>");
            }
        }
        return res;
    }
    
    /**
     * Method use to check bidder is mapped with this tender or not?
     * @param tenderId
     * @param userId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public boolean checkBidderMappedWithLimitedTender(int tenderId,int userId) throws Exception
    {
       boolean res=false;
       Map<String, Object> map = new HashMap<String, Object>();
       map.put(TENDERID, tenderId);
       map.put("userId", userId);
       if(hibernateQueryDao.countForQuery("TblTenderBidderMap tbm","tbm.mapBidderId","tbm.tblTender.tenderId = :tenderId AND tbm.tblUserLogin.userId = :userId",map) > 0)
       {
          res=true; 
       }   
       return res; 
    }
    
    /**
     * Method use to get consortium if of lead partner for given tender and for given user if user is lead partner.
     * @author dipal
     * @param userId
     * @param tenderId
     * @return {@code List<Object[]>}
     */
    public List<Object[]> getConsortiumIdLeadPartner(int userId, int tenderId,int partnerType)
    {
         StringBuilder query=new StringBuilder();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(TENDERID, tenderId);
        map.put("userId", userId);
        map.put("partnerType", partnerType);
        
        
        query.append(" SELECT C.consortiumId,C.isActive FROM TblConsortium C ");
        query.append(" inner join C.tblConsortiumDetail CD  ");
        query.append(" where C.isActive!= 2 AND CD.cstatus=1 and CD.tblUserLogin.userId=:userId ");
        query.append(" and C.tblTender.tenderId=:tenderId and CD.partnerType = :partnerType ");
        return hibernateQueryDao.createNewQuery(query.toString(),map);  
    }
    
    /**
     * @author VIPULP
     * @param tenderId
     * @param companyId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getBidWithDrawaldtls(int tenderId,int companyId)throws Exception{
        StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
	 var.put(TENDERID, tenderId);
	 var.put(COMPANYID, companyId);
        
        query.append("select tblbidwithdrawal.remark,tblbidwithdrawal.finalSubmissionDate,tblbidwithdrawal.finalSubmissionIPAddress,")
                .append("tblbidwithdrawal.ipAddress,tblbidwithdrawal.createdOn ")
                .append(" from TblBidWithdrawal tblbidwithdrawal ")
                .append(" where tblbidwithdrawal.tblTender.tenderId=:tenderId and tblbidwithdrawal.tblCompany.companyId=:companyId")
                .append(" order by tblbidwithdrawal.bidWithdrawalId desc");
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }

    /**
     * Get Cells on which rebate/discount is to be taken
     * @param formId
     * @return{@code List<Object>}
     * @throws Exception 
     */
    public List<Object> getRebateCellId(int formId) throws Exception{
        List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        list = hibernateQueryDao.getSingleColQuery("select tblrebateform.tblTenderCell.cellId from TblRebateForm tblrebateform where tblrebateform.tblTenderForm.formId=:formId",var);                
        return list;        

    }
    
     /**
     * Check whether final submission is done for the tender by the company/bidder
     * @param companyId
     * @param tenderId
     * @return true for Yes; false for No
     * @throws Exception 
     */
    public boolean checkFinalSubmitDone(int companyId,int tenderId) throws Exception{

        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(COMPANYID,companyId);
        var.put(TENDERID,tenderId);
        count = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblfinalsubmission ","tblfinalsubmission.finalSubmissionId ","tblfinalsubmission.tblTender.tenderId=:tenderId and tblfinalsubmission.tblCompany.companyId=:companyId",var);
        return count==0;
    }
          
    /**
     * Delete's the bid
     * @param bidId
     * @param tenderId
     * @param formId
     * @param companyId
     * @return true for success delete; false for failure
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED,rollbackFor = Exception.class)
    public boolean deleteBidSubmitted(int bidId,int tenderId,int formId,int companyId) throws Exception{
        int cnt = 0;
        int rebateId = getFormRebate(tenderId, formId);
        Map<String, Object> var = new HashMap<String, Object>();
        if(rebateId!=0){
            var.put("rebateId",rebateId);
            var.put(COMPANYID,companyId);
            hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderRebate tbltenderrebate where tbltenderrebate.tblRebate.rebateId=:rebateId and tbltenderrebate.tblCompany.companyId=:companyId",var);
            var.clear();
            List<Object> bidTableIds = getBidTableIdByBidId(bidId);
            if(bidTableIds != null) {
	            var.put(TENDERID,tenderId);
	            var.put(COMPANYID,companyId);
	            var.put("bidTableIds", bidTableIds.toArray());
	            hibernateQueryDao.updateDeleteNewQuery("delete  from TblRebateDetail tblrebatedetail where tblrebatedetail.tblTender.tenderId=:tenderId and tblrebatedetail.tblCompany.companyId=:companyId and tblrebatedetail.tblTenderBidMatrix.bidTableId in (:bidTableIds)",var);
	            var.clear();
            }
        }
        var.put(TENDERID,tenderId);
        List<Object> tenderData = hibernateQueryDao.singleColQuery("select isItemSelectionPageRequired from TblTender where tenderId=:tenderId", var);
        var.clear();
        var.put("formId",formId);
        List<Object> formData = hibernateQueryDao.singleColQuery("select isPriceBid from TblTenderForm where formId=:formId", var);
        if(!formData.isEmpty()){
        	var.put("companyId",companyId);
            if((Integer)formData.get(0)==0){
                hibernateQueryDao.updateDeleteNewQuery("delete from TblItemSelection where tblTenderForm.formId=:formId and tblCompany.companyId=:companyId", var);                
            }else{
                if(!tenderData.isEmpty()){
                    if((Integer)tenderData.get(0)==1){
                        hibernateQueryDao.updateDeleteNewQuery("update TblItemSelection set isBidded=0 where tblTenderForm.formId=:formId and tblCompany.companyId=:companyId", var);
                    }else if((Integer)tenderData.get(0)==0){
                        hibernateQueryDao.updateDeleteNewQuery("delete from TblItemSelection where tblTenderForm.formId=:formId and tblCompany.companyId=:companyId", var);
                    }
                }
            }
        }
        var.clear();
        var.put("bidId",bidId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblEventFees tblEventFees  where tblEventFees.bidId=:bidId and tblEventFees.cstatus=0",var);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderBid tbltenderbid where tbltenderbid.bidId=:bidId",var);
        return cnt!=0;

    }
    
    public List<Object> getBidTableIdByBidId(int bidId) {
    	List<Object> bidTableIds = null;
    	Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidId", bidId);
        bidTableIds = hibernateQueryDao.getSingleColQuery("select tblTenderBidMatrix.bidTableId from TblTenderBidMatrix tblTenderBidMatrix where tblTenderBidMatrix.tblTenderBid.bidId =:bidId ",var);
        return (bidTableIds!=null && !bidTableIds.isEmpty()) ? bidTableIds : null;
    }
    /**
     * Method use for remove secondary partner from consortium.
     * @author dipal
     * @param consortiumId
     * @param bidderId
     * @return boolean
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean removeSecondaryPartner(int consortiumId, int bidderId) throws Exception
    {
       int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId",consortiumId);
        var.put("bidderId",bidderId);
        List<Object> lst=hibernateQueryDao.getSingleColQuery("select td.partnerStake from TblConsortiumDetail td where td.tblUserLogin.userId=:bidderId AND td.tblConsortium.consortiumId=:consortiumId and td.cstatus = 0",var);        
        String partnerSake="0";
        if(lst!=null && !lst.isEmpty())
        {
            var = new HashMap<String, Object>();
            var.put("consortiumId",consortiumId);
            partnerSake = lst.get(0).toString();
             hibernateQueryDao.updateDeleteNewQuery("UPDATE TblConsortiumDetail td SET td.partnerStake = td.partnerStake + "+partnerSake+"  where td.tblConsortium.consortiumId=:consortiumId and td.partnerType = 2",var);              
            var = new HashMap<String, Object>();
            var.put("consortiumId",consortiumId);
            var.put("bidderId",bidderId);
        }        
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblConsortiumDetail td where td.tblUserLogin.userId=:bidderId AND td.tblConsortium.consortiumId=:consortiumId and td.cstatus = 0",var);        
        return cnt!=0;
    }
    
    /**
     * Method use for accept Reject secondary partner request.
     * @author dipal
     * @param consortiumId
     * @param bidderId
     * @return boolean
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean acceptRejectSecondaryPartnerRequest(int consortiumId, int bidderId,int decision,String remarks) throws Exception
    {
       int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId",consortiumId);
        var.put("bidderId",bidderId);
        if(decision == 2) /* Reject invitation */
        {
            List<Object> lst=hibernateQueryDao.getSingleColQuery("select td.partnerStake from TblConsortiumDetail td where td.tblUserLogin.userId=:bidderId AND td.tblConsortium.consortiumId=:consortiumId and td.cstatus = 0",var);        
            String partnerSake="0";
            if(lst!=null && !lst.isEmpty())
            {
                var = new HashMap<String, Object>();
                var.put("consortiumId",consortiumId);
                partnerSake = lst.get(0).toString();
                 hibernateQueryDao.updateDeleteNewQuery("UPDATE TblConsortiumDetail td SET td.partnerStake = td.partnerStake + "+partnerSake+"  where td.tblConsortium.consortiumId=:consortiumId and td.partnerType = 2",var);              
            }
        }
        var.put("decision",decision);
        var.put("remarks",remarks);
        var.put("bidderId",bidderId);
        StringBuilder query=new StringBuilder();
        query.append(" UPDATE TblConsortiumDetail td SET td.cstatus = :decision, td.remarks=:remarks ");
        if(decision==2)
        {
            query.append(", rejectedOn='").append(commonService.getServerDateTime()).append("' ");
        }
        query.append(" where td.tblUserLogin.userId=:bidderId AND td.tblConsortium.consortiumId=:consortiumId and td.cstatus = 0");
        cnt = hibernateQueryDao.updateDeleteNewQuery(query.toString(),var);               
        return cnt!=0;
    }
    
    /**
     * Method use for add secondary bidder for consortium. 
     * @author dipal
     * @param consortiumDetail
     * @return boolean [true: Operation Success , false: Operation Failed]
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addSecondaryPartner(TblConsortiumDetail consortiumDetail) throws Exception
    {
        tblConsortiumDetailDao.addTblConsortiumDetail(consortiumDetail);
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId",consortiumDetail.getTblConsortium().getConsortiumId());
        
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblConsortiumDetail td  set td.partnerStake=td.partnerStake - "+consortiumDetail.getPartnerStake()+" where td.tblConsortium.consortiumId=:consortiumId and td.partnerType = 2",var);        
        return cnt!=0;        
    }
    
    /**
     * Method use for add Consortium Lead partner.
     * @author dipal
     * @param tblConsortium
     * @param tblConsortiumDetail
     * @return int consortiumId.
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public int addLeadPartner(TblConsortium tblConsortium, TblConsortiumDetail tblConsortiumDetail) throws Exception
    {
        tblConsortiumDao.addTblConsortium(tblConsortium);
        tblConsortiumDetail.setTblConsortium(tblConsortium);
        tblConsortiumDetailDao.addTblConsortiumDetail(tblConsortiumDetail);
        return tblConsortium.getConsortiumId();
    }
    
    /**
     * @author VIPULP
     * @param tenderId
     * @param companyId
     * @return boolean
     */
    public boolean isTenderBidConfirmation(int tenderId, int companyId) throws Exception{
        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID,tenderId);
        var.put(COMPANYID,companyId);
        count = hibernateQueryDao.countForNewQuery("TblTenderBidConfirmation tbltenderbidconfirmation ","tbltenderbidconfirmation.bidConfirmationId ","tbltenderbidconfirmation.tblCompany.companyId=:companyId and tbltenderbidconfirmation.tblTender.tenderId=:tenderId",var);
        return count!=0;
    }
    public boolean isTenderBidRegret(int tenderId, int companyId) throws Exception{
        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID,tenderId);
        var.put(COMPANYID,companyId);
        count = hibernateQueryDao.countForNewQuery("TblTenderBidRegression tblTenderBidRegression ","tblTenderBidRegression.bidRegressionId ","tblTenderBidRegression.tblCompany.companyId=:companyId and tblTenderBidRegression.tblTender.tenderId=:tenderId",var);
        return count!=0;
    }
    /**
     * @author VIPULP
     * @param tenderId
     * @return boolean
     * @throws Exception 
     */
    public boolean isConsortiumRoleSelected(int tenderId,int userId) throws Exception{
        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID,tenderId);
        var.put("userId",userId);
        
        count = hibernateQueryDao.countForNewQuery("TblConsortium C inner join C.tblConsortiumDetail CD ","C.consortiumId ","C.isActive=1 AND CD.cstatus = 1 and CD.tblUserLogin.userId=:userId and C.tblTender.tenderId=:tenderId",var);
        return count!=0;
    }

    
    /**
     * Method use for approve JV by final consortium process.
     * @author dipal
     * @param consortiumId
     * @return boolean
     * @throws Exception 
     */
    public boolean finalConsortiumProcess(int consortiumId) throws Exception
    {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId",consortiumId);
        StringBuilder query=new StringBuilder();
        query.append("update TblConsortium c  set c.isActive = 1, approvedOn='").append(commonService.getServerDateTime()).append("' where c.consortiumId=:consortiumId");
        return hibernateQueryDao.updateDeleteNewQuery(query.toString(),var)!=0;        
    }
    
    /**
     * Method use for Reset Consortium.
     * @author dipal
     * @param tenderId
     * @param consortiumId
     * @param ipAddress
     * @param sessionUserId
     * @param clietId
     * @return boolean
     * @throws Exception 
     */
    public boolean resetConsortium(int tenderId, int consortiumId, String ipAddress, int sessionUserId, int clietId,String resetMsg) throws Exception
    {
        boolean res=false;
        ArrayList<LinkedHashMap<String, Object>> lst = sPResetConsortium.executeProcedure(tenderId, consortiumId, ipAddress, sessionUserId, clietId,resetMsg);
        if(lst!=null && !lst.isEmpty() && lst.get(0).get("resultMessage")!=null && lst.get(0).get("resultMessage").toString().equalsIgnoreCase("true"))
        {
            res=true;
        }
        return res;
    }
    
    /**
     * Method use for get lead partner email id.
     * @author dipal
     * @param consortiumId
     * @return String
     */
    public String getLeadPartenerEmailId(int consortiumId)
    {
        String emailId=null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId",consortiumId);
        List<Object> lst=hibernateQueryDao.getSingleColQuery("select ul.loginId from TblConsortiumDetail td INNER JOIN td.tblUserLogin ul where td.partnerType = 2 AND td.tblConsortium.consortiumId=:consortiumId",var);        
        if(lst!=null && !lst.isEmpty())
        {
            emailId=(String)lst.get(0);
        }
        return emailId;
    }
    
    /**
     * Method use for get secondary partner's email id who have invitation status as pending or approved, rejected status partner will not be considered.
     * @author dipal
     * @param consortiumId
     * @return String
     */
    public StringBuilder getSecondayPartenerEmailIds(int consortiumId,int fromBidderId)
    {
        StringBuilder strEmailId=null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId",consortiumId);
        var.put("fromBidderId",fromBidderId);
        List<Object> lst=hibernateQueryDao.getSingleColQuery("select ul.loginId from TblConsortiumDetail td INNER JOIN td.tblUserLogin ul where td.partnerType != 1 AND td.tblConsortium.consortiumId=:consortiumId AND td.cstatus != 2 AND ul.userId != :fromBidderId ",var);        
        if(lst!=null && !lst.isEmpty())
        {   for(Object ob:lst)
            {
                if(strEmailId == null)
                {
                    strEmailId=new StringBuilder();
                    strEmailId.append(ob);
                }
                else
                {
                    strEmailId.append(",").append(ob);
                }
            }
        }
        return strEmailId;
    }
    
    /**
     * @author VIPULP
     * @param tenderId
     * @param companyId
     * @return boolean
     * @throws Exception 
     */
    public boolean isBidderPresenceRegistered(int tenderId, int companyId) throws Exception{
        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID,tenderId);
        var.put(COMPANYID,companyId);
        
        count = hibernateQueryDao.countForNewQuery("TblBidderPresence tblbidderpresence ","tblbidderpresence.bidderPresenceId ","tblbidderpresence.tblCompany.companyId=:companyId and tblbidderpresence.tblTender.tenderId=:tenderId",var);

        return count!=0;
    }
    /**
     * 
     * @param rebateId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getRebateList(int rebateId,int companyId) throws Exception{
    	StringBuilder query = new StringBuilder();
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("rebateId",rebateId);
        var.put(COMPANYID,companyId);        
        query.append("select tblrebate.isRebateForm, tblrebate.reportName,tbltenderform.formName,tbltendertable.tableName, tbltendercolumn.columnHeader, tblrebatedetail.cellValue,tbltenderrebate.rebateValue ")
        .append("FROM TblRebate tblrebate ")
        .append("INNER JOIN tblrebate.tblRebateForm tblrebateform ")
        .append("INNER JOIN tblrebateform.tblTenderForm tbltenderform WITH tbltenderform.cstatus = 1 ")
        .append("INNER JOIN tblrebateform.tblTenderCell tbltendercell ")
        .append("INNER JOIN tbltendercell.tblTenderColumn tbltendercolumn ")
        .append("INNER JOIN tbltendercolumn.tblTenderTable tbltendertable ")
        .append("INNER JOIN tbltenderform.tblTenderBid tbltenderbid WITH tbltenderbid.tblCompany.companyId = :companyId and tbltenderbid.cstatus = 2 ")
        .append("INNER JOIN tbltenderbid.tblTenderBidMatrix tbltenderbidmatrix ")
        .append("INNER JOIN tbltenderbidmatrix.tblRebateDetail tblrebatedetail ")
        .append("LEFT JOIN tblrebate.tblTenderRebate tbltenderrebate WITH tbltenderrebate.tblCompany.companyId = :companyId ") 
        .append("WHERE tblrebate.rebateId = :rebateId AND tblrebatedetail.tblTenderCell.cellId = tbltendercell.cellId "); 
        
        list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list;        

    }
    /**
     * @author krunal.patel 
     * @param tblTenderRebate
     * @return boolean
     * @throws Exception 
     */
    public boolean addTenderRebate(TblTenderRebate tblTenderRebate) throws Exception{
    boolean bSuccess = false;             
                tblTenderRebateDao.addTblTenderRebate(tblTenderRebate);
            bSuccess=true;        
        return bSuccess;
    }
    /**
     * @author krunal.patel
     * @param rebateId
     * @param tenderRebate
     * @return boolean
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean editTenderRebate(int rebateId,TblTenderRebate tenderRebate,int companyId) throws Exception{
    boolean bSuccess = false;
    boolean dSuccess = false;
    
    	/*** Delete old entry by Rebate Id **/
    	dSuccess = deleteTenderRebate(rebateId,companyId);
    	
    	if(dSuccess){
    		/*** insert new entry **/
    		tblTenderRebateDao.addTblTenderRebate(tenderRebate);
            bSuccess=true;
            return bSuccess;
    	}
    	 return bSuccess;
    }
    
    /**
     * 
     * @param rebateId
     * @param companyId
     * @return
     * @throws Exception 
     */
    public boolean deleteTenderRebate(int rebateId,int companyId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("rebateId",rebateId);
        var.put("companyId",companyId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete  from TblTenderRebate tbltenderrebate where tbltenderrebate.tblCompany.companyId=:companyId and tbltenderrebate.tblRebate.rebateId=:rebateId",var);        
        return cnt!=0;

    }
    /**
     * @author VIPULP
     * @param tenderId
     * @param companyId
     * @return {@code List<Object[]>}
     * @throws Exception 
     */
    public List<Object[]> getRebateFormTenderBidCount(int tenderId, int companyId) throws Exception{
        StringBuilder query = new StringBuilder();
         Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID,tenderId);
        var.put(COMPANYID,companyId);
        
        query.append("select count(distinct tblrebateform.tblTenderForm.formId),count(distinct tbltenderbid.bidId) ")
                .append(" from TblRebate tblrebate ")
                .append(" inner join tblrebate.tblRebateForm tblrebateform ")
                .append(" inner join tblrebateform.tblTenderForm tbltenderform with tbltenderform.cstatus=1")
                .append(" left join tbltenderform.tblTenderBid tbltenderbid with tbltenderbid.tblCompany.companyId=:companyId and tbltenderbid.cstatus=2")
                .append(" where tblrebate.tblTender.tenderId=:tenderId");
        
        return hibernateQueryDao.createNewQuery(query.toString(), var);
    }
    
    /**
     * 
     * @param tenderId
     * @param formId
     * @return
     * @throws Exception 
     */
    public int getFormRebate(int tenderId,int formId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID,tenderId);
        var.put("formId",formId);
        List<Object> list = hibernateQueryDao.getSingleColQuery("select tblrebate.rebateId from TblRebate tblrebate inner join tblrebate.tblRebateForm tblrebateform where tblrebate.tblTender.tenderId=:tenderId and tblrebateform.tblTenderForm.formId=:formId",var);                
        return list.isEmpty() ? 0 : (Integer)list.get(0);
    }
    
    

    /**
     * 
     * @param formId
     * @param companyId
     * @return
     * @throws Exception 
     */
    public boolean checkFormBided(int formId,int companyId) throws Exception{
        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("formId",formId);
        var.put("companyId",companyId);
        count = hibernateQueryDao.countForNewQuery("TblTenderBid tbltenderbid ","tbltenderbid.bidId ","tbltenderbid.tblCompany.companyId=:companyId and tbltenderbid.tblTenderForm.formId=:formId",var);
        return count==0;
    }
    
      /**
     * 
     * @param bidId
     * @return
     * @throws Exception 
     */
    public boolean deleteBidFees(int bidId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidId",bidId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set tblEventFees.isActive=0  where tblEventFees.bidId=:bidId and cstatus=0",var);        
        return cnt!=0;

    }
    
    /**
     * 
     * @param eventFeesId
     * @return
     * @throws Exception 
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean updateBidFees(List<Integer> eventFeesId,int isActive,int tenderId,int companyId ) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("eventFeesId",eventFeesId);
        var.put("isActive",isActive);
        var.put("companyId",companyId);
        var.put("objectId",tenderId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set tblEventFees.isActive=:isActive  where tblEventFees.eventFeeId in (:eventFeesId) and cstatus=0 and objectId=:objectId and tblCompany.companyId=:companyId ",var);
        
        var.clear();
        var.put("companyId",companyId);
        var.put("objectId",tenderId);
        var.put("uniqueId",tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8));
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set uniqueId=:uniqueId  where cstatus=0 and feeType=2  and objectId=:objectId and tblCompany.companyId=:companyId ",var);        
        var.put("uniqueId",tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8));
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set uniqueId=:uniqueId  where cstatus=0 and feeType=3  and objectId=:objectId and tblCompany.companyId=:companyId ",var);
        var.put("uniqueId",tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8));
        cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set uniqueId=:uniqueId  where cstatus=0 and feeType=8  and objectId=:objectId and tblCompany.companyId=:companyId ",var);
        return cnt!=0;

    }
    
    /**
     *author :heeral.soni 
     * @param TblChallan
     * @return
     * @throws Exception 
     */
    public void addChallanDetails(TblChallan tblChallan) throws Exception{            
        tblChallanDetailsDao.addTblChallan(tblChallan);
    }   

    /**
     * author : heeral.soni
     * used to get max challan No(maxchallanId)
     * @param clientId
     * @return
     * @throws Exception 
     */
    public int getMaxChallanId(int clientId) throws Exception{
        int data=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId",clientId);
        List<Object> list = hibernateQueryDao.getSingleColQuery("select max(tblChallan.challanNo) from TblChallan tblChallan where tblChallan.tblClient.clientId=:clientId",var);                
        if(list.get(0)!=null && !"".equals(list.get(0))){
            data = Integer.parseInt(list.get(0).toString());
        }
        return data;
    }
    
     /**
     * author : heeral.soni
     * used to get max challan No(maxchallanId)
     * @param clientId
     * @return
     * @throws Exception 
     */
    public boolean isChallanConfigure(int clientId) throws Exception{
        int data=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId",clientId);
        StringBuilder query = new StringBuilder();
        query.append("select COUNT(tblclientfeature.clientFeatureId) from TblClientFeature tblclientfeature ");
        query.append("inner join tblclientfeature.tblClient tblclient ");
        query.append("inner join tblclientfeature.tblFeature tblfeature ");
        query.append("where tblfeature.featureId = 1 and tblclient.clientId=:clientId and tblclientfeature.isActive=1");
        
        //System.out.println("query isChallanConfigure=====> " + query.toString());
        List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(),var);                
        if(list!=null && !list.isEmpty()){
            data = Integer.parseInt(list.get(0).toString());
        }
        return data!=0 ? true : false;
        
        
    }
    
    /**
     * author : heeral soni
     * @param tenderId
     * used to get challan no and date
     * @throws Exception 
     */
    public Object getChallanDetails(int tenderId,int companyId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        StringBuilder query = new StringBuilder();
        var.put("tenderId",tenderId);
        query.append("select tblChallan.challanNo,tblChallan.createdOn,tblChallan.tblTender.tenderId ");
        query.append("from TblChallan tblChallan ");
        query.append("inner join tblChallan.tblCompany tblcompany ");
        query.append("where tblChallan.tblTender.tenderId=:tenderId ");
        query.append("and tblChallan.tblCompany.companyId =").append(companyId);
        //System.out.println("query getChallanDetails :--->"+query.toString());
        List<Object[]> list = hibernateQueryDao.createNewQuery(query.toString(),var);                
        return list != null && !list.isEmpty() ? list.get(0) : null;        

    }
    /**author : heeral.soni
     * 
     * @param tenderId
     * @param bidderId
     * used to get payment details for online challan
     * @throws Exception 
     */
    public List<Object[]> getOnlinePaymentDeatil(int tenderId,int bidderId) throws Exception{
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("bidderId",bidderId);
        StringBuilder query = new StringBuilder();
        query.append("select (CASE WHEN tblpayment.paymentFor = 1 THEN 'DOC FEE' ELSE 'EMD / SD' END),tblpayment.objectId,cast(tblpayment.amount as string),tblcompany.companyName, ");
        query.append("(CASE WHEN tblpaymenttype.paymentTypeId = 1 THEN 'Payment gateway' WHEN tblpaymenttype.paymentTypeId = 2 THEN 'NEFT/RTGS' WHEN tblpaymenttype.paymentTypeId =3 THEN 'Cheque'  WHEN tblpaymenttype.paymentTypeId =4 THEN 'Demand Draft' WHEN tblpaymenttype.paymentTypeId =5 THEN 'Cash' ELSE 'Exemption Certificate' END), ");
        query.append("tblpayment.createdOn,(select tbldepartment.deptName from TblDepartment tbldepartment where tbldepartment.deptId = tblpayment.tblClient.deptId), ");
        query.append("concat((CASE WHEN tblpayment.paymentFor = 1 THEN 'DF' ELSE 'EMD' END),'/',cast(year(tblpayment.createdOn) as string),'/',cast(tblpayment.paymentId as string)) ");
        query.append("from TblPayment tblpayment ");
        query.append("inner join tblpayment.tblOnlinePayment tblonlinepayment ");
        query.append("inner join tblpayment.tblCompany  tblcompany ");
        query.append("inner join tblpayment.tblPaymentType tblpaymenttype ");
        query.append("where tblpayment.objectId=:tenderId and tblpayment.paymentFor in (1,2) and tblpaymenttype.paymentTypeId != 6 ");
        query.append("and tblonlinepayment.responseCode = '0300' ");
        query.append("and tblpayment.tblUserLogin =:bidderId");
        //System.out.println("query getOnlinePaymentDeatil :--->"+query.toString());
        return hibernateQueryDao.createNewQuery(query.toString(),var);        

    }
    
    
    /**
     * 
     * @param clientId
     * @param objectId
     * @param companyId
     * @return
     * @throws Exception 
     */
    public boolean checkBidPayment(int clientId,int objectId,int companyId,List<Integer> paymentFor) throws Exception{

        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("clientId",clientId);
        var.put("objectId",objectId);
        var.put("paymentFor",paymentFor);
        var.put("companyId",companyId);
        if(!paymentFor.isEmpty()){
            count = hibernateQueryDao.countForNewQuery("TblPayment tblpayment ","tblpayment.paymentId ","tblpayment.tblCompany.companyId=:companyId and tblpayment.tblClient.clientId=:clientId and  tblpayment.objectId=:objectId and tblpayment.paymentFor in (:paymentFor) and tblpayment.cstatus=1",var);
        }
        return count==0;
    }
    /**
     * 
     * @param clientId
     * @param objectId
     * @param companyId
     * @return
     * @throws Exception 
     */
    public boolean checkTenderFeesBidPayment(int bidId,int objectId,int companyId) throws Exception{

        long count=0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidId",bidId);
        var.put("objectId",objectId);
        var.put("companyId",companyId);
            count = hibernateQueryDao.countForNewQuery("TblEventFees tblEventFees ","tblEventFees.eventFeesId ","tblEventFees.tblTenderBid.bidId=:bidId and tblEventFees.tblCompany.companyId=:companyId and  tblEventFees.objectId=:objectId and  tblEventFees.cstatus=1 and tblEventFees.isActive=1",var);
        return count==0;
    }
    
    /**
     * author bhavin.patel
     * @param tenderId
     * @param companyIds Ex. Object[] companyIds = {new TblCompany(companyId),new TblCompany(companyId),...new TblCompany(companyId)};
     * @param isCertRequired
     * @param envelopeType
     * @return
     * @throws Exception
     */
    public List<Object> getTenderBidForms(int tenderId, Object[] companyIds, int isCertRequired, int envelopeType) throws Exception {
    	StringBuffer query = new StringBuffer();
    	query.append("select tblTenderBid.tblTenderForm.formId from TblTenderBid tblTenderBid inner join tblTenderBid.tblTenderForm tblTenderForm inner join tblTenderBid.tblTenderEnvelope tblTenderEnvelope where tblTenderBid.tblTender.tenderId = :tenderId and tblTenderBid.tblCompany in (:companyIds) and tblTenderForm.cstatus != 2");    	
    	if(isCertRequired == 0 && envelopeType == 2){
    		query.append(" and tblTenderEnvelope.sortOrder = 1");    		
    	}
    	else if(isCertRequired == 1 && envelopeType == 1){
    		query.append(" and tblTenderForm.isPriceBid = 0 and tblTenderForm.isEncryptionReq = 0");
    	}
    	else if(isCertRequired == 1 && envelopeType == 2){
    		query.append(" and tblTenderEnvelope.sortOrder = 1 and tblTenderForm.isPriceBid = 0 and tblTenderForm.isEncryptionReq = 0");
    	}
    	
    	List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyIds",companyIds);
        list = hibernateQueryDao.getSingleColQuery(query.toString(),var);        
        return list;
    }
    
    /**
     * 
     * author bhavin.patel
     * @param tenderId
     * @param companyIds Ex. Object[] companyIds = {new TblCompany(companyId),new TblCompany(companyId),...new TblCompany(companyId)};
     * @param formIds Object[] formIds = {new TblTenderForm(formId), new TblTenderForm(formId)...,new TblTenderForm(formId)};
     * @return
     * @throws Exception
     */
    public List<TblTenderBid> getTenderBid(int tenderId, Object[] companyIds, Object[] formIds) throws Exception {
    	return tblTenderBidDao.findTblTenderBid("tblTender", Operation_enum.EQ, new TblTender(tenderId), "tblCompany", Operation_enum.IN, companyIds, "tblTenderForm", Operation_enum.IN, formIds);
    }
    
    public TblTenderBid getTenderBidById(int bidId) throws Exception {
        List<TblTenderBid> list = tblTenderBidDao.findTblTenderBid("bidId", Operation_enum.EQ, bidId);
        return (list != null && !list.isEmpty()) ? list.get(0) : null;
    }
    
    
    /**
     * 
     * author bhavin.patel
     * @param bidId
     * @return
     * @throws Exception
     */
    public List<TblTenderBidMatrix> getTableBidMatrix(int bidId) throws Exception {
    	return tblTenderBidMatrixDao.findTblTenderBidMatrix("tblTenderBid", Operation_enum.EQ, new TblTenderBid(bidId));
    }
    
    /**
     * 
     * author bhavin.patel
     * @param ipAddress
     * @param params | params[0] = tenderId, params[1] = companyId, params[2] = userId, params[3] = userDetailId, params[4] = (0 Get, 1 Post), params[5] = isCertRequired, params[6] = envelopeType  
     * @return
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addTenderBidOpenDetails(String ipAddress, int... params) throws Exception {
        boolean bSuccess = false;
        int isItemSelectionPageRequired=0;
        boolean isPriceBid = false;
        List<Object[]> cellIdList = null;
        
        Object[] companyIds = {new TblCompany(params[1])};
        isItemSelectionPageRequired = Integer.parseInt(tenderCommonService.getTenderField(params[0], "isItemSelectionPageRequired").toString()); 
        
        List<Object> formIdList = getTenderBidForms(params[0], companyIds, params[5], params[6]);
        Object[] formIds = new Object[formIdList.size()];
        for(int i=0; i<formIdList.size(); i++){
        	formIds[i] = new TblTenderForm((Integer) formIdList.get(i));
        }
        
        if(formIds.length > 0){
        	List<TblTenderBid> tblTenderBidList = getTenderBid(params[0], companyIds, formIds);
    		
    		if(tblTenderBidList != null && !tblTenderBidList.isEmpty()){
    			List<TblTenderOpen> tblTenderOpenList = new ArrayList<TblTenderOpen>();
    			List<TblTenderBidOpenSign> tblTenderBidOpenSignList = new ArrayList<TblTenderBidOpenSign>();
    			List<TblTenderBidDetail> tblTenderBidDetailList = new ArrayList<TblTenderBidDetail>();
    			List<String> userFormIds = new ArrayList<String>();    			
    			cellIdList = tenderOpenService.getBidSelectedandBidded(formIdList,params[1]);
    			
        		for(TblTenderBid tblTenderBid : tblTenderBidList){
        			String userFormId = tblTenderBid.getTblTenderForm().getFormId() + "~" + tblTenderBid.getTblCompany().getCompanyId(); 
        			if(!userFormIds.contains(userFormId)){
        				userFormIds.add(userFormId);
        				TblTenderOpen tblTenderOpen = new TblTenderOpen();
            			tblTenderOpen.setTblTender(tblTenderBid.getTblTender());
            			tblTenderOpen.setTblTenderEnvelope(tblTenderBid.getTblTenderEnvelope());
            			tblTenderOpen.setTblTenderForm(tblTenderBid.getTblTenderForm());
            			tblTenderOpen.setTblCompany(tblTenderBid.getTblCompany());
            			tblTenderOpen.setTblUserLogin(tblTenderBid.getTblUserLogin());
            			tblTenderOpen.setDecryptionLevel(1);
            			tblTenderOpen.setIpAddress(ipAddress);
            			tblTenderOpen.setCreatedBy(params[3]);
            			tblTenderOpenList.add(tblTenderOpen);
        			}
        			
        			List<TblTenderBidMatrix> tblTenderBidMatrixList = getTableBidMatrix(tblTenderBid.getBidId());
        			isPriceBid = tenderFormService.getIsPriceBidForm(tblTenderBid.getTblTenderForm().getFormId());
        			if(tblTenderBidMatrixList != null && !tblTenderBidMatrixList.isEmpty()){
        				for(TblTenderBidMatrix tblTenderBidMatrix : tblTenderBidMatrixList){
        					TblTenderBidOpenSign tblTenderBidOpenSign = new TblTenderBidOpenSign();
        					tblTenderBidOpenSign.setTblTenderBidMatrix(tblTenderBidMatrix);
        					tblTenderBidOpenSign.setDecryptedBid(tblTenderBidMatrix.getBidJson());
        					tblTenderBidOpenSign.setBidSignText(tblTenderBidMatrix.getBidJson());
        					tblTenderBidOpenSign.setCreatedBy(params[3]);
        					tblTenderBidOpenSignList.add(tblTenderBidOpenSign);
        					
        					JSONArray jsonArray = new JSONArray(tblTenderBidMatrix.getBidJson());
        					for (int i = 0; i < jsonArray.length(); i++) {
        						JSONObject jSONObject = jsonArray.getJSONObject(i);
        						for (Iterator it = jSONObject.keys(); it.hasNext();) {
        							String key = it.next().toString();
        							String[] keyValues = key.split("_");
        							String jsonValue = jSONObject.getString(key);
        							
        							if(isItemSelectionPageRequired==1 && isPriceBid && cellIdList!=null && !cellIdList.isEmpty()){
            							if(cellIdList.contains(keyValues[0].toString())){
            								TblTenderBidDetail tblTenderBidDetail = new TblTenderBidDetail();
                							tblTenderBidDetail.setTblTenderBidMatrix(tblTenderBidMatrix);
                							tblTenderBidDetail.setTblTenderCell(new TblTenderCell(Integer.parseInt(keyValues[0])));
                							tblTenderBidDetail.setCellNo(Integer.parseInt(keyValues[1]));
                							tblTenderBidDetail.setCellValue(jsonValue.replace("@@"," - "));
                							tblTenderBidDetailList.add(tblTenderBidDetail);
            							}
        							}else{
        								TblTenderBidDetail tblTenderBidDetail = new TblTenderBidDetail();
            							tblTenderBidDetail.setTblTenderBidMatrix(tblTenderBidMatrix);
            							tblTenderBidDetail.setTblTenderCell(new TblTenderCell(Integer.parseInt(keyValues[0])));
            							tblTenderBidDetail.setCellNo(Integer.parseInt(keyValues[1]));
            							tblTenderBidDetail.setCellValue(jsonValue.replace("@@"," - "));
            							tblTenderBidDetailList.add(tblTenderBidDetail);
        							}
                                }
        					}
        				}
        			}
        		}
        		if(!tblTenderOpenList.isEmpty() && !tblTenderBidDetailList.isEmpty() && !tblTenderBidOpenSignList.isEmpty()){
                	tblTenderOpenDao.saveUpdateAllTblTenderOpen(tblTenderOpenList);
                	tblTenderBidOpenSignDao.saveUpdateAllTblTenderBidOpenSign(tblTenderBidOpenSignList);
                	tblTenderBidDetailDao.saveUpdateAllTblTenderBidDetail(tblTenderBidDetailList);
                }
    		}	
        }
        
        bSuccess = true;
        return bSuccess;
    }
    
    /**
     * 
     * author bhavin
     * @param tenderId
     * @param companyId
     * @return
     * @throws Exception
     */
    public boolean addTenderRebateDetails(int tenderId, int companyId) throws Exception {
    	int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("insert into TblTenderRebateDetail (tblTenderRebate, rebateValue, decryptionLevel) select tblTenderRebate, tblTenderRebate.rebateValue, 0 from TblRebate tblRebate inner join tblRebate.tblTenderRebate tblTenderRebate where tblRebate.tblTender.tenderId = :tenderId and tblTenderRebate.tblCompany.companyId = :companyId",var);        
        return cnt!=0;
    }
    
    /**
     * 
     * author bhavin
     * @param tenderId
     * @param companyId
     * @return
     * @throws Exception
     */
    public boolean deleteTenderRebateDetails(int tenderId, int companyId) throws Exception{
        int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderRebateDetail tblTenderRebateDetail where tblTenderRebateDetail.tblTenderRebate.tenderRebateId = (select tblTenderRebate.tenderRebateId from TblRebate tblRebate inner join tblRebate.tblTenderRebate tblTenderRebate where tblRebate.tblTender.tenderId = :tenderId and tblTenderRebate.tblCompany.companyId = :companyId)",var);
        return cnt!=0;

    }
    
    /**
     * 
     * author bhavin.patel
     * @param tenderId
     * @param companyId
     * @return
     * @throws Exception
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean deleteBidOpenData(int tenderId, int companyId) throws Exception {
    	boolean bSuccess = false;
    	List<Object> bidIds = null;
    	Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("companyId",companyId);
    	bidIds = hibernateQueryDao.getSingleColQuery("select tblTenderBid.bidId from TblTenderBid tblTenderBid where tblTenderBid.tblTender.tenderId=:tenderId and tblTenderBid.tblCompany.companyId=:companyId",var);
    	
    	List<Object> bidTableIds = null;
    	Map<String, Object> var1 = new HashMap<String, Object>();
        var1.put("bidIds",bidIds);
        bidTableIds = hibernateQueryDao.getSingleColQuery("select tblTenderBidMatrix.bidTableId from TblTenderBidMatrix tblTenderBidMatrix where tblTenderBidMatrix.tblTenderBid.bidId in (:bidIds)",var1);
        
        if(!bidIds.isEmpty() && !bidTableIds.isEmpty()){
        	deleteTenderOpenData(tenderId, companyId);
        	deleteTenderBidOpenSignData(bidTableIds);
        	deleteTenderBidDetailData(bidTableIds);        	
        }        
        bSuccess = true;
        return bSuccess;
    }
    
    /**
     * 
     * author bhavin.patel
     * @param tenderId
     * @param companyId
     * @return
     * @throws Exception
     */
    public boolean deleteTenderOpenData(int tenderId, int companyId) throws Exception {
    	 int cnt = 0;
         Map<String, Object> var = new HashMap<String, Object>();
         var.put("tenderId",tenderId);
         var.put("companyId",companyId);
         cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderOpen tblTenderOpen where tblTenderOpen.tblTender.tenderId=:tenderId and tblTenderOpen.tblCompany.companyId=:companyId",var);        
         return cnt!=0;
    }
    
    /**
     * 
     * author bhavin.patel
     * @param bidTableIds
     * @return
     * @throws Exception
     */
    public boolean deleteTenderBidOpenSignData(List<Object> bidTableIds) throws Exception {
   	 int cnt = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidTableIds",bidTableIds);
        cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderBidOpenSign tblTenderBidOpenSign where tblTenderBidOpenSign.tblTenderBidMatrix.bidTableId in (:bidTableIds)",var);        
        return cnt!=0;
    }
    
    /**
     * 
     * author bhavin.patel
     * @param bidTableIds
     * @return
     * @throws Exception
     */
    public boolean deleteTenderBidDetailData(List<Object> bidTableIds) throws Exception {
    	int cnt = 0;
    	Map<String, Object> var = new HashMap<String, Object>();
    	var.put("bidTableIds",bidTableIds);
    	cnt = hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderBidDetail tblTenderBidDetail where tblTenderBidDetail.tblTenderBidMatrix.bidTableId in (:bidTableIds)",var);        
    	return cnt!=0;
    }

    public List<Object[]> getcolumnData(int tableId, int companyId) {
        StringBuilder query = new StringBuilder();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("tableId", tableId);
        map.put("companyId", companyId);
        
        query.append("select tblTenderColumn.tblColumnType.columnTypeId,case when tblTenderCell.cellValue = '' then tblTenderProxyBid.cellValue else tblTenderCell.cellValue  end,tblTenderCell.cellId,tblTenderCell.cellNo,tblTenderColumn.columnHeader ");
        query.append(" from  TblTenderColumn tblTenderColumn inner join tblTenderColumn.tblTenderCell tblTenderCell  ");
        query.append(" left join tblTenderColumn.tblTenderProxyBid tblTenderProxyBid  with tblTenderProxyBid.tblCompany.companyId =:companyId");
        query.append(" where tblTenderColumn.tblTenderTable.tableId =:tableId and tblTenderColumn.tblColumnType.columnTypeId in (21,22,2,4,5) order by tblTenderColumn.tblColumnType.columnTypeId ");
       
      
        return hibernateQueryDao.createNewQuery(query.toString(), map);

    }
    
    /**
     * Check Any Bidder Done Final Submission
     * @author vivek.rajyaguru
     * @param tenderId
     * @return
     * @throws Exception
     */
    public boolean isFinalSubmissionDone(int tenderId) throws Exception {
      	long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        count = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblfinalsubmission ", "tblfinalsubmission.finalSubmissionId ", "tblfinalsubmission.tblTender.tenderId=:tenderId and tblfinalsubmission.isActive=1", var);
        return count != 0;
   }
    /**
     * @author manoj.gadhavi
     * @param tenderId
     * @param userId
     * @return
     */
    public List<Object> isBidderSecondaryPartner(int tenderId,int userId)
    {
        StringBuilder query=new StringBuilder();
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(TENDERID, tenderId);
        map.put("userId", userId);
        
        query.append(" SELECT tblConsortiumDetail.tblConsortium.consortiumId ");
        query.append(" FROM TblConsortiumDetail tblConsortiumDetail  ");
        query.append(" WHERE tblConsortiumDetail.tblConsortium.tblTender.tenderId=:tenderId AND tblConsortiumDetail.tblConsortium.isActive <> 2 AND tblConsortiumDetail.tblUserLogin.userId=:userId AND tblConsortiumDetail.cstatus = 1 AND tblConsortiumDetail.partnerType = 3   ");
        return hibernateQueryDao.singleColQuery(query.toString(),map); 
    }
    /**
     * Added by Dhananjay to enable Regret button functionality on 18-08-2017
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean addRegretBidConfm(TblTenderBidRegression tblTenderBidRegression) throws Exception{
		boolean isRegretSuccess = true;
		tblTenderBidRegressionDao.addTblTenderBidRegression(tblTenderBidRegression);
		
		return isRegretSuccess;
    }
    /**
     * @author Priyanka Dalwadi
     * for get list of regret/activate items
     * @return
     * @throws Exception
     */
    public List<Object[]> getRegretActivateItem(int tenderId, int formId,int status,int companyId) throws Exception {
    	boolean success= false; 
    	Map<String, Object> var = new HashMap<String, Object>();
    	
    	List<TblTenderBidRegression> tblRgeretLst = tblTenderBidRegressionDao.findTblTenderBidRegression("formId", Operation_enum.EQ, formId, "tblCompany.companyId", Operation_enum.EQ, companyId);
    	
        var.put("tenderId", tenderId);
        var.put("formId",formId);
     
        if( tblRgeretLst.isEmpty() && status==0){
        	success = true;
        }else if(!tblRgeretLst.isEmpty()){
        	success = true;
        }
        if(success){
        StringBuilder query = new StringBuilder("select tblTenderCell.cellValue as c0,tblTenderCell.tableId as c1,tblTenderCell.rowId as c2,tbltendertable.tablename as c3,tbltendertable.tableHeader as c4,tbltendertable.tableFooter as c5");
        if(status==1){
        	query.append(" , tblTenderBidRegression.remarks as c6 ");
        }
        query.append(" from apptender.tbl_tender tbltender ");
        query.append(" inner join apptender.tbl_tenderform tblTenderForm on tblTenderForm.tenderId = tbltender.tenderId and tblTenderForm.isPriceBid=1 ");
        query.append(" inner join apptender.tbl_tendertable tbltendertable on tbltendertable.formId = tblTenderForm.formId ");
        query.append(" inner join apptender.tbl_tendercolumn tblTenderColumn on tblTenderColumn.tableId = tbltendertable.tableId  and tblTenderColumn.columnTypeId = 1 ");
        query.append(" inner join apptender.tbl_tendercell tblTenderCell on  tblTenderColumn.columnId = tblTenderCell.columnId ");
        if(!tblRgeretLst.isEmpty()){
        	  var.put("companyId",companyId);
        	if(status==0){
        		query.append(" left join apptenderbid.tbl_TenderBidRegression tblTenderBidRegression on tbltender.tenderId = tblTenderBidRegression.tenderId and tblTenderBidRegression.rowId=tblTenderCell.rowId  and  tblTenderBidRegression.tableId=tblTenderCell.tableId and companyId = :companyId");
        	}else{
           	 var.put("status",status);
        		query.append(" inner join apptenderbid.tbl_TenderBidRegression tblTenderBidRegression on tbltender.tenderId = tblTenderBidRegression.tenderId and tblTenderBidRegression.rowId=tblTenderCell.rowId and   tblTenderBidRegression.tableId=tblTenderCell.tableId and tblTenderBidRegression.isActive=:status and companyId = :companyId");
        	}
        	
        }
        query.append(" where tbltender.tenderId = :tenderId and tblTenderForm.formId= :formId and tblTenderCell.dataType != 0  ");
        if(status==0  && !tblRgeretLst.isEmpty()){
        	query.append(" and (tblTenderBidRegression.bidRegressionId is null or  tblTenderBidRegression.isActive=0)  ");
        }
        query.append(" order by tblTenderColumn.tableId,tblTenderCell.rowId ");
        
        if(status==1){
        	int nVarCharColumnIndex [] = {0,3,4,5,6};
            return hibernateQueryDao.createSQLQuery(query.toString(), var, nVarCharColumnIndex, 7); 
        }else{
        	int nVarCharColumnIndex [] = {0,3,4,5};
            return hibernateQueryDao.createSQLQuery(query.toString(), var, nVarCharColumnIndex, 6); 
        }
        }else{
        	return null;
        }
    }
    /**
     * @author Priyanka Dalwadi
     * @param tblTenderBidRegression
     * @param status
     * @param formId
     * @param companyId
     * @param rowId
     * insert/update regret/Activate Item List
     * @return
     */
    @Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
    public boolean updateRegretActivateItem(List<TblTenderBidRegression> tblTenderBidRegression,int status,int formId,int companyId,Map<Integer,Integer> rowIds,boolean updateItemSelection,List<Integer> bidderItemId,int tenderId) throws Exception{
        boolean bSuccess =  addTblRegreatActivateItemHistory(tblTenderBidRegression);
        int cnt = 0;
        if(bSuccess){
        	Map<String, Object> var = new HashMap<String, Object>();
            Map<Integer,List<Integer>> tableRows = new HashMap<Integer, List<Integer>>();
            for (TblTenderBidRegression tbltenderbidregression : tblTenderBidRegression) {
                List<Integer> rowId = null;
                if(tableRows.containsKey(tbltenderbidregression.getTableId())){
                    rowId = tableRows.get(tbltenderbidregression.getTableId());
                }else{                        
                    rowId = new ArrayList<Integer>();
                }
                rowId.add(tbltenderbidregression.getRowId());
                tableRows.put(tbltenderbidregression.getTableId(), rowId);
            }
            if(updateItemSelection && status==1){
        		var.clear();
        		 var.put("bidderItemId",bidderItemId);
                 hibernateQueryDao.updateDeleteNewQuery("update TblItemSelection set isBidded=0 where bidderItemId in (:bidderItemId)", var);
        	}
            for (Integer tableId : tableRows.keySet()) {
            	var.clear();
                var.put("tableId",tableId);
                var.put("rowId",tableRows.get(tableId));
                var.put("formId",formId);
                var.put("companyId",companyId);
                hibernateQueryDao.updateDeleteNewQuery("delete TblTenderBidRegression where formId=:formId and companyId=:companyId and tableId in (:tableId) and rowId in (:rowId)", var);
                if(status==1){
	              
	                var.put("uniqueId",tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8));
	                cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set uniqueId=:uniqueId,isActive=0  where cstatus=0 and feeType=2 and formId=:formId and companyId=:companyId and tableId in (:tableId) and rowId in (:rowId) ",var);        
	                var.put("uniqueId",tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8));
	                cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set uniqueId=:uniqueId,isActive=0  where cstatus=0 and feeType=3 and formId=:formId and companyId=:companyId and tableId in (:tableId) and rowId in (:rowId) ",var);
	                var.put("uniqueId",tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8));
	                cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set uniqueId=:uniqueId,isActive=0  where cstatus=0 and feeType=8 and formId=:formId and companyId=:companyId and tableId in (:tableId) and rowId in (:rowId) ",var);
                }else{
                	 
 	                cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set isActive=1  where cstatus=0 and formId=:formId and tableId in (:tableId) and rowId in (:rowId) and companyId=:companyId ",var);
 	               var.clear();
 	              var.put("formId",formId);           
 	                var.put("companyId",companyId);
	                var.put("uniqueId",tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8));
	                cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set uniqueId=:uniqueId  where cstatus=0 and feeType=2 and companyId=:companyId and formId in (:formId) ",var);        
	                var.put("uniqueId",tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8));
	                cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set uniqueId=:uniqueId where cstatus=0 and feeType=3  and companyId=:companyId and formId in (:formId) ",var);
	                var.put("uniqueId",tenderId+""+UUID.randomUUID().toString().replaceAll("-", "").substring(0,8));
	                cnt = hibernateQueryDao.updateDeleteNewQuery("update TblEventFees tblEventFees set uniqueId=:uniqueId  where cstatus=0 and feeType=8  and companyId=:companyId and formId in (:formId) ",var);
                }
            }
            
            if(status==1){
            tblTenderBidRegressionDao.saveUpdateAllTblTenderBidRegression(tblTenderBidRegression);
            }
            bSuccess = true;
        }   
        return bSuccess;
    }
    /**
     * @author Priyanka Dalwadi
     * @param tblTenderBidRegressionlst
     * Add history for regret/Activate Item List
     * @return
     */
    
    public boolean addTblRegreatActivateItemHistory(List<TblTenderBidRegression> tblTenderBidRegressionlst) throws Exception{
        boolean bSuccess = false; 
        List<TblTenderBidRegressionHistory> tblTenderBidRegressionHistoryList = new ArrayList<TblTenderBidRegressionHistory>();
        for(TblTenderBidRegression tblTenderBidRegression:tblTenderBidRegressionlst){
        	TblTenderBidRegressionHistory tblTenderBidRegressionHistory = new TblTenderBidRegressionHistory();
        	tblTenderBidRegressionHistory.setTblTender(tblTenderBidRegression.getTblTender());
        	tblTenderBidRegressionHistory.setFormId(tblTenderBidRegression.getFormId());//formId
        	tblTenderBidRegressionHistory.setTableId(tblTenderBidRegression.getTableId());//tableId
        	tblTenderBidRegressionHistory.setRowId(tblTenderBidRegression.getRowId());//rowId
        	tblTenderBidRegressionHistory.setRemarks(tblTenderBidRegression.getRemarks());
        	tblTenderBidRegressionHistory.setTblCompany(tblTenderBidRegression.getTblCompany());
        	tblTenderBidRegressionHistory.setTblUserLogin(tblTenderBidRegression.getTblUserLogin());
        	tblTenderBidRegressionHistory.setTblUserDetail(tblTenderBidRegression.getTblUserDetail());
        	tblTenderBidRegressionHistory.setIpAddress(tblTenderBidRegression.getIpAddress());
        	tblTenderBidRegressionHistory.setCreatedBy(tblTenderBidRegression.getTblUserDetail().getUserDetailId());
        	tblTenderBidRegressionHistory.setUpdatedBy(tblTenderBidRegression.getTblUserDetail().getUserDetailId());
        	tblTenderBidRegressionHistory.setIsActive(tblTenderBidRegression.getIsActive());
        	tblTenderBidRegressionHistory.setRegretType(tblTenderBidRegression.getRegretType());
        	tblTenderBidRegressionHistoryList.add(tblTenderBidRegressionHistory);
        }
        tblTenderBidRegressionHistoryDao.saveUpdateAllTblTenderBidRegressionHistory(tblTenderBidRegressionHistoryList);
        bSuccess=true;        
        return bSuccess;
  }
    public 	List<TblTenderBidRegression> CheckBidderEntryExistsInTenderBidRegret(int tenderId,int userId,int isActive)throws Exception{
		List<TblTenderBidRegression> list=tblTenderBidRegretDao.findTblTenderBidRegression("tblTender.tenderId", Operation_enum.EQ,tenderId,"tblUserLogin.userId", Operation_enum.EQ,userId,"isActive", Operation_enum.EQ,isActive,"bidRegressionId",Operation_enum.ORDERBY,Operation_enum.DESC);
	   	return (list!=null && !list.isEmpty()) ? list : null;
	}
    
  
	public Integer getCorrigendumIdFromTenderIdDtls(int tenderId,int cstatus,int processId)throws Exception{
		Map<String,Object> var=new HashMap<String,Object>();
	   	var.put("tenderId", tenderId);
	   	var.put("cstatus", cstatus);
	   	var.put("processId", processId);
	   	StringBuilder query = new StringBuilder();
	   	query.append(" select TC.corrigendumId from TblCorrigendum TC where objectId=:tenderId and TC.cstatus=:cstatus and TC.tblProcess.processId=:processId order by 1 desc ");
	   	List<Object> list = hibernateQueryDao.getSingleColQuery(query.toString(),var);
        return   list.isEmpty() ? 0 : (Integer) list.get(0);
	}

	public TblTenderBidRegression getRegretBidderDetail(int userId,int tenderId)throws Exception{
		List<TblTenderBidRegression> lisTblTenderBidRegression=tblTenderBidRegressionDao.findTblTenderBidRegression("tblUserLogin.userId", Operation_enum.EQ,userId,"tblTender", Operation_enum.EQ,new TblTender(tenderId));
		
		return (lisTblTenderBidRegression!=null && !lisTblTenderBidRegression.isEmpty()) ? lisTblTenderBidRegression.get(0) : null; 
	}
    
	public boolean isBidderRegretted(int userId,int tenderId) throws Exception {
      	long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId", userId);
        var.put("tenderId", tenderId);
        var.put("regretType", 1);
        count = hibernateQueryDao.countForNewQuery("TblTenderBidRegression tblTenderBidRegression ", "tblTenderBidRegression.bidRegressionId ", "tblTenderBidRegression.tblUserLogin.userId=:userId and tblTender.tenderId=:tenderId and regretType=:regretType", var);
        return count != 0;
   }
	public List<Object[]> viewRegretedBidDetails(int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();
		 var.put("tenderId", tenderId);
		 String query="select  TC.companyName as c0,TBR.remarks as c1,T.cstatus as c2,TBR.createdOn as c3 from apptender.tbl_Tender T INNER JOIN apptenderbid.tbl_TenderBidRegression TBR ON T.tenderId=TBR.tenderId INNER JOIN appuser.tbl_Company TC ON TBR.companyId=TC.companyId where T.tenderId=:tenderId and TBR.regreTType=1";
		 int nVarCharColumnIndex [] = {0,1,3};
         return hibernateQueryDao.createSQLQuery(query.toString(), var, nVarCharColumnIndex, 4); 
	}
	public TblUserLogin getUserIdByLoginId(String loginId) throws Exception {
		List<TblUserLogin> list = null;
		list = tblUserLoginDao.findTblUserLogin("loginId",Operation_enum.EQ,loginId);
		return (list!=null && !list.isEmpty()) ? list.get(0) : null; 
		
	}
	public void deleteBidRegressionEntry(int bidderId,int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidderId",bidderId);
        var.put("tenderId",tenderId);
        var.put("regretType", 1);
        hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderBidRegression where bidderId=:bidderId and tenderId=:tenderId and regretType=:regretType", var);
      }
	public void deleteBidIAgreeEntry(int bidderId, int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidderId",bidderId);
        var.put("tenderId",tenderId);
        hibernateQueryDao.updateDeleteNewQuery("delete from TblTenderBidConfirmation where bidderId=:bidderId and tenderId=:tenderId", var);
		
	}
	public void deleteFinalSubmissionEntry(int bidderId, int tenderId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("bidderId",bidderId);
        var.put("tenderId",tenderId);
        hibernateQueryDao.updateDeleteNewQuery("delete from TblFinalSubmission where bidderId=:bidderId and tenderId=:tenderId", var);
		
	}  
	public List<Object[]> getSecoundryPartnerDetail(int tenderId) {
	Map<String, Object> var = new HashMap<String, Object>();
	 var.put("tenderId", tenderId);
	 String query="Select TC.tenderId as c0,TCD.bidderId as c1,TCD.partnerType as c2,TCD.userDetailId as c3 ,UL.loginId as c4,TC.consortiumId as c5 from apptenderbid.tbl_consortium TC INNER JOIN apptenderbid.tbl_ConsortiumDetail TCD ON TC.consortiumId=TCD.consortiumId LEFT JOIN appuser.tbl_UserLogin UL ON UL.userId=TCD.bidderId where tenderId=:tenderId and TCD.partnerType=3 and TC.isActive in (1,0)";
	 int nVarCharColumnIndex [] = {4};
     return hibernateQueryDao.createSQLQuery(query.toString(), var, nVarCharColumnIndex, 6); 
	}
	public TblTender getTblTenderDetail(int tenderId) throws Exception{
        List<TblTender> list=tbltenderDao.findTblTender("tenderId",Operation_enum.EQ,tenderId);
        return list!=null?list.get(0):null;
    }	
    /**
     * Get Bid Regretted Count
     * @author Dhananjay Dubey
     * @param tenderId
     * @param integer
     * @return
     * @throws Exception
     */
	public int getBidWithdrawalCount(int tenderId, int isConsortiumAllowed) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder query = new StringBuilder();
        if(isConsortiumAllowed == 0){
            query.append("SELECT BW.companyId,BW.bidderId from apptenderbid.tbl_BidWithdrawal BW LEFT JOIN apptenderbid.tbl_FinalSubmission FS ");
            query.append("ON BW.companyId = FS.companyId AND BW.tenderId = FS.tenderId ");
            query.append("LEFT JOIN apptenderbid.tbl_TenderBidRegression TBR ON BW.companyId = TBR.companyId AND BW.tenderId = TBR.tenderId ");
            query.append("where BW.tenderId =:tenderId AND FS.finalsubmissionId IS NULL AND (TBR.isActive=0 OR TBR.isActive IS NULL) group by BW.companyId,BW.bidderId");
        }else{
            query.append("select BW.companyId,BW.bidderId from apptenderbid.tbl_BidWithdrawal BW ");
            query.append("LEFT JOIN apptenderbid.tbl_TenderBidRegression TBR ON BW.companyId = TBR.companyId AND BW.tenderId = TBR.tenderId ");
            query.append("where BW.companyId in (select cd.companyId from apptenderbid.tbl_Consortium c inner join apptenderbid.tbl_ConsortiumDetail cd on c.consortiumId = cd.consortiumId ");
            query.append("left join apptenderbid.tbl_FinalSubmission fs on c.consortiumId = fs.consortiumId where c.tenderId =:tenderId and cd.partnerType in (1,2) and c.isActive = 1 and fs.finalsubmissionId IS NULL) AND BW.tenderId =:tenderId AND (TBR.isActive=0 OR TBR.isActive IS NULL) group by BW.companyId,BW.bidderId");
        }
        list = hibernateQueryDao.createSQLQuery(query.toString(), var);
        return list != null && !list.isEmpty() ? list.size() : 0;
    }
    /**
     * Get Bid Regretted Count
     * @author Dhananjay Dubey
     * @param tenderId
     * @param integer
     * @return
     * @throws Exception
     */
    public int getBidRegrettedCount(int tenderId, int isConsortiumAllowed) throws Exception{
        List<Object[]> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        StringBuilder query = new StringBuilder();
       query.append("SELECT TBR.companyId,TBR.bidderId from apptenderbid.tbl_TenderBidRegression TBR LEFT JOIN apptenderbid.tbl_FinalSubmission FS ");
       query.append("ON TBR.companyId = FS.companyId AND TBR.tenderId = FS.tenderId ");
       query.append("LEFT JOIN apptenderbid.tbl_BidWithdrawal BW ON BW.tenderId = TBR.tenderId and TBR.companyId = BW.companyId ");
       query.append("where TBR.tenderId =:tenderId AND TBR.isActive=1 and TBR.regretType=1 group by TBR.companyId,TBR.bidderId");
       list = hibernateQueryDao.createSQLQuery(query.toString(), var);
        return list != null && !list.isEmpty() ? list.size() : 0;
    }
    /**
     * Get Lead Partner Regret Detail
     * @author Dhananjay Dubey
     * @param tenderId
     * @param userId
     * @param integer
     * @return
     * @throws Exception
     */
    public boolean isLeadPartnerRegret(int consortiumId,int partnerType,int bidderId) throws Exception {
      	long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId", consortiumId);
        var.put("partnerType", partnerType);
        var.put("bidderId", bidderId);
        count = hibernateQueryDao.countForNewQuery("TblConsortiumDetail tblConsortiumDetail ", "tblConsortiumDetail.consortiumDetailId", "tblConsortiumDetail.tblConsortium.consortiumId=:consortiumId and tblConsortiumDetail.partnerType=:partnerType and tblConsortiumDetail.tblUserLogin.userId=:bidderId order by 1 asc", var);
        return count != 0;
   }

    public List<Object[]> regretDoneByLeadPartner(int tenderId,int userId) {
    	Map<String, Object> var = new HashMap<String, Object>();
    	 var.put("tenderId", tenderId);
    	 var.put("userId", userId);
    	 String query="Select TC.tenderId as c0,TCD.bidderId as c1,TCD.partnerType as c2,TCD.userDetailId as c3 ,UL.loginId as c4 from apptenderbid.tbl_consortium TC INNER JOIN apptenderbid.tbl_ConsortiumDetail TCD ON TC.consortiumId=TCD.consortiumId LEFT JOIN appuser.tbl_UserLogin UL ON UL.userId=TCD.bidderId where tenderId=:tenderId and TCD.partnerType=2 and userId=:userId";
    	 int nVarCharColumnIndex [] = {4};
         return hibernateQueryDao.createSQLQuery(query.toString(), var, nVarCharColumnIndex, 5); 
    	}
    
    public List<Object[]> secoundryPartner(int tenderId,int userId) {
    	Map<String, Object> var = new HashMap<String, Object>();
    	 var.put("tenderId", tenderId);
    	 var.put("userId", userId);
    	 String query="Select TC.tenderId as c0,TCD.bidderId as c1,TCD.partnerType as c2,TCD.userDetailId as c3 ,UL.loginId as c4 from apptenderbid.tbl_consortium TC INNER JOIN apptenderbid.tbl_ConsortiumDetail TCD ON TC.consortiumId=TCD.consortiumId LEFT JOIN appuser.tbl_UserLogin UL ON UL.userId=TCD.bidderId where tenderId=:tenderId and TCD.partnerType=3 and userId=:userId";
    	 int nVarCharColumnIndex [] = {4};
         return hibernateQueryDao.createSQLQuery(query.toString(), var, nVarCharColumnIndex, 5); 
  }
/*    public boolean isRegretAllow(int tenderId) throws Exception {
      	long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        count = hibernateQueryDao.countForNewQuery("TblTender tblTender", "isRegretAllow", "tblTender.tenderId=:tenderId", var);
        return count == 1;
   }*/
    public boolean isTenderArchive(int tenderId) throws Exception {
    	List<Object> list = null;
        Map<String, Object> var = new HashMap<String, Object>();
        StringBuilder query = new StringBuilder();
        var.put("tenderId", tenderId);
        query.append(" select tbltender.tenderId");
        query.append(" from TblTender tbltender");
        query.append(" where tbltender.tenderId=:tenderId and  GETUTCDATE() > tbltender.submissionEndDate");
        list = hibernateQueryDao.singleColQuery(query.toString(), var);
        if (!list.isEmpty()) {
           return true;
        }
        return false;
   }  
    public boolean isFinalSubmissionDoneBySecoundryPartner(int tenderId, int userId) throws Exception {
      	long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put(TENDERID, tenderId);
        var.put(USERID, userId);
        count = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblfinalsubmission ", "tblfinalsubmission.finalSubmissionId ", "tblfinalsubmission.tblUserLogin.userId=:userId and tblfinalsubmission.tblTender.tenderId=:tenderId and tblfinalsubmission.isActive=1", var);
        return count != 0;
   }   
	public void cancelConsortium(int tenderId,int consortiumId) {
		//int consortiumId
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        //var.put("isActive",2);
        var.put("consortiumId",consortiumId);
       // var.put("consortiumId",consortiumId);
        hibernateQueryDao.updateDeleteNewQuery("update TblConsortiumDetail c  set c.isActive = 2 where c.consortiumId=:consortiumId and c.tblTender.tenderId=:tenderId",var);
       // "update TblConsortium tblConsortium set isActive=:isActive where tblConsortium.tbltender.tenderId=:tenderId"
        //hibernateQueryDao.updateDeleteNewQuery("delete from TblFinalSubmission where bidderId=:bidderId and tenderId=:tenderId", var);
		
	}
	/*public boolean finalConsortiumProcess(int consortiumId) throws Exception
    {
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId",consortiumId);
        StringBuilder query=new StringBuilder();
        query.append("update TblConsortium c  set c.isActive = 2 where c.consortiumId=:consortiumId and tblConsortium.tblTender.tenderId=:tenderId");
        return hibernateQueryDao.updateDeleteNewQuery(query.toString(),var)!=0;        
    }*/
	
	
	/**
	 * @param tenderId
	 * @param envelopeId
	 * @param companyId
	 * @return
	 * @throws Exception
	 */
	public List<Object[]> getFirstPricedBidFormBidId(int tenderId,int envelopeId,int companyId)throws Exception{
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId",tenderId);
        var.put("envelopeId",envelopeId);
        var.put("companyId",companyId);
        StringBuilder query = new StringBuilder();
        query.append("select top 1 TF.formId,TB.bidId from apptenderbid.tbl_TenderBid TB ");
        query.append("INNER JOIN apptender.tbl_TenderForm TF ON TB.formId=TF.formId and TF.cstatus=1 and TF.isPriceBid=1 ");
        query.append("where TB.tenderId=:tenderId and TB.envelopeId=:envelopeId and TB.companyId=:companyId order by TF.sortOrder " );
        return hibernateQueryDao.createSQLQuery(query.toString(), var);
	}
	public void deleteConsortiumSecoundryPartnerEntry(int userId, int consortiumId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId",userId);
        var.put("consortiumId",consortiumId);
        var.put("partnerType",3);
        hibernateQueryDao.updateDeleteNewQuery("delete from TblConsortiumDetail tblConsortiumDetail where tblConsortiumDetail.tblConsortium.consortiumId=:consortiumId and partnerType=:partnerType and tblConsortiumDetail.tblUserLogin.userId=:userId ", var);
		
	}  
	public void deleteConsortiumPrimaryPartnerEntry(int userId, int consortiumId) {
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId",userId);
        var.put("consortiumId",consortiumId);
        var.put("partnerType",2);
        hibernateQueryDao.updateDeleteNewQuery("delete from TblConsortiumDetail tblConsortiumDetail where tblConsortiumDetail.tblConsortium.consortiumId=:consortiumId and partnerType=:partnerType and tblConsortiumDetail.tblUserLogin.userId=:userId ", var);
		
	}  
	public boolean isBidderItemWiseRegretted(int userId,int tenderId,int selectRowId,int isActive) throws Exception {
      	long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId", userId);
        var.put("tenderId", tenderId);
        var.put("selectRowId", selectRowId);
        var.put("regretType", 2);
        var.put("isActive", isActive);
        count = hibernateQueryDao.countForNewQuery("TblTenderBidRegressionHistory tenderBidRegressionHistory ", "tenderBidRegressionHistory.bidRegressionHistoryId ", "tenderBidRegressionHistory.tblUserLogin.userId=:userId and tblTender.tenderId=:tenderId and regretType=:regretType and tenderBidRegressionHistory.rowId=:selectRowId and tenderBidRegressionHistory.isActive=:isActive", var);
        return count != 0;
   }
	public boolean isLeadPartnerRegretPartenerType(int consortiumId,int partnerType,int bidderId) throws Exception {
      	long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("consortiumId", consortiumId);
        var.put("partnerType", partnerType);
        var.put("bidderId", bidderId);
        count = hibernateQueryDao.countForNewQuery("TblConsortiumDetail tblConsortiumDetail ", "tblConsortiumDetail.consortiumDetailId", "tblConsortiumDetail.tblConsortium.consortiumId=:consortiumId and tblConsortiumDetail.partnerType=:partnerType and tblConsortiumDetail.tblUserLogin.userId=:bidderId", var);
        return count != 0;
   }
	public List<Object[]> getPartnerType(int tenderId,int bidderId) {
		Map<String, Object> var = new HashMap<String, Object>();
		 var.put("tenderId", tenderId);
		 var.put("bidderId", bidderId);
		 String query="Select TC.tenderId as c0,TCD.bidderId as c1,TCD.partnerType as c2,TCD.userDetailId as c3 ,UL.loginId as c4,TC.consortiumId as c5 from apptenderbid.tbl_consortium TC INNER JOIN apptenderbid.tbl_ConsortiumDetail TCD ON TC.consortiumId=TCD.consortiumId LEFT JOIN appuser.tbl_UserLogin UL ON UL.userId=TCD.bidderId where tenderId=:tenderId and bidderId=:bidderId and TC.isActive in (1,0)";
		 int nVarCharColumnIndex [] = {4};
	     return hibernateQueryDao.createSQLQuery(query.toString(), var, nVarCharColumnIndex, 6); 
		}
	public boolean isBidderRegrettedItemwise(int userId,int tenderId,int rowId) throws Exception {
      	long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("userId", userId);
        var.put("tenderId", tenderId);
        var.put("regretType", 2);
        var.put("rowId", rowId);
        count = hibernateQueryDao.countForNewQuery("TblTenderBidRegression tblTenderBidRegression ", "tblTenderBidRegression.bidRegressionId ", "tblTenderBidRegression.tblUserLogin.userId=:userId and tblTender.tenderId=:tenderId and regretType=:regretType and tblTenderBidRegression.rowId=:rowId", var);
        return count != 0;
   }
	public boolean getBIdDetailOfBidderAllreadyBidded(int tableId) throws Exception {
      	long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tableId", tableId);
        count = hibernateQueryDao.countForNewQuery("TblTenderBidMatrix tblTenderBidMatrix ", "tblTenderBidMatrix.bidTableId ", "tblTenderBidMatrix.tblTenderTable.tableId=:tableId", var);
        return count != 0;
   }
	public TblTenderTable getTenderTableDetail(int formId) throws Exception {
        List<TblTenderTable> lstTblTenderTable = tblTenderTableDao.findTblTenderTable("tblTenderForm.formId", Operation_enum.EQ, formId);
        if (lstTblTenderTable != null && !lstTblTenderTable.isEmpty()) {
            return lstTblTenderTable.get(0);
        } else {
            return null;
        }

    }
	public boolean isFinalSubmissionDoneByBidder(int tenderId, int userId) throws Exception {
      	long count = 0;
        Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("userId", userId);
        count = hibernateQueryDao.countForNewQuery("TblFinalSubmission tblfinalsubmission ", "tblfinalsubmission.finalSubmissionId ", "tblfinalsubmission.tblTender.tenderId=:tenderId and tblfinalsubmission.isActive=1 and tblfinalsubmission.tblUserLogin.userId=:userId", var);
        return count != 0;
   }
	
	public boolean isSecondarypartnerInvited(int userId, int tenderId) {
		List<Object[]> lst = null;
		Map<String, Object> var = new HashMap<String, Object>();
        var.put("tenderId", tenderId);
        var.put("userId", userId);
        lst= hibernateQueryDao.createNewQuery("select tblConsortiumDetail.tblConsortium.consortiumId,tblConsortiumDetail.partnerType from TblConsortiumDetail tblConsortiumDetail inner join tblConsortiumDetail.tblConsortium tblConsortium where  tblConsortiumDetail.tblUserLogin.userId=:userId  and tblConsortiumDetail.partnerType = 3 and tblConsortium.tblTender.tenderId=:tenderId and tblConsortiumDetail.cstatus in (0,1) and tblConsortiumDetail.tblConsortium.isActive=0", var);
        return (lst !=null && !lst.isEmpty()) ? true : false;
	}  
}
