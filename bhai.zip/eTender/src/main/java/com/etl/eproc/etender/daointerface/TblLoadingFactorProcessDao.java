package com.etl.eproc.etender.daointerface;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.etender.model.TblLoadingFactorProcess;

public interface TblLoadingFactorProcessDao  {

    public void addTblLoadingFactorProcess(TblLoadingFactorProcess tblLoadingFactorProcess);

    public void deleteTblLoadingFactorProcess(TblLoadingFactorProcess tblLoadingFactorProcess);

    public void updateTblLoadingFactorProcess(TblLoadingFactorProcess tblLoadingFactorProcess);

    public List<TblLoadingFactorProcess> getAllTblLoadingFactorProcess();

    public List<TblLoadingFactorProcess> findTblLoadingFactorProcess(Object... values) throws Exception;

    public List<TblLoadingFactorProcess> findByCountTblLoadingFactorProcess(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblLoadingFactorProcessCount();

    public void saveUpdateAllTblLoadingFactorProcess(List<TblLoadingFactorProcess> tblLoadingFactorProcesss);

	public void saveOrUpdateTblLoadingFactorProcess(TblLoadingFactorProcess tblLoadingFactorProcess);
}