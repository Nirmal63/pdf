/**
 * To load listing grid
 */
function loadListingGrid(isShowMore){
	if(isShowMore){
		$('#txtpageNo').val(Number($('#txtpageNo').val())+1);
	}
	var urlstr="";
	$("#tab_"+selectedTab).addClass("active");
	urlstr+="&txtAucStatus="+selectedTab;
	urlstr+="&txtPageNo="+$('#txtpageNo').val();
	if(searchFieldCount==1){
		console.log("urlStr for searched");
		urlstr+="&txtSearch=1";
		urlstr+="&txtSearchData="+$("#txtKeywordSearch").val();
	}
	$.ajax({
	        type: "POST",
	        url: jsReportUrlStr,
	        dataType: 'text',
	        data : urlstr,
	        success: function(searchedData)
	        {
	        	if($.trim(searchedData).indexOf("sessionexpired") != -1)
                {
                    window.location = errorPageUrl;
                }
                else
                {
                	if(searchFieldCount==1){
                		$("#tabDiv").hide();
                	}
                	else{
                		$("#tabDiv").show();
                	}
                	$("#reportResultDiv").html(searchedData);
                	$("#divTotalRecords_"+selectedTab).html("("+$('#txtTotalRecords').val()+")");
                	console.log("$('#txtpageNo').val() : "+$('#txtpageNo').val()+"\n $('#txtTotalPages').val() : "+$("#txtTotalPages").val());
                	if(Number($('#txtpageNo').val()) >= Number($("#txtTotalPages").val())){
                		$("#btnShowMore").hide();
                	}
                	else{
                		$("#btnShowMore").show();
                	}
                }
	        },
	        error: function(XMLHttpRequest, textStatus, errorThrown) {
	            alert(ajaxErrorMsg);
	            return false;
	        }
	});
}
/*
 * To search from listing.  
 */
function search(){
	if($("#txtKeywordSearch").val() != null && $.trim($("#txtKeywordSearch").val()) != '') {
		$('#txtpageNo').val('1');
		searchFieldCount = 1;
		loadListingGrid(false);
	}
	else{
		alert(MSG_SEARCHCRITERIA);
	}
}
/*
 * In case of after type in search textbox press 'Enter' key.
 */
function loadReport(key){
	if(key.keyCode ===13){
		search();
	}
}
/*
 * To clear search
 */
function resetListinGrid(){
	$("#tabDiv").show();
	searchFieldCount = 0;
	$("#txtKeywordSearch").val("")
	tabClick(1);
}
/*
 * When click on tab
 */
function tabClick(tabNo){
	selectedTab = tabNo;
	 $("a").each(function( i ){
		if($(this).attr('id') != null && $(this).attr('id') != undefined && $(this).attr('id').indexOf('tab_') != -1) 
		{
			$(this).removeClass("active");
			$(this).find("span").html("");
		}
	});
	$('#tab_'+tabNo).addClass('active');
	$('#txtpageNo').val("1");
	loadListingGrid(false);
}

// Send participation request (i m interested)
function sendParticipationRequest(auctionId,context,interestId) {
		var ajaxurl=context+"/eauction/bidder/iminterrested";
		$.ajax({
    		type:"POST",
    		async: true,
			dataType: "json",
		    url: ajaxurl,
    	    data:{
    	    	'txtAuctionId' : auctionId, 
    	    	'txtInterestId' : interestId 
    	    },
    	    success:function(ajaxData){
				if(ajaxData != null) {
				 $.each( ajaxData, function( key, value ) {	
					 if(value == "true") {
						$('.interested_'+auctionId).html('Requested for participation');
						$('.interested_'+auctionId).removeClass("orange");
					 }
				 });
				}	 
            }
    	});
}
