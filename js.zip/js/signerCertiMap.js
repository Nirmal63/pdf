$(document).ready(function() {
	openSignEncKeyStore();	/* load as per digicertificate.js - $.getScript*/
});

function openSignEncKeyStore() { /* replica of signEncryptCert.js - openSignEncKeyStore*/
	var signCombo = document.getElementById("certNames_sign");
	var enccombo = document.getElementById("certNames_encrypt");
	
	if (signCombo != null) {
		for (var i = signCombo.length; i >= 0; i--) {
			signCombo.options[i] = null;
		}
		signCombo.options[0] = new Option("--Please Select--",0);
	}
	if (enccombo != null) {
		for (var i = enccombo.length; i >= 0; i--) {
			enccombo.options[i] = null;
		}
		enccombo.options[0] = new Option("--Please Select--", 0);
	}
	var certificates = sealock.getCertificateAliases();
	var noOfcertificate = certificates != null ? certificates.length : 0;
	for (var i = 0; i < noOfcertificate; i++) {
	    var certificate = certificates[i];
	    try {
			var isSignCert = certificate.digitalSignature;
			var isEncCert = certificate.dataEncipherment;
			var certAlias = certificate.serialNumber;
			if (isSignCert && signCombo != null) {
				signCombo.options[signCombo.length] = new Option(certificate.clientName, certAlias);
			}
			if (isEncCert && enccombo != null) {
				enccombo.options[enccombo.length] = new Option(certificate.clientName, certAlias);
			}
		} catch (e) {}
	}
	if(signCombo != null){
		sortComboText('certNames_sign');
		if(signCombo.length == 2){
	   	 	signCombo.selectedIndex = '1';
	    	$(signCombo).change();
		}else{            
	   		if(typeof SIGNPKEY !=='undefined' && SIGNPKEY!=''){                 
		        $(signCombo).val(getCertiAliasByKeyUsage(SIGNPKEY, 1));
		        $(signCombo).change();
		        enccombo.options[0] = new Option("--Please Select--", 1);
		    }
		}
	}
    if(enccombo != null){
        sortComboText('certNames_encrypt');
        if(enccombo.length == 2){
            enccombo.selectedIndex = '1';
            $(enccombo).change();
        }
    }
}

var remainDays = 0;

function showSignEncCertInfo(certType) { /* replica of signEncryptCert.js - showSignEncCertInfo*/
	if (certType == 'encrypt') {
		if (document.getElementById("certNames_encrypt").value == 0 || document.getElementById("certNames_encrypt").value == 1) {
			document.getElementById("skpSubject_encrypt").value = null;
			document.getElementById("skpIssuer_encrypt").value = null;
			document.getElementById("skpSerial_encrypt").value = null;
			document.getElementById("skpValidFrom_encrypt").value = null;
			document.getElementById("skpValidTo_encrypt").value = null;
			document.getElementById("skpPublicKey_encrypt").value = null;
			document.getElementById("skpAlias_encrypt").value = null;
			document.getElementById("skpPurpose_encrypt").value = null;
			$('#key_encrypt').hide();
		} else {
			$('#key_encrypt').show();
		}
	}

	var td = document.getElementById("key_" + certType);
	var isSign = new Boolean();
	var isEncrypt = new Boolean();
	var oids = '2.16.356.100.2.';
	var certificateClass = "";
	if (document.getElementById("jhdcertificateclass").value != null || document.getElementById("jhdcertificateclass").value != "") {
		certificateClass = document.getElementById("jhdcertificateclass").value;
	} else {
		certificateClass = 'N.A';
	}
		
	if (document.getElementById("certNames_" + certType).value != 0) {
		document.getElementById("newkey2_" + certType).style.display = '';
		var tableDataCert = "<h2 class='black'>Certificate Detail : </h2><table class='m-top1'>";
		sealock.selectCertificate(document.getElementById("certNames_" + certType).value);
		var certSub = sealock.getCertificateInformation();
		if(certSub != null){
			if(certificateClass.indexOf('N.A') == -1) { 					// If certificateClass doesnot consist of N.A then tresspass else bypass
				var certificateClassArray = certificateClass.split("|");
				for (var i = 0; i < certificateClassArray.length; i++) { 
					oids = '2.16.356.100.2.' + certificateClassArray[i];
					var certificatePolicies = certSub.certificateClass;
					if(certificatePolicies.indexOf('N.A') == -1){
						if(oids == certificatePolicies || certSub.issuerName == "CN=e-Procurement Technologies Ltd. (Internal use only)" ){
							document.getElementById("jhdisValidPolicy").value="valid";
						    break;
						}else {
						    document.getElementById("jhdisValidPolicy").value="invalid";
						}
					}else{
						if(certSub.issuerName == "CN=e-Procurement Technologies Ltd. (Internal use only)"){
							document.getElementById("jhdisValidPolicy").value="valid";
							break;
						}else{
							document.getElementById("jhdisValidPolicy").value="invalid";
						}
					}
				}        
			}else{
				document.getElementById("jhdisValidPolicy").value="valid";
			}
			
			var subject = certSub.clientName;
			document.getElementById("skpSubject_" + certType).value = subject;		
			tableDataCert = tableDataCert  + "<tr><td width='17%' class='no-padding black'>Subject</td><td width='83%' class='a-left' style='line-height:18px;'>" + subject + "</td></tr>";
			var certIssuer = certSub.issuerName; 
			document.getElementById("skpIssuer_" + certType).value = certIssuer; 
			tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Issuer</td><td  class='a-left'>" + certIssuer + "</td></tr>";
			var certSerial = certSub.serialNumber;
			document.getElementById("skpSerial_" + certType).value = certSerial;
			tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Serial No.</td><td  class='a-left'>" + certSerial + "</td></tr>";
			var certValidFrom =certSub.validFrom;
			document.getElementById("skpValidFrom_" + certType).value = certValidFrom;
			tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Valid From</td><td  class='a-left'>" + certValidFrom + "</td></tr>";

			var certValidTo =certSub.validTo;
			document.getElementById("skpValidTo_" + certType).value = certValidTo;
			tableDataCert = tableDataCert+ "<tr><td  class=' no-padding black'>Valid To</td><td  class='a-left'>" + certValidTo + "</td></tr></table>";
			td.innerHTML = tableDataCert;
			document.getElementById("skpPublicKey_" + certType).value = certSub.publicKey;
			document.getElementById("skpAlias_" + certType).value = certSub.alias;
		}
		if (chekSignEncCertificateRenewDate(certType)) {
			td.innerHTML = td.innerHTML+ " <br><br><b><font>Note : </font></b>";
			td.innerHTML = td.innerHTML+ " <b><font>Please Renew your digital certificate.</font></b> ";
			td.innerHTML = td.innerHTML+ " <b><font>It's going to expire in next " + remainDays+ " days. </font></b>";
			td.innerHTML = td.innerHTML+ " <b><font>You may contact any of abcProcure support executive for Renewal process.</font></b></br>";
		}
   	} else {
		document.getElementById("newkey2_" + certType).style.display = 'none';
		document.getElementById("skpSubject_" + certType).value = "";
		document.getElementById("skpIssuer_" + certType).value = "";
		document.getElementById("skpSerial_" + certType).value = "";
		document.getElementById("skpValidFrom_" + certType).value = "";
		document.getElementById("skpValidTo_" + certType).value = "";
		document.getElementById("skpPublicKey_" + certType).value = "";
		document.getElementById("skpPurpose_" + certType).value = "";
		document.getElementById("skpAlias_" + certType).value = "";
		td.innerHTML = "";
	}
}

function checkBothCertExpire() { /* replica of signEncryptCert.js - checkBothCertExpire*/
	$('.err').remove();
    if (document.getElementById("certNames_sign").value == 0 || (document.getElementById("certNames_encrypt")  != null  && document.getElementById("certNames_encrypt").value == 1)) {
    	if (document.getElementById("certNames_sign").value == 0) {
    		$("#certNames_sign").parent().append("<div class='err' style='color:red;margin-top:5px;'>Please select Signing Certificate</div>");
    	}
        if (document.getElementById("certNames_encrypt")  != null && document.getElementById("certNames_encrypt").value == 1) {
        	$("#certNames_encrypt").parent().append("<div class='err' style='color:red;margin-top:5px;'>Please select Encryption Certificate</div>");
        }
        return false;
    }

	var certificateClass = document.getElementById("jhdcertificateclass").value;
	var certificateClassArray = certificateClass.split("|");
	
	var temp = document.getElementById("jhdisValidPolicy").value;
	if(temp.indexOf('invalid') != -1) {			// If invalid than fire validation
		var alertText = "Please attach";
		for (var i = 0; i < certificateClassArray.length; i++) { 
			alertText = alertText + " Class-"+certificateClassArray[i];
			if(i != certificateClassArray.length-1) {
				alertText = alertText + " or";
			}
		}
		alertText = alertText + " digital certificate";
		alert(alertText);
		return false;
   }      

	var currentDt = new Date(document.getElementById("serverdt").value);
	var signCertDt = new Date(document.getElementById("skpValidTo_sign").value);	
	var encCertDt = (document.getElementById("skpValidTo_encrypt")!=null) ? new Date(document.getElementById("skpValidTo_encrypt").value) : '';
	if(currentDt >= signCertDt){
		alert("Signing Digital Certificate is expired. Please select valid Digital Certificate.");
		return false;
	}
	if(encCertDt!='' && currentDt >= encCertDt){
		alert("Encryption Digital Certificate is expired. Please select valid Digital Certificate");
		return false;
	}
	return true;
}

function chekSignEncCertificateRenewDate(certType) { /* replica of signEncryptCert.js - chekSignEncCertificateRenewDate*/
	if (document.getElementById("certNames_sign").value != 0 || document.getElementById("certNames_encrypt").value != 0) {
		var theDate;
		if (certType == "sign") {
			theDate = document.getElementById("skpValidTo_sign").value;
		} else {
			theDate = document.getElementById("skpValidTo_encrypt").value;
		}
		var currentDt = new Date(document.getElementById("serverdt").value);
		var certDt = new Date(theDate);
		var DAY = 1000 * 60 * 60 * 24;
		remainDays = (Math.round((certDt.getTime() - currentDt.getTime()) / DAY));
		if ((Math.round((certDt.getTime() - currentDt.getTime()) / DAY)) <= 30) {
			if ((Math.round((certDt.getTime() - currentDt.getTime()) / DAY)) <= 0) {
				return false;
			} else {
				return true;
			}
		} else {
			return false;
		}
	}
}

function sortComboText(id){ /* replica of digicertificate.js - sortComboText*/
	var cmb = document.getElementById(id);
    var value = new Array();
    var text = new Array();
   	for(var i=0;i<cmb.options.length;i++){
    	value[i]=(cmb.options[i].value);
  		text[i]=($.trim(cmb.options[i].text.toString()));
    }
    for(var i=1;i<cmb.options.length;i++){
        for(var j=0;j<cmb.options.length-i;j++){
            if(text[j].toString().toUpperCase() > text[j+1].toString().toUpperCase()){
                var temp=text[j];
                text[j]=text[j+1];
                text[j+1]=temp;
                var temp2=value[j];
                value[j]=value[j+1];
                value[j+1]=temp2;
            }
        }
    }
    var options = '';
    var psVar = '';
    for(var i=0;i<cmb.options.length;i++){
        if(text[i] != '--Please Select--'){
            options = options+'<option value="'+value[i]+'">'+text[i]+'</option>';
        }else {
            psVar = '<option value="'+value[i]+'">'+text[i]+'</option>';
        }
    }
	$('#'+id).html(psVar+options);
}

function isValidEncAndBrowserSupport(signedata){ /* replica of browserCheck.js - isValidEncAndBrowserSupport*/
	try {
		sealock.selectCertificate(document.getElementById("certNames_encrypt").value);
	    var bidderPublicKey = sealock.getPublicKey();
		sealock.setPublicKey(bidderPublicKey);
	    sealock.setPublicKey1(bidderPublicKey);
	    sealock.setData(signedata);
	    var encrypt1 = sealock.getMultiEncrypt();
	    sealock.setData(encrypt1);
	    var encrypt2 = sealock.getMultiEncrypt();
	    return true;
	} catch (e) {
		alert("System is unable to encrypt the data due to system configuration/browser support. Kindly contact our support executive.");
		return false;
    }
}