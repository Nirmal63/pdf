function openSignEncKeyStore() {
    sealock.openKeyStore("my", "");
    var signCombo = document.getElementById("certNames_sign");
    var enccombo = document.getElementById("certNames_encrypt");
    if(signCombo != null){
    	for (var i = signCombo.length; i >= 0; i--) {
            signCombo.options[i] = null;
        }
    	signCombo.options[0] = new Option("--Please Select--", 0);
    }
 
    if(enccombo != null){
	    for (var i = enccombo.length; i >= 0; i--) {
	        enccombo.options[i] = null;
	    }
	    enccombo.options[0] = new Option("--Please Select--", 0);
    }    

    var certSubject;
    var isSignCert = false;
    var isEncCert = false;
    var subStringForCN;
    var clientName;

    var certCount = sealock.getCertificateCount();

    for (var i = 1; i <= certCount; i++) {
        sealock.selectCertificate(sealock.getCertificateAlias(i));
        certSubject = sealock.getCertificateInformation(0);
        
        if(signCombo != null){
        	isSignCert = sealock.getCertificateInformation(7).IsDigitalSignatureEnabled;
        }
        if(enccombo != null){
        	isEncCert = sealock.getCertificateInformation(7).IsKeyEnciphermentEnabled;
        }

        subStringForCN = certSubject.substring(certSubject.indexOf('CN=') + 3, certSubject.length);

        if (subStringForCN.indexOf(',') != -1) {
            clientName = subStringForCN.substring(0, subStringForCN.indexOf(','));
        } else {
            clientName = subStringForCN;
        }

        if (isSignCert) {
            signCombo.options[signCombo.length] = new Option(clientName, sealock.getCertificateAlias(i));
        }
        if (isEncCert) {
            enccombo.options[enccombo.length] = new Option(clientName, sealock.getCertificateAlias(i));
        }
    }
    if(signCombo != null){
        sortComboText('certNames_sign');
        if(signCombo.length == 2){
            signCombo.selectedIndex = '1';
            $(signCombo).change();
        }else{            
            if(typeof SIGNPKEY !=='undefined' && SIGNPKEY!=''){                 
                $(signCombo).val(getCertiAliasByKeyUsage(SIGNPKEY,'1'));
                $(signCombo).change();
                $(signCombo).attr('disabled', '');
                enccombo.options[0] = new Option("--Please Select--", 1);
            }
        }
    }
    if(enccombo != null){
        sortComboText('certNames_encrypt');
        if(enccombo.length == 2){
            enccombo.selectedIndex = '1';
            $(enccombo).change();
        }
     }
}

var remainDays = 0;

function showSignEncCertInfo(certType) {
	if(certType == 'encrypt')
	{
		if(document.getElementById("certNames_encrypt").value == 0 || document.getElementById("certNames_encrypt").value == 1)
		{
			
			document.getElementById("skpSubject_encrypt").value=null;
	        document.getElementById("skpIssuer_encrypt").value=null;
	        document.getElementById("skpSerial_encrypt").value=null;
	        document.getElementById("skpValidFrom_encrypt").value=null;
	        document.getElementById("skpValidTo_encrypt").value=null;
	        document.getElementById("skpPublicKey_encrypt").value=null;
	        document.getElementById("skpAlias_encrypt").value=null;
	        document.getElementById("skpPurpose_encrypt").value=null;
	        $('#key_encrypt').hide();
		}	
		else
		{
			$('#key_encrypt').show();
		}
	}
	
    var td = document.getElementById("key_" + certType);
    var isSign = new Boolean();
    var isEncrypt = new Boolean();
	var oids = '2.16.356.100.2.';
	var certificateClass = "";
	if(document.getElementById("jhdcertificateclass").value!=null || document.getElementById("jhdcertificateclass").value!="")
	{
		certificateClass = document.getElementById("jhdcertificateclass").value;
	}
	else
	{
		certificateClass = 'N.A';
	}
    if (document.getElementById("certNames_" + certType).value != 0) {
    	document.getElementById("newkey2_" + certType).style.display = '';
                var tableDataCert = "<h2 class='black'>Certificate Detail : </h2><table class='m-top1'>";
        
        sealock.selectCertificate(document.getElementById("certNames_" + certType).value);
        if(certificateClass.indexOf('N.A')  == -1)  					// If certificateClass doesnot consist of N.A then tresspass else bypass
        {
        	var certificateClassArray = certificateClass.split("|");
        	var sealockForPolicy = new signer();
          	sealockForPolicy.openKeyStore("my", "");
          	
        	for (var i = 0; i < certificateClassArray.length; i++) { 
        	    oids= '2.16.356.100.2.' + certificateClassArray[i];
        	    var certificatePolicies = sealockForPolicy.selectCertificatePolicy(oids);
                if(certificatePolicies.Count > 0)
              	{
              		for(var i=1;i<=certificatePolicies.Count;i++)
              		{
              			sealockForPolicy.getSelectedCertificatePolicy(certificatePolicies,i);
              			
              			if(sealock.getPublicKey() == sealockForPolicy.getPublicKey() || sealock.getCertificateInformation(1) == "CN=e-Procurement Technologies Ltd. (Internal use only)" )
              			{
              				document.getElementById("jhdisValidPolicy").value="valid";
              				break;
              			}
              			else
              			{
              				document.getElementById("jhdisValidPolicy").value="invalid";
              			}
              		}
            	}
                else
                {
                	if(sealock.getCertificateInformation(1) == "CN=e-Procurement Technologies Ltd. (Internal use only)")
                	{
                		document.getElementById("jhdisValidPolicy").value="valid";
                	}
                	else
                	{
                		document.getElementById("jhdisValidPolicy").value="invalid";
                	}
                }
        	}        

        }
        else
        {
        	document.getElementById("jhdisValidPolicy").value="valid";
        }
            	
        document.getElementById("skpSubject_" + certType).value = sealock.getCertificateInformation(0);
        tableDataCert = tableDataCert + "<tr><td width='36%' class='no-padding black'>Subject</td><td width='53%' class='a-left' style='line-height:18px;'>"+ sealock.getCertificateInformation(0)+"</td></tr>";

        document.getElementById("skpIssuer_" + certType).value = sealock.getCertificateInformation(1);
        tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Issuer</td><td  class='a-left'>" + sealock.getCertificateInformation(1)+"</td></tr>";

        document.getElementById("skpSerial_" + certType).value = sealock.getCertificateInformation(2);
        tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Serial No.</td><td  class='a-left'>" + sealock.getCertificateInformation(2)+"</td></tr>";

               var tmpDateF= new Date(sealock.getCertificateInformation(5));
        var finalDateF= tmpDateF;
        var tmpDateT= new Date(sealock.getCertificateInformation(6));
        var finalDateT= tmpDateT;
        var browser=detectBrowserVersion();
        if(browser=="11"){
            var utcDateF=tmpDateF.toUTCString().split(" ");
            var dayF=utcDateF[0].split(",");
            finalDateF=dayF[0]+" "+utcDateF[2]+" "+utcDateF[1]+" "+utcDateF[4]+" "+"UTC"+"+0530"+" "+utcDateF[3];
            
            var utcDateT=tmpDateT.toUTCString().split(" ");
            var dayT=utcDateT[0].split(",");
            finalDateT=dayT[0]+" "+utcDateT[2]+" "+utcDateT[1]+" "+utcDateT[4]+" "+"UTC"+"+0530"+" "+utcDateT[3];
        }
        document.getElementById("skpValidFrom_" + certType).value = finalDateF;
        tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Valid From</td><td  class='a-left'>" + finalDateF+"</td></tr>";

        document.getElementById("skpValidTo_" + certType).value = finalDateT;
        tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Valid To</td><td  class='a-left'>" + finalDateT+"</td></tr></table>";

        td.innerHTML = tableDataCert /*+ " <br><br><b style='display:none;'>Public Key : </b></br><div style='display:none;word-break: break-all; white-space:normal; word-wrap: break-word; width:320px;'>" + wrapPublicKey(sealock.getPublicKey()) + "</div>";*/
        document.getElementById("skpPublicKey_" + certType).value = sealock.getPublicKey();
        
        isSign = sealock.getCertificateInformation(7).IsDigitalSignatureEnabled;
        isEncrypt = sealock.getCertificateInformation(7).IsKeyEnciphermentEnabled;
        
        if(isSign && isEncrypt){
        	document.getElementById("skpPurpose_" + certType).value = "2";
        }
        else {
        	document.getElementById("skpPurpose_" + certType).value = "1";
        }

        document.getElementById("skpAlias_" + certType).value = document.getElementById("certNames_" + certType).value;
        
        if (chekSignEncCertificateRenewDate(certType)) {
            td.innerHTML = td.innerHTML + " <br><br><b><font>Note : </font></b>";
            td.innerHTML = td.innerHTML + " <b><font>Please Renew your digital certificate.</font></b> ";
            td.innerHTML = td.innerHTML + " <b><font>It's going to expire in next " +remainDays+ " days. </font></b>";
            td.innerHTML = td.innerHTML + " <b><font>You may contact any of abcProcure support executive for Renewal process.</font></b></br>";
        }
    } else {
        document.getElementById("newkey2_" + certType).style.display = 'none';
        td.innerHTML = "";
    }
}

function checkIsDcVerified()
{
	

}
function checkBothCertExpire(){
        $('.err').remove();
        if (document.getElementById("certNames_sign").value == 0 || (document.getElementById("certNames_encrypt")  != null  && document.getElementById("certNames_encrypt").value == 1)) {
                if (document.getElementById("certNames_sign").value == 0) {
                    $("#certNames_sign").parent().append("<div class='err' style='color:red;margin-top:5px;'>Please select Signing Certificate</div>");
                }
                if (document.getElementById("certNames_encrypt")  != null && document.getElementById("certNames_encrypt").value == 1) {
                            $("#certNames_encrypt").parent().append("<div class='err' style='color:red;margin-top:5px;'>Please select Encryption Certificate</div>");
                        }
		return false;
	}	
	
    	var certificateClass = document.getElementById("jhdcertificateclass").value;
    	var certificateClassArray = certificateClass.split("|");
    	
var temp = document.getElementById("jhdisValidPolicy").value;
		if(temp.indexOf('invalid') != -1)			// If invalid than fire validation
       {
    	   var alertText = "Please attach";
    	   
    	for (var i = 0; i < certificateClassArray.length; i++) { 
    		
    		alertText = alertText + " Class-"+certificateClassArray[i];
    		
    		if(i != certificateClassArray.length-1)
    		{
    			alertText = alertText + " or";
    		}
    	
    	}
    		alertText = alertText + " digital certificate";
    		alert(alertText);
    		return false;
       }      
	
	var currentDt = new Date(document.getElementById("serverdt").value);
	var signCertDt = new Date(document.getElementById("skpValidTo_sign").value);	
	var encCertDt = (document.getElementById("skpValidTo_encrypt")!=null) ? new Date(document.getElementById("skpValidTo_encrypt").value) : '';
	if(currentDt >= signCertDt){
		alert("Signing Digital Certificate is expired. Please select valid Digital Certificate.");
		return false;
	}
	if(encCertDt!='' && currentDt >= encCertDt){
		alert("Encryption Digital Certificate is expired. Please select valid Digital Certificate");
		return false;
	}
	return true;
}

function chekSignEncCertificateRenewDate(certType) {
    if (document.getElementById("certNames_sign").value != 0 || document.getElementById("certNames_encrypt").value != 0) {
        var theDate;
        
        if (certType == "sign") {
            theDate = document.getElementById("skpValidTo_sign").value;
            //date1 = new Date(theDate);
        } else {
            theDate = document.getElementById("skpValidTo_encrypt").value;
            //date1 = new Date(theDate);
        }        
        
        var currentDt = new Date(document.getElementById("serverdt").value);
        var certDt = new Date(theDate);
        
        var DAY = 1000 * 60 * 60  * 24;
        
        remainDays = (Math.round((certDt.getTime() - currentDt.getTime()) / DAY));
        
        if((Math.round((certDt.getTime() - currentDt.getTime()) / DAY)) <= 30){
        	if((Math.round((certDt.getTime() - currentDt.getTime()) / DAY)) <= 0){
        		return false;	
        	}
        	else {
        		return true;
        	}
        }
        else {
        	return false;
        }
        
        
        
        
                
        /*var arrDateStr = theDate.split(" ");

        var year = arrDateStr[5];
        var month = getMonthNum(arrDateStr[1]);
        var day = arrDateStr[2];
        var tempTime = arrDateStr[3];
        var tempTimeArray = tempTime.split(":");
        var hour = tempTimeArray[0];
        var minute = tempTimeArray[1];
        var serverDateNew = document.getElementById("appDate").value;
        var hr = hour;
        var mm = minute;

        var serverDateTimeArray = serverDateNew.split(" ");
        var serverDateArray = serverDateTimeArray[0].split("/");
        var serveTime = serverDateTimeArray[1];

        var serverTime1 = serveTime.replace(":", "/");
        var serveTimeArray = serverTime1.split("/");
        var servermin = serveTimeArray[1];
        var servermin1 = servermin.replace(":", "/");
        var servermin1Array = servermin1.split("/");

        if (eval(serverDateArray[2]) == eval(year)) {
            if (eval(serverDateArray[0]) == eval(month)) {
                if (eval(eval(serverDateArray[1]) + 29) >= eval(day)) {
                    return true;
                } else
                    return false;
            } else {
                if (eval(serverDateArray[0]) == eval(eval(month) - 1)) {
                    if (eval(serverDateArray[1]) >= eval(day)) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }
        } else if (eval(serverDateArray[2]) == eval(eval(year) - 1)) {
            if (serverDateArray[0] == 12 && month == 1) {
                if (eval(eval(serverDateArray[1]) + 29) >= eval(day)) {
                    return true;
                } else if (eval(serverDateArray[1]) >= eval(day)) {
                    return true;
                } else {
                    return false;
                }
            } else{
                return false;
            }
        } else {
            return false;
        }*/
    }
}
function getCertiAlias(publicKey) {
    //sealock.openKeyStore("my", "");          
    var isSignCert = false;    
    var certAlias ="";
    var certCount = sealock.getCertificateCount();
    var ispkfound = false;
    for (var i = 1; i <= certCount; i++) {
        var certAlias = sealock.getCertificateAlias(i);
        sealock.selectCertificate(certAlias);
        isSignCert = sealock.getCertificateInformation(7).IsDigitalSignatureEnabled;                
        if(isSignCert && publicKey == sealock.getPublicKey()){
            ispkfound = true;
            return certAlias;
        }                       
    }
    if(!ispkfound){
       certAlias=""; 
    }
    return certAlias;
}
function getCertiAliasByKeyUsage(publicKey,keyUsage) {
    //sealock.openKeyStore("my", "");          
    var isValidCert = false;    
    var certAlias ="";
    var certCount = sealock.getCertificateCount();
    var ispkfound = false;
    for (var i = 1; i <= certCount; i++) {
        var certAlias = sealock.getCertificateAlias(i);
        sealock.selectCertificate(certAlias);
        if(keyUsage == 1){
            isValidCert = sealock.getCertificateInformation(7).IsDigitalSignatureEnabled;
        }
        if(keyUsage == 2){
            isValidCert = sealock.getCertificateInformation(7).IsKeyEnciphermentEnabled;
        }
        if(isValidCert && publicKey == sealock.getPublicKey()){
            ispkfound = true;
            return certAlias;
        }                       
    }
    if(!ispkfound){
       certAlias=""; 
    }
    return certAlias;
}
