/*
    signagent.js
    
    version 1.0
    
    Copyright (c) 2006, E-Procurement Technologies Pvt Ltd, India.
    Contact <sales@abcprocure.com>
*/

var CAPICOM_AUTHENTICATED_ATTRIBUTE_SIGNING_TIME = 0;
var CAPICOM_AUTHENTICATED_ATTRIBUTE_DOCUMENT_NAME = 1;
var CAPICOM_AUTHENTICATED_ATTRIBUTE_DOCUMENT_DESCRIPTION = 2;
var CAPICOM_CERT_INFO_SUBJECT_SIMPLE_NAME = 0;
var CAPICOM_CERT_INFO_ISSUER_SIMPLE_NAME = 1;
var CAPICOM_CERT_INFO_SUBJECT_EMAIL_NAME = 2;
var CAPICOM_CERT_INFO_ISSUER_EMAIL_NAME = 3;
var CAPICOM_CERT_INFO_SUBJECT_UPN = 4;
var CAPICOM_CERT_INFO_ISSUER_UPN = 5;
var CAPICOM_CERT_INFO_SUBJECT_DNS_NAME = 6;
var CAPICOM_CERT_INFO_ISSUER_DNS_NAME = 7;
var CAPICOM_CERTIFICATE_FIND_SHA1_HASH = 0;
var CAPICOM_CERTIFICATE_FIND_SUBJECT_NAME = 1;
var CAPICOM_CERTIFICATE_FIND_ISSUER_NAME = 2;
var CAPICOM_CERTIFICATE_FIND_ROOT_NAME = 3;
var CAPICOM_CERTIFICATE_FIND_TEMPLATE_NAME = 4;
var CAPICOM_CERTIFICATE_FIND_EXTENSION = 5;
var CAPICOM_CERTIFICATE_FIND_EXTENDED_PROPERTY = 6;
var CAPICOM_CERTIFICATE_FIND_APPLICATION_POLICY = 7;
var CAPICOM_CERTIFICATE_FIND_CERTIFICATE_POLICY = 8;
var CAPICOM_CERTIFICATE_FIND_TIME_VALID = 9;
var CAPICOM_CERTIFICATE_FIND_TIME_NOT_YET_VALID = 10;
var CAPICOM_CERTIFICATE_FIND_TIME_EXPIRED = 11;
var CAPICOM_CERTIFICATE_FIND_KEY_USAGE = 12;
var CAPICOM_CERTIFICATE_INCLUDE_CHAIN_EXCEPT_ROOT = 0;
var CAPICOM_CERTIFICATE_INCLUDE_WHOLE_CHAIN = 1;
var CAPICOM_CERTIFICATE_INCLUDE_END_ENTITY_ONLY = 2;
var CAPICOM_CERTIFICATE_SAVE_AS_PFX = 0;
var CAPICOM_CERTIFICATE_SAVE_AS_CER = 1;

//} CAPICOM_CERTIFICATES_SAVE_AS_TYPE;
var CAPICOM_CERTIFICATES_SAVE_AS_SERIALIZED = 0;
CAPICOM_CERTIFICATES_SAVE_AS_PKCS7 = 1;
CAPICOM_CERTIFICATES_SAVE_AS_PFX = 2;

//CAPICOM_CHAIN_STATUS;
var CAPICOM_CHAIN_STATUS_OK = 0x00000000;
var CAPICOM_CHAIN_STATUS_REVOKED = 0x80092010;
var CAPICOM_CHAIN_STATUS_REVOCATION_NO_CHECK = 0x80092012;
var CAPICOM_CHAIN_STATUS_REVOCATION_OFFLINE = 0x80092013;
var CAPICOM_CHAIN_STATUS_INVALID_BASIC_CONSTRAINTS = 0x80096019;
var CAPICOM_CHAIN_STATUS_INVALID_SIGNATURE = 0x80096004;
var CAPICOM_CHAIN_STATUS_EXPIRED = 0x800B0101;
var CAPICOM_CHAIN_STATUS_NESTED_VALIDITY_PERIOD = 0x800B0102;
var CAPICOM_CHAIN_STATUS_UNTRUSTEDROOT = 0x800B0109;
var CAPICOM_CHAIN_STATUS_PARTIAL_CHAINING = 0x800B010A;
var CAPICOM_CHAIN_STATUS_INVALID_USAGE = 0x800B0110;
var CAPICOM_CHAIN_STATUS_INVALID_POLICY = 0x800B0113;
var CAPICOM_CHAIN_STATUS_INVALID_NAME = 0x800B0114;

//} CAPICOM_CHECK_FLAG;
var CAPICOM_CHECK_NONE = 0x00000000;
var CAPICOM_CHECK_TRUSTED_ROOT = 0x00000001;
var CAPICOM_CHECK_TIME_VALIDITY = 0x00000002;
var CAPICOM_CHECK_SIGNATURE_VALIDITY = 0x00000004;
var CAPICOM_CHECK_ONLINE_REVOCATION_STATUS = 0x00000008;
var CAPICOM_CHECK_OFFLINE_REVOCATION_STATUS = 0x00000010;
var CAPICOM_CHECK_COMPLETE_CHAIN = 0x00000020;
var CAPICOM_CHECK_NAME_CONSTRAINTS = 0x00000040;
var CAPICOM_CHECK_BASIC_CONSTRAINTS = 0x00000080;
var CAPICOM_CHECK_NESTED_VALIDITY_PERIOD = 0x00000100;
var CAPICOM_CHECK_ONLINE_ALL = 0x000001EF;
var CAPICOM_CHECK_OFFLINE_ALL = 0x000001F7;

//} CAPICOM_EKU;
var CAPICOM_EKU_OTHER = 0;
var CAPICOM_EKU_SERVER_AUTH = 1;
var CAPICOM_EKU_CLIENT_AUTH = 2;
var CAPICOM_EKU_CODE_SIGNING = 3;
var CAPICOM_EKU_EMAIL_PROTECTION = 4;
var CAPICOM_EKU_SMARTCARD_LOGON = 5;
var CAPICOM_EKU_ENCRYPTING_FILE_SYSTEM = 6;

//} CAPICOM_ENCODING_TYPE;
var CAPICOM_ENCODE_ANY = 0xffffffff;
var CAPICOM_ENCODE_BASE64 = 0;
var CAPICOM_ENCODE_BINARY = 1;

//} CAPICOM_ENCRYPTION_ALGORITHM;
var CAPICOM_ENCRYPTION_ALGORITHM_RC2 = 0;
var CAPICOM_ENCRYPTION_ALGORITHM_RC4 = 1;
var CAPICOM_ENCRYPTION_ALGORITHM_DES = 2;
var CAPICOM_ENCRYPTION_ALGORITHM_3DES = 3;
var CAPICOM_ENCRYPTION_ALGORITHM_AES = 4; // v2.0

//} CAPICOM_ENCRYPTION_KEY_LENGTH;
var CAPICOM_ENCRYPTION_KEY_LENGTH_MAXIMUM = 0;
var CAPICOM_ENCRYPTION_KEY_LENGTH_40_BITS = 1;
var CAPICOM_ENCRYPTION_KEY_LENGTH_56_BITS = 2;
var CAPICOM_ENCRYPTION_KEY_LENGTH_128_BITS = 3;
var CAPICOM_ENCRYPTION_KEY_LENGTH_192_BITS = 4; // v2.0;
var CAPICOM_ENCRYPTION_KEY_LENGTH_256_BITS = 5; // v2.0

//} CAPICOM_ERROR_CODE;
var CAPICOM_E_ENCODE_INVALID_TYPE = 0x80880100;
var CAPICOM_E_EKU_INVALID_OID = 0x80880200;
var CAPICOM_E_EKU_OID_NOT_INITIALIZED = 0x80880201;
var CAPICOM_E_CERTIFICATE_NOT_INITIALIZED = 0x80880210;
var CAPICOM_E_CERTIFICATE_NO_PRIVATE_KEY = 0x80880211;
var CAPICOM_E_CHAIN_NOT_BUILT = 0x80880220;
var CAPICOM_E_STORE_NOT_OPENED = 0x80880230;
var CAPICOM_E_STORE_EMPTY = 0x80880231;
var CAPICOM_E_STORE_INVALID_OPEN_MODE = 0x80880232;
var CAPICOM_E_STORE_INVALID_SAVE_AS_TYPE = 0x80880233;
var CAPICOM_E_ATTRIBUTE_NAME_NOT_INITIALIZED = 0x80880240;
var CAPICOM_E_ATTRIBUTE_VALUE_NOT_INITIALIZED = 0x80880241;
var CAPICOM_E_ATTRIBUTE_INVALID_NAME = 0x80880242;
var CAPICOM_E_ATTRIBUTE_INVALID_VALUE = 0x80880243;
var CAPICOM_E_SIGNER_NOT_INITIALIZED = 0x80880250;
var CAPICOM_E_SIGNER_NOT_FOUND = 0x80880251;
var CAPICOM_E_SIGNER_NO_CHAIN = 0x80880252; // v2.0;
var CAPICOM_E_SIGNER_INVALID_USAGE = 0x80880253; //v2.0;
var CAPICOM_E_SIGN_NOT_INITIALIZED = 0x80880260;
var CAPICOM_E_SIGN_INVALID_TYPE = 0x80880261;
var CAPICOM_E_SIGN_NOT_SIGNED = 0x80880262;
var CAPICOM_E_INVALID_ALGORITHM = 0x80880270;
var CAPICOM_E_INVALID_KEY_LENGTH = 0x80880271;
var CAPICOM_E_ENVELOP_NOT_INITIALIZED = 0x80880280;
var CAPICOM_E_ENVELOP_INVALID_TYPE = 0x80880281;
var CAPICOM_E_ENVELOP_NO_RECIPIENT = 0x80880282;
var CAPICOM_E_ENVELOP_RECIPIENT_NOT_FOUND = 0x80880283;
var CAPICOM_E_ENCRYPT_NOT_INITIALIZED = 0x80880290;
var CAPICOM_E_ENCRYPT_INVALID_TYPE = 0x80880291;
var CAPICOM_E_ENCRYPT_NO_SECRET = 0x80880292;
var CAPICOM_E_PRIVATE_KEY_NOT_INITIALIZED = 0x80880300; // v2.0;
var CAPICOM_E_PRIVATE_KEY_NOT_EXPORTABLE = 0x80880301; // v2.0;
var CAPICOM_E_ENCODE_NOT_INITIALIZED = 0x80880320; // v2.0;
var CAPICOM_E_EXTENSION_NOT_INITIALIZED = 0x80880330; // v2.0;
var CAPICOM_E_PROPERTY_NOT_INITIALIZED = 0x80880340; // v2.0;
var CAPICOM_E_FIND_INVALID_TYPE = 0x80880350; // v2.0;
var CAPICOM_E_FIND_INVALID_PREDEFINED_POLICY = 0x80880351; // v2.0;
var CAPICOM_E_CODE_NOT_INITIALIZED = 0x80880360; // v2.0;
var CAPICOM_E_CODE_NOT_SIGNED = 0x80880361; // v2.0;
var CAPICOM_E_CODE_DESCRIPTION_NOT_INITIALIZED = 0x80880362; // v2.0;
var CAPICOM_E_CODE_DESCRIPTION_URL_NOT_INITIALIZED = 0x80880363; // v2.0;
var CAPICOM_E_CODE_INVALID_TIMESTAMP_URL = 0x80880364; // v2.0;
var CAPICOM_E_HASH_NO_DATA = 0x80880370; // v2.0;
var CAPICOM_E_INVALID_CONVERT_TYPE = 0x80880380; // v2.0;
var CAPICOM_E_NOT_SUPPORTED = 0x80880900;
var CAPICOM_E_UI_DISABLED = 0x80880901;
var CAPICOM_E_CANCELLED = 0x80880902;
var CAPICOM_E_NOT_ALLOWED = 0x80880903; // v2.0;
var CAPICOM_E_OUT_OF_RESOURCE = 0x80880904; // v2.0;
var CAPICOM_E_INTERNAL = 0x80880911;
var CAPICOM_E_UNKNOWN = 0x80880999;

//} CAPICOM_EXPORT_FLAG;
var CAPICOM_EXPORT_DEFAULT = 0;
var CAPICOM_EXPORT_IGNORE_PRIVATE_KEY_NOT_EXPORTABLE_ERROR = 1;

//} CAPICOM_HASH_ALGORITHM;
var CAPICOM_HASH_ALGORITHM_SHA1 = 0;
var CAPICOM_HASH_ALGORITHM_MD2 = 1;
var CAPICOM_HASH_ALGORITHM_MD4 = 2;
var CAPICOM_HASH_ALGORITHM_MD5 = 3;
var CAPICOM_HASH_ALGORITHM_SHA256 = 4;
var CAPICOM_HASH_ALGORITHM_SHA384 = 5;
var CAPICOM_HASH_ALGORITHM_SHA512 = 6;

//} CAPICOM_KEY_ALGORITHM;
var CAPICOM_KEY_ALGORITHM_OTHER = 0;
var CAPICOM_KEY_ALGORITHM_RSA = 1;
var CAPICOM_KEY_ALGORITHM_DSS = 2;

//} CAPICOM_KEY_LOCATION;
var CAPICOM_CURRENT_USER_KEY = 0;
var CAPICOM_LOCAL_MACHINE_KEY = 1;

//} CAPICOM_KEY_SPEC;
var CAPICOM_KEY_SPEC_KEYEXCHANGE = 1;
var CAPICOM_KEY_SPEC_SIGNATURE = 2;

//} CAPICOM_KEY_STORAGE_FLAG
var CAPICOM_KEY_STORAGE_DEFAULT = 0;
var CAPICOM_KEY_STORAGE_EXPORTABLE = 1;
var CAPICOM_KEY_STORAGE_USER_PROTECTED = 2;

//} CAPICOM_KEY_USAGE
var CAPICOM_DIGITAL_SIGNATURE_KEY_USAGE = 0x00000080;
var CAPICOM_NON_REPUDIATION_KEY_USAGE = 0x00000040;
var CAPICOM_KEY_ENCIPHERMENT_KEY_USAGE = 0x00000020;
var CAPICOM_DATA_ENCIPHERMENT_KEY_USAGE = 0x00000010;
var CAPICOM_KEY_AGREEMENT_KEY_USAGE = 0x00000008;
var CAPICOM_KEY_CERT_SIGN_KEY_USAGE = 0x00000004;
var CAPICOM_OFFLINE_CRL_SIGN_KEY_USAGE = 0x00000002;
var CAPICOM_CRL_SIGN_KEY_USAGE = 0x00000002;
var CAPICOM_ENCIPHER_ONLY_KEY_USAGE = 0x00000001;
var CAPICOM_DECIPHER_ONLY_KEY_USAGE = 0x00008000;

//} CAPICOM_OID
var CAPICOM_OID_OTHER = 0;
var CAPICOM_OID_AUTHORITY_KEY_IDENTIFIER_EXTENSION = 1;
var CAPICOM_OID_KEY_ATTRIBUTES_EXTENSION = 2;
var CAPICOM_OID_CERT_POLICIES_95_EXTENSION = 3;
var CAPICOM_OID_KEY_USAGE_RESTRICTION_EXTENSION = 4;
var CAPICOM_OID_LEGACY_POLICY_MAPPINGS_EXTENSION = 5;
var CAPICOM_OID_SUBJECT_ALT_NAME_EXTENSION = 6;
var CAPICOM_OID_ISSUER_ALT_NAME_EXTENSION = 7;
var CAPICOM_OID_BASIC_CONSTRAINTS_EXTENSION = 8;
var CAPICOM_OID_SUBJECT_KEY_IDENTIFIER_EXTENSION = 9;
var CAPICOM_OID_KEY_USAGE_EXTENSION = 10;
var CAPICOM_OID_PRIVATEKEY_USAGE_PERIOD_EXTENSION = 11;
var CAPICOM_OID_SUBJECT_ALT_NAME2_EXTENSION = 12;
var CAPICOM_OID_ISSUER_ALT_NAME2_EXTENSION = 13;
var CAPICOM_OID_BASIC_CONSTRAINTS2_EXTENSION = 14;
var CAPICOM_OID_NAME_CONSTRAINTS_EXTENSION = 15;
var CAPICOM_OID_CRL_DIST_POINTS_EXTENSION = 16;
var CAPICOM_OID_CERT_POLICIES_EXTENSION = 17;
var CAPICOM_OID_POLICY_MAPPINGS_EXTENSION = 18;
var CAPICOM_OID_AUTHORITY_KEY_IDENTIFIER2_EXTENSION = 19;
var CAPICOM_OID_POLICY_CONSTRAINTS_EXTENSION = 20;
var CAPICOM_OID_ENHANCED_KEY_USAGE_EXTENSION = 21;
var CAPICOM_OID_CERTIFICATE_TEMPLATE_EXTENSION = 22;
var CAPICOM_OID_APPLICATION_CERT_POLICIES_EXTENSION = 23;
var CAPICOM_OID_APPLICATION_POLICY_MAPPINGS_EXTENSION = 24;
var CAPICOM_OID_APPLICATION_POLICY_CONSTRAINTS_EXTENSION = 25;
var CAPICOM_OID_AUTHORITY_INFO_ACCESS_EXTENSION = 26;
var CAPICOM_OID_SERVER_AUTH_EKU = 100;
var CAPICOM_OID_CLIENT_AUTH_EKU = 101;
var CAPICOM_OID_CODE_SIGNING_EKU = 102;
var CAPICOM_OID_EMAIL_PROTECTION_EKU = 103;
var CAPICOM_OID_IPSEC_END_SYSTEM_EKU = 104;
var CAPICOM_OID_IPSEC_TUNNEL_EKU = 105;
var CAPICOM_OID_IPSEC_USER_EKU = 106;
var CAPICOM_OID_TIME_STAMPING_EKU = 107;
var CAPICOM_OID_CTL_USAGE_SIGNING_EKU = 108;
var CAPICOM_OID_TIME_STAMP_SIGNING_EKU = 109;
var CAPICOM_OID_SERVER_GATED_CRYPTO_EKU = 110;
var CAPICOM_OID_ENCRYPTING_FILE_SYSTEM_EKU = 111;
var CAPICOM_OID_EFS_RECOVERY_EKU = 112;
var CAPICOM_OID_WHQL_CRYPTO_EKU = 113;
var CAPICOM_OID_NT5_CRYPTO_EKU = 114;
var CAPICOM_OID_OEM_WHQL_CRYPTO_EKU = 115;
var CAPICOM_OID_EMBEDED_NT_CRYPTO_EKU = 116;
var CAPICOM_OID_ROOT_LIST_SIGNER_EKU = 117;
var CAPICOM_OID_QUALIFIED_SUBORDINATION_EKU = 118;
var CAPICOM_OID_KEY_RECOVERY_EKU = 119;
var CAPICOM_OID_DIGITAL_RIGHTS_EKU = 120;
var CAPICOM_OID_LICENSES_EKU = 121;
var CAPICOM_OID_LICENSE_SERVER_EKU = 122;
var CAPICOM_OID_SMART_CARD_LOGON_EKU = 123;
var CAPICOM_OID_PKIX_POLICY_QUALIFIER_CPS = 124;
var CAPICOM_OID_PKIX_POLICY_QUALIFIER_USERNOTICE = 125;

//} CAPICOM_PROPID
var CAPICOM_PROPID_UNKNOWN = 0;
var CAPICOM_PROPID_KEY_PROV_HANDLE = 1;
var CAPICOM_PROPID_KEY_PROV_INFO = 2;
var CAPICOM_PROPID_SHA1_HASH = 3;
var CAPICOM_PROPID_HASH_PROP = 3;
var CAPICOM_PROPID_MD5_HASH = 4;
var CAPICOM_PROPID_KEY_CONTEXT = 5;
var CAPICOM_PROPID_KEY_SPEC = 6;
var CAPICOM_PROPID_IE30_RESERVED = 7;
var CAPICOM_PROPID_PUBKEY_HASH_RESERVED = 8;
var CAPICOM_PROPID_ENHKEY_USAGE = 9;
var CAPICOM_PROPID_CTL_USAGE = 9;
var CAPICOM_PROPID_NEXT_UPDATE_LOCATION = 10;
var CAPICOM_PROPID_FRIENDLY_NAME = 11;
var CAPICOM_PROPID_PVK_FILE = 12;
var CAPICOM_PROPID_DESCRIPTION = 13;
var CAPICOM_PROPID_ACCESS_STATE = 14;
var CAPICOM_PROPID_SIGNATURE_HASH = 15;
var CAPICOM_PROPID_SMART_CARD_DATA = 16;
var CAPICOM_PROPID_EFS = 17;
var CAPICOM_PROPID_FORTEZZA_DATA = 18;
var CAPICOM_PROPID_ARCHIVED = 19;
var CAPICOM_PROPID_KEY_IDENTIFIER = 20;
var CAPICOM_PROPID_AUTO_ENROLL = 21;
var CAPICOM_PROPID_PUBKEY_ALG_PARA = 22;
var CAPICOM_PROPID_CROSS_CERT_DIST_POINTS = 23;
var CAPICOM_PROPID_ISSUER_PUBLIC_KEY_MD5_HASH = 24;
var CAPICOM_PROPID_SUBJECT_PUBLIC_KEY_MD5_HASH = 25;
var CAPICOM_PROPID_ENROLLMENT = 26;
var CAPICOM_PROPID_DATE_STAMP = 27;
var CAPICOM_PROPID_ISSUER_SERIAL_NUMBER_MD5_HASH = 28;
var CAPICOM_PROPID_SUBJECT_NAME_MD5_HASH = 29;
var CAPICOM_PROPID_EXTENDED_ERROR_INFO = 30;
var CAPICOM_PROPID_RENEWAL = 64;
var CAPICOM_PROPID_ARCHIVED_KEY_HASH = 65;
var CAPICOM_PROPID_FIRST_RESERVED = 66;
var CAPICOM_PROPID_LAST_RESERVED = 0x00007FFF;
var CAPICOM_PROPID_FIRST_USER = 0x00008000;
var CAPICOM_PROPID_LAST_USER = 0x0000FFFF;

//} CAPICOM_PROV_TYPE
var CAPICOM_PROV_RSA_FULL = 1;
var CAPICOM_PROV_RSA_SIG = 2;
var CAPICOM_PROV_DSS = 3;
var CAPICOM_PROV_FORTEZZA = 4;
var CAPICOM_PROV_MS_EXCHANGE = 5;
var CAPICOM_PROV_SSL = 6;
var CAPICOM_PROV_RSA_SCHANNEL = 12;
var CAPICOM_PROV_DSS_DH = 13;
var CAPICOM_PROV_EC_ECDSA_SIG = 14;
var CAPICOM_PROV_EC_ECNRA_SIG = 15;
var CAPICOM_PROV_EC_ECDSA_FULL = 16;
var CAPICOM_PROV_EC_ECNRA_FULL = 17;
var CAPICOM_PROV_DH_SCHANNEL = 18;
var CAPICOM_PROV_SPYRUS_LYNKS = 20;
var CAPICOM_PROV_RNG = 21;
var CAPICOM_PROV_INTEL_SEC = 22;
var CAPICOM_PROV_REPLACE_OWF = 23;
var CAPICOM_PROV_RSA_AES = 24;

//} CAPICOM_SECRET_TYPE
var CAPICOM_SECRET_PASSWORD = 0;

//} CAPICOM_SIGNED_DATA_VERIFY_FLAG
var CAPICOM_VERIFY_SIGNATURE_ONLY = 0;
var CAPICOM_VERIFY_SIGNATURE_AND_CERTIFICATE = 1;

//} CAPICOM_STORE_LOCATION
var CAPICOM_MEMORY_STORE = 0;
var CAPICOM_LOCAL_MACHINE_STORE = 1;
var CAPICOM_CURRENT_USER_STORE = 2;
var CAPICOM_ACTIVE_DIRECTORY_USER_STORE = 3;
var CAPICOM_SMART_CARD_USER_STORE = 4;

//} CAPICOM_STORE_OPEN_MODE
var CAPICOM_STORE_OPEN_READ_ONLY = 0;
var CAPICOM_STORE_OPEN_READ_WRITE = 1;
var CAPICOM_STORE_OPEN_MAXIMUM_ALLOWED = 2;
var CAPICOM_STORE_OPEN_EXISTING_ONLY = 128;
var CAPICOM_STORE_OPEN_INCLUDE_ARCHIVED = 256;

//} CAPICOM_STORE_SAVE_AS_TYPE
var CAPICOM_STORE_SAVE_AS_SERIALIZED = 0;
var CAPICOM_STORE_SAVE_AS_PKCS7 = 1;

var CAPICOM_MY_STORE = "My";

var CAPICOM_TRUST_IS_NOT_TIME_VALID = 1;
var CAPICOM_TRUST_IS_NOT_TIME_NESTED = 2;
var CAPICOM_TRUST_IS_REVOKED = 4;
var CAPICOM_TRUST_IS_NOT_SIGNATURE_VALID = 8;
var CAPICOM_TRUST_IS_NOT_VALID_FOR_USAGE = 16;
var CAPICOM_TRUST_IS_UNTRUSTED_ROOT = 32;
var CAPICOM_TRUST_REVOCATION_STATUS_UNKNOWN = 64;
var CAPICOM_TRUST_IS_CYCLIC = 128;
var CAPICOM_TRUST_IS_PARTIAL_CHAIN = 65536;
var CAPICOM_TRUST_CTL_IS_NOT_TIME_VALID = 131072;
var CAPICOM_TRUST_CTL_IS_NOT_SIGNATURE_VALID = 262144;
var CAPICOM_TRUST_CTL_IS_NOT_VALID_FOR_USAGE = 524288;

var flagDataSet = 0x01;
var flagStoreOpen = 0x02;
var flagPrivateKeySelected = 0x04;
var flagPublicKeySelected = 0x08;
var flagSignatureSelected = 0x0f;
var flagEncryptedFlagSet = 0x10;
var flagCertificateSelected = 0x20;

var errorStoreNotOpened=1;
var errorCertificateNotSelected=2;

/* pending state checking, exception handling, parameter validation */
function getCertificateAlias ( certificate )
{
	var rv = null;

	this.setError( 0 );

	// store should be opened

	if ( this.state & flagStoreOpen )
	{
		var store = this.store;
		var certs = store.certificates;
		if (certificate <= certs.Count)
		    rv = certs.Item( certificate ).Thumbprint;
	}
	else
	{
		this.setError( errorStoreNotOpened );
	}

	return ( rv );
}

/* pending state checking, exception handling, parameter validation */
function getCertificateCount ()
{
	var rv = 0;

	this.setError( 0 );

	// store should be opened

	if ( this.state & flagStoreOpen )
	{
		var store = this.store;
		rv = store.certificates.count;
	}
	else
	{
		this.setError( errorStoreNotOpened );
	}

	return ( rv );
}

/* pending state checking, exception handling, parameter validation */
function getData ()
{
	return this.data1;
}
function getData1 ()
{
	return this.data11;
}


/* pending state checking, exception handling, parameter validation */
function setData ( data1 )
{
	this.data1 = data1;
}

/* pending state checking, exception handling, parameter validation */
function setHashType ( algorithm )
{
	// we want only sha-1 and md5

	if ( algorithm == 1 )  // our value for md5
	{
		algorithm = 3; // capicoms value for md5
	}
	else
	{
		algorithm = 0; // anything other than md5 is interpreted as sha-1
	}

	this.algorithm = algorithm;
}

/* pending state checking, exception handling, parameter validation */
function getHashFileSign()
{
	var oHashedData = new ActiveXObject( "CAPICOM.HashedData" );
	oHashedData.algorithm = this.algorithm;
	oHashedData.Hash( this.getData() );
	// added for file signing... after hash creation.
	return ( oHashedData.value );
}

function getHash ()
{
	var oHashedData = new ActiveXObject( "CAPICOM.HashedData" );
	oHashedData.algorithm = this.algorithm;
	oHashedData.Hash( this.getData());
	return ( oHashedData.value );
}

/* pending state checking, exception handling, parameter validation */
function setSignature ( sign )
{
	this.sign = sign;
}

/* pending state checking, exception handling, parameter validation */
function getSignature ()
{
    var signdata = new ActiveXObject("CAPICOM.SignedData");
    var signer = new ActiveXObject("CAPICOM.Signer");
    signer.Certificate = this.certificate;
    signer.Options =   CAPICOM_CERTIFICATE_INCLUDE_END_ENTITY_ONLY;
    signdata.Content = this.getData();
    this.sign = signdata.Sign(signer, false, CAPICOM_ENCODE_BASE64);
	return ( this.sign );
}

/* pending state checking, exception handling, parameter validation */
function isVerifySignature ()
{
    var rv=true;
    
    var signdata = new ActiveXObject("CAPICOM.SignedData");
    
    try {
        signdata.Verify(this.sign, false,CAPICOM_VERIFY_SIGNATURE_ONLY);
        this.data1 = signdata.Content;
    } catch(e) {
        rv=false;
    }
    
	return ( rv );
}

/* pending state checking, exception handling, parameter validation */
/* not implemented ! */
function setSignInfo ( info, data1 )
{
	return "";
}

/* pending state checking, exception handling, parameter validation */
/* not implemented ! */
function getSignInfo ( info )
{
	return "";
}

/* pending state checking, exception handling, parameter validation */
function openKeyStore ( storename, password1 )
{
	this.setError( 0 );

	if ( this.state & flagStoreOpen )
	{
		// store already opened?
		// clear the store opened flag
		//this.state &= 0xfd; //bug!
	}

	try
	{
		this.store = new ActiveXObject( "capicom.store" );
		this.store.Open( CAPICOM_CURRENT_USER_STORE, storename, CAPICOM_STORE_OPEN_READ_ONLY + CAPICOM_STORE_OPEN_EXISTING_ONLY );
		this.state |= flagStoreOpen;
	}
	catch ( e )
	{
		this.store = "";
		this.setError( errorStoreNotOpened );
	}

	return ( this.getError() == 0 );
}

/* pending state checking, exception handling, parameter validation */
function selectCertificate ( alias )
{
    this.setError(0);
    
    if(this.state & flagStoreOpen )
    {
        var store = this.store;
        var certificates = store.certificates;
        var certificate = certificates.Find(CAPICOM_CERTIFICATE_FIND_SHA1_HASH, alias, false);
        this.certificate = certificate.Item(1);
      
        this.state = this.state | flagCertificateSelected;
    }
    else
    {
        this.setError(errorStoreNotOpened);
    }
	return "";
}

/* pending state checking, exception handling, parameter validation */

function selectCertificatePolicy ( oids )
{
    this.setError(0);
    
    if(this.state & flagStoreOpen )
    {
    	
        var store = this.store;
        var certificates = store.certificates;
        var certificate = certificates.Find(CAPICOM_CERTIFICATE_FIND_CERTIFICATE_POLICY,oids, false); 
        
        
        this.state = this.state | flagCertificateSelected;
    }
    else
    {
        this.setError(errorStoreNotOpened);
    }
	return certificate;
}


function getSelectedCertificatePolicy (certificatePolicy,i)
{
    this.certificate = certificatePolicy.Item(i);
}


/* pending state checking, exception handling, parameter validation */
function getCertificateInformation ( info )
{
    var rv="";
    
    this.setError(0);
    
    if(this.state & flagStoreOpen)
    {
        if(this.state & flagCertificateSelected)
        {
            var certificate = this.certificate;
            
            switch(info)
            {
                case 0: // subject distinguished name
                    rv = certificate.SubjectName;
                    break;
                case 1: // issuer distinguished name
                    rv = certificate.IssuerName;
                    break;
                case 2: // subject serial number
                    rv=certificate.SerialNumber;
                    break;
                case 3: // subject unique id
                    rv=certificate.Thumbprint;
                    break;
                case 4: // issuer unique id
                    rv="not implemented";
                    break;
                case 5: // not before
                    rv = certificate.validfromdate;
                    break;
                case 6: // not after
                    rv= certificate.validtodate;
                    break;
                case 7: // not after
                    rv= certificate.KeyUsage();
                    break;
                default:
                    rv = "invalid index: "+info;
                    break;
            }
        }
        else
        {
            this.setError(errorCertificateNotSelected);
        }
    }
    else
    {
        this.setError(errorStoreNotOpened);
    }
	return rv;
}

/* pending state checking, exception handling, parameter validation */
function setPublicKey ( publicKey )
{
    this.publicKey = publicKey;
	return true;
}
function setPublicKey1 ( publicKey1 )
{
    this.publicKey1 = publicKey1;
	return true;
}

/* pending state checking, exception handling, parameter validation */
function getPublicKey ()
{
    var rv="";
    this.setError(0);
    
    if(this.state & flagStoreOpen)
    {
        if(this.state & flagCertificateSelected)
        {
            var certificate = this.certificate;
            //rv=certificate.publickey().encodedkey;
            rv=certificate.Export(CAPICOM_ENCODE_BASE64);
            //alert(rv);
            rva=rv.split("\r\n");
            rv="";
            for(var xx=0;xx<rva.length;xx++)
            {
                rv=rv+rva[xx];
            }
            //alert(rv);
        }
        else
        {
            this.setError(errorCertificateNotSelected);
        }
    }
    else
    {
        this.setError(errorStoreNotOpened);
    }
	return rv;
}

/* pending state checking, exception handling, parameter validation */
function setEncrypt ( encrypt )
{
    this.encrypt = encrypt;
	return true;
}

/* pending state checking, exception handling, parameter validation */
function getEncrypt ()
{
    var envelopeddata = new ActiveXObject("CAPICOM.EnvelopedData");

    var certificate = new ActiveXObject("CAPICOM.Certificate"); 

    certificate.Import(this.publicKey);

    envelopeddata.Algorithm.Name = CAPICOM_ENCRYPTION_ALGORITHM_3DES;
    envelopeddata.Algorithm.KeyLength = CAPICOM_ENCRYPTION_KEY_LENGTH_MAXIMUM;
    envelopeddata.Recipients.Add(certificate);    
    envelopeddata.Content=this.data1; 
    this.encrypt = envelopeddata.Encrypt(CAPICOM_ENCODE_BASE64);

	return this.encrypt;
}

function getMultiEncrypt()
{
    var envelopeddata = new ActiveXObject("CAPICOM.EnvelopedData");

    var certificate = new ActiveXObject("CAPICOM.Certificate"); 
    var certificate1 = new ActiveXObject("CAPICOM.Certificate");
    certificate.Import(this.publicKey);
    certificate1.Import(this.publicKey1);
    envelopeddata.Algorithm.Name = CAPICOM_ENCRYPTION_ALGORITHM_3DES;
    envelopeddata.Algorithm.KeyLength = CAPICOM_ENCRYPTION_KEY_LENGTH_MAXIMUM;
    envelopeddata.Recipients.Add(certificate);    
    envelopeddata.Recipients.Add(certificate1);
    envelopeddata.Content=this.data1; 
    this.encrypt = envelopeddata.Encrypt(CAPICOM_ENCODE_BASE64);

	return this.encrypt;
}


/* pending state checking, exception handling, parameter validation */
function getDecrypt ()
{
    var rv="";
    var envelopeddata = new ActiveXObject("CAPICOM.EnvelopedData");
    envelopeddata.Decrypt(this.encrypt);
    rv=envelopeddata.Content;
	return rv;
}

/* pending state checking, exception handling, parameter validation */
function getError ()
{
	return ( this.errorCode );
}

/* pending state checking, exception handling, parameter validation */
function setError ( errorCode )
{
	this.errorCode = errorCode;
}

/* pending state checking, exception handling, parameter validation */
function getErrorMessage ()
{
	return this.errorCode;
}

/* pending state checking, exception handling, parameter validation */
function getVersion ()
{
	return ( "1.0" );
}

function setSignature1 ( sign )
{

	this.sign = sign;
}



function signer()
{
	this.data1 = "";
	this.data11 = "";

	this.sign = "";
	this.algorithm = 0;
	this.errorCode = 0;
	this.store = null;
	this.publicKey = null;
	this.publicKey1 = null;
	this.certificate = null;
	this.encrypt = ""
    
	this.state = 0;

	this.getCertificateAlias = getCertificateAlias;
	this.getCertificateCount = getCertificateCount;
	this.getCertificateInformation = getCertificateInformation;
	this.getData = getData;

	this.getDecrypt = getDecrypt;
	this.getEncrypt = getEncrypt;
	// Sanjay Prajapati
	this.getMultiEncrypt = getMultiEncrypt;
	this.getError = getError;
	this.getErrorMessage = getErrorMessage;
	this.getHash = getHash;
	this.getHashFileSign = getHashFileSign;
	this.getPublicKey = getPublicKey;
	
	this.getSignature = getSignature;
	this.isVerifySignature = isVerifySignature;

	this.openKeyStore = openKeyStore;
	this.selectCertificate = selectCertificate;
	this.selectCertificatePolicy = selectCertificatePolicy;
	this.getSelectedCertificatePolicy = getSelectedCertificatePolicy; 
	this.setData = setData;
	this.setEncrypt = setEncrypt;
	this.setError = setError;
	this.setHashType = setHashType;
	this.setPublicKey = setPublicKey;
	this.setPublicKey1 = setPublicKey1;
	this.setSignature = setSignature;

	this.getVersion = getVersion;

	this.getData1 = getData1;
	this.isVerifySignature1 = isVerifySignature1;
	this.setSignature1 = setSignature1;

}
function isVerifySignature1 ()
{
    var rv=true;
    
    var signdata = new ActiveXObject("CAPICOM.SignedData");
    
    try {

       signdata.Verify(this.sign, false, CAPICOM_VERIFY_SIGNATURE_ONLY);
		theSigners = signdata.Signers;
            signer = theSigners.Item(1);
		oAttributes = signer.AuthenticatedAttributes;
		oCertificate = signer.Certificate;
		alert("Subject Name= " + oCertificate.GetInfo(CAPICOM_CERT_INFO_SUBJECT_SIMPLE_NAME)
			+ "\n" + "Issuer Name= " + oCertificate.GetInfo(CAPICOM_CERT_INFO_ISSUER_SIMPLE_NAME) 
			+ "\n" + "ThumbPrint= " + oCertificate.Thumbprint
			+ "\n" + "SerialNumber= " + oCertificate.SerialNumber
			//+ "\n" + "IssuerName CN= " + GetNamePart(oCertificate.IssuerName, "CN=")
			//+ "\n" + GetNamePart(oCertificate.IssuerName, "OU=")
			//+ "\n" + GetNamePart(oCertificate.IssuerName, "O=")
			//+ "\n" + GetNamePart(oCertificate.IssuerName, "C=")
			//+ "\n" + GetNamePart(oCertificate.IssuerName, "L=")
			//+ "\n" + GetNamePart(oCertificate.IssuerName, "S=")
			//+ "\n" + GetNamePart(oCertificate.SubjectName, "CN=")
			//+ "\n" + GetNamePart(oCertificate.SubjectName, "OU=")
			//+ "\n" + GetNamePart(oCertificate.SubjectName, "O=")
			//+ "\n" + GetNamePart(oCertificate.SubjectName, "C=")
			//+ "\n" + GetNamePart(oCertificate.SubjectName, "L=")
			//+ "\n" + GetNamePart(oCertificate.SubjectName, "S=")
			+ "\n" + "ValidFromDate= " + oCertificate.ValidFromDate
			+ "\n" + "ValidToDate= " + oCertificate.ValidToDate
			+ "\n" + "Issuer Email= " + oCertificate.GetInfo(CAPICOM_CERT_INFO_ISSUER_EMAIL_NAME)
			+ "\n" + "Subject Email= " + oCertificate.GetInfo(CAPICOM_CERT_INFO_SUBJECT_EMAIL_NAME)
		);

        this.data11 = signdata.Content;

    } catch(e) {
        rv=false;
    }
    
	return ( rv );
}

