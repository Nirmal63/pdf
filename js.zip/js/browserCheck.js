function IeBrowserSupportChecks(){
	if(isActiveXEnabled()){
		checkCAPICOM();
	}
}

function isActiveXEnabled(){
    try {
    	var fileSystemObject  = new ActiveXObject("Scripting.FileSystemObject");
    	if(!isTrustedSite()){
    		alert("System is about to add site in 'Trusted site'. To add, click 'Run/Run as Administrator' or if already added click 'Cancel' in next Popup.");
    		window.location = pageContext+"/downloadRegistry/2";
    	}
    	return true;
    } catch (e){     
    	window.location = pageContext+"/activexenable";
    	return false;
    }
}

function checkCAPICOM(){
	try{
		var objFSO = new ActiveXObject("CAPICOM.EnvelopedData");
		return true;
	} catch(e){
		alert("System is about to install 'Signer component'. To install, click 'Run/Run as Administrator' or if already installed click 'Cancel' in next Popup (Restart browser after installation).");
		window.location = pageContext+"/downloads/signerCA";
		return false;
	}
}

function isTrustedSite()
{
	 try{
		 var oWSS = new ActiveXObject("WScript.Shell");
		 var hostName = (window.location.hostname).split(".");
		 var hostNameSize = hostName.length; 
		 var httpProtocol = (location.protocol == "https:" ? "https" : "http");
		 if(hostNameSize == 1){
			 if(isRegisteredAsTrustedSite(hostName[0]+"\\"+ httpProtocol , oWSS)){
				 return true;
			 }
		 }else if(hostNameSize == 2){
			 if(isRegisteredAsTrustedSite(hostName[0]+"."+hostName[1]+"\\"+ httpProtocol , oWSS)){
				 return true;
			 }
		 }else {
			 var childDir = "" ;
			 for(var i=0; i < hostNameSize-2; i++) {
				 childDir = childDir + "" + hostName[i];
				 if(i != hostNameSize-3) {
					 childDir = childDir + ".";
				 }
			 }
			 if(isRegisteredAsTrustedSite(hostName[hostNameSize-2]+"."+hostName[hostNameSize-1]+"\\"+childDir+"\\"+ httpProtocol , oWSS) || isRegisteredAsTrustedSite(hostName[hostNameSize-2]+"."+hostName[hostNameSize-1]+"\\"+ httpProtocol , oWSS)){
				 return true;
			 }
		 }
		 return false;
	 } catch(e){
		 return false;
	 }
}

function isRegisteredAsTrustedSite(sRegEntry, oWSS){
	try{
		var regpath = "HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\ZoneMap\\Domains\\" + sRegEntry;
		return oWSS.RegRead(regpath) == 2 ? true : false; 
	} catch(e) {
		 return false;
	}
}

function isValidEncAndBrowserSupport(signedata){
	try {
		sealock.selectCertificate(document.getElementById("certNames_encrypt").value);
	    sealock.setPublicKey(sealock.getPublicKey());
	    sealock.setPublicKey1(sealock.getPublicKey());
	    sealock.setData(signedata);
	    var encrypt1 = sealock.getMultiEncrypt();
	    sealock.setData(encrypt1);
	    var encrypt2 = sealock.getMultiEncrypt();
	    return true;
	} catch (e) {
		alert("System is unable to encrypt the data due to system configuration/browser support. Kindly contact our support executive.");
		return false;
    }
}