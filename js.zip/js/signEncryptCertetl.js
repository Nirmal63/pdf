function openSignEncKeyStore() {    
    //alert(sealock);
    sealock.openKeyStore("my", "");
    var signCombo = document.getElementById("certNames_sign");
    var enccombo = document.getElementById("certNames_encrypt");

    if(signCombo != null){
    	for (var i = signCombo.length; i >= 0; i--) {
            signCombo.options[i] = null;
        }
    	signCombo.options[0] = new Option("--Please Select--", 0);
    }
 
    if(enccombo != null){
	    for (var i = enccombo.length; i >= 0; i--) {
	        enccombo.options[i] = null;
	    }
	    enccombo.options[0] = new Option("--Please Select--", 0);
    }    
    var certType;
    
    var osType = sealock.getOsType();
    
    var certCount = sealock.getCertificateCount();

    for (var i = 1; i<=certCount; i++) {
    	try{
    		var isSignCert = false;
            var isEncCert = false;
        	var certAlias = sealock.getCertificateAlias(i);
            sealock.selectCertificate(certAlias);
            certSubject = sealock.getCertificateInformation(0);
            
            certType = sealock.getCertificateInformation(7);
            //alert(signCombo);
            //alert(certType);
            if(signCombo != null){
            	if(certType == 1 || certType == 3){
            		isSignCert = true;	
            	}
            }
            if(enccombo != null){
            	if(certType == 2 || certType == 3){
            		isEncCert = true;	
            	}
            }

            /*subStringForCN = certSubject.substring(certSubject.indexOf('CN=') + 3, certSubject.length);

            if (subStringForCN.indexOf(',') != -1) {
                clientName = subStringForCN.substring(0, subStringForCN.indexOf(','));
            } else {
                clientName = subStringForCN;
            }*/

            var certName = "";
            if(osType == 1){
            	certName = setCertificateNameLinux(certSubject);
            }
            else {
            	certName = setCertificateName(certAlias);
            }
            
            if (isSignCert) {
                signCombo.options[signCombo.length] = new Option(certName, certAlias);
            }
            if (isEncCert) {
                enccombo.options[enccombo.length] = new Option(certName, certAlias);
            }
    	}
    	catch(e){
    		
    	}
    }
    if(signCombo != null){
        sortComboText('certNames_sign');
        if(signCombo.length == 2){
            signCombo.selectedIndex = '1';
            $(signCombo).change();
        }else{            
            if(typeof SIGNPKEY !=='undefined' && SIGNPKEY!=''){                 
                $(signCombo).val(getCertiAliasByKeyUsage(SIGNPKEY,'1'));
                $(signCombo).change();
                $(signCombo).attr('disabled', '');
                enccombo.options[0] = new Option("--Please Select--", 1);
            }
        }
    }
    if(enccombo != null){
        sortComboText('certNames_encrypt');
        if(enccombo.length == 2){
            enccombo.selectedIndex = '1';
            $(enccombo).change();
        }
     }
}
function setCertificateName(alias){
	if(alias.lastIndexOf(" - ") != -1){
		return alias.substring(0,alias.lastIndexOf(" - "));
	}
	return alias;
}

function setCertificateNameLinux(subject){
	var a = subject.substring(subject.indexOf("CN=")+3);
	a = a.substring(0,a.indexOf(","));
	return a;
}

var remainDays = 0;

function showSignEncCertInfo(certType) {

	if(certType == 'encrypt')
	{
		if(document.getElementById("certNames_encrypt").value == 0 || document.getElementById("certNames_encrypt").value == 1)
		{
			
			document.getElementById("skpSubject_encrypt").value=null;
	        document.getElementById("skpIssuer_encrypt").value=null;
	        document.getElementById("skpSerial_encrypt").value=null;
	        document.getElementById("skpValidFrom_encrypt").value=null;
	        document.getElementById("skpValidTo_encrypt").value=null;
	        document.getElementById("skpPublicKey_encrypt").value=null;
	        document.getElementById("skpAlias_encrypt").value=null;
	        document.getElementById("skpPurpose_encrypt").value=null;
	        $('#key_encrypt').hide();
		}	
		else
		{
			$('#key_encrypt').show();
		}
	}


    var td = document.getElementById("key_" + certType);
    var certKeyUse;

    if (document.getElementById("certNames_" + certType).value != 0) {
    	document.getElementById("newkey2_" + certType).style.display = '';
        var tableDataCert = "<span class='black'>Certificate Detail : </span><br /><table class='m-top1'>";
        
        sealock.selectCertificate(document.getElementById("certNames_" + certType).value);
        
        var certSub = sealock.getCertificateInformation(0);
        document.getElementById("skpSubject_" + certType).value = certSub;
        tableDataCert = tableDataCert + "<tr><td width='17%' class='no-padding black'>Subject</td><td width='83%' class='a-left' style='line-height:18px;'>" + certSub+"</td></tr>";

        var certIssuer = sealock.getCertificateInformation(1);
        document.getElementById("skpIssuer_" + certType).value = certIssuer;
        tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Issuer</td><td  class='a-left'>" + certIssuer+"</td></tr>";

        var certSerial = sealock.getCertificateInformation(2);
        document.getElementById("skpSerial_" + certType).value = certSerial;
        tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Serial No.</td><td  class='a-left'>" + certSerial+"</td></tr>";

        var certValidFrom = sealock.getCertificateInformation(5);
        document.getElementById("skpValidFrom_" + certType).value = certValidFrom;
        tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Valid From</td><td  class='a-left'>" + certValidFrom+"</td></tr>";

        var certValidTo = sealock.getCertificateInformation(6);
        document.getElementById("skpValidTo_" + certType).value = certValidTo;
        tableDataCert = tableDataCert + "<tr><td  class=' no-padding black'>Valid To</td><td  class='a-left'>" + certValidTo+"</td></tr></table>";
        
        td.innerHTML = tableDataCert /*+ " <br><br><b style='display:none;'>Public Key : </b></br><div style='display:none; word-break: break-all; white-space:normal; word-wrap: break-word; width:320px;'>" + wrapPublicKey(sealock.getPublicKey()) + "</div>";*/
        document.getElementById("skpPublicKey_" + certType).value = sealock.getPublicKey();
        
        certKeyUse = sealock.getCertificateInformation(7);
          
        if(certKeyUse == 3){
        	document.getElementById("skpPurpose_" + certType).value = "2";
        }
        else {
        	document.getElementById("skpPurpose_" + certType).value = "1";
        }

        document.getElementById("skpAlias_" + certType).value = document.getElementById("certNames_" + certType).value;
        
        if (chekSignEncCertificateRenewDate(certType)) {
            td.innerHTML = td.innerHTML + " <br><br><b><font>Note : </font></b>";
            td.innerHTML = td.innerHTML + " <b><font>Please Renew your digital certificate.</font></b> ";
            td.innerHTML = td.innerHTML + " <b><font>It's going to expire in next " +remainDays+ " days. </font></b>";
            td.innerHTML = td.innerHTML + " <b><font>You may contact any of abcProcure support executive for Renewal process.</font></b></br>";
        }
    } else {
        document.getElementById("newkey2_" + certType).style.display = 'none';
        document.getElementById("skpSubject_" + certType).value = "";
        document.getElementById("skpIssuer_" + certType).value = "";
        document.getElementById("skpSerial_" + certType).value = "";
        document.getElementById("skpValidFrom_" + certType).value = "";
        document.getElementById("skpValidTo_" + certType).value = "";
        document.getElementById("skpPublicKey_" + certType).value = "";
        document.getElementById("skpPurpose_" + certType).value = "";
        document.getElementById("skpAlias_" + certType).value = "";
        td.innerHTML = "";
    }
}

function checkBothCertExpire(){
        $('.err').remove();
        if (document.getElementById("certNames_sign").value == 0 || (document.getElementById("certNames_encrypt")  != null  && document.getElementById("certNames_encrypt").value == 1)) {
                if (document.getElementById("certNames_sign").value == 0) {
                    $("#certNames_sign").parent().append("<div class='err' style='color:red;margin-top:5px;'>Please select Signing Certificate</div>");
                }
                if (document.getElementById("certNames_encrypt")  != null && document.getElementById("certNames_encrypt").value == 1) {
                            $("#certNames_encrypt").parent().append("<div class='err' style='color:red;margin-top:5px;'>Please select Encryption Certificate</div>");
                        }
		return false;
	}
	
	var currentDt = new Date(document.getElementById("serverdt").value);
	var signCertDt = new Date(document.getElementById("skpValidTo_sign").value);
	var encCertDt = (document.getElementById("skpValidTo_encrypt")!=null) ? new Date(document.getElementById("skpValidTo_encrypt").value) : '';
	if(currentDt >= signCertDt){
		alert("Signing Digital Certificate is expired. Please select valid Digital Certificate.");
		return false;
	}
	if(encCertDt!='' && currentDt >= encCertDt){
		alert("Encryption Digital Certificate is expired. Please select valid Digital Certificate");
		return false;
	}
	return true;
}

function chekSignEncCertificateRenewDate(certType) {
    if (document.getElementById("certNames_sign").value != 0 || document.getElementById("certNames_encrypt").value != 0) {
        var theDate;
        
        if (certType == "sign") {
            theDate = document.getElementById("skpValidTo_sign").value;
            //date1 = new Date(theDate);
        } else {
            theDate = document.getElementById("skpValidTo_encrypt").value;
            //date1 = new Date(theDate);
        }        
        
        var currentDt = new Date(document.getElementById("serverdt").value);
        var certDt = new Date(theDate);
        
        var DAY = 1000 * 60 * 60  * 24;
        
        remainDays = (Math.round((certDt.getTime() - currentDt.getTime()) / DAY));
        
        if((Math.round((certDt.getTime() - currentDt.getTime()) / DAY)) <= 30){
        	if((Math.round((certDt.getTime() - currentDt.getTime()) / DAY)) <= 0){
        		return false;	
        	}
        	else {
        		return true;
        	}
        }
        else {
        	return false;
        }
                
        /*var arrDateStr = theDate.split(" ");

        var year = arrDateStr[5];
        var month = getMonthNum(arrDateStr[1]);
        var day = arrDateStr[2];
        var tempTime = arrDateStr[3];
        var tempTimeArray = tempTime.split(":");
        var hour = tempTimeArray[0];
        var minute = tempTimeArray[1];
        var serverDateNew = document.getElementById("appDate").value;
        var hr = hour;
        var mm = minute;

        var serverDateTimeArray = serverDateNew.split(" ");
        var serverDateArray = serverDateTimeArray[0].split("/");
        var serveTime = serverDateTimeArray[1];

        var serverTime1 = serveTime.replace(":", "/");
        var serveTimeArray = serverTime1.split("/");
        var servermin = serveTimeArray[1];
        var servermin1 = servermin.replace(":", "/");
        var servermin1Array = servermin1.split("/");

        if (eval(serverDateArray[2]) == eval(year)) {
            if (eval(serverDateArray[0]) == eval(month)) {
                if (eval(eval(serverDateArray[1]) + 29) >= eval(day)) {
                    return true;
                } else
                    return false;
            } else {
                if (eval(serverDateArray[0]) == eval(eval(month) - 1)) {
                    if (eval(serverDateArray[1]) >= eval(day)) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }
        } else if (eval(serverDateArray[2]) == eval(eval(year) - 1)) {
            if (serverDateArray[0] == 12 && month == 1) {
                if (eval(eval(serverDateArray[1]) + 29) >= eval(day)) {
                    return true;
                } else if (eval(serverDateArray[1]) >= eval(day)) {
                    return true;
                } else {
                    return false;
                }
            } else{
                return false;
            }
        } else {
            return false;
        }*/
    }
}

function getCertiAlias(publicKey) {  
    var certAlias="";
    sealock.openKeyStore("my", "");
    var certType;    
    var certCount = sealock.getCertificateCount();
    var ispkfound = false;
    for (var i = 1; i<=certCount; i++) {
    	var isSignCert = false;
    	certAlias = sealock.getCertificateAlias(i);
        sealock.selectCertificate(certAlias);                
        certType = sealock.getCertificateInformation(7);                
        if(certType == 1 || certType == 3){
                isSignCert = true;	
        }        
        if(isSignCert && publicKey == sealock.getPublicKey()){
            ispkfound = true;
            return certAlias;
        }
    }
    if(!ispkfound){
       certAlias=""; 
    }
    return certAlias;
}
function getCertiAliasByKeyUsage(publicKey,keyUsage) {  
    var certAlias="";
    sealock.openKeyStore("my", "");
    var certType;    
    var certCount = sealock.getCertificateCount();
    var ispkfound = false;
    var isValidCert = false;
    for (var i = 1; i<=certCount; i++) {
    	certAlias = sealock.getCertificateAlias(i);
        sealock.selectCertificate(certAlias);                
        certType = sealock.getCertificateInformation(7);                
        if(keyUsage == 1 && (certType == 1 || certType == 3)){
            isValidCert = true;	
        }        
        if(keyUsage == 2 && (certType == 2 || certType == 3)){
            isValidCert = true;	
        }
        if(isValidCert && publicKey == sealock.getPublicKey()){
            ispkfound = true;
            return certAlias;
        }
    }
    if(!ispkfound){
       certAlias=""; 
    }
    return certAlias;
}
