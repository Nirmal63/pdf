//    Document   : kpidashboard.js
//    Created on : Aug 20, 2015  14:18:47 PM
//    Author     : Janak.Dhanani

$(document).ready(function(){
	Highcharts.setOptions({
	    lang: {
	        columnButtonTitle: "Column chart",
	        lineButtonTitle: "Line chart",
	        barButtonTitle: "Bar chart",
	        pieButtonTitle: "Pie chart",
	        thousandsSep: ','
	    }
	});
	$('#datatable').DataTable( {
    	"lengthMenu": [ [10, 25, 50, -1], [10, 25, 50, "All"] ]
    });
});

$(function() {	// select kpi or change event for Kpi criteria items, Year, Quarter and month
	
	$('.kpiMenu').on("click", function () {
		$(".kpiMenu").removeClass("kpiMenuSelected");
		$(this).addClass("kpiMenuSelected");
		var kpiName = $(this).text();
		var selKpiSpan = "<span class='hovercollapse collapse-info-catalogue collapse-info-catalogue-kpi'>"+kpiName+"</span>";
		$("#filterBreadCrumbs").html("");
		$("#filterBreadCrumbs").append(selKpiSpan);
		$( "#breadcrumbs-view" ).slideDown( "slow", function() {});
		$( "#yrqtrmon-view" ).slideDown( "slow", function() {});
		addRecentFilterBreadScrums();
	});
	
	$("input:checkbox[class=kpiCriteriaItem]").change(function (){
		var kpiCriteriaItemNameVal = this.name; 
		var totCheckedItemByCrt = $('input:checkbox[name="'+kpiCriteriaItemNameVal+'"]:checked').length;
		var BCId = 'BC'+kpiCriteriaItemNameVal;
		if(totCheckedItemByCrt == 0){
			$('#'+BCId).remove();	
		}else{
			if ($('#'+BCId).length == 0) {
				var kpiId = kpiCriteriaItemNameVal.split("_")[1];
				var crtId = kpiCriteriaItemNameVal.split("_")[2];
				var crtName = $("h2[class='kpiCrt_"+kpiId+"'][id='crt_"+crtId+"']").text();
				addBreadCrumbs(BCId,crtName,kpiCriteriaItemNameVal);
			}
		}
	});
	
	$("input:checkbox[id=filterYrQtrMon]").change( function () {
		if($(this).is(":checked")) {
			$(this).parent().addClass('active');
	    } else {
	    	$(this).parent().removeClass('active');
	    }
		
		var nameValFilterYrQtrMon = $(this).prop("name");
		var totCheckedItemOnYrQtrMon = $('input:checkbox[name="'+nameValFilterYrQtrMon+'"]:checked').length;
		var BCId = 'BC'+nameValFilterYrQtrMon;
		if(totCheckedItemOnYrQtrMon == 0){
			$('#'+BCId).remove();	
		}else{
			if ($('#'+BCId).length == 0) {
				var nameBC='';
				if(nameValFilterYrQtrMon =='filterYear') nameBC = 'Year';
				else if(nameValFilterYrQtrMon =='filterQuarter') nameBC = 'Quarter';
				else if(nameValFilterYrQtrMon =='filterMonth') nameBC = 'Month';
				addBreadCrumbs(BCId,nameBC,nameValFilterYrQtrMon);
			}
		}
	});
	
	$("input:checkbox[name=filterQuarter]").change(function () {
		$('#BCfilterMonth').remove();
		var checkedQtr = new Array();
		var unCheckedQtr = new Array();
		$("input:checkbox[name=filterQuarter]:checked").each(function(){
			checkedQtr.push($(this).val());
		});
		$("input:checkbox[name=filterQuarter]:not(:checked)").each(function(){
			unCheckedQtr.push($(this).val());
		});
		var qtrNo;
		for ( var i = 0, l = checkedQtr.length; i < l; i++ ) {
			qtrNo = checkedQtr[ i ];
			$.each($("input:checkbox[class=q"+qtrNo+"]"), function() {
				$(this).prop('checked',true) ;
				$(this).parent().addClass('active');
			});
		}
		for ( var i = 0, l = unCheckedQtr.length; i < l; i++ ) {
			qtrNo = unCheckedQtr[ i ];
			$.each($("input:checkbox[class=q"+qtrNo+"]"), function() {
				$(this).attr('checked', false); 
				$(this).parent().removeClass('active');
			});
		}
	});
	
	$("input:checkbox[name=filterMonth]").change(function () {
		$("input:checkbox[name=filterQuarter]").each(function(){
			$(this).attr('checked', false); 
			$(this).parent().removeClass('active');
			$('#BCfilterQuarter').remove();
		});
	});
});

function getSelDashboardReportFilter()  //get selected filter on filter kpi filter
{
	var dashboardParam = {};
	var selYear = new Array();
	var unCheckedQtr = new Array();
	var selQuarter = new Array();
	var selMonth = new Array();
	var kpiId=0;
	$("input:checkbox[name=filterYear]:checked").each(function(){
		selYear.push($(this).val());
	});
	if(selYear.length > 0)
		dashboardParam.year=selYear;
	else{
		$("input:checkbox[name=filterYear]:not(:checked)").each(function(){
			unCheckedQtr.push($(this).val());
		});
		dashboardParam.year=unCheckedQtr;
	}
	$("input:checkbox[name=filterQuarter]:checked").each(function(){
		selQuarter.push($(this).val());
	});
	if(selQuarter.length > 0)
		dashboardParam.quarter=selQuarter;
	$("input:checkbox[name=filterMonth]:checked").each(function(){
		selMonth.push($(this).val());
	});
	if(selMonth.length > 0)
		dashboardParam.month=selMonth;
	
	if($('.kpiMenuSelected').attr('id') != undefined){
		var vlKpiId =$('.kpiMenuSelected').attr('id'); 
		kpiId = vlKpiId.split("_")[1];
		var arrSelKpiCriterias = [];
		$('.kpiCrt_'+kpiId).each(function() {
			var varCrtId =  this.id;
			var crtId = varCrtId.split("_")[1];
			var selCrtIds = $("input:checkbox[name=crtItem_"+kpiId+"_"+crtId+"]:checked").map(function() {
				return this.value; 
			}).get().join(',');
			if(selCrtIds != ''){
				arrSelKpiCriterias.push(crtId +"@"+selCrtIds);
			}
		});
		dashboardParam.criteria=arrSelKpiCriterias.join('#');
	}else{
		alert("Please select kpi");
	}
	dashboardParam.kpiId=kpiId;
	return JSON.stringify(dashboardParam);
}

function addRecentFilterBreadScrums(){
	if($('.kpiMenuSelected').attr('id') != undefined){
		var vlKpiId =$('.kpiMenuSelected').attr('id'); 
		kpiId = vlKpiId.split("_")[1];
		var arrSelKpiCriterias = [];
		$('.kpiCrt_'+kpiId).each(function() {
			var varCrtId =  this.id;
			var crtId = varCrtId.split("_")[1];
			var kpiCriteriaItemNameVal = "crtItem_"+kpiId+"_"+crtId;
			var totCheckedItemByCrt = $('input:checkbox[name="'+kpiCriteriaItemNameVal+'"]:checked').length;
			var BCId = 'BC'+kpiCriteriaItemNameVal;
			if(totCheckedItemByCrt == 0){
				$('#'+BCId).remove();	
			}else{
				if ($('#'+BCId).length == 0) {
					var crtName = $("h2[class='kpiCrt_"+kpiId+"'][id='crt_"+crtId+"']").text();
					addBreadCrumbs(BCId,crtName,kpiCriteriaItemNameVal);
				}
			}
		});
	}
	
	var totCheckedYear = $('input:checkbox[name="filterYear"]:checked').length;
	if(totCheckedYear != 0){
		addBreadCrumbs('BCfilterYear','Year','filterYear');
	}
	var totCheckedQuarter = $('input:checkbox[name="filterQuarter"]:checked').length;
	if(totCheckedQuarter != 0){
		addBreadCrumbs('BCfilterQuarter','Quarter','filterQuarter');
	}
	else{
		var totCheckedMonth = $('input:checkbox[name="filterMonth"]:checked').length;
		if(totCheckedMonth != 0){
			addBreadCrumbs('BCfilterMonth','Month','filterMonth');
		}
	}
	
}

function addBreadCrumbs(BCId, BCName, chechBoxName){
	if ($('#'+BCId).length == 0) {
		var selCrtBC = "<span class='hovercollapse collapse-info-catalogue resetAllBC' id='"+ BCId +"'>"+BCName+"<a href='javascript:void(0);' onclick='removeBreadCrumbs(\""+chechBoxName+"\");' class='close-info-icon-catalogue'></a></span>";
		$("#filterBreadCrumbs").append(selCrtBC);
	}
}
function removeBreadCrumbs(chechBoxName){	// on click cancel BreadCrumbs remove selection of input checkbox by name 
	$('#BC'+chechBoxName).remove();			// remove clicked BreadCrumbs by #BC+Id
	$("input:checkbox[name="+chechBoxName+"]").each(function(){
		$(this).attr('checked', false);
		$(this).parent().removeClass('active');
	});
}

function resetAllFilter(){
	$("input:checkbox[id=filterYrQtrMon]").each(function(){
		$(this).attr('checked', false); 
		$(this).parent().removeClass('active');
	});
	$("input:checkbox[class=kpiCriteriaItem]").each(function(){
		$(this).attr('checked', false); 
	});
	$('.resetAllBC').remove();
	getDashboardKPI(); // to reset all filter and reload the selected kpi
}