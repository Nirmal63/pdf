/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

document.oncontextmenu=(function() {return false;}());
if(isDiy!=1)
{
	if(window.history.forward(1) != null )
	{  
	    window.history.forward(1);
	}
}
var message="Due to security reason, Right Click is not allowed";

function clickIE4(){
    if (event.button==2){
        alert(message);
        return false;
    }
}

function clickNS4(e){
    if (document.layers||document.getElementById&&!document.all){
        if (e.which==2||e.which==3){
            alert(message);
            return false;
        }
    }
}

if (document.layers){
    document.captureEvents(Event.MOUSEDOWN);
    document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
    document.onmousedown=clickIE4;
}
document.oncontextmenu=function(){alert(message);return false;};
