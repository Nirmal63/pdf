function GetCal(txtname, controlname, datetype) {
	if (datetype == 'datetime') {
		var date;
		new Calendar({
			inputField : txtname,
			trigger : controlname,
			dateFormat : DATETIMEFORMATE_CALENDAR,
			showTime : true,
			onSelect : function() {
				date = this.selection.get()
				date = Calendar.intToDate(date);
				date = Calendar.printDate(date, DATETIMEFORMATE_CALENDAR);
				this.hide();
				if (txtname == 'txtdob') {
					RndEndDt();
				}

				document.getElementById(txtname).focus();
			}
		});
	} else {

		new Calendar({
			inputField : txtname,
			trigger : controlname,
			showTime : false,
			dateFormat : DATEFORMATE_CALENDAR,
			onSelect : function() {
				var date = Calendar.intToDate(this.selection.get());
				LEFT_CAL.args.min = date;
				LEFT_CAL.redraw();
				this.hide();
			}
		});

	}
	var LEFT_CAL = Calendar.setup({
		weekNumbers : false
	})
}
			


function checkKeyGoTo(e)
{
    var keyValue = (window.event)? e.keyCode : e.which;
    if(keyValue == 13){
       /* $(function() {*/
            var txtpageNo=parseInt($('#dispPage').val());
            var totalPages=parseInt($('#txtTotalPages').val());
            if(txtpageNo > 0)
            {
                if(txtpageNo <= totalPages) {
                    $('#txtpageNo').val(Number(txtpageNo));
                    goTo();
                    $('#dispPage').val(Number(txtpageNo));
                }
            }
        /*});*/
    }
}
// page - end
function first(){
    var totalPages=parseInt($('#txtTotalPages').val(),10);
    var fromSearch = $("#txtFromSearch").val();
    if(totalPages>0 && $('#txtpageNo').val()!="1")
    {
        $('#txtpageNo').val("1");
        $('#dispPage').val("1");
        if(fromSearch!='1'){
    		getReportData(currentTabId);
    	}
    	else{
    		validateSearch('1');
    	}
        $('#dispPage').val("1");
        $('#txtpageNo').val("1");
        if(parseInt($('#txtpageNo').val()) == 1)
            $('#btnPrevious').attr("disabled", "true");
    }
	chkdisble($('#txtpageNo').val());
}
function last(){
	var totalPages=parseInt($('#txtTotalPages').val(),10);
	var fromSearch = $("#txtFromSearch").val();
    if(totalPages>0)
    {
    	$('#dispPage').val(totalPages);
        $('#txtpageNo').val(totalPages);
        if(fromSearch!='1'){
    		getReportData(currentTabId);
    	}
    	else{
    		validateSearch(totalPages);
    	}
        $('#dispPage').val(totalPages);
        $('#txtpageNo').val(totalPages);
        if(parseInt($('#txtpageNo').val(), 10) == 1)
            $('#btnPrevious').attr("disabled", "true");
			
    }
	chkdisble($('#txtpageNo').val());
}
function next(){
    var txtpageNo=parseInt($('#dispPage').val());
    var totalPages=parseInt($('#txtTotalPages').val());
    var fromSearch = $("#txtFromSearch").val();
    if(txtpageNo != totalPages) {
    	$('#txtpageNo').val((Number(txtpageNo)+1));
    	$('#dispPage').val((Number(txtpageNo)+1));
    	if(fromSearch!='1'){
    		getReportData(currentTabId);
    	}
    	else{
    		validateSearch($('#dispPage').val());
    	}
        $('#dispPage').val((Number(txtpageNo)+1));
        $('#txtpageNo').val((Number(txtpageNo)+1));
        $('#btnPrevious').removeAttr("disabled");
		chkdisble($('#txtpageNo').val());
    }
}
function previous(){
    var txtpageNo=$('#txtpageNo').val();
    var fromSearch = $("#txtFromSearch").val();
    if(parseInt(txtpageNo, 10) > 1)
    {
        $('#txtpageNo').val(Number(txtpageNo) - 1);
        $('#dispPage').val(Number(txtpageNo) - 1);
        if(fromSearch!='1'){
    		getReportData(currentTabId);
    	}
    	else{
    		validateSearch($('#dispPage').val());
    	}
        $('#dispPage').val(Number(txtpageNo) - 1);
        $('#txtpageNo').val(Number(txtpageNo) - 1);
        if(parseInt($('#txtpageNo').val()) == 1)
            $('#btnPrevious').attr("disabled", "true");
			
    }
	chkdisble($('#txtpageNo').val());
		}
function goTo(){
	var fromSearch = $("#txtFromSearch").val();
    var txtpageNo=parseInt($('#dispPage').val());
    var totalPages=parseInt($('#txtTotalPages').val());
    if(txtpageNo > 0)
    {
        if(txtpageNo <= totalPages) {
            $('#txtpageNo').val(Number(txtpageNo));
            $('#dispPage').val(Number(txtpageNo));
            if(fromSearch!='1'){
        		getReportData(currentTabId);
        	}
        	else{
        		validateSearch($('#dispPage').val());
        	}
            $('#dispPage').val(Number(txtpageNo));
            $('#txtpageNo').val(Number(txtpageNo));
            if(parseInt($('#txtpageNo').val()) == 1)
                $('#btnPrevious').attr("disabled", "true");
            if(parseInt($('#txtpageNo').val()) > 1)
                $('#btnPrevious').removeAttr("disabled");
        }
		chkdisble($('#txtpageNo').val());
    }
}
		
//page - start
 function chkdisble(txtpageNo)
{
    $('#dispPage').val(Number(txtpageNo));
    if(parseInt($('#txtpageNo').val()) == 0)
    {
        $('#btnFirst').attr("disabled", "true");
        $('#btnFirst').css('color', 'gray');
        $('#btnNext').attr("disabled", "true");
        $('#btnNext').css('color', 'gray');
        $('#btnPrevious').attr("disabled", "true");
        $('#btnPrevious').css('color', 'gray');
        $('#btnLast').attr("disabled", "true");
        $('#btnLast').css('color', 'gray');
    }
    else
    {
        if(parseInt($('#txtpageNo').val(), 10) != 1){
            $('#btnFirst').removeAttr("disabled");
            $('#btnFirst').css('color', '#333');
        }

        if(parseInt($('#txtpageNo').val(), 10) == 1){
            $('#btnFirst').attr("disabled", "true");
            $('#btnFirst').css('color', 'gray');
        }


        if(parseInt($('#txtpageNo').val(), 10) == 1){
            $('#btnPrevious').attr("disabled", "true")
            $('#btnPrevious').css('color', 'gray');
        }

        if(parseInt($('#txtpageNo').val(), 10) > 1){
            $('#btnPrevious').removeAttr("disabled");
            $('#btnPrevious').css('color', '#333');
        }

        if(parseInt($('#txtpageNo').val(), 10) == parseInt($('#txtTotalPages').val())){
            $('#btnLast').attr("disabled", "true");
            $('#btnLast').css('color', 'gray');
        }

        else{
            $('#btnLast').removeAttr("disabled");
            $('#btnLast').css('color', '#333');
        }

        if(parseInt($('#txtpageNo').val(), 10) == parseInt($('#txtTotalPages').val())){
            $('#btnNext').attr("disabled", "true")
            $('#btnNext').css('color', 'gray');
        }
        else{
            $('#btnNext').removeAttr("disabled");
            $('#btnNext').css('color', '#333');
        }
    }
} 