function loadListingReportGrid(isShowMore)
{
	$('#resultTablePdf').find("tr:gt(3)").remove();
	var urlstr="";
	var strVal="";
	for(var i=0;i<searchColArr.length;i++)
	{
		if($("#selop_"+searchColArr[i]).val() != undefined)
		{
			urlstr+="&selop_"+searchColArr[i]+"="+$("#selop_"+searchColArr[i]).val();
			urlstr+="&jhselop_"+searchColArr[i]+"="+$("#jhselop_"+searchColArr[i]).val();
			
		}
		strVal=$.trim($("#txt_"+searchColArr[i]).val());
		if($("#txt_"+searchColArr[i]).attr('class') != null && $("#txt_"+searchColArr[i]).attr('class').toString().indexOf('easyui-combotree') != -1)
		{
			strVal = $.trim($("#txt_"+searchColArr[i]).combotree('getValue'));
		}
		if(strVal != "")
		{
			strVal=encodeSPChar(strVal);
			searchFieldCount++;
		}
		urlstr+="&txt_"+searchColArr[i]+"="+strVal;
		strVal=$.trim($("#txt_"+searchColArr[i]+"_to").val());
		if(strVal != '')
		{
			strVal=encodeSPChar(strVal);
			searchFieldCount++;
		}
		urlstr+="&txt_"+searchColArr[i]+"_to="+strVal;
	}
	urlstr = urlstr.replace(/\'/g, '&#39;').replace(/\"/g, ''); // for BUG #30171 Keval soni
	if($("#txtKeywordSearch").val() != null && $.trim($("#txtKeywordSearch").val()) != '') {
		jsParam10 = $.trim($("#txtKeywordSearch").val());
		searchFieldCount++;
	} else {
		jsParam10 = "";
	}
	if(searchFieldCount > 0) {
		jsParam10 = jsParam10.replace(/\'/g, '&#39;').replace(/\"/g, '').replace(/\=/g, ''); // for BUG #30171 Keval soni
		 urlstr+="&txtReportId="+jsReportId+
         "&txtpageNo="+$("#txtpageNo").val()+
         "&txtModuleName="+$("#txtModuleName").val()+
         "&txtsize="+ $("#txtsize").val()+
         "&txtparam1="+ escape(jsParam1).replace('+', '%2B')+
         "&txtparam2="+ escape(jsParam2).replace('+', '%2B')+
         "&txtparam3="+ escape(jsParam3).replace('+', '%2B')+
         "&txtparam4="+ escape(jsParam4).replace('+', '%2B')+
         "&txtparam5="+ escape(jsParam5).replace('+', '%2B')+
         "&txtparam6="+ escape(jsParam6).replace('+', '%2B')+
         "&txtparam7="+ escape(jsParam7).replace('+', '%2B')+
         "&txtparam8="+ escape(jsParam8).replace('+', '%2B')+
         "&txtparam9="+ escape(jsParam9).replace('+', '%2B')+
         "&txtparam10="+ escape(jsParam10).replace('+', '%2B')+
         "&txtsortColumn="+ $('#txtsortColumn').val()+
         "&txtsortOrder="+ $('#txtsortOrder').val()+
         "&txtTab="+ selectedTab;
		 $.ajax({
         type: "POST",
         url: jsReportUrlStr,
         dataType: 'text',
         data : urlstr,
         success: function(j)
         {
             if($.trim(j).indexOf("sessionexpired") != -1)
             {
                 window.location = errorPageUrl;
             }
             else
             {
			searchFieldCount=0;
			if(rptType ==0)
			{
				$('#resultTable tr:gt(2)').remove();
				$('#resultTable tr:last').after(j);
			}
			else
			{
				/*$('#tblAdvanceSearch').attr("style",'display: none;');*/
				if(j.indexOf("id='noRecordFound'") == -1 && isShowMore) {
					//$('#reportDetail').html($('#reportDetail').html()+j);
					$("#reportDetail tr:last").after(j);
				} else if(!isShowMore) {
					$('#reportDetail').html("<table class='m-left_1 m-top_1' style='width:100%'>"+j+"</table>");
				}
			}
			 
			if($("#lnkAdvSearch").html()!=MSG_ADVANCESEARCH){
				$("html, body").animate({ scrollTop: $(window).height()-470}, 600);
			}
			if($('#noRecordFound').attr('value') == "noRecordFound")
			{
				$("#txtpageNo").val("0");
				$("#btnShowMore").hide();
			}
			else{
				$("#btnShowMore").show();
			}

			if($("#totalPages").val() == 1){
				$('#btnNext_1').attr("disabled", "true");
				$('#btnLast_1').attr("disabled", "true");
				$("#btnShowMore").hide();
			}else{
				$('#btnNext_1').removeAttr("disabled");
				$('#btnLast_1').removeAttr("disabled");
			}


			$("#pageTot").html('');

			$("#pageTot").html($("#totalPages").val());

			$("#pageNoTot").html($("#txtpageNo").val());

			if(displayAllTabCount =='Y')
			{
				var arrTabDtl = $("#tabCountsDetails").val().split("||");
				$("span[id*='divTotalRecords']").each(function( i )
						{
					if($(this).attr('id').indexOf('_')!= -1)
					{
						for(var j=0;j<arrTabDtl.length;j++)
						{
							if(arrTabDtl[j].indexOf("::")!= -1 && arrTabDtl[j].split("::")[0] == $(this).attr('id').substr($(this).attr('id').indexOf('_')+1))
							{
								$(this).html("("+arrTabDtl[j].split("::")[1]+")");
							}
						}
					}
				});
			}


			if(selectedTab !='')
			{
				$("#divTotalRecords_"+selectedTab).html("("+$("#totalRecords").val()+")");
			}
			$("#divTotalRecords").html("("+$("#totalRecords").val()+")");
			$("#divSearchCriteria").html($("#searchCriteria").val());


			$('th[id^=col]').each(function( i )
					{
				if($("#searchCriteria").val()=='' && $(this).attr('id').indexOf('1')!= -1)
				{
					$(this).hide();
				}
				else
				{
					$(this).show();
				}
			});


			if($("#searchCriteria").val()=='' && $("#txtKeywordSearch").val()=='')
			{
				$('#tabTd').show();
				if(rptType ==0) {
					$("#divTotalRecords").hide();
				}
				$("#searchCriTotalDiv").hide();
			}
			else
			{
				$('#tabTd').hide();
				$("#searchCriTotalDiv").show();
				$("#divTotalRecords").html(MSG_TOTALRECORDS+$("#totalRecords").val());
				$("#divTotalRecords").show();
			}

			$('#resultDiv').show();
			chkdisble($("#txtpageNo").val());
             }
              
         },
         error: function(XMLHttpRequest, textStatus, errorThrown) {
         alert(ajaxErrorMsg);
         return false;
       }
     });	} else {
		alert(MSG_SEARCHCRITERIA);
	}
}
function loadReport(key){
	var result = false;
	if(key.keyCode ===13){
		$('#txtpageNo').val('1');
		loadListingReportGrid(false);
		result=true;
	}
}
function chkdisble(txtpageNo)
{
	$('#dispPage').val(Number(txtpageNo));
	if(parseInt($('#txtpageNo').val(), 10) == 0)
	{
		$('#btnFirst_1').attr("disabled", "true");
		$('#btnFirst_1').css('color', 'gray');
		$('#btnNext_1').attr("disabled", "true");
		$('#btnNext_1').css('color', 'gray');
		$('#btnPrevious_1').attr("disabled", "true");
		$('#btnPrevious_1').css('color', 'gray');
		$('#btnLast_1').attr("disabled", "true");
		$('#btnLast_1').css('color', 'gray');
	}
	else
	{
		if(parseInt($('#txtpageNo').val(), 10) != 1){
			$('#btnFirst_1').removeAttr("disabled");
			$('#btnFirst_1').css('color', '#333');
		}

		if(parseInt($('#txtpageNo').val(), 10) == 1){
			$('#btnFirst_1').attr("disabled", "true");
			$('#btnFirst_1').css('color', 'gray');
		}


		if(parseInt($('#txtpageNo').val(), 10) == 1){
			$('#btnPrevious_1').attr("disabled", "true")
			$('#btnPrevious_1').css('color', 'gray');
		}

		if(parseInt($('#txtpageNo').val(), 10) > 1){
			$('#btnPrevious_1').removeAttr("disabled");
			$('#btnPrevious_1').css('color', '#333');
		}

		if(parseInt($('#txtpageNo').val(), 10) == parseInt($('#totalPages').val())){
			$('#btnLast_1').attr("disabled", "true");
			$('#btnLast_1').css('color', 'gray');
		}

		else{
			$('#btnLast_1').removeAttr("disabled");
			$('#btnLast_1').css('color', '#333');
		}

		if(parseInt($('#txtpageNo').val(), 10) == parseInt($('#totalPages').val())){
			$('#btnNext_1').attr("disabled", "true")
			$('#btnNext_1').css('color', 'gray');
		}
		else{
			$('#btnNext_1').removeAttr("disabled");
			$('#btnNext_1').css('color', '#333');
		}
	}
}

function tabClick_1(selTabId)
{
	searchFieldCount = 1;
	$("a").each(function( i )
			{
		if ($(this).attr('id') != null && $(this).attr('id') != undefined && $(this).attr('id').indexOf('link') != -1) 
		{
			$(this).removeClass("tab active");
		}
			});
	$("span[id*='divTotalRecords']").each(function( i )
			{
		if($(this).html().indexOf("Total") == -1 && displayAllTabCount !='Y')
		{
			$(this).html("");
		}
			});
	selectedTab = selTabId;

	$('#link_'+selTabId).addClass('tab active');
	$('#txtpageNo').val('1');
	resetGrid_1();
}

function resetGrid_1()
{
	$('#txtpageNo').val('1');
	//$('#frmReportSearch').reset();
	$('#frmReportSearch').each(function(){
	});
	try
	{
		for(var i=0;i<searchColArr.length;i++)
		{
			if(document.getElementById("selop_"+searchColArr[i]))
			{
				document.getElementById("selop_"+searchColArr[i]).selectedIndex=0;
				if(document.getElementById('txt_div_'+searchColArr[i]+'_to') != null)
				{
					document.getElementById('txt_div_'+searchColArr[i]+'_to').style.display='none';
				}
			}

			if($("#txt_"+searchColArr[i]).attr('class') != null && $("#txt_"+searchColArr[i]).attr('class').toString().indexOf('easyui-combotree') != -1)
			{
				document.getElementsByName("txt_"+searchColArr[i]).item(0).value='';
			}
		}
		$("#txtKeywordSearch").val("");
	}catch(e){}

	loadListingReportGrid(false);
}

function firstPage() {
	searchFieldCount = 1;
	var totalPages=parseInt($('#totalPages').val(),10);

	if(totalPages>0 && $('#txtpageNo').val()!="1")
	{
		$('#txtpageNo').val("1");
		loadListingReportGrid(false);
		$('#dispPage').val("1");
		if(parseInt($('#txtpageNo').val(), 10) == 1)
			$('#btnPrevious_1').attr("disabled", "true")
	}
}

function lastPage() {
	searchFieldCount = 1;
	var totalPages=parseInt($('#totalPages').val(),10);
	if(totalPages>0)
	{
		$('#txtpageNo').val(totalPages);
		loadListingReportGrid(false);
		$('#dispPage').val(totalPages);
		if(parseInt($('#txtpageNo').val(), 10) == 1)
			$('#btnPrevious_1').attr("disabled", "true")
	}
}

function nextPage() {
	searchFieldCount = 1;
	var txtpageNo=parseInt($('#txtpageNo').val(),10);
	var totalPages=parseInt($('#totalPages').val(),10);

	if(txtpageNo != totalPages) {
		$('#txtpageNo').val(Number(txtpageNo)+1);
		loadListingReportGrid(false);
		$('#dispPage').val(Number(txtpageNo)+1);
		$('#btnPrevious_1').removeAttr("disabled");
	}
}

function previousPage() {
	searchFieldCount = 1;
	var txtpageNo=$('#txtpageNo').val();

	if(parseInt(txtpageNo, 10) > 1)
	{
		$('#txtpageNo').val(Number(txtpageNo) - 1);
		loadListingReportGrid(false);
		$('#dispPage').val(Number(txtpageNo) - 1);
		if(parseInt($('#txtpageNo').val(), 10) == 1){
			$('#btnPrevious_1').attr("disabled", "true");
		}
	}
}

function goToPage() {
	searchFieldCount = 1;
	var txtpageNo=parseInt($('#dispPage').val(),10);
	var totalPages=parseInt($('#totalPages').val(),10);
	if(txtpageNo > 0)
	{
		if(txtpageNo <= totalPages) {
			$('#txtpageNo').val(Number(txtpageNo));
			loadListingReportGrid();
			$('#dispPage').val(Number(txtpageNo));
			if(parseInt($('#txtpageNo').val(), 10) == 1){
				$('#btnPrevious_1').attr("disabled", "true");
			}
			if(parseInt($('#txtpageNo').val(), 10) > 1){
				$('#btnPrevious_1').removeAttr("disabled");
			}
		}
	}
}

function toggleAdvanceSearch(isSessionAvail)
{
	if($.trim($('#tblAdvanceSearch').attr("style")).indexOf("none")!= -1)
	{
		$(".placeholder").hide();
		$(".nor-keyword").hide();
   		$(".nor-search").hide();
   		$(".nor-clear").hide();
		$("#tdKeywordSearch").attr("style", "display: none;");
		$("#tdKeywordClearSearch").attr("style", "display: none;");
		$('#tblAdvanceSearch').attr("style",'display: block;');
		/*$('#divAdvSearch').attr("style",'display: none;');*/
		$("#lnkAdvSearch").attr("title",'Normal search');
		$("#lnkAdvSearch").html(MSG_NORMALSEARCH);
		if(isSessionAvail){
			console.log("1");
			$("#tblAdvanceSearch .tblAdvanceSearchTable tr:first-child td:nth-child(2)").find('input[type="text"]').trigger('focus');
		}
		else{
			$("#tblAdvanceSearch .tblAdvanceSearchTable tr:first-child td:last-child").find('input[type="text"]').trigger('focus');
			console.log("2");
		}
	}
	else
	{
		$("#txtKeywordSearch_placeholder").show();
		$(".nor-keyword").show();
   		$(".nor-search").show();
   		$(".nor-clear").show();
		$("#tdKeywordSearch").attr("style", "display: table-cell;");
		$("#tdKeywordClearSearch").attr("style", "display: table-cell;");
		$('#tblAdvanceSearch').attr("style",'display: none;');
		/*$('#divAdvSearch').attr("style",'display: block;')*/
		$("#lnkAdvSearch").attr("title",'Advanced search');
		$("#lnkAdvSearch").html(MSG_ADVANCESEARCH);
	}
}

function checkBetween(obj_index)
{
	if(document.getElementById("selop_"+obj_index).value == 'bt')
	{
		document.getElementById("txt_div_"+obj_index+"_to").style.display='block';
	}
	else
	{
		try
		{
			document.getElementById("txt_div_"+obj_index+"_to").style.display='none';
		}
		catch(e){}
	}
}
function checkKeyGoTo(e)
{
	var keyValue = (window.event)? e.keyCode : e.which;
	if(keyValue == 13){
		$(function() {
			var txtpageNo=parseInt($('#dispPage').val(),10);
			var totalPages=parseInt($('#totalPages').val(),10);
			if(txtpageNo > 0)
			{
				if(txtpageNo <= totalPages) {
					$('#txtpageNo').val(Number(txtpageNo));
					//loadTable();
					$('#btnGoto_1').click();
					$('#dispPage').val(Number(txtpageNo));
				}
			}
		});
	}
}

function encodeSPChar(str)
{ 
	str=str.replace("%","%25","g");
	str=str.replace("&","%26","g");
	str=str.replace("+","%2B","g");
	str=str.replace("#","%23","g");
	return str;
}

function comboChange(ob,id)
{
	$('#txt_'+id).val($(ob).val());
}
function addPlaceHolder(obj){
    if(obj.value == MSG_PLACEHOLDER){
        obj.value = '';
        $(obj).removeClass('palce-hldr');
        $('.placeholder').hide();
    }
}
function removePlaceHolder(obj){
    if(obj.value == ''){
        //obj.value = MSG_PLACEHOLDER;
        $(obj).addClass('palce-hldr');
        $('.placeholder').show();
    }
}