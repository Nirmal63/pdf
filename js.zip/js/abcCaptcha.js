/**
 * @author jaynam
 * 
 */
$(document).ready(function() {
		$("#recaptcha_response_field").blur(function(){
		javascript:validateAbcCaptcha(); 
		});  
		$("#recaptcha_response_field").focus(function(){
		javascript:responseFocus();
		});  
	keyAjax();
});
function refreshCapcha() {
	//console.log(cpage);
	var cRandom = Math.random() * 5;
	responseFocus();
	var id = $("DIV#abcCapchaDiv");
	var ctype = $("#cType").val();
	var theme = $("#ctheme").val();
	//cpage = page;
	

	if (ctype == 0) {
		var height = $("#cHeight").val();
		var width = $("#cWidth").val();
		var blur = $("#cBlur").val();
		id.empty();
		id.append("<img id='abcCaptchaImageId' alt='captcha' src='"+cpage+"/AbcCapchaImage?flag=image&ctheme="
				+theme+ "&ctype=0&h="+height+"&w="+width+"&b="+blur+"&temp="+cRandom+ "'> "
				+ "<input type='hidden' name='recaptcha_challenge_field' id='recaptcha_challenge_field' value=''/>"
				+ "<input type='hidden' name='cHeight' id='cHeight' value='"+height+"'/>"
				+ "<input type='hidden' name='cWidth' id='cWidth' value='"+width+"'/>"
				+ "<input type='hidden' name='cBlur' id='cBlur' value='"+blur+"'/>"
				+ "<input type='hidden' name='cType' id='cType' value='0'/>"
				+ "<input type='hidden' name='ctheme' id='ctheme' value='"+theme+"'/>"
				+ "<br/>"
				+ "<br/>"
				+ "<input type='text' name='recaptcha_response_field' id='recaptcha_response_field' value=''/>");
	} else {
		id.empty();
		id.append("<img id='abcCaptchaImageId' alt='captcha' src='"+cpage+"/AbcCapchaImage?flag=image&ctheme="
						+ theme
						+ "&ctype=1&temp="
						+ cRandom
						+ "'> "
						+ "<input type='hidden' name='recaptcha_challenge_field' id='recaptcha_challenge_field' value=''/>"
						+ "<input type='hidden' name='cType' id='cType' value='1'/>"
						+ "<input type='hidden' name='ctheme' id='ctheme' value='"
						+ theme
						+ "'/>"
						+ "<br/>"
						+ "<br/>"
						+ "<input type='text' name='recaptcha_response_field' id='recaptcha_response_field' value=''/>");

	}

	id.fadeIn();
	setTimeout(function(){keyAjax();}, 300);
	$("#recaptcha_response_field").blur(function(){
			javascript:validateAbcCaptcha(); 
		});  
}

function keyAjax() {

	$.ajax({
		type : "GET",
		async: false,
		url : cpage+'/AbcCapchaImage',
		dataType : 'text',
		data : {
			flag : "key"
		},
		success : function(responseText) {
			var key = responseText;
			if(key == null || key == ""){
				$('span#vericode').css("color", "red");
				$("span#vericode").html("Captcha Generation Error : please try again.");
			} else {
				$("#recaptcha_challenge_field").val(key);	
			}
			
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {

			return false;
		}
	});
}

function responseFocus() {
	$("span#vericode").html("");

}

function validateAbcCaptcha() {
	cpage = $('#captchaContext').val();
	if ($('#recaptcha_response_field').val() != "") {
		$.ajax({
			type : "POST",
			url : cpage+'/ajaxcall/validatecaptcha',
			dataType : 'text',
			data : {
				challenge : $('#recaptcha_challenge_field').val(),
				userInput : $('#recaptcha_response_field').val()
			},
			success : function(j) {
				if (j.toString() == "OK" || j.toString() == "Valid") {
					$('span#vericode').css("color", "green");
					isCaptchaVerified = true;
				} else {
					refreshCapcha();
					$('span#vericode').css("color", "red");
					isCaptchaVerified = false;
				}
				$('span#vericode').html(j);
				//setTimeout(function(){$('span#vericode').html(j).insertAfter('#abcCaptchaImageId');}, 500);
				
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {

				return false;
			}

		});
	} else {
		
		$('span#vericode').html("");
		$('span#vericode').css("color", "red");
		$('span#vericode').html("Please enter verification code");
		//.insertAfter('#abcCaptchaImageId');
		//$('#abcCaptchaImageId').after($('span#vericode'));
		isCaptchaVerified = false;
	}

}
