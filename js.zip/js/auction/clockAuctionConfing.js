 			//validaton done while approve of auction
            function validate(){
            	var vbool = valOnSubmit();
            	var isCheckReservePrice = false;
            	var reservePrice=0;
                var startPrice=0;
                var id;
                var isChkEndDate = false;
                id=0;
                $('[name="txtReservePrice"]').each(function(){
                	
                	isCheckReservePrice = checkReservePrice(this,id);
                	if(isCheckReservePrice) {
                		if(!compReservePrice(this,id)){
                			vbool = false;	
                		}
                	}else{
                		vbool = false;
                	}
                	 
                	id=id+1;
            	});
                id = 0;
                $('[name="txtStartPrice"]').each(function(){
                	if(!compStartPrice(this,id)){
                		vbool = false;	
                	}
                	 
                	id = id + 1;
            	});
                id = 0;
                if(isReservePriceReq == 1){
                	$('[name="txtEndDate"]').each(function(){
                    	calEndDate(id);
                    });	
                }else{
                	$('[name="txtEndDate"]').each(function(){
                    	
                    	isChkEndDate = checkEndDate(this,id);
                    	if(!isChkEndDate){
                    		vbool = false;	
                    	}
                    	id = id + 1;
                    });	
                }
                id = 0;
                $('[name="txtIncDecIntervalMin"]').each(function(){
                	if(!reservePriceChk(id,this)){
                		vbool = false;
                	}
                	id = id + 1;                        	
                });  
                id = 0;
                $('[name="txtStartDate"]').each(function(){
                	if(!checkStartDate(this,id)){
                		vbool = false;
                	}
                	id = id + 1;                        	
                });
                if(vbool){
                    id=0;
                    
                }
                vbool= disableBtn(vbool);
                return vbool;
            }
            function uploadExcelError(data)
            {
            	jAlert(data.toString().replace(/ERROR:~:/g, ''),"Configure parameter");
            }
            //Clock Auction Reserve price check onblur 
            function checkReservePrice(ob,cnt){
                
                var reservePrice=$(ob).val();    
                //$(ob).parent().find('#divResPricCheck').remove();
                if(isBidderWiseStartPrice==0 && eventType==varreverseclockauction){
                    var startPrice=$("#txtStartPrice_"+cnt).val();
                    if(parseFloat(reservePrice)<=parseFloat(startPrice)){
                        //$(ob).parent().append("<div id='divResPricCheck' style='color:red;'>${varrpgreaterthanst}  </div>");
                        $(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varrpgreaterthanst+" </div>");
                        return false;
                    }else if(reservePrice != '' && startPrice != '' &&  parseFloat(reservePrice)==parseFloat(startPrice)){
                        //$(ob).parent().append("<div id='divResPricCheck' style='color:red;'>${varrpgreaterthanst}  </div>");
                        $(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varrpgreaterthanst+" </div>");
                        return false;
                    }
                }else if(isBidderWiseStartPrice==0  && eventType==varforwardclockauction){
                    var startPrice=$("#txtStartPrice_"+cnt).val();
                    if(parseFloat(reservePrice)>=parseFloat(startPrice)){
                        //$(ob).parent().append("<div id='divResPricCheck' style='color:red;'>${varrplessthanst}  </div>");
                    	  $(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varrplessthanst+" </div>");
                    	  return false;
                    }else if(reservePrice != '' && startPrice != '' &&  parseFloat(reservePrice)==parseFloat(startPrice)){
                    	  $(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varrplessthanst+" </div>");
                    	  return false;
                    }
                }
                return true;
            }
            // start price compare with incdec value
            function compStartPrice(ob,cnt){
                var startPrice=$(ob).val();    
                var incDecVal=$("#txtIncDecVal_"+cnt).val();
                if(startPrice != '' && (parseFloat(startPrice) <= parseFloat(incDecVal)) && eventType==varforwardclockauction){
                	$(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varstlessthanincdec+" </div>");
                	return false;
                }else{
                var reminder = (parseFloat(startPrice) / parseFloat(incDecVal)).toFixed(5);
                reminder = reminder % 1;
                	if(startPrice != '' && reminder != 0){
               			if(eventType==varreverseclockauction){
               				$(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varstmulwithinc+" </div>");
               				return false;
               			}else if(eventType==varforwardclockauction){
               				$(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varstmulwithdec+" </div>");
               				return false;
               			}
               			
               		}
               		return true;
                }	
                }
         // Reserve price compare with incdec value
            function compReservePrice(ob,cnt){
                var reservePrice=$(ob).val();    
                var incDecVal=$("#txtIncDecVal_"+cnt).val();
                var reminder = parseFloat(reservePrice) % parseFloat(incDecVal);
               		if(reservePrice != '' && reminder != 0){
               			if(eventType==varreverseclockauction){
               				$(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varremulwithinc+" </div>");
               				return false;
               			}else if(eventType==varforwardclockauction){
               				$(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varremulwithdec+" </div>");
               				return false;
               			}
               			
               		}
               		return true;
                }
            // Check All start date
            function checkSameSD(ob){
                var rowId=$("#jhdRowId").val();
                // alert("rowId "+rowId);
                var fStartDate="";
                var i = 0;
                if($(ob).attr('checked')){
                    if(rowId==1){
                        fStartDate=$("#jhdRowId").parent().parent().find("#txtStartDate_0").val();
                        if(fStartDate=="" || fStartDate==null){
                        	$(ob).attr('checked',false);
                            jAlert(varenterstartdate);
                            return false;
                        }
                        $('[name="txtStartDate"]').each(function(){
                            $(this).val(fStartDate);
                            if($("#txtEndDate_"+i).val() != "" ){
                            	checkStartDate(this,i);
                            }
                            i++;
                        });     
                    }
                }
            }
         // Check All End date
            function checkSameED(ob){
                var rowId=$("#jhdRowId").val();
                var fEndDate="";
                var i = 0;
                if($(ob).attr('checked')){
                    if(rowId==1){
                        fEndDate=$("#jhdRowId").parent().parent().find("#txtEndDate_0").val();
                        if(fEndDate=="" || fEndDate==null){
                        	$(ob).attr('checked',false);
                        	jAlert(varenterenddate);
                            return false;
                        }
                        $('[name="txtEndDate"]').each(function(){
                            $(this).val(fEndDate);
                            if(isReservePriceReq==1){
                            	calEndDate(i);
                            }else{
                            	var edDate = document.getElementById("txtEndDate_"+i);	
                            	checkEndDate(edDate,i);
                            }
                            i++;
                        });     
                    }
                }
            }            
         // Check All time for incdec value
            function checkSameTimeReQuired(ob){
                var rowId=$("#jhdRowId").val();
                // alert("rowId "+rowId);
                var fTomeRequiredDate="";
                if($(ob).attr('checked')){
                    if(rowId==1){
                        fTomeRequiredDate=$("#jhdRowId").parent().parent().find("#txtTimeForIncDecItem_0").val();
                        if(fTomeRequiredDate=="" || fTomeRequiredDate==null){
                        	$(ob).attr('checked',false);
                            if(eventtype==varforwardclockauction){
                            	jAlert(varenterincamountafterdate);
                            }else{
                            	jAlert(varenterdecamountafterdate);
                            }
                            return false;
                        }
                        $('[name="txtTimeForIncDecItem"]').each(function(){
                            $(this).val(fTomeRequiredDate);
                        });     
                    }
                }
            }
         // Check All Interval Minutes
            function checkSameIncDecIntervalMin(ob){
                var rowId=$("#jhdRowId").val();
                var fEndDate="";
                var i = 0;
                if($(ob).attr('checked')){
                    if(rowId==1){
                    	
                        fIncDecIntervalMinute=$("#jhdRowId").parent().parent().find("#txtIncDecIntervalMin_0").val();
                        if(fIncDecIntervalMinute=="" || fIncDecIntervalMinute==null){
                        	$(ob).attr('checked',false);
                        	jAlert(varenterincdecintervalminute);
                            return false;
                        }
                        $('[name="txtIncDecIntervalMin"]').each(function(){
                        	$(this).val(fIncDecIntervalMinute);
                        	reservePriceChk(i,this);
							i++;                        	
                        });     
                    }
                }
            }
         // Check All end date
            function checkEndDate(ob,cnt)
            {
            	$(ob).parent().find('.error'+$(ob).attr('id')).remove();
            	var startDate =  $("#txtStartDate_"+cnt).val();
            	var endDate = $("#txtEndDate_"+cnt).val();
            	if(startDate != '' && endDate != ''){
            		 var newStartDate = null;
            		 var newEndDate = null;
            		 if(dateFmt == 'DD MMM YYYY'){
            			 var set_date = startDate.split(' ');
             			 var dd = set_date[0];
             			 var mm = getMonthValuefromName(set_date[1]);
             			 var yy = set_date[2];
             			 var set_time = set_date[3].split(':'); 
             			
             			newStartDate = new Date(yy, mm-1,dd  , set_time[0],set_time[1],00);
             			
             			var set_e_date = endDate.split(' ');
            			 var edd = set_e_date[0];
            			 var emm = getMonthValuefromName(set_e_date[1]);
            			 var eyy = set_e_date[2];
            			 var set_e_time = set_e_date[3].split(':'); 
            			
            			 newEndDate = new Date(eyy, emm-1,edd  , set_e_time[0],set_e_time[1],00);
             			
            		 }else{
            			 var set_date = startDate.split(' ');
		        		 var set_time = set_date[1].split(':');
			        	 var set_start = set_date[0].split('/');
			        	 
			        	 
			        	 if(dateFmt == 'DD/MM/YYYY'){
			        		 newStartDate = new Date(set_start[2], set_start[1]-1,set_start[0] , set_time[0],set_time[1],00);
				       	 }else if(dateFmt == 'MM/DD/YYYY'){
				       		newStartDate = new Date(set_start[2], set_start[0]-1,set_start[1]  , set_time[0],set_time[1],00);
				       	 }
            			 var set_e_date = endDate.split(' ');
		        		 var set_e_time = set_e_date[1].split(':');
			        	 var set_e_start = set_e_date[0].split('/');
			        	 
			        	 
			        	 if(dateFmt == 'DD/MM/YYYY'){
			        		 newEndDate = new Date(set_e_start[2], set_e_start[1]-1,set_e_start[0]  , set_e_time[0],set_e_time[1],00);
				       	 }else if(dateFmt == 'MM/DD/YYYY'){
				       		newEndDate = new Date(set_e_start[2], set_e_start[0]-1,set_e_start[1]  , set_e_time[0],set_e_time[1],00);
				       	 }
            		 } 
	            	if(newStartDate >= newEndDate){
	            		if($(ob).parent().find('.error'+$(ob).attr('id')).length !=0 || $(ob).parent().find('.err'+$(ob).attr('id')).length !=0){
		        			 return false;
		        		 }else{
		        			 $(ob).parent().append("<div class='error"+$(ob).attr('id')+"' style='color:red;'>"+varendDategreaterStartDate+"</div>");
		        			 return false;
		        			 
		        		 }
	            	}
            	}
            	var incDevIntervalMin = $("#txtIncDecIntervalMin_"+cnt).val();
            	 var interval="";
            	 var incDecVal=$("#txtIncDecVal_"+cnt).val();
               	 if($("#txtStartPrice_"+cnt).val() != '' && incDecVal != ''){
               		interval = ($("#txtStartPrice_"+cnt).val())/incDecVal;	
               	 }
               	 interval = interval * incDevIntervalMin; 
                 
            	if(startDate != '' && endDate != '' && incDevIntervalMin != ''){
            		
            		 var newStartDate = null;
            		 var newEndDate = null;
            		 if(dateFmt == 'DD MMM YYYY'){
            			 var set_date = startDate.split(' ');
             			 var dd = set_date[0];
             			 var mm = getMonthValuefromName(set_date[1]);
             			 var yy = set_date[2];
             			 var set_time = set_date[3].split(':'); 
             			
             			newStartDate = new Date(yy, mm-1,dd  , set_time[0],set_time[1],00);
             			
             			var set_e_date = endDate.split(' ');
            			 var edd = set_e_date[0];
            			 var emm = getMonthValuefromName(set_e_date[1]);
            			 var eyy = set_e_date[2];
            			 var set_e_time = set_e_date[3].split(':'); 
            			
            			 newEndDate = new Date(eyy, emm-1,edd  , set_e_time[0],set_e_time[1],00);
             			
            		 }else{
            			 var set_date = startDate.split(' ');
		        		 var set_time = set_date[1].split(':');
			        	 var set_start = set_date[0].split('/');
			        	 
			        	 
			        	 if(dateFmt == 'DD/MM/YYYY'){
			        		 newStartDate = new Date(set_start[2], set_start[1]-1,set_start[0] , set_time[0],set_time[1],00);
				       	 }else if(dateFmt == 'MM/DD/YYYY'){
				       		newStartDate = new Date(set_start[2], set_start[0]-1,set_start[1]  , set_time[0],set_time[1],00);
				       	 }
            			 var set_e_date = endDate.split(' ');
		        		 var set_e_time = set_e_date[1].split(':');
			        	 var set_e_start = set_e_date[0].split('/');
			        	 
			        	 
			        	 if(dateFmt == 'DD/MM/YYYY'){
			        		 newEndDate = new Date(set_e_start[2], set_e_start[1]-1,set_e_start[0]  , set_e_time[0],set_e_time[1],00);
				       	 }else if(dateFmt == 'MM/DD/YYYY'){
				       		newEndDate = new Date(set_e_start[2], set_e_start[0]-1,set_e_start[1]  , set_e_time[0],set_e_time[1],00);
				       	 }
            		 } 
		        	 var diffMs = (newEndDate - newStartDate);
		        	 var diffDays = parseInt(diffMs / 86400000);
		        	 var diffHrs = parseInt((diffMs % 86400000) / 3600000);
		        	 var diffMins = parseInt(((diffMs % 86400000) % 3600000) / 60000);
		        	
		        	 /* if(set_time[0] >set_e_time[0]){
						diffDays = diffDays-1;
					} 
					if(set_time[1] > set_e_time[1]){
						diffHrs  = diffHrs-1;
					} */
					var totalDiffInMinutes = (diffDays*24*60)+(diffHrs*60)+diffMins;
		        	  if(diffMins % incDevIntervalMin != 0){
		        		 if($(ob).parent().find('.error'+$(ob).attr('id')).length !=0 || $(ob).parent().find('.err'+$(ob).attr('id')).length !=0){
		        			 return false;
		        		 }else{
		        			 $(ob).parent().append("<div class='error"+$(ob).attr('id')+"' style='color:red;'>"+varaucenddatevalidate+"</div>");
		        			 return false;
		        			 
		        		 }
		        	 }else{
		        		 if(totalDiffInMinutes > interval){
			        		 if($(ob).parent().find('.error'+$(ob).attr('id')).length !=0 || $(ob).parent().find('.err'+$(ob).attr('id')).length !=0){
			        			 return false;
			        		 }else{
			        			 newStartDate.setMinutes(newStartDate.getMinutes()+interval);
			        			 if(eventtype == varforwardclockauction){
			        				 var enddateless = newenddateless;
			        				 enddateless = enddateless.replace('{0}',myDateFormatter(newStartDate));
			        				 $(ob).parent().append("<div class='error"+$(ob).attr('id')+"' style='color:red;'>"+enddateless+"</div>");
			        				 //$(ob).parent().append("<div class='error"+$(ob).attr('id')+"' style='color:red;'>End Date and time should not be greater then "+myDateFormatter(newStartDate)+" based on the start price and decrement value</div>");
				        			 return false;	 
			        			 }else{
			        				 return true;
			        			 }
			        			 
			        		 }
			        	 }else{
			        		 $(ob).parent().find('.error'+$(ob).attr('id')).remove();
			        		 return true;
			        	 }
		        	 }
		        	 	 
            	}
            	
            }
         // Change into client date formate
            function myDateFormatter (d) {
            	var day = d.getDate();
                var month = d.getMonth();
                var year = d.getFullYear();
                if (day < 10) {
                    day = "0" + day;
                }
                month = parseInt(month+1);
                if (month < 10) {
                    month = "0" + month;
                }
                var hours = d.getHours();
   			 	var minutes = d.getMinutes();
   			 	if (hours < 10){
   			 		hours = "0"+hours;
   			 	}if(minutes < 10){
   			 		minutes = "0"+minutes;
   			 	}
   			 	var date = "";
	   			 if(dateFmt == 'DD/MM/YYYY'){
	                 date = day + "/" + month + "/" + year + " "+hours+":"+minutes;
	   			 }else if(dateFmt == 'MM/DD/YYYY'){
	   				date = month + "/" + day + "/" + year + " "+hours+":"+minutes;
	   			 }else{
	   				date = day + " " + getMonthNameFromValue(month) + " " + year + " "+hours+":"+minutes;
	   			 }
                

                return date;
            }; 
            //Calculate end date in reserve price check yes
            function calEndDate(i)
            {
            		var startDate =  $("#txtStartDate_"+i).val();
            	    //alert(startDate);
                    var incDevIntervalMin = $("#txtIncDecIntervalMin_"+i).val();
                    console.log(incDevIntervalMin);
                    var interval="";
                    var incDecVal=$("#txtIncDecVal_"+i).val();
                    if(eventtype==varforwardclockauction){
                    	if($("#txtStartPrice_"+i).val() != '' && incDecVal != ''){
                    		interval = ($("#txtStartPrice_"+i).val()-$("#txtReservePrice_"+i).val()+parseInt(incDecVal))/incDecVal;	
                    	}
                    }else if(eventtype==varreverseclockauction){
                    	if($("#txtReservePrice_"+i).val()!= '' && incDecVal != ''){
                    		interval = ($("#txtReservePrice_"+i).val()-$("#txtStartPrice_"+i).val()+parseInt(incDecVal))/incDecVal;	
                    	}
                    }
                    console.log(interval);
                    if(interval != ''){
                    	incDevIntervalMin = interval * incDevIntervalMin;	
                    }
                    
                   
                    //alert(incDevIntervalMin);
                    if(startDate != '' && incDevIntervalMin != '' &&  incDevIntervalMin != 0){
                    	 var newDate = null;
                    	 var mon;
                    	 var dat;
                    	 if(dateFmt == 'DD MMM YYYY'){
                    		 var set_date = startDate.split(' ');
                 			 var dd = set_date[0];
                 			 var mm = getMonthValuefromName(set_date[1]);
                 			 var yy = set_date[2];
                 			 var set_time = set_date[3].split(':'); 
                 			
                 			newDate = new Date(yy, mm-1,dd  , set_time[0],set_time[1],00);
	    	        		mon = mm; 
	    	        		dat = dd;
                    	 }else{
                    		 var set_date = startDate.split(' ');
	    	        		 var set_time = set_date[1].split(':');
	    		        	 var set_start = set_date[0].split('/');
	    		        	 
	    		        	 
	    		        	 if(dateFmt == 'DD/MM/YYYY'){
	    		        		 newDate = new Date(set_start[2], set_start[1]-1,set_start[0]  , set_time[0],set_time[1],00);
	    			       	 }else if(dateFmt == 'MM/DD/YYYY'){
	    			       		newDate = new Date(set_start[2], set_start[0]-1,set_start[1]  , set_time[0],set_time[1],00);
	    			       	 }
	    		        	 mon = set_start[1];
	    		        	 dat = set_start[0];
                    	 }
    		        	 var duration = incDevIntervalMin;
    		        	 var minutes = newDate.getMinutes();
    		        	/*  console.log(newDate,1); */
    		        	//console.log(newDate.getHours());
    		        	 newDate.setMinutes(parseInt(minutes)+parseInt(duration));
    		        	//console.log(newDate.getHours());
    		        	/*  console.log(newDate,2); */
    		        	
    		        	 var month = parseInt(newDate.getMonth()+1);
    		        	 month = month.toString().length == 1?"0"+month.toString():month.toString();
    		        	 var day = newDate.getDate().toString().length == 1 ? "0"+newDate.getDate().toString():newDate.getDate().toString();
    		        	 var year = newDate.getFullYear().toString();
    		        	 var hour = newDate.getHours().toString().length == 1?"0"+newDate.getHours().toString():newDate.getHours().toString();	 
    		        	 var  min = newDate.getMinutes().toString().length == 1?"0"+newDate.getMinutes().toString():newDate.getMinutes().toString();
    		        	 //alert(month);
    		        	 if(month==00){
    		        		 month=12;
    		        		 year = year-1;
    		        	 }
    		        	 var newMonth = parseInt(mon)+1;
    		        	 var checkMonth = newMonth.toString().length == 1?"0"+newMonth.toString():newMonth.toString();
    		        	 if(month==02){
    		        		if(year%4==0){
    		        			if(day==30){
    		        				month=(parseInt(month)+1);
    			        			day=01;
    		        			}
    		        		}
    		        		else{
    		        			if(day==29){
    		        				month=(parseInt(month)+1);
    			        			day=01;
    		        			}
    		        		}
    		        	 }	 
    		        	else if(mon==01 || mon==03 || mon==05 || mon==07 || mon==08 || mon==10 || mon==12){
    		        		if(dat==30){
    		        			if(month==checkMonth){
    		        				month=set_start[1];
    		        				day=31;
    		        			}
    		        		}
    		        		else if(dat==31){
    		        			day=01;
    		        		}
    		        	}
    		        	 if(dateFmt == 'DD/MM/YYYY'){
    		        		 $("#txtEndDate_"+i).val(day+"/"+month+"/"+year +" " +hour +":"+min);
    			       	 }else if(dateFmt == 'MM/DD/YYYY'){
    			       		 $("#txtEndDate_"+i).val(month+"/"+day+"/"+year +" " +hour +":"+min);
    			        }else{
    			        	$("#txtEndDate_"+i).val(day+" "+getMonthNameFromValue(month)+" "+year +" " +hour +":"+min);
    			        } 
    		           } else {
    	        		 $("#txtEndDate_"+i).val("");
    	        		 
    	        	 }
            }
            
           //Check All Start Date
            function checkSameStartPrice(ob){
                var rowId=$("#jhdRowId").val();
                // alert("rowId "+rowId);
                var fStartPrice="";
                var i = 0;
                if($(ob).attr('checked')){
                    if(rowId==1){
                        fStartPrice=$("#jhdRowId").parent().parent().find("#txtStartPrice_0").val();
                        if(fStartPrice=="" || fStartPrice==null){
                        	$(ob).attr('checked',false);
                            jAlert(varenterstartprice);
                            return false;
                        }
                        $('[name="txtStartPrice"]').each(function(){
                            $(this).val(fStartPrice);
                            if(isReservePriceReq==1){
                        		calEndDate(i);
	                        }else{
	                        	var edDate = document.getElementById("txtEndDate_"+i);	
	                        	checkEndDate(edDate,i);
	                        }
							i++;
                        });     
                    }
                }
            }
            // Check All Inc dec value
            function checkSameIncDec(ob){
                var rowId=$("#jhdRowId").val();
                // alert("rowId "+rowId);
                var fIncDecVal="";
                var i=0;
                if($(ob).attr('checked')){
                    if(rowId==1){
                    	fIncDecVal=$("#jhdRowId").parent().parent().find("#txtIncDecVal_0").val();
                        if(fIncDecVal=="" || fIncDecVal==null){
                        	$(ob).attr('checked',false);
                            jAlert(varenterfirstitemvalue);
                            return false;
                        }
                        $('[name="txtIncDecVal"]').each(function(){
                        	$(this).val(fIncDecVal);
                        	if(isReservePriceReq==1){
                        		calEndDate(i);
	                        }else{
	                        	var edDate = document.getElementById("txtEndDate_"+i);	
	                        	checkEndDate(edDate,i);
	                        }
							i++;
                        });     
                    }
                }
            }
            // Check ALl reserve price
            function checkSameReservePrice(ob){
                var rowId=$("#jhdRowId").val();
                // alert("rowId "+rowId);
                var fReservePrice="";
                var i=0;
                if($(ob).attr('checked')){
                    if(rowId==1){
                    	fReservePrice=$("#jhdRowId").parent().parent().find("#txtReservePrice_0").val();
                        if(fReservePrice=="" || fReservePrice==null){
                        	$(ob).attr('checked',false);
                            jAlert(varenterfirstitemvalue);
                            return false;
                        }
                        $('[name="txtReservePrice"]').each(function(){
                            $(this).val(fReservePrice);
                            if(isReservePriceReq==1){
                        		calEndDate(i);
	                        }else{
	                        	var edDate = document.getElementById("txtEndDate_"+i);	
	                        	checkEndDate(edDate,i);
	                        }
							i++;
                        });     
                    }
                }
            }
            
            //Reserve price check whether it is greater then start price and multiple of incdec amout
           function reservePriceChk(i,ob){
        	   var vbool = true;
        	   $(ob).parent().find('.err'+$(ob).attr('id')).remove();
        	   var intervalMin = $(ob).val();
        	   if(intervalMin < 60){
        		   if(60 % parseInt(intervalMin) != 0){
        			   if($(ob).parent().find('.err'+$(ob).attr('id')).length !=0){
		        			 vbool =  false;
		        		 }else{
		        			  $(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varConfIntervalValidate+"</div>");
		        			  vbool = false;	 
		        		 }
        		   }else{
        			   
        			   	var startDate = $("#txtStartDate_"+i);
        			     checkStartDate(startDate,i);
        			     vbool = true;
		           }
        	   }else{
        		   if(parseInt(intervalMin) % 60 != 0 ){
        			   if($(ob).parent().find('.err'+$(ob).attr('id')).length !=0){
        				   vbool = false;
		        		 }else{
		        			  $(ob).parent().append("<div class='err"+$(ob).attr('id')+"' style='color:red;'>"+varConfIntervalValidate+"</div>");
		        			  vbool = false;	 
		        		 }		   
        		   }else{
        			   vbool = true;
	           	   }
        	 }
        	   
        	   
        	   if(isReservePriceReq==1){
               		calEndDate(i);
               	}else{
               		var edDate = document.getElementById("txtEndDate_"+i);	
               		checkEndDate(edDate,i);
               	}
        	   return vbool;
           }  
           
           //Check All Start Date
           function checkStartDate(ob,i){
        	   var vbool = true;
        	   $(ob).parent().find('.error'+$(ob).attr('id')).remove();
        	   var startDate = $(ob).val();
        	   var intervalMin = $("#txtIncDecIntervalMin_"+i).val();
        	   if(intervalMin == ""){
        		   intervalMin = 1;
        	   }
        	   
        	   var startDt = null;
        	   if(startDate != ''){
        		if(dateFmt == 'DD MMM YYYY'){
        			var set_date = startDate.split(' ');
        			var dd = set_date[0];
        			var mm = getMonthValuefromName(set_date[1]);
        			var yy = set_date[2];
        			var set_time = set_date[3].split(':'); 
        			
        			startDt = new Date(yy, mm-1,dd  , set_time[0],set_time[1],00);
        		}else{
        		   
					var set_date = startDate.split(' ');
					var set_time = set_date[1].split(':');
					var set_start = set_date[0].split('/');
					 
					if(dateFmt == 'DD/MM/YYYY'){
							startDt = new Date(set_start[2], set_start[1]-1,set_start[0]  , set_time[0],set_time[1],00);
					}else if(dateFmt == 'MM/DD/YYYY'){
							startDt = new Date(set_start[2], set_start[0]-1,set_start[1]  , set_time[0],set_time[1],00);
					}
        		}
        	  //var startDt  =new Date(startDate);
			  
			  //console.log(startDt);
			  //console.log(parseInt(intervalMin));
			  //console.log("condi -" + startDt.getMinutes() % parseInt(intervalMin));
			  
        	   if(startDt.getMinutes() % parseInt(intervalMin) != 0){
        		   if($(ob).parent().find('.err'+$(ob).attr('id')).length !=0 || $(ob).parent().find('.error'+$(ob).attr('id')).length !=0){
        			   vbool = false;
	        		 }else{
	        			  $(ob).parent().append("<div class='error"+$(ob).attr('id')+"' style='color:red;'>"+varConfStartDateValidate+"</div>");
	        			  vbool = false;
		        	 }
        		   
        	   }else{
        		   vbool = true;
        	   } 
        	  
        	  
        	   if(isReservePriceReq==1){
              		calEndDate(i);
              	}else{
              		var edDate = document.getElementById("txtEndDate_"+i);	
              		checkEndDate(edDate,i);
              	}
        	   }
        	  return vbool; 
           }
 // get month value from name   
 function getMonthValuefromName(name){
	 var monthValue;
	 switch(name){
	 	case 'Jan' :
	 		monthValue = 1
	 		break;
	 	case 'Feb' :
	 		monthValue = 2
	 		break;
	 	case 'Mar' :
	 		monthValue = 3
	 		break;
	 	case 'Apr' :
	 		monthValue = 4
	 		break;
	 	case 'May' :
	 		monthValue = 5
	 		break;
	 	case 'Jun' :
	 		monthValue = 6
	 		break;
	 	case 'Jul' :
	 		monthValue = 7
	 		break;
	 	case 'Aug' :
	 		monthValue = 8
	 		break;
	 	case 'Sep' :
	 		monthValue = 9
	 		break;
	 	case 'Oct' :
	 		monthValue = 10
	 		break;
	 	case 'Nov' :
	 		monthValue = 11
	 		break;
	 	case 'Dec' :
	 		monthValue = 12
	 		break;
	 	
	 }
	 return monthValue;
	 
	 
 }   
 // get month name from value
 function getMonthNameFromValue(value){
	 var monthName;
	 switch(value){
	 	case '01' :
	 		monthName = 'Jan'
	 		break;
	 	case '02' :
	 		monthName = 'Feb'
	 		break;
	 	case '03' :
	 		monthName = 'Mar'
	 		break;
	 	case '04' :
	 		monthName = 'Apr'
	 		break;
	 	case '05' :
	 		monthName = 'May'
	 		break;
	 	case '06' :
	 		monthName = 'Jun'
	 		break;
	 	case '07' :
	 		monthName = 'Jul'
	 		break;
	 	case '08' :
	 		monthName = 'Aug'
	 		break;
	 	case '09' :
	 		monthName = 'Sep'
	 		break;
	 	case '10' :
	 		monthName = 'Oct'
	 		break;
	 	case '11' :
	 		monthName = 'Nov'
	 		break;
	 	case '12' :
	 		monthName = 'Dec'
	 		break;
	 }
	 return monthName;
	 
 }
           $(document).ready(function() { 
           		
           	/*** Add Condition for Sequence Auction if Sequence than only first item have input start date ,end date and itemwise cretain date
           	remaing default set 01/01/1900 00:00:00 **/
           	
           	$('#bottom').on('scroll', function () {
           	    $('#top').scrollLeft($(this).scrollLeft());
           	});
           	
           	
           });
           
           
           function excelUrl()
           {
        	   
        	   var count=0;
        	   var vbool = true;
	             $("input[name='chkConfigParam']").each(function () {
		        	   if($(this).attr("checked")){
		        		   count++;
		        	   }
		         });
	             if(count==0){
	            	 jAlert("Please Select at least one parameter","Configure Parameter");
	            	 vbool = false;
	        	 }
	             
	             
        	   var hdColumnNames="";
        	   $("input[name='chkConfigParam']").each( function () {
        		   if($(this).attr('checked'))
        			   {
        			   hdColumnNames = hdColumnNames + $(this).val() +"@@"; 
        	   		}
        		});
              
        	   
        	   
        	   var mapForm = document.createElement("form");
        	   mapForm.method = "POST";
        	   mapForm.action = contextPath+"/eauction/auctioneer/genexcelforconfig";
        	   
        	   var mapInput1 = document.createElement("input");
        	   mapInput1.type = "hidden";
        	   mapInput1.name = "jhdColumnName";
        	   mapInput1.value = hdColumnNames;

        	   var mapInput2 = document.createElement("input");
        	   mapInput2.type = "hidden";
        	   mapInput2.name = "jhdAuctionId";
        	   mapInput2.value = auctionId;
        	   
        	   // Add the input to the form
        	   mapForm.appendChild(mapInput1);
        	   mapForm.appendChild(mapInput2);

        	   // Add the form to dom
        	   document.body.appendChild(mapForm);

        	   // Just submit
        	   if(vbool)
        		  {
        		   mapForm.submit(); 
        		  } 
        	   // Remove mapForm and input
        	   document.body.removeChild(mapForm);
        	  
        	  
        	   
           }

     
           
