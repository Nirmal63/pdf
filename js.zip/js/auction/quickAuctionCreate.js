function GetCal(txtname, controlname, datetype) {
    if (datetype == 'datetime') {
        var date;
        new Calendar({
            inputField : txtname,
            trigger : controlname,
            dateFormat : DATETIMEFORMATE_CALENDAR,
            showTime : true,
            onSelect : function() {
                date = this.selection.get()
                date = Calendar.intToDate(date);
                date = Calendar.printDate(date, DATETIMEFORMATE_CALENDAR);
                this.hide();
                if (txtname == 'txtdob') {
                    RndEndDt();
                }

                document.getElementById(txtname).focus();
            }
        });
    }
    else {
        new Calendar({
            inputField : txtname,
            trigger : controlname,
            showTime : false,
            dateFormat : DATEFORMATE_CALENDAR,
            onSelect : function() {
                var date = Calendar.intToDate(this.selection.get());
                LEFT_CAL.args.min = date;
                LEFT_CAL.redraw();
                this.hide();
            }
        });
    }
    var LEFT_CAL = Calendar.setup({
        weekNumbers : false
    })
}
var defaultKeyArr = new Array();
defaultKeyArr.push(9);// Tab
defaultKeyArr.push(13);// enter
defaultKeyArr.push(16);// shift
defaultKeyArr.push(17);// ctrl
defaultKeyArr.push(18);// atl
defaultKeyArr.push(19);// pause/break
defaultKeyArr.push(20);// caps loks
defaultKeyArr.push(27);// escape
defaultKeyArr.push(33);// page up
defaultKeyArr.push(34);// page down
defaultKeyArr.push(35);// end
defaultKeyArr.push(36);// home
defaultKeyArr.push(37);// left arrow
defaultKeyArr.push(38);// up arrow
defaultKeyArr.push(39);// right arrow
defaultKeyArr.push(40);// down arrow
defaultKeyArr.push(45);// insert
defaultKeyArr.push(46);// delete
defaultKeyArr.push(91);// left window key
defaultKeyArr.push(92);// right window key
defaultKeyArr.push(93);// select key
defaultKeyArr.push(112);// f1
defaultKeyArr.push(113);//f2 
defaultKeyArr.push(114);//f3
defaultKeyArr.push(115);//f4
defaultKeyArr.push(116);//f5
defaultKeyArr.push(117);//f6
defaultKeyArr.push(118);//f7
defaultKeyArr.push(119);//f8
defaultKeyArr.push(120);//f9
defaultKeyArr.push(121);//f10
defaultKeyArr.push(122);//f11
defaultKeyArr.push(123);//f12
defaultKeyArr.push(144);//num lock
defaultKeyArr.push(145);//scroll lock
defaultKeyArr.push(186);// semi colon
defaultKeyArr.push(187);//qqual sign

function search(event,nTh) {			
    var temp = "";
//    var val = $("#txtAucKeyword").val();
    var val = $(".txt-keyword_"+nTh).val();
    var myString = $.trim(val.substr(val.lastIndexOf(",") + 1));
    if(myString != null && myString != "" && myString.length >= 3){
        var availableTags= "[";
        if ($(".txt-keyword_"+nTh).val() != "") {
        	if(avoideDefaultKey(event.keyCode))
        	{
        		return true;
        	} 
            $(".final-result_"+nTh).show(); //show div block that contains on result
            $(".loading").show(); // show loading text while getting result
	
            //call web searvice
            $.ajax({ 
                type: "POST",
                url: contextPath+"/ajaxcall/getkeywordsuggestion", //function that in web service
                data: {
                    text : myString
                },// passing value of txtSearch input
                dataType: "json",
                async: true,
                success: function(response) {
                    $(".list-suggestion_"+nTh).html(""); // clear previous result
		                        
                    if(response != null && response != "") {
                        var html = '<select onclick="return selectText($(this).val(),'+nTh+');" style="width: 100%; height: 100%;" multiple="multiple" >';
		
                        //looping in 'result' array to get data and fill it inside ".record" div as html
                        $.each(response, function(index, res) {
                        	if(index != 0){
                        		html += '<option  value="' + res.keyword + '" class="keyword_option" onmouseover="$(this).attr(\'style\', \'background-color: white; border: 1px solid black !important;\');" onmouseout="$(this).attr(\'style\', \'\');">' + res.keyword + '</option>';
                        	}else{
                        		html += '<option  selected="selected" value="' + res.keyword + '" class="keyword_option" onmouseover="$(this).attr(\'style\', \'background-color: white; border: 1px solid black !important;\');" onmouseout="$(this).attr(\'style\', \'\');">' + res.keyword + '</option>';
                        	}
                        });
									
                        html += '</select>';
										
                        $(".list-suggestion_"+nTh).html(html);
                    //hide loading div when the data was got
                    } else {
                        $(".divResult").hide();
                    }
                    $(".loading").hide();
                },
                error: function(msg) {
                /* $(".record").html(msg.d); */
                }
	
            });
	
        }
        else {
            $(".divResult").hide(); //hide div that contains result when the input text is empty
            $(".list-suggestion_"+nTh).html(""); //also loading text when the input text is empty
        }
    }
}
function avoideDefaultKey(key)
{
	    if($.inArray(key,defaultKeyArr) != -1)
	    {   return true;
	    }else{
	    	return false;
	    }
}
function selectText(val,nTh) {
    var terms = $(".txt-keyword_"+nTh).val().split(/,\s*/);
    terms.pop();
    terms.push(val);
    terms.push("");
    $(".txt-keyword_"+nTh).val(terms.join( ", " ));
                
    /*var textArea = document.getElementById("txtAucKeyword");
    textArea.selectionStart = textArea.selectionEnd = textArea.value.length;
    textArea.focus();*/
    $(".txt-keyword_"+nTh).focus();
    $(".divResult").hide();
                
    return false;
}
function showHideKeyword()
{	
	//if(isCategoryAllow == 0 || $('input[id=rdAccess]:checked').val() == 1){ // if access type is limited
		$("#keywordTR").show();
		$("#txtAucKeyword").attr("tovalid","true");
	/*}else if(isCategoryAllow == 1 && $("#selBrdMode").val() == one)// Category allow and brd mode is auto
	{	$("#keywordTR").show();
		$("#txtaAucKeyword").attr("tovalid","true");
	}else if(isCategoryAllow == 1 && ($("#selBrdMode").val() == two || $("#selBrdMode").val() == zero))// Category allow and brd mode is manual
	{
		$("#keywordTR").hide();
		$("#txtaAucKeyword").attr("tovalid","false");
	}else{
		$("#keywordTR").show();
		$("#txtaAucKeyword").attr("tovalid","true");
	}*/
}
function showHideKeywordAsDefault() ////CR: 18430
{
	$("#keywordTR").show();
	$("#txtAucKeyword").attr("tovalid","true");
	/*if($("#selBrdMode").val() == undefined ) // If brd is hide from default configuration.
		{
			if(isCategoryAllow == 0 || defBrdModeVal == '1') // if default value of brd is auto or category is not allow then show keyword. 
				{
					$("#keywordTR").show();
					$("#txtaAucKeyword").attr("tovalid","true");
				}
			else{
					$("#keywordTR").hide();
					$("#txtaAucKeyword").attr("tovalid","false");
				}
		}*/
}
/**
 * To add item to bidding form
 */
function addItemToBiddingForm(){
			
	$("#biddingForms tr:last-child").parent().append('<tr id="item_1" class="trClass"><td class="a-center srno"><label>1</label></td>'+
			'<td><input id="txtItemName" type="text" title="Item Description" onblur="validateTxtComp(this)" tovalid="true" validarr="required" name="txtItemName"></td>' +
			'<td><input type="text" title="Quantity" onblur="javascript:{if(validateTxtComp(this)){numeric(this)}}" tovalid="true" validarr="required" name="txtQty" id="txtQty"></td>'+
			'<td><input type="text" title="Unit of Measurement" onblur="validateTxtComp(this)" tovalid="true" validarr="required" name="txtUom" id="txtUom"></td>'+
			'<td><input type="text" title="Start price" onblur="validateTxtComp(this)" tovalid="true" validarr="required@@lengthForNum:15@@numanduptodecimal:@@nonzero" name="txtStartPrice" id="txtStartPrice">'+
				'<form:errors path="txtStartPrice" cssClass="validationMsg clearfix"/></td>'+
			'<td><input type="text" title="Decrement" onblur="validateTxtComp(this)" tovalid="true" validarr="required@@lengthForNum:15@@numanduptodecimal:@@nonzero" name="txtIncDecValue" id="txtIncDecValue"></td>'+
			'<td><input type="text" style="width:293px;min-height:34px !important; " class="txtarea_vertical_scroll txt-keyword_1" onkeyup="return search(event,1);" onfocus="setBiddingFormVisible();" autocomplete="off" title="Product/service/work keywords" onblur="javascript:{if(validateTxtComp(this)){setBiddingFormHidden();}else{setBiddingFormHidden();}}" tovalid="true" validarr="required@@length:0,1000@@commonkeyword" name="txtAucKeyword" id="txtAucKeyword">'+
					'<div class="divResult" style="display: none;">'+
						'<div class="loading m-top2">Loading..</div>'+
							'<div class="record no-border list-suggestion_1" style="height: 200px; overflow-y: hidden; position: absolute; z-index: 9999; width:293px;"></div>'+
							'</div><form:errors path="txtAucKeyword" cssClass="validationMsg clearfix"/>'+
			'</td>'+
			'<td class="v-a-middle"><a href="javascript:void(0);" onclick="removeItemFromBiddingForm(this)">Remove</a> </td>'+				
			'</tr>');
	var srno = 1;
	$(".srno").each(function() {
        	$(this).html('<label>'+srno+'</label>');
        	srno++;
		});
	//txtarea_vertical_scroll
	srno = 1;
	$(".txtarea_vertical_scroll").each(function() {
		$(this).attr("class","");
		$(this).attr("class","txtarea_vertical_scroll txt-keyword_"+srno);
		$(this).attr("onkeyup","return search(event,"+srno+");");
    	srno++;
	});
	//list-suggestion_1 record
	srno = 1;
	$(".record").each(function() {
		$(this).attr("class","");
		$(this).attr("class","record no-border list-suggestion_"+srno);
    	srno++;
	});
	//divResult
	srno = 1;
	$(".divResult").each(function() {
		$(this).attr("class","");
		$(this).attr("class","divResult final-result_"+srno);
    	srno++;
	});
	srno = 1;
	$(".trClass").each(function() {
    	$(this).attr("id","item_"+srno);
    	srno++;
	});
}
/**
 * To remove item from bidding form.
 * @param currentItem
 */
function removeItemFromBiddingForm(currentItem){
	 var noOfRows = 0;
	 $(".srno").each(function() {
		 noOfRows++;
	 });
	 if(noOfRows!=0 && noOfRows>1){
		 $(currentItem).closest('tr').remove();
	 }
	 else{
		console.log("Single Row - ",noOfRows);
	 }
	 var srno = 1;
	 $(".srno").each(function() {
	        $(this).html('<label>'+srno+'</label>');
	        srno++;
	 });
	//txtarea_vertical_scroll
	srno = 1;
	$(".txtarea_vertical_scroll").each(function() {
		$(this).attr("class","");
		$(this).attr("class","txtarea_vertical_scroll txt-keyword_"+srno);
		$(this).attr("onkeyup","return search(event,"+srno+");");
    	srno++;
	});
	//list-suggestion_1 record
	srno = 1;
	$(".record").each(function() {
		$(this).attr("class","");
		$(this).attr("class","record no-border list-suggestion_"+srno);
    	srno++;
	});
	//divResult
	srno = 1;
	$(".divResult").each(function() {
		$(this).attr("class","");
		$(this).attr("class","divResult final-result_"+srno);
    	srno++;
	});
	srno = 1;
	 $(".trClass").each(function() {
	   	$(this).attr("id","item_"+srno);
	   	srno++;
	});
}
function setBiddingFormVisible(){
	$("#mainBiddingForm").addClass("o-visible");
	$("#subBiddingForm").addClass("o-visible");
}
function setBiddingFormHidden(){
	$("#mainBiddingForm").attr("class","");
	$("#mainBiddingForm").attr("class","panel panel-default");
	$("#subBiddingForm").attr("class","");
	$("#subBiddingForm").attr("class","panel-body");
}