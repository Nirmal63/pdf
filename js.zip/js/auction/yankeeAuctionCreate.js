/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * Author : Dhruvil Chokshi
 * Date : 07/05/2016
 */
function GetCal(txtname, controlname, datetype) {
    if (datetype == 'datetime') {
        var date;
        new Calendar({
            inputField : txtname,
            trigger : controlname,
            dateFormat : DATETIMEFORMATE_CALENDAR,
            showTime : true,
            onSelect : function() {
                date = this.selection.get()
                date = Calendar.intToDate(date);
                date = Calendar.printDate(date, DATETIMEFORMATE_CALENDAR);
                this.hide();
                if (txtname == 'txtdob') {
                    RndEndDt();
                }

                document.getElementById(txtname).focus();
            }
        });
    }
    else {
        new Calendar({
            inputField : txtname,
            trigger : controlname,
            showTime : false,
            dateFormat : DATEFORMATE_CALENDAR,
            onSelect : function() {
                var date = Calendar.intToDate(this.selection.get());
                LEFT_CAL.args.min = date;
                LEFT_CAL.redraw();
                this.hide();
            }
        });
    }
    var LEFT_CAL = Calendar.setup({
        weekNumbers : false
    })
}

function validate(){   
    var vbool = valOnSubmit();
    var parentDeptVal = $('#txtParentDepartment').combotree('tree').tree('getSelected');		// get selected node
    if(parentDeptVal ==null || parentDeptVal == ""){
        $("#errSpanParentDepartmentMsg").text(varSelDepartment);
        vbool = false;
    }else{
        $("#errSpanParentDepartmentMsg").text("");
    } 
    if(clientPaymentConfigure==2 && $("#selIsEmdReq").val()==1){
    	alert(emdNoteMsg);
    	vbool=false;
    }
    $('#txtBorrowerName').val(replaceQuotes($('#txtBorrowerName').val()));
    if(isCategoryAllow == 0 && vbool){
    	vbool = validateKeyword(vbool);
    }
    return vbool;
}
            
function checkAccess(ob)
{
    if($(ob).val() == '1')
    {
        if($('#rowLimitedAuc') != null){
        	if(hideMap['showBidderWiseForm'] == 'true'){
        		$('#rowLimitedAuc').hide();
        	}
        }
        
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        $('#trBrdMode').hide();
        $("#tdRestrictH1Bidder").hide();
        $('#rdAuctionResult_2').hide();
        $('#sprdAuctionResult_2').hide();
        $('#trIncDecRuleOn').hide();   
        if($('input[name=rdAuctionResult]:checked').val()==3){
            $('input:radio[name=rdAuctionResult]')[0].checked = true;
        } 
        $('#trForHomePage').hide();
    }
    else
    { 
        if($('#rowLimitedAuc') != null){
        	if(hideMap['showBidderWiseForm'] == 'true'){
        		$('#rowLimitedAuc').show();
        	}
        }
        if($('input[name=rdAuctionResult]:checked').val()==2 && $('input[name=rdIsAutoBidAllowed]:checked').val()==0 && $('input[name=rdAucType]:checked').val()==1 && hideMap['isRestrictH1Bidder'] == 'true'){
        	$("#tdRestrictH1Bidder").show();
        }else{
        	$("#tdRestrictH1Bidder").hide();
        }
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        $('#trBrdMode').show();
        $('#rdAuctionResult_2').show();
        $('#sprdAuctionResult_2').show();
        if($('input[name=rdAuctionResult]:checked').val()==3 && hideMap['incDecRuleOn']=='true'){
            $('#trIncDecRuleOn').show();  
        }else{
            $('#trIncDecRuleOn').hide();
        }
        $('#trForHomePage').show();
    }
    if($('input[name=rdAuctionResult]:checked').val()=='3' || $('input[id=rdBiddingType]:checked').val()==2 ){
        //$('#trIncDecType').hide();
    	$('#tdBiddingPriceType').hide();
        $('#IncDicMult').hide();
        var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';        
        $('#txtIncDecValue').attr('validarr', attrVal);
        $('#txtIncDecDuringExt').attr('validarr', attrVal);
        $('#txtSepIncDecValue').attr('validarr', attrVal);
    }else{
    	if(hideMap['incDecType']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
        	$('#tdBiddingPriceType').show();
        }
    	if(hideMap['incDecInMultiple']=='true' && $('input[id=rdIncDecType]:checked').val()==1 && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
        	$('#IncDicMult').show();
        }
        if($('input[id=rdIncDecType]:checked').val()==1){
            var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';            
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
            if(hideMap['incDecInMultiple']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                $('#IncDicMult').show();
            }
        }else{
            var attrVal='required@@lengthForNum:3@@percentage@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';            
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
        }
    }
   //Bug: 18430
    showHideKeyword();
    showHideKeywordAsDefault();
    showMobAutoBid();	// CR:20108 Nirav Raval
}

function changeIsMinQtyReq(ob){
	if($(ob).val() == '0'){
	//alert();
	bidderWiseQtyAllocationReq();
	}
}


function search(event) {			
    var temp = "";
    var val = $("#txtaAucKeyword").val();
    var myString = $.trim(val.substr(val.lastIndexOf(",") + 1));
    if(myString != null && myString != "" && myString.length >= 3){
        var availableTags= "[";
        if ($("#txtaAucKeyword").val() != "") {
        	if(avoideDefaultKey(event.keyCode))
        	{
        		return true;
        	}
            $(".divResult").show(); //show div block that contains on result
            $(".loading").show(); // show loading text while getting result
	
            //call web searvice
            $.ajax({ 
                type: "POST",
                url: contextPath+"/ajaxcall/getkeywordsuggestion", //function that in web service
                data: {
                    text : myString
                },// passing value of txtSearch input
                dataType: "json",
                async: true,
                success: function(response) {
                    $(".record").html(""); // clear previous result
		                        
                    if(response != null && response != "") {
                        var html = '<select onclick="return selectText($(this).val());" style="width: 100%; height: 100%;" multiple="multiple" >';
		
                        //looping in 'result' array to get data and fill it inside ".record" div as html
                        $.each(response, function(index, res) {
                        	if(index != 0){
                        		html += '<option  value="' + res.keyword + '" class="keyword_option" onmouseover="$(this).attr(\'style\', \'background-color: white; border: 1px solid black !important;\');" onmouseout="$(this).attr(\'style\', \'\');">' + res.keyword + '</option>';
                        	}else{
                        		html += '<option  selected="selected" value="' + res.keyword + '" class="keyword_option" onmouseover="$(this).attr(\'style\', \'background-color: white; border: 1px solid black !important;\');" onmouseout="$(this).attr(\'style\', \'\');">' + res.keyword + '</option>';
                        	}
                        });
									
                        html += '</select>';
										
                        $('.record').html(html);
                    //hide loading div when the data was got
                    } else {
                        $(".divResult").hide();
                    }
                    $(".loading").hide();
                },
                error: function(msg) {
                /* $(".record").html(msg.d); */
                }
	
            });
	
        }
        else {
            $(".divResult").hide(); //hide div that contains result when the input text is empty
            $(".record").html(""); //also loading text when the input text is empty
        }
    }
}
$(window).click(function() {
    $(".divResult").hide();
});
function selectText(val) {
    var terms = $("#txtaAucKeyword").val().split(/,\s*/);
    terms.pop();
    terms.push(val);
    terms.push("");
    $("#txtaAucKeyword").val(terms.join( "," ));
    var textArea = document.getElementById("txtaAucKeyword");
    textArea.selectionStart = textArea.selectionEnd = textArea.value.length;
    textArea.focus();
    $(".divResult").hide();
    $(".errtxtaAucKeyword").remove();
    return false;
}

function changeNegotiation(value){
	$("#hdIsNegotiationAllow").val(value);
}

var defaultValOfNegotiation;
function changeIncDec(ob){
	if($(ob).val() == '1') {
        $('#lblDecIncMultiple').text(varIncMultiple);
        $('#lblDecIncVal').text(varIncVal);
        //$('#lblIncDecTimes').text(varlblaucinctimes);
        $("#lblIncDecInTimes").text(varlblinctimes);
        $("#txtIncDecInTimes").attr('title',varlblinctimes);
        $('#lblDecIncVal').append('<span> *</span>');
        $('#txtIncDecValue').attr("title",varIncVal);
        $('#lblDecIncType').text(varIncType);
        $('#lblIncDecInPeriod').text(varIncInPeriod);
        $('#lblIncDecInPeriod').append('<span> * </span>');
        $('#txtTimeForIncDecToItem').attr("title",varIncInPeriod);
        $('#lblIncDecInPerReq').text(varIncRequire);
        $('#lblIncDecExt').text(varIncExt);
        $('#lblIncDecExt').append('<span> *</span>');
        $('#txtIncDecDuringExt').attr("title",varIncExt);
        $('#lblItemWiseIncDecValMsg').text(varItemWiseIncValMsg);
        $('#lblItemWiseTimeIncDecValMsg').text(varItemWiseIncPriceStartEndDateMsg);
        $('#lblSepDecIncVal').text(varspecincvalue);
        $('#lblSepDecIncVal').append('<span> * </span>');
        $('#txtSepIncDecValue').attr("title",varspecincvalue);
        $('#lblIncDecRulesOn').text(varincrules);
        $('#sprdFirstBidCond_1').text(varfirstBidCondAddIncVal);
        $('#sprdIncDecRules_0').text(incdecononeitem);
        $('#sprdIncDecRules_1').text(incdeconallitems);
        $('#trIsNegotiationAllow').hide();
        $('#lblRestrictL1H1Bidder').text(varrestrictH1bidder);
        $('#selIsNegotiationAllow option[value="2Js7vmaJbs8="]').prop('selected', true);
        if($('#lblDispL1H1Amt')!=null){
            $('#lblDispL1H1Amt').text(vardispH1amt);
        }
		var selIsEmdReq = $('#selIsEmdReq :selected').val();
		var selEmdPaymentMode = $('#selEmdPaymentMode :selected').val();
		if(selEmdPaymentMode=='1'){
			$('#tdEmdPayableAt').hide();
			$('#txtaEmdPayableAt').attr("tovalid","false");
		}
		else{
			$('#tdEmdPayableAt').show();
			$('#txtaEmdPayableAt').attr("tovalid","true");
		}
		if(selIsEmdReq=='1'){
			$('#tdEmdMode').show();
			$('#tdEmdFees').show();
			/*if(hideMap['biddingCapacity']=='true'){
				$('#tdBiddingCapacity').show();
				$('#txtBiddingCapacity').attr("tovalid","true");
			}else{
				$('#tdBiddingCapacity').hide();
				$('#txtBiddingCapacity').attr("tovalid","false");
			}*/
			$('#txtEmdAmt').attr("tovalid","true");
			if(hideMap['isBidCapacityReq'] == 'true'){
				$('#tdIsBidCapicityReq').show();
		        $('#selisBidCapacityReq').show();
			}else{
				$('#selisBidCapacityReq').val(map['isBidCapacityReq']);
			}			
			if($('#selisBidCapacityReq :selected').val() == 1){
				if(hideMap['biddingCapacity'] == 'true'){
					$("#tdBiddingCapacity").show();
					$('#txtBiddingCapacity').attr("tovalid","true");
				}else{
					$('#txtBiddingCapacity').attr("tovalid","false");
				}				
				$('#selEmdPaymentMode').prop("disabled", true);
				$('#selEmdPaymentMode').val(1);
				$('#tdEmdFees').hide();
				$('#txtEmdAmt').attr("tovalid","false");
				hideAutoBid(); //hide
				$("input[name=rdIsAutoBidAllowed][value=0]").prop('checked', true);
			}
		}else{
			$('#tdEmdMode').hide();
			$('#tdEmdFees').hide();
			$('#tdBiddingCapacity').hide();
			$('#txtBiddingCapacity').attr("tovalid","false");
			$('#txtEmdAmt').attr("tovalid","false");
			
		}
		if(hideMap['isEmdReq']=='true'){
			if(clientPaymentConfigure != 0 ){
				$('#trEmd').show();
			}else{
				$('#trEmd').hide();
				$('#txtEmdAmt').attr("tovalid","false");
			}
		}
		if($('input[name=rdAuctionResult]:checked').val()==1 && $("#selIsEmdReq").val()==1 && clientPaymentConfigure != 0){
			if(hideMap['isRestOfAucMoneyRequired'] == 'true'){
				$("#trRestOfAuctionMoney").show();
			}else{
				$("#trRestOfAuctionMoney").hide();
			}
			
		}else{
			$("#trRestOfAuctionMoney").hide();
		}
		
    }
    else{
        $('#lblDecIncMultiple').text(varDecMultiple);
        $('#lblDecIncVal').text(varDecVal);
        $('#lblIncDecTimes').text(varlblaucdectimes);
        $("#lblIncDecInTimes").text(varlbldectimes);
        $("#txtIncDecInTimes").attr('title',varlbldectimes);
        $('#lblDecIncVal').append('<span> *</span>');
        $('#lblIncDecRulesOn').text(vardecrules);
        $('#txtIncDecValue').attr("title",varDecVal);
        $('#lblDecIncType').text(varDecType);
        $('#lblIncDecInPeriod').text(varIDecInPeriod);
        $('#lblIncDecInPeriod').append('<span> * </span>');
        $('#txtTimeForIncDecToItem').attr("title",varIDecInPeriod);
        $('#lblIncDecInPerReq').text(varDecRequire);
        $('#lblIncDecExt').text(varDecExt);
        $('#lblIncDecExt').append('<span> *</span>');
        $('#txtIncDecDuringExt').attr("title",varDecExt)
        $('#lblItemWiseIncDecValMsg').text(varItemWiseDecValMsg);
        $('#lblItemWiseTimeIncDecValMsg').text(varItemWiseDecPriceStartEndDateMsg);
        $('#lblSepDecIncVal').text(varspecdecvalue);
        $('#lblSepDecIncVal').append('<span> * </span>');
        $('#txtSepIncDecValue').attr("title",varspecdecvalue);
        $('#sprdFirstBidCond_1').text(varfirstBidCondAddDecVal);
        $('#sprdIncDecRules_0').text(incdecononeitems);
        $('#sprdIncDecRules_1').text(decinallitems);
        $('#lblRestrictL1H1Bidder').text(varrestrictL1bidder);
        if(hideMap['editValIsNegAllow']=="1"){
        	$('#selIsNegotiationAllow option[value="nIFOHNH0pTI="]').prop('selected', true);
        }else if(hideMap['editValIsNegAllow']=="0"){
        	$('#selIsNegotiationAllow option[value="2Js7vmaJbs8="]').prop('selected', true);
        }else{
        	if(hideMap['valIsNegAllow']==1){
				$('#selIsNegotiationAllow option[value="nIFOHNH0pTI="]').prop('selected', true);
			}else{
				$('#selIsNegotiationAllow option[value="2Js7vmaJbs8="]').prop('selected', true);
			}
        }
        if(hideMap['isNegAllow']=='true'){
    		$('#trIsNegotiationAllow').show();
    	}else{
    		$('#trIsNegotiationAllow').hide();
    	}
        if($('#lblDispL1H1Amt')!=null){
            $('#lblDispL1H1Amt').text(vardispL1amt);
        }

        $('#tdIsBidCapicityReq').hide();
        $('#selisBidCapacityReq').hide();
        
        	$('#selisBidCapacityReq').val(0);
        
		$('#tdBiddingCapacity').hide();
		$("#trRestOfAuctionMoney").hide();
		$('#txtBiddingCapacity').attr("tovalid","false");
		hideAutoBid(); //hide
		var selIsEmdReq = $('#selIsEmdReq :selected').val();
		if(selIsEmdReq == '1'){
			$('#selEmdPaymentMode').prop("disabled", true);
			$('#selEmdPaymentMode').val(1);
			if(clientPaymentConfigure != 0 ){
				$('#tdEmdFees').show();
				$('#txtEmdAmt').attr("tovalid","true");
			}else{
				$('#tdEmdFees').hide();
				$('#txtEmdAmt').attr("tovalid","false");
			}
		}
	}
}

function standardAuc(ob){
    if($(ob).val() == '2'){
        $('#displayrank1').hide();
        $("#tdRestrictH1Bidder").hide();
        $('#trDispWinningBid').hide();
        $('#trWinBidderName').hide();
        if(hideMap['showWinningAmount']=='true'){
            $('#trDispH1L1Amt').show();
        }else{
            $('#trDispH1L1Amt').hide();
        }
        
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        if($('input[id=rdDispL1H1Price]:checked').val()==1){
            if(hideMap['showWinningBid']=='true'){
                $('#trDispWinningBid').show();
            }else{
                $('#trDispWinningBid').hide();
            }
            if(hideMap['showWinnerName']=='true'){
                $('#trWinBidderName').show();
            }else{
                $('#trWinBidderName').hide();
            }
        }
        if($('input[id=rdIsAutoExt]:checked').val()==1){
            if(hideMap['rankForExt']=='true'){
                $('#trExtOnReceiveBidbyRank').show();
                 $('#txtRankForExt').attr('tovalid','true');
                
            }else{
                $('#trExtOnReceiveBidbyRank').hide(); 
                 $('#txtRankForExt').attr('tovalid','false');
            }
        }else{
            $('#trExtOnReceiveBidbyRank').hide();
             $('#txtRankForExt').attr('tovalid','false');
        }
       // $('#trGreaterRank').hide();
        if($('input[id=rdIsBidderNameMasking]:checked').val()==0){
        	$('#trGreaterRank').show();
		}
        if(hideMap['isEncodedName']=='true'){
            $('#trEncodeBidderName').show();   
        }
    }else{
        
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        if($('input[name=rdAuctionResult]:checked').val()==2 && $('input[name=rdIsAutoBidAllowed]:checked').val()==0 && $('input[name=rdAccess]:checked').val()==2 && hideMap['isRestrictH1Bidder'] == 'true'){
        	$("#tdRestrictH1Bidder").show();
        }else{
        	$("#tdRestrictH1Bidder").hide();
        }
        if(hideMap['showWinnerName']=='true'){
            $('#trWinBidderName').show();
        }else{
            $('#trWinBidderName').hide();
        }
        $('#trDispRank').show();
        if(hideMap['showRank']=='true'){
            $('#displayrank1').show();
            $('#displayrank2').show();
        }else{
            $('#displayrank1').hide();
            $('#displayrank2').hide();
        }
        /*if(hideMap['isBidderNameMasking']=='true'){
            $('#IsBidderNameMasking1').show();
            $('#IsBidderNameMasking2').show();
        }else{
            $('#IsBidderNameMasking1').hide();
            $('#IsBidderNameMasking2').hide();
        }*/
        $('#trDispH1L1Amt').hide();
        $('#trDispWinningBid').hide();
        $('#trExtOnReceiveBidbyRank').hide();
         $('#txtRankForExt').attr('tovalid','false');
        if($('input[id=rdIsBidderNameMasking]:checked').val()==1){
        	if(hideMap['greaterRank']=='true'){
        		$('#trGreaterRank').show();
        	}
            if(hideMap['isEncodedName']=='true'){
                $('#trEncodeBidderName').show();
            }
        }else{
        	$('#trGreaterRank').hide();
            $('#trEncodeBidderName').hide();
        }
    }
}

function dispWinningBid(ob){           
    if($(ob).val()=='1'){
//        $('#trDispWinningBid').show();
		if(hideMap['showWinningBid']=='true'){
			$('#trDispWinningBid').show();
        }else{
            $('#trDispWinningBid').hide();
        }
        /*Bug #71631*/
        if(hideMap['showWinnerName']=='true'){
        	$('#trWinBidderName').show();
		}else{
			$('#trWinBidderName').hide();
		}
    }else{
        $('#trDispWinningBid').hide();
        $('#trWinBidderName').hide();
    }            
}

function showIncDicMult(ob){
    if($(ob).val() == '2'){
        $('#trAutoBid').hide();
        $('#IncDicMult').hide();
        if($('input[name=rdAuctionResult]:checked').val()==1){
            var attrVal='required@@lengthForNum:3@@percentage@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
        }
    }else{
        if($('input[id=rdIncDecType]:checked').val()==1 && $('input[id=rdBidderWiseStartPrc]:checked').val()==0 && hideMap['isAutoBidAllowed']=='true'){
            $('#trAutoBid').show();
        }else{
            $('#trAutoBid').hide();
        }
        if($('input[id=rdBiddingType]:checked').val()==1){
            var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';            
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
            if(hideMap['incDecInMultiple']=='true' && $('input[id=rdIncDecType]:checked').val()==1 && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                $('#IncDicMult').show();
            }
        }
    }
    showMobAutoBid();	// CR:20108 Nirav Raval
}
function hideIncDecTime(ob) {
	
	if($(ob).val() == '2' || $('input[name=rdAuctionResult]:checked').val()==3){
		$("#trBiddingPriceIncDec").hide();
		$('#txtIncDecInTimes').attr('tovalid','false');
	}else if($(ob).val() == '1'){
		if(hideMap['BiddingPriceIncrementInTimes']=='true' && $('input[id=rdIncDecType]:checked').val()==1){
			$("#trBiddingPriceIncDec").show();
		}else{
			$("#trBiddingPriceIncDec").hide();
		}
		if($('input[name=rdAuctionResult]:checked').val()==1)
		{
			if($("#selBiddingPriceIncDecInTimes").val() == 1) {
        		$("#tdIncDecInTimes").show();
				$('#txtIncDecInTimes').attr('tovalid','true');
			}else {
				$("#tdIncDecInTimes").hide();
				$('#txtIncDecInTimes').attr('tovalid','false');
			}
		}else {
			$("#tdIncDecInTimes").hide();
			$('#txtIncDecInTimes').attr('tovalid','false');
		}
	}
}

function showGTAucRslt(ob){
    if($(ob).val() == '2'){
    	if(hideMap['BiddingPriceIncrementInTimes']=='true' && $('input[id=rdIncDecType]:checked').val()==1){
			$("#trBiddingPriceIncDec").show();
		}else{
			$("#trBiddingPriceIncDec").hide();
		}
    	$("#tdIncDecInTimes").hide();
    	if($('input[name=rdAucType]:checked').val()==1 && $('input[name=rdIsAutoBidAllowed]:checked').val()==0 && $('input[name=rdAccess]:checked').val()==2 && hideMap['isRestrictH1Bidder'] == 'true'){
        	$("#tdRestrictH1Bidder").show();
        }else{
        	$("#tdRestrictH1Bidder").hide();
        }
    	$('#txtIncDecInTimes').attr('tovalid','false');
    	if($('input[id=rdIncDecType]:checked').val()==2){
    		$("#trBiddingPriceIncDec").hide();
    	}
        if($('input[id=rdBiddingType]:checked').val()==1){
        	if(hideMap['incDecType']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
            	$('#tdBiddingPriceType').show();
                //$('#trIncDecType').show();
            }
        	if(hideMap['incDecInMultiple']=='true' && map['incDecType']==1 && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
            	$('#IncDicMult').show();
            }
        }
        
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        if($('input[id=rdConfigureTimeForItem]:checked').val()=='2' && $('input[id=rdIsItemWiseTime]:checked').val()=='1'){
        	$('#tdItemSelectionReq').hide();
        	$("#trIncDecInPeriod").hide();
        }else{
        	if(hideMap['isitemSelection'] == 'true'){
            	$('#tdItemSelectionReq').show();
            }else{
            	$('#tdItemSelectionReq').hide();
            }
        	$("#trIncDecInPeriod").show();
        }
        $('#trGrandTtlPrc').hide();
        $('#txtStartPrice').attr('tovalid', 'false');
        $('#txtReservePrice').attr('tovalid', 'false');
        $('#trIncDecVal').hide();
        $('#txtIncDecValue').attr('tovalid', 'false');
        $('#trIncDecExt').hide();
        $('#trIncDecRuleOn').hide();
        $('#txtIncDecDuringExt').attr('tovalid', 'false'); 
        $('#trItemWiseMsg').show();
        $('#trItemWiseTimeReqMsg').hide();
        $('#trIncDecCertPerValue').hide();
        $('#txtSepIncDecValue').attr('tovalid','false');
        $('#trItemWiseTimeReq').show();     
        $("#trRestOfAuctionMoney").hide();
        if($('input[id=rdIsItemWiseTime]:checked').val()=='0'){ 
        	$('#trConfigureTimeforItem').hide();
        	if($('input[id=rdIncDecCertPrdTime]:checked').val()=='1'){ 
                $('#trIncDecCertPrdTime').show();
                $('#txtTimeForIncDecToItem').attr('dtrequired','true');
                $('#txtTimeForIncDecToItem').attr('comparewith','txtStartDate,txtEndDate');
            }else{
                $('#trIncDecCertPrdTime').hide();
                $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
                $('#txtTimeForIncDecToItem').removeAttr('comparewith');
            }
            $('#trAucStartEndDate').show();
            if($('input[id=rdIsAutoExt]:checked').val()=='1'){
                if($('input[id=rdExtMode]:checked').val()=='1'){
                    if(hideMap['totalExt']=='true'){
                        $('#trNoOfExt').show();
                    }else{
                        $('#trNoOfExt').hide();
                    }
                    $('#txtTotalExt').attr('tovalid','true');
                }else{
                    $('#trNoOfExt').hide();
                    $('#txtTotalExt').attr('tovalid','false');
                }
                $('#extWhenAndBy').show();
                $('#txtExtendWhen').attr('tovalid','true');
                $('#txtExtendBy').attr('tovalid','true');
                if(hideMap['extendWhen']=='true'){
                    $('#extendWhen1').show();
                    $('#extendWhen2').show();
                }else{
                    $('#extendWhen1').hide();
                    $('#extendWhen2').hide();
                }
                if(hideMap['extendBy']=='true'){
                    $('#extendBy1').show();
                    $('#extendBy2').show();
                }else{
                    $('#extendBy1').hide();
                    $('#extendBy2').hide();
                }
            }else{
                $('#trNoOfExt').hide();
                $('#extWhenAndBy').hide();
                $('#txtTotalExt').attr('tovalid','false');
                $('#txtExtendWhen').attr('tovalid','false');
                $('#txtExtendBy').attr('tovalid','false');
                $('#trExtMode').hide();  
                $('#trIncDecExt').hide();
            }
            $('#txtStartDate').attr('dtrequired','true');
            $('#txtStartDate').attr('isgreater','true');
            if(eval(isApproved) == true && opType == 'edit'){
                $('#txtStartDate').attr('comparetocurrdate','false');     
            }else{
                $('#txtStartDate').attr('comparetocurrdate','true');     
            }                        
            $('#txtEndDate').attr('dtrequired','true');
            $('#txtEndDate').attr('isgreater','true');
            $('#txtEndDate').attr('comparewith','txtStartDate');
            
        }else{
        	$('#trConfigureTimeforItem').show();
        	if($('#trIncDecCertPrdTime')!=null){
                $('#trIncDecCertPrdTime').hide();
                $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
                $('#txtTimeForIncDecToItem').removeAttr('comparewith');
            }
            $('#trAucStartEndDate').hide();
            $('#trNoOfExt').hide();
            $('#txtTotalExt').attr('tovalid','false');
            $('#extWhenAndBy').hide();
            $('#txtExtendWhen').attr('tovalid','false');
            $('#txtExtendBy').attr('tovalid','false');
            $('#txtStartDate').removeAttr('dtrequired');
            $('#txtStartDate').removeAttr('isgreater');
            $('#txtStartDate').removeAttr('comparetocurrdate');
            $('#txtEndDate').removeAttr('dtrequired');
            $('#txtEndDate').removeAttr('isgreater');
            $('#txtStartDate').removeAttr('comparewith');
            if($('input[id=rdIsAutoExt]:checked').val()=='1'){
                $('#trItemWiseTimeForAutoExt').show();
            }
            $('#trItemWiseTimeReqMsg').show();
            $('#trItemWiseMsg').hide();        
            if($('input[id=rdIncDecType]:checked').val()==1){
            	if(hideMap['incDecInMultiple']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                    $('#IncDicMult').show();
                }
            }else{
                $('#IncDicMult').hide();
            }
        }
        if(hideMap['isitemSelection']=='false'){
			$('#tdItemSelectionReq').hide();
			$('#selIsItemSelection').attr('tovalid','false');
		}
		$('#tdShowMinQtyReq').show();
		bidderWiseQtyAllocationReq();
		if(hideMap['isMinQtyReq']=='false'){
			$('#tdShowMinQtyReq').hide();
			$('#selIsMinQtyReq').attr('tovalid','false');
		}
        $('#tdShowWinAmountOnListing').hide();
		$('#selIsShowWinAmountOnListing').attr('tovalid','false');
		
    }else  if($(ob).val()== '1'  || $(ob).val() == '3'){
    	$('#trConfigureTimeforItem').hide();
    	/*if($(ob).val()== '1'){*/
    		if($('input[id=rdIncDecType]:checked').val()==1){
    			if(hideMap['BiddingPriceIncrementInTimes']=='true' && $('input[id=rdIncDecType]:checked').val()==1){
    				$("#trBiddingPriceIncDec").show();
    			}else{
    				$("#trBiddingPriceIncDec").hide();
    			}
	    		$('#txtIncDecInTimes').attr('tovalid','true');
	 			if($("#selBiddingPriceIncDecInTimes").val() == 1) {
	        		$("#tdIncDecInTimes").show();
					$('#txtIncDecInTimes').attr('tovalid','true');
				}else {
					$("#tdIncDecInTimes").hide();
					$('#txtIncDecInTimes').attr('tovalid','false');
				}
	        }
    	/*}else{
    		$("#trBiddingPriceIncDec").hide();
    		$('#txtIncDecInTimes').attr('tovalid','false');
    	}*/
    	if($('input[id=rdIncDecType]:checked').val()==1){
    		if(hideMap['incDecInMultiple']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                $('#IncDicMult').show();
            }
        }else{
            $('#IncDicMult').hide();
        }
        
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        $("#tdRestrictH1Bidder").hide();
		$('#tdShowMinQtyReq').hide();
		$('#selIsMinQtyReq').attr('tovalid','false');
		
		if($(ob).val() == 1){
			if($("#selIsEmdReq").val()==1 && $("#selEventType").val()==1 && clientPaymentConfigure != 0){
				if(hideMap['isRestOfAucMoneyRequired'] == 'true'){
					$("#trRestOfAuctionMoney").show();
				}else{
					$("#trRestOfAuctionMoney").hide();
				}
				
			}else{
				$("#trRestOfAuctionMoney").hide();
			}
		}else{
			$("#trRestOfAuctionMoney").hide();
		}
		
        if($(ob).val() == 3){
            if(hideMap['incDecRuleOn']=='true'){
                $('#trIncDecRuleOn').show();
            }else{
                $('#trIncDecRuleOn').hide(); 
            }
        }else{
            $('#trIncDecRuleOn').hide();
        }
        if($('input[id=rdBiddingType]:checked').val()==1){
        	if(hideMap['incDecType']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                //$('#trIncDecType').show();
            	$('#tdBiddingPriceType').show();
            }
        	if(hideMap['incDecInMultiple']=='true' && $('input[id=rdIncDecType]:checked').val()==1 && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
            	$('#IncDicMult').show();
            }
        }
        $('#trGrandTtlPrc').show();
        $('#trItemWiseTimeForAutoExt').hide();
        $('#trItemWiseTimeReqMsg').hide();
        $('#txtStartPrice').attr('tovalid', 'true');
        $('#txtReservePrice').attr('tovalid', 'true');
        $('#trIncDecVal').show();
        $('#txtIncDecValue').attr('tovalid', 'true');
        $('#trIncDecExt').show();
        $('#txtIncDecDuringExt').attr('tovalid', 'true'); 
        $('#trItemWiseMsg').hide();
        $('#trItemWiseTimeReqMsg').hide();
        if( $('#trItemWiseTimeReq')!=null){
            $('#trItemWiseTimeReq').hide();
        }
        $('#extWhenAndBy').show();
        if(hideMap['extendWhen']=='true'){
            $('#extendWhen1').show();
            $('#extendWhen2').show();
        }else{
            $('#extendWhen1').hide();
            $('#extendWhen2').hide();
        }
        if(hideMap['extendBy']=='true'){
            $('#extendBy1').show();
            $('#extendBy2').show();
        }else{
            $('#extendBy1').hide();
            $('#extendBy2').hide();
        }
        $('#txtExtendWhen').attr('tovalid','true');
        $('#txtExtendBy').attr('tovalid','true');
        if($('input[id=rdIncDecCertPrdTime]:checked').val()=='1'){ 
            $('#trIncDecCertPrdTime').show();
            $('#txtTimeForIncDecToItem').attr('dtrequired','true');
            $('#txtTimeForIncDecToItem').attr('comparewith','txtStartDate,txtEndDate');
            $('#trIncDecCertPerValue').show();
            $('#txtSepIncDecValue').attr('tovalid','true');
        }else{
            $('#trIncDecCertPrdTime').hide();
            $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
            $('#txtTimeForIncDecToItem').removeAttr('comparewith');
            $('#trIncDecCertPerValue').hide();
            $('#txtSepIncDecValue').attr('tovalid','false');
        }
        $('#trAucStartEndDate').show();
        if($('input[id=rdIsAutoExt]:checked').val()=='1'){
            if($('input[id=rdExtMode]:checked').val()=='1'){
                if(hideMap['totalExt']=='true'){
                    $('#trNoOfExt').show();
                }else{
                    $('#trNoOfExt').hide();
                }
                $('#txtTotalExt').attr('tovalid','true');
            }else{
                $('#trNoOfExt').hide();
                $('#txtTotalExt').attr('tovalid','false');
            }
            
            $('#extWhenAndBy').show();
            if(hideMap['extendWhen']=='true'){
                $('#extendWhen1').show();
                $('#extendWhen2').show();
            }else{
                $('#extendWhen1').hide();
                $('#extendWhen2').hide();
            }
            if(hideMap['extendBy']=='true'){
                $('#extendBy1').show();
                $('#extendBy2').show();
            }else{
                $('#extendBy1').hide();
                $('#extendBy2').hide();
            }
            $('#txtIncDecDuringExt').attr('tovalid','true');
            $('#txtExtendWhen').attr('tovalid','true');
            $('#txtExtendBy').attr('tovalid','true');
        }else{
            $('#trNoOfExt').hide();
            $('#extWhenAndBy').hide();
            $('#txtTotalExt').attr('tovalid','false');
            $('#txtExtendWhen').attr('tovalid','false');
            $('#txtExtendBy').attr('tovalid','false');
            $('#trExtMode').hide();  
            $('#trIncDecExt').hide();
            $('#txtIncDecDuringExt').attr('tovalid','false');
        }
        if($('input[id=rdAccess]:checked').val()==2 && $(ob).val() == 3){
            //$('#trIncDecType').hide();
        	$('#tdBiddingPriceType').hide();
        	$('#IncDicMult').hide();
            var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
            /*if(hideMap['incDecInMultiple']=='true'){
                $('#IncDicMult').show();
            }*/
        }else{
        	if(hideMap['incDecType']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
            	$('#tdBiddingPriceType').show();
            }
            if($('input[id=rdIncDecType]:checked').val()==1){
                var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';
                $('#txtIncDecValue').attr('validarr', attrVal);
                $('#txtIncDecDuringExt').attr('validarr', attrVal);
                $('#txtSepIncDecValue').attr('validarr', attrVal);
                if($('input[id=rdIncDecType]:checked').val()==1){
                	if(hideMap['incDecInMultiple']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                        $('#IncDicMult').show();
                    }
                }else{
                    $('#IncDicMult').hide();
                }
            }else{
                var attrVal='required@@lengthForNum:3@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';
                $('#txtIncDecValue').attr('validarr', attrVal);
                $('#txtIncDecDuringExt').attr('validarr', attrVal);
                $('#txtSepIncDecValue').attr('validarr', attrVal);
            }
        }
        $('#txtStartDate').attr('dtrequired','true');
        $('#txtStartDate').attr('isgreater','true');
        $('#txtStartDate').attr('comparetocurrdate','true');        
        $('#txtEndDate').attr('dtrequired','true');
        $('#txtEndDate').attr('isgreater','true');
        $('#txtEndDate').attr('comparewith','txtStartDate');
		$('#tdItemSelectionReq').hide();
		
		$('#tdShowWinAmountOnListing').show();
		if(hideMap['showWinAmountOnListing']=='false'){
			$('#tdShowWinAmountOnListing').hide();
			$('#selIsShowWinAmountOnListing').attr('tovalid','false');
		}
    }
}

function getReservePriceCheck(ob){
    var eventType=$('#selEventType').val();
    var startPrice=$('#txtStartPrice').val();
    var reservePrice=$(ob).val();
    $('#txtReservePrice').parent().find("#divReserveprice").remove();
    $("#errtxtReservePrice").html("");
    if(eventType=='1' &&( $('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='3')){  
        if(parseFloat(reservePrice)<parseFloat(startPrice)){
            $(ob).parent().append("<div id='errtxtReservePrice' class='err"+$('#txtReservePrice').attr('id')+"' style='color:red;'>"+varrpgreaterthanst+" </div>");           
        }else if(reservePrice != '' && startPrice != '' && parseFloat(reservePrice) == parseFloat(startPrice)){
            $(ob).parent().append("<div id='errtxtReservePrice' class='err"+$('#txtReservePrice').attr('id')+"' style='color:red;'>"+varrpgreaterthanst+" </div>");
        }
    }else if(eventType=='2' &&( $('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='3')){
        if(parseFloat(reservePrice)>parseFloat(startPrice)){
        	if(parseFloat(startPrice)>0){
        		$(ob).parent().append("<div id='errtxtReservePrice' class='err"+$('#txtReservePrice').attr('id')+"' style='color:red;'>"+varrplessthanst+"</div>");
        	}
        }else if(reservePrice != '' && startPrice != '' && parseFloat(reservePrice) == parseFloat(startPrice)){
            $(ob).parent().append("<div id='errtxtReservePrice' class='err"+$('#txtReservePrice').attr('id')+"' style='color:red;'>"+varrplessthanst+"</div>");
        }
    }
}
function getExtendByCheck(ob){
    var extendBy=$(ob).val();
    var extendWhen=$('#txtExtendWhen').val();
    $(ob).parent().find("#divExtendBy").remove();
//    if($('input[id=rdExtMode]:checked').val()=='2'){
        if(parseInt(extendBy)<parseInt(extendWhen)){
            $(ob).parent().append("<div id='divExtendBy' style='color:red;'>"+varExtendByLessThanExtendWhen+"</div>");
        }
//    }
}
function callme(chk){
    if($(chk).val() == $('#selAucBaseCurr').val()){
        return false;
    }else{
        return true;
    }
}
function getBaseCurrSelect(ob){
    var aucBaseCur=$(ob).val();
    var inputs = $('input:checkbox[id^="chkCurrency_"]'); 
    for(var i=1;i<=inputs.length;i++){ 
        var chkval=  $("#chkCurrency_"+i).val();
        if($('#divWord_txtCurrency_'+i).length)
    	{
        	$('#divWord_txtCurrency_'+i).remove();
    	}
        if(aucBaseCur==chkval){
            $("#chkCurrency_"+i).attr("checked", true);            
            $('#txtCurrency_'+chkval).attr("value",1);
            $('#txtCurrency_'+chkval).parent().find('#divWord').remove();
            $('#txtCurrency_'+chkval).attr("readonly",true);
        }else{
            $("#chkCurrency_"+i).attr("checked", false);
            $('#txtCurrency_'+chkval).attr("value",0);
            $('#txtCurrency_'+chkval).parent().find('#divWord').remove(); 
            $('#txtCurrency_'+chkval).attr("readonly",false);
            
        }
    }   
}
function hideIncDecType(ob){
                    
    if($(ob).val() == '2'){
        //$('#trIncDecType').hide();
    	$('#IncDicMult').hide();
    	$('#tdBiddingPriceType').hide();
        $('#trBidCurrency').show();
        $('#IncDicMult').hide();
        var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';        
        $('#txtIncDecValue').attr('validarr', attrVal);
        $('#txtIncDecDuringExt').attr('validarr', attrVal);
        $('#txtSepIncDecValue').attr('validarr', attrVal);
        //$('#trIncDecType').hide();
        $('#trAutoBid').hide();
        var aucBaseCur=aucDefBaseCurrency;
        var inputs = $('input:checkbox[id^="chkCurrency_"]'); 
        for(var i=1;i<=inputs.length;i++){ 
            var chkval=  $("#chkCurrency_"+i).val(); 
            if(aucBaseCur==chkval){
                $("#chkCurrency_"+i).attr("checked", true);
                $('#txtCurrency_'+chkval).attr("value",1);
                $('#txtCurrency_'+chkval).attr("readonly", true);
                $('#txtCurrency_'+chkval).parent().find('#divWord').remove();
            }
        }
    }else{
        if($('input[id=rdAccess]:checked').val()==2 &&  $('input[name=rdAuctionResult]:checked').val()=='3'){
        	//$('#trIncDecType').hide();
        	$('#tdBiddingPriceType').hide();
            $('#IncDicMult').hide();            
            var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';            
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
        }else{
            if(hideMap['incDecType']=='true' && $('#rdBiddingType').val() ==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                //$('#trIncDecType').show();
            	$('#tdBiddingPriceType').show();
            }else{
                //$('#trIncDecType').hide();
            	$('#tdBiddingPriceType').hide();
            }
            if(hideMap['incDecInMultiple']=='true' && $('input[id=rdIncDecType]:checked').val()==1 && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
            	$('#IncDicMult').show();
            }else{
            	$('#IncDicMult').hide();
            }
            if($('input[id=rdIncDecType]:checked').val()==1){
                var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';                
                $('#txtIncDecValue').attr('validarr', attrVal);
                $('#txtIncDecDuringExt').attr('validarr', attrVal);
                $('#txtSepIncDecValue').attr('validarr', attrVal);
                if(hideMap['incDecInMultiple']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                    $('#IncDicMult').show();
                }
            }else{
                var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';                
                $('#txtIncDecValue').attr('validarr', attrVal);
                $('#txtIncDecDuringExt').attr('validarr', attrVal);
                $('#txtSepIncDecValue').attr('validarr', attrVal);
            }
        }
        $('#trBidCurrency').hide();
        if($('input[id=rdBiddingType]:checked').val()==1 && $('input[id=rdBidderWiseStartPrc]:checked').val()==0 && hideMap['isAutoBidAllowed']=='true'){
            $('#trAutoBid').show();
        }else{
            $('#trAutoBid').hide();
        }
    }
    showMobAutoBid();	// CR:20108 Nirav Raval
}
            
function showHideGreateRank(ob){
	if(($(ob).val()=='0') || ob=='0'){
    	$('#trGreaterRank').hide();
        $('#trEncodeBidderName').hide();
        $('#txtGreaterRank').attr('tovalid', 'false');
        $("#isDecodeBidderTr").hide();
        $('input[name=rdIsDecodeBidder][value="0"]').first().attr('checked','checked'); // set value to 0 if mask bidder is no.
    }else{
    	if(hideMap['greaterRank']=='true'){
    		$('#trGreaterRank').show();
    	}
        if(hideMap['isEncodedName']=='true'){
            $('#trEncodeBidderName').show();
        }else{
            $('#trEncodeBidderName').hide();
        }
        $('#txtGreaterRank').attr('tovalid', 'true');
        showHideIsDecodeBidder();
    }
}
function resPriceM(ob){
    var validarr = $('#txtReservePrice').attr("validarr");
    if($(ob).val() == '1'){
        $('#resPriceM').text(' *');
        if(validarr.indexOf('required@@')==-1){                        
            $('#txtReservePrice').attr("validarr",'required@@nonzero@@'+validarr);
        }
        if(hideMap['isShowReservePriceToBidder']=='true'){
        	$("#tdShowResPriceToBidder").show();
        }else{
        	$("#tdShowResPriceToBidder").hide();
        }
    }else{
        $('#resPriceM').text('');
        if(validarr.indexOf('required@@')!=-1){                        
            $('#txtReservePrice').attr("validarr",validarr.replace('required@@nonzero@@',''));
        }
        $("#tdShowResPriceToBidder").hide();
    }
               
}
function incDecCertPrdTime(ob){
             
    if($(ob).val() == '1'){
        if(($('input[id=rdIsItemWiseTime]:checked').val()=='0' && $('input[name=rdAuctionResult]:checked').val()=='2') ||  $('input[name=rdAuctionResult]:checked').val()=='1'  || $('input[name=rdAuctionResult]:checked').val()=='3'){
            $('#trIncDecCertPrdTime').show();
            $('#txtTimeForIncDecToItem').attr('dtrequired','true');
            $('#txtTimeForIncDecToItem').attr('comparewith','txtStartDate,txtEndDate');
            if ($('input[name=rdAuctionResult]:checked').val()=='1'  || $('input[name=rdAuctionResult]:checked').val()=='3'){
                $('#trIncDecCertPerValue').show();
                $('#txtSepIncDecValue').attr('tovalid','true');
            }else{
                $('#trIncDecCertPerValue').hide();
                $('#txtSepIncDecValue').attr('tovalid','false');
            }
        }
    }else{
        if($('#trIncDecCertPrdTime')!=null){
            $('#trIncDecCertPrdTime').hide();
            $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
            $('#txtTimeForIncDecToItem').removeAttr('comparewith');
        }         
        $('#trIncDecCertPerValue').hide();
        $('#txtSepIncDecValue').attr('tovalid','false');
                     
    }
} 
function AutoExtRequire(ob){
    if($(ob).val() == '1'){
        if(hideMap['extMode']=='true'){
        	$('#trExtMode').show();
        }
        $('#trIncDecExt').hide();
        $('#txtIncDecDuringExt').attr('tovalid', false); 
        if(($('input[id=rdIsItemWiseTime]:checked').val()=='0' && $('input[name=rdAuctionResult]:checked').val()=='2') || $('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='3'){
            if(hideMap['totalExt']=='true'){
                if($('input[id=rdExtMode]:checked').val()=='1'){
                    $('#trNoOfExt').show();
                    $('#txtTotalExt').attr('tovalid','true');
                }
            }else{
                $('#trNoOfExt').hide();
                $('#txtTotalExt').attr('tovalid','false');
            }
            $('#trItemWiseTimeForAutoExt').hide();     
           
            $('#extWhenAndBy').show();
            if(hideMap['extendWhen']=='true'){
                $('#extendWhen1').show();
                $('#extendWhen2').show();
            }else{
                $('#extendWhen1').hide();
                $('#extendWhen2').hide();
            }
            if(hideMap['extendBy']=='true'){
                $('#extendBy1').show();
                $('#extendBy2').show();
            }else{
                $('#extendBy1').hide();
                $('#extendBy2').hide();
            }
            $('#txtExtendWhen').attr('tovalid','true');
            $('#txtExtendBy').attr('tovalid','true');
        }else{
            $('#trNoOfExt').hide();
            $('#trItemWiseTimeForAutoExt').show();       
            $('#txtTotalExt').attr('tovalid','false');
            $('#extWhenAndBy').hide();
            $('#txtExtendWhen').attr('tovalid','false');
            $('#txtExtendBy').attr('tovalid','false');
        }
        if($('input[id=rdAucType]:checked').val()=='2'){
            if(hideMap['rankForExt']=='true'){
                $('#trExtOnReceiveBidbyRank').show();
                $('#txtRankForExt').attr('tovalid','true');
            }else{
                $('#trExtOnReceiveBidbyRank').hide();
                 $('#txtRankForExt').attr('tovalid','false');
            }
        }else{
            $('#trExtOnReceiveBidbyRank').hide();
             $('#txtRankForExt').attr('tovalid','false');
        } 
        if($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='3'){
            $('#trIncDecExt').show();
            $('#txtIncDecDuringExt').attr('tovalid', 'true'); 
        }       
    }else{
        $('#trItemWiseTimeForAutoExt').hide(); 
        
        $('#trNoOfExt').hide();
        $('#txtTotalExt').attr('tovalid','false');
        $('#trExtMode').hide();
        $('#extWhenAndBy').hide();
        $('#txtExtendWhen').attr('tovalid','false');
        $('#txtExtendBy').attr('tovalid','false');
        $('#trIncDecExt').hide();
        $('#txtIncDecDuringExt').attr('tovalid', 'false'); 
        $('#trExtOnReceiveBidbyRank').hide();
        $('#txtRankForExt').attr('tovalid','false');
    }
}
           
function noOfExt(ob){
    if($(ob).val() == '1'){
        if(($('input[name=rdIsItemWiseTime]:checked').val()=='0' && $('input[name=rdAuctionResult]:checked').val()=='2') || $('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='3'){
            if(hideMap['totalExt']=='true'){
                $('#trNoOfExt').show();
                $('#txtTotalExt').attr('tovalid','true');
                
            }else{
                $('#trNoOfExt').hide();  
                $('#txtTotalExt').attr('tovalid','false');
            }
          //  $('#txtTotalExt').attr('tovalid',true);
        }else{
            $('#trNoOfExt').hide();
            $('#txtTotalExt').attr('tovalid','false');
        }
    }else{
        $('#trNoOfExt').hide();
        $('#txtTotalExt').attr('tovalid','false');
    }
}
           
function showHideItemWiseTimeReq(ob){
    if($(ob).val()=='1'){
    	$('#trConfigureTimeforItem').show();
    	// Start For Bug #29883
    	if(opType==='edit')
    	{
    		if(cstatus == 1){
    			$('input[id=rdConfigureTimeForItem]:radio').attr('disabled',true);
    		}
    	}
    	//end Bug #29883
    	if($('input[id=rdConfigureTimeForItem]:checked').val()=='1'){ 
            $('#thItemDuration').hide();
            $('#tdItemDuration').hide();
            if(hideMap['isitemSelection'] == 'true'){
            	$('#tdItemSelectionReq').show();
            }else{
            	$('#tdItemSelectionReq').hide();
            }
            $("#trIncDecInPeriod").show();
        }else  if($('input[id=rdConfigureTimeForItem]:checked').val()=='2'){ 
            $('#thItemDuration').show();
            $('#tdItemDuration').show();
            $('#tdItemSelectionReq').hide();
            $("#trIncDecInPeriod").hide();
        }
        $('#trItemWiseTimeReqMsg').show();
        $('#trItemWiseMsg').hide();
        $('#trAucStartEndDate').hide();
        $('#txtStartDate').removeAttr('dtrequired');
        $('#txtStartDate').removeAttr('isgreater');
        $('#txtStartDate').removeAttr('comparetocurrdate');
        $('#txtEndDate').removeAttr('dtrequired');
        $('#txtEndDate').removeAttr('isgreater');
        $('#txtStartDate').removeAttr('isgreater');
        $('#txtStartDate').removeAttr('comparewith');
        if($('#trIncDecCertPerValue')!=null){
            $('#trIncDecCertPerValue').hide();
            $('#txtSepIncDecValue').attr('tovalid','false');
        }
        $('#trIncDecCertPrdTime').hide();
        $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
        $('#txtTimeForIncDecToItem').removeAttr('comparewith');
        if($('input[name=rdIsAutoExt]:checked').val()==1){
            $('#trItemWiseTimeForAutoExt').show();
        }else{
            $('#trItemWiseTimeForAutoExt').hide();
        }
        if($('#trNoOfExt')!=null){
            $('#trNoOfExt').hide();
            $('#txtTotalExt').attr('tovalid','false');
        }
        $('#trIncDecExt').hide();
        $('#txtIncDecDuringExt').attr('tovalid', 'false'); 
        $('#extWhenAndBy').hide();
        $('#txtExtendWhen').attr('tovalid','false');
        $('#txtExtendBy').attr('tovalid','false');
    }else{
    	if(hideMap['isitemSelection'] == 'true'){
        	$('#tdItemSelectionReq').show();
        }else{
        	$('#tdItemSelectionReq').hide();
        }
    	$('#trConfigureTimeforItem').hide();
        $('#trItemWiseTimeReqMsg').hide();
        $('#trItemWiseMsg').show();
        $('#trAucStartEndDate').show();
        $('#txtStartDate').attr('dtrequired','true');
        $('#txtStartDate').attr('isgreater','true');
        if(eval(isApproved) == true && opType == 'edit'){
            $('#txtStartDate').attr('comparetocurrdate','false');
        }else{
            $('#txtStartDate').attr('comparetocurrdate','true');
        }           
        $('#txtEndDate').attr('dtrequired','true');
        $('#txtEndDate').attr('isgreater','true');
        $('#txtEndDate').attr('comparewith','txtStartDate');
        $('#trIncDecCertPerValue').hide();
        $('#txtSepIncDecValue').attr('tovalid','false');
        if($('input[name=rdIncDecCertPrdTime]:checked').val()==1){
            $('#trIncDecCertPrdTime').show();
            $('#txtTimeForIncDecToItem').attr('dtrequired','true');
            $('#txtTimeForIncDecToItem').attr('comparewith','txtStartDate,txtEndDate');
        }else{
            $('#trIncDecCertPrdTime').hide();
            $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
            $('#txtTimeForIncDecToItem').removeAttr('comparewith');
        }
        
        $('#trItemWiseTimeForAutoExt').hide();
        if($('input[name=rdIsAutoExt]:checked').val()=='1'){
            if(hideMap['totalExt']=='true'){
                $('#trNoOfExt').show();
                $('#txtTotalExt').attr('tovalid','true');
            }else{
                $('#trNoOfExt').hide();
                 $('#txtTotalExt').attr('tovalid','false');
            }
          //  $('#txtTotalExt').attr('tovalid',true);
            $('#extWhenAndBy').show();
            $('#txtExtendWhen').attr('tovalid','true');
            $('#txtExtendBy').attr('tovalid','true');
            
            if(hideMap['extendWhen']=='true'){
                $('#extendWhen1').show();
                $('#extendWhen2').show();
                $('#txtExtendWhen').attr('tovalid','true');
            }else{
                $('#extendWhen1').hide();
                $('#extendWhen2').hide();
                    $('#txtExtendWhen').attr('tovalid','false');
            }
            if(hideMap['extendBy']=='true'){
                $('#extendBy1').show();
                $('#extendBy2').show();
                $('#txtExtendBy').attr('tovalid','true');
            }else{
                $('#extendBy1').hide();
                $('#extendBy2').hide();
                $('#txtExtendBy').attr('tovalid','false');
            }
            
        }else{
            $('#trNoOfExt').hide();
            $('#txtTotalExt').attr('tovalid','false');
            $('#extWhenAndBy').hide();
            $('#txtExtendWhen').attr('tovalid','false');
            $('#txtExtendBy').attr('tovalid','false');
        }
    }
}

function showHideItemDuration(ob){
    if($(ob).val()=='1'){
    	$('#thItemDuration').hide();
    	$('#tdItemDuration').hide();
    	if(hideMap['isitemSelection'] == 'true'){
        	$('#tdItemSelectionReq').show();
        }else{
        	$('#tdItemSelectionReq').hide();
        }
    	$("#trIncDecInPeriod").show();
    }else if($(ob).val()=='2'){
    	$('#thItemDuration').show();
    	$('#tdItemDuration').show();
    	$('#tdItemSelectionReq').hide();
    	$("#trIncDecInPeriod").hide();
    }
}

function hideAutoBid(ob){
    if($('input[id=rdBidderWiseStartPrc]:checked').val() =='0' &&  $('input[id=rdBiddingType]:checked').val()==1 && $('input[id=rdIncDecType]:checked').val()==1 && hideMap['isAutoBidAllowed']=='true' && $('#selisBidCapacityReq').val() == 0){
        $('#trAutoBid').show();
    }else{
        $('#trAutoBid').hide();
    }
    showMobAutoBid();	// CR:20108 Nirav Raval
}
function validation(){
    var vbool=true;
    vbool=validate();
    if(vbool){
    	
    	var selEmdPaymentMode = $('#selEmdPaymentMode :selected').val();
    	var selEmdModeReq = $('#selIsEmdReq :selected').val();
    	if(opType=='edit' && eval(isApproved) == true && selEmdPaymentMode == '1' && selEmdModeReq == '1' ){
    		var txtEmdAmt = $('#txtEmdAmt').val();
    		if(parseInt(txtEmdAmt) != parseInt(emdAmt)){
    			if(confirm(varemdamtedit)){
    				
    				vbool=true;
    			}else{
    				vbool=false;
    			}
    			
    		}
    		
    	}
    	
        if($('input[id=rdBiddingType]:checked').val()==2){
            var currList="";
            $("input[id*='chkCurrency_']:checked").each(function() {
                var cur = $(this).val();
                   
                var exchangeRate=$('#txtCurrency_'+cur).val();
                if(exchangeRate == 0.0){
                    $('#txtCurrency_'+cur).parent().append("<div class='err"+$('#txtCurrency_'+cur).attr('id')+"' style='color:red;'>"+varenterexchangerate+"</div>");
                    vbool=false;   
                }
                if(currList==""){
                    currList=cur;
                }else{
                    currList=currList+","+cur;
                }
            });
                
            $('#txtCommaSepCur').val(currList);
        }
    }
              
    if(vbool){
        var eventType=$('#selEventType').val();
        $('#txtReservePrice').parent().find("#divReserveprice").remove();
        if(eventType=='1' &&( $('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='3')){
            var startPrice=$('#txtStartPrice').val();
            var reservePrice=$('#txtReservePrice').val();
            if(parseFloat(reservePrice)<parseFloat(startPrice)){
                $('#txtReservePrice').parent().append("<div id='divReserveprice' class='err"+$('#txtReservePrice').attr('id')+"' style='color:red;'>"+varrpgreaterthanst+" </div>");         
                vbool=false;
            } else if(reservePrice != '' && startPrice != '' && parseFloat(reservePrice) == parseFloat(startPrice)){
                $('#txtReservePrice').parent().append("<div id='divReserveprice' class='err"+$('#txtReservePrice').attr('id')+"' style='color:red;'>"+varrpgreaterthanst+" </div>");         
                vbool=false;
            }
            
        }else if(eventType=='2' &&( $('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='3')){
            var startPrice=$('#txtStartPrice').val();
            var reservePrice=$('#txtReservePrice').val();
            if(parseFloat(reservePrice)>parseFloat(startPrice)){
            	if(parseFloat(startPrice)>0){
            		$('#txtReservePrice').parent().append("<div id='divReserveprice' class='err"+$('#txtReservePrice').attr('id')+"'  style='color:red;'>"+varrplessthanst+"</div>");
            		vbool=false;
            	}
            }else if(reservePrice != '' && startPrice != '' && parseFloat(reservePrice) == parseFloat(startPrice)){
            	$('#txtReservePrice').parent().append("<div id='divReserveprice' class='err"+$('#txtReservePrice').attr('id')+"'  style='color:red;'>"+varrplessthanst+"</div>");
                vbool=false;
            }
        }
    
        var extendBy=$('#txtExtendBy').val();
        var extendWhen=$('#txtExtendWhen').val();
        $('#txtExtendBy').parent().find("#divExtendBy").remove();

//Bug #34824(remove rdExtMode condition) 
//        if($('input[id=rdExtMode]:checked').val()=='2'){
            if(parseInt(extendBy)<parseInt(extendWhen)){
                $('#txtExtendBy').parent().append("<div id='divExtendBy' class='err"+$('#txtExtendBy').attr('id')+"'  style='color:red;'>"+varExtendByLessThanExtendWhen+" "+extendWhen+" "+min+"</div>");
                vbool=false;
            }
//        } 
    }     
    //vbool=true;
    if(vbool){
        var decimalOnly = "^\\s*-?[0-9]\\d*(\\.\\d{1,decimal})?\\s*$";
        var count=0;
        var obj=null;
        var decimalupto=$('#selDecimalValueUpto').val(); 
        decimalOnly = new RegExp(decimalOnly.replace('decimal',decimalupto));
        if(hideMap['isDocFee']=='false' && $('#txtAucDocFee').val() != "" && $('#txtAucDocFee').val()!=null){
            if(!decimalOnly.test($('#txtAucDocFee').val())){
            	$('#txtAucDocFee').parent().find("#divAucDoczFees").remove();
                $('#txtAucDocFee').parent().append("<div id='divAucDoczFees'  class='err"+$('#txtAucDocFee').attr('id')+"' style='color:red;'>"+varaucDecimalUpto+" "+$('#selDecimalValueUpto').val()+" "+varDigitAllow+"</div>");
                count=count+1;
                if(count==1){
                    obj='#txtAucDocFee';
                }
                vbool=false;  
            }
        }
        if(hideMap['isParticipationFee'] == 'false' && $('#txtAucParticipateFee').val()!= "" && $('#txtAucParticipateFee').val()!= null){
            if(!decimalOnly.test($('#txtAucParticipateFee').val())){
                $('#txtAucParticipateFee').parent().find("#divAucParticipationFees").remove();
                $('#txtAucParticipateFee').parent().append("<div id='divAucParticipationFees' class='err"+$('#txtAucParticipateFee').attr('id')+"' style='color:red;'>"+varaucDecimalUpto+" "+$('#selDecimalValueUpto').val()+" "+varDigitAllow+" </div>");
                count=count+1;
                if(count==1){
                    obj='#txtAucParticipateFee';
                }
                vbool=false;  
            }
        }
        if(hideMap['eventValue'] == 'false' && $('#txtEventValue').val()!= "" && $('#txtEventValue').val()!= null){
            if(!decimalOnly.test($('#txtEventValue').val())){
                $('#txtEventValue').parent().find("#divEventValue").remove();
                $('#txtEventValue').parent().append("<div id='divEventValue' class='err"+$('#txtEventValue').attr('id')+"' style='color:red;'>"+varaucDecimalUpto+" "+$('#selDecimalValueUpto').val()+" "+varDigitAllow+" </div>");
                count=count+1;
                if(count==1){
                    obj='#txtEventValue';
                }
                vbool=false;  
            }
        }
        if($('input[name=rdAuctionResult]:checked').val()==1 || $('input[name=rdAuctionResult]:checked').val()==3){
            if($('#txtStartPrice').val() != null && $('#txtStartPrice').val()!= "" && !decimalOnly.test($('#txtStartPrice').val())){
                $('#txtStartPrice').parent().find("#divStartPrice").remove();
                $('#txtStartPrice').parent().append("<div id='divStartPrice' class='err"+$('#txtStartPrice').attr('id')+"' style='color:red;'>"+varaucDecimalUpto+" "+$('#selDecimalValueUpto').val()+" "+varDigitAllow+" </div>");
                count=count+1;
                if(count==1){
                    obj='#txtStartPrice';
                }
                vbool=false;  
                      
            }
            if($('#txtReservePrice').val() != null && $('#txtReservePrice').val()!= "" && !decimalOnly.test($('#txtReservePrice').val())){
                $('#txtReservePrice').parent().find("#divReservePrice").remove();
                $('#txtReservePrice').parent().append("<div id='divReservePrice' class='err"+$('#txtReservePrice').attr('id')+"' style='color:red;'>"+varaucDecimalUpto+" "+$('#selDecimalValueUpto').val()+" "+varDigitAllow+" </div>");
                count=count+1;
                if(count==1){
                    obj='#txtReservePrice';
                }
                vbool=false;  
            }
            if($('#txtIncDecValue').val() != null && $('#txtIncDecValue').val()!= "" && !decimalOnly.test($('#txtIncDecValue').val())){
                $('#txtIncDecValue').parent().find("#divIncDecPrice").remove();
                $('#txtIncDecValue').parent().append("<div id='divIncDecPrice' class='err"+$('#txtIncDecValue').attr('id')+"' style='color:red;'>"+varaucDecimalUpto+" "+$('#selDecimalValueUpto').val()+" "+varDigitAllow+" </div>");
                count=count+1;
                if(count==1){
                    obj='#txtIncDecValue';
                }
                vbool=false;  
            }
               
            if($('#txtSepIncDecValue').val() != null && $('#txtSepIncDecValue').val()!= ""  && !decimalOnly.test($('#txtSepIncDecValue').val())){
                $('#txtSepIncDecValue').parent().find("#divSepIncDecVal").remove();
                $('#txtSepIncDecValue').parent().append("<div id='divSepIncDecVal' class='err"+$('#txtSepIncDecValue').attr('id')+"' style='color:red;'>"+varaucDecimalUpto+" "+$('#selDecimalValueUpto').val()+" "+varDigitAllow+" </div>");
                count=count+1;
                if(count==1){
                    obj='#txtSepIncDecValue';
                }
                vbool=false;  
            }
            if($('#txtIncDecDuringExt').val() != null && $('#txtIncDecDuringExt').val()!= "" && !decimalOnly.test($('#txtIncDecDuringExt').val())){
                $('#txtIncDecDuringExt').parent().find("#divIncDecDuringExt").remove();
                $('#txtIncDecDuringExt').parent().append("<div id='divIncDecDuringExt' class='err"+$('#txtIncDecDuringExt').attr('id')+"' style='color:red;'>"+varaucDecimalUpto+" "+$('#selDecimalValueUpto').val()+" "+varDigitAllow+" </div>");
                count=count+1;
                if(count==1){
                    obj='#txtIncDecDuringExt';
                }
                vbool=false;  
            }
        }
        $(obj).focus();
    }
    //var optype=opType;
    if(vbool && opType=='edit'){
        var newauctionresult=$('input[name=rdAuctionResult]:checked').val();
        var oldauctionresult=map['auctionResult'];
        var oldAuctionMode=map['auctionMode'];
        var newAuctiomMode=$('input[name=rdAccess]:checked').val();
        if((oldauctionresult!=null && oldauctionresult!="" && oldauctionresult!=' ') || (oldAuctionMode!=null && oldAuctionMode!="" && oldAuctionMode!=' ')){
            if(newauctionresult != oldauctionresult || newAuctiomMode!=oldAuctionMode){
                if(confirm(varauctionedit)){
                    vbool=true;
                }else{   
                    vbool=false;
                }
            }
        }
    }
    
    if($("#txtCategory").val() != undefined)
    {
		if($("input[name='txtCategory']").length <= 0)
			{
				$("#errtxtCategory").show();
				vbool = false;
			}else{
				$("#errtxtCategory").hide();
			}
    }  
    
    if(vbool){
        vbool= disableBtn(vbool);
    }else{
    	// For Bug:#24110
    	$('#txtaAucBriefScope').val(reverseReplaceQuotes($('#txtaAucBriefScope').val()));
    }  
    return vbool;
}
function testData(){
    if(nodedata==0 ||  nodedata == null || nodedata  == "" || nodedata == undefined){
        $("#errSpanParentDepartmentMsg").val(varSelDepartment);
    }
}
function formLoadData(){
	if($('input[name=rdAccess]:checked').val()==1){
    	$('#trBrdMode').hide();
    	$('#trForHomePage').hide();
    }else{
    	$('#trBrdMode').show();
    	$('#trForHomePage').show();
    }
	// Start For Bug #29883
	if(opType==='edit' && map['isItemWiseTime']=='1')
	{
		if(cstatus == 1){
			$('input[id=rdConfigureTimeForItem]:radio').attr('disabled',true);
		}
	}
	//end Bug #29883
	if(hideMap['BiddingPriceIncrementInTimes']=='false'){
		if(hideMap['valBiddingPriceIncrementInTimes'] == '1'){
			$("#tdIncDecInTimes").show();
		}else{
			$("#trBiddingPriceIncDec").hide();
		}
	}else{
		if(hideMap['BiddingPriceIncrementInTimes']=='true' && $('input[id=rdIncDecType]:checked').val()==1){
			$("#trBiddingPriceIncDec").show();
		}else{
			$("#trBiddingPriceIncDec").hide();
		}
    }
	 if(hideMap['breakPriceBid']=='true'){
 		$('#trBreakPriceBid').show();
 	}else{
 		$('#trBreakPriceBid').hide();
 	}
    if(map['auctionMode']=="1"){
        if($('#rowLimitedAuc') != null){
        	if(hideMap['showBidderWiseForm'] == 'true'){
        		$('#rowLimitedAuc').hide();
        	}
        }
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        $('#rdAuctionResult_2').hide();
        $('#sprdAuctionResult_2').hide();
        $('#trIncDecRuleOn').hide(); 
        if($('input[name=rdAuctionResult]:checked').val()==3){
            $('input:radio[name=rdAuctionResult]')[0].checked = true;
        }
    }else{
        if($('#rowLimitedAuc') != null){
        	if(hideMap['showBidderWiseForm'] == 'true'){
        		$('#rowLimitedAuc').show();
        	}
        }
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        $('#rdAuctionResult_2').show();
        $('#sprdAuctionResult_2').show();
        if($('input[name=rdAuctionResult]:checked').val()==3 && hideMap['incDecRuleOn']=='true'){
            $('#trIncDecRuleOn').show(); 
        }
    }
    if(map['biddingType']=='2'){
        //$('#trIncDecType').hide();
    	
    	$('#tdBiddingPriceType').hide();
    	$('#IncDicMult').hide();
    	
        $('#trAutoBid').hide();
        $('#trBidCurrency').show();
        $('#IncDicMult').hide();
        var attrVal='required@@lengthForNum:3@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';        
        $('#txtIncDecValue').attr('validarr', attrVal);
        $('#txtIncDecDuringExt').attr('validarr', attrVal);
        $('#txtSepIncDecValue').attr('validarr', attrVal);
        var aucBaseCur=aucDefBaseCurrency;
        var inputs = $('input:checkbox[id^="chkCurrency_"]'); 
        for(var i=1;i<=inputs.length;i++){ 
            var chkval=  $("#chkCurrency_"+i).val();
                  
            if(aucBaseCur==chkval){
                $('#txtCurrency_'+chkval).attr("value",1);
                $('#txtCurrency_'+chkval).attr("readonly", true);
                $('#txtCurrency_'+chkval).parent().find('#divWord').remove();
            }
        }
    }else{
        if($('input[id=rdBidderWiseStartPrc]:checked').val()==0 &&  $('input[id=rdIncDecType]:checked').val()==1){        	
        	if(hideMap['isAutoBidAllowed']=='true'){
        		$('#trAutoBid').show();
        	}
        }else{
            $('#trAutoBid').hide();
        }
        if(hideMap['incDecType']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
        	$('#tdBiddingPriceType').show();
        }else{
        	$('#tdBiddingPriceType').hide();
        }
        if(hideMap['incDecInMultiple']=='true' && $('input[id=rdIncDecType]:checked').val()==1 && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
        	$('#IncDicMult').show();
        }else{
        	$('#IncDicMult').hide();
        }
        
        if($('input[id=rdIncDecType]:checked').val()==1){
            var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';            
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
            if(hideMap['incDecInMultiple']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                $('#IncDicMult').show();
            }
            if(hideMap['BiddingPriceIncrementInTimes']=='true'){
            	$("#trBiddingPriceIncDec").show();
            	var selBiddingPriceIncDecInTimes = $("#selBiddingPriceIncDecInTimes").val();
            	if(selBiddingPriceIncDecInTimes == 0) {
            		$("#tdIncDecInTimes").hide();
        			$('#txtIncDecInTimes').attr('tovalid','false');
            	}else{
            		$("#tdIncDecInTimes").show();
        			$('#txtIncDecInTimes').attr('tovalid','true');
            	}
        	}
        }else{
            var attrVal='required@@lengthForNum:3@@percentage@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';
            $("#trBiddingPriceIncDec").hide();
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
        }
        $('#trBidCurrency').hide();
    }
    
    if(map['eventTypeId']=='1'){
        $('#lblDecIncMultiple').text(varIncMultiple);
        $('#lblDecIncVal').text(varIncVal);
        //$('#lblIncDecTimes').text(varlblaucinctimes);
        $("#lblIncDecInTimes").text(varlblinctimes);
        $("#txtIncDecInTimes").attr('title',varlblinctimes);
        $('#lblDecIncVal').append('<span> *</span>');
        $('#txtIncDecValue').attr("title",varIncVal);
        $('#lblDecIncType').text(varIncType);
        $('#lblIncDecInPeriod').text(varIncInPeriod);
        $('#lblIncDecInPeriod').append('<span> * </span>');
        $('#txtTimeForIncDecToItem').attr("title",varIncInPeriod);
        $('#lblIncDecInPerReq').text(varIncRequire);
        $('#lblIncDecExt').text(varIncExt);
        $('#lblIncDecExt').append('<span> *</span>');
        $('#txtIncDecDuringExt').attr("title",varIncExt);
        $('#lblItemWiseIncDecValMsg').text(varItemWiseIncValMsg);
        $('#lblItemWiseTimeIncDecValMsg').text(varItemWiseIncPriceStartEndDateMsg);
        $('#lblSepDecIncVal').text(varspecincvalue);
        $('#lblSepDecIncVal').append('<span> * </span>');
        $('#txtSepIncDecValue').attr("title",varspecincvalue);
        $('#lblIncDecRulesOn').text(varincrules);
        $('#sprdFirstBidCond_1').text(varfirstBidCondAddIncVal);
        $('#sprdIncDecRules_0').text(incdecononeitem);
        $('#sprdIncDecRules_1').text(incdeconallitems);
        $('#trIsNegotiationAllow').hide();
        $('#selIsNegotiationAllow option[value="2Js7vmaJbs8="]').prop('selected', true);
        if($('#lblDispL1H1Amt')!=null){
            $('#lblDispL1H1Amt').text(vardispH1amt);
        }
		if(hideMap['isEmdReq']=='false'){
			$('#tdEmd').hide();
		}else{
			if(clientPaymentConfigure != 0 ){
				$('#trEmd').show();
			}else{
				$('#trEmd').hide();
			}
		}
		if(hideMap['biddingCapacity']=='false'){
			$('#tdBiddingCapacity').hide();
			$('#txtBiddingCapacity').attr("tovalid","false");
		}
    }
    else{
        $('#lblDecIncMultiple').text(varDecMultiple);
        $('#lblDecIncVal').text(varDecVal);
        $('#lblIncDecTimes').text(varlblaucdectimes);
        $("#lblIncDecInTimes").text(varlbldectimes);
        $("#txtIncDecInTimes").attr('title',varlbldectimes);
        $('#lblDecIncVal').append('<span> *</span>');
        $('#lblIncDecRulesOn').text(vardecrules);
        $('#txtIncDecValue').attr("title",varDecVal);
        $('#lblDecIncType').text(varDecType);
        $('#lblIncDecInPeriod').text(varIDecInPeriod);
        $('#lblIncDecInPeriod').append('<span> * </span>');
        $('#txtTimeForIncDecToItem').attr("title",varIDecInPeriod);
        $('#lblIncDecInPerReq').text(varDecRequire);
        $('#lblIncDecExt').text(varDecExt);
        $('#lblIncDecExt').append('<span> *</span>');
        $('#txtIncDecDuringExt').attr("title",varDecExt)
        $('#lblItemWiseIncDecValMsg').text(varItemWiseDecValMsg);
        $('#lblItemWiseTimeIncDecValMsg').text(varItemWiseDecPriceStartEndDateMsg);
        $('#lblSepDecIncVal').text(varspecdecvalue);
        $('#lblSepDecIncVal').append('<span> * </span>');
        $('#txtSepIncDecValue').attr("title",varspecdecvalue);
        $('#sprdFirstBidCond_1').text(varfirstBidCondAddDecVal);
        $('#sprdIncDecRules_0').text(incdecononeitems);
        $('#sprdIncDecRules_1').text(decinallitems);
        if((hideMap['editValIsNegAllow'] != "1")&&(hideMap['editValIsNegAllow'] != "0")){
        	if(hideMap['valIsNegAllow']==1){
				$('#selIsNegotiationAllow option[value="nIFOHNH0pTI="]').prop('selected', true);
			}else{
				$('#selIsNegotiationAllow option[value="2Js7vmaJbs8="]').prop('selected', true);
			}
        }
        if(hideMap['isNegAllow']=='true'){
    		$('#trIsNegotiationAllow').show();
    	}else{
    		$('#trIsNegotiationAllow').hide();
    	}
        if($('#lblDispL1H1Amt')!=null){
            $('#lblDispL1H1Amt').text(vardispL1amt);
        }
        if(hideMap['isEmdReq']=='false'){
			$('#tdEmd').hide();
		}
	}
    if(map['auctionType']=="2"){
        $('#displayrank1').hide();
        $('#trWinBidderName').hide();
        if(hideMap['showWinningAmount']=='true'){
            $('#trDispH1L1Amt').show();
        }else{
            $('#trDispH1L1Amt').hide();
        }
        $('#trDispWinningBid').hide();
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        if($('input[id=rdDispL1H1Price]:checked').val()==1){
            if(hideMap['showWinningBid']=='true'){
                $('#trDispWinningBid').show();
            }else{
                $('#trDispWinningBid').hide();
            }
            if(hideMap['showWinnerName']=='true'){
                $('#trWinBidderName').show();
            }else{
                $('#trWinBidderName').hide();
            }
        }
        if($('input[id=rdIsAutoExt]:checked').val()==1){
            if(hideMap['rankForExt']=='true'){
                $('#trExtOnReceiveBidbyRank').show();
                $('#txtRankForExt').attr('tovalid','true');
            }else{
                $('#trExtOnReceiveBidbyRank').hide(); 
                $('#txtRankForExt').attr('tovalid','false');
            }
        }else{
            $('#trExtOnReceiveBidbyRank').hide();
            $('#txtRankForExt').attr('tovalid','false');
        }
        $('#trGreaterRank').show();
        if(hideMap['isEncodedName']=='true'){
            $('#trEncodeBidderName').show();   
        }
        var validarr = $('#txtRankForExt').attr("validarr");
        if(map['isRankForExtRequired']=='1'){
            $('#rankForExtM').val('*');
            if(validarr.indexOf('required@@')==-1){                        
                $('#txtRankForExt').attr("validarr",'required@@'+validarr);
            }
        }else{
            $('#rankForExtM').val('');
            if(validarr.indexOf('required@@')!=-1){                        
                $('#txtRankForExt').attr("validarr",validarr.replace('required@@',''));
            }
        }
        
    }else{
        if($('input[id=rdAccess]:checked').val()==2){
            bidderWiseStartPriceShowHide();
            bidderWiseQtyAllocationReq();
        }
        
        if(hideMap['showWinnerName']=='true'){
            $('#trWinBidderName').show();
        }else{
            $('#trWinBidderName').hide();
        }
        
        $('#trDispRank').show();
        $('#trDispH1L1Amt').hide();
        $('#trDispWinningBid').hide();
        $('#trExtOnReceiveBidbyRank').hide();
        $('#txtRankForExt').attr('tovalid','false');
        if($('input[id=rdIsBidderNameMasking]:checked').val()==1){
        	if(hideMap['greaterRank']=='true'){
        		$('#trGreaterRank').show();
        	}
            if(hideMap['isEncodedName']=='true'){
                $('#trEncodeBidderName').show();
            }
        }else{
        	$('#trGreaterRank').hide();
            $('#trEncodeBidderName').hide();
        }
    }
	if(hideMap['greaterRank']=='false'){
		$('#trGreaterRank').hide();
	}
    if(map['auctionType']==1){
        if(map['isBidderNameMasking']=='0'){
        	$('#trGreaterRank').hide();
            $('#trEncodeBidderName').hide();
            $('#txtGreaterRank').attr('tovalid', 'false');
        }else{
            if(hideMap['isEncodedName']=='true'){
                $('#trEncodeBidderName').show();
            }
            if(hideMap['greaterRank']=='true'){
            	$('#trGreaterRank').show();
            }
            $('#txtGreaterRank').attr('tovalid', 'true');
        }
    }
    if(map['incDecType']=='2'){
        $('#trAutoBid').hide();        
        var attrVal='required@@lengthForNum:3@@percentage@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';        
        $('#txtIncDecValue').attr('validarr', attrVal);
        $('#txtIncDecDuringExt').attr('validarr', attrVal);
        $('#txtSepIncDecValue').attr('validarr', attrVal);
        $('#IncDicMult').hide();   
       // $('#txtIncDecValue')
    }else{
        if($('input[id=rdBidderWiseStartPrc]:checked').val()==0 && $('input[id=rdBiddingType]:checked').val()==1){        	
        	if(hideMap['isAutoBidAllowed']=='true'){
        		$('#trAutoBid').show();
        	}
        }else{
            $('#trAutoBid').hide();
        }
        if($('input[id=rdBiddingType]:checked').val()==1){
            var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';            
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
            if(hideMap['incDecInMultiple']=='true' && $('input[id=rdIncDecType]:checked').val()==1 && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                $('#IncDicMult').show();
            }
        }else{
            var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';            
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
            $('#IncDicMult').hide();
        }
    }
    var validarr = $('#txtReservePrice').attr("validarr");
    if(map['checkReservePrice']=='1'){
        $('#resPriceM').text('*');
        if(validarr.indexOf('required@@')==-1){                        
            $('#txtReservePrice').attr("validarr",'required@@nonzero@@'+validarr);
        }
        if(hideMap['isShowReservePriceToBidder']=='true'){
        	$("#tdShowResPriceToBidder").show();
        }else{
        	$("#tdShowResPriceToBidder").hide();
        }
    }else{
        $('#resPriceM').text('');
        if(validarr.indexOf('required@@')!=-1){                        
            $('#txtReservePrice').attr("validarr",validarr.replace('required@@nonzero@@',''));
        }
        $("#tdShowResPriceToBidder").hide();
    }
    if(map['auctionResult'] == '2' ){
        if($('input[id=rdBiddingType]:checked').val()==1){
        	if(hideMap['incDecType']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                //$('#trIncDecType').show();
            	$('#tdBiddingPriceType').show();
            }
        	if(hideMap['incDecInMultiple']=='true' && $('input[id=rdIncDecType]:checked').val()==1 && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
            	$('#IncDicMult').show();
            }
        }
        
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        $("#tdIncDecInTimes").hide();
		$('#txtIncDecInTimes').attr('tovalid','false');
		if($('input[id=rdIncDecType]:checked').val()==2){
    		$("#trBiddingPriceIncDec").hide();
    	}

		if(hideMap['BiddingPriceIncrementInTimes']=='true' && $('input[id=rdIncDecType]:checked').val()==1){
			$("#trBiddingPriceIncDec").show();
		}else{
			$("#trBiddingPriceIncDec").hide();
		}
		$('#trGrandTtlPrc').hide();
        $('#txtStartPrice').attr('tovalid', 'false');
        $('#txtReservePrice').attr('tovalid', 'false');
        $('#trIncDecVal').hide();
        $('#txtIncDecValue').attr('tovalid', 'false');
        $('#trIncDecExt').hide();
        $('#trIncDecRuleOn').hide();
        $('#txtIncDecDuringExt').attr('tovalid', 'false'); 
        $('#trItemWiseMsg').show();
        $('#trItemWiseTimeReqMsg').hide();
        $('#trIncDecCertPerValue').hide();
        $('#txtSepIncDecValue').attr('tovalid','false');
        $('#trItemWiseTimeReq').show();                     
        if($('input[id=rdIsItemWiseTime]:checked').val()=='0'){ 
        	if(hideMap['isitemSelection'] == 'true'){
            	$('#tdItemSelectionReq').show();
            }else{
            	$('#tdItemSelectionReq').hide();
            }
        	$('#trConfigureTimeforItem').hide();
            if($('input[id=rdIncDecCertPrdTime]:checked').val()=='1'){ 
                $('#trIncDecCertPrdTime').show();
                $('#txtTimeForIncDecToItem').attr('dtrequired','true');
                $('#txtTimeForIncDecToItem').attr('comparewith','txtStartDate,txtEndDate');
            }else{
                $('#trIncDecCertPrdTime').hide();
                $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
                $('#txtTimeForIncDecToItem').removeAttr('comparewith');
            }
            $('#trAucStartEndDate').show();
            if($('input[id=rdExtMode]:checked').val()=='1'){
                if(hideMap['totalExt']=='true'){
                    $('#trNoOfExt').show();
                }else{
                    $('#trNoOfExt').hide(); 
                }
                $('#txtTotalExt').attr('tovalid','true');
            }else{
                $('#trNoOfExt').hide();
                $('#txtTotalExt').attr('tovalid','false');
            }
            
            $('#extWhenAndBy').show();
            if(hideMap['extendWhen']=='true'){
                $('#extendWhen1').show();
                $('#extendWhen2').show();
            }else{
                $('#extendWhen1').hide();
                $('#extendWhen2').hide();
            }
            if(hideMap['extendBy']=='true'){
                $('#extendBy1').show();
                $('#extendBy2').show();
            }else{
                $('#extendBy1').hide();
                $('#extendBy2').hide();
            }
            $('#txtExtendWhen').attr('tovalid','true');
            $('#txtExtendBy').attr('tovalid','true');
            $('#txtStartDate').attr('dtrequired','true');
            $('#txtStartDate').attr('isgreater','true');
            if(eval(isApproved) == true && opType == 'edit'){
                $('#txtStartDate').attr('comparetocurrdate','false');
            }else{
                $('#txtStartDate').attr('comparetocurrdate','true');
            }                        
            $('#txtEndDate').attr('dtrequired','true');
            $('#txtEndDate').attr('isgreater','true');
            $('#txtEndDate').attr('comparewith','txtStartDate');
            
        }else{
        	 $('#trConfigureTimeforItem').show();
        	 if($('input[id=rdConfigureTimeForItem]:checked').val()=='1'){ 
        	    	$('#thItemDuration').hide();
        	    	$('#tdItemDuration').hide();
        	    	if(hideMap['isitemSelection'] == 'true'){
                    	$('#tdItemSelectionReq').show();
                    }else{
                    	$('#tdItemSelectionReq').hide();
                    }
        	    	$("#trIncDecInPeriod").show();
    	    }else  if($('input[id=rdConfigureTimeForItem]:checked').val()=='2'){ 
        	    	$('#thItemDuration').show();
        	    	$('#tdItemDuration').show();
        	    	$('#tdItemSelectionReq').hide();
        	    	$("#trIncDecInPeriod").hide();
    	    }
        	
            if($('#trIncDecCertPrdTime')!=null){
                $('#trIncDecCertPrdTime').hide();
                $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
                $('#txtTimeForIncDecToItem').removeAttr('comparewith');
            }
            $('#trAucStartEndDate').hide();
            $('#trNoOfExt').hide();
            $('#txtTotalExt').attr('tovalid','false');
            $('#extWhenAndBy').hide();
            $('#txtExtendWhen').attr('tovalid','false');
            $('#txtExtendBy').attr('tovalid','false');
            $('#txtStartDate').removeAttr('dtrequired');
            $('#txtStartDate').removeAttr('isgreater');
            $('#txtStartDate').removeAttr('comparetocurrdate');
            $('#txtEndDate').removeAttr('dtrequired');
            $('#txtEndDate').removeAttr('isgreater');
            $('#txtEndDate').removeAttr('comparewith');
            if($('input[id=rdIsAutoExt]:checked').val()=='1'){
                $('#trItemWiseTimeForAutoExt').show();
            }
            $('#trItemWiseTimeReqMsg').show();
            $('#trItemWiseMsg').hide();
			$('#tdShowWinAmountOnListing').hide();
			$('#selIsShowWinAmountOnListing').attr('tovalid','false');
        }     
    }else  if(map['auctionResult']== '1'  || map['auctionResult']== '3'){
    	$('#trConfigureTimeforItem').hide();
    	/*if(map['auctionResult']== '1'){*/
    		
	    	if(hideMap['valBiddingPriceIncrementInTimes']=='1' && $('input[id=rdIncDecType]:checked').val()==1){
	    		if(hideMap['BiddingPriceIncrementInTimes']=='true' && $('input[id=rdIncDecType]:checked').val()==1){
	    			$("#trBiddingPriceIncDec").show();
	    		}else{
	    			$("#trBiddingPriceIncDec").hide();
	    		}
	    		$('#txtIncDecInTimes').attr('tovalid','true');
	    		$('#txtIncDecInTimes').attr('tovalid','true');
			}else if(hideMap['valBiddingPriceIncrementInTimes']=='0'){
					$("#tdIncDecInTimes").hide();
					$('#txtIncDecInTimes').attr('tovalid','false');
				}
    	/*}else {
    		$("#trBiddingPriceIncDec").hide();
    		$('#txtIncDecInTimes').attr('tovalid','false');
    	}*/
        if(map['auctionMode']==2 && map['auctionResult'] == 3){
            if(hideMap['incDecRuleOn']=='true'){
                $('#trIncDecRuleOn').show();
            }else{
                $('#trIncDecRuleOn').hide();
            }
        }else{
            if(map['auctionMode']==1 && map['auctionResult'] == 3){
                $('input:radio[name=rdAuctionResult]')[0].checked = true;
            }
            $('#trIncDecRuleOn').hide();
        }
        if($('input[id=rdBiddingType]:checked').val()==1){
        	if(hideMap['incDecType']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                //$('#trIncDecType').show();
            	$('#tdBiddingPriceType').show();
            }
        	if(hideMap['incDecInMultiple']=='true' && $('input[id=rdIncDecType]:checked').val()==1 && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
            	$('#IncDicMult').show();
            }
        }
        
        bidderWiseStartPriceShowHide();
        bidderWiseQtyAllocationReq();
        $('#trGrandTtlPrc').show();
        $('#trItemWiseTimeForAutoExt').hide();
        $('#trItemWiseTimeReqMsg').hide();
        $('#trItemWiseMsg').show();
        $('#txtStartPrice').attr('tovalid', 'true');
        $('#txtReservePrice').attr('tovalid', 'true');
        $('#trIncDecVal').show();
        $('#txtIncDecValue').attr('tovalid', 'true');
        $('#trIncDecExt').show();
        $('#txtIncDecDuringExt').attr('tovalid', 'true'); 
        $('#trItemWiseMsg').hide();
        if( $('#trItemWiseTimeReq')!=null){
            $('#trItemWiseTimeReq').hide();
        }
        $('#extWhenAndBy').show();
        if(hideMap['extendWhen']=='true'){
            $('#extendWhen1').show();
            $('#extendWhen2').show();
        }else{
            $('#extendWhen1').hide();
            $('#extendWhen2').hide();
        }
        if(hideMap['extendBy']=='true'){
            $('#extendBy1').show();
            $('#extendBy2').show();
        }else{
            $('#extendBy1').hide();
            $('#extendBy2').hide();
        }
        $('#txtExtendWhen').attr('tovalid','true');
        $('#txtExtendBy').attr('tovalid','true');
        if($('input[id=rdIncDecCertPrdTime]:checked').val()=='1'){ 
            $('#trIncDecCertPrdTime').show();
            $('#txtTimeForIncDecToItem').attr('dtrequired','true');
            $('#txtTimeForIncDecToItem').attr('comparewith','txtStartDate,txtEndDate');
            $('#trIncDecCertPerValue').show();
            $('#txtSepIncDecValue').attr('tovalid','true');
        }else{
            $('#trIncDecCertPrdTime').hide();
            $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
            $('#txtTimeForIncDecToItem').removeAttr('comparewith');
            $('#trIncDecCertPerValue').hide();
            $('#txtSepIncDecValue').attr('tovalid','false');
        }
        $('#trAucStartEndDate').show();
        if($('input[id=rdExtMode]:checked').val()=='1'){
            if(hideMap['totalExt']=='true'){
                $('#trNoOfExt').show();
            }else{
                $('#trNoOfExt').hide();
            }
            $('#txtTotalExt').attr('tovalid','true');
        }else{
            $('#trNoOfExt').hide();
            $('#txtTotalExt').attr('tovalid','false');
        }
        $('#extWhenAndBy').show();
        if(hideMap['extendWhen']=='true'){
            $('#extendWhen1').show();
            $('#extendWhen2').show();
        }else{
            $('#extendWhen1').hide();
            $('#extendWhen2').hide();
        }
        if(hideMap['extendBy']=='true'){
            $('#extendBy1').show();
            $('#extendBy2').show();
        }else{
            $('#extendBy1').hide();
            $('#extendBy2').hide();
        }
        $('#txtExtendWhen').attr('tovalid','true');
        $('#txtExtendBy').attr('tovalid','true');
        if($('input[id=rdBiddingType]:checked').val()==1){
            if(map['auctionMode']==2 && map['auctionResult'] == 3 ){
                var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';
                $('#txtIncDecValue').attr('validarr', attrVal);
                $('#txtIncDecDuringExt').attr('validarr', attrVal);
                $('#txtSepIncDecValue').attr('validarr', attrVal);
                //$('#trIncDecType').hide();
                $('#tdBiddingPriceType').hide();
                $('#IncDicMult').hide();
//                if(hideMap['incDecInMultiple']=='true'){
//                    $('#IncDicMult').show();
//                }
            }else{
            	if(hideMap['incDecType']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                	$('#tdBiddingPriceType').show();
                }
            	if(hideMap['incDecInMultiple']=='true' && $('input[id=rdIncDecType]:checked').val()==1 && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                	$('#IncDicMult').show();
                }
                if($('input[id=rdIncDecType]:checked').val()==1){
                    var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';
                    $('#txtIncDecValue').attr('validarr', attrVal);
                    $('#txtIncDecDuringExt').attr('validarr', attrVal);
                    $('#txtSepIncDecValue').attr('validarr', attrVal);
                    if(hideMap['incDecInMultiple']=='true' && $('input[id=rdBiddingType]:checked').val()==1 && ($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='2')){
                        $('#IncDicMult').show();
                    }
                }else{
                    var attrVal='required@@lengthForNum:3@@percentage@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';
                    $('#txtIncDecValue').attr('validarr', attrVal);
                    $('#txtIncDecDuringExt').attr('validarr', attrVal);
                    $('#txtSepIncDecValue').attr('validarr', attrVal);
                }
            }
        }else{
            var attrVal='required@@lengthForNum:15@@numanduptodecimal:'+varUptoDecimal+'@@nonzero';
            $('#txtIncDecValue').attr('validarr', attrVal);
            $('#txtIncDecDuringExt').attr('validarr', attrVal);
            $('#txtSepIncDecValue').attr('validarr', attrVal);
            $('#IncDicMult').hide();
            //$('#trIncDecType').hide();
            $('#tdBiddingPriceType').hide();
            $('#IncDicMult').hide();

        }
        $('#txtStartDate').attr('dtrequired','true');
        $('#txtStartDate').attr('isgreater','true');
        if(eval(isApproved) == true && opType == 'edit'){
            $('#txtStartDate').attr('comparetocurrdate','false');
        }else{
            $('#txtStartDate').attr('comparetocurrdate','true');
        }                
        $('#txtEndDate').attr('dtrequired','true');
        $('#txtEndDate').attr('isgreater','true');
        $('#txtEndDate').attr('comparewith','txtStartDate');
		
		$('#tdShowWinAmountOnListing').show();
		if(hideMap['showWinAmountOnListing']=='false'){
			$('#tdShowWinAmountOnListing').hide();
			$('#selIsShowWinAmountOnListing').attr('tovalid','false');
		}
    }
    if(map['auctionResult']== '2')
    {
		if($('input[name=rdAuctionResult]:checked').val()=='2'){
			if(hideMap['isitemSelection']=='false'){
				$('#tdItemSelectionReq').hide();
				$('#selIsItemSelection').attr('tovalid','false');
			}
			if(hideMap['isMinQtyReq']=='false'){
				$('#tdShowMinQtyReq').hide();
				bidderWiseQtyAllocationReq();
				$('#selIsMinQtyReq').attr('tovalid','false');
			}
		}
        if(map['isItemWiseTime']=='1'){
            $('#trItemWiseTimeReqMsg').show();
            $('#trItemWiseMsg').hide();
            $('#trAucStartEndDate').hide();
            $('#txtStartDate').removeAttr('dtrequired');
            $('#txtStartDate').removeAttr('isgreater');
            $('#txtStartDate').removeAttr('comparetocurrdate');
            $('#txtEndDate').removeAttr('dtrequired');
            $('#txtEndDate').removeAttr('isgreater');
            $('#txtStartDate').removeAttr('comparewith');
            if($('#trIncDecCertPerValue')!=null){
                $('#trIncDecCertPerValue').hide();
                $('#txtSepIncDecValue').attr('tovalid','false');
            }
            $('#trIncDecCertPrdTime').hide();
            $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
            $('#txtTimeForIncDecToItem').removeAttr('comparewith');
            $('#trItemWiseTimeForAutoExt').show();
            if($('#trNoOfExt')!=null){
                $('#trNoOfExt').hide();
                $('#txtTotalExt').attr('tovalid','false');
            }
            $('#trIncDecExt').hide();
            $('#txtIncDecDuringExt').attr('tovalid', 'false'); 
            $('#extWhenAndBy').hide();
            $('#txtExtendWhen').attr('tovalid','false');
            $('#txtExtendBy').attr('tovalid','false');
        }
        else{
            $('#trItemWiseTimeReqMsg').hide();
            $('#trItemWiseMsg').show();
            $('#trAucStartEndDate').show();
            $('#txtStartDate').attr('dtrequired','true');
            $('#txtStartDate').attr('isgreater','true');
            if(eval(isApproved) == true && opType == 'edit'){
                $('#txtStartDate').attr('comparetocurrdate','false');
            }else{
                $('#txtStartDate').attr('comparetocurrdate','true');
            }                      
            $('#txtEndDate').attr('dtrequired','true');
            $('#txtEndDate').attr('isgreater','true');
            $('#txtEndDate').attr('comparewith','txtStartDate');
            $('#trIncDecCertPerValue').hide();
            $('#txtSepIncDecValue').attr('tovalid','false');
            if($('input[name=rdIncDecCertPrdTime]:checked').val()==1){
                $('#trIncDecCertPrdTime').show();
                $('#txtTimeForIncDecToItem').attr('dtrequired','true');
                $('#txtTimeForIncDecToItem').attr('comparewith','txtStartDate,txtEndDate');
            }else{
                $('#trIncDecCertPrdTime').hide();
                $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
                $('#txtTimeForIncDecToItem').removeAttr('comparewith');
            }
            $('#trItemWiseTimeForAutoExt').hide();
            if(hideMap['totalExt']=='true'){
                $('#trNoOfExt').show();
            }else{
                $('#trNoOfExt').hide();
            }
            $('#txtTotalExt').attr('tovalid','true');
            $('#extWhenAndBy').show();
            if(hideMap['extendWhen']=='true'){
                $('#extendWhen1').show();
                $('#extendWhen2').show();
            }else{
                $('#extendWhen1').hide();
                $('#extendWhen2').hide();
            }
            if(hideMap['extendBy']=='true'){
                $('#extendBy1').show();
                $('#extendBy2').show();
            }else{
                $('#extendBy1').hide();
                $('#extendBy2').hide();
            }
            $('#txtExtendWhen').attr('tovalid','true');
            $('#txtExtendBy').attr('tovalid','true');
        } 
    }
    if(map['isIncDecInPeriod']=='1'){
        if(($('input[id=rdIsItemWiseTime]:checked').val()=='0' && $('input[name=rdAuctionResult]:checked').val()=='2') ||  $('input[name=rdAuctionResult]:checked').val()=='1'  || $('input[name=rdAuctionResult]:checked').val()=='3'){
            $('#trIncDecCertPrdTime').show();
            $('#txtTimeForIncDecToItem').attr('dtrequired','true');
            $('#txtTimeForIncDecToItem').attr('comparewith','txtStartDate,txtEndDate');
            if ($('input[name=rdAuctionResult]:checked').val()=='1'  ||$('input[name=rdAuctionResult]:checked').val()=='3'){
                $('#trIncDecCertPerValue').show();
                $('#txtSepIncDecValue').attr('tovalid','true');
            }else{
                $('#trIncDecCertPerValue').hide();
                $('#txtSepIncDecValue').attr('tovalid','false');
            }
        }
    }else{
        if($('#trIncDecCertPrdTime')!=null){
            $('#trIncDecCertPrdTime').hide();
            $('#txtTimeForIncDecToItem').removeAttr('dtrequired');
            $('#txtTimeForIncDecToItem').removeAttr('comparewith');
        }        
        $('#trIncDecCertPerValue').hide();
        $('#txtSepIncDecValue').attr('tovalid','false');
                    
    }
    if(map['isAutoExt']=='1'){
    	if(hideMap['extMode']=='true'){
    		$('#trExtMode').show();
    	}
        $('#trIncDecExt').hide();
        $('#txtIncDecDuringExt').attr('tovalid', 'false'); 
        if(($('input[name=rdIsItemWiseTime]:checked').val()=='0' && $('input[name=rdAuctionResult]:checked').val()=='2') || $('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='3'){
            if(hideMap['totalExt']=='true'){
                if($('input[id=rdExtMode]:checked').val()=='1'){
                    $('#trNoOfExt').show();
                    $('#txtTotalExt').attr('tovalid','true');
                }
            }else{
                $('#trNoOfExt').hide();
                $('#txtTotalExt').attr('tovalid','false');
            }
            $('#trItemWiseTimeForAutoExt').hide();     
            $('#extWhenAndBy').show();
            if(hideMap['extendWhen']=='true'){
                $('#extendWhen1').show();
                $('#extendWhen2').show();
            }else{
                $('#extendWhen1').hide();
                $('#extendWhen2').hide();
            }
            if(hideMap['extendBy']=='true'){
                $('#extendBy1').show();
                $('#extendBy2').show();
            }else{
                $('#extendBy1').hide();
                $('#extendBy2').hide();
            }
            $('#txtExtendWhen').attr('tovalid','true');
            $('#txtExtendBy').attr('tovalid','true');
        }else{
            $('#trNoOfExt').hide();
            $('#txtTotalExt').attr('tovalid','false');
            $('#extWhenAndBy').hide();
            $('#txtExtendWhen').attr('tovalid','false');
            $('#txtExtendBy').attr('tovalid','false');
        }
                 
        if($('input[id=rdAucType]:checked').val()=='2'){    
            if(hideMap['rankForExt']=='true'){
                $('#trExtOnReceiveBidbyRank').show();
                $('#txtRankForExt').attr('tovalid','true');
            }else{
                $('#trExtOnReceiveBidbyRank').hide();
                $('#txtRankForExt').attr('tovalid','false'); 
            }
        }else{
            $('#trExtOnReceiveBidbyRank').hide();
            $('#txtRankForExt').attr('tovalid','false');
        }
        if($('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='3'){
            $('#trIncDecExt').show();
            $('#txtIncDecDuringExt').attr('tovalid', 'true'); 
        }
    }else{
        $('#trNoOfExt').hide();
        $('#txtTotalExt').attr('tovalid','true');
        $('#trExtMode').hide();
        $('#extWhenAndBy').hide();
        $('#txtExtendWhen').attr('tovalid','false');
        $('#txtExtendBy').attr('tovalid','false');
        $('#trIncDecExt').hide();
        $('#txtIncDecDuringExt').attr('tovalid', 'false'); 
        $('#trExtOnReceiveBidbyRank').hide();
        $('#txtRankForExt').attr('tovalid','false');
    }
    if(map['extMode']=='1'){
        if(($('input[id=rdIsItemWiseTime]:checked').val()=='0' && $('input[name=rdAuctionResult]:checked').val()=='2') || $('input[name=rdAuctionResult]:checked').val()=='1' || $('input[name=rdAuctionResult]:checked').val()=='3'){
            if(hideMap['totalExt']=='true' && map['isAutoExt']=='1'){
                $('#trNoOfExt').show();
            }else{
                $('#trNoOfExt').hide();
            }
            $('#txtTotalExt').attr('tovalid','true');
        }else{
            $('#trNoOfExt').hide();
            $('#txtTotalExt').attr('tovalid','false');
        }
    }else{
        $('#trNoOfExt').hide();
        $('#txtTotalExt').attr('tovalid','false');
    }
    if(map['auctionType']=="2"){
        if(map['showWinningAmount']=='1'){
            if( hideMap['showWinningBid']=='true'){
                $('#trDispWinningBid').show();
            }else{
                $('#trDispWinningBid').hide();
            }
            if(hideMap['showWinnerName']=='true')
                $('#trWinBidderName').show();
            else
                $('#trWinBidderName').hide();
        }else{
            $('#trDispWinningBid').hide();
            $('#trWinBidderName').hide();
        }
    }
    if(hideMap['isAutoBidAllowed']=='false' || $('input[id=rdBiddingType]:checked').val()==2 || $('input[id=rdIncDecType]:checked').val()==2){
		$('#trAutoBid').hide();
	}
	else{
		$('#trAutoBid').show();
	}
	var selEventTypeId = $('#selEventType :selected').val();
	if(selEventTypeId=='1'){
		$('#tdEmdMode').show();
		$('#tdEmdFees').show();
		$('#selEmdMode').attr("tovalid","true");
		$('#txtEmdAmt').attr("tovalid","true");
	}
	else{
		$('#tdEmdMode').hide();
		$('#tdEmdFees').hide();
		$('#selEmdMode').attr("tovalid","false");
		$('#txtEmdAmt').attr("tovalid","false");
	}
	var selEmdModeReq = $('#selIsEmdReq :selected').val();
	var selEmdPaymentMode = $('#selEmdPaymentMode :selected').val();
	if(selEmdModeReq=='1'){
		/*if(hideMap['emdPaymentMode']=='true'){*/
		if(clientPaymentConfigure == 1 || clientPaymentConfigure == 3 ){
			$('#trAucEmdMode').show();
			$('#tdEmdMode').show();
			$('#selEmdPaymentMode').attr("tovalid","true");
		}else{
			$('#trAucEmdMode').hide();
			$('#tdEmdMode').hide();
			$('#selEmdPaymentMode').attr("tovalid","false");
		}
		/*}else{
			$('#trAucEmdMode').hide();
			$('#tdEmdMode').hide();
			$('#selEmdPaymentMode').attr("tovalid","true");
		}*/
		$('#tdEmdFees').show();
		$('#txtEmdAmt').attr("tovalid","true");
		var eventType=$('#selEventType').val();
		if(eventType == 1){
			//$("#trBidCap").show();
			if(hideMap['isBidCapicityReq'] == 'true'){
				$('#tdIsBidCapicityReq').show();
			}
			if(hideMap['biddingCapacity'] == 'true'){
				$("#tdBiddingCapacity").show();
				$('#txtBiddingCapacity').attr("tovalid","true");
			}else{
				$('#txtBiddingCapacity').attr("tovalid","false");
			}
		}else{
			$('#tdIsBidCapicityReq').hide();
			
				$('#selisBidCapacityReq').val(0);
			
			$("#tdBiddingCapacity").hide();
			$('#txtBiddingCapacity').attr("tovalid","false");
			//$("#trBidCap").hide();
		}
		/*if(hideMap['biddingCapacity']=='true'){
			$('#tdBiddingCapacity').show();
			$('#txtBiddingCapacity').attr("tovalid","true");
		}else{
			$('#tdBiddingCapacity').hide();
			$('#txtBiddingCapacity').attr("tovalid","false");
		}*/
		if(selEmdPaymentMode=='1'){
			$('#txtaEmdPayableAt').attr("tovalid","false");
		}
		else{
			$('#txtaEmdPayableAt').attr("tovalid","true");
		}
		//$('#txtBiddingCapacity').attr("tovalid","true");
	}
	else{
		$('#trAucEmdMode').hide();
		$('#tdEmdFees').hide();
		$('#txtaEmdPayableAt').attr("tovalid","false");
		$('#tdBiddingCapacity').hide();
		$('#txtBiddingCapacity').attr("tovalid","false");
		$('#txtEmdAmt').attr("tovalid","false");
		//$("#trBidCap").hide();	
	}	
    showMobAutoBid();	// CR:20108 Nirav Raval
    hideAutoBid();
    showHideIsDecodeBidder(); // PT: 20336
    showHideGreateRank($("#rdIsBidderNameMasking:checked").val());
    doShowHideRegTr();
    if($("#rdIsBidderNameMasking:checked").val() == '0')
    {
    	$("#isDecodeBidderTr").hide();
    	$('input[name=rdIsDecodeBidder][value="0"]').first().attr('checked','checked'); // set value to 0 if mask bidder is no.
    }
    
    var selEmdPaymentMode = $('#selEmdPaymentMode :selected').val();
    if(selEmdPaymentMode == '2' && hideMap['emdPayableAt']=='true'){
		$('#tdEmdPayableAt').show();
		$('#txtaEmdPayableAt').attr("tovalid","true");
	}
	else{
		$('#tdEmdPayableAt').hide();
		$('#txtaEmdPayableAt').attr("tovalid","false");
	}
    if($('input[name=rdAucType]:checked').val()==1 && $('input[name=rdAuctionResult]:checked').val()==2 && $('input[name=rdAccess]:checked').val()==2 && $('input[name=rdIsAutoBidAllowed]:checked').val()==0 && hideMap['isRestrictH1Bidder'] == 'true'){
    	$("#tdRestrictH1Bidder").show();
    }else{
    	$("#tdRestrictH1Bidder").hide();
    }
    var eventType=$('#selEventType').val();
	if(eventType == 1){
		$('#lblRestrictL1H1Bidder').text(varrestrictH1bidder);
	}else{
		$('#lblRestrictL1H1Bidder').text(varrestrictL1bidder);
	}
    
	if($('input[name=rdAuctionResult]:checked').val()==1 &&  $("#selIsEmdReq").val()==1 && $("#selEventType").val()==1 && clientPaymentConfigure != 0){
		if(hideMap['isRestOfAucMoneyRequired'] == 'true'){
			$("#trRestOfAuctionMoney").show();
		}else{
			$("#trRestOfAuctionMoney").hide();
		}
		
	}else{
		$("#trRestOfAuctionMoney").hide();
	}
	showHideEMDNBidCapacity();
	if(clientPaymentConfigure == 1 || clientPaymentConfigure == 3 ){
		$("#noteMsgEmdMode").hide();
		if(hideMap['isEmdReq']=='false'){
			$('#trEmd').hide();
		}else{
			$('#trEmd').show();
		}
		
	}else{
		if($("#selIsEmdReq").val()==1){
			$("#noteMsgEmdMode").show();
		}else{
			$("#noteMsgEmdMode").hide();
		}
		if(clientPaymentConfigure == 2){
			if(hideMap['isEmdReq']=='false'){
				$('#trEmd').hide();
				$('#txtEmdAmt').attr('tovalid','false');
			}else{
				$('#trEmd').show();
			}
		}else{
			$('#trEmd').hide();
			$('#txtEmdAmt').attr('tovalid','false');
		}
		$('#trBidCap').hide();
		$('#trAucEmdMode').hide();
		$('#selEmdPaymentMode').attr("tovalid","false");
	}
	if(clientPaymentConfigure != 0){
		if(hideMap['registrationChargeAllow'] == 'false'){
			$('#trIsRegistrationCharges').hide();
		}else{
			$('#trIsRegistrationCharges').show();
		}
	}else{
		$('#trIsRegistrationCharges').hide();
		$('#registrationChageTR').hide();
		$("#txtRegistrationCharges").attr("tovalid","false");
		$("#txtRegistrationCharges").val("");
	}
	var aucBaseCur=aucDefBaseCurrency;
    var inputs = $('input:checkbox[id^="chkCurrency_"]'); 
    for(var i=1;i<=inputs.length;i++){ 
        var chkval=  $("#chkCurrency_"+i).val(); 
        if(aucBaseCur==chkval){
            $("#chkCurrency_"+i).attr("checked", true);
            $('#txtCurrency_'+chkval).attr("value",1);
            $('#txtCurrency_'+chkval).attr("readonly", true);
            $('#txtCurrency_'+chkval).parent().find('#divWord').remove();
        }
    }
}

function showHideEMDNBidCapacity(){
	var selEmdModeReq = $('#selIsEmdReq :selected').val();
	var selBidCapReq = $('#selisBidCapacityReq').val();
	if(hideMap['isBidCapacityReq'] == 'false'){
		$('#tdIsBidCapicityReq').hide();
		$('#selisBidCapacityReq').val(map['isBidCapacityReq']);
		
	}else{
		$('#tdIsBidCapicityReq').show();
	}
	var eventType=$('#selEventType').val();
	if(selEmdModeReq == 1){
		if(eventType == 1){
		if(selBidCapReq == 1){
			$('#selEmdPaymentMode').prop("disabled", true);
			$('#selEmdPaymentMode').val(1);
			$('#tdEmdFees').hide();
			$('#txtEmdAmt').attr('tovalid','false');
			hideAutoBid(); //hide
			$("input[name=rdIsAutoBidAllowed][value=0]").prop('checked', true);
		}else{
			$('#selEmdPaymentMode').prop("disabled", true);
			$('#selEmdPaymentMode').val(1);
			$('#tdEmdFees').show();
			$('#txtEmdAmt').attr('tovalid','true');
			$('#tdBiddingCapacity').hide();
			$('#tdBiddingCapacity').attr('tovalid','false');
			hideAutoBid(); //show			
		}
		}else{
			$('#tdIsBidCapicityReq').hide();
			$('#selisBidCapacityReq').val(0);
			
		}
	}else{
		$('#tdEmdFees').hide();
		$('#txtEmdAmt').attr('tovalid','false');
		$('#tdBiddingCapacity').hide();
		$('#txtBiddingCapacity').attr("tovalid","false");
		$('#tdIsBidCapicityReq').hide();
		
	}
}

function bidderWiseStartPriceShowHide(){
    if($('input[id=rdAccess]:checked').val()==2 && ($('input[name=rdAuctionResult]:checked').val()==2 || $('input[name=rdAuctionResult]:checked').val()==3) && $('input[name=rdAucType]:checked').val()==2 && hideMap['isBidderWiseStartPrice']=='true'){
         $('#trBidderWiseStartPrice').show();
    }else{
         $('#trBidderWiseStartPrice').hide();
         $('input[name=rdBidderWiseStartPrc][value="0"]').first().attr('checked','checked');
         hideAutoBid();
    }
}

function bidderWiseQtyAllocationReq(){
    if($('input[id=rdAccess]:checked').val()==2 && $('#selIsMinQtyReq').val() == '0' && hideMap['isBidderWiseQtyAllocationReq']=='true'){
         $('#trBidderWiseQtyReq').show();
    }else{
         $('#trBidderWiseQtyReq').hide();
         $('input[name=rdBidderWiseQtyReq][value="0"]').first().attr('checked','checked');
    }
}

var defaultKeyArr = new Array();
defaultKeyArr.push(9);// Tab
defaultKeyArr.push(13);// enter
defaultKeyArr.push(16);// shift
defaultKeyArr.push(17);// ctrl
defaultKeyArr.push(18);// atl
defaultKeyArr.push(19);// pause/break
defaultKeyArr.push(20);// caps loks
defaultKeyArr.push(27);// escape
defaultKeyArr.push(33);// page up
defaultKeyArr.push(34);// page down
defaultKeyArr.push(35);// end
defaultKeyArr.push(36);// home
defaultKeyArr.push(37);// left arrow
defaultKeyArr.push(38);// up arrow
defaultKeyArr.push(39);// right arrow
defaultKeyArr.push(40);// down arrow
defaultKeyArr.push(45);// insert
defaultKeyArr.push(46);// delete
defaultKeyArr.push(91);// left window key
defaultKeyArr.push(92);// right window key
defaultKeyArr.push(93);// select key
defaultKeyArr.push(112);// f1
defaultKeyArr.push(113);//f2 
defaultKeyArr.push(114);//f3
defaultKeyArr.push(115);//f4
defaultKeyArr.push(116);//f5
defaultKeyArr.push(117);//f6
defaultKeyArr.push(118);//f7
defaultKeyArr.push(119);//f8
defaultKeyArr.push(120);//f9
defaultKeyArr.push(121);//f10
defaultKeyArr.push(122);//f11
defaultKeyArr.push(123);//f12
defaultKeyArr.push(144);//num lock
defaultKeyArr.push(145);//scroll lock
defaultKeyArr.push(186);// semi colon
defaultKeyArr.push(187);//qqual sign

function avoideDefaultKey(key)
{
	    if($.inArray(key,defaultKeyArr) != -1)
	    {   return true;
	    }else{
	    	return false;
	    }
}

function showHideKeyword()
{	
	if(isCategoryAllow == 0){ // if access type is limited
		$("#keywordTR").show();
		$("#txtaAucKeyword").attr("tovalid","true");
	}else if(isCategoryAllow == 1 )// Category allow and brd mode is manual
	{
		$("#keywordTR").hide();
		$("#txtaAucKeyword").attr("tovalid","false");
	}
}
function showHideKeywordAsDefault() ////CR: 18430
{
	if($("#selBrdMode").val() == undefined ) // If brd is hide from default configuration.
		{
			if(isCategoryAllow == 0) // if default value of brd is auto or category is not allow then show keyword. 
				{
					$("#keywordTR").show();
					$("#txtaAucKeyword").attr("tovalid","true");
				}
			else{
					$("#keywordTR").hide();
					$("#txtaAucKeyword").attr("tovalid","false");
				}
		}
}

// CR:20108 Nirav Raval
function showMobAutoBid(){
	if(hideMap['isMobABAllow']=='true' && $('input[id=rdBiddingType]:checked').val() == 1 && $('input[id=rdIncDecType]:checked').val() == 1 && $('input[id=rdBidderWiseStartPrc]:checked').val()==0){
		$('#trIsMobABAllow').show();
	}else{
		$('#trIsMobABAllow').hide();
		$("#selIsMobAutoBidAllowed").val(zero);
	}
}

function showHideIsDecodeBidder()
{
	if($('input[name=rdIsEncodedName]:checked').val()==1){
		if(hideMap['isDecodeBidder'] == 'true'){
			$("#isDecodeBidderTr").show();
		}
	}else{
		$("#isDecodeBidderTr").hide();
		$('input[name=rdIsDecodeBidder][value="0"]').first().attr('checked','checked'); // set value to 0 if encode bidder name is set to no.
	}
}

function doShowHideRegTr()
{
	if($('#selIsRegistrationCharges').val()==1){
			$("#registrationChageTR").show();
			$("#divWord_txtRegistrationCharges").hide();
			$("#txtRegistrationCharges").attr("tovalid","true");
	}else{
		$("#registrationChageTR").hide();
		$("#txtRegistrationCharges").attr("tovalid","false");
		$("#txtRegistrationCharges").val("");
	}
}
function changeEmd(ob){
	var emdMode = $('#selEmdMode :selected').val();
	if($(ob).val() == '1') {
		if(clientPaymentConfigure == 2){
			$("#noteMsgEmdMode").show();
		}
		/*if(hideMap['emdPaymentMode']=='true'){*/
			if(clientPaymentConfigure == 1 || clientPaymentConfigure == 3 ){
				$('#trAucEmdMode').show();
				$('#tdEmdMode').show();
			}else{
				$('#trAucEmdMode').hide();
				$('#tdEmdMode').hide();
			}
			//$('#selEmdPaymentMode').attr("tovalid","true");
		/*}*/
		if($('input[name=rdAuctionResult]:checked').val()==1 && $("#selEventType").val()==1 && clientPaymentConfigure != 0){
			if(hideMap['isRestOfAucMoneyRequired'] == 'true'){
				$("#trRestOfAuctionMoney").show();
			}else{
				$("#trRestOfAuctionMoney").hide();
			}
			
		}else{
			$("#trRestOfAuctionMoney").hide();
		}
		$('#tdEmdFees').show();
		$('#txtEmdAmt').attr("tovalid","true");
		hideAutoBid(); //show
		$('#selEmdPaymentMode').prop("disabled", true);
		$('#selEmdPaymentMode').val(1);
		var eventType=$('#selEventType').val();
		if(eventType == 1){
			//$("#trBidCap").show();
			if(hideMap['isBidCapacityReq'] == 'true'){
				$('#tdIsBidCapicityReq').show();
			}else{
				$('#selisBidCapacityReq').val(map['isBidCapacityReq']);
			}			
			$('#selisBidCapacityReq').show();
			if($('#selisBidCapacityReq :selected').val() == 1){
				
				if(hideMap['biddingCapacity'] == 'true'){
					$("#tdBiddingCapacity").show();
					$('#txtBiddingCapacity').attr("tovalid","true");
				}else{
					$('#txtBiddingCapacity').attr("tovalid","false");
				}				
				$('#selEmdPaymentMode').prop("disabled", true);
				$('#selEmdPaymentMode').val(1);
				$('#tdEmdFees').hide();
				$('#txtEmdAmt').attr("tovalid","false");
				hideAutoBid(); //hide
				$("input[name=rdIsAutoBidAllowed][value=0]").prop('checked', true);
			}
		}else{			
			//$("#trBidCap").hide();
			//if(hideMap['isBidCapacityReq'] == 'true'){
				$('#tdIsBidCapicityReq').hide();
				
					$('#selisBidCapacityReq').val(0);
				
				$("#tdBiddingCapacity").hide();
			//}
		}
		/*if(hideMap['biddingCapacity']=='true'){
			$('#tdBiddingCapacity').show();
			$('#txtBiddingCapacity').attr("tovalid","true");
		}else{
			$('#tdBiddingCapacity').hide();
			$('#txtBiddingCapacity').attr("tovalid","false");
		}*/
	}
	else{
		$("#noteMsgEmdMode").hide();
		$('#trAucEmdMode').hide();
		$('#tdEmdMode').hide();
		$('#txtBiddingCapacity').attr("tovalid","false");
		$('#tdBiddingCapacity').hide();
		$('#txtBiddingCapacity').attr("tovalid","false");
		$('#tdEmdFees').hide();
		$('#txtEmdAmt').attr("tovalid","false");
		$("#trRestOfAuctionMoney").hide();
		//$("#trBidCap").hide();
		$('#tdIsBidCapicityReq').hide();
		
			$('#selisBidCapacityReq').val(0);
		
		hideAutoBid(); //show		
		
	}
	var selEmdPaymentMode = $('#selEmdPaymentMode :selected').val();
	if(selEmdPaymentMode == '2' && hideMap['emdPayableAt']!='false'){
		$('#tdEmdPayableAt').show();
		$('#txtaEmdPayableAt').attr("tovalid","true");
	}
	else{
		$('#tdEmdPayableAt').hide();
		$('#txtaEmdPayableAt').attr("tovalid","false");
	}
}
function changeEmdMode(ob){
	if($(ob).val() == '2' && hideMap['emdPayableAt']=='true'){
		$('#tdEmdPayableAt').show();
		$('#txtaEmdPayableAt').attr("tovalid","true");
	}
	else{
		$('#tdEmdPayableAt').hide();
		$('#txtaEmdPayableAt').attr("tovalid","false");
	}
}
function checkBiddingPriceIncDecTimes(ob){
	var bididnPriceincdectimes = $(ob).val();
	var eventType=$('#selEventType').val();
	if(bididnPriceincdectimes == 0){
		$("#tdIncDecInTimes").hide();
		$('#txtIncDecInTimes').attr('tovalid','false');
	}else if(bididnPriceincdectimes == 1){
		if(eventType == 1 && ($('input[name=rdAuctionResult]:checked').val()==1) && $('input[id=rdIncDecType]:checked').val()==1){
				$("#tdIncDecInTimes").show();
				$("#lblIncDecInTimes").text(varlblinctimes);
				$("#txtIncDecInTimes").attr('title',varlblinctimes);
		}else if(eventType == 2 && ($('input[name=rdAuctionResult]:checked').val()==1) && $('input[id=rdIncDecType]:checked').val()==1){
				$("#tdIncDecInTimes").show();
				$("#lblIncDecInTimes").text(varlbldectimes);
				$("#txtIncDecInTimes").attr('title',varlbldectimes);
		}
	}
}



function showConfigBiddingTypeInfo() {
	if (opType == 'edit') {
		var newauctionbiddingtype=$("input[name=rdIncDecType]:checked").val();
//		var oldauctionbiddingtype = map['incDecType'];
		
		if (confirm(varbiddingtypestatus) == false) {
			if(newauctionbiddingtype == 2 ){
				if(hideMap['incDecInMultiple']=='true'){
					$('#IncDicMult').show();
				}
				$("input[name=rdIncDecType][value=" + 1 + "]").prop('checked', true);
			}else{
				$("input[name=rdIncDecType][value=" + 2 + "]").prop('checked', true);
				$('#IncDicMult').hide();
			}
		}
	}
	
}
// Cr: #27306 
function setHideLiveBidToOfficerState(){
	// checking grandtotal auction result
	
	var result = $("#rdAuctionResult_0").prop("checked");
	// Checking a ishidelivebid to officer is yes and grandtotal auction is true.
	if($("#selisHideLiveBidToOfficer").val() =="nIFOHNH0pTI=" && result == true){
		$("#selShowWinAmountOnListing option[value=0]").attr("selected",true);
		$("#tdShowWinAmountOnListing").hide();
	}
	else
	{
		$("#tdShowWinAmountOnListing").show();
		if($('input[name=rdAuctionResult]:checked').val() == '2'){
			$("#tdShowWinAmountOnListing").hide();
		}
		
	}
}

function validateKeyword(vbool){
	var userSelectedKeywords = $("#txtaAucKeyword").val();
	if(userSelectedKeywords != null && isCategoryAllow == 0 && isCategoryAllow != ''){
		$.ajax({ 
            type: "POST",
            url: contextPath+"/ajaxcall/chechKeywordExists", //function that in web service
            data: {
                text : userSelectedKeywords
            },// passing value of txtSearch input
            dataType: "json",
            async: false,
            success: function(keywords) {
            	var keyErrWords = '';
            	if(keywords != undefined && keywords != '' && keywords != null){
	            	$.each(keywords,function(index,res){
	            	   if(res.status == 'false' && res.keyword != ''){
	            		   $("#txtaAucKeyword").focus();
	            		   if(keyErrWords == ''){
	            			   keyErrWords = res.keyword;
	            		   }else{
	            			   keyErrWords +=	','+res.keyword;
	            		   }
	            	   }
	            	});
            	}
               if(keyErrWords != ''){
            	   vbool = false;
            	   $("#txtaAucKeyword").parent().append("<div id='errtxtaAucKeyword' class='err"+$('#txtaAucKeyword').attr('id')+"' style='color:red;'>"+'Please select proper keywords : '+keyErrWords +"</div>");
               }
            },
            error: function(msg) {
//             $(".record").html(msg.d); 
            }
        });
	}
	return vbool;
}