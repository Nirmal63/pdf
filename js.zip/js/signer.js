var isSignerAliveAndValid = false;
var isErrorShownOnCurrPage = false;

function signerCall(action, serialNumber, data, publicKey, key){
	if(!isSignerAliveAndValid){
		signerCheck();
	}
	var signerObj = {};
	if(isSignerAliveAndValid){
		serialNumber = ((typeof serialNumber === "undefined") ? '' : serialNumber);
		data = ((typeof data === "undefined") ? '' : data);
		publicKey = ((typeof publicKey === "undefined") ? '' : publicKey);
		var reqData = {action :action, serialNumber :serialNumber, data :data, publicKey: publicKey, key :key};
		$.ajax({
			type: "POST",
			async: false,
			url: callSignerUrl + "signer",
			data: reqData,
			dataType: "json",
			contentType: "application/x-www-form-urlencoded; charset=UTF-8",
			success: function(responseJson){
				try {
					if(responseJson.hasOwnProperty("signerResponse")){
						signerObj = responseJson.signerResponse;
					} else if (responseJson.hasOwnProperty("exception") && !$.isEmptyObject(responseJson.exception)){
						alert("Exception : "+responseJson.exception.code + " - " + responseJson.exception.message);
					}  else if (isErrorShownOnCurrPage == false && responseJson.hasOwnProperty("error")){
						isErrorShownOnCurrPage = true;
						alert("Error : "+responseJson.error.code + " - " + responseJson.error.message);
					}
				} catch (e) {}
			}, 
			error: function(xhr, errorType, exception) {
				isSignerAliveAndValid = false;
				alert("Either signer not installed or signer service not running in your machine at " + callSignerUrl);
			}
		});
	}
	return signerObj;
}

function signerCheck(){
	$.ajax({
		type: "POST",
		async: false,
		url: callSignerUrl,
		dataType: "json",
		contentType: "application/x-www-form-urlencoded; charset=UTF-8",
		success: function(responseJson){
			try {
				if(responseJson.hasOwnProperty("signerResponse")){
					var signerObj = responseJson.signerResponse;
					if(signerObj.hasOwnProperty("error")){
						if(signerObj.error == 'REQUIRE_UNLIMITTED_JCE_POLICY'){
							alert("Please install unlimitted jce policy in your machine at " + signerObj.javaHome + "\\lib\\security directory");
						} else {
							alert(signerObj.error);
						}
					} else if (signerVersion != signerObj.version){
						alert("Please install latest version of signer-" + signerVersion);
					} else {
						isSignerAliveAndValid = true;
						isErrorShownOnCurrPage = false;
					}
				} else if (isErrorShownOnCurrPage == false && responseJson.hasOwnProperty("exception")){
					alert("Exception : "+responseJson.exception.code + " - " + responseJson.exception.message);
				} else if (isErrorShownOnCurrPage == false && responseJson.hasOwnProperty("error")){
					isErrorShownOnCurrPage = true;
					alert("Error : "+responseJson.error.code + " - " + responseJson.error.message);
				}
			} catch (e) {}
		}, 
		error: function(xhr, errorType, exception) {
			if(isErrorShownOnCurrPage == false){
				isErrorShownOnCurrPage = true;
				alert("Either signer not installed or signer service not running in your machine at " + callSignerUrl);
				window.location = pageContext+"/signerenable";
			}
		}
	});
}

var SIGNER_COMPONENT_ISSUE = 'Issue in signer component';
var sealock = new signer();

function signer() {
	this.data = "";
	this.setData = setData;
	this.getData = getData;
	
	this.certificate = "";
	this.selectCertificate = selectCertificate;
	
	this.sign = "";
	this.getSignature = getSignature;
	this.setSignature = setSignature;
	this.isVerifySignature = isVerifySignature;
	
	this.publicKey = "";
	this.publicKey1 = "";
	this.setPublicKey = setPublicKey;
	this.getPublicKey = getPublicKey;
	this.setPublicKey1 = setPublicKey1;
	
	this.encrypt = "";
	this.setEncrypt = setEncrypt;
	this.getEncrypt = getEncrypt;
	this.getMultiEncrypt = getMultiEncrypt;
	
	this.decrypt = "";
	this.setDecrypt = setDecrypt;
	this.getDecrypt = getDecrypt;
	
	this.getCertificateAliases = getCertificateAliases;
	this.getCertificateInformation = getCertificateInformation;
}

function setData(data) {
	this.data = data;
}

function getData() {
	return this.data;
}

function selectCertificate(alias) {
	this.certificate = alias;
	return "";
}

function setSignature(sign){
	this.sign = sign;
}

function getSignature() {
	var signedDataObj = signerCall(4, this.certificate, this.data, "", 0);
	if(!$.isEmptyObject(signedDataObj)){
		if(signedDataObj.hasOwnProperty("error")){
			throw new Error(signedDataObj.error);
		} else {
			this.sign = signedDataObj.signData;
		}
	} else {
		throw new Error(SIGNER_COMPONENT_ISSUE);
	}
	return (this.sign);
}

function isVerifySignature() {
	this.data = "";
	var isVerifySignature = false;
	try {
		var verifiedSignObj = signerCall(5, "", this.sign, "", 0);
		if(!$.isEmptyObject(verifiedSignObj)){
			if(verifiedSignObj.hasOwnProperty("error")){
				throw new Error(verifiedSignObj.error);
			} else if(verifiedSignObj.hasOwnProperty("isSignedData") && verifiedSignObj.isSignedData == true){
				isVerifySignature = verifiedSignObj.isSignedData;
				this.data = verifiedSignObj.plainData;
			}
		}
	} catch(e) {
		isVerifySignature = false;
    }
	return isVerifySignature;
}

function setPublicKey(publicKey) {
    this.publicKey = publicKey;
	return true;
}
function getPublicKey() {
	this.publicKey = "";
	var publicKeyObj = signerCall(3, this.certificate, "", "", 0);
	if(!$.isEmptyObject(publicKeyObj)){
		if(publicKeyObj.hasOwnProperty("error")){
			throw new Error(publicKeyObj.error);
		} else {
			this.publicKey = publicKeyObj.publicKey;
		}
	} else {
		throw new Error(SIGNER_COMPONENT_ISSUE);
	}
	return this.publicKey;
}
function setPublicKey1(publicKey1) {
    this.publicKey1 = publicKey1;
	return true;
}

function setEncrypt(encrypt) {
    this.encrypt = encrypt;
	return true;
}
function getEncrypt() {
	this.encrypt = "";
	var encryptBidObj = signerCall(6, "", this.data, this.publicKey, 0);
	if(!$.isEmptyObject(encryptBidObj)){
		if(encryptBidObj.hasOwnProperty("error")){
			throw new Error(encryptBidObj.error);
		} else {
			this.encrypt = encryptBidObj.encryptedData;
		}
	} else {
		throw new Error(SIGNER_COMPONENT_ISSUE);
	}
	return this.encrypt;
}

function getMultiEncrypt() {
	this.encrypt = "";
	var publicKeyArr = new Array();
	publicKeyArr.push(this.publicKey);
	publicKeyArr.push(this.publicKey1);
	var publicKeys = JSON.stringify(publicKeyArr);
	var multiEncryptObj = signerCall(7, "", this.data, publicKeys, 0);
	if(!$.isEmptyObject(multiEncryptObj)){
		if(multiEncryptObj.hasOwnProperty("error")){
			throw new Error(multiEncryptObj.error);
		} else {
			this.encrypt = multiEncryptObj.encryptedData;
		}
	} else {
		throw new Error(SIGNER_COMPONENT_ISSUE);
	}
	return this.encrypt;
}

function setDecrypt(decrypt) {
    this.decrypt = decrypt;
	return true;
}
function getDecrypt() {
	this.decrypt = "";
	var decryptDataObj = signerCall(8, "", this.encrypt, "", 0);
	if(!$.isEmptyObject(decryptDataObj)){
		if(decryptDataObj.hasOwnProperty("error")){
			throw new Error(decryptDataObj.error);
		} else if(decryptDataObj.hasOwnProperty("decryptedData")){
			this.decrypt = decryptDataObj.decryptedData;
		}
	} else {
		throw new Error(SIGNER_COMPONENT_ISSUE);
	}
	return this.decrypt;
}

function getCertiAlias(publicKey) {
	return getCertiAliasByKeyUsage(publicKey, 1);
}

function getCertiAliasByKeyUsage(publicKey,keyUsage) {
	var serialNumber = "";
	var serialNumberObj = signerCall(2, "", "", publicKey, keyUsage);
	if(!$.isEmptyObject(serialNumberObj) && serialNumberObj.hasOwnProperty("serialNumber")){
		serialNumber = serialNumberObj.serialNumber;
	}
	sealock.selectCertificate(serialNumber);
	return serialNumber;
}

function getCertificateAliases() {
	var certificateAliases = null;
	var certificateObj = signerCall(0, "", "", "", 0);
	if(!$.isEmptyObject(certificateObj) && certificateObj.hasOwnProperty("certificates")){
		certificateAliases = certificateObj.certificates;
	}
	return certificateAliases;
}
function getCertificateInformation() {
	var certificateDetail = null;
	var certificateDetailObj = signerCall(1, this.certificate, "", "", 0);
	if(!$.isEmptyObject(certificateDetailObj)){
		if(certificateDetailObj.hasOwnProperty("error")){
			alert(certificateDetailObj.error);
		} else {
			certificateDetail = certificateDetailObj.certificateDetail;
		}
	}
	return certificateDetail;
}