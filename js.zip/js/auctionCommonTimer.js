/**
 * @author jaynam
 */
var intBidDate;
if('${sysdate}' != null)
{
    intBidDate=Date.parse('${sysdate}');
}  
UpdateBidTimer();
getAuctionRemainingTime();
window.setInterval("getAuctionRemainingTime()", 30000);
window.setInterval("UpdateBidTimer()", 1000);
setInterval("dynamicSupplierRemClock()",1000);    
function dynamicSupplierRemClock()
{
    if(auctionStatus == '0')
    {
        for(var cnt=0;cnt<arrRow.length;cnt++)
        {   
            var j=0;
                j=cnt;               
            if($("#remainTimer_"+j) && isRowBidTimeOver[j] == false)
            {
                if(Min[j] == 0 && Sec[j] == 0 && Hr[j] == 0)
                {
                        isRowBidTimeOver[j]=true;
						if (isAuctionLive == 1) {
							$('#clockTimer_'+j).html(scriptBidTimeOverMsg);
                       } else {
							alert(1);
							$('#clockTimer_'+j).html("");
					   }
                }
                else
                {
                     /* call ajax for get recent bid detail for last 15, 8, 3 seconds */
                    if(Hr[j] == 0 && Min[j] == 0 && (Sec[j] == 15 || Sec[j] == 8 || Sec[j] == 3 ))
                    {
                        getAuctionRemainingTime();
                    }
                    var isAuctionFinished=false;
                    if(Min[j] == 0 && Sec[j] == 1 && Hr[j] == 0)
                    {
                    		isAuctionFinished = true;
                    		isRowBidTimeOver[j]=true;
							if (isAuctionLive == 1) {
								$('#clockTimer_'+j).html(scriptBidTimeOverMsg);
							} else {
								$('#clockTimer_'+j).html("");
							}		
							if(isAuctionFinished)
							{
								setTimeout(window.location.reload(true),1000);;
							} 
                        /*** END :  Reload page when bid time over  ***/
                    }

                    if(Hr[j] > 0){
                        if(Min[j] == 0 && Sec[j] == 0){
                            Hr[j] = Hr[j] - 1;
                            Min[j] = 59;
                            Sec[j] = 60;
                        }else if(Min[j] > 0 && Sec[j] == 0){
                            Min[j] = Min[j] - 1;
                            Sec[j] = 60;
                        }
                        else if(Sec[j] == 0){
                            Sec[j] = 60;
                        }
                    }else{
                        if(Min[j] > 0 && Sec[j] == 0){
                            Min[j] = Min[j] - 1;
                            Sec[j] = 60;
                        }
                        else if(Sec[j] == 0){
                            Sec[j] = 60;
                        }
                    }
                    Sec[j] = Sec[j] - 1;
               }   
               if(!isNaN(Hr[j]) && !isNaN(Min[j]) && !isNaN(Sec[j]) && auctionStatus == '0')
                {		
            	   		if($("#remainTimer_"+j).hasClass("red")){
            	   			$("#remainTimer_"+j).removeClass("red");
            	   		}
                    	$("#remainTimer_"+j).html(Hr[j]+" Hr - "+Min[j]+" Minutes - "+Sec[j] +" Seconds");
                }
                else if(auctionStatus == '0')
                {
                    $("#remainTimer_"+j).html(0+":"+0+":"+0);
                }
            }
        }
    }
}
function getAuctionRemainingTime () {
  
	$.ajax({
        type: "GET",
        url: ajaxAuctionRemainingTime,
        dataType: 'text',
       	success: function(response)
        { 
       		response=response.toString();
       	   var result = $.trim(response).split('~');
        	    if(result!=null && (result.indexOf("SessionExpired")!= -1))
                {
                    alert(sessionexpired);
                    return false;
                }
                else
                {
                	 /* setting Current time */
                	auctionStatus = result[2];
                    isAuctionClosed = result[4];
                    if(result != null)  /* Need to set only once not for each rows*/
                    {
                         intBidDate = Date.parse(result[0]);
                         UpdateBidTimer();
		     		 }
                 	 /* setting remaining time,enddate,curExt */
                     var dtarr = $.trim(result[1]).split(':');
                         Hr[0]=parseInt(dtarr[0],10);
                         Min[0]=parseInt(dtarr[1],10);
                         Sec[0]=parseInt(dtarr[2],10);
                  //       console.log(auctionStatus);
                         if(parseInt(result[5]) == 1){
                         	$('#remainTime_msg').html('Remaining Time :');
                         }
						 if(!isNaN(Hr[0]) && !isNaN(Min[0]) && !isNaN(Sec[0]) && result[2] == '0' && result[4] == 'false')
                         {	
							$("#remainTimer_0").addClass('black');
                        	 $("#remainTimer_0").html(Hr[0]+" Hr - "+Min[0]+" Minutes - "+Sec[0] +" Seconds");
                         }else if(result[4] == 'true'){
                         	$("#clockTimer_0").html(scriptBidTimeOverMsg);
                             if($("clockTimer-collapse_0").length >0){
                             	$("#clockTimer-collapse_0").html(scriptBidTimeOverMsg);
                             }
                         } else if(auctionStatus == '1') {
                        	 $("#remainTimer_0").removeClass('black');
                        	 $("#remainTimer_0").addClass('red');
                			$("#remainTimer_0").html('<font><b>Auction is paused</b><font>');
                		} else if (auctionStatus == '2') {
                			 $("#remainTimer_0").removeClass('black');
                			 $("#remainTimer_0").addClass('red');
                			$("#remainTimer_0").html('<font><b>Auction is paused</b><font>');
				//			console.log('jaynam');
                		}else if (auctionStatus == '4') {
                			 $("#remainTimer_0").removeClass('black');
                			 $("#remainTimer_0").addClass('red');
                			$("#remainTimer_0").html('<font><b>Auction is cancelled</b><font>');
                		}
                         if(parseInt(result[3]) > 0){
                         	$('#remainTime_msg').html(lbl_auc_ext_rem_time);
                         }
						 isAuctionLive = result[5];
			    }    
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          alert(ajaxErrorMsg);
          return false;
        }
      });
	 
 }