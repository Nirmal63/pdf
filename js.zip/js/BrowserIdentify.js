var browName="";
function detectBrowserVersion(){
    var userAgent = navigator.userAgent.toLowerCase();
    $.browser.chrome = /chrome/.test(navigator.userAgent.toLowerCase());
    var version = 0;

    // Is this a version of IE?
    if (!!navigator.userAgent.match(/Trident\/7\./)){//For IE 11
    	browName="IE";        
	    userAgent = '11';	    
	    version = userAgent;	    
    } 
    if($.browser.msie){   
        browName="IE";        
        userAgent = $.browser.version;
        userAgent = userAgent.substring(0,userAgent.indexOf('.'));
        version = userAgent;
    }

    // Is this a version of Chrome?
    if($.browser.chrome){
        browName="Chrome";
        userAgent = userAgent.substring(userAgent.indexOf('chrome/') +7);
        userAgent = userAgent.substring(0,userAgent.indexOf('.'));
        version = userAgent;
        // If it is chrome then jQuery thinks it's safari so we have to tell it it isn't
        $.browser.safari = false;
        
    }

    // Is this a version of Safari?
    if($.browser.safari){
        browName="Safari";
        userAgent = userAgent.substring(userAgent.indexOf('safari/') +7);
        userAgent = userAgent.substring(0,userAgent.indexOf('.'));
        version = userAgent;
    }

    // Is this a version of Mozilla?
    if($.browser.mozilla){
        //Is it Firefox?
        if(navigator.userAgent.toLowerCase().indexOf('firefox') != -1){
            browName="Mozilla";
            userAgent = userAgent.substring(userAgent.indexOf('firefox/') +8);
            userAgent = userAgent.substring(0,userAgent.indexOf('.'));
            version = userAgent;
        }
        // If not then it must be another Mozilla
        else{
        }
    }

    // Is this a version of Opera?
    if($.browser.opera){
        browName="Opera";
        userAgent = userAgent.substring(userAgent.indexOf('version/') +8);
        userAgent = userAgent.substring(0,userAgent.indexOf('.'));
        version = userAgent;
    }
    return version;
}


function BrowserIdentification()
{   
	var isBrowser64Bit = false;
	var userAgent = navigator.userAgent.toLowerCase();
	
	if ((userAgent.indexOf("msie") != -1 || userAgent.indexOf("trident") != -1) && (userAgent.indexOf("win64") != -1 && userAgent.indexOf("x64") != -1)){
		isBrowser64Bit = true;
	}

	if(isBrowser64Bit){
	    window.location = 'checkBrowser64bit';
	}
	else {
		var browserVer = detectBrowserVersion();    
	    var browserName = browName;
	    var allowBrowser = false;
	    //    //alert(navigator.userAgent);
	    //    $(document).ready(function(){
	    //        var allowBrowser = false;
	    //        jQuery.each(jQuery.browser, function(i, val) {
	    //            browserVer = jQuery.browser.version;   
	    //            if(i == "mozilla" && parseFloat(browserVer.substr(0,3)) >= 13.0){
	    //                browserName = i;
	    //                browserVer = nomVersionNavig();
	    //            //allowBrowser = true;
	    //            }
	    //            if(i == "msie" && (/*browserVer.substr(0,3) == "8.0" ||*/  browserVer.substr(0,3) == "9.0")){
	    //                browserName = i;
	    //                browserVer = browserVer.substr(0,3);
	    //            //allowBrowser = true;
	    //            }
	    //           
	    //           
	    //        });
	    //        //alert("vestion  "  + browserVer.substr(0, 3));
	    //        if(browserName == "mozilla" && (parseFloat(browserVer.substr(0,3)) >= 13.0)){
	    //            allowBrowser = true;
	    //        }
	    //        if(browserName == "msie" && (/*browserVer.substr(0, 3) == "8.0" ||*/ browserVer.substr(0, 3) == "9.0")){
	    //            allowBrowser = true;
	    //        }
	    //alert(browserName);
	    //alert(browserVer);
	    if(browserName=='IE' && (browserVer==8 || browserVer==9 || browserVer==10 || browserVer==11)){
	        allowBrowser = true;
	    }
	    else if(browserName=='Mozilla' && browserVer >= 13){
	        allowBrowser = true;
	    }
	    else if(browserName=='Chrome' && browserVer >= 20){            
	        allowBrowser = true;
	    }            
	    if(!allowBrowser){            
	        window.location = 'checkbrowser';
	    }
	}
    //CheckBrowser64bit
//    });
}
