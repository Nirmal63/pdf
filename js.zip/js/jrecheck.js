/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function ActiveJavaCheck(){           
    if (navigator.userAgent.indexOf("MSIE") != -1 || navigator.userAgent.indexOf("Trident") != -1) {        
        isActiveXEnabled();
    }
    else {		        
        //if(checkJREVersion()){
            checkJavaEnable();
       // }
    }
}

function checkJavaEnable(){	
	var isChromium = window.chrome;
	var jcnt = 0;
	if(isChromium != null){
		for(var i=0;i<navigator.plugins.length;i++){
	        if(navigator.plugins[i].name.toString().toLowerCase().indexOf('java(tm) platform') != -1 || navigator.plugins[i].name.toString().toLowerCase().indexOf('java deployment toolkit') != -1){
	            jcnt++;
	        }        
	    }
	}
	else {
		if(navigator.javaEnabled()){
    		jcnt = 1;	
    	}
	}
	var chkFlag = checkJREVersion();
	if(chkFlag && jcnt < 1){
        window.location ="javaenabled/1";
    }
}
                   
function isActiveXEnabled(){
    //if (navigator.appName == "Microsoft Internet Explorer") {
    try {
        var objFSO = new ActiveXObject("CAPICOM.EnvelopedData");
    }
    catch (e){        
        window.location = "activexenable";
    }
//}
}

function checkJREVersion(){    
    var jreArray = deployJava.getJREs();    
    var msg = "You are using older version of Java(TM) Runtime Environment. You need the latest";
    var redirectUrl = "javaenabled/2";
    var minVer = "1.6.0_32";
    var checkCount = 0;
//alert(jreArray);	
    if(jreArray.length > 0){
        for(var i=0;i<jreArray.length;i++){
            var arrItem = jreArray[i];
            var ver = parseFloat(arrItem.substring(0,3));            
            if(ver > 1.6){
                checkCount++;
            }
        }
		
        if(checkCount == 0){
            userInput = confirm(msg);
            if (userInput == true) {
                window.location = redirectUrl;
                return false;
            }
        }
        else {
            return true;
        }
    }
    else {
        window.location = redirectUrl;
        return false;
    }
}
