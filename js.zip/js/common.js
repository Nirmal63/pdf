/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


function Setup()
{
    // set Globals
    Affix = new Array('UNITES', 'THOUSAND', 'LAKH', 'CRORE')
    for(i=1;i<5;i++)
    {
        Affix[3+i] = Affix[0+i]
    }
    Name = new Array
    ('ZERO', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX',
    'SEVEN', 'EIGHT', 'NINE', 'TEN', 'ELEVEN', 'TWELVE',
    'THIRTEEN', 'FOURTEEN', 'FIFTEEN',  'SIXTEEN', 'SEVENTEEN',
    'EIGHTEEN', 'NINETEEN')
    Namety = new Array('TWENTY', 'THIRTY', 'FORTY',
    'FIFTY', 'SIXTY', 'SEVENTY', 'EIGHTY', 'NINETY')
    PointName = new Array
    ('ZERO', 'ONE', 'TWO', 'THREE', 'FOUR', 'FIVE', 'SIX',
    'SEVEN', 'EIGHT', 'NINE')
}

function Small(TC, J, K)
{
    if (J==0) return TC
    if (J>999) return ' Internal ERROR: J = ' + J + ' (>999)'
    var S = TC
    if (J>99)
    {
        S += Name[Math.floor(J/100)] + ' HUNDRED ' ; J %= 100
        if (J>0) S += 'and '
    }
    else if ((S>'') && (J>0) && (K==0)) S += 'and '
    if (J>19)
    {
        S += Namety[Math.floor(J/10)-2] ; J %= 10 ;
        S += ( J>0 ? '-' : ' ')
    }
    if (J>0) S += Name[J] + ' '
    if (K>0) S += Affix[K] + ' '
    return S
}

function TextCash(L, K)
{
    
    if (L==0) return (K>0 ? '' : 'Zero ')
    if (K==0 || K==3)
    {
        return Small(TextCash(Math.floor(L/1000), K+1), L%1000, K)
    }
    else
    {
        return Small(TextCash(Math.floor(L/100), K+1), L%100, K)
    }
}

function TextCash1(L, K)
{
    if (L==0) return (K>0 ? '' : 'NIL ')
    return Small(TextCash1(Math.floor(L/100), K+1), L%100, K) }

function TextCash2(L, K)
{
    if (L==0) return (K>0 ? '' : 'NIL ')
    {
        var pointStr1= new String();
        var pointlen1,pointStr2,pointStr3;
        pointStr2="";
        pointStr3="";
        pointStr1=L;
        pointStr1=pointStr1.toString();
        pointlen1= pointStr1.length;
       
        for(pointi=0;pointi<pointlen1;pointi++)
        {
            pointStr2=pointStr1.substr(pointi,1);
            if(undefined == PointName[pointStr2])
                continue;
            pointStr3=pointStr3+PointName[pointStr2]+' ';
           
        }
        return pointStr3;
    }
}

function IndianConvertionAmountInWord(Numeric){
    Setup();
    Q = Numeric;
    if (isNaN(parseFloat(Q))){
        Word = '';
    }else{
        //-----------Code by umesh ------------------
        Word=''
        var tempStr1=new String();
        var tempStr3=new String();
        tempStr1=Q;
        tempStr1=tempStr1.toString();
        var tempstr2=tempStr1.search('-');
        if (tempstr2==0){
            Word = 'Minus ';
            //tempStr3='Minus ';
            //tempStr3.fontcolor("red");
            //Word=tempStr3;
        }
        Q=tempStr1.replace('-','')

        //---------------------comment old---------------------
        /*P = Math.round(((Q -
Math.floor(Q))*100)*Math.pow(10,5))/Math.pow(10,5);
         //P = Math.round((Q - Math.floor(Q))*100)
         Q = Math.floor(Q)
           if (P<=9){
               P='0'+P;
           }

         if (P==0){
             //Word = 'Rupee' + (Q==1?'':'s') + ' ' + TextCash(Q, 0) + 'Only'
             Word = Word + '' + (Q==1?'':'') + '' + TextCash(Q, 0) + '';
         }else{
                 //Word = 'Rupee' + (Q==1?'':'s') + ' ' + TextCash(Q, 0)
+ 'and Paisa' + ' ' + TextCash1(P, 0) + 'Only'
                 Word = Word + '' + (Q==1?'':'') + '' + TextCash(Q, 0) + 'point' + ' ' + TextCash2(P, 0) + '';
         }*/
        //----------------------comment old---------------------

        //-------------------yrj change-------------------------
        var P, pointStr3;
        qStr = Q.toString();
        if(qStr.indexOf(".") != -1){
            qStrAfterPoint = qStr.substring(qStr.indexOf(".")+1,
            qStr.length);
            P = eval(qStrAfterPoint);
            if(P == 0){
                pointStr3 = '';
            }else{
                var pointStr1= new String();
                var pointlen1,pointStr2;
                pointStr2="";
                pointStr3="";
                pointStr1=qStrAfterPoint;
                pointlen1= pointStr1.length;

                for(pointi=0;pointi<pointlen1;pointi++){
                    pointStr2=pointStr1.substr(pointi,1);
                    if(PointName[pointStr2] != undefined){
                        pointStr3=pointStr3+PointName[pointStr2]+' ';
                    }
                }
            }
        }else{
            P = 0;
        }

        //------------------------------------------Added By Manish Sharma :: gives wrong value in case of Math.floor(999999999999.99999)--------------------
        if(Q.indexOf(".") == -1){
            Q = Math.floor(Q);
        }else{
            Q = Q.substring(0, Q.indexOf("."));
        }

        var yz = Q.toString();
        var substr = yz.substring(yz.length-7,yz.length);

        if (P<=9){
            P='0'+P;
        }

        R = Q%10000000000;

        if (P==0){
            if(Q < 10000000000){
                Word = Word + '' + (Q==1?'':'') + '' + TextCash(Q, 0) + '';
            }else{
                Word = Word + '' + (Q==1?'':'') + '' + TextCash(Q, 0) + '';
                if(R == 0){
                    Word = Word + 'Crore';
                }

                X = Math.floor(Q/10000000);
                if(R!=0 && (X%10) == 0){
                    Word = '';
                    Word = Word + '' + (X==1?'':'') + '' + TextCash(X,
                    0) + 'Crore';
                    if(substr!="0000000"){
                        Word = Word + ' And ' + (R==1?'':'') + '' + TextCash(substr, 0) + '';
                    }
                }
            }
        }else{
            //TextCash2(P, 0)
            if(Q < 10000000000){
                Word = Word + '' + (Q==1?'':'') + '' + TextCash(Q, 0) + 'point' + ' ' + pointStr3 + '';
            }else{
                Word = Word + '' + (Q==1?'':'') + '' + TextCash(Q, 0);
                if(R == 0){
                    Word = Word + 'Crore ';
                }
                Word = Word + 'point' + ' ' + pointStr3 + '';

                X = Math.floor(Q/10000000);
                if(R!=0 && (X%10) == 0){
                    Word = '';
                    Word = Word + '' + (X==1?'':'') + '' + TextCash(X,
                    0) + 'Crore';
                    if(substr!="0000000"){
                        Word = Word + 'And' + (R==1?'':'') + '' + TextCash(R, 0) + 'point' + ' ' + pointStr3 + '';
                    }
                }
            }
        }
        //-------------------yrj change-------------------------
    }
    return Word
}

/**
 * @author manish.sharma
 * @returns international level conversion of numbers into words like billion, trillion etc...
 */
function InternationConvertionAmountInWord(s){
   
    var th = ['','THOUSAND','MILLION', 'BILLION','TRILLION'];
    var dg = ['ZERO','ONE','TWO','THREE','FOUR',
        'FIVE','SIX','SEVEN','EIGHT','NINE'];
    var tn = ['TEN','ELEVEN','TWELVE','THIRTEEN',
        'FOURTEEN','FIFTEEN','SIXTEEN', 'SEVENTEEN','EIGHTEEN','NINETEEN'];
    var tw = ['TWENTY','THIRTY','FORTY','FIFTY',
        'SIXTY','SEVENTY','EIGHTY','NINETY'];

    if(s=='0'){
        
        return "ZERO";
    }
    s = s.toString(); s = s.replace(/[\, ]/g,'');
    if (s != parseFloat(s))
        return 'NOT A NUMBER';
    var x = s.indexOf('.');
    //bug 33222 : case come when "words conversion standard = Million" 
    var str = '';
    var afterPointNum = ''
	var Q = s;
	var tempstr2=Q.search('-');
	if (tempstr2==0){
       str = 'Minus ';
	}
	s=Q.replace('-','')
	//End Bug 33222
    
	if(s.indexOf(".") != -1){
    	var pointLenght= s.length;
        s = s.substring(0, s.indexOf("."));
        afterPointNum = Q.substring(Q.indexOf(".")+1,Q.length);
    }
	
	if (x == -1){ x = s.length}else{x = s.length};
    if (x > 15)
        return 'TOO BIG';
    var n = s.split('');
    
    var sk = 0;
    for (var i=0; i < x; i++) {
        if ((x-i)%3==2) {
            if (n[i] == '1') {
                str += tn[Number(n[i+1])] + ' '; i++; sk=1;
            } else if (n[i]!=0) {
                str += tw[n[i]-2] + ' ';
                sk=1;
            }
        } else if (n[i]!=0) {
            str += dg[n[i]] +' ';
            if ((x-i)%3==0)
                str += 'HUNDRED ';sk=1;
        } if ((x-i)%3==1) {
            if (sk)
                str += th[(x-i-1)/3] + ' ';sk=0;
        }
    }
    var P, pointStr3;
    if (x != pointLenght) {
    	P = eval(afterPointNum);
    	if(P == 0){
            pointStr3 = '';
        }else{
            var pointStr1= new String();
            var pointlen1,pointStr2;
            pointStr2="";
            pointStr3="";
            pointStr1=afterPointNum;
            pointlen1= pointStr1.length;
            for(pointi=0;pointi<pointlen1;pointi++){
                pointStr2=pointStr1.substr(pointi,1);
                if(dg[pointStr2] != undefined){
                    pointStr3=pointStr3+dg[pointStr2]+' ';
                }
            }
            if(pointStr3 != ''){
            	str += 'POINT '+pointStr3;
            }
        }
    }
    return str.replace(/\s+/g,' ');
}
function convertToWord(nums,wordConversion){
    if (wordConversion == '0') {
        nums = IndianConvertionAmountInWord(nums);
    }else {
        nums = InternationConvertionAmountInWord(nums);
    }
    return nums;
}