		var pos;
        var interval;
        var scrollSpeed = 200;
		var scrollDistance = 50;
		
			$(function(){
				if($("div").hasClass("dynScroll")){
		        	pos = $(".dynScroll").position();
		    		$('.leftScrollDiv').css({'top':pos.top+2});
		    		$('.rightScrollDiv').css({'top':pos.top+2});
		    		
		    		$('.leftScrollDiv').hide();
		    		$('.rightScrollDiv').hide();
		    		
		    		
		    		$(".leftScrollDiv").mouseup(function(){
		    			clearInterval(interval);
		        	});
		    		$(".rightScrollDiv").mouseup(function(){
		    			clearInterval(interval);
		        	});
		    		(function($) {
		    		    $.fn.hasScrollBar = function() {
		    		        return this.get(0).scrollWidth > this.width();
		    		    }
		    		})(jQuery);
		    		if($('.o-auto').hasScrollBar())
		    		{
		    			$('.leftScrollDiv').show();
			    		$('.rightScrollDiv').show();
		    		}
				}
	    	});
        	function scrollWindowLeft() {
        		var scrollleft = $(".dynScroll").scrollLeft() - scrollDistance;
				$(".dynScroll").scrollLeft(scrollleft);
        		interval=setInterval(function(){
        			var scrollleft = $(".dynScroll").scrollLeft() - scrollDistance;
    				$(".dynScroll").scrollLeft(scrollleft);
    			},scrollSpeed);
        		
        	}
        	function scrollWindowRight() {
        			var scrollright = $(".dynScroll").scrollLeft() + scrollDistance;
    				$(".dynScroll").scrollLeft(scrollright);
    				interval=setInterval(function(){
    					var scrollright = $(".dynScroll").scrollLeft() + scrollDistance;
        				$(".dynScroll").scrollLeft(scrollright);
    				},scrollSpeed);	
    				
    	 	}
        	
        	$(window).scroll(function(e){
        		if($("div").hasClass("dynScroll")){
        		  $el = $('.leftScrollDiv'); 
        		 if ($(this).scrollTop() > $(".dynScroll").offset().top && $el.css('position') != 'fixed'){ 
        		    $('.leftScrollDiv').css({'position': 'fixed', 'top': '0px'});
        		    $('.rightScrollDiv').css({'position': 'fixed', 'top': '0px','right':'160px'});
        		  }else if ($(this).scrollTop() < $(".dynScroll").offset().top  && $el.css('position') == 'fixed') {
        		    $('.leftScrollDiv').css({'position': 'absolute','top':pos.top+2}); 
        		    $('.rightScrollDiv').css({'position': 'absolute','right':'0px','top':pos.top+2}); 
        		  }
        		}
        	});
        	