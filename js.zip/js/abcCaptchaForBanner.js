
function capchaClose(){
	$("#tdCapcha").html("");
	$("a.panel-tool-close").removeAttr("onclick");
}
$(document).keyup(function(e) {
    if (e.keyCode == 27) { 
    	$("#tdCapcha").html("");
    	$("a.panel-tool-close").removeAttr("onclick");
   }
});
function getAbcCaptchaBanner(url){
		var cpage = $('#captchaContext').val();
		var appendCaptchaHtml="<div  class='bannercapcha' id='abcCapchaDiv'>"		
		+ "<input type='hidden' name='recaptcha_challenge_field' id='recaptcha_challenge_field' value=''/>"
		+ "<input type='hidden' name='cType' id='cType' value='1'/>"
		+ "<input type='hidden' name='ctheme' id='ctheme' value='0'/>"
		+ "</div><span class='validationMsg validbannercapcha' id='vericode'></span>";
		$("#tdCapcha").html(appendCaptchaHtml);
		
		var cRandom = Math.random() * 5;
		responseFocusBanner();
		
		var id = $(".bannercapcha#abcCapchaDiv");
		var ctype = $(".bannercapcha > #cType").val();
		var theme = $(".bannercapcha > #ctheme").val();
		
		id.empty();
		id.append("<img id='abcCaptchaImageId' alt='captcha' src='"+cpage+"/AbcCapchaImage?flag=image&ctheme="
						+ theme
						+ "&ctype=1&temp="
						+ cRandom
						+ "'> "
						+ "<input type='hidden' name='recaptcha_challenge_field' id='recaptcha_challenge_field' value=''/>"
						+ "<input type='hidden' name='cType' id='cType' value='1'/>"
						+ "<input type='hidden' name='ctheme' id='ctheme' value='"
						+ theme
						+ "'/>"
						+ "<br/>"
						+ "<br/>"
						+ "<input type='text' name='recaptcha_response_field' id='recaptcha_response_field' value=''   onblur='javascript:validateAbcCaptchaForBanner()' onfocus='javascript:responseFocusBanner()'/>");

		id.fadeIn();
		setTimeout(function(){keyAjaxBanner();}, 300);
		
		
		$('#smsvalue').val(url); 
    	$('#createEvent').show();
    	$('#createEvent').dialog({ 
            autoOpen: true,
            title: 'Download mobile app',
            resizable: true,
            position:'center',
            width:400,
            top:130,
            modal:true,
            resizable: false,
            draggable: false,
            dialogClass: 'panel window',
           
          });
     $("a.panel-tool-close").attr("onclick","capchaClose()");
	
}
function validateAbcCaptchaForBanner() {
	var cpage = $('#captchaContext').val();
    var recaptcha_response_field_banner =$(".bannercapcha > #recaptcha_response_field").val();
	if (recaptcha_response_field_banner != "") {
		$.ajax({
			type : "POST",
			url : cpage+'/ajaxcall/validatecaptcha',
			dataType : 'text',
			data : {
				challenge : $('.bannercapcha > #recaptcha_challenge_field').val(),
				userInput : recaptcha_response_field_banner
			},
			success : function(j) {
				if (j.toString() == "OK" || j.toString() == "Valid") {
					$('.validbannercapcha#vericode').css("color", "green");
					isCaptchaVerified = true;
				} else {
					getAbcCaptchaBanner();
					$('.validbannercapcha#vericode').css("color", "red");
					isCaptchaVerified = false;
				}
				$('.validbannercapcha#vericode').html(j);
				//setTimeout(function(){$('span#vericode').html(j).insertAfter('#abcCaptchaImageId');}, 500);
				
			},
			error : function(XMLHttpRequest, textStatus, errorThrown) {

				return false;
			}

		});
	} else {
		
		$('.validbannercapcha#vericode').html("");
		$('.validbannercapcha#vericode').css("color", "red");
		$('.validbannercapcha#vericode').html("Please enter verification code");
		isCaptchaVerified = false;
	}

}

function responseFocusBanner() {
	$(".validbannercapcha#vericode").html("");

}
function keyAjaxBanner() {
	var cpage = $('#captchaContext').val();
	$.ajax({
		type : "GET",
		async: false,
		url : cpage+'/AbcCapchaImage',
		dataType : 'text',
		data : {
			flag : "key"
		},
		success : function(responseText) {
			var key = responseText;
			if(key == null || key == ""){
				$('.validbannercapcha#vericode').css("color", "red");
				$(".validbannercapcha#vericode").html("Captcha Generation Error : please try again.");
			} else {
				$(".bannercapcha > #recaptcha_challenge_field").val(key);	
			}
			
		},
		error : function(XMLHttpRequest, textStatus, errorThrown) {

			return false;
		}
	});
}