/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
 

  var timerId = 0;
    function closeMe(){
	try{
            jQuery('#dialog_chat').dialog('close');
            clearInterval(timerId);
	}catch(err){}
    }
  function chatcount(){
	
	load();
     timerId = window.setInterval("load()", 5000);
	 $("a.panel-tool-close").attr("onclick", "closeMe()");
}
    
var searchCall = false;
function getDeptTree(varCompId) {
	var deptName = window.showModalDialog(deptTreePath, '',
			'dialogHeight=400px;dialogWidth=300px;center=1;scroll=yes;',
			'Select Department');
	$("#" + varCompId).val(deptName);
	$("#" + varCompId).focus();
}
function comboChange(ob, id) { 

	$('#txt_' + id).val($(ob).val());
	if ('#txt_' + id == '#txt_687') {	
			CM(ob);
			 
	}
	if ('#txt_' + id == '#txt_124') {	
			CMFOrPending(ob);
			 
	}
	if ('#txt_' + id == '#txt_243') {	
			CMFOrProcess(ob);
			 
	}
}

function CMS(ob){
setInterval(function() {
	
		
	if($(ob).val() == '1707') {
			    	 $('.removedata  .plus-icn').hide();
			    	  $('.removedata  .tree-folder').hide();
			    	  $('.removedata  .disable-icn').hide();
			    	 }
	}, 500);
	}
// var auctionModuleId = '<abc:encdec isenc="true" value="1" />';
function CMFOrPending(ob){debugger;
	if ($(ob).val() == '1') {
		//$('#txt_125').hide();
			$('#selop_125').parent().hide();
			$('#img_125').parent().hide();
		 $('#txt_125').parent().parent().children('td').eq(2).hide();
		$('#txt_156').parent().parent().children('td').hide();
		$('#txt_157').parent().parent().children('td').hide();
		
	     	$('#selop_695').parent().show();
			$('#img_695').parent().show();
		    $('#txt_695').parent().parent().children('td').eq(2).show();
	     	$('#txt_696').parent().parent().children('td').show();
	     	$('#txt_697').parent().parent().children('td').eq(1).show();
			$('#txt_697').parent().parent().children('td').eq(0).show();
				loadReportGrid();
	}
	if ($(ob).val() == '4') {
			$('#selop_695').parent().hide();
			$('#img_695').parent().hide();
		    $('#txt_695').parent().parent().children('td').eq(2).hide();
	     	$('#txt_696').parent().parent().children('td').hide();
	     	$('#txt_697').parent().parent().children('td').eq(1).hide();
			$('#txt_697').parent().parent().children('td').eq(0).hide();
			
		$('#selop_125').parent().show();
			$('#img_125').parent().show();
		 $('#txt_125').parent().parent().children('td').eq(2).show();
		$('#txt_156').parent().parent().children('td').show();
		$('#txt_157').parent().parent().children('td').show();
			loadReportGrid();
	}

}
function CMFOrProcess(ob){debugger;
	if ($(ob).val() == '1') {
		//$('#txt_125').hide();
			$('#selop_244').parent().hide();
			$('#img_244').parent().hide();
		 $('#txt_244').parent().parent().children('td').eq(2).hide();
		$('#txt_245').parent().parent().children('td').hide();
		//show
			$('#selop_698').parent().show();
			$('#img_698').parent().show();
		    $('#txt_698').parent().parent().children('td').eq(2).show();
	     	$('#txt_699').parent().parent().children('td').show();
	     	$('#txt_700').parent().parent().children('td').show();
	
				loadReportGrid();
	}
	if ($(ob).val() == '4') {
			$('#selop_698').parent().hide();
			$('#img_698').parent().hide();
		    $('#txt_698').parent().parent().children('td').eq(2).hide();
	     	$('#txt_699').parent().parent().children('td').hide();
	     	$('#txt_700').parent().parent().children('td').hide();
			
		$('#selop_244').parent().show();
			$('#img_244').parent().show();
		 $('#txt_244').parent().parent().children('td').eq(2).show();
		$('#txt_245').parent().parent().children('td').show();
			loadReportGrid();
	}

}
 function CM(ob){
		    	 if ($(ob).val() == '1706') {
		 			$('#chirag').html('');
		 			$('#chirag').html('<c:set var="parm5" value="5"/>');
		 			searchCall=true;
			 			$('#hdmoduleId').val('c0daxubOVTc=');
			 			$('#txtparam5').val('5');
			 			
			 		 $('#txt_689').parent().parent().children('td').eq(0).show();
		 			$('#txt_689').parent().parent().children('td').eq(1).hide(); 
					$('#txt_692').parent().parent().children('td').hide(); 
		 			$('#txt_692').parent().parent().children('td').hide();
		 			$('#txt_690').parent().parent().children('td').hide();
		 			$('#txt_690').parent().parent().children('td').hide();
		 			$('#txt_691').parent().parent().children('td').eq(0).hide();
		 			$('#txt_691').parent().parent().children('td').eq(1).hide(); 	
			 		   $('#txt_51').parent().parent().children('td').eq(0).show();
			 		   	$('#txt_51').parent().parent().children('td').eq(1).show();
			 			 $('#txt_52').parent().parent().children('td').eq(0).show();
			 			 $('#txt_52').parent().parent().children('td').eq(1).show();
			 			 $('#txt_53').parent().parent().children('td').show();
			 			 $('#txt_53').parent().parent().children('td').show();
			 			  $('#txt_54').parent().parent().children('td').eq(0).show();
			 			$('#txt_54').parent().parent().children('td').eq(1).show();
		 			$('#txtpageNo').val('1');
		 			$('#txt_689').hide();
		 			loadReportGrid();
		 			
		    	 }
		    	  if ($(ob).val() == '1707') {debugger;
			 			$('#chirag').html('');
		 			$('#chirag').html('<c:set var="parm5" value="3"/>');
			 			$('#hdmoduleId').val('dpTZ6jp6CKI=');
			 			//$('input[name=txtparam5]').val('3');
			 			searchCall=true;
			 	    $('#txt_689').parent().parent().children('td').eq(0).show();
		 			$('#txt_689').parent().parent().children('td').eq(1).show(); 
		 			$('#txt_690').parent().parent().children('td').show();
		 			$('#txt_690').parent().parent().children('td').show();
		 			$('#txt_691').parent().parent().children('td').eq(0).show();
		 			$('#txt_691').parent().parent().children('td').eq(1).show(); 	
					$('#txt_692').parent().parent().children('td').show(); 
		 			$('#txt_692').parent().parent().children('td').show();
		 		
		 			
			 		   $('#txt_51').parent().parent().children('td').eq(0).hide();
			 		   	$('#txt_51').parent().parent().children('td').eq(1).hide();
			 			 $('#txt_52').parent().parent().children('td').eq(0).hide();
			 			 $('#txt_52').parent().parent().children('td').eq(1).hide();
			 			 $('#txt_53').parent().parent().children('td').hide();
			 			 $('#txt_53').parent().parent().children('td').hide();
			 			  $('#txt_54').parent().parent().children('td').eq(0).hide();
			 			$('#txt_54').parent().parent().children('td').eq(1).hide();
			 			
			 		
			 			$('#txtpageNo').val('1');
			 			loadReportGrid();
			 			    CMS(ob);
			    	 }
			    	
		     }
function chkdisble(txtpageNo) {
	$('#dispPage').val(Number(txtpageNo));
	if (parseInt($('#txtpageNo').val(), 10) == 0) {
		$('#btnFirst').attr("disabled", "true");
		$('#btnFirst').css('color', 'gray');
		$('#btnNext').attr("disabled", "true");
		$('#btnNext').css('color', 'gray');
		$('#btnPrevious').attr("disabled", "true");
		$('#btnPrevious').css('color', 'gray');
		$('#btnLast').attr("disabled", "true");
		$('#btnLast').css('color', 'gray');
	} else {
		if (parseInt($('#txtpageNo').val(), 10) != 1) {
			$('#btnFirst').removeAttr("disabled");
			$('#btnFirst').css('color', '#333');
			$('#btnFirst').css({
				cursor : "pointer"
			});
		}

		if (parseInt($('#txtpageNo').val(), 10) == 1) {
			$('#btnFirst').attr("disabled", "true");
			$('#btnFirst').css('color', 'gray');
			$('#btnFirst').css({
				cursor : "default"
			});
		}

		if (parseInt($('#txtpageNo').val(), 10) == 1) {
			$('#btnPrevious').attr("disabled", "true");
			$('#btnPrevious').css('color', 'gray');
			$('#btnPrevious').css({
				cursor : "default"
			});
		}

		if (parseInt($('#txtpageNo').val(), 10) > 1) {
			$('#btnPrevious').removeAttr("disabled");
			$('#btnPrevious').css('color', '#333');
			$('#btnPrevious').css({
				cursor : "pointer"
			});
		}

		if (parseInt($('#txtpageNo').val(), 10) == parseInt($('#totalPages')
				.val())) {
			$('#btnLast').attr("disabled", "true");
			$('#btnLast').css('color', 'gray');
			$('#btnLast').css({
				cursor : "default"
			});
		}

		else {
			$('#btnLast').removeAttr("disabled");
			$('#btnLast').css('color', '#333');
			$('#btnLast').css({
				cursor : "pointer"
			});
		}

		if (parseInt($('#txtpageNo').val(), 10) == parseInt($('#totalPages')
				.val())) {
			$('#btnNext').attr("disabled", "true");
			$('#btnNext').css('color', 'gray');
			$('#btnNext').css({
				cursor : "default"
			});
		} else {
			$('#btnNext').removeAttr("disabled");
			$('#btnNext').css('color', '#333');
			$('#btnNext').css({
				cursor : "pointer"
			});
		}
	}
}

$(function() {
	$('#btnFirst').click(function() {
		var totalPages = parseInt($('#totalPages').val(), 10);

		if (totalPages > 0 && $('#txtpageNo').val() != "1") {
			$('#txtpageNo').val("1");
			loadReportGrid();
			$('#dispPage').val("1");
			if (parseInt($('#txtpageNo').val(), 10) == 1)
				$('#btnPrevious').attr("disabled", "true")
		}
	});
});

$(function() {
	$('#btnLast').click(function() {
		var totalPages = parseInt($('#totalPages').val(), 10);
		if (totalPages > 0) {
			$('#txtpageNo').val(totalPages);
			loadReportGrid();
			$('#dispPage').val(totalPages);
			if (parseInt($('#txtpageNo').val(), 10) == 1)
				$('#btnPrevious').attr("disabled", "true")
		}
	});
});

$(function() {
	$('#btnNext').click(function() {
		var txtpageNo = parseInt($('#txtpageNo').val(), 10);
		var totalPages = parseInt($('#totalPages').val(), 10);

		if (txtpageNo != totalPages) {
			$('#txtpageNo').val(Number(txtpageNo) + 1);
			loadReportGrid();
			$('#dispPage').val(Number(txtpageNo) + 1);
			$('#btnPrevious').removeAttr("disabled");
		}
	});
});

$(function() {
	$('#btnPrevious').click(function() {
		var txtpageNo = $('#txtpageNo').val();

		if (parseInt(txtpageNo, 10) > 1) {
			$('#txtpageNo').val(Number(txtpageNo) - 1);
			loadReportGrid();
			$('#dispPage').val(Number(txtpageNo) - 1);
			if (parseInt($('#txtpageNo').val(), 10) == 1)
				$('#btnPrevious').attr("disabled", "true")
		}
	});
});

$(function() {
	$('#btnGoto').click(function() {
		var txtpageNo = parseInt($('#dispPage').val(), 10);
		var totalPages = parseInt($('#totalPages').val(), 10);
		if (txtpageNo > 0) {
			if (txtpageNo <= totalPages) {
				$('#txtpageNo').val(Number(txtpageNo));
				loadReportGrid();
				$('#dispPage').val(Number(txtpageNo));
				if (parseInt($('#txtpageNo').val(), 10) == 1)
					$('#btnPrevious').attr("disabled", "true")
				if (parseInt($('#txtpageNo').val(), 10) > 1)
					$('#btnPrevious').removeAttr("disabled");
			}
		}
	});
});

function checkBetween(obj_index) {
	if (document.getElementById("selop_" + obj_index).value == 'bt') {
		document.getElementById("txt_div_" + obj_index + "_to").style.display = 'block';
	} else {
		try {
			document.getElementById("txt_div_" + obj_index + "_to").style.display = 'none';
			document.getElementById("txt_" + obj_index + "_to").value = '';
		} catch (e) {
		}
	}
}
function checkKeyGoTo(e) {
	var keyValue = (window.event) ? e.keyCode : e.which;
	if (keyValue == 13) {
		$(function() {
			var txtpageNo = parseInt($('#dispPage').val(), 10);
			var totalPages = parseInt($('#totalPages').val(), 10);
			if (txtpageNo > 0) {
				if (txtpageNo <= totalPages) {
					$('#txtpageNo').val(Number(txtpageNo));
					$('#btnGoto').click();
					$('#dispPage').val(Number(txtpageNo));
				}
			}
		});
	}
}

function sort(column, objIndex) {

	$('span[id^=img_sort_]').each(function(i) {
		$(this).removeAttr("class");
	});

	$('#txtsortColumn').val(column);
	if ($('#txtsortCol_' + objIndex).val() == 'asc') {
		$('#txtsortOrder').val('desc');
		$('#txtsortCol_' + objIndex).val('desc');
		document
				.getElementById('img_sort_' + objIndex)
				.setAttribute(
						'class',
						'ui-grid-ico-sort ui-icon-desc ui-icon ui-icon-triangle-1-s ui-sort-ltr ui-state-disabled');
	} else {
		$('#txtsortOrder').val('asc');
		$('#txtsortCol_' + objIndex).val('asc');
		document
				.getElementById('img_sort_' + objIndex)
				.setAttribute(
						'class',
						'ui-grid-ico-sort ui-icon-asc ui-icon ui-icon-triangle-1-n ui-sort-ltr ui-state-disabled');

	}
	$('#txtpageNo').val('1');

	loadReportGrid();
}

function resetGrid() {
	$('#txtpageNo').val('1');

	$('#frmReportSearch').each(function() {
		this.reset();
		for ( var i = 0; i < searchColArr.length; i++) {
			$('#txtHid_' + searchColArr[i]).val('');
			$('#txt_' + searchColArr[i]).val('');
		}
	});
	try {
		for ( var i = 0; i < searchColArr.length; i++) {
			if (document.getElementById("selop_" + searchColArr[i]) != null
					&& document.getElementById("selop_" + searchColArr[i]) != undefined) {
				document.getElementById("selop_" + searchColArr[i]).selectedIndex = 0;
				if (document.getElementById('txt_div_' + searchColArr[i]
						+ '_to') != null) {
					document.getElementById('txt_div_' + searchColArr[i]
							+ '_to').style.display = 'none';
				}
			}

			if ($("#txt_" + searchColArr[i]) != null
					&& $("#txt_" + searchColArr[i]) != undefined
					&& $("#txt_" + searchColArr[i]).attr('class') != undefined
					&& $("#txt_" + searchColArr[i]).attr('class').toString()
							.indexOf('easyui-combotree') != -1) {
				document.getElementsByName("txt_" + searchColArr[i]).item(0).value = '';
			}
		}
	} catch (e) {
		alert("Search criteria not found");
	}

	var searchReportJson = {};
	if ($.cookie("savedSearch") != "" && $.cookie("savedSearch") != null) {
		searchReportJson = JSON.parse($.cookie("savedSearch"));

		var searchReportObj = searchReportJson["r_" + jsReportId];
		if (searchReportObj != null) {
			delete searchReportJson["r_" + jsReportId];
			$.cookie("savedSearch", JSON.stringify(searchReportJson), {
				path : '/${projectProperties.contextName}/'
			});
		}
	}
	if(jsReportId != '32' && jsReportId != '45'){ // reportId 32 for Manage Audit trial report officer side and reportId 45 for manage audit trial report bidder side
   		loadReportGrid();
   		
   		// PT : #36402 By Jitendra. Validation for search criteria for Bidder Profile Details Report Only.
		if(jsReportId == 124){
			$('#searchErrorDiv').hide();
		}
   		
   	}else{
   		$(".padding1").attr('style','display:none');
   		$("#resultTable").append("<tr class='line-height v-a-middle padding1'><td colspan='7'>No Record Found </td> </tr>");
   		$("#paginationId").attr("style","display:none");
   		$("#divTotalRecords").html(totalRec+":0");
   	}
	
}

function generatePdf(generateType) // bug:19812 add arrgument for change in
									// print option.
{
	var urlstr = "";
	if (pdfPageWise != null && pdfPageWise != '1') {

		var j = "";
		$("#resultTable > tbody > tr").each(function(i) {
			if (i >= 2) {
				j += "<tr id='resultrtemp'>" + $(this).html() + "</tr>"; // /CR:
																			// 17844
			}
		});

		if (rptType == 'V') {
			$('#resultTablePdf').find("tr:gt(2)").remove();   // bug solved for first record repeat at the time of second hit.  
			$('#resultTablePdf tr:last').after(j);
		} else {
			$('#resultTablePdf1').find("tr:gt(1)").remove();
			$('#resultTablePdf1 tr:last').after(j);
		}

		if ($('#noRecordFound').attr('value') == "noRecordFound") {
			$("#txtpageNoPdf").val("0");
		}
		$("#divTotalRecordsPdf").html(totalRecords + ": " + varRecordPerPage);
		$("#divSearchCriteriaPdf").html($("#divSearchCriteria").html());
		exportDivToPDF(generateType);
	} else {
		for ( var i = 0; i < searchColArr.length; i++) {
			if ($("#selop_" + searchColArr[i]).val() != undefined) {
				urlstr += "&selop_" + searchColArr[i] + "="
						+ $("#selop_" + searchColArr[i]).val();
				urlstr += "&jhselop_" + searchColArr[i] + "="
						+ $("#jhselop_" + searchColArr[i]).val();
			}
			strVal = $.trim($("#txt_" + searchColArr[i]).val());
			if ($("#txt_" + searchColArr[i]).attr('class') != undefined
					&& $("#txt_" + searchColArr[i]).attr('class').toString()
							.indexOf('easyui-combotree') != -1) {
				strVal = $.trim(document.getElementsByName(
						"txt_" + searchColArr[i]).item(0).value);
			}
			if (strVal != "") {
				strVal = encodeSPChar(strVal);
			}
			urlstr += "&txt_" + searchColArr[i] + "=" + strVal;
			strVal = $.trim($("#txt_" + searchColArr[i] + "_to").val());
			if (strVal != '') {
				strVal = encodeSPChar(strVal);
			}
			urlstr += "&txt_" + searchColArr[i] + "_to=" + strVal;
		}
		urlstr += "&txtReportId=" + jsReportId + "&txtpageNo="
				+ $("#txtpageNo").val() + "&txtsize=" + $("#txtsize").val()
				+ "&txtparam1=" + escape(jsParam1).replace('+', '%2B')
				+ "&txtparam2=" + escape(jsParam2).replace('+', '%2B')
				+ "&txtparam3=" + escape(jsParam3).replace('+', '%2B')
				+ "&txtparam4=" + escape(jsParam4).replace('+', '%2B')
				+ "&txtparam5=" + escape(jsParam5).replace('+', '%2B')
				+ "&txtparam6=" + escape(jsParam6).replace('+', '%2B')
				+ "&txtparam7=" + escape(jsParam7).replace('+', '%2B')
				+ "&txtparam8=" + escape(jsParam8).replace('+', '%2B')
				+ "&txtparam9=" + escape(jsParam9).replace('+', '%2B')
				+ "&txtparam10=" + escape(jsParam10).replace('+', '%2B')
				+ "&txtsortColumn=" + $('#txtsortColumn').val()
				+ "&txtsortOrder=" + $('#txtsortOrder').val() + "&txtTab="
				+ selectedTab;
				
				$.ajax({
					type : "POST",
					url : jsPDFReportUrlStr,
					dataType : 'text',
					data : urlstr,
					success : function(j) {
						if (rptType == 'V') {
							$('#resultTablePdf').find("tr:gt(2)").remove(); // bug solved for first record repeat at the time of second hit.
							$('#resultTablePdf tr:last').after(j);
						} else {
							$('#resultTablePdf1').find("tr:gt(1)").remove();
							$('#resultTablePdf1 tr:last').after(j);
						}

						if ($('#noRecordFound').attr('value') == "noRecordFound") {
							$("#txtpageNoPdf").val("0");
						}
						$("#divTotalRecordsPdf").html(
								$("#divTotalRecords").html());
						$("#divSearchCriteriaPdf").html(
								$("#divSearchCriteria").html());
						$("#resultTablePdf tbody tr .pdfdisplay").each(function() {
					        $(this).attr("style","visibility: visible");
					     });
						
						exportDivToPDF(generateType);
					},
					error : function(XMLHttpRequest, textStatus, errorThrown) {
						alert(ajaxErrorMsg);
						return false;
					}
				});
		
	}
	try {
		// $("tr[id=resultrtemp]").remove();
		$("[id=resultrtemp]").each(function() { // ///CR: 17844
			$(this).remove();
		});
	} catch (err) {
		console.log("Error in resultrtemp remove: " + err);
	}
}

function encodeSPChar(str) {
	str = str.replace(/\%/g, "%25");
	str = str.replace(/\&/g, "%26");
	str = str.replace(/\+/g, "%2B");
	str = str.replace(/\#/g, "%23");
	return str;
}

function tabClick(selTabId) {
	$("a").each(
			function(i) {

				if ($(this).attr('id') != null
						&& $(this).attr('id') != undefined
						&& $(this).attr('id').indexOf('link') != -1) {
					$(this).removeClass("tab active");
				}
			});
	$("span[id*='divTotalRecords']").each(
			function(i) {
				if ($(this).html().indexOf("Total") == -1
						&& displayAllTabCount != 'Y') {
					$(this).html("");
				}
			});
	selectedTab = selTabId;

	$('#link_' + selTabId).addClass('tab active');
	$('#txtpageNo').val('1');
	resetGrid();
}

function loadReportGrid() {debugger;
	$('#searchErrorDiv').html('');
	
	// PT : #36402 By Jitendra. Validation for search criteria for Bidder Profile Details Report Only. 
	if(jsReportId == 124){
		$('#searchErrorDiv').hide();
	}
	
	// $('#txt_5').combotree('setValue', 544);
	$('#frmReportSearch input[type="text"]').each(function(){
		$(this).val(replaceQuotes($(this).val()));
	});
	if (validateSearchData()) {
		var searchReportJson = {};
		if ($.cookie("savedSearch") != "" && $.cookie("savedSearch") != null) {
			searchReportJson = JSON.parse($.cookie("savedSearch"));
			var searchReportObj = searchReportJson["r_" + jsReportId];

			if (searchReportObj != null && !searchCall) {
				$.each(searchReportObj, function(key, data) {
					if (data.type == "text") {
						$("#" + data.id).val(data.value);
					} else if (data.type == "select") {
						$("#" + data.id).prop('selectedIndex', data.index);

						if (data.id.indexOf("selop_") == 0
								&& $("#" + data.id).val() == 'bt') {
							$("#txt_div_" + data.id.split("_")[1] + "_to").css(
									"display", "block");
						}
					} else if (data.type == "combotree") {
						$("#" + data.id).combotree("setValue", data.value);
					}
				});
			}
		}

		var itemValArray = [];
		var urlstr = "";
		var strVal = "";
		var isSearchGiven = false;
		for ( var i = 0; i < searchColArr.length; i++) {
			if ($("#selop_" + searchColArr[i]).val() != undefined) {
				urlstr += "&selop_" + searchColArr[i] + "="
						+ $("#selop_" + searchColArr[i]).val();
				urlstr += "&jhselop_" + searchColArr[i] + "="
						+ $("#jhselop_" + searchColArr[i]).val();

				var obj1 = {};
				obj1.id = "selop_" + searchColArr[i] + "";
				obj1.type = "select";
				obj1.index = ""
						+ $("#selop_" + searchColArr[i]).prop("selectedIndex")
						+ "";
				itemValArray.push(obj1);
			}
			strVal = $.trim($("#txt_" + searchColArr[i]).val());
			if ($("#txt_" + searchColArr[i]).attr('class') != null
					&& $("#txt_" + searchColArr[i]).attr('class').toString()
							.indexOf('easyui-combotree') != -1) {
				strVal = $.trim($("#txtHid_" + searchColArr[i]).val());
			}

			if ($("#selsel_" + searchColArr[i]).val() != null
					&& $("#selsel_" + searchColArr[i]).val() != "") {
				var obj1 = {};
				obj1.id = "selsel_" + searchColArr[i] + "";
				obj1.type = "select";
				obj1.index = ""
						+ $("#selsel_" + searchColArr[i]).prop("selectedIndex")
						+ "";
				itemValArray.push(obj1);
			}

			if (strVal != "") {
				strVal = encodeSPChar(strVal);
				isSearchGiven = true;

				var inputType = "text";
				if ($("#txt_" + searchColArr[i]).attr('class') != null
						&& $("#txt_" + searchColArr[i]).attr('class')
								.toString().indexOf('easyui-combotree') != -1) {
					inputType = "combotree";
				}

				var obj1 = {};
				obj1.id = "txt_" + searchColArr[i] + "";
				obj1.type = inputType;
				obj1.value = strVal;
				itemValArray.push(obj1);
			}
			urlstr += "&txt_" + searchColArr[i] + "=" + strVal;
			strVal = $.trim($("#txt_" + searchColArr[i] + "_to").val());
			if (strVal != '') {
				strVal = encodeSPChar(strVal);
				isSearchGiven = true;

				var obj1 = {};
				obj1.id = "txt_" + searchColArr[i] + "_to";
				obj1.type = "text";
				obj1.value = strVal;
				itemValArray.push(obj1);
			}
			urlstr += "&txt_" + searchColArr[i] + "_to=" + strVal;
		}

		if (searchCall) {
			searchReportJson["r_" + jsReportId + ""] = itemValArray;
			$.cookie("savedSearch", JSON.stringify(searchReportJson), {
				path : '/${projectProperties.contextName}/'
			});
		}

		if (isSearchGiven || !searchCall) {
			$('#reportResultDiv').fadeOut();
			//UI Issue #39968 Tender Form Library Report
			if(jsReportId == 40){
				$('#selectdForm').fadeOut();
			}
			$('#resultTablePdf').find("tr:gt(3)").remove();
			urlstr += "&txtReportId=" + jsReportId + "&txtpageNo="
					+ $("#txtpageNo").val() + "&txtsize=" + $("#txtsize").val()
					+ "&txtparam1=" + escape(jsParam1).replace('+', '%2B')
					+ "&txtparam2=" + escape(jsParam2).replace('+', '%2B')
					+ "&txtparam3=" + escape(jsParam3).replace('+', '%2B')
					+ "&txtparam4=" + escape(jsParam4).replace('+', '%2B')
					+ "&txtparam5=" + escape(jsParam5).replace('+', '%2B')
					+ "&txtparam6=" + escape(jsParam6).replace('+', '%2B')
					+ "&txtparam7=" + escape(jsParam7).replace('+', '%2B')
					+ "&txtparam8=" + escape(jsParam8).replace('+', '%2B')
					+ "&txtparam9=" + escape(jsParam9).replace('+', '%2B')
					+ "&txtparam10=" + escape(jsParam10).replace('+', '%2B')
					+ "&txtsortColumn=" + $('#txtsortColumn').val()
					+ "&txtsortOrder=" + $('#txtsortOrder').val() + "&txtTab="
					+ selectedTab;
			$.blockUI({
		        message: '<h1>Please wait...</h1>',
		        onBlock: function() {
		        	$.ajax({
						type : "POST",
						url : jsReportUrlStr,
						dataType : 'text',
						data : urlstr,
						success : function(j) {
							if ($.trim(j).indexOf("sessionexpired") != -1) {
								window.location = errorPageUrl;
							} else {
								if (rptType == 'V') {
									if (selectedTab == '') {
										if (searchColArr.length != 0
												&& searchColArr != undefined) {
											$('#resultTable').find("tr:gt(2)")
													.remove();
										} else {
											$('#resultTable').find("tr:gt(1)")
													.remove();
										}

									} else {
										$('#resultTable').find("tr:gt(2)")
												.remove();
									}
									$('#resultTable tr:last').after(j);
								} else {
									$('#reportDetail').html(j);
								}

								if ($('#noRecordFound').attr('value') == "noRecordFound") {
									$("#txtpageNo").val("0");
								}

								if ($("#totalPages").val() == 1) {
									$('#btnNext').attr("disabled", "true");
									$('#btnLast').attr("disabled", "true");
								} else {
									$('#btnNext').removeAttr("disabled");
									$('#btnLast').removeAttr("disabled");
								}

								$("#pageTot").html('');

								$("#pageTot").html($("#totalPages").val());

								$("#pageNoTot").html($("#txtpageNo").val());

								if (displayAllTabCount == 'Y') {
									var arrTabDtl = $("#tabCountsDetails")
											.val().split("||");
									$("span[id*='divTotalRecords']")
											.each(
													function(i) {
														if ($(this).attr('id')
																.indexOf('_') != -1) {

															for ( var j = 0; j < arrTabDtl.length; j++) {
																if (arrTabDtl[j]
																		.indexOf("::") != -1
																		&& arrTabDtl[j]
																				.split("::")[0] == $(
																				this)
																				.attr(
																						'id')
																				.substr(
																						$(
																								this)
																								.attr(
																										'id')
																								.indexOf(
																										'_') + 1)) {
																	$(this)
																			.html(
																					"("
																							+ arrTabDtl[j]
																									.split("::")[1]
																							+ ")");
																}
															}
														}
													});
								}
								if (selectedTab == '') {
									$("#divTotalRecords").html(
											totalRecords + ": "
													+ $("#totalRecords").val());
								} else {
									$("#divTotalRecords_" + selectedTab).html(
											"(" + $("#totalRecords").val()
													+ ")");
									$("#divTotalRecords").html(
											totalRecords + ": "
													+ $("#totalRecords").val());
								}
								$("#divSearchCriteria").html(
										$("#searchCriteria").val());

								$('th[id^=col]')
										.each(
												function(i) {
													if ($("#searchCriteria")
															.val() == ''
															&& $(this)
																	.attr('id')
																	.indexOf(
																			'1') != -1) {
														$(this).hide();
													} else {
														$(this).show();
													}
												});

								if ($("#searchCriteria").val() == '') {
									$('#tabTd').show();
									$("#divTotalRecords").hide();
									$("#searchCriTotalDiv").hide();
								} else {
									$('#tabTd').hide();
									$("#searchCriTotalDiv").show();
									$("#divTotalRecords").html(
											totalRecords + ": "
													+ $("#totalRecords").val());
									$("#divTotalRecords").show();
								}
								$('#resultDiv').show();
								chkdisble($("#txtpageNo").val());
								$('#reportResultDiv').fadeIn();
								//UI Issue #39968 Tender Form Library Report
								if(jsReportId == 40){
									$('#selectdForm').fadeIn();
								}
								if ($("#totalPages").val() <= 1) {

									$("td#pagination").hide();
									$(" #pagination td.pagination").hide();
								} else {
									$("td#pagination").show();
									$(" #pagination td.pagination").show();
								}
							}
							try{
								$('#frmReportSearch input[type="text"]').each(function(){
									$(this).val(reverseReplaceQuotes($(this).val()));
								});
								myFileFun(selectedTab);
							}catch(err){
								
							}
							$.unblockUI();
						//	chatcount();
							load();
                            
						},
						error : function(XMLHttpRequest, textStatus,
								errorThrown) {
							alert(ajaxErrorMsg);
							$.unblockUI();
							return false;
						}
					});
		        }	
		      });	

		} else {
			$('#searchErrorDiv')
					.html(
							'<font color="red">' + msg_common_report_search
									+ '</font>');
			
			// PT : #36402 By Jitendra. Validation for search criteria for Bidder Profile Details Report Only.
			if(jsReportId == 124){
				$('#searchErrorDiv').show();
			}
		}
		searchCall = false;
	}
}

function exportDivToExcel(forPrintData) {
	var urlstr = "";
	var strVal = "";
	for ( var i = 0; i < searchColArr.length; i++) {
		if ($("#selop_" + searchColArr[i]).val() != undefined) {
			urlstr += "&selop_" + searchColArr[i] + "="
					+ $("#selop_" + searchColArr[i]).val();
			urlstr += "&jhselop_" + searchColArr[i] + "="
					+ $("#jhselop_" + searchColArr[i]).val();
		}
		strVal = $.trim($("#txt_" + searchColArr[i]).val());

		if ($("#txt_" + searchColArr[i]).attr('class') != undefined
				&& $("#txt_" + searchColArr[i]).attr('class').toString()
						.indexOf('easyui-combotree') != -1) {
			strVal = $.trim(document
					.getElementsByName("txt_" + searchColArr[i]).item(0).value);
		}
		if (strVal != "") {
			strVal = encodeSPChar(strVal);
		}
		urlstr += "&txt_" + searchColArr[i] + "=" + strVal;
		strVal = $.trim($("#txt_" + searchColArr[i] + "_to").val());
		if (strVal != '') {
			strVal = encodeSPChar(strVal);
		}
		urlstr += "&txt_" + searchColArr[i] + "_to=" + strVal;
	}
	urlstr += "&txtTab=" + selectedTab + "&txtpageNo=" + $("#txtpageNo").val()
			+ "&txtsize=" + $("#txtsize").val();
	if (forPrintData == '1') {
		document.frmExcel.action = jsXLSReprortUrlStr + urlstr;
	} else {
		document.frmExcel.action = jsPrintReprortUrlStr + urlstr;
	}
	document.frmExcel.method = 'POST';
	document.frmExcel.submit();
}

// To Remove
function printDataToRemove() {
	printElemToRemove({
		leaveOpen : true,
		printMode : 'popup'
	});
}

// To Remove
function printElemToRemove(options) {

	$
			.post(
					jsPrintReprortUrlStr,
					{
						txtIsPrint : "yes",
						txtIsPDF : "yes",
						reportId : printReportId
					},
					function(j) {
						if ($.trim(j.toString()) == 'sessionexpired') {
							window.location = "${pageContext.servletContext.contextPath}/sessionexpired";
						} else {
							$('#print_area').html(j);
							$('#print_area').printElement(options);
						}
					});
}

function exportDivToPDF(generateType) // bug:19812 add arrgument for change in
										// print option.
{
	try{
		myFileFunForPDF(selectedTab);
	}catch(err){
		
	}
	var tableHTML = '';
	var dynPageSize1, isLandScape1, hdfileName1, pdfBuffer1, hdid1, txtGenerateType1,forwardUrl1;
	var rptDynPageSize = document.createElement("input");
	rptDynPageSize.type = "hidden";
	rptDynPageSize.name = "dynPageSize";
	rptDynPageSize.value = document.getElementById("scrolldata").scrollWidth + (customWidth == '' || customWidth == undefined ? 100 : parseInt(customWidth));
	dynPageSize1 = rptDynPageSize.value;
	document.getElementById("formstyle").appendChild(rptDynPageSize);
	var forwardUrl= document.createElement("input");
    forwardUrl.type = "hidden";
    forwardUrl.name = "forwardUrl";
    forwardUrl.value = pageUrl;
    forwardUrl1= forwardUrl.value;
    document.getElementById("formstyle").appendChild(forwardUrl);
	if (isLandScape) {
		if (isLandScape != undefined && isLandScape == true) {
			var rptIsLandScape = document.createElement("input");
			rptIsLandScape.type = "hidden";
			rptIsLandScape.name = "isLandScap";
			rptIsLandScape.value = isLandScape;
			document.getElementById("formstyle").appendChild(rptIsLandScape);
			isLandScape1 = rptIsLandScape.value;
		}
	}
	if (pdfReqDivId != null && pdfReqDivId != '') {
		var gobackhtml = $('#gobacklink').html();
		$('#gobacklink').html("");
		var pdfHeadData = $("#" + pdfReqDivId).html();
		$('#gobacklink').html(gobackhtml);
		// tableHTML = "<div>"+$.trim(pdfHeadData)+"<div
		// style='padding-top:10px;'>"+$("#pdfReportDiv").html()+"</div></div>";
		
		// Unable to print document while clicking print icon. Bug #32783 by Jitendra.
		tableHTML = "<section class='inner-right-bar pull-left grid_26 border-left'><div class='print-pdf main_container o-hidden' id='temp'><div class='container_25'><div class='content_section' ><section class='inner-right-bar pull-left grid_26 border-left'>"
				+ (pdfHeadData != undefined ? $.trim(reverseReplaceQuotes(pdfHeadData)) : "")
				+ $("#pdfReportDiv").html()
				+ "</section></div></div></div></section>";
	} else {
		tableHTML = "<section class='inner-right-bar pull-left grid_26 border-left'><div class='print-pdf main_container o-hidden' id='temp'><div class='container_25'><div class='content_section' ><section class='inner-right-bar pull-left grid_26 border-left'>"
				+ reverseReplaceQuotes($("#pdfReportDiv").html())
				+ "</section></div></div></div></section>";
	}
	//console.log(tableHTML);
	document.formstyle.pdfBuffer.value = (tableHTML + "</div></div></div>").replace(/<a.+?\/?>/g, '');
	pdfBuffer1 = document.formstyle.pdfBuffer.value;
	document.formstyle.method = 'POST';
	var fs = 12;
	if (userTypeId == 1) {
		/*
		 * while(true) { var fs=prompt("Enter font size:","12"); if(fs==null ||
		 * (fs!='' && !isNaN(fs) && parseInt(fs,10) >=5 && parseInt(fs,10)<=15)) {
		 * break; } else { alert("Invalid Font size. Please enter font size
		 * between 5 and 15."); } }
		 */
	}
	if (fs == null) {
		return false;
	}

	$('#txtFontSize').val(fs);
	hdfileName1 = $("#hdfileName").val();
	hdid1 = $("#hdid").val();
	if (generateType != undefined && generateType != null && generateType != ''
			&& generateType == 5) {
		txtGenerateType1 = 5;
		if (isIE8Browser) {
			exportDivToExcel('0');
		} else {
			pdfToPrint(dynPageSize1, isLandScape1, hdfileName1, pdfBuffer1,
					hdid1, txtGenerateType1,0,0,pageUrl);
		}
	} else {
		if (generateType == 4) {
			$("#txtGenerateType").val(generateType);
		} else {
			$("#txtGenerateType").val(0);
		}

		document.formstyle.submit();
	}

}

function toggleAdvanceSearch() {
	if ($('#tblAdvanceSearch').attr("style") == 'display: none;') {
		$('#tblAdvanceSearch').attr("style", 'display: ;');
		$("#lnkAdvSearch").html(MSG_NORMALSEARCH);
	} else {
		$('#tblAdvanceSearch').attr("style", 'display: none;');
		$("#lnkAdvSearch").html(MSG_ADVANCESEARCH);
	}
}

function specialTrim(str) {
	return str.replace(/>\s+</g, '><');
}

function validateSearchData() {
	var vBool = true;
	var datatype = '';
	for ( var i = 0; i < searchColArr.length; i++) {
		datatype = $('#hdDataType_' + searchColArr[i]).val();
		if (datatype == 'text') {
			vBool = validateText($('#txt_' + searchColArr[i]), searchColArr[i]);
		} else if (datatype == 'numeric') {
			vBool = validateNumeric($('#txt_' + searchColArr[i]),
					searchColArr[i]);
		} else if ((datatype == 'date' || datatype == 'datetime')
				&& $('#txt_' + searchColArr[i]).val() != null
				&& $('#txt_' + searchColArr[i]).val() != ''
				&& $('#selop_' + searchColArr[i]).val() == 'bt') {
			vBool = validateDate($('#txt_' + searchColArr[i]).val(), $(
					'#txt_' + searchColArr[i] + '_to').val(), searchColArr[i],
					datatype);
		}
		if (!vBool) {
			break;
		}
	}
	return vBool;
}

function validateText(textbox, colId) {
	$("#err" + colId).remove();
	var string = $.trim($(textbox).val());
	
	// PT : #36402 By Jitendra. Validation for 'budget' field for Bidder Profile Details Report Only. 
	if(colId == 522){
		if(string != "" && (isNaN(string) || string.length > 10)){
			$(textbox).parent().append(
					"<div id='err" + colId + "' style='color:red;'>"
							+ msg_validation_budget + "</div>");
			return false;
		}
	}else{
		if (string != null && string != ""
			&& (string.indexOf("--") != -1 || string.indexOf("=") != -1)) {
			$(textbox).parent().append(
				"<div id='err" + colId + "' style='color:red;'>"
						+ VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL + "</div>");
			return false;
		}
	}
	
	return true;
}

function validateDate(startdt, enddate, colId, datatype) {
	$("#err" + colId).remove();
	var startDtVal = "";
	var endDtVal = "";
	if (enddate == null || enddate == "") {
		$('#txt_' + colId + '_to').parent().append(
				"<div id='err" + colId + "' style='color:red;'>"
						+ MSG_AUC_ENTERVAL + "</div>");
		return false;
	}
	if (dtFormat == 'DD/MM/YYYY') {
		var dtArr = null;
		var dtHr = null;
		if (datatype == 'date') {
			dtArr = startdt.split("/");
			startDtVal = Date.parse(dtArr[2] + "/" + dtArr[1] + "/" + dtArr[0]);

			dtArr = enddate.split("/");
			endDtVal = Date.parse(dtArr[2] + "/" + dtArr[1] + "/" + dtArr[0]);
		} else if (datatype == 'datetime') {
			dtHr = startdt.split(" ")[1];
			dtArr = startdt.split(" ")[0].split("/");
			startDtVal = Date.parse(dtArr[2] + "/" + dtArr[1] + "/" + dtArr[0]
					+ " " + dtHr);

			dtHr = enddate.split(" ")[1];
			dtArr = enddate.split(" ")[0].split("/");
			endDtVal = Date.parse(dtArr[2] + "/" + dtArr[1] + "/" + dtArr[0]
					+ " " + dtHr);
		}
	} else if (dtFormat == 'MM/DD/YYYY') {
		if (datatype == 'date') {
			startDtVal = Date.parse(startdt, 'MM/DD/YYYY');
			endDtVal = Date.parse(enddate, 'MM/DD/YYYY');
		} else if (datatype == 'datetime') {
			startDtVal = Date.parse(startdt, 'MM/DD/YYYY hh:mm');
			endDtVal = Date.parse(enddate, 'MM/DD/YYYY hh:mm');
		}
	} else if (dtFormat == 'DD MMM YYYY') {
		if (datatype == 'date') {
			startDtVal = Date.parse(startdt, 'DD MMM YYYY');
			endDtVal = Date.parse(enddate, 'DD MMM YYYY');
		} else if (datatype == 'datetime') {
			startDtVal = Date.parse(startdt, 'DD MMM YYYY hh:mm');
			endDtVal = Date.parse(enddate, 'DD MMM YYYY hh:mm');
		}
	}
	// alert(startDtVal);
	// alert(endDtVal);
	if (startDtVal > endDtVal) {
		$('#txt_' + colId + '_to').parent().append(
				"<div id='err" + colId + "' style='color:red;'>"
						+ MSG_VALID_RANGE + "</div>");
		return false;
	}
	return true;
}

function validateNumeric(textbox, colId) // Datatype = Numeric
{
	var string = $.trim($(textbox).val());
	$("#err" + colId).remove();
	if (string != null && string != "" && isNaN(string)) {
		$(textbox).parent().append(
				"<div id='err" + colId + "' style='color:red;'>"
						+ VALIDATE_MSG_ONLY_NUMERIC + "</div>");
		return false;
	} else if (string != null && string != "" && !isNaN(string)
			&& $('#selop_' + colId).val() == 'bt') {
		var textboxto = $('#txt_' + colId + '_to');
		var stringTo = $.trim($('#txt_' + colId + '_to').val());
		if (stringTo == null || stringTo == "") {
			$(textboxto).parent().append(
					"<div id='err" + colId + "' style='color:red;'>"
							+ MSG_AUC_ENTERVAL + "</div>");
			return false;
		} else if (stringTo != null && stringTo != "" && isNaN(stringTo)) {
			$(textboxto).parent().append(
					"<div id='err" + colId + "' style='color:red;'>"
							+ VALIDATE_MSG_ONLY_NUMERIC + "</div>");
			return false;
		} else if (parseFloat(string, 10) > parseFloat(stringTo, 10)) {
			$(textboxto).parent().append(
					"<div id='err" + colId + "' style='color:red;'> "
							+ MSG_VALID_RANGE + "</div>");
			return false;
		}
	}
	return true;
}