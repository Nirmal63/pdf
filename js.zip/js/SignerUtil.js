/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
// JavaScript Document
function trim(s)
{
    while (s.substring(0,1) == ' ')
    {
        s = s.substring(1,s.length);
  
    }
  
    while (s.substring(s.length-1,s.length) == ' ')
    {
        s = s.substring(0,s.length-1);
    }
    return s;
}

function generateSign(pkey, plainData)
{
    //var pkey = document.getElementById("publickey").value;
    sealock.openKeyStore("my","");
    var certCount = sealock.getCertificateCount();
    for(var i=1;i<=certCount;i++)
    {
        sealock.selectCertificate(sealock.getCertificateAlias(i));
        if(sealock.getPublicKey() == pkey){
            break;
        }else{
            if(i==certCount)
            {
                alert("Proper certificate is not installed on this machine.");
                return false;
            }
        }
    }
    
    //var plainData = trim(document.getElementById("signedData").value);
	
    var signedData;
    if(plainData != "")
    {
        sealock.setData(plainData);
        try
        {
            signedData = sealock.getSignature();
        }
        catch(e)
        {
            signedData = "";
            return false;
        }
        document.getElementById("txtsignedData").value = signedData;
        sealock.setData("");
        document.getElementById("txtsignedData").readOnly = true;
    }
    
    return signedData;
}

function generateSign1(pkey, plainData)
{
    //var pkey = document.getElementById("publickey").value;
    sealock.openKeyStore("my","");
    var certCount = sealock.getCertificateCount();
    for(var i=1;i<=certCount;i++)
    {
        sealock.selectCertificate(sealock.getCertificateAlias(i));
        if(sealock.getPublicKey() == pkey){
            break;
        }else{
            if(i==certCount)
            {
                alert("Proper certificate is not installed on this machine.");
                return false;
            }
        }
    }
    
    //var plainData = trim(document.getElementById("signedData").value);
	
    var signedData;
    if(plainData != "")
    {
        sealock.setData(plainData);
        try
        {
            signedData = sealock.getSignature();
        }
        catch(e)
        {
            signedData = plainData;
            return false;
        }
        document.getElementById("signedData").value = signedData;
        sealock.setData("");
        document.getElementById("signedData").readOnly = true;
    }
    
    return signedData;
}

 function selectCertificateForDecrypt(pkey)
{
    sealock.openKeyStore("my","");
    var certCount = sealock.getCertificateCount();
    for(var i=1;i<=certCount;i++)
    {
        sealock.selectCertificate(sealock.getCertificateAlias(i));
        if(sealock.getPublicKey() == pkey){
            break;
        }else{
            if(i==certCount)
            {
                alert("Proper certificate is not installed on this machine.");
                return false;
            }
        }
    }
    return true;
}


function decrypt(encStr)
{
    /*dec check start*/
    try{
        sealock.setEncrypt(encStr);
        encStr=sealock.getDecrypt();
        if(encStr == "")
        {
            alert("Decryption Failed" );
        }
    }catch(e){
        encStr="";
        alert("There is an error " + e.messsage);
    }
    /*dec check end*/

    //alert('after decrypt===>'+encStr);
    return encStr;
}



function varifySign(str)
{
    /*dec check start*/
    try{
        sealock.setSignature(str);
        if(sealock.isVerifySignature()){
            if(sealock.getData() == ""){
                alert("Verification Failed");            
            }
            str=sealock.getData();
        }
        else
        {
            str="";
        }
         
    }catch(e){
        str="";
        alert("There is an error " + e.messsage);
    }
    
    /*dec check end*/

    //alert('after decrypt===>'+encStr);
    return str;
}