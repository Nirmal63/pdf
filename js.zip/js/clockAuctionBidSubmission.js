   
/**
 *Method use for update Remaining time of bid submission timer.
 */  
 
function printReport()
{
    window.print()
}   
function dynamicRemClock()
{
	var completedCount = 0;
    if(auctionStatus == '0')
    {  
        for(var cnt=0;cnt<arrRow.length;cnt++)
        {   
                
            var j=cnt;
            if( isItemWiseTimeReq == 1)
            {
                j=arrRow[cnt] - 1;
            }
            // alert(j);
            // alert(Hr[j]+":"+Min[j]+":"+Sec[j]);
            var k=j;
            if(auctionResult == 2 && isItemWiseTimeReq == 1)
            {
                k++;
            }
            if($("#remainTimer_"+j) && isRowBidTimeOver[j] == false)
            {
                
					if(Min[j] == 0 && Sec[j] == 1 && Hr[j] == 0)
                    {
                        setTimeout(function(){
							if(isRowBidTimeOver[j] == false){
								$("#bidBtn_"+j).html('');
								$('#clockTimer_'+j).hide();
								getBidDetails();
							}		
						},5000);
						if(isRowBidTimeOver[j] == false){
							$('#clockTimer_'+j).hide();
							$('#updateTimer_'+j).show();
							$('#updateTimer_'+j).html('Please wait, Final result is being fetched...');
							$("#bidBtn_"+j).html('');
						}
                        
                    /*** END :  ***/
                    }

                    if(Hr[j] > 0){
                        if(Min[j] == 0 && Sec[j] == 0){
                            Hr[j] = Hr[j] - 1;
                            Min[j] = 59;
                            Sec[j] = 60;
                        }else if(Min[j] > 0 && Sec[j] == 0){
                            Min[j] = Min[j] - 1;
                            Sec[j] = 60;
                        }
                        else if(Sec[j] == 0){
                            Sec[j] = 60;
                        }
                    }else{
                        if(Min[j] > 0 && Sec[j] == 0){
                            Min[j] = Min[j] - 1;
                            Sec[j] = 60;
                        }
                        else if(Sec[j] == 0){
                            Sec[j] = 60;
                        }
                    }
                    Sec[j] = Sec[j] - 1;					
					
					
                //}   
                if(!isNaN(Hr[j]) && !isNaN(Min[j]) && !isNaN(Sec[j]))
                {
                	$("#remainTimer_"+k).html(Hr[j]+" Hr - "+Min[j]+" Minutes - "+Sec[j]+" Seconds");
					$('span[id^=bidBtn_]').each(function()
                    {
                        $(this).show();
                    });
                }
                    
                if(isRowBidTimeOver[j]==true && auctionResult == 2 && isItemWiseTimeReq == 1)
                {
                    $("#bidBtn_"+j).html('');
					$('#clockTimer_'+j).hide();
					$('#updateTimer_'+j).show();
					$('#updateTimer_'+j).html(scriptBidTimeOverMsg);
					
                }
                

            }else if(isRowBidTimeOver[j] == true){
				$("#bidBtn_"+j).html('');
				$('#clockTimer_'+j).hide();
				$('#updateTimer_'+j).show();
				$('#updateTimer_'+j).html(scriptBidTimeOverMsg);
			}
			if(isRowBidTimeOver[j] == true){
				completedCount++;
			}
        }
		if(arrRow.length == completedCount && auctionStatus != 0){
			completedCount = 0;
			clearInterval(dynaRemClockInterval);
			clearInterval(getBidInterval);
			clearInterval(marqueeInterval);
			window.location.reload(true);
		}
    }
    else
    {
        $('span[id^=bidBtn_]').each(function()
        {
            $(this).hide();			
			
        });
    }
}  
    
/**
 * Method use to get bid detail using ajax call.
 */  
function getBidDetails()
{
    $.ajax({
        type: "GET",
        url: ajaxBidDetailPath,
        dataType: 'text',
        data: { 
            hdAcceptDecimalUpTo: $('#hdAcceptDecimalUpTo').val()
        },
        success: function(j)
        { 
            try
            {
                if(j!=null && (j.indexOf("SessionExpired")!= -1))
                {
                    alert(sessionexpired);
                    return false;
                }
                else
                {
                    renderBidDetails(j);
                }  
            }
            catch(e)
            {
                alert(scriptErrorMsg+e.toString());
                return false;
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(ajaxErrorMsg);
            return false;
        }
    });
}
  
/**
 * Method use for submit bid detail using ajax.
 */  
function submitItemWiseBid(rId,obButton)
{
    var errcodecount = 0;
    var vbool = true; 
    $('.errcode').each(function(i)
    {	
    	if(this.id.indexOf("_"+rId+"_") > -1){
    		errcodecount++;
    	}
    });
    
    if(errcodecount > 0){
    	vbool = false; 
    }
    
    if(errcodecount == 0){
	    var bidString='RowId_'+rId+'=';
	    $('td[id^=tdmessage]').each(function(i)
	    {
	        $(this).hide();
	    });
	    $('div[id^=divmessage]').each(function(i)
	    {
	        $(this).removeAttr("class");
	        $(this).html("");
	    });
	    var urlstr="";
	    
	    urlstr="temp=1";
	      
	    $('input[id^=txtcell_'+rId+'_]').each(function(i)
	    {
	        if(!$(this).attr("readonly") && $(this).attr('type') != 'hidden')
	        {
	            if(!isRequiredTrue(this)){
	                vbool = false;
	            }
	        }
	        if($(this).attr('type')== 'hidden'||$(this).attr('readonly'))
	        {
	        	 urlstr+="&"+($(this).attr('id').replace('lbl_','txtacell_'))+"="+$(this).val();
	 	         bidString+=$(this).attr('id')+"_value_"+$(this).val()+";";
	        }
	        else
	        {
	        	urlstr+="&"+$(this).attr('id')+"="+replaceQuotes($(this).val()).replace(/\&/g,"%26");
	        	bidString+=$(this).attr('id')+"_value_"+replaceQuotes($(this).val()).replace(/\&/g,"%26")+";";
	        }
	    });
	        
	       	
	    $('textarea[id^=txtacell_'+rId+'_]').each(function(i)
	    {
	        if(!$(this).attr("readonly")  && $(this).attr('type')!='hidden')
	        {
	            if(!isRequiredTrue(this)){
	                vbool = false;
	            }
	        }
	        urlstr+="&"+$(this).attr('id')+"="+replaceQuotes($(this).val()).replace(/\&/g,"%26");
	        bidString+=$(this).attr('id')+"_value_"+replaceQuotes($(this).val()).replace(/\&/g,"%26");+";";
	    });
	        
	    $('label[id^=lbl_'+rId+'_]').each(function(i)
	    {
	        urlstr+="&"+($(this).attr('id').replace('lbl_','txtacell_'))+"="+$(this).html();
	        bidString+=$(this).attr('id')+"_value_"+$(this).html()+";";
	    }); 
	        
	    var vboolRemarks=true;
	    if(userTypeId != USERTYPE_BIDDER)
	    {
	        var txtbidrem=document.getElementById("txtaBidRemarks");
	        $("#errtxtaBidRemarks").remove();
	        vboolRemarks = valOnSubmit();
	        if(txtbidrem.value.length > 1000)
	        {
	            $("#errtxtaBidRemarks").remove();
	            $('#txtaBidRemarks').parent().append("<div id='errtxtaBidRemarks' style='color:red;'>"+ VALIDATE_MSG_MAXIMUM + " " + 1000 + " " + VALIDATE_MSG_CHARS_ALLOWED +"</div>");
	            vboolRemarks = false;
	        }
	    } 
    }
    if(vbool && vboolRemarks)
    {
        var confirmMst="";
        var reConfirmMst="";
        var amountInWord="";
        if(amountConvertion == '0')
        {
            amountInWord =IndianConvertionAmountInWord(eval($("#txtcell_"+rId+"_"+govColumnNo).val()));
        }
        else
        {
            amountInWord =InternationConvertionAmountInWord(eval($("#txtcell_"+rId+"_"+govColumnNo).val()));
        }
        var msgTemp="";
        if($.trim($("#bidAmtIncDec_"+rId).html()) != '' && !isNaN($.trim($("#bidAmtIncDec_"+rId).html())))
        {
            //msgTemp=msg_bid_per_incdec+" "+$.trim($("#bidAmtIncDec_"+rId).html())+"% ";
        	if(bidDiff==bidDiffSpecClientId){
	        	var h1l1="";
	        	if(eventTypeId==1){
	        		h1l1="higher than H1 amount.";
	        	}else{
	        		h1l1="lower than L1 amount.";
	        	}
	            msgTemp="You bid amount is"+" "+$("#txtcell_"+rId+"_"+govColumnNo).val()+",which is "+$.trim($("#bidAmtIncDec_"+rId).html())+"% "+h1l1+" Are you sure you want to submit the bid";
        	}else{
        		msgTemp=msg_bid_per_incdec+" "+$.trim($("#bidAmtIncDec_"+rId).html())+"% ";
        	}
            
        }
        if(displayPriceBidBreakUp == '1')
        {
            confirmMst=bidconfirmmsg+" "+$("#txtcell_"+rId+"_"+govColumnNo).val()+" ( "+amountInWord+confirmationonly+" )";
            reConfirmMst = bidreconfirmmsg+" "+$("#txtcell_"+rId+"_"+govColumnNo).val()+" ( "+amountInWord+ confirmationonly+" )";
        }
        else
        {
        	confirmMst=bidconfirmmsg+".";
			reConfirmMst = bidreconfirmmsg+".";
		}
        if(msgTemp !='')
        {
            confirmMst+="\n"+msgTemp+".";
            reConfirmMst+="\n"+msgTemp+".";
        }
        jConfirm(confirmMst, "", function(response) {
            if (response) {
                jConfirm(reConfirmMst, "", function(response) {
                    if (response) {      
                        if((isPkiEnabled == 1 || isEvenPkiEnabled == 1) && (userTypeId != USERTYPE_ABCUSER || (userTypeId == USERTYPE_ABCUSER && isPkiEnabledAbcUser == 'true')))
                        {
                            bidString =getSignData(bidString);
                        }
                        else
                        {
                            bidString=''
                        }
                        //  alert(bidString);
                        urlstr+="&hdAuctionId="+$('#hdAuctionId').val()+
                        "&hdTableId="+$('#hdTableId').val()+
                        "&hdRowId="+$('#hdRowId_'+rId).val()+
                        "&hdGovColumnId="+$('#hdGovColumnId').val()+
                        "&hdBidderId="+$('#hdBidderId').val()+
                        "&hdBidToken="+$('#hdBidToken').val()+
                        "&skpSignText="+bidString;
					

                        if(userTypeId != USERTYPE_BIDDER)
                        {    
                            urlstr+="&txtaBidRemarks="+$('#txtaBidRemarks').val();
                        }
                        $(obButton).attr('disabled','true');
                        $.ajax({
                            type: "POST",
                            url: ajaxBidSubmissionPath,
                            dataType: 'text',
                            data : encodeURI(urlstr),
                            success: function(j)
                            {
                                $(obButton).removeAttr('disabled');
                                //alert(j);
                                try
                                {                              
                                    if(j!=null && (j.indexOf("SessionExpired")!= -1))
                                    {
                                        alert(sessionexpired);
                                        return false;
                                    }
                                    else
                                    {
                                        var art = j.split("^^");
                                        j=art[0];
                                        //Below line commented for Project Task:#24753
                                        //$('#hdBidToken').val(art[1]);

                                        if(j!=null && (j.indexOf("MSG_BIDTOKEN_NOT_MATCHED")!= -1))
                                        {
                                            var msgDivId='divmessage_'+rId;
                                            $('#tdmessage_'+rId).show();
                                            $('#'+msgDivId).attr("class", "errorMsg m-top");
                                            $('#'+msgDivId).html(eval(art[0]));
                                            window.location = errorPageUrl;
                                            return false;
                                        }
                                        else
                                        {
                                            var bResult=''
                                            if(j!=null && j != '')
                                            {
                                                j=$.trim(j).toString();

                                                bResult=j;
                                                if(j.indexOf("@@")!= -1)
                                                {
                                                    var arrTemp=j.split("@@");
                                                    bResult=arrTemp[0];
                                                    if(arrTemp[1]!=null)
                                                    {
                                                        renderBidDetails(arrTemp[1]);
                                                    }
                                                }
                                            }
                                            
											
											var msgDivId='divmessage_'+rId;
											var msgBidSuccess='bidmessage_'+rId;
											$('#tdmessage_'+rId).show();
											if(bResult == 'msg_aucbid_success') // If bid submitted successfully?
											{
												isRowBidTimeOver[rId-1] = true;
												jAlert(msg_aucbid_success,'Success', function(test){
													if(test == true){
														if(userTypeId != USERTYPE_BIDDER)
														{
															document.getElementById("txtaBidRemarks").value="";
														}
														getAjaxMarqueeDetail();
													} 
												});
												$('#'+msgBidSuccess).attr("class", "successMsg m-top");
												$('#'+msgBidSuccess).html(notifyAllBidMessage);												    
											}
											else
											{
												$('#'+msgDivId).attr("class", "errorMsg m-top");
												$('#'+msgDivId).html(eval(bResult));
											}
											
                                        }
                                    }
                                }
                                catch(e)
                                {
                                    alert(scriptErrorMsg+e.toString());
                                    return false;
                                }
                            },
                            error: function(XMLHttpRequest, textStatus, errorThrown) {
                                $(obButton).removeAttr('disabled');
                                alert(ajaxErrorMsg);
                                return false;
                            }
                        });
                    }
                });
            }
        });
    } // End of vbool if
    return vbool;
    
}
  
/**
 * Method use for render bid details get from ajax at html page.
 */
 
function renderBidDetails(j)
{
    var runItemCount=0;
    try
    {
        j=$.trim(j.toString());
        var ar;
        var arrdtl;
        var arrincri;
        var biddtlincri;
        var biddtl;
        var otherbiddtllist;
        var otherbiddtl;
        var rId;
        var rowId;        
        if(j.indexOf("~^stNextItemTime~") < 0){
        	if(j!=null && j!="" && j!="null")
        	{	
	            var ar=j.split("||");
	            //alert(ar);
	            for(var k=1;k<=totalRows;k++)
	            {
	                $('#bidDetailrowid_'+k).hide();
	            }
				
				/* Start - By Nirav Raval: Change position for below block of code for Task: #23801(Performance analysis and improvement)*/
				/* code for hide button once auction is stop or cancel */
				
				if(auctionStatus != '0')
				{
					for(var i=0;i<isRowBidTimeOver.length;i++){
						if(isRowBidTimeOver[i]!=undefined && isRowBidTimeOver[i] == false){
							$('span[id^=bidBtn_'+i+']').hide();
							$('#clockTimer_'+i).hide();
							$('#updateTimer_'+i).show();
							$('#updateTimer_'+i).html(scriptBidTimeOverMsg);
						}
					}
				}
				else 
				{
					for(var i=0;i<isRowBidTimeOver.length;i++){
						if(isRowBidTimeOver[i]!=undefined && isRowBidTimeOver[i] == false){
							$('span[id^=bidBtn_'+i+']').show();
							$('#clockTimer_'+i).show();
							$('#updateTimer_'+i).hide();
						}
					}
					/*clearInterval(dynaRemClockInterval);
					clearInterval(getBidInterval);
					clearInterval(marqueeInterval);*/
				}  
				/* End - By Nirav Raval: Change position for above block of code for Task: #23801(Performance analysis and improvement)*/
	            for(var i=0;i<=ar.length;i++)
	            {
	                if(auctionResult == 2 && i == 0)
	                {
	                    continue;                        
	                }
	                    
	                if(auctionResult != 2 && i == 0)
	                {
	                    arrdtl=ar[i].toString().split("`");
	                }
	                else if (auctionResult == 2)
	                {
	                    arrdtl=ar[i-1].toString().split("`");
	                }
	                    
	                if(auctionResult == 3 && ar[i]!=null)
	                {
	                    arrincri=ar[i].toString().split("`");
	                    if(arrincri[0]!=null)
	                    {
	                        biddtlincri=arrincri[0].toString().split("~");
	                    }
	                }    
	                    
	                /******* Setting bidder information *****/
	                if(arrdtl[0] !=null) 
	                {
	                    //alert(arrdtl[0]);
	                    biddtl = arrdtl[0].toString().split("~");
	                    rId=biddtl[0];
	                    rowId=parseInt(rId);      
	                        
	                    // alert(rowId);
	                    /*
	                        Bidder Detail Format:
	                        rowId~bidderId~sysdate~remainingtime~enddatevirtual~curExt~IncDecvalue~incDecPer~H1L1price~Rank~lastValidBIdAmount~startPrice
	                        */
	
	                    /* setting Current time */
	                    if(biddtl.length >= 3 && i == 1)  /* Need to set only once not for each rows*/
	                    {
	                        intBidDate = Date.parse(biddtl[2]);
	                        UpdateBidTimer();
	                    }
	
	                    /* setting remaining time,enddate,curExt */
	                    var dtarr = $.trim(biddtl[3]).split(':');
	                    
							if(biddtl[13] == 0){
								isRowBidTimeOver[rowId-1]=true;
							}else{
								isRowBidTimeOver[rowId-1]=false;
							}
							Hr[rowId-1]=parseInt(dtarr[0],10);
	                        Min[rowId-1]=parseInt(dtarr[1],10);
	                        Sec[rowId-1]=parseInt(dtarr[2],10);
	                        if(!isNaN(Hr[rowId-1]) && !isNaN(Min[rowId-1]) && !isNaN(Sec[rowId-1]) && auctionStatus == '0')
	                        {
	                        	$("#remainTimer_"+rowId).html(Hr[rowId-1]+" Hr - "+Min[rowId-1]+" Minutes - "+Sec[rowId-1]+" Seconds");	                            
	                        }
	                        $("#endDate_"+rowId).html(biddtl[4]);
	                        if($("#extCurrent_"+rowId))
	                        {
	                            $("#extCurrent_"+rowId).html(biddtl[5]);
	                        }
	                        if($('#extTotal_'+rowId))
	                        {
	                        	$('#extTotal_'+rowId).html(biddtl[21]); // Bug : 30281
	                        }
	                    
	                    if(auctionResult == 2  && isItemWiseTimeReq == 1 )
	                    {
	                        if(biddtl[13] == '-1')
	                        {
	                            $("#itemRow_"+rowId).hide();
	                            if(isBidderNameMasking == '0' && $("#bidDetailrowid_"+rowId))
	                            {
	                                $("#bidDetailrowid_"+rowId).hide();
	                            }
	                       
	                        }
	                        else
	                        {
	                            runItemCount++;
	                            $("#itemRow_"+rowId).show();
	                            if(isBidderNameMasking == '0' && $("#bidDetailrowid_"+rowId))
	                            {
	                                $("#bidDetailrowid_"+rowId).show();
	                            }
	                        }
	                    }
	                        
	                    if(biddtl[13] != '0') // aution is not closed
	                    {
	                        if(rowId != 0 && $('#clockTimer_'+(rowId - 1)).html() != scriptBidTimeOverMsg)
	                        {
	                            $("#bidBtn_"+(rowId - 1)).html('<button type="button" name="bid_'+rowId+'" id="bid_'+rowId+'" class="blue-button-small" onclick="submitItemWiseBid('+rowId+',this);">'+auc_btn_bid+'</button>');
	                        }
	                        else if($('#clockTimer_0').html() != scriptBidTimeOverMsg)
	                        {
	                            $("#bidBtn_0").html('<button type="button" name="bid" id="bid_0" class="blue-button-small" onclick="submitGrandTotalWiseBidForm(this);">'+auc_btn_bid+'</button>');
	                        }                            
	                    }
	                         
	                    /* setting H1L1amount,lastbiddetail,IncDecValue,BidderRank */
	                    
						$("#startPrice_"+rowId).html(biddtl[11]);
						
						var str = biddtl[11];
						str = str.replace(new RegExp(",", 'g'),"");
						if(isUnitRateDecimal == 0){
							str = str.substring(0,str.lastIndexOf("."));
						}
						$("#txtcell_"+rowId+"_"+unitRateColNo).val(str);
						$("#txtcell_"+rowId+"_"+unitRateColNo).blur();
					

						if($("#incDecPer_"+rowId))
						{
							$("#incDecPer_"+rowId).html(biddtl[7]+"%");
						}
						if($("#incDecAmt_"+rowId))
						{
							$("#incDecAmt_"+rowId).html(biddtl[6]);
						}
	                    
	                    if(isBidder == 'true'){
	                    	$("#BidDate_"+rowId).html((biddtl[15]!='null' && biddtl[15]!='')? biddtl[15]: '&nbsp;'+MSG_NOTBIDDED);
	                    }else{
	                    	$("#BidDate_"+rowId).html('&nbsp;-&nbsp;');
	                    }
						
						if(biddtl[8]!='null' && biddtl[8]!=''){
							var msgBidSuccess='bidmessage_'+rowId;
							$('#'+msgBidSuccess).attr("class", "successMsg m-top");
							$('#'+msgBidSuccess).html(notifyAllBidMessage);	
						}
						
	                    if($("#h1l1Amount_"+rowId) && auctionType == 1 || (showWinningBidAmount  == 1 && (showWinningBid == 1 || (showWinningBid == 2 && biddtl[10] != ''))))
	                    {
	                    	$("#h1l1Amount_"+rowId).html(biddtl[8] != ''? biddtl[8]:MSG_NOTBIDDED);
	                        if($("#h1l1BidderName_"+rowId))
	                        {
	                            $("#h1l1BidderName_"+rowId).html((biddtl[12]!='null' && biddtl[12]!='')? biddtl[12]:MSG_NOTBIDDED);
	                        }
	                               
	                    }
	                    if($("#bidRank_"+rowId))
	                    {
	                    	 if(isBidder == 'true'){
								 if(isYankeeAuction == 1){	
									$("#bidRank_"+rowId).html('&nbsp;-&nbsp;');
								 }else{
									$("#bidRank_"+rowId).html(biddtl[9] != ''? biddtl[9] :MSG_NOTBIDDED);
								 }
	                    	 }else{
	                    		 $("#bidRank_"+rowId).html('&nbsp;-&nbsp;');
	                    	 }
	                    }
	                    if(biddtl[9] == '1')
	                    {
	                        $("#rowid_"+rId).attr("class","row-highlight");
	                    }
	                    else
	                    {
	                        $("#rowid_"+rId).removeAttr("class");
	                    }
	                    if($("#lastBidAmt_"+rowId))
	                    {
	                    	if(isBidder == 'true'){
	                    		$("#lastBidAmt_"+rowId).html(biddtl[10] != ''? biddtl[10] :MSG_NOTBIDDED);
	                    	}else{
	                    		$("#lastBidAmt_"+rowId).html('&nbsp;-&nbsp;');
	                    	}
	                    }
	                    $("#hidLastBidAmt_"+rowId).val(biddtl[10] != ''? (biddtl[10]).replace(new RegExp(",", 'g'),"") :(0).toFixed(acceptDecimalUpTo));
	                    $("#hidL1H1Amount_"+rowId).val(biddtl[8] != ''? (biddtl[8]).replace(new RegExp(",", 'g'),"") :(0).toFixed(acceptDecimalUpTo));
	                    calculateBidPerIncDec(rowId);
	                    if($("#incDecPer_"+rowId))
	                    {
	                        $("#incDecPer_"+rowId).html(biddtl[7]+"%");
	                    }
	                    if($("#incDecAmt_"+rowId))
	                    {
	                        $("#incDecAmt_"+rowId).html(biddtl[6]);
	                    }
	                        
	                    var nextBidAmt=0;
	                    var isFirstBid=0;
	                    var varlastbidamount=biddtl[10] != ''? (biddtl[10]).replace(new RegExp(",", 'g'),"") :0;
	                    var varincdecAmount=biddtl[6] != ''? (biddtl[6]).replace(new RegExp(",", 'g'),"") :0;
	                    var varstartPrice=biddtl[11] != ''? (biddtl[11]).replace(new RegExp(",", 'g'),"") :0;
	                    var varh1l1Price=biddtl[8] != ''? (biddtl[8]).replace(new RegExp(",", 'g'),"") :0;
	                    var totBidCapacity = 0;
						var remainingBidCapacity = 0;
						var newIncDecAmt = 0.00;
						var diffIncDecAmt = 0.00;
						if(auctionType == 2){      //Rank Auction
							if(varlastbidamount == 0){
								newIncDecAmt = (parseFloat(biddtl[11]) * parseFloat(biddtl[7])) / 100; 
							}else{
								newIncDecAmt = (parseFloat(varlastbidamount) * parseFloat(biddtl[7])) / 100;
							}
						}else{                //Standard auction
							if(varh1l1Price == 0){
								newIncDecAmt = (parseFloat(biddtl[11]) * parseFloat(biddtl[7])) / 100; 
							}else{
								newIncDecAmt = (parseFloat(varh1l1Price) * parseFloat(biddtl[7])) / 100;
							}
						}
						diffIncDecAmt = parseFloat(newIncDecAmt) - parseFloat(varincdecAmount);
						if(incDecType == 2){
							if(diffIncDecAmt != 0){
								if(acceptDecimalUpTo == 1){
									varincdecAmount = parseFloat(varincdecAmount) + 0.1;
								}else if(acceptDecimalUpTo == 2){
									varincdecAmount = parseFloat(varincdecAmount) + 0.01;
								}else if(acceptDecimalUpTo == 3){
									varincdecAmount = parseFloat(varincdecAmount) + 0.001;
								}else if(acceptDecimalUpTo == 4){
									varincdecAmount = parseFloat(varincdecAmount) + 0.0001;
								}else if(acceptDecimalUpTo == 5){
									varincdecAmount = parseFloat(varincdecAmount) + 0.00001;
								}
							}
						}
	                    if(auctionType == '1' && parseFloat(varh1l1Price,10) > 0.0)
	                    {
	                        nextBidAmt=parseFloat(varh1l1Price,10);
	                    }
	                    else if(auctionType == '2' && parseFloat(varlastbidamount,10) > 0.0)
	                    {
	                        nextBidAmt=parseFloat(varlastbidamount,10);
	                    }
	                    else if(parseFloat(varstartPrice,10) > 0.0)
	                    {
	                        nextBidAmt=parseFloat(varstartPrice,10);
	                        isFirstBid=1;
	                    }
	                    if(nextBidAmt > 0.0 && displayPriceBidBreakUp == '1')
	                    {
	                        if (eventTypeId == 1 && (isFirstBid == 0 || (isFirstBid == 1 && firstBidCond == 2)))
	                        {
	                            $('#divNextBid_'+rowId).show();
	                            if(isBidder == 'true'){
	                            	if(auctionResult == 2 && isDIYClient == 1){
	                            		$('.cell_nxtbidamt_'+rowId).val((nextBidAmt+parseFloat(varincdecAmount,10)).toFixed(acceptDecimalUpTo));	       
	                            		$('.cell_nxtbidamt_'+rowId).focus();
	                            		$('.cell_nxtbidamt_'+rowId).blur();
	                            	}else{
	                            		$('#netBidAmt_'+rowId).html((nextBidAmt+parseFloat(varincdecAmount,10)).toFixed(acceptDecimalUpTo));
	                            	}
	                            }else{
	                            	if(auctionResult == 2 && isDIYClient == 1){
	                            		$('.cell_nxtbidamt_'+rowId).val('&nbsp;-&nbsp;');	                            		
	                            	}else{
	                            		$('#netBidAmt_'+rowId).html('&nbsp;-&nbsp;');
	                            	}
	                            }
	                        }
	                        if(eventTypeId == 2 && (isFirstBid == 0 || (isFirstBid == 1 && firstBidCond == 2)))
	                        {
	                        	$('#divNextBid_'+rowId).show();
	                            if(isBidder == 'true'){
	                            	if(auctionResult == 2 && isDIYClient == 1){
	                            		$('.cell_nxtbidamt_'+rowId).val((nextBidAmt-parseFloat(varincdecAmount,10)).toFixed(acceptDecimalUpTo));
	                            		$('.cell_nxtbidamt_'+rowId).focus();
	                            		$('.cell_nxtbidamt_'+rowId).blur();
	                            	}else{
	                            		$('#netBidAmt_'+rowId).html((nextBidAmt-parseFloat(varincdecAmount,10)).toFixed(acceptDecimalUpTo));
	                            	}
	                            }else{
	                            	if(auctionResult == 2 && isDIYClient == 1){
	                            		$('.cell_nxtbidamt_'+rowId).val('&nbsp;-&nbsp;');
	                            	}else{
	                            		$('#netBidAmt_'+rowId).html('&nbsp;-&nbsp;');
	                            	}
	                            }
	                        }
	                        if (isFirstBid == 1 && firstBidCond == 1)
	                        {
	                            $('#divNextBid_'+rowId).show();
	                            if(isBidder == 'true'){
	                            	$('#netBidAmt_'+rowId).html(nextBidAmt.toFixed(acceptDecimalUpTo));
	                            }else{
	                            	$('#netBidAmt_'+rowId).html('&nbsp;-&nbsp;');
	                            }
	                        }
	                    }
	                    if(auctionResult == 2 && isDIYClient == 1){
	                    	$(".diy-h1L1Price_"+rowId).html(biddtl[8] != ''? biddtl[8]:' - ');
	                    	$(".diy-bidderRank_"+rowId).html(biddtl[9] != ''? biddtl[9]:' - ');
	                    }
						/* Added By Nirav Raval for Change Request #22430 for EMD balance Start*/
	                    if(isEmdReq == 1 && isBidCapacityReq == 1){
							$('#emdAmt_'+rowId).html(biddtl[16]);	
							$('#emdBal_'+rowId).html(biddtl[17]);	
							
							var emdAmt=biddtl[16] != ''? (biddtl[16]).replace(new RegExp(",", 'g'),"") :0;
							var emdBal=biddtl[17] != ''? (biddtl[17]).replace(new RegExp(",", 'g'),"") :0;
							
							totBidCapacity = (parseFloat(emdAmt) * parseFloat(biddingCapacity));
							remainingBidCapacity = (parseFloat(emdBal) * parseFloat(biddingCapacity));
							
							$('#totBidCapacity_'+rowId).html(totBidCapacity.toFixed(acceptDecimalUpTo));	
							$('#AvailableBidCapacity_'+rowId).html(remainingBidCapacity.toFixed(acceptDecimalUpTo));	
							
						}
	                    
	                   /* Start - Added By Nirav Raval for Project Task #23847 for Need to give provision to have check on minimum quantity required */
						if(auctionResult == 2 && isMinQtyCheckReq == 1){
							$('#minQty_'+rowId).html(biddtl[18]);								
						}
						/* End - Added By Nirav Raval for Project Task #23847 for Need to give provision to have check on minimum quantity required */
						//Project Task #26114						
						if(isBidPriceIncDecInTimesReq == 1){
							$('#bidPriceIncDecInTimes_'+rowId).html(biddtl[19]);
						}
						//End Project Task #26114
						
					}
	                /******* Setting Other bidder rank information *****/
					if(arrdtl[1] !=null && arrdtl[1]!='' && arrdtl[1]!='~~')
	                {
	                    otherbiddtllist = arrdtl[1].toString().split("<<");
	                    /*
	                        Other Bidder Detail Format:
	                        bidderId~companyName~bidAmount~BidCurrency~ExchangeRate~Rank~BidDateTime
	                        */
	                    var tr='';
	                        
	                    for(var k=0;k<otherbiddtllist.length;k++)
	                    {
	                        otherbiddtl= otherbiddtllist[k].toString().split("~");
	
	                        tr += "<tr "+((otherbiddtl[5] == '1')? "class='row-highlight'" : '')+ ">";
	                        tr += '<td width="50px" style="text-align:center;">'+otherbiddtl[5] +'</td>';
	                        tr += '<td width="200px" style="text-align:center;">'+otherbiddtl[1]+'</td>';
	                        tr += '<td width="100px" style="text-align:center;">'+ otherbiddtl[2] +'</td>';
	                        if(isICBAuction == 2)
	                        {
	                            tr += '<td width="230px" style="text-align:center;">'+otherbiddtl[3]+' / '+otherbiddtl[4]+'</td>';
	                        }
	                            
	                        tr += '<td width="150px" style="text-align:center;">'+otherbiddtl[6] +'</td>';
	                        tr += '</tr>';
	                    }
	                    if($('#otherBidDtl_'+rowId).length)
                    	{
	                    	$('#otherBidDtl_'+rowId).find("tr").remove();
		                    $('#otherBidDtl_'+rowId).html(tr);
		                }
	                    else
                    	{
	                    	
	                    	$('#tblOtherBidderRank').find("tr.row-highlight").remove();
	                    	$('#tblOtherBidderRank').find("td").remove();
	                    	$('#tblOtherBidderRank').append(tr);
	                    }
	                    $("#bidDetailrowid_"+rowId).show();
	                }
	                else
	                {
	                    if(isICBAuction == 2)
	                    {
	                        var tr='<td colspan=6>';
	                    }
	                    else
	                    {
	                        var tr='<td colspan=5>';
	                    }
	                       
	                    if(auctionResult == 1){
	                    	$('#otherBidDtl_0').find("td").remove();
		                    tr += "<br></br><center>"+MSG_NOBIDRECEIVED+"</center><br></br></td>";            
		                    $('#otherBidDtl_0').append(tr);
	                    }else{
	                    	if(auctionResult == 2 && isItemWiseTimeReq == 1 && configureTimeforItem == 2 && !$('#otherBidDtl_'+rowId).length){
	                    		$('#tblOtherBidderRank').find("td").remove();
			                    tr += "<br></br><center>"+MSG_NOBIDRECEIVED+"</center><br></br></td>";            
			                    $('#tblOtherBidderRank').append(tr);
	                    	}else{
	                    		
			                    if($('#otherBidDtl_'+rowId).length)
		                    	{
			                    	$('#otherBidDtl_'+rowId).find("td").remove();
			                    	 tr+="<center>"+MSG_NOBIDRECEIVED+"</center></td>"
				                    $('#otherBidDtl_'+rowId).append(tr);
		                    	}
			                    else
		                    	{
			                    	$('#tblOtherBidderRank_'+rowId).find("td").remove();
				                    tr += "<br></br><center>"+MSG_NOBIDRECEIVED+"</center><br></br></td>";            
				                    $('#tblOtherBidderRank_'+rowId).append(tr);
		                    	}
			                    
			                    
	                    	}
	                    }	                    
	                }
	            }	           
	          }
        }
    }
    catch(e)
    {
        alert(scriptErrorMsg+e.toString());
        return false;
    }
        
    if(auctionResult == 2  && isItemWiseTimeReq == 1 && runItemCount <= 0 && j != "null")
    {
    	if(j.indexOf("~^stNextItemTime~") > -1){
    		var rowId = j.split("~")[0];
        	$("itemRow_"+rowId).removeClass("display");
        	$("#itemRow_"+rowId).removeAttr("style");
    		$("#itemRow_"+rowId).addClass("display-none");
        	$("#expanderContent_"+rowId).removeClass("display");
    		$("#expanderContent_"+rowId).removeAttr("style");
    		$("#expanderContent_"+rowId).addClass("display-none");
    		$('#tblOtherBidderRank').find("td").remove();
            var tr = "<td colspan=6><br></br><center>"+MSG_NOBIDRECEIVED+"</center><br></br></td>";            
            $('#tblOtherBidderRank').append(tr);
        	var stNextItemMainArr = j.split("^");
        	var stNextItemSubArr = stNextItemMainArr[1].split("~");
        	
    		biddtl = stNextItemSubArr[1];
			srHr = biddtl.split(":")[0];
	        srMin = biddtl.split(":")[1];
	        srSec = biddtl.split(":")[2];
	        if(srSec.indexOf("`") != -1){
	        	srSec = srSec.substring(0,srSec.length-1);
	        }
        	$('#divItemYetStart').html(msg_auc_next_item_time+' '+srHr+' Hr - '+srMin+' Minutes - '+srSec+' Seconds');
        	$('#trItemYetStart').show();
    	}else{
    		if(typeof biddtl === 'undefined'){
    			 $('#trItemYetStart').hide();
    		 }else{    
				 if(configureTimeforItem ==2 && auctionMode == 2){
					 srHr = stNextItemSubArr[1].split(":")[0];
					 srMin = stNextItemSubArr[1].split(":")[1];
					 srSec = stNextItemSubArr[1].split(":")[2];
					 if(srSec.indexOf("`") != -1){
				        	srSec = srSec.substring(0,srSec.length-1);
				        }
					 $('#divItemYetStart').html(msg_auc_next_item_time+' '+srHr+' Hr - '+srMin+' Minutes - '+srSec+' Seconds');
				 }else{
					$('#divItemYetStart').html(msg_auc_items_start_soon);
				 }
    		 }
    	}
        if(userTypeId != USERTYPE_BIDDER)
        {
            $('#trRemarks').hide();
        }
    }
    else if(auctionResult == 2  && isItemWiseTimeReq == 1)
    {
        $('#trItemYetStart').hide();
        if(userTypeId != USERTYPE_BIDDER)
        {
            $('#trRemarks').show();
        }
    }
    if(j == "null"){
    	$('#tblOtherBidderRank').find("td").remove();
        var tr = "<td colspan=6><br></br><center>"+MSG_NOBIDRECEIVED+"</center><br></br></td>";            
        $('#tblOtherBidderRank').append(tr);
    }
}
   
/**
 * Method use for generate dynamic formula base on current render controlls.
 */
function generateFormula()
{
    var str='',finalStr='';
    var numbers=/^[0-9]*$/;
    for(var i=0;i<formularr.length;i++) 
    {
        str='',finalStr='';
        str=formularr[i];
        if(formularr[i].indexOf('Total') == -1 && formularr[i].indexOf('Word') == -1)
        {
            str=str.replace(/\+/g,'~+~');
            str=str.replace(/\-/g,'~-~');
            str=str.replace(/\*/g,'~*~');
            str=str.replace(/\//g,'~/~');
            str=str.replace(/\(/g,'~(~');
            str=str.replace(/\)/g,'~)~');
            var atemp=str.split("~");
            for(var j=0;j<atemp.length;j++) 
            {
                if($.trim(atemp[j]) != '')
                {
                    if(numbers.test(atemp[j]))
                    {
                        if(columnFillBy[atemp[j]-1] == FILLEDBY_BIDDER || columnFillBy[atemp[j]-1] == FILLEDBY_AUTO) // If fill by =auto or bidder?
                        {
                            finalStr +='parseFloat($("#txtcell_rowId_'+atemp[j]+'").val(),10)';
                        }
                        else  // If fill by proxy or buyer?
                        {
                            if(columnShowHide[atemp[j]-1] == 0) //If show_HIde= Hide
                            {
                                finalStr +='parseFloat(hideCellValue[rowId - 1]['+(atemp[j]-1)+'],10)';
                            }
                            else
                            {
                                finalStr +='parseFloat($("#txtcell_rowId_'+atemp[j]+'").html(),10)';
                            }
                                    
                        }
                    }
                            
                    else if(atemp[j].indexOf('N_')!=-1)
                    {
                        finalStr+=atemp[j].replace('N_','');
                    }
                    else
                    {
                        finalStr +=atemp[j];
                    }
                }
            }
        }
        else
        {
            str=str.replace(/\(/g,'~(~');
            str=str.replace(/\)/g,'~)~');
            atemp=str.split("~");
            for(var j=0;j<atemp.length;j++) 
            {
                if($.trim(atemp[j]) != '')
                {
                    if(numbers.test(atemp[j]))
                    {
                        finalStr +='parseFloat($("#txtcell_rowId_'+atemp[j]+'").val(),10)';
                    }
                    else
                    {
                        finalStr +=atemp[j];
                    }
                }
            }
        }
        formulaStr.push(finalStr);
    // alert(finalStr);
    }
        
}
    
/**
 * Method use for execute dynamic formula.
 */
function execForumula(rowId,fromulaindex)
{
    var tempFormula="";
    var tempResult="";
    var tempWordResult="";
    //alert("ddd"+fromulaindex);
    for(var i=0;i<formulaStr.length ;i++)
    {
    	if(fromulaindex.indexOf("~"+i+"~")!= -1)
        {
            tempFormula=formulaStr[i].replace(/rowId/g,rowId);
            if(formulaStr[i].indexOf('WORD') != -1)
            {   
                //alert("tempFormula="+tempFormula);
                tempFormula=tempFormula.replace("WORD(","");
                tempFormula=tempFormula.substr(0,tempFormula.lastIndexOf(")"));
                //alert(AmountInWord(eval(tempFormula)))
                if(amountConvertion == '0')
                {
                    tempResult = IndianConvertionAmountInWord(eval(tempFormula));
                }
                else
                {
                    tempResult= InternationConvertionAmountInWord(eval(tempFormula));
                }
                if($("#lbl_"+rowId+"_"+formulacolarr[i]).html()!=undefined)
                {
                    $("#lbl_"+rowId+"_"+formulacolarr[i]).text(tempResult);
                }
                if($("#txtacell_"+rowId+"_"+formulacolarr[i]).val()!=undefined)
                {
                    $("#txtacell_"+rowId+"_"+formulacolarr[i]).val(tempResult);
                }
                if($("#txtcell_"+rowId+"_"+formulacolarr[i]).val()!=undefined)
                {
                    $("#txtcell_"+rowId+"_"+formulacolarr[i]).val(tempResult);
                }
            }
            else if(formulaStr[i].indexOf('TOTAL')!= -1)
            {
                var total=0;
                for(var j=1;j<=totalRows-1;j++)
                {
                    if($("#txtcell_"+j+"_"+formulacolarr[i]).val() != '')
                    {
                        total += eval($("#txtcell_"+j+"_"+formulacolarr[i]).val());
                    }
                        
                }
                tempResult=(Math.round(total*Math.pow(10,acceptDecimalUpTo))/Math.pow(10,acceptDecimalUpTo)).toFixed(acceptDecimalUpTo);
                    
                $("#txtcell_0_"+formulacolarr[i]).val(tempResult);
                if(amountConvertion == '0')
                {
                    tempWordResult=IndianConvertionAmountInWord(eval(tempResult));
                }
                else
                {
                    tempWordResult=InternationConvertionAmountInWord(eval(tempResult));
                }
                $("#divword_0_"+formulacolarr[i]).html('( '+tempWordResult+')');
                for(var k=0;k<formulaStr.length ;k++)
                {
                    // alert(formulaStr[k]+"=="+('WORD('+'parseFloat($("#txtcell_rowId_'+formulacolarr[i]+'").val(),10)'+')'));
                    if($("#lbltotalword_0_"+formulacolarr[k]) && formulaStr[k].indexOf('WORD('+'parseFloat($("#txtcell_rowId_'+formulacolarr[i]+'").val(),10)'+')')!= -1)
                    {
                        $("#lbltotalword_0_"+formulacolarr[k]).html(tempWordResult);
                    }
                }
            }
            else 
            {
                //alert("["+formulacolarr[i]+"]"+tempFormula+"="+eval(tempFormula));
                if(!isNaN(eval(tempFormula)))
                {
                	if($("#txtcell_"+rowId+"_"+formulacolarr[i]).val()!=Math.round(eval(tempFormula)*Math.pow(10,acceptDecimalUpTo))/Math.pow(10,acceptDecimalUpTo))
                		$("#txtcell_"+rowId+"_"+formulacolarr[i]).val((Math.round(eval(tempFormula)*Math.pow(10,acceptDecimalUpTo))/Math.pow(10,acceptDecimalUpTo))).change();
                }
                else
                {
                    $("#txtcell_"+rowId+"_"+formulacolarr[i]).val(0);
                }
            }
        }
    }
}

   
/**
 * Method use to get Marquee Text using ajax call.
 */  
function getAjaxMarqueeDetail()
{
    $.ajax({
        type: "GET",
        url: ajaxMaqueeDetailPath,
        dataType: 'text',
        success: function(ajaxResponse)
        {
            //alert(j);
            try
            {
                if(ajaxResponse!=null && (ajaxResponse.indexOf("SessionExpired")!= -1))
                {
                    alert(sessionexpired);
                    return false;
                }
                else
                {
                    ajaxResponse = $.trim(ajaxResponse);
                    j=ajaxResponse;
                    var rejMaq=null;
                    if(ajaxResponse.indexOf("|||") != -1) // Reject bid message exist?
                    {
                        var arrMRDetail = ajaxResponse.split("|||");
                        j=arrMRDetail[0];
                        rejMaq=arrMRDetail[1];
                    }
                    var marqueeStr='<font>';
                    auctionStatus='0';
                    if(j!=null && $.trim(j.toString())!='')
                    {
                        var arrMaquee=j.split("~");
                        for(var i=0;i<arrMaquee.length;i++)
                        {
                            var arr=arrMaquee[i].split("`");
                            if(arr[1]!=null && (arr[1] == '1' || arr[1] == '2' || arr[1] == '4'))
                            {
                                auctionStatus=arr[1];
                            }
                            marqueeStr=marqueeStr+" "+arr[0];
                        }
                    }
                    marqueeStr+="</font> ";
//                    alert(j.toString());
                    
                    if(j!=null && $.trim(j.toString())!=''){
                    	$('#marqueeDiv').show();
                    }else{
                    	$('#marqueeDiv').hide();
                    }
                    
                    
                    $('#dynamicMarqueeText').html(marqueeStr);
                    //  alert(auctionStatus);
                    if(auctionStatus != 0)
                    {
                        if(auctionStatus == AUCTION_PAUSE)
                        {
                            $('span[id^=remainTimer_]').each(function()
                            {
                                $(this).html("<font color='red'><b>"+MSG_AUCTIONPAUSE+"</b></font>");
                            });
                        }
                        else if(auctionStatus == AUCTION_STOP)
                        {
                            $('span[id^=remainTimer_]').each(function()
                            {
                                $(this).html("<font color='red'><b>"+MSG_AUCTIONSTOP+"</b></font>");
                            });
                        }
                        else if(auctionStatus == AUCTION_CANCEL)
                        {
                            $('span[id^=remainTimer_]').each(function()
                            {
                                $(this).html("<font color='red'><b>"+MSG_AUCTIONCANCEL+"</b></font>");
                            });
                        }
                                 
                    }
                        
                    /**** Start : reject bid marquee code *****/
                    $('marquee[id^=dynamicMarqueeText_]').each(function()
                    {
                        $(this).html("");
                    });
                    $('tr[id^=tr_marq_]').each(function()
                    {
                        $(this).hide();
                    });
                    if(rejMaq!=null && $.trim(rejMaq.toString())!='')
                    {
                        arrMaquee=rejMaq.split("`");
                            
                        for(i=0;i<arrMaquee.length;i++)
                        {
                            arr=arrMaquee[i].split("~");
                            $('#tr_marq_'+arr[0]).show();
                            if(arr[0] != null && arr[0] !=''){
                    			$("#rejMarqueeDiv_"+arr[0]).show();
		                    }else{        
                                $("#rejMarqueeDiv_"+arr[0]).hide();
                            }
                            
                            if(auctionResult == '2' && isDIYClient == '1'){
                            	$('#dynamicMarqueeText_'+arr[0]).html(msg_auc_view_rejectbid_remark_1+" : <a href='javascript:void(0);' onclick=\"openpopRejectForDIY('"+arr[0]+"','"+arr[1]+"');\" style=\"cursor:hand; cursor:pointer;\"> "+msg_auc_view_rejectbid_remark_2+"</a>"+msg_auc_view_rejectbid_remark_3);
                            }else{
                            	$('#dynamicMarqueeText_'+arr[0]).html(msg_auc_view_rejectbid_remark_1+" : <a href='javascript:void(0);' onclick=\"openpopReject('"+arr[0]+"','"+arr[1]+"');\" style=\"cursor:hand; cursor:pointer;\"> "+msg_auc_view_rejectbid_remark_2+"</a>"+msg_auc_view_rejectbid_remark_3);
                            }
                        }
                    //alert(rejMaq);
                    }
                /**** END : reject bid marquee code *****/
                }
                
            }
            catch(e)
            {
                alert(scriptErrorMsg+e.toString());
                return false;
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(ajaxErrorMsg);
            return false;
        }
    });
}
    

function getSignData(bidDetailStr)
{
    //alert("ddd"+publicKey);
    var signData=null;
    var certiAlias=getCertiAlias(publicKey);
    sealock.selectCertificate(certiAlias);
    sealock.setData(bidDetailStr);
    try
    {
        try
        {
            signData = sealock.getSignature();
        }
        catch(ex)
        {
            alert("There is an error " + e.messsage);
        }
    }
    catch(e)
    {
        alert("There is an error " + e.messsage);
    }   
    return signData;
}

function refreshPage(aucImDtAr,rId,flag) {
	if(parseInt(aucImDtAr[1]) == 1){
		  $.ajax({
        type: "GET",
        url: ajaxBidDetailPath,
        dataType: 'text',
        data: { 
            hdAcceptDecimalUpTo: $('#hdAcceptDecimalUpTo').val()
        },
        success: function(j)
        { 
            try
            {
                if(j!=null && (j.indexOf("SessionExpired")!= -1))
                {
                    alert(sessionexpired);
                    return false;
                }
                else
                {  
				 location.reload();	
                }  
            }
            catch(e)
            {
                alert(scriptErrorMsg+e.toString());
                return false;
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
            alert(ajaxErrorMsg);
            return false;
        }
    });
		
	}
}
  
/**
     * Method use for 
     */        
function submitEnter(txtControl,e,rId)
{
    if(e.keyCode == 13)// IF Enter key pressed?
    {
        if($(txtControl).blur())
        {
            if(auctionResult == 2)
            {
                $("#bid_"+rId).click();
            }
            else
            {
                $("#bid_0").click();
            }
        }
    }
}
  
/**
   * Method use for calculate increment/decrement percentage of bid with respect to it's last bid amount
   */
function calculateBidPerIncDec(rowId)
{
	if($('#txtcell_'+rowId+'_'+govColumnNo))
    {
        var bidAmount=parseFloat($('#txtcell_'+rowId+'_'+govColumnNo).val(),10);
        var lastBidAmount;
        if(bidDiff==bidDiffSpecClientId){
        	lastBidAmount=parseFloat($('#hidL1H1Amount_'+rowId).val(),10);
        }else{
        	lastBidAmount=parseFloat($('#hidLastBidAmt_'+rowId).val(),10);
        }
        var incDecPer=0.0;
        if(eventTypeId == 1)//forward
        {
            incDecPer=(((bidAmount - lastBidAmount) * 100)/lastBidAmount).toFixed(acceptDecimalUpTo);
        }
        else
        {
            incDecPer=(((lastBidAmount - bidAmount) * 100)/lastBidAmount).toFixed(acceptDecimalUpTo);
        }
    }
        
    if(lastBidAmount > 0.0)
    {
        $('#bidAmtIncDec_'+rowId).html(incDecPer);
    }
    else
    {
        $('#bidAmtIncDec_'+rowId).html('');
    }
}
function checkForRevise(ele,endLimit,rowId) {
var eleValue = $(ele).val();
var eLimit = endLimit;
var rId = rowId;
var flag = $('#txtAutobidFlag_'+rId).val();
	if(flag == '2'){
		if(eleValue == eLimit) {
			$('#txtReviseSubmitCheck_'+rId).val(false);
		} else if(eleValue == "") {
			$('#txtReviseSubmitCheck_'+rId).val(false);
		}else { 
			$('#txtReviseSubmitCheck_'+rId).val(true);
		}
	} else {
		if(eleValue != ""){
			$('#txtReviseSubmitCheck_'+rId).val(true);
		} else {
			$('#txtReviseSubmitCheck_'+rId).val(false);
		}
		
	}
}

function roundFunction(rnd){
         return (Math.round(eval(rnd)*Math.pow(10,5))/Math.pow(10,5));
     }

function makeMod(varA, varB){
         varA = roundFunction(varA*100000);
         varB = roundFunction(varB*100000);
         var toReturn = (varA%varB)/100000;
         return toReturn;
     }