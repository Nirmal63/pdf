/* 
 *@Author : TaherT 
 */
var formulaStack = new Array();
var formulaDispStack = new Array();
var columnFormula = new Array();
var openBraceCnt = 0;
var closeBraceCnt = 0;
var isFormulaTested = false;
var addCellInfo;
function removeFormulaTable() {
    $('.formulaTable').each(function() {
        if ($('#' + $(this).attr('id') + ' tr').length == 2) {
            $(this).remove();
        }
    });
}
function validateCForm() {
    var tbool = true;
    if (!isFormulaTested) {
        tbool = false;
        jAlert(MSG_AUC_TESTFORMULA, MSG_AUC_FORMULALERT, function(RetVal) {
        });
    } else {
        $('#txtCellInfo').val(addCellInfo);
        if($('#txtFormulaMsg').val()!=''){
            $('#txtFormulaMsg').val($('#txtFormulaMsg').val().replace(/,/g,'&#44;'));
        }
        dispFormula();
    }
//    return false;
    return disableBtn(tbool);
}
function showHideTable(flag) {
    for (var t = 0; t < tableIds.length; t++) {
        if (flag) {
            $('#' + tableIds[t] + ' tr:gt(2)').hide();
            $('#' + tableIds[t] + ' tr:eq(2) td').each(function(){
                $(this).find('label[tolbl="1"]').hide();
                $(this).find('input[tooff="1"]').show();
            });
        } else {
            $('#' + tableIds[t] + ' tr:gt(2)').show();
            $('#' + tableIds[t] + ' tr:eq(2) td').each(function(){
                $(this).find('label[tolbl="1"]').show();
                $(this).find('input[tooff="1"]').hide();
            });
        }
    }
}
function changeFType(ftype) {
    $('.errtxtFormulaMsg').remove();
    var cmbValue = $(ftype).val();
    clearAll();
    if (cmbValue == '1') {
        showHideTable(false);
        $('#valbtns').hide();
        $('#sp_valmsg').hide();
        $('#txtFormulaMsg').attr('disabled', true);
    } else if (cmbValue == '2') {
        showHideTable(false);
        $('#valbtns').show();
        $('#sp_valmsg').show();
        $('#txtFormulaMsg').removeAttr('disabled');
    } else if (cmbValue == '3') {
        showHideTable(true);
        $('#valbtns').show();
        $('#sp_valmsg').show();
        $('#txtFormulaMsg').removeAttr('disabled');
    }
}
function testformula() {
    var tbool = valOnSubmit();
    $('#txtaFormFormula').val(reverseReplaceQuotes($('#txtaFormFormula').val()));
    if (tbool) {
        $('.err').remove();
        var isFormulaOk = true;
        var formulaValStack = new Array();
        columnFormula.splice(0, columnFormula.length);
        for (var f = 2; f < formulaStack.length; f++) {
            if (!isNaN(formulaStack[f])) {
                var fcolumnNo = $('input[cellid="' + formulaStack[f] + '"]').attr('id');
                if (fcolumnNo == undefined) {
                    fcolumnNo = $('select[cellid="' + formulaStack[f] + '"]').attr('id');
                }
                columnFormula.push(fcolumnNo.split("_")[1]);
                var cellvalue = $('input[cellid="' + formulaStack[f] + '"]').val();
                if (cellvalue == undefined) {
                    cellvalue = $('select[cellid="' + formulaStack[f] + '"]').val();
                }
                if ($.trim(cellvalue) == '') {
                    jAlert(MSG_AUC_FILLVALTEST, MSG_AUC_FORMULALERT, function(RetVal) {
                    });
                    isFormulaOk = false;
                    break;
                } else {
                    var NUMERICWITHDECIMAL = "^\\d*[\\.]?\\d{1,"+decimalUpto+"}$";
                    var decimalRegex = new RegExp(NUMERICWITHDECIMAL);
                    if (!decimalRegex.test(cellvalue)) {
                        jAlert(MSG_TENDER_ALLOWPOSITIVE, MSG_AUC_FORMULALERT, function(RetVal) {
                        });
                        isFormulaOk = false;
                        break;
                    } else {
                        formulaValStack.push(cellvalue);
                    }
                }
            } else {
                formulaValStack.push(formulaStack[f].replace(/N_/g, ''));
                columnFormula.push(formulaStack[f]);
            }
        }
        if (isFormulaOk && formulaStack.length > 2) {
            try {
                var evalValue = eval(formulaValStack.toString().replace(/,/g, ''));
                if ($('#selFormulaType').val() == '1') {
                    $('input[cellid="' + formulaStack[0] + '"]').val(evalValue.toFixed(decimalUpto));
                } else {
                    isFormulaOk = (evalValue == true) || (evalValue == false);
                    if (!isFormulaOk) {
                        jAlert(MSG_AUC_PROPERFORMULA, MSG_AUC_FORMULALERT, function(RetVal) {
                        });
                    }
                    if (!evalValue) {
                        $('input[cellid="' + formulaStack[0] + '"]').parent().append('<div class="err" style="color:red;">' + $('#txtFormulaMsg').val() + '</div>');
                        $('select[cellid="' + formulaStack[0] + '"]').parent().append('<div class="err" style="color:red;">' + $('#txtFormulaMsg').val() + '</div>');
                    }
                }
            } catch (e) {
                isFormulaOk = false;
                jAlert(MSG_AUC_PROPERFORMULA, MSG_AUC_FORMULALERT, function(RetVal) {
                });
            }
        }
        isFormulaTested = isFormulaOk;
    }
}

function UndoChange() {
    if (formulaStack[formulaStack.length - 1] == '(') {
        openBraceCnt--;
    }
    if (formulaStack[formulaStack.length - 1] == ')') {
        closeBraceCnt--;
    }
    if (formulaStack[formulaStack.length - 1] == '=') {
        formulaStack.splice(formulaStack.length - 1, 1);
    }
    formulaStack.splice(formulaStack.length - 1, 1);
    if (formulaDispStack[formulaDispStack.length - 1] == '=') {
        formulaDispStack.splice(formulaDispStack.length - 1, 1);
    }
    formulaDispStack.splice(formulaDispStack.length - 1, 1);
    dispFormula();
}
function clearAll() {
    formulaStack = new Array();
    formulaDispStack = new Array();
    openBraceCnt = 0;
    closeBraceCnt = 0;
    dispFormula();
}

function addExpression(operator) {
    var operatorVal = $(operator).val();
    var prevStack = formulaStack[formulaStack.length - 1];
    if (operatorVal == '(' && (formulaStack.length == 2 || (formulaStack.length > 2 && isNaN(prevStack) && prevStack != '(' && prevStack != ')')) && prevStack.indexOf('N_') == -1) {
        formulaStack.push(operatorVal);
        formulaDispStack.push(operatorVal);
        openBraceCnt++;
    }
    if (operatorVal == ')' && ((formulaStack.length > 2 && openBraceCnt - closeBraceCnt > 0 && (prevStack.indexOf('N_') != -1 || !isNaN(prevStack)) && prevStack != '(' && prevStack != ')'))) {
        formulaStack.push(operatorVal);
        formulaDispStack.push(operatorVal);
        closeBraceCnt++;
    }
    if (operatorVal == 'Number' && (formulaStack.length == 2 || (formulaStack.length > 2 && isNaN(prevStack) && prevStack.indexOf('N_') == -1) && prevStack != '(' && prevStack != ')')) {
        var answer = prompt("Enter Number", "");
        formulaStack.push("N_" + answer);
        formulaDispStack.push(answer);
    }
    if (formulaStack.length > 2 && operatorVal != ')' && operatorVal != '(' && operatorVal != 'Number') {
        if (prevStack == ')' || prevStack.indexOf('N_') != -1 || !isNaN(formulaStack[formulaStack.length - 1])) {
            formulaStack.push(operatorVal);
            formulaDispStack.push(operatorVal);
        }
    }
    dispFormula();
}
function makeFormula(comp) {    
    if (formulaStack.length == 0 ) {
        if($(comp).attr('tooff') == undefined || $(comp).attr('tooff') == ''){
            if (!($(comp).parent().is('.biddercell') && $('#selFormulaType').val() == '1')) {
                if ($('#selFormulaType').val() != '1' || copyCellId.length==0 || (',' + copyCellId.toString() + ',').indexOf(',' + $(comp).attr('cellid') + ',') == -1) {
                    formulaStack.push($(comp).attr('cellid'));
                    formulaStack.push('=');
                    formulaDispStack.push($(comp).attr('nametodisplay'));
                    formulaDispStack.push('=');
                    addCellInfo = $(comp).attr('id');
                } else {
                    jAlert(MSG_COPY_FORMULA_EXIST, MSG_AUC_FORMULALERT, function(RetVal) {
                    });
                }
            } else {
                jAlert(MSG_COPY_FORMULA_BYBIDDER, MSG_AUC_FORMULALERT, function(RetVal) {
                });
            }
        }
    } else if (formulaStack.length != 0) {
        if ($('#selFormulaType').val() == '3' && addCellInfo.split('_')[0] != $(comp).attr('id').split('_')[0]) {
            jAlert(MSG_VALIDATE_COLUMN_SAMETABLE, MSG_AUC_FORMULALERT, function(RetVal) {
            });
        } else {
            if (formulaStack[formulaStack.length - 1] != ')' && formulaStack[formulaStack.length - 1].indexOf('N_') == -1 && isNaN(formulaStack[formulaStack.length - 1])) {
                formulaDispStack.push($(comp).attr('nametodisplay'));
                formulaStack.push($(comp).attr('cellid'));
            }
        }
    }    
    dispFormula();
}
function dispFormula() {
    $('#txtaFormFormula').val(formulaDispStack.toString().replace(/,/g, ''));
    if ($('#selFormulaType').val() == '3') {
        $('#skpFormula').val(columnFormula.toString().replace(/,/g, ''));
    } else {
        $('#skpFormula').val(formulaStack.toString().replace(/,/g, ''));
    }
    isFormulaTested = false;
}