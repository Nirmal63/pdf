var mformatArr = new Array();
var jsonObj = new Array();
var jsonData = new Array();
var proxyData = new Array();
var proxyValue = new Array();
var tabcells = new Array();
var cellValidated = new Array();
var pagination;
var userData = new Array();
var filledByArr = new Array();
var tableWiseNotGenRow = new Array();
var isPriceBid=0;
var isBidder=false;
var ruleArr = new Array();
var itemSelectionList = new Object();
var activeItemList = new Object();
var mappedBidderRowsList = new Object();
function setBidData(index, tableId, bidpkey, bidpkey2,ismasterbid) { 
	//alert("setBidDate is called....");
	var errorCnt = 0;
    var bidderData = new Array();
    var bidArr = jsonData[index];    
    if(bidArr!=null){
    for (var cnt = 1; cnt < bidArr.length; cnt++) {
        addBidTable(tableId);
    }
    for (var cnt = 0; cnt < bidArr.length; cnt++) {
        var plainJson = '';
        if(ismasterbid || JSisBidSavedInDraft =='true'){
            plainJson = bidArr[cnt];
        } else{
            plainJson = decryptData(((bidpkey=='' && bidpkey2=='') || encryptionReq==0) ? bidArr[cnt] : reverseReplaceJunk(bidArr[cnt]), bidpkey, bidpkey2);
        }
        if (plainJson == 'nocertificate') {
            errorCnt--;
            break;
        } else if (plainJson != '') {
	
		
			var newJSON1 ="";
				
				
				try
				{
					newJSON1= plainJson.replace(/"/g, '\'');
				console.log("Step-1 ==>"+newJSON1);
				newJSON1 = newJSON1.replaceAll("{'", '{\"');
				console.log("Step-2 ==>"+newJSON1);
				newJSON1 = newJSON1.replaceAll("'}", '\"}');
				console.log("Step-2 ==>"+newJSON1);
				newJSON1 = newJSON1.replaceAll("':'", '\":\"');
				console.log("Step-3 ==>"+newJSON1);
				newJSON1 = newJSON1.replaceAll("\t", '');
				newJSON1 = newJSON1.replaceAll("\n", '');
				newJSON1 = newJSON1.replaceAll("\r", '');
				
				console.log(jQuery.parseJSON( newJSON1));
				}catch(e)
				{
					console.log(e);
				}	
            var jsonBid = jQuery.parseJSON(newJSON1);
            $.each(jsonBid, function() {
                $.each(this, function(t, s) {
                	var comboAboveBelowReg = /.*###.*###/g;
                	if( comboAboveBelowReg.test(s) ){
	                	s=s.replace(/###.*###/,"");
                	}
                	bidderData[t.toString().split('_')[1]]=s;                    
                    $('textarea[cellid="' + t.toString().split('_')[0] + '"][position="' + cnt + '"]').val(htmlReverseReplaceQuotes(reverseReplaceQuotes(s)));
                    $('input[cellid="' + t.toString().split('_')[0] + '"][position="' + cnt + '"]').val(htmlReverseReplaceQuotes(reverseReplaceQuotes(s)));
                    var selComboElement = $('select[cellid="' + t.toString().split('_')[0] + '"][position="' + cnt + '"]');
                    selComboElement.val((selComboElement.attr('multiple')!=undefined) ? s.split(',') : (s.indexOf('@@')==-1 ? s : s.split('@@')[0]));                    
                    if(s.indexOf('@@')!=-1){
                        $('textarea[cellid="'+selComboElement.attr('cellid')+'"][position="'+cnt+'"]').remove();
                        selComboElement.parent().append('<textarea   position="'+cnt+'" cellid="' + selComboElement.attr("cellid") + '" name="' + selComboElement.attr("name") + '" id="' + selComboElement.attr("id") + '" rowid="' + selComboElement.attr("rowid") + '" colid="' + selComboElement.attr("colid") + '">'+htmlReverseReplaceQuotes(reverseReplaceQuotes(s.split('@@')[1]))+'</textarea>');
                    }else{
                        if(selComboElement.html()!=undefined){
                            $('textarea[cellid="'+selComboElement.attr('cellid')+'"][position="'+cnt+'"]').remove();
                        }
                    }
                    $('input[cellidno="' + t.toString().split('_')[0] + '_' + t.toString().split('_')[1] + '"]').val(s);
                    $('label[cellidno="' + t.toString().split('_')[0] + '_' + t.toString().split('_')[1] + '"]').html(s);
                });
            });
            userData.push(bidderData);
        } else {
            errorCnt++;
            break;
        }
    }
    }
    else if(bidArr==null){
    	errorCnt=-1;
    }
    return errorCnt;
}

function setBidDataLabel(index, tableId, bidpkey, bidpkey2) {
	//alert("setBidDataLabel..");
    var errorCnt = 0;
    
    var bidArr = jsonData[index];
    for (var cnt = 1; cnt < bidArr.length; cnt++) {
        addBidTable(tableId);
    }
    for (var cnt = 0; cnt < bidArr.length; cnt++) {
		var plainJson = '';
		if(JSisBidSavedInDraft =='true'){
			plainJson = bidArr[cnt];
		} else {
        	plainJson = decryptData(((bidpkey=='' && bidpkey2=='') || encryptionReq==0) ? bidArr[cnt] : reverseReplaceJunk(bidArr[cnt]), bidpkey, bidpkey2);
       	}

        if (plainJson == 'nocertificate') {
            errorCnt--;
            break;
        } else if (plainJson != '') {
	console.log( ' dsdfsdf  '+replaceDoubleQuotes(htmlReplaceQuotes(plainJson)));
	
	var newJSON ="";
	
	
	try
	{
		newJSON= plainJson.replace(/"/g, '\'');
	console.log("Step-1 ==>"+newJSON);
	newJSON = newJSON.replaceAll("{'", '{\"');
	console.log("Step-2 ==>"+newJSON);
	newJSON = newJSON.replaceAll("'}", '\"}');
	console.log("Step-2 ==>"+newJSON);
	newJSON = newJSON.replaceAll("':'", '\":\"');
	console.log("Step-3 ==>"+newJSON);
	newJSON = newJSON.replaceAll("\t", '');
	newJSON = newJSON.replaceAll("\n", '');
	newJSON = newJSON.replaceAll("\r", '');
	console.log(jQuery.parseJSON( newJSON));
	}catch(e)
	{
		console.log(e);
	}
	
            var jsonBid = jQuery.parseJSON(newJSON);
            $.each(jsonBid, function() {
                $.each(this, function(t, s) {
                	//start Bug Id 24474 and 25280
                	var comboAboveBelowReg = /.*###.*###/g;
                	if( comboAboveBelowReg.test(s) ){ 
                		var comboAboveBelowReg_comment = /.*@@/g;
                		if(comboAboveBelowReg_comment.test(s)){
                			s=s.replace(/###.*###/,"");
                		}else{
                			var matchValue=s.match("###(.*)###");
    	                	s=matchValue[1];
                		}
                	}//end Bug Id 24474 and 25280
                	//alert(htmlReverseReplaceQuotes(reverseReplaceQuotes(s)));
                	s = htmlReverseReplaceQuotes(reverseReplaceQuotes(s));
                    $('a[cellid="' + t.toString().split('_')[0] + '"][position="' + cnt + '"]').remove();
                    $('textarea[cellid="' + t.toString().split('_')[0] + '"][position="' + cnt + '"]').parent().append(s);
                    $('textarea[cellid="' + t.toString().split('_')[0] + '"][position="' + cnt + '"]').remove();
                    $('input[cellid="' + t.toString().split('_')[0] + '"][position="' + cnt + '"]').parent().append(s);
                    $('input[cellid="' + t.toString().split('_')[0] + '"][position="' + cnt + '"]').remove();
                    $('select[cellid="' + t.toString().split('_')[0] + '"][position="' + cnt + '"]').parent().append(s.indexOf('@@')==-1 ? s : s.replace('@@',' | '));
                    $('select[cellid="' + t.toString().split('_')[0] + '"][position="' + cnt + '"]').remove();
                    $('input[cellidno="' + t.toString().split('_')[0] + '_' + t.toString().split('_')[1] + '"]').parent().append(s);
                    $('input[cellidno="' + t.toString().split('_')[0] + '_' + t.toString().split('_')[1] + '"]').remove();
                    $('label[cellidno="' + t.toString().split('_')[0] + '_' + t.toString().split('_')[1] + '"]').parent().append(s);
                    $('label[cellidno="' + t.toString().split('_')[0] + '_' + t.toString().split('_')[1] + '"]').remove();
                });
            });
        } else {
            errorCnt++;
            break;
        }
    }
    /*$("input[type='hidden']").each(function(){ //Bug Id #37053
    	var name = $(this).attr('name'); 
    	if(name == 'textvalue'){
    		var html = '<input type="text"  readonly="readonly"/>';
    	}
  	  $(this).after(html).remove(); // add new, then remove original input
  	});
    $("select").each(function(){ //Bug Id #37053
    	var name = $(this).attr('name'); 
    	var html = '<input type="text"  readonly="readonly"/>';    	
  	  $(this).after(html).remove(); // add new, then remove original input
  	});*/
    return errorCnt;
}
function setFormTableData(index) {
	//alert('Test df');
    var mformat = new Array();
    var myarray = new Array();
    if( jsonObj[index]!=null){
    	var jsonData = jsonObj[index].replace('\r\n','');
    		jsonData = jsonObj[index].replace('\t','');
    		console.log(reverseReplaceLineBreaks(jsonData).replace(/(\r\n|\n|\r)/gm,""));
    }
    var newJSON2 ="";
	
	
	try
	{
		newJSON2= jsonObj[index].replace(/"/g, '\'');
	//console.log("Step-1 ==>"+newJSON2);
	newJSON2 = newJSON2.replaceAll("{'", '{\"');
	//console.log("Step-2 ==>"+newJSON2);
	newJSON2 = newJSON2.replaceAll("'}", '\"}');
	//console.log("Step-2 ==>"+newJSON2);
	newJSON2 = newJSON2.replaceAll("':'", '\":\"');
	//console.log("Step-3 ==>"+newJSON2);
	newJSON2 = newJSON2.replaceAll("\t", '');
	newJSON2 = newJSON2.replaceAll("\n", '');
	newJSON2 = newJSON2.replaceAll("\r", '');
	console.log(jQuery.parseJSON( newJSON2));
	}catch(e)
	{
		console.log(e);
	}
	
    //var jsonData = htmlReplaceQuotes(replaceQuotes(htmlTabReplaceQuotes(jsonObj[index])));
  //  alert(jsonData);
    var json = jQuery.parseJSON(newJSON2);
    $.each(json, function() {                    
        $.each(this, function(k, v) {
            var key = k.toString().split("_");
            var colCnt = key[1];
            var rowCnt = key[2];            
            if (myarray[rowCnt] == undefined) {
                myarray[rowCnt] = new Array(colCnt);
            }
            myarray[rowCnt][colCnt - 1] = k + '@@$$' + v;
//                        alert(myarray[rowCnt][colCnt - 1]);
        });
    });     
    for (var tf = 0; tf < myarray.length; tf++) {
        if (myarray[tf] != undefined) {
            mformat.push(myarray[tf]);
        }
    }
//                alert('aa:: ' + mformat);
    mformatArr[index] = mformat;
}
function getFilledByArr(index){
    var filledBy = new Array();
//    console.log(filledByArr[index]);
    for(var cnt=0;cnt<filledByArr[index].length;cnt++){
        var fby = filledByArr[index][cnt].split("@@");
//    for(var fill in filledByArr[index]){
//        var fby = filledByArr[fill].split("@@");
        filledBy[fby[0]] = fby[1];
    }
    return filledBy;
} 
function formulaToArr(compVal) {
    compVal = compVal.replace(/_/g,'');
    var allc = new Array();
    var isnum = false;
    var isinput = false;
    for (var c = 0; c < compVal.length; c++) {
        var cc = compVal[c];
        if (cc != 'N') {
            if (isNaN(cc) && cc != '.') {
                allc.push(cc);
                isnum = false;
                isinput = false;
            } else {
                if (isnum) {
                        allc[allc.length - 1] = allc[allc.length - 1] + cc;
                } else {
                    if(isinput){
                        allc[allc.length - 1] = allc[allc.length - 1] + cc;                        
                    }else{
                        allc.push(cc);
                    }
                }
                isnum = true;
            }
        }else{
            allc.push('N');
            isinput=true; 
        }
    }
    return allc;
}

var strFormula = new Array();
var specialFormula = new Array();
var valFormula = new Array();
var valCellFormula = new Array();
function calvalidData(comp, datatype, index) {
    var compId = $(comp).attr("id");
    var crowId = $(comp).attr("rowId");
    var compVal = $.trim($(comp).val());
    $(comp).val(compVal);
    var position = $(comp).attr('position');
    var fromTableId = $(comp).attr('id').split('_')[0];
//    $('.errclass').remove();
//if($(comp).html().indexOf('</option>')!=-1 && ($(comp).html().indexOf('comments="0"')!=-1 || $(comp).html().indexOf('comments="1"')!=-1)){
//}
    var isIE8Browser=false;
 	if($.browser.msie){
        var userAgentHead = $.browser.version;
        userAgentHead = userAgentHead.substring(0,userAgentHead.indexOf('.'));
        versionHead = userAgentHead;
         if(versionHead == 8){
        	isIE8Browser = true;
           
	 	} 
 	}
 	if(isIE8Browser==false){
    //Start For VendorEnlistment combo value textarea
    if($(comp).html().indexOf('</option>')!=-1){
        comboHideShow(comp);
        if($(comp).html().indexOf('comments="1"')!=-1 && comp.options[comp.selectedIndex].getAttribute("comments")!=undefined){
            if(comp.options[comp.selectedIndex].getAttribute("comments")==1 && $('textarea[id="'+compId+'"][position="'+position+'"]').html() == undefined){                
                $(comp).parent().append('<textarea   position="'+position+'" cellid="' + $(comp).attr("cellid") + '" name="' + compId + '" id="' + compId + '" rowid="' + (crowId) + '" colid="' + $(comp).attr("colid") + '"></textarea>');
            }
            if(comp.options[comp.selectedIndex].getAttribute("comments")==0){
                $('textarea[id="'+compId+'"][position="'+position+'"]').remove();
            }
        }
    }
    //End
 	}else{
 		if(comp.selectedIndex !=-1){
 	        comboHideShow(comp);
 	        if($(comp).html().indexOf('comments="1"')!=-1 && comp.options[comp.selectedIndex].getAttribute("comments")!=undefined){
 	            if(comp.options[comp.selectedIndex].getAttribute("comments")==1 && $('textarea[id="'+compId+'"][position="'+position+'"]').html() == undefined){                
 	                $(comp).parent().append('<textarea   position="'+position+'" cellid="' + $(comp).attr("cellid") + '" name="' + compId + '" id="' + compId + '" rowid="' + (crowId) + '" colid="' + $(comp).attr("colid") + '"></textarea>');
 	            }
 	            if(comp.options[comp.selectedIndex].getAttribute("comments")==0){
 	                $('textarea[id="'+compId+'"][position="'+position+'"]').remove();
 	            }
 	        }
 	    }
 	}
 	
 	
 	
    $('.err'+compId+'_'+position).remove();
    var tbool = true;    
   /* if(datatype == 1 || datatype == 2){ //smalltext || longtext
        if($.trim(compVal) != "" && (!/^([0-9a-zA-Z\!\$\#\^\s\&\_\[\]\:\;\?\|\@\*\(\)\-\+\.\/\,\\]*)[0-9a-zA-Z\.]+([0-9a-zA-Z\!\$\#\^\s\&\_\[\]\:\;\?\|\@\*\(\)\-\+\.\/\,\\]*)$/.test(compVal)) || (/\-{2}/.test(compVal))) {
            $(comp).parent().append("<div class='err"+compId+"_"+position+"' style='color:red;'>"+MSG_SMALLLONGTEXT+"</div>");
            tbool = false;
        }
    }else*/ if(datatype == 3){ //datatype_numeric
        if($.trim(compVal) != "" && !/^([0-9]){0,15}$/.test(compVal)) {
            $(comp).parent().append("<div class='err"+compId+"_"+position+"' style='color:red;'>"+MSG_WITHOUTDEC+"</div>");
            tbool = false;
        }                         
    }else if(datatype == 4){ //datatype_money
        var NUMERICWITHDECIMAL = "^(\\d{1,15}|\\d{1,15}\\.\\d{1,"+decimalUpto+"})$";
        var decimalRegex = new RegExp(NUMERICWITHDECIMAL);        
        if($.trim(compVal) != "" && !decimalRegex.test(compVal)) {
            $(comp).parent().append("<div class='err"+compId+"_"+position+"' style='color:red;'>"+MSG_DECUPTO+" "+decimalUpto+" places</div>");
            tbool = false;
        }                         
    }else if(datatype == 5){ //datatype_money_all        
        var NUMERICWITHDECIMALM = "^-?(\\d{1,15}|\\d{1,15}\\.\\d{1,"+decimalUpto+"})$";
        var decimalRegexM = new RegExp(NUMERICWITHDECIMALM);
        if($.trim(compVal) != "" && !decimalRegexM.test(compVal)) {
            $(comp).parent().append("<div class='err"+compId+"_"+position+"' style='color:red;'>"+MSG_ALLNUMBERS+" "+decimalUpto+" places</div>");
            tbool = false;
        }                         
    }
    if($.trim(compVal) != "" && tbool && (datatype == 3 || datatype == 4 || datatype == 5)){
       $(comp).val(parseFloat($(comp).val(),10));
    }
    if(!tbool){
    	$('.errclass').remove();
    }
    if(tbool && strFormula[index]!=undefined){        
        var formulas = sortFormula(strFormula[index].split(","));
//        alert(formulas);
        for (var ff = 0; ff < formulas.length; ff++) {
            var colno = formulas[ff].split('@@')[0];
            var formula = formulas[ff].split('@@')[1];
    //                    alert('formula :: '+formula);
    //                    $('#tdrow_' + crowId + '_' + eval(colno - 1)).html(null);                            
            /*$("input[hdcolrow='auto_" + crowId + "_" + eval(colno - 1) + "_" + index + "']").each(function() {
             $(this).val(eval(null));
             });*/
            if ($.trim(compVal) != "") {
                if (formula.indexOf('WORD(') == -1 && formula.indexOf('TOTAL(') == -1) {
                    var str = formula.replace(/N_/g, 'N').replace(/\+/g, '_').replace(/-/g, '_').replace(/\)/g, '_').replace(/\(/g, '_').replace(/\*/g, '_').replace(/\//g, '_');
//                    console.log(str);
                    var arr = str.split("_");
                    var columns = new Array();
                    for (var i = 0; i < arr.length; i++) {                        
                        if (arr[i] != '' && arr[i].indexOf('N') == -1) {
                            columns.push(arr[i]);
                        }
                    }                    
                    var formulaArr = formulaToArr(formula);
//                    console.log(formulaArr);
                    var finalform = '';
                    for (var cnt2 = 0; cnt2 < columns.length; cnt2++) {
                        for (var cnt3 = 0; cnt3 < formulaArr.length; cnt3++) {
                            if (columns[cnt2] == formulaArr[cnt3]) {
    //                                        var curRow = $(comp).closest('tr');
                                var mformate = mformatArr[index];
    //                                        alert('tt :: '+mformatArr[0]);
                                var mforcols = mformate[crowId];
    //                                        alert('mforcols :: '+mforcols);
                                if (mforcols != undefined) {
    //                                            alert('test :: '+mforcols[eval(columns[cnt2] - 1)]);
                                    var key = mforcols[eval(columns[cnt2] - 1)].toString().split("@@$$")[0].split("_");
                                    var cellNo = key[0];
                                    var colCnt = key[1];
                                    var v = mforcols[eval(columns[cnt2] - 1)].toString().split("@@$$")[1];                                    
                                    var tableId = key[4];
                                    if(v == ''){
                                        v = getProxyData(key[6]);                                        
                                    }                                    
                                    if(v != '' &&  key[3]==6){
                                        v = $('select[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + position + '"]').val();
                                    }                                                                                                            
                                    if (v == '' && $('textarea[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + position + '"]').val() != undefined) {
    //                                                alert($('textarea[id="' + tableId + '_' + colCnt + '_' + cellNo+'"][position="'+position+'"]').val())
                                        v = $('textarea[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + position + '"]').val();
                                    }
                                    if (v == '' && $('input[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + position + '"]').val() != undefined) {                                        
//                                        console.log('id="' + tableId + '_' + colCnt + '_' + cellNo+'"][position="'+position+'"]');
//                                                alert($('input[id="' + tableId + '_' + colCnt + '_' + cellNo+'"][position="'+position+'"]').val())
                                        v = $('input[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + position + '"]').val();
                                    }
                                    formulaArr[cnt3] = v + '$$';
                                }
                            }
                        }
                    }
                    for (var cnt3 = 0; cnt3 < formulaArr.length; cnt3++) {
                        finalform = finalform + formulaArr[cnt3].replace('$$', '').replace('N', '');
                    }
    //                            $('#lb_' + crowId + '_' + eval(colno - 1)).html(eval(finalform));
//                    console.log(finalform);
//                    console.log("'auto_" + crowId + "_" + eval(colno - 1) + "_" + index + "'");
                    $("input[hdcolrow='auto_" + crowId + "_" + eval(colno - 1) + "_" + index + "'][position='" + position + "']").each(function() {
    //                                alert(finalform);
                        try {
                            $(this).val(eval(finalform).toFixed(decimalUpto));
                        } catch (e) {
                            
                        }
                    });
                }
                if (formula.indexOf('WORD(') != -1) {
                    var Oncol = formula.replace('WORD(', '').replace(')', '');
                    var wordData = '';
                    $("input[hdcolrow='auto_" + crowId + "_" + eval(Oncol - 1) + "_" + index + "'][position='" + position + "']").each(function() {                        
                        wordData = convertToWord($(this).val(),wordConversion);
                    });
                    $("textarea[hdcolrow='auto_" + crowId + "_" + eval(Oncol - 1) + "_" + index + "'][position='" + position + "']").each(function() {                        
                        wordData = convertToWord($(this).val(),wordConversion);
                    });
                    if(wordData == ''){
                        $("input[name^="+fromTableId+"][colId='"+ eval(Oncol - 1)+ "'][rowId='"+crowId+"'][position='" + position + "']").each(function() {
                            wordData = convertToWord($(this).val(),wordConversion);
                        });                       
                        $("textarea[name^="+fromTableId+"][colId='"+ eval(Oncol - 1)+ "'][rowId='"+crowId+"'][position='" + position + "']").each(function() {                        
                            wordData = convertToWord($(this).val(),wordConversion);
                        });                       
                    }
                    $("input[hdcolrow='auto_" + crowId + "_" + eval(colno - 1) + "_" + index + "'][position='" + position + "']").each(function() {
                        $(this).val(wordData);
                    });
                    $("textarea[hdcolrow='auto_" + crowId + "_" + eval(colno - 1) + "_" + index + "'][position='" + position + "']").each(function() {
                        $(this).val(wordData);
                    });
                }
                if (formula.indexOf('TOTAL(') != -1) {
                    var Oncol = formula.replace('TOTAL(', '').replace(')', '');
                    //var rowCnt = $('#hd_' + index).val();//commented for limited RowMapping
                    var idArr = compId.split('_');
                    /*var cprowId = $(comp).attr('rowid');//commented for limited RowMapping
                    var idAppender = 0;
                    if (Oncol == idArr[1]) {
                        idAppender = parseInt(idArr[2]) - parseInt(cprowId);
                    } else {
                        idAppender = (parseInt(idArr[2]) + (rowCnt * (Math.abs(parseInt(Oncol) - parseInt(idArr[1]))))) - parseInt(cprowId);
                    }*/
//                    console.log('Oncol '+Oncol+' | rowCnt '+rowCnt+' | idArr '+idArr+' | cprowId '+cprowId+' | idAppender '+idAppender+' | ')
                    var gttotal = 0.0;
                    var isUndefined = false;
                    var tempId = idArr[0] + '_' + Oncol;
                    /*for (var i = 0; i < rowCnt; i++) {//commented for limited RowMapping
//                        console.log(tempId + '_' + eval(idAppender + i));
                        isUndefined = ($('input[id="' + tempId + '_' + eval(idAppender + i) + '"]').html() == undefined);
                        $('input[id="' + tempId + '_' + eval(idAppender + i) + '"]').each(function() {
                            var dataVal = $(this).val();
                            if ($.trim(dataVal) != '' && !isNaN(dataVal)) {
                                gttotal = eval(gttotal + parseFloat(dataVal));
                            }
                        });
                    }*/                    
//                    console.log(tempId);
                    //added for limited RowMapping to bidder
                    $('input[id^="' + tempId + '_"]').each(function() {
                        var dataVal = $(this).val();
//                        console.log('ID '+$(this).attr('id')+' : '+ dataVal);
                        if ($.trim(dataVal) != '' && !isNaN(dataVal)) {
                            gttotal = eval(gttotal + parseFloat(dataVal));
                        }
                    });
                    //added for limited RowMapping to bidder
//                    console.log('Oncol : '+Oncol+' GT : '+gttotal+' isUndefined : '+isUndefined);
                    if(gttotal!=0 || !isUndefined){
                        gttotal = gttotal.toFixed(decimalUpto);
                        if(isCgClient){
                        	$('#gt_' + tempId + '_' + index).val(Math.ceil(gttotal));
                        }else{
                        $('#gt_' + tempId + '_' + index).val(gttotal);
                        }
                    }
                    if (formulas.toString().indexOf('WORD(' + Oncol + ')') != -1) {
                        var wordcolno = 0;
                        for (var ss = 0; ss < formulas.length; ss++) {
                        	 if(formulas[ss].indexOf('WORD(' + Oncol + ')')!= -1){
                                wordcolno = parseInt(formulas[ss].split('@@')[0],10)-1;
                            }
                        }
                        var gtinword = convertToWord(gttotal,wordConversion);
                        $('#gttd_' + wordcolno  + '_' + index).html(gtinword+'<input type="hidden"  cellidno="'+$('#gttd_' + wordcolno  + '_' + index).attr('cellidno')+'" value="'+gtinword+'"/>');
                    }
                }                
            }
        }
    }    
    if ($.trim(compVal)!='' && valFormula[index] != undefined) {        
        var specFormulaArr = valFormula[index].split(',');
        var isVFFormulaOK = true;
        for(var r=0;r<specFormulaArr.length;r++){
            var specFormula = specFormulaArr[r];            
            if (isVFFormulaOK && specFormula.indexOf('VF_') != -1) {
                var destcolumnno = specFormula.split('@@')[0];
                var destcellno = '';
                var cellformula = specFormula.split('@@')[1].replace('VF_', '');
                var cellmsg = specFormula.split('@@')[2];
                var formulaArr = formulaToArr(cellformula);
                var str = cellformula.replace(/N_/g, 'N').replace(/\+/g, '_').replace(/-/g, '_').replace(/\)/g, '_').replace(/\(/g, '_').replace(/\*/g, '_').replace(/\//g, '_').replace(/<=/g, '_').replace(/>=/g, '_').replace(/!=/g, '_').replace(/</g, '_').replace(/>/g, '_').replace(/==/g, '_').replace(/%/g, '_');
                var arr = str.split("_");
                var columns = new Array();
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i] != '' && arr[i].indexOf('N') == -1) {
                        columns.push(arr[i]);
                    }
                }
                var finalformula = '';
    //            alert('ff : '+formulaArr);
                for (var cnt2 = 0; cnt2 < columns.length; cnt2++) {
                    for (var s = 0; s < formulaArr.length; s++) {
                        if (destcolumnno == formulaArr[s]) {
                            var mformate = mformatArr[index];
                            var mforcols = mformate[crowId];
                            if (mforcols != undefined) {
                                var key = mforcols[eval(columns[cnt2] - 1)].toString().split("@@$$")[0].split("_");
                                destcellno = key[0];
                            }    
                        }
                        if (columns[cnt2] == formulaArr[s]) {
                            var mformate = mformatArr[index];
                            var mforcols = mformate[crowId];
                            if (mforcols != undefined) {
                                var key = mforcols[eval(columns[cnt2] - 1)].toString().split("@@$$")[0].split("_");
                                var cellNo = key[0];
                                var colCnt = key[1];
                                var v = mforcols[eval(columns[cnt2] - 1)].toString().split("@@$$")[1];
                                var tableId = key[4];
                                if (v == '') {
                                    v = getProxyData(key[6]);
    //                                console.log('Proxy VF : '+v);
                                }
                                if (v != '' && key[3] == 6) {
                                    v = $('select[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + position + '"]').val();
                                }
                                if (v == '' && $('input[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + position + '"]').val() != undefined) {
                                    //                                                alert($('input[id="' + tableId + '_' + colCnt + '_' + cellNo+'"][position="'+position+'"]').val())
                                    v = $('input[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + position + '"]').val();
                                }
                                if (v == '' && $('textarea[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + position + '"]').val() != undefined) {
                                    //                                                alert($('input[id="' + tableId + '_' + colCnt + '_' + cellNo+'"][position="'+position+'"]').val())
                                    v = $('textarea[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + position + '"]').val();
                                }
                                formulaArr[s] = v + '$$';
                            }
                        }
                    }
                }
                $('.err'+tableId+'-'+destcolumnno+'-'+destcellno+'-'+position).remove();
    //            alert(formulaArr);
                var dontCheckZero = true;//Need to remove temporary solution for allowing bid with zero value MARK @@
                for (var cnt3 = 0; cnt3 < formulaArr.length; cnt3++) {
                    var tempFormulaVar = formulaArr[cnt3].replace('$$', '').replace('N', '');                
                    /*if(!isNaN(tempFormulaVar) && parseFloat(tempFormulaVar) == 0){//@@
                        dontCheckZero = false;//@@
                        break;//@@
                    }//@@*/
                    finalformula = finalformula + tempFormulaVar;
                }
                try{
                	if(dontCheckZero && !eval(finalformula)){//@@
                        var vcomponent = $('#'+tableId+'_'+destcolumnno+'_'+destcellno);
                        vcomponent.parent().append('<div class="err'+tableId+'-'+destcolumnno+'-'+destcellno+'-'+position+'" style="color:red;">'+cellmsg+'</div>');
                        cellValidated.push(vcomponent);
                        isVFFormulaOK = false;
                    }
                }catch(e){
                	//alert(e);
                }
            }
        }
    }
    for (var sp = 0; sp < specialFormula.length; sp++) {
    	if(specialFormula[sp]!=undefined){
        var specFormula = specialFormula[sp].split(',');
        for (var spvf = 0; spvf < specFormula.length; spvf++) {
            if (specFormula[spvf].indexOf('SPF_') != -1) {
                var destcellid = specFormula[spvf].split('@@')[0];
                var cellformula = specFormula[spvf].split('@@')[1].replace('SPF_', '');
                var formulaArr = formulaToArr(cellformula);
                var str = cellformula.replace(/N_/g, 'N').replace(/\+/g, '_').replace(/-/g, '_').replace(/\)/g, '_').replace(/\(/g, '_').replace(/\*/g, '_').replace(/\//g, '_');
                var arr = str.split("_");
                var cells = new Array();
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i] != '' && arr[i].indexOf('N') == -1) {
                        cells.push(arr[i]);
                    }
                }
                var finalformula = '';
                for (var cnt2 = 0; cnt2 < cells.length; cnt2++) {
                    for (var s = 0; s < formulaArr.length; s++) {
                        if (cells[cnt2] == formulaArr[s]) {
                            var cellValue = $('input[cellidno^="' + formulaArr[s] + '"]').val();
                            if (cellValue == undefined) {
                                cellValue = $('input[cellid="' + formulaArr[s] + '"]').val();
                                if (cellValue == undefined) {
                                    cellValue = $('textarea[cellid="' + formulaArr[s] + '"]').val();
                                }
                                if (cellValue == undefined) {
                                    cellValue = $('select[cellid="' + formulaArr[s] + '"]').val();
                                }
                                if (cellValue == undefined) {
                                    cellValue = getProxyData(formulaArr[s]);
//                                    console.log('Proxy SPF: '+cellValue);
                                }
                            }
                            formulaArr[s] = (cellValue == '' ? 0 : cellValue);
                        }
                    }
                }
                finalformula = eval(formulaArr.join().replace(/,/g, '').replace(/N/g, '')).toFixed(decimalUpto);
                $('input[cellidno^="' + destcellid + '"]').val(finalformula);
                $('input[cellid="' + destcellid + '"]').val(finalformula);
                $('textarea[cellid="' + destcellid + '"]').val(finalformula);
                $('select[cellid="' + destcellid + '"]').val(finalformula);
            }
        }
      }	
    }
    for (var spv = 0; spv < valCellFormula.length; spv++) {
    	if(valCellFormula[spv]!=undefined){
    	var specFormula = valCellFormula[spv].split(',');
        for (var spvf = 0; spvf < specFormula.length; spvf++) {
            if (specFormula[spvf].indexOf('VCF_') != -1) {
                var destcellid = specFormula[spvf].split('@@')[0];                
                var cellformula = specFormula[spvf].split('@@')[1].replace('VCF_', '');
                var cellmsg = specFormula[spvf].split('@@')[2];
                var formulaArr = formulaToArr(cellformula);
                var str = cellformula.replace(/N_/g, 'N').replace(/\+/g, '_').replace(/-/g, '_').replace(/\)/g, '_').replace(/\(/g, '_').replace(/\*/g, '_').replace(/\//g, '_').replace(/<=/g, '_').replace(/>=/g, '_').replace(/!=/g, '_').replace(/</g, '_').replace(/>/g, '_').replace(/==/g, '_').replace(/%/g, '_');
                var arr = str.split("_");
                var cells = new Array();
                var checkCell = 0;
                for (var i = 0; i < arr.length; i++) {
                    if (arr[i] != '' && arr[i].indexOf('N') == -1) {
                        cells.push(arr[i]);
                        if(cells.length==1){
                            checkCell  = parseInt(arr[i]);
                        }else{
                            checkCell -= parseInt(arr[i]);
                        }
                    }
                }                
                if (checkCell != 0) {
                    var formulaIndex = new Array();
                    var tablecell = $('input[cellid="' + destcellid + '"][position="0"]');
                    if (tablecell.val() != undefined) {
                        $('input[cellid="' + destcellid + '"]').each(function() {
                            formulaIndex.push(formulaArr);
                            $('.err' + destcellid + '_' + (formulaIndex.length - 1)).remove();
                        });
                    }
                    var tablecell = $('textarea[cellid="' + destcellid + '"][position="0"]');
                    if (tablecell.val() != undefined) {
                        $('textarea[cellid="' + destcellid + '"]').each(function() {
                            formulaIndex.push(formulaArr);
                            $('.err' + destcellid + '_' + (formulaIndex.length - 1)).remove();
                        });
                    }
                    tablecell = $('select[cellid="' + destcellid + '"][position="0"]');
                    if (tablecell.val() != undefined) {
                        $('select[cellid="' + destcellid + '"]').each(function() {
                            formulaIndex.push(formulaArr);
                            $('.err' + destcellid + '_' + (formulaIndex.length - 1)).remove();
                        });
                    }
                    tablecell = $('input[cellidno^="' + destcellid + '_"]');
                    if (tablecell.val() != undefined) {
                        formulaIndex.push(formulaArr);
                        $('.err' + destcellid + '_' + (formulaIndex.length - 1)).remove();
                    }
                    var finalformula = '';
                    for (var cnt2 = 0; cnt2 < cells.length; cnt2++) {
                        for (var s = 0; s < formulaArr.length; s++) {
                            var fcellId = cells[cnt2];
                            if (fcellId == formulaArr[s]) {
                                for (var t = 0; t < formulaIndex.length; t++) {
//                                if (checkCell != 0) {
                                    var cellValue = $('input[cellidno^="' + fcellId + '"]').val();
                                    if (cellValue == undefined) {
                                        cellValue = $('input[cellid="' + fcellId + '"][position="' + ((fcellId == destcellid) ? t : 0) + '"]').val();
                                        if (cellValue == undefined) {
                                            cellValue = $('textarea[cellid="' + fcellId + '"][position="' + ((fcellId == destcellid) ? t : 0) + '"]').val();
                                        }
                                        if (cellValue == undefined) {
                                            cellValue = $('select[cellid="' + fcellId + '"][position="' + ((fcellId == destcellid) ? t : 0) + '"]').val();
                                        }
                                        if (cellValue == undefined) {
                                            cellValue = getProxyData(fcellId);
//                                            console.log('Proxy VCF: '+cellValue);
                                        }
                                    }
//                              alert('fcellId : '+fcellId+' fposition : '+fposition+' cellValue : '+cellValue);
                                    var tempArr = formulaIndex[t];
                                    var sArr = new Array();
                                    for (var e = 0; e < tempArr.length; e++) {
                                        if (e == s) {
                                            sArr.push((cellValue == '' ? 'dontexecute' : cellValue));
                                        } else {
                                            sArr.push(tempArr[e]);
                                        }
                                    }
                                    formulaIndex[t] = sArr;                                    
                                }
                            }
                        }
                    }
                    for (var t = 0; t < formulaIndex.length; t++) {
                        if (formulaIndex[t].join().replace(/,/g, '').toString().indexOf('dontexecute') != -1) {
                            finalformula = true;
                        } else {
//                          console.log(formulaIndex[t].join().replace(/,/g, ''));                                
                            finalformula = eval(formulaIndex[t].join().replace(/,/g, '').replace(/N/g, ''));
                        }
                        if (!finalformula) {
                            var vcomponent = $('input[cellidno^="' + destcellid + '"]');
                            if (vcomponent.val() == undefined) {
                                vcomponent = $('input[cellid="' + destcellid + '"][position="' + t + '"]');
                            }
                            if (vcomponent.val() == undefined) {
                                vcomponent = $('textarea[cellid="' + destcellid + '"][position="' + t + '"]');
                            }
                            if (vcomponent.val() == undefined) {
                                vcomponent = $('select[cellid="' + destcellid + '"][position="' + t + '"]');
                            }
                            vcomponent.parent().append('<div class="err' + destcellid + '_' + t + '" style="color:red;">'+cellmsg+'</div>');
                            cellValidated.push(vcomponent);
							return false;
                        }
                    }
                }else{
                    var compoCnt=0;
                    var valueCell = new Array();
                    var tablecell = $('input[cellid="' + destcellid + '"][position="0"]');
                    if (tablecell.val() != undefined) {
                        $('input[cellid="' + destcellid + '"]').each(function() {
                            valueCell.push(($(this).val() == '' ? 'dontexecute' : $(this).val()));
                            $('.err' + destcellid + '_' + compoCnt).remove();
                            compoCnt++;
                        });
                    }
                    var tablecell = $('textarea[cellid="' + destcellid + '"][position="0"]');
                    if (tablecell.val() != undefined) {
                        $('textarea[cellid="' + destcellid + '"]').each(function() {
                            valueCell.push(($(this).val() == '' ? 'dontexecute' : $(this).val()));
                            $('.err' + destcellid + '_' + compoCnt).remove();
                            compoCnt++;
                        });
                    }
                    tablecell = $('select[cellid="' + destcellid + '"][position="0"]');
                    if (tablecell.val() != undefined) {
                        $('select[cellid="' + destcellid + '"]').each(function() {
                            valueCell.push(($(this).val() == '' ? 'dontexecute' : $(this).val()));
                            $('.err' + destcellid + '_' + compoCnt).remove();
                            compoCnt++;
                        });
                    }
                    var actCnt = (compoCnt*compoCnt)-compoCnt;
                    var formulaIndex = new Array();
                    for(var x = 0; x < actCnt; x++) {
                        formulaIndex.push(formulaArr);
                    }
                    var tcount=0;
                    for (var s = 0; s < compoCnt; s++) {
                        for (var t = 0; t < compoCnt; t++) {
                            if(t==s){
                                for(var v=0;v<(compoCnt-1);v++){
                                    var tempArr = formulaIndex[(t*(compoCnt-1))+v];
                                    var sArr = new Array();
                                    for (var e = 0; e < tempArr.length; e++) {
                                        if (e == 0) {
                                            sArr.push(valueCell[t]);
                                        } else {
                                            sArr.push(tempArr[e]);
                                        }
                                    }
                                    formulaIndex[(t*(compoCnt-1))+v] = sArr;
                                }
                            }else{
                                if(tcount<actCnt){
                                    var tempArr = formulaIndex[tcount];
                                    var sArr = new Array();
                                    for (var e = 0; e < tempArr.length; e++) {
                                        if (e == (tempArr.length-1)) {
                                            sArr.push(valueCell[t]);
                                        } else {
                                            sArr.push(tempArr[e]);
                                        }
                                    }
                                    formulaIndex[tcount] = sArr;                                
                                    tcount++;
                                }
                            }
                        }
                    }
                    var successCounter=0;
                    var invalidIndex = new Array();
                     for (var t = 0; t < formulaIndex.length; t++) {
                        if (formulaIndex[t].join().replace(/,/g, '').toString().indexOf('dontexecute') != -1) {
                            finalformula = true;
                            successCounter++;
                        } else {
//                        alert(formulaIndex[t].join().replace(/,/g, ''));
                            finalformula = eval(formulaIndex[t].join().replace(/,/g, ''));
                        }
                        if (finalformula) {
                            successCounter++;
                        }else{
                            invalidIndex.push(t);
                        }
                    }
                    if(successCounter != actCnt){
//                        alert(invalidIndex);
                        for (var p = 0; p < invalidIndex.length; p++) {
                            for (var s = 0; s < (compoCnt - 1); s++) {
                                if((invalidIndex[p]-s)%(compoCnt - 1)==0){
                                    var failIndex = ((invalidIndex[p]-s)/(compoCnt - 1));
//                                     alert(failIndex);
                                    if($('.err' + destcellid + '_' + failIndex).html()==undefined){
                                        var vcomponent = $('input[cellid="' + destcellid + '"][position="' + failIndex + '"]');
                                        if (vcomponent.val() == undefined) {
                                            vcomponent = $('textarea[cellid="' + destcellid + '"][position="' + failIndex + '"]');
                                        }
                                        if (vcomponent.val() == undefined) {
                                            vcomponent = $('select[cellid="' + destcellid + '"][position="' + failIndex + '"]');
                                        }
                                        vcomponent.parent().append('<div class="err' + destcellid + '_' + failIndex + '" style="color:red;">' + cellmsg + '</div>');
                                        cellValidated.push(vcomponent);
                                        return false;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
      }
    }
    if(isBidder && tenderResult == 2 && isPriceBid == 1 && ($.trim(compVal)=='')){
    	var isTablePartialFillingAllow = tablePartialMandatory[index][0];
	    if (isTablePartialFillingAllow == 1){
	    	var vTrComp = $(comp).parent().parent();
	    	var bidderRfilledCell = 0;
	    	$(vTrComp).find('.biddercell').each (function() {
	    		if ($(this).children().val() != "" && $(this).children().val() != null)
	    			bidderRfilledCell++;
	    	}); 
	    	if(bidderRfilledCell == 0){
	    		$(vTrComp).find('[hdcolrow]').each (function() {
	        		$(this).val('');
	        	});
	    		var bidderAllFilledCell = 0;
	    		$('.biddercell').each(function(i, vBCell) {
	    			if ($(vBCell).children().val() != ""){ 
	    			  bidderAllFilledCell++;
	    			  $(vBCell).children().blur();
	    		  }
	    		});
	    		if(bidderAllFilledCell == 0){
	    			$('[name^=gt_'+fromTableId+']').each(function() {
	    				$(this).val('');
	    			});
	    		}
	    	}
	    }
    }
}
function specialTrim(str) { 
	var strDataforTrim = str;
	if (strDataforTrim != undefined ){
		strDataforTrim  = strDataforTrim.replace(/>\s+</g, '><');
	}
    return strDataforTrim; 
}
var addTabCounter = new Array();
function addBidTable(tableId) {
	//alert('addBidTable ');
    if (addTabCounter[tableId] == undefined) {
        addTabCounter[tableId] = 1;
    }
    $('#table_' + tableId + ' > tbody > tr:eq(' + ((addTabCounter[tableId] * tabcells[tableId].length) + 2) + ')').after(specialTrim(tabcells[tableId].join(" ")).replace(/position="0"/g, 'position="' + addTabCounter[tableId] + '"').replace(/position=\\'0\\'/g, "position=\\'" + addTabCounter[tableId] + "\\'"));
    //$('#table_' + tableId + ' > tbody > tr:eq(' + ((addTabCounter[tableId] * tabcells[tableId].length) - 1) + ')').after(specialTrim(tabcells[tableId].join(" ")).replace(/position="0"/g, 'position="' + addTabCounter[tableId] + '"').replace(/position=\\'0\\'/g, "position=\\'" + addTabCounter[tableId] + "\\'"));
    $('#table_' + tableId).append('<input type="hidden" position="' + addTabCounter[tableId] + '" name="tableBid_' + tableId + '" id="tableBid_' + tableId + '"/><input type="hidden" position="' + addTabCounter[tableId] + '" name="tableEnc_' + tableId + '" id="tableEnc_' + tableId + '"><input type="hidden" position="' + addTabCounter[tableId] + '" name="rtfSorBid_' + tableId + '" id="rtfSorBid_' + tableId + '"/>');
    autoNumberCountChange(tableId);
    addTabCounter[tableId] = addTabCounter[tableId] + 1;
}

function autoNumberCountChange(tableId){
	var autoNumber = 1;
	$('tr[id^="rowtr_"]').each(function() {
		var rawTableId = $(this).attr('id').split('_')[2];
		if(rawTableId == tableId){
			$('td', this).each(function(){
				if($(this).html().indexOf('autonumber=') != -1){
					$('input', this).val(autoNumber);
					$('lable', this).html(autoNumber);
				}
		    });
			autoNumber++;
		}
	});
}

function removeBidTable(tableId) {
    if (addTabCounter[tableId] == undefined || addTabCounter[tableId] == 1) {
        jAlert(MSG_ATLEASTONEROW, MSG_BIDSUBMITHEAD, function(RetVal) {
        });
    } else {
        var isremoved = false;
        $(":checkbox[id='trchk_" + tableId + "']").each(function() {
            var rempos = $(this).attr('position');            
                if ($(this).is(':checked')) {                    
                    if (addTabCounter[tableId] == undefined || addTabCounter[tableId] == 1) {
                        jAlert(MSG_ATLEASTONEROW, MSG_BIDSUBMITHEAD, function(RetVal) {
                        });                        
                    }else{
                        $('tr[id*="_' + tableId + '"][position="' + rempos + '"]').each(function() {
                            $(this).remove();
                        });
                        $('input[id="tableBid_' + tableId + '"][position="' + rempos + '"]').remove();
                        $('input[id="tableEnc_' + tableId + '"][position="' + rempos + '"]').remove();
                        $('input[id="rtfSorBid_' + tableId + '"][position="' + rempos + '"]').remove();                    
                        addTabCounter[tableId] = addTabCounter[tableId] - 1;
                        isremoved = true;
                }
            }
        });
        if (isremoved) {            
            for (var newremposition = 0; newremposition < addTabCounter[tableId]; newremposition++) {
                var otherpos = document.getElementsByName('trchk_' + tableId).item(newremposition).getAttribute('position');
//            alert('otherpos : '+otherpos+' newremposition : '+newremposition);
                $('tr[id*="_' + tableId + '"][position="' + otherpos + '"]').each(function() {
                    $('tr[id="' + $(this).attr('id') + '"][position="' + otherpos + '"] > td > input').each(function() {
                        $(this).blur();
                        $(this).attr('position', newremposition);
                    });
                    $('tr[id="' + $(this).attr('id') + '"][position="' + otherpos + '"] > td > textarea').each(function() {
                        $(this).attr('position', newremposition);
                    });
                    $('tr[id="' + $(this).attr('id') + '"][position="' + otherpos + '"] > td > select').each(function() {
                        $(this).attr('position', newremposition);
                    });
                    $(this).attr('position', newremposition);
                });
                $('input[id="tableBid_' + tableId + '"][position="' + otherpos + '"]').attr('position', newremposition);
                $('input[id="tableEnc_' + tableId + '"][position="' + otherpos + '"]').attr('position', newremposition);
                $('input[id="rtfSorBid_' + tableId + '"][position="' + otherpos + '"]').attr('position', newremposition);                    
            }
        }
    }
    autoNumberCountChange(tableId);
}

function signNencryptData(bidTableData, bidpkey){
	//alert('signNencryptData ');
    bidTableData = signData(bidTableData, bidpkey);
    bidTableData = encryptData(bidTableData);
    return bidTableData;
}

function signNencryptBidData(bidTableData, bidpkey,bidpkey2){
    //alert('signNencryptBidData ');
    bidTableData = signData(bidTableData, bidpkey);
    bidTableData = encryptBidData(bidTableData,bidpkey2);
    return bidTableData;
}

function signEncryptCellValueData(cellValue, bidpkey,bidpkey2){
    //alert('signEncryptCellValueData ');
	cellValue = signData(cellValue, bidpkey);
    cellValue = encryptBidData(cellValue,bidpkey2);
    return cellValue;
}

function signData(bidTableData, bidpkey){
	//alert('signData ');
	if (isPki) {

		try {
            getCertiAliasByKeyUsage(bidpkey,1);
//            sealock.selectCertificate();
console.log("\n\n--bidTableData--");
console.log(bidTableData);
            sealock.setData(bidTableData);
            bidTableData = sealock.getSignature();
        }catch (e) {
            console.log('signData : '+e.message);
//            alert(e);
            return false;
        }
    }
    if (encryptionReq != 1) {
        bidTableData = replaceJunk(bidTableData); 
    }
    return bidTableData;
}

function encryptData(bidTableData) {
	if (isPki) {
        try {            
        	if (encryptionReq == 1) {
        		sealock.setSignature(bidTableData);//to verify signed data 
        		if(sealock.isVerifySignature()){
        			if (encLevel == 1) {
                        sealock.setData(bidTableData);
                        if (encLevelOnePKey.length == 1) {
                            sealock.setPublicKey(encLevelOnePKey[0]);
                            bidTableData = sealock.getEncrypt();
                        }
                        if (encLevelOnePKey.length > 1) {
                            sealock.setPublicKey(encLevelOnePKey[0]);
                            sealock.setPublicKey1(encLevelOnePKey[1]);
                            bidTableData = sealock.getMultiEncrypt();
                        }
                    }
                    if (encLevel == 2) {
                        sealock.setData(bidTableData);
                        if (encLevelOnePKey.length == 1) {
                            sealock.setPublicKey(encLevelOnePKey[0]);
                            sealock.setData(sealock.getEncrypt());
                        }
                        if (encLevelOnePKey.length > 1) {
                            sealock.setPublicKey(encLevelOnePKey[0]);
                            sealock.setPublicKey1(encLevelOnePKey[1]);
                            sealock.setData(sealock.getMultiEncrypt());
                        }
                        if (encLevelTwoPKey.length == 1) {
                            sealock.setPublicKey(encLevelTwoPKey[0]);
                            bidTableData = sealock.getEncrypt();
                        }
                        if (encLevelTwoPKey.length > 1) {
                            sealock.setPublicKey(encLevelTwoPKey[0]);
                            sealock.setPublicKey1(encLevelTwoPKey[1]);
                            bidTableData = sealock.getMultiEncrypt();
                        }
                    }
                    //3 Level Encryption @Author Hema
                    if (encLevel == 3) {
                    	
                        sealock.setData(bidTableData);
                        if (encLevelOnePKey.length == 1) {
                            sealock.setPublicKey(encLevelOnePKey[0]);
                            sealock.setData(sealock.getEncrypt());
                        }
                        if (encLevelOnePKey.length > 1) {
                       	 sealock.setPublicKey(encLevelOnePKey[0]);
                            sealock.setPublicKey1(encLevelOnePKey[1]);
                          bidTableData = sealock.getMultiEncrypt();
                            sealock.setData(sealock.getMultiEncrypt());
                        }
                        if (encLevelTwoPKey.length == 1) {
                            sealock.setPublicKey(encLevelTwoPKey[0]);
                            sealock.setData(sealock.getEncrypt());
                            bidTableData = sealock.getEncrypt();
                        }
                        if (encLevelTwoPKey.length > 1) {
                          
                            
                            sealock.setPublicKey(encLevelTwoPKey[0]);
                            sealock.setPublicKey1(encLevelTwoPKey[1]);
                         bidTableData = sealock.getMultiEncrypt();
                               sealock.setData(sealock.getMultiEncrypt());
                        }
                        
                        //3 Level Encryption @Author Hema
                        if (encLevelThreePKey.length == 1) {
                            sealock.setPublicKey(encLevelThreePKey[0]);
                            bidTableData = sealock.getEncrypt();
                        }
                        if (encLevelThreePKey.length > 1) {
                           
                            
                            sealock.setPublicKey(encLevelThreePKey[0]);
                            sealock.setPublicKey1(encLevelThreePKey[1]);
                            bidTableData = sealock.getMultiEncrypt();
                              sealock.setData(sealock.getMultiEncrypt());
                        }
                    }
         	
        		}else{
                    console.log('problem with signed data');
        			return false;
        		}
            }
        } catch (e) {
            console.log('encryptData : '+e.message);
//            alert(e);
            return false;
        }
    }
    return replaceJunk(bidTableData);
}
function encryptBidData(bidTableData, bidpkey) {
    if (isPki) {
        try {            
            if (encryptionReq == 1) {
            	sealock.setSignature(bidTableData);//to verify signed data 
            	if(sealock.isVerifySignature()){
            	     sealock.setData(bidTableData);
                     sealock.setPublicKey(bidpkey);
                     bidTableData = sealock.getEncrypt();
            	}else{
                    console.log('problem with signed data');
            		return false;
            	}
            }
        } catch (e) {
            console.log('encryptBidData : '+e.message);
//            alert(e);
            return false;
        }
    }
    return replaceJunk(bidTableData);
}
function decryptData(bidTableData, bidpkey,bidpkey2) {    
    if (isPki) {        
        try {
            if (encryptionReq == 1) {
                var cert2alias = getCertiAliasByKeyUsage(bidpkey2,2);
                if(cert2alias!=''){
                    
//                    sealock.selectCertificate(cert2alias);
                    sealock.setEncrypt(bidTableData);
                    bidTableData = sealock.getDecrypt();                
                }else{
                    bidTableData="nocertificate";
                }
            }
            if(bidTableData!=''){
                var cert1alias = getCertiAliasByKeyUsage(bidpkey,1);
                if(cert1alias!=''){
//                    sealock.selectCertificate(cert1alias);
                    sealock.setSignature(bidTableData);
                    if (sealock.isVerifySignature()) {
                        bidTableData = sealock.getData();
                    }                   
                }else{
                    bidTableData="nocertificate";
                }
            }
        } catch (e) {
            console.log('decryptData : '+e.message);
            bidTableData=''            
        }
        $("#uploadFormData").removeAttr("disabled");
    }    
    return bidTableData;
}
function replaceJunk(data) {
//    return data;
//    return data.toString().replace(/[/\r]/g,'@@@').replace(/[/\n]/g,'$$$').replace(/[/\t]/g,'~~~').replace(/[/\s]/g,'^^^');
    return data.toString().replace(/[\r]/g, '@@').replace(/[\n]/g, '##');
}
function reverseReplaceJunk(data) {
//    return data;
//    alert(data);
//    return data.toString().replace(/@@@/g,'\r').replace(/$$$/g,'\n').replace(/~~~/g,'\t').replace(/^^^/g,'\s');
    return data.toString().replace(/@@/g, '\r').replace(/##/g, '\n');
}
function GetCal(txtname, controlname, datetype,picker) {

    if (datetype == 'datetime') {
        var date;
        new Calendar({
            inputField: txtname,
            trigger: controlname,
            dateFormat: DATETIMEFORMATE_CALENDAR,
            position:picker,
            showTime: true,
            onSelect: function() {
                date = this.selection.get()
                date = Calendar.intToDate(date);
                date = Calendar.printDate(date, DATETIMEFORMATE_CALENDAR);
                this.hide();
                document.getElementById(txtname).focus();
            }
        });
    } else {
        new Calendar({
            inputField: txtname,
            trigger: controlname,
            showTime: false,
            position:picker,
            dateFormat: DATEFORMATE_CALENDAR,
            onSelect: function() {
                var date = Calendar.intToDate(this.selection.get());
                LEFT_CAL.args.min = date;
                LEFT_CAL.redraw();
                this.hide();
            }
        });

    }

    var LEFT_CAL = Calendar.setup({
        weekNumbers: false
    })
}
function sortFormula(formula){    
    var finalFormula = new Array();
    var totalFormula = new Array();
    var wordFormula = new Array();
    var simpleFormula = new Array();
    for(var i=0;i<formula.length;i++){
        if(formula[i].toString().indexOf('@@TOTAL(')!=-1){
            totalFormula[formula[i].toString().split('@@')[0]]=formula[i].toString().split('@@')[1];
        }else if(formula[i].toString().indexOf('@@WORD(')!=-1){
            wordFormula[formula[i].toString().split('@@')[0]]=formula[i].toString().split('@@')[1];
        }else{
            simpleFormula[formula[i].toString().split('@@')[0]]=formula[i].toString().split('@@')[1];
        }
    }
    for(var s=0;s<simpleFormula.length;s++){
        if(simpleFormula[s]!=undefined && simpleFormula[s]!=''){
            finalFormula.push(s+'@@'+simpleFormula[s]);
        }
    }
    for(var s=0;s<totalFormula.length;s++){
        if(totalFormula[s]!=undefined && totalFormula[s]!=''){
            finalFormula.push(s+'@@'+totalFormula[s]);
        }
    }    
    for(var s=0;s<wordFormula.length;s++){
        if(wordFormula[s]!=undefined && wordFormula[s]!=''){
            finalFormula.push(s+'@@'+wordFormula[s]);
        }
    }    
    return finalFormula;
}
function setProxyData(index){
    if (proxyData[index] != undefined && proxyData[index] != '') {
        var proxyJson = jQuery.parseJSON(proxyData[index]);
        $.each(proxyJson, function() {
            $.each(this, function(t, s) {                
                $('#lblproxy_' + t).html(s);
                proxyValue.push(t+'@@@'+s);
            });
        });
    }
}
function getProxyData(pCellId){
    var proxyVal = '';
    for(var c=0;c<proxyValue.length;c++){
        if(proxyValue[c].indexOf(pCellId+'@@@')!=-1){
            proxyVal = proxyValue[c].split('@@@')[1];
        }
    }
    if(proxyVal==''){
        if($('input[proxycellid="'+pCellId+'"]').val()!=undefined){
            proxyVal = $('input[proxycellid="'+pCellId+'"]').val();
        }
    }
    return proxyVal;
}
function generateRows(index, tableId, rowcount, isGtWise) {
    var currRows = parseInt($('#hdcr_' + index).val());
    var tds = new Array();
    var kk = currRows;
    var counter = 0;
    var filledByNColumnTypes = getFilledByArr(index);
//        console.log(parseInt(currRows)+parseInt(pagination));
//        console.log(rowcount);
    var tempCnt = rowcount - (parseInt(currRows) + parseInt(pagination));
    var pageCounter = pagination;
    if (isGtWise == 'true' && tempCnt < 0) {
//        console.log(tempCnt);
        pageCounter = parseInt(pageCounter) + parseInt(tempCnt);
    }
    
//        console.log(pageCounter);
    for (var dt = 0; dt < pageCounter; dt++) {
        var mforcols = mformatArr[index][kk];
        if (mforcols != undefined) {
            for (var gg = 0; gg < mforcols.length; gg++) {
                var key = mforcols[gg].toString().split("@@$$")[0].split("_");
//                    console.log(key);
                var cellId = key[6];
                var cellNo = key[0];
                var colCnt = key[1];
                var rowCnt = key[2];
                var datatype = key[3];
//                console.log(userData[index]);
                var vals = userData[index]==undefined ? undefined : userData[index][cellNo];
//                console.log(vals);
                var v = mforcols[gg].toString().split("@@$$")[1];
                //                console.log(v);
                if (tds[dt] == undefined) {
                    tds[dt] = '<tr id="' + (eval(rowCnt - 1)) + '">';
                }
                if (vals != undefined) {
                    if(!(datatype==6 || datatype==9 || datatype==8)){
                        v = vals;
                    }
                }
                //                console.log(filledBy);
                var filledByNColumnTypeId = filledByNColumnTypes[colCnt].split('_');
                var ffilled = filledByNColumnTypeId[0];
                var fcolumntype = filledByNColumnTypeId[1];
                var fcolumnshow = filledByNColumnTypeId[2];
                var tdInValue = '';
                //                console.log(ffilled);
                var tdText = '<td '+(isBidder && fcolumnshow=='0' ? 'style="display:none;"' : '')+' class="v-a-middle border-left '
                    +((ffilled == 1 && (datatype=='1' || datatype=='2')) ? ' a-left ' :(ffilled == 2 ? ' a-center biddercell ' : (ffilled==3 ? ' a-center ' : ' a-center ')))
                    +((ffilled == '1' && fcolumntype=='1' ? ' cItemName ' : '' ))
                    +'" id="tdrow_' + (rowCnt - 1) + '_' + (colCnt - 1) + '" sorder="'+gg+'"  valign="top" tableId="'+tableId+'">';
                var tdClose='</td>';
                if (ffilled == 1) {
                    tdInValue = v;
//                    tds[dt] = tds[dt] + tdText + v;
                } else if (ffilled == 2) {
                    if(fcolumntype==8){//columntypeId=8 currency
                        var comboStr = currencyArr[index];
                        if(vals!=undefined){
                                comboStr = comboStr.replace('value="'+vals+'"','value="'+vals+'" selected');
                        }
                        tdInValue = '<select class="descView" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '"  onchange="calvalidData(this,\'' + datatype + '\',\'' + index + '\')" position="0" colid="' + (colCnt - 1) + '" rowid="' + (rowCnt - 1) + '" cellid="' + cellId + '">'+comboStr+'</select>';
//                        tds[dt] = tds[dt] + tdText + 'class="a-center biddercell"  tableId="'+tableId+'">'
//                        +'<select name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '"  onchange="calvalidData(this,\'' + datatype + '\',\'' + index + '\')" position="0" colid="' + (colCnt - 1) + '" rowid="' + (rowCnt - 1) + '" cellid="' + cellId + '">'+comboStr+'</select></td>';
                    }else if (datatype == 1 || datatype == 3 || datatype == 4 || datatype == 5) {
                        tdInValue = '<input class="descView '+((isPriceBid==1 && (datatype == 3 || datatype == 4 || datatype == 5)) ? 'input-width' : '')+'"  position="0" cellid="' + cellId + '" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '" value="' + v + '" onblur="calvalidData(this,\'' + datatype + '\',\'' + index + '\')" rowid="' + (rowCnt - 1) + '" colid="' + (colCnt - 1) + '" type="text"/>';
//                        tds[dt] = tds[dt] + tdText + 'class="a-center biddercell"  tableId="'+tableId+'">'
//                                + '<input class="'+((isPriceBid==1 && (datatype == 3 || datatype == 4 || datatype == 5)) ? 'input-width' : '')+'"  position="0" cellid="' + cellId + '" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '" value="' + v + '" onblur="calvalidData(this,\'' + datatype + '\',\'' + index + '\')" rowid="' + (rowCnt - 1) + '" colid="' + (colCnt - 1) + '" type="text"/></td>';
                    }else if (datatype == 2) {
                        tdInValue = '<textarea class="descView"  position="0" cellid="' + cellId + '" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '" rowid="' + (rowCnt - 1) + '" onblur="calvalidData(this,\'' + datatype + '\',\'' + index + '\')" colid="' + (colCnt - 1) + '">' + v + '</textarea>';
//                        tds[dt] = tds[dt] + tdText + 'class="a-center biddercell"  tableId="'+tableId+'">'
//                        +'<textarea   position="0" cellid="' + cellId + '" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '" rowid="' + (rowCnt - 1) + '" onblur="calvalidData(this,\'' + datatype + '\',\'' + index + '\')" colid="' + (colCnt - 1) + '">' + v + '</textarea></td>';
                    }else if (datatype == 6){//combo
                        var comboStr = comboBoxArray[v];
                        if(vals!=undefined){
                                comboStr = comboStr.replace('value="'+vals+'"','value="'+vals+'" selected');
                        }
                        tdInValue = '<select class="descView" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '"  onchange="calvalidData(this,\'' + datatype + '\',\'' + index + '\')" position="0" colid="' + (colCnt - 1) + '" rowid="' + (rowCnt - 1) + '" cellid="' + cellId + '">'+comboStr+'</select>';
//                        tds[dt] = tds[dt] + tdText + 'class="a-center biddercell"  tableId="'+tableId+'">'
//                        +'<select name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '"  onchange="calvalidData(this,\'' + datatype + '\',\'' + index + '\')" position="0" colid="' + (colCnt - 1) + '" rowid="' + (rowCnt - 1) + '" cellid="' + cellId + '">'+comboStr+'</select></td>';
                    }else if (datatype == 7){//date
                        tdInValue = '<input name="' + tableId + '_' + colCnt + '_' + cellNo + '" class="descView dateBox" id="' + tableId + '_' + colCnt + '_' + cellNo + '"   type="text" readonly="true" position="0" cellid="' + cellId + '" value="'+v+'"/>'
                        +'<a name="img' + tableId + '_' + colCnt + '_' + cellNo + '" style="position:absolute;" class="calender pull-right prefix1_1" id="img' + tableId + '_' + colCnt + '_' + cellNo + '" onmouseover="GetCal(\'' + tableId + '_' + colCnt + '_' + cellNo + '\',\'img' + tableId + '_' + colCnt + '_' + cellNo + '\',\'date\',$(\'input[id=\\\'' + tableId + '_' + colCnt + '_' + cellNo + '\\\'][position=\\\'0\\\']\').attr(\'position\'));" href="javascript:void(0);" position="0"/>';
//                        tds[dt] = tds[dt] + tdText + 'class="a-center biddercell"  tableId="'+tableId+'">'
//                        +'<input name="' + tableId + '_' + colCnt + '_' + cellNo + '" class="dateBox" id="' + tableId + '_' + colCnt + '_' + cellNo + '"   type="text" readonly="true" position="0" cellid="' + cellId + '" value="'+v+'"/>'
//                        +'<a name="img' + tableId + '_' + colCnt + '_' + cellNo + '" style="position:absolute;" class="calender pull-right prefix1_1" id="img' + tableId + '_' + colCnt + '_' + cellNo + '" onmouseover="GetCal(\'' + tableId + '_' + colCnt + '_' + cellNo + '\',\'img' + tableId + '_' + colCnt + '_' + cellNo + '\',\'date\',$(\'input[id=\\\'' + tableId + '_' + colCnt + '_' + cellNo + '\\\'][position=\\\'0\\\']\').attr(\'position\'));" href="javascript:void(0);" position="0"/></td>';                        
                    }else if (datatype == 8){//mf
                        var mfComp = ''
                        for(var mcnt=0;mcnt<masterFieldArray.length;mcnt++){
                            var masterFieldStr = masterFieldArray[mcnt];
                            var mfObjectId = masterFieldStr.split('@@@')[0];
                            var mfCompId = masterFieldStr.split('@@@')[1];
                            var mfDefValue = masterFieldStr.split('@@@')[2];
                            var mfSelValue = masterFieldStr.split('@@@')[3];
                            var mfValue = masterFieldStr.split('@@@')[4];
                            if(mfObjectId == v){
                                if(mfCompId==1){
                                    mfComp = '<input class="descView"  position="0" cellid="' + cellId + '" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '" value="' + (vals!=undefined ? vals : mfValue) + '" rowid="' + (rowCnt - 1) + '" colid="' + (colCnt - 1) + '" type="text"/>';
                                    break;
                                }else if(mfCompId==2){
                                    mfComp = '<textarea class="descView"  position="0" cellid="' + cellId + '" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '" rowid="' + (rowCnt - 1) + '" colid="' + (colCnt - 1) + '">' + (vals!=undefined ? vals : mfValue) + '</textarea>';
                                    break;                                    
                                }else if(mfCompId==3 || mfCompId==4){
                                    mfComp = '<select class="descView"  position="0" cellid="' + cellId + '" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '" rowid="' + (rowCnt - 1) + '" colid="' + (colCnt - 1) + '">';
                                    for(var fcnt=0; fcnt<mfSelValue.split(',').length; fcnt++){
                                        mfComp = mfComp + '<option value="'+(mfSelValue.split(',')[fcnt])+'" '+(vals!=undefined && mfSelValue.split(',')[fcnt]==vals ? 'selected' : mfSelValue.split(',')[fcnt]==mfDefValue ? 'selected' : '')+'>'+mfSelValue.split(',')[fcnt]+'</option>';
                                    }
                                    mfComp = mfComp + '</select>';
                                    break;                                    
                                }else if(mfCompId==6){
                                    mfComp = '<input name="' + tableId + '_' + colCnt + '_' + cellNo + '" class="descView dateBox" id="' + tableId + '_' + colCnt + '_' + cellNo + '"  type="text" readonly="true" position="0" cellid="' + cellId + '" value="'+(vals!=undefined ? vals : mfValue)+'"/>'
                                    +'<a name="img' + tableId + '_' + colCnt + '_' + cellNo + '" style="position:absolute;" class="calender pull-right prefix1_1" id="img' + tableId + '_' + colCnt + '_' + cellNo + '" onmouseover="GetCal(\'' + tableId + '_' + colCnt + '_' + cellNo + '\',\'img' + tableId + '_' + colCnt + '_' + cellNo + '\',\'date\',$(\'input[id=\\\'' + tableId + '_' + colCnt + '_' + cellNo + '\\\'][position=\\\'0\\\']\').attr(\'position\'));" href="javascript:void(0);" position="0"/>';
                                    break;                                    
                                }
                            }                            
                        }
                        tdInValue = mfComp;
//                        tds[dt] = tds[dt] + tdText + 'class="a-center biddercell"  tableId="'+tableId+'">'+mfComp+'</td>';
                    }else if (datatype == 9){//lb
                        var comboStr = listBoxArray[v];
                        if(vals!=undefined){
                            for(var cmbValCnt=0;cmbValCnt<vals.split(',').length;cmbValCnt++){
                                comboStr = comboStr.replace('value="'+(vals.split(',')[cmbValCnt])+'"','value="'+(vals.split(',')[cmbValCnt])+'" selected');
                            }
                        }
                        tdInValue = '<select class="descView" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '"  onchange="calvalidData(this,\'' + datatype + '\',\'' + index + '\')" size="4" multiple="" position="0" colid="' + (colCnt - 1) + '" rowid="' + (rowCnt - 1) + '" cellid="' + cellId + '">'+comboStr+'</select>';
//                        tds[dt] = tds[dt] + tdText + 'class="a-center biddercell"  tableId="'+tableId+'">'
//                        +'<select name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '"  onchange="calvalidData(this,\'' + datatype + '\',\'' + index + '\')" size="4" multiple="" position="0" colid="' + (colCnt - 1) + '" rowid="' + (rowCnt - 1) + '" cellid="' + cellId + '">'+comboStr+'</select></td>';
                    }
                } else if (ffilled == 3) {
                    if (datatype == 2){
                        tdInValue = '<textarea class="descView" rows="4" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '"   type="text" readonly="true" position="0" cellid="' + cellId + '" hdcolrow="auto_' + (rowCnt - 1) + '_' + (colCnt - 1) + '_' + index + '">'+v+'</textarea>';
//                        tds[dt] = tds[dt] + tdText + ' class="a-center">'
//                                + '<textarea rows="4" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '"   type="text" readonly="true" position="0" cellid="' + cellId + '" hdcolrow="auto_' + (rowCnt - 1) + '_' + (colCnt - 1) + '_' + index + '">'+v+'</textarea></td>';
                    }else{
                        tdInValue = '<input class="descView '+((isPriceBid==1 && (datatype == 3 || datatype == 4 || datatype == 5)) ? 'input-width' : '')+'" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '"   type="text" readonly="true" position="0" cellid="' + cellId + '" hdcolrow="auto_' + (rowCnt - 1) + '_' + (colCnt - 1) + '_' + index + '" value="'+v+'"/>';
//                        tds[dt] = tds[dt] + tdText + ' class="a-center">'
//                                + '<input class="'+((isPriceBid==1 && (datatype == 3 || datatype == 4 || datatype == 5)) ? 'input-width' : '')+'" name="' + tableId + '_' + colCnt + '_' + cellNo + '" id="' + tableId + '_' + colCnt + '_' + cellNo + '"   type="text" readonly="true" position="0" cellid="' + cellId + '" hdcolrow="auto_' + (rowCnt - 1) + '_' + (colCnt - 1) + '_' + index + '" value="'+v+'"/></td>';                       
                    }
                }else if (ffilled == 4) {//proxy
                    tdInValue = '<label id="lblproxy_'+cellId+'" position="0">'+getProxyData(cellId)+'</label>';
//                    tds[dt] = tds[dt] + tdText + ' class="a-center">'                    
//                    +'<label id="lblproxy_'+cellId+'" position="0">'+getProxyData(cellId)+'</label></td>';
                }
                tds[dt] = tds[dt] + tdText + tdInValue + tdClose;
            }
            tds[dt] = tds[dt] + '</tr>';            
            kk++;
            counter++;
        }
    }
//    console.log(tds);
    var notMappedRow = 0;    
    for (var td = 0; td < tds.length; td++) {
        var addRow = (isBidRowLimited == 'false') ? true : false;
        if(!addRow){            
            for (var tdd = 0; tdd < bidderRow[tableId].length; tdd++) {
                if(tds[td].indexOf('<tr id="'+eval((bidderRow[tableId][tdd])-1)+'">')!=-1){
                    addRow = true;
                }
            }
            if(!addRow){
                notMappedRow--;
            }
        }
        if(addRow){            
            $("#bodydata_"+tableId).append(tds[td]);
        }
    }
    if (tds.length != 0) {
        $('#hdcr_' + index).val(eval(parseInt(currRows) + counter));
    }
    if(isBidRowLimited == 'true'){        
        if(tableWiseNotGenRow[tableId] == undefined){
           tableWiseNotGenRow[tableId] = notMappedRow;                 
        }else{
            tableWiseNotGenRow[tableId] = tableWiseNotGenRow[tableId] + notMappedRow;
        }
    }    
    if(parseInt($('#hdcr_' + index).val()) + (tableWiseNotGenRow[tableId]==undefined ? 0 : tableWiseNotGenRow[tableId])==rowcount){
        $('#showmore_'+tableId).remove();
    }
    itemHoverDisplay();
}
function comboHideShow(comp) {
    var comboCellId = $(comp).attr('cellId');
    var ruleSubArr = ruleArr[comboCellId];
    if (ruleSubArr != undefined) {
        var cellVal = $(comp).val();
        for (var c = 0; c < ruleSubArr.length; c++) {
            var cRowId = ruleSubArr[c].split('@@')[0];
            var cTabId = ruleSubArr[c].split('@@')[1];
            var cCellVal = ruleSubArr[c].split('@@')[2];
            $('#rowtr_' + cRowId + '_' + cTabId).show();
            if (cellVal == '') {
                $('#rowtr_' + cRowId + '_' + cTabId).hide();
            } else {
                if (cellVal == cCellVal) {
                    $('#rowtr_' + cRowId + '_' + cTabId).hide();
                }
            }
        }
    }
}
function wordConvertForExcel(currRows) 
{
    try{
	if(currRows == undefined)
	   {
	    	currRows=0;
	    }
        if(strFormula.length > 0)
        {
            for(var indexI = 0;indexI< strFormula.length;indexI++)
            {
    		var str = (strFormula[indexI]).split(",");
    		for(var indexJ=0;indexJ<str.length;indexJ++){
    		   if(str[indexJ].indexOf("WORD") != -1)
         	    {
    			var toColumn = 	str[indexJ].split("@@")[0];
    			var fromColumn = (str[indexJ].split("@@")[1]);
    			fromColumn = fromColumn.replace('WORD(', '').replace(')', '');
    			fromColumn = fromColumn.split(",")[0];
    			fromColumn  = fromColumn - 1;
    			$("[colid="+fromColumn +"]").filter(function() {
    			  return $(this).attr("rowId") >= currRows;
    			}).each(function(){
    				var rowid = $(this).attr("rowId");
    				var wordData = convertToWord($(this).val(),wordConversion);
    				$("[colid="+(toColumn -1)+"][rowId="+rowid+"]").val(wordData);
    			});	
    		    }
        	 }
            }
        }
    }catch(err)
    {
	console.log(err);
    }
}
function setJsonData(excelDataArr) {
	var flag = false;
	try{
	    for (var excelCnt = 0; excelCnt < excelDataArr.length; excelCnt++) {
	        var tableId = tableIds[excelCnt];
	        var excelData = excelDataArr[excelCnt];
	        if (excelData != '' && excelData != 'nodata') {
	            var jsonObj = jQuery.parseJSON(excelData);
	            $.each(jsonObj, function() {
	                $.each(this, function(k, v) {
	                    if (k.indexOf('_') != -1) {
	                        var rowId = k.split('_')[0];
	                        var colId = parseInt(k.split('_')[1]);
	                        //console.log('rowId : '+rowId+' colId : '+colId);
	                        //console.log($('td[id="tdrow_'+rowId+'_'+colId+'"][class*="biddercell"]').html());
	                        var bidderTd = $('td[id^="tdrow_' + rowId + '_"][sorder="' + colId + '"][class*="biddercell"][tableId="' + tableId + '"]');
	                        if (bidderTd.html() != undefined) {
	                            var bidderCell = bidderTd.children();
	                            flag = true;
	                            if(!$(bidderCell).is("select")) {
	                            	bidderCell.val(v);
	                            } else {
	                            	bidderCell.val(v).attr("selected", "selected").change();
	                            }
	                            bidderCell.blur();
	                        }
	                        //                            console.log(rowId+'_'+colId+'_'+v+'@@'+'input[id=^"'+tableId+'_'+colId+'_"][rowid="'+rowId+'"]');
	                        //                            $('input[id=^"'+tableId+'_'+colId+'_"][rowid="'+rowId+'"]').val(v);
	                    }
	                });
	            });
	        }
	    }
      }catch(err){}
    return flag;
}