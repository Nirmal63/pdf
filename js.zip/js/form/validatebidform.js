/* 
 * @Author : TaherT
 */
var notEncrCellId = new Array();
var isbidForm = false;
function validateBidForm(isDraft) {  debugger
    var tbool = true;
    $('.errclass').remove();
    $('#rebateId').html('');
    $('#processCellId').html('');
    $('#docCellId').html('');
    $('#emdCellId').html('');
    $('#emdCellOfficerId').html('');
    $('#docCellOfficerId').html('');
    $('#participationCellOfficerId').html('');
    $('#notEncrCellId').html('');
    $('#bidTableRowId').html('');
    var cellValData = new Array();
    var formComponent = new Array();
    for (var i = 0; i < tableIds.length; i++) {
        var tcells = mformatArr[i];
        var bidCounter = (addTabCounter[tableIds[i]] == undefined ? 1 : addTabCounter[tableIds[i]]);
        for (var k = 0; k < bidCounter; k++) {
            var bidjson = '';
            for (var j = 0; j < tcells.length; j++) {
                var scells = tcells[j];
                var reqfields = 0;
                var filledfields = 0;
                for (var m = 0; m < scells.length; m++) {
                    var key = scells[m].toString().split("@@$$")[0].split("_");
                    var cellValue = scells[m].toString().split("@@$$")[1];
                    var flag;
                    if(isfromTermsheet == 'true'){
	
                       if(parseInt(key[1])==3){
                    	   var elementExists = document.getElementById('rtfck_'+key[4] + '_' + parseInt(key[1]) + '_' + key[0]);
                    	   	console.log('rtfck_'+key[4] + '_' + parseInt(key[1]) + '_' + key[0])
                    	   if(elementExists){

                      	cellValue=htmlReplaceQuotes(replaceQuotes(CKEDITOR.instances['rtfck_'+key[4] + '_' + parseInt(key[1]) + '_' + key[0]].getData()));
                      	 	$("#" + key[4] + '_' + key[1] + '_' + key[0]).val(cellValue);
                      	 	console.log(cellValue);
                      	 	
                       }
            		   }
            		     flag = cellValue != '';
            		}
            		else
            		{
            		      flag=cellValue == ''
            		}
           
                    if (flag  || key[3] == dtcombo || key[3] == dtlistbox || key[3] == dtmasterfield) {                        
                        var cellNo = key[0];
                        var colCnt = parseInt(key[1]);
                        var tableId = key[4];
                        var cellId = key[6];
                        var datatype = key[3];
                        var inputCell = $('input[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + k + '"]');
                        var selectCell = $('select[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + k + '"]');
                        if(isPriceBid!=1){ //Changes done for BUG #49933
                        /*  Changes done for BUG #48520  */
                        if(datatype==6 && $("#errDiv_"+ tableId + '_' + colCnt + '_' + cellNo+"_"+ datatype).length > 0){
                          $("#errDiv_"+ tableId + '_' + colCnt + '_' + cellNo+"_"+ datatype).remove();
                        }
                        if(datatype==6 && selectCell.val()==null){
                        	selectCell.focus();
                        	selectCell.closest('td').append('<div id="errDiv_' + tableId + '_' + colCnt + '_' + cellNo +"_"+ datatype + '" style="color:red;">Please select proper value</div>');
                        	alert("Please select value for row no "+(j+1));
                        	tbool = false;
                         }
                        }
                        if(inputCell.val() == undefined){
                            inputCell = $('textarea[id="' + tableId + '_' + colCnt + '_' + cellNo + '"][position="' + k + '"]');
                            if(inputCell.val() != undefined && selectCell.val() != undefined){
                                inputCell.val(htmlReplaceQuotes(replaceQuotes(inputCell.val())));
                                inputCell = $('input[id="abc"][position="' + k + '"]');
                            }
                        }
                        var grantTCell = $('input[cellidno="' + cellId + '_' + cellNo + '"]');
                        if (inputCell.val() != undefined && inputCell.parent().parent().is(":visible")) {                            
                            inputCell.blur();
                            formComponent.push(inputCell);
                            reqfields++;
                            var isAutoCell = (inputCell.attr('hdcolrow')!=undefined);
                            if (inputCell.val() != '') {
                                var compId = inputCell.attr('id');
                                $('.err'+compId+'_'+k).remove();
                                if(tbool && !isAutoCell){
                                    /*if(datatype == 1 || datatype == 2){ smalltext || longtext
                                        if($.trim(inputCell.val()) != "" && (!/^([0-9a-zA-Z\!\$\#\^\s\&\_\[\]\:\;\?\|\@\*\(\)\-\+\.\/\,\\]*)[0-9a-zA-Z\.]+([0-9a-zA-Z\!\$\#\^\s\&\_\[\]\:\;\?\|\@\*\(\)\-\+\.\/\,\\]*)$/.test(inputCell.val())) || (/\-{2}/.test(inputCell.val()))) {                                              
                                            $(inputCell).parent().append("<div class='err"+compId+"_"+k+"' style='color:red;'>"+MSG_SMALLLONGTEXT+"</div>");
                                            $(inputCell).focus();
                                            tbool = false;
                                        }
                                    }else*/ if(datatype == 3){ //datatype_numeric
                                        if($.trim(inputCell.val()) != "" && !/^([0-9]){0,15}$/.test(inputCell.val())) {
                                            $(inputCell).parent().append("<div class='err"+compId+"_"+k+"' style='color:red;'>"+MSG_WITHOUTDEC+"</div>");
                                            $(inputCell).focus();
                                            tbool = false;
                                        }                         
                                    }else if(datatype == 4){ //datatype_money
                                        var NUMERICWITHDECIMAL = "^(\\d{1,15}|\\d{1,15}\\.\\d{1,"+decimalUpto+"})$";
                                        var decimalRegex = new RegExp(NUMERICWITHDECIMAL);        
                                        if($.trim(inputCell.val()) != "" && !decimalRegex.test(inputCell.val())) {
                                            $(inputCell).parent().append("<div class='err"+compId+"_"+k+"' style='color:red;'>"+MSG_DECUPTO+" "+decimalUpto+" places</div>");
                                            $(inputCell).focus();
                                            tbool = false;
                                        }                         
                                    }else if(datatype == 5){ //datatype_money_all        
                                        var NUMERICWITHDECIMALM = "^-?(\\d{1,15}|\\d{1,15}\\.\\d{1,"+decimalUpto+"})$";
                                        var decimalRegexM = new RegExp(NUMERICWITHDECIMALM);
                                        if($.trim(inputCell.val()) != "" && !decimalRegexM.test(inputCell.val())) {
                                            $(inputCell).parent().append("<div class='err"+compId+"_"+k+"' style='color:red;'>"+MSG_ALLNUMBERS+" "+decimalUpto+" places</div>");
                                            $(inputCell).focus();
                                            tbool = false;
                                        }                         
                                    }else if(datatype == 7){
                                    	var dateFromat = CLIENT_DATEFORMATE;
                                    	if(dateFromat=="DD/MM/YYYY" && inputCell.val().match(/(0[1-9]|1\d|2\d|3[01])\/(0[1-9]|1[0-2])\/\d{4}/)){
                                    		tbool = true;
                                    	}else if(dateFromat=="MM/DD/YYYY" && inputCell.val().match(/(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/\d{4}/)){
                                    		tbool = true;
                                    	}else{
                                    		$(inputCell).parent().append("<div class='err"+compId+"_"+k+"' style='color:red;'>"+MSG_DATE_DDMMYYYY+"</div>");
                                            $(inputCell).focus();
                                            tbool = false;
                                    	}
                                    if(tbool){
                                    	var date = new Date(inputCell.val()),mnth = ("0" + (date.getMonth()+1)).slice(-2),
                            	        day  = ("0" + date.getDate()).slice(-2);
                            			if(dateFromat == "DD/MM/YYYY"){
                                   	    	data = day+"/"+mnth+"/"+date.getFullYear();
                                   	    }else if(dateFromat == "MM/DD/YYYY"){
                                   	    	data = mnth+"/"+day+"/"+date.getFullYear();
                                   	    }else if(dateFromat == "DD MMM YYYY"){
                                   	    	data = day+" "+mnth+" "+date.getFullYear();
                                   	    }
                                    }
                                    }
                                }
                                bidjson = bidjson + '{"' + cellId + '_' + cellNo + '":"' + ((datatype == 1 || datatype == 2|| isfromTermsheet=='true'||JSisBidSavedInDraft == 'true') ? htmlReplaceQuotes(replaceQuotes(inputCell.val()).replace(/\n/g,' ')) : inputCell.val().replace(/\n/g,' ')) + '"},';
                                // bidjson = bidjson + '{"' + cellId + '_' + cellNo + '":"' + ((datatype == 1 || datatype == 2 ) ? inputCell.val().replace(/\n/g,' ') : inputCell.val().replace(/\n/g,' ')) + '"},';
                                if(key[3] == dtdate){
                                    formComponent.push($('a[id="img'+tableId+'_'+colCnt+'_'+cellNo+'"][position="'+k+'"]'));                                    
                                }
                                filledfields++;
                            }
                            else {
                            	if(!isbidForm || isItemSelectionPageRequired == 1)
                            	{	
                                    if (!isDraft && !isAutoCell && isPartialFillingAllowedForTender != 1) {
                                        inputCell.parent().append("<div class='errclass' style='color:red;'>"+MSG_PLEASEENTERVAL+"</div>");
                                        if(!isAutoCell){
                                            inputCell.focus();
                                        }
                                        tbool = false;
                                    }/*else if (!isDraft && !isAutoCell && isPartialFillingAllowedForTender == 1 && isItemSelectionPageRequired == 1) {
                                    	var isTablePartialFillingAllowNew = tablePartialMandatory[i][0];
                                    	var bidderRfilledCellNew = 0;
                                    	if (isTablePartialFillingAllowNew == 1)
                                	    {
                                	    	var vTrCompNew = inputCell.parent().parent();
                                	    	$(vTrCompNew).find('.biddercell').each (function() {
                                	    		if($(this).children().val() != "" && $(this).children().val() != null)
                                	    		{
                                	    			bidderRfilledCellNew++;
                                	    		}
                                	    	}); 
                                	    }
                                	    else
                                	    {
                                	    	inputCell.parent().append("<div class='errclass' style='color:red;'>"+MSG_PLEASEENTERVAL+"</div>");
                                            if(!isAutoCell){
                                                inputCell.focus();
                                            }
                                            tbool = false;
                                	    }
                                    	 if (!isDraft && bidderRfilledCellNew != 0 && isPriceBid == 1) {
                                    		 inputCell.parent().append("<div class='errclass' style='color:red;'>"+MSG_PLEASEENTERVAL+"</div>");
                                    		 inputCell.focus();
                                             tbool = false;
                                         }
                                    }*/
                            	}
                            }
                        }
                        if ((selectCell.val() != undefined || (selectCell.attr('multiple'))) && selectCell.parent().parent().is(":visible")) {  
                            var selRemarks = $('textarea[id="'+selectCell.attr('id')+'"][position="'+selectCell.attr('position')+'"]');
                            if(selRemarks.val() != undefined){
                                if($.trim(selRemarks.val()) == ''){
                                    selRemarks.parent().append("<div class='errclass' style='color:red;'>"+MSG_BID_REMARKS+"</div>");
                                    selRemarks.focus();
                                    tbool = false;
                                }else{
                                    formComponent.push(selRemarks);
                                }
                            }
                            selectCell.change();
                            formComponent.push(selectCell);
                            reqfields++;
                            if (selectCell.val() != '' && selectCell.val() != null) {
                            	if(selectCell.attr('multiple'))
                            	{
                            		bidjson = bidjson + '{"' + cellId + '_' + cellNo + '":"' + selectCell.val() +((selRemarks.val()!=undefined) ? '@@'+replaceQuotes(selRemarks.val()).replace(/\\r/g,' ').replace(/\\n/g,' ').replace(/\\t/g,' ') : '')+ '"},';
                            	}
                            	else
                            	{
	                            	var selCellOptionText = selectCell[0].selectedOptions[0].text;
	                            	bidjson = bidjson + '{"' + cellId + '_' + cellNo + '":"' + selectCell.val()+"###"+ selCellOptionText +"###"+((selRemarks.val()!=undefined) ? '@@'+replaceQuotes(selRemarks.val()).replace(/\\r/g,' ').replace(/\\n/g,' ').replace(/\\t/g,' ') : '')+ '"},';
                            	}
                            	filledfields++;
                            } else {
                            	var bidderRfilledCell = 0;
                            	if(isBidder && tenderResult == 2 && isPriceBid == 1)
                                {
                                	var isTablePartialFillingAllow = tablePartialMandatory[i][0];
                            	    if (isTablePartialFillingAllow == 1)
                            	    {
                            	    	var vTrComp = selectCell.parent().parent();
                            	    	$(vTrComp).find('.biddercell').each (function() {
                            	    		if ($(this).children().val() != "" && $(this).children().val() != null)
                            	    		{
                            	    			bidderRfilledCell++;
                            	    		}
                            	    	}); 
                            	    }
                            	    else
                            	    {
                                        selectCell.parent().append("<div class='errclass' style='color:red;'>"+MSG_PLEASESELVAL+"</div>");
                                        selectCell.focus();
                                        tbool = false;
                            	    }
                            	  
                                }
                                if ((!isDraft && bidderRfilledCell!=0) || isPriceBid!=1) {
                                    selectCell.parent().append("<div class='errclass' style='color:red;'>"+MSG_PLEASESELVAL+"</div>");
                                    selectCell.focus();
                                    tbool = false;
                                }
                            }
                        }
                        if (k == (bidCounter - 1) && grantTCell.val() != undefined) {
                            grantTCell.blur();
                            formComponent.push(grantTCell);
//                                            reqfields++;
                            for (var p = 0; p < rebateId.length; p++) {
                                var rcellId = rebateId[p].toString().split('@@@');
                                if (cellId == rcellId[0]) {
                                    var rdata = $('#rebateId').html();
                                    $('#rebateId').html(rdata + '<input type="hidden" value="' + rcellId[1] + '@@@' + signEncryptCellValueData(grantTCell.val(), bidpkey, bidpkey2) + '" name="skpRebateCell_' + tableId + '"/>');
                                }
                            }                            
                            bidjson = bidjson + '{"' + cellId + '_' + cellNo + '":"' + grantTCell.val() + '"},';
//                                            filledfields++;
                        }
                    }
                }
                if (isDraft && (filledfields != 0 && filledfields != reqfields)) {
                        jAlert(MSG_SAVEASDRAFT,MSG_BIDSUBMITHEAD, function(RetVal) {
                        });
                    tbool = false;
                    break;
                }
            }
            var bidTableData = '[' + bidjson.substring(0, bidjson.length - 1) + ']';
            cellValData.push(bidTableData);
        }
    }
    if(isbidForm && tbool && isItemSelectionPageRequired == 0)
    {
    	tbool = tableValidate(formComponent,isDraft);
    }	
    if(isbidForm && tbool && isItemSelectionPageRequired == 1 && isPartialFillingAllowedForTender == 1)
    {
    	tbool = tableValidateNew(formComponent,isDraft);
    }
    var dataArr = new Array();
    if (tbool) {
        var falseCnt=0;
        for(var jk=0;jk<cellValidated.length;jk++){
            if(cellValidated[jk].parent().parent().html().indexOf('<div class="err')!=-1){
                falseCnt++;   
            }
        }        
        if(falseCnt==0){
            dataArr.push(cellValData);
            dataArr.push(formComponent);
//            for (var d = 0; d < formComponent.length; d++) {
                for (var p = 0; p < processCellId.length; p++) {
                    var rcellId = processCellId[p].toString().split('@@@');
                    var pcellval = $('input[cellidno^="'+rcellId[0]+'"]').val();
                    if(pcellval == undefined){
                        pcellval = $('input[cellid="'+rcellId[0]+'"]').val();                        
                    }
                    if (pcellval != undefined) {
                        var rdata = $('#processCellId').html();
                        $('#processCellId').html(rdata + '<input type="hidden" value="' + rcellId[1] + '@@@' + signEncryptCellValueData(pcellval, bidpkey, bidpkey2) + '" name="skpProcessCell_' + tableId + '"/>');
                    }
                }
                for (var p = 0; p < docCellId.length; p++) {
                    var rcellId = docCellId[p].toString().split('@@@');
                    var dcellval = $('input[cellidno^="'+rcellId[0]+'"]').val();
                    if(dcellval == undefined){
                        dcellval = $('input[cellid="'+rcellId[0]+'"]').val();                        
                    }
                    if (dcellval != undefined) {
                        var rdata = $('#docCellId').html();
                        $('#docCellId').html(rdata + '<input type="hidden" value="' + rcellId[1] + '@@@' + dcellval + '" name="skpDocCell_' + tableId + '"/>');
                    }
                }
                for (var p = 0; p < emdCellId.length; p++) {
                    var rcellId = emdCellId[p].toString().split('@@@');
                    var ecellval = $('input[cellidno^="'+rcellId[0]+'"]').val();
                    if(ecellval == undefined){
                        ecellval = $('input[cellid="'+rcellId[0]+'"]').val();                        
                    }
                    if (ecellval != undefined) {
                        var rdata = $('#emdCellId').html();
                        $('#emdCellId').html(rdata + '<input type="hidden" value="' + rcellId[1] + '@@@' + ecellval + '" name="skpEmdCell_' + tableId + '"/>');
                    }
                }
                for (var p = 0; p < emdCellOfficerId.length; p++) {
                    var rcellId = emdCellOfficerId[p].toString().split('@@@');
                    var ecellval = $('input[cellidno^="'+rcellId[0]+'"]').val();
                    if(ecellval == undefined){
                        ecellval = $('input[cellid="'+rcellId[0]+'"]').val();                        
                    }
                    if (ecellval != undefined) {
                        var rdata = $('#emdCellOfficerId').html();
                        $('#emdCellOfficerId').html(rdata + '<input type="hidden" value="' + rcellId[1] + '@@@' + ecellval + '@@@' + p + '" name="skpEmdCellOfficer_' + tableId + '"/>');
                    }
                }
                for (var p = 0; p < participationCellOfficerId.length; p++) {
                    var rcellId = participationCellOfficerId[p].toString().split('@@@');
                    var ecellval = $('input[cellidno^="'+rcellId[0]+'"]').val();
                    if(ecellval == undefined){
                        ecellval = $('input[cellid="'+rcellId[0]+'"]').val();                        
                    }
                    if (ecellval != undefined) {
                        var rdata = $('#participationCellOfficerId').html();
                        $('#participationCellOfficerId').html(rdata + '<input type="hidden" value="' + rcellId[1] + '@@@' + ecellval +  '@@@' + p + '" name="skpParticipationCellOfficer_' + tableId + '"/>');
                    }
                }
                for (var p = 0; p < docCellOfficerId.length; p++) {
                    var rcellId = docCellOfficerId[p].toString().split('@@@');
                    var ecellval = $('input[cellidno^="'+rcellId[0]+'"]').val();
                    if(ecellval == undefined){
                        ecellval = $('input[cellid="'+rcellId[0]+'"]').val();                        
                    }
                    if (ecellval != undefined) {
                        var rdata = $('#docCellOfficerId').html();
                        $('#docCellOfficerId').html(rdata + '<input type="hidden" value="' + rcellId[1] + '@@@' + ecellval + '@@@' + p + '" name="skpDocCellOfficer_' + tableId + '"/>');
                    }
                }
                for (var p = 0; p < notEncrCellId.length; p++) {
                    var rcellId = notEncrCellId[p].toString().split('@@@');
                    var ecellval = $('input[cellidno^="'+rcellId[0]+'"]').val();
                    if(ecellval == undefined){
                        ecellval = $('input[cellid="'+rcellId[0]+'"]').val();                        
                    }
                    if (ecellval != undefined) {
                        var rdata = $('#notEncrCellId').html();
                        $('#notEncrCellId').html(rdata + '<input type="hidden" value="' + rcellId[1] + '@@@' + ecellval+ '" name="skpNotEncrCell_' + tableId + '"/>');
                    }
                }
                var tableRowIds = new Array();
                for (var d = 0; d < formComponent.length; d++) {
                    var compRowId = $(formComponent[d]).attr('rowid');
                    if(compRowId!=undefined && tableRowIds.toString().indexOf(($(formComponent[d]).attr('id').split('_')[0])+"_"+compRowId)==-1 && $(formComponent[d]).val()!=''){
                         tableRowIds.push(($(formComponent[d]).attr('id').split('_')[0])+"_"+compRowId);
                    }
                }
                if (tableRowIds.length != 0) {
                    $('#bidTableRowId').html('<input type="hidden" value="' +tableRowIds+ '" name="abcdTableRow"/>');
                }
//            }
        }
    }
    return dataArr;
}
function saveAsDraft() {  
    var finalFormData = validateBidForm(true);
    var tbool = (finalFormData.length != 0);
    if (tbool) {
        tbool = false;
        var jsonDataFinal = finalFormData[0];
        var mCounter = 0;
        for (var i = 0; i < tableIds.length; i++) {
            var bidCounter = (addTabCounter[tableIds[i]] == undefined ? 1 : addTabCounter[tableIds[i]]);
            for (var k = 0; k < bidCounter; k++) {
                //var draftBid = signNencryptBidData(jsonDataFinal[mCounter], bidpkey,bidpkey2);
                //var draftEnc = signNencryptData(jsonDataFinal[mCounter], bidpkey);      
				var draftBid = jsonDataFinal[mCounter];
                var draftEnc = jsonDataFinal[mCounter];          
                if(draftBid!='' && (draftBid!='false' && draftBid!='False' && draftBid!=false) && draftEnc!='' && (draftEnc!='false' && draftEnc!='False' && draftEnc!=false)){                    
                    $('input[id="tableBid_' + tableIds[i] + '"][position="' + k + '"]').val(encryptionReq==1 ? draftBid : jsonDataFinal[mCounter]);
                    $('input[id="tableEnc_' + tableIds[i] + '"][position="' + k + '"]').val(draftEnc);                
                    mCounter++;
                }
            }
        }
        if (jsonDataFinal.length == mCounter) {
            var bidFormComp = finalFormData[1];
            var emptyCounter=0;
            for (var d = 0; d < bidFormComp.length; d++) {
                if($.trim($(bidFormComp[d]).val())==''){
                    emptyCounter++;                    
                }
            }
            if(emptyCounter!=bidFormComp.length){
                for (var d = 0; d < bidFormComp.length; d++) {
                    
                    $(bidFormComp[d]).attr('disabled', true);
                }
                $('#hdFormActionS').remove();
                tbool = true;
            }else{                
                jAlert(MSG_SAVEASDRAFT, MSG_BIDSUBMITHEAD, function(RetVal) {
                }); 
            }
        }else{
             jAlert(MSG_BIDPROBLEM, MSG_BIDSUBMITHEAD, function(RetVal) {
             }); 
        }
        
 if(isfromTermsheet== 'true' ){//&& JSisBidSavedInDraft == 'true'
		for (var b = 0; b < tableIds.length; b++) {
			//var rowCount=$('#bodydata_'+tableIds[b]+ ' tr').length;
			//alert(JSisBidSavedInDraft)
		var rowCount =$('#bodydata_'+tableIds[b]).children().length;
			for (var m = rowCount*3; m< rowCount*3+rowCount; m++) {
				  var elementExists = document.getElementById('rtfck_'+tableIds[b] + '_3_' + m);
                     if(elementExists){
							CKEDITOR.instances['rtfck_'+tableIds[b]+'_3_'+m].setData('');
						}
            }	
         }
   }
        
    }
    return disableBtn(tbool);
//                    return false;
}
function viewMasterData() {  
    var errorCnt = 0;
    for (var b = 0; b < tableIds.length; b++) {
        var mcount = setBidData(b, tableIds[b], bidpkey,bidpkey2,true);
        errorCnt += mcount;
    }
    if(errorCnt!=0){
        jAlert(MSG_BID_MASTERDATA, MSG_BIDSUBMITHEAD, function(RetVal) {
        });
    }else{
        $('.viewDataBtn').remove();        
    }
}


function decryptTermsSheetForm(rowCount , tableId) {  
	//call web searvice
	var data = {};
	data["bidId"]=bidId;
	data["formId"]=formId;
	$.ajax({ 
		type: "POST",
		url: contextPath+"/etender/bidder/editbid", //function that in web service
		data : {
			bidId : bidId,
			formId : formId
		},
		dataType: "json",
		sync: true,
		success: function(response) {
			if(response ==false) {
				jAlert(MSG_NO_REC_FOUND, MSG_BID_DEC_FAILED, function(RetVal) {
				});
				$('.decryptBtn').attr('disabled',true);
			}
			else if(response ==true) {
				var errorCnt = 0;
				for (var b = 0; b < tableIds.length; b++) {
					var mcount = setBidData(b, tableIds[b], bidpkey,bidpkey2,false);
					errorCnt += mcount;        
				}
				if(errorCnt==0){
					$('.decryptBtn').remove();
					$('.saveAsDraftBtn').removeAttr('disabled');
					if(isPki){
						$('.signBtn').removeAttr('disabled');
						$('#signtr').show();
						$('#dataencryption').val('');
						jAlert((encryptionReq==1 ? MSG_BIDDATADECNVERIFY : MSG_BIDDATAVERIFY), MSG_BIDSUBMITHEAD, function(RetVal) {
						});
					}else{
						$('.saveBtn').removeAttr('disabled');            
					}
				}else if(errorCnt<0 && errorCnt!=-1){
					jAlert(MSG_CERTNEEDINSTALL, MSG_BIDSUBMITHEAD, function(RetVal) {
					});
					$('.decryptBtn').attr('disabled',true);
				}else if(errorCnt>0){
					jAlert((encryptionReq==1 ? MSG_BIDDATADECNVERIFYFAIL : MSG_BIDDATAVERIFYFAIL), MSG_BIDSUBMITHEAD, function(RetVal) {
					});
					$('.decryptBtn').attr('disabled',true);
				}
				else if(errorCnt==-1){
					jAlert(MSG_NO_REC_FOUND, MSG_BID_DEC_FAILED, function(RetVal) {
					});
					$('.decryptBtn').attr('disabled',true);
				}
			}
			var negoFlag = $('#isNegotiationCountData').val().trim();
			negoFlag=negoFlag.replaceAll('[','');
			negoFlag=negoFlag.replaceAll(']','');
			negoFlag=negoFlag.replaceAll(' ','');
			var negoArr = negoFlag.split(',');
		//	negoArr = negoFlag.replaceAll(',','');
				var y=0; 
			for (var b = 0; b < tableIds.length; b++) {
			rowCount =$('#bodydata_'+tableIds[b]).children().length;
			
			for (var m = rowCount*3; m< rowCount*3+rowCount; m++) {
			var x;	
				
            	  var negoVal = negoArr[y];
            	   if(negoVal == '1'){
						//console.log("#"+tableIds[b]+'_3_'+m)
	               		x=$("#"+tableIds[b]+'_3_'+m).val();	console.log(x)
	               		if(x!= undefined){
            	  			CKEDITOR.instances['rtfck_'+tableIds[b]+'_3_'+m].setData(x);
            	  		}
            	   }
            		y++;
            }
            }
			
		},
		error: function(msg) {
			/* $(".record").html(msg.d); */
		}

	});

}

function decryptForm() {
	//call web searvice
	var data = {};
	data["bidId"]=bidId;
	data["formId"]=formId;
	$.ajax({ 
		type: "POST",
		url: contextPath+"/etender/bidder/editbid", //function that in web service
		data : {
			bidId : bidId,
			formId : formId
		},
		dataType: "json",
		sync: true,
		success: function(response) {
			if(response ==false) {
				jAlert(MSG_NO_REC_FOUND, MSG_BID_DEC_FAILED, function(RetVal) {
				});
				$('.decryptBtn').attr('disabled',true);
			}
			else if(response ==true) {
				var errorCnt = 0;
				for (var b = 0; b < tableIds.length; b++) {
					var mcount = setBidData(b, tableIds[b], bidpkey,bidpkey2,false);
					errorCnt += mcount;        
				}
				if(errorCnt==0){
					$('.decryptBtn').remove();
					$('.saveAsDraftBtn').removeAttr('disabled');
					if(isPki){
						$('.signBtn').removeAttr('disabled');
						$('#signtr').show();
						$('#dataencryption').val('');
						jAlert((encryptionReq==1 ? MSG_BIDDATADECNVERIFY : MSG_BIDDATAVERIFY), MSG_BIDSUBMITHEAD, function(RetVal) {
						});
					}else{
						$('.saveBtn').removeAttr('disabled');            
					}
				}else if(errorCnt<0 && errorCnt!=-1){
					jAlert(MSG_CERTNEEDINSTALL, MSG_BIDSUBMITHEAD, function(RetVal) {
					});
					$('.decryptBtn').attr('disabled',true);
				}else if(errorCnt>0){
					jAlert((encryptionReq==1 ? MSG_BIDDATADECNVERIFYFAIL : MSG_BIDDATAVERIFYFAIL), MSG_BIDSUBMITHEAD, function(RetVal) {
					});
					$('.decryptBtn').attr('disabled',true);
				}
				else if(errorCnt==-1){
					jAlert(MSG_NO_REC_FOUND, MSG_BID_DEC_FAILED, function(RetVal) {
					});
					$('.decryptBtn').attr('disabled',true);
				}
			}
		},
		error: function(msg) {
			/* $(".record").html(msg.d); */
		}

	});

}
function signForm() {
	if(isCgClient == true && isPriceBid == 1 && tableIds.length==2){
		
		/***** If Duplicate Priority ****/
		var priorityEle = [];
		var priority = [];
		var priorityDuplicated = false;
		var zeroPriority = false;
		
		$("#table_"+tableIds[1]).find('> tbody > tr > td:first-child ').each(function (){
			
			$(this).find('> input ').each(function (){
				var value = $(this).val();
				if(value != null && value != '')
				{					
					for(var i=0;i<priority.length;i++)
					{
						$(this).parent().children('div').remove();
							if(priority[i] == value)
							{
								priorityDuplicated = true;
								$(this).focus();
								$(this).parent().closest('td').append('<div style="color:red;">Duplicate priority</div>');
								priorityEle.push(this);
								break;
							}
					}
					priority.push(value);
				}
			});
			
		});
		if(priorityEle.length>0)
		{
			alert("Duplicate priority");
			return false;
		}
		
		$("#table_"+tableIds[1]).find('> tbody > tr > td:nth-child(1)').each(function (){
			$(this).find('> input ').each(function (){
				var priorityValue = $(this).val();
				$(this).parent().children('div').remove();
				if(priorityValue != null && priorityValue != ''){
					if(priorityValue == 0){
						$(this).focus();
						$(this).parent().closest('td').append('<div style="color:red;">Priority cannot be Zero</div>');
						zeroPriority = true;
					}
				}
			});
		});
		if(zeroPriority == true){
			alert("Priority cannot be Zero");	
			return false;
		}
		
		/***** If Priority cannot be greater than total priority ****/
		
		var valueTotalLot;
		$("#table_"+tableIds[0]).find('> tbody > tr > td:nth-child(6)').each(function (){
			$(this).find('> input ').each(function (){
				valueTotalLot = $(this).val();
			});
		});
		var priorityFlag = false;
		$("#table_"+tableIds[1]).find('> tbody > tr > td:nth-child(1)').each(function (){
			$(this).find('> input ').each(function (){
				var priorityValue = $(this).val();
				$(this).parent().children('div').remove();
				if(parseInt(priorityValue,10)>parseInt(valueTotalLot,10)){
					$(this).focus();
					$(this).parent().closest('td').append('<div style="color:red;">Priority cannot be greater than total lots</div>');
					priorityFlag = true;
				}
			});
		});
		if(priorityFlag == true){
			alert("Priority cannot be greater than total lots");	
			return false;
		}
		
      /***** If Price value of lot is greater than Purchase Capacity ****/
		
		var emdPurchaseCapacity;
		$("#table_"+tableIds[0]).find('> tbody > tr >td:nth-child(2)').each(function (){
			$(this).find('> input ').each(function (){
				emdPurchaseCapacity = $(this).val();
			});
		});
		
		var purchaseRateBiddingFlag = false;
		$("#table_"+tableIds[1]).find('> tbody > tr >td:nth-child(5)').each(function (){
			$(this).find('> input ').each(function (){
				var idCompare = "gt_"+tableIds[1]+"_5_1"
				var id = $(this).attr("id");
			  if(id!=idCompare){
				var purchaseRateQty = $(this).val();
				$(this).parent().children('div').remove();
				if(parseInt(purchaseRateQty,10)>parseInt(emdPurchaseCapacity,10)){
					$(this).focus();
					$(this).parent().closest('td').append('<div style="color:red;">Price value of lot is greater than Purchase Capacity</div>');
					purchaseRateBiddingFlag = true;
				}
			   }
			});
		});
		
		if(purchaseRateBiddingFlag == true){
			alert("Price value of lot is greater than Purchase Capacity");	
			return false;
		}
		
      /***** If Total Price Value of lots is greater than 10 times of Purchase Capacity ****/
		
		var emdBiddingCapacity;
		$("#table_"+tableIds[0]).find('> tbody > tr >td:nth-child(3)').each(function (){
			$(this).find('> input ').each(function (){
				emdBiddingCapacity = $(this).val();
			});
		});
		
		var totalPurchaseCapacityFlag = false;
		$("#table_"+tableIds[1]).find('> tbody > tr >td:nth-child(5)').each(function (){
			$(this).find('> input ').each(function (){
				var idCompare = "gt_"+tableIds[1]+"_5_1"
				var id = $(this).attr("id");
			     if(id==idCompare){
			    	var totalPurchaseCapacity = $(this).val();
			    	$(this).parent().children('div').remove();
					if(parseInt(totalPurchaseCapacity,10)>parseInt(emdBiddingCapacity,10)){
						$(this).focus();
						$(this).parent().closest('td').append('<div style="color:red;">Total Price Value of lots is greater than 10 times of Purchase Capacity</div>');
						totalPurchaseCapacityFlag = true;
					}
			    }
			});
		});	
		
		if(totalPurchaseCapacityFlag == true){
			alert("Total Price Value of lots is greater than 10 times of Purchase Capacity");	
			return false;
		}
	}
	
	var value = checkCertificateVerification(1);
	if(value == 'false')
	{
		alert("Signing Certificate is Not Verified");
		return false;
	}
	else if(value != undefined)
	{
		var signStr = '';
	    var finalFormData = validateBidForm(isPartialFillingAllowed);
	    var tbool = (finalFormData.length != 0);
	    if (tbool) {
	        tbool = false;        
	        var showMoreCnt = 0;
	        for (var i = 0; i < tableIds.length; i++) {
	            if($('#hdcr_'+i).val()!=undefined){
	                 if(eval(parseInt($('#hdcr_'+i).val()) + (tableWiseNotGenRow[tableIds[i]] != undefined ? tableWiseNotGenRow[tableIds[i]] : 0))  != $('#hd_'+i).val()){
	                 //   showMoreCnt++; // to remove show more from bidder side 
	                }
	            }
	        }
	        if(showMoreCnt==0){
	            var jsonDataFinal = finalFormData[0];
	            var mCounter = 0;
	            var isValidSigned = true;
	            for (var i = 0; i < tableIds.length; i++) {
	                var bidCounter = (addTabCounter[tableIds[i]] == undefined ? 1 : addTabCounter[tableIds[i]]);
	                for (var k = 0; k < bidCounter; k++) {
	                    var bidTableData = signData(jsonDataFinal[mCounter], bidpkey);
	                    
	                    if(bidTableData == '' || bidTableData == false || bidTableData == 'false' || bidTableData == 'False'){
                            isValidSigned = false;                            
                        }
	                    signStr = signStr + bidTableData;
	                    $('input[id="tableBid_' + tableIds[i] + '"][position="' + k + '"]').val(encryptionReq==1 ? bidTableData : jsonDataFinal[mCounter]);
	                    $('input[id="tableEnc_' + tableIds[i] + '"][position="' + k + '"]').val(bidTableData);
	                    mCounter++;
	                }
	            }            
	            if (isValidSigned && jsonDataFinal.length == mCounter) {
	                var bidFormComp = finalFormData[1];
	                if(isPartialFillingAllowed){
	                    var emptyCounter=0;
	                    for (var d = 0; d < bidFormComp.length; d++) {
	                        if($.trim($(bidFormComp[d]).val())==''){
	                            emptyCounter++;                    
	                        }
	                    }
	                    if(emptyCounter!=bidFormComp.length){
	                        for (var d = 0; d < bidFormComp.length; d++) {//same as code 1
	                            $(bidFormComp[d]).attr('disabled', true);//same as code 1
	                        }//same as code 1
	                        tbool = true;
	                    }else{
	                        jAlert('Please enter data in at least 1 row', MSG_BIDSUBMITHEAD, function(RetVal) {
	                        });
	                    }
	                }else{
	                    for (var d = 0; d < bidFormComp.length; d++) {//code 1
	                        $(bidFormComp[d]).attr('disabled', true);//code 1
	                    }//code 1
	                    tbool = true;
	                }                
	            }
	            else{
	                jAlert('Signing failed. Pl. try again.', MSG_BIDSUBMITHEAD, function(RetVal) {
	                });
	            }
	        }else{
	            jAlert(MSG_BID_COMPLETEFORM, MSG_BIDSUBMITHEAD, function(RetVal) {
	            });            
	        }
	    }
	    if(signStr=='false' || signStr=='False' || signStr==false){
	        //$('.add-icon').removeAttr('onclick');
	        //$('.remove-icon').removeAttr('onclick');        
	        $('input[id^="excelfile_"]').attr('disabled', true);
	        //$('.add-icon').attr('disabled', true);
	        //$('.remove-icon').attr('disabled', true);
	        tbool=false;
	    }
	    if (tbool) {
	        $('#datasignature').val(signStr);
	        $('#btnact').val('2');
	        $('.saveAsDraftBtn').attr('disabled', true);
	        $('.signBtn').attr('disabled', true);
	        $('.add-icon').removeAttr('onclick');
	        $('.remove-icon').removeAttr('onclick');        
	        $('input[id^="excelfile_"]').attr('disabled', true);
	        $('.add-icon').attr('disabled', true);
	        $('.remove-icon').attr('disabled', true);        
	        if (encryptionReq == 1) {
	            $('.encryptBtn').removeAttr('disabled');
	            $('.saveBtn').attr('disabled', true);
	        } else {
	            $('.saveBtn').removeAttr('disabled');
	        }
	        if(isPki){
	            jAlert(MSG_BIDDIGISIGN, MSG_BIDSUBMITHEAD, function(RetVal) {
	            });
	        }
	    }
	    return tbool;
	}
}
function encryptForm() {
    
	var value = checkCertificateVerification(2);
	if(value == 'false')
	{
		alert("Encryption Certificate is Not Verified");
		return false;
	}
	else
	{
		var tbool = true;
	    var encString = '';
	    for (var i = 0; i < tableIds.length; i++) {
	        var bidCounter = (addTabCounter[tableIds[i]] == undefined ? 1 : addTabCounter[tableIds[i]]);
	        for (var k = 0; k < bidCounter; k++) {
	            var tableBid = $('input[id="tableBid_' + tableIds[i] + '"][position="' + k + '"]').val()
	            var tableEnc = $('input[id="tableEnc_' + tableIds[i] + '"][position="' + k + '"]').val();
	            if (tableBid != '') {
	                var encBidStr = encryptBidData(tableBid, bidpkey2);
	                encString = encString + encBidStr;
	                $('input[id="tableBid_' + tableIds[i] + '"][position="' + k + '"]').val(encBidStr);
	            } else {
	                tbool = false;
	            }
	            if (tableEnc != '') {
	                $('input[id="tableEnc_' + tableIds[i] + '"][position="' + k + '"]').val(encryptData(tableEnc));
	            } else {
	                tbool = false;
	            }
	        }
	    }
	    if(encString=='false' || encString=='False' || encString==false){
	        tbool=false;
	    }
	    if (tbool) {
	        $('#dataencryption').val(encString);
	        $('.saveAsDraftBtn').attr('disabled', true);
	        $('.signBtn').attr('disabled', true);
	        $('.encryptBtn').attr('disabled', true);
	        $('.saveBtn').removeAttr('disabled');
	        jAlert(MSG_BIDDIGIENCRYPT, MSG_BIDSUBMITHEAD, function(RetVal) {
	        });
	    }

	}
}
function saveForm() {
    var tbool = true;
    for (var i = 0; i < tableIds.length; i++) {
        var bidCounter = (addTabCounter[tableIds[i]] == undefined ? 1 : addTabCounter[tableIds[i]]);
        for (var k = 0; k < bidCounter; k++) {
            var tableBid = $('input[id="tableBid_' + tableIds[i] + '"][position="' + k + '"]').val()
            var tableEnc = $('input[id="tableEnc_' + tableIds[i] + '"][position="' + k + '"]').val();
            if (tableBid == '' || tableBid == 'false' || tableBid == 'False' || tableBid==false) {
                tbool = false;
            }
            if (tableEnc == '' || tableEnc == 'false' || tableEnc == 'False' || tableEnc == false) {
                tbool = false;
            }
        }
    }
            
 if(isfromTermsheet== 'true' ){//&& JSisBidSavedInDraft == 'true'
		for (var b = 0; b < tableIds.length; b++) {
			//var rowCount=$('#bodydata_'+tableIds[b]+ ' tr').length;
			//alert(JSisBidSavedInDraft)
		var rowCount =$('#bodydata_'+tableIds[b]).children().length;
			for (var m = rowCount*3; m< rowCount*3+rowCount; m++) {
				  var elementExists = document.getElementById('rtfck_'+tableIds[b] + '_3_' + m);
                     if(elementExists){
							CKEDITOR.instances['rtfck_'+tableIds[b]+'_3_'+m].setData('');
						}
            }	
         }
   }
    if (tbool) {
        $('#hdFormActionD').remove();
    }else{
        jAlert(MSG_BIDPROBLEM, MSG_BIDSUBMITHEAD, function(RetVal) {
        });        
    }
    return disableBtn(tbool);
}
function validateBidFormData(){debugger


    if($('#btnact').val() == '1'){
        return saveAsDraft();
    }
    if($('#btnact').val() == '2'){
        return !isPki ? (signForm() ? saveForm() : false) : saveForm();
    }
}
function validateSorForm(){
    var finalFormData = validateBidForm(false);
    var tbool = (finalFormData.length != 0);
    if (tbool) {
        tbool = false;
        var jsonDataFinal = finalFormData[0];
        var mCounter = 0;
        for (var i = 0; i < tableIds.length; i++) {
            var bidCounter = (addTabCounter[tableIds[i]] == undefined ? 1 : addTabCounter[tableIds[i]]);
            for (var k = 0; k < bidCounter; k++) {
                var bidTableData = jsonDataFinal[mCounter]; 
                $('input[id="rtfSorBid_' + tableIds[i] + '"][position="' + k + '"]').val(bidTableData);                
                mCounter++;
            }
        }
        if (jsonDataFinal.length == mCounter) {
            var bidFormComp = finalFormData[1];
            for (var d = 0; d < bidFormComp.length; d++) {
                $(bidFormComp[d]).attr('disabled', true)
            }
            tbool = true;
        }
    }    
    return disableBtn(tbool);
}
function putDistinctValInArr(dataVal,dataList){
    if(dataList.toString().indexOf(dataVal)==-1){
        dataList.push(dataVal);
    }
    return dataList;
}
function tableValidate(formComponent,isDraft)
{
	mbool = true;
	/**
	 * PF : Partial Filling Table
	 * MN : Mandatory Table
	 * 
	 * case 1 : PF 1  MN 1
	 * case 2 : PF 1  MN 0
	 * case 3 : PF 0  MN 1
	 * case 4 : PF 0  MN 0
	 *
	 * minTablesReqForBidding
	 */
	$(".errorMsg,t_space,b_space").remove();
	var tableMedatoryCount=0; 
    for (var d1 = 0; d1 < tableIds.length; d1++) {
    	var isTablePartialFillingAllow = tablePartialMandatory[d1][0];
    	var isTableMedatory = tablePartialMandatory[d1][2];
    	var tableRowIds = new Array();
    	for (var d = 0; d < formComponent.length; d++) {
            var compRowId = $(formComponent[d]).attr('rowid');
            if($(formComponent[d]).attr('id')!=undefined){
	            if($(formComponent[d]).attr('id').split('_')[0] == tableIds[d1])
	            {	
		            if(compRowId!=undefined && tableRowIds.toString().indexOf(compRowId)==-1){
		                 tableRowIds.push(compRowId);
		            }
	            }
        	}
        }
    	var noOfRow = tableRowIds.length;

    	var PFyesMNyes = isTablePartialFillingAllow == 1 && isTableMedatory == 1;
    	var PFyesMNno =  isTablePartialFillingAllow == 1 && isTableMedatory == 0;
    	var PFnoMNyes =  isTablePartialFillingAllow == 0 && isTableMedatory == 1;
    	var PFnoMNno =   isTablePartialFillingAllow == 0 && isTableMedatory == 0;
    	
		var rcount = 0;
		var tableVirtMandt = false;
		for(var nm = 0 ; nm < tableRowIds.length ; nm++)
		{
			var compCount = 0,filledCompCount = 0;
    		for (var d = 0; d < formComponent.length; d++) {
    			var compRowId = $(formComponent[d]).attr('rowid');
    			if(compRowId != undefined && $(formComponent[d]).attr('id').split('_')[0] != undefined)
	    		{
	    			if(($(formComponent[d]).attr('id').split('_')[0].toString() == tableIds[d1].toString())  && (compRowId.toString() == tableRowIds[nm].toString()))
	                {
	                	if($(formComponent[d]).val() != undefined && $(formComponent[d]).val() !='')
	                	{
	                		 filledCompCount++;
	                	}else{
	                		 var isAutoCell = ($(formComponent[d]).attr('hdcolrow')!=undefined);
	                		 if(!isDraft && !isAutoCell)
	                		 {
	                			 if(PFnoMNyes)
			                	 {
			                		 $(formComponent[d]).parent().append("<div class='errclass' style='color:red;'>"+MSG_PLEASEENTERVAL+"</div>");
			                		 mbool = false; 
			                	 }
	                		 }	 
	                	}	
	                	compCount++;
	                }
	    		 }	
            }
    		if(compCount!=filledCompCount && filledCompCount > 0){
    			mbool = false;
        		jAlert(MSG_BID_INCOMPLETE_ROW,MSG_BIDSUBMITHEAD, function(RetVal) {
                });
        	}
    		if(PFyesMNyes){
    			if(compCount == filledCompCount && compCount!=0 && filledCompCount!=0){
	    			rcount++;
	    		}
       	 	}
    		if(PFyesMNno){
    			if(compCount == filledCompCount){
	    			rcount++;
    			}
       	 	}
    		if(PFnoMNyes){
	    		if(compCount == filledCompCount && compCount!=0 && filledCompCount!=0){
		    		rcount++;
		    	}
       	    }
			if(PFnoMNno){
	    		if(filledCompCount > 0){
		    			tableVirtMandt = true;
	    		}if(compCount == filledCompCount){
		    			rcount++;}
	    	}	
		}	
	    if(!isDraft)
	    {
			if(PFyesMNyes){
				if(rcount<1){
					$('#table_'+tableIds[d1]).parent().prepend("<div class='errorMsg t_space b_space' id='divEr'>"+MSG_BID_FILL_ONE_ROW+"</div>");
					mbool = false;
				}else{tableMedatoryCount++;
				}
	   	 	}
			if(PFyesMNno){
				if(rcount>0)
				{tableMedatoryCount++;
				}	
	   	 	}
			if(PFnoMNyes){
				if(rcount!=noOfRow){
					$('#table_'+tableIds[d1]).parent().prepend("<div class='errorMsg t_space b_space' id='divEr' >"+MSG_BID_FILL_ALL_ROW+"</div>");
					mbool = false;
		 		}else{tableMedatoryCount++;
		 		}
	    	}
			if(PFnoMNno){
				if(tableVirtMandt && rcount!=noOfRow){
					$('#table_'+tableIds[d1]).parent().prepend("<div class='errorMsg t_space b_space' id='divEr' >"+MSG_BID_FILL_ALL_ROW+"</div>");
					mbool = false;
		  		}
				else{
					if(rcount>0)
					{tableMedatoryCount++;}	
				}
	    	}
	    }
    }
    if(!isDraft)
    {
    	if(tableMedatoryCount < minTablesReqForBidding)
        {
        	jAlert(MSG_BID_MIN_TABLE,MSG_BIDSUBMITHEAD, function(RetVal) {
            });
        	mbool = false;
        }
    }	
    return mbool;
}

function tableValidateNew(formComponent,isDraft)
{
	mbool = true;
	/**
	 * PF : Partial Filling Table
	 * MN : Mandatory Table
	 * 
	 * case 1 : PF 1  MN 1
	 * case 2 : PF 1  MN 0
	 * case 3 : PF 0  MN 1
	 * case 4 : PF 0  MN 0
	 *
	 * minTablesReqForBidding
	 */
	$(".errorMsg,t_space,b_space").remove();
	var tableMedatoryCount=0; 
    for (var d1 = 0; d1 < tableIds.length; d1++) {
    	var isTablePartialFillingAllow = tablePartialMandatory[d1][0];
    	//var isTableMedatory = tablePartialMandatory[d1][2];
    	var isTableMedatory = 1;
    	var tableRowIds = new Array();
    	for (var d = 0; d < formComponent.length; d++) {
            var compRowId = $(formComponent[d]).attr('rowid');
            if($(formComponent[d]).attr('id')!=undefined){
	            if($(formComponent[d]).attr('id').split('_')[0] == tableIds[d1])
	            {	
		            if(compRowId!=undefined && tableRowIds.toString().indexOf(compRowId)==-1){
		                 tableRowIds.push(compRowId);
		            }
	            }
        	}
        }
    	var noOfRow = tableRowIds.length;

    	if(noOfRow > 0){
    		
    	var PFyesMNyes = isTablePartialFillingAllow == 1 && isTableMedatory == 1;
    	var PFyesMNno =  isTablePartialFillingAllow == 1 && isTableMedatory == 0;
    	var PFnoMNyes =  isTablePartialFillingAllow == 0 && isTableMedatory == 1;
    	var PFnoMNno =   isTablePartialFillingAllow == 0 && isTableMedatory == 0;
    	
		var rcount = 0;
		var tableVirtMandt = false;
		for(var nm = 0 ; nm < tableRowIds.length ; nm++)
		{
			var compCount = 0,filledCompCount = 0;
    		for (var d = 0; d < formComponent.length; d++) {
    			var compRowId = $(formComponent[d]).attr('rowid');
    			if(compRowId != undefined && $(formComponent[d]).attr('id').split('_')[0] != undefined)
	    		{
	    			if(($(formComponent[d]).attr('id').split('_')[0].toString() == tableIds[d1].toString())  && (compRowId.toString() == tableRowIds[nm].toString()))
	                {
	                	if($(formComponent[d]).val() != undefined && $(formComponent[d]).val() !='')
	                	{
	                		 filledCompCount++;
	                	}else{
	                		 var isAutoCell = ($(formComponent[d]).attr('hdcolrow')!=undefined);
	                		 if(!isDraft && !isAutoCell)
	                		 {
	                			 if(PFnoMNyes)
			                	 {
			                		 $(formComponent[d]).parent().append("<div class='errclass' style='color:red;'>"+MSG_PLEASEENTERVAL+"</div>");
			                		 mbool = false; 
			                	 }
	                		 }	 
	                	}	
	                	compCount++;
	                }
	    		 }	
            }
    		if(compCount!=filledCompCount && filledCompCount > 0){
    			mbool = false;
        		jAlert(MSG_BID_INCOMPLETE_ROW,MSG_BIDSUBMITHEAD, function(RetVal) {
                });
        	}
    		if(PFyesMNyes){
    			if(compCount == filledCompCount && compCount!=0 && filledCompCount!=0){
	    			rcount++;
	    		}
       	 	}
    		if(PFyesMNno){
    			if(compCount == filledCompCount){
	    			rcount++;
    			}
       	 	}
    		if(PFnoMNyes){
	    		if(compCount == filledCompCount && compCount!=0 && filledCompCount!=0){
		    		rcount++;
		    	}
       	    }
			if(PFnoMNno){
	    		if(filledCompCount > 0){
		    			tableVirtMandt = true;
	    		}if(compCount == filledCompCount){
		    			rcount++;}
	    	}	
		}	
	    if(!isDraft)
	    {
			if(PFyesMNyes){
				if(rcount<1){
					$('#table_'+tableIds[d1]).parent().prepend("<div class='errorMsg t_space b_space' id='divEr'>"+MSG_BID_FILL_ONE_ROW+"</div>");
					mbool = false;
				}else{tableMedatoryCount++;
				}
	   	 	}
			if(PFyesMNno){
				if(rcount>0)
				{tableMedatoryCount++;
				}	
	   	 	}
			if(PFnoMNyes){
				if(rcount!=noOfRow){
					$('#table_'+tableIds[d1]).parent().prepend("<div class='errorMsg t_space b_space' id='divEr' >"+MSG_BID_FILL_ALL_ROW+"</div>");
					mbool = false;
		 		}else{tableMedatoryCount++;
		 		}
	    	}
			if(PFnoMNno){
				if(tableVirtMandt && rcount!=noOfRow){
					$('#table_'+tableIds[d1]).parent().prepend("<div class='errorMsg t_space b_space' id='divEr' >"+MSG_BID_FILL_ALL_ROW+"</div>");
					mbool = false;
		  		}
				else{
					if(rcount>0)
					{tableMedatoryCount++;}	
				}
	    	}
	    }
    }
    }
    if(!isDraft)
    {
    	if(tableMedatoryCount < minTablesReqForBidding)
        {
        	jAlert(MSG_BID_MIN_TABLE,MSG_BIDSUBMITHEAD, function(RetVal) {
            });
        	mbool = false;
        }
    }	
    return mbool;
}

function extendEndTime()
{
    $.ajax({
        type: "GET",
        url: ajaxExtendTimeUrl,
        dataType: 'text',
        success: function(j)
        {
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
        }
    });
}