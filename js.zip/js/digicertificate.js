
var contextPath = location.pathname.substring(0,location.pathname.lastIndexOf('/'));
contextPath='/'+contextPath.split('/')[1];
var browser=navigator.userAgent.toLowerCase();
if(browser.indexOf('msie')!=-1 || browser.indexOf('MSIE')!=-1 || !!navigator.userAgent.match(/Trident\/7\./)){
    //Avoid writing document.write, it will some time overwrite whole content and hence creating problem
    //document.write('<object width="0" height="0" codebase="capicom.cab#version=2,0,0,3" classid="clsid:A996E48C-D3DC-4244-89F7-AFA33EC60679" name="etlABCUtility" id="etlABCUtility"></object>');
    jQuery(function($) {
        $('<object width="0" height="0" codebase="capicom.cab#version=2,0,0,3" classid="clsid:A996E48C-D3DC-4244-89F7-AFA33EC60679" name="etlABCUtility" id="etlABCUtility"></object>').appendTo("head");
    });
    var sealock = undefined;
    $.getScript(contextPath+'/resources/js/signagent.js', function(){
        $.getScript(contextPath+'/resources/js/signEncryptCert.js', function(){             
            $.getScript(contextPath+'/resources/js/jQuery/jquery.blockUI.js', function(){
                $.blockUI({
                    message: '<h1>Please wait...</h1>',
                    onBlock: function() {
                        sealock = new signer();
                        openSignEncKeyStore();
                        $.unblockUI();
                    }
                });
            });
        });
    });
	
	/*$.getScript(contextPath+'/resources/js/signagent.js', function(){});
    $.getScript(contextPath+'/resources/js/signEncryptCert.js', function(){});
    var sealock = undefined;
	$.getScript(contextPath+'/resources/js/jQuery/jquery.blockUI.js', function(){});
    $.blockUI({
        message: '<h1>Please wait.</h1>',
        onBlock: function() {
            sealock = new signer();
            openSignEncKeyStore();
            $.unblockUI();
        }
    });*/
}else{
    /*
    jQuery(function($) {
            $('<object type="application/x-java-applet" name="etlABCUtility" id="etlABCUtility" height="0" width="0">').appendTo("head");
            $('<param name="java_code" value="com.abcprocure.crypto.ABCCertificateUtility" />').appendTo("head");
            $('<param name="mayscript" value="yes" />').appendTo("head");
            $('<param name="jnlp_href" value="' + contextPath + '/resources/jar/EtlCryptoAPI.jnlp" />').appendTo("head");
            $('<param name="scriptable" value="true" />').appendTo("head").appendTo("head");
            $('</object>').appendTo("head");
    });
    $.getScript(contextPath+'/resources/js/signEncryptCertetl.js', function(){});
    */
    
    var jksPass = getCookieInCert('abcJavaKeyStoreCryptoUtil');
    document.write('<object type="application/x-java-applet" name="etlABCUtility" id="etlABCUtility" height="0" width="0">');
    document.write('<param name="java_code" value="com.abcprocure.crypto.ABCCertificateUtility" />');
    document.write('<param name="mayscript" value="yes" />');
    document.write('<param name="jnlp_href" value="' + contextPath + '/resources/jar/EtlCryptoAPI.jnlp" />');
    document.write('<param name="scriptable" value="true" />');
    document.write('<param name="ksPass" value="'+jksPass+'" />');
    document.write('</object>');
    document.write('<script type="text/javascript" src="' + contextPath + '/resources/js/signEncryptCertetl.js"></script>');
    function waituntilok() {
        if(document.etlABCUtility != null || document.etlABCUtility != undefined){
            document.etlABCUtility.style.height = '1px';	
        }
    }
    waituntilok();
    var sealock = document.getElementById('etlABCUtility');
    $.blockUI({
        message: '<h1>Please wait..</h1>',
        onBlock: function() {
            openSignEncKeyStore();
            $.unblockUI();
        }
    });
}
function wrapPublicKey(pkey){
    var newPKey = pkey.substring(0,72) + "<br>" + pkey.substring(73,144) + "<br>" + pkey.substring(145,216);
    return newPKey;
}
function wrapWord(tword){
    var wlen = tword.length;
    var tk = 72;
    var cnt = parseInt(wlen/tk);
    var newWord = '';
    var wmod = wlen%tk;
    for(var i=0;i<cnt;i++){
        if(i==0){
            newWord = newWord + tword.substring(0,tk) + "<br/>";
        }else{
            newWord = newWord + tword.substring(tk-71,tk) + "<br/>";
        }
        tk = tk +72;
    }
    if(wmod!=0){
        newWord = newWord + tword.substring(wlen-wmod+1,wlen);
    }
    return newWord;
}
function sortComboText(id){
    var cmb = document.getElementById(id);
    var value = new Array();
    var text = new Array();
    for(var i=0;i<cmb.options.length;i++){
        value[i]=(cmb.options[i].value);
text[i]=($.trim(cmb.options[i].text.toString()));
    }
    for(var i=1;i<cmb.options.length;i++){
        for(var j=0;j<cmb.options.length-i;j++){
            if(text[j].toString().toUpperCase() > text[j+1].toString().toUpperCase()){
                var temp=text[j];
                text[j]=text[j+1];
                text[j+1]=temp;

                var temp2=value[j];
                value[j]=value[j+1];
                value[j+1]=temp2;
            }
        }
    }
    var options = '';
    var psVar = '';
    for(var i=0;i<cmb.options.length;i++){
        if(text[i] != '--Please Select--'){
            options = options+'<option value="'+value[i]+'">'+text[i]+'</option>';
        }else{
            psVar = '<option value="'+value[i]+'">'+text[i]+'</option>';
        }
    }
    $('#'+id).html(psVar+options);
}
function getCookieInCert(cname){
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
      var c = ca[i];
      if (c.indexOf(name)==0) return c.substring(name.length,c.length);
    }
    return "";
}