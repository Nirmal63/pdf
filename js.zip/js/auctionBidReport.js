/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *Method use to show hide item details 
 */
function toggleShowHid(ob,varob)
{
    if($(varob).html()== 'View More')
    {
        $(varob).html("Hide");
    }
    else
    {
        $(varob).html("View More");
    }
    $(ob).toggle();
}
 /**
 *Method use for update Remaining time of bid submission timer.
 */  
 function dynamicRemClock()
    {
        if(auctionStatus == '0')
        {
            for(var cnt=0;cnt<arrRow.length;cnt++)
            {   
                var j=cnt;
                if(isItemWiseTimeReq == 1)
                {                
                    j=arrRow[cnt] - 1;                  
                }
                /*else
                {
                    j=cnt;  
                }*/
                var k=j;
                if(auctionResult == 2 && isItemWiseTimeReq == 1)
                {
                    k++;
                }
                if($("#remainTimer_"+j) && isRowBidTimeOver[j] == false)
                {
                		if(Min[j] == 0 && Sec[j] == 1 && Hr[j] == 0)
                        {
                			if(isItemWiseTimeReq == 1 && isSerialAuction == 2){ //only for serial for other update from getbiddetails.
    							isRowBidTimeOver[j]=true;
    						}
                			// For collapse item which has time over
                            if(isItemWiseTimeReq == 1 && isSerialAuction == 1){
    							if(isRowBidTimeOver[j] == false){
    								setTimeout(function(){
										getBidDetails();
			    					},3000);
									if(!$('#updateTimer_'+j).is(":visible")){
										$('#updateTimer_'+j).show();
										$('#clockTimer_'+j).hide();
										$('#updateTimer_'+j).html("Please wait, Final result is being fetched...");
									}
    							}
                            }
                            /*** START : Reload page when bid time over (if item wise time yes then all item's bid time over then reload page ***/
	                        var isAuctionFinished=true;
		                    if(auctionResult == 2 && isItemWiseTimeReq == 1)// Item wise time is yes
		                    {
		                        for(var cnt=0;cnt<arrRow.length;cnt++)
		                        {
		                            if(isRowBidTimeOver[arrRow[cnt] - 1] != true)
		                            {
		                                isAuctionFinished=false;
		                                break;
		                            }
		                        }
		                    }                                                   
		                    if(isAuctionFinished)
		                    {
		                    	setTimeout(function(){
									window.location.reload(true);
								},3000);
								$('#updateTimer_'+j).show();
								$('#clockTimer_'+j).hide();
								$("#bidBtn_"+j).html('');
		                        $('#updateTimer_'+j).html("Please wait, Final result is being fetched...");
		                    }   
                        }
		            	if(Hr[j] > 0){
		                    if(Min[j] == 0 && Sec[j] == 0){
		                        Hr[j] = Hr[j] - 1;
		                        Min[j] = 59;
		                        Sec[j] = 60;
		                    }else if(Min[j] > 0 && Sec[j] == 0){
		                        Min[j] = Min[j] - 1;
		                        Sec[j] = 60;
		                    }
		                    else if(Sec[j] == 0){
		                        Sec[j] = 60;
		                    }
		                }else{
		                    if(Min[j] > 0 && Sec[j] == 0){
		                        Min[j] = Min[j] - 1;
		                        Sec[j] = 60;
		                    }
		                    else if(Sec[j] == 0){
		                        Sec[j] = 60;
		                    }
		                }
		                Sec[j] = Sec[j] - 1;	
		                if(!isNaN(Hr[j]) && !isNaN(Min[j]) && !isNaN(Sec[j]) && auctionStatus == '0')
		                 {	
		                    if(auctionResult == 2 && isDIYClient == 1 && userTypeId != 1){
		                    	$("#remainTimer_"+j).html(Hr[j]+" : "+Min[j]+" : "+Sec[j]);
		            		}else{
		            			$("#remainTimer_"+j).html(Hr[j]+" Hr - "+Min[j]+" Minutes - "+Sec[j]+" Seconds");	
		            		}
		                     if($("#remainTimer-collapse_"+j).length > 0){
		                     	$("#remainTimer-collapse_"+j).html(Hr[j]+" Hr - "+Min[j]+" Minutes - "+Sec[j]+" Seconds")
		                     }
		                 }
                	}
            	}
        	}
    	}  
    
/**
 * Method use to get bid detail using ajax call.
 */  
 function getBidDetails()
    {
        $.ajax({
        type: "GET",
        url: ajaxBidDetailPath,
        dataType: 'text',
        data: { 
                    hdAcceptDecimalUpTo: $('#hdAcceptDecimalUpTo').val()
                },
        success: function(j)
        { 
            j=j.toString();
            try
            {
                if(j!=null && (j.indexOf("SessionExpired")!= -1))
                {
                    alert(sessionexpired);
                    return false;
                }
                else
                {
                    renderBidDetails(j);
                }    
            }
            catch(e)
            {
                alert(scriptErrorMsg);
                return false;
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          alert(ajaxErrorMsg);
          return false;
        }
      });
    }
    
  
 
 /**
 * Method use for render bid details get from ajax at html page.
 */
   function renderBidDetails(j)
    {
        try
        {
            j=$.trim(j.toString());
            var ar;
            var arrdtl;
            var biddtl;
            var otherbiddtllist;
            var otherbiddtl;
            var rId;
            if(j!=null && j!="" && j!="null")
            {
               // alert(j);
                var ar=j.split("||");
                var i=0;
                for(var cnt=0;cnt<ar.length;cnt++)
                {
                    arrdtl=ar[cnt].toString().split("`");
                
                    /******* Setting bidder information *****/
                    if(arrdtl[0] !=null) 
                    {
                        biddtl = arrdtl[0].toString().split("~");
                        rId=biddtl[0];
                        if(isItemWiseTimeReq == 1)
                        {
                            i=rId - 1;
                        }
                        else
                        {
                            i=cnt;
                        }
                        
                        /*
                        Auction Detail Format:
                           rowId~sysdate~remainingtime~enddatevirtual~curExt~IncDecvalue~incDecPer~startPrice
                        */

                        /* setting Current time */
                       if(biddtl.length >= 3 && i == 0)  /* Need to set only once not for each rows*/
                       {
                            intBidDate = Date.parse(biddtl[1]);
                            UpdateBidTimer();

                       }

                        /* setting remaining time,enddate,curExt */
                        var dtarr = $.trim(biddtl[2]).split(':');
                        if(isItemWiseTimeReq == 0 && i==0) //Item wise time required == No.
                        {   
                            Hr[0]=parseInt(dtarr[0],10);
                            Min[0]=parseInt(dtarr[1],10);
                            Sec[0]=parseInt(dtarr[2],10);
                            if(!isNaN(Hr[0]) && !isNaN(Min[0]) && !isNaN(Sec[0]) && auctionStatus == '0' && isAuctionClosed == 'false')
                            {
                                if(auctionResult == 2 && isDIYClient == 1 && userTypeId != 1){
                            		$("#remainTimer_0").html(Hr[0]+" : "+Min[0]+" : "+Sec[0]);
                        		}else{
                        			$("#remainTimer_0").html(Hr[0]+" Hr - "+Min[0]+" Minutes - "+Sec[0]+" Seconds"); 
                    			}
                                
                            }else if(isAuctionClosed == 'true'){
                            	$("#clockTimer_0").html(scriptBidTimeOverMsg);
                                if($("clockTimer-collapse_0").length >0){
                                	$("#clockTimer-collapse_0").html(scriptBidTimeOverMsg);
                                }
                            }
                            $("#endDate_0").html(biddtl[3]);
                            if($("#endDate-collapse_0").length > 0){
                            	$("#endDate-collapse_0").html(biddtl[3]);
                            }
                            
                            if($("#extCurrent_0"))
                            {
                                $("#extCurrent_0").html(biddtl[4]);
                                if($("#extCurrent-collapse_0").length > 0){
                                	$("#extCurrent-collapse_0").html(biddtl[4]);
                                }
                            }
                            
                            if(isDIYClient == 1  && userTypeId != 1 && parseInt(biddtl[4]) > 0){
	                        	$('#remainTime_msg').html(lbl_auc_ext_rem_time);
	                        }
                        }
                        else
                        {
                            Hr[i]=parseInt(dtarr[0],10);
                            Min[i]=parseInt(dtarr[1],10);
                            Sec[i]=parseInt(dtarr[2],10);
                            if(!isNaN(Hr[i]) && !isNaN(Min[i]) && !isNaN(Sec[i]) && auctionStatus == '0')
                            {	
                            	if(Hr[i] == 0 && Min[i] == 0 && Sec[i] == 0){
                            		$('#updateTimer_'+i).hide();
									$('#clockTimer_'+i).show();
									$("#clockTimer_"+(i)).html(scriptBidTimeOverMsg);
                            	}else{
                            		$('#updateTimer_'+i).hide();
									$('#clockTimer_'+i).show();
                            		if(auctionResult == 2 && isDIYClient == 1 && userTypeId != 1){
            	                    	$("#remainTimer_"+i).html(Hr[i]+" : "+Min[i]+" : "+Sec[i]);
            	            		}else{
            	            			$("#remainTimer_"+i).html(Hr[i]+" Hr - "+Min[i]+" Minutes - "+Sec[i]+" Seconds");
            	            		}
                                    if($("remainTimer-collapse_"+i).length >0){
                                    	$("#remainTimer-collapse_"+i).html(Hr[i]+" Hr - "+Min[i]+" Minutes - "+Sec[i]+" Seconds");
                                    }
                            	}
                            }
                            $("#endDate_"+i).html(biddtl[3]);
                            if($("#extCurrent_"+i))
                            {
                               $("#extCurrent_"+i).html(biddtl[4]);
                               if($("#extCurrent-collapse_"+i).length > 0){
                               	$("#extCurrent-collapse_"+i).html(biddtl[4]);
                               }
                            }
                        }
                        /* setting H1L1amount,lastbiddetail,IncDecValue,BidderRank */
                       $("#startPrice_"+i).html(biddtl[7]);
                        
                        if($("#incDecPer_"+i))
                        {
                           $("#incDecPer_"+i).html(biddtl[6]);
                        }
                        if($("#incDecAmt_"+i))
                        {
                           $("#incDecAmt_"+i).html(biddtl[5]);
                        }
                        if(isBidPriceIncDecTimes == 1){
                        	$("#bidPriceIncDecInTimes_"+i).html(biddtl[8]);
                        }
                        if(isYankeeAuction == 1){
							if(biddtl[9] == 1){ //isHideLiveBidToOfficer is 1
								$("#totQty_"+i).html(biddtl[11]);
								$("#remQty_"+i).html(biddtl[12]);
							}else{
								$("#totQty_"+i).html(biddtl[10]);
								$("#remQty_"+i).html(biddtl[11]);									
							}
						}
                      //Bug #27487 and #27566 fetch isauctionlive status from backend in ajax
                        var ajaxHideBidsFromDeptUser = (auctionStatus == 0 || auctionStatus == 2 || auctionStatus == 3) && biddtl[10] == 1 && userTypeId == 3 && cstatus !=0 && biddtl[9] == 1;
                        if((ajaxHideBidsFromDeptUser == true && hideBidsFromDeptUser == 'false') || (ajaxHideBidsFromDeptUser == false && hideBidsFromDeptUser == 'true')){
                        	window.location.reload(true);
                        }
                    }


                    /******* Setting bidder's information *****/
                    if(arrdtl[1] !=null)
                    {
                        otherbiddtllist = arrdtl[1].toString().split("<<");
                        /*
                        Other Bidder Detail Format:
                        bidderId~companyName~encodedName~bidAmount~BidCurrency~ExchangeRate~Rank~BidDateTime~startPrice~bidHistoryEncStr~bidBreakUpEncStr~rejectEncStr
                        bidderId~companyName~encodedName~bidAmount~Rank~BidDateTime~startPrice~bidId~bidHistoryEncStr~bidBreakUpEncStr~rejectEncStr
                        */
                       var tr='';
					   //var zeroRankTr = '';
                       if(ajaxHideBidsFromDeptUser != true){ //Project Task #27308
                        for(var k=0;k<otherbiddtllist.length;k++)
                        {
                            otherbiddtl= otherbiddtllist[k].toString().split("~");
                            if(otherbiddtl[4]!=null && otherbiddtl[4]!=undefined)
                            {
								tr += "<tr "+((otherbiddtl[4] == '1')? "class='row-highlight'" : '')+ ">";
                                tr += '<td class="v-a-middle a-center">'+otherbiddtl[4]+'</td>';
                                if(bidderwisebidhistoryrightsexist == 'true')
                                {
                                	if(isBidderEncoded == '1' && ISAUCTIONCLOSED != 'true')
                                    {
                                		//for decode bidder manually for dept admin
                                		if(isDecodedRight && isBidderEncoded == '1' && ISAUCTIONCLOSED !='true' ){
                                			tr += '<td class="v-a-middle a-center"><a title="'+titalbidderwisebidhistory+'" href="'+contexPath+'/eauction/auctioneer/bidhistoryreport/'+auctionId+'/'+tableId+'/'+rId+'/0/'+otherbiddtl[0]+otherbiddtl[8]+'">'+otherbiddtl[1]+'</a></td>';
                                		}
                                		else if(isDecodedRight && isDeptAdmin == '1' && isBidderEncoded == '1' && (auctionStatus == 2 || cancelauction == 'true') && ((varisdecodebidderrequired == '1' && varisdecodebidderdone == '1') ||  varisdecodebidderrequired == '0')){
                                			tr += '<td class="v-a-middle a-center"><a title="'+titalbidderwisebidhistory+'" href="'+contexPath+'/eauction/auctioneer/bidhistoryreport/'+auctionId+'/'+tableId+'/'+rId+'/0/'+otherbiddtl[0]+otherbiddtl[8]+'">'+otherbiddtl[1]+'</a></td>';
                                   		}else{
                                   			tr += '<td class="v-a-middle a-center"><a title="'+titalbidderwisebidhistory+'" href="'+contexPath+'/eauction/auctioneer/bidhistoryreport/'+auctionId+'/'+tableId+'/'+rId+'/0/'+otherbiddtl[0]+otherbiddtl[8]+'">'+otherbiddtl[2]+'</a></td>';
                                   		}
                                    }
                                    else if((isDeptAdmin == '1' || userId!=1 )&& isBidderEncoded == '1' && (ISAUCTIONCLOSED == 'true' || auctionStatus == 2 || cancelauction == 'true' )&& varisdecodebidderdone=='0'){
                                    	if((isDecodedRight && varisdecodebidderrequired == '1' && varisdecodebidderdone == '1') || varisdecodebidderrequired == '0'){
                                    		tr += '<td class="v-a-middle a-center"><a title="'+titalbidderwisebidhistory+'" href="'+contexPath+'/eauction/auctioneer/bidhistoryreport/'+auctionId+'/'+tableId+'/'+rId+'/0/'+otherbiddtl[0]+otherbiddtl[8]+'">'+otherbiddtl[1]+'</a></td>';
	                               		}else if(varisdecodebidderrequired == '1' && varisdecodebidderdone == '1'){
	                               			tr += '<td class="v-a-middle a-center"><a title="'+titalbidderwisebidhistory+'" href="'+contexPath+'/eauction/auctioneer/bidhistoryreport/'+auctionId+'/'+tableId+'/'+rId+'/0/'+otherbiddtl[0]+otherbiddtl[8]+'">'+otherbiddtl[1]+'</a></td>';
	                               		}
                                    	else{
	                               			tr += '<td class="v-a-middle a-center"><a title="'+titalbidderwisebidhistory+'" href="'+contexPath+'/eauction/auctioneer/bidhistoryreport/'+auctionId+'/'+tableId+'/'+rId+'/0/'+otherbiddtl[0]+otherbiddtl[8]+'">'+otherbiddtl[2]+'</a></td>';
	                               		}
                                    }else
                                    {
                                        tr += '<td class="v-a-middle a-center"><a title="'+titalbidderwisebidhistory+'" href="'+contexPath+'/eauction/auctioneer/bidhistoryreport/'+auctionId+'/'+tableId+'/'+rId+'/0/'+otherbiddtl[0]+otherbiddtl[8]+'">'+otherbiddtl[1]+'</a></td>';
                                    }
                                }
                                else
                                {	
                                    if(isBidderEncoded == '1' && ISAUCTIONCLOSED != 'true')
                                    {
                                    	if(isDecodedRight && isDeptAdmin == '1' && isBidderEncoded == '1' && (auctionStatus == 2 || cancelauction == 'true') && ((varisdecodebidderrequired == '1' && varisdecodebidderdone == '1') || varisdecodebidderrequired == '0')){
                                   			tr += '<td class="v-a-middle a-center">'+otherbiddtl[1]+'</td>';
                                   		}else{
                                   			tr += '<td class="v-a-middle a-center">'+otherbiddtl[2]+'</td>';
                                   		}                                    		
                                    }
                                    else if(isDeptAdmin == '1' && isBidderEncoded == '1' && (ISAUCTIONCLOSED == 'true' || auctionStatus == 2 || cancelauction == 'true')){
                                    	if((isDecodedRight && varisdecodebidderrequired == '1' && varisdecodebidderdone == '1') || varisdecodebidderrequired == '0'){
                                   			tr += '<td class="v-a-middle a-center">'+otherbiddtl[1]+'</td>';
                                   		}else{
                                   			tr += '<td class="v-a-middle a-center">'+otherbiddtl[2]+'</td>';
                                   		}
                                    }
                                    else
                                    {
                                        tr += '<td class="v-a-middle a-center">'+otherbiddtl[1]+'</td>';
                                    }
                                }
                                var t=otherbiddtl[3];
                                if(isBidderWiseStartPrice == '1'){
                                	if(isDeptAdmin == '1'){
                                		if('true' == 'true'){
			                                if(displayPriceBidBreakUp == '1')
			                                {
			                                    tr += '<td class="v-a-middle a-center"><a title="'+titalpricebidbreakup+'" href="'+contexPath+'/eauction/auctioneer/breakupbidreport/'+auctionId+'/'+otherbiddtl[7]+"/"+otherbiddtl[0]+"/"+rId+otherbiddtl[9]+'">'+t+'</a></td>';
			                                }
			                                else
			                                {
			                                    tr += '<td class="v-a-middle a-center">'+t+'</td>';
			                                }
                                		}
                                	}else{
                                		if(displayPriceBidBreakUp == '1')
		                                {
		                                    tr += '<td class="v-a-middle a-center"><a title="'+titalpricebidbreakup+'" href="'+contexPath+'/eauction/auctioneer/breakupbidreport/'+auctionId+'/'+otherbiddtl[7]+"/"+otherbiddtl[0]+"/"+rId+otherbiddtl[9]+'">'+t+'</a></td>';
		                                }
		                                else
		                                {
		                                    tr += '<td class="v-a-middle a-center">'+t+'</td>';
		                                }
                                	}                                
                                }else{
                                	if(displayPriceBidBreakUp == '1')
	                                {
	                                    tr += '<td class="v-a-middle a-center"><a title="'+titalpricebidbreakup+'" href="'+contexPath+'/eauction/auctioneer/breakupbidreport/'+auctionId+'/'+otherbiddtl[7]+"/"+otherbiddtl[0]+"/"+rId+otherbiddtl[9]+'">'+t+'</a></td>';
	                                }
	                                else
	                                {
	                                    tr += '<td class="v-a-middle a-center">'+t+'</td>';
	                                }
                                }

                                if(isBidderWiseStartPrice == '1'){
                                	if(isDeptAdmin == '1'){
                                		if('true' == 'true'){
                                			tr += '<td>' + otherbiddtl[6] +'</td>';
                                		}
                                	}else{
                                		tr += '<td>' + otherbiddtl[6] +'</td>';
                                	}
                                }
                                
                                if(isYankeeAuction == 1){
                                	tr += '<td class="v-a-middle a-center">'+otherbiddtl[14]+'</td>';
									tr += '<td class="v-a-middle a-center">'+otherbiddtl[15]+'</td>';									
                                }
                                
								if(isICBAuction == 2) {
									tr += '<td class="v-a-middle a-center">'+otherbiddtl[12] +' '+ otherbiddtl[13] +'</td>';
								}
                                tr += '<td class="v-a-middle a-center">'+otherbiddtl[5]+'</td>';
								 
                                
                                if(auctionResult == 2 && isDIYClient == 1 && userTypeId != 1){
                                	if(ISAUCTIONCLOSED != 'true' && otherbiddtl[11] == '0' && isClockAuction == 0 && isBidCapacityReq == '0' && isRestrictH1Bidder != '1' && eval(sessionClientId) != eval(clientWiseEmdDomain)){
                                		tr += '<td class="v-a-middle a-center"><a title="'+linkaucrejectbid+'" href="'+contexPath+'/eauction/auctioneer/rejectbidform/'+auctionId+'/'+otherbiddtl[7]+"/"+otherbiddtl[0]+"/"+rId+otherbiddtl[10]+'">'+linkaucrejectbid+'</a></td>';
                                	}else{
                                		tr += '<td class="v-a-middle a-center">-</td>';
                                	}
                                    
                                }else if(rejectbidrightsexists == 'true')
                                {
                                    if(ISAUCTIONCLOSED == 'true' || ($('#clockTimer_'+i) && ($('#clockTimer_'+i).html()!=null && (parseInt($('#clockTimer_'+i).html().indexOf("red"),10) == -1 && parseInt($('#clockTimer_'+i).html().indexOf("Hr"),10) == -1)) ))
                                    {
                                        tr += '<td class="v-a-middle a-center">-</td>';    
                                    }
                                    else
                                    {
                                    	if(otherbiddtl[11] == '0' && isClockAuction == 0 && isBidCapacityReq == '0' && isRestrictH1Bidder != '1' && eval(sessionClientId) != eval(clientWiseEmdDomain)){
                                    		tr += '<td class="v-a-middle a-center"><a title="'+linkaucrejectbid+'" href="'+contexPath+'/eauction/auctioneer/rejectbidform/'+auctionId+'/'+otherbiddtl[7]+"/"+otherbiddtl[0]+"/"+rId+otherbiddtl[10]+'">'+linkaucrejectbid+'</a></td>';
                                    	}else{
                                    		tr += '<td class="v-a-middle a-center">-</td>';
                                    	}
                                    }
                                }
                                
                                tr += '</tr>';
								/*if(otherbiddtl[4] == '0'){
                                	zeroRankTr += tr;
                                	tr = '';
                                }*/
                            }
                            else if(otherbiddtl[4]==null || otherbiddtl[4]==undefined)
                            {
                                if(isBidderWiseStartPrice == '1')
                                {
                                    tr += "<tr><td colspan='6' style='text-align:center;'>  "+MSG_NOBIDRECEIVED+" </td></tr> "; 
                                }
                                else
                                {
                                    tr += "<tr><td colspan='5' style='text-align:center;'>  "+MSG_NOBIDRECEIVED+" </td></tr> ";   
                                }
                            }
                                
                        }
                        $('#otherBidDtl_'+i).find("tr").remove();
						//tr += zeroRankTr;
                        $('#otherBidDtl_'+i).html(tr);						
                    }else{ //Project Task #27308
                    	if(isBidderWiseStartPrice == '1')
                        {
                    		if(auctionStatus == AUCTION_STOP)
                            {
                    			tr += "<tr><td colspan='6' style='text-align:center;color:red'>  "+MSG_AUCTIONSTOP+"</td></tr> ";
                                
                            }else{
                            	tr += "<tr><td colspan='6' style='text-align:center;color:red'>  "+MSG_AUCTIONLIVE+" </td></tr> ";
                            }
                        }
                        else
                        {
                        	if(auctionStatus == AUCTION_STOP)
                            {
                    			tr += "<tr><td colspan='5' style='text-align:center;color:red'>  "+MSG_EVENTSTOP+"</td></tr> ";
                                
                            }else{
                            	tr += "<tr><td colspan='5' style='text-align:center;color:red'>  "+MSG_AUCTIONLIVE+" </td></tr> ";
                            }
                        }
                    	 $('#otherBidDtl_'+i).find("tr").remove();
                         $('#otherBidDtl_'+i).html(tr);
                    }
                  }
                }
            }
        }
        catch(e)
        {
            alert(scriptErrorMsg+e.toString());
            return false;
        }
    }
   
   
   /**
 * Method use to get Marquee Text using ajax call.
 */  
 function getAjaxMarqueeDetail()
    {
        $.ajax({
        type: "GET",
        url: ajaxMaqueeDetailPath,
        success: function(j)
        {
            j=j.toString();
            try
            {
                if(j!=null && (j.indexOf("SessionExpired")!= -1))
                {
                    alert(sessionexpired);
                    return false;
                }
                else
                {  
                    var marqueeStr='<font>';
                    auctionStatus='0';
                    if(j!=null && $.trim(j.toString())!='')
                    {
                        var arrMaquee=j.split("~");
                        for(var i=0;i<arrMaquee.length;i++)
                        {
                            var arr=arrMaquee[i].split("`");
                            if(arr[1]!=null && (arr[1] == '1' || arr[1] == '2' || arr[1] == '4'))
                            {
                                auctionStatus=arr[1];
                            }  
                            marqueeStr+=arr[0]+" ";
                        }
                    }
                    marqueeStr+="</font> ";
                    
                    if(j!=null && $.trim(j.toString())!=''){
                    	$('#marqueeDiv').show();
                    }else{
                    	$('#marqueeDiv').hide();
                    }                    

                    $('#dynamicMarqueeText').html(marqueeStr);
                    if(auctionStatus != 0)
                    {
                        if(auctionStatus == AUCTION_PAUSE)
                        {
                            $('span[id^=remainTimer]').each(function()
                            {
                                $(this).html("<font color='red'><b>"+MSG_AUCTIONPAUSE+"</b></font>");
                            });
                        }
                        else if(auctionStatus == AUCTION_STOP)
                        {
                            $('span[id^=remainTimer]').each(function()
                            {
                                $(this).html("<font color='red'><b>"+MSG_AUCTIONSTOP+"</b></font>");
                            });
                        }
                        else if(auctionStatus == AUCTION_CANCEL)
                        {
                           $('span[id^=remainTimer]').each(function()
                            {
                                $(this).html("<font color='red'><b>"+MSG_AUCTIONCANCEL+"</b></font>");
                            });
                        }      
                    }
                }
            }
            catch(e)
            {
                alert(scriptErrorMsg+e.toString());
                return false;
            }
        },
        error: function(XMLHttpRequest, textStatus, errorThrown) {
          alert(ajaxErrorMsg);
          return false;
        }
      });
    }

 /**
  * Push data to SAMIL Agri gold auction
  */
 function pushData(auctionId){
 	//var encString = '<abc:encdec isenc="true" value="eauction/auctioneer/pushauctiondata/${auctionId}${sessionScope.sessionObject.userName}"/>';
 	//var urlToPush = "${pageContext.servletContext.contextPath}/eauction/auctioneer/ajax/pushauctiondata/${auctionId}";
 	$.ajax({
 		url : urlToPush,
 		type: "POST",
 		success: function (sData,textStatus, xhr) {
				alert(sData);       				
 			},

			error: function (xmlHttpRequest, textStatus, errorThrown) {
				console.log("Error > "+errorThrown);
				alert("Error in Notify status.");
			}
 	});
 }
 
 /**
  * push auction data generic
  */
 function pushAuctionData(obj){
	 	
		$.blockUI({
	        message: '<h1>Please wait...</h1>',
	        onBlock: function() {
				$.ajax({
					url : pushDataURL,
					type: "POST",
					success: function (sData,textStatus, xhr) {
							if(sData != "error"){
								$("#pushStatus").html(sData);
								$(obj).replaceWith($(obj).text());
								$("#pushStatus").attr("style","color: green");
								alert("Data sent successfully");
							}else{
								$("#pushStatus").html("<span style='font-style: bold; color: red'> (Unsuccessful)</span>");
							}
							$.unblockUI();
						},

						error: function (xmlHttpRequest, textStatus, errorThrown) {
							console.log("Error > "+errorThrown);
							$("#pushStatus").html("<span style='font-style: bold; color: red'> (Unsuccessful)</span>");					
							$.unblockUI();
						}
				});
			}
		});
	 }
