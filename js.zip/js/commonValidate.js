/*
 *@author TaherT
 */
//<REGEX>/^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

//var EMAIL_ID = /^\w+[_\-\.]+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;//email  :alphanumeric and Special Characters (@,.,-,_)
var EMAIL_ID = /^((([a-z]|\d|[\-_ ]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[\-_]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))){2,}$/i; //email,emailmsgbox //Changes for bug Id#32113 before(\.?) after({2,}) (server side and client side regex not same and client side regex accept single(.)) 
var ALTER_EMAIL_ID = /^(((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))([\,](((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))))*\.?$/i;//alteremail
var ALTERNATE_EMAIL_ID_WITH_DASH = /^([-])|(((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))([\,](((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))))*\.?$/i;//alternateemailwithdash
var ALTERNATE_EMAIL_ID_WITH_COMMA = /^(((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))),{0,1}((((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))))*\.?$/i;//alternateemailwithdash
var NUMERICS = /^[0-9]*$/;//numeric		:only number are allowed
var ALPHABETS = /^[\sa-zA-Z\'\-]+$/;//alphabet  :only Alphabets
var CITY = /^[a-zA-Z ]*$/;//city	  :alphabats and only space
var PHONENO = /^((\+){0,1}[0-9][0-9](\-){0,1}){0,1}([0-9]+(\-)*[0-9]+)+$/; //phoneno  	:numbers and Special Characters (-,+)
var MULTI_PHONENO = /^((\+){0,1}[0-9][0-9](\-){0,1}){0,1}[0-9]+(\-){0,1}[0-9]+(([\/]{0,1})+((\+){0,1}[0-9][0-9](\-){0,1}){0,1}[0-9]+(\-){0,1}[0-9]+)*$/; //multiphoneno  	:numbers and Special Characters (-,+,/,,)
var ALPHANUMSPECIAL = /^([0-9a-zA-Z\@\*\(\)\-\+\.\s\/\,]*)[a-zA-Z\@\*\(\)\-\+\.\s\,\/]+([0-9a-zA-Z\@\*\(\)\-\+\.\s\/\,]*)$/;//alphanumspecial  	:Alphanumeric and Special Characters (@,*, (,), -, +,/,., Space and ,)
var ALPHANUMSPECIALGRADE = /^([0-9a-zA-Z\-\+\.\s\/\,]*)[a-zA-Z\-\+\.\s\,\/]+([0-9a-zA-Z\-\+\.\s\/\,]*)$/;//alphanumspecial  	:Alphanumeric and Special Characters (-, +,/,., Space)
var ALPHANUMSPECIALWITHEQUALTO = /^([0-9a-zA-Z\=\@\*\(\)\-\+\.\s\/\,'"&;:]*)[a-zA-Z\@\*\(\)\-\+\.\s\,\/\=]+([0-9a-zA-Z\=\@\*\(\)\-\+\.\s\/\,'"&;:]*)$/;//alphanumspecialwithequalto  	:Alphanumeric and Special Characters (@,=,*, (,), -, +,/,., Space and ,)
var ALPHANUMSPECIALMARQUEE = /^([0-9a-zA-Z\*\.\s\-\+\,\/]*)[a-zA-Z\*\.\,\-\+\/\s]+([0-9a-zA-Z\*\.\,\s\-\+\/]*)$/;//alphanumspecialmarquee  	:Alphanumeric and Special Characters (*, -, +,/,. and space)
var ALPHANUMSPECIALMARQUEECHAR = /^([0-9a-zA-Z\*\.\s\-\+\,\/]*)[a-zA-Z\*\@\.\,\-\+\/\s]+([0-9a-zA-Z\*\@\.\,\s\-\+\/]*)$/;//alphanumspecialmarquee  	:Alphanumeric and Special Characters (*, -, +,/,.,@ and space)
var PASSWORD = /^((?=.*[a-zA-Z])(?=.*\d)(?=.*[!@#$_\.\(\)])[a-zA-Z0-9!@#$_\.\(\)]{8,50})+$/;//password	 :Allows Min 8 and Max. 50 alphanumeric and Special Characters (!,@,#,$,_,.,(,)), Password must comprise of at least one alphanumeric and Special Character (!,@,#,$,_,.,(,))
var FULLNAME = /^([a-zA-Z\'\-\.\s]*){0,1}[a-zA-Z]+([a-zA-Z0-9\'\-\.\s]*)$/;//fullname    :characters and Special character (â€™,- , .,Space)
var DOCNAME = /^([a-zA-Z0-9\_]+)+([a-zA-Z0-9\s\-\_\/\\]*)$/; //docname    Allows  Alphanumeric and Special Characters (-,/,\,space)
var MANDOCNAME = /^([a-zA-Z0-9\s\-]+)+([a-zA-Z0-9\s\-]*)$/; //mandocname    Allows  Alphanumeric and Special Characters (space,-)
var BIDMANDOCNAME = /^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\~\#\$\{\}\:\.]+([0-9a-zA-Z\s\~\#\$\{\}\:\.]*)$/; //mandocname    Allows  Alphanumeric and Special Characters except  & = " \ / %
var COMPANYNAME = /^([0-9a-zA-Z\-\.\&\(\)\s]*)[a-zA-Z]+([0-9a-zA-Z\-\.\&\(\)\s]*)$/;//companyname   :Alphanumeric and Special character (- , ., &, (, ), Space) //Changes Bug Id #30329
var KEYWORD = /^([a-zA-Z0-9\,\s]*)[a-zA-Z\s]+([a-zA-Z0-9&\,\-\/\.\s]*)$/;//keyword  :characters and Special Characters (/ , - , ., &, Space)
var NEWPAT = /^([a-zA-Z0-9@\-\_\.\s]*)$/;
var WEBSITE =/^([a-zA-Z0-9_\-]+(?:\.[a-zA-Z0-9_\-]+)(?:\.[a-zA-Z0-9_\-]+)*\.[a-zA-Z]{2,4}(?:\/[a-zA-Z0-9_]+)*(?:\/[a-zA-Z0-9_]+\.[a-zA-Z]{2,4}(?:\?[a-zA-Z0-9_]+\=[a-zA-Z0-9_]+)?)?(?:\&[a-zA-Z0-9_]+\=[a-zA-Z0-9_]+)*)$/;//website
var URL = /^http(s)?:\/\/(www\.)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;
var ALPHANUMWITHSPACE =/^([0-9a-zA-Z\s]*)[a-zA-Z]+([0-9a-zA-Z\s]*)$/;//alphanumwithspace  :Alphanumeric and Special Characters (Space)
var CLIENTNAME =/^([0-9a-zA-Z\s]*)[a-zA-Z]+([0-9a-zA-Z\s\-\/\&]*)$/;//clientname  :Alphanumeric and Special Characters (-,/,&space)
var NUMWITHDECIMAL = "^\\d.*?\\.\\d{decimalUpto}$";//numwithdecimal  :decimal with specified digits
var INTEGERONLY = /^[1-9]\d*$/;// old one/^[1-9]/ integeronly:allows integer from 1-9 digits only
var POSITIVENO = /^\d+$/;//positiveonly: not allows negative value
var UPTOFIVEDECIMAL=/^\s*-?[0-9]\d*(\.\d{1,5})?\s*$/; //maximum five decimal value allow
var POSITIVEWITHDECIMAL=/^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$/;
var UPTOFIVEDECIMALSECOND=/^\s*-?[0-9]\d{0,9}(\.\d{1,5})?\s*$/; //maximum five decimal value allow
var BRIEF=/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\(\)_:&\,\+]+([0-9a-zA-Z\s\-\/\.\(\)_:&\,\+\s]*)$/; //auction brief :Alphanumeric and Special Characters (()_:&,+, /, -, ., Space)
var BRIEFREMARK=/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\(\)%&\,\+]+([0-9a-zA-Z\s\-\/\.\(\)%&\,\+\s]*)$/; //Negotiation committee publish remark: Allows Max. 1000 alphabets, numbers and special characters ((,),&,comma, -, +,/,.,%, Space)
var BRIEFCASEDOCNAME=/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\(\)_:&\,+]+([0-9a-zA-Z\s\-\/\.\(\)_:&\+\s]*)$/; //auction brief :Alphanumeric and Special Characters (()_:&,+, /, -, ., Space)
var TENDERFORMNAME =/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\:]+([0-9a-zA-Z\s\-\/\.\:\s]*)$/; //TenderFormName:Allows Max. 500 characters, numbers and special characters ( / , - , .,:)  // Allow Colon(:) as per CR #30847 
var UPTODECIMAL = "^\\s*-?[0-9]\\d*(\\.\\d{1,decimal})?\\s*$";
var ALPHANUMWITHSPACEDECIMAL =/^([0-9a-zA-Z\s]*)[0-9a-zA-Z]+([0-9a-zA-Z\s\.]*)$/;//alphanumwithspacedecimal  :Alphanumeric and Special Characters (Space) Decimal
var UPTOFIVENUM = /^[1-5]*$/;//numeric		:only number are allowed
var UPTONINENUM = /^[1-9]*$/;//uptonine		:only number are allowed
var ONETONINENUM = /^[1-9]*$/;//uptonine		:only number are allowed
var POSITIVECOUNT = "^\\d{1,count}$"; //positivecount
var UPTOFIVEDECIMALNUMERIC=/^[0-9]\d{0,4}$/; //maximum five decimal value allow

var COMMAINVALID=/^[0-9a-zA-Z\s\\\/\-\(\)\&]+[0-9a-zA-Z\s\\\/\-\(\)\&]*$/
//var COMMAINVALID= /^([0-9a-zA-Z\s\\\/\-\(\)\&]+(([0-9a-zA-Z\s\\\/\-\(\)\&]*([\,]){0,1})*[0-9a-zA-Z\s\\\/\-\(\)\&]+)*)*$/;//commainvalid  : it will never accept string starts with ends with Comma(,) . Not accept adjecent Comma(,) in a string
var TXTAREA =/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\,]+([0-9a-zA-Z\s\-\/\.\'\&\(\)\,]*)$/; //txtarea :Alphanumeric and Special Characters (/,-,.,',&,(,),Comma and space) //Bug Id: 19077 allow & and ( ) brackets ,and it will apply to all txtarea validation. bcoze live client use this in old application. 
var ADDRESS =/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\,\&\:\;]+([0-9a-zA-Z\s\-\/\.\,\&\:\;]*)$/; //address :Characters numbers and special characters (/ , - , ., ,, Space, &, :, ;)
//To check confirm password against password //confirmpwd
//</REGEX>
var ALPHANUMSPECIALRTF = /^([0-9a-zA-Z\=\:\,\#\&\;\'\"\>\<\@\*\(\)\-\+\.\s\/]*)[a-zA-Z]+([0-9a-zA-Z\=\:\,\#\&\;\'\"\>\<\@\*\(\)\-\+\.\s\/]*)$/;//alphanumspecialrtf  	:Alphanumeric and Special Characters (@,*, (,), -, +,/,., Space,<,>,#,&,',",;,=,: and ,)
var REJECTREMARK = /^([0-9a-zA-Z\=\:\,\#\&\;\'\"\>\<\@\*\(\)\-\+\.\s\/]*)([0-9a-zA-Z\!\@\#\$\%\^\&\*\(\)\/\*\-\+\,\.\?\>\<\:\;\'\"\`\_\[\{\}\]\|\\\=\s\/]*)$/;
var VALIDATIONMESSAGE = /^([0-9a-zA-Z\.\s\,]*)[a-zA-Z]+([0-9a-zA-Z\.\s\,]*)$/;//validationmessage  	:Characters and Special Characters (Space,(.) and(,))
var NOSPACE = /^[\S]+$/;
var TENDERBRIEF =/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\(\)_:&\'\,\+]+([0-9a-zA-Z\s\-\/\.\(\)_:&\,\+\s]*)$/;
var REFERENCENO =/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\(\)_:&\,\+]+([0-9a-zA-Z\s\-\/\.\(\)_:&\,\+\s]*)$/;
var REBATENAME=/^([0-9a-zA-Z\(\)\-\&\+\_\s]*)[0-9a-zA-Z\s\(\)\-\&\+\_]+([0-9a-zA-Z\s\(\)\-\&\+\_]*)$/; //alphanumeric and special character like(- Space &()+_) allow
var ALPHANUMWITHNEWCHAR = /^([0-9a-zA-Z\s]*)[0-9a-zA-Z\+\-\.\/\(\)\s]+([0-9a-zA-Z\+\-\.\/\(\)\s]*)$/;//alphanumwithnewchar   :Alphanumeric and special characters ((,), -, +,/,., Space)
var ALPHANUMWITHCHAR = /^([0-9a-zA-Z\s]*)[0-9a-zA-Z\,\-\.\/\s]+([0-9a-zA-Z\,\-\.\/\s]*)$/;//alphanumeric and Special Characters (/,-,.,, and space)
var ALPHANUMERICWITHSPECIAL = /^([0-9a-zA-Z\s]*)[0-9a-zA-Z\+\-\.\/\(\)\,\s]+([0-9a-zA-Z\+\-\.\/\(\)\,\s]*)$/; //Alphanumeric and special characters ((,), -, +,/,., Space and comma)
var SPECIALKEYWORD = /^([0-9a-zA-Z\s]*)[0-9a-zA-Z\@\*\+\-\.\/\(\)\,\s]+([0-9a-zA-Z\@\*\+\-\.\/\(\)\,\s]*)$/; //Alphanumeric and special characters (@,*,(,), -, +,/,., Space and comma)
var SPECIALKEYWORDWITHNUMBER = /^([0-9a-zA-Z\s]*)[0-9a-zA-Z\@\*\+\-\.\/\(\)\s]+([0-9a-zA-Z\@\*\+\-\.\/\(\)\s]*)$/; //Alphanumeric and special characters (@,*,(,), -, +,/,., Space and comma)
var SPECIALALPHANUMERIC = /^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\(\)\+\@\*]+([0-9a-zA-Z\s\-\/\.\(\)\+\@\*]*)$/; //alphanumeric and special character (@,*, (,), -, +,/,., Space)
var ALPHAWITHSPECIAL = /^([0-9a-zA-Z\s]*)[a-zA-Z\-\.\/\s]+([0-9a-zA-Z\-\.\/\s]*)$/; //Alphabates and numbers and special characters (.,-,/), not only numeric allow
var ALPHAWITHSOMESPECIAL = /^([0-9a-zA-Z\s]*)[a-zA-Z\-\.\'\s]+([0-9a-zA-Z\-\.\'\s]*)$/; //Alphabates and special characters (.,-,')
var TENDERKEYWORD=/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\(\)\+\@\*\,]+([0-9a-zA-Z\s\-\/\.\(\)\+\@\*\,]*)$/;
var FAQBRIEF=/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\(\)_:&\'\,\+]+([0-9a-zA-Z\s\-\/\.\(\)_:&\?\,\+\s]*)$/;
var COMMONKEYWORD=/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\(\)\+\@\*\&\,]+([0-9a-zA-Z\s\-\/\.\(\)\+\@\*\&\,]*)$/;//alphanumspecial  	:Alphanumeric and Special Characters (@,*, (,), -, +,/,., Space and &)
var CHANGESKEYWORD=/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\(\)\+\@\*\&\,]+([0-9a-zA-Z\s\-\/\.\(\)\+\@\*\&\,]*)$/;//alphanumspecial  	:Alphanumeric and Special Characters (@,*, (,), -, +,/,., Space and &)
var PERCENTAGE = /^-?[0-9]+(\.[0-9]{1,5})?%?$|^-?(100)(\.[0]{1,5})?%?$/;//numeric:only number are allowed with decimal
//Used for  allowing & in address and name in create client and department
var ALPHANUMSPECIALWITHAND = /^([0-9a-zA-Z\@\*\(\)\-\+\.\s\/\,]*)[a-zA-Z\@\*\(\)\-\+\.\s\,\/]+([0-9a-zA-Z\@\*\(\)\-\+\.\s\/\,\&]*)$/;//ALPHANUMSPECIALWITHAND  	:Alphanumeric and Special Characters (@,*, (,), -, +,/,.,&, Space and ,)
var ALPHANUMSPECIALWITHOUTCOMMA = /^([0-9a-zA-Z\@\*\(\)\-\+\.\s\/]*)[a-zA-Z\@\*\(\)\-\+\.\s\/]+([0-9a-zA-Z\@\*\(\)\-\+\.\s\/\&]*)$/;//ALPHANUMSPECIALWITHAND  	:Alphanumeric and Special Characters (@,*, (,), -, +,/,.,&, Space)
var NEGOTIATIONREMARKS = /^([0-9a-zA-Z\s]*)[0-9a-zA-Z\+\-\.\/\(\)\,\s]+([0-9a-zA-Z\+\-\.\/\(\)\,\%\s]*)$/; //Alphanumeric and special characters ((,), -, +,/,.,%, Space and comma)
var NUMERICFEWALPHA = /^([0-9a-zA-Z\&\_\-\.\s\(\)\/\,]*)[0-9a-zA-Z\&\_\-\.\s\(\)\,\/]+([0-9a-zA-Z\&\_\-\.\s\(\)\/\,\&]*)$/;//alphabets, numbers and special characters (dot, -, /, comma, space,(,), &, _)
var DATEDDMMYYYY =/^(0[1-9]|1\d|2\d|3[01])\/(0[1-9]|1[0-2])\/(19|20)\d{2} (0\d|1\d|2[0-3]):(0\d|1\d|2\d|3\d|4\d|5\d)$/;
var DATEMMDDYYYY =/^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2} (0\d|1\d|2[0-3]):(0\d|1\d|2\d|3\d|4\d|5\d)$/;
var DATEDDMMMYYYY=/^(0[1-9]|1\d|2\d|3[01])\ (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\ (19|20)\d{2} (0\d|1\d|2[0-3]):(0\d|1\d|2\d|3\d|4\d|5\d)$/;
var ALPHANUMERICSPECIAL_SUBJECT = /^([0-9a-zA-Z\s]*)[0-9a-zA-Z\+\-\*\@\.\/\(\)\,\s]+([0-9a-zA-Z\+\-\*\@\.\/\(\)\,\s]*)$/; //Alphanumeric and special characters ((,), -, +,/,., Space and comma)
var ALPHANUMWITHOUTSPACE=/^[a-zA-Z0-9]*$/;  // only alphabets and numbers
var NUMERICSWITHCOMMA = /^[0-9\,]*$/;///^[0-9]*$/
var SPECIALKEYWORDFORGROUPNAME = /^([0-9a-zA-Z\s]*)[0-9a-zA-Z\@\*\+\-\!\/\(\)\s]+([0-9a-zA-Z\@\*\+\-\!\/\(\)\s]*)$/; //Alphanumeric and special characters (@,*,(,), -, +,/,!, Space) For Group Name
var ALLMONEY = "^-?[0-9]+(.?[0-9]{0,5})?$";
var ALPHANUMERICSPECIAL_CONTACTNO=/^[a-zA-Z_0-9-/]+$/;
var ALPHANUMERICSPECIAL_CONTRACTNAME=/^[a-zA-Z_0-9-/]+$/;

var DATEDDMMYYYYWithoutHM=/^(0[1-9]|1\d|2\d|3[01])\/(0[1-9]|1[0-2])\/(19|20)\d{2}$/;
var DATEMMDDYYYYWithoutHM=/^(0[1-9]|1[0-2])\/(0[1-9]|1\d|2\d|3[01])\/(19|20)\d{2}$/;
var DATEDDMMMYYYYWithoutHM=/^(0[1-9]|1\d|2\d|3[01])\ (Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\$/;

var NUMERICSWITHSLASH = /^[0-9/]*$/;
var COMMANOTALLOWED =/^([0-9a-zA-Z\s]*)[^,:]+([^,:]*)$/; //comma not allowed :Characters numbers and special characters (/ , - , ., ,, Space, &, :, ;)

var TXTAREABIDWITHDRAW =/^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\,]+([0-9a-zA-Z\s\-\/\.\'\&\(\)\,\+\_\:\'\’]*)$/;
//^([0-9a-zA-Z\s]*)[0-9a-zA-Z\s\-\/\.\,]+([0-9a-zA-Z\s\-\/\.\'\&\(\)\,\+\_\:\'\’]*)

var mandatoryCheckBoxIds=new Array();//This is use for dynamic Field page only
function validateTxtComp(comp){
    var compVal = $.trim($(comp).val());
    $(comp).val(compVal);

    var compId = $(comp).attr('id');
    var tbool=true;
    $(".err"+compId).remove();
    var valids = new Array();
	if($(comp).attr("validarr") != undefined){
		valids = $(comp).attr("validarr").split("@@");
	}

    var notcommmsg = true;
    var isreqfired = false;
    if($(comp).attr("validationmsg")!=undefined){
        notcommmsg = false;
    }
    var maxlen = 0;
    for(var i=0;i<valids.length;i++){
        var str = valids[i];
        var minlen = 0;
        var decimalupto = 0;
        var othercmpId = '';
        var uptodecimal=0;
        if(str.indexOf(':', 0)!=-1){
            var lenArr = str.split(':');
            str = lenArr[0];

            if(str == 'length'){
                minlen = parseInt(lenArr[1].split(',')[0]);
                maxlen = parseInt(lenArr[1].split(',')[1]);
            }else if(str == 'numwithdecimal'){
                decimalupto = parseInt(lenArr[1]);
            }else if(str == 'checkloginidpwd'){
                othercmpId = lenArr[1];
            }else if(str == 'confirmpwd'){
                othercmpId = lenArr[1];
            }else if(str == 'confirmAcctNo'){
                othercmpId = lenArr[1];
            }else if(str == 'alphanumwithoutspace'){
            	uptodecimal = lenArr[1];
            }else if(str == 'uptodecimal'){
                uptodecimal = lenArr[1];
            }else if(str == 'positivecount'){
                uptodecimal = lenArr[1];
            }else if(str == 'numanduptodecimal'){
                uptodecimal = lenArr[1];
            }else if(str == 'numanduptodecimalmoneyall'){
            	uptodecimal = lenArr[1];
            }else if(str == 'lengthForNum'){
                maxlen = parseInt(lenArr[1]);
            }else if(str == 'percentage'){
            	uptodecimal = parseInt(lenArr[1]);
            }else if(str == 'percentage1to100'){
            	uptodecimal = parseInt(lenArr[1]);
            }else if(str == 'percentagescore0to100'){
            	uptodecimal = parseInt(lenArr[1]);
            }else if(str == 'percentagepass0to100'){
            	uptodecimal = parseInt(lenArr[1]);
            }else if(str == 'percentageupto100'){
            	uptodecimal = parseInt(lenArr[1]);
            }else if(str == 'percentagesplit0to100'){
            	uptodecimal = parseInt(lenArr[1]);
            }else if(str == 'tenderbrief'){
                maxlen = parseInt(lenArr[1]);
            }else if(str == 'tenderkeyword'){
                maxlen = parseInt(lenArr[1]);
            }else if(str == 'specialkeyword'){
                maxlen = parseInt(lenArr[1]);
            }else if(str == 'changeskeyword'){
                maxlen = parseInt(lenArr[1]);
            }else if(str == 'specialalphanumeric'){
            	maxlen = parseInt(lenArr[1]);
            }else if(str == 'specialkeywordforgroupname'){
                maxlen = parseInt(lenArr[1]);
            }else if(str == 'lessthanequalto100'){
                maxlen = parseInt(lenArr[1]);
            }else if(str == 'referenceno'){
                maxlen = parseInt(lenArr[1]);
            }
            else if(str == 'contractno'){
                maxlen = parseInt(lenArr[1]);
            } else if(str == 'workplanqty'){
            	maxlen = parseFloat(lenArr[1]);
            }else if(str == 'numanduptodecimalwithoutzero'){
                uptodecimal = lenArr[1];
            }
           
        }
        var compValEmpty = (compVal!='');
        UPTODECIMAL="^\\s*-?[0-9]\\d*(\\.\\d{1,decimal})?\\s*$"; // Assign Actual RegExp Changes Bug Id:30211
        switch (str){
            case 'required':
                if(tbool && !compValEmpty){
                    /*$(comp).parent().append("<div class='err"+compId+" ' style='color:red;'><spring:message code='msg_js_common_validations_required' argument='" + ($(comp).attr('title')!='' ? $(comp).attr('title') : 'value')+ "'/>" + "</div>");*/
                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_REQUIRED + " " + ($(comp).attr('title')!='' ? $(comp).attr('title') : 'value') + "</div>");
                    tbool = false;
                    isreqfired = true;
                }
                break;                
            case 'email':
                if(tbool && compValEmpty){  /* && !EMAIL_ID.test(compVal) */
                    
                        /*$(comp).parent().append("<div class='err"+compId+" validationMsg'><spring:message code='msg_js_common_validations_email'/></div>");*/
                        /*$(comp).parent().append("<div class='err"+compId+"' style='color:red; padding-top:5px;'>" + VALIDATE_MSG_INVALID_EMAIL + "</div>");*/
                    	if(compVal.length < 6 || compVal.length > 50 || !(/^[A-Za-z0-9@.\-_]*$/.test(compVal))){  /* length and special characters*/
                    		if(notcommmsg){
                    			$(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_EMAIL_INVALID + "</div>");
                    		}
                			tbool = false;
                		}else if(!EMAIL_ID.test(compVal)){ /* validate email */
                			if(notcommmsg){
                        	     $(comp).parent().append("<div class='err"+compId+"' style='color:red; padding-top:5px;'>" + VALIDATE_MSG_INVALID_EMAIL + "</div>");                        		
                			}
                			tbool = false;
                        }
                    
                }
                break;
            case 'alteremail':
                if(tbool && compValEmpty && !ALTER_EMAIL_ID.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_EMAIL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'NEWPAT':
            debugger;
                if(tbool && compValEmpty && !NEWPAT.test(compVal)){
                    tbool = false;
                }
                break;
            case 'alternateemailwithdash':
                if(tbool && compValEmpty && !ALTERNATE_EMAIL_ID_WITH_DASH.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_EMAIL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alternateemailwithdcomma':
                if(tbool && compValEmpty && !ALTERNATE_EMAIL_ID_WITH_COMMA.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_EMAIL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'emailmsgbox':
                if(tbool && compValEmpty){                                        
                	if(compVal.length < 6 || compVal.length > 50 || !(/^[A-Za-z0-9@.\-_]*$/.test(compVal))){  /* length and special characters*/
                		if(notcommmsg){
                			$(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_EMAIL_MSGBOX + "</div>");
                		}
            			tbool = false;
            		}else if(!ALTER_EMAIL_ID.test(compVal)){ /* validate email */
            			if(notcommmsg){
                    	     $(comp).parent().append("<div class='err"+compId+"' style='color:red; padding-top:5px;'>" + VALIDATE_MSG_INVALID_MSGBOX_EMAIL + "</div>");                        		
            			}
            			tbool = false;
                    }
                }
                break;
            case 'length':
                var tempVal = compVal;
                //console.log(tempVal);
                /*alert(tempVal);*/
                if(compId.indexOf('rtf') != -1){
                //alert(compVal.length);
                //alert(compVal);
                	/*Nikhil CR :28651 removing nbsp and replacing with space*/
                	compVal=compVal.replace(/&nbsp;/g, " ");
                    compVal = compVal.replace(/(\r\n|\n|\r)/gm, " ").replace(/^\s+|\s+$/g, '');
                  //  alert(compVal.length);
                  //  alert(compVal);
                    /*CR:28161 Max length changes Start*/
                    	//compVal = $.trim(stripCKEDITOR(compVal));
                    /*CR:28161 Max length changes end*/
                }
                if(tbool && compValEmpty && minlen!=0 && compVal.length < minlen){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MINIMUM + " " + minlen + " " + VALIDATE_MSG_CHARS_ALLOWED + "</div>");
                    }
                    tbool = false;
                }
                if(tbool && compValEmpty && maxlen!=0 && compVal.length > maxlen){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MAXIMUM + " " + maxlen + " " + VALIDATE_MSG_CHARS_ALLOWED + "</div>");
                    }
                    tbool = false;
                }
                /*if(compId.indexOf('rtf') != -1){
                    compVal = CKEDITOR.tools.htmlEncode(tempVal);
                    $(comp).val(compVal);
                }*/
                break;

               case 'lengthForNum':
                var beforeDot=compVal.split(".",1);
                if(tbool && compValEmpty && maxlen!=0 && beforeDot[0].length > maxlen){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MAXIMUM + " " + maxlen + " " + VALIDATE_NUMBER_LENGTH + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'numeric':
                if(tbool && compValEmpty && !NUMERICS.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_NUMERIC + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'numericwithcomma':
            	if(tbool && compValEmpty && !NUMERICSWITHCOMMA.test(compVal))
            	{
            		if(notcommmsg)
            		{
            			$(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_NUMERIC_WITH_COMMA + "</div>");
            		}
            		tbool =false;	
            	}
            	break;
            case 'uptofive':
                if(tbool && compValEmpty && !UPTOFIVENUM.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_UPTO_FIVE_DECIMAL+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'uptonine':
                if(tbool && compValEmpty && !UPTONINENUM.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_UPTO_NINE_NUMERIC+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'onetonine':
                if(tbool && compValEmpty && !ONETONINENUM.test(compVal) && parseInt(compVal,10)==0){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_UPTO_NINE_NUMERIC+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'integeronly':
                if(tbool && compValEmpty && !INTEGERONLY.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_POSITIVE + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'positiveonly':
                if(tbool && compValEmpty && !POSITIVENO.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_POSITIVE_1 + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alphabet':
                if(tbool && compValEmpty && !ALPHABETS.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_ALPHABETS + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'city':
                if(tbool && compValEmpty && !CITY.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_CITY + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'phoneno':
                if(tbool && compValEmpty && !PHONENO.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_PHONE + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'multiphoneno':
                if(tbool && compValEmpty && !MULTI_PHONENO.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_PHONE + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alphanumspecial':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMSPECIAL.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alphanumspecialgrade':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMSPECIALGRADE.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL + "</div>");
                    }
                    tbool = false;
                }
                break;    
			case 'alphanumspecialwithequalto':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMSPECIALWITHEQUALTO.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alphanumspecialmarquee':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMSPECIALMARQUEE.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alphanumspecialmarqueechar':
            	
            	if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMSPECIALMARQUEECHAR.test(compVal))){
                     if(notcommmsg){
                         $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL_CHAR + "</div>");
                     }
                     tbool = false;
                 }
                 break;
                
                
            case 'password':
                if(tbool && compValEmpty && !PASSWORD.test(compVal)){
                    if(notcommmsg){
                    	//alert(compVal.search(/^[A-Za-z0-9][A-Za-z-9, %^&*-+=|\{}[]:;"'~`<,>\/?]+$/));
                    	if(compVal.length < 8 || compVal.length > 50 ||  (/^(?=.*\d)(?=.*[a-zA-Z])(?=.*[\{\}\'\"\?\^\|\[\]\-\_<>\:\;\+\*\`\~\\]).{6,}$/.test(compVal))){
                    		$(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_PASSWORD + "</div>");
                    	}else{
                    		$(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_PASSWORD_SPECIAL_CHAR +"</div>");
                    	}
                    }
                    tbool = false;
                }
                break;
            case 'fullname':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !FULLNAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_FULL_NAME + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'docname':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !DOCNAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_DOC_NAME + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'mandocname':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !MANDOCNAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_DOC_NAME + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'companyname':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !COMPANYNAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_COMPANY_NAME + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'keyword':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !KEYWORD.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_KEYWORD + "</div>");
                    }
                    tbool = false;
                }
                break;
               case 'tenderkeyword':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !TENDERKEYWORD.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_KEYWORD + "</div>");
                    }
                    tbool = false;
                }
                else if(maxlen<compVal.length){
                     if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_TENDERKEYWORD_LENGTH + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'website':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !WEBSITE.test(compVal) && !URL.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_WEBSITE + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alphanumwithspace':
                if(tbool && compValEmpty && !ALPHANUMWITHSPACE.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_ALPHA_NUM_SPACE + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alphanumwithspacedecimal':
                if(tbool && compValEmpty && !ALPHANUMWITHSPACEDECIMAL.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_ALPHA_NUM_SPACE_DECIMAL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alphanumwithoutspace':
                if(tbool && compValEmpty && (!ALPHANUMWITHOUTSPACE.test(compVal) || compVal.length > uptodecimal)){
                	if(notcommmsg){
                        $(comp).parent().append('<div class="err'+compId+' validationMsg clearfix"> Allows Max. '+uptodecimal+' alphabets and numbers </div>');
                    }
                    tbool = false;
                }
                break;
            case 'clientname':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !CLIENTNAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_CLIENT_NAME + "</div>");
                    }
                    tbool = false;
                }
                break;

            case 'numwithdecimal':
                if(tbool && compValEmpty){
                    NUMWITHDECIMAL = NUMWITHDECIMAL.replace('decimalUpto',decimalupto);
                    var decimalRegex = new RegExp(NUMWITHDECIMAL);
                    if (!decimalRegex.test(compVal)){
                        if(notcommmsg){
                            $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_NUM_DECIMAL + " " +decimalupto+"</div>");
                        }
                        tbool = false;
                    }
                }
                break;
				
				
            case 'nonzero':
				if(tbool && compValEmpty){
					if(eval(compVal)==0){
						if(notcommmsg){
							$(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_NOZERO +"</div>");
						}
						tbool = false; 
					}
				}
				break;
				
            case 'uptodecimal':
                if(tbool && compValEmpty ){
                    UPTODECIMAL=UPTODECIMAL.replace('decimal',uptodecimal);
                    var decimalRegex = new RegExp(UPTODECIMAL);
                    if(compVal!=null && compVal!= ""){
                    if (!decimalRegex.test(compVal)){
                        if(notcommmsg){
                            $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_MAXIMUM+" "+uptodecimal +" "+VALIDATE_MSG_DECIMALPOINT+"</div>");
                        }
                        tbool = false;
                    }
                        }
                }
                break;
            case 'positivecount':
                if(tbool && compValEmpty ){
                	POSITIVECOUNT="^\\d{1,"+uptodecimal+"}$";
                    //POSITIVECOUNT=POSITIVECOUNT.replace('count',uptodecimal);
                    var countRegex = new RegExp(POSITIVECOUNT);
                    if (!countRegex.test(compVal) || compVal[0] == 0){
                        if(notcommmsg){
                            $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>Allows Max. "+uptodecimal +" positive whole numbers</div>");
                        }
                        tbool = false;
                    }
                }
                break;
            case 'confirmpwd':
                if(tbool && compValEmpty && compVal != $('#txt'+othercmpId).val()){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_CONF_PASSWORD +' ' + $('#txt'+othercmpId).attr('title') + "</div>");
                    }
                    tbool = false;
                }
                break;
			 case 'checkloginidpwd':
				if(tbool && compValEmpty && compVal == $('#txt'+othercmpId).val()){
					if(notcommmsg){
						$(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_SAME_PASSWORD_AS_LOGINID + "</div>");
					}
					tbool = false;
				}
				break;
			  case 'confirmAcctNo':
	                if(tbool && compValEmpty && compVal != $('#txt'+othercmpId).val()){
	                    if(notcommmsg){
	                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + ($(comp).attr('title')!='' ? $(comp).attr('title') : 'value') + ' ' +VALIDATE_MSG_INVALID_CONF_ACCTNo +' ' + $('#txt'+othercmpId).attr('title') + "</div>");
	                    }
	                    tbool = false;
	                }
	                break;
            case 'uptofivedecimal':
                if(tbool && compValEmpty && !UPTOFIVEDECIMAL.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'> "+VALIDATE_MSG_MAXIMUM+" "+($(comp).attr('title')!='' ? $(comp).attr('title') : 'value')+" "+VALIDATE_MSG_DECIMALPOINT+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'uptofivedecimalsecond':
            	if(tbool && compValEmpty && !POSITIVEWITHDECIMAL.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_POSITIVE_1 + "</div>");
                    }
                    tbool = false;
                }else if(tbool && compValEmpty && !PERCENTAGE.test(compVal)){
            		 if(notcommmsg){
            			 $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix' style='color:red;'>"+" "+VALIDATE_MSG_INVALID_FINAL_NETVALUE_DEC+"</div>");
            			// $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+" "+($(comp).attr('title')!='' ? $(comp).attr('title') : 'value')+" "+VALIDATE_MSG_INCDECVAL_IN_PER+"</div>");
            			 tbool = false;
            		 }
                 }
            	 else if(tbool && compValEmpty && !UPTOFIVEDECIMALSECOND.test(compVal)){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'> "+VALIDATE_MSG_MAXIMUM+" "+VALIDATE_MSG_INVALID_FINAL_NETVALUE_NUM+"</div>");
                    tbool = false;
                }
                break;
            case 'brief':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !BRIEF.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_ALLOW_MAX+" "+maxlen+" "+VALIDATE_MSG_BRIEF+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'briefcasedocname':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !BRIEFCASEDOCNAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_ALLOW_MAX+" "+maxlen+" "+VALIDATE_MSG_BRIEFCASEDOCNAME+"</div>");
                    }
                    tbool = false;
                }
                break;    
                case 'tenderbrief':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !TENDERBRIEF.test(compVal) || maxlen<compVal.length)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATE_MSG_ALLOW_MAX+" "+maxlen+" "+VALIDATE_MSG_TENDERBRIEF+"</div>");
                    }
                    tbool = false;
                }
                break;
                case 'referenceno':
                    if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !REFERENCENO.test(compVal) || maxlen<compVal.length)){
                        if(notcommmsg){
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATE_MSG_ALLOW_MAX+" "+maxlen+" "+VALIDATE_MSG_REFERENCENO+"</div>");
                        }
                        tbool = false;
                    }
                    break;
            case 'commainvalid':
				//remove last comma from string.
				if(compVal.lastIndexOf(",") == compVal.length-1){
					compVal = compVal.substring(0,compVal.lastIndexOf(","));
				}
				//remove first comma from string.
				if(compVal.indexOf(",") == 0){
					compVal = compVal.substring(1,compVal.length);
				}
				$(comp).val(compVal);
				var tArr = compVal.split(",");
				for(var t1=0;t1<tArr.length;t1++){
				
					if(tbool && compValEmpty && (/\-{2}/.test(tArr[t1]) || !COMMAINVALID.test(tArr[t1]))){
						if(notcommmsg){
							$(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_COMMAINVALID+"</div>");
						}
						tbool = false;
					}
				}
                break;
            case 'alphanumspecialrtf':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMSPECIALRTF.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'rejectremark':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !REJECTREMARK.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'percentage' :
                if(tbool && compValEmpty){
                	var decimalRegex = null;
                	if(uptodecimal != 0){
                		UPTODECIMAL=UPTODECIMAL.replace('decimal',uptodecimal);
                        decimalRegex = new RegExp(UPTODECIMAL);
                	}
                    if((parseFloat(compVal)<=0 || parseFloat(compVal)>100 ) || (uptodecimal!=0 && !decimalRegex.test(compVal))){
                        $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+" "+($(comp).attr('title')!='' ? $(comp).attr('title') : 'value')+" "+VALIDATE_MSG_INCDECVAL_IN_PER+"</div>");
                         tbool = false;
                    }
                }
                break;
            case 'percentage1to100' :
                if(tbool && compValEmpty){
                    var decimalRegex = null;
                    if(uptodecimal != 0){
                        UPTODECIMAL=UPTODECIMAL.replace('decimal',uptodecimal);
                                decimalRegex = new RegExp(UPTODECIMAL);
                    }
                     if(!PERCENTAGE.test(compVal)){
                    	 $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATION_PERCENTAGE+"</div>");
                    	 tbool = false;
                     }else if(!decimalRegex.test(compVal)){   
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATE_MSG_MAXIMUM+" "+uptodecimal+" "+" "+VALIDATE_MSG_DECIMALPOINT+"</div>");
                             tbool = false;
                    }else{
                        if((parseFloat(compVal)<0 || parseFloat(compVal)>100 )){
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+" "+VALIDATE_MSG_REBATE_PERCENTAGE+"</div>");
                             tbool = false;
                        }
                    }
                }
                break;
            case 'percentageupto100' :
                if(tbool && compValEmpty){
                    var decimalRegex = null;
                    if(uptodecimal != 0){
                        UPTODECIMAL=UPTODECIMAL.replace('decimal',uptodecimal);
                                decimalRegex = new RegExp(UPTODECIMAL);
                    }
                    if(!decimalRegex.test(compVal)){   
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATE_MSG_COMMON_NUM_DECIMAL+" "+uptodecimal+" "+" "+VALIDATE_MSG_DECIMALPOINT+"</div>");
                             tbool = false;
                    }else{
                        if((parseFloat(compVal)<0 || parseFloat(compVal)>100 )){
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+" "+VALIDATE_MSG_REBATE_PERCENTAGE+"</div>");
                             tbool = false;
                        }
                    }
                }
                break;
            case 'percentagescore0to100' :
                if(tbool && compValEmpty){
                    var decimalRegex = null;
                    if(uptodecimal != 0){
                        UPTODECIMAL=UPTODECIMAL.replace('decimal',uptodecimal);
                                decimalRegex = new RegExp(UPTODECIMAL);
                    }
                     if(!PERCENTAGE.test(compVal)){
                    	 $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATION_WEIGHTAGE_TEXT_PERCENTAGE_BEFORE +" "+ uptodecimal +" "+ VALIDATION_WEIGHTAGE_TEXT_PERCENTAGE_AFTER +"</div>");
                    	 tbool = false;
                     }else if(!decimalRegex.test(compVal)){ 
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATE_MSG_MAXIMUM+" "+uptodecimal+" "+" "+VALIDATE_MSG_DECIMALPOINT+"</div>");
                             tbool = false;
                    }else{
                        if((parseFloat(compVal)<= 0 || parseFloat(compVal)>100 )){
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+" "+VALIDATE_MSG_WEIGHTAGE_PERCENTAGE+"</div>");
                             tbool = false;
                        }
                    }
                }
                break;
            case 'percentagepass0to100' :
                if(tbool && compValEmpty){
                    var decimalRegex = null;
                    if(uptodecimal != 0){
                        UPTODECIMAL=UPTODECIMAL.replace('decimal',uptodecimal);
                                decimalRegex = new RegExp(UPTODECIMAL);
                    }
                     if(!PERCENTAGE.test(compVal)){
                    	 $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATION_WEIGHTAGE_TEXT_PERCENTAGE_BEFORE +" "+ uptodecimal +" "+ VALIDATION_WEIGHTAGE_TEXT_PERCENTAGE_AFTER +"</div>");
                    	 tbool = false;
                     }else if(!decimalRegex.test(compVal)){ 
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATE_MSG_MAXIMUM+" "+uptodecimal+" "+" "+VALIDATE_MSG_DECIMALPOINT+"</div>");
                             tbool = false;
                    }else{
                        if((parseFloat(compVal)< 0 || parseFloat(compVal)>100 )){
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+" "+VALIDATE_MSG_WEIGHTAGE_PERCENTAGE+"</div>");
                             tbool = false;
                        }
                    }
                }
                break;
            case 'percentagesplit0to100' :
                if(tbool && compValEmpty){
                    var decimalRegex = null;
                    if(uptodecimal != 0){
                        UPTODECIMAL=UPTODECIMAL.replace('decimal',uptodecimal);
                                decimalRegex = new RegExp(UPTODECIMAL);
                    }
                     if(!PERCENTAGE.test(compVal)){
                    	 $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATION_SPLIT_PERCENTAGE_BEFORE +" "+ uptodecimal +" "+ VALIDATION_SPLIT_PERCENTAGE_AFTER +"</div>");
                    	 tbool = false;
                     }else if(!decimalRegex.test(compVal)){ 
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATE_MSG_MAXIMUM+" "+uptodecimal+" "+" "+VALIDATE_MSG_DECIMALPOINT+"</div>");
                             tbool = false;
                    }else{
                        if((parseFloat(compVal)<= 0 || parseFloat(compVal)>100 )){
                            $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+" "+VALIDATE_MSG_SPLIT_ORDER_PERCENTAGE+"</div>");
                             tbool = false;
                        }
                    }
                }
                break;
            case 'txtarea':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !TXTAREA.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MAXIMUM + " " + maxlen + " " + VALIDATE_MSG_TXTAREA + "</div>");
                    }
                    tbool = false;
                }
                break;
                
                case 'txtareabidwithdraw':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !TXTAREABIDWITHDRAW.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MAXIMUM + " " + maxlen + " " + VALIDATE_MSG_TXTAREA + "</div>");
                    }
                    tbool = false;
                }
                break;
                
                
            case 'address':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ADDRESS.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MAXIMUM + " " + maxlen + " " + VALIDATE_MSG_ADDRESS + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'rebatename':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !REBATENAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATE_MSG_ALLOW_MAX+" "+maxlen+" "+VALIDATE_TENDER_REFERENCE_NO+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'validationmessage':
                if(tbool && compValEmpty && !VALIDATIONMESSAGE.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATION_VALIDATIONMESSAGE+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'numanduptodecimal':
                if(tbool && compValEmpty ){
                    if(compVal!=null && compVal!= ""){
                        UPTODECIMAL=UPTODECIMAL.replace('decimal',uptodecimal);
                        var decimalRegex = new RegExp(UPTODECIMAL);
                        if(compVal.indexOf('.', 0)==-1){
                            if (!NUMERICS.test(compVal)){
                                if(notcommmsg){
                                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_NUMERIC + "</div>");
                                }
                                tbool = false;
                            }
                        }else{
                            var number=compVal.split('.')[0];
                            if (!NUMERICS.test(number)){
                                if(notcommmsg){
                                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_NUMERIC + "</div>");
                                }
                                tbool = false;
                            }else{
                                if (!decimalRegex.test(compVal)){
                                    if(notcommmsg){
                                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_MAXIMUM+" "+uptodecimal +" "+VALIDATE_MSG_DECIMALPOINT+"</div>");
                                    }
                                    tbool = false;
                                }
                            }
                        }
                }
            }
            break;
            case 'numanduptodecimalmoneyall':
                if(tbool && compValEmpty ){
                    if(compVal!=null && compVal!= ""){
                        UPTODECIMAL=UPTODECIMAL.replace('decimal',uptodecimal);
                        var decimalRegex = new RegExp(UPTODECIMAL);
                        var allMoneyRegx = new RegExp(ALLMONEY);
                        if(compVal.indexOf('.', 0)==-1){
                            if (!allMoneyRegx.test(compVal)){
                                if(notcommmsg){
                                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_NUMERIC + "</div>");
                                }
                                tbool = false;
                            }
                        }else{
                            var number=compVal.split('.')[0];
                            if (!allMoneyRegx.test(number)){
                                if(notcommmsg){
                                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_NUMERIC + "</div>");
                                }
                                tbool = false;
                            }else{
                                if (!decimalRegex.test(compVal)){
                                    if(notcommmsg){
                                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_MAXIMUM+" "+uptodecimal +" "+VALIDATE_MSG_DECIMALPOINT+"</div>");
                                    }
                                    tbool = false;
                                }
                            }
                        }
                }
            }
            break;
			case 'nospace':
				if (tbool && !NOSPACE.test(compVal)){
					if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_MAXIMUM+" "+uptodecimal +" "+VALIDATE_MSG_NO_SPACE+"</div>");
                    }
					tbool = false;
				}
				break;
            case 'alphanumwithnewchar':
            if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMWITHNEWCHAR.test(compVal))){
                if(notcommmsg){
                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_ALPHANUMWITHNEWCHAR + "</div>");
                }
                tbool = false;
            }
            break;
            case 'alphanumwithchar':
            if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMWITHCHAR.test(compVal))){
                if(notcommmsg){
                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_ALPHANUMWITHCHAR + "</div>");
                }
                tbool = false;
            }
            break;
            case 'specialkeyword':
            if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !SPECIALKEYWORD.test(compVal) || maxlen<compVal.length)){
                if(notcommmsg){
                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MAXIMUM + " " + maxlen + " " + VALIDATE_MSG_INVALID_SPECIALKEYWORD + "</div>");
                }
                tbool = false;
            }
            break;
            case 'specialkeywordwithnumber':
            if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !SPECIALKEYWORDWITHNUMBER.test(compVal) )){
                if(notcommmsg){
                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MAXIMUM + " " + maxlen + " " + VALIDATE_MSG_INVALID_SPECIALKEYWORD_NUMBER + "</div>");
                }
                tbool = false;
            }
            break;
            case 'changeskeyword':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !CHANGESKEYWORD.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MAXIMUM + " " + maxlen + " " + VALIDATE_MSG_CHANGESKEYWORD + "</div>");
                    }
                    tbool = false;
                }
            break;
            case 'alphanumericspecial_subject':
            if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMERICSPECIAL_SUBJECT.test(compVal))){
                if(notcommmsg){
                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_ALPHANUMERICWITHSPECIAL + "</div>");
                }
                tbool = false;
            }
            break;
            case 'aplhawithspecial':
            if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHAWITHSPECIAL.test(compVal))){
                if(notcommmsg){
                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_ALPHAWITHSPECIAL + "</div>");
                }
                tbool = false;
            }
            break;
            case 'alphawithsomespecial':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHAWITHSOMESPECIAL.test(compVal))){
                if(notcommmsg){
                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_SPECIAL_CHAR + "</div>");
                }
                tbool = false;
            }
            break;
            case 'commonkeyword':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !COMMONKEYWORD.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_COMMON_KEYWORD + "</div>");
                    }
                    tbool = false;
                }
             break;
            case 'alphanumspecialwithand':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMSPECIALWITHAND.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alphanumspecialwithoutcomma':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMSPECIALWITHOUTCOMMA.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL_COMMA + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'numrericwithfewalpha':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !NUMERICFEWALPHA.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_NUMERICFEWALPHA + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'alphanumericwithspecial':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMERICWITHSPECIAL.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_ALPHANUMERICWITHSPECIAL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'negotiationremarks':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !NEGOTIATIONREMARKS.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_ALPHAWITHSPECIAL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'specialalphanumeric':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !SPECIALALPHANUMERIC.test(compVal) || maxlen<compVal.length)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+VALIDATE_MSG_ALLOW_MAX+" "+maxlen+" "+ VALIDATE_MSG_SPECIALALPHANUMERIC +"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'specialkeywordforgroupname':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !SPECIALKEYWORDFORGROUPNAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_ALPHA_NUM_SPECIAL + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'tenderformname':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !TENDERFORMNAME.test(compVal))){
                	if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_ALLOW_MAX+" "+maxlen+" "+VALIDATE_MSG_FORM_NAME+"</div>");
                	}   
                    tbool = false;
                }
                break;    
            case 'lessthanequalto100':
        		if(tbool && compValEmpty){
        			if((parseFloat(compVal)<0 || parseFloat(compVal)>100 )){
                        $(comp).parent().append("<div class='err"+compId+"' style='color:red;'>"+" "+VALIDATE_MSG_PBG_DETAILS+"</div>");
                         tbool = false;
                    }
        		}
        		break;
            case 'briefRemark':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !BRIEFREMARK.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_ALLOW_MAX+" "+maxlen+" "+VALIDATE_MSG_BRIEFREMARK+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'contractno':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMERICSPECIAL_CONTACTNO.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MAXIMUM + " " + maxlen + " " + VALIDATE_MSG_CONTRACTNO + "</div>");
                    }
                    tbool = false;
                }
                break;
            case 'workplanqty':
            var currentQty=0.00;
        	currentQty=currentQty+parseFloat(compVal);
        	if(tbool && parseFloat(maxlen) >  parseFloat(currentQty) ){
                if(notcommmsg){
                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_WORKPLAN_QTY + "</div>");
                }
                tbool = false;
            }
            break;
            case 'contractname':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !ALPHANUMERICSPECIAL_CONTRACTNAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'> Provide valid Contract No. </div>");
                    }
                    tbool = false;
                }
                break;
            case 'numanduptodecimalwithoutzero':
                if(tbool && compValEmpty ){
                    if(compVal!=null && compVal!= ""){
                        UPTODECIMAL=UPTODECIMAL.replace('decimal',uptodecimal);
                        var decimalRegex = new RegExp(UPTODECIMAL);
                        if(compVal.indexOf('.', 0)==-1){
                            if (!INTEGERONLY.test(compVal)){
                                if(notcommmsg){
                                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_NUMERIC + "</div>");
                                }
                                tbool = false;
                            }
                        }else{
                            var number=compVal.split('.')[0];
                            if (!INTEGERONLY.test(number)){
                                if(notcommmsg){
                                    $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_ONLY_NUMERIC + "</div>");
                                }
                                tbool = false;
                            }else{
                                if (!decimalRegex.test(compVal)){
                                    if(notcommmsg){
                                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_MAXIMUM+" "+uptodecimal +" "+VALIDATE_MSG_DECIMALPOINT+"</div>");
                                    }
                                    tbool = false;
                                }
                            }
                        }
                }
            }
                break;
            case 'bidmandocname':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !BIDMANDOCNAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_INVALID_DOC_NAME + "</div>");
                    }
                    tbool = false;
                }
                break;
               
            case 'numericwithslash':
                if(tbool && compValEmpty && !NUMERICSWITHSLASH.test(compVal)){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'> Allow numeric characters with slash(/)</div>");
                    }
                    tbool = false;
                }
                break;
                
            case 'folderName':  // STQC Change
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !FOLDERNAME.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+VALIDATE_MSG_FOLDER+"</div>");
                    }
                    tbool = false;
                }
                break;
            case 'commanotallowed':
                if(tbool && compValEmpty && (/\-{2}/.test(compVal) || !COMMANOTALLOWED.test(compVal))){
                    if(notcommmsg){
                        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_MAXIMUM + " " + VALIDATE_MSG_COMMANOTALLOWED + "</div>");
                    }
                    tbool = false;
                }
                break;
                
        }
    }
    if(!tbool && !isreqfired && !notcommmsg){
        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+$(comp).attr("validationmsg")+"</div>");
    }
    if(tbool){
            var iswordConversion=$(comp).attr("wordconversion");
            if(iswordConversion=='true'){
            	// Project Task:#24514
            	if(typeof wordconversion === 'undefined'){
            		wordConversionFunction(comp);
            	}
            }
        }else{
            $(comp).parent().find('#divWord_'+$(comp).attr('id')).remove();
        }
          
    return tbool;
}
 function wordConversionFunction(ob){
    if($.trim($(ob).val())!='' && !isNaN($(ob).val())){
        var value=$(ob).val();
        $(ob).parent().find('#divWord_'+$(ob).attr('id')).remove();
        if(wordConversionFormat!=null && wordConversionFormat!='undefined' && wordConversionFormat!=''){
        if(wordConversionFormat == '0'){
            $(ob).parent().append("<div class='clearfix black' style='padding:5px' id='divWord_"+$(ob).attr('id')+"'>"+IndianConvertionAmountInWord(parseFloat(value))+" </div>");
        }
        else{
            $(ob).parent().append("<div style='padding:5px' id='divWord_"+$(ob).attr('id')+"'>"+InternationConvertionAmountInWord(parseFloat(value))+" </div>");
        }
        }
    }else{
    	$("#divWord_"+$(ob).attr('id')).html('');
    }
}
function valOnSubmit(){
    var  vbool = true;
    var txtAreaValArr = new Array();
    var cnt=0;
    $("input[tovalid='true']").each(function(){
        if(!$(this).is(':disabled')  && !validateTxtComp(this)){
            cnt=cnt+1;
            if(cnt==1){
                $(this).focus();
            }
            vbool = false;
        }
    });

    $("textarea[tovalid='true']").each(function(){
        if(!$(this).is(':disabled')){
            var isRTF = false;
            if($(this).attr('id').indexOf('rtf') != -1){
                CKEDITOR.instances[$(this).attr('id')].setData(CKEDITOR.instances[$(this).attr('id')].getData().replace(/-/g,'&#45;'));
                $(this).val(CKEDITOR.instances[$(this).attr('id')].getData());
                isRTF = true;
            }
            if(!validateTxtComp(this)){
                cnt=cnt+1;
                if(cnt==1){
                    $(this).focus();
                }
                vbool = false;
            }else{
                if(!isRTF){
                    txtAreaValArr.push(this);
                }
            }            
        }
    });
    $("select[isrequired='true']").each(function(){
        if(!$(this).is(':disabled')  && !validateCombo(this)){
            cnt=cnt+1;
            if(cnt==1){
                $(this).focus();
            }
            vbool = false;
        }
    });
    $("input[datepicker='yes']").each(function(){
        if(!$(this).is(':disabled')  && !validateEmptyDt(this)){
            cnt=cnt+1;
            if(cnt==1){
                $(this).focus();
            }
            vbool = false;
        }
    });
    $("input[type=checkbox]").each(function(){
        if(!$(this).is(':disabled') && $(this).attr('isrequired')){
        	createMandatoryCheckBoxArray(this);
        }
    });
    hideDynamicFieldsOfGroup();//to hide all fields which are not in selected group in case of dynamic fields with group is available
    vbool=dynamicCheckBoxValidation(vbool);
    if(vbool){
        safePageTextArea(txtAreaValArr);
    }
    return vbool;
}

function safePageTextArea(txtAreaValArr){
    for(var j=0;j<txtAreaValArr.length;j++){        
        $(txtAreaValArr[j]).val(replaceQuotes($(txtAreaValArr[j]).val().replace(/>\s+</g, '><')));
    }
}
function createMandatoryCheckBoxArray(comp){
	var cnt=0;
	for(var i=0;i<mandatoryCheckBoxIds.length;i++){
		var fieldName= $(comp).attr('name');
		if(fieldName==$(mandatoryCheckBoxIds[i]).attr('name')){
			cnt++;
		}
	}
	if(cnt==0){
		mandatoryCheckBoxIds.push(comp);
	}
}
function dynamicCheckBoxValidation(vbool){
	if(mandatoryCheckBoxIds.length > 0){
		var cnt=0;
		for(var i=0;i<mandatoryCheckBoxIds.length;i++){
    		var compName=$(mandatoryCheckBoxIds[i]).attr('name');
    		$('.err'+compName).remove();
		}
    	for(var i=0;i<mandatoryCheckBoxIds.length;i++){
    		var comp=$(mandatoryCheckBoxIds[i]);
    		var compName = $(comp).attr('name');
    		var chkBool =true;
    		$('input[name='+compName+']').each(function(){
    			var cntChecked=0;
    			var isChecked=$(this).attr('checked');
				if(isChecked){
					cntChecked++;
				}
				if(cntChecked>0){
					chkBool=false;
				}
	   	 	 });
    		 if(chkBool){
    			 /* UI Issue #35647 Remove parent()*/
	   			// Reverted By Jitendra. Becasue. It effects on all multiselect checkbox validations.
	   			// STQC Change 
	   			if(compName == "echkEventTypeList3" || compName == "echkEventTypeList5"){
	   				$("#errDiv"+compName).parent().append("<span class='err"+compName+"' style='color:red;'><br/>" + VALIDATE_MSG_SELECT + " " +($(comp).attr('title')!='' ? $(comp).attr('title') : 'value')+"</span>");
	   			}else{
	   				$("#errDiv"+compName).parent().parent().append("<span class='err"+compName+"' style='color:red;'><br/>" + VALIDATE_MSG_SELECT + " " +($(comp).attr('title')!='' ? $(comp).attr('title') : 'value')+"</span>");
	   			}
	   			cnt++;
    		}
    	}
    	if(cnt==0 && vbool){
    		return true;
    	}else{
    		return false;
    	}
    }else{
    	return vbool;
    }
}
function validateCombo(comp){
    var compVal = $(comp).val();
    var compId = $(comp).attr('id');
    var tbool=true;
    $(".err"+compId).remove();
    if(compVal != ''){
		$("#selValidation option[value='']").attr('selected', false);
	}
    if(compVal=='' || compVal==null){
        $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_SELECT + " " +($(comp).attr('title')!='' ? $(comp).attr('title') : 'value')+"</div>");
        tbool = false;
    }
    return tbool;
}
function isValidDate(dateString,dateFormateFlag)
{
	var dateWithOutTime = dateString.split(" ");
	var parts;
	var day = 0;
    var month = 0;	
    var year = 0;
	if(dateFormateFlag!=3){
		parts = dateWithOutTime[0].split("/");	
	}else{
		switch(dateWithOutTime[1]){
		case'Jan':
			dateWithOutTime[1] = 01;
			break;
		case'Feb':
			dateWithOutTime[1] = 02;
			break;
		case'Mar':
			dateWithOutTime[1] = 03;
			break;
		case'Apr':
			dateWithOutTime[1] = 04;
			break;
		case'May':
			dateWithOutTime[1] = 05;
			break;
		case'Jun':
			dateWithOutTime[1] = 06;
			break;
		case'Jul':
			dateWithOutTime[1] = 07;
			break;
		case'Aug':
			dateWithOutTime[1] = 08;
			break;
		case'Sep':
			dateWithOutTime[1] = 09;
			break;
		case'Oct':
			dateWithOutTime[1] = 10;
			break;
		case'Nov':
			dateWithOutTime[1] = 11;
			break;
		case'Dec':
			dateWithOutTime[1] = 12;
			break;
		}
		parts = [dateWithOutTime[0],dateWithOutTime[1],dateWithOutTime[2]];
	}
    
    if(dateFormateFlag == 1 || dateFormateFlag == 3){
    	day = parseInt(parts[0], 10);
        month = parseInt(parts[1], 10);
        year = parseInt(parts[2], 10);
    }else if(dateFormateFlag == 2){
    	day = parseInt(parts[1], 10);
        month = parseInt(parts[0], 10);
        year = parseInt(parts[2], 10);
    }

    if(year < 1000 || year > 3000 || month == 0 || month > 12){
    	return false;
    }
    var monthLength = [ 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 ];

    // Adjust for leap years
    if(year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)){
    	monthLength[1] = 29;
    }

    // Check the range of the day
    return day > 0 && day <= monthLength[month - 1];
}
function validateEmptyDt(comp){
	 var compVal = toJSDate($(comp).val());
	    var compId = $(comp).attr('id');
	    var dateFormate = $(comp).attr('placeholder');
	    var dateFormateArry = dateFormate.split(" ");
	    var tbool=true;
	    $(".err"+compId).remove();
	 /*** Krunal **/
   if($(comp).val()!='' && tbool && !$(comp).attr('readonly')){
   	/* Changed by : Pooja Kakkad
	     * Reason : Apply validation for date dataType & editable true.
	    */
   	if(dateFormateArry.length > 1){
   		if(dateFormateArry[0] == 'DD/MM/YYYY'){
       		if(!DATEDDMMYYYY.test($(comp).val())){
                   $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_DATE_INVALID+"</div>");
                   tbool = false;
               }else if(!isValidDate($(comp).val(),1)){
               	$(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_DATE_INVALID+"</div>");
                   tbool = false;
               }	
       	}else if(dateFormateArry[0] == 'MM/DD/YYYY'){
       		if(!DATEMMDDYYYY.test($(comp).val())){
       			$(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_DATE_INVALID+"</div>");
                   tbool = false;
               }else if(!isValidDate($(comp).val(),2)){
               	$(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_DATE_INVALID+"</div>");
                   tbool = false;
               }
       	}
       	else if(dateFormateArry[1] == 'MMM'){
       		if(!DATEDDMMMYYYY.test($(comp).val())){
       			$(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_DATE_INVALID+"</div>");
                   tbool = false;
               }else if(!isValidDate($(comp).val(),3)){
               	$(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_DATE_INVALID+"</div>");
                   tbool = false;
               }
       	}
   	}else{
          	if(dateFormateArry[0] == 'DD/MM/YYYY'){
          		if(!DATEDDMMYYYYWithoutHM.test($(comp).val())){
                      $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_For_OnlyDATE_INVALID+"</div>");
                      tbool = false;
                          }else if(!isValidDate($(comp).val(),1)){
                          	$(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_For_OnlyDATE_INVALID+"</div>");
                              tbool = false;
                          }	
                  	}else if(dateFormateArry[0] == 'MM/DD/YYYY'){
                  		if(!DATEMMDDYYYYWithoutHM.test($(comp).val())){
                  			$(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_For_OnlyDATE_INVALID+"</div>");
                              tbool = false;
                          }else if(!isValidDate($(comp).val(),2)){
                          	$(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_For_OnlyDATE_INVALID+"</div>");
                              tbool = false;
                          }
                  	}
                  	else if(dateFormateArry[1] == 'MMM'){
                  		if(!DATEDDMMMYYYYWithoutHM.test($(comp).val())){
                  			$(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_For_OnlyDATE_INVALID+"</div>");
                              tbool = false;
                          }else if(!isValidDate($(comp).val(),3)){
                          	$(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>"+VALIDATION_MSG_For_OnlyDATE_INVALID+"</div>");
                              tbool = false;
                          }
                  	}
          	    }
   	
   }
   
   
   if(compVal!='' && tbool){
       if($(comp).attr('datevalidate')!=undefined){
           var compIds = $(comp).attr('datevalidate').split(",");
           $.each(compIds,function(key, value ){
               var datesp=compIds[key].split(":");
               if(datesp[1]=='c'){
               	var compIdDataType = $(comp).attr('datetype');
               	if(compIdDataType=='datetime'){
	                    if(datesp[0]=='ge'){
	                        var cdate=toJSDate(CLIENT_DATETIME.substring(0, CLIENT_DATETIME.lastIndexOf(":"))); /*Changes Bug Id:#30555 Validation proper not work because of seconds in Client DateTime(SeverDateTime)*/ 
	                        if(cdate>compVal){
	                            $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_GE_CURRDATE+"</div>");
	                            tbool = false;
	                        }
	                    }else if(datesp[0]=='gt'){
	                        var cdate=toJSDate(CLIENT_DATETIME.substring(0, CLIENT_DATETIME.lastIndexOf(":")));  /*Changes Bug Id:#30555 Validation proper not work because of seconds in Client DateTime(SeverDateTime)*/
	                        if(cdate>=compVal){
	                            $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_GT_CURRDATE+"</div>");
	                            tbool = false;
	                        }
	                    }else if(datesp[0]=='le'){
	                    	var cdate=toJSDate(CLIENT_DATETIME.substring(0, CLIENT_DATETIME.lastIndexOf(":")));  /*Changes Bug Id:#30555 Validation proper not work because of seconds in Client DateTime(SeverDateTime)*/
	                        if(cdate<compVal){
	                            $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_LE_CURRDATE+"</div>");
	                            tbool = false;
	                        }
	                    }
               	}else{
               		if(datesp[0]=='ge'){
               			var dateonly=CLIENT_DATETIME.split(" ");
	                        var cdate=toJSDate(dateonly[0]);  
	                        if(cdate>compVal){
	                            $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_GE_CURRDATEONLY+"</div>");
	                            tbool = false;
	                        }
	                    }else if(datesp[0]=='gt'){
	                    	var dateonly=CLIENT_DATETIME.split(" ");
	                        var cdate=toJSDate(dateonly[0]); 
	                        if(cdate>=compVal){
	                            $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_GT_CURRDATEONLY+"</div>");
	                            tbool = false;
	                        }
	                    }else if(datesp[0]=='le'){
	                    	var dateonly=CLIENT_DATETIME.split(" ");
	                        var cdate=toJSDate(dateonly[0]); 
	                        if(cdate<compVal){
	                            $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_LE_CURRDATE+"</div>");
	                            tbool = false;
	                        }
	                    }
               	}
               }else if(datesp[1]!='c'){
                   if($('#'+datesp[1]).val()!='' && $('#'+datesp[1]).val()!=null){
                       if(datesp[0]=='ge'){
                           var compareDate = toJSDate($('#'+datesp[1]).val());
                           if(compareDate>compVal){
                               $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_GE_COMPDATE+" "+($('#'+datesp[1]).attr('title')!='' ? $('#'+datesp[1]).attr('title') : 'date')+"</div>");
                               tbool = false;
                           }
                       }
                       else if(datesp[0]=='gt'){
                           var compareDate = toJSDate($('#'+datesp[1]).val());
                           if(compareDate>=compVal){
                               $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_GT_COMPDATE+" "+($('#'+datesp[1]).attr('title')!='' ? $('#'+datesp[1]).attr('title') : 'date')+"</div>");
                               tbool = false;
                           }
                       }
                       else if(datesp[0]=='le'){
                           var compareDate = toJSDate($('#'+datesp[1]).val());
                           if(compareDate<compVal){
                               $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_LE_COMPDATE+" "+($('#'+datesp[1]).attr('title')!='' ? $('#'+datesp[1]).attr('title') : 'date')+"</div>");
                               tbool = false;
                           }
                       }
                       else if(datesp[0]=='lt'){
                           var compareDate = toJSDate($('#'+datesp[1]).val());
                           if(compareDate<=compVal){
                               $(comp).parent().append("<div class='err"+compId+" clearfix' style='color:red;'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_LT_COMPDATE+" "+($('#'+datesp[1]).attr('title')!='' ? $('#'+datesp[1]).attr('title') : 'date')+"</div>");
                               tbool = false;
                           }
                       }
                   }
               }
               if(!tbool){
                   return tbool;
               }
           });
       }
   }
   if($(comp).attr('dtrequired')!=undefined &&  $(comp).attr('dtrequired') == 'true' && compVal==''){
       $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" + VALIDATE_MSG_SELECT + " " +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"</div>");
       tbool = false;
   }
   if(compVal!='' && tbool){
       var isgreater = false;
       if($(comp).attr('comparewith')!=undefined){
           if($(comp).attr('comparewith').indexOf(',', 0)!=-1){
               var compIds = $(comp).attr('comparewith').split(",");
               var startDt = toJSDate($('#'+compIds[0]).val());
               var endDt = toJSDate($('#'+compIds[1]).val());
               if(!(startDt<=compVal && endDt>=compVal)){
                   $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>" +($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_BETWEEN +($('#'+compIds[0]).attr('title')!='' ? $('#'+compIds[0]).attr('title') : 'date')+" and " +($('#'+compIds[1]).attr('title')!='' ? $('#'+compIds[1]).attr('title') : 'date')+"</div>");
                   tbool = false;
               }
           }else{
               isgreater = $(comp).attr('isgreater')!=undefined ? $(comp).attr('isgreater') : false;
               var datecomp = $('#'+$(comp).attr('comparewith'));
               var compDt = toJSDate(datecomp.val());
               if(isgreater=='true' && compDt>=compVal){
                   $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_GREATER +(datecomp.attr('title')!='' ? datecomp.attr('title') : 'date')+"</div>");
                   tbool = false;
               }
               if(isgreater=='false' && compDt<compVal){
                   $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+"  "+VALIDATE_LESSAR +(datecomp.attr('title')!='' ? datecomp.attr('title') : 'date')+"</div>");
                   tbool = false;
               }
           }
       }
       if($(comp).attr('comparetocurrdate')!=undefined && $(comp).attr('comparetocurrdate')=='true'){
           isgreater = $(comp).attr('isgreater')!=undefined ? $(comp).attr('isgreater') : false;
           var currDt = toJSDate(CLIENT_DATETIME);
           if(isgreater=='true' && (currDt>=compVal)){
               $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+" "+VALIDATE_GREATER_SYSDATE+"</div>");
               tbool = false;
           }
           if(isgreater=='false' && (currDt<compVal)){
               $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix'>"+($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+" "+VALIDATE_LESSAR_SYSDATE+"</div>");
               tbool = false;
           }
       }
         if(tbool && $(comp).attr('customvalidation')!=undefined){
            var params = $(comp).attr('customvalidation').split(":"); 
            var tenderMode = $("#selTenderMode").val();
            switch (params[0]){
               case 'corrigendum':                            
               var compIds = params[1].split(",");           
               var currDt = toJSDate(CLIENT_DATETIME);
               if($('#'+compIds[1]).val()!=undefined && $('#'+compIds[0]).val()!=undefined){                
                   var oldDate = toJSDate($('#'+compIds[1]).val());
                   var newDate = toJSDate($('#'+compIds[0]).val());
                   ///if(oldDate!=newDate && currDt>=newDate){
                   var pastEventPublish = $("#jhdPastEventPublish").val();
                   if(pastEventPublish  == 1 && (tenderMode == 1 || tenderMode == 2)){
                   	if(oldDate>newDate){
                           $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix' style='color:red;'>"+VALIDATE_PREPONE_DATE+" "+($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+" and time</div>");
                           tbool = false;
                     }	
                   }
                   if(tbool && oldDate!=newDate && currDt>=newDate && pastEventPublish != 1){  //bug:19150 if past date event is not allowed then only current date check.
                       $(comp).parent().append("<div class='err"+compId+" validationMsg clearfix' style='color:red;'>"+($(comp).attr('title')!='' ? $(comp).attr('title') : 'date')+" "+VALIDATE_GREATER_SYSDATE+"</div>");
                       tbool = false;
                 }
               }
            }
       } 
   }
   return tbool;
}

//Start:: Add Dynamic Row in Table For Validation
var tmpCheck=false;// only one time enter in if(len == 1 && !tmpCheck ) condition otherwise it will change id if len == 1
function addDynamicControl(parentId,compIds){
    var len=$(parentId).children().length;
    var lastRow;
    //lastRow = $(parentId).find('tr');
    if(compIds==='srNo,txtsortOrder,isSelect,txtaAddQuestion,txtaAddAnswer')
	{
    	 lastRow = $(parentId).find('tr');
	}
    else
	{
    	 lastRow = $(parentId).find('tr:last');
	}
    var lastRowHtml;
    var compIdArray = compIds.split(",");
    for(var i =0;i<compIdArray.length;i++){
    	$(".err"+compIdArray[i]).remove();
    }
    if($(parentId).children().length == 1){
    	lastRowHtml=lastRow.html();
    }else{
    	lastRowHtml=clearDefVal(lastRow.html());
    }
    //var lastRowHtml = $(parentId).children().length == 1 ? lastRow.html() : clearDefVal(lastRow.html());
    var oldTagId="";
    if(len == 1 && !tmpCheck){
        //this is use to change id of first row , like id="selControltype" to id="selControltype_1"
        for(i =0;i<compIdArray.length;i++){
            var newTagId= compIdArray[i].concat("_0");
            oldTagId = compIdArray[i];
            if($("#"+oldTagId).val()!=undefined){//This condition is for Create time
            	var oldTagData=$("#"+oldTagId).val();
                /*if(navig_agt.indexOf("firefox")!=-1){
    	            var tagName=$("#"+oldTagId);
    	            if(tagName == "TEXTAREA"){
    	            	lastRowHtml = lastRowHtml.replace('</textarea>',oldTagData+"</textarea>");
    	            }
                }*/
                if(oldTagId.indexOf('txta')!=-1){
                	lastRowHtml = lastRowHtml.replace('id="'+oldTagId,'id="'+newTagId);
                	if($("#"+newTagId).val()!=''){
                		if(lastRowHtml.indexOf('></textarea>')!=-1){
                			lastRowHtml = lastRowHtml.replace('></textarea>',">"+oldTagData+"</textarea>");
                		}
                	}
            	}else if(oldTagId.indexOf('txt')!=-1){
            		lastRowHtml = lastRowHtml.replace('id="'+oldTagId,'id="'+newTagId+'" value="'+oldTagData);
            	}else if(oldTagId.indexOf('sel')!=-1){
            		lastRowHtml = lastRowHtml.replace('id="'+oldTagId,'id="'+newTagId);
            		lastRowHtml = lastRowHtml.replace('value="'+oldTagData,'value="'+oldTagData+'" selected="selected');
            	}
            	else {
            		lastRowHtml = lastRowHtml.replace('id="'+oldTagId,'id="'+newTagId);
            		}
                lastRowHtml = lastRowHtml.replace('id="jh'+oldTagId,'id="jh'+newTagId);//for hidden field
            }else{//This condition is for Edit time
            	var oldTagData=$("#"+newTagId).val();
            	
                if(newTagId.indexOf('txta')!=-1){
//                	lastRowHtml = lastRowHtml.replace('id="'+newTagId,'id="'+newTagId);
                	lastRowHtml = lastRowHtml.replace('</textarea>',oldTagData+"</textarea>");
            	}else if(newTagId.indexOf('txt')!=-1){
            		lastRowHtml = lastRowHtml.replace('id="'+newTagId,'id="'+newTagId+'" value="'+oldTagData);
            	}else if(newTagId.indexOf('sel')!=-1){
//            		lastRowHtml = lastRowHtml.replace('id="'+oldTagId,'id="'+newTagId);
            		lastRowHtml = lastRowHtml.replace('value="'+oldTagData,'value="'+oldTagData+'" selected="selected');
            	}
            	else{
            		lastRowHtml = lastRowHtml.replace('id="'+newTagId,'id="'+newTagId);
            	}
                lastRowHtml = lastRowHtml.replace('id="jh'+newTagId,'id="jh'+newTagId);//for hidden field
            }
        }
        lastRow.remove();
        $(parentId).append("<tr>"+lastRowHtml+"</tr>");
        if(compIds==='srNo,txtsortOrder,isSelect,txtaAddQuestion,txtaAddAnswer')
		{
        	lastRowHtml = $(parentId).find('tr').html();
		}
        else
    	{
        	lastRowHtml = $(parentId).find('tr:last').html();
    	}
        
        tmpCheck=true;
    }
    // this is use to change id of second ,third... row , like id="selControltype_1" to id="selControltype_2"
    for(var i =0;i<compIdArray.length;i++){
        var newTagId= compIdArray[i].concat("_"+len);
        if(compIds==='srNo,txtsortOrder,isSelect,txtaAddQuestion,txtaAddAnswer')
    	{
        	oldTagId = compIdArray[i].concat("_0");
    	}
        else
        {
        	oldTagId = compIdArray[i].concat("_"+(len-1));
        }
        lastRowHtml = lastRowHtml.replace('id="'+oldTagId,'id="'+newTagId);
        lastRowHtml = lastRowHtml.replace('id="jh'+oldTagId,'id="jh'+newTagId);//for hidden field
    }
    $(parentId).append("<tr>"+clearDefVal(lastRowHtml)+"</tr>");
}
//End:: Add Dynamic Row in Table For Validation

//Start:: Remove Dynamic Row in Table For Validation
function removeDynamicControl(parentId,compIds){
    var test = $(":checkbox:checked").length;
    var lenT=$(parentId).children().length;
    var cntChkBox=0;
    $(":checkbox:checked").each(function(){
        var len=$(parentId).children().length;
        var curRow = $(this).closest('tr');
        if(test == lenT && cntChkBox == 0){
            alert("All rows cannot be deleted","Dynamic Control", function(RetVal) {
                });
        }else{
            var currTagId=$(this).attr("id");
            var id=currTagId.substring(currTagId.indexOf("_")+1,currTagId.length);//row id = dynTr_1
            var compIdArray = compIds.split(",");
            for(var i=id;i<len;i++){
                for(var j =0;j<compIdArray.length;j++){
                    if(j != 0){
                        $(".err"+compIdArray[j]+"_"+(i)).remove();
                    }
                    //$('.err'+compIdArray[j]+"_"+eval(eval(i)+eval(1))).attr("class",compIdArray[j]+"_"+(i));
                    $('#'+compIdArray[j]+"_"+eval(eval(i)+eval(1))).attr("id",compIdArray[j]+"_"+(i));
                    $('#jh'+compIdArray[j]+"_"+eval(eval(i)+eval(1))).attr("id","jh"+compIdArray[j]+"_"+(i));
                }
            }
            curRow.remove();
        }
        cntChkBox++;
    });
    var lastRowContent = $(parentId).find("tr:last").html();
    //alert(lastRowContent);
    $("#hidCheck").val("<tr>"+lastRowContent+"</tr>");//it is set in input hidden field
    $("#hidDynCount").val($(parentId).children().length-1);
    valOnSubmit();
}
//End:: Remove Dynamic Row in Table For Validation
//function to remove Default values
function clearDefVal(tds){
	var tdArr ;
	if(isIE8Browser)
	{
		tdArr = tds.split('</TD>');
		var newTdStr = '';
	    for(var tdCnt in tdArr){
	        var data = tdArr[tdCnt];
	        if(data.indexOf('name=txta')!=-1){
	            var temp = data.substring(data.indexOf('<TD', 0), data.indexOf('<TEXTAREA', 0));
	            newTdStr = newTdStr + temp + data.replace(temp,'').replace(/">.*?<\/TEXTAREA>/g,'"></TEXTAREA>')+'</TD>';
	        }else if(data.indexOf('name=txt')!=-1){
	            newTdStr = newTdStr + data.replace(/value=/g,'')+'</TD>';
	        }else if(data.indexOf('name=sel')!=-1){
	            newTdStr = newTdStr + data.replace(/selected=\""/g,'')+'</TD>';
	        }else if(data.indexOf('name=chk')!=-1){
	            newTdStr = newTdStr + data.replace(/checked=\""/g,'')+'</TD>';
	        }else if(data.indexOf('name=rd')!=-1){
	            newTdStr = newTdStr + data.replace(/checked=\""/g,'')+'</TD>';
	        }else{
	            newTdStr = newTdStr + data+'</TD>';
	        }
	    }
	    return newTdStr.replace('</TD></TD>','</TD>');
	}
	else
	{
		tdArr = tds.split('</td>');
		var newTdStr = '';
	    for(var tdCnt in tdArr){
	        var data = tdArr[tdCnt];
	        if(data.indexOf('name="txta', 0)!=-1){
	            var temp = data.substring(data.indexOf('<td', 0), data.indexOf('<textarea', 0));
	            newTdStr = newTdStr + temp + data.replace(temp,'').replace(/">.*?<\/textarea>/g,'"></textarea>')+'</td>';
	        }else if(data.indexOf('name="txt', 0)!=-1){
	            newTdStr = newTdStr + data.replace(/value=\".*?\"/g,'value=""')+'</td>';
	        }else if(data.indexOf('name="sel', 0)!=-1){
	            newTdStr = newTdStr + data.replace(/selected=\""/g,'')+'</td>';
	        }else if(data.indexOf('name="chk', 0)!=-1){
	            newTdStr = newTdStr + data.replace(/checked=\""/g,'')+'</td>';
	        }else if(data.indexOf('name="rd', 0)!=-1){
	            newTdStr = newTdStr + data.replace(/checked=\""/g,'')+'</td>';
	        }else{
	            newTdStr = newTdStr + data+'</td>';
	        }
	    }
	    return newTdStr.replace('</td></td>','</td>');
	}	
    
}
function disableBtn(status){
    if(status){
        $("button[type='submit']").each(function(){
            $(this).attr('disabled',true);
        });
    }
    return status;
}
function toJSDate(date){
    if(date!='' && date!=undefined){
        var cal_months_names = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        for(var cal=0;cal<cal_months_names.length;cal++){            
            date = date.replace(cal_months_names[cal],((eval(cal+1)<=9) ? '0': '')+eval(cal+1));
        }
        var time = date.substr(date.lastIndexOf(" ")+1);
        date = date.indexOf(":") != -1 ? date.substr(0, date.lastIndexOf(" ")) : date;
        var day = date.slice(0,2);
        var month = date.slice(3,5);
        var year = date.slice(6,11);
        if(DATEFORMATE_CALENDAR.indexOf('%d')>1){
            var temp = month;
            month=day;
            day=temp;
        }
        var finalStartDt=year+"/"+month+"/"+day+" "+time;
        if(time.indexOf(":") == -1 ){
        	finalStartDt=year+"/"+month+"/"+day;
        }
        return new Date(finalStartDt).getTime();
    }else{
        return '';
    }
}
function stripCKEDITOR(html) {
    var tmp = document.createElement("div");
    tmp.innerHTML = html;

    if (tmp.textContent == '' && typeof tmp.innerText == 'undefined') {
        return '0';
    }
    return tmp.textContent || tmp.innerText;
}
function replaceQuotes(quotedata){
    return quotedata.replace(/â€˜/g,'&#0145;').replace(/â€™/g,'&#0146;').replace(/â€œ/g,'&#0147;').replace(/â€�/g,'&#0148;').replace(/'/g,'&#39;').replace(/"/g,'&#34;').replace(/Â¨/g,'&#168;').replace(/Â´/g,'&#180;').replace(/`/g,'&#96;').replace(/â€¢/g,'&#8226;').replace(/â€”/g,'&#8212;').replace(/=/g,'&#61;').replace(/-/g,'&#45;').replace(/\+/g,'&#43;').replace(/\n/g,'&#xa;').replace(/\r/g,'&#x9;').replace(/\t/g,'&#xa;').replace(/\\/g,'&#92;');
}

function reverseReplaceLineBreaks(quotedata){
    return quotedata.replace(/&#xa;/g,' ').replace(/&#x9;/g,' ').replace(/&#xa;/g,' ');
}
function reverseReplaceQuotes(quotedata){
    return quotedata.replace(/&#0145;/g,'â€˜').replace(/&#0146;/g,'â€™').replace(/&#0147;/g,'â€œ').replace(/&#0148;/g,'â€�').replace(/&#39;/g,"'").replace(/&#34;/g,'"').replace(/&#168;/g,'Â¨').replace(/&#180;/g,'Â´').replace(/&#96;/g,'`').replace(/&#8226;/g,'â€¢').replace(/&#8212;/g,'â€”').replace(/&#61;/g,'=').replace(/&#45;/g,'-').replace(/&#43;/g,'+').replace(/&#xa;/g,'\n').replace(/&#x9;/g,'\r').replace(/&#xa;/g,'\t').replace(/&#92;/g,'\\');
}
function htmlReplaceQuotes(quotedata){
	return quotedata.replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
function htmlReverseReplaceQuotes(quotedata){
	return quotedata.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&#xa;/g,' ').replace(/&amp;/g,'&');
}
function htmlNewLineReverseReplaceQuotes(quotedata){
	return quotedata.replace(/&#xa;/g,'\n');
}

function replaceDoubleQuotes(quotedata){
	return quotedata.replace(/"/g, '\'');
}

function htmlTabReplaceQuotes(quotedata){
	return quotedata.replace('\t','');
}

function processHTML(tabs) {// IE 8 process HTML
    //if href are coming on PDF it must be removed
    if (typeof String.prototype.startsWith != 'function') {
        String.prototype.startsWith = function(str) {
            return this.slice(0, str.length) == str;
        };
    }
    if (typeof String.prototype.endsWith != 'function') {
        String.prototype.endsWith = function(str) {
            return this.slice(-str.length) == str;
        };
    }
//            var tabs = '<div class="borderRadius tenderContiner t_space"><div class="formHeader">Bid history</div><TABLE width="100%" class=formField1 cellSpacing=0 cellPadding=0><TBODY><TR><TH width="25%" class=f-bold>Auction ID</TH><TD width="25%">641</TD><TH width="25%" class=f-bold>Auction no.</TH><TD width="25%">555</TD></TR><TR><TH width="25%" class=f-bold>Auction brief</TH><TD colspan=3>Live auction grand total case</TD></TR><TR><TH width="25%" class=f-bold>Department</TH><TD width="25%">e-Procurement Department</TD><TH width="25%" class=f-bold>Officer</TH><TD width="25%">Test</TD></TR><TR><TH width="25%" class=f-bold>Auction method</TH><TD width="25%">Forward </TD><TH width="25%" class=f-bold>Auction variant</TH><TD width="25%">Rank </TD></TR><TR><TH width="25%" class=f-bold>Auction base currency</TH><TD width="25%">EURO</TD><TH width="25%" class=f-bold>Bidding type</TH><TD width="25%">National competitive bidding </TD></TR><TR><TH width="25%" class=f-bold>Bid submission for</TH><TD width="25%">Grand total </TD><TH width="25%" class=f-bold>Allowed auto extension?</TH><TD width="25%">No </TD></TR><TR><TH width="25%" class=f-bold>Bidding access</TH><TD width="25%">Limited </TD><TH width="25%" class=f-bold>Bidding price increment in </TH><TD width="25%">Figure </TD></TR><TR><TH width="25%" class=f-bold>Increment in multiples </TH><TD width="25%">Yes </TD><TH width="25%" class=f-bold>First bid acceptance condition </TH><TD width="25%">Accept start price </TD></TR></TBODY></TABLE></div><div class="borderRadius tenderContiner t_space"><TABLE width="100%" class=tableView border=0 cellSpacing=0 cellPadding=0><TBODY><TR><TH class=cellPadding colspan=6><FONT class="f-right ">(<FONT color=red>*</FONT>) sign indicates bid submitted by auto bidder and (<FONT color=red>**</FONT>) sign indicates bid submitted by proxy bid</FONT></TH></TR><TR><TH width="5%" class=cellPadding>Sr. no. </TH><TH width="15%" class=cellPadding>Bid amount </TH><TH width="10%" class=cellPadding>Bid date and time </TH><TH width="10%" class=cellPadding>Ip address </TH><TH width="10%" class=cellPadding>Bid status </TH><TH width="10%" class=cellPadding>Remarks </TH></TR><TR><TD class=a-center>1</TD><TD class=a-center>10,000.000 &#160;<FONT color=red>*</FONT></TD><TD class=a-center>11/12/2013 16:15:34.257</TD><TD class=a-center>192.168.101.181</TD><TD class=a-center>Accepted </TD><TD>- </TD></TR><TR><TD class=a-center>2</TD><TD class=a-center>15,000.000 &#160;<FONT color=red>*</FONT></TD><TD class=a-center>11/13/2013 08:36:12.333</TD><TD class=a-center>192.168.100.193</TD><TD class=a-center>Accepted </TD><TD>- </TD></TR><TR><TD class=a-center>3</TD><TD class=a-center>25,000.000 </TD><TD class=a-center>11/13/2013 13:33:03.060</TD><TD class=a-center>192.168.101.13</TD><TD class=a-center>Accepted </TD><TD>- </TD></TR><TR><TD class=a-center>4</TD><TD class=a-center>25,000.000 </TD><TD class=a-center>11/14/2013 16:12:46.487</TD><TD class=a-center>192.168.100.74</TD><TD class=a-center>Rejected by system </TD><TD>Invalid bid. Please revise your bid with respect to increment criteria. </TD></TR></TBODY></TABLE></div>';
    var arr1 = tabs.split('>');
    for (var g = 0; g < arr1.length; g++) {
//                console.log('^^^^^^' + arr1[g]);
        var arr2 = arr1[g].split('=');
        for (var x = 1; x < arr2.length; x++) {
            if (arr2[x].startsWith('"') && arr2[x].endsWith('"')) {

            } else if (arr2[x].startsWith('"') && arr2[x].indexOf('" ') != -1) {

            } else if (arr2[x].indexOf('</') != -1) {

            } else if (arr2[x].indexOf('"') == -1) {
                if (arr2[x].indexOf(' ') != -1) {
                    var v1 = arr2[x].split(' ');
                    arr2[x] = '"' + v1[0] + '" ' + v1[1].toLowerCase() + "";
                } else {
                    arr2[x] = '"' + arr2[x] + '"';
                }
            }
//                    console.log('$$$$$$' + arr2[x]);
        }
        arr1[g] = arr2.join('=');
    }
    console.log(arr1.join('>'));
    return arr1.join('>');
}

// Added By Nirav Raval For UI Change #18497
function wordConversionOnMouseOver(ob,rowId){
	var spanId = $(ob).attr('id');
	var value = $(ob).html().replace(/\,/g,"");

    if(value !='' && !isNaN(value)){
        $('.popbox').hide();  
		if(spanId.indexOf("startPrice_") > -1){			
			$('#pop_startPrice_'+rowId).text(IndianConvertionAmountInWord(parseFloat(value)));
			$('#pop_startPrice_'+rowId).show();
			$("#pop_startPrice_"+rowId).offset({left:tempX+5,top:tempY+10});
		}else if(spanId.indexOf("h1l1Amount_") > -1){			
			$('#pop_h1l1Amount_'+rowId).text(IndianConvertionAmountInWord(parseFloat(value)));
			$('#pop_h1l1Amount_'+rowId).show();
			$("#pop_h1l1Amount_"+rowId).offset({left:tempX+5,top:tempY+10});
		}
    }
}

function hideWordConversion(){
	 $('.popbox').hide();
}

function replaceWithBR(textdata){
    return textdata.replace(/\r?\n/g, '<br />');;
}
function ie8InnerHtmlParse(obj, convertToLowerCase) {
    var zz = obj.innerHTML ? String(obj.innerHTML) : obj
       ,z  = zz.match(/(<.+[^>])/g);    

    if (z) {
     for ( var i=0;i<z.length;(i=i+1) ){
      var y
         ,zSaved = z[i]
         ,attrRE = /\=[a-zA-Z\.\:\[\]_\(\)\&\$\%#\@\!0-9\/]+[?\s+|?>]/g
      ;

      z[i] = z[i]
              .replace(/([<|<\/].+?\w+).+[^>]/,
                 function(a){return a.toLowerCase();
               });
      y = z[i].match(attrRE);

      if (y){
        var j   = 0
           ,len = y.length
        while(j<len){
          var replaceRE = 
               /(\=)([a-zA-Z\.\:\[\]_\(\)\&\$\%#\@\!0-9\/]+)?([\s+|?>])/g
             ,replacer  = function(){
                  var args = Array.prototype.slice.call(arguments);
                  return '="'+(convertToLowerCase 
                          ? args[2].toLowerCase() 
                          : args[2])+'"'+args[3];
                };
          z[i] = z[i].replace(y[j],y[j].replace(replaceRE,replacer));
          j+=1;
        }
       }
       zz = zz.replace(zSaved,z[i]);
     }
   }
  return zz;
}
function createActiveXObject(activeXName){
    try{
        return new ActiveXObject(activeXName)
    }catch(e){
        jAlert("<table style='text-align:left' class='no-border'><tr><td>1. Click on Tools</td></tr><tr><td>2. Click on Internet options</td></tr><tr><td>3. Click on Security tab</td></tr><tr><td>4. Select Trusted sites zone</td></tr><tr><td>5. Click on Sites</td></tr><tr><td>6. Enter URL of the website with https:// prefix</td></tr><tr><td>7. Click on Add button</td></tr><tr><td>8. Click on Close button</td></tr></table>","Instructions", function(RetVal) {});
    }
    return null;
}

function ieInnerHTML(obj, convertToLowerCase) {
    var zz = obj.innerHTML ? String(obj.innerHTML) : obj
       ,z  = zz.match(/(<.+[^>])/g);    

    if (z) {
     for ( var i=0;i<z.length;(i=i+1) ){
      var y
         ,zSaved = z[i]
         ,attrRE = /\=[a-zA-Z\-\.\:\[\]_\(\)\&\$\%#\@\!0-9\/]+[?\s+|?>]/g
      ;

      z[i] = z[i]
              .replace(/([<|<\/].+?\w+).+[^>]/,
                 function(a){return a.toLowerCase();
               });
      y = z[i].match(attrRE);

      if (y){
        var j   = 0
           ,len = y.length
        while(j<len){
          var replaceRE = 
               /(\=)([a-zA-Z\-\.\:\[\]_\(\)\&\$\%#\@\!0-9\/]+)?([\s+|?>])/g
             ,replacer  = function(){
                  var args = Array.prototype.slice.call(arguments);
                  return '="'+(convertToLowerCase 
                          ? args[2].toLowerCase() 
                          : args[2])+'"'+args[3];
                };
          z[i] = z[i].replace(y[j],y[j].replace(replaceRE,replacer));
          j+=1;
        }
       }
       zz = zz.replace(zSaved,z[i]);
     }
   }
  return zz;
}
function checkNumericLength(value)
{
	  if(!UPTOFIVEDECIMALNUMERIC.test(value)){
      	return false;
      }
	  return true;
}
function removeMandatoryCheckBoxArray()
{
	mandatoryCheckBoxIds.splice(0, mandatoryCheckBoxIds.length);
}

function hideDynamicFieldsOfGroup(){
	var groupId=parseInt($('#selgrouplst').val());
	if(groupId!=NaN){
	    $('tr[class^="group_"]').each(function () {
			$(this).hide();
		});
		$("tr.group_"+groupId+"").show();
	}
}

