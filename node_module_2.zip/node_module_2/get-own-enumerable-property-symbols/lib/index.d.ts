declare const _default: (object: object) => symbol[];
export default _default;
