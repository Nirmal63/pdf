import "./App.css";

//Functional Component
import FunctionalComponents from "./components/FunctionalComponentExample";

//Class Component
import ClassComponents from "./components/ClassComponentExample";

//State props concept
import Class1 from "./components/StatepropsExample.js/Class1";

//Using html
import FirstLastNameWithHTML from "./components/FirstLastName/FirstLastNameWithHTML/Page1";

//Using material ui
import FirstNameWithMaterial from "./components/FirstLastName/FirstNameWithMaterial/Page1";

function App() {
  return (
    <div className="App">
      <header className="App-header">
        {/* <FunctionalComponents />

        <ClassComponents /> */}

        {/* <Class1 /> */}

        <FirstLastNameWithHTML />

        {/* <FirstNameWithMaterial /> */}
      </header>
    </div>
  );
}

export default App;
