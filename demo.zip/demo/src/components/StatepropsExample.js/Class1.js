import React from "react";
import Class2 from "../StatepropsExample.js/Class2";

class Class1 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "Abc",
      age: "28",
    };
  }

  render() {
    return (
      <>
        <h6>Props And State Example</h6>

        <Class2
          name={this.state.name}
          age={this.state.age}
          // {...this.state}
        />
      </>
    );
  }
}

export default Class1;
