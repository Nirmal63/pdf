import React from "react";

class Class2 extends React.Component {
  render() {
    return (
      <>
        <h6>Name: {this.props.name}</h6>
        <h6>Age: {this.props.age}</h6>
      </>
    );
  }
}

export default Class2;
