import * as React from "react";
export default class BasicButtons extends React.Component {
  render() {
    return (
      <button type="button" onClick={this.props.onClick}>
        {this.props.name}
      </button>
    );
  }
}
