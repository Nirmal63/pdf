import * as React from "react";

export default class BasicTextFields extends React.Component {
  render() {
    return (
      <input
        class={this.props.class}
        type={this.props.type}
        id={this.props.id}
        onChange={this.props.onChange}
      />
    );
  }
}
