import * as React from "react";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";

export default class BasicButtons extends React.Component {
  render() {
    return (
      <Button variant={this.props.variant} onClick={this.props.onClick}>
        {this.props.name}
      </Button>
    );
  }
}
