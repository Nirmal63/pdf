import * as React from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";

// export default function BasicTextFields(props) {
//   return (
//     <Box
//       component="form"
//       sx={{
//         "& > :not(style)": { m: 1, width: "25ch" },
//       }}
//       noValidate
//       autoComplete="off"
//     >
//       <TextField
//         label={props.label}
//         variant="outlined"
//         onChange={props.onChange}
//         type={props.type}
//         id={props.id}
//       />
//     </Box>
//   );
// }

export default class BasicTextFields extends React.Component {
  render() {
    return (
      <Box
        component="form"
        sx={{
          "& > :not(style)": { m: 1, width: "25ch" },
        }}
        noValidate
        autoComplete="off"
      >
        <TextField
          label={this.props.label}
          variant="outlined"
          onChange={this.props.onChange}
          type={this.props.type}
          id={this.props.id}
        />
      </Box>
    );
  }
}
