import React from "react";
import "./style.css";
import Page2 from "./Page2";
import TextField from "./TextField";
import Button from "./Button";

class Page1 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fname: "",
      lname: "",
      isButtonClick: false,
    };
  }

  onHandleChange = (key, value) => {
    this.setState({
      [key]: value,
    });
  };

  onButtonClick = () => {
    this.setState({
      isButtonClick: !this.state.isButtonClick,
    });
  };

  render() {
    return (
      <>
        <div>
          <label class="col-6 col-sm-6 col-md-6" for="fname">
            Use Of Material{" "}
          </label>
        </div>
        {!this.state.isButtonClick ? (
          <div>
            <div class="row ">
              <label class="col-6 col-sm-6 col-md-6" for="fname">
                First name{" "}
              </label>
              <TextField
                class="col-6 col-sm-6 col-md-6"
                type="text"
                id="fname"
                name="fname"
                onChange={(event) =>
                  this.onHandleChange(event.target.id, event.target.value)
                }
              />
            </div>

            <div class="row ">
              <label class="col-6 col-sm-6 col-md-6" for="lname">
                Last name{" "}
              </label>
              <TextField
                class="col-6 col-sm-6 col-md-6"
                type="text"
                id="lname"
                name="lname"
                onChange={(event) =>
                  this.onHandleChange(event.target.id, event.target.value)
                }
              />
            </div>

            <div class="d-flex justify-content-between">
              <Button
                name="Save"
                variant="contained"
                onClick={() => this.onButtonClick()}
              />
            </div>
          </div>
        ) : (
          <Page2
            {...this.state}
            {...this.props}
            onButtonClick={this.onButtonClick}
          />
        )}
      </>
    );
  }
}

export default Page1;
