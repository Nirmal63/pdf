import React from "react";
import "./style.css";

class Page2 extends React.Component {
  render() {
    return (
      <div>
        <div class="row ">
          <label class="col-6 col-sm-6 col-md-6" for="fname">
            First name:{this.props.fname}
          </label>
        </div>

        <div class="row ">
          <label class="col-6 col-sm-6 col-md-6" for="lname">
            Last name:{this.props.lname}
          </label>
        </div>

        <div class="d-flex justify-content-between">
          <button
            type="button"
            name="Form"
            onClick={() => this.props.onButtonClick()}
          >
            Form
          </button>
        </div>
      </div>
    );
  }
}

export default Page2;
