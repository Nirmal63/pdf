const FunctionalComponent = () => {
  return <h5>Hi, I am FunctionalComponent!</h5>;
};

export default FunctionalComponent;
