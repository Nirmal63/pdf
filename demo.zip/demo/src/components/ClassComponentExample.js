import React from "react";

class ClassComponent extends React.Component {
  render() {
    return <h5>Hi, I am a ClassComponent!</h5>;
  }
}

export default ClassComponent;
