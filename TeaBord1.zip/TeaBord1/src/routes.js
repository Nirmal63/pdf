import React, { Component, Suspense } from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import { isNullOrIsEmptyOrIsUndefined } from "./commonConstants/CommonValidator";
import { getLocalStorageItem } from "./commonConstants/LocalStorageData";

const SampleCreate = React.lazy(() => import("./components/SampleCreate"));

const SampleList = React.lazy(() => import("./components/SampleList"));

const Dashboard = React.lazy(() => import("./containers/Dashboard"));

const CreateClient = React.lazy(() =>
  import("./containers/Client/CreateClient")
);

const ManageClient = React.lazy(() =>
  import("./containers/Client/ManageClient")
);

const CreateDepartment = React.lazy(() =>
  import("./containers/CreateDepartment")
);
const CreateDesignation = React.lazy(() =>
  import("./containers/Designation/CreateDesignation")
);
const CreateGrade = React.lazy(() => import("./containers/Grade/CreateGrade"));

const AuctionList = React.lazy(() =>
  import("../src/containers/Auction/AuctionList")
);

const BiddingHall = React.lazy(() =>
  import("../src/containers/Auction/BiddingHall")
);

const CreateAuction = React.lazy(() =>
  import("../src/containers/Auction/CreateAuction")
);

const CreateAuctionV1 = React.lazy(() =>
  import("../src/containers/Auction/CreateAuctionV1")
);

const AuctionDashboard = React.lazy(() =>
  import("../src/containers/Auction/AuctionDashboard")
);

const RegisterBidder = React.lazy(() =>
  import("../src/containers/RegisterBidder")
);

const RegisterUser = React.lazy(() => import("../src/containers/RegisterUser"));

const CreateAuctionFormula = React.lazy(() =>
  import("./containers/Auction/CreateAuctionFormula")
);
const ClientConfigureParameter = React.lazy(() =>
  import("./containers/ClientConfigureParameter")
);

const ApproveAuction = React.lazy(() =>
  import("./containers/Auction/ApproveAuction")
);

// const AuctionBidConfirmation = React.lazy(() =>
//   import("./containers/Auction/AuctionBidConfirmation")
// );

const loading = (
  <div className="pt-3 text-center">
    <div className="sk-spinner sk-spinner-pulse"></div>
  </div>
);
export default class DataRouter extends Component {
  componentDidUpdate() {
    window.scroll(0, 0);
  }

  render() {
    if (window.location.pathname == "/" || window.location.pathname == "") {
      if (!isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("clientId"))) {
        if (
          this.props.isAuthenticated ||
          !isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("token"))
        ) {
          return <Redirect to="/createClient" />;
        } else {
          return <Redirect to="/dashboard" />;
        }
      } else {
        return <Redirect to="/dashboard" />;
      }
    }

    return (
      <Switch>
        <Suspense fallback={loading}>
          <Route
            path={`/sampleCreate`}
            render={(props) => <SampleCreate {...props} {...this.props} />}
          />

          <Route
            path={`/sampleList`}
            render={(props) => <SampleList {...props} {...this.props} />}
          />

          <Route
            path={`/dashboard`}
            render={(props) => <Dashboard {...props} {...this.props} />}
          />

          <Route
            path={`/createClient`}
            render={(props) => <CreateClient {...props} {...this.props} />}
          />

          <Route
            path={`/manageClient`}
            render={(props) => <ManageClient {...props} {...this.props} />}
          />

          <Route
            path={`/createDepartment`}
            render={(props) => <CreateDepartment {...props} {...this.props} />}
          />

          <Route
            path={`/auctionList`}
            render={(props) => <AuctionList {...props} {...this.props} />}
          />

          <Route
            path={`/biddingHall`}
            render={(props) => <BiddingHall {...props} {...this.props} />}
          />

          <Route
            path={`/createAuction`}
            render={(props) => <CreateAuction {...props} {...this.props} />}
          />

          <Route
            path={`/createAuctionV1`}
            render={(props) => <CreateAuctionV1 {...props} {...this.props} />}
          />

          <Route
            path={`/auctionDashboard`}
            render={(props) => <AuctionDashboard {...props} {...this.props} />}
          />

          <Route
            path={`/createDesignation`}
            render={(props) => <CreateDesignation {...props} {...this.props} />}
          />

          <Route
            path={`/createGrade`}
            render={(props) => <CreateGrade {...props} {...this.props} />}
          />

          <Route
            path={`/registerBidder`}
            render={(props) => <RegisterBidder {...props} {...this.props} />}
          />

          <Route
            path={`/registerUser`}
            render={(props) => <RegisterUser {...props} {...this.props} />}
          />

          <Route
            path={`/createAuctionFormula`}
            render={(props) => (
              <CreateAuctionFormula {...props} {...this.props} />
            )}
          />

          <Route
            path={`/approveAuction`}
            render={(props) => <ApproveAuction {...props} {...this.props} />}
          />

          <Route
            path={`/clientConfigureParameter`}
            render={(props) => (
              <ClientConfigureParameter {...props} {...this.props} />
            )}
          />

          {/* <Route
            path={`/auctionBidConfirmation`}
            render={(props) => (
              <AuctionBidConfirmation {...props} {...this.props} />
            )}
          /> */}
        </Suspense>
      </Switch>
    );
  }
}
