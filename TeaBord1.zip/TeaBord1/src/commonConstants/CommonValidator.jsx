import moment from "moment";
export const isNullOrIsEmptyOrIsUndefined = (value) => {
  return null === value || undefined === value || "" === value || " " === value;
};

export const isNullOrIsEmptyOrIsUndefinedWithTrim = (value) => {
  if (value === undefined || value === null) {
    return true;
  }

  return value.toString().trim().length === 0;
};

export const getOrDefault = (value, defaultValue) => {
  if (isNullOrIsEmptyOrIsUndefinedWithTrim(value)) {
    return defaultValue;
  }

  return value;
};

export const isNullOrIsEmptyOrIsUndefinedOrNbspWithTrim = (value) => {
  return (
    null === value ||
    undefined === value ||
    value.trim().length === 0 ||
    value === "&nbsp" ||
    value === "&nbsp;"
  );
};

export const isNullAndIsUndefined = (value) => {
  return null === value && undefined === value;
};

export const isNullOrIsUndefined = (value) => {
  return null === value || undefined === value;
};

export const isNullOrIsEmpty = (value) => {
  return null === value || "" === value;
};

export const isValidNumber = (value, mustBeInt, minValue, maxValue) => {
  if (value && value.toString().includes(" ")) {
    return false;
  }
  minValue = minValue !== 0 ? minValue : 0;
  return !(
    (mustBeInt === 1 && value && value.toString().includes(".")) ||
    (value !== "" && (isNaN(value) || value < minValue)) ||
    (maxValue && maxValue < value)
  );
};

export const isValidDate = (value) => {
  return !(moment(value).format("YYYY-MM-DD") == "Invalid date");
};
export const attachmentValidator = (fileName, validFileExtentions) => {
  let extention = fileName.substr(fileName.lastIndexOf(".") + 1);
  return validFileExtentions.includes(extention);
};

export const isNullOrIsEmptyOrIsUndefinedWithTrimV1 = (value) => {
  value = value + "";
  if (value && ("null" == value.trim() || "undefined" == value.trim()))
    return true;
  return "null" === value || "undefined" === value || value.trim().length === 0;
};
export const isValid24Hours = (value) => {
  return !(
    moment(moment().format("YYYY-MM-DD") + " " + value).format("HH:mm") ==
    "Invalid date"
  );
};

export const isValidHttpUrl = (string) => {
  let url;

  try {
    url = new URL(string);
  } catch (_) {
    return false;
  }

  return url.protocol === "http:" || url.protocol === "https:";
};

export const isValidTime = (value, format) => {
  return !(moment(value, format).format("HH:mm") == "Invalid date");
};

export const isValidHHmm = (value) => {
  if (!value) {
    return true;
  } else {
    return (
      new RegExp("^([0-9][0-9][0-9]):[0-5][0-9]$").test(value) ||
      new RegExp("^([0-9][0-9]):[0-5][0-9]$").test(value)
    );
    /// 24 hours reg
    // ^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$   //""
  }
};
