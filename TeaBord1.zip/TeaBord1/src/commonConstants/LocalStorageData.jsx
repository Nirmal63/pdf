import { isNullOrIsEmptyOrIsUndefined } from "./CommonValidator";

export function setLocalStorageItem(key, data) {
  let encodeData = Buffer.from(data.toString()).toString("base64");
  localStorage.setItem(key, encodeData);
}

export function getLocalStorageItem(key) {
  let data = "";
  if (!isNullOrIsEmptyOrIsUndefined(localStorage.getItem(key))) {
    data = Buffer.from(localStorage.getItem(key), "base64").toString("ascii");
  }
  return data;
}
