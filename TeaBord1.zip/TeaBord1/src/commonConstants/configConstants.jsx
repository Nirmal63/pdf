export const SERVER_ADDR = "http://192.168.100.195:9191/";
export const REQUEST_ENCRYPTION = !true;

function getServerAddress() {
  const SERVER_ADDR_LOCAL = "http://192.168.100.155:9191/";
  if (window.cordova === undefined) {
    return window.location.origin + "/";
  } else {
    return SERVER_ADDR_LOCAL;
  }
}

// 9191 : gateway port
// 9192 : common port
//9193 : auction port
// 192.168.100.155 : ankitbhai ip
// 192.168.100.195 : mayur ip
