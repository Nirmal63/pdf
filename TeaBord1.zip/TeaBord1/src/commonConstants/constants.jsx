export const TOAST_AUTO_CLOSE_TIMING = "10000";

export const ERROR_MESSAGE_FOR_400 = "Bad request";

export const ERROR_MESSAGE_FOR_DEFAULT =
  "The task you are trying to perform is temporarily unavailable. Kindly contact administrator.";

export const TOAST_POSITION = "toast.POSITION.TOP_CENTER";
