import React, { Component } from "react";

export default class Loader extends Component {
  render() {
    return (
      <div class="d-flex justify-content-center">
        <div class="spinner-grow text-primary" role="status">
          <span class="sr-only">Loading...</span>
        </div>
      </div>
    );
  }
}
