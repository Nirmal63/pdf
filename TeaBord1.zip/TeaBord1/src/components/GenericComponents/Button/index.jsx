import React, { Component } from "react";

export default class Button extends Component {
  render() {
    const {
      handleButtons,
      labelValue,

      value,
    } = this.props;

    return (
      <div class="NextPrev">
        <button class="btnNext" onClick={() => handleButtons(value)}>
          {labelValue}
        </button>
      </div>
    );
  }
}
