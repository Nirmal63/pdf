import React, { Component } from "react";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";
import $ from "jquery";

export default class index extends Component {
  constructor(props) {
    super(props);

    this.state = {
      openIds: [],
    };
  }

  //To set child tree
  setChildTree = (elements) => {
    const {
      handleClassDTO,
      classDTO,
      classDTOKey,
      divIdName,
      iconIdName,
      departmentTreeChildDivMargin,
      iconIdMarginAvailable,
      liName,
      inputId,
      inputName,
    } = this.props;

    return (
      <>
        {elements &&
          elements.children &&
          elements.children.map((data, index) => {
            return (
              <>
                {data.children ? (
                  <ul>
                    <li class={liName}>
                      {data.children ? (
                        <div className={departmentTreeChildDivMargin}>
                          <i
                            id={iconIdName + data.value}
                            className={
                              iconIdMarginAvailable
                                ? this.state.openIds &&
                                  this.state.openIds.length &&
                                  this.state.openIds.length > 0 &&
                                  this.state.openIds.includes(data.value)
                                  ? "bi bi-caret-up-fill departmentTreeMargin"
                                  : "bi bi-caret-down-fill departmentTreeMargin"
                                : this.state.openIds &&
                                  this.state.openIds.length &&
                                  this.state.openIds.length > 0 &&
                                  this.state.openIds.includes(data.value)
                                ? "bi bi-caret-up-fill"
                                : "bi bi-caret-down-fill"
                            }
                            onClick={() => this.hideShowTreevalues(data.value)}
                          ></i>
                        </div>
                      ) : (
                        ""
                      )}
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="radio"
                          name={inputName}
                          id={inputId}
                          value={data.value}
                          checked={
                            classDTO &&
                            classDTO[classDTOKey] &&
                            classDTO[classDTOKey] == data.value
                              ? true
                              : false
                          }
                          onChange={(event) =>
                            handleClassDTO(
                              classDTOKey,
                              parseInt(event.target.value)
                            )
                          }
                        />
                        <label class="form-check-label" for="agree2">
                          {data.label}
                        </label>
                        <>
                          {data.children ? (
                            <div id={divIdName + data.value}>
                              {this.setChildTree(data)}
                            </div>
                          ) : null}
                        </>
                      </div>
                    </li>
                  </ul>
                ) : (
                  <li>
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        type="radio"
                        name={inputName}
                        id={inputId}
                        value={data.value}
                        checked={
                          classDTO &&
                          classDTO[classDTOKey] &&
                          classDTO[classDTOKey] == data.value
                            ? true
                            : false
                        }
                        onChange={(event) =>
                          handleClassDTO(
                            classDTOKey,
                            parseInt(event.target.value)
                          )
                        }
                      />
                      <label class="form-check-label" for="agree2">
                        {data.label}
                      </label>
                    </div>
                  </li>
                )}
              </>
            );
          })}
      </>
    );
  };

  //To set default time open
  setOpenTreeValue = (elements) => {
    let { divIdName } = this.props;

    $("#" + divIdName + elements.value).addClass("departmentTreeShow");

    this.state.openIds.push(elements.value);
    {
      elements &&
        elements.children &&
        elements.children.map((data, index) => {
          if (
            data.children &&
            !isNullOrIsEmptyOrIsUndefined(data.children) &&
            data.children.length > 0
          ) {
            this.setOpenTreeValue(data);
          }
        });
    }
  };

  //To open close child dive on click of icons
  hideShowTreevalues = (id) => {
    let { divIdName, iconIdName, iconIdMarginAvailable } = this.props;
    if (!isNullOrIsEmptyOrIsUndefined(id)) {
      if (this.state.openIds.includes(id)) {
        //To remove id
        const index = this.state.openIds.indexOf(id);
        if (index > -1) {
          this.state.openIds.splice(index, 1);
        }
        //Add remove div class
        $("#" + divIdName + id).removeClass("departmentTreeShow");
        $("#" + divIdName + id).addClass("departmentTreeNone");

        //To add remove icon class
        $("#" + iconIdName + id).addClass("bi bi-caret-down-fill ");
        $("#" + iconIdName + id).removeClass("bi bi-caret-up-fill ");
      } else {
        //To add id
        //Add remove div class
        $("#" + divIdName + id).addClass("departmentTreeShow");
        $("#" + divIdName + id).removeClass("departmentTreeNone");

        //To add remove icon class
        $("#" + iconIdName + id).removeClass("bi bi-caret-down-fill ");
        $("#" + iconIdName + id).addClass("bi bi-caret-up-fill ");

        this.state.openIds.push(id);
      }

      if (iconIdMarginAvailable) {
        $("#" + iconIdName + id).addClass("departmentTreeMargin");
      }
    }
  };

  render() {
    const {
      handleClassDTO,
      classDTO,
      responseData,
      classDTOKey,
      divIdName,
      iconIdName,
      departmentTreeChildDivMargin,
      iconIdMarginAvailable,
      liName,
      inputId,
      inputName,
    } = this.props;

    //To set default open tree
    if (
      !isNullOrIsEmptyOrIsUndefined(responseData) &&
      responseData.length &&
      responseData.length > 0 &&
      0 == this.state.openIds.length
    ) {
      const data =
        responseData &&
        responseData.map((data, index) =>
          data &&
          data.children &&
          !isNullOrIsEmptyOrIsUndefined(data.children) &&
          data.children.length > 0
            ? this.setOpenTreeValue(data)
            : ""
        );
    }

    return (
      <div class="CardBox">
        <ul>
          {responseData &&
            responseData.map((data, index) => (
              <li class={liName}>
                {data.children ? (
                  <div className={departmentTreeChildDivMargin}>
                    <i
                      id={iconIdName + data.value}
                      className={
                        iconIdMarginAvailable
                          ? this.state.openIds &&
                            this.state.openIds.length &&
                            this.state.openIds.length > 0 &&
                            this.state.openIds.includes(data.value)
                            ? "bi bi-caret-up-fill departmentTreeMargin"
                            : "bi bi-caret-down-fill departmentTreeMargin"
                          : this.state.openIds &&
                            this.state.openIds.length &&
                            this.state.openIds.length > 0 &&
                            this.state.openIds.includes(data.value)
                          ? "bi bi-caret-up-fill"
                          : "bi bi-caret-down-fill"
                      }
                      onClick={() => this.hideShowTreevalues(data.value)}
                    ></i>
                  </div>
                ) : (
                  ""
                )}
                <div class="form-check">
                  <input
                    class="form-check-input"
                    type="radio"
                    name={inputName}
                    id={inputId}
                    value={data.value}
                    checked={
                      classDTO &&
                      classDTO[classDTOKey] &&
                      classDTO[classDTOKey] == data.value
                        ? true
                        : false
                    }
                    onChange={(event) =>
                      handleClassDTO(classDTOKey, parseInt(event.target.value))
                    }
                  />
                  <label class="form-check-label" for="agree2">
                    {data.label}
                  </label>
                  <>
                    {data.children ? (
                      <div id={divIdName + data.value}>
                        {this.setChildTree(data)}
                      </div>
                    ) : null}
                  </>
                </div>
              </li>
            ))}
        </ul>
      </div>
    );
  }
}
