import {
  getFetchRequestedAction,
  getFetchCompletedAction,
} from "../../actions/loading";
import { all, call, put, takeLatest } from "redux-saga/effects";

export default function* loadingInterceptor(actualSaga, action) {
  yield put(getFetchRequestedAction());
  yield actualSaga(action);
  yield put(getFetchCompletedAction());
}
