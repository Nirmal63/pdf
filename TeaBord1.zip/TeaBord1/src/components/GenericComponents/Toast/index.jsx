import { toast } from "react-toastify";

import React from "react";
//used timeout to prevent duplicate toast
const timeOut = 250;

// for UAT time is set to 5000 for Production 1000 & 3000
const defaultTimeForSuccess = 5000;
const defaultTimeForError = 5000;
const defaultTimeForWarning = 5000;

toast.configure();

const CustomToastObj = function () {
  this.configure = function (message) {
    toast.configure();
  };
  this.success = function (message, time = defaultTimeForSuccess) {
    setTimeout(function () {
      toast.success(message, {
        position: toast.POSITION.TOP_CENTER,
        autoClose: time,
      });
    }, timeOut);
  };
  this.error = function (message, time = defaultTimeForError) {
    toast.dismiss();
    setTimeout(function () {
      toast.error(message, {
        autoClose: time,
        position: toast.POSITION.TOP_CENTER,
      });
    }, timeOut);
  };
  this.warn = function (message, time = defaultTimeForWarning) {
    toast.dismiss();
    setTimeout(function () {
      toast.warn(message, {
        autoClose: time,
        position: toast.POSITION.TOP_CENTER,
      });
    }, timeOut);
  };
  this.dismiss = function (message) {
    toast.dismiss();
  };
};

export const CustomToast = new CustomToastObj();
