import React, { Component } from "react";
import TextBox from "../GenericComponents/TextBox";
import Select from "../GenericComponents/Select";
import TextArea from "../GenericComponents/TextArea";
import Button from "../GenericComponents/Button";

let selectData = [
  { displayKey: "Yes", value: 0 },
  { displayKey: "No", value: 1 },
];

export default class index extends Component {
  render() {
    return (
      <div>
        <h2 class="Title">Sample Create</h2>

        <div class="CreateClient ShadowBox">
          <div class="row g-3">
            <TextBox
              labelValue="Textbox*"
              textBoxType="text"
              payloadkey="auctionNo"
              //   value={classDTOCreateAuction && classDTOCreateAuction.auctionNo}
              maxlength="50"
              //   handleClassDTO={handleClassDTOCreateAuction}
              //   errorValue={
              //     classDTOCreateAuction && classDTOCreateAuction.auctionNoError
              //   }
            />

            <Select
              labelValue="Select*"
              payloadkey="displayOfficerName"
              // value={
              //   (classDTOCreateAuction &&
              //     classDTOCreateAuction.displayOfficerName) ||
              //   ""
              // }
              // handleClassDTO={handleClassDTOCreateAuction}
              // errorValue={
              //   classDTOCreateAuction &&
              //   classDTOCreateAuction.displayOfficerNameError
              // }
              data={selectData}
              optionKey="displayKey"
              optionValue="value"
            />

            <TextArea
              labelValue="Textarea*"
              payloadkey="keywordText"
              // value={classDTOCreateAuction && classDTOCreateAuction.keywordText}
              maxlength="1000"
              // handleClassDTO={handleClassDTOCreateAuction}
              // errorValue={
              //   classDTOCreateAuction && classDTOCreateAuction.keywordTextError
              // }
            />
          </div>

          <Button
            labelValue="Submit"
            value=""
            // handleButtons={handleButtons}
          />
        </div>
      </div>
    );
  }
}
