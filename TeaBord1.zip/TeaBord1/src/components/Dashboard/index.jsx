import React, { Component } from "react";

export default class Dashboard extends Component {
  render() {
    return (
      <>
        <div class="col-12">
          <h2 class="Title">Live Auctions list</h2>
        </div>

        <div className="TableBox">
          <table className="table ">
            <thead>
              <tr>
                <th></th>
                <th>Auction Name</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Event Type</th>
                <th>Auction Id</th>
              </tr>
            </thead>
            <tbody>
              {this.props.getAuctionDetailsResponse &&
                this.props.getAuctionDetailsResponse.map((data, index) => (
                  <tr>
                    <td>{index + 1}</td>
                    <td>{data.auctionBrief}</td>
                    <td>{data.startDate}</td>
                    <td>{data.endDate}</td>
                    <td>{data.eventType}</td>
                    <td>{data.auctionId}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </>
    );
  }
}
