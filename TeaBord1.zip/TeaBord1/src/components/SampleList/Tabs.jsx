import React, { Component } from "react";
import $ from "jquery";

export default class Tabs extends Component {
  onFilter = () => {
    $(".FilterBox").toggleClass("active");
  };

  render() {
    return (
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li
          class="nav-item active"
          role="presentation"
          id="BasicDetails-tab"
          data-bs-toggle="tab"
          data-bs-target="#BasicDetails"
          type="button"
          role="tab"
          aria-controls="BasicDetails"
          aria-selected="true"
        >
          <button class="nav-link">Pending</button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="ModuleConfiguration-tab"
          data-bs-toggle="tab"
          data-bs-target="#ModuleConfiguration"
          type="button"
          role="tab"
          aria-controls="ModuleConfiguration"
          aria-selected="false"
        >
          <button class="nav-link">Approved</button>
        </li>
      </ul>
    );
  }
}
