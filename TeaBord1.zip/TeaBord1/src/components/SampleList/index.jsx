import React, { Component } from "react";
import Tabs from "./Tabs";
import PendingList from "./PendingList";
import Approvedlist from "./Approvedlist";
import Filter from "./Filter";
import Pagination from "./Pagination";

let headers = [{ title: "Sr.No" }, { title: "Client Name" }];

let values = [{ value: "name" }];
let data = [{ name: "abc" }, { name: "def" }, { name: "xyz" }];

export default class index extends Component {
  render() {
    return (
      <>
        <h2 class="Title">Manage Clients</h2>
        <div class="CreateClient ShadowBox Manageclients">
          <Tabs {...this.props} />
          <PendingList
            {...this.props}
            headers={headers}
            values={values}
            data={data}
          />
          <Approvedlist {...this.props} />
          <Pagination {...this.props} />
        </div>

        <Filter {...this.props} />
      </>
    );
  }
}
