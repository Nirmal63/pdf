import React, { Component } from "react";
import $ from "jquery";

export default class List extends Component {
  onFilter = () => {
    $(".FilterBox").toggleClass("active");
  };

  render() {
    return (
      <div class="tab-content" id="myTabContent">
        <div
          class="tab-pane fade"
          id="ModuleConfiguration"
          role="tabpanel"
          aria-labelledby="ModuleConfiguration-tab"
        >
          <div class="row g-3">
            <div class="col-12">
              <div class="Filter">
                <a href="#">
                  <i class="fa fa-filter"></i> Filter
                </a>
              </div>
            </div>
            <div class="TableBox">
              <table class="table">
                <thead>
                  <tr>
                    <th>Sr. No.</th>
                    <th>Client details</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td class="DepartmentsName">
                      <strong>Training123.abcprocure.com</strong>
                      <small>Java Training</small>
                    </td>
                    <td class="Action">
                      <a href="#">
                        <i class="fa fa-edit"></i>
                      </a>
                      <a href="#">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                      </a>
                      <a href="#">
                        <i class="fa-sharp fa-solid fa-gear"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-screwdriver-wrench"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-solid fa-file"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-chart-pie"></i>
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td class="DepartmentsName">
                      <strong>Training123.abcprocure.com</strong>
                      <small>Java Training</small>
                    </td>
                    <td class="Action">
                      <a href="#">
                        <i class="fa fa-edit"></i>
                      </a>
                      <a href="#">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                      </a>
                      <a href="#">
                        <i class="fa-sharp fa-solid fa-gear"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-screwdriver-wrench"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-solid fa-file"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-chart-pie"></i>
                      </a>
                    </td>
                  </tr>

                  <tr>
                    <td>3</td>
                    <td class="DepartmentsName">
                      <strong>Training123.abcprocure.com</strong>
                      <small>Java Training</small>
                    </td>
                    <td class="Action">
                      <a href="#">
                        <i class="fa fa-edit"></i>
                      </a>
                      <a href="#">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                      </a>
                      <a href="#">
                        <i class="fa-sharp fa-solid fa-gear"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-screwdriver-wrench"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-solid fa-file"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-chart-pie"></i>
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td>4</td>
                    <td class="DepartmentsName">
                      <strong>Training123.abcprocure.com</strong>
                      <small>Java Training</small>
                    </td>
                    <td class="Action">
                      <a href="#">
                        <i class="fa fa-edit"></i>
                      </a>
                      <a href="#">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                      </a>
                      <a href="#">
                        <i class="fa-sharp fa-solid fa-gear"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-screwdriver-wrench"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-solid fa-file"></i>
                      </a>
                      <a href="#">
                        <i class="fa fa-chart-pie"></i>
                      </a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
