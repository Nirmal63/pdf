import React, { Component } from "react";
import $ from "jquery";

export default class PendingList extends Component {
  onFilter = () => {
    $(".FilterBox").toggleClass("active");
  };

  render() {
    const { headers, values, data } = this.props;

    return (
      <div class="tab-content" id="myTabContent">
        <div
          class="tab-pane fade show active"
          id="BasicDetails"
          role="tabpanel"
          aria-labelledby="BasicDetails-tab"
        >
          <div class="row g-3">
            <div class="col-12">
              <div class="Filter">
                <a onClick={() => this.onFilter()} class="FilterBtn">
                  <i class="fa fa-filter"></i> Filter
                </a>
              </div>
            </div>
            <div class="TableBox">
              <table class="table">
                <thead>
                  <tr>
                    {headers &&
                      headers.map((data, index) => <td>{data.title}</td>)}
                  </tr>
                </thead>
                <tbody>
                  {data &&
                    data.map((tempData, index) => (
                      <tr>
                        <td>{index + 1}</td>
                        {values &&
                          values.map((innerData, innerIndex) => (
                            <td>{tempData[innerData.value]}</td>
                          ))}
                      </tr>
                    ))}

                  {/* <tr>
                      <td>2</td>
                      <td class="DepartmentsName">
                        <strong>Training123.abcprocure.com</strong>
                        <small>Java Training</small>
                      </td>
                      <td class="Action">
                        <a href="#">
                          <i class="fa fa-edit"></i>
                        </a>
                        <a href="#">
                          <i class="fa-solid fa-cloud-arrow-up"></i>
                        </a>
                        <a href="#">
                          <i class="fa-sharp fa-solid fa-gear"></i>
                        </a>
                        <a href="#">
                          <i class="fa fa-screwdriver-wrench"></i>
                        </a>
                        <a href="#">
                          <i class="fa fa-solid fa-file"></i>
                        </a>
                        <a href="#">
                          <i class="fa fa-chart-pie"></i>
                        </a>
                      </td>
                    </tr> */}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
