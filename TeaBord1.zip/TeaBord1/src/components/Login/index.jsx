import React, { Component } from "react";
import $ from "jquery";
import Toast from "../../components/GenericComponents/Toast";

export default class index extends Component {
  constructor(props) {
    super(props);

    this.state = {
      toastMessage: "",
      showToast: false,
    };
  }

  onCloseModal() {
    console.log("in");
  }

  componentDidUpdate() {
    // console.log(
    //   "this.props.submitDetailsResponse",
    //   this.props.submitDetailsResponse
    // );
    // if (
    //   this.props.submitDetailsResponse &&
    //   200 === this.props.submitDetailsResponse.statusCode
    // ) {
    //   $("#exampleModal").hide();
    //   this.props.updateSubmitDetailsResponse();
    // }
    // if (
    //   this.props.submitDetailsResponse &&
    //   400 === this.props.submitDetailsResponse.statusCode
    // ) {
    //   this.state.showToast = true;
    //   this.props.updateSubmitDetailsResponse();
    // }
  }

  render() {
    const {
      flag,
      openPopUp,
      handleClassDTOLogin,
      handleButtonsLogin,
      classDTOLogin,
    } = this.props;
    return (
      <>
        <div
          className="modal fade LoginModal"
          id="exampleModal"
          tabindex="-1"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <div className="modal-dialog modal-dialog-centered modal-lg">
            <div className="modal-content">
              <i
                className="fa fa-close CloseModal"
                data-bs-dismiss="modal"
                aria-label="Close"
                onClick={() => {
                  this.onCloseModal();
                }}
              ></i>
              <div className="modal-body">
                <div className="row align-items-center g-0">
                  <div className="col-md-6">
                    <img src="../../login.jpg" className="img-fluid" />
                  </div>
                  <div className="col-md-6">
                    <div className="LoginForm">
                      <div className="row g-3">
                        <div className="col-12">
                          <input
                            type="text"
                            name="loginId"
                            className="form-control"
                            placeholder="Enter Email"
                            value={classDTOLogin && classDTOLogin.loginId}
                            onChange={(event) =>
                              handleClassDTOLogin(
                                event.target.name,
                                event.target.value
                              )
                            }
                          />
                        </div>
                        {classDTOLogin && classDTOLogin.loginIdError ? (
                          <label className="error">
                            {classDTOLogin.loginIdError}
                          </label>
                        ) : (
                          ""
                        )}

                        <div className="col-12">
                          <div className="PasswordBox">
                            <input
                              id="password-field"
                              name="password"
                              type="password"
                              className="form-control"
                              placeholder="Password"
                              value={classDTOLogin && classDTOLogin.password}
                              onChange={(event) =>
                                handleClassDTOLogin(
                                  event.target.name,
                                  event.target.value
                                )
                              }
                            />
                            <span
                              toggle="#password-field"
                              className="fa fa-fw fa-eye field-icon toggle-password"
                            ></span>
                          </div>
                        </div>
                        {classDTOLogin && classDTOLogin.passwordError ? (
                          <label className="error">
                            {classDTOLogin.passwordError}
                          </label>
                        ) : (
                          ""
                        )}

                        <div className="col-12">
                          <button
                            className="LoginBtn"
                            onClick={() => handleButtonsLogin("login")}
                          >
                            Login
                          </button>
                        </div>
                        {/* <div className="col-lg-6">
                        <div className="form-check">
                          <input
                            className="form-check-input"
                            type="checkbox"
                            value=""
                            id="agree2"
                          />
                          <label className="form-check-label" for="agree2">
                            Keep me logged in
                          </label>
                        </div>
                      </div>

                      <div className="col-lg-6">
                        <a href="#">
                          <small>Forgot Password?</small>
                        </a>
                      </div> */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
