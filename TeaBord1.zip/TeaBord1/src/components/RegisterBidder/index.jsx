import React, { Component } from "react";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";
import { COMPANY_INDIVIDUAL_VALUES } from "../../containers/RegisterBidder/constants";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";

export default class index extends Component {
  render() {
    const {
      handleClassDTORegisterBidder,
      classDTORegisterBidder,
      getAllCountryDetailsResponse,
      getAllStateDetailsByCountryIdResponse,
      handleButtonsRegisterBidder,
      getAllTimeZoneDetailsResponse,
    } = this.props;

    return (
      <div>
        <h2 class="Title">Bidder Registration</h2>

        <div class="CreateClient ShadowBox">
          <div class="row g-3">
            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">
                Email Id*{" "}
                <i
                  class="bi bi-info-circle"
                  data-toggle="tooltip"
                  data-placement="top"
                  title="Email id should be valid email id as all future correspondence will be done through email id only e.g. password, reset password"
                ></i>
              </label>
              <input
                type="text"
                class="form-control"
                name="loginId"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTORegisterBidder && classDTORegisterBidder.loginId}
              />
              {classDTORegisterBidder && classDTORegisterBidder.loginIdError ? (
                <label className="error">
                  {classDTORegisterBidder.loginIdError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Person name*</label>
              <input
                type="text"
                class="form-control"
                name="userName"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTORegisterBidder && classDTORegisterBidder.userName
                }
              />
              {classDTORegisterBidder &&
              classDTORegisterBidder.userNameError ? (
                <label className="error">
                  {classDTORegisterBidder.userNameError}
                </label>
              ) : (
                ""
              )}
            </div>

            {/* Individual name & company name */}
            <div class="col-xl-3 col-lg-6 mt-3">
              <h5 class="SmallTitle mt-1"></h5>
              <div class="RadioGroup">
                {COMPANY_INDIVIDUAL_VALUES &&
                  COMPANY_INDIVIDUAL_VALUES.map((data, index) => (
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        type="radio"
                        name={data.value}
                        id={data.displayKey}
                        value={data.value}
                        checked={
                          classDTORegisterBidder &&
                          classDTORegisterBidder.userNameTemp &&
                          classDTORegisterBidder.userNameTemp == data.value
                            ? true
                            : false
                        }
                        onChange={(event) =>
                          handleClassDTORegisterBidder(
                            "userNameTemp",
                            event.target.value
                          )
                        }
                      />
                      <label class="form-check-label" for={data.displayKey}>
                        {data.displayKey}
                      </label>
                    </div>
                  ))}
              </div>
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">
                {classDTORegisterBidder && classDTORegisterBidder.userNameTemp}*
              </label>
              <input
                type="text"
                class="form-control"
                name="companyName"
                maxlength="200"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTORegisterBidder && classDTORegisterBidder.companyName
                }
                disabled={
                  classDTORegisterBidder &&
                  classDTORegisterBidder.userNameTemp &&
                  "Individual Name" == classDTORegisterBidder.userNameTemp
                    ? true
                    : false
                }
              />
              {classDTORegisterBidder &&
              classDTORegisterBidder.companyNameError ? (
                <label className="error">
                  {classDTORegisterBidder.companyNameError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Password*</label>
              <input
                type="password"
                class="form-control"
                name="password"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTORegisterBidder && classDTORegisterBidder.password
                }
              />
              {classDTORegisterBidder &&
              classDTORegisterBidder.passwordError ? (
                <label className="error">
                  {classDTORegisterBidder.passwordError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Confirm password*</label>
              <input
                type="password"
                class="form-control"
                name="confPassword"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTORegisterBidder && classDTORegisterBidder.confPassword
                }
              />
              {classDTORegisterBidder &&
              classDTORegisterBidder.confPasswordError ? (
                <label className="error">
                  {classDTORegisterBidder.confPasswordError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Country*</label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="tblCountry"
                value={
                  (classDTORegisterBidder &&
                    classDTORegisterBidder.tblCountry) ||
                  ""
                }
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
              >
                <option value="">Please Select</option>
                {getAllCountryDetailsResponse &&
                  getAllCountryDetailsResponse.map((data, index) => (
                    <option value={data.countryId}>{data.lang1}</option>
                  ))}
              </select>
              {classDTORegisterBidder &&
              classDTORegisterBidder.tblCountryError ? (
                <label className="error">
                  {classDTORegisterBidder.tblCountryError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">State*</label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="tblState"
                value={
                  (classDTORegisterBidder && classDTORegisterBidder.tblState) ||
                  ""
                }
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                disabled={
                  isNullOrIsEmptyOrIsUndefined(
                    getAllStateDetailsByCountryIdResponse
                  )
                    ? true
                    : false
                }
              >
                <option value="">Please Select</option>
                {getAllStateDetailsByCountryIdResponse &&
                  getAllStateDetailsByCountryIdResponse.map((data, index) => (
                    <option value={data.stateId}>{data.lang1}</option>
                  ))}
              </select>
              {classDTORegisterBidder &&
              classDTORegisterBidder.tblStateError ? (
                <label className="error">
                  {classDTORegisterBidder.tblStateError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">City*</label>
              <input
                type="text"
                class="form-control"
                name="city"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTORegisterBidder && classDTORegisterBidder.city}
              />
              {classDTORegisterBidder && classDTORegisterBidder.cityError ? (
                <label className="error">
                  {classDTORegisterBidder.cityError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-12">
              <label class="LabelText">Address*</label>
              <textarea
                class="form-control"
                id="exampleFormControlTextarea1"
                name="address"
                maxLength="1000"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTORegisterBidder && classDTORegisterBidder.address}
              ></textarea>{" "}
              {classDTORegisterBidder && classDTORegisterBidder.addressError ? (
                <label className="error">
                  {classDTORegisterBidder.addressError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Phone no.</label>
              <input
                type="number"
                class="form-control"
                name="phoneNo"
                maxlength="20"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTORegisterBidder && classDTORegisterBidder.phoneNo}
              />
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Mobile no.*</label>
              <input
                type="number"
                class="form-control"
                name="mobileNo"
                maxlength="20"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTORegisterBidder && classDTORegisterBidder.mobileNo
                }
              />
              {classDTORegisterBidder &&
              classDTORegisterBidder.mobileNoError ? (
                <label className="error">
                  {classDTORegisterBidder.mobileNoError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Website</label>
              <input
                type="text"
                class="form-control"
                name="website"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTORegisterBidder && classDTORegisterBidder.website}
              />
            </div>

            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">
                Time zone*{" "}
                <i
                  class="bi bi-info-circle"
                  data-toggle="tooltip"
                  data-placement="top"
                  title="Select your country time zone as it is convenient for commercial or other communication to keep the same time"
                ></i>
              </label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="tblTimeZone"
                value={
                  (classDTORegisterBidder &&
                    classDTORegisterBidder.tblTimeZone) ||
                  ""
                }
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
              >
                {getAllTimeZoneDetailsResponse &&
                  getAllTimeZoneDetailsResponse.map((data, index) => (
                    <option value={data.timeZoneId}>{data.lang1}</option>
                  ))}
              </select>
              {classDTORegisterBidder &&
              classDTORegisterBidder.tblTimeZoneError ? (
                <label className="error">
                  {classDTORegisterBidder.tblTimeZoneError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-12">
              <label class="LabelText">
                Business category keyword*{" "}
                <i
                  class="bi bi-info-circle"
                  data-toggle="tooltip"
                  data-placement="top"
                  title="Enter business keywords that are highly relevant to your business offerings"
                ></i>
              </label>
              <textarea
                class="form-control"
                id="exampleFormControlTextarea1"
                name="busCatKeywords"
                maxLength="300"
                onChange={(event) =>
                  handleClassDTORegisterBidder(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTORegisterBidder &&
                  classDTORegisterBidder.busCatKeywords
                }
              ></textarea>
              {classDTORegisterBidder &&
              classDTORegisterBidder.busCatKeywordsError ? (
                <label className="error">
                  {classDTORegisterBidder.busCatKeywordsError}
                </label>
              ) : (
                ""
              )}
            </div>
          </div>

          <div class="NextPrev">
            <button
              class="btnNext"
              onClick={() => handleButtonsRegisterBidder("submit")}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    );
  }
}
