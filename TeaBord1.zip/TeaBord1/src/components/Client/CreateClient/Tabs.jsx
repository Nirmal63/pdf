import React, { Component } from "react";

export default class Tabs extends Component {
  render() {
    return (
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li
          class="nav-item active"
          role="presentation"
          id="home-tab"
          data-bs-toggle="tab"
          data-bs-target="#BasicDetails"
          type="button"
          role="tab"
          aria-controls="home"
          aria-selected="true"
        >
          <button class="nav-link">Basic Details</button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="profile-tab"
          data-bs-toggle="tab"
          data-bs-target="#ModuleConfiguration"
          type="button"
          role="tab"
          aria-controls="profile"
          aria-selected="false"
        >
          <button class="nav-link">Module Configuration</button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="contact-tab"
          data-bs-toggle="tab"
          data-bs-target="#RegistrationConfiguration"
          type="button"
          role="tab"
          aria-controls="contact"
          aria-selected="false"
        >
          <button class="nav-link">Registration Configuration</button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="contact-tab"
          data-bs-toggle="tab"
          data-bs-target="#Localization"
          type="button"
          role="tab"
          aria-controls="contact"
          aria-selected="false"
        >
          <button class="nav-link">Localization</button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="contact-tab"
          data-bs-toggle="tab"
          data-bs-target="#AdvancedConfiguration"
          type="button"
          role="tab"
          aria-controls="contact"
          aria-selected="false"
        >
          <button class="nav-link">Advanced Configuration</button>
        </li>
      </ul>
    );
  }
}
