import React, { Component } from "react";

export default class Localization extends Component {
  render() {
    const {
      handleClassDTOClient,
      classDTOClient,
      getAllCurrencyDetailsResponse,
      getAllLanguageDetailsResponse,
      getAllTimeZoneDetailsResponse,
      getAllDateFormatResponse,
      selectRecord,
      handleButtonsClient,
    } = this.props;
    return (
      <div
        class="tab-pane fade"
        id="Localization"
        role="tabpanel"
        aria-labelledby="contact-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Localization</h6>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <div class="CardBox">
              <h5 class="SmallTitle">Currencies*</h5>
              <ul>
                {getAllCurrencyDetailsResponse &&
                  getAllCurrencyDetailsResponse.map((data, index) => (
                    <li>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          name={data.currencyId}
                          value={data.currencyId}
                          id="agree2"
                          checked={
                            classDTOClient &&
                            classDTOClient.currenciesList &&
                            classDTOClient.currenciesList.includes(
                              data.currencyId
                            )
                              ? true
                              : false
                          }
                          onChange={(event) => {
                            selectRecord(
                              event,
                              data.currencyId,
                              "currenciesList",
                              "currencyId",
                              getAllCurrencyDetailsResponse
                            );
                          }}
                        />
                        <label class="form-check-label" for="agree2">
                          {data.lang1}
                        </label>
                      </div>
                    </li>
                  ))}
              </ul>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Default currencies</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="currencyId"
              value={(classDTOClient && classDTOClient.currencyId) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              <option value="">Please Select</option>
              {classDTOClient &&
                classDTOClient.currenciesList1 &&
                classDTOClient.currenciesList1.map((data, index) => (
                  <option value={data.currencyId}>{data.lang1}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.currencyIdError ? (
              <label className="error">{classDTOClient.currencyIdError}</label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <div class="CardBox">
              <h5 class="SmallTitle">Languages*</h5>
              <ul>
                {getAllLanguageDetailsResponse &&
                  getAllLanguageDetailsResponse.map((data, index) => (
                    <li>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          name={data.languageId}
                          value={data.languageId}
                          id="agree2"
                          checked={
                            classDTOClient &&
                            classDTOClient.languagesList &&
                            classDTOClient.languagesList.includes(
                              data.languageId
                            )
                              ? true
                              : false
                          }
                          onChange={(event) => {
                            selectRecord(
                              event,
                              data.languageId,
                              "languagesList",
                              "languageId",
                              getAllLanguageDetailsResponse
                            );
                          }}
                        />
                        <label class="form-check-label" for="agree2">
                          {data.language}
                        </label>
                      </div>
                    </li>
                  ))}
              </ul>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Default languages*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="languageId"
              value={(classDTOClient && classDTOClient.languageId) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              <option value="">Please Select</option>
              {classDTOClient &&
                classDTOClient.languagesList1 &&
                classDTOClient.languagesList1.map((data, index) => (
                  <option value={data.languageId}>{data.language}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.languageIdError ? (
              <label className="error">{classDTOClient.languageIdError}</label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Time zone*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="timeZoneId"
              value={(classDTOClient && classDTOClient.timeZoneId) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {getAllTimeZoneDetailsResponse &&
                getAllTimeZoneDetailsResponse.map((data, index) => (
                  <option value={data.timeZoneId}>{data.lang1}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.timeZoneIdError ? (
              <label className="error">{classDTOClient.timeZoneIdError}</label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Default date format*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="dateFormatId"
              value={(classDTOClient && classDTOClient.dateFormatId) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {getAllDateFormatResponse &&
                getAllDateFormatResponse.map((data, index) => (
                  <option value={data.dateFormatId}>{data.dateFormat}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.dateFormatIdError ? (
              <label className="error">
                {classDTOClient.dateFormatIdError}
              </label>
            ) : (
              ""
            )}
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsClient("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() => handleButtonsClient("nextButton", "localization")}
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
