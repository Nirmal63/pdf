import React, { Component } from "react";
import TabsComponent from "./Tabs";
import BasicDetailsComponent from "./BasicDetails";
import ModuleConfiguration from "./ModuleConfiguration";
import RegistrationConfiguration from "./RegistrationConfiguration";
import Localization from "./Localization";
import AdvancedConfiguration from "./AdvancedConfiguration";

export default class index extends Component {
  render() {
    return (
      <div>
        <h2 class="Title">Create Client</h2>

        <div class="CreateClient ShadowBox">
          <TabsComponent />

          <div class="tab-content" id="myTabContent">
            <BasicDetailsComponent {...this.props} />
            <ModuleConfiguration {...this.props} />
            <RegistrationConfiguration {...this.props} />
            <Localization {...this.props} />
            <AdvancedConfiguration {...this.props} />
          </div>
        </div>
      </div>
    );
  }
}
