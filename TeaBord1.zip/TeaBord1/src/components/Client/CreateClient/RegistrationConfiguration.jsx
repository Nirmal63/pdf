import React, { Component } from "react";
import {
  DIGITAL_CERTIFICATE_REQUIRES_VALUES,
  PASSWORD_BASE_ENCRYPTION_REQUIRES_VALUES,
  SIGNER_TYPE_VALUES,
  BIDDER_REGISTRATION_APPROVAL_BY_VALUES,
  BIDDER_REGISTRATION_VERIFICATION_BY_VALUES,
  DEPARTMENT_USER_REGISTRATION_VERIFICATION_BY_VALUES,
  BIDDER_REGISTRATION_BY_VALUES,
  BIDDER_REGISTRATION_CHARGES_VALUES,
  REGISTRATION_CHARGES_MODE_OF_PAYMENT_VALUES,
  REGISTRATION_SUPPORTING_DOCUMENT_VALUES,
  TWO_STAGE_REGISTRATION_APPROVAL_REQUIRED_VALUES,
  SHOW_DIGITAL_CERTIFICATE_BANNER_VALUES,
  MANAGE_LOGIN_SEPARATE_FOR_BIDDER_BUYER_VALUES,
  CERTIFICATE_MAPPING_VALUES,
  CERTIFICATE_CLASSES_VALUES,
} from "../../../containers/Client/CreateClient/constants";

export default class RegistrationConfiguration extends Component {
  render() {
    const {
      handleClassDTOClient,
      classDTOClient,
      selectRecord,
      handleButtonsClient,
    } = this.props;
    return (
      <div
        class="tab-pane fade"
        id="RegistrationConfiguration"
        role="tabpanel"
        aria-labelledby="contact-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Registration Configuration</h6>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Digital certificate requiires*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isPkiEnabled"
              value={(classDTOClient && classDTOClient.isPkiEnabled) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {DIGITAL_CERTIFICATE_REQUIRES_VALUES &&
                DIGITAL_CERTIFICATE_REQUIRES_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.isPkiEnabledError ? (
              <label className="error">
                {classDTOClient.isPkiEnabledError}
              </label>
            ) : (
              ""
            )}
          </div>

          {classDTOClient &&
          classDTOClient.isPkiEnabled &&
          (1 == classDTOClient.isPkiEnabled ||
            2 == classDTOClient.isPkiEnabled) ? (
            <>
              <div class="col-xl-3 col-lg-4 col-md-6 col-12">
                <div class="CardBox">
                  <h5 class="SmallTitle">Digital certificate class*</h5>
                  <ul>
                    {CERTIFICATE_CLASSES_VALUES &&
                      CERTIFICATE_CLASSES_VALUES.map((data, index) => (
                        <li>
                          <div class="form-check">
                            <input
                              class="form-check-input"
                              type="checkbox"
                              name={data.value}
                              value={data.value}
                              id="agree2"
                              checked={
                                classDTOClient &&
                                classDTOClient.certificateClass1 &&
                                classDTOClient.certificateClass1.includes(
                                  data.value
                                )
                                  ? true
                                  : false
                              }
                              onChange={(event) => {
                                selectRecord(
                                  event,
                                  data.value,
                                  "certificateClass1"
                                );
                              }}
                            />
                            <label class="form-check-label" for="agree2">
                              {data.displayKey}
                            </label>
                          </div>
                        </li>
                      ))}
                  </ul>
                </div>
              </div>

              <div class="col-xl-3 col-lg-4 col-md-6 col-12">
                <label class="LabelText">Signer type*</label>
                <select
                  class="form-select"
                  aria-label="Default select example"
                  name="isSigner"
                  value={(classDTOClient && classDTOClient.isSigner) || ""}
                  onChange={(event) =>
                    handleClassDTOClient(event.target.name, event.target.value)
                  }
                >
                  {SIGNER_TYPE_VALUES &&
                    SIGNER_TYPE_VALUES.map((data, index) => (
                      <option value={data.value}>{data.displayKey}</option>
                    ))}
                </select>

                {classDTOClient && classDTOClient.isSignerError ? (
                  <label className="error">
                    {classDTOClient.isSignerError}
                  </label>
                ) : (
                  ""
                )}
              </div>
            </>
          ) : classDTOClient &&
            classDTOClient.isPkiEnabled &&
            0 == classDTOClient.isPkiEnabled ? (
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">
                Password base encryption required*
              </label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="isPassEncReq"
                value={(classDTOClient && classDTOClient.isPassEncReq) || ""}
                onChange={(event) =>
                  handleClassDTOClient(event.target.name, event.target.value)
                }
              >
                {PASSWORD_BASE_ENCRYPTION_REQUIRES_VALUES &&
                  PASSWORD_BASE_ENCRYPTION_REQUIRES_VALUES.map(
                    (data, index) => (
                      <option value={data.value}>{data.displayKey}</option>
                    )
                  )}
              </select>
              {classDTOClient && classDTOClient.isPassEncReqError ? (
                <label className="error">
                  {classDTOClient.isPassEncReqError}
                </label>
              ) : (
                ""
              )}
            </div>
          ) : (
            ""
          )}

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Bidder registration approval by*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="bidderRegApprovalBy"
              value={
                (classDTOClient && classDTOClient.bidderRegApprovalBy) || ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {BIDDER_REGISTRATION_APPROVAL_BY_VALUES &&
                BIDDER_REGISTRATION_APPROVAL_BY_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>

            {classDTOClient && classDTOClient.bidderRegApprovalByError ? (
              <label className="error">
                {classDTOClient.bidderRegApprovalByError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">
              Bidder registration verification by*
            </label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="bidderRegVerifiedBy"
              value={
                (classDTOClient && classDTOClient.bidderRegVerifiedBy) || ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {BIDDER_REGISTRATION_VERIFICATION_BY_VALUES &&
                BIDDER_REGISTRATION_VERIFICATION_BY_VALUES.map(
                  (data, index) => (
                    <option value={data.value}>{data.displayKey}</option>
                  )
                )}
            </select>
            {classDTOClient && classDTOClient.bidderRegVerifiedByError ? (
              <label className="error">
                {classDTOClient.bidderRegVerifiedByError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">
              Department user registration verification by*
            </label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="officerRegVerifiedBy"
              value={
                (classDTOClient && classDTOClient.officerRegVerifiedBy) || ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {DEPARTMENT_USER_REGISTRATION_VERIFICATION_BY_VALUES &&
                DEPARTMENT_USER_REGISTRATION_VERIFICATION_BY_VALUES.map(
                  (data, index) => (
                    <option value={data.value}>{data.displayKey}</option>
                  )
                )}
            </select>
            {classDTOClient && classDTOClient.officerRegVerifiedByError ? (
              <label className="error">
                {classDTOClient.officerRegVerifiedByError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Bidder registration by*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="bidderRegBy"
              value={(classDTOClient && classDTOClient.bidderRegBy) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {BIDDER_REGISTRATION_BY_VALUES &&
                BIDDER_REGISTRATION_BY_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.bidderRegByError ? (
              <label className="error">{classDTOClient.bidderRegByError}</label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Bidder registration charges*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isRegistrationCharges"
              value={
                (classDTOClient && classDTOClient.isRegistrationCharges) || ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              <option selected>Bidder registration charges*</option>
              {BIDDER_REGISTRATION_CHARGES_VALUES &&
                BIDDER_REGISTRATION_CHARGES_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.isRegistrationChargesError ? (
              <label className="error">
                {classDTOClient.isRegistrationChargesError}
              </label>
            ) : (
              ""
            )}
          </div>

          {classDTOClient &&
          classDTOClient.isRegistrationCharges &&
          1 == classDTOClient.isRegistrationCharges ? (
            <>
              {" "}
              <div class="col-xl-3 col-lg-4 col-md-6 col-12">
                <label class="LabelText">
                  Registration charges mode of payment
                </label>
                <select
                  class="form-select"
                  aria-label="Default select example"
                  name="registrationChargesMode"
                  value={
                    (classDTOClient &&
                      classDTOClient.registrationChargesMode) ||
                    ""
                  }
                  onChange={(event) =>
                    handleClassDTOClient(event.target.name, event.target.value)
                  }
                >
                  {REGISTRATION_CHARGES_MODE_OF_PAYMENT_VALUES &&
                    REGISTRATION_CHARGES_MODE_OF_PAYMENT_VALUES.map(
                      (data, index) => (
                        <option value={data.value}>{data.displayKey}</option>
                      )
                    )}
                </select>
              </div>
              <div class="col-xl-3 col-lg-4 col-md-6 col-12">
                <label class="LabelText">Registration charges*</label>
                <input
                  type="number"
                  class="form-control"
                  name="regCharges"
                  maxlength="20"
                  onChange={(event) =>
                    handleClassDTOClient(event.target.name, event.target.value)
                  }
                  value={classDTOClient && classDTOClient.regCharges}
                />
                {classDTOClient && classDTOClient.regChargesError ? (
                  <label className="error">
                    {classDTOClient.regChargesError}
                  </label>
                ) : (
                  ""
                )}
              </div>
            </>
          ) : (
            ""
          )}

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Registration supporting document*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isManDocsReq"
              value={(classDTOClient && classDTOClient.isManDocsReq) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {REGISTRATION_SUPPORTING_DOCUMENT_VALUES &&
                REGISTRATION_SUPPORTING_DOCUMENT_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.isManDocsReqError ? (
              <label className="error">
                {classDTOClient.isManDocsReqError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">
              Two stage registration approval required
            </label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isTwoStepBidderApproval"
              value={
                (classDTOClient && classDTOClient.isTwoStepBidderApproval) || ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {TWO_STAGE_REGISTRATION_APPROVAL_REQUIRED_VALUES &&
                TWO_STAGE_REGISTRATION_APPROVAL_REQUIRED_VALUES.map(
                  (data, index) => (
                    <option value={data.value}>{data.displayKey}</option>
                  )
                )}
            </select>
          </div>

          {classDTOClient &&
          classDTOClient.isPkiEnabled &&
          0 == classDTOClient.isPkiEnabled ? (
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Certificate mapping*</label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="mapDcRequired"
                value={(classDTOClient && classDTOClient.mapDcRequired) || ""}
                onChange={(event) =>
                  handleClassDTOClient(event.target.name, event.target.value)
                }
              >
                {CERTIFICATE_MAPPING_VALUES &&
                  CERTIFICATE_MAPPING_VALUES.map((data, index) => (
                    <option value={data.value}>{data.displayKey}</option>
                  ))}
              </select>
              {classDTOClient && classDTOClient.mapDcRequiredError ? (
                <label className="error">
                  {classDTOClient.mapDcRequiredError}
                </label>
              ) : (
                ""
              )}
            </div>
          ) : (
            ""
          )}

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Show digital certificate banner*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isShowDcBanner"
              value={(classDTOClient && classDTOClient.isShowDcBanner) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {SHOW_DIGITAL_CERTIFICATE_BANNER_VALUES &&
                SHOW_DIGITAL_CERTIFICATE_BANNER_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.isShowDcBannerError ? (
              <label className="error">
                {classDTOClient.isShowDcBannerError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">
              Manage login separately for Bidder / Buyer
            </label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isloginLinkConfigured"
              value={
                (classDTOClient && classDTOClient.isloginLinkConfigured) || ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {MANAGE_LOGIN_SEPARATE_FOR_BIDDER_BUYER_VALUES &&
                MANAGE_LOGIN_SEPARATE_FOR_BIDDER_BUYER_VALUES.map(
                  (data, index) => (
                    <option value={data.value}>{data.displayKey}</option>
                  )
                )}
            </select>
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsClient("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() =>
              handleButtonsClient("nextButton", "registrationConfiguration")
            }
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
