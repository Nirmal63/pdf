import React, { Component } from "react";
import {
  SEARCH_PANEL_VALUES,
  DISPLAY_HOME_PAGE_VALUES,
  HOME_PAGE_VALUES,
  EVENT_STATUS_LISTING_VALUES,
  ALLOW_EXTERNAL_USERS_TO_VIEW_REPORT_VALUES,
} from "../../../containers/Client/CreateClient/constants";

export default class ModuleConfiguration extends Component {
  selectRecordEventType = (event, element, showKey, key, allData) => {
    let classDTOClient = JSON.parse(JSON.stringify(this.props.classDTOClient));
    let tempObj = [];
    if (element) {
      let recordListObj = classDTOClient[showKey] || [];
      if (event.target.checked) {
        recordListObj.push(element);
      } else {
        recordListObj.splice(recordListObj.indexOf(element), 1);
      }
      if (recordListObj && recordListObj.length && recordListObj.length > 0) {
        for (let rec = 0; rec < recordListObj.length; rec++) {
          let data =
            allData &&
            allData.filter((data) => data.eventTypeId == recordListObj[rec])[0];

          let tempData = {
            eventTypeId: data && data.eventTypeId ? data.eventTypeId : "",
            moduleId: data && data.moduleId ? data.moduleId : "",
          };

          tempObj.push(tempData);
        }
      }
      this.props.handleClassDTOClient(key, tempObj);
      this.props.handleClassDTOClient(showKey, recordListObj);
    } else {
      this.props.handleClassDTOClient(key, []);
      this.props.handleClassDTOClient(showKey, []);
    }
  };

  render() {
    const {
      handleClassDTOClient,
      classDTOClient,
      getAllModuleDetailsResponse,
      getAllModuleEventTypeDetailsResponse,
      selectRecord,
      handleButtonsClient,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="ModuleConfiguration"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Module Configuration</h6>
          </div>

          <div class="col-xl-4 col-lg-6">
            <div class="CardBox">
              <h5 class="SmallTitle">Module(s)</h5>
              <ul>
                {getAllModuleDetailsResponse &&
                  getAllModuleDetailsResponse.map((data, index) => (
                    <li>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          name={data.moduleId}
                          value={data.moduleId}
                          id="agree2"
                          checked={
                            classDTOClient &&
                            classDTOClient.moduleList &&
                            classDTOClient.moduleList.includes(data.moduleId)
                              ? true
                              : false
                          }
                          onChange={(event) => {
                            selectRecord(
                              event,
                              data.moduleId,
                              "moduleList",
                              "moduleId",
                              getAllModuleDetailsResponse
                            );
                          }}
                        />
                        <label class="form-check-label" for="agree2">
                          {data.lang1}
                        </label>
                      </div>
                    </li>
                  ))}
              </ul>
            </div>
            {classDTOClient && classDTOClient.moduleListError ? (
              <label className="error">{classDTOClient.moduleListError}</label>
            ) : (
              ""
            )}
          </div>

          {classDTOClient &&
          classDTOClient.moduleList &&
          classDTOClient.moduleList.length > 0 &&
          classDTOClient.moduleList.includes(3) ? (
            <>
              <div class="col-xl-4 col-lg-6">
                <div class="CardBox">
                  <h5 class="SmallTitle">Event Type RFx*</h5>
                  <ul>
                    {getAllModuleEventTypeDetailsResponse &&
                      getAllModuleEventTypeDetailsResponse.map(
                        (data, index) => (
                          <>
                            {3 == data.moduleId ? (
                              <li>
                                <div class="form-check">
                                  <input
                                    class="form-check-input"
                                    type="checkbox"
                                    name={data.eventTypeId}
                                    value={data.eventTypeId}
                                    id="agree2"
                                    checked={
                                      classDTOClient &&
                                      classDTOClient.eventTypeList1 &&
                                      classDTOClient.eventTypeList1.includes(
                                        data.eventTypeId
                                      )
                                        ? true
                                        : false
                                    }
                                    onChange={(event) => {
                                      this.selectRecordEventType(
                                        event,
                                        data.eventTypeId,
                                        "eventTypeList1",
                                        "eventTypeList",
                                        getAllModuleEventTypeDetailsResponse
                                      );
                                    }}
                                  />
                                  <label class="form-check-label" for="agree2">
                                    {data.lang1}
                                  </label>
                                </div>
                              </li>
                            ) : (
                              ""
                            )}
                          </>
                        )
                      )}
                  </ul>
                </div>
              </div>
            </>
          ) : (
            ""
          )}

          {classDTOClient &&
          classDTOClient.moduleList &&
          classDTOClient.moduleList.length > 0 &&
          classDTOClient.moduleList.includes(5) ? (
            <>
              <div class="col-xl-4 col-lg-6">
                <div class="CardBox">
                  <h5 class="SmallTitle">Auction Variant*</h5>
                  <ul>
                    {getAllModuleEventTypeDetailsResponse &&
                      getAllModuleEventTypeDetailsResponse.map(
                        (data, index) => (
                          <>
                            {5 == data.moduleId ? (
                              <li>
                                <div class="form-check">
                                  <input
                                    class="form-check-input"
                                    type="checkbox"
                                    name={data.eventTypeId}
                                    value={data.eventTypeId}
                                    id="agree2"
                                    checked={
                                      classDTOClient &&
                                      classDTOClient.eventTypeList1 &&
                                      classDTOClient.eventTypeList1.includes(
                                        data.eventTypeId
                                      )
                                        ? true
                                        : false
                                    }
                                    onChange={(event) => {
                                      this.selectRecordEventType(
                                        event,
                                        data.eventTypeId,
                                        "eventTypeList1",
                                        "eventTypeList",
                                        getAllModuleEventTypeDetailsResponse
                                      );
                                    }}
                                  />
                                  <label class="form-check-label" for="agree2">
                                    {data.lang1}
                                  </label>
                                </div>
                              </li>
                            ) : (
                              ""
                            )}
                          </>
                        )
                      )}
                  </ul>
                </div>
              </div>
            </>
          ) : (
            ""
          )}

          {classDTOClient &&
          classDTOClient.moduleList &&
          classDTOClient.moduleList.length > 0 &&
          classDTOClient.moduleList.includes(6) ? (
            <>
              <div class="col-xl-4 col-lg-6">
                <div class="CardBox">
                  <h5 class="SmallTitle">Event Type Contract Management*</h5>
                  <ul>
                    {getAllModuleEventTypeDetailsResponse &&
                      getAllModuleEventTypeDetailsResponse.map(
                        (data, index) => (
                          <>
                            {6 == data.moduleId ? (
                              <li>
                                <div class="form-check">
                                  <input
                                    class="form-check-input"
                                    type="checkbox"
                                    name={data.eventTypeId}
                                    value={data.eventTypeId}
                                    id="agree2"
                                    checked={
                                      classDTOClient &&
                                      classDTOClient.eventTypeList1 &&
                                      classDTOClient.eventTypeList1.includes(
                                        data.eventTypeId
                                      )
                                        ? true
                                        : false
                                    }
                                    onChange={(event) => {
                                      this.selectRecordEventType(
                                        event,
                                        data.eventTypeId,
                                        "eventTypeList1",
                                        "eventTypeList",
                                        getAllModuleEventTypeDetailsResponse
                                      );
                                    }}
                                  />
                                  <label class="form-check-label" for="agree2">
                                    {data.lang1}
                                  </label>
                                </div>
                              </li>
                            ) : (
                              ""
                            )}
                          </>
                        )
                      )}
                  </ul>
                </div>
              </div>
            </>
          ) : (
            ""
          )}

          {classDTOClient &&
          classDTOClient.moduleList &&
          classDTOClient.moduleList.length > 0 &&
          classDTOClient.moduleList.includes(12) ? (
            <>
              <div class="col-xl-4 col-lg-6">
                <div class="CardBox">
                  <h5 class="SmallTitle">
                    Event Type Offline Contract Management*
                  </h5>
                  <ul>
                    {getAllModuleEventTypeDetailsResponse &&
                      getAllModuleEventTypeDetailsResponse.map(
                        (data, index) => (
                          <>
                            {12 == data.moduleId ? (
                              <li>
                                <div class="form-check">
                                  <input
                                    class="form-check-input"
                                    type="checkbox"
                                    name={data.eventTypeId}
                                    value={data.eventTypeId}
                                    id="agree2"
                                    checked={
                                      classDTOClient &&
                                      classDTOClient.eventTypeList1 &&
                                      classDTOClient.eventTypeList1.includes(
                                        data.eventTypeId
                                      )
                                        ? true
                                        : false
                                    }
                                    onChange={(event) => {
                                      this.selectRecordEventType(
                                        event,
                                        data.eventTypeId,
                                        "eventTypeList1",
                                        "eventTypeList",
                                        getAllModuleEventTypeDetailsResponse
                                      );
                                    }}
                                  />
                                  <label class="form-check-label" for="agree2">
                                    {data.lang1}
                                  </label>
                                </div>
                              </li>
                            ) : (
                              ""
                            )}
                          </>
                        )
                      )}
                  </ul>
                </div>
              </div>
            </>
          ) : (
            ""
          )}

          {classDTOClient &&
          classDTOClient.moduleList &&
          classDTOClient.moduleList.length > 0 &&
          classDTOClient.moduleList.includes(13) ? (
            <>
              <div class="col-xl-4 col-lg-6">
                <div class="CardBox">
                  <h5 class="SmallTitle">Event Type Online Contract*</h5>
                  <ul>
                    {getAllModuleEventTypeDetailsResponse &&
                      getAllModuleEventTypeDetailsResponse.map(
                        (data, index) => (
                          <>
                            {13 == data.moduleId ? (
                              <li>
                                <div class="form-check">
                                  <input
                                    class="form-check-input"
                                    type="checkbox"
                                    name={data.eventTypeId}
                                    value={data.eventTypeId}
                                    id="agree2"
                                    checked={
                                      classDTOClient &&
                                      classDTOClient.eventTypeList1 &&
                                      classDTOClient.eventTypeList1.includes(
                                        data.eventTypeId
                                      )
                                        ? true
                                        : false
                                    }
                                    onChange={(event) => {
                                      this.selectRecordEventType(
                                        event,
                                        data.eventTypeId,
                                        "eventTypeList1",
                                        "eventTypeList",
                                        getAllModuleEventTypeDetailsResponse
                                      );
                                    }}
                                  />
                                  <label class="form-check-label" for="agree2">
                                    {data.lang1}
                                  </label>
                                </div>
                              </li>
                            ) : (
                              ""
                            )}
                          </>
                        )
                      )}
                  </ul>
                </div>
              </div>
            </>
          ) : (
            ""
          )}
        </div>

        <div class="row g-3">
          {classDTOClient &&
          classDTOClient.moduleList &&
          classDTOClient.moduleList.length > 0 ? (
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">
                Default module listing on home page*
              </label>

              <select
                class="form-select"
                aria-label="Default select example"
                name="tblModuleId"
                value={(classDTOClient && classDTOClient.tblModuleId) || ""}
                onChange={(event) =>
                  handleClassDTOClient(event.target.name, event.target.value)
                }
              >
                <option value="">Please Select</option>
                {classDTOClient &&
                  classDTOClient.moduleList1 &&
                  classDTOClient.moduleList1.map((data, index) => (
                    <option value={data.moduleId}>{data.lang1}</option>
                  ))}
              </select>

              {classDTOClient && classDTOClient.tblModuleIdError ? (
                <label className="error">
                  {classDTOClient.tblModuleIdError}
                </label>
              ) : (
                ""
              )}
            </div>
          ) : (
            ""
          )}

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Search panel*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="searchPanelType"
              value={(classDTOClient && classDTOClient.searchPanelType) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              <option value="">Please Select</option>
              {SEARCH_PANEL_VALUES &&
                SEARCH_PANEL_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>

            {classDTOClient && classDTOClient.searchPanelTypeError ? (
              <label className="error">
                {classDTOClient.searchPanelTypeError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Display home page*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isHomePageRequire"
              value={(classDTOClient && classDTOClient.isHomePageRequire) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {DISPLAY_HOME_PAGE_VALUES &&
                DISPLAY_HOME_PAGE_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          {classDTOClient && 1 == classDTOClient.isHomePageRequire ? (
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Select home page*</label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="homePageTypeId"
                value={(classDTOClient && classDTOClient.homePageTypeId) || ""}
                onChange={(event) =>
                  handleClassDTOClient(event.target.name, event.target.value)
                }
              >
                {HOME_PAGE_VALUES &&
                  HOME_PAGE_VALUES.map((data, index) => (
                    <option value={data.value}>{data.displayKey}</option>
                  ))}
              </select>
            </div>
          ) : (
            ""
          )}

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Event status listing*</label>

            <select
              class="form-select"
              aria-label="Default select example"
              name="isEventStatusListing"
              value={
                (classDTOClient && classDTOClient.isEventStatusListing) || ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {EVENT_STATUS_LISTING_VALUES &&
                EVENT_STATUS_LISTING_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">
              Allow external users to view report*
            </label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isAllowExternalUserToViewReport"
              value={
                (classDTOClient &&
                  classDTOClient.isAllowExternalUserToViewReport) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {ALLOW_EXTERNAL_USERS_TO_VIEW_REPORT_VALUES &&
                ALLOW_EXTERNAL_USERS_TO_VIEW_REPORT_VALUES.map(
                  (data, index) => (
                    <option value={data.value}>{data.displayKey}</option>
                  )
                )}
            </select>
            {classDTOClient &&
            classDTOClient.isAllowExternalUserToViewReportError ? (
              <label className="error">
                {classDTOClient.isAllowExternalUserToViewReportError}
              </label>
            ) : (
              ""
            )}
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsClient("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() =>
              handleButtonsClient("nextButton", "moduleConfiguration")
            }
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
