import React, { Component } from "react";
import {
  WORK_FLOW_VALUES,
  CATEGORY_STANDARD_VALUES,
  FIGURES_INTO_WORDS_VALUES,
  LISTING_VIEW_VALUES,
  ALLOW_CONCURRENT_USER_VALUES,
  STATICS_REQUIRED_VALUES,
  OFFICER_REGISTRATION_BY_VALUES,
  IS_DIY_REQUIRED_VALUES,
  DISPLAY_VISITORS_COUNT_VALUES,
  MY_CALENDER_MODULE_REQUIRED_VALUES,
} from "../../../containers/Client/CreateClient/constants";

export default class AdvancedConfiguration extends Component {
  render() {
    const {
      handleClassDTOClient,
      classDTOClient,
      getAllWorkFlowTypeDetailsResponse,
      handleButtonsClient,
      selectRecord,
    } = this.props;
    return (
      <div
        class="tab-pane fade"
        id="AdvancedConfiguration"
        role="tabpanel"
        aria-labelledby="contact-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Advanced Configuration</h6>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Workflow*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isWorkflowReq"
              value={(classDTOClient && classDTOClient.isWorkflowReq) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              <option selected>Please Select</option>
              {WORK_FLOW_VALUES &&
                WORK_FLOW_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>

            {classDTOClient && classDTOClient.isWorkflowReqError ? (
              <label className="error">
                {classDTOClient.isWorkflowReqError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Category standard</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="categoryType"
              value={(classDTOClient && classDTOClient.categoryType) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {CATEGORY_STANDARD_VALUES &&
                CATEGORY_STANDARD_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <div class="CardBox">
              <h5 class="SmallTitle">Workflow type*</h5>
              <ul>
                {getAllWorkFlowTypeDetailsResponse &&
                  getAllWorkFlowTypeDetailsResponse.map((data, index) => (
                    <li>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          name={data.workflowTypeId}
                          value={data.workflowTypeId}
                          id="agree2"
                          checked={
                            classDTOClient &&
                            classDTOClient.workflowTypeList &&
                            classDTOClient.workflowTypeList.includes(
                              data.workflowTypeId
                            )
                              ? true
                              : false
                          }
                          onChange={(event) => {
                            selectRecord(
                              event,
                              data.workflowTypeId,
                              "workflowTypeList",
                              "workflowTypeId",
                              getAllWorkFlowTypeDetailsResponse
                            );
                          }}
                        />
                        <label class="form-check-label" for="agree2">
                          {data.lang1}
                        </label>
                      </div>
                    </li>
                  ))}
              </ul>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">
              Figures into words conversion standard*
            </label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="wordConversionFormat"
              value={
                (classDTOClient && classDTOClient.wordConversionFormat) || ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {FIGURES_INTO_WORDS_VALUES &&
                FIGURES_INTO_WORDS_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.wordConversionFormatError ? (
              <label className="error">
                {classDTOClient.wordConversionFormatError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Listing view</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="listingStyle"
              value={(classDTOClient && classDTOClient.listingStyle) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {LISTING_VIEW_VALUES &&
                LISTING_VIEW_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Allow concurrent user</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isConcurrentLogin"
              value={(classDTOClient && classDTOClient.isConcurrentLogin) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {ALLOW_CONCURRENT_USER_VALUES &&
                ALLOW_CONCURRENT_USER_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Statistic required</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isStatisticsRequired"
              value={
                (classDTOClient && classDTOClient.isStatisticsRequired) || ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {STATICS_REQUIRED_VALUES &&
                STATICS_REQUIRED_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Officer registration by</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="officerRegBy"
              value={(classDTOClient && classDTOClient.officerRegBy) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {OFFICER_REGISTRATION_BY_VALUES &&
                OFFICER_REGISTRATION_BY_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Is DIY required</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="officerRegBy"
              value={(classDTOClient && classDTOClient.officerRegBy) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {IS_DIY_REQUIRED_VALUES &&
                IS_DIY_REQUIRED_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Display visitor's count</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isShowCounter"
              value={(classDTOClient && classDTOClient.isShowCounter) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {DISPLAY_VISITORS_COUNT_VALUES &&
                DISPLAY_VISITORS_COUNT_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">My calendar module required</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isCalendarConfigured"
              value={
                (classDTOClient && classDTOClient.isCalendarConfigured) || ""
              }
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              {MY_CALENDER_MODULE_REQUIRED_VALUES &&
                MY_CALENDER_MODULE_REQUIRED_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsClient("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() => handleButtonsClient("submit", "")}
          >
            Submit
          </button>
        </div>
      </div>
    );
  }
}
