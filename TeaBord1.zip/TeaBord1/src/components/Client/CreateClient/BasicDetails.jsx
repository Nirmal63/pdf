import React, { Component } from "react";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import { GST_DETAILS_REQUIRED_VALUES } from "../../../containers/Client/CreateClient/constants";

export default class BasicDetails extends Component {
  render() {
    const {
      handleClassDTOClient,
      classDTOClient,
      getAllCountryDetailsResponse,
      getAllStateDetailsByCountryIdResponse,
      handleButtonsClient,
    } = this.props;

    return (
      <div
        class="tab-pane fade show active"
        id="BasicDetails"
        role="tabpanel"
        aria-labelledby="home-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Basic Details</h6>
          </div>
          <div class="col-xl-3 col-lg-6 col-md-6 col-12">
            <label class="LabelText">Sub domain name*</label>
            <input
              type="text"
              class="form-control"
              name="domainName"
              maxlength="100"
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
              value={classDTOClient && classDTOClient.domainName}
            />
            {classDTOClient && classDTOClient.domainNameError ? (
              <label className="error">{classDTOClient.domainNameError}</label>
            ) : (
              ""
            )}
          </div>

          {classDTOClient && classDTOClient.domainName ? (
            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <button
                class="LinkBtn"
                onClick={() => handleButtonsClient("checkDomainAvailibility")}
              >
                <i class="fa fa-check"></i> Check Availability
              </button>
            </div>
          ) : (
            ""
          )}

          <div class="col-xl-3 col-lg-6 col-md-6 col-12">
            <label class="LabelText">Client name*</label>
            <input
              type="text"
              class="form-control"
              name="clientName"
              maxlength="200"
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
              value={classDTOClient && classDTOClient.clientName}
            />
            {classDTOClient && classDTOClient.clientNameError ? (
              <label className="error">{classDTOClient.clientNameError}</label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12">
            <label class="LabelText">Department name*</label>
            <input
              type="text"
              class="form-control"
              name="deptName"
              maxlength="200"
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
              value={classDTOClient && classDTOClient.deptName}
            />
            {classDTOClient && classDTOClient.deptNameError ? (
              <label className="error">{classDTOClient.deptNameError}</label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12">
            <label class="LabelText">Country*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="countryId"
              value={(classDTOClient && classDTOClient.countryId) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              <option value="">Please Select</option>
              {getAllCountryDetailsResponse &&
                getAllCountryDetailsResponse.map((data, index) => (
                  <option value={data.countryId}>{data.lang1}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.countryIdError ? (
              <label className="error">{classDTOClient.countryIdError}</label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12">
            <label class="LabelText">State*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="stateId"
              value={(classDTOClient && classDTOClient.stateId) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
              disabled={
                isNullOrIsEmptyOrIsUndefined(
                  getAllStateDetailsByCountryIdResponse
                )
                  ? true
                  : false
              }
            >
              <option value="">Please Select</option>
              {getAllStateDetailsByCountryIdResponse &&
                getAllStateDetailsByCountryIdResponse.map((data, index) => (
                  <option value={data.stateId}>{data.lang1}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.stateIdError ? (
              <label className="error">{classDTOClient.stateIdError}</label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12">
            <label class="LabelText">City*</label>
            <input
              type="text"
              class="form-control"
              name="cityId"
              maxlength="50"
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
              value={classDTOClient && classDTOClient.cityId}
            />
            {classDTOClient && classDTOClient.cityIdError ? (
              <label className="error">{classDTOClient.cityIdError}</label>
            ) : (
              ""
            )}
          </div>

          <div class="col-12">
            <label class="LabelText">Address</label>
            <textarea
              class="form-control"
              id="exampleFormControlTextarea1"
              name="address"
              maxLength="1000"
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
              value={classDTOClient && classDTOClient.address}
            ></textarea>
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12">
            <label class="LabelText">Phone no.</label>
            <input
              type="text"
              class="form-control"
              name="phoneNo"
              maxlength="20"
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
              value={classDTOClient && classDTOClient.phoneNo}
            />
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12">
            <label class="LabelText">GST details required*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isGSTRequired"
              value={(classDTOClient && classDTOClient.isGSTRequired) || ""}
              onChange={(event) =>
                handleClassDTOClient(event.target.name, event.target.value)
              }
            >
              <option value="">Please Select</option>
              {GST_DETAILS_REQUIRED_VALUES &&
                GST_DETAILS_REQUIRED_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
            {classDTOClient && classDTOClient.isGSTRequiredError ? (
              <label className="error">
                {classDTOClient.isGSTRequiredError}
              </label>
            ) : (
              ""
            )}
          </div>

          {classDTOClient &&
          classDTOClient.isGSTRequired &&
          1 == classDTOClient.isGSTRequired ? (
            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">GST no.*</label>
              <input
                type="text"
                class="form-control"
                name="gstNo"
                maxlength="20"
                onChange={(event) =>
                  handleClassDTOClient(event.target.name, event.target.value)
                }
                value={classDTOClient && classDTOClient.gstNo}
              />
              {classDTOClient && classDTOClient.gstNoError ? (
                <label className="error">{classDTOClient.gstNoError}</label>
              ) : (
                ""
              )}
            </div>
          ) : (
            ""
          )}
        </div>

        <div class="NextPrev">
          <button
            class="btnNext"
            onClick={() => handleButtonsClient("nextButton", "basicDetails")}
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
