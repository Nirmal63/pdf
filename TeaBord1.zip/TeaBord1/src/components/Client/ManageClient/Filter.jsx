import React, { Component } from "react";
import $ from "jquery";

export default class Filter extends Component {
  filterCloseClick = () => {
    console.log("close click");
    $(".FilterBox").removeClass("active");
  };

  render() {
    return (
      <div class="FilterBox">
        <a class="FilterBtn" onClick={() => this.filterCloseClick()}>
          <i class="fa fa-times"></i>
        </a>
        <div class="row g-0">
          <div class="col-12">
            <div class="InputGroup">
              <h6 class="LabelText">Sub Domain</h6>
              <input
                type="text"
                class="form-control"
                name=""
                placeholder="Sub Domain"
              />
            </div>
          </div>
          <div class="col-12">
            <div class="InputGroup">
              <h6 class="LabelText">Department</h6>
              <input
                type="text"
                class="form-control"
                name=""
                placeholder="Department"
              />
            </div>
          </div>
          <div class="col-12">
            <div class="InputGroup">
              <h6 class="LabelText">Status</h6>
              <select class="form-select" aria-label="Default select example">
                <option selected>Select Country</option>
                <option value="1">One</option>
                <option value="2">Two</option>
                <option value="3">Three</option>
              </select>
            </div>
          </div>
          <div class="col-6">
            <button class="BlueButton ms-auto mt-4">Submit</button>
          </div>
          <div class="col-6">
            <button type="reset" class="Clear me-auto mt-4 ms-2">
              Clear
            </button>
          </div>
        </div>
      </div>
    );
  }
}
