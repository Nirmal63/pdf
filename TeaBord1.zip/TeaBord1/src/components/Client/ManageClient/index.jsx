import React, { Component } from "react";
import List from "./List";
import Filter from "./Filter";

export default class index extends Component {
  render() {
    return (
      <>
        <h2 class="Title">Manage Clients</h2>
        <List />
        <Filter />
      </>
    );
  }
}
