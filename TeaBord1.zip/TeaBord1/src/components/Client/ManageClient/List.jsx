import React, { Component } from "react";
import $ from "jquery";

export default class List extends Component {
  onFilter = () => {
    $(".FilterBox").toggleClass("active");
  };

  render() {
    return (
      <>
        <div class="CreateClient ShadowBox Manageclients">
          <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li
              class="nav-item active"
              role="presentation"
              id="home-tab"
              data-bs-toggle="tab"
              data-bs-target="#BasicDetails"
              type="button"
              role="tab"
              aria-controls="home"
              aria-selected="true"
            >
              <button class="nav-link">Pending</button>
            </li>
            <li
              class="nav-item"
              role="presentation"
              id="profile-tab"
              data-bs-toggle="tab"
              data-bs-target="#ModuleConfiguration"
              type="button"
              role="tab"
              aria-controls="profile"
              aria-selected="false"
            >
              <button class="nav-link">Approved</button>
            </li>
          </ul>
          <div class="tab-content" id="myTabContent">
            <div
              class="tab-pane fade show active"
              id="BasicDetails"
              role="tabpanel"
              aria-labelledby="home-tab"
            >
              <div class="row g-3">
                <div class="col-12">
                  <div class="Filter">
                    <a onClick={() => this.onFilter()} class="FilterBtn">
                      <i class="fa fa-filter"></i> Filter
                    </a>
                  </div>
                </div>
                <div class="TableBox">
                  <table class="table">
                    <thead>
                      <tr>
                        <td>Sr. No.</td>
                        <td>Client details</td>
                        <td>Action</td>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>1</td>
                        <td class="DepartmentsName">
                          <strong>Training123.abcprocure.com</strong>
                          <small>Java Training</small>
                        </td>
                        <td class="Action">
                          <a href="#">
                            <i class="fa fa-edit"></i>
                          </a>
                          <a href="#">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                          </a>
                          <a href="#">
                            <i class="fa-sharp fa-solid fa-gear"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-screwdriver-wrench"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-solid fa-file"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-chart-pie"></i>
                          </a>
                        </td>
                      </tr>
                      <tr>
                        <td>2</td>
                        <td class="DepartmentsName">
                          <strong>Training123.abcprocure.com</strong>
                          <small>Java Training</small>
                        </td>
                        <td class="Action">
                          <a href="#">
                            <i class="fa fa-edit"></i>
                          </a>
                          <a href="#">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                          </a>
                          <a href="#">
                            <i class="fa-sharp fa-solid fa-gear"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-screwdriver-wrench"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-solid fa-file"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-chart-pie"></i>
                          </a>
                        </td>
                      </tr>

                      <tr>
                        <td>3</td>
                        <td class="DepartmentsName">
                          <strong>Training123.abcprocure.com</strong>
                          <small>Java Training</small>
                        </td>
                        <td class="Action">
                          <a href="#">
                            <i class="fa fa-edit"></i>
                          </a>
                          <a href="#">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                          </a>
                          <a href="#">
                            <i class="fa-sharp fa-solid fa-gear"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-screwdriver-wrench"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-solid fa-file"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-chart-pie"></i>
                          </a>
                        </td>
                      </tr>
                      <tr>
                        <td>4</td>
                        <td class="DepartmentsName">
                          <strong>Training123.abcprocure.com</strong>
                          <small>Java Training</small>
                        </td>
                        <td class="Action">
                          <a href="#">
                            <i class="fa fa-edit"></i>
                          </a>
                          <a href="#">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                          </a>
                          <a href="#">
                            <i class="fa-sharp fa-solid fa-gear"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-screwdriver-wrench"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-solid fa-file"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-chart-pie"></i>
                          </a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <nav aria-label="...">
                  <ul class="pagination">
                    <li class="page-item disabled">
                      <a
                        class="page-link"
                        href="#"
                        tabindex="-1"
                        aria-disabled="true"
                      >
                        Previous
                      </a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">
                        1
                      </a>
                    </li>
                    <li class="page-item active" aria-current="page">
                      <a class="page-link" href="#">
                        2
                      </a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">
                        3
                      </a>
                    </li>
                    <li class="page-item">
                      <a class="page-link" href="#">
                        Next
                      </a>
                    </li>
                  </ul>
                </nav>
              </div>
            </div>
            <div
              class="tab-pane fade"
              id="ModuleConfiguration"
              role="tabpanel"
              aria-labelledby="profile-tab"
            >
              <div class="row g-3">
                <div class="col-12">
                  <div class="Filter">
                    <a href="#">
                      <i class="fa fa-filter"></i> Filter
                    </a>
                  </div>
                </div>
                <div class="TableBox">
                  <table class="table">
                    <thead>
                      <tr>
                        <th>Sr. No.</th>
                        <th>Client details</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>1</td>
                        <td class="DepartmentsName">
                          <strong>Training123.abcprocure.com</strong>
                          <small>Java Training</small>
                        </td>
                        <td class="Action">
                          <a href="#">
                            <i class="fa fa-edit"></i>
                          </a>
                          <a href="#">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                          </a>
                          <a href="#">
                            <i class="fa-sharp fa-solid fa-gear"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-screwdriver-wrench"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-solid fa-file"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-chart-pie"></i>
                          </a>
                        </td>
                      </tr>
                      <tr>
                        <td>2</td>
                        <td class="DepartmentsName">
                          <strong>Training123.abcprocure.com</strong>
                          <small>Java Training</small>
                        </td>
                        <td class="Action">
                          <a href="#">
                            <i class="fa fa-edit"></i>
                          </a>
                          <a href="#">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                          </a>
                          <a href="#">
                            <i class="fa-sharp fa-solid fa-gear"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-screwdriver-wrench"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-solid fa-file"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-chart-pie"></i>
                          </a>
                        </td>
                      </tr>

                      <tr>
                        <td>3</td>
                        <td class="DepartmentsName">
                          <strong>Training123.abcprocure.com</strong>
                          <small>Java Training</small>
                        </td>
                        <td class="Action">
                          <a href="#">
                            <i class="fa fa-edit"></i>
                          </a>
                          <a href="#">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                          </a>
                          <a href="#">
                            <i class="fa-sharp fa-solid fa-gear"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-screwdriver-wrench"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-solid fa-file"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-chart-pie"></i>
                          </a>
                        </td>
                      </tr>
                      <tr>
                        <td>4</td>
                        <td class="DepartmentsName">
                          <strong>Training123.abcprocure.com</strong>
                          <small>Java Training</small>
                        </td>
                        <td class="Action">
                          <a href="#">
                            <i class="fa fa-edit"></i>
                          </a>
                          <a href="#">
                            <i class="fa-solid fa-cloud-arrow-up"></i>
                          </a>
                          <a href="#">
                            <i class="fa-sharp fa-solid fa-gear"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-screwdriver-wrench"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-solid fa-file"></i>
                          </a>
                          <a href="#">
                            <i class="fa fa-chart-pie"></i>
                          </a>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <ul class="pagination">
                  <li class="page-item disabled">
                    <a
                      class="page-link"
                      href="#"
                      tabindex="-1"
                      aria-disabled="true"
                    >
                      Previous
                    </a>
                  </li>
                  <li class="page-item">
                    <a class="page-link" href="#">
                      1
                    </a>
                  </li>
                  <li class="page-item active" aria-current="page">
                    <a class="page-link" href="#">
                      2
                    </a>
                  </li>
                  <li class="page-item">
                    <a class="page-link" href="#">
                      3
                    </a>
                  </li>
                  <li class="page-item">
                    <a class="page-link" href="#">
                      Next
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
