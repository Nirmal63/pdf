import React, { Component } from "react";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";
import TreeStructureView from "../GenericComponents/TreeStructureView";

export default class index extends Component {
  render() {
    const {
      handleClassDTOCreateDepartment,
      classDTOCreateDepartment,
      getAllDepartmentDetailsResponse,
      getAllCountryDetailsResponse,
      getAllStateDetailsByCountryIdResponse,
      handleButtonsCreateDepartment,
    } = this.props;

    return (
      <div>
        <h2 class="Title">Create Department</h2>

        <div class="CreateClient ShadowBox">
          <div class="row g-3">
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Parent department*</label>
              <TreeStructureView
                responseData={getAllDepartmentDetailsResponse}
                handleClassDTO={handleClassDTOCreateDepartment}
                classDTO={classDTOCreateDepartment}
                classDTOKey="parentDeptId"
                divIdName="childDivDepartmentDepartment"
                iconIdName="chilIconDepartmentDepartment"
                departmentTreeChildDivMargin={"departmentTreeChildDivMargin"}
                iconIdMarginAvailable={false}
              />

              {classDTOCreateDepartment &&
              classDTOCreateDepartment.parentDeptIdError ? (
                <label className="error">
                  {classDTOCreateDepartment.parentDeptIdError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Department name*</label>
              <input
                type="text"
                class="form-control"
                name="deptName"
                maxlength="100"
                onChange={(event) =>
                  handleClassDTOCreateDepartment(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTOCreateDepartment && classDTOCreateDepartment.deptName
                }
              />
              {classDTOCreateDepartment &&
              classDTOCreateDepartment.deptNameError ? (
                <label className="error">
                  {classDTOCreateDepartment.deptNameError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Select country*</label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="tblCountry"
                value={
                  (classDTOCreateDepartment &&
                    classDTOCreateDepartment.tblCountry) ||
                  ""
                }
                onChange={(event) =>
                  handleClassDTOCreateDepartment(
                    event.target.name,
                    event.target.value
                  )
                }
              >
                <option value="">Please Select</option>
                {getAllCountryDetailsResponse &&
                  getAllCountryDetailsResponse.map((data, index) => (
                    <option value={data.countryId}>{data.lang1}</option>
                  ))}
              </select>
              {classDTOCreateDepartment &&
              classDTOCreateDepartment.tblCountryError ? (
                <label className="error">
                  {classDTOCreateDepartment.tblCountryError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">State*</label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="tblState"
                value={
                  (classDTOCreateDepartment &&
                    classDTOCreateDepartment.tblState) ||
                  ""
                }
                onChange={(event) =>
                  handleClassDTOCreateDepartment(
                    event.target.name,
                    event.target.value
                  )
                }
                disabled={
                  isNullOrIsEmptyOrIsUndefined(
                    getAllStateDetailsByCountryIdResponse
                  )
                    ? true
                    : false
                }
              >
                <option value="">Please Select</option>
                {getAllStateDetailsByCountryIdResponse &&
                  getAllStateDetailsByCountryIdResponse.map((data, index) => (
                    <option value={data.stateId}>{data.lang1}</option>
                  ))}
              </select>
              {classDTOCreateDepartment &&
              classDTOCreateDepartment.tblStateError ? (
                <label className="error">
                  {classDTOCreateDepartment.tblStateError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">City*</label>
              <input
                type="text"
                class="form-control"
                name="city"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTOCreateDepartment(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTOCreateDepartment && classDTOCreateDepartment.city
                }
              />
              {classDTOCreateDepartment &&
              classDTOCreateDepartment.cityError ? (
                <label className="error">
                  {classDTOCreateDepartment.cityError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-12">
              <label class="LabelText">Address</label>
              <textarea
                class="form-control"
                id="exampleFormControlTextarea1"
                name="address"
                maxLength="1000"
                onChange={(event) =>
                  handleClassDTOCreateDepartment(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTOCreateDepartment && classDTOCreateDepartment.address
                }
              ></textarea>
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Phone no.</label>
              <input
                type="text"
                class="form-control"
                name="phoneNo"
                maxlength="20"
                onChange={(event) =>
                  handleClassDTOCreateDepartment(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTOCreateDepartment && classDTOCreateDepartment.phoneNo
                }
              />
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">GST no.</label>
              <input
                type="text"
                class="form-control"
                name="gstNo"
                maxlength="20"
                onChange={(event) =>
                  handleClassDTOCreateDepartment(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTOCreateDepartment && classDTOCreateDepartment.gstNo
                }
              />
            </div>
          </div>

          <div class="NextPrev">
            <button
              class="btnNext"
              onClick={() => handleButtonsCreateDepartment("submit")}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    );
  }
}
