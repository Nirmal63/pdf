import React, { Component } from "react";
import { GRADE_LEVEL } from "../../../containers/Grade/CreateGrade/constants";

export default class index extends Component {
  render() {
    const {
      handleButtonsCreateGrade,
      handleClassDTOCreateGrade,
      classDTOCreateGrade,
    } = this.props;

    return (
      <div>
        <h2 class="Title">Create Grade</h2>
        <div class="CreateClient ShadowBox">
          <div class="row g-3">
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Grade Name*</label>
              <input
                type="text"
                class="form-control"
                name="gradeName"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTOCreateGrade(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTOCreateGrade && classDTOCreateGrade.gradeName}
              />
              {classDTOCreateGrade && classDTOCreateGrade.gradeNameError ? (
                <label className="error">
                  {classDTOCreateGrade.gradeNameError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Grade Level*</label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="gradelevel"
                value={
                  (classDTOCreateGrade && classDTOCreateGrade.gradelevel) || ""
                }
                onChange={(event) =>
                  handleClassDTOCreateGrade(
                    event.target.name,
                    parseInt(event.target.value)
                  )
                }
              >
                <option value="">Please Select</option>
                {GRADE_LEVEL &&
                  GRADE_LEVEL.map((data, index) => (
                    <option value={data.value}>{data.displayKey}</option>
                  ))}
              </select>
              {classDTOCreateGrade && classDTOCreateGrade.gradelevelError ? (
                <label className="error">
                  {classDTOCreateGrade.gradelevelError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Min. Financial Limit*</label>
              <input
                type="text"
                class="form-control"
                name="minLimit"
                maxlength="15"
                onChange={(event) =>
                  handleClassDTOCreateGrade(
                    event.target.name,
                    parseInt(event.target.value)
                  )
                }
                value={classDTOCreateGrade && classDTOCreateGrade.minLimit}
              />
              {classDTOCreateGrade && classDTOCreateGrade.minLimitError ? (
                <label className="error">
                  {classDTOCreateGrade.minLimitError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Max. Financial Limit*</label>
              <input
                type="text"
                class="form-control"
                name="maxLimit"
                maxlength="15"
                onChange={(event) =>
                  handleClassDTOCreateGrade(
                    event.target.name,
                    parseInt(event.target.value)
                  )
                }
                value={classDTOCreateGrade && classDTOCreateGrade.maxLimit}
              />
              {classDTOCreateGrade && classDTOCreateGrade.maxLimitError ? (
                <label className="error">
                  {classDTOCreateGrade.maxLimitError}
                </label>
              ) : (
                ""
              )}
            </div>
          </div>

          <div class="submit">
            <button
              class="BlueButton m-auto mt-5"
              onClick={() => handleButtonsCreateGrade("submit")}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    );
  }
}
