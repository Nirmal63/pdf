import React, { Component } from "react";
import { isNullAndIsUndefined } from "../../commonConstants/CommonValidator";

let isDataSet = false;
export default class Columntype extends Component {
  render() {
    const {
      handleClassDTOClientConfig,
      getClientCustomParameterDetailsResponse,
      handleButtonsClientConfig,
      classDTOClientConfig,
      updateClassDTOClientConfig,
      selectRecord,
      handleChange,
    } = this.props;

    console.log(
      "getClientCustomParameterDetailsResponse 14",
      getClientCustomParameterDetailsResponse &&
        getClientCustomParameterDetailsResponse.clientColumnTypeDTOList
    );

    console.log("classDTOClientConfig 22", classDTOClientConfig);
    console.log(
      "classDTOClientConfig 22",
      classDTOClientConfig && classDTOClientConfig.columnTypeIdList
    );
    console.log(
      "classDTOClientConfig 22",
      classDTOClientConfig &&
        classDTOClientConfig.columnTypeIdList &&
        classDTOClientConfig.columnTypeIdList.length == 0
    );

    console.log("isDataSet", isDataSet);
    console.log(
      "getClientCustomParameterDetailsResponse 35",
      getClientCustomParameterDetailsResponse
    );

    return (
      <div
        class="tab-pane fade"
        id="Columntype"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Columntype</h6>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <div class="CardBox">
              <h5 class="SmallTitle">Column Type*</h5>
              <ul>
                {getClientCustomParameterDetailsResponse &&
                  getClientCustomParameterDetailsResponse.clientColumnTypeDTOList &&
                  getClientCustomParameterDetailsResponse.clientColumnTypeDTOList.map(
                    (data, index) => (
                      <li>
                        <div class="form-check">
                          <input
                            class="form-check-input"
                            type="checkbox"
                            name={data.columnTypeId}
                            value={data.columnTypeId}
                            id="agree2"
                            // checked={
                            //   classDTOClientConfig &&
                            //   classDTOClientConfig.columnTypeIdList &&
                            //   classDTOClientConfig.columnTypeIdList.includes(
                            //     data.columnTypeId
                            //   )
                            //     ? true
                            //     : false
                            // }
                            checked={
                              (classDTOClientConfig &&
                                classDTOClientConfig.columnTypeIdList &&
                                classDTOClientConfig.columnTypeIdList.includes(
                                  data.columnTypeId
                                )) ||
                              data.chekedItem != null
                                ? true
                                : false
                            }
                            onChange={(event) => {
                              selectRecord(
                                event,
                                data.columnTypeId,
                                "columnTypeIdList",
                                "columnTypeId",
                                getClientCustomParameterDetailsResponse &&
                                  getClientCustomParameterDetailsResponse.clientColumnTypeDTOList
                              );
                            }}
                          />
                          <label class="form-check-label" for="agree2">
                            {data.lang1}
                          </label>
                        </div>
                      </li>
                    )
                  )}
              </ul>
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <div class="CardBox">
              {console.log("classDTOClientConfig 81", classDTOClientConfig)}
              <ul>
                <label class="LabelText">Mandatory column type *</label>
                {classDTOClientConfig &&
                  classDTOClientConfig.columnTypeIdList1 &&
                  classDTOClientConfig.columnTypeIdList1.map((data) => (
                    <li>
                      <div class="form-check">
                        <input
                          class="form-check-input"
                          type="checkbox"
                          name="isMandatory"
                          value={data.isMandatory}
                          id="agree3"
                          checked={data.isMandatory == 1}
                          onChange={(event) =>
                            handleChange(
                              event.target.name,
                              event.target.checked ? 1 : 0,
                              data.columnTypeId,
                              "columnTypeId"
                            )
                          }
                        />
                        <label class="form-check-label" for="agree3">
                          {data.lang1}
                          {console.log("data.isMandatory123", data.isMandatory)}
                        </label>
                      </div>
                    </li>
                  ))}

                {/* <select
              class="form-select"
              aria-label="Default select example"
              name="columnTypeId"
              value={
                (classDTOClientConfig && classDTOClientConfig.columnTypeId) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOClientConfig(
                  event.target.name,
                  event.target.value
                )
              }
            >
              <option value="">Please Select</option>
              {classDTOClientConfig &&
                classDTOClientConfig.columnTypeIdList1 &&
                classDTOClientConfig.columnTypeIdList1.map((data, index) => (
                  <option value={data.columnTypeId}>{data.lang1}</option>
                ))}
            </select> */}
                {classDTOClientConfig && classDTOClientConfig.gstNoError ? (
                  <label className="error">
                    {classDTOClientConfig.gstNoError}
                  </label>
                ) : (
                  ""
                )}
              </ul>
            </div>
          </div>
        </div>
        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsClientConfig("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() => handleButtonsClientConfig("submit")}
          >
            Submit
          </button>
        </div>
      </div>
    );
  }
}
