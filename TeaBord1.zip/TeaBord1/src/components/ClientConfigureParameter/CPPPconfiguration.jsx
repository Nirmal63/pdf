import React, { Component } from "react";

export default class CPPPconfiguration extends Component {
  render() {
    const {
      handleButtonsClientConfig,
      getClientCustomParameterDetailsResponse,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="CPPPconfiguration"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <div class="row">
          <div class="col-12">
            {/* <h5 class="MediumTitle">CPPP configuration</h5> */}
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th></th>
                  <th>
                    <h5 class="SmallTitle">Field caption</h5>
                  </th>
                  <th>
                    <h5 class="SmallTitle">Default value</h5>
                  </th>
                  <th>
                    <h5 class="SmallTitle">Display in Event notice page</h5>
                  </th>
                </tr>
              </thead>
              <tbody>
                {getClientCustomParameterDetailsResponse &&
                  getClientCustomParameterDetailsResponse.customParameterDTOList &&
                  getClientCustomParameterDetailsResponse.customParameterDTOList.map(
                    (data, index) => {
                      if (data.fieldGroupId === 12) {
                        return (
                          <tr key={index}>
                            <td>
                              <h5 class="SmallTitle">{data.fieldLabel}</h5>
                            </td>
                            <td>
                              <input
                                type="text"
                                class="form-control"
                                name={data.fieldLabel}
                                placeholder={data.fieldLabel}
                              />
                            </td>
                            <td>
                              <select
                                class="form-select"
                                aria-label="Default select example"
                              >
                                <option selected>
                                  Default module listing on home page*
                                </option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                              </select>
                            </td>
                            <td>
                              <div class="RadioGroup">
                                <div class="form-check">
                                  <input
                                    class="form-check-input"
                                    type="radio"
                                    name="Typesofcontract"
                                    id="Typesofcontract-Goods"
                                    checked
                                  />
                                  <label
                                    class="form-check-label"
                                    for="Typesofcontract-Goods"
                                  >
                                    Show
                                  </label>
                                </div>
                                <div class="form-check">
                                  <input
                                    class="form-check-input"
                                    type="radio"
                                    name="Typesofcontract"
                                    id="Typesofcontract-Services"
                                  />
                                  <label
                                    class="form-check-label"
                                    for="Typesofcontract-Services"
                                  >
                                    Hide
                                  </label>
                                </div>
                              </div>
                            </td>
                          </tr>
                        );
                      } else {
                        return null;
                      }
                    }
                  )}
              </tbody>
            </table>
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsClientConfig("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() =>
              handleButtonsClientConfig("nextButton", "cPPPconfiguration")
            }
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
