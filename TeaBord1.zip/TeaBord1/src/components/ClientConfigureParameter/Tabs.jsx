import React, { Component } from "react";
import $ from "jquery";

import { isNullAndIsUndefined } from "../../commonConstants/CommonValidator";

let isDataSet = false;

export default class Tabs extends Component {
  tabButtonClick(data) {
    const {
      getClientCustomParameterDetailsResponse,
      classDTOClientConfig,
      updateClassDTOClientConfig,
    } = this.props;

    if ("columnTypeTab" == data) {
      if (
        !isNullAndIsUndefined(getClientCustomParameterDetailsResponse) &&
        classDTOClientConfig &&
        classDTOClientConfig.columnTypeIdList &&
        classDTOClientConfig.columnTypeIdList.length == 0 &&
        !isDataSet
      ) {
        let columnTypeIdList = [];
        let columnTypeIdList1 = [];

        let tempData =
          getClientCustomParameterDetailsResponse &&
          getClientCustomParameterDetailsResponse.clientColumnTypeDTOList &&
          getClientCustomParameterDetailsResponse.clientColumnTypeDTOList.map(
            (data, index) => {
              if (data && data.chekedItem && data.chekedItem != null) {
                data.isMandatory = data.chekedMandotoryItem;
                {
                  console.log(
                    "data.chekedMandotoryItem",
                    data.chekedMandotoryItem
                  );
                }
                columnTypeIdList.push(data.columnTypeId);
                columnTypeIdList1.push(data);
              }
            }
          );

        let classDTOClientConfigTemp = classDTOClientConfig;
        classDTOClientConfigTemp.columnTypeIdList = columnTypeIdList;
        classDTOClientConfigTemp.columnTypeIdList1 = columnTypeIdList1;
        updateClassDTOClientConfig(classDTOClientConfigTemp);
        isDataSet = true;
      }
    }
  }
  render() {
    return (
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li
          class="nav-item active"
          role="presentation"
          id="home-tab"
          data-bs-toggle="tab"
          data-bs-target="#BasicDetails"
          type="button"
          role="tab"
          aria-controls="home"
          aria-selected="true"
        >
          <button class="nav-link">Basic Details</button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="profile-tab"
          data-bs-toggle="tab"
          data-bs-target="#GeneralConfiguration"
          type="button"
          role="tab"
          aria-controls="profile"
          aria-selected="false"
        >
          <button class="nav-link">General configuration</button>
        </li>

        <li
          class="nav-item"
          role="presentation"
          id="profile-tab"
          data-bs-toggle="tab"
          data-bs-target="#TimeAutoExtensionConfiguration"
          type="button"
          role="tab"
          aria-controls="profile"
          aria-selected="false"
        >
          <button class="nav-link">Time auto extension configuration</button>
        </li>

        <li
          class="nav-item"
          role="presentation"
          id="profile-tab"
          data-bs-toggle="tab"
          data-bs-target="#BidSubmissionConfiguration"
          type="button"
          role="tab"
          aria-controls="profile"
          aria-selected="false"
        >
          <button class="nav-link">Bid submission configuration</button>
        </li>

        <li
          class="nav-item"
          role="presentation"
          id="profile-tab"
          data-bs-toggle="tab"
          data-bs-target="#ResultConfiguration"
          type="button"
          role="tab"
          aria-controls="profile"
          aria-selected="false"
        >
          <button class="nav-link">Result Configuration</button>
        </li>

        <li
          class="nav-item"
          role="presentation"
          id="profile-tab"
          data-bs-toggle="tab"
          data-bs-target="#Columntype"
          type="button"
          role="tab"
          aria-controls="profile"
          aria-selected="false"
        >
          <button
            class="nav-link"
            onClick={() => {
              this.tabButtonClick("columnTypeTab");
            }}
          >
            Column type
          </button>
        </li>
      </ul>
    );
  }
}
