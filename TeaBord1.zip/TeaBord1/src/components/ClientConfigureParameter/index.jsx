import React, { Component } from "react";
import TabsComponent from "./Tabs";
import BasicDetails from "./BasicDetails";
import GeneralConfiguration from "./GeneralConfiguration";
import TimeAutoExtensionConfiguration from "./TimeAutoExtensionConfiguration";
import BidSubmissionConfiguration from "./BidSubmissionConfiguration";
import ResultConfiguration from "./ResultConfiguration";
import CPPPconfiguration from "./CPPPconfiguration";
import Columntype from "./Columntype";
export default class index extends Component {
  render() {
    return (
      // <>
      //   <div class="col-12">
      //     <h2 class="Title">Default configuration</h2>
      //   </div>

      //   <div className="TableBox">
      //     <table className="table ">
      //       <thead>
      //         <tr>
      //           <th></th>
      //           <th>Display officer name</th>
      //           <th>Field caption</th>
      //           <th>Default value</th>
      //           <th>Display in Event notice page</th>

      //         </tr>
      //       </thead>
      //       <tbody>
      //       {console.log("this.props.getClientCustomParameterDetailsResponse",this.props.getClientCustomParameterDetailsResponse )}

      //         {console.log("this.props.getClientCustomParameterDetailsResponse",this.props.getClientCustomParameterDetailsResponse && this.props.getClientCustomParameterDetailsResponse[0])}
      //         {this.props.getClientCustomParameterDetailsResponse &&
      //           this.props.getClientCustomParameterDetailsResponse.map((data, index) => (
      //             <tr>
      //               <td>{index + 1}</td>
      //               <td>{data.eventTypeId}</td>
      //               <td>{data.fieldLabel}</td>
      //               <td>{data.fieldCaption}</td>
      //               <td>{data.defaultvalue}</td>
      //               <td>{data.forShowHide}</td>
      //               <td>{data.moduleId}</td>
      //               <td>{data.forShowHide}</td>
      //             </tr>
      //           ))}
      //       </tbody>
      //     </table>
      //   </div>
      // </>
      <div>
        <h2 class="Title">Default configuration</h2>
        <div class="CreateClient ShadowBox DefaultConfiguration">
          <TabsComponent {...this.props} />
          <div class="tab-content" id="myTabContent">
            <BasicDetails {...this.props} />
            <GeneralConfiguration {...this.props} />
            <TimeAutoExtensionConfiguration {...this.props} />
            <BidSubmissionConfiguration {...this.props} />
            <ResultConfiguration {...this.props} />
            {/* <CPPPconfiguration {...this.props} /> */}
            <Columntype {...this.props} />
          </div>
        </div>
      </div>
    );
  }
}
