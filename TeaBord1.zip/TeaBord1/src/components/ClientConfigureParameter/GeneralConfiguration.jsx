import React, { Component } from "react";
import { HIDE_SHOW_VALUES } from "../../containers/ClientConfigureParameter/constants";
import { isNullAndIsUndefined } from "../../commonConstants/CommonValidator";

export default class GeneralConfiguration extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedOptions: {},
    };
  }

  render() {
    const {
      handleButtonsClientConfig,
      getClientCustomParameterDetailsResponse,
      getAllprocurementnatureResponse,
      customParameterDTO,
      classDTOClientConfig,
      setSelectedOption,
      handleChange,
    } = this.props;

    const { selectedOptions } = this.state;

    // if (
    //   getClientCustomParameterDetailsResponse &&
    //   getClientCustomParameterDetailsResponse.customParameterDTOList.length &&
    //   getClientCustomParameterDetailsResponse.customParameterDTOList.length > 0
    // )
    {
      let data =
        getClientCustomParameterDetailsResponse &&
        getClientCustomParameterDetailsResponse.customParameterDTOList &&
        getClientCustomParameterDetailsResponse.customParameterDTOList.map(
          (data, index) => {
            let tempData = data;
            let values = data.controlValue.split("~");
            if (values.length > 0) {
              const defaultOption = [];
              for (let i = 0; i < values.length; i++) {
                const displayKeyWithLabel = values[i].split("::")[0];
                const value = values[i].split("::")[1];

                const displayKey = displayKeyWithLabel.replace("label_", ""); // Remove "label_" prefix
                const capitalizedDisplayKey =
                  displayKey.charAt(0).toUpperCase() + displayKey.slice(1); // Capitalize the first letter

                defaultOption.push({
                  displayKey: capitalizedDisplayKey,
                  value,
                });
              }
              tempData.defaultOption = defaultOption;
            }

            return tempData;
          }
        );
    }

    return (
      <div
        className="tab-pane fade"
        id="GeneralConfiguration"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <div className="row">
          <div className="col-12">
            <h5 className="MediumTitle">General Configuration</h5>
          </div>
          <div className="table-responsive">
            <table className="table">
              <thead>
                <tr>
                  <th></th>
                  <th>
                    <h5 className="SmallTitle">Field caption</h5>
                  </th>
                  <th>
                    <h5 className="SmallTitle">Default value</h5>
                  </th>
                  <th>
                    <h5 className="SmallTitle">Display in Event notice page</h5>
                  </th>
                </tr>
              </thead>
              <tbody>
                {console.log(
                  "getClientCustomParameterDetailsResponse",
                  getClientCustomParameterDetailsResponse
                )}
                {getClientCustomParameterDetailsResponse &&
                  getClientCustomParameterDetailsResponse.customParameterDTOList &&
                  getClientCustomParameterDetailsResponse.customParameterDTOList.map(
                    (data, index) => {
                      if (data.fieldGroupId === 7) {
                        return (
                          <tr key={index}>
                            <td>
                              <h5 className="SmallTitle">{data.fieldLabel}</h5>
                            </td>
                            <td>
                              <input
                                type="text"
                                className="form-control"
                                name="fieldCaption"
                                placeholder={data.fieldCaption}
                                onChange={(event) =>
                                  handleChange(
                                    event.target.name,
                                    event.target.value,
                                    data.fieldId,
                                    "fieldId"
                                  )
                                }
                              />
                            </td>
                            <td>
                              <>
                                {data.fieldId == 49 ? (
                                  <select
                                    className="form-select"
                                    aria-label="Default select example"
                                    name="defaultvalue"
                                    onChange={(event) =>
                                      handleChange(
                                        event.target.name,
                                        event.target.value,
                                        data.fieldId,
                                        "fieldId"
                                      )
                                    }
                                  >
                                    {getAllprocurementnatureResponse &&
                                      getAllprocurementnatureResponse.map(
                                        (data1, index) => (
                                          <option
                                            value={data1.procurementNatureId}
                                            selected={
                                              data1.procurementNatureId ==
                                              data.defaultvalue
                                            }
                                          >
                                            {data1.lang1}
                                          </option>
                                        )
                                      )}
                                  </select>
                                ) : data.controlType === 1 ? (
                                  <div>
                                    <input
                                      type="text"
                                      className="form-control"
                                      name="defaultvalue"
                                      onChange={(event) =>
                                        handleChange(
                                          event.target.name,
                                          event.target.value,
                                          data.fieldId,
                                          "fieldId"
                                        )
                                      }
                                      value={data.defaultvalue}
                                    />
                                    {data && data.defaultvalueError ? (
                                      <label className="error">
                                        {data.defaultvalueError}
                                      </label>
                                    ) : (
                                      ""
                                    )}
                                  </div>
                                ) : (
                                  <div>
                                    {data.controlType == 2 ? (
                                      <select
                                        className="form-select"
                                        aria-label="Default select example"
                                        name="defaultvalue"
                                        value={setSelectedOption}
                                        onChange={(event) =>
                                          handleChange(
                                            event.target.name,
                                            event.target.value,
                                            data.fieldId,
                                            "fieldId"
                                          )
                                        }
                                      >
                                        {data.defaultOption &&
                                          data.defaultOption.map(
                                            (option, index) => (
                                              <option
                                                key={index}
                                                value={option.value}
                                                selected={
                                                  option.value ==
                                                  data.defaultvalue
                                                }
                                              >
                                                {option.displayKey}
                                              </option>
                                            )
                                          )}
                                      </select>
                                    ) : (
                                      ""
                                    )}

                                    {classDTOClientConfig &&
                                    classDTOClientConfig.isGSTRequiredError ? (
                                      <label className="error">
                                        {
                                          classDTOClientConfig.isGSTRequiredError
                                        }
                                      </label>
                                    ) : (
                                      ""
                                    )}
                                  </div>
                                )}
                              </>
                            </td>
                            <td>
                              <div>
                                {/* <div className="form-check">
                                <input
                                  className="form-check-input"
                                  type="radio"
                                  name={`Typesofcontract-${index}`}
                                  id={`Typesofcontract-Goods-${index}`}
                                  checked={selectedOption === "show"}
                                  value="show"
                                  onChange={(event) =>
                                    handleChange(
                                      event.target.name,
                                      event.target.checked,
                                      data.fieldId
                                    )
                                  }
                                />
                                <label
                                  className="form-check-label"
                                  htmlFor={`Typesofcontract-Goods-${index}`}
                                >
                                  Show
                                </label>
                              </div>
                              <div className="form-check">
                                <input
                                  className="form-check-input"
                                  type="radio"
                                  name={`Typesofcontract-${index}`}
                                  id={`Typesofcontract-Services-${index}`}
                                  checked={selectedOption === "hide"}
                                  value="hide"
                                  onChange={(event) =>
                                    handleChange(
                                      event.target.name,
                                      event.target.value,
                                      data.fieldId,
                                      "hide"
                                    )
                                  }
                                />
                                {console.log("index", index)}
                                <label
                                  className="form-check-label"
                                  htmlFor={`Typesofcontract-Services-${index}`}
                                >
                                  Hide
                                </label>
                              </div> */}

                                <select
                                  className="form-select"
                                  aria-label="Default select example"
                                  name="forShowHide"
                                  value={setSelectedOption}
                                  onChange={(event) =>
                                    handleChange(
                                      event.target.name,
                                      event.target.value,
                                      data.fieldId,
                                      "fieldId"
                                    )
                                  }
                                >
                                  {HIDE_SHOW_VALUES &&
                                    HIDE_SHOW_VALUES.map((option, index) => (
                                      <option
                                        value={option.value}
                                        selected={
                                          data.forShowHide === 1
                                            ? option.value === 1
                                            : option.value === 0
                                        }
                                      >
                                        {option.displayKey}
                                      </option>
                                    ))}
                                </select>
                              </div>
                            </td>
                          </tr>
                        );
                      } else {
                        return null;
                      }
                    }
                  )}
              </tbody>
            </table>
          </div>
        </div>
        <div className="NextPrev">
          <button
            className="btnPrevious"
            onClick={() => handleButtonsClientConfig("prevButton", "")}
          >
            Prev
          </button>
          <button
            className="btnNext"
            onClick={() =>
              handleButtonsClientConfig("nextButton", "generalConfiguration")
            }
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
