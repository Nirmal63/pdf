import React, { Component } from "react";
import { HIDE_SHOW_VALUES } from "../../containers/ClientConfigureParameter/constants";
import { isNullAndIsUndefined } from "../../commonConstants/CommonValidator";

export default class BidSubmissionConfiguration extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedOptions: {},
    };
  }
  render() {
    const {
      handleButtonsClientConfig,
      getClientCustomParameterDetailsResponse,
      getAllprocurementnatureResponse,

      classDTOClientConfig,
      setSelectedOption,
      handleChange,
    } = this.props;

    //const { selectedOptions } = this.state;

    // if (
    //   getClientCustomParameterDetailsResponse &&
    //   getClientCustomParameterDetailsResponse.customParameterDTOList.length &&
    //   getClientCustomParameterDetailsResponse.customParameterDTOList.length > 0
    // )
    {
      let data =
        getClientCustomParameterDetailsResponse &&
        getClientCustomParameterDetailsResponse.customParameterDTOList &&
        getClientCustomParameterDetailsResponse.customParameterDTOList.map(
          (data, index) => {
            let tempData = data;
            let values = data.controlValue.split("~");
            if (values.length > 0) {
              const defaultOption = [];
              for (let i = 0; i < values.length; i++) {
                const displayKeyWithLabel = values[i].split("::")[0];
                const value = values[i].split("::")[1];

                const displayKey = displayKeyWithLabel.replace("label_", ""); // Remove "label_" prefix
                const capitalizedDisplayKey =
                  displayKey.charAt(0).toUpperCase() + displayKey.slice(1); // Capitalize the first letter

                defaultOption.push({
                  displayKey: capitalizedDisplayKey,
                  value,
                });
              }
              tempData.defaultOption = defaultOption;
            }

            return tempData;
          }
        );
    }
    const { selectedOptions } = this.state;
    return (
      <div
        class="tab-pane fade"
        id="BidSubmissionConfiguration"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <div class="row">
          <div class="col-12">
            <h5 class="MediumTitle">Time auto extension configuration</h5>
          </div>
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th></th>
                  <th>
                    <h5 class="SmallTitle">Field caption</h5>
                  </th>
                  <th>
                    <h5 class="SmallTitle">Default value</h5>
                  </th>
                  <th>
                    <h5 class="SmallTitle">Display in Event notice page</h5>
                  </th>
                </tr>
              </thead>
              <tbody>
                {getClientCustomParameterDetailsResponse &&
                  getClientCustomParameterDetailsResponse.customParameterDTOList &&
                  getClientCustomParameterDetailsResponse.customParameterDTOList.map(
                    (data, index) => {
                      if (data.fieldGroupId === 9) {
                        const selectedOption =
                          selectedOptions[index] ||
                          (data.forShowHide === 1 ? "show" : "hide");
                        return (
                          <tr key={index}>
                            <td>
                              <h5 class="SmallTitle">{data.fieldLabel}</h5>
                            </td>
                            <td>
                              <input
                                type="text"
                                class="form-control"
                                name="fieldCaption"
                                placeholder={data.fieldLabel}
                                onChange={(event) =>
                                  handleChange(
                                    event.target.name,
                                    event.target.value,
                                    data.fieldId,
                                    "fieldId"
                                  )
                                }
                              />
                            </td>
                            <td>
                              <>
                                {data.controlType == 1 ? (
                                  <div>
                                    <input
                                      type="text"
                                      className="form-control"
                                      name="defaultvalue"
                                      // maxlength="20"
                                      onChange={(event) =>
                                        handleChange(
                                          event.target.name,
                                          event.target.value,
                                          data.fieldId,
                                          "fieldId"
                                        )
                                      }
                                    />
                                    {classDTOClientConfig &&
                                    classDTOClientConfig.gstNoError ? (
                                      <label className="error">
                                        {classDTOClientConfig.gstNoError}
                                      </label>
                                    ) : (
                                      ""
                                    )}
                                  </div>
                                ) : (
                                  <div>
                                    {data.controlType == 2 ? (
                                      <select
                                        className="form-select"
                                        aria-label="Default select example"
                                        name="defaultvalue"
                                        value={setSelectedOption}
                                        onChange={(event) =>
                                          handleChange(
                                            event.target.name,
                                            event.target.value,
                                            data.fieldId,
                                            "fieldId"
                                          )
                                        }
                                      >
                                        {data.defaultOption &&
                                          data.defaultOption.map(
                                            (option, index) => (
                                              <option
                                                key={index}
                                                value={option.value}
                                                selected={
                                                  option.value ==
                                                  data.defaultvalue
                                                }
                                              >
                                                {option.displayKey}
                                              </option>
                                            )
                                          )}
                                      </select>
                                    ) : (
                                      ""
                                    )}

                                    {classDTOClientConfig &&
                                    classDTOClientConfig.isGSTRequiredError ? (
                                      <label className="error">
                                        {
                                          classDTOClientConfig.isGSTRequiredError
                                        }
                                      </label>
                                    ) : (
                                      ""
                                    )}
                                  </div>
                                )}
                              </>
                            </td>
                            <td>
                              <div>
                                <select
                                  className="form-select"
                                  aria-label="Default select example"
                                  name="forShowHide"
                                  value={setSelectedOption}
                                  onChange={(event) =>
                                    handleChange(
                                      event.target.name,
                                      event.target.value,
                                      data.fieldId,
                                      "fieldId"
                                    )
                                  }
                                >
                                  {HIDE_SHOW_VALUES &&
                                    HIDE_SHOW_VALUES.map((option, index) => (
                                      <option
                                        value={option.value}
                                        selected={
                                          data.forShowHide === 1
                                            ? option.value === 1
                                            : option.value === 0
                                        }
                                      >
                                        {option.displayKey}
                                      </option>
                                    ))}
                                </select>
                              </div>
                            </td>
                          </tr>
                        );
                      } else {
                        return null;
                      }
                    }
                  )}
              </tbody>
            </table>
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsClientConfig("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() =>
              handleButtonsClientConfig(
                "nextButton",
                "bidSubmissionConfiguration"
              )
            }
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
