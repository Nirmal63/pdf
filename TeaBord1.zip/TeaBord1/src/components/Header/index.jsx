import React, { Component } from "react";
import LoginContainer from "../../containers/Login";
import $ from "jquery";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";
import { getLocalStorageItem } from "../../commonConstants/LocalStorageData";

export default class index extends Component {
  loginButtonClick = () => {
    // console.log("in");
  };

  logoutButtonClick = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("userId");
    localStorage.removeItem("usertypeId");
    localStorage.removeItem("clientId");

    window.location.href = "/dashboard";
  };

  registerBidder = () => {
    window.location.href = "/registerBidder";
  };

  sidebarToggleClick = () => {
    if (
      this.props.isAuthenticated ||
      !isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("token"))
    ) {
      $(".AfterLoginSide").toggleClass("active");
      $(".SidebarToggle .fas").toggleClass(
        "fa-angle-double-left fa-angle-double-right"
      );
      $("body").toggleClass("active");
    } else {
      $(".BeforeLoginSide").toggleClass("active");
      $(".SidebarToggle .fas").toggleClass(
        "fa-angle-double-left fa-angle-double-right"
      );
      $("body").toggleClass("active");
    }
  };
  render() {
    return (
      <>
        <LoginContainer />
        <header>
          <nav className="navbar navbar-expand-lg navbar-light bg-light">
            <div className="container-fluid">
              <a className="navbar-brand" href="#">
                Navbar
              </a>
              {
                <button
                  class="navbar-toggler"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarSupportedContent"
                  aria-controls="navbarSupportedContent"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <a
                    class="SidebarToggle "
                    onClick={() => this.sidebarToggleClick()}
                  >
                    {" "}
                    <i class="fa-solid fa-bars"></i>
                  </a>
                </button>
              }

              {isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("clientId")) ? (
                ""
              ) : (
                <>
                  {" "}
                  {this.props.isAuthenticated ||
                  isNullOrIsEmptyOrIsUndefined(
                    localStorage.getItem("token")
                  ) ? (
                    <div
                      className="collapse navbar-collapse"
                      id="navbarSupportedContent"
                    >
                      <ul className="navbar-nav ms-auto">
                        <li className="nav-item">
                          <a
                            className="nav-link"
                            data-bs-toggle="modal"
                            data-bs-target="#exampleModal"
                            onClick={() => this.loginButtonClick()}
                          >
                            Login
                          </a>
                        </li>
                      </ul>
                    </div>
                  ) : (
                    <div
                      className="collapse navbar-collapse"
                      id="navbarSupportedContent"
                    >
                      <ul className="navbar-nav ms-auto">
                        <li className="nav-item">
                          <a
                            className="nav-link"
                            onClick={() => this.logoutButtonClick()}
                          >
                            Logout
                          </a>
                        </li>
                      </ul>
                    </div>
                  )}
                </>
              )}
            </div>
          </nav>
        </header>
      </>
    );
  }
}
