import React, { Component } from "react";
// import LoadingComponent from "../../components/GenericComponents/Loader";
import SideBar from "../../components/SideBarNew";
import RouterComponent from "../../routes";
import Header from "../../components/Header";
import $ from "jquery";

export default class index extends Component {
  sidebarToggleClick = () => {
    $(".BeforeLoginSide").toggleClass("active");
    $(".AfterLoginSide").toggleClass("active");
    $(".SidebarToggle .fas").toggleClass(
      "fa-angle-double-left fa-angle-double-right"
    );
    $("body").toggleClass("active");
  };

  showLoading = () => {
    // if (this.props.isLoading) {
    // return <LoadingComponent />;
    // }
  };

  render() {
    return (
      <div className={"MainBox"}>
        <Header {...this.props} />
        <div className="MainScreen">
          <SideBar {...this.props} />

          <div className="ComponentScreen">
            {/* {this.showLoading()} */}

            <a
              className="SidebarToggle Desktop"
              onClick={() => this.sidebarToggleClick()}
            >
              <i className="fas fa-angle-double-left"></i>
            </a>

            <RouterComponent {...this.props} />
          </div>
        </div>
      </div>
    );
  }
}
