import React, { Component } from "react";
import $ from "jquery";

export default class index extends Component {
  sidebarToggleMobileClick = () => {
    $(".AfterLoginSide").toggleClass("active");
    $(".SidebarToggle .fas").toggleClass(
      "fa-angle-double-left fa-angle-double-right"
    );
    $("body").removeClass("active");
  };

  render() {
    return (
      <div class="AfterLoginSide">
        <a
          class="SidebarToggle Mobile"
          onClick={() => this.sidebarToggleMobileClick()}
        >
          <i class="fa fa-times"></i>
        </a>

        <ul class="Contact">
          {/* <li class="ProfileNames">
            <h5 class="UserName">Welcome Super Admin - ETL</h5>
            <h6>19/05/2023 10:02:03 IST</h6>
          </li> */}
          <div class="accordion" id="accordionSideBar">
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingAdministrator">
                <button
                  class={
                    window.location.href &&
                    (window.location.href.includes("/createClient") ||
                      window.location.href.includes("/manageClient") ||
                      window.location.href.includes("/registerUser") ||
                      window.location.href.includes("/registerBidder") ||
                      window.location.href.includes("/createDepartment") ||
                      window.location.href.includes("/createDesignation") ||
                      window.location.href.includes("/createGrade") ||
                      window.location.href.includes(
                        "/clientConfigureParameter"
                      ))
                      ? "accordion-button"
                      : "accordion-button collapsed"
                  }
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#Administration"
                  aria-expanded={
                    window.location.href &&
                    (window.location.href.includes("/createClient") ||
                      window.location.href.includes("/manageClient") ||
                      window.location.href.includes("/registerUser") ||
                      window.location.href.includes("/registerBidder") ||
                      window.location.href.includes("/createDepartment") ||
                      window.location.href.includes("/createDesignation") ||
                      window.location.href.includes("/createGrade") ||
                      window.location.href.includes(
                        "/clientConfigureParameter"
                      ))
                      ? "true"
                      : "false"
                  }
                  aria-controls="Administration"
                >
                  <i class="fa fa-user"></i> Administration
                </button>
              </h2>
              <div
                id="Administration"
                class={
                  window.location.href &&
                  (window.location.href.includes("/createClient") ||
                    window.location.href.includes("/manageClient") ||
                    window.location.href.includes("/registerUser") ||
                    window.location.href.includes("/registerBidder") ||
                    window.location.href.includes("/createDepartment") ||
                    window.location.href.includes("/createDesignation") ||
                    window.location.href.includes("/createGrade") ||
                    window.location.href.includes("/clientConfigureParameter"))
                    ? "accordion-collapse collapse show"
                    : "accordion-collapse collapse"
                }
                aria-labelledby="headingAdministrator"
                data-bs-parent="#accordionSideBar"
              >
                <div class="accordion-body">
                  <div class="accordion-body">
                    <ul>
                      <li
                        onClick={() => {
                          window.location.href = "/createClient";
                        }}
                      >
                        Create client
                      </li>

                      <li
                        onClick={() => {
                          window.location.href = "/manageClient";
                        }}
                      >
                        Manage client
                      </li>

                      <li
                        onClick={() => {
                          window.location.href = "/clientConfigureParameter";
                        }}
                      >
                        Client Configure Parameter
                      </li>

                      <li
                        onClick={() => {
                          window.location.href = "/createDepartment";
                        }}
                      >
                        Create department
                      </li>
                      <li
                        onClick={() => {
                          window.location.href = "/createDesignation";
                        }}
                      >
                        Create designation
                      </li>
                      <li
                        onClick={() => {
                          window.location.href = "/createGrade";
                        }}
                      >
                        Create grade
                      </li>

                      <li
                        onClick={() => {
                          window.location.href = "/registerUser";
                        }}
                      >
                        Register user
                      </li>

                      <li
                        onClick={() => {
                          window.location.href = "/registerBidder";
                        }}
                      >
                        Register bidder
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div class="accordion-item">
              <h2 class="accordion-header" id="headingAuction">
                <button
                  class={
                    window.location.href &&
                    (window.location.href.includes("/createAuction") ||
                      window.location.href.includes("/auctionList") ||
                      window.location.href.includes("/biddingHall") ||
                      window.location.href.includes("/auctionDashboard") ||
                      window.location.href.includes("/createAuctionFormula") ||
                      window.location.href.includes("/approveAuction"))
                      ? "accordion-button"
                      : "accordion-button collapsed"
                  }
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#Auction"
                  aria-expanded={
                    window.location.href &&
                    (window.location.href.includes("/createAuction") ||
                      window.location.href.includes("/auctionList") ||
                      window.location.href.includes("/biddingHall") ||
                      window.location.href.includes("/auctionDashboard") ||
                      window.location.href.includes("/createAuctionFormula") ||
                      window.location.href.includes("/approveAuction"))
                      ? "true"
                      : "false"
                  }
                  aria-controls="Auction"
                >
                  <i class="fa fa-user"></i> Auction
                </button>
              </h2>
              <div
                id="Auction"
                class={
                  window.location.href &&
                  (window.location.href.includes("/createAuction") ||
                    window.location.href.includes("/auctionList") ||
                    window.location.href.includes("/biddingHall") ||
                    window.location.href.includes("/auctionDashboard") ||
                    window.location.href.includes("/createAuctionFormula") ||
                    window.location.href.includes("/approveAuction"))
                    ? "accordion-collapse collapse show"
                    : "accordion-collapse collapse"
                }
                aria-labelledby="headingAuction"
                data-bs-parent="#accordionSideBar"
              >
                <div class="accordion-body">
                  <div class="accordion-body">
                    <ul>
                      <li
                        onClick={() => {
                          window.location.href = "/createAuction";
                        }}
                      >
                        Create auction
                      </li>

                      <li
                        onClick={() => {
                          window.location.href = "/auctionList";
                        }}
                      >
                        Auction list
                      </li>

                      {/* <li
                        onClick={() => {
                          window.location.hash = "#/biddingHall";
                        }}
                      >
                        Bidding hall
                      </li> */}
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            <div class="text-center mt-3">
              <button class="m-auto BlueButton Mobile">Logout</button>
            </div>
            {/* <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#RFXTender"
                  aria-expanded="false"
                  aria-controls="RFXTender"
                >
                  <i class="fa fa-file"></i> RFX/Tender
                </button>
              </h2>
              <div
                id="RFXTender"
                class="accordion-collapse collapse"
                aria-labelledby="headingThree"
                data-bs-parent="#accordionExample"
              >
                <div class="accordion-body">
                  <div class="accordion-body">
                    <ul>
                      <li>Create RFX/Tender</li>
                      <li>Search RFX/Tender</li>
                      <li>Bid opening</li>
                      <li>Bid evaluation</li>
                      <li>Pre-bid meeting</li>
                      <li>Negotiation</li>
                      <li>BOQ</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>{" "} */}
            {/* <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#Auction"
                  aria-expanded="false"
                  aria-controls="Auction"
                >
                  <i class="fa fa-gavel" aria-hidden="true"></i> Auction
                </button>
              </h2>
              <div
                id="Auction"
                class="accordion-collapse collapse"
                aria-labelledby="headingThree"
                data-bs-parent="#accordionExample"
              >
                <div class="accordion-body">
                  <div class="accordion-body">
                    <ul>
                      <li>Create auction Excel</li>
                      <li>Create auction</li>
                      <li>Search auction</li>
                      <li>Negotiation</li>
                      <li>Search Bulk Auction</li>
                      <li>Manage Revive Auction</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#Workflow"
                  aria-expanded="false"
                  aria-controls="Workflow"
                >
                  <i class="fas fa-tasks"></i> Workflow
                </button>
              </h2>
              <div
                id="Workflow"
                class="accordion-collapse collapse"
                aria-labelledby="headingThree"
                data-bs-parent="#accordionExample"
              >
                <div class="accordion-body">
                  <div class="accordion-body">
                    <ul>
                      <li>My pending tasks</li>
                      <li>My processed tasks</li>
                      <li>Pull up</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div> */}
            {/* <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#Reports"
                  aria-expanded="false"
                  aria-controls="Reports"
                >
                  <i class="fas fa-file-edit"></i> Reports
                </button>
              </h2>
              <div
                id="Reports"
                class="accordion-collapse collapse"
                aria-labelledby="headingThree"
                data-bs-parent="#accordionExample"
              >
                <div class="accordion-body">
                  <div class="accordion-body">
                    <ul>
                      <li>Compose</li>
                      <li>Inbox</li>
                      <li>Starred</li>
                      <li>Draft</li>
                      <li>Sent</li>
                      <li>Trash</li>
                      <li>To do</li>
                      <li>Manage label</li>
                      <li>All labels</li>
                    </ul>
                  </div>
                </div>
              </div>
              <button class="AccordionLink">
                <i class="fa-solid fa-phone-slash"></i> Check DND
              </button>
              <div class="accordion-item">
                <h2 class="accordion-header" id="headingThree">
                  <button
                    class="accordion-button collapsed"
                    type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#Download"
                    aria-expanded="false"
                    aria-controls="Download"
                  >
                    <i class="fas fa-download"></i> Download
                  </button>
                </h2>
                <div
                  id="Download"
                  class="accordion-collapse collapse"
                  aria-labelledby="headingThree"
                  data-bs-parent="#accordionExample"
                >
                  <div class="accordion-body">
                    <div class="accordion-body">
                      <ul>
                        <li>27_04TEst</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div> */}
          </div>
        </ul>
      </div>
    );
  }
}
