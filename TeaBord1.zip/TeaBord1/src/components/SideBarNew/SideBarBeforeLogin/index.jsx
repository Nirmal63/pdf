import React, { Component } from "react";
import $ from "jquery";

export default class index extends Component {
  onClickOpenWindow = (url) => {
    window.open(url);
  };

  sidebarToggleMobileClick = () => {
    $(".BeforeLoginSide").toggleClass("active");
    $(".SidebarToggle .fas").toggleClass(
      "fa-angle-double-left fa-angle-double-right"
    );
    $("body").removeClass("active");
  };

  render() {
    return (
      <div className="BeforeLoginSide">
        <a
          class="SidebarToggle Mobile"
          onClick={() => this.sidebarToggleMobileClick()}
        >
          <i class="fa fa-times"></i>
        </a>

        <ul className="Contact">
          <small>Contact</small>
          <li>
            <a href="#">
              <i className="fa fa-phone" aria-hidden="true"></i>
              +91 - 9099090830
            </a>
          </li>
          <li>
            <a href="#">
              <i className="fa fa-envelope" aria-hidden="true"></i>{" "}
              dsc@abcprocure.com
            </a>
          </li>
        </ul>
        <ul className="Contact">
          <small>Our Product</small>
          <li
            onClick={() =>
              this.onClickOpenWindow("http://www.eptl.in/pt/cc/PT/")
            }
          >
            <a>
              <i className="fa-regular fa-circle-check"></i> Procure Tiger
            </a>
          </li>
          <li
            onClick={() =>
              this.onClickOpenWindow("http://www.eptl.in/pt/cc/TT/")
            }
          >
            <a>
              <i className="fa-regular fa-circle-check"></i> Tender Tiger
            </a>
          </li>
          <li
            onClick={() =>
              this.onClickOpenWindow("http://www.eptl.in/pt/cc/AT/")
            }
          >
            <a>
              <i className="fa-regular fa-circle-check"></i> Auction Tiger
            </a>
          </li>
          <li
            onClick={() =>
              this.onClickOpenWindow("http://www.eptl.in/pt/cc/ST/")
            }
          >
            <a>
              <i className="fa-regular fa-circle-check"></i> Supplier Tiger
            </a>
          </li>
        </ul>
        <ul className="Contact">
          <small>Services</small>
          <li>
            <a href="#">
              <i className="fa-regular fa-circle-check"></i> SSL root
              Certificate
            </a>
          </li>
          <li>
            <a href="#">
              <i className="fa-regular fa-circle-check"></i> Winzip
            </a>
          </li>
          <li>
            <a href="#">
              <i className="fa-regular fa-circle-check"></i> SPDF reader
            </a>
          </li>
          <li>
            <a href="#">
              <i className="fa-regular fa-circle-check"></i> Signer Component
            </a>
          </li>
        </ul>
        <div class="text-center mt-3">
          <button class="m-auto BlueButton Mobile">Login</button>
        </div>
      </div>
    );
  }
}
