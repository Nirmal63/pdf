import React, { Component } from "react";
import SideBarBeforeLogin from "./SideBarBeforeLogin";
import SideBarAfterLogin from "./SideBarAfterLogin";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";
import { getLocalStorageItem } from "../../commonConstants/LocalStorageData";

export default class index extends Component {
  render() {
    return (
      <>
        {this.props.isAuthenticated ||
        !isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("token")) ? (
          <SideBarAfterLogin
            isAuthenticated={this.props.isAuthenticated}
            updateIsAuthenticated={this.props.updateIsAuthenticated}
          />
        ) : (
          <SideBarBeforeLogin
            isAuthenticated={this.props.isAuthenticated}
            updateIsAuthenticated={this.props.updateIsAuthenticated}
          />
        )}
      </>
    );
  }
}
