import React, { Component } from "react";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";

export default class index extends Component {
  render() {
    const {
      handleButtonsAuctionFormula,
      handleClassDTOAuctionFormula,
      classDTOAuctionFormula,
      getcreateformulastep1Response,
      getcreateformulastep4Response,
      submitAuctionFormulaDetailsResponse,
      removeGoverningColumnResponse,
    } = this.props;

    return (
      <div>
        <h2 class="Title">Formula And Governing Column</h2>
        <div class="CreateClient ShadowBox">
          <div class="row g-3">
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Step 1*</label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="columnId"
                value={
                  (classDTOAuctionFormula &&
                    classDTOAuctionFormula.columnId &&
                    JSON.stringify(classDTOAuctionFormula.columnId)) ||
                  ""
                }
                onChange={(event) =>
                  handleClassDTOAuctionFormula(
                    event.target.name,
                    event.target.value
                  )
                }
              >
                <option value="">Please Select</option>
                {getcreateformulastep1Response &&
                  getcreateformulastep1Response.map((data, index) => (
                    <option value={JSON.stringify(data)}>
                      {data.columnHeader}
                    </option>
                  ))}
              </select>

              {classDTOAuctionFormula &&
              classDTOAuctionFormula.columnIdError ? (
                <label className="error">
                  {classDTOAuctionFormula.columnIdError}
                </label>
              ) : (
                ""
              )}
            </div>
            <label class="LabelText">Step 2*</label>

            <div class="TableBox">
              <table class="table">
                <thead>
                  <tr>
                    <th>Item Name</th>
                    <th>Quantity</th>
                    <th>Unit Rate</th>
                    <th>Total Rate</th>
                  </tr>
                </thead>
                <tbody>
                  {/* {getAuctionFiledDetails &&
                    getAuctionFiledDetails.map((data, index) => ( */}
                  <tr>
                    <td>Item 1</td>
                    <td>
                      <input
                        type="text"
                        class="form-control"
                        name="quantity"
                        id="quantity"
                        onChange={(event) =>
                          handleClassDTOAuctionFormula(
                            event.target.name,
                            event.target.value
                          )
                        }
                        value={
                          classDTOAuctionFormula &&
                          classDTOAuctionFormula.quantity
                        }
                        // onClick={() => handleButtonsAuctionFormula("quantity")}
                      />
                      {classDTOAuctionFormula &&
                      classDTOAuctionFormula.quantityError ? (
                        <label className="error">
                          {classDTOAuctionFormula.quantityError}
                        </label>
                      ) : (
                        ""
                      )}
                    </td>
                    <td>
                      <input
                        type="text"
                        class="form-control"
                        name="unitRate"
                        id="unitRate"
                        onChange={(event) =>
                          handleClassDTOAuctionFormula(
                            event.target.name,
                            event.target.value
                          )
                        }
                        value={
                          classDTOAuctionFormula &&
                          classDTOAuctionFormula.unitRate
                        }
                      />
                      {classDTOAuctionFormula &&
                      classDTOAuctionFormula.unitRateError ? (
                        <label className="error">
                          {classDTOAuctionFormula.unitRateError}
                        </label>
                      ) : (
                        ""
                      )}
                    </td>
                    <td>
                      <input
                        type="text"
                        class="form-control"
                        name="TotalRate"
                        id="TotalRate"
                        disabled={true}
                        onChange={(event) =>
                          handleClassDTOAuctionFormula(
                            event.target.name,
                            event.target.value
                          )
                        }
                        value={
                          classDTOAuctionFormula &&
                          classDTOAuctionFormula.TotalRate
                        }
                      />
                    </td>
                  </tr>
                  {/* ))} */}
                </tbody>
              </table>
            </div>

            <table style={{ width: "100%" }}>
              <tr>
                <td class="col-10">
                  {" "}
                  <textarea
                    class="form-control"
                    id="displayFormula"
                    name="displayFormula"
                    maxLength="1000"
                    disabled={true}
                    // value={
                    //   classDTOAuctionFormula &&
                    //   classDTOAuctionFormula.displayFormula
                    // }
                    value={"Total Rate = Quantity * Unit Rate"}
                  ></textarea>{" "}
                </td>
                <tr>
                  <td class="col-2">
                    <input
                      disabled="true"
                      type="button"
                      value="*"
                      // onclick="display('*')"
                      onClick={() => handleButtonsAuctionFormula("multiple")}
                    />
                  </td>
                  <td>
                    <input
                      type="button"
                      disabled="true"
                      value="/"
                      // onclick="display('/')"
                      onClick={() => handleButtonsAuctionFormula("divisions")}
                    />
                  </td>
                  <td>
                    <input
                      disabled="true"
                      type="button"
                      value="+"
                      // onclick="display('+')"
                      onClick={() => handleButtonsAuctionFormula("plus")}
                    />
                  </td>
                  <td>
                    <input
                      disabled="true"
                      type="button"
                      value="-"
                      // onclick="display('-')"
                      onClick={() =>
                        handleButtonsAuctionFormula("subscription")
                      }
                    />
                  </td>
                </tr>
                <tr>
                  <td class="col-2">
                    <input
                      disabled="true"
                      type="button"
                      value="("
                      // onclick="display('(')"
                      onClick={() => handleButtonsAuctionFormula("openPer")}
                    />
                  </td>
                  <td>
                    <input
                      disabled="true"
                      type="button"
                      value=")"
                      // onclick="display(')')"
                      onClick={() => handleButtonsAuctionFormula("closePer")}
                    />
                  </td>
                  <td>
                    <input
                      disabled="true"
                      type="button"
                      value="Number"
                      onclick="display('Number')"
                    />
                  </td>
                </tr>
                <tr>
                  <td class="col-2">
                    <input
                      disabled="true"
                      type="button"
                      value="Undo"
                      onclick="display('undo')"
                      onClick={() => handleButtonsAuctionFormula("undo")}
                    />
                  </td>
                  <td>
                    <input
                      disabled="true"
                      type="button"
                      value="Clear"
                      onclick="display('Clear')"
                      onClick={() => handleButtonsAuctionFormula("clear")}
                    />
                  </td>
                </tr>
              </tr>
            </table>

            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Step 3*</label>
              <button
                class="BlueButton"
                onClick={() => handleButtonsAuctionFormula("testFormula")}
                value={
                  classDTOAuctionFormula.quantity.value +
                  "*" +
                  classDTOAuctionFormula.unitRate.value
                }
              >
                Test Formula
              </button>
            </div>
            {classDTOAuctionFormula && !classDTOAuctionFormula.isSubmitted ? (
              <div class="col-xl-3 col-lg-4 col-md-6 col-12">
                <label class="LabelText">Step 4*</label>
                <select
                  class="form-select"
                  aria-label="Default select example"
                  name="govColumnId"
                  value={
                    (classDTOAuctionFormula &&
                      classDTOAuctionFormula.govColumnId &&
                      JSON.stringify(classDTOAuctionFormula.govColumnId)) ||
                    ""
                  }
                  onChange={(event) =>
                    handleClassDTOAuctionFormula(
                      event.target.name,
                      event.target.value
                    )
                  }
                >
                  <option value="">--Govorning Column--</option>
                  {getcreateformulastep4Response &&
                    getcreateformulastep4Response.map((data, index) => (
                      <option value={JSON.stringify(data)}>
                        {data.columnHeader}
                      </option>
                    ))}
                </select>
                {classDTOAuctionFormula &&
                classDTOAuctionFormula.govColumnIdError ? (
                  <label className="error">
                    {classDTOAuctionFormula.govColumnIdError}
                  </label>
                ) : (
                  ""
                )}
              </div>
            ) : (
              <div class="col-xl-3 col-lg-6 col-md-6 col-12">
                {submitAuctionFormulaDetailsResponse &&
                  submitAuctionFormulaDetailsResponse.govColumnId}{" "}
                "Unit Rate" is Governing Column
                <label
                  class="LabelText"
                  onClick={() => handleButtonsAuctionFormula("removeGov")}
                >
                  [remove governing column]
                </label>
              </div>
            )}
            {/* {classDTOAuctionFormula && classDTOAuctionFormula.isSubmitted ? (
              <div class="col-xl-3 col-lg-6 col-md-6 col-12">
                {submitAuctionFormulaDetailsResponse.govColumnId} "Unit Rate" is
                Governing Column
                <label
                  class="LabelText"
                  onClick={() => handleButtonsAuctionFormula("removeGov")}
                >
                  [remove governing column]
                </label>
              </div>
            ) : (
              ""
            )} */}
          </div>

          <div class="submit">
            <button
              class="BlueButton m-auto mt-5"
              onClick={() => handleButtonsAuctionFormula("submit")}
            >
              Save Formula
            </button>
          </div>
        </div>
      </div>
    );
  }
}
