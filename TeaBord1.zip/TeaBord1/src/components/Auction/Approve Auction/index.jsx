import { data, event } from "jquery";
import React, { Component } from "react";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import { AUCTION_VARIANT } from "../../../containers/Auction/ApproveAuction/reducer";

export default class index extends Component {
  render() {
    const {
      handleButtonsApproveAuction,
      getAllAucionDetailsByAuctionIdResponse,
    } = this.props;
    return (
      <div>
        <h2 class="Title">Approve Auction</h2>
        <div class="CreateClient ShadowBox">
          <div class="row g-4">
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Department: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.departmentName}
              </label>
              v
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Officer: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.officerName}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Auction ID: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.auctionId}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Auction no:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.auctionNo}
              </label>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Auction brief: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.auctionBrief}
              </label>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Auction detail: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.auctionDetail}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Product location: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.productLocation}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Document fees:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.documentFee}
              </label>
            </div>{" "}
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Participation/Processing fees: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.participationFee}
              </label>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">
                Event wise registration charges applicable on:{" "}
              </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.isRegistrationCharges}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Budget: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.BigDecimal}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Auction variant:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.eventTypeId &&
                1 == getAllAucionDetailsByAuctionIdResponse.eventTypeId
                  ? "Forward"
                  : "Reverse"}
              </label>
            </div>{" "}
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Bidding type: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.biddingType &&
                1 == getAllAucionDetailsByAuctionIdResponse.biddingType
                  ? "NCB/Domestic"
                  : "Domestic"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Bidding access: </label>{" "}
              <label class="text">
                Limited
                {/* {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.participationFee} */}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Auction type: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.typeOfAuction &&
                0 == getAllAucionDetailsByAuctionIdResponse.typeOfAuction
                  ? "Standard"
                  : "Other"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Auction base currency:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.defaultCurrency}
              </label>
            </div>{" "}
            {/* <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">
                Bidding currencies and their exchange rate for base currency:{" "}
              </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.participationFee}
              </label>
            </div> */}
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Bid submission for: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.auctionResult}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">
                Requires check on minimum quantity:{" "}
              </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isMinQtyReq &&
                0 == getAllAucionDetailsByAuctionIdResponse.isMinQtyReq
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">
                Line item wise bid submission time allowed?:
              </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isItemWiseTime &&
                1 == getAllAucionDetailsByAuctionIdResponse.isItemWiseTime
                  ? "YES"
                  : "NO"}
              </label>
            </div>{" "}
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Start date and time: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.startDate}
              </label>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">End date and time: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.endDate}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Allowed auto extension?: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isAutoExt &&
                1 == getAllAucionDetailsByAuctionIdResponse.isAutoExt
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">
                Extend time when valid bid received in last(in minutes):
              </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.extendWhen}
              </label>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Extend time by(in minutes): </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.extendBy}
              </label>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">No. of extension: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.totalExt}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Increment in certain period: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isIncDecInPeriod &&
                1 == getAllAucionDetailsByAuctionIdResponse.isIncDecInPeriod
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Reserve price check require:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.checkReservePrice &&
                1 == getAllAucionDetailsByAuctionIdResponse.checkReservePrice
                  ? "YES"
                  : "NO"}
              </label>
            </div>{" "}
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Accept decimal value upto: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.decimalValueUpto}
              </label>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">No. of Bid Restriction: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.noOfBidRestriction &&
                1 == getAllAucionDetailsByAuctionIdResponse.noOfBidRestriction
                  ? "Allowed"
                  : "Don't allow"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">
                Result Sharing for Specific Duration:{" "}
              </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.resultSharingForSpecificDuration &&
                1 ==
                  getAllAucionDetailsByAuctionIdResponse.resultSharingForSpecificDuration
                  ? "Allowed"
                  : "Don't allow"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">First bid acceptance condition:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.firstBidCond &&
                1 == getAllAucionDetailsByAuctionIdResponse.firstBidCond
                  ? "Allowed"
                  : "Don't allow"}
              </label>
            </div>{" "}
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Mask bidder name: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isBidderNameMasking &&
                1 == getAllAucionDetailsByAuctionIdResponse.isBidderNameMasking
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">
                Display bidder name encoding to officer:{" "}
              </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isEncodedName &&
                1 == getAllAucionDetailsByAuctionIdResponse.isEncodedName
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Bidding form: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.biddingForm &&
                1 == getAllAucionDetailsByAuctionIdResponse.biddingForm
                  ? "Create new form"
                  : "Copy existing form"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Decode bidder name manually:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isDecodeBidder &&
                1 == getAllAucionDetailsByAuctionIdResponse.isDecodeBidder
                  ? "YES"
                  : "NO"}
              </label>
            </div>{" "}
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">
                Display winning bidder name to bidder:{" "}
              </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.showWinnerName &&
                1 == getAllAucionDetailsByAuctionIdResponse.showBidderWiseForm
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-6 col-md-6 col-12">
              <label class="LabelText">
                Display last accepted bid to bidder:{" "}
              </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.showLastBid &&
                1 == getAllAucionDetailsByAuctionIdResponse.showLastBid
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Display rank: </label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.showRank &&
                1 == getAllAucionDetailsByAuctionIdResponse.showRank
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Enable Result API:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isResultApiRequired &&
                1 == getAllAucionDetailsByAuctionIdResponse.isResultApiRequired
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Bidder wise form display:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.showBidderWiseForm &&
                1 == getAllAucionDetailsByAuctionIdResponse.showBidderWiseForm
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Restrict bidder on H1:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isRestrictBidderOnl1h1 &&
                1 ==
                  getAllAucionDetailsByAuctionIdResponse.isRestrictBidderOnl1h1
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Evaluation required?:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isEvaluationReq &&
                1 == getAllAucionDetailsByAuctionIdResponse.isEvaluationReq
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText"> EMD required?:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isEmdReq &&
                1 == getAllAucionDetailsByAuctionIdResponse.isEmdReq
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Restrict bidder on H1 and EMD:</label>{" "}
              <label class="text">
                {/* {getAllAucionDetailsByAuctionIdResponse &&
                  getAllAucionDetailsByAuctionIdResponse.participationFee} */}
                No
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Demo auction:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.isDemoAuction &&
                1 == getAllAucionDetailsByAuctionIdResponse.isDemoAuction
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Borrower Name:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.borrowerName &&
                1 == getAllAucionDetailsByAuctionIdResponse.borrowerName
                  ? "YES"
                  : "-"}
              </label>
            </div>
            <div class="col-xl-5 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Security Fees:</label>{" "}
              <label class="text">
                {getAllAucionDetailsByAuctionIdResponse &&
                getAllAucionDetailsByAuctionIdResponse.securityFees &&
                1 == getAllAucionDetailsByAuctionIdResponse.securityFees
                  ? "YES"
                  : "NO"}
              </label>
            </div>
            <h5>Documents</h5>
            <div class="TableBox">
              <table class="table">
                <thead>
                  <tr>
                    <th>Sr. no.</th>
                    <th>Document name</th>
                    <th>Size (in kb.)</th>
                    <th>Document brief</th>
                    <th>Status</th>
                    <th>Download document</th>
                  </tr>
                </thead>
                <tbody>
                  {/* {getAuctionFiledDetails &&
                    getAuctionFiledDetails.map((data, index) => ( */}
                  <tr>
                    <p>No record found</p>
                  </tr>
                  {/* ))} */}
                </tbody>
              </table>
            </div>
          </div>

          <div class="submit">
            <button
              class="BlueButton m-auto mt-5"
              onClick={() => handleButtonsApproveAuction("submit")}
            >
              Approve
            </button>
          </div>
        </div>
      </div>
    );
  }
}
