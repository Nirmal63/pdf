import React, { Component } from "react";
import TabsComponent from "./Tabs";
import BasicDetailsComponent from "./BasicDetails";
import GeneralConfiguration from "./GeneralConfiguration";
import TimeAutoExtensionConfiguration from "./TimeAutoExtensionConfiguration";
import BidSubmissionConfiguration from "./BidSubmissionConfiguration";
import ResultConfiguration from "./ResultConfiguration";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";

export default class index extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isDefaultValueSet: false,
    };
  }

  render() {
    let {
      classDTOCreateAuction,
      updateClassDTOCreateAuction,
      getAllFieldsDetailsResponse,
    } = this.props;

    if (
      !isNullOrIsEmptyOrIsUndefined(getAllFieldsDetailsResponse) &&
      !this.state.isDefaultValueSet
    ) {
      this.state.isDefaultValueSet = true;
      {
        getAllFieldsDetailsResponse &&
          getAllFieldsDetailsResponse.map((data, index) => {
            if (490 == data.fieldId) {
              let tempData = {
                currencyId: 1,
                lang1: "INR",
                symbol: "Rs.",
                exchangeRate: 0,
                isDefault: 1,
                tblCurrency: 1,
              };

              let dataForDTO = [];
              dataForDTO.push(tempData);
              classDTOCreateAuction.aucBaseCurr = tempData;
              classDTOCreateAuction.auctionCurrencyDtoSet = dataForDTO;
              classDTOCreateAuction.defaultCurrency =
                tempData && tempData.currencyId;
            } else {
              classDTOCreateAuction[data.fieldname] = data.fieldValue;
            }
          });
      }
      updateClassDTOCreateAuction(classDTOCreateAuction);
    }

    return (
      <div>
        <h2 class="Title">Create English Auction</h2>

        <div class="CrateEnglishAuction ShadowBox">
          <TabsComponent />
          <div class="tab-content" id="myTabContent">
            <BasicDetailsComponent {...this.props} />
            <GeneralConfiguration {...this.props} />
            <TimeAutoExtensionConfiguration {...this.props} />
            <BidSubmissionConfiguration {...this.props} />
            <ResultConfiguration {...this.props} />
          </div>
        </div>
      </div>
    );
  }
}
