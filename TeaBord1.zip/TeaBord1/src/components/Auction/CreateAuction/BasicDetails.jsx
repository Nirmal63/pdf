import React, { Component } from "react";
import { SHOW_HIDE_VALUES } from "../../../containers/Auction/CreateAuction/constants";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import TreeStructureView from "../../GenericComponents/TreeStructureView";
import TextBox from "./Components/TextBox";
import TextArea from "./Components/TextArea";
import Select from "./Components/Select";
import DateTime from "./Components/DateTime";

export default class BasicDetails extends Component {
  render() {
    const {
      handleClassDTOCreateAuction,
      classDTOCreateAuction,
      handleButtonsCreateAuction,
      getAllDepartmentDetailsResponse,
      getAllOfficerDetailsResponse,
      getAllFieldsDetailsResponse,
    } = this.props;

    return (
      <div
        class="tab-pane fade show active"
        id="BasicDetails"
        role="tabpanel"
        aria-labelledby="home-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Basic Details</h6>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mb-4">
            <label class="LabelText">Department*</label>
            <TreeStructureView
              responseData={getAllDepartmentDetailsResponse}
              handleClassDTO={handleClassDTOCreateAuction}
              classDTO={classDTOCreateAuction}
              classDTOKey="tblDepartment"
              divIdName="childDivDepartmentAuction"
              iconIdName="chilIconDepartmentAuction"
              departmentTreeChildDivMargin={""}
              iconIdMarginAvailable={true}
            />

            {classDTOCreateAuction &&
            classDTOCreateAuction.tblDepartmentError ? (
              <label className="error">
                {classDTOCreateAuction.tblDepartmentError}
              </label>
            ) : (
              ""
            )}
          </div>

          <Select
            labelValue="Officer*"
            payloadkey="auctioneerId"
            value={
              (classDTOCreateAuction && classDTOCreateAuction.auctioneerId) ||
              ""
            }
            handleClassDTO={handleClassDTOCreateAuction}
            errorValue={
              classDTOCreateAuction && classDTOCreateAuction.auctioneerIdError
            }
            data={getAllOfficerDetailsResponse}
            disabled={
              isNullOrIsEmptyOrIsUndefined(getAllOfficerDetailsResponse)
                ? true
                : false
            }
            optionKey="officerName"
            optionValue="userDetailsId"
            selectValueOptionAvailable={true}
            selectValueOptionLabel="Please Select"
          />

          <TextBox
            labelValue="Auction no.*"
            textBoxType="text"
            payloadkey="auctionNo"
            value={classDTOCreateAuction && classDTOCreateAuction.auctionNo}
            maxlength="50"
            handleClassDTO={handleClassDTOCreateAuction}
            errorValue={
              classDTOCreateAuction && classDTOCreateAuction.auctionNoError
            }
          />

          {getAllFieldsDetailsResponse &&
            getAllFieldsDetailsResponse.map((data, index) => {
              if (1004 == data.fieldId && data.isShown) {
                return (
                  <Select
                    labelValue={data.fieldLabel + "*"}
                    payloadkey="displayOfficerName"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.displayOfficerName) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    errorValue={
                      classDTOCreateAuction &&
                      classDTOCreateAuction.displayOfficerNameError
                    }
                    data={SHOW_HIDE_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              }
            })}

          <TextArea
            labelValue="Brief scope of work*"
            payloadkey="auctionBrief"
            value={classDTOCreateAuction && classDTOCreateAuction.auctionBrief}
            maxlength="1000"
            handleClassDTO={handleClassDTOCreateAuction}
            errorValue={
              classDTOCreateAuction && classDTOCreateAuction.auctionBriefError
            }
          />

          <TextArea
            labelValue="Auction details*"
            payloadkey="auctionDetail"
            value={classDTOCreateAuction && classDTOCreateAuction.auctionDetail}
            maxlength="20000"
            handleClassDTO={handleClassDTOCreateAuction}
            errorValue={
              classDTOCreateAuction && classDTOCreateAuction.auctionDetailError
            }
          />

          <DateTime
            labelValue="Start date and time*"
            payloadkey="startDate"
            value={classDTOCreateAuction && classDTOCreateAuction.startDate}
            handleClassDTO={handleClassDTOCreateAuction}
            errorValue={
              classDTOCreateAuction && classDTOCreateAuction.startDateError
            }
          />

          <DateTime
            labelValue="End date and time*"
            payloadkey="endDate"
            value={classDTOCreateAuction && classDTOCreateAuction.endDate}
            handleClassDTO={handleClassDTOCreateAuction}
            errorValue={
              classDTOCreateAuction && classDTOCreateAuction.endDateError
            }
          />
        </div>

        <div class="NextPrev">
          <button
            class="btnNext"
            onClick={() =>
              handleButtonsCreateAuction("nextButton", "basicDetails")
            }
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
