import React, { Component } from "react";
import {
  BID_SUBMISSION_FOR_VALUES,
  DISPLAY_WINNING_BID_VALUES,
  ALLOW_DONT_ALLOW_VALUES,
  ANY_ALL_ITEM_VALUES,
  REQUIRED_NOT_REQUIRED_VALUES,
} from "../../../containers/Auction/CreateAuction/constants";
import TextBox from "./Components/TextBox";
import Select from "./Components/Select";

export default class ResultConfiguration extends Component {
  render() {
    const {
      handleClassDTOCreateAuction,
      classDTOCreateAuction,
      handleButtonsCreateAuction,
      getAllFieldsDetailsResponse,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="ResultConfiguration"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Result Configuration</h6>
          </div>

          {getAllFieldsDetailsResponse &&
            getAllFieldsDetailsResponse.map((data, index) => {
              if (72 == data.fieldId && data.isShown) {
                //Bid submission for
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="auctionResult"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.auctionResult) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={BID_SUBMISSION_FOR_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (73 == data.fieldId && data.isShown) {
                //Item wise L1 / H1
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="itemh1l1"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.itemh1l1) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (74 == data.fieldId && data.isShown) {
                //Display price bid break up link
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="breakPriceBid"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.breakPriceBid) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (75 == data.fieldId && data.isShown) {
                //Want to display notice in other subdomain?
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="dispnotice"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.dispnotice) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                78 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.auctionResult &&
                3 != classDTOCreateAuction.auctionResult
              ) {
                //Increment/Decreament in multiples
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="incDecInMultiple"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.incDecInMultiple) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                79 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.auctionResult &&
                3 == classDTOCreateAuction.auctionResult
              ) {
                //Increment/Decreament rules on
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="incDecRuleOn"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.incDecRuleOn) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={ANY_ALL_ITEM_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (80 == data.fieldId && data.isShown) {
                //Display winning bidder name to bidder
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="showWinnerName"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.showWinnerName) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                81 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.typeOfAuction &&
                1 == classDTOCreateAuction.typeOfAuction
              ) {
                //Display rank
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="showRank"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.showRank) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (82 == data.fieldId && data.isShown) {
                //Mask bidder name
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isBidderNameMasking"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isBidderNameMasking) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                83 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.showWinAmountOnListing &&
                1 == classDTOCreateAuction.showWinAmountOnListing
              ) {
                //Display winning bid
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="showWinningBid"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.showWinningBid) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={DISPLAY_WINNING_BID_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (374 == data.fieldId && data.isShown) {
                //Greater rank
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="greaterRank"
                    value={
                      classDTOCreateAuction && classDTOCreateAuction.greaterRank
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="number"
                  />
                );
              } else if (375 == data.fieldId && data.isShown) {
                //Display IP address during live auction
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="showIpAddress"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.showIpAddress) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (390 == data.fieldId && data.isShown) {
                //Evaluation required?
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isEvaluationReq"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isEvaluationReq) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                (457 == data.fieldId || 458 == data.fieldId) &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.auctionResult &&
                2 == classDTOCreateAuction.auctionResult
              ) {
                //Item selection required?
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isItemSelection"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isItemSelection) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (519 == data.fieldId && data.isShown) {
                //Hide live bidding to department user
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isHideLiveBidToOfficer"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isHideLiveBidToOfficer) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (874 == data.fieldId && data.isShown) {
                //Rest of Auction Money
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isRestOfAucMoneyRequired"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isRestOfAucMoneyRequired) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={REQUIRED_NOT_REQUIRED_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (875 == data.fieldId && data.isShown) {
                //Enable Result API
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isResultApiRequired"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isResultApiRequired) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (928 == data.fieldId && data.isShown) {
                //Display bidder’s actual name?
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isDisplaybidderRealName"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isDisplaybidderRealName) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                929 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.auctionResult &&
                3 == classDTOCreateAuction.auctionResult
              ) {
                //Display L1/H1 for Item wise & Grand Total wise
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isDisplayL1ItemWiseAndGTWise"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isDisplayL1ItemWiseAndGTWise) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={REQUIRED_NOT_REQUIRED_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (1124 == data.fieldId && data.isShown) {
                //No. of bid restriction
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="noOfBidRestriction"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.noOfBidRestriction) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={ALLOW_DONT_ALLOW_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                1125 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.auctionResult &&
                2 != classDTOCreateAuction.auctionResult
              ) {
                //No. of bids allowed
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="noOfBidAllowed"
                    value={
                      classDTOCreateAuction &&
                      classDTOCreateAuction.noOfBidAllowed
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="number"
                  />
                );
              } else if (1126 == data.fieldId && data.isShown) {
                //Result sharing for specific duration
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="resultSharingForSpecificDuration"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.resultSharingForSpecificDuration) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={ALLOW_DONT_ALLOW_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                1127 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.resultSharingForSpecificDuration &&
                1 == classDTOCreateAuction.resultSharingForSpecificDuration
              ) {
                //Result sharing duration
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="resultSharingDuration"
                    value={
                      classDTOCreateAuction &&
                      classDTOCreateAuction.resultSharingDuration
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="number"
                  />
                );
              } else if (1128 == data.fieldId && data.isShown) {
                //Share L1/H1 after auction
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="shareL1H1AfterAuc"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.shareL1H1AfterAuc) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={ALLOW_DONT_ALLOW_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                1129 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.shareL1H1AfterAuc &&
                1 == classDTOCreateAuction.shareL1H1AfterAuc
              ) {
                //Duration to display L1/H1 amount (Mins)
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="durationToDisplayL1H1"
                    value={
                      classDTOCreateAuction &&
                      classDTOCreateAuction.durationToDisplayL1H1
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="number"
                  />
                );
              }
            })}

          {classDTOCreateAuction &&
          classDTOCreateAuction.auctionResult &&
          1 == classDTOCreateAuction.auctionResult ? (
            <>
              <TextBox
                labelValue="Start price"
                payloadkey="startPrice"
                value={
                  classDTOCreateAuction && classDTOCreateAuction.startPrice
                }
                maxlength="15"
                handleClassDTO={handleClassDTOCreateAuction}
                textBoxType="number"
              />

              <TextBox
                labelValue="Reserve price amount"
                payloadkey="reservePrice"
                value={
                  classDTOCreateAuction && classDTOCreateAuction.reservePrice
                }
                maxlength="15"
                handleClassDTO={handleClassDTOCreateAuction}
                textBoxType="number"
              />

              <TextBox
                labelValue="Increment "
                payloadkey="incDecValue"
                value={
                  classDTOCreateAuction && classDTOCreateAuction.incDecValue
                }
                maxlength="15"
                handleClassDTO={handleClassDTOCreateAuction}
                textBoxType="number"
              />
            </>
          ) : (
            ""
          )}

          <>
            {classDTOCreateAuction &&
            classDTOCreateAuction.biddingPriceIncrementInTimes &&
            1 == classDTOCreateAuction.biddingPriceIncrementInTimes &&
            classDTOCreateAuction.auctionResult &&
            2 != classDTOCreateAuction.auctionResult ? (
              <TextBox
                labelValue="Required bidding price increment in times"
                payloadkey="incDecValue"
                value={
                  classDTOCreateAuction && classDTOCreateAuction.incDecValue
                }
                maxlength="15"
                handleClassDTO={handleClassDTOCreateAuction}
                textBoxType="number"
              />
            ) : (
              ""
            )}
          </>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsCreateAuction("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() =>
              handleButtonsCreateAuction("submit", "ResultConfiguration")
            }
          >
            Submit
          </button>
        </div>
      </div>
    );
  }
}
