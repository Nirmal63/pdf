import React, { Component } from "react";
import {
  TYPE_OF_CONTRACT_VALUES,
  NOT_REQUIRED_AUTO_MANUAL_VALUES,
  AUCTION_VARIANT_VALUES,
  BIDDING_FORM_VALUES,
  NOT_REQUIRED_EVENT_ITEM_WISE_VALUES,
  ALLOW_DONT_ALLOW_VALUES,
  BIDDING_TYPE_VALUES,
} from "../../../containers/Auction/CreateAuction/constants";
import TextBox from "./Components/TextBox";
import TextArea from "./Components/TextArea";
import Select from "./Components/Select";

export default class GeneralConfiguration extends Component {
  selectRecord = (event, element, key, filterKey, allData) => {
    let classDTOCreateAuction = JSON.parse(
      JSON.stringify(this.props.classDTOCreateAuction)
    );

    let tempObj = [];
    if (element) {
      let recordListObj = classDTOCreateAuction[key] || [];
      if (event.target.checked) {
        recordListObj.push(element);
      } else {
        recordListObj.splice(recordListObj.indexOf(element), 1);
      }
      if (recordListObj && recordListObj.length && recordListObj.length > 0) {
        for (let rec = 0; rec < recordListObj.length; rec++) {
          let data =
            allData &&
            allData.filter((data) => data[filterKey] == recordListObj[rec])[0];
          data.exchangeRate = 0;
          data.isDefault = 0;
          data.tblCurrency = data.currencyId;
          tempObj.push(data);
        }
      }
      this.props.handleClassDTOCreateAuction(key + 1, tempObj);
      this.props.handleClassDTOCreateAuction(key, recordListObj);
    } else {
      this.props.handleClassDTOCreateAuction(key + 1, []);
      this.props.handleClassDTOCreateAuction(key, []);
    }
  };

  handleChangeForExchangeRate = (value, id) => {
    let data =
      this.props.classDTOCreateAuction &&
      this.props.classDTOCreateAuction.currencyList1 &&
      this.props.classDTOCreateAuction.currencyList1.map((data, index) => {
        if (id != data.currencyId) return data;

        if (id == data.currencyId) {
          data.exchangeRate = value;
          return { ...data, exchangeRate: value };
        }
      });

    let currency =
      this.props.getAllCurrencyDetailsResponse &&
      this.props.getAllCurrencyDetailsResponse.map((data, index) => {
        if (id != data.currencyId) return data;

        if (id == data.currencyId) {
          data.exchangeRate = value;
          return { ...data, exchangeRate: value };
        }
      });

    this.props.updateGetAllCurrencyDetailsResponse(currency);
  };

  render() {
    const {
      handleClassDTOCreateAuction,
      classDTOCreateAuction,
      handleButtonsCreateAuction,
      getAllFieldsDetailsResponse,
      getAllCurrencyDetailsResponse,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="GeneralConfiguration"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">General Configuration</h6>
          </div>
          {getAllFieldsDetailsResponse &&
            getAllFieldsDetailsResponse.map((data, index) => {
              if (49 == data.fieldId && data.isShown) {
                //Type of contract
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="procurementNatureId"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.procurementNatureId) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={TYPE_OF_CONTRACT_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (50 == data.fieldId && data.isShown) {
                //Bidding access
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="auctionMode"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.auctionMode) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (51 == data.fieldId && data.isShown) {
                //Bidder wise form display
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="showBidderWiseForm"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.showBidderWiseForm) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (52 == data.fieldId && data.isShown) {
                //Bidding type
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="biddingType"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.biddingType) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={BIDDING_TYPE_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (53 == data.fieldId && data.isShown) {
                //Auction variant
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="eventTypeId"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.eventTypeId) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={AUCTION_VARIANT_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (54 == data.fieldId && data.isShown) {
                //Auction type
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="auctionType"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.auctionType) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (55 == data.fieldId && data.isShown) {
                //Document fees
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="documentFee"
                    value={
                      classDTOCreateAuction && classDTOCreateAuction.documentFee
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="text"
                  />
                );
              } else if (56 == data.fieldId && data.isShown) {
                // Participation/Processing fees
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="participationFee"
                    value={
                      classDTOCreateAuction &&
                      classDTOCreateAuction.participationFee
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="text"
                  />
                );
              } else if (285 == data.fieldId && data.isShown) {
                //No. Of Property
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="propertyCount"
                    value={
                      classDTOCreateAuction &&
                      classDTOCreateAuction.propertyCount
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="number"
                  />
                );
              } else if (338 == data.fieldId && data.isShown) {
                //Product location
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="productLocation"
                    value={
                      classDTOCreateAuction &&
                      classDTOCreateAuction.productLocation
                    }
                    maxlength="50"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="text"
                  />
                );
              } else if (339 == data.fieldId && data.isShown) {
                //Bidding form
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="biddingForm"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.biddingForm) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={BIDDING_FORM_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (343 == data.fieldId && data.isShown) {
                //Demo auction
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isDemoAuction"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isDemoAuction) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (346 == data.fieldId && data.isShown) {
                //brd mode
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="brdMode"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.brdMode) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={NOT_REQUIRED_AUTO_MANUAL_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (348 == data.fieldId && data.isShown) {
                //Negotiation
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isNegotiationAllowed"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isNegotiationAllowed) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={ALLOW_DONT_ALLOW_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (372 == data.fieldId && data.isShown) {
                //Display limited event on home page
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="forHomePage"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.forHomePage) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (382 == data.fieldId && data.isShown) {
                //Decode bidder name manually
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isDecodeBidder"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isDecodeBidder) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (393 == data.fieldId && data.isShown) {
                //Event wise registration charges applicable on
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isRegistrationCharges"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isRegistrationCharges) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={ALLOW_DONT_ALLOW_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (394 == data.fieldId && data.isShown) {
                //Participation/Processing fees Payment mode
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="registrationChargesMode"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.registrationChargesMode) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (459 == data.fieldId && data.isShown) {
                //EMD required?
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isEmdReq"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isEmdReq) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={NOT_REQUIRED_EVENT_ITEM_WISE_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (473 == data.fieldId && data.isShown) {
                //Bidding Capacity (in times)
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="biddingCapacity"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.biddingCapacity) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (475 == data.fieldId && data.isShown) {
                //Mode of EMD payment
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="emdPaymentMode"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.emdPaymentMode) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (477 == data.fieldId && data.isShown) {
                //EMD payable at
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="emdPayableAt"
                    value={
                      classDTOCreateAuction &&
                      classDTOCreateAuction.emdPayableAt
                    }
                    maxlength="1000"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="text"
                  />
                );
              } else if (490 == data.fieldId && data.isShown) {
                //Auction base currency
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="auctionCurrencyDtoSet"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.auctionCurrencyDtoSet) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={getAllCurrencyDetailsResponse}
                    optionKey="lang1"
                    optionValue="currencyId"
                    isValueAsData={true}
                  />
                );
              } else if (
                511 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.auctionResult &&
                2 == classDTOCreateAuction.auctionResult
              ) {
                //Requires check on minimum quantity
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isMinQtyReq"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isMinQtyReq) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (621 == data.fieldId && data.isShown) {
                //Bid capacity required
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isBidCapacityReq"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isBidCapacityReq) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (880 == data.fieldId && data.isShown) {
                //Budget
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="eventValue"
                    value={
                      classDTOCreateAuction && classDTOCreateAuction.eventValue
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="number"
                  />
                );
              } else if (983 == data.fieldId && data.isShown) {
                //Borrower name
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="borrowerName"
                    value={
                      classDTOCreateAuction &&
                      classDTOCreateAuction.borrowerName
                    }
                    maxlength="1000"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="text"
                  />
                );
              } else if (1028 == data.fieldId && data.isShown) {
                //Security Fees
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="securityFees"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.securityFees) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (1151 == data.fieldId && data.isShown) {
                //Upload reference document
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isUploadRefDocAllowed"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isUploadRefDocAllowed) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              }
            })}
          <TextArea
            labelValue="Product/service/work keywords*"
            payloadkey="keywordText"
            value={classDTOCreateAuction && classDTOCreateAuction.keywordText}
            maxlength="1000"
            handleClassDTO={handleClassDTOCreateAuction}
            errorValue={
              classDTOCreateAuction && classDTOCreateAuction.keywordTextError
            }
          />

          {classDTOCreateAuction &&
          classDTOCreateAuction.biddingType &&
          2 == classDTOCreateAuction.biddingType ? (
            <div class="col-12">
              <div class="CardBox">
                <h5 class="SmallTitle">
                  Bidding currencies and their exchange rate for base currency*
                </h5>
                <ul>
                  {getAllCurrencyDetailsResponse &&
                    getAllCurrencyDetailsResponse.map((data, index) => (
                      <li>
                        <div class="form-check">
                          <input
                            class="form-check-input"
                            type="checkbox"
                            name={data.currencyId}
                            value={data.currencyId}
                            id="agree2"
                            checked={
                              classDTOCreateAuction.defaultCurrency ==
                              data.currencyId
                                ? true
                                : classDTOCreateAuction &&
                                  classDTOCreateAuction.currencyList &&
                                  classDTOCreateAuction.currencyList.includes(
                                    data.currencyId
                                  )
                                ? true
                                : false
                            }
                            onChange={(event) => {
                              this.selectRecord(
                                event,
                                data.currencyId,
                                "currencyList",
                                "currencyId",
                                getAllCurrencyDetailsResponse
                              );
                            }}
                            disabled={
                              classDTOCreateAuction.defaultCurrency ==
                              data.currencyId
                                ? true
                                : false
                            }
                          />
                          <label class="form-check-label" for="agree2">
                            {data.lang1}
                          </label>
                          <input
                            type="number"
                            class="form-control"
                            name="exchangeRate"
                            maxlength="15"
                            onChange={(event) =>
                              this.handleChangeForExchangeRate(
                                event.target.value,
                                data.currencyId
                              )
                            }
                            value={data.exchangeRate}
                            disabled={
                              classDTOCreateAuction.defaultCurrency ==
                              data.currencyId
                                ? true
                                : false
                            }
                          />
                        </div>
                      </li>
                    ))}
                </ul>
              </div>
            </div>
          ) : (
            ""
          )}
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsCreateAuction("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() =>
              handleButtonsCreateAuction("nextButton", "generalConfiguration")
            }
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
