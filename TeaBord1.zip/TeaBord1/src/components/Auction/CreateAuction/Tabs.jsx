import React, { Component } from "react";

export default class Tabs extends Component {
  render() {
    return (
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li
          class="nav-item active"
          role="presentation"
          id="home-tab"
          data-bs-toggle="tab"
          data-bs-target="#BasicDetails"
          type="button"
          role="tab"
          aria-controls="home"
          aria-selected="true"
        >
          <button class="nav-link">Basic Details</button>
        </li>

        <li
          class="nav-item"
          role="presentation"
          id="profile-tab"
          data-bs-toggle="tab"
          data-bs-target="#GeneralConfiguration"
          type="button"
          role="tab"
          aria-controls="profile"
          aria-selected="false"
        >
          <button class="nav-link">General Configuration</button>
        </li>

        <li
          class="nav-item"
          role="presentation"
          id="contact-tab"
          data-bs-toggle="tab"
          data-bs-target="#TimeAutoExtensionConfiguration"
          type="button"
          role="tab"
          aria-controls="contact"
          aria-selected="false"
        >
          <button class="nav-link">Time Auto Extension Configuration</button>
        </li>

        <li
          class="nav-item"
          role="presentation"
          id="contact-tab"
          data-bs-toggle="tab"
          data-bs-target="#BidSubmissionConfiguration"
          type="button"
          role="tab"
          aria-controls="contact"
          aria-selected="false"
        >
          <button class="nav-link">Bid Submission Configuration</button>
        </li>

        <li
          class="nav-item"
          role="presentation"
          id="contact-tab"
          data-bs-toggle="tab"
          data-bs-target="#ResultConfiguration"
          type="button"
          role="tab"
          aria-controls="contact"
          aria-selected="false"
        >
          <button class="nav-link">Result Configuration</button>
        </li>
      </ul>
    );
  }
}
