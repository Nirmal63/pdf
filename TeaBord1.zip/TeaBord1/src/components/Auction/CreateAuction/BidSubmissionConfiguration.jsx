import React, { Component } from "react";
import {
  ACCEPT_DECIMAL_VALUES_UPTO_VALUES,
  FIRST_BID_ACCEPT_CONDITION_VALUES,
  ACCEPT_DONT_ACCEPT_SAME_AMOUNT_VALUES,
  ALLOW_DONT_ALLOW_VALUES,
} from "../../../containers/Auction/CreateAuction/constants";
import Select from "./Components/Select";

export default class BidSubmissionConfiguration extends Component {
  render() {
    const {
      handleClassDTOCreateAuction,
      classDTOCreateAuction,
      handleButtonsCreateAuction,
      getAllFieldsDetailsResponse,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="BidSubmissionConfiguration"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Bid Submission Configuration</h6>
          </div>

          {getAllFieldsDetailsResponse &&
            getAllFieldsDetailsResponse.map((data, index) => {
              if (
                62 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.auctionResult &&
                3 != classDTOCreateAuction.auctionResult
              ) {
                //Bidding price increment in
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="incDecType"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.incDecType) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                63 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.auctionResult &&
                3 != classDTOCreateAuction.auctionResult
              ) {
                //Reserve price check require
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="checkReservePrice"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.checkReservePrice) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (64 == data.fieldId && data.isShown) {
                //Display L1/H1 amount
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="showWinAmountOnListing"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.showWinAmountOnListing) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                65 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.auctionResult &&
                2 == classDTOCreateAuction.auctionResult
              ) {
                //Line item wise bid submission time allowed?
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isItemWiseTime"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isItemWiseTime) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (66 == data.fieldId && data.isShown) {
                //Auto bid allowed?
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isAutoBidAllowed"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isAutoBidAllowed) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (67 == data.fieldId && data.isShown) {
                //Display bidder name encoding to officer
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isEncodedName"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isEncodedName) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (68 == data.fieldId && data.isShown) {
                //Accept decimal value upto
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="decimalValueUpto"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.decimalValueUpto) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={ACCEPT_DECIMAL_VALUES_UPTO_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (69 == data.fieldId && data.isShown) {
                //First bid acceptance condition
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="firstBidCond"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.firstBidCond) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={FIRST_BID_ACCEPT_CONDITION_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (70 == data.fieldId && data.isShown) {
                //Display last accepted bid to bidder
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="showLastBid"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.showLastBid) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (71 == data.fieldId && data.isShown) {
                //Increment in certain period
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isIncDecInPeriod"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isIncDecInPeriod) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (77 == data.fieldId && data.isShown) {
                //Bidder wise start price require
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isBidderWiseStartPrice"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isBidderWiseStartPrice) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (378 == data.fieldId && data.isShown) {
                //Allow mobile bidding
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isMobABAllow"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isMobABAllow) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                489 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.auctionResult &&
                2 != classDTOCreateAuction.auctionResult
              ) {
                //Display L1/H1 amount in live auction listing
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="showWinAmountOnListing"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.showWinAmountOnListing) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (518 == data.fieldId && data.isShown) {
                //Require bidding price increment in times
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="biddingPriceIncrementInTimes"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.biddingPriceIncrementInTimes) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (633 == data.fieldId && data.isShown) {
                //Restrict bidder on H1
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isRestrictH1Bidder"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isRestrictH1Bidder) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (934 == data.fieldId && data.isShown) {
                //Display reserve price to bidders
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isShowReservePriceToBidder"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isShowReservePriceToBidder) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (1110 == data.fieldId && data.isShown) {
                //Rank Logic
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="rankLogic"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.rankLogic) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={ACCEPT_DONT_ACCEPT_SAME_AMOUNT_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (1148 == data.fieldId && data.isShown) {
                //Event wise Regret
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isEventwiseRegretAllowed"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isEventwiseRegretAllowed) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={ALLOW_DONT_ALLOW_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (1188 == data.fieldId && data.isShown) {
                //Restrict bidder on H1/L1 and EMD
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isRestrictBidderOnl1h1"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isRestrictBidderOnl1h1) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              }
            })}
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsCreateAuction("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() =>
              handleButtonsCreateAuction(
                "nextButton",
                "bidSubmissionConfiguration"
              )
            }
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
