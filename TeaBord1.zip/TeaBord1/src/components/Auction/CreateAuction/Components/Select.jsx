import React, { Component } from "react";

export default class Select extends Component {
  render() {
    const {
      handleClassDTO,
      labelValue,
      payloadkey,
      value,
      errorValue,
      data,
      disabled,
      optionKey,
      optionValue,
      isValueAsData,
      selectValueOptionAvailable,
      selectValueOptionLabel,
    } = this.props;

    return (
      <div class="col-xl-3 col-lg-4 col-md-6 col-12">
        <label class="LabelText">{labelValue}</label>
        <select
          class="form-select"
          aria-label="Default select example"
          name={payloadkey}
          value={value}
          onChange={(event) =>
            handleClassDTO(event.target.name, event.target.value)
          }
          disabled={disabled}
        >
          {selectValueOptionAvailable ? (
            <option value="">{selectValueOptionLabel}</option>
          ) : (
            ""
          )}

          {data &&
            data.map((innerData, index) => (
              <option
                value={
                  isValueAsData
                    ? JSON.stringify(innerData)
                    : innerData[optionValue]
                }
              >
                {innerData[optionKey]}
              </option>
            ))}
        </select>

        {errorValue ? <label className="error">{errorValue}</label> : ""}
      </div>
    );
  }
}
