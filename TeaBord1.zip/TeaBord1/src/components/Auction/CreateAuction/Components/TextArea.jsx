import React, { Component } from "react";

export default class TextArea extends Component {
  render() {
    const {
      handleClassDTO,
      labelValue,
      payloadkey,
      maxlength,
      value,
      errorValue,
    } = this.props;

    return (
      <div class="col-12">
        <label class="LabelText">{labelValue}</label>
        <textarea
          class="form-control"
          id="exampleFormControlTextarea1"
          name={payloadkey}
          maxlength={maxlength}
          onChange={(event) =>
            handleClassDTO(event.target.name, event.target.value)
          }
          value={value}
        ></textarea>
        {errorValue ? <label className="error">{errorValue}</label> : ""}
      </div>
    );
  }
}
