import React, { Component } from "react";

export default class DateTime extends Component {
  render() {
    const { handleClassDTO, labelValue, payloadkey, value, errorValue } =
      this.props;

    return (
      <div class="col-xl-3 col-lg-4 col-md-6 col-12">
        <label class="LabelText">{labelValue}</label>
        <input
          type="datetime-local"
          class="form-control"
          name={payloadkey}
          onChange={(event) => {
            handleClassDTO(event.target.name, event.target.value);
          }}
          value={value}
          id="datetimepicker"
        />
        {errorValue ? <label className="error">{errorValue}</label> : ""}
      </div>
    );
  }
}
