import React, { Component } from "react";

export default class TextBox extends Component {
  render() {
    const {
      handleClassDTO,
      labelValue,
      payloadkey,
      maxlength,
      value,
      errorValue,
      type,
    } = this.props;

    return (
      <div class="col-xl-3 col-lg-4 col-md-6 col-12">
        <label class="LabelText">{labelValue}</label>
        <input
          type={type}
          class="form-control"
          name={payloadkey}
          maxlength={maxlength}
          onChange={(event) =>
            handleClassDTO(event.target.name, event.target.value)
          }
          value={value}
        />
        {errorValue ? <label className="error">{errorValue}</label> : ""}
      </div>
    );
  }
}
