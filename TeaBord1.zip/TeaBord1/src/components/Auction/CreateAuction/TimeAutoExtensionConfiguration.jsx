import React, { Component } from "react";
import { AUTO_EXTENSION_MODE_VALUES } from "../../../containers/Auction/CreateAuction/constants";
import TextBox from "./Components/TextBox";
import Select from "./Components/Select";

export default class TimeAutoExtensionConfiguration extends Component {
  render() {
    const {
      handleClassDTOCreateAuction,
      classDTOCreateAuction,
      handleButtonsCreateAuction,
      getAllFieldsDetailsResponse,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="TimeAutoExtensionConfiguration"
        role="tabpanel"
        aria-labelledby="contact-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Time Auto Extension Configuration</h6>
          </div>

          {getAllFieldsDetailsResponse &&
            getAllFieldsDetailsResponse.map((data, index) => {
              if (57 == data.fieldId && data.isShown) {
                //Allowed auto extension?
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="isAutoExt"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.isAutoExt) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (
                58 == data.fieldId &&
                data.isShown &&
                classDTOCreateAuction &&
                classDTOCreateAuction.isAutoExt &&
                1 == classDTOCreateAuction.isAutoExt
              ) {
                //Auto extension mode
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="extMode"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.extMode) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={AUTO_EXTENSION_MODE_VALUES}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (59 == data.fieldId && data.isShown) {
                //Extend time when valid bid received in last(In Minutes)
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="extendWhen"
                    value={
                      classDTOCreateAuction && classDTOCreateAuction.extendWhen
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="number"
                  />
                );
              } else if (60 == data.fieldId && data.isShown) {
                //No. of extension
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="totalExt"
                    value={
                      classDTOCreateAuction && classDTOCreateAuction.totalExt
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="number"
                  />
                );
              } else if (61 == data.fieldId && data.isShown) {
                //Extend time by(In Minutes)*
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="extendBy"
                    value={
                      classDTOCreateAuction && classDTOCreateAuction.extendBy
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="number"
                  />
                );
              } else if (76 == data.fieldId && data.isShown) {
                //Extension applicable on rank
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="rankForExt"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.rankForExt) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (322 == data.fieldId && data.isShown) {
                //Bid submission mode
                return (
                  <Select
                    labelValue={data.fieldLabel}
                    payloadkey="configureTimeForItem"
                    value={
                      (classDTOCreateAuction &&
                        classDTOCreateAuction.configureTimeForItem) ||
                      ""
                    }
                    handleClassDTO={handleClassDTOCreateAuction}
                    data={data.controlValueDTOList}
                    optionKey="displayKey"
                    optionValue="value"
                  />
                );
              } else if (323 == data.fieldId && data.isShown) {
                //Time Interval (In Mins)
                return (
                  <TextBox
                    labelValue={data.fieldLabel}
                    payloadkey="itemDuration"
                    value={
                      classDTOCreateAuction &&
                      classDTOCreateAuction.itemDuration
                    }
                    maxlength="15"
                    handleClassDTO={handleClassDTOCreateAuction}
                    textBoxType="number"
                  />
                );
              }
            })}
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsCreateAuction("prevButton", "")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() =>
              handleButtonsCreateAuction(
                "nextButton",
                "timeAutoExtensionConfiguration"
              )
            }
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
