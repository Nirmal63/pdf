import React, { Component } from "react";
import AuctionDetails from "./AuctionDetails";
import Tabs from "./Tabs";
import TabData from "./TabData";
import BiddingForm from "./BiddingForm";
import ConfigureParameters from "./ConfigureParameters";

export default class AuctionDashboard extends Component {
  render() {
    console.log(
      "getEventDetailsBySubModuleIdResponse",
      this.props.getEventDetailsBySubModuleIdResponse
    );
    return (
      <>
        <h2 class="Title">Auction Dashboard</h2>
        <div class="CreateClient ShadowBox Manageclients">
          <AuctionDetails {...this.props} />

          <Tabs {...this.props} />

          <div class="tab-content" id="myTabContent">
            <TabData {...this.props} />
            {/* <BiddingForm {...this.props} />
            <ConfigureParameters {...this.props} /> */}
          </div>
        </div>
      </>
    );
  }
}
