import React, { Component } from "react";

export default class ConfigureParameters extends Component {
  render() {
    const {
      handleButtonsAuctionDashboard,
      handleClassDTOAuctionDashboard,
      classDTOAuctionDashboard,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="ConfigureParameters"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <div class="row g-3">
          <div
            class="col-12 textDecoration"
            data-bs-toggle="modal"
            data-bs-target="#configureparameterModal"
          >
            Upload document for Configure Parameter
          </div>
        </div>

        <div class="modal" id="configureparameterModal">
          <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
              <div class="modal-header">
                <h4 class="modal-title">Upload Document</h4>
                <button
                  type="button"
                  class="btn-close"
                  data-bs-dismiss="modal"
                ></button>
              </div>

              <div class="modal-body">
                <div class="row g-3">
                  <div class="col-12">
                    <input
                      type="file"
                      class="form-control"
                      id="customFile"
                      onChange={(event) => {
                        handleClassDTOAuctionDashboard("fileName", event);
                      }}
                    />

                    {classDTOAuctionDashboard &&
                    classDTOAuctionDashboard.fileNameError ? (
                      <label className="error">
                        {classDTOAuctionDashboard.fileNameError}
                      </label>
                    ) : (
                      ""
                    )}
                  </div>
                  <div class="NextPrev mb-3">
                    <button
                      class="btnNext"
                      onClick={() =>
                        handleButtonsAuctionDashboard(
                          "submitConfigureParameters"
                        )
                      }
                    >
                      Submit
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
