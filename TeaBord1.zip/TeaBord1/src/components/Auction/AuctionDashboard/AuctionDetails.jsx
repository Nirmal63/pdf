import React, { Component } from "react";
import $ from "jquery";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";

export default class AuctionDetails extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isCollapsed: true,
    };
  }

  componentDidMount() {}

  buttonClick = () => {
    this.state.isCollapsed = !this.state.isCollapsed;

    if (this.state.isCollapsed) {
      //  if (
      //    !isNullOrIsEmptyOrIsUndefined(
      //      localStorage.getItem("auctionIdForAuctionDashboard")
      //    )
      //  ) {
      //    let decodeData = Buffer.from(
      //      localStorage.getItem("auctionIdForAuctionDashboard"),
      //      "base64"
      //    ).toString("ascii");

      //    let data = {
      //      auctionId: decodeData,
      //    };
      //    this.props.getAuctionSummaryDetails(data);
      //  }
      $("#accordionSummaryBody").addClass("show");
      $("#accordionSummaryButton").removeClass("collapsed");
    } else {
      $("#accordionSummaryBody").removeClass("show");
      $("#accordionSummaryButton").addClass("collapsed");
    }
  };
  render() {
    let { getAuctionSummaryDetailsResponse } = this.props;

    return (
      <>
        <div class="row">
          <div class="accordion" id="accordionAuctionDetails">
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingAuctiondetails">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#collapseThree"
                  aria-expanded="false"
                  aria-controls="collapseThree"
                  onClick={() => {
                    this.buttonClick();
                  }}
                  id="accordionSummaryButton"
                >
                  Auction Details
                </button>
              </h2>
              <div
                // id={this.state.isCollapsed ? "collapseThree" : ""}
                id="collapseThree"
                // id="accordionSummaryBody"
                class="accordion-collapse collapse show"
                aria-labelledby="headingAuctiondetails"
                data-bs-parent="#accordionAuctionDetails"
              >
                <div class="accordion-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="TableBox AuctionSummary">
                        <table class="table table-striped">
                          <tbody>
                            <tr>
                              <td width="25%">Auction ID</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.auctionId}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Auction brief</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.auctionBrief}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Department</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.departmentName}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Start date and time</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.startDate}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Auction variant</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.eventTypeId &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.eventTypeId
                                  ? "Forward Auction"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.eventTypeId &&
                                    2 ==
                                      getAuctionSummaryDetailsResponse.eventTypeId
                                  ? "Reverse Auction"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Digital certificate required</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.isPkiEnabled &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.isPkiEnabled
                                  ? "Yes"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.isPkiEnabled &&
                                    0 ==
                                      getAuctionSummaryDetailsResponse.isPkiEnabled
                                  ? "No"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.isPkiEnabled &&
                                    2 ==
                                      getAuctionSummaryDetailsResponse.isPkiEnabled
                                  ? "Event Specific"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Bidding type</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.biddingType &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.biddingType
                                  ? "NCB/Domestic"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.biddingType &&
                                    2 ==
                                      getAuctionSummaryDetailsResponse.biddingType
                                  ? "ICB/Global"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">
                                Line item wise bid submission time allowed?
                              </td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.isItemWiseTime &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.isItemWiseTime
                                  ? "Yes"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.isItemWiseTime &&
                                    0 ==
                                      getAuctionSummaryDetailsResponse.isItemWiseTime
                                  ? "No"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Auto extension mode</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.extMode &&
                                1 == getAuctionSummaryDetailsResponse.extMode
                                  ? "Limited extensions"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.extMode &&
                                    2 ==
                                      getAuctionSummaryDetailsResponse.extMode
                                  ? "Unlimited extensions"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Extend time by(in minutes)</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.extendBy}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Bidding price increment in</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.incDecInMultiple &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.incDecInMultiple
                                  ? "Yes"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.incDecInMultiple &&
                                    0 ==
                                      getAuctionSummaryDetailsResponse.incDecInMultiple
                                  ? "No"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">
                                First bid acceptance condition
                              </td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.firstBidCond &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.firstBidCond
                                  ? "Accept Start Price"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.firstBidCond &&
                                    2 ==
                                      getAuctionSummaryDetailsResponse.firstBidCond
                                  ? "Accept Start Price + Increment/Decrement Value"
                                  : ""}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="TableBox AuctionSummary">
                        <table class="table table-striped">
                          <tbody>
                            <tr>
                              <td width="25%">Auction No.</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.auctionNo}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">{} </td>
                              <td width="1%">{}</td>
                              <td>{}</td>
                            </tr>

                            <tr>
                              <td width="25%">Officer</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.officerName}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">End date and time</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.endDate}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Auction type</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.auctionType &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.auctionType
                                  ? "Standrad"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.auctionType &&
                                    2 ==
                                      getAuctionSummaryDetailsResponse.auctionType
                                  ? "Rank"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Auction base currency</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.currency}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Bid submission for</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.auctionResult &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.auctionResult
                                  ? "Grandtotal"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.auctionResult &&
                                    2 ==
                                      getAuctionSummaryDetailsResponse.auctionResult
                                  ? "Itemwise"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.auctionResult &&
                                    2 ==
                                      getAuctionSummaryDetailsResponse.auctionResult
                                  ? "Grandtotal and Itemwise"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Allowed auto extension?</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.isAutoExt &&
                                1 == getAuctionSummaryDetailsResponse.isAutoExt
                                  ? "Yes"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.isAutoExt &&
                                    0 ==
                                      getAuctionSummaryDetailsResponse.isAutoExt
                                  ? "No"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">
                                Extend time when valid bid received in last(in
                                minutes){" "}
                              </td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.extendWhen}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Bidding access</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.auctionMode &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.auctionMode
                                  ? "Open"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.auctionMode &&
                                    2 ==
                                      getAuctionSummaryDetailsResponse.auctionMode
                                  ? "Limited"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Increment in multiples</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.incDecType &&
                                1 == getAuctionSummaryDetailsResponse.incDecType
                                  ? "Figure"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.incDecType &&
                                    2 ==
                                      getAuctionSummaryDetailsResponse.incDecType
                                  ? "Percentage"
                                  : ""}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">
                                Require bidding price increment in times
                              </td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.biddingPriceIncrementInTimes &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.biddingPriceIncrementInTimes
                                  ? "Yes"
                                  : getAuctionSummaryDetailsResponse &&
                                    getAuctionSummaryDetailsResponse.biddingPriceIncrementInTimes &&
                                    0 ==
                                      getAuctionSummaryDetailsResponse.biddingPriceIncrementInTimes
                                  ? "No"
                                  : ""}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
