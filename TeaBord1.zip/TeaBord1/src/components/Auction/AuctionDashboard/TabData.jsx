import React, { Component } from "react";

export default class BiddingForm extends Component {
  render() {
    const {
      handleButtonsAuctionDashboard,
      handleClassDTOAuctionDashboard,
      classDTOAuctionDashboard,
      getEventDetailsBySubModuleIdResponse,
    } = this.props;

    return (
      <div
        class="tab-pane fade show active"
        id="BiddingForm"
        role="tabpanel"
        aria-labelledby="home-tab"
      >
        <div class="row g-3">
          <div
            class="col-12 textDecoration"
            data-bs-toggle="modal"
            data-bs-target="#biddingFormModal"
          >
            <div class="TableBox">
              <table class="table">
                <tbody>
                  {" "}
                  {getEventDetailsBySubModuleIdResponse &&
                    getEventDetailsBySubModuleIdResponse.map((data, index) => (
                      <tr>
                        <td width={"20%"}>{data.eventName}</td>
                        <td width={"80%"}>
                          {data &&
                            data.auctionLinkDTOS &&
                            data.auctionLinkDTOS.map(
                              (auctionLinkDTOData, auctionLinkDTOIndex) => (
                                <>
                                  {auctionLinkDTOIndex > 0
                                    ? "          |          "
                                    : ""}
                                  <a>{auctionLinkDTOData.linkName}</a>
                                  {/* <p> </p> */}
                                </>
                              )
                            )}
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
