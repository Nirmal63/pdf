import React, { Component } from "react";

export default class List extends Component {
  tabButtonClick = (subModuleId) => {
    let data = {
      subModuleId: subModuleId,
    };
    this.props.getEventDetailsBySubModuleId(data);
  };

  render() {
    return (
      <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        {this.props.getAuctionSubModulesDetailsResponse &&
          this.props.getAuctionSubModulesDetailsResponse.map((data, index) => (
            <li
              class={index == 0 ? "nav-item active" : "nav-item"}
              role="presentation"
              id="home-tab"
              data-bs-toggle="tab"
              data-bs-target="#BiddingForm"
              type="button"
              role="tab"
              aria-controls="home"
              aria-selected="true"
            >
              <button
                class="nav-link"
                onClick={() => {
                  this.tabButtonClick(data.subModuleId);
                }}
              >
                {data.lang1}
              </button>
            </li>
          ))}
      </ul>
    );
  }
}
