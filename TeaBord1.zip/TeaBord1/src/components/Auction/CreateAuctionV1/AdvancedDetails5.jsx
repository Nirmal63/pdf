import React, { Component } from "react";

export default class AdvanceDetails5 extends Component {
  render() {
    return (
      <div
        class="tab-pane fade"
        id="AdvanceDetails5"
        role="tabpanel"
        aria-labelledby="contact-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Advance Details 5</h6>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <select class="form-select">
              <option selected>Hide live bidding to department user</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </select>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <input
              type="text"
              class="form-control"
              name=""
              placeholder="Borrower Name"
            />
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <select class="form-select">
              <option selected>Upload Reference Document</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </select>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <select class="form-select">
              <option selected>Rank Logic</option>
              <option value="1">One</option>
              <option value="2">Two</option>
              <option value="3">Three</option>
            </select>
          </div>
          <button class="BlueButton m-auto mt-5">Submit</button>
        </div>
      </div>
    );
  }
}
