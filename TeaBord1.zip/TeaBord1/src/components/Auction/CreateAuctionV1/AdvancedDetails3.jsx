import React, { Component } from "react";
import {
  YES_NO_VALUES,
  AUTO_EXTENSION_MODE_VALUES,
  FIRST_BID_ACCEPT_CONDITION_VALUES,
  ACCEPT_DECIMAL_VALUES_UPTO_VALUES,
  DISPLAY_WINNING_BID_VALUES,
} from "../../../containers/Auction/CreateAuctionV1/constants";

export default class AdvanceDetails3 extends Component {
  render() {
    const {
      handleClassDTOCreateAuction,
      classDTOCreateAuction,
      handleButtonsCreateAuction,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="AdvanceDetails3"
        role="tabpanel"
        aria-labelledby="contact-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Advance Details 3</h6>
          </div>

          <div class="row">
            <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
              <label class="LabelText">Start Date and Time*</label>
              <input
                type="date"
                name="startDate"
                class="form-control"
                onChange={(event) =>
                  handleClassDTOCreateAuction(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTOCreateAuction && classDTOCreateAuction.startDate}
              />
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
              <label class="LabelText">End Date and Time*</label>
              <input
                type="date"
                name="endDate"
                class="form-control"
                onChange={(event) =>
                  handleClassDTOCreateAuction(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTOCreateAuction && classDTOCreateAuction.endDate}
              />
            </div>

            {classDTOCreateAuction &&
            classDTOCreateAuction.isIncDecInPeriod &&
            1 == classDTOCreateAuction.isIncDecInPeriod ? (
              <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
                <label class="LabelText">Increment amount after*</label>
                <input
                  type="date"
                  name="timeForIncDecToItem"
                  class="form-control"
                  onChange={(event) =>
                    handleClassDTOCreateAuction(
                      event.target.name,
                      event.target.value
                    )
                  }
                  value={
                    classDTOCreateAuction &&
                    classDTOCreateAuction.timeForIncDecToItem
                  }
                />
              </div>
            ) : (
              ""
            )}

            <div class="col-xl-auto col-lg-6 col-md-6 col-12 mt-3">
              <h5 class="SmallTitle">Allowed auto extension?</h5>
              <div class="RadioGroup">
                {YES_NO_VALUES &&
                  YES_NO_VALUES.map((data, index) => (
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        type="radio"
                        name="Allowedautoextenstion"
                        id="Allowedautoextenstion-Yes"
                        value={data.value}
                        checked={
                          classDTOCreateAuction &&
                          classDTOCreateAuction.isAutoExt &&
                          classDTOCreateAuction.isAutoExt == data.value
                            ? true
                            : false
                        }
                        onChange={(event) =>
                          handleClassDTOCreateAuction(
                            "isAutoExt",
                            parseInt(event.target.value)
                          )
                        }
                      />
                      <label
                        class="form-check-label"
                        for="Allowedautoextenstion-Yes"
                      >
                        {data.displayKey}
                      </label>
                    </div>
                  ))}
              </div>
            </div>

            {classDTOCreateAuction &&
            classDTOCreateAuction.isAutoExt &&
            1 == classDTOCreateAuction.isAutoExt ? (
              <>
                <div class="col-xl-auto col-lg-6 col-md-6 col-12 mt-3">
                  <h5 class="SmallTitle">Auto extenstion mode</h5>
                  <div class="RadioGroup">
                    {AUTO_EXTENSION_MODE_VALUES &&
                      AUTO_EXTENSION_MODE_VALUES.map((data, index) => (
                        <div class="form-check">
                          <input
                            class="form-check-input"
                            type="radio"
                            name="Autoextenstionmode"
                            id="LimitedExtension"
                            value={data.value}
                            checked={
                              classDTOCreateAuction &&
                              classDTOCreateAuction.extMode &&
                              classDTOCreateAuction.extMode == data.value
                                ? true
                                : false
                            }
                            onChange={(event) =>
                              handleClassDTOCreateAuction(
                                "extMode",
                                parseInt(event.target.value)
                              )
                            }
                          />
                          <label
                            class="form-check-label"
                            for="LimitedExtension"
                          >
                            {data.displayKey}
                          </label>
                        </div>
                      ))}
                  </div>
                </div>

                <div class="col-xl-4 col-lg-6 col-md-6 col-12 mt-3">
                  <label class="LabelText">
                    Extend time when valid bid received in last(In Minutes)*
                  </label>
                  <input
                    type="number"
                    name="extendWhen"
                    class="form-control"
                    maxlength="15"
                    onChange={(event) =>
                      handleClassDTOCreateAuction(
                        event.target.name,
                        event.target.value
                      )
                    }
                    value={
                      classDTOCreateAuction && classDTOCreateAuction.extendWhen
                    }
                  />
                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
                  <label class="LabelText">Extend time by(In Minutes)*</label>
                  <input
                    type="number"
                    name="extendBy"
                    class="form-control"
                    maxlength="15"
                    onChange={(event) =>
                      handleClassDTOCreateAuction(
                        event.target.name,
                        event.target.value
                      )
                    }
                    value={
                      classDTOCreateAuction && classDTOCreateAuction.extendBy
                    }
                  />
                </div>
              </>
            ) : (
              ""
            )}

            <div class="col-xl-auto col-lg-6 col-md-6 col-12 mt-3">
              <h5 class="SmallTitle">First bid acceptance condition</h5>
              <div class="RadioGroup">
                {FIRST_BID_ACCEPT_CONDITION_VALUES &&
                  FIRST_BID_ACCEPT_CONDITION_VALUES.map((data, index) => (
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        type="radio"
                        name="Firstbidacceptancecondition"
                        id="Firstbidacceptancecondition-Yes"
                        value={data.value}
                        checked={
                          classDTOCreateAuction &&
                          classDTOCreateAuction.firstBidCond &&
                          classDTOCreateAuction.firstBidCond == data.value
                            ? true
                            : false
                        }
                        onChange={(event) =>
                          handleClassDTOCreateAuction(
                            "firstBidCond",
                            parseInt(event.target.value)
                          )
                        }
                      />
                      <label
                        class="form-check-label"
                        for="Firstbidacceptancecondition-Yes"
                      >
                        {data.displayKey}
                      </label>
                    </div>
                  ))}
              </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
              <label class="LabelText">Accept decimal value upto*</label>
              <select
                class="form-select"
                name="decimalValueUpto"
                value={
                  (classDTOCreateAuction &&
                    classDTOCreateAuction.decimalValueUpto) ||
                  ""
                }
                onChange={(event) =>
                  handleClassDTOCreateAuction(
                    event.target.name,
                    event.target.value
                  )
                }
              >
                {ACCEPT_DECIMAL_VALUES_UPTO_VALUES &&
                  ACCEPT_DECIMAL_VALUES_UPTO_VALUES.map((data, index) => (
                    <option value={data.value}>{data.displayKey}</option>
                  ))}
              </select>
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
              <h5 class="SmallTitle">Display L1/H1 amount</h5>
              <div class="RadioGroup">
                {YES_NO_VALUES &&
                  YES_NO_VALUES.map((data, index) => (
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        type="radio"
                        name="Displayl1h1amount"
                        id="Displayl1h1amount-Yes"
                        value={data.value}
                        checked={
                          classDTOCreateAuction &&
                          classDTOCreateAuction.showWinAmountOnListing &&
                          classDTOCreateAuction.showWinAmountOnListing ==
                            data.value
                            ? true
                            : false
                        }
                        onChange={(event) =>
                          handleClassDTOCreateAuction(
                            "showWinAmountOnListing",
                            parseInt(event.target.value)
                          )
                        }
                      />
                      <label
                        class="form-check-label"
                        for="Displayl1h1amount-Yes"
                      >
                        {data.displayKey}
                      </label>
                    </div>
                  ))}
              </div>
            </div>

            {classDTOCreateAuction &&
            classDTOCreateAuction.showWinAmountOnListing &&
            1 == classDTOCreateAuction.showWinAmountOnListing ? (
              <>
                <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
                  <h5 class="SmallTitle">Display winning bid</h5>
                  <div class="RadioGroup">
                    {DISPLAY_WINNING_BID_VALUES &&
                      DISPLAY_WINNING_BID_VALUES.map((data, index) => (
                        <div class="form-check">
                          <input
                            class="form-check-input"
                            type="radio"
                            name="Displaywinningbid"
                            id="Displaywinningbid-Yes"
                            value={data.value}
                            checked={
                              classDTOCreateAuction &&
                              classDTOCreateAuction.showWinningBid &&
                              classDTOCreateAuction.showWinningBid == data.value
                                ? true
                                : false
                            }
                            onChange={(event) =>
                              handleClassDTOCreateAuction(
                                "showWinningBid",
                                parseInt(event.target.value)
                              )
                            }
                          />
                          <label
                            class="form-check-label"
                            for="Displaywinningbid-Yes"
                          >
                            {data.displayKey}
                          </label>
                        </div>
                      ))}
                  </div>
                </div>

                <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
                  <h5 class="SmallTitle">
                    Display winning bidder name to bidder
                  </h5>
                  <div class="RadioGroup">
                    {YES_NO_VALUES &&
                      YES_NO_VALUES.map((data, index) => (
                        <div class="form-check">
                          <input
                            class="form-check-input"
                            type="radio"
                            name="Displaywinningbiddernametobidder"
                            id="Displaywinningbiddernametobidder-Yes"
                            value={data.value}
                            checked={
                              classDTOCreateAuction &&
                              classDTOCreateAuction.showWinnerName &&
                              classDTOCreateAuction.showWinnerName == data.value
                                ? true
                                : false
                            }
                            onChange={(event) =>
                              handleClassDTOCreateAuction(
                                "showWinnerName",
                                parseInt(event.target.value)
                              )
                            }
                          />
                          <label
                            class="form-check-label"
                            for="Displaywinningbiddernametobidder-Yes"
                          >
                            {data.displayKey}
                          </label>
                        </div>
                      ))}
                  </div>
                </div>
              </>
            ) : (
              ""
            )}

            <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
              <h5 class="SmallTitle">Display last accepted bid to bidder</h5>
              <div class="RadioGroup">
                {YES_NO_VALUES &&
                  YES_NO_VALUES.map((data, index) => (
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        type="radio"
                        name="Displaylastacceptedbidtobidder"
                        id="Displaylastacceptedbidtobidder-Yes"
                        value={data.value}
                        checked={
                          classDTOCreateAuction &&
                          classDTOCreateAuction.showLastBid &&
                          classDTOCreateAuction.showLastBid == data.value
                            ? true
                            : false
                        }
                        onChange={(event) =>
                          handleClassDTOCreateAuction(
                            "showLastBid",
                            parseInt(event.target.value)
                          )
                        }
                      />
                      <label
                        class="form-check-label"
                        for="Displaylastacceptedbidtobidder-Yes"
                      >
                        {data.displayKey}
                      </label>
                    </div>
                  ))}
              </div>
            </div>
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsCreateAuction("prevButton")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() => handleButtonsCreateAuction("nextButton")}
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
