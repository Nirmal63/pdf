import React, { Component } from "react";

export default class Tabs extends Component {
  render() {
    return (
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li
          class="nav-item active"
          role="presentation"
          id="home-tab"
          data-bs-toggle="tab"
          data-bs-target="#BasicDetails"
          type="button"
          role="tab"
          aria-controls="home"
          aria-selected="true"
        >
          <button class="nav-link">Basic Details</button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="profile-tab"
          data-bs-toggle="tab"
          data-bs-target="#AdvanceDetails1"
          type="button"
          role="tab"
          aria-controls="profile"
          aria-selected="false"
        >
          <button class="nav-link">Advance Details 1</button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="contact-tab"
          data-bs-toggle="tab"
          data-bs-target="#AdvanceDetails2"
          type="button"
          role="tab"
          aria-controls="contact"
          aria-selected="false"
        >
          <button class="nav-link">Advance Details 2</button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="contact-tab"
          data-bs-toggle="tab"
          data-bs-target="#AdvanceDetails3"
          type="button"
          role="tab"
          aria-controls="contact"
          aria-selected="false"
        >
          <button class="nav-link">Advance Details 3</button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="contact-tab"
          data-bs-toggle="tab"
          data-bs-target="#AdvanceDetails4"
          type="button"
          role="tab"
          aria-controls="contact"
          aria-selected="false"
        >
          <button class="nav-link">Advance Details 4</button>
        </li>
        {/* <li
          class="nav-item"
          role="presentation"
          id="contact-tab"
          data-bs-toggle="tab"
          data-bs-target="#AdvanceDetails5"
          type="button"
          role="tab"
          aria-controls="contact"
          aria-selected="false"
        >
          <button class="nav-link">Advance Details 5</button>
        </li> */}
      </ul>
    );
  }
}
