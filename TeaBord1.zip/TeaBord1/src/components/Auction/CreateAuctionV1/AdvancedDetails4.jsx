import React, { Component } from "react";
import {
  YES_NO_VALUES,
  NOT_REQUIRED_EVENT_ITEM_WISE_VALUES,
  ACCEPT_DONT_ACCEPT_SAME_AMOUNT_VALUES,
} from "../../../containers/Auction/CreateAuctionV1/constants";

export default class AdvanceDetails4 extends Component {
  render() {
    const {
      handleClassDTOCreateAuction,
      classDTOCreateAuction,
      handleButtonsCreateAuction,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="AdvanceDetails4"
        role="tabpanel"
        aria-labelledby="contact-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Advance Details 4</h6>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <h5 class="SmallTitle">Bidder wise start price require</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Bidderwisestartpricerequire"
                      id="Bidderwisestartpricerequire-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.isBidderWiseStartPrice &&
                        classDTOCreateAuction.isBidderWiseStartPrice ==
                          data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "isBidderWiseStartPrice",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label
                      class="form-check-label"
                      for="Bidderwisestartpricerequire-Yes"
                    >
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <label class="LabelText">Digital certificate required</label>
            <select
              class="form-select"
              name="isCertRequired"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.isCertRequired) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
            <h5 class="SmallTitle">Demo auction</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Demoauction"
                      id="Demoauction-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.isDemoAuction &&
                        classDTOCreateAuction.isDemoAuction == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "isDemoAuction",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label class="form-check-label" for="Demoauction-Yes">
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
            <label class="LabelText">Greater rank</label>
            <input
              type="number"
              name="greaterRank"
              class="form-control"
              maxlength="15"
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
              value={classDTOCreateAuction && classDTOCreateAuction.greaterRank}
            />
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
            <h5 class="SmallTitle">Evaluation required?</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Evaluationrequired"
                      id="Evaluationrequired-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.isEvaluationReq &&
                        classDTOCreateAuction.isEvaluationReq == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "isEvaluationReq",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label
                      class="form-check-label"
                      for="Evaluationrequired-Yes"
                    >
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
            <h5 class="SmallTitle">Display limited event on home page</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="DisplayLimitedeventonhomepage"
                      id="DisplayLimitedeventonhomepage-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.forHomePage &&
                        classDTOCreateAuction.forHomePage == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "forHomePage",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label
                      class="form-check-label"
                      for="DisplayLimitedeventonhomepage-Yes"
                    >
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
            <h5 class="SmallTitle">Display IP address during live auction</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="DisplayIPaddressduringLiveauction"
                      id="DisplayIPaddressduringLiveauction-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.showIpAddress &&
                        classDTOCreateAuction.showIpAddress == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "showIpAddress",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label
                      class="form-check-label"
                      for="DisplayIPaddressduringLiveauction-Yes"
                    >
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <label class="LabelText">EMD required?</label>
            <select
              class="form-select"
              name="isEmdReq"
              value={
                (classDTOCreateAuction && classDTOCreateAuction.isEmdReq) || ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {NOT_REQUIRED_EVENT_ITEM_WISE_VALUES &&
                NOT_REQUIRED_EVENT_ITEM_WISE_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <label class="LabelText">Display price bid break up line</label>
            <select
              class="form-select"
              name="breakPriceBid"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.breakPriceBid) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <label class="LabelText">Enable result API</label>
            <select
              class="form-select"
              name="isResultApiRequired"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.isResultApiRequired) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <label class="LabelText">
              Hide live bidding to department user
            </label>
            <select
              class="form-select"
              name="isHideLiveBidToOfficer"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.isHideLiveBidToOfficer) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
            <label class="LabelText">Borrower name</label>
            <input
              type="text"
              name="borrowerName"
              class="form-control"
              maxlength="1000"
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
              value={
                classDTOCreateAuction && classDTOCreateAuction.borrowerName
              }
            />
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <label class="LabelText">Rank logic</label>
            <select
              class="form-select"
              name="rankLogic"
              value={
                (classDTOCreateAuction && classDTOCreateAuction.rankLogic) || ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {ACCEPT_DONT_ACCEPT_SAME_AMOUNT_VALUES &&
                ACCEPT_DONT_ACCEPT_SAME_AMOUNT_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsCreateAuction("prevButton")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() => handleButtonsCreateAuction("submit")}
          >
            Submit
          </button>
        </div>
      </div>
    );
  }
}
