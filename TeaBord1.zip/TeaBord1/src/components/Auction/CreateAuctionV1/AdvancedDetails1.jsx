import React, { Component } from "react";
import {
  TYPE_OF_CONTRACT_VALUES,
  BIDDING_ACCESS_VALUES,
  YES_NO_VALUES,
  NOT_REQUIRED_AUTO_MANUAL_VALUES,
  BIDDING_TYPE_VALUES,
  AUCTION_VARIANT_VALUES,
} from "../../../containers/Auction/CreateAuctionV1/constants";

export default class AdvanceDetails1 extends Component {
  render() {
    const {
      handleClassDTOCreateAuction,
      classDTOCreateAuction,
      getAllCurrencyDetailsResponse,
      handleButtonsCreateAuction,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="AdvanceDetails1"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Advance Details 1</h6>
          </div>

          <div class="col-12 mt-3">
            <h5 class="SmallTitle">Types of contract</h5>
            <div class="RadioGroup">
              {TYPE_OF_CONTRACT_VALUES &&
                TYPE_OF_CONTRACT_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Typesofcontract"
                      id="Typesofcontract-"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.formContract &&
                        classDTOCreateAuction.formContract == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "formContract",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label class="form-check-label" for="Typesofcontract-">
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-auto mt-3">
            <h5 class="SmallTitle">Bidding access</h5>
            <div class="RadioGroup">
              {BIDDING_ACCESS_VALUES &&
                BIDDING_ACCESS_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="BiddingAccess"
                      id="BiddingAccess-Open"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.auctionMode &&
                        classDTOCreateAuction.auctionMode == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "auctionMode",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label class="form-check-label" for="BiddingAccess-Open">
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-auto mt-3">
            <h5 class="SmallTitle">Bidder wise form display</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Bidderwiseformdisplay"
                      id="Bidderwiseformdisplay-"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.biddingForm &&
                        classDTOCreateAuction.biddingForm == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "biddingForm",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label
                      class="form-check-label"
                      for="Bidderwiseformdisplay-"
                    >
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-12 mt-3">
            <label class="LabelText">Product/service/work keywords.</label>
            <textarea
              class="form-control"
              name="keywordText"
              maxLength="1000"
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
              value={classDTOCreateAuction && classDTOCreateAuction.keywordText}
            ></textarea>
            {classDTOCreateAuction && classDTOCreateAuction.keywordTextError ? (
              <label className="error">
                {classDTOCreateAuction.keywordTextError}
              </label>
            ) : (
              ""
            )}
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">BRD mode*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="brdMode"
              value={
                (classDTOCreateAuction && classDTOCreateAuction.brdMode) || ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {NOT_REQUIRED_AUTO_MANUAL_VALUES &&
                NOT_REQUIRED_AUTO_MANUAL_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Product location</label>
            <input
              type="text"
              class="form-control"
              name="productLocation"
              maxlength="50"
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
              value={
                classDTOCreateAuction && classDTOCreateAuction.productLocation
              }
            />
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Budget</label>
            <input
              type="number"
              class="form-control"
              name="eventValue"
              maxlength="15"
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
              value={classDTOCreateAuction && classDTOCreateAuction.eventValue}
            />
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Auction base currency</label>
            <select
              class="form-select"
              name="auctionCurrencyDtoSet"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.auctionCurrencyDtoSet) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {getAllCurrencyDetailsResponse &&
                getAllCurrencyDetailsResponse.map((data, index) => (
                  <option value={data}>{data.lang1}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-6 mt-3">
            <h5 class="SmallTitle">Bidding type</h5>

            {BIDDING_TYPE_VALUES &&
              BIDDING_TYPE_VALUES.map((data, index) => (
                <div class="RadioGroup">
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Biddingtype"
                      id={data.displayKey}
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.biddingType &&
                        classDTOCreateAuction.biddingType == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "biddingType",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label class="form-check-label" for={data.displayKey}>
                      {data.displayKey}
                    </label>
                  </div>
                </div>
              ))}
          </div>
          {/* {classDTOCreateAuction &&
          classDTOCreateAuction.biddingType &&
          2 == classDTOCreateAuction.biddingType ? (
            <label class="LabelText">
              Bidding currencies and their exchange rate for base currency *
            </label>
          ) : (
            ""
          )} */}

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Auction variant</label>
            <select
              class="form-select"
              name="eventTypeId"
              value={
                (classDTOCreateAuction && classDTOCreateAuction.eventTypeId) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {AUCTION_VARIANT_VALUES &&
                AUCTION_VARIANT_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsCreateAuction("prevButton")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() => handleButtonsCreateAuction("nextButton")}
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
