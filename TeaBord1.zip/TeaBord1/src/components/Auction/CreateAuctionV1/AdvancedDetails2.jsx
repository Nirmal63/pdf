import React, { Component } from "react";
import {
  YES_NO_VALUES,
  STANDARD_RANK_VALUES,
  BID_SUBMISSION_FOR_VALUES,
  ALLOW_DONT_ALLOW_VALUES,
  BIDDING_FORM_VALUES,
} from "../../../containers/Auction/CreateAuctionV1/constants";

export default class AdvanceDetails2 extends Component {
  render() {
    const {
      handleClassDTOCreateAuction,
      classDTOCreateAuction,
      handleButtonsCreateAuction,
    } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="AdvanceDetails2"
        role="tabpanel"
        aria-labelledby="contact-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Advance Details 2</h6>
          </div>

          <div class="col-xl-3 col-lg-6 mt-3">
            <h5 class="SmallTitle">Auction type</h5>
            <div class="RadioGroup">
              {STANDARD_RANK_VALUES &&
                STANDARD_RANK_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name={data.value}
                      id={data.displayKey}
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.typeOfAuction &&
                        classDTOCreateAuction.typeOfAuction == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "typeOfAuction",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label class="form-check-label" for={data.displayKey}>
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          {classDTOCreateAuction &&
          classDTOCreateAuction.typeOfAuction &&
          1 == classDTOCreateAuction.typeOfAuction ? (
            <div class="col-xl-3 col-lg-6 mt-3">
              <h5 class="SmallTitle">Display rank</h5>
              <div class="RadioGroup">
                {YES_NO_VALUES &&
                  YES_NO_VALUES.map((data, index) => (
                    <div class="form-check">
                      <input
                        class="form-check-input"
                        type="radio"
                        name={data.value}
                        id={data.displayKey}
                        value={data.value}
                        checked={
                          classDTOCreateAuction &&
                          classDTOCreateAuction.showRank &&
                          classDTOCreateAuction.showRank == data.value
                            ? true
                            : false
                        }
                        onChange={(event) =>
                          handleClassDTOCreateAuction(
                            "showRank",
                            parseInt(event.target.value)
                          )
                        }
                      />
                      <label class="form-check-label" for={data.displayKey}>
                        {data.displayKey}
                      </label>
                    </div>
                  ))}
              </div>
            </div>
          ) : (
            ""
          )}

          <div class="col-xl-3 col-lg-6 mt-3">
            <h5 class="SmallTitle">Mask bidder name</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Maskbiddername"
                      id="Maskbiddername-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.isBidderNameMasking &&
                        classDTOCreateAuction.isBidderNameMasking == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "isBidderNameMasking",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label class="form-check-label" for="Maskbiddername-Yes">
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-3 col-lg-6 mt-3">
            <h5 class="SmallTitle">Reserve price check require</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Reservepricecheckrequire"
                      id="Reservepricecheckrequire-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.checkReservePrice &&
                        classDTOCreateAuction.checkReservePrice == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "checkReservePrice",
                          event.target.value
                        )
                      }
                    />
                    <label
                      class="form-check-label"
                      for="Reservepricecheckrequire-Yes"
                    >
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-12 mt-3">
            <h5 class="SmallTitle">Bid submission for</h5>
            <div class="RadioGroup">
              {BID_SUBMISSION_FOR_VALUES &&
                BID_SUBMISSION_FOR_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Bidsubmissionfor"
                      id="GrnadTotal"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.auctionResult &&
                        classDTOCreateAuction.auctionResult == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "auctionResult",
                          event.target.value
                        )
                      }
                    />
                    <label class="form-check-label" for="GrnadTotal">
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          {/* <div class="col-12 mt-3">
            <h5 class="SmallTitle">Increment/Decrement rules on</h5>
            <div class="RadioGroup">
              {INC_DEC_VALUE_RUE_VALUES &&
                INC_DEC_VALUE_RUE_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="IncrementDecrementruleson"
                      id="Inscementinoneormoreitems"
                    
                    />
                    <label
                      class="form-check-label"
                      for="Inscementinoneormoreitems"
                    >
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div> */}

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Requires check on minimum quantity</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isMinQtyReq"
              value={
                (classDTOCreateAuction && classDTOCreateAuction.isMinQtyReq) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Item selection required?</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isItemSelection"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.isItemSelection) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">
              Line item wise bid submission time allowed?
            </label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="isItemWiseTime"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.isItemWiseTime) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">
              Require bidding price increment in times
            </label>
            <select
              class="form-select"
              name="isBidPriceIncDecInTimesReq"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.isBidPriceIncDecInTimesReq) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">No. of bid restriction</label>
            <select
              class="form-select"
              name={"noOfBidRestriction"}
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.noOfBidRestriction) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {ALLOW_DONT_ALLOW_VALUES &&
                ALLOW_DONT_ALLOW_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">
              Result sharing for specific duration
            </label>
            <select
              class="form-select"
              name="resultSharingForSpecificDuration"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.resultSharingForSpecificDuration) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {ALLOW_DONT_ALLOW_VALUES &&
                ALLOW_DONT_ALLOW_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          {classDTOCreateAuction &&
          classDTOCreateAuction.resultSharingForSpecificDuration &&
          1 == classDTOCreateAuction.resultSharingForSpecificDuration ? (
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Result sharing duration</label>
              <input
                type="number"
                class="form-control"
                name="resultSharingDuration"
                maxlength="15"
                onChange={(event) =>
                  handleClassDTOCreateAuction(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTOCreateAuction &&
                  classDTOCreateAuction.resultSharingDuration
                }
              />
            </div>
          ) : (
            ""
          )}

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Share L1/H1 after auction</label>
            <select
              class="form-select"
              name="shareL1H1AfterAuc"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.shareL1H1AfterAuc) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {ALLOW_DONT_ALLOW_VALUES &&
                ALLOW_DONT_ALLOW_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>
          </div>

          {classDTOCreateAuction &&
          classDTOCreateAuction.shareL1H1AfterAuc &&
          1 == classDTOCreateAuction.shareL1H1AfterAuc ? (
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">
                Duration to display L1/H1 amount (Mins) *
              </label>
              <input
                type="number"
                class="form-control"
                name="durationToDisplayL1H1"
                maxlength="15"
                onChange={(event) =>
                  handleClassDTOCreateAuction(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTOCreateAuction &&
                  classDTOCreateAuction.durationToDisplayL1H1
                }
              />
            </div>
          ) : (
            ""
          )}

          <div class="col-xl-3 col-lg-4 col-md-6 col-12 mt-3">
            <h5 class="SmallTitle">Display bidder name encoding to officer</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Displaybiddernameencodingtoofficer"
                      id="Displaybiddernameencodingtoofficer-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.isEncodedName &&
                        classDTOCreateAuction.isEncodedName == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "isEncodedName",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label
                      class="form-check-label"
                      for="Displaybiddernameencodingtoofficer-Yes"
                    >
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
            <h5 class="SmallTitle">Bidding form</h5>
            <div class="RadioGroup">
              {BIDDING_FORM_VALUES &&
                BIDDING_FORM_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Biddingform"
                      id="Biddingform-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.biddingForm &&
                        classDTOCreateAuction.biddingForm == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "biddingForm",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label class="form-check-label" for="Biddingform-Yes">
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
            <h5 class="SmallTitle">Decode bidder name manually</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Decodebiddernamemanually"
                      id="Decodebiddernamemanually-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.isDecodeBidder &&
                        classDTOCreateAuction.isDecodeBidder == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "isDecodeBidder",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label
                      class="form-check-label"
                      for="Decodebiddernamemanually-Yes"
                    >
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>

          <div class="col-xl-3 col-lg-6 col-md-6 col-12 mt-3">
            <h5 class="SmallTitle">Increment in certain period</h5>
            <div class="RadioGroup">
              {YES_NO_VALUES &&
                YES_NO_VALUES.map((data, index) => (
                  <div class="form-check">
                    <input
                      class="form-check-input"
                      type="radio"
                      name="Incrementincertainperiod"
                      id="Incrementincertainperiod-Yes"
                      value={data.value}
                      checked={
                        classDTOCreateAuction &&
                        classDTOCreateAuction.isIncDecInPeriod &&
                        classDTOCreateAuction.isIncDecInPeriod == data.value
                          ? true
                          : false
                      }
                      onChange={(event) =>
                        handleClassDTOCreateAuction(
                          "isIncDecInPeriod",
                          parseInt(event.target.value)
                        )
                      }
                    />
                    <label
                      class="form-check-label"
                      for="Incrementincertainperiod-Yes"
                    >
                      {data.displayKey}
                    </label>
                  </div>
                ))}
            </div>
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnPrevious"
            onClick={() => handleButtonsCreateAuction("prevButton")}
          >
            Prev
          </button>
          <button
            class="btnNext"
            onClick={() => handleButtonsCreateAuction("nextButton")}
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
