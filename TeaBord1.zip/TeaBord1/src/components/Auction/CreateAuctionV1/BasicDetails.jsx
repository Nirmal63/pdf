import React, { Component } from "react";
import { SHOW_HIDE_VALUES } from "../../../containers/Auction/CreateAuctionV1/constants";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import TreeStructureView from "../../GenericComponents/TreeStructureView";

export default class BasicDetails extends Component {
  render() {
    const {
      handleClassDTOCreateAuction,
      classDTOCreateAuction,
      handleButtonsCreateAuction,
      getAllDepartmentDetailsResponse,
      getAllOfficerDetailsResponse,
    } = this.props;

    return (
      <div
        class="tab-pane fade show active"
        id="BasicDetails"
        role="tabpanel"
        aria-labelledby="home-tab"
      >
        <div class="row g-3">
          <div class="col-12">
            <h6 class="MediumTitle">Basic Details</h6>
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Department*</label>
            <TreeStructureView
              responseData={getAllDepartmentDetailsResponse}
              handleClassDTO={handleClassDTOCreateAuction}
              classDTO={classDTOCreateAuction}
              classDTOKey="tblDepartment"
              divIdName="childDivDepartmentAuction"
              iconIdName="chilIconDepartmentAuction"
              departmentTreeChildDivMargin={""}
              iconIdMarginAvailable={true}
            />

            {classDTOCreateAuction &&
            classDTOCreateAuction.tblDepartmentError ? (
              <label className="error">
                {classDTOCreateAuction.tblDepartmentError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Officer*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="userDetailId"
              disabled={
                isNullOrIsEmptyOrIsUndefined(getAllOfficerDetailsResponse)
                  ? true
                  : false
              }
              value={
                (classDTOCreateAuction && classDTOCreateAuction.userDetailId) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {getAllOfficerDetailsResponse &&
                getAllOfficerDetailsResponse.map((data, index) => (
                  <option value={data.userDetailId}>{data.officerName}</option>
                ))}
            </select>
            {classDTOCreateAuction &&
            classDTOCreateAuction.displayOfficerNameError ? (
              <label className="error">
                {classDTOCreateAuction.displayOfficerNameError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Auction no.*</label>
            <input
              type="text"
              class="form-control"
              name="auctionNo"
              maxlength="50"
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
              value={classDTOCreateAuction && classDTOCreateAuction.auctionNo}
            />
            {classDTOCreateAuction && classDTOCreateAuction.auctionNoError ? (
              <label className="error">
                {classDTOCreateAuction.auctionNoError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Display officer name*</label>
            <select
              class="form-select"
              aria-label="Default select example"
              name="displayOfficerName"
              value={
                (classDTOCreateAuction &&
                  classDTOCreateAuction.displayOfficerName) ||
                ""
              }
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
            >
              {SHOW_HIDE_VALUES &&
                SHOW_HIDE_VALUES.map((data, index) => (
                  <option value={data.value}>{data.displayKey}</option>
                ))}
            </select>

            {classDTOCreateAuction &&
            classDTOCreateAuction.displayOfficerNameError ? (
              <label className="error">
                {classDTOCreateAuction.displayOfficerNameError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-12">
            <label class="LabelText">Brief scope of work*</label>
            <textarea
              class="form-control"
              id="exampleFormControlTextarea1"
              name="auctionBrief"
              maxLength="1000"
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
              value={
                classDTOCreateAuction && classDTOCreateAuction.auctionBrief
              }
            ></textarea>
            {classDTOCreateAuction &&
            classDTOCreateAuction.auctionBriefError ? (
              <label className="error">
                {classDTOCreateAuction.auctionBriefError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-12">
            {/* <h5 class="SmallTitle">Auction Details</h5>
            <textarea name="" id="editor" cols="30" rows="10"></textarea> */}
            <label class="LabelText">Auction details</label>
            <textarea
              class="form-control"
              id="exampleFormControlTextarea1"
              name="auctionDetail"
              maxLength="20000"
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
              value={
                classDTOCreateAuction && classDTOCreateAuction.auctionDetail
              }
            ></textarea>
            {classDTOCreateAuction &&
            classDTOCreateAuction.auctionDetailError ? (
              <label className="error">
                {classDTOCreateAuction.auctionDetailError}
              </label>
            ) : (
              ""
            )}
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Document fees</label>
            <input
              type="text"
              class="form-control"
              name="documentFee"
              maxlength="15"
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
              value={classDTOCreateAuction && classDTOCreateAuction.documentFee}
            />
          </div>
          <div class="col-xl-3 col-lg-4 col-md-6 col-12">
            <label class="LabelText">Participation fees</label>
            <input
              type="text"
              class="form-control"
              name="participationFee"
              maxlength="15"
              onChange={(event) =>
                handleClassDTOCreateAuction(
                  event.target.name,
                  event.target.value
                )
              }
              value={
                classDTOCreateAuction && classDTOCreateAuction.participationFee
              }
            />
          </div>
        </div>

        <div class="NextPrev">
          <button
            class="btnNext"
            onClick={() => handleButtonsCreateAuction("nextButton")}
          >
            Next
          </button>
        </div>
      </div>
    );
  }
}
