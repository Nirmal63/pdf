import React, { Component } from "react";
import Tabs from "./Tabs";
import BasicDetails from "./BasicDetails";
import AdvanceDetails1 from "./AdvancedDetails1";
import AdvanceDetails2 from "./AdvancedDetails2";
import AdvanceDetails3 from "./AdvancedDetails3";
import AdvanceDetails4 from "./AdvancedDetails4";
// import AdvanceDetails5 from "./AdvancedDetails5";

export default class index extends Component {
  render() {
    return (
      <div>
        <h2 class="Title">Create English Auction</h2>

        <div class="CrateEnglishAuction ShadowBox">
          <Tabs />
          <div class="tab-content" id="myTabContent">
            <BasicDetails {...this.props} />
            <AdvanceDetails1 {...this.props} />
            <AdvanceDetails2 {...this.props} />
            <AdvanceDetails3 {...this.props} />
            <AdvanceDetails4 {...this.props} />
            {/* <AdvanceDetails5 {...this.props} /> */}
          </div>
        </div>
      </div>
    );
  }
}
