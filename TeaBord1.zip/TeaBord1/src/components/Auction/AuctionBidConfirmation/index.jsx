import React, { Component } from "react";
import $ from "jquery";
// import Toast from "../../components/GenericComponents/Toast";

export default class index extends Component {
  constructor(props) {
    super(props);

    this.state = {
      toastMessage: "",
      showToast: false,
    };
  }

  onCloseModal() {
    localStorage.removeItem("auctionBidConfirmation");
  }

  onRejectButton() {
    localStorage.removeItem("auctionBidConfirmation");
    window.location.href = "/auctionList";
  }
  render() {
    const {
      flag,
      openPopUp,
      handleButtonsAuctionBidConfirmation,
      classDTOAuctionBidConfirmation,
      handleClassDTOAuctionBidConfirmation,
      getAuctionBidTermAndConditionResponse,
      getuserDetailIdResponse,
    } = this.props;
    return (
      <>
        {getAuctionBidTermAndConditionResponse &&
          getAuctionBidTermAndConditionResponse.map((data, index) => (
            <>
              {getuserDetailIdResponse &&
                getuserDetailIdResponse.map((data1, index) => (
                  <>
                    <div
                      className="modal fade LoginModal"
                      id="auctionBidConfirmationModal"
                      tabindex="-1"
                      aria-labelledby="exampleModalLabel"
                      aria-hidden="true"
                    >
                      <div className="modal-dialog modal-dialog-centered modal-lg">
                        <div className="modal-content">
                          <i
                            className="fa fa-close CloseModal"
                            data-bs-dismiss="modal"
                            aria-label="Close"
                            onClick={() => {
                              this.onCloseModal();
                            }}
                          ></i>
                          <div className="modal-body">
                            <div className="row align-items-center g-0">
                              <div className="col-md-13">
                                <div className="LoginForm">
                                  <div className="row g-2">
                                    <p>
                                      <h1
                                        id="clientBidTermId"
                                        name="clientBidTermId"
                                        // data={data && data.clientBidTermId}
                                        value={
                                          (data && data.clientBidTermId) || ""
                                        }
                                        // value={data && data.clientBidTermId}
                                      >
                                        {data.bidTerm}
                                        Hii
                                      </h1>
                                      {/* <h5>{data.clientBidTermId}</h5> */}
                                    </p>
                                    <li>
                                      We have read, examined and understood the
                                      Seal Bid documents pertaining to this Seal
                                      Bid notice and have no reservations to the
                                      same.
                                    </li>

                                    <br />
                                    <li>
                                      We offer to execute the works in
                                      conformity with the Seal Bid Document's.
                                    </li>
                                    <br />
                                    <li>
                                      Our bid shall be valid for a period as
                                      mentioned in the Seal Bid document and it
                                      shall remain binding upon us.
                                    </li>
                                    <br />
                                    <li>
                                      We understand that you are not bound to
                                      accept the lowest bid in case of Seal Bid
                                      and highest bid in case of Seal Bid or any
                                      other bid that you may receive.
                                      233344556677
                                    </li>
                                    <br />

                                    <div class="form-check">
                                      <input
                                        class="form-check-input"
                                        type="checkbox"
                                        name="iAgree"
                                        id="iAgree"
                                        checked={
                                          classDTOAuctionBidConfirmation &&
                                          classDTOAuctionBidConfirmation.iAgree
                                            ? true
                                            : false
                                        }
                                        value={
                                          classDTOAuctionBidConfirmation &&
                                          classDTOAuctionBidConfirmation.iAgree
                                        }
                                        onChange={(event) =>
                                          handleClassDTOAuctionBidConfirmation(
                                            event.target.name,
                                            event.target.checked
                                          )
                                        }
                                      />
                                      <label
                                        class="form-check-label"
                                        for="iAgree"
                                      >
                                        I Agree
                                      </label>
                                    </div>

                                    {classDTOAuctionBidConfirmation &&
                                    classDTOAuctionBidConfirmation.iAgree &&
                                    true ==
                                      classDTOAuctionBidConfirmation.iAgree ? (
                                      <>
                                        <div className="submit">
                                          <button
                                            onClick={() =>
                                              handleButtonsAuctionBidConfirmation(
                                                "Agree",
                                                data && data.clientBidTermId,
                                                data1 && data1.userDetailId
                                              )
                                            }
                                          >
                                            Accept
                                          </button>
                                          <button
                                            data-bs-dismiss="modal"
                                            aria-label="Close"
                                            onClick={() => {
                                              this.onRejectButton();
                                            }}
                                          >
                                            Reject
                                          </button>
                                        </div>
                                      </>
                                    ) : (
                                      " "
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </>
                ))}
            </>
          ))}
      </>
    );
  }
}
