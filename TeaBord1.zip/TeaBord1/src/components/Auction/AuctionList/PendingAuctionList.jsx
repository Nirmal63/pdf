import React, { Component } from "react";
import {
  setLocalStorageItem,
  getLocalStorageItem,
} from "../../../commonConstants/LocalStorageData";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import LoaderComponent from "../../GenericComponents/LoaderComponent";

export default class PendingAuctionList extends Component {
  // onFilter = () => {
  //   $(".FilterBox").toggleClass("active");
  // };

  componentDidMount() {
    let data = {
      userId: getLocalStorageItem("userId"),
      cstatus: 0,
    };
    this.props.getAuctionDetailsWithStatus(data);
  }

  goToPage = (data) => {
    setLocalStorageItem("auctionIdForAuctionDashboard", data);
    window.location.href = "/auctionDashboard";
  };

  goToPageApprove = (data) => {
    setLocalStorageItem("auctionIdForApproveAuction", data);
    window.location.href = "/approveAuction";
  };

  goToPageFormula = (data) => {
    setLocalStorageItem("auctionIdForFormula", data);
    window.location.href = "/createAuctionFormula";
  };

  render() {
    const { getAuctionDetailsWithStatusResponse } = this.props;

    return (
      <div
        class="tab-pane fade show active"
        id="PendingAuctionDetails"
        role="tabpanel"
        aria-labelledby="home-tab"
      >
        {!isNullOrIsEmptyOrIsUndefined(getAuctionDetailsWithStatusResponse) ? (
          <div class="row g-3">
            {/* <div class="col-12">
                <div class="Filter">
                  <a onClick={() => this.onFilter()} class="FilterBtn">
                    <i class="fa fa-filter"></i> Filter
                  </a>
                </div>
              </div> */}
            <div class="TableBox">
              <table class="table">
                <thead>
                  <tr>
                    <td></td>
                    <th>Auction Name</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    {/* <th>Auction Type</th>
                  <th>Auction Variant</th> */}
                    <th>Auction Id</th>
                    <th>Formula</th>
                    <th>Approve Auction</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {getAuctionDetailsWithStatusResponse &&
                    getAuctionDetailsWithStatusResponse.map((data, index) => (
                      <tr>
                        <td>{index + 1}</td>
                        {/* <td class="DepartmentsName">
                            <strong></strong>
                            <small></small>
                          </td> */}
                        <td>{data.auctionBrief}</td>
                        <td>{data.startDate}</td>
                        <td>{data.endDate}</td>
                        {/* <td>{data.eventType}</td>
                      <td>
                        {1 == data.eventTypeId
                          ? "Forward Auction"
                          : "Reverse Auction"}
                      </td> */}

                        <td>{data.auctionId}</td>

                        <td
                          className="textDecoration"
                          onClick={() => this.goToPageFormula(data.auctionId)}
                        >
                          Formula
                        </td>

                        <td
                          className="textDecoration"
                          onClick={() => this.goToPageApprove(data.auctionId)}
                        >
                          Approve
                        </td>

                        <td
                          className="textDecoration"
                          onClick={() => this.goToPage(data.auctionId)}
                        >
                          Dashboard
                        </td>

                        {/* <td class="Action">
                        <a href="#">
                          <i class="fa fa-edit"></i>
                        </a>
                        <a href="#">
                          <i class="fa-solid fa-cloud-arrow-up"></i>
                        </a>
                        <a href="#">
                          <i class="fa-sharp fa-solid fa-gear"></i>
                        </a>
                        <a href="#">
                          <i class="fa fa-screwdriver-wrench"></i>
                        </a>
                        <a href="#">
                          <i class="fa fa-solid fa-file"></i>
                        </a>
                        <a href="#">
                          <i class="fa fa-chart-pie"></i>
                        </a>
                      </td> */}
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
            {/* <nav aria-label="...">
                <ul class="pagination">
                  <li class="page-item disabled">
                    <a
                      class="page-link"
                      href="#"
                      tabindex="-1"
                      aria-disabled="true"
                    >
                      Previous
                    </a>
                  </li>
                  <li class="page-item">
                    <a class="page-link" href="#">
                      1
                    </a>
                  </li>
                  <li class="page-item active" aria-current="page">
                    <a class="page-link" href="#">
                      2
                    </a>
                  </li>
                  <li class="page-item">
                    <a class="page-link" href="#">
                      3
                    </a>
                  </li>
                  <li class="page-item">
                    <a class="page-link" href="#">
                      Next
                    </a>
                  </li>
                </ul>
              </nav> */}
          </div>
        ) : (
          <LoaderComponent />
        )}
      </div>
    );
  }
}
