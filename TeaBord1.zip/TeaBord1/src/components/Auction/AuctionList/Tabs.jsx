import React, { Component } from "react";
import $ from "jquery";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

export default class List extends Component {
  onFilter = () => {
    $(".FilterBox").toggleClass("active");
  };

  tabButtonClick = (currentTab) => {
    if ("pending" == currentTab) {
      let data = {
        userId: getLocalStorageItem("userId"),
        cstatus: 0,
      };
      this.props.getAuctionDetailsWithStatus(data);
    } else if ("live" == currentTab) {
      let data = {
        id: getLocalStorageItem("clientId"),
      };
      this.props.getLiveAuctionDetails(data);
    }
  };

  render() {
    return (
      <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li
          class="nav-item active"
          role="presentation"
          id="home-tab"
          data-bs-toggle="tab"
          data-bs-target="#PendingAuctionDetails"
          type="button"
          role="tab"
          aria-controls="home"
          aria-selected="true"
        >
          <button
            class="nav-link"
            onClick={() => {
              this.tabButtonClick("pending");
            }}
          >
            Pending
          </button>
        </li>
        <li
          class="nav-item"
          role="presentation"
          id="profile-tab"
          data-bs-toggle="tab"
          data-bs-target="#LiveAuctionDetails"
          type="button"
          role="tab"
          aria-controls="profile"
          aria-selected="false"
        >
          <button
            class="nav-link"
            onClick={() => {
              this.tabButtonClick("live");
            }}
          >
            Live
          </button>
        </li>
      </ul>
    );
  }
}
