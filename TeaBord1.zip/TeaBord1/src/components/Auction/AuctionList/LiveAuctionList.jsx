import React, { Component } from "react";
import { setLocalStorageItem } from "../../../commonConstants/LocalStorageData";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import LoaderComponent from "../../GenericComponents/LoaderComponent";
import AuctionBidConfirmationContainer from "../../../containers/Auction/AuctionBidConfirmation";

export default class LiveAuctionList extends Component {
  // onFilter = () => {
  //   $(".FilterBox").toggleClass("active");
  // };

  goToPage = (data) => {
    setLocalStorageItem("auctionIdForBiddingHall", data);
    window.location.href = "/biddingHall";
  };

  bidConformationButtonClick = (data) => {
    setLocalStorageItem("auctionBidConfirmation", data);
  };

  render() {
    const { getLiveAuctionDetailsResponse } = this.props;

    return (
      <div
        class="tab-pane fade"
        id="LiveAuctionDetails"
        role="tabpanel"
        aria-labelledby="profile-tab"
      >
        <AuctionBidConfirmationContainer />
        {!isNullOrIsEmptyOrIsUndefined(getLiveAuctionDetailsResponse) ? (
          <div class="row g-3">
            {/* <div class="col-12">
                <div class="Filter">
                  <a onClick={() => this.onFilter()} class="FilterBtn">
                    <i class="fa fa-filter"></i> Filter
                  </a>
                </div>
              </div> */}
            <div class="TableBox">
              <table class="table">
                <thead>
                  <tr>
                    <td></td>
                    <th>Auction Name</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Auction Type</th>
                    <th>Bidding Type</th>
                    <th>Auction Id</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {getLiveAuctionDetailsResponse &&
                    getLiveAuctionDetailsResponse.map((data, index) => (
                      <tr>
                        <td>{index + 1}</td>
                        {/* <td class="DepartmentsName">
                            <strong></strong>
                            <small></small>
                          </td> */}
                        <td>{data.auctionBrief}</td>
                        <td>{data.startDate}</td>
                        <td>{data.endDate}</td>
                        <td>
                          {1 == data.eventTypeId
                            ? "Forward Auction"
                            : "Reverse Auction"}
                        </td>
                        <td>
                          {0 == data.isAutoBidAllowed
                            ? "Manual Bid"
                            : "Auto Bid"}
                        </td>
                        <td
                          className="textDecoration"
                          onClick={() => this.goToPage(data.auctionId)}
                        >
                          {data.auctionId}
                        </td>
                        <td
                          className="textDecoration"
                          data-bs-toggle="modal"
                          data-bs-target="#auctionBidConfirmationModal"
                          onClick={() =>
                            this.bidConformationButtonClick(data.auctionId)
                          }
                        >
                          Click here to Bid
                        </td>

                        {/* <td class="Action">
                        <a href="#">
                          <i class="fa fa-edit"></i>
                        </a>
                        <a href="#">
                          <i class="fa-solid fa-cloud-arrow-up"></i>
                        </a>
                        <a href="#">
                          <i class="fa-sharp fa-solid fa-gear"></i>
                        </a>
                        <a href="#">
                          <i class="fa fa-screwdriver-wrench"></i>
                        </a>
                        <a href="#">
                          <i class="fa fa-solid fa-file"></i>
                        </a>
                        <a href="#">
                          <i class="fa fa-chart-pie"></i>
                        </a>
                      </td> */}
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
            {/* <nav aria-label="...">
                <ul class="pagination">
                  <li class="page-item disabled">
                    <a
                      class="page-link"
                      href="#"
                      tabindex="-1"
                      aria-disabled="true"
                    >
                      Previous
                    </a>
                  </li>
                  <li class="page-item">
                    <a class="page-link" href="#">
                      1
                    </a>
                  </li>
                  <li class="page-item active" aria-current="page">
                    <a class="page-link" href="#">
                      2
                    </a>
                  </li>
                  <li class="page-item">
                    <a class="page-link" href="#">
                      3
                    </a>
                  </li>
                  <li class="page-item">
                    <a class="page-link" href="#">
                      Next
                    </a>
                  </li>
                </ul>
              </nav> */}
          </div>
        ) : (
          <LoaderComponent />
        )}
      </div>
    );
  }
}
