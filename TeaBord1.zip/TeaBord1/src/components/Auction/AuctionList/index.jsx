import React, { Component } from "react";
import PendingAuctionList from "./PendingAuctionList";
import LiveAuctionList from "./LiveAuctionList";

import Tabs from "./Tabs";

export default class index extends Component {
  render() {
    return (
      <>
        <h2 class="Title">Auction List</h2>
        <div class="CreateClient ShadowBox Manageclients">
          <Tabs {...this.props} />

          <div class="tab-content" id="myTabContent">
            <PendingAuctionList {...this.props} />
            <LiveAuctionList {...this.props} />
          </div>
        </div>
      </>
    );
  }
}
