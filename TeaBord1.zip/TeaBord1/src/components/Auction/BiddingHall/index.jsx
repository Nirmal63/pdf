import React, { Component } from "react";
import AuctionSummaryDetails from "./AuctionSummaryDetails";
import moment from "moment";

let currentDate = moment(new Date()).format("DD/MM/YYYY HH:mm:ss");

export default class index extends Component {
  setAccordionName = (data) => {
    let columnId = 0,
      columnName = "";
    data &&
      data.AuctionColumnHeader &&
      data.AuctionColumnHeader.map((headerData, index) => {
        if (1 == headerData.columntypeid) {
          columnId = headerData.columnid;
        }
      });

    data &&
      data.AuctionCellValueList &&
      data.AuctionCellValueList.map((columnData, index) => {
        if (columnId == columnData.columnid) {
          columnName = columnData.cellvalue;
        }
      });

    return columnName;
  };

  render() {
    let {
      getBidDetailsResponse,
      handleButtonsBiddingHall,
      handleClassDTOBiddingHall,
    } = this.props;

    return (
      <>
        <h2 class="Title">Bidding Hall</h2>
        <div class="ShadowBox BiddingHall">
          <div class="row mb-2 align-items-center">
            <div class="col-lg-6">
              <h6>key links</h6>
            </div>
            <div class="col-lg-6">
              <div class="KeyLinks">
                <a href="#">View notice & document</a>{" "}
                <a href="#">Bid History</a>
              </div>
            </div>
            <div class="col-12 mt-3">
              <h5>
                Current Date and Time: <span>{currentDate}</span>
              </h5>
            </div>
          </div>

          {/* Header */}
          <div class="row align-items-center">
            <div class="col-md-11 col-6">
              {getBidDetailsResponse &&
                getBidDetailsResponse.AuctionTableValueList &&
                getBidDetailsResponse.AuctionTableValueList.map(
                  (data, index) => <h1 class="Title">{data.tableheader}</h1>
                )}
            </div>
            <div class="col-md-1 col-6">
              <a href="#" class="PDF">
                <i class="fa fa-file-pdf"></i>
              </a>
            </div>
          </div>

          {/* item List */}
          {getBidDetailsResponse &&
            getBidDetailsResponse.biddingHallDetail &&
            getBidDetailsResponse.biddingHallDetail.map((data, index) => (
              <div class="accordion" id="BiddingHall">
                {/* For length of 2 accordion */}
                <div class="accordion-item">
                  <h2 class="accordion-header" id="headingOne">
                    <button
                      class="accordion-button"
                      type="button"
                      data-bs-toggle="collapse"
                      data-bs-target="#i1"
                      aria-expanded="true"
                      aria-controls="collapseOne"
                    >
                      {/* To set name of accordion */}
                      {this.setAccordionName(data)}
                    </button>
                  </h2>
                  <div
                    id="i1"
                    class="accordion-collapse collapse show"
                    aria-labelledby="headingOne"
                    data-bs-parent="#BiddingHall"
                  >
                    <div class="accordion-body">
                      <div class="row mb-3">
                        <div class="col-auto">
                          <p>
                            <strong>Remaining time:</strong>
                            {data.remainingtime}
                          </p>
                        </div>
                        <div class="col-auto">
                          <p>
                            <strong>Start date and time:</strong>
                            {data.startdate}
                          </p>
                        </div>
                        <div class="col-auto">
                          <p>
                            <strong>End date and time:</strong>
                            {data.enddate}
                            {/* 23 hr - 41 Minutes - 56 seconds */}
                          </p>
                        </div>
                        <div class="col-auto">
                          <p>
                            <strong>Last bid price:</strong>
                            {data.bidderlastvalidbidamount}
                          </p>
                        </div>
                        <div class="col-auto">
                          <p>
                            <strong>L1/H1 bid price:</strong>
                            {data.bidderh1l1price}
                          </p>
                        </div>
                        <div class="col-12 mt-3">
                          <strong>Start price:</strong>
                          {data.bidderstartprice}
                          <strong> Bid date:</strong>
                          {data.submittedon}
                        </div>
                      </div>
                      <div class="TableBox">
                        <table class="table">
                          <thead>
                            {/* To set table header */}
                            <tr>
                              {data &&
                                data.AuctionColumnHeader &&
                                data.AuctionColumnHeader.map(
                                  (headerData, index) => (
                                    <th class="text-center">
                                      {headerData.columnheader}
                                    </th>
                                  )
                                )}
                              <th class="text-center">Bid</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              {/* To set table columns */}
                              {data &&
                                data.AuctionCellValueList &&
                                data.AuctionCellValueList.map(
                                  (cellData, index) => (
                                    <th class="text-center">
                                      {4 == cellData.columntypeid ? (
                                        <input
                                          type="number"
                                          class="form-control"
                                          name={cellData.columntypeid}
                                          value={cellData.cellvalue}
                                          onChange={(event) =>
                                            handleClassDTOBiddingHall(
                                              event.target.value,
                                              cellData.rowid,
                                              cellData.columnid
                                            )
                                          }
                                          maxlength={15}
                                        />
                                      ) : 5 == cellData.columntypeid ? (
                                        <input
                                          type="number"
                                          class="form-control"
                                          name={cellData.columntypeid}
                                          value={cellData.cellvalue}
                                          onChange={(event) =>
                                            handleClassDTOBiddingHall(
                                              event.target.value,
                                              cellData.rowid,
                                              cellData.columnid
                                            )
                                          }
                                          maxlength={15}
                                          disabled
                                        />
                                      ) : (
                                        cellData.cellvalue
                                      )}
                                    </th>
                                  )
                                )}
                              <td class="text-center">
                                <button
                                  class="Bid"
                                  onClick={() =>
                                    handleButtonsBiddingHall(
                                      "submit",
                                      data.rowid
                                    )
                                  }
                                >
                                  Bid
                                </button>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}

          {/* Footer */}
          <div class="row">
            <div class="col-11">
              {getBidDetailsResponse &&
                getBidDetailsResponse.AuctionTableValueList &&
                getBidDetailsResponse.AuctionTableValueList.map(
                  (data, index) => <h1 class="Title">{data.tablefooter}</h1>
                )}{" "}
            </div>
            <div class="col-12">
              <div class="Notic">
                <p>
                  You are advised not to wait till last minute or last seconds
                  to submit your bid to avoid complications related to internet
                  connectivity, netword problems, system crash down, power
                  failure, etc. Nelther department nor e-Procurement
                  Technologies Ltd. (service provider) are responsible for any
                  unforeseen circumstance.
                </p>
              </div>
            </div>
          </div>

          <AuctionSummaryDetails {...this.props} />

          <div class="col-12">
            <a href="#" class="More">
              Show more detail
            </a>
          </div>
          <div class="col-12">
            <button class="BlueButton">View full notice & document</button>
          </div>
        </div>
      </>
    );
  }
}
