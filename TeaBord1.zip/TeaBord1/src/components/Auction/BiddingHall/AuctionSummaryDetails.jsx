import React, { Component } from "react";
import $ from "jquery";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

export default class AuctionSummaryDetails extends Component {
  constructor(props) {
    super(props);

    this.state = {
      isCollapsed: false,
    };
  }

  componentDidMount() {}

  buttonClick = () => {
    this.state.isCollapsed = !this.state.isCollapsed;

    if (this.state.isCollapsed) {
      if (
        !isNullOrIsEmptyOrIsUndefined(
          getLocalStorageItem("auctionIdForBiddingHall")
        )
      ) {
        this.props.getAuctionSummaryDetails(
          getLocalStorageItem("auctionIdForBiddingHall")
        );
      }
      $("#accordionSummaryBody").addClass("show");
      $("#accordionSummaryButton").removeClass("collapsed");
    } else {
      $("#accordionSummaryBody").removeClass("show");
      $("#accordionSummaryButton").addClass("collapsed");
    }
  };
  render() {
    let { getAuctionSummaryDetailsResponse } = this.props;

    return (
      <>
        <div class="row">
          <div class="accordion" id="accordionExample">
            <div class="accordion-item">
              <h2 class="accordion-header" id="headingThree">
                <button
                  class="accordion-button collapsed"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#collapseThree"
                  aria-expanded="false"
                  aria-controls="collapseThree"
                  onClick={() => {
                    this.buttonClick();
                  }}
                  id="accordionSummaryButton"
                >
                  Auction Summary
                </button>
              </h2>
              <div
                // id={this.state.isCollapsed ? "collapseThree" : ""}
                id="collapseThree"
                // id="accordionSummaryBody"
                class="accordion-collapse collapse"
                aria-labelledby="headingThree"
                data-bs-parent="#accordionExample"
              >
                <div class="accordion-body">
                  <div class="row">
                    <div class="col-md-6">
                      <div class="TableBox AuctionSummary">
                        <table class="table table-striped">
                          <tbody>
                            <tr>
                              <td width="25%">Auction ID</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.auctionId}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Auction brief</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.auctionBrief}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Start date and time</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.startDate}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Auction variant</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                getAuctionSummaryDetailsResponse.eventTypeId &&
                                1 ==
                                  getAuctionSummaryDetailsResponse.eventTypeId
                                  ? "Forward Auction"
                                  : "Reverse Auction"}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="TableBox AuctionSummary">
                        <table class="table table-striped">
                          <tbody>
                            <tr>
                              <td width="25%">Auction No.</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.auctionNo}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Department</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.departmentName}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">End date and time ID</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.endDate}
                              </td>
                            </tr>

                            <tr>
                              <td width="25%">Auction base currency</td>
                              <td width="1%">:</td>
                              <td>
                                {getAuctionSummaryDetailsResponse &&
                                  getAuctionSummaryDetailsResponse.currency}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}
