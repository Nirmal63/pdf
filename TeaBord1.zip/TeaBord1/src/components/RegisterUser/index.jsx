import React, { Component } from "react";
import TreeStructureView from "../GenericComponents/TreeStructureView";
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap-icons/font/bootstrap-icons.css";

export default class index extends Component {
  render() {
    const {
      handleClassDTORegisterUser,
      classDTORegisterUser,
      handleButtonsRegisterUser,
      getAllTimeZoneDetailsResponse,
      getAllDepartmentDetailsResponse,
      getAllDesignationDetailsByDepartmentIdResponse,
    } = this.props;

    return (
      <div>
        <h2 class="Title">User Registration</h2>

        <div class="CreateClient ShadowBox">
          <div class="row g-3">
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Department*</label>
              <TreeStructureView
                responseData={getAllDepartmentDetailsResponse}
                handleClassDTO={handleClassDTORegisterUser}
                classDTO={classDTORegisterUser}
                classDTOKey="deptId"
                divIdName="childDivDepartmentRegBidder"
                iconIdName="chilIconDepartmentRegBidder"
                departmentTreeChildDivMargin={""}
                iconIdMarginAvailable={true}
                liName="departmentTree"
                inputId="BidderwiseformdisplayDep-"
                inputName="BidderwiseformdisplayDep"
              />

              {classDTORegisterUser && classDTORegisterUser.deptIdError ? (
                <label className="error">
                  {classDTORegisterUser.deptIdError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Designation*</label>
              <TreeStructureView
                responseData={getAllDesignationDetailsByDepartmentIdResponse}
                handleClassDTO={handleClassDTORegisterUser}
                classDTO={classDTORegisterUser}
                classDTOKey="designationId"
                divIdName="childDivDesignationRegBidder"
                iconIdName="chilIconDesignationRegBidder"
                departmentTreeChildDivMargin={""}
                iconIdMarginAvailable={false}
                liName="designationTree"
                inputId="BidderwiseformdisplayDes-"
                inputName="BidderwiseformdisplayDes"
              />

              {classDTORegisterUser &&
              classDTORegisterUser.designationIdError ? (
                <label className="error">
                  {classDTORegisterUser.designationIdError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Email Id* </label>
              <input
                type="text"
                class="form-control"
                name="loginId"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTORegisterUser(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTORegisterUser && classDTORegisterUser.loginId}
              />
              {classDTORegisterUser && classDTORegisterUser.loginIdError ? (
                <label className="error">
                  {classDTORegisterUser.loginIdError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Person name*</label>
              <input
                type="text"
                class="form-control"
                name="userName"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTORegisterUser(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTORegisterUser && classDTORegisterUser.userName}
              />
              {classDTORegisterUser && classDTORegisterUser.userNameError ? (
                <label className="error">
                  {classDTORegisterUser.userNameError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Mobile no.*</label>
              <input
                type="number"
                class="form-control"
                name="mobileNo"
                maxlength="20"
                onChange={(event) =>
                  handleClassDTORegisterUser(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTORegisterUser && classDTORegisterUser.mobileNo}
              />
              {classDTORegisterUser && classDTORegisterUser.mobileNoError ? (
                <label className="error">
                  {classDTORegisterUser.mobileNoError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Phone no.*</label>
              <input
                type="number"
                class="form-control"
                name="phoneNo"
                maxlength="20"
                onChange={(event) =>
                  handleClassDTORegisterUser(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTORegisterUser && classDTORegisterUser.phoneNo}
              />
              {classDTORegisterUser && classDTORegisterUser.phoneNoError ? (
                <label className="error">
                  {classDTORegisterUser.phoneNoError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Password*</label>
              <input
                type="password"
                class="form-control"
                name="password"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTORegisterUser(
                    event.target.name,
                    event.target.value
                  )
                }
                value={classDTORegisterUser && classDTORegisterUser.password}
              />
              {classDTORegisterUser && classDTORegisterUser.passwordError ? (
                <label className="error">
                  {classDTORegisterUser.passwordError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Confirm password*</label>
              <input
                type="password"
                class="form-control"
                name="confPassword"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTORegisterUser(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTORegisterUser && classDTORegisterUser.confPassword
                }
              />
              {classDTORegisterUser &&
              classDTORegisterUser.confPasswordError ? (
                <label className="error">
                  {classDTORegisterUser.confPasswordError}
                </label>
              ) : (
                ""
              )}
            </div>

            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">
                Time zone*{" "}
                <i
                  class="bi bi-info-circle"
                  data-toggle="tooltip"
                  data-placement="top"
                  title="Select your country time zone as it is convenient for commercial or other communication to keep the same time"
                ></i>
              </label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="tblTimeZone"
                value={
                  (classDTORegisterUser && classDTORegisterUser.tblTimeZone) ||
                  ""
                }
                onChange={(event) =>
                  handleClassDTORegisterUser(
                    event.target.name,
                    event.target.value
                  )
                }
              >
                {getAllTimeZoneDetailsResponse &&
                  getAllTimeZoneDetailsResponse.map((data, index) => (
                    <option value={data.timeZoneId}>{data.lang1}</option>
                  ))}
              </select>
              {classDTORegisterUser && classDTORegisterUser.tblTimeZoneError ? (
                <label className="error">
                  {classDTORegisterUser.tblTimeZoneError}
                </label>
              ) : (
                ""
              )}
            </div>
          </div>

          <div class="NextPrev">
            <button
              class="btnNext"
              onClick={() => handleButtonsRegisterUser("submit")}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    );
  }
}
