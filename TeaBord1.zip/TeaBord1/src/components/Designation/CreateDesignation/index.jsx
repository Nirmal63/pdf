import { data, event } from "jquery";
import React, { Component } from "react";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import TreeStructureView from "../../../components/GenericComponents/TreeStructureView";

export default class index extends Component {
  render() {
    const {
      handleClassDTODesignation,
      handleButtonsDesignation,
      classDTOCreateDesignation,
      getAllDepartmentDetailsResponse,
      getAllDesignationDetailsResponse,
      getAllGradeDetailsResponse,
    } = this.props;
    return (
      <div>
        <h2 class="Title">Create Designation</h2>
        <div class="CreateClient ShadowBox">
          <div class="row g-3">
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Department*</label>
              <TreeStructureView
                responseData={getAllDepartmentDetailsResponse}
                handleClassDTO={handleClassDTODesignation}
                classDTO={classDTOCreateDesignation}
                classDTOKey="deptId"
                divIdName="childDivDepartmentDepartment"
                iconIdName="chilIconDepartmentDepartment"
                departmentTreeChildDivMargin={"departmentTreeChildDivMargin"}
                iconIdMarginAvailable={false}
                liName="departmentTree"
                inputId="BidderwiseformdisplayDep-"
                inputName="BidderwiseformdisplayDep"
              />

              {classDTOCreateDesignation &&
              classDTOCreateDesignation.deptIdError ? (
                <label className="error">
                  {classDTOCreateDesignation.deptIdError}
                </label>
              ) : (
                ""
              )}
            </div>
            <div class="col-xl-3 col-lg-6 col-md-6 col-12">
              <label class="LabelText">Parent Designation</label>
              <TreeStructureView
                responseData={getAllDesignationDetailsResponse}
                handleClassDTO={handleClassDTODesignation}
                classDTO={classDTOCreateDesignation}
                classDTOKey="parentDesignationId"
                divIdName="childDivDesignation"
                iconIdName="chilIconDesignation"
                designationTreeChildDivMargin={"designationTreeChildDivMargin"}
                iconIdMarginAvailable={false}
                liName="designationTree"
                inputId="BidderwiseformdisplayDes-"
                inputName="BidderwiseformdisplayDes"
                disabled={
                  isNullOrIsEmptyOrIsUndefined(getAllDesignationDetailsResponse)
                    ? true
                    : false
                }
              />
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Designation*</label>
              <input
                type="text"
                class="form-control"
                name="designationName"
                maxlength="50"
                onChange={(event) =>
                  handleClassDTODesignation(
                    event.target.name,
                    event.target.value
                  )
                }
                value={
                  classDTOCreateDesignation &&
                  classDTOCreateDesignation.designationName
                }
              />
              {classDTOCreateDesignation &&
              classDTOCreateDesignation.designationNameError ? (
                <label className="error">
                  {classDTOCreateDesignation.designationNameError}
                </label>
              ) : (
                ""
              )}
            </div>
            <div class="col-xl-3 col-lg-4 col-md-6 col-12">
              <label class="LabelText">Grade*</label>
              <select
                class="form-select"
                aria-label="Default select example"
                name="gradeId"
                value={
                  (classDTOCreateDesignation &&
                    classDTOCreateDesignation.gradeId) ||
                  ""
                }
                onChange={(event) =>
                  handleClassDTODesignation(
                    event.target.name,
                    event.target.value
                  )
                }
              >
                <option value="">Please Select</option>
                {getAllGradeDetailsResponse &&
                  getAllGradeDetailsResponse.map((data, index) => (
                    <option value={data.gradeId}>{data.gradeName}</option>
                  ))}
              </select>
              {classDTOCreateDesignation &&
              classDTOCreateDesignation.gradeIdError ? (
                <label className="error">
                  {classDTOCreateDesignation.gradeIdError}
                </label>
              ) : (
                ""
              )}
            </div>

            {classDTOCreateDesignation &&
            !isNullOrIsEmptyOrIsUndefined(classDTOCreateDesignation.gradeId) ? (
              <>
                <div></div>
                {getAllGradeDetailsResponse &&
                  getAllGradeDetailsResponse.map((data, index) => {
                    if (data.gradeId == classDTOCreateDesignation.gradeId) {
                      return (
                        <div class="col-xl-3 col-lg-6 col-md-6 col-12">
                          <label class="LabelText">Financial Limit</label>
                          <input
                            type="text"
                            class="form-control"
                            value={data.minLimit + "-" + data.maxLimit}
                            disabled={true}
                          />
                        </div>
                      );
                    }
                  })}
              </>
            ) : (
              ""
            )}
          </div>

          <div class="submit">
            <button
              class="BlueButton m-auto mt-5"
              onClick={() => handleButtonsDesignation("submit")}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    );
  }
}
