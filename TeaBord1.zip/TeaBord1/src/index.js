import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import "./index.css";
import { Provider } from "react-redux";
import { store } from "./store/index";

export const app = {
  cssRetries: 0,
  fetchRetries: 0,

  run() {
    this.render(App);

    /* istanbul ignore else */
  },

  render(Component) {
    const root = document.getElementById("root");
    /* istanbul ignore next */
    if (root) {
      ReactDOM.render(
        <Provider store={store}>
          <Component />
        </Provider>,
        root
      );
    }
  },
};

app.run();
