import React, { Component } from "react";
import logo from "./logo.svg";
import "./App.css";
import History from "./utility/history-utils";
import { store } from "./store/index";
import { Switch, Route, BrowserRouter } from "react-router-dom";
import { ActionTypes } from "./containers/Home/constants";
import * as actions from "./containers/Home/actions";
import * as selectors from "./containers/Home/selectors";
import UserSaga from "./containers/Home/sagas";
import UserReducer from "./containers/Home/reducer";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import { createStructuredSelector } from "reselect";
import { connect } from "react-redux";
import { compose } from "redux";
import HomeContainer from "./containers/Home";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

class App extends Component {
  componentDidMount() {
    this.props.updateIsAuthenticated(false);
  }

  render() {
    return (
      <BrowserRouter history={History} store={store}>
        <React.Fragment>
          <Switch>
            <Route
              render={(props) => <HomeContainer {...props} {...this.props} />}
              path="/"
            />
          </Switch>
        </React.Fragment>
      </BrowserRouter>
    );
  }
}

function mapStateToProps(state) {
  return createStructuredSelector({
    isAuthenticated: selectors.getIsAuthenticated(),
  });
}

function mapDispatchToProps(dispatch) {
  return {
    updateIsAuthenticated: (value) => {
      dispatch(actions.updateIsAuthenticated(value));
    },
  };
}

const withReducer = injectReducer({ key: "user", reducer: UserReducer });
const withConnect = connect(mapStateToProps, mapDispatchToProps);
const withSaga = injectSaga({ key: "user", saga: UserSaga });

export default compose(withReducer, withSaga, withConnect)(App);
