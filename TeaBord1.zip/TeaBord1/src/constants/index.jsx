import keyMirror from "fbjs/lib/keyMirror";

export const ActionTypes = keyMirror({
  FETCH_INITIATED: undefined,
  FETCH_COMPLETED: undefined,
  UNAUTHENTICATED_REQUEST: undefined,
  BUSINESS_EXCEPTION: undefined,
});
