      if(categoryData.get("type") == 'system'){
         var complaints = filterByCategory(ownCaseData, "complaint");
         var items = complaints.get("items").filter() 
         var updatedComplaints = complaints.set("items", items);
         ownCaseData = updateCategory(ownCaseData, complaints, updatedComplaints);
      }

      if(categoryData.get("type") == 'complaint'){
         var casehistory = filterByCategory(ownCaseData, "casehistory");
         var items = casehistory.get("items").filter() 
         var updatedCasehistory = casehistory.set("items", items);
         ownCaseData = updateCategory(ownCaseData, casehistory, updatedCasehistory); 
      }