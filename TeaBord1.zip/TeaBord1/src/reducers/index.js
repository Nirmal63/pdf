import user from "../containers/Home/reducer";

export default {
  ...user,
};
