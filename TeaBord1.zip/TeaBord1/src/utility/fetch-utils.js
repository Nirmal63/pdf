import fetchDefaults from "fetch-defaults";
import FetchInterceptor from "./fetch-interceptor";
import { store } from "../store/index";
import * as configConstants from "../commonConstants/configConstants";
import * as constants from "../commonConstants/constants";
// import * as ErrorConstant from "../Constant/ErrorConstants";
import {
  getUnauthenticatedRequestAction,
  getFetchCompletedAction,
  getFetchRequestedAction,
} from "../actions/loading";
import { getBusinessException } from "../actions/loading";
import { isNullOrIsEmptyOrIsUndefined } from "../commonConstants/CommonValidator";
import { getLocalStorageItem } from "../commonConstants/LocalStorageData";

const fetchInProgress = [];
// Register interceptor hooks
const interceptor = FetchInterceptor.register({
  onBeforeRequest(request, controller) {
    fetchInProgress.push(1);
    // store.dispatch(getFetchRequestedAction());
  },
  onRequestSuccess(response, request, controller) {
    //
    hideProgressBar();
  },
  onRequestFailure(response, request, controller) {
    hideProgressBar();
  },
  noInternetConnection(exception) {
    store.dispatch(
      getBusinessException({ recoverable: false, errorCode: "NO-INTERNET" })
    );
    hideProgressBar();
  },
  retryRequest(request) {
    return apiFetch(request);
  },
});

const dispatchException = (response, errorAction, recoverable) => {
  try {
    const result = response.json();
    response.json = function () {
      return result;
    };
    result.then((item) => {
      item.recoverable = recoverable;
      store.dispatch(errorAction(item));
    });
  } catch (e) {}
};

const hideProgressBar = () => {
  fetchInProgress.pop();
  if (fetchInProgress.length == 0) {
    setTimeout(() => {
      store.dispatch(getFetchCompletedAction());
    }, 300);
  }
};

const api = { url: configConstants.SERVER_ADDR };
export const initApi = function (url) {
  if (url) api.url = url;
};
// const setServerNo = function (url) {
//   return url
//     .replace("api/", "api" + getServerNo() + "/")
//     .replace("salarySlips/", "salarySlips" + getServerNo() + "/")
//     .replace("document/", "document" + getServerNo() + "/");
// };
export const updateURL = function (url) {
  let originalURL = url;
  if (configConstants.REQUEST_ENCRYPTION) {
    var preURL = "";
    if (url.indexOf("http") != -1) {
      var splitURL = url.split("/");
      preURL = splitURL.splice(0, 3).join("/");
      url = splitURL.join("/");
    }
    var suburl = url.substring(url.indexOf("/") + 1);
    if (url.indexOf("?") != -1) {
      suburl = url.substring(url.indexOf("/") + 1, url.indexOf("?"));
    }

    suburl = btoa(suburl);
    suburl =
      suburl.substring(0, 5) +
      suburl
        .substring(5, suburl.length - 5)
        .split("")
        .reverse()
        .join("") +
      suburl.substring(suburl.length - 5);
    if (url.indexOf("?") != -1) {
      url =
        url.substring(0, url.indexOf("/") + 1) +
        encodeURIComponent(suburl) +
        url.substring(url.indexOf("?"));
    } else {
      url = url.substring(0, url.indexOf("/") + 1) + encodeURIComponent(suburl);
    }
    if (preURL != "") {
      url = preURL + "/" + url;
    }
    // if (constants.RESET_USER_DTO_API_URL != originalURL) {
    //   url = setServerNo(url);
    // }
  }
  return url;
};

const onRequestFailureHandle = (response, url) => {
  //added code here from onRequestFailure()
  //426 used for version mismatch
  //405 used for access denied
  //401 used for auth fail
  if (
    (url == configConstants.SERVER_ADDR + "api/auth/signin" ||
      url == configConstants.SERVER_ADDR + "api/auth/signin") &&
    (response.status == 401 || response.status == 403)
  ) {
    store.dispatch(getUnauthenticatedRequestAction());
  } else if (response.status == 400) {
    // dispatchException(response, getBusinessException, true);
  } else if (response.status == 401) {
    response.json().then((data) => {
      if (
        data.message &&
        "Full authentication is required to access this resource" ==
          data.message
      ) {
        store.dispatch(
          getBusinessException({ recoverable: false, errorCode: 4001 })
        );
      }
    });
  } else if (response.status == 500) {
    store.dispatch(
      getBusinessException({ recoverable: false, errorCode: 9999 })
    );
  }
};

let domainName = window.location.hostname;
let postUrl = `common/unauth/checkclient/${domainName}`;
export const checkClientDomain = async (url, data) => {
  const promise = apiFetch1(postUrl, data, configConstants.REQUEST_ENCRYPTION);

  let httpObj = {};
  let responseObj = {};
  if (configConstants.REQUEST_ENCRYPTION) {
    responseObj = await promise.then((value) => {
      httpObj = value.clone();
      return value.text();
    });
  } else {
    let valueOfPromise = await promise.then((value) => {
      httpObj = value.clone();
      return value;
    });
    try {
      responseObj = await valueOfPromise.json();
    } catch (exception) {
      responseObj = null;
    }
  }
  // console.log("responseObj125 : " + JSON.stringify(responseObj));
  if (!isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("clientId"))) {
    // console.log("clientId : " + getLocalStorageItem("clientId"));
    // console.log("clientIdWith clientId : " + responseObj.responseData);
    if (getLocalStorageItem("clientId") == responseObj.responseData) {
      return true;
    } else {
      return false;
    }
  }
};

export const apiFetch = async (url, data) => {
  let data1 = await checkClientDomain();
  // console.log("data1:::" + data1);
  if (data1 == true) {
    const promise = apiFetch1(url, data, configConstants.REQUEST_ENCRYPTION);
    let httpObj = {};
    let responseObj = {};
    if (configConstants.REQUEST_ENCRYPTION) {
      responseObj = await promise.then((value) => {
        httpObj = value.clone();
        return value.text();
      });
    } else {
      let valueOfPromise = await promise.then((value) => {
        httpObj = value.clone();
        return value;
      });
      try {
        responseObj = await valueOfPromise.json();
      } catch (exception) {
        responseObj = null;
      }
    }

    let options = {
      headers: httpObj.headers,
      status: httpObj.status,
      statusText: httpObj.statusText,
    };
    let response = new Response(
      (responseObj && JSON.stringify(responseObj)) || undefined,
      options
    );

    Object.defineProperty(response, "url", { value: httpObj.url });
    Object.defineProperty(response, "redirected", {
      value: httpObj.redirected,
    });
    Object.defineProperty(response, "type", { value: httpObj.type });
    Object.defineProperty(response, "bodyUsed", { value: httpObj.bodyUsed });
    Object.defineProperty(response, "ok", { value: httpObj.ok });
    onRequestFailureHandle(response, url);
    // console.log("response 194", response);
    return Promise.resolve(response);
  } else {
    localStorage.removeItem("token");
    localStorage.removeItem("clientId");
    localStorage.removeItem("userId");
    localStorage.removeItem("usertypeId");
    // window.location.href = "/dashboard";
    if (window.location.href && !window.location.href.includes("dashboard")) {
      window.location.href = "/dashboard";
    }
  }
};

export const apiFetch1 = function (url, data, encryptResponse) {
  const promise = new Promise((resolve, reject) => {
    const serverUrl = api.url;
    let logUrl = url;
    url = updateURL(url);
    if (configConstants.REQUEST_ENCRYPTION) {
      if (
        data.method.toLowerCase() == "post" ||
        data.method.toLowerCase() == "put" ||
        data.method.toLowerCase() == "delete"
      ) {
        data.body = data.body.toString();
      }
    }
    const start = new Date();
    fetchDefaults(
      window.fetch,
      serverUrl,
      {
        headers: getAuthHeader(encryptResponse),
      }
      // null
    )(url, data).then((response) => {
      // console.log("response 218", response);
      resolve(response);
    });
  });
  return promise;
};

function getAuthHeader(encryptResponse) {
  var headers = {
    encryptResponse: encryptResponse,
    "Content-type": "application/json",
    "Access-Control-Allow-Origin": "*",
  };

  if (!isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("token"))) {
    headers["Authorization"] = ` Bearer ${getLocalStorageItem("token")}`;
  }

  // if (!isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("userId"))) {
  //   headers["UserId"] = getLocalStorageItem("userId");
  // }

  // if (!isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("usertypeId"))) {
  //   headers["UsertypeId"] = getLocalStorageItem("usertypeId");
  // }

  //  if (!isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("clientId"))) {
  //      //headers["clientId"] = getLocalStorageItem("clientId");
  //  }

  // headers["emailId"] = ``;
  // headers["ipAddress"] = ``;
  // headers["ConversionValue"] = `103`;

  return headers;
}

const fetchClientIP = async () => {
  // try {
  //   const response = await fetch("https://api.ipify.org?format=json");
  //   const data = await response.json();
  //   console.log("hello 251", data);
  //   console.log("hello 252", data.ip);
  // } catch (error) {
  //   console.error("Error fetching client IP:", error);
  // }
};

/**
 * The FetchInterceptor class
 */
