import { isNull, isNullOrUndefined } from "util";
export function showRequiredFieldValidation(
  fixedKey,
  currentKey,
  currentProps,
  currentObject
) {
  if (
    !isNullOrUndefined(fixedKey) &&
    !isNullOrUndefined(currentKey) &&
    !isNullOrUndefined(currentProps) &&
    !isNullOrUndefined(currentObject)
  ) {
    currentProps.map((data, idx) => {
      data.error[currentObject] = "Please enter " + currentKey;
      return { ...data };
    });
  }
}
