import * as ErrorConstant from '../Constant/ErrorConstants';

const ERRORS_MESSAGES = {  
  401:'Invalid UserName Password',
  400:'Invalid UserName Password',
  404:'Invalid UserName Password',
  9999:'The task you are trying to perform is temporarily unavailable. Kindly contact administrator.',
  4001:ErrorConstant.SESSION_EXPIRE,
  "NO-INTERNET":ErrorConstant.NO_INTERNET_TITLE,
  "4260-web":ErrorConstant.INVALID_WEB_VERSION_TITLE,
  "4260-1-web":ErrorConstant.INVALID_WEB_NEW_VERSION_OLD_VERSION_REQUIRED_TITLE,
  "4260-2-web":ErrorConstant.INVALID_WEB_VERSION_NOT_FOUND_TITLE,
  "4260-android":ErrorConstant.INVALID_ANDROID_VERSION_NEW_VERSION_REQUIRED_TITLE,
  "4260-1-android":ErrorConstant.INVALID_ANDROID_NEW_VERSION_OLD_VERSION_REQUIRED_TITLE,
  "4260-2-android":ErrorConstant.INVALID_ANDROID_VERSION_NOT_FOUND_TITLE,
  "4260-ios":ErrorConstant.INVALID_IOS_VERSION_TITLE,
  "4260-1-ios":ErrorConstant.INVALID_IOS_NEW_VERSION_OLD_VERSION_REQUIRED_TITLE,
  "4260-2-ios":ErrorConstant.INVALID_IOS_VERSION_NOT_FOUND_TITLE,
  "405-not-allowed":ErrorConstant.NOT_ALLWED_TO_ACCESS_YOUR_ACCOUNT_TITLE,
};

export function getResponseError(serverErrorResponse) {
  
  var errorPlaceHolder;  
  if(4001===serverErrorResponse.errorCode || 
    '4260-web'===serverErrorResponse.errorCode ||
    '4260-1-web'===serverErrorResponse.errorCode ||
    '4260-2-web'===serverErrorResponse.errorCode ||
    '4260-android'===serverErrorResponse.errorCode ||
    '4260-1-android'===serverErrorResponse.errorCode ||
    '4260-2-android'===serverErrorResponse.errorCode ||
    '4260-ios'===serverErrorResponse.errorCode ||
    '4260-1-ios'===serverErrorResponse.errorCode ||
    '4260-2-ios'===serverErrorResponse.errorCode ||
    '405-not-allowed'===serverErrorResponse.errorCode ||
    'NO-INTERNET'===serverErrorResponse.errorCode ||
    9999===serverErrorResponse.errorCode){         
    errorPlaceHolder=ERRORS_MESSAGES[serverErrorResponse.errorCode];
  }else{    
    errorPlaceHolder=ERRORS_MESSAGES[serverErrorResponse.code];
  }  
  return errorPlaceHolder.replace(/%\w+%/g, all => serverErrorResponse[all.substring(1, all.length - 1)] || all);
}

export const consumeException = action => {
  action.consumed = true;
};

export const isConsumed = action => action.consumed;
