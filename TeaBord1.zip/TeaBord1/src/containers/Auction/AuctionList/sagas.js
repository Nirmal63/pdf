import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { apiFetch } from "../../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../../commonConstants/constants";
import { CustomToast as toast } from "../../../components/GenericComponents/Toast";
// import { loadingInterceptor } from "../../../components/GenericComponents/Loader";
import { loadingInterceptor } from "../../../utility/loading-interceptor";

export function* getLiveAuctionDetails({ payload }) {
  let response = yield apiFetch(`eauction/auctioneer/live`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.GET_LIVE_AUCTION_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_LIVE_AUCTION_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAuctionDetailsWithStatus({ payload }) {
  let response = yield apiFetch(
    `eauction/auctioneer/search/${payload.data.userId}/${payload.data.cstatus}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.GET_AUCTION_DETAILS_WITH_STATUS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_AUCTION_DETAILS_WITH_STATUS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.GET_LIVE_AUCTION_DETAILS,
      loadingInterceptor,
      getLiveAuctionDetails
    ),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_AUCTION_DETAILS_WITH_STATUS,
      loadingInterceptor,
      getAuctionDetailsWithStatus
    ),
  ]);
}
