import { ActionTypes } from "./constants";

const initialState = {};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.GET_LIVE_AUCTION_DETAILS_SUCCESS: {
      state.getLiveAuctionDetails = action.payload.value;
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_AUCTION_DETAILS_WITH_STATUS_SUCCESS: {
      state.getAuctionDetailsWithStatus = action.payload.value;
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
