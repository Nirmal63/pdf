import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import AuctionListCompoenent from "../../../components/Auction/AuctionList";

class index extends Component {
  render() {
    return <AuctionListCompoenent {...this.props} />;
  }
}

function mapDispatchToProps(dispatch) {
  return {
    getLiveAuctionDetails: (payload) => {
      dispatch(actions.getLiveAuctionDetails(payload));
    },

    getAuctionDetailsWithStatus: (payload) => {
      dispatch(actions.getAuctionDetailsWithStatus(payload));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    getLiveAuctionDetailsResponse: selectors.getLiveAuctionDetails(),
    getAuctionDetailsWithStatusResponse:
      selectors.getAuctionDetailsWithStatus(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
