import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "liveAuction";

export const ActionTypes = keyMirrorRecursive(
  {
    GET_LIVE_AUCTION_DETAILS: undefined,
    GET_LIVE_AUCTION_DETAILS_SUCCESS: undefined,
    GET_AUCTION_DETAILS_WITH_STATUS: undefined,
    GET_AUCTION_DETAILS_WITH_STATUS_SUCCESS: undefined,
  },
  pageName
);
