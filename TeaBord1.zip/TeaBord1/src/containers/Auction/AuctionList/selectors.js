import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getLiveAuctionDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getLiveAuctionDetails);

export const getAuctionDetailsWithStatus = () =>
  createSelector(stateSelector, (bstate) => bstate.getAuctionDetailsWithStatus);
