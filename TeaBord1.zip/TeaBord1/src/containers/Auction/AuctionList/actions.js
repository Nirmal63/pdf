import { ActionTypes } from "./constants";

export function getLiveAuctionDetails(data) {
  return {
    type: ActionTypes.GET_LIVE_AUCTION_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function getAuctionDetailsWithStatus(data) {
  return {
    type: ActionTypes.GET_AUCTION_DETAILS_WITH_STATUS,
    payload: {
      data: data,
    },
  };
}
