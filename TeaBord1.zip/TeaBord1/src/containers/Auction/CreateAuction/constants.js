import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "createAuction";

export const ActionTypes = keyMirrorRecursive(
  {
    UPDATE_CLASS_DTO_CREATE_AUCTION: undefined,
    SUBMIT_CREATE_AUCTION_DETAILS: undefined,
    SUBMIT_CREATE_AUCTION_DETAILS_SUCCESS: undefined,
    GET_ALL_FIELDS_DETAILS: undefined,
    GET_ALL_FIELDS_DETAILS_SUCCESS: undefined,
    GET_ALL_CURRENCY_DETAILS: undefined,
    GET_ALL_CURRENCY_DETAILS_SUCCESS: undefined,
    GET_ALL_DEPARTMENT_DETAILS: undefined,
    GET_ALL_DEPARTMENT_DETAILS_SUCCESS: undefined,
    GET_ALL_OFFICER_DETAILS: undefined,
    GET_ALL_OFFICER_DETAILS_SUCCESS: undefined,
  },
  pageName
);

export const YES_NO_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const SHOW_HIDE_VALUES = [
  {
    displayKey: "Show",
    value: 1,
  },
  {
    displayKey: "Hide",
    value: 0,
  },
];

export const NOT_REQUIRED_AUTO_MANUAL_VALUES = [
  {
    displayKey: "Not Required",
    value: 0,
  },
  {
    displayKey: "Auto",
    value: 1,
  },
  {
    displayKey: "Manual",
    value: 2,
  },
];

export const TYPE_OF_CONTRACT_VALUES = [
  {
    displayKey: "Goods",
    value: 1,
  },
  {
    displayKey: "Service",
    value: 2,
  },
  {
    displayKey: "Work",
    value: 3,
  },
  {
    displayKey: "Turnkey Project",
    value: 4,
  },
  {
    displayKey: "Other",
    value: 5,
  },
];

export const BIDDING_ACCESS_VALUES = [
  {
    displayKey: "Open",
    value: 1,
  },
  {
    displayKey: "Limited",
    value: 2,
  },
];

export const BIDDING_TYPE_VALUES = [
  {
    displayKey: " NCB/Domestic",
    value: 1,
  },
  {
    displayKey: "ICB/Global",
    value: 2,
  },
];

export const AUCTION_VARIANT_VALUES = [
  {
    displayKey: "Forward Auction",
    value: 1,
  },
  {
    displayKey: "Reverse Auction",
    value: 2,
  },
];

export const STANDARD_RANK_VALUES = [
  {
    displayKey: "Standard",
    value: 1,
  },
  {
    displayKey: "Rank",
    value: 2,
  },
];

export const BID_SUBMISSION_FOR_VALUES = [
  {
    displayKey: "Grand Total",
    value: 1,
  },
  {
    displayKey: "Each Line Item",
    value: 2,
  },
  {
    displayKey: "Each Line Item And Grand Total",
    value: 3,
  },
];

export const INC_DEC_VALUE_RUE_VALUES = [
  {
    displayKey: "Increment in one or more items",
    value: 1,
  },
  {
    displayKey: "Increment in all items",
    value: 2,
  },
];

export const ALLOW_DONT_ALLOW_VALUES = [
  {
    displayKey: "Allow",
    value: 1,
  },
  {
    displayKey: "Don't Allow",
    value: 0,
  },
];

export const BIDDING_FORM_VALUES = [
  {
    displayKey: "Use Standard Form",
    value: 1,
  },
  {
    displayKey: "Create New Form",
    value: 2,
  },
];

export const AUTO_EXTENSION_MODE_VALUES = [
  {
    displayKey: "Limited extensions",
    value: 1,
  },
  {
    displayKey: "Unlimited extensions",
    value: 2,
  },
];

export const FIRST_BID_ACCEPT_CONDITION_VALUES = [
  {
    displayKey: "Accept Start Price",
    value: 1,
  },
  {
    displayKey: "Accept Start Price + Increment/Decrement Value",
    value: 2,
  },
];

export const ACCEPT_DECIMAL_VALUES_UPTO_VALUES = [
  {
    displayKey: "1",
    value: 1,
  },
  {
    displayKey: "2",
    value: 2,
  },
  {
    displayKey: "3",
    value: 3,
  },
  {
    displayKey: "4",
    value: 4,
  },
  {
    displayKey: "5",
    value: 5,
  },
];

export const DISPLAY_WINNING_BID_VALUES = [
  {
    displayKey: "Before Bid Submission",
    value: 1,
  },
  {
    displayKey: "After bid submission",
    value: 2,
  },
];

export const NOT_REQUIRED_EVENT_ITEM_WISE_VALUES = [
  {
    displayKey: "Not Required",
    value: 0,
  },
  {
    displayKey: "Event Wise",
    value: 1,
  },
  {
    displayKey: "Item Wise",
    value: 2,
  },
];

export const ACCEPT_DONT_ACCEPT_SAME_AMOUNT_VALUES = [
  {
    displayKey: "Accept Same amount",
    value: 0,
  },
  {
    displayKey: "Don’t accept same amount",
    value: 1,
  },
];

export const ANY_ALL_ITEM_VALUES = [
  {
    displayKey: "Any Item",
    value: 1,
  },
  {
    displayKey: "All Item",
    value: 2,
  },
];

export const REQUIRED_NOT_REQUIRED_VALUES = [
  {
    displayKey: "Required",
    value: 1,
  },
  {
    displayKey: "Not Required",
    value: 2,
  },
];
