import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";

import { apiFetch } from "../../../utility/fetch-utils";
import {
  ERROR_MESSAGE_FOR_DEFAULT,
  ERROR_MESSAGE_FOR_400,
} from "../../../commonConstants/constants";
import { CustomToast as toast } from "../../../components/GenericComponents/Toast";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

export function* submitCreateAuctionDetails({ payload }) {
  let response = yield apiFetch("eauction/auctioneer/create", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      toast.success(responseJSON.message);
      var responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.SUBMIT_CREATE_AUCTION_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
      window.location.href = "/auctionList";
    } else {
      toast.error(responseJSON.message);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_CREATE_AUCTION_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else if (400 === response.status) {
    toast.error(ERROR_MESSAGE_FOR_400);
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllFieldsDetails({ payload }) {
  let response = yield apiFetch(
    `eauction/auctioneer/aucfield/${payload.eventId}/${payload.modelId}/${payload.clientId}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_FIELDS_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_FIELDS_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllCurrencyDetails() {
  let response = yield apiFetch(`common/currency/getAllCurrency`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_CURRENCY_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_CURRENCY_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllDepartmentDetails() {
  // clientId
  let response = yield apiFetch(
    `common/dept/getdepthierarchy/${getLocalStorageItem("clientId")}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    yield put({
      type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: responseJSON,
      },
    });

    // if (200 === responseJSON.statusCode) {
    //   let responseObj = responseJSON || {};
    //   yield put({
    //     type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
    //     payload: {
    //       value: responseObj.responseData,
    //     },
    //   });
    // } else {
    //   // toast.error(
    //   //   responseJSON.message ||ERROR_MESSAGE_FOR_DEFAULT
    //   // );
    // }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllOfficerDetails({ payload }) {
  let response = yield apiFetch(
    `common/getofficer/${payload.departmentId}/${payload.clientId}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_OFFICER_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_OFFICER_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_CREATE_AUCTION_DETAILS,
      submitCreateAuctionDetails
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_FIELDS_DETAILS, getAllFieldsDetails),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_CURRENCY_DETAILS, getAllCurrencyDetails),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_DEPARTMENT_DETAILS, getAllDepartmentDetails),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_OFFICER_DETAILS, getAllOfficerDetails),
  ]);
}
