import { ActionTypes } from "./constants";

const initialState = {
  classDTOCreateAuction: {
    // tblDepartment: "",
    // userDetailsId: 1,
    // auctionNo: "",
    // displayOfficerName: 1,
    // auctionBrief: "",
    // auctionDetail: "",
    // procurementNatureId: 0,
    // documentFee: "",
    // participationFee: "",
    // formContract: 1,
    // auctionMode: 2,
    // biddingForm: 0,
    // brdMode: 0,
    // biddingType: 1,
    // eventTypeId: 1,
    // typeOfAuction: 2,
    // showRank: 1,
    // isBidderNameMasking: 1,
    // checkReservePrice: 0,
    // auctionResult: 2,
    // isMinQtyReq: 0,
    // isItemSelection: 0,
    // isItemWiseTime: 0,
    // isBidPriceIncDecInTimesReq: 1,
    // noOfBidRestriction: 1,
    // resultSharingForSpecificDuration: 1,
    // resultSharingDuration: 0,
    // shareL1H1AfterAuc: 0,
    // isEncodedName: 1,
    // biddingForm: 2,
    // isDecodeBidder: 1,
    // isIncDecInPeriod: 1,
    // durationToDisplayL1H1: 0,
    // isAutoExt: 1,
    // extMode: 2,
    // extendWhen: 10,
    // extendBy: 10,
    // firstBidCond: 2,
    // decimalValueUpto: 5,
    // showWinningBid: 1,
    // showWinnerName: 0,
    // isBidderWiseStartPrice: 1,
    // isCertRequired: 0,
    // isDemoAuction: 1,
    // greaterRank: 0,
    // isEvaluationReq: 1,
    // showIpAddress: 1,
    // isEmdReq: 0,
    // forHomePage: 1,
    // isRegistrationCharges: 0,
    // breakPriceBid: 1,
    // isResultApiRequired: 0,
    // isHideLiveBidToOfficer: 0,
    // borrowerName: "",
    // rankLogic: 0,
    // showWinAmountOnListing: 1,
    // showLastBid: 1,
  },
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.UPDATE_CLASS_DTO_CREATE_AUCTION: {
      state.classDTOCreateAuction = action.payload.data || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_FIELDS_DETAILS_SUCCESS: {
      state.getAllFieldsDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_CURRENCY_DETAILS_SUCCESS: {
      state.getAllCurrencyDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS: {
      state.getAllDepartmentDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_OFFICER_DETAILS_SUCCESS: {
      state.getAllOfficerDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
