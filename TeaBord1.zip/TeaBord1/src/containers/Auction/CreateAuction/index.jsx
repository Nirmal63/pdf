import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import CreateAuctionComponent from "../../../components/Auction/CreateAuction";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import $ from "jquery";
import moment from "moment";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

class index extends Component {
  componentDidMount() {
    let data = {
      eventId: 1,
      modelId: 5,
      clientId: getLocalStorageItem("clientId"),
    };
    this.props.getAllFieldsDetails(data);
    this.props.getAllDepartmentDetails();
    this.props.getAllCurrencyDetails();
  }

  handleClassDTOCreateAuction = (key, value) => {
    let { classDTOCreateAuction } = this.props;
    classDTOCreateAuction.isValidationSuccess = true;

    switch (key) {
      case "aucBaseCurr": {
        classDTOCreateAuction[key] = JSON.parse(value);
        let data = [];
        data.push(JSON.parse(value));

        let tempData =
          data &&
          data.map(
            (mapData, mapIndex) => (
              (mapData.exchangeRate = 0),
              (mapData.isDefault = 1),
              (mapData.tblCurrency = mapData.currencyId)
            )
          );

        classDTOCreateAuction.auctionCurrencyDtoSet = data;
        classDTOCreateAuction.defaultCurrency =
          classDTOCreateAuction.aucBaseCurr &&
          classDTOCreateAuction.aucBaseCurr.currencyId;
        break;
      }

      case "biddingType": {
        classDTOCreateAuction[key] = value;
        if (2 == value) {
          classDTOCreateAuction &&
            classDTOCreateAuction.auctionCurrencyDtoSet &&
            classDTOCreateAuction.auctionCurrencyDtoSet.map(
              (data, index) => (data.exchangeRate = 1)
            );
        }
      }

      default: {
        classDTOCreateAuction[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTOCreateAuction);
  };

  checkValidations = (key, data) => {
    let { classDTOCreateAuction, updateClassDTOCreateAuction } = this.props;

    classDTOCreateAuction = data;
    classDTOCreateAuction.isValidationSuccess = true;

    if ("tblDepartment" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateAuction.tblDepartment)) {
        classDTOCreateAuction.tblDepartmentError = "Please select";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.tblDepartmentError = "";
        if ("tblDepartment" === key) {
          let data = {
            departmentId: classDTOCreateAuction.tblDepartment,
            clientId: getLocalStorageItem("clientId"),
          };
          this.props.getAllOfficerDetails(data);
        }
      }
    }

    if ("auctioneerId" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateAuction.auctioneerId)) {
        classDTOCreateAuction.auctioneerIdError = "Please select";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.auctioneerIdError = "";
      }
    }

    if ("auctionNo" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateAuction.auctionNo)) {
        classDTOCreateAuction.auctionNoError = "Please enter";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.auctionNoError = "";
      }
    }

    // if (
    //   "displayOfficerName" === key ||
    //   "basicDetails" === key ||
    //   "all" === key
    // ) {
    //   if (
    //     isNullOrIsEmptyOrIsUndefined(classDTOCreateAuction.displayOfficerName)
    //   ) {
    //     classDTOCreateAuction.displayOfficerNameError = "Please select";
    //     classDTOCreateAuction.isValidationSuccess = false;
    //   } else {
    //     classDTOCreateAuction.displayOfficerNameError = "";
    //   }
    // }

    if ("auctionBrief" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateAuction.auctionBrief)) {
        classDTOCreateAuction.auctionBriefError = "Please enter";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.auctionBriefError = "";
      }
    }

    if ("auctionDetail" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateAuction.auctionDetail)) {
        classDTOCreateAuction.auctionDetailError = "Please enter";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.auctionDetailError = "";
      }
    }

    if ("startDate" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateAuction.startDate)) {
        classDTOCreateAuction.startDateError = "Please select";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.startDateError = "";
      }
    }

    if ("endDate" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateAuction.endDate)) {
        classDTOCreateAuction.endDateError = "Please select";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.endDateError = "";
      }
    }

    if (
      "keywordText" === key ||
      "generalConfiguration" === key ||
      "all" === key
    ) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateAuction.keywordText)) {
        classDTOCreateAuction.keywordTextError = "Please enter";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.keywordTextError = "";
      }
    }

    updateClassDTOCreateAuction(classDTOCreateAuction);
  };

  handleButtonsCreateAuction = (name, value) => {
    var { classDTOCreateAuction } = this.props;

    switch (name) {
      case "submit": {
        this.checkValidations("all", classDTOCreateAuction);
        if (classDTOCreateAuction.isValidationSuccess) {
          if (1 == classDTOCreateAuction.auctionResult) {
            classDTOCreateAuction.auctionCriteriaDto = {
              startPrice: classDTOCreateAuction.startPrice,
              reservePrice: classDTOCreateAuction.reservePrice,
              incDecValue: classDTOCreateAuction.incDecValue,
            };
          } else {
            classDTOCreateAuction.auctionCriteriaDto = null;
          }

          if (
            classDTOCreateAuction.biddingType &&
            2 == classDTOCreateAuction.biddingType
          ) {
            classDTOCreateAuction.currencyList1 &&
              classDTOCreateAuction.currencyList1.map((mapData, mapIndex) =>
                classDTOCreateAuction.auctionCurrencyDtoSet.push(mapData)
              );
          }

          classDTOCreateAuction.startDate =
            classDTOCreateAuction.startDate &&
            moment(classDTOCreateAuction.startDate).format(
              "DD-MM-YYYY HH:mm:ss"
            );

          classDTOCreateAuction.endDate =
            classDTOCreateAuction.endDate &&
            moment(classDTOCreateAuction.endDate).format("DD-MM-YYYY HH:mm:ss");

          this.props.submitCreateAuctionDetails(classDTOCreateAuction);
        }
        break;
      }

      case "prevButton": {
        $(".nav > .active").prev("li").find("button").trigger("click");
        break;
      }

      case "nextButton": {
        this.checkValidations(value, classDTOCreateAuction);
        if (classDTOCreateAuction.isValidationSuccess) {
          $(".nav > .active").next("li").find("button").trigger("click");
        }
        break;
      }

      default: {
        break;
      }
    }
  };

  componentWillUnmount() {
    let data = {};
    this.props.updateClassDTOCreateAuction(data);
  }

  render() {
    return (
      <CreateAuctionComponent
        {...this.props}
        handleClassDTOCreateAuction={this.handleClassDTOCreateAuction}
        handleButtonsCreateAuction={this.handleButtonsCreateAuction}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    updateClassDTOCreateAuction: (payload) => {
      dispatch(actions.updateClassDTOCreateAuction(payload));
    },

    submitCreateAuctionDetails: (payload) => {
      dispatch(actions.submitCreateAuctionDetails(payload));
    },

    getAllFieldsDetails: (payload) => {
      dispatch(actions.getAllFieldsDetails(payload));
    },

    getAllCurrencyDetails: () => {
      dispatch(actions.getAllCurrencyDetails());
    },

    updateGetAllCurrencyDetailsResponse: (data) => {
      dispatch(actions.updateGetAllCurrencyDetailsResponse(data));
    },

    getAllDepartmentDetails: () => {
      dispatch(actions.getAllDepartmentDetails());
    },

    getAllOfficerDetails: (payload) => {
      dispatch(actions.getAllOfficerDetails(payload));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTOCreateAuction: selectors.getClassDTOCreateAuction(),
    getAllFieldsDetailsResponse: selectors.getAllFieldsDetails(),
    getAllCurrencyDetailsResponse: selectors.getAllCurrencyDetails(),
    getAllDepartmentDetailsResponse: selectors.getAllDepartmentDetails(),
    getAllOfficerDetailsResponse: selectors.getAllOfficerDetails(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
