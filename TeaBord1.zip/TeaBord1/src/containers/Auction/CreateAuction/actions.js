import { ActionTypes } from "./constants";

export function updateClassDTOCreateAuction(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_CREATE_AUCTION,
    payload: {
      data: payload,
    },
  };
}

export function submitCreateAuctionDetails(data) {
  return {
    type: ActionTypes.SUBMIT_CREATE_AUCTION_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function getAllFieldsDetails(payload) {
  return {
    type: ActionTypes.GET_ALL_FIELDS_DETAILS,
    payload,
  };
}

export function getAllCurrencyDetails() {
  return {
    type: ActionTypes.GET_ALL_CURRENCY_DETAILS,
  };
}

export function updateGetAllCurrencyDetailsResponse(payload) {
  return {
    type: ActionTypes.GET_ALL_CURRENCY_DETAILS_SUCCESS,
    payload: {
      value: payload,
    },
  };
}

export function getAllDepartmentDetails() {
  return {
    type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS,
  };
}

export function getAllOfficerDetails(payload) {
  return {
    type: ActionTypes.GET_ALL_OFFICER_DETAILS,
    payload,
  };
}
