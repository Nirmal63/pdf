import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import BiddingHallComponent from "../../../components/Auction/BiddingHall";
import SockJS from "sockjs-client";
import Stomp from "stompjs";
import * as configConstants from "../../../commonConstants/configConstants";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

class index extends Component {
  constructor(props) {
    super(props);
    this.socketHandler();
  }

  socketHandler() {
    // Connect to the server using SockJS
    const socket = new SockJS(
      configConstants.SERVER_ADDR +
        "socketservice/connect?token=" +
        getLocalStorageItem("token")
    );

    // Create a Stomp.js client over the WebSocket connection
    this.stompClient = Stomp.over(socket);

    // Function to handle messages received from the server
    this.handleMessage = (message) => {
      console.log("Received message:", message.body);
      if (message.body) {
        let data = {
          auctionId: getLocalStorageItem("auctionIdForBiddingHall"),
          userId: getLocalStorageItem("userId"),
          // bidderId: userId,
          clientId: getLocalStorageItem("clientId"),
          ipAdd: "192.168.100.100",
        };
        this.props.getBidDetails(data);
      }
    };

    // Function to subscribe to a topic on the server
    this.subscribeToTopic = () => {
      this.stompClient.subscribe(
        "/socketservice/broadcast/getlivebiddata/" +
          getLocalStorageItem("auctionIdForBiddingHall"),
        this.handleMessage
      );
    };

    // Connect to the WebSocket server
    this.stompClient.connect({}, () => {
      console.log("Connected to WebSocket server");
      this.subscribeToTopic();
    });
  }

  componentDidMount() {
    let data = {
      auctionId: getLocalStorageItem("auctionIdForBiddingHall"),
      userId: getLocalStorageItem("userId"),
      clientId: getLocalStorageItem("clientId"),
      ipAdd: "192.168.100.100",
    };
    this.props.getBidDetails(data);
  }

  handleClassDTOBiddingHall = (value, rowId, columnId) => {
    let quantity = 1;
    let data =
      this.props.getBidDetailsResponse &&
      this.props.getBidDetailsResponse.biddingHallDetail.map(
        (biddingHallDetailData, biddingHallDetailDataIndex) => {
          if (rowId != biddingHallDetailData.rowid)
            return biddingHallDetailData;

          if (rowId == biddingHallDetailData.rowid) {
            let innerData =
              biddingHallDetailData &&
              biddingHallDetailData.AuctionCellValueList &&
              biddingHallDetailData.AuctionCellValueList.map(
                (auctionCellValueListData, auctionCellValueListIndex) => {
                  //if column id same then set unit rate
                  if (columnId == auctionCellValueListData.columnid) {
                    auctionCellValueListData.cellvalue = value;
                  }

                  //get quantity
                  if ("2" == auctionCellValueListData.columntypeid) {
                    quantity = auctionCellValueListData.cellvalue;
                  }

                  //set total rate
                  if ("5" == auctionCellValueListData.columntypeid) {
                    auctionCellValueListData.cellvalue = quantity * value;
                  }
                  return auctionCellValueListData;
                }
              );

            let biddingHallDetail = biddingHallDetailData;
            biddingHallDetail.AuctionCellValueList = innerData;
            return biddingHallDetail;
          }
        }
      );
    let response = this.props.getBidDetailsResponse;
    response.biddingHallDetail = data;

    this.props.updateGetBidDetailsResponse(response);
  };

  handleButtonsBiddingHall = (name, value1) => {
    switch (name) {
      case "submit": {
        let tempData = {
          auctionId: getLocalStorageItem("auctionIdForBiddingHall"),
          v_BidderId: getLocalStorageItem("userId"),
          v_SessionUserId: getLocalStorageItem("userId"),
          userid: getLocalStorageItem("userId"),
          v_UserDetailId: getLocalStorageItem("userId"),

          v_TableId: "",
          v_RowId: 0,
          v_BidPrice: 0,
          v_IPAddress: "192.168.100.100",
          v_BidType: 0,
          v_QtyBidPrice: 0,

          v_CalledFrom: 2,

          v_CheckBidAmtStr: "",
          v_OutputStr: "",
        };

        let data =
          this.props.getBidDetailsResponse &&
          this.props.getBidDetailsResponse.biddingHallDetail &&
          this.props.getBidDetailsResponse.biddingHallDetail.map(
            (biddingHallDetailData, index) => {
              if (value1 == biddingHallDetailData.rowid) {
                let innerData =
                  biddingHallDetailData &&
                  biddingHallDetailData.AuctionCellValueList &&
                  biddingHallDetailData.AuctionCellValueList.map(
                    (auctionCellValueListData, auctionCellValueListIndex) => {
                      if (2 == auctionCellValueListData.columntypeid) {
                        tempData.v_QtyBidPrice =
                          auctionCellValueListData.cellvalue;
                      } else if (
                        4 == auctionCellValueListData.columntypeid &&
                        6 == this.props.getBidDetailsResponse.govColNo
                      ) {
                        //unit rate
                        tempData.cellValue = auctionCellValueListData.cellvalue;
                        tempData.cellId = auctionCellValueListData.cellid;
                        tempData.v_BidPrice =
                          auctionCellValueListData.cellvalue;
                        tempData.v_TableId = auctionCellValueListData.tableid;
                        tempData.v_RowId = auctionCellValueListData.rowid;
                      } else if (
                        5 == auctionCellValueListData.columntypeid &&
                        7 == this.props.getBidDetailsResponse.govColNo
                      ) {
                        //unit rate
                        tempData.cellValue = auctionCellValueListData.cellvalue;
                        tempData.cellId = auctionCellValueListData.cellid;
                        tempData.v_BidPrice =
                          auctionCellValueListData.cellvalue;
                        tempData.v_TableId = auctionCellValueListData.tableid;
                        tempData.v_RowId = auctionCellValueListData.rowid;
                      }
                    }
                  );
              }
            }
          );

        this.props.submitBiddingHallDetails(tempData);

        break;
      }
      default: {
        break;
      }
    }
  };

  componentWillUnmount() {
    localStorage.removeItem("auctionIdForBiddingHall");

    // Disconnect the WebSocket connection
    this.stompClient.disconnect();
  }

  componentDidUpdate() {
    if (
      this.props.submitBiddingHallDetailsResponse &&
      this.props.submitBiddingHallDetailsResponse.statusCode &&
      200 == this.props.submitBiddingHallDetailsResponse.statusCode
    ) {
      this.props.updateSubmitBiddingHallDetails("");
      this.stompClient.send(
        "/socketservice/send/addbid",
        {},
        getLocalStorageItem("auctionIdForBiddingHall")
      ); // Send a subscription message to the server
    }
  }

  render() {
    return (
      <BiddingHallComponent
        {...this.props}
        handleClassDTOBiddingHall={this.handleClassDTOBiddingHall}
        handleButtonsBiddingHall={this.handleButtonsBiddingHall}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    submitBiddingHallDetails: (data) => {
      dispatch(actions.submitBiddingHallDetails(data));
    },

    updateSubmitBiddingHallDetails: (data) => {
      dispatch(actions.updateSubmitBiddingHallDetails(data));
    },

    getAuctionSummaryDetails: (data) => {
      dispatch(actions.getAuctionSummaryDetails(data));
    },

    getBidDetails: (data) => {
      dispatch(actions.getBidDetails(data));
    },

    updateGetBidDetailsResponse: (data) => {
      dispatch(actions.updateGetBidDetailsResponse(data));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    getAuctionSummaryDetailsResponse: selectors.getAuctionSummaryDetails(),
    getBidDetailsResponse: selectors.getBidDetails(),
    submitBiddingHallDetailsResponse: selectors.submitBiddingHallDetails(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
