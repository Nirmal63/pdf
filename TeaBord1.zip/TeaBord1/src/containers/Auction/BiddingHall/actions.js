import { ActionTypes } from "./constants";

export function submitBiddingHallDetails(data) {
  return {
    type: ActionTypes.SUBMIT_BIDDING_HALL_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function updateSubmitBiddingHallDetails(data) {
  return {
    type: ActionTypes.SUBMIT_BIDDING_HALL_DETAILS_SUCCESS,
    payload: {
      value: data,
    },
  };
}

export function getAuctionSummaryDetails(data) {
  return {
    type: ActionTypes.GET_AUCTION_SUMMARY_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function getBidDetails(data) {
  return {
    type: ActionTypes.GET_BID_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function updateGetBidDetailsResponse(data) {
  return {
    type: ActionTypes.GET_BID_DETAILS_SUCCESS,
    payload: {
      value: data,
    },
  };
}
