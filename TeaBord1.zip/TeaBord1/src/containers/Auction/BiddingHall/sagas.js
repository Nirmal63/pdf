import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { apiFetch } from "../../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../../commonConstants/constants";
import { CustomToast as toast } from "../../../components/GenericComponents/Toast";

toast.configure();
export function* submitBiddingHallDetails({ payload }) {
  const response = yield apiFetch("eauctionbid/bidsubmit", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    const responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      toast.success(responseJSON.message);
      yield put({
        type: ActionTypes.SUBMIT_BIDDING_HALL_DETAILS_SUCCESS,
        payload: {
          value: responseJSON,
        },
      });
    } else if (204 === responseJSON.statusCode) {
      toast.error(
        responseJSON.responseData && responseJSON.responseData.outputstr
      );
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_BIDDING_HALL_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(response.message || ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAuctionSummaryDetails({ payload }) {
  const response = yield apiFetch(
    `eauction/auctioneer/auctionSummary/${payload.data}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    const responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      var responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.GET_AUCTION_SUMMARY_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_AUCTION_SUMMARY_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(response.message || ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getBidDetails({ payload }) {
  const response = yield apiFetch(`eauctionbid/biddingHall`, {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    const responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      var responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.GET_BID_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_BID_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(response.message || ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_BIDDING_HALL_DETAILS,
      submitBiddingHallDetails
    ),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_AUCTION_SUMMARY_DETAILS,
      getAuctionSummaryDetails
    ),
  ]);

  yield all([takeLatest(ActionTypes.GET_BID_DETAILS, getBidDetails)]);
}
