import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "biddingHall";

export const ActionTypes = keyMirrorRecursive(
  {
    SUBMIT_BIDDING_HALL_DETAILS: undefined,
    SUBMIT_BIDDING_HALL_DETAILS_SUCCESS: undefined,
    GET_AUCTION_SUMMARY_DETAILS: undefined,
    GET_AUCTION_SUMMARY_DETAILS_SUCCESS: undefined,
    GET_BID_DETAILS: undefined,
    GET_BID_DETAILS_SUCCESS: undefined,
  },
  pageName
);
