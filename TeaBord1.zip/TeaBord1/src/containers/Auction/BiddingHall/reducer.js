import { ActionTypes } from "./constants";

const initialState = {};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.SUBMIT_BIDDING_HALL_DETAILS_SUCCESS: {
      state.submitBiddingHallDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_AUCTION_SUMMARY_DETAILS_SUCCESS: {
      state.getAuctionSummaryDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_BID_DETAILS_SUCCESS: {
      state.getBidDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
