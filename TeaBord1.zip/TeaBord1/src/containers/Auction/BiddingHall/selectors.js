import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const submitBiddingHallDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.submitBiddingHallDetails);

export const getAuctionSummaryDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAuctionSummaryDetails);

export const getBidDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getBidDetails);
