import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "login";

export const ActionTypes = keyMirrorRecursive(
  {
    AUCTION_BID_CONFIRMATION: undefined,
    GET_AUCTION_BID_TERM_CONDITION: undefined,
    GET_AUCTION_BID_TERM_CONDITION_SUCCESS: undefined,
    AUCTION_BID_CONFIRMATION_SUCCESS: undefined,
    SUBMIT_AUCTION_BID_CONFIRMATION: undefined,
    SUBMIT_AUCTION_BID_CONFIRMATION_SUCCESS: undefined,
    GET_USER_DETAIL_ID: undefined,
    GET_USER_DETAIL_ID_SUCCESS: undefined,
  },
  pageName
);
