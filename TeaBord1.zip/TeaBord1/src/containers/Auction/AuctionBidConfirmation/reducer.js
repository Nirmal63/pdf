import { ActionTypes } from "./constants";

const initialState = {
  classDTOAuctionBidConfirmation: {
    ipAddress: "",
    auctionId: 0,
    clientBidTermId: "",
    userDetailId: "",
    bidderId: 0,
    encodedName: "",
    iAgree: false,
  },
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.AUCTION_BID_CONFIRMATION: {
      state.classDTOAuctionBidConfirmation = action.payload || {};
      return JSON.parse(JSON.stringify(state));
    }
    case ActionTypes.GET_AUCTION_BID_TERM_CONDITION_SUCCESS: {
      state.getAuctionBidTermAndCondition = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }
    case ActionTypes.GET_USER_DETAIL_ID_SUCCESS: {
      state.getuserDetailId = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
