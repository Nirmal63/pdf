import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import AuctionBidConfirmationComponent from "../../../components/Auction/AuctionBidConfirmation";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

class index extends Component {
  componentDidMount() {
    this.props.getAuctionBidTermAndCondition();
    this.props.updateAuctionBidConfirmation();
    this.props.getuserDetailId();
  }

  handleClassDTOAuctionBidConfirmation = (key, value) => {
    let { classDTOAuctionBidConfirmation } = this.props;
    classDTOAuctionBidConfirmation[key] = value;

    this.checkValidations(key, classDTOAuctionBidConfirmation);
  };
  checkValidations = (key, data) => {
    let { classDTOAuctionBidConfirmation, updateAuctionBidConfirmation } =
      this.props;

    classDTOAuctionBidConfirmation = data;
    classDTOAuctionBidConfirmation.isValidationSuccess = true;

    if ("iAgree" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOAuctionBidConfirmation.iAgree)) {
        classDTOAuctionBidConfirmation.iAgreeError =
          "Please Select Term and condition";
        classDTOAuctionBidConfirmation.isValidationSuccess = false;
      } else {
        classDTOAuctionBidConfirmation.loginIdError = "";
      }
    }

    updateAuctionBidConfirmation(classDTOAuctionBidConfirmation);
  };
  handleButtonsAuctionBidConfirmation = (name, value, value1) => {
    let { classDTOAuctionBidConfirmation } = this.props;
    switch (name) {
      case "Agree": {
        this.checkValidations("all", classDTOAuctionBidConfirmation);
        if (classDTOAuctionBidConfirmation.isValidationSuccess) {
          let data = {
            ipAddress: "192.168.100.133",
            auctionId: parseInt(getLocalStorageItem("auctionBidConfirmation")),
            clientBidTermId: value,
            userDetailId: value1,
            //  parseInt(getLocalStorageItem("userId")) || 267 or 268
            bidderId: parseInt(getLocalStorageItem("userId")),
            encodedName: "ABC==",
          };
          this.props.submitAuctionBidConfirmation(data);
        }
        break;
      }

      default: {
        break;
      }
    }
  };

  resetData = () => {
    let classDTOAuctionBidConfirmation = {
      ipAddress: "",
      auctionId: 0,
      clientBidTermId: "",
      userDetailId: 0,
      bidderId: 0,
      encodedName: "",
      iAgree: false,
    };
    this.props.updateAuctionBidConfirmation(classDTOAuctionBidConfirmation);
  };

  componentWillUnmount() {
    localStorage.removeItem("auctionBidConfirmation");
    this.resetData();
  }

  render() {
    return (
      <AuctionBidConfirmationComponent
        {...this.props}
        flag={this.props.flag}
        openPopUp={this.props.onClickOfClickHereToBid}
        handleButtonsAuctionBidConfirmation={
          this.handleButtonsAuctionBidConfirmation
        }
        handleClassDTOAuctionBidConfirmation={
          this.handleClassDTOAuctionBidConfirmation
        }
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    updateAuctionBidConfirmation: (payload) => {
      dispatch(actions.updateAuctionBidConfirmation(payload));
    },
    getAuctionBidTermAndCondition: () => {
      dispatch(actions.getAuctionBidTermAndCondition());
    },
    // auctionBidConfirmation: (data) => {
    //   dispatch(actions.auctionBidConfirmationResponse(data));
    // },
    submitAuctionBidConfirmation: (data) => {
      dispatch(actions.submitAuctionBidConfirmation(data));
    },
    getuserDetailId: (data) => {
      dispatch(actions.getuserDetailId(data));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTOAuctionBidConfirmation:
      selectors.getclassDTOAuctionBidConfirmation(),
    // submitAuctionBidConfirmationResponse:
    //   selectors.submitAuctionBidConfirmation(),
    getAuctionBidTermAndConditionResponse:
      selectors.getAuctionBidTermAndCondition(),
    getuserDetailIdResponse: selectors.getuserDetailId(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
