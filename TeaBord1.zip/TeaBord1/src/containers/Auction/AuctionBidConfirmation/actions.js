import { ActionTypes } from "./constants";

export function updateAuctionBidConfirmation(payload) {
  return {
    type: ActionTypes.AUCTION_BID_CONFIRMATION,
    payload,
  };
}

export function getAuctionBidTermAndCondition(value) {
  return {
    type: ActionTypes.GET_AUCTION_BID_TERM_CONDITION,
    payload: {
      value,
    },
  };
}

export function submitAuctionBidConfirmation(data) {
  return {
    type: ActionTypes.SUBMIT_AUCTION_BID_CONFIRMATION,
    payload: {
      data: data,
    },
  };
}

export function getuserDetailId(value) {
  return {
    type: ActionTypes.GET_USER_DETAIL_ID,
    payload: {
      value,
    },
  };
}
