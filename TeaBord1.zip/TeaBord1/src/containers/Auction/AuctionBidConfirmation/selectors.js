import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getAuctionBidTermAndCondition = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.getAuctionBidTermAndCondition
  );

export const getclassDTOAuctionBidConfirmation = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.classDTOAuctionBidConfirmation
  );

export const getuserDetailId = () =>
  createSelector(stateSelector, (bstate) => bstate.getuserDetailId);
