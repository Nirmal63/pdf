import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
// import { ActionTypes as ActionTypesHome } from "../Home/constants";
import { apiFetch } from "../../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../../commonConstants/constants";
import { CustomToast as toast } from "../../../components/GenericComponents/Toast";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

export function* getAuctionBidTermAndCondition() {
  let response = yield apiFetch(
    `common/client/getClientBidTermId/${getLocalStorageItem("clientId")}`,
    {
      method: "GET",
    }
  ).then((res) => res);
  if (200 === response.status) {
    let responseJSON = yield response.json() || {};
    yield put({
      type: ActionTypes.GET_AUCTION_BID_TERM_CONDITION_SUCCESS,
      payload: {
        value: responseJSON.responseData,
      },
    });
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_AUCTION_BID_TERM_CONDITION_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getuserDetailId() {
  let response = yield apiFetch(
    // ${getLocalStorageItem("userId")} / 267 or 268
    `common/client/getUserDetailId/${getLocalStorageItem("userId")}`,
    {
      method: "GET",
    }
  ).then((res) => res);
  if (200 === response.status) {
    let responseJSON = yield response.json() || {};
    yield put({
      type: ActionTypes.GET_USER_DETAIL_ID_SUCCESS,
      payload: {
        value: responseJSON.responseData,
      },
    });
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_USER_DETAIL_ID_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* auctionBidConfirmation({ payload }) {
  let response = yield apiFetch(
    "eauctionbid/aucbidconform/createaucbidconform",
    {
      method: "POST",
      body: JSON.stringify(payload.data),
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON.responseData || {};

      let data = {
        ipAddress: "",
        auctionId: 0,
        clientBidTermId: "",
        userDetailId: 0,
        bidderId: 0,
        encodedName: "",
        iAgree: false,
      };
      window.$("#auctionBidConfirmationModal").modal("hide");
      window.location.href = "/auctionList";
      yield put({
        type: ActionTypes.AUCTION_BID_CONFIRMATION,
        payload: {
          data: data,
        },
      });
      yield put({
        type: ActionTypes.SUBMIT_AUCTION_BID_CONFIRMATION_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.success(responseJSON.message);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_AUCTION_BID_CONFIRMATION_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_AUCTION_BID_CONFIRMATION,
      auctionBidConfirmation
    ),
  ]);
  yield all([
    takeLatest(
      ActionTypes.GET_AUCTION_BID_TERM_CONDITION,
      getAuctionBidTermAndCondition
    ),
  ]);
  yield all([takeLatest(ActionTypes.GET_USER_DETAIL_ID, getuserDetailId)]);
}
