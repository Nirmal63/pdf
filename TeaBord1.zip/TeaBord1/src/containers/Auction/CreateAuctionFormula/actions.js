import { ActionTypes } from "./constants";

export function submitAuctionFormulaDetails(data) {
  return {
    type: ActionTypes.SUBMIT_AUCTION_FORMULA_DETAILS,
    payload: {
      data: data,
    },
  };
}
export function updateClassDTOAuctionFormula(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_AUCTION_FORMULA,
    payload: {
      data: payload,
    },
  };
}
export function updateClassDTOAddGoverningColumn(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_ADD_GOVERNING_COLUMN,
    payload,
  };
}
export function removeGoverningColumn(data) {
  return {
    type: ActionTypes.REMOVE_GOVERNING_COLUMN,
    payload: {
      data: data,
    },
  };
}

export function getcreateformulastep1(data) {
  return {
    type: ActionTypes.GET_CREATE_FORMULA_STEP1,
    payload: {
      data: data,
    },
  };
}

export function getcreateformulastep4(data) {
  return {
    type: ActionTypes.GET_CREATE_FORMULA_STEP4,
    payload: {
      data: data,
    },
  };
}

export function getTableIdByAuctionId(data) {
  return {
    type: ActionTypes.GET_TABLE_ID_BY_AUCTION_ID,
    payload: {
      data: data,
    },
  };
}
