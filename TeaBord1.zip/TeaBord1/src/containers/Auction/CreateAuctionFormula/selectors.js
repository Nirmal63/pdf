import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getclassDTOAuctionFormula = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTOAuctionFormula);

export const getcreateformulastep1 = () =>
  createSelector(stateSelector, (bstate) => bstate.getcreateformulastep1);

export const getcreateformulastep4 = () =>
  createSelector(stateSelector, (bstate) => bstate.getcreateformulastep4);

export const removeGoverningColumn = () =>
  createSelector(stateSelector, (bstate) => bstate.removeGoverningColumn);

export const submitAuctionFormulaDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.submitAuctionFormulaDetails);

export const getTableIdByAuctionId = () =>
  createSelector(stateSelector, (bstate) => bstate.getTableIdByAuctionId);
