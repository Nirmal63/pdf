import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { apiFetch } from "../../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../../commonConstants/constants";
import { CustomToast as toast } from "../../../components/GenericComponents/Toast";

export function* submitAuctionFormulaDetails({ payload }) {
  let response = yield apiFetch("eauction/createformula", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      var responseObj = responseJSON.responseObj || {};
      toast.success(responseJSON.message);
      let data = {
        colFormula: "",
        columnNo: 0,
        displayFormula: "",
        formula: "",
        formulaId: 0,
        tblAuctionColumn: 0,
        tblAuctionTable: 0,
        quantity: 0,
        unitRate: 0,
        TotalRate: 0,
        // govColumnId: 0,
        cellId: 0,
        // tableId: 0,
        isSubmitted: true,
      };

      yield put({
        type: ActionTypes.UPDATE_CLASS_DTO_AUCTION_FORMULA,
        payload: {
          data: data,
        },
      });
      yield put({
        type: ActionTypes.SUBMIT_AUCTION_FORMULA_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.success(responseJSON.message);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_AUCTION_FORMULA_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getcreateformulastep1({ payload }) {
  let response = yield apiFetch(
    `eauction/getcraeteformulastep1/${payload.data}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    yield put({
      type: ActionTypes.GET_CREATE_FORMULA_STEP1_SUCCESS,
      payload: {
        value: responseJSON.responseData,
      },
    });
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_CREATE_FORMULA_STEP1_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getcreateformulastep4({ payload }) {
  let response = yield apiFetch(
    `eauction/getcraeteformulastep4/${payload.data}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    yield put({
      type: ActionTypes.GET_CREATE_FORMULA_STEP4_SUCCESS,
      payload: {
        value: responseJSON.responseData,
      },
    });
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_CREATE_FORMULA_STEP4_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* removeGoverningColumn({ payload }) {
  let response = yield apiFetch("eauction/deleteGovCol/${payload.data}", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      var responseObj = responseJSON.responseObj || {};
      toast.success(responseJSON.message);
      let data = {
        colFormula: "",
        columnNo: 0,
        displayFormula: "",
        formula: "",
        formulaId: 0,
        tblAuctionColumn: 0,
        tblAuctionTable: 0,
        quantity: "",
        unitRate: "",
        TotalRate: 0,
        govColumnId: "",
        cellId: "",
        tableId: "",
        isSubmitted: false,
      };

      yield put({
        type: ActionTypes.UPDATE_CLASS_DTO_AUCTION_FORMULA,
        payload: {
          data: data,
        },
      });

      yield put({
        type: ActionTypes.REMOVE_GOVERNING_COLUMN_SUCCESS,
        payload: {
          value: [],
        },
      });
    } else {
      toast.success(responseJSON.message);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.REMOVE_GOVERNING_COLUMN_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getTableIdByAuctionId({ payload }) {
  let response = yield apiFetch(`eauction/gettableidbyaucid/${payload.data}`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    yield put({
      type: ActionTypes.GET_TABLE_ID_BY_AUCTION_ID_SUCCESS,
      payload: {
        value: responseJSON.responseData,
      },
    });

    yield put({
      type: ActionTypes.GET_CREATE_FORMULA_STEP1,
      payload: {
        data: responseJSON.responseData && responseJSON.responseData.tableId,
      },
    });

    yield put({
      type: ActionTypes.GET_CREATE_FORMULA_STEP4,
      payload: {
        data: responseJSON.responseData && responseJSON.responseData.tableId,
      },
    });
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_TABLE_ID_BY_AUCTION_ID_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_AUCTION_FORMULA_DETAILS,
      submitAuctionFormulaDetails
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_CREATE_FORMULA_STEP1, getcreateformulastep1),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_CREATE_FORMULA_STEP4, getcreateformulastep4),
  ]);

  yield all([
    takeLatest(ActionTypes.REMOVE_GOVERNING_COLUMN, removeGoverningColumn),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_TABLE_ID_BY_AUCTION_ID, getTableIdByAuctionId),
  ]);
}
