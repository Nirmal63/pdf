import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";
import { REHYDRATE } from "redux-persist/lib/constants";

export const pageName = "CreateAuctionFormula";

export const ActionTypes = keyMirrorRecursive(
  {
    UPDATE_CLASS_DTO_AUCTION_FORMULA: undefined,
    SUBMIT_AUCTION_FORMULA_DETAILS: undefined,
    SUBMIT_AUCTION_FORMULA_DETAILS_SUCCESS: undefined,
    UPDATE_CLASS_DTO_ADD_GOVERNING_COLUMN: undefined,
    REMOVE_GOVERNING_COLUMN: undefined,
    REMOVE_GOVERNING_COLUMN_SUCCESS: undefined,
    GET_CREATE_FORMULA_STEP1: undefined,
    GET_CREATE_FORMULA_STEP1_SUCCESS: undefined,
    GET_CREATE_FORMULA_STEP4: undefined,
    GET_CREATE_FORMULA_STEP4_SUCCESS: undefined,
    GET_TABLE_ID_BY_AUCTION_ID: undefined,
    GET_TABLE_ID_BY_AUCTION_ID_SUCCESS: undefined,
  },
  pageName
);
