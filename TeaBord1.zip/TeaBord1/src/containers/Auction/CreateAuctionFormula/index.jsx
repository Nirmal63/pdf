import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import CreateAuctionFormulaComponent from "../../../components/Auction/CreateAuctionFormula";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

class index extends Component {
  componentDidMount() {
    this.props.getTableIdByAuctionId(
      getLocalStorageItem("auctionIdForFormula")
    );
    // let tableId = "";
    // this.props.getcreateformulastep1(tableId);
    // this.props.getcreateformulastep4(tableId);
  }

  handleClassDTOAuctionFormula = (key, value) => {
    let { classDTOAuctionFormula } = this.props;
    classDTOAuctionFormula.isValidationSuccess = true;

    switch (key) {
      default: {
        classDTOAuctionFormula[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTOAuctionFormula);
  };

  checkValidations = (key, data) => {
    let { classDTOAuctionFormula, updateClassDTOAuctionFormula } = this.props;

    classDTOAuctionFormula = data;
    classDTOAuctionFormula.isValidationSuccess = true;

    if ("columnId" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOAuctionFormula.columnId)) {
        classDTOAuctionFormula.columnIdError = "Please select ";
        classDTOAuctionFormula.isValidationSuccess = false;
      } else {
        classDTOAuctionFormula.columnIdError = "";
      }

      if ("columnId" === key) {
        classDTOAuctionFormula.columnId =
          classDTOAuctionFormula.columnId &&
          JSON.parse(classDTOAuctionFormula.columnId);
        classDTOAuctionFormula.columnNo =
          classDTOAuctionFormula.columnId &&
          classDTOAuctionFormula.columnId.columnNo;
      }

      // classDTOAuctionFormula.columnIdError = "";
      // classDTOAuctionFormula.columnId = JSON.parse(
      //   classDTOAuctionFormula.columnId
      // );
      // classDTOAuctionFormula.displayFormula =
      //   classDTOAuctionFormula.columnId &&
      //   classDTOAuctionFormula.columnId.columnHeader + "" + "=" + "";
    }

    if ("quantity" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOAuctionFormula.quantity)) {
        classDTOAuctionFormula.quantityError = "Please enter";
        classDTOAuctionFormula.isValidationSuccess = false;
      } else {
        classDTOAuctionFormula.quantityError = "";
      }
      // else {
      //   classDTOAuctionFormula.displayFormula += key;
      // }
      // classDTOAuctionFormula.quantityError = "";
      // classDTOAuctionFormula.quantity = JSON.parse(
      //   classDTOAuctionFormula.quantity
      // );
    }

    if ("unitRate" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOAuctionFormula.unitRate)) {
        classDTOAuctionFormula.unitRateError = "Please enter";
        classDTOAuctionFormula.isValidationSuccess = false;
      } else {
        classDTOAuctionFormula.unitRateError = "";
      }
      //  else {
      //   classDTOAuctionFormula.displayFormula += key;
      // }
      // classDTOAuctionFormula.unitRateError = "";
      // classDTOAuctionFormula.unitRate = JSON.parse(
      //   classDTOAuctionFormula.unitRate
      // );
    }

    if ("TotalRate" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOAuctionFormula.TotalRate)) {
        classDTOAuctionFormula.TotalRateError = "Please enter";
        classDTOAuctionFormula.isValidationSuccess = false;
      }
      classDTOAuctionFormula.TotalRateError = "";

      classDTOAuctionFormula.formula =
        classDTOAuctionFormula.quantity + "*" + classDTOAuctionFormula.unitRate;

      classDTOAuctionFormula.colFormula =
        classDTOAuctionFormula.quantity + "*" + classDTOAuctionFormula.unitRate;

      classDTOAuctionFormula.displayFormula =
        "Total Rate = Quantity * Unit Rate";

      //  else {
      //   classDTOAuctionFormula.displayFormula += key;
      // }
      // classDTOAuctionFormula.unitRateError = "";
      // classDTOAuctionFormula.unitRate = JSON.parse(
      //   classDTOAuctionFormula.unitRate
      // );
    }

    if ("govColumnId" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOAuctionFormula.govColumnId)) {
        classDTOAuctionFormula.govColumnIdError =
          "Please select governing column";
        classDTOAuctionFormula.isValidationSuccess = false;
      } else {
        classDTOAuctionFormula.govColumnIdError = "";
      }

      if ("govColumnId" === key) {
        classDTOAuctionFormula.govColumnId =
          classDTOAuctionFormula.govColumnId &&
          JSON.parse(classDTOAuctionFormula.govColumnId);
      }
    }

    updateClassDTOAuctionFormula(classDTOAuctionFormula);
  };

  handleButtonsAuctionFormula = (name) => {
    var { classDTOAuctionFormula } = this.props;

    switch (name) {
      case "submit": {
        this.checkValidations("all", classDTOAuctionFormula);
        if (classDTOAuctionFormula.isValidationSuccess) {
          let data = {
            // colFormula: classDTOAuctionFormula.colFormula,
            colFormula: "3*6",
            columnNo: classDTOAuctionFormula.columnNo,
            displayFormula: classDTOAuctionFormula.displayFormula,
            // formula: classDTOAuctionFormula.formula,
            formulaId: classDTOAuctionFormula.columnId.columnId,
            formula: "3*6",
            tblAuctionColumn: classDTOAuctionFormula.columnId.columnId,
            tblAuctionTable: classDTOAuctionFormula.tableId,
            auctionGovColumnDTOSet: [
              {
                cellId: 0,
                tblAuctionColumn: classDTOAuctionFormula.columnId.columnId,
                tblAuctionTable: classDTOAuctionFormula.tableId,
                columnNo:
                  classDTOAuctionFormula.govColumnId &&
                  classDTOAuctionFormula.govColumnId.columnNo,
              },
            ],
            auctionId: getLocalStorageItem("auctionIdForFormula"),
          };
          this.props.submitAuctionFormulaDetails(data);
        }
        break;
      }
      case "clear": {
        document.getElementById("displayFormula").value = "";
        break;
      }

      case "undo": {
        var value = document.getElementById("displayFormula").value;
        document.getElementById("displayFormula").value = value.substr(
          0,
          value.length - 1
        );
        break;
      }

      case "plus": {
        document.getElementById("displayFormula").value += "+";
        break;
      }

      case "subscription": {
        document.getElementById("displayFormula").value += "-";
        break;
      }

      case "multiple": {
        document.getElementById("displayFormula").value += "*";
        break;
      }

      case "divisions": {
        document.getElementById("displayFormula").value += "/";
        break;
      }

      case "openPer": {
        document.getElementById("displayFormula").value += "(";
        break;
      }

      case "closePer": {
        document.getElementById("displayFormula").value += ")";
        break;
      }

      case "testFormula": {
        var p = document.getElementById("quantity").value;
        var q = document.getElementById("unitRate").value;
        var r = eval(p * q);
        document.getElementById("TotalRate").value = r;
        break;
      }

      case "removeGov": {
        this.props.removeGoverningColumn(
          getLocalStorageItem("auctionIdForFormula")
        );
        break;
      }

      default: {
        break;
      }
    }
  };

  resetData = () => {
    let classDTOAuctionFormula = {
      colFormula: "",
      columnNo: 0,
      displayFormula: "",
      formula: "",
      formulaId: 0,
      tblAuctionColumn: 0,
      tblAuctionTable: 0,
      quantity: 0,
      unitRate: 0,
      TotalRate: 0,
      // govColumnId: 0,
      cellId: 0,
      tableId: 0,
      isSubmitted: false,
    };
    this.props.updateClassDTOAuctionFormula(classDTOAuctionFormula);
  };

  componentWillUnmount() {
    this.resetData();
    localStorage.removeItem("auctionIdForFormula");
  }

  render() {
    return (
      <CreateAuctionFormulaComponent
        {...this.props}
        handleClassDTOAuctionFormula={this.handleClassDTOAuctionFormula}
        handleButtonsAuctionFormula={this.handleButtonsAuctionFormula}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    submitAuctionFormulaDetails: (data) => {
      dispatch(actions.submitAuctionFormulaDetails(data));
    },

    updateClassDTOAuctionFormula: (payload) => {
      dispatch(actions.updateClassDTOAuctionFormula(payload));
    },

    getcreateformulastep1: (data) => {
      dispatch(actions.getcreateformulastep1(data));
    },

    getcreateformulastep4: (data) => {
      dispatch(actions.getcreateformulastep4(data));
    },

    removeGoverningColumn: (data) => {
      dispatch(actions.removeGoverningColumn(data));
    },

    getTableIdByAuctionId: (data) => {
      dispatch(actions.getTableIdByAuctionId(data));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTOAuctionFormula: selectors.getclassDTOAuctionFormula(),
    getcreateformulastep1Response: selectors.getcreateformulastep1(),
    getcreateformulastep4Response: selectors.getcreateformulastep4(),
    removeGoverningColumnResponse: selectors.removeGoverningColumn(),
    submitAuctionFormulaDetailsResponse:
      selectors.submitAuctionFormulaDetails(),
    getTableIdByAuctionIdResponse: selectors.getTableIdByAuctionId(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
