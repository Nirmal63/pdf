import { ActionTypes } from "./constants";

const initialState = {
  classDTOAuctionFormula: {
    colFormula: "",
    columnNo: 0,
    displayFormula: "",
    formula: "",
    formulaId: 0,
    tblAuctionColumn: 0,
    tblAuctionTable: 0,
    quantity: "",
    unitRate: "",
    TotalRate: 0,
    govColumnId: "",
    cellId: 0,
    tableId: 89,
    govColumnHeader: "",
    isSubmitted: false,
  },
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.UPDATE_CLASS_DTO_AUCTION_FORMULA: {
      state.classDTOAuctionFormula = action.payload.data || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_CREATE_FORMULA_STEP1_SUCCESS: {
      state.getcreateformulastep1 = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_CREATE_FORMULA_STEP4_SUCCESS: {
      state.getcreateformulastep4 = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.SUBMIT_AUCTION_FORMULA_DETAILS_SUCCESS: {
      state.submitAuctionFormulaDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.REMOVE_GOVERNING_COLUMN_SUCCESS: {
      state.removeGoverningColumn = action.payload.data || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.REMOVE_GOVERNING_COLUMN: {
      state.removeGoverningColumn = action.payload.data || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_TABLE_ID_BY_AUCTION_ID_SUCCESS: {
      state.getTableIdByAuctionId = action.payload.data || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
