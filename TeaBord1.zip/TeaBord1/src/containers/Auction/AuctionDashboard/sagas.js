import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";

import { apiFetch } from "../../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../../commonConstants/constants";
import { CustomToast as toast } from "../../../components/GenericComponents/Toast";

export function* submitBiddingFormDetails({ payload }) {
  const response = yield apiFetch(
    `eauction/uploadexcel/${payload.data.auctionId}`,
    {
      method: "POST",
      body: JSON.stringify(payload.data),
    }
  ).then((res) => res);

  if (200 === response.status) {
    const responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      toast.success(responseJSON.message);
      window.$("#biddingFormModal").modal("hide");
      var responseObj = responseJSON.responseObj || {};
      yield put({
        type: ActionTypes.SUBMIT_BIDDING_FORM_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_BIDDING_FORM_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* submitConfigureParameterDetails({ payload }) {
  const response = yield apiFetch(`eauction/config/uploadexcel`, {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    const responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      toast.success(responseJSON.message);
      window.$("#configureparameterModal").modal("hide");
      var responseObj = responseJSON.responseObj || {};
      yield put({
        type: ActionTypes.SUBMIT_CONFIGURE_PARAMETER_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_CONFIGURE_PARAMETER_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAuctionSummaryDetails({ payload }) {
  const response = yield apiFetch(
    `eauction/auctioneer/auctionSummary/${payload.data.auctionId}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    const responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      var responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.GET_AUCTION_SUMMARY_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_AUCTION_SUMMARY_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(response.message || ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAuctionSubModulesDetails({ payload }) {
  const response = yield apiFetch(
    `eauction/auctioneer/getallsubmodule/${payload.data.moduleId}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    const responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      var responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.GET_AUCTION_MODULES_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_AUCTION_MODULES_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(response.message || ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getEventDetailsBySubModuleId({ payload }) {
  const response = yield apiFetch(
    `eauction/auctioneer/auctiondashboardbysubModuleId/${payload.data.subModuleId}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    const responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      var responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.GET_EVENT_DETAILS_BY_SUB_MODULE_ID_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_EVENT_DETAILS_BY_SUB_MODULE_ID_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(response.message || ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_BIDDING_FORM_DETAILS,
      submitBiddingFormDetails
    ),
  ]);

  yield all([
    takeLatest(
      ActionTypes.SUBMIT_CONFIGURE_PARAMETER_DETAILS,
      submitConfigureParameterDetails
    ),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_AUCTION_SUMMARY_DETAILS,
      getAuctionSummaryDetails
    ),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_AUCTION_MODULES_DETAILS,
      getAuctionSubModulesDetails
    ),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_EVENT_DETAILS_BY_SUB_MODULE_ID,
      getEventDetailsBySubModuleId
    ),
  ]);
}
