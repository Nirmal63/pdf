import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "auctionDashboard";

export const ActionTypes = keyMirrorRecursive(
  {
    UPDATE_CLASS_DTO_AUCTION_DASHBOARD: undefined,
    SUBMIT_BIDDING_FORM_DETAILS: undefined,
    SUBMIT_BIDDING_FORM_DETAILS_SUCCESS: undefined,
    SUBMIT_CONFIGURE_PARAMETER_DETAILS: undefined,
    SUBMIT_CONFIGURE_PARAMETER_DETAILS_SUCCESS: undefined,
    GET_AUCTION_SUMMARY_DETAILS: undefined,
    GET_AUCTION_SUMMARY_DETAILS_SUCCESS: undefined,
    GET_AUCTION_MODULES_DETAILS: undefined,
    GET_AUCTION_MODULES_DETAILS_SUCCESS: undefined,
    GET_EVENT_DETAILS_BY_SUB_MODULE_ID: undefined,
    GET_EVENT_DETAILS_BY_SUB_MODULE_ID_SUCCESS: undefined,
  },
  pageName
);
