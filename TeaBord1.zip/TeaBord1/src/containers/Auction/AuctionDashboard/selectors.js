import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getClassDTOAuctionDashboard = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTOAuctionDashboard);

export const getAuctionSummaryDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAuctionSummaryDetails);

export const getAuctionSubModulesDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAuctionSubModulesDetails);

export const getEventDetailsBySubModuleId = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.getEventDetailsBySubModuleId
  );
