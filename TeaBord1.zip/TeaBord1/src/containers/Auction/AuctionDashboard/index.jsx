import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import AuctionDashboardComponent from "../../../components/Auction/AuctionDashboard";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

class index extends Component {
  componentDidMount() {
    let { classDTOAuctionDashboard, updateClassDTOAuctionDashboard } =
      this.props;
    if (
      !isNullOrIsEmptyOrIsUndefined(
        getLocalStorageItem("auctionIdForAuctionDashboard")
      )
    ) {
      let data = {
        auctionId: getLocalStorageItem("auctionIdForAuctionDashboard"),
      };

      classDTOAuctionDashboard.auctionId = getLocalStorageItem(
        "auctionIdForAuctionDashboard"
      );
      updateClassDTOAuctionDashboard(classDTOAuctionDashboard);
      this.props.getAuctionSummaryDetails(data);
    }

    if (!isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("clientId"))) {
      let data = {
        moduleId: 5,
        clientId: getLocalStorageItem("clientId"),
      };
      this.props.getAuctionSubModulesDetails(data);
    }
  }

  handleClassDTOAuctionDashboard = (key, value) => {
    let { classDTOAuctionDashboard } = this.props;
    classDTOAuctionDashboard.isValidationSuccess = true;

    switch (key) {
      case "fileName": {
        let file = value.target.files && value.target.files[0];
        if (!file) return;
        classDTOAuctionDashboard[key] = file;
        break;
      }

      default: {
        classDTOAuctionDashboard[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTOAuctionDashboard);
  };

  checkValidations = (key, data) => {
    let { classDTOAuctionDashboard, updateClassDTOAuctionDashboard } =
      this.props;

    classDTOAuctionDashboard = data;
    classDTOAuctionDashboard.isValidationSuccess = true;

    if ("fileName" == key || "all" == key) {
      var reader = new FileReader();
      reader.readAsDataURL(classDTOAuctionDashboard.fileName);

      reader.onload = function () {
        if (
          (
            classDTOAuctionDashboard.fileName &&
            classDTOAuctionDashboard.fileName.name &&
            classDTOAuctionDashboard.fileName.name.split(".")[
              classDTOAuctionDashboard.fileName.name.split(".").length - 1
            ] + ""
          ).toLowerCase() == "xls" ||
          (
            classDTOAuctionDashboard.fileName &&
            classDTOAuctionDashboard.fileName.name &&
            classDTOAuctionDashboard.fileName.name.split(".")[
              classDTOAuctionDashboard.fileName.name.split(".").length - 1
            ] + ""
          ).toLowerCase() == "xlsx"
        ) {
          classDTOAuctionDashboard.fileNameError = "";
          classDTOAuctionDashboard.fileName =
            classDTOAuctionDashboard.fileName.name;
          classDTOAuctionDashboard.fileContent = reader.result.split(",")[1];
          classDTOAuctionDashboard.size =
            classDTOAuctionDashboard.fileName.size;
        } else {
          classDTOAuctionDashboard.isValidationSuccess = false;
          classDTOAuctionDashboard.fileNameError =
            "File attachment format MUST be xls/xlsx";
        }
      };
    }

    updateClassDTOAuctionDashboard(classDTOAuctionDashboard);
  };

  handleButtonsAuctionDashboard = (name) => {
    var { classDTOAuctionDashboard } = this.props;

    switch (name) {
      case "submitBiddingForm": {
        // this.checkValidations("all", classDTOAuctionDashboard);
        if (classDTOAuctionDashboard.isValidationSuccess) {
          this.props.submitBiddingFormDetails(classDTOAuctionDashboard);
        }
        break;
      }

      case "submitConfigureParameters": {
        // this.checkValidations("all", classDTOAuctionDashboard);
        if (classDTOAuctionDashboard.isValidationSuccess) {
          this.props.submitConfigureParameterDetails(classDTOAuctionDashboard);
        }
        break;
      }

      default: {
        break;
      }
    }
  };

  componentWillUnmount() {
    localStorage.removeItem("auctionIdForAuctionDashboard");
  }

  render() {
    return (
      <AuctionDashboardComponent
        {...this.props}
        handleClassDTOAuctionDashboard={this.handleClassDTOAuctionDashboard}
        handleButtonsAuctionDashboard={this.handleButtonsAuctionDashboard}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    updateClassDTOAuctionDashboard: (payload) => {
      dispatch(actions.updateClassDTOAuctionDashboard(payload));
    },

    submitBiddingFormDetails: (data) => {
      dispatch(actions.submitBiddingFormDetails(data));
    },

    submitConfigureParameterDetails: (data) => {
      dispatch(actions.submitConfigureParameterDetails(data));
    },

    getAuctionSummaryDetails: (payload) => {
      dispatch(actions.getAuctionSummaryDetails(payload));
    },

    getAuctionSubModulesDetails: (payload) => {
      dispatch(actions.getAuctionSubModulesDetails(payload));
    },

    getEventDetailsBySubModuleId: (payload) => {
      dispatch(actions.getEventDetailsBySubModuleId(payload));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTOAuctionDashboard: selectors.getClassDTOAuctionDashboard(),
    getAuctionSummaryDetailsResponse: selectors.getAuctionSummaryDetails(),
    getAuctionSubModulesDetailsResponse:
      selectors.getAuctionSubModulesDetails(),
    getEventDetailsBySubModuleIdResponse:
      selectors.getEventDetailsBySubModuleId(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
