import { ActionTypes } from "./constants";

const initialState = {
  classDTOAuctionDashboard: {},
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.UPDATE_CLASS_DTO_AUCTION_DASHBOARD: {
      state.classDTOAuctionDashboard = action.payload || {};
      return { ...state };
    }

    case ActionTypes.GET_AUCTION_SUMMARY_DETAILS_SUCCESS: {
      state.getAuctionSummaryDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_AUCTION_MODULES_DETAILS_SUCCESS: {
      state.getAuctionSubModulesDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_EVENT_DETAILS_BY_SUB_MODULE_ID_SUCCESS: {
      state.getEventDetailsBySubModuleId = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
