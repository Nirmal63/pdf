import { ActionTypes } from "./constants";

export function updateClassDTOAuctionDashboard(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_AUCTION_DASHBOARD,
    payload,
  };
}

export function submitBiddingFormDetails(data) {
  return {
    type: ActionTypes.SUBMIT_BIDDING_FORM_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function submitConfigureParameterDetails(data) {
  return {
    type: ActionTypes.SUBMIT_CONFIGURE_PARAMETER_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function getAuctionSummaryDetails(payload) {
  return {
    type: ActionTypes.GET_AUCTION_SUMMARY_DETAILS,
    payload: {
      data: payload,
    },
  };
}

export function getAuctionSubModulesDetails(payload) {
  return {
    type: ActionTypes.GET_AUCTION_MODULES_DETAILS,
    payload: {
      data: payload,
    },
  };
}

export function getEventDetailsBySubModuleId(payload) {
  return {
    type: ActionTypes.GET_EVENT_DETAILS_BY_SUB_MODULE_ID,
    payload: {
      data: payload,
    },
  };
}
