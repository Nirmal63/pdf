import { ActionTypes } from "./constants";

const initialState = {
  // classDTOApproveAuction: {
  //   auctionid: 95,
  //   clientid: 10,
  // },
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.GET_ALL_AUCTION_DETAILS_BY_AUCTIONID_SUCCESS: {
      state.getAllAucionDetailsByAuctionId = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }
    case ActionTypes.APPROVE_AUCTION: {
      state.approveAuction = action.payload.data || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
