import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { apiFetch } from "../../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../../commonConstants/constants";
import { CustomToast as toast } from "../../../components/GenericComponents/Toast";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

export function* getAllAucionDetailsByAuctionId() {
  // {auctionid}
  let response = yield apiFetch(
    `eauction/auctioneer/getAuction/${getLocalStorageItem(
      "auctionIdForApproveAuction"
    )}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    yield put({
      type: ActionTypes.GET_ALL_AUCTION_DETAILS_BY_AUCTIONID_SUCCESS,
      payload: {
        value: responseJSON.responseData,
      },
    });
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_AUCTION_DETAILS_BY_AUCTIONID_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}
export function* approveAuction({ payload }) {
  let response = yield apiFetch(
    `eauction/auctioneer/approveauction/${getLocalStorageItem(
      "auctionIdForApproveAuction"
    )}/${getLocalStorageItem("clientId")}`,
    {
      method: "POST",
      body: JSON.stringify(payload.data),
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON.responseObj || {};
      toast.success(responseJSON.message);

      window.location.href = "/auctionList";
      yield put({
        type: ActionTypes.APPROVE_AUCTION_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.APPROVE_AUCTION_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.GET_ALL_AUCTION_DETAILS_BY_AUCTIONID,
      getAllAucionDetailsByAuctionId
    ),
  ]);

  yield all([takeLatest(ActionTypes.APPROVE_AUCTION, approveAuction)]);
}
