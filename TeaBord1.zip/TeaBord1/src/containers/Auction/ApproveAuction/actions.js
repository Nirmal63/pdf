import { ActionTypes } from "./constants";

export function getAllAucionDetailsByAuctionId() {
  return {
    type: ActionTypes.GET_ALL_AUCTION_DETAILS_BY_AUCTIONID,
  };
}
export function approveAuction(data) {
  return {
    type: ActionTypes.APPROVE_AUCTION,
    payload: {
      data: data,
    },
  };
}

// export function updateApproveAuction(payload) {
//   return {
//     type: ActionTypes.UPDATE_APPROVE_AUCTION_DATA,
//     payload: {
//       data: payload,
//     },
//   };
// }
