import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "createDesignation";

export const ActionTypes = keyMirrorRecursive(
  {
    GET_ALL_AUCTION_DETAILS_BY_AUCTIONID: undefined,
    GET_ALL_AUCTION_DETAILS_BY_AUCTIONID_SUCCESS: undefined,
    // UPDATE_APPROVE_AUCTION_DATA: undefined,
    APPROVE_AUCTION: undefined,
    APPROVE_AUCTION_SUCCESS: undefined,
  },
  pageName
);
