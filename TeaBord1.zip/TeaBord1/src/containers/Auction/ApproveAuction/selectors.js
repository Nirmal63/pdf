import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getAllAucionDetailsByAuctionId = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.getAllAucionDetailsByAuctionId
  );

export const approveAuction = () =>
  createSelector(stateSelector, (bstate) => bstate.approveAuction);
