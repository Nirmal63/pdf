import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import CreateApproveAuction from "../../../components/Auction/Approve Auction";

class index extends Component {
  componentDidMount() {
    this.props.getAllAucionDetailsByAuctionId();
  }

  handleButtonsApproveAuction = (name, value) => {
    switch (name) {
      case "submit": {
        this.props.approveAuction();
        break;
      }

      default: {
        break;
      }
    }
  };

  componentWillUnmount() {
    localStorage.removeItem("auctionIdForApproveAuction");
  }

  render() {
    return (
      <CreateApproveAuction
        {...this.props}
        // handleClassDTOApproveAuction={this.handleClassDTOApproveAuction}
        handleButtonsApproveAuction={this.handleButtonsApproveAuction}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    getAllAucionDetailsByAuctionId: () => {
      dispatch(actions.getAllAucionDetailsByAuctionId());
    },
    approveAuction: (data) => {
      dispatch(actions.approveAuction(data));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    getAllAucionDetailsByAuctionIdResponse:
      selectors.getAllAucionDetailsByAuctionId(),
    approveAuctionResponse: selectors.approveAuction(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
