import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import CreateAuctionComponent from "../../../components/Auction/CreateAuctionV1";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import $ from "jquery";

class index extends Component {
  componentDidMount() {
    this.props.getAllDepartmentDetails();
    this.props.getAllCurrencyDetails();
  }

  handleClassDTOCreateAuction = (key, value) => {
    let { classDTOCreateAuction } = this.props;
    classDTOCreateAuction.isValidationSuccess = true;

    switch (key) {
      default: {
        classDTOCreateAuction[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTOCreateAuction);
  };

  checkValidations = (key, data) => {
    let { classDTOCreateAuction, updateClassDTOCreateAuction } = this.props;

    classDTOCreateAuction = data;
    classDTOCreateAuction.isValidationSuccess = true;

    if ("tblDepartment" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.tblDepartment)) {
        classDTOCreateAuction.tblDepartmentError = "Please select";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.tblDepartmentError = "";
        if ("tblDepartment" === key) {
          this.props.getAllOfficerDetails(classDTOCreateAuction.tblDepartment);
        }
      }
    }

    if ("userDetailId" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.userDetailId)) {
        classDTOCreateAuction.userDetailIdError = "Please select";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.userDetailIdError = "";
      }
    }

    if ("auctionNo" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.auctionNo)) {
        classDTOCreateAuction.auctionNoError = "Please enter";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.auctionNoError = "";
      }
    }

    if ("displayOfficerName" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.displayOfficerName)) {
        classDTOCreateAuction.displayOfficerNameError = "Please select";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.displayOfficerNameError = "";
      }
    }

    if ("auctionBrief" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.auctionBrief)) {
        classDTOCreateAuction.auctionBriefError = "Please enter";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.auctionBriefError = "";
      }
    }

    if ("auctionDetail" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.auctionDetail)) {
        classDTOCreateAuction.auctionDetailError = "Please enter";
        classDTOCreateAuction.isValidationSuccess = false;
      } else {
        classDTOCreateAuction.auctionDetailError = "";
      }
    }

    updateClassDTOCreateAuction(classDTOCreateAuction);
  };

  handleButtonsCreateAuction = (name) => {
    var { classDTOCreateAuction } = this.props;

    switch (name) {
      case "submit": {
        this.checkValidations("all", classDTOCreateAuction);
        if (classDTOCreateAuction.isValidationSuccess) {
          this.props.submitCreateAuctionDetails(classDTOCreateAuction);
        }
        break;
      }

      case "prevButton": {
        $(".nav > .active").prev("li").find("button").trigger("click");
        break;
      }

      case "nextButton": {
        this.checkValidations("all", classDTOCreateAuction);
        if (classDTOCreateAuction.isValidationSuccess) {
          $(".nav > .active").next("li").find("button").trigger("click");
        }
        break;
      }

      default: {
        break;
      }
    }
  };

  render() {
    return (
      <CreateAuctionComponent
        {...this.props}
        handleClassDTOCreateAuction={this.handleClassDTOCreateAuction}
        handleButtonsCreateAuction={this.handleButtonsCreateAuction}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    updateClassDTOCreateAuction: (payload) => {
      dispatch(actions.updateClassDTOCreateAuction(payload));
    },

    submitCreateAuctionDetails: (data) => {
      dispatch(actions.submitCreateAuctionDetails(data));
    },

    getAllCurrencyDetails: () => {
      dispatch(actions.getAllCurrencyDetails());
    },

    getAllDepartmentDetails: () => {
      dispatch(actions.getAllDepartmentDetails());
    },

    getAllOfficerDetails: (payload) => {
      dispatch(actions.getAllOfficerDetails(payload));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTOCreateAuction: selectors.getClassDTOCreateAuction(),
    getAllCurrencyDetailsResponse: selectors.getAllCurrencyDetails(),
    getAllDepartmentDetailsResponse: selectors.getAllDepartmentDetails(),
    getAllOfficerDetailsResponse: selectors.getAllOfficerDetails(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
