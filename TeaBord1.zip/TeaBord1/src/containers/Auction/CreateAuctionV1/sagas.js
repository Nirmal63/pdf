import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";
import { apiFetch } from "../../../utility/fetch-utils";
import { toast } from "react-toastify";
toast.configure();

export function* submitCreateAuctionDetails({ payload }) {
  let response = yield apiFetch("eauction/auctioneer/create", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.code) {
      var responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.SUBMIT_CREATE_AUCTION_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message, {
        position: toast.POSITION.TOP_CENTER,
      });
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_CREATE_AUCTION_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(
      "The task you are trying to perform is temporarily unavailable. Kindly contact administrator.",
      {
        autoClose: 10000,
        position: toast.POSITION.TOP_CENTER,
      }
    );
  }
}

export function* getAllCurrencyDetails() {
  let response = yield apiFetch(`common/currency/getAllCurrency`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_CURRENCY_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(
        responseJSON.message ||
          "The task you are trying to perform is temporarily unavailable. Kindly contact administrator.",
        {
          autoClose: 10000,
          position: toast.POSITION.TOP_CENTER,
        }
      );
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_CURRENCY_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(
      "The task you are trying to perform is temporarily unavailable. Kindly contact administrator.",
      {
        autoClose: 10000,
        position: toast.POSITION.TOP_CENTER,
      }
    );
  }
}

export function* getAllDepartmentDetails() {
  // clientId
  let response = yield apiFetch(
    `common/dept/getdepthierarchy/${getLocalStorageItem("clientId")}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    yield put({
      type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: responseJSON,
      },
    });

    // if (200 === responseJSON.statusCode) {
    //   let responseObj = responseJSON || {};
    //   yield put({
    //     type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
    //     payload: {
    //       value: responseObj.responseData,
    //     },
    //   });
    // } else {
    //   // toast.error(
    //   //   responseJSON.message ||
    //   //     "The task you are trying to perform is temporarily unavailable. Kindly contact administrator.",
    //   //   {
    //   //     autoClose: 10000,
    //   //     position: toast.POSITION.TOP_CENTER,
    //   //   }
    //   // );
    // }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(
      "The task you are trying to perform is temporarily unavailable. Kindly contact administrator.",
      {
        autoClose: 10000,
        position: toast.POSITION.TOP_CENTER,
      }
    );
  }
}

export function* getAllOfficerDetails({ payload }) {
  let response = yield apiFetch(`common/user/getofficer/${payload}`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_OFFICER_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(
        responseJSON.message ||
          "The task you are trying to perform is temporarily unavailable. Kindly contact administrator.",
        {
          autoClose: 10000,
          position: toast.POSITION.TOP_CENTER,
        }
      );
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_OFFICER_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(
      "The task you are trying to perform is temporarily unavailable. Kindly contact administrator.",
      {
        autoClose: 10000,
        position: toast.POSITION.TOP_CENTER,
      }
    );
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_CREATE_AUCTION_DETAILS,
      submitCreateAuctionDetails
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_CURRENCY_DETAILS, getAllCurrencyDetails),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_DEPARTMENT_DETAILS, getAllDepartmentDetails),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_OFFICER_DETAILS, getAllOfficerDetails),
  ]);
}
