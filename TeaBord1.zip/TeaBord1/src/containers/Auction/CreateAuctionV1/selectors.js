import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getClassDTOCreateAuction = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTOCreateAuction);

export const getAllCurrencyDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllCurrencyDetails);

export const getAllDepartmentDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllDepartmentDetails);

export const getAllOfficerDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllOfficerDetails);
