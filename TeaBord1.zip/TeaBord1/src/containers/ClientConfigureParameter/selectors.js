import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getClientCustomParameterDetails = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.getClientCustomParameterDetails
  );

export const getAllprocurementnature = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllprocurementnature);

export const getClassDTOClientConfig = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTOClientConfig);
