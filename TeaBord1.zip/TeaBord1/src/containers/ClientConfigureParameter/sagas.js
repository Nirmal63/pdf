import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { apiFetch } from "../../utility/fetch-utils";
import {
  ERROR_MESSAGE_FOR_DEFAULT,
  ERROR_MESSAGE_FOR_400,
} from "../../commonConstants/constants";
import { CustomToast as toast } from "../../components/GenericComponents/Toast";
import { getLocalStorageItem } from "../../commonConstants/LocalStorageData";

export function* submitClientConfig({ payload }) {
  let eventTypeId = 1;

  let response = yield apiFetch(
    `common/defaultconfiguration/saveallcustomparameter/${eventTypeId}/${getLocalStorageItem(
      "clientId"
    )}`,
    {
      method: "POST",
      body: JSON.stringify(payload.data),
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      toast.success(responseJSON.message);
      var responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.SUBMIT_CLIENT_CUSTOM_PARAMETER_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
      // window.location.reload();
    } else {
      toast.error(responseJSON.message);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_CLIENT_CUSTOM_PARAMETER_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else if (400 === response.status) {
    toast.error(ERROR_MESSAGE_FOR_400);
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getClientCustomParameterDetails({ payload }) {
  let eventTypeId = payload.eventTypeId;
  let moduleId = payload.moduleId;
  let clientId = payload.clientId;

  let response = yield apiFetch(
    `common/defaultconfiguration/getallcustomparameter/${eventTypeId}/${moduleId}/${clientId}}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};

      if (200 === responseObj.statusCode) {
        yield put({
          type: ActionTypes.GET_CLIENT_CUSTOM_PARAMETER_DETAILS_SUCCESS,
          payload: {
            value: responseObj.responseData,
          },
        });
      }
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.statusCode) {
    yield put({
      type: ActionTypes.GET_CLIENT_CUSTOM_PARAMETER_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllprocurementnature() {
  let response = yield apiFetch(
    `/common/procurementnature/getAllprocurementnature`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_PROCUREMENT_NATURE_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_PROCUREMENT_NATURE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_CLIENT_CUSTOM_PARAMETER_DETAILS,
      submitClientConfig
    ),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_CLIENT_CUSTOM_PARAMETER_DETAILS,
      getClientCustomParameterDetails
    ),
  ]);
  yield all([
    takeLatest(
      ActionTypes.GET_ALL_PROCUREMENT_NATURE_DETAILS,
      getAllprocurementnature
    ),
  ]);
}
