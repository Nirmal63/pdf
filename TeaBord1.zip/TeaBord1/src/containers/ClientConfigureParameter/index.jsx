import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import $ from "jquery";
import ClientConfigureParameter from "../../components/ClientConfigureParameter";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";
import { getLocalStorageItem } from "../../commonConstants/LocalStorageData";

class index extends Component {
  componentDidMount() {
    let data = {
      eventTypeId: 1,
      moduleId: 5,
      clientid: getLocalStorageItem("clientId"),
    };
    this.props.getClientCustomParameterDetails(data);
    this.props.getAllprocurementnature();
  }

  handleClassDTOClientConfig = (key, value) => {
    let { classDTOClientConfig, updateClassDTOClientConfig } = this.props;
    classDTOClientConfig.isValidationSuccess = true;

    switch (key) {
      default: {
        classDTOClientConfig[key] = value;
        break;
      }
    }
    //this.checkValidations(key, classDTOClientConfig);

    updateClassDTOClientConfig(classDTOClientConfig);
  };

  handleChange = (name, value, id, typeOfData) => {
    const {
      getClientCustomParameterDetailsResponse,
      updateGetClientCustomParameterDetailsResponse,
      classDTOClientConfig,
      updateClassDTOClientConfig,
    } = this.props;

    let data = getClientCustomParameterDetailsResponse;

    switch (typeOfData) {
      case "fieldId": {
        const updatedData =
          data &&
          data.customParameterDTOList &&
          data.customParameterDTOList.map((customParameterDTO) => {
            if (customParameterDTO.fieldId != id) return customParameterDTO;
            if (customParameterDTO.fieldId == id) {
              return { ...customParameterDTO, [name]: value };
            }
          });
        data.customParameterDTOList = updatedData;
      }
      case "columnTypeId": {
        //For submit JSON update
        const updatedColumnTypeData =
          data &&
          data.clientColumnTypeDTOList &&
          data.clientColumnTypeDTOList.map((clientColumnTypeDTO) => {
            if (clientColumnTypeDTO.columnTypeId != id)
              return clientColumnTypeDTO;
            if (clientColumnTypeDTO.columnTypeId == id) {
              return { ...clientColumnTypeDTO, [name]: value };
            }
          });
        data.clientColumnTypeDTOList = updatedColumnTypeData;

        //For ColumnType DTO update
        let classDTOClientConfigTemp = classDTOClientConfig;

        let tempDataOfClassDTO =
          classDTOClientConfigTemp &&
          classDTOClientConfigTemp.columnTypeIdList1 &&
          classDTOClientConfigTemp.columnTypeIdList1.map((columnTypeId) => {
            if (columnTypeId.columnTypeId != id) return columnTypeId;
            if (columnTypeId.columnTypeId == id) {
              return { ...columnTypeId, [name]: value };
            }
          });

        classDTOClientConfigTemp.columnTypeIdList1 = tempDataOfClassDTO;
        updateClassDTOClientConfig(classDTOClientConfigTemp);
      }
    }
    this.checkValidations(name, data, id, value);
    // updateGetClientCustomParameterDetailsResponse(data);
  };

  checkValidations = (name, data1, id, value) => {
    let {
      getClientCustomParameterDetailsResponse,
      updateGetClientCustomParameterDetailsResponse,
    } = this.props;

    getClientCustomParameterDetailsResponse = data1;

    getClientCustomParameterDetailsResponse.isValidationSuccess = true;

    if (
      "defaultvalue" === name ||
      "generalConfiguration" == name ||
      "resultConfiguration" == name ||
      "basicDetails" == name ||
      "timeAutoExtensionConfiguration" == name ||
      "all" === name
    ) {
      let tempData =
        getClientCustomParameterDetailsResponse.customParameterDTOList &&
        getClientCustomParameterDetailsResponse.customParameterDTOList.map(
          (customParameterDTO) => {
            if ("defaultvalue" === name) {
              if (customParameterDTO.fieldId != id) return customParameterDTO;
              if (customParameterDTO.fieldId == id) {
                if (
                  (customParameterDTO.fieldId === 1170 ||
                    customParameterDTO.fieldId === 477 ||
                    customParameterDTO.fieldId === 1125 ||
                    customParameterDTO.fieldId === 1127) &&
                  isNullOrIsEmptyOrIsUndefined(value)
                ) {
                  // getClientCustomParameterDetailsResponse.defaultvalueError =
                  //   "Please select EMD payable at";
                  // getClientCustomParameterDetailsResponse.isValidationSuccess = false;
                  getClientCustomParameterDetailsResponse.isValidationSuccess = false;
                  return {
                    ...customParameterDTO,
                    defaultvalueError: "Please enter value",
                  };
                } else {
                  return {
                    ...customParameterDTO,
                    defaultvalueError: "",
                  };
                }
              }
            } else {
              if ("basicDetails" == name) {
                if (
                  customParameterDTO.fieldId === 1170 &&
                  isNullOrIsEmptyOrIsUndefined(customParameterDTO.defaultvalue)
                ) {
                  getClientCustomParameterDetailsResponse.isValidationSuccess = false;
                  return {
                    ...customParameterDTO,
                    defaultvalueError: "Please enter",
                  };
                } else {
                  return customParameterDTO;
                }
              } else if ("generalConfiguration" == name) {
                if (
                  customParameterDTO.fieldId === 477 &&
                  isNullOrIsEmptyOrIsUndefined(customParameterDTO.defaultvalue)
                ) {
                  getClientCustomParameterDetailsResponse.isValidationSuccess = false;
                  return {
                    ...customParameterDTO,
                    defaultvalueError: "Please select",
                  };
                } else if (
                  (customParameterDTO.fieldId === 477 ||
                    customParameterDTO.fieldId === 55 ||
                    customParameterDTO.fieldId === 56 ||
                    customParameterDTO.fieldId === 285 ||
                    customParameterDTO.fieldId === 490 ||
                    customParameterDTO.fieldId === 880 ||
                    customParameterDTO.fieldId === 474) &&
                  isNaN(customParameterDTO.defaultvalue)
                ) {
                  getClientCustomParameterDetailsResponse.isValidationSuccess = false;
                  return {
                    ...customParameterDTO,
                    defaultvalueError: "Please enter a numeric value",
                  };
                } else if (
                  (customParameterDTO.fieldId === 338 ||
                    customParameterDTO.fieldId === 983) &&
                  !isNullOrIsEmptyOrIsUndefined(
                    customParameterDTO.defaultvalue
                  ) &&
                  !/^[A-Za-z\s]+$/.test(customParameterDTO.defaultvalue)
                ) {
                  getClientCustomParameterDetailsResponse.isValidationSuccess = false;
                  return {
                    ...customParameterDTO,
                    defaultvalueError:
                      "Please enter alphabetic characters only",
                  };
                } else {
                  return customParameterDTO;
                }
              } else if ("resultConfiguration" == name) {
                if (
                  (customParameterDTO.fieldId === 1125 ||
                    customParameterDTO.fieldId === 1127) &&
                  isNullOrIsEmptyOrIsUndefined(customParameterDTO.defaultvalue)
                ) {
                  getClientCustomParameterDetailsResponse.isValidationSuccess = false;
                  return {
                    ...customParameterDTO,
                    defaultvalueError: "Please enter",
                  };
                } else if (
                  (customParameterDTO.fieldId === 1125 ||
                    customParameterDTO.fieldId === 1127 ||
                    customParameterDTO.fieldId === 374 ||
                    customParameterDTO.fieldId === 1129) &&
                  isNaN(customParameterDTO.defaultvalue)
                ) {
                  getClientCustomParameterDetailsResponse.isValidationSuccess = false;
                  return {
                    ...customParameterDTO,
                    defaultvalueError: "Please enter a numeric value",
                  };
                } else {
                  return customParameterDTO;
                }
              } else if ("timeAutoExtensionConfiguration" == name) {
                // if (
                //   (customParameterDTO.fieldId === 1125 ||
                //     customParameterDTO.fieldId === 1127) &&
                //   isNullOrIsEmptyOrIsUndefined(customParameterDTO.defaultvalue)
                // ) {
                //   getClientCustomParameterDetailsResponse.isValidationSuccess = false;
                //   return {
                //     ...customParameterDTO,
                //     defaultvalueError: "Please enter",
                //   };
                // } else
                if (
                  (customParameterDTO.fieldId === 59 ||
                    customParameterDTO.fieldId === 60 ||
                    customParameterDTO.fieldId === 61 ||
                    customParameterDTO.fieldId === 323) &&
                  isNaN(customParameterDTO.defaultvalue)
                ) {
                  getClientCustomParameterDetailsResponse.isValidationSuccess = false;
                  return {
                    ...customParameterDTO,
                    defaultvalueError: "Please enter a numeric value",
                  };
                } else {
                  return customParameterDTO;
                }
              } else {
                return customParameterDTO;
              }
            }
          }
        );

      getClientCustomParameterDetailsResponse.customParameterDTOList = tempData;
    }
    updateGetClientCustomParameterDetailsResponse(
      getClientCustomParameterDetailsResponse
    );
  };

  handleButtonsClientConfig = (name, value) => {
    console.log("in con next", name);
    var { classDTOClientConfig, getClientCustomParameterDetailsResponse } =
      this.props;
    let data = getClientCustomParameterDetailsResponse;

    switch (name) {
      case "submit": {
        this.checkValidations("all", data);

        getClientCustomParameterDetailsResponse.clientColumnTypeDTOList =
          classDTOClientConfig && classDTOClientConfig.columnTypeIdList1;
        this.props.submitClientConfig(data);
        //this.checkValidations("all", classDTOClientConfig);
        // if (classDTOClientConfig.isValidationSuccess) {
        // this.props.submitClientConfig(getClientCustomParameterDetailsResponse);
        // classDTOClientConfig columnTypeIdList;
        //this.setState({ submitStatus: "success" });
        // }
        break;
      }

      case "prevButton": {
        $(".nav > .active").prev("li").find("button").trigger("click");
        break;
      }

      case "nextButton": {
        this.checkValidations(value, data);
        if (getClientCustomParameterDetailsResponse.isValidationSuccess) {
          $(".nav > .active").next("li").find("button").trigger("click");
        }

        break;
      }

      default: {
        break;
      }
    }
  };

  selectRecord = (event, element, key, filterKey, allData) => {
    let classDTOClientConfig = JSON.parse(
      JSON.stringify(this.props.classDTOClientConfig)
    );

    let tempObj = [];
    if (element) {
      let recordListObj = classDTOClientConfig[key] || [];
      if (event.target.checked) {
        recordListObj.push(element);
      } else {
        recordListObj.splice(recordListObj.indexOf(element), 1);
      }
      if (recordListObj && recordListObj.length && recordListObj.length > 0) {
        for (let rec = 0; rec < recordListObj.length; rec++) {
          let data =
            allData &&
            allData.filter((data) => data[filterKey] == recordListObj[rec])[0];
          tempObj.push(data);
        }
      }

      this.handleClassDTOClientConfig(key + 1, tempObj);
      this.handleClassDTOClientConfig(key, recordListObj);
    } else {
      this.handleClassDTOClientConfig(key + 1, []);
      this.handleClassDTOClientConfig(key, []);
    }
  };

  render() {
    return (
      <ClientConfigureParameter
        {...this.props}
        handleButtonsClientConfig={this.handleButtonsClientConfig}
        handleClassDTOClientConfig={this.handleClassDTOClientConfig}
        handleChange={this.handleChange}
        selectRecord={this.selectRecord}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    getClientCustomParameterDetails: (data) => {
      dispatch(actions.getClientCustomParameterDetails(data));
    },

    updateGetClientCustomParameterDetailsResponse: (data) => {
      dispatch(actions.updateGetClientCustomParameterDetailsResponse(data));
    },

    getAllprocurementnature: () => {
      dispatch(actions.getAllprocurementnature());
    },

    updateClassDTOClientConfig: (payload) => {
      dispatch(actions.updateClassDTOClientConfig(payload));
    },

    submitClientConfig: (data) => {
      dispatch(actions.submitClientConfig(data));
    },
  };
}

// function mapStateToProps() {
//   return createStructuredSelector({
//     getClientCustomParameterDetailsResponse: selectors.getClientCustomParameterDetails(),
//     getAllprocurementnatureResponse:selectors.getAllprocurementnature(),
//     classDTOClientConfig:selectors.getClassDTOClientConfig(),
//   });
// }
function mapStateToProps(state) {
  return {
    getClientCustomParameterDetailsResponse:
      selectors.getClientCustomParameterDetails()(state),
    getAllprocurementnatureResponse: selectors.getAllprocurementnature()(state),
    classDTOClientConfig: selectors.getClassDTOClientConfig()(state),
  };
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
