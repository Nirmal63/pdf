import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "defaultconfiguration";

export const ActionTypes = keyMirrorRecursive(
  {
    SUBMIT_CLIENT_CUSTOM_PARAMETER_DETAILS: undefined,
    SUBMIT_CLIENT_CUSTOM_PARAMETER_DETAILS_SUCCESS: undefined,
    GET_CLIENT_CUSTOM_PARAMETER_DETAILS: undefined,
    GET_CLIENT_CUSTOM_PARAMETER_DETAILS_SUCCESS: undefined,
    GET_ALL_PROCUREMENT_NATURE_DETAILS: undefined,
    GET_ALL_PROCUREMENT_NATURE_DETAILS_SUCCESS: undefined,
    UPDATE_CLASS_DTO_CLIENT_DEFAULT_CONFIG: undefined,
    UPDATE_CLASS_DTO_CLIENT_CONFIG: undefined,
  },
  pageName
);

export const HIDE_SHOW_VALUES = [
  {
    displayKey: "Show",
    value: 1,
  },
  {
    displayKey: "Hide",
    value: 0,
  },
];
