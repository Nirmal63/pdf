import { ActionTypes } from "./constants";

export function getClientCustomParameterDetails(payload) {
  return {
    type: ActionTypes.GET_CLIENT_CUSTOM_PARAMETER_DETAILS,
    payload,
  };
}

export function updateGetClientCustomParameterDetailsResponse(payload) {
  return {
    type: ActionTypes.GET_CLIENT_CUSTOM_PARAMETER_DETAILS_SUCCESS,
    payload: {
      value: payload,
    },
  };
}

export function getAllprocurementnature(payload) {
  return {
    type: ActionTypes.GET_ALL_PROCUREMENT_NATURE_DETAILS,
    payload,
  };
}

export function updateClassDTOClientConfig(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_CLIENT_CONFIG,
    payload: {
      value: payload,
    },
  };
}

export function submitClientConfig(data) {
  return {
    type: ActionTypes.SUBMIT_CLIENT_CUSTOM_PARAMETER_DETAILS,
    payload: {
      data: data,
    },
  };
}
