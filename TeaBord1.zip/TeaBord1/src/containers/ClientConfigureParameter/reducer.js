import { ActionTypes } from "./constants";

const initialState = {
  classDTOClientConfig: {
    columnTypeIdList1: [],
    columnTypeIdList: [],
  }, // Initialize as an empty object
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.GET_CLIENT_CUSTOM_PARAMETER_DETAILS_SUCCESS: {
      state.getClientCustomParameterDetails = action.payload.value;
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_PROCUREMENT_NATURE_DETAILS_SUCCESS: {
      state.getAllprocurementnature = action.payload.value;
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.UPDATE_CLASS_DTO_CLIENT_CONFIG: {
      state.classDTOClientConfig = action.payload.value;
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
