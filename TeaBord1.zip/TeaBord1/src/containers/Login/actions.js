import { ActionTypes } from "./constants";

export function updateClassDTOLogin(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_LOGIN,
    payload,
  };
}

export function submitLoginDetails(data) {
  return {
    type: ActionTypes.SUBMIT_LOGIN_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function updateSubmitDetailsResponse(data) {
  return {
    type: ActionTypes.SUBMIT_LOGIN_DETAILS_SUCCESS,
    payload: {
      value: data,
    },
  };
}
