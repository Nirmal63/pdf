import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "login";

export const ActionTypes = keyMirrorRecursive(
  {
    UPDATE_CLASS_DTO_LOGIN:undefined,
    SUBMIT_LOGIN_DETAILS: undefined,
    SUBMIT_LOGIN_DETAILS_SUCCESS: undefined,
  },
  pageName
);
