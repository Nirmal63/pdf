import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { ActionTypes as ActionTypesHome } from "../Home/constants";
import { apiFetch } from "../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../commonConstants/constants";
import { CustomToast as toast } from "../../components/GenericComponents/Toast";
import { setLocalStorageItem } from "../../commonConstants/LocalStorageData";

export function* submitLoginDetails({ payload }) {
  let response = yield apiFetch("auth/token", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON.responseData || {};

      setLocalStorageItem("token", responseObj && responseObj.token);
      setLocalStorageItem("userId", responseObj && responseObj.userId);
      setLocalStorageItem("usertypeId", responseObj && responseObj.usertypeId);
      setLocalStorageItem("clientId", 10);

      window.$("#exampleModal").modal("hide");
      window.location.href = "/createClient";
      yield put({
        type: ActionTypesHome.UPDATE_IS_AUTHENTICATED,
        payload: {
          data: true,
        },
      });

      yield put({
        type: ActionTypes.SUBMIT_LOGIN_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.SUBMIT_LOGIN_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_LOGIN_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([takeLatest(ActionTypes.SUBMIT_LOGIN_DETAILS, submitLoginDetails)]);
}
