import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import LoginComponent from "../../components/Login";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";
import $ from "jquery";

class index extends Component {
  componentDidMount() {
    let data = {
      loginId: "",
      loginIdError: "",
      password: "",
      passwordError: "",
    };
    this.props.updateClassDTOLogin(data);
  }

  handleClassDTOLogin = (key, value) => {
    let { classDTOLogin } = this.props;
    classDTOLogin.isValidationSuccess = true;

    switch (key) {
      default: {
        classDTOLogin[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTOLogin);
  };

  checkValidations = (key, data) => {
    let { classDTOLogin, updateClassDTOLogin } = this.props;

    classDTOLogin = data;
    classDTOLogin.isValidationSuccess = true;

    if ("loginId" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.loginId)) {
        classDTOLogin.loginIdError = "Please enter email id";
        classDTOLogin.isValidationSuccess = false;
      } else {
        classDTOLogin.loginIdError = "";
      }
    }

    if ("password" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.password)) {
        classDTOLogin.passwordError = "Please enter password";
        classDTOLogin.isValidationSuccess = false;
      } else {
        classDTOLogin.passwordError = "";
      }
    }

    updateClassDTOLogin(classDTOLogin);
  };

  handleButtonsLogin = (name) => {
    let { classDTOLogin } = this.props;

    switch (name) {
      case "login": {
        this.checkValidations("all", classDTOLogin);
        if (classDTOLogin.isValidationSuccess) {
          this.props.submitLoginDetails(classDTOLogin);
        }
        break;
      }
      default: {
        break;
      }
    }
  };

  render() {
    return (
      <LoginComponent
        {...this.props}
        flag={this.props.flag}
        openPopUp={this.props.onClickOfLogin}
        handleClassDTOLogin={this.handleClassDTOLogin}
        handleButtonsLogin={this.handleButtonsLogin}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    updateClassDTOLogin: (payload) => {
      dispatch(actions.updateClassDTOLogin(payload));
    },
    submitLoginDetails: (data) => {
      dispatch(actions.submitLoginDetails(data));
    },
    updateSubmitDetailsResponse: (data) => {
      dispatch(actions.updateSubmitDetailsResponse(data));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTOLogin: selectors.getClassDTOLogin(),
    submitDetailsResponse: selectors.submitDetailsResponse(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
