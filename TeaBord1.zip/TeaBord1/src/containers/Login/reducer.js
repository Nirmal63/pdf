import { ActionTypes } from "./constants";

const initialState = {
  classDTOLogin: {},
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.UPDATE_CLASS_DTO_LOGIN: {
      state.classDTOLogin = action.payload || {};
      return JSON.parse(JSON.stringify(state));
    }
    case ActionTypes.SUBMIT_LOGIN_DETAILS_SUCCESS: {
      state.submitDetailsResponse = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }
    default:
      return JSON.parse(JSON.stringify(state));
  }
}
