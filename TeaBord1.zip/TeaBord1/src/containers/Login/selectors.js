import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getClassDTOLogin = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTOLogin);
  
export const submitDetailsResponse = () =>
  createSelector(stateSelector, (bstate) => bstate.submitDetailsResponse);