import { ActionTypes } from "./constants";

const initialState = {
  classDTOCreateGrade: {
    gradeName: "",
    gradelevel: "",
    maxLimit: "",
    minLimit: "",
    clientId: 10,
  },
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.UPDATE_CLASS_DTO_CREATE_GRADE: {
      state.classDTOCreateGrade = action.payload.data || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
