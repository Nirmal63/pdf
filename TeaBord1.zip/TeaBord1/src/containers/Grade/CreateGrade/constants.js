import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "createGrade";

export const ActionTypes = keyMirrorRecursive(
    {
      UPDATE_CLASS_DTO_CREATE_GRADE: undefined,
      SUBMIT_CREATE_GRADE_DETAILS: undefined,
      SUBMIT_CREATE_GRADE_DETAILS_SUCCESS: undefined,
    },
    pageName
  );

  export const GRADE_LEVEL = [
    {
      displayKey: "1",
      value: 1,
    },
    {
      displayKey: "2",
      value: 2,
    },
    {
      displayKey: "3",
      value: 3,
    },
    {
      displayKey: "3",
      value: 3,
    },
    {
      displayKey: "4",
      value: 4,
    },
    {
      displayKey: "5",
      value: 5,
    },
    {
      displayKey: "6",
      value: 6,
    },
    {
      displayKey: "7",
      value: 7,
    },
    {
      displayKey: "8",
      value: 8,
    },
    {
      displayKey: "9",
      value: 9,
    },
    {
      displayKey: "10",
      value: 10,
    },
    {
      displayKey: "11",
      value: 11,
    },
    {
      displayKey: "12",
      value: 12,
    },
    {
      displayKey: "13",
      value: 13,
    },
    {
      displayKey: "14",
      value: 14,
    },
    {
      displayKey: "15",
      value: 15,
    },
  ];