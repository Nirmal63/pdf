import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import CreateGradeComponent from "../../../components/Grade/CreateGrade";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

class index extends Component {
  handleClassDTOCreateGrade = (key, value) => {
    let { classDTOCreateGrade } = this.props;
    classDTOCreateGrade.isValidationSuccess = true;

    switch (key) {
      default: {
        classDTOCreateGrade[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTOCreateGrade);
  };

  checkValidations = (key, data) => {
    let { classDTOCreateGrade, updateClassDTOCreateGrade } = this.props;

    classDTOCreateGrade = data;
    classDTOCreateGrade.isValidationSuccess = true;

    if ("gradeName" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.gradeName)) {
        classDTOCreateGrade.gradeNameError = "Please enter";
        classDTOCreateGrade.isValidationSuccess = false;
      } else {
        classDTOCreateGrade.gradeNameError = "";
      }
    }

    if ("gradelevel" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.gradelevel)) {
        classDTOCreateGrade.gradelevelError = "Please select a grade level";
        classDTOCreateGrade.isValidationSuccess = false;
      } else {
        classDTOCreateGrade.gradelevelError = "";
      }
    }

    if ("minLimit" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.minLimit)) {
        classDTOCreateGrade.minLimitError = "Please enter";
        classDTOCreateGrade.isValidationSuccess = false;
      } else {
        classDTOCreateGrade.minLimitError = "";
      }
    }

    if ("maxLimit" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.maxLimit)) {
        classDTOCreateGrade.maxLimitError = "Please enter";
        classDTOCreateGrade.isValidationSuccess = false;
      } else {
        classDTOCreateGrade.maxLimitError = "";
      }
    }

    updateClassDTOCreateGrade(classDTOCreateGrade);
  };

  handleButtonsCreateGrade = (name) => {
    var { classDTOCreateGrade } = this.props;

    switch (name) {
      case "submit": {
        this.checkValidations("all", classDTOCreateGrade);
        if (classDTOCreateGrade.isValidationSuccess) {
          classDTOCreateGrade.clientId = getLocalStorageItem("clientId");
          this.props.submitCreateGradeDetails(classDTOCreateGrade);
        }
        break;
      }

      default: {
        break;
      }
    }
  };

  resetData = () => {
    let classDTOCreateGrade = {
      gradeName: "",
      gradelevel: "",
      maxLimit: "",
      minLimit: "",
      clientId: getLocalStorageItem("clientId"),
    };
    this.props.updateClassDTOCreateGrade(classDTOCreateGrade);
  };

  componentWillUnmount() {
    this.resetData();
  }

  render() {
    return (
      <CreateGradeComponent
        {...this.props}
        handleClassDTOCreateGrade={this.handleClassDTOCreateGrade}
        handleButtonsCreateGrade={this.handleButtonsCreateGrade}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    submitCreateGradeDetails: (data) => {
      dispatch(actions.submitCreateGradeDetails(data));
    },
    updateClassDTOCreateGrade: (payload) => {
      dispatch(actions.updateClassDTOCreateGrade(payload));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTOCreateGrade: selectors.getClassDTOCreateGrade(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
