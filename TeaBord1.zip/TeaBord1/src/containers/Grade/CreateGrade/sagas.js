import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { apiFetch } from "../../../utility/fetch-utils";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../../commonConstants/constants";
import { CustomToast as toast } from "../../../components/GenericComponents/Toast";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

export function* submitCreateGradeDetails({ payload }) {
  let response = yield apiFetch("common/grade/create", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      var responseObj = responseJSON.responseObj || {};
      toast.success(responseJSON.message);

      let data = {
        gradeName: "",
        gradelevel: "",
        maxLimit: "",
        minLimit: "",
        clientId: getLocalStorageItem("clientId"),
      };
      yield put({
        type: ActionTypes.UPDATE_CLASS_DTO_CREATE_GRADE,
        payload: {
          data: data,
        },
      });
      yield put({
        type: ActionTypes.SUBMIT_CREATE_GRADE_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.success(responseJSON.message);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_CREATE_GRADE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_CREATE_GRADE_DETAILS,
      submitCreateGradeDetails
    ),
  ]);
}
