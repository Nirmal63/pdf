import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getClassDTOCreateGrade = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTOCreateGrade);