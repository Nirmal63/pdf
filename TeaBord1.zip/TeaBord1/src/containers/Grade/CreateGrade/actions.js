import { ActionTypes } from "./constants";

export function submitCreateGradeDetails(data) {
  return {
    type: ActionTypes.SUBMIT_CREATE_GRADE_DETAILS,
    payload: {
      data: data,
    },
  };
}
export function updateClassDTOCreateGrade(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_CREATE_GRADE,
    payload: {
      data: payload,
    },
  };
}
