import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getClientDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getClientDetails);
