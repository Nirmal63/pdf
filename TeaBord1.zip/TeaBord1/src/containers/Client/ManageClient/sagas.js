import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { apiFetch } from "../../../utility/fetch-utils";
import { toast } from "react-toastify";
toast.configure();

export function* getClientDetails() {
  let response = yield apiFetch("eauction/auctioneer/live", {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.code) {
      let responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.GET_CLIENT_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(
        responseJSON.message ||
          "The task you are trying to perform is temporarily unavailable. Kindly contact administrator.",
        {
          autoClose: 10000,
          position: toast.POSITION.TOP_CENTER,
        }
      );
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_CLIENT_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(
      "The task you are trying to perform is temporarily unavailable. Kindly contact administrator.",
      {
        autoClose: 10000,
        position: toast.POSITION.TOP_CENTER,
      }
    );
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.GET_CLIENT_DETAILS,

      getClientDetails
    ),
  ]);
}
