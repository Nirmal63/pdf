import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "manageClient";

export const ActionTypes = keyMirrorRecursive(
  {
    GET_CLIENT_DETAILS: undefined,
    GET_CLIENT_DETAILS_SUCCESS: undefined,
  },
  pageName
);
