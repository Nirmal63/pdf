import { ActionTypes } from "./constants";

const initialState = {};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.GET_CLIENT_DETAILS_SUCCESS: {
      state.getClientDetails = action.payload.value;
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
