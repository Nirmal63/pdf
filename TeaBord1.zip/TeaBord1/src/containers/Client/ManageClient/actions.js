import { ActionTypes } from "./constants";

export function getClientDetails() {
  return {
    type: ActionTypes.GET_CLIENT_DETAILS,
  };
}
