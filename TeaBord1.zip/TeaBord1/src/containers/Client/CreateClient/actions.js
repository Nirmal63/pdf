import { ActionTypes } from "./constants";

export function updateClassDTOClient(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_CLIENT,
    payload,
  };
}

export function submitClientDetails(data) {
  return {
    type: ActionTypes.SUBMIT_CLIENT_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function getDomainNameDetails(payload) {
  return {
    type: ActionTypes.GET_DOMAIN_NAME_DETAILS,
    payload,
  };
}

export function getAllCountryDetails() {
  return {
    type: ActionTypes.GET_ALL_COUNTRY_DETAILS,
  };
}

export function getAllStateDetailsByCountryId(value) {
  return {
    type: ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID,
    payload: {
      value,
    },
  };
}

export function getAllModuleDetails() {
  return {
    type: ActionTypes.GET_ALL_MODULE_DETAILS,
  };
}

export function getAllModuleEventTypeDetails() {
  return {
    type: ActionTypes.GET_ALL_MODULE_EVENT_TYPE_DETAILS,
  };
}

export function getAllCurrencyDetails() {
  return {
    type: ActionTypes.GET_ALL_CURRENCY_DETAILS,
  };
}

export function getAllLanguageDetails() {
  return {
    type: ActionTypes.GET_ALL_LANGUAGE_DETAILS,
  };
}

export function getAllTimeZoneDetails() {
  return {
    type: ActionTypes.GET_ALL_TIME_ZONE_DETAILS,
  };
}

export function getAllDateFormatDetails() {
  return {
    type: ActionTypes.GET_ALL_DATE_FORMATE_DETAILS,
  };
}

export function getAllWorkFlowTypeDetails() {
  return {
    type: ActionTypes.GET_ALL_WORK_FLOW_TYPE_DETAILS,
  };
}