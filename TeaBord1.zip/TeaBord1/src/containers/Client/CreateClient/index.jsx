import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import ClientComponent from "../../../components/Client/CreateClient";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";
import $ from "jquery";

class index extends Component {
  componentDidMount() {
    this.props.getAllCountryDetails();
    this.props.getAllModuleDetails();
    this.props.getAllModuleEventTypeDetails();
    this.props.getAllCurrencyDetails();
    this.props.getAllLanguageDetails();
    this.props.getAllTimeZoneDetails();
    this.props.getAllDateFormatDetails();
    this.props.getAllWorkFlowTypeDetails();
  }

  handleClassDTOClient = (key, value) => {
    let { classDTOClient } = this.props;
    classDTOClient.isValidationSuccess = true;

    switch (key) {
      default: {
        classDTOClient[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTOClient);
  };

  checkValidations = (key, data) => {
    let { classDTOClient, updateClassDTOClient } = this.props;

    classDTOClient = data;
    classDTOClient.isValidationSuccess = true;

    if ("domainName" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.domainName)) {
        classDTOClient.domainNameError = "Please enter domain name";
        classDTOClient.isValidationSuccess = false;
      } else {
        if ("basicDetails" === key) {
          if (isNullOrIsEmptyOrIsUndefined(classDTOClient.domainNameError)) {
            classDTOClient.domainNameError = "";
          } else {
            classDTOClient.isValidationSuccess = false;
          }
        } else {
          classDTOClient.domainNameError = "";
        }
      }
    }

    if ("clientName" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.clientName)) {
        classDTOClient.clientNameError = "Please enter client name";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.clientNameError = "";
      }
    }

    if ("deptName" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.deptName)) {
        classDTOClient.deptNameError = "Please enter department Name";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.deptNameError = "";
      }
    }

    if ("countryId" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.countryId)) {
        classDTOClient.countryIdError = "Please select country";
        classDTOClient.isValidationSuccess = false;
      } else {
        if ("countryId" === key) {
          this.props.getAllStateDetailsByCountryId(classDTOClient.countryId);
        }
        classDTOClient.countryIdError = "";
      }
    }

    if ("stateId" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.stateId)) {
        classDTOClient.stateIdError = "Please select state";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.stateIdError = "";
      }
    }

    if ("cityId" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.cityId)) {
        classDTOClient.cityIdError = "Please enter city";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.cityIdError = "";
      }
    }

    if ("isGSTRequired" === key || "basicDetails" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.isGSTRequired)) {
        classDTOClient.isGSTRequiredError = "Please select gst details";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.isGSTRequiredError = "";
      }
    }

    if (
      !isNullOrIsEmptyOrIsUndefined(classDTOClient.isGSTRequired) &&
      1 === classDTOClient.isGSTRequired
    ) {
      if ("gstNo" === key || "basicDetails" === key || "all" === key) {
        if (isNullOrIsEmptyOrIsUndefined(classDTOClient.gstNo)) {
          classDTOClient.gstNoError = "Please enter gst number";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.gstNoError = "";
        }
      }
    }

    ////////////Module Configuration
    if (
      "moduleList" === key ||
      "moduleConfiguration" === key ||
      "all" === key
    ) {
      if (
        isNullOrIsEmptyOrIsUndefined(classDTOClient.moduleList) ||
        classDTOClient.moduleList.length <= 0
      ) {
        classDTOClient.moduleListError = "Please select modules";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.moduleListError = "";
      }
    }

    if (
      "tblModuleId" === key ||
      "moduleConfiguration" === key ||
      "all" === key
    ) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.tblModuleId)) {
        classDTOClient.tblModuleIdError = "Please select default home page";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.tblModuleIdError = "";
      }
    }

    if (
      "searchPanelType" === key ||
      "moduleConfiguration" === key ||
      "all" === key
    ) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.searchPanelType)) {
        classDTOClient.searchPanelTypeError = "Please select search panel type";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.searchPanelTypeError = "";
      }
    }

    if (
      "isAllowExternalUserToViewReport" === key ||
      "moduleConfiguration" === key ||
      "all" === key
    ) {
      if (
        isNullOrIsEmptyOrIsUndefined(
          classDTOClient.isAllowExternalUserToViewReport
        )
      ) {
        classDTOClient.isAllowExternalUserToViewReportError = "Please select";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.isAllowExternalUserToViewReportError = "";
      }
    }

    /////////////////////////Registration Configuration
    if (
      "isPkiEnabled" === key ||
      "registrationConfiguration" === key ||
      "all" === key
    ) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.isPkiEnabled)) {
        classDTOClient.isPkiEnabledError =
          "Please select digital certificate is required or not";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.isPkiEnabledError = "";
      }
    }

    if (
      !isNullOrIsEmptyOrIsUndefined(classDTOClient.isEventStatusListing) &&
      0 == classDTOClient.isEventStatusListing
    ) {
      if (
        "isPassEncReq" === key ||
        "registrationConfiguration" === key ||
        "all" === key
      ) {
        if (isNullOrIsEmptyOrIsUndefined(classDTOClient.isPassEncReq)) {
          classDTOClient.isPassEncReqError =
            "Please select digital certificate class";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.isPassEncReqError = "";
        }
      }
    } else {
      if (
        "DigitalCertificateClassList" === key ||
        "registrationConfiguration" === key ||
        "all" === key
      ) {
        if (
          isNullOrIsEmptyOrIsUndefined(
            classDTOClient.DigitalCertificateClassList
          )
        ) {
          classDTOClient.DigitalCertificateClassListError =
            "Please select digital certificate class";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.DigitalCertificateClassListError = "";
        }
      }

      if (
        "isSigner" === key ||
        "registrationConfiguration" === key ||
        "all" === key
      ) {
        if (isNullOrIsEmptyOrIsUndefined(classDTOClient.isSigner)) {
          classDTOClient.isSignerError = "Please select signer type";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.isSignerError = "";
        }
      }

      if (
        "bidderRegApprovalBy" === key ||
        "registrationConfiguration" === key ||
        "all" === key
      ) {
        if (isNullOrIsEmptyOrIsUndefined(classDTOClient.bidderRegApprovalBy)) {
          classDTOClient.bidderRegApprovalByError =
            "Please select bidder registration approval by";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.bidderRegApprovalByError = "";
        }
      }

      if (
        "bidderRegVerifiedBy" === key ||
        "registrationConfiguration" === key ||
        "all" === key
      ) {
        if (isNullOrIsEmptyOrIsUndefined(classDTOClient.bidderRegVerifiedBy)) {
          classDTOClient.bidderRegVerifiedByError =
            "Please select bidder registration verification by";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.bidderRegVerifiedByError = "";
        }
      }

      if (
        "officerRegVerifiedBy" === key ||
        "registrationConfiguration" === key ||
        "all" === key
      ) {
        if (isNullOrIsEmptyOrIsUndefined(classDTOClient.officerRegVerifiedBy)) {
          classDTOClient.officerRegVerifiedByError =
            "Please select department user registration verification by";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.officerRegVerifiedByError = "";
        }
      }

      if (
        "bidderRegBy" === key ||
        "registrationConfiguration" === key ||
        "all" === key
      ) {
        if (isNullOrIsEmptyOrIsUndefined(classDTOClient.bidderRegBy)) {
          classDTOClient.bidderRegByError =
            "Please select bidder registration by";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.bidderRegByError = "";
        }
      }

      if (
        "isRegistrationCharges" === key ||
        "registrationConfiguration" === key ||
        "all" === key
      ) {
        if (
          isNullOrIsEmptyOrIsUndefined(classDTOClient.isRegistrationCharges)
        ) {
          classDTOClient.isRegistrationChargesError =
            "Please select bidder registration charges";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.isRegistrationChargesError = "";
        }
      }

      if (
        "regCharges" === key ||
        "registrationConfiguration" === key ||
        "all" === key
      ) {
        if (isNullOrIsEmptyOrIsUndefined(classDTOClient.regCharges)) {
          classDTOClient.regChargesError = "Please enter registration charges";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.regChargesError = "";
        }
      }

      if (
        "isManDocsReq" === key ||
        "registrationConfiguration" === key ||
        "all" === key
      ) {
        if (isNullOrIsEmptyOrIsUndefined(classDTOClient.isManDocsReq)) {
          classDTOClient.isManDocsReqError =
            "Please select registration supporting document";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.isManDocsReqError = "";
        }
      }
    }

    //////Localization
    if ("currenciesList" === key || "localization" === key || "all" === key) {
      if (
        isNullOrIsEmptyOrIsUndefined(classDTOClient.currenciesList) ||
        classDTOClient.currenciesList.length <= 0
      ) {
        classDTOClient.currenciesListError = "Please select currencies";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.currenciesListError = "";
      }
    }

    if ("currencyId" === key || "localization" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.currencyId)) {
        classDTOClient.currencyIdError = "Please select default currency";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.currencyIdError = "";
      }
    }

    if ("languagesList" === key || "localization" === key || "all" === key) {
      if (
        isNullOrIsEmptyOrIsUndefined(classDTOClient.languagesList) ||
        classDTOClient.languagesList.length <= 0
      ) {
        classDTOClient.languagesListError = "Please select languages";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.languagesListError = "";
      }
    }

    if ("languageId" === key || "localization" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.languageId)) {
        classDTOClient.languageIdError = "Please select default language";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.languageIdError = "";
      }
    }

    if ("timeZoneId" === key || "localization" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.timeZoneId)) {
        classDTOClient.timeZoneIdError = "Please select timezone";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.timeZoneIdError = "";
      }
    }

    if ("dateFormatId" === key || "localization" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.dateFormatId)) {
        classDTOClient.dateFormatIdError = "Please select date format";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.dateFormatIdError = "";
      }
    }

    //////Advanced configuration
    if ("isWorkflowReq" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.isWorkflowReq)) {
        classDTOClient.isWorkflowReqError = "Please select workflow";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.isWorkflowReqError = "";
      }
    }

    if (
      !isNullOrIsEmptyOrIsUndefined(classDTOClient.isWorkflowReq) &&
      0 === classDTOClient.isWorkflowReq
    ) {
    } else {
      if ("workflowTypeList" === key || "all" === key) {
        if (
          isNullOrIsEmptyOrIsUndefined(classDTOClient.workflowTypeList) ||
          classDTOClient.workflowTypeList.length <= 0
        ) {
          classDTOClient.workflowTypeListError = "Please select workflow type";
          classDTOClient.isValidationSuccess = false;
        } else {
          classDTOClient.workflowTypeListError = "";
        }
      }
    }

    if ("wordConversionFormat" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOClient.wordConversionFormat)) {
        classDTOClient.wordConversionFormatError =
          "Please select word conversion format";
        classDTOClient.isValidationSuccess = false;
      } else {
        classDTOClient.wordConversionFormatError = "";
      }
    }

    updateClassDTOClient(classDTOClient);
  };

  handleButtonsClient = (name, value) => {
    let { classDTOClient, getDomainNameDetails, submitClientDetails } =
      this.props;

    switch (name) {
      case "checkDomainAvailibility": {
        getDomainNameDetails(classDTOClient);
        break;
      }

      case "submit": {
        this.checkValidations("all", classDTOClient);

        if (classDTOClient.isValidationSuccess) {
          if (
            classDTOClient.certificateClass1 &&
            classDTOClient.certificateClass1.length > 0
          ) {
            for (let i = 0; i <= classDTOClient.certificateClass1.length; i++) {
              if ("N.A" != classDTOClient.certificateClass1[i]) {
                if (i == 0) {
                  classDTOClient.certificateClass =
                    classDTOClient.certificateClass1[i];
                } else {
                  if (classDTOClient.certificateClass1[i] != undefined) {
                    classDTOClient.certificateClass =
                      classDTOClient.certificateClass +
                      "|" +
                      classDTOClient.certificateClass1[i];
                  }
                }
              }
            }
          }
          submitClientDetails(classDTOClient);
        }
        break;
      }

      case "prevButton": {
        $(".nav > .active").prev("li").find("button").trigger("click");
        break;
      }

      case "nextButton": {
        this.checkValidations(value, classDTOClient);
        if (classDTOClient.isValidationSuccess) {
          $(".nav > .active").next("li").find("button").trigger("click");
        }
        break;
      }

      default: {
        break;
      }
    }
  };

  selectRecord = (event, element, key, filterKey, allData) => {
    let classDTOClient = JSON.parse(JSON.stringify(this.props.classDTOClient));

    let tempObj = [];
    if (element) {
      let recordListObj = classDTOClient[key] || [];
      if (event.target.checked) {
        recordListObj.push(element);
      } else {
        recordListObj.splice(recordListObj.indexOf(element), 1);
      }
      if (recordListObj && recordListObj.length && recordListObj.length > 0) {
        for (let rec = 0; rec < recordListObj.length; rec++) {
          let data =
            allData &&
            allData.filter((data) => data[filterKey] == recordListObj[rec])[0];
          tempObj.push(data);
        }
      }
      this.handleClassDTOClient(key + 1, tempObj);
      this.handleClassDTOClient(key, recordListObj);
    } else {
      this.handleClassDTOClient(key + 1, []);
      this.handleClassDTOClient(key, []);
    }
  };

  resetData = () => {
    let classDTOClient = {
      domainName: "",
      clientName: "",
      departmentName: "",
      address: "",
      countryId: "",
      stateId: "",
      cityId: "",
      phoneNo: "",
      isGSTRequired: "",
      gstNo: "",
      moduleList: [],
      tblModuleId: "",
      searchPanelType: "",
      isHomePageRequire: 0,
      isEventStatusListing: 0,
      isAllowExternalUserToViewReport: 0,
      isPkiEnabled: 1,
      isPassEncReq: 1,
      certificateClass: [2, 3],
      certificateClass1: [2, 3],
      isSigner: 0,
      bidderRegApprovalBy: 0,
      bidderRegVerifiedBy: 0,
      officerRegVerifiedBy: 0,
      bidderRegBy: 1,
      isRegistrationCharges: 1,
      registrationChargesMode: 1,
      regCharges: "",
      isManDocsReq: 0,
      isTwoStepBidderApproval: 0,
      mapDcRequired: 1,
      isShowDcBanner: 1,
      isloginLinkConfigured: 0,
      currenciesList: [],
      currencyId: "",
      languagesList: [],
      languageId: "",
      timeZoneId: 42,
      dateFormatId: 1,
      isWorkflowReq: 1,
      workflowTypeList: [],
      categoryType: 1,
      wordConversionFormat: 1,
      listingStyle: 1,
      isConcurrentLogin: 1,
      isStatisticsRequired: 0,
      officerRegBy: 1,
      isDIYClient: 0,
      isShowCounter: 0,
      isCalendarConfigured: 0,
    };

    this.props.updateClassDTOClient(classDTOClient);
  };

  componentWillUnmount() {
    this.resetData();
  }

  render() {
    return (
      <ClientComponent
        {...this.props}
        handleClassDTOClient={this.handleClassDTOClient}
        handleButtonsClient={this.handleButtonsClient}
        selectRecord={this.selectRecord}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    updateClassDTOClient: (payload) => {
      dispatch(actions.updateClassDTOClient(payload));
    },

    submitClientDetails: (data) => {
      dispatch(actions.submitClientDetails(data));
    },

    getDomainNameDetails: (payload) => {
      dispatch(actions.getDomainNameDetails(payload));
    },

    getAllCountryDetails: () => {
      dispatch(actions.getAllCountryDetails());
    },

    getAllStateDetailsByCountryId: (payload) => {
      dispatch(actions.getAllStateDetailsByCountryId(payload));
    },

    getAllModuleDetails: () => {
      dispatch(actions.getAllModuleDetails());
    },

    getAllModuleEventTypeDetails: () => {
      dispatch(actions.getAllModuleEventTypeDetails());
    },

    getAllCurrencyDetails: () => {
      dispatch(actions.getAllCurrencyDetails());
    },

    getAllLanguageDetails: () => {
      dispatch(actions.getAllLanguageDetails());
    },

    getAllTimeZoneDetails: () => {
      dispatch(actions.getAllTimeZoneDetails());
    },

    getAllDateFormatDetails: () => {
      dispatch(actions.getAllDateFormatDetails());
    },

    getAllWorkFlowTypeDetails: () => {
      dispatch(actions.getAllWorkFlowTypeDetails());
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTOClient: selectors.getClassDTOClient(),
    getDomainNameDetailsResponse: selectors.getDomainNameDetails(),
    getAllCountryDetailsResponse: selectors.getAllCountryDetails(),
    getAllStateDetailsByCountryIdResponse:
      selectors.getAllStateDetailsByCountryId(),
    getAllModuleDetailsResponse: selectors.getAllModuleDetails(),
    getAllModuleEventTypeDetailsResponse:
      selectors.getAllModuleEventTypeDetails(),
    getAllCurrencyDetailsResponse: selectors.getAllCurrencyDetails(),
    getAllLanguageDetailsResponse: selectors.getAllLanguageDetails(),
    getAllTimeZoneDetailsResponse: selectors.getAllTimeZoneDetails(),
    getAllDateFormatResponse: selectors.getAllDateFormatDetails(),
    getAllWorkFlowTypeDetailsResponse: selectors.getAllWorkFlowTypeDetails(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
