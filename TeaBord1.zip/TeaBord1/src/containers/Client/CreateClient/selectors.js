import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getClassDTOClient = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTOClient);

export const getDomainNameDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getDomainNameDetails);

export const getAllCountryDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllCountryDetails);

export const getAllStateDetailsByCountryId = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.getAllStateDetailsByCountryId
  );

export const getAllModuleDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllModuleDetails);

export const getAllModuleEventTypeDetails = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.getAllModuleEventTypeDetails
  );

export const getAllCurrencyDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllCurrencyDetails);

export const getAllLanguageDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllLanguageDetails);

export const getAllTimeZoneDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllTimeZoneDetails);

export const getAllDateFormatDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllDateFormatDetails);

export const getAllWorkFlowTypeDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllWorkFlowTypeDetails);
