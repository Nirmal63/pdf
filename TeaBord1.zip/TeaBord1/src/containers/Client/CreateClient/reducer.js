import { ActionTypes } from "./constants";

const initialState = {
  classDTOClient: {
    domainName: "",
    clientName: "",
    departmentName: "",
    address: "",
    countryId: "",
    stateId: "",
    cityId: "",
    phoneNo: "",
    isGSTRequired: "",
    gstNo: "",
    moduleList: [],
    tblModuleId: "",
    searchPanelType: "",
    isHomePageRequire: 0,
    isEventStatusListing: 0,
    isAllowExternalUserToViewReport: 0,
    isPkiEnabled: 1,
    isPassEncReq: 1,
    certificateClass: [2, 3],
    certificateClass1: [2, 3],
    isSigner: 0,
    bidderRegApprovalBy: 0,
    bidderRegVerifiedBy: 0,
    officerRegVerifiedBy: 0,
    bidderRegBy: 1,
    isRegistrationCharges: 1,
    registrationChargesMode: 1,
    regCharges: "",
    isManDocsReq: 0,
    isTwoStepBidderApproval: 0,
    mapDcRequired: 1,
    isShowDcBanner: 1,
    isloginLinkConfigured: 0,
    currenciesList: [],
    currencyId: "",
    languagesList: [],
    languageId: "",
    timeZoneId: 42,
    dateFormatId: 1,
    isWorkflowReq: 1,
    workflowTypeList: [],
    categoryType: 1,
    wordConversionFormat: 1,
    listingStyle: 1,
    isConcurrentLogin: 1,
    isStatisticsRequired: 0,
    officerRegBy: 1,
    isDIYClient: 0,
    isShowCounter: 0,
    isCalendarConfigured: 0,
  },
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.UPDATE_CLASS_DTO_CLIENT: {
      state.classDTOClient = action.payload || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_DOMAIN_NAME_DETAILS_SUCCESS: {
      state.getDomainNameDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_COUNTRY_DETAILS_SUCCESS: {
      state.getAllCountryDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS: {
      state.getAllStateDetailsByCountryId = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_MODULE_DETAILS_SUCCESS: {
      state.getAllModuleDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_MODULE_EVENT_TYPE_DETAILS_SUCCESS: {
      state.getAllModuleEventTypeDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_CURRENCY_DETAILS_SUCCESS: {
      state.getAllCurrencyDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_LANGUAGE_DETAILS_SUCCESS: {
      state.getAllLanguageDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_TIME_ZONE_DETAILS_SUCCESS: {
      state.getAllTimeZoneDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_DATE_FORMATE_DETAILS_SUCCESS: {
      state.getAllDateFormatDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_WORK_FLOW_TYPE_DETAILS_SUCCESS: {
      state.getAllWorkFlowTypeDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
