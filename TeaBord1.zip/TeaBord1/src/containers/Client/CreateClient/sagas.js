import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";

import { apiFetch } from "../../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../../commonConstants/constants";
import { CustomToast as toast } from "../../../components/GenericComponents/Toast";

export function* submitClientDetails({ payload }) {
  let response = yield apiFetch("common/client/create", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON.responseData || {};
      toast.success(responseJSON.message);
      yield put({
        type: ActionTypes.SUBMIT_CLIENT_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_CLIENT_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getDomainNameDetails({ payload }) {
  let response = yield apiFetch(
    `common/client/domainname/${payload.domainName}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};

      if (responseObj.responseData == true) {
        payload.domainNameError = "Domain name is not available";
        payload.isValidationSuccess = true;
      } else {
        payload.domainNameError = "Domain name is available";
        payload.isValidationSuccess = false;
      }

      yield put({
        type: ActionTypes.UPDATE_CLASS_DTO_CLIENT,
        payload,
      });
      yield put({
        type: ActionTypes.GET_DOMAIN_NAME_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_DOMAIN_NAME_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllCountryDetails() {
  let response = yield apiFetch("common/country/unauth/getAllCountry", {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};

      yield put({
        type: ActionTypes.GET_ALL_COUNTRY_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_COUNTRY_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllStateDetailsByCountryId({ payload }) {
  let response = yield apiFetch(
    `common/state/unauth/getStateByCountryId/${payload.value}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllModuleDetails() {
  let response = yield apiFetch(`common/module/getAllModule`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_MODULE_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_MODULE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllModuleEventTypeDetails() {
  let response = yield apiFetch("common/eventType/getEventtype", {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_MODULE_EVENT_TYPE_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_MODULE_EVENT_TYPE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllCurrencyDetails() {
  let response = yield apiFetch(`common/currency/getAllCurrency`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_CURRENCY_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_CURRENCY_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllLanguageDetails() {
  let response = yield apiFetch(`common/language/getAllLanguage`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_LANGUAGE_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_LANGUAGE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllTimeZoneDetails() {
  let response = yield apiFetch(`common/timezone/unauth/getAllTimeZone`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_TIME_ZONE_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_TIME_ZONE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllDateFormatDetails() {
  let response = yield apiFetch(`common/dateFormat/getAllDateFormat`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_DATE_FORMATE_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_DATE_FORMATE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllWorkFlowTypeDetails() {
  let response = yield apiFetch(`common/workFlowType/getAllWorkFlowType`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_WORK_FLOW_TYPE_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_WORK_FLOW_TYPE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(ActionTypes.SUBMIT_CLIENT_DETAILS, submitClientDetails),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_DOMAIN_NAME_DETAILS, getDomainNameDetails),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_COUNTRY_DETAILS, getAllCountryDetails),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID,
      getAllStateDetailsByCountryId
    ),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID,
      getAllStateDetailsByCountryId
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_MODULE_DETAILS, getAllModuleDetails),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_ALL_MODULE_EVENT_TYPE_DETAILS,
      getAllModuleEventTypeDetails
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_CURRENCY_DETAILS, getAllCurrencyDetails),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_LANGUAGE_DETAILS, getAllLanguageDetails),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_TIME_ZONE_DETAILS, getAllTimeZoneDetails),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_ALL_DATE_FORMATE_DETAILS,
      getAllDateFormatDetails
    ),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_ALL_WORK_FLOW_TYPE_DETAILS,
      getAllWorkFlowTypeDetails
    ),
  ]);
}
