import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "client";

export const ActionTypes = keyMirrorRecursive(
  {
    UPDATE_CLASS_DTO_CLIENT: undefined,
    SUBMIT_CLIENT_DETAILS: undefined,
    SUBMIT_CLIENT_DETAILS_SUCCESS: undefined,
    GET_DOMAIN_NAME_DETAILS: undefined,
    GET_DOMAIN_NAME_DETAILS_SUCCESS: undefined,
    GET_ALL_COUNTRY_DETAILS: undefined,
    GET_ALL_COUNTRY_DETAILS_SUCCESS: undefined,
    GET_ALL_STATE_DETAILS_BY_COUNTRY_ID: undefined,
    GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS: undefined,
    GET_ALL_MODULE_DETAILS: undefined,
    GET_ALL_MODULE_DETAILS_SUCCESS: undefined,
    GET_ALL_MODULE_EVENT_TYPE_DETAILS: undefined,
    GET_ALL_MODULE_EVENT_TYPE_DETAILS_SUCCESS: undefined,
    GET_ALL_CURRENCY_DETAILS: undefined,
    GET_ALL_CURRENCY_DETAILS_SUCCESS: undefined,
    GET_ALL_LANGUAGE_DETAILS: undefined,
    GET_ALL_LANGUAGE_DETAILS_SUCCESS: undefined,
    GET_ALL_TIME_ZONE_DETAILS: undefined,
    GET_ALL_TIME_ZONE_DETAILS_SUCCESS: undefined,
    GET_ALL_DATE_FORMATE_DETAILS: undefined,
    GET_ALL_DATE_FORMATE_DETAILS_SUCCESS: undefined,
    GET_ALL_WORK_FLOW_TYPE_DETAILS: undefined,
    GET_ALL_WORK_FLOW_TYPE_DETAILS_SUCCESS: undefined,
  },
  pageName
);

export const GST_DETAILS_REQUIRED_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const DEFAULT_HOME_PAGES_VALUES = [
  {
    displayKey: "Administration & reports",
    value: 1,
  },
  {
    displayKey: "Indent",
    value: 2,
  },
  {
    displayKey: "RFx",
    value: 3,
  },
  {
    displayKey: "Auction",
    value: 5,
  },
  {
    displayKey: "Contract management",
    value: 6,
  },
  {
    displayKey: "Vendor enlistment",
    value: 8,
  },
  {
    displayKey: "Spend analysis",
    value: 9,
  },
  {
    displayKey: "Advertisement",
    value: 10,
  },
  {
    displayKey: "Offline Contract Management",
    value: 12,
  },
  {
    displayKey: "Online Contract",
    value: 13,
  },
];

export const SEARCH_PANEL_VALUES = [
  {
    displayKey: "Horizontal",
    value: 1,
  },
  {
    displayKey: "Vertical",
    value: 2,
  },
];

export const DISPLAY_HOME_PAGE_VALUES = [
  {
    displayKey: "No",
    value: 0,
  },
  {
    displayKey: "Yes",
    value: 1,
  },
];

export const HOME_PAGE_VALUES = [
  {
    displayKey: "Property",
    value: 1,
  },
];

export const EVENT_STATUS_LISTING_VALUES = [
  {
    displayKey: "Live",
    value: 0,
  },
  {
    displayKey: "No",
    value: 1,
  },
];

export const ALLOW_EXTERNAL_USERS_TO_VIEW_REPORT_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const DIGITAL_CERTIFICATE_REQUIRES_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
  {
    displayKey: "Event Specific",
    value: 2,
  },
];

export const PASSWORD_BASE_ENCRYPTION_REQUIRES_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const SIGNER_TYPE_VALUES = [
  {
    displayKey: "Capicom",
    value: 0,
  },
  {
    displayKey: "Signer service",
    value: 1,
  },
];

export const BIDDER_REGISTRATION_APPROVAL_BY_VALUES = [
  {
    displayKey: "Manual",
    value: 0,
  },
  {
    displayKey: "Auto",
    value: 1,
  },
];

export const BIDDER_REGISTRATION_VERIFICATION_BY_VALUES = [
  {
    displayKey: "Email ID",
    value: 1,
  },
  {
    displayKey: "Email ID and Mobile Number",
    value: 2,
  },
  {
    displayKey: "Mobile Number",
    value: 3,
  },
  {
    displayKey: "Not Required",
    value: 0,
  },
];

export const DEPARTMENT_USER_REGISTRATION_VERIFICATION_BY_VALUES = [
  {
    displayKey: "Email ID",
    value: 1,
  },
  {
    displayKey: "Email ID and Mobile Number",
    value: 2,
  },
  {
    displayKey: "Not Required",
    value: 0,
  },
];

export const BIDDER_REGISTRATION_BY_VALUES = [
  {
    displayKey: "Bidder",
    value: 1,
  },
  {
    displayKey: "Authorized User",
    value: 0,
  },
];

export const BIDDER_REGISTRATION_CHARGES_VALUES = [
  {
    displayKey: "Applicable",
    value: 1,
  },
  {
    displayKey: "Not Applicable",
    value: 0,
  },
];

export const REGISTRATION_CHARGES_MODE_OF_PAYMENT_VALUES = [
  {
    displayKey: "Online",
    value: 1,
  },
  {
    displayKey: "Offline",
    value: 2,
  },
  {
    displayKey: "Both",
    value: 3,
  },
];

export const REGISTRATION_SUPPORTING_DOCUMENT_VALUES = [
  {
    displayKey: "Not Required",
    value: 0,
  },
  {
    displayKey: "Required",
    value: 1,
  },
];

export const CERTIFICATE_MAPPING_VALUES = [
  {
    displayKey: "During Registration",
    value: 1,
  },
  {
    displayKey: "At The Time Of Login",
    value: 0,
  },
];

export const TWO_STAGE_REGISTRATION_APPROVAL_REQUIRED_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const SHOW_DIGITAL_CERTIFICATE_BANNER_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const MANAGE_LOGIN_SEPARATE_FOR_BIDDER_BUYER_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const WORK_FLOW_VALUES = [
  {
    displayKey: "Required",
    value: 1,
  },
  {
    displayKey: "Not Required",
    value: 0,
  },
  {
    displayKey: "Event Specific",
    value: 2,
  },
];

export const CATEGORY_STANDARD_VALUES = [
  {
    displayKey: "Standard(CPV)",
    value: 1,
  },
  {
    displayKey: "Manual",
    value: 0,
  },
];

export const FIGURES_INTO_WORDS_VALUES = [
  {
    displayKey: "Lacs, Crore",
    value: 1,
  },
  {
    displayKey: "Million, Billion, Trillion",
    value: 0,
  },
];

export const LISTING_VIEW_VALUES = [
  {
    displayKey: "Tabular",
    value: 0,
  },
  {
    displayKey: "Normal",
    value: 1,
  },
  {
    displayKey: "Block",
    value: 2,
  },
];

export const ALLOW_CONCURRENT_USER_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const STATICS_REQUIRED_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const OFFICER_REGISTRATION_BY_VALUES = [
  {
    displayKey: "Registered Officer",
    value: 1,
  },
  {
    displayKey: "Himself",
    value: 0,
  },
];

export const IS_DIY_REQUIRED_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const DISPLAY_VISITORS_COUNT_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const MY_CALENDER_MODULE_REQUIRED_VALUES = [
  {
    displayKey: "Yes",
    value: 1,
  },
  {
    displayKey: "No",
    value: 0,
  },
];

export const CERTIFICATE_CLASSES_VALUES = [
  {
    displayKey: "Class-2",
    value: 2,
  },
  {
    displayKey: "Class-3",
    value: 3,
  },
  {
    displayKey: "Class-N.A",
    value: 1,
  },
];
