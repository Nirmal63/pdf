import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { apiFetch } from "../../utility/fetch-utils";
import {
  ERROR_MESSAGE_FOR_DEFAULT,
  ERROR_MESSAGE_FOR_400,
} from "../../commonConstants/constants";
import { CustomToast as toast } from "../../components/GenericComponents/Toast";
import { getLocalStorageItem } from "../../commonConstants/LocalStorageData";

export function* submitRegisterUserDetails({ payload }) {
  const response = yield apiFetch("common/createuser", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    const responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      toast.success(responseJSON.message);

      var responseObj = responseJSON.responseObj || {};

      yield put({
        type: ActionTypes.SUBMIT_REGISTER_USER_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_REGISTER_USER_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else if (400 === response.status) {
    toast.error(ERROR_MESSAGE_FOR_400);
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllDepartmentDetails() {
  let response = yield apiFetch(
    `common/dept/getdepthierarchy/${getLocalStorageItem("clientId")}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    yield put({
      type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: responseJSON,
      },
    });

    // if (200 === responseJSON.statusCode) {
    //   let responseObj = responseJSON || {};
    //   yield put({
    //     type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
    //     payload: {
    //       value: responseObj.responseData,
    //     },
    //   });
    // } else {
    //   // toast.error(
    //   //   responseJSON.message ||
    //   //     ERROR_MESSAGE_FOR_DEFAULT
    //   // );
    // }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllDesignationDetailsByDepartmentId({ payload }) {
  let response = yield apiFetch(
    `common/designation/getParentDesignationHierarchy/${payload.data}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    yield put({
      type: ActionTypes.GET_ALL_DESIGNATION_DETAILS_BY_DEPARTMENT_ID_SUCCESS,
      payload: {
        value: responseJSON,
      },
    });

    // if (200 === responseJSON.statusCode) {
    //   let responseObj = responseJSON || {};
    //   yield put({
    //     type: ActionTypes.GET_ALL_DESIGNATION_DETAILS_BY_DEPARTMENT_ID_SUCCESS,
    //     payload: {
    //       value: responseObj.responseData,
    //     },
    //   });
    // } else {
    //   // toast.error(
    //   //   responseJSON.message ||
    //   //   ERROR_MESSAGE_FOR_DEFAULT
    //   // );
    // }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_DESIGNATION_DETAILS_BY_DEPARTMENT_ID_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllTimeZoneDetails() {
  let response = yield apiFetch(`common/timezone/unauth/getAllTimeZone`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_TIME_ZONE_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_TIME_ZONE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_REGISTER_USER_DETAILS,
      submitRegisterUserDetails
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_DEPARTMENT_DETAILS, getAllDepartmentDetails),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_ALL_DESIGNATION_DETAILS_BY_DEPARTMENT_ID,
      getAllDesignationDetailsByDepartmentId
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_TIME_ZONE_DETAILS, getAllTimeZoneDetails),
  ]);
}
