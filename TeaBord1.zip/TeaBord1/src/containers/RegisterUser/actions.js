import { ActionTypes } from "./constants";

export function updateClassDTORegisterUser(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_REGISTER_USER,
    payload: {
      data: payload,
    },
  };
}

export function submitRegisterUserDetails(data) {
  return {
    type: ActionTypes.SUBMIT_REGISTER_USER_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function getAllDepartmentDetails() {
  return {
    type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS,
  };
}

export function getAllDesignationDetailsByDepartmentId(data) {
  return {
    type: ActionTypes.GET_ALL_DESIGNATION_DETAILS_BY_DEPARTMENT_ID,
    payload: {
      data: data,
    },
  };
}

export function getAllTimeZoneDetails() {
  return {
    type: ActionTypes.GET_ALL_TIME_ZONE_DETAILS,
  };
}
