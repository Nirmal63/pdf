import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getClassDTORegisterUser = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTORegisterUser);

export const getAllDepartmentDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllDepartmentDetails);

export const getAllDesignationDetailsByDepartmentId = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.getAllDesignationDetailsByDepartmentId
  );

export const getAllTimeZoneDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllTimeZoneDetails);
