import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "registerUser";

export const ActionTypes = keyMirrorRecursive(
  {
    UPDATE_CLASS_DTO_REGISTER_USER: undefined,
    SUBMIT_REGISTER_USER_DETAILS: undefined,
    SUBMIT_REGISTER_USER_DETAILS_SUCCESS: undefined,
    GET_ALL_DEPARTMENT_DETAILS: undefined,
    GET_ALL_DEPARTMENT_DETAILS_SUCCESS: undefined,
    GET_ALL_DESIGNATION_DETAILS_BY_DEPARTMENT_ID: undefined,
    GET_ALL_DESIGNATION_DETAILS_BY_DEPARTMENT_ID_SUCCESS: undefined,
    GET_ALL_TIME_ZONE_DETAILS: undefined,
    GET_ALL_TIME_ZONE_DETAILS_SUCCESS: undefined,
  },
  pageName
);

export const COMPANY_INDIVIDUAL_VALUES = [
  {
    displayKey: "Company Name",
    value: "Company Name",
  },
  {
    displayKey: "Individual Name",
    value: "Individual Name",
  },
];
