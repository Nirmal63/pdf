import { ActionTypes } from "./constants";

const initialState = {
  classDTORegisterUser: {},
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.UPDATE_CLASS_DTO_REGISTER_USER: {
      state.classDTORegisterUser = action.payload.data || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS: {
      state.getAllDepartmentDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_DESIGNATION_DETAILS_BY_DEPARTMENT_ID_SUCCESS: {
      state.getAllDesignationDetailsByDepartmentId = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_TIME_ZONE_DETAILS_SUCCESS: {
      state.getAllTimeZoneDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
