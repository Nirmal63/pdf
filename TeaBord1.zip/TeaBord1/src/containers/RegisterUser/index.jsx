import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import RegisterUserComponent from "../../components/RegisterUser";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";

class index extends Component {
  componentDidMount() {
    this.props.getAllDepartmentDetails();
    this.props.getAllTimeZoneDetails();
  }

  handleClassDTORegisterUser = (key, value) => {
    let { classDTORegisterUser } = this.props;
    classDTORegisterUser.isValidationSuccess = true;

    switch (key) {
      default: {
        classDTORegisterUser[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTORegisterUser);
  };

  checkValidations = (key, data) => {
    let { classDTORegisterUser, updateClassDTORegisterUser } = this.props;

    classDTORegisterUser = data;
    classDTORegisterUser.isValidationSuccess = true;

    if ("deptId" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.deptId)) {
        classDTORegisterUser.deptIdError = "Please select";
        classDTORegisterUser.isValidationSuccess = false;
      } else {
        classDTORegisterUser.deptIdError = "";
        if ("deptId" === key) {
          this.props.getAllDesignationDetailsByDepartmentId(
            classDTORegisterUser.deptId
          );
        }
      }
    }

    if ("designationId" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.designationId)) {
        classDTORegisterUser.designationIdError = "Please select";
        classDTORegisterUser.isValidationSuccess = false;
      } else {
        classDTORegisterUser.designationIdError = "";
      }
    }

    if ("loginId" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.loginId)) {
        classDTORegisterUser.loginIdError = "Please enter";
        classDTORegisterUser.isValidationSuccess = false;
      } else {
        classDTORegisterUser.loginIdError = "";
      }
    }

    if ("userName" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.userName)) {
        classDTORegisterUser.userNameError = "Please enter";
        classDTORegisterUser.isValidationSuccess = false;
      } else {
        classDTORegisterUser.userNameError = "";
      }
    }

    if ("mobileNo" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.mobileNo)) {
        classDTORegisterUser.mobileNoError = "Please enter";
        classDTORegisterUser.isValidationSuccess = false;
      } else {
        classDTORegisterUser.mobileNoError = "";
      }
    }

    if ("phoneNo" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.phoneNo)) {
        classDTORegisterUser.phoneNoError = "Please enter";
        classDTORegisterUser.isValidationSuccess = false;
      } else {
        classDTORegisterUser.phoneNoError = "";
      }
    }

    if ("password" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.password)) {
        classDTORegisterUser.passwordError = "Please enter";
        classDTORegisterUser.isValidationSuccess = false;
      } else {
        if (
          classDTORegisterUser.password &&
          classDTORegisterUser.password.length < 8
        ) {
          classDTORegisterUser.passwordError =
            "Allows min 8 and max. 50 alphanumeric and special characters (!,@,#,$,_,.,(,))";
          classDTORegisterUser.isValidationSuccess = false;
        } else if (
          !isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.password) &&
          !isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.confPassword) &&
          classDTORegisterUser.password !== classDTORegisterUser.confPassword
        ) {
          classDTORegisterUser.confPasswordError =
            "Confirm password does not match with Password";
          classDTORegisterUser.isValidationSuccess = false;
        } else {
          classDTORegisterUser.confPasswordError = "";
          classDTORegisterUser.passwordError = "";
        }
      }
    }

    if ("confPassword" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.confPassword)) {
        classDTORegisterUser.confPasswordError = "Please enter";
        classDTORegisterUser.isValidationSuccess = false;
      } else {
        if (
          !isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.password) &&
          !isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.confPassword) &&
          classDTORegisterUser.password != classDTORegisterUser.confPassword
        ) {
          classDTORegisterUser.confPasswordError =
            "Confirm password does not match with Password";
          classDTORegisterUser.isValidationSuccess = false;
        } else {
          classDTORegisterUser.confPasswordError = "";
        }
      }
    }

    if ("tblTimeZone" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterUser.tblTimeZone)) {
        classDTORegisterUser.tblTimeZoneError = "Please select";
        classDTORegisterUser.isValidationSuccess = false;
      } else {
        classDTORegisterUser.tblTimeZoneError = "";
      }
    }

    updateClassDTORegisterUser(classDTORegisterUser);
  };

  handleButtonsRegisterUser = (name) => {
    var { classDTORegisterUser } = this.props;

    switch (name) {
      case "submit": {
        this.checkValidations("all", classDTORegisterUser);
        if (classDTORegisterUser.isValidationSuccess) {
          classDTORegisterUser.tblClient = 10;
          classDTORegisterUser.ipAddress = "192";
          this.props.submitRegisterUserDetails(classDTORegisterUser);
        }
        break;
      }
      default: {
        break;
      }
    }
  };

  componentWillUnmount() {
    let data = {};
    this.props.updateClassDTORegisterUser(data);
  }

  render() {
    return (
      <RegisterUserComponent
        {...this.props}
        handleClassDTORegisterUser={this.handleClassDTORegisterUser}
        handleButtonsRegisterUser={this.handleButtonsRegisterUser}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    updateClassDTORegisterUser: (payload) => {
      dispatch(actions.updateClassDTORegisterUser(payload));
    },

    submitRegisterUserDetails: (data) => {
      dispatch(actions.submitRegisterUserDetails(data));
    },

    getAllDepartmentDetails: () => {
      dispatch(actions.getAllDepartmentDetails());
    },

    getAllDesignationDetailsByDepartmentId: (data) => {
      dispatch(actions.getAllDesignationDetailsByDepartmentId(data));
    },

    getAllTimeZoneDetails: () => {
      dispatch(actions.getAllTimeZoneDetails());
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTORegisterUser: selectors.getClassDTORegisterUser(),
    getAllDepartmentDetailsResponse: selectors.getAllDepartmentDetails(),
    getAllDesignationDetailsByDepartmentIdResponse:
      selectors.getAllDesignationDetailsByDepartmentId(),
    getAllTimeZoneDetailsResponse: selectors.getAllTimeZoneDetails(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
