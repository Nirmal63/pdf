import { ActionTypes } from "./constants";

const initialState = {
  classDTORegisterBidder: {
    // address: "",
    // alternateLoginId: "",
    // busCatKeywords: "",
    // city: "",
    // companyName: "",
    // deptName: "",
    // designation: "",
    // ipAddress: "",
    // loginId: "",
    // mobileNo: "",
    // password: "",
    // phoneNo: "",
    // tblClient: "",
    // tblCountry: "",
    // tblState: "",
    // tblTimeZone: 0,
    // userName: "",

    userNameTemp: "Company Name",
  },
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.UPDATE_CLASS_DTO_REGISTER_BIDDER: {
      state.classDTORegisterBidder = action.payload.data || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_COUNTRY_DETAILS_SUCCESS: {
      state.getAllCountryDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS: {
      state.getAllStateDetailsByCountryId = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_TIME_ZONE_DETAILS_SUCCESS: {
      state.getAllTimeZoneDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
