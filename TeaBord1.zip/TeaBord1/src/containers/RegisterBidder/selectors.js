import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getClassDTORegisterBidder = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTORegisterBidder);

export const getAllCountryDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllCountryDetails);

export const getAllStateDetailsByCountryId = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.getAllStateDetailsByCountryId
  );

export const getAllTimeZoneDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllTimeZoneDetails);
