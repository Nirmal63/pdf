import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";

import { apiFetch } from "../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../commonConstants/constants";
import { CustomToast as toast } from "../../components/GenericComponents/Toast";
import { getLocalStorageItem } from "../../commonConstants/LocalStorageData";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";

export function* submitRegisterBidderDetails({ payload }) {
  const response = yield apiFetch("common/bidder/register", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    const responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      toast.success(responseJSON.message);

      let data = { userNameTemp: "Company Name" };
      yield put({
        type: ActionTypes.SUBMIT_REGISTER_BIDDER_DETAILS_SUCCESS,
        payload: {
          data: data,
        },
      });

      var responseObj = responseJSON.responseObj || {};
      yield put({
        type: ActionTypes.SUBMIT_REGISTER_BIDDER_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });

      if (!isNullOrIsEmptyOrIsUndefined(getLocalStorageItem("token"))) {
        window.location.href = "/dashboard";
      }
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_REGISTER_BIDDER_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else if (400 === response.status) {
    const responseJSON = yield response.json() || {};

    toast.error(responseJSON.loginId);
    toast.error(responseJSON.userName);
    toast.error(responseJSON.companyName);
    toast.error(responseJSON.tblCountry);
    toast.error(responseJSON.tblState);
    toast.error(responseJSON.city);
    toast.error(responseJSON.address);
    toast.error(responseJSON.mobileNo);
    toast.error(responseJSON.tblTimeZone);
    toast.error(responseJSON.busCatKeywords);
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllCountryDetails() {
  let response = yield apiFetch("common/country/unauth/getAllCountry", {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};

      yield put({
        type: ActionTypes.GET_ALL_COUNTRY_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_COUNTRY_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllStateDetailsByCountryId({ payload }) {
  let response = yield apiFetch(
    `common/state/unauth/getStateByCountryId/${payload.value}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllTimeZoneDetails() {
  let response = yield apiFetch(`common/timezone/unauth/getAllTimeZone`, {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_TIME_ZONE_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_TIME_ZONE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_REGISTER_BIDDER_DETAILS,
      submitRegisterBidderDetails
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_COUNTRY_DETAILS, getAllCountryDetails),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID,
      getAllStateDetailsByCountryId
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_TIME_ZONE_DETAILS, getAllTimeZoneDetails),
  ]);
}
