import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "registerBidder";

export const ActionTypes = keyMirrorRecursive(
  {
    UPDATE_CLASS_DTO_REGISTER_BIDDER: undefined,
    SUBMIT_REGISTER_BIDDER_DETAILS: undefined,
    SUBMIT_REGISTER_BIDDER_DETAILS_SUCCESS: undefined,
    GET_ALL_COUNTRY_DETAILS: undefined,
    GET_ALL_COUNTRY_DETAILS_SUCCESS: undefined,
    GET_ALL_STATE_DETAILS_BY_COUNTRY_ID: undefined,
    GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS: undefined,
    GET_ALL_TIME_ZONE_DETAILS: undefined,
    GET_ALL_TIME_ZONE_DETAILS_SUCCESS: undefined,
  },
  pageName
);

export const COMPANY_INDIVIDUAL_VALUES = [
  {
    displayKey: "Company Name",
    value: "Company Name",
  },
  {
    displayKey: "Individual Name",
    value: "Individual Name",
  },
];
