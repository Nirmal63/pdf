import { ActionTypes } from "./constants";

export function updateClassDTORegisterBidder(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_REGISTER_BIDDER,
    payload: {
      data: payload,
    },
  };
}

export function submitRegisterBidderDetails(data) {
  return {
    type: ActionTypes.SUBMIT_REGISTER_BIDDER_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function getAllCountryDetails() {
  return {
    type: ActionTypes.GET_ALL_COUNTRY_DETAILS,
  };
}

export function getAllStateDetailsByCountryId(value) {
  return {
    type: ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID,
    payload: {
      value,
    },
  };
}

export function getAllTimeZoneDetails() {
  return {
    type: ActionTypes.GET_ALL_TIME_ZONE_DETAILS,
  };
}
