import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import RegisterBidderComponent from "../../components/RegisterBidder";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";

class index extends Component {
  componentDidMount() {
    this.props.getAllCountryDetails();
    this.props.getAllTimeZoneDetails();
  }

  handleClassDTORegisterBidder = (key, value) => {
    let { classDTORegisterBidder } = this.props;
    classDTORegisterBidder.isValidationSuccess = true;

    switch (key) {
      default: {
        classDTORegisterBidder[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTORegisterBidder);
  };

  checkValidations = (key, data) => {
    let { classDTORegisterBidder, updateClassDTORegisterBidder } = this.props;

    classDTORegisterBidder = data;
    classDTORegisterBidder.isValidationSuccess = true;

    if ("loginId" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.loginId)) {
        classDTORegisterBidder.loginIdError = "Please enter";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        classDTORegisterBidder.loginIdError = "";
      }
    }

    if ("userName" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.userName)) {
        classDTORegisterBidder.userNameError = "Please enter";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        classDTORegisterBidder.userNameError = "";
      }

      if ("Individual Name" == classDTORegisterBidder.userNameTemp) {
        classDTORegisterBidder.companyName = classDTORegisterBidder.userName;
      }
    }

    if ("companyName" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.companyName)) {
        classDTORegisterBidder.companyNameError = "Please enter";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        classDTORegisterBidder.companyNameError = "";
      }
    }

    if ("tblCountry" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.tblCountry)) {
        classDTORegisterBidder.tblCountryError = "Please select country";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        if ("tblCountry" === key) {
          this.props.getAllStateDetailsByCountryId(
            classDTORegisterBidder.tblCountry
          );
        }
        classDTORegisterBidder.tblCountryError = "";
      }
    }

    if ("tblState" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.tblState)) {
        classDTORegisterBidder.tblStateError = "Please select state";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        classDTORegisterBidder.tblStateError = "";
      }
    }

    if ("city" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.city)) {
        classDTORegisterBidder.cityError = "Please enter city";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        classDTORegisterBidder.cityError = "";
      }
    }

    if ("address" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.address)) {
        classDTORegisterBidder.addressError = "Please enter";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        classDTORegisterBidder.addressError = "";
      }
    }

    if ("mobileNo" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.mobileNo)) {
        classDTORegisterBidder.mobileNoError = "Please enter";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        classDTORegisterBidder.mobileNoError = "";
      }
    }

    if ("tblTimeZone" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.tblTimeZone)) {
        classDTORegisterBidder.tblTimeZoneError = "Please select";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        classDTORegisterBidder.tblTimeZoneError = "";
      }
    }

    if ("busCatKeywords" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.busCatKeywords)) {
        classDTORegisterBidder.busCatKeywordsError = "Please enter";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        classDTORegisterBidder.busCatKeywordsError = "";
      }
    }

    if ("userNameTemp" === key) {
      if ("Individual Name" == classDTORegisterBidder.userNameTemp) {
        classDTORegisterBidder.companyName = classDTORegisterBidder.userName;
      } else {
        classDTORegisterBidder.companyName = "";
      }
    }

    if ("password" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.password)) {
        classDTORegisterBidder.passwordError = "Please enter";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        if (
          classDTORegisterBidder.password &&
          classDTORegisterBidder.password.length < 8
        ) {
          classDTORegisterBidder.passwordError =
            "Allows min 8 and max. 50 alphanumeric and special characters (!,@,#,$,_,.,(,))";
          classDTORegisterBidder.isValidationSuccess = false;
        } else if (
          !isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.password) &&
          !isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.confPassword) &&
          classDTORegisterBidder.password != classDTORegisterBidder.confPassword
        ) {
          classDTORegisterBidder.confPasswordError =
            "Confirm password does not match with Password";
          classDTORegisterBidder.isValidationSuccess = false;
        } else {
          classDTORegisterBidder.confPasswordError = "";
          classDTORegisterBidder.passwordError = "";
        }
      }
    }

    if ("confPassword" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.confPassword)) {
        classDTORegisterBidder.confPasswordError = "Please enter";
        classDTORegisterBidder.isValidationSuccess = false;
      } else {
        if (
          !isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.password) &&
          !isNullOrIsEmptyOrIsUndefined(classDTORegisterBidder.confPassword) &&
          classDTORegisterBidder.password != classDTORegisterBidder.confPassword
        ) {
          classDTORegisterBidder.confPasswordError =
            "Confirm password does not match with Password";
          classDTORegisterBidder.isValidationSuccess = false;
        } else {
          classDTORegisterBidder.confPasswordError = "";
        }
      }
    }

    updateClassDTORegisterBidder(classDTORegisterBidder);
  };

  handleButtonsRegisterBidder = (name) => {
    var { classDTORegisterBidder } = this.props;

    switch (name) {
      case "submit": {
        this.checkValidations("all", classDTORegisterBidder);
        if (classDTORegisterBidder.isValidationSuccess) {
          classDTORegisterBidder.tblClient = 10;
          classDTORegisterBidder.ipAddress = "192";
          this.props.submitRegisterBidderDetails(classDTORegisterBidder);
        }
        break;
      }
      default: {
        break;
      }
    }
  };

  componentWillUnmount() {
    let data = { userNameTemp: "Company Name" };
    this.props.updateClassDTORegisterBidder(data);
  }

  render() {
    return (
      <RegisterBidderComponent
        {...this.props}
        handleClassDTORegisterBidder={this.handleClassDTORegisterBidder}
        handleButtonsRegisterBidder={this.handleButtonsRegisterBidder}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    updateClassDTORegisterBidder: (payload) => {
      dispatch(actions.updateClassDTORegisterBidder(payload));
    },

    submitRegisterBidderDetails: (data) => {
      dispatch(actions.submitRegisterBidderDetails(data));
    },

    getAllCountryDetails: () => {
      dispatch(actions.getAllCountryDetails());
    },

    getAllStateDetailsByCountryId: (payload) => {
      dispatch(actions.getAllStateDetailsByCountryId(payload));
    },

    getAllTimeZoneDetails: () => {
      dispatch(actions.getAllTimeZoneDetails());
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTORegisterBidder: selectors.getClassDTORegisterBidder(),
    getAllCountryDetailsResponse: selectors.getAllCountryDetails(),
    getAllStateDetailsByCountryIdResponse:
      selectors.getAllStateDetailsByCountryId(),
    getAllTimeZoneDetailsResponse: selectors.getAllTimeZoneDetails(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
