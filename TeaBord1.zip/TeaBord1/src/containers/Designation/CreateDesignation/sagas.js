import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { apiFetch } from "../../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../../commonConstants/constants";
import { CustomToast as toast } from "../../../components/GenericComponents/Toast";
import { getLocalStorageItem } from "../../../commonConstants/LocalStorageData";

export function* getAllDepartmentDetails() {
  let response = yield apiFetch(
    `common/dept/getdepthierarchy/${getLocalStorageItem("clientId")}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    yield put({
      type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: responseJSON,
      },
    });
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllDesignationDetails({ payload }) {
  let response = yield apiFetch(
    `/common/designation/getParentDesignationHierarchy/${payload.value}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};
    yield put({
      type: ActionTypes.GET_ALL_PARENT_DESIGNATION_DETAILS_SUCCESS,
      payload: {
        value: responseJSON,
      },
    });
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_PARENT_DESIGNATION_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllGradeDetails() {
  let response = yield apiFetch(
    `common/grade/getbyclientId/${getLocalStorageItem("clientId")}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};
    yield put({
      type: ActionTypes.GET_ALL_GRADE_DETAILS_SUCCESS,
      payload: {
        value: responseJSON.responseData,
      },
    });
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_GRADE_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* submitDesignationDetails({ payload }) {
  let response = yield apiFetch("common/designation/createDesignation", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON.responseObj || {};
      toast.success(responseJSON.message);

      let data = {
        deptId: "",
        designationName: "",
        gradeId: "",
        parentDesignationId: "",
        cstatus: 1,
      };
      yield put({
        type: ActionTypes.UPDATE_CLASS_DTO_DESIGNATION,
        payload: {
          data: data,
        },
      });
      yield put({
        type: ActionTypes.SUBMIT_DESIGNATION_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_DESIGNATION_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(ActionTypes.GET_ALL_DEPARTMENT_DETAILS, getAllDepartmentDetails),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_ALL_PARENT_DESIGNATION_DETAILS,
      getAllDesignationDetails
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_GRADE_DETAILS, getAllGradeDetails),
  ]);

  yield all([
    takeLatest(
      ActionTypes.SUBMIT_DESIGNATION_DETAILS,
      submitDesignationDetails
    ),
  ]);
}
