import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "createDesignation";

export const ActionTypes = keyMirrorRecursive(
  {
    GET_ALL_DEPARTMENT_DETAILS: undefined,
    GET_ALL_DEPARTMENT_DETAILS_SUCCESS: undefined,
    GET_ALL_PARENT_DESIGNATION_DETAILS: undefined,
    GET_ALL_PARENT_DESIGNATION_DETAILS_SUCCESS: undefined,
    GET_ALL_GRADE_DETAILS: undefined,
    GET_ALL_GRADE_DETAILS_SUCCESS: undefined,
    UPDATE_CLASS_DTO_DESIGNATION: undefined,
    SUBMIT_DESIGNATION_DETAILS: undefined,
    SUBMIT_DESIGNATION_DETAILS_SUCCESS: undefined,
  },
  pageName
);
