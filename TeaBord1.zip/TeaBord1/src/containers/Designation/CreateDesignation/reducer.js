import { ActionTypes } from "./constants";

const initialState = {
  classDTOCreateDesignation: {
    deptId: "",
    designationName: "",
    gradeId: "",
    parentDesignationId: "",
    cstatus: 1,
  },
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS: {
      state.getAllDepartmentDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_PARENT_DESIGNATION_DETAILS_SUCCESS: {
      state.getAllDesignationDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_GRADE_DETAILS_SUCCESS: {
      state.getAllGradeDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.UPDATE_CLASS_DTO_DESIGNATION: {
      state.classDTOCreateDesignation = action.payload.data || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
