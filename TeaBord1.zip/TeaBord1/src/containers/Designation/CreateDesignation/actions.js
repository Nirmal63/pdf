import { ActionTypes } from "./constants";

export function getAllDepartmentDetails() {
  return {
    type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS,
  };
}

export function getAllDesignationDetails(value) {
  return {
    type: ActionTypes.GET_ALL_PARENT_DESIGNATION_DETAILS,
    payload: {
      value,
    },
  };
}

export function getAllGradeDetails(value) {
  return {
    type: ActionTypes.GET_ALL_GRADE_DETAILS,
    payload: {
      value,
    },
  };
}

export function submitDesignationDetails(data) {
  return {
    type: ActionTypes.SUBMIT_DESIGNATION_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function updateClassDTODesignation(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_DESIGNATION,
    payload: {
      data: payload,
    },
  };
}
