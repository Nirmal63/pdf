import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getAllDepartmentDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllDepartmentDetails);

export const getAllDesignationDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllDesignationDetails);

export const getAllGradeDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllGradeDetails);

export const getClassDTODesignation = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTOCreateDesignation);
