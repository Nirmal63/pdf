import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import CreateDesignationComponent from "../../../components/Designation/CreateDesignation";
import { isNullOrIsEmptyOrIsUndefined } from "../../../commonConstants/CommonValidator";

class index extends Component {
  componentDidMount() {
    this.props.getAllDepartmentDetails();
    // this.props.getAllDesignationDetails();
    this.props.getAllGradeDetails();
  }

  handleClassDTODesignation = (key, value) => {
    let { classDTOCreateDesignation } = this.props;
    classDTOCreateDesignation.isValidationSuccess = true;

    switch (key) {
      default: {
        classDTOCreateDesignation[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTOCreateDesignation);
  };

  checkValidations = (key, data) => {
    let { classDTOCreateDesignation, updateClassDTODesignation } = this.props;

    classDTOCreateDesignation = data;
    classDTOCreateDesignation.isValidationSuccess = true;

    if ("deptId" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.deptId)) {
        classDTOCreateDesignation.deptIdError = "Please select a department";
        classDTOCreateDesignation.isValidationSuccess = false;
      } else {
        if ("deptId" === key) {
          this.props.getAllDesignationDetails(data.deptId);
        }
        classDTOCreateDesignation.deptIdError = "";
      }
    }

    if ("designationName" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.designationName)) {
        classDTOCreateDesignation.designationNameError = "Please enter";
        classDTOCreateDesignation.isValidationSuccess = false;
      } else {
        classDTOCreateDesignation.designationNameError = "";
      }
    }

    if ("gradeId" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(data.gradeId)) {
        classDTOCreateDesignation.gradeIdError = "Please select a grade";
        classDTOCreateDesignation.isValidationSuccess = false;
      } else {
        classDTOCreateDesignation.gradeIdError = "";
      }
    }
    updateClassDTODesignation(classDTOCreateDesignation);
  };

  handleButtonsDesignation = (name, value) => {
    let { classDTOCreateDesignation } = this.props;

    switch (name) {
      case "submit": {
        this.checkValidations("all", classDTOCreateDesignation);
        if (classDTOCreateDesignation.isValidationSuccess) {
          this.props.submitDesignationDetails(classDTOCreateDesignation);
        }
        break;
      }

      default: {
        break;
      }
    }
  };

  resetData = () => {
    let classDTOCreateDesignation = {
      deptId: "",
      designationName: "",
      gradeId: "",
      parentDesignationId: "",
      cstatus: 1,
    };
    this.props.updateClassDTODesignation(classDTOCreateDesignation);
  };

  componentWillUnmount() {
    this.resetData();
  }

  render() {
    return (
      <CreateDesignationComponent
        {...this.props}
        handleClassDTODesignation={this.handleClassDTODesignation}
        handleButtonsDesignation={this.handleButtonsDesignation}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    getAllDepartmentDetails: () => {
      dispatch(actions.getAllDepartmentDetails());
    },

    getAllDesignationDetails: (payload) => {
      dispatch(actions.getAllDesignationDetails(payload));
    },

    getAllGradeDetails: () => {
      dispatch(actions.getAllGradeDetails());
    },

    updateClassDTODesignation: (payload) => {
      dispatch(actions.updateClassDTODesignation(payload));
    },

    submitDesignationDetails: (data) => {
      dispatch(actions.submitDesignationDetails(data));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    getAllDepartmentDetailsResponse: selectors.getAllDepartmentDetails(),
    getAllDesignationDetailsResponse: selectors.getAllDesignationDetails(),
    getAllGradeDetailsResponse: selectors.getAllGradeDetails(),
    classDTOCreateDesignation: selectors.getClassDTODesignation(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
