import React, { Component } from "react";
import "../../styles/global.css";
import "../../styles/media.css";
import "../../styles/component.css";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { ActionTypes, pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import HomeComponent from "../../components/Home";

class index extends Component {
  componentDidMount() {}

  render() {
    return <HomeComponent {...this.props} />;
  }
}

function mapDispatchToProps(dispatch) {
  return {};
}

function mapStateToProps() {
  return createStructuredSelector({});
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
