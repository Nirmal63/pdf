import { ActionTypes } from "./constants";

export function updateIsAuthenticated(value) {
  return {
    type: ActionTypes.UPDATE_IS_AUTHENTICATED,
    payload: {
      data: value,
    },
  };
}

