import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getIsAuthenticated = () =>
  createSelector(stateSelector, (bstate) => bstate.isAuthenticated);

export const isLoading = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.fetchInitiated && !bstate.fetchCompleted
  );
