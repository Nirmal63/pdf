import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "user";

export const ActionTypes = keyMirrorRecursive(
  {
    UPDATE_IS_AUTHENTICATED: undefined,
    FETCH_INITIATED: undefined,
    FETCH_COMPLETED: undefined,
    UNAUTHENTICATED_REQUEST: undefined,
    BUSINESS_EXCEPTION: undefined,
  },
  pageName
);
