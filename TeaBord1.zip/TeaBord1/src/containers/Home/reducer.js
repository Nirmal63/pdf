import { ActionTypes } from "./constants";

const initialState = {
  isAuthenticated: false,
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.UPDATE_IS_AUTHENTICATED: {
      state.isAuthenticated = action.payload.data;
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.FETCH_INITIATED: {
      state.fetchInitiated = true;
      state.fetchCompleted = false;
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.FETCH_COMPLETED: {
      state.fetchCompleted = true;
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.UNAUTHENTICATED_REQUEST: {
      state.isAuthenticated = false;
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.BUSINESS_EXCEPTION: {
      return state.set("exception", action.payload.exception);
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
