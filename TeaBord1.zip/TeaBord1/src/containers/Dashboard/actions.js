import { ActionTypes } from "./constants";

export function getAuctionDetails() {
  return {
    type: ActionTypes.GET_AUCTION_DETAILS,
  };
}

export function checkClientDomainName(data) {
  return {
    type: ActionTypes.CHECK_CLIENT_DOMAIN_NAME,
    payload: {
      data: data,
    },
  };
}
