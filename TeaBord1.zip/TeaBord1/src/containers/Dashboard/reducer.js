import { ActionTypes } from "./constants";

const initialState = {};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.GET_AUCTION_DETAILS_SUCCESS: {
      state.getAuctionDetails = action.payload.value;
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.CHECK_CLIENT_DOMAIN_NAME_SUCCESS: {
      state.checkClientDomainName = action.payload.value;
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
