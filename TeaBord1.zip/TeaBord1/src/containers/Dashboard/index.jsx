import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import DashboardComponent from "../../components/Dashboard";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";

class index extends Component {
  componentDidMount() {
    if (!isNullOrIsEmptyOrIsUndefined(window.location.hostname)) {
      var domainName = window.location.hostname;
      this.props.checkClientDomainName(domainName);
    }
    this.props.getAuctionDetails();
  }

  render() {
    return <DashboardComponent {...this.props} />;
  }
}

function mapDispatchToProps(dispatch) {
  return {
    getAuctionDetails: () => {
      dispatch(actions.getAuctionDetails());
    },

    checkClientDomainName: (payload) => {
      dispatch(actions.checkClientDomainName(payload));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    getAuctionDetailsResponse: selectors.getAuctionDetails(),
    checkClientDomainNameResource: selectors.checkClientDomainName(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
