import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getAuctionDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAuctionDetails);

export const checkClientDomainName = () =>
  createSelector(stateSelector, (bstate) => bstate.checkClientDomainName);
