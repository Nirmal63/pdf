import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "dashboard";

export const ActionTypes = keyMirrorRecursive(
  {
    GET_AUCTION_DETAILS: undefined,
    GET_AUCTION_DETAILS_SUCCESS: undefined,
    CHECK_CLIENT_DOMAIN_NAME: undefined,
    CHECK_CLIENT_DOMAIN_NAME_SUCCESS: undefined,
  },
  pageName
);
