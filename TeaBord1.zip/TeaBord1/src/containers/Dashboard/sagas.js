import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";
import { apiFetch } from "../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../commonConstants/constants";
import { CustomToast as toast } from "../../components/GenericComponents/Toast";
import { setLocalStorageItem } from "../../commonConstants/LocalStorageData";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";

export function* getAuctionDetails() {
  let response = yield apiFetch("eauction/unauth/live", {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};

      yield put({
        type: ActionTypes.GET_AUCTION_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_AUCTION_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}
export function* checkClientDomainName({ payload }) {
  let response = yield apiFetch(`common/unauth/checkclient/${payload.data}`, {
    method: "GET",
  }).then((res) => res);

  console.log("response 45", response);
  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON.responseData || {};

      // if (responseJSON.message == "success") {
      if (!isNullOrIsEmptyOrIsUndefined(responseObj)) {
        // toast.success(responseJSON.message);
        yield put({
          type: ActionTypes.CHECK_CLIENT_DOMAIN_NAME_SUCCESS,
          payload: {
            value: responseObj,
          },
        });
        setLocalStorageItem("clientId", responseObj);
        console.log("setClient:::::", responseObj);
      } else {
        localStorage.removeItem("token");
        localStorage.removeItem("clientId");
        localStorage.removeItem("userId");
        localStorage.removeItem("usertypeId");
        window.location.href = "/dashboard";
      }
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    toast.success(response.message, {
      position: toast.POSITION.TOP_CENTER,
    });
    yield put({
      type: ActionTypes.CHECK_CLIENT_DOMAIN_NAME_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.GET_AUCTION_DETAILS,

      getAuctionDetails
    ),
  ]);

  yield all([
    takeLatest(
      ActionTypes.CHECK_CLIENT_DOMAIN_NAME,

      checkClientDomainName
    ),
  ]);
}
