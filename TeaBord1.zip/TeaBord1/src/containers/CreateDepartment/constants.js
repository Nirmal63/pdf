import keyMirrorRecursive from "fbjs/lib/keyMirrorRecursive";

export const pageName = "createDepartment";

export const ActionTypes = keyMirrorRecursive(
  {
    UPDATE_CLASS_DTO_CREATE_DEPARTMENT: undefined,
    SUBMIT_CREATE_DEPARTMENT_DETAILS: undefined,
    SUBMIT_CREATE_DEPARTMENT_DETAILS_SUCCESS: undefined,
    GET_ALL_DEPARTMENT_DETAILS: undefined,
    GET_ALL_DEPARTMENT_DETAILS_SUCCESS: undefined,
    GET_ALL_COUNTRY_DETAILS: undefined,
    GET_ALL_COUNTRY_DETAILS_SUCCESS: undefined,
    GET_ALL_STATE_DETAILS_BY_COUNTRY_ID: undefined,
    GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS: undefined,
  },
  pageName
);
