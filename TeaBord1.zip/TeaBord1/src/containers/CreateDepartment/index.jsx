import React, { Component } from "react";
import { compose } from "redux";
import { connect } from "react-redux";
import { createStructuredSelector } from "reselect";
import { injectReducer, injectSaga } from "redux-inject-reducer-and-saga";
import * as actions from "./actions";
import { pageName } from "./constants";
import reducer from "./reducer";
import saga from "./sagas";
import * as selectors from "./selectors";
import CreateDepartmentComponent from "../../components/CreateDepartment";
import { isNullOrIsEmptyOrIsUndefined } from "../../commonConstants/CommonValidator";
import { getLocalStorageItem } from "../../commonConstants/LocalStorageData";

class index extends Component {
  componentDidMount() {
    this.props.getAllDepartmentDetails();
    this.props.getAllCountryDetails();
  }

  handleClassDTOCreateDepartment = (key, value) => {
    let { classDTOCreateDepartment } = this.props;
    classDTOCreateDepartment.isValidationSuccess = true;

    switch (key) {
      default: {
        classDTOCreateDepartment[key] = value;
        break;
      }
    }

    this.checkValidations(key, classDTOCreateDepartment);
  };

  checkValidations = (key, data) => {
    let { classDTOCreateDepartment, updateClassDTOCreateDepartment } =
      this.props;

    classDTOCreateDepartment = data;
    classDTOCreateDepartment.isValidationSuccess = true;

    if ("deptName" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateDepartment.deptName)) {
        classDTOCreateDepartment.deptNameError = "Please enter department name";
        classDTOCreateDepartment.isValidationSuccess = false;
      } else {
        classDTOCreateDepartment.deptNameError = "";
      }
    }

    if ("tblCountry" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateDepartment.tblCountry)) {
        classDTOCreateDepartment.tblCountryError = "Please select country";
        classDTOCreateDepartment.isValidationSuccess = false;
      } else {
        if ("tblCountry" === key) {
          this.props.getAllStateDetailsByCountryId(
            classDTOCreateDepartment.tblCountry
          );
        }
        classDTOCreateDepartment.tblCountryError = "";
      }
    }

    if ("tblState" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateDepartment.tblState)) {
        classDTOCreateDepartment.tblStateError = "Please select state";
        classDTOCreateDepartment.isValidationSuccess = false;
      } else {
        classDTOCreateDepartment.tblStateError = "";
      }
    }

    if ("city" === key || "all" === key) {
      if (isNullOrIsEmptyOrIsUndefined(classDTOCreateDepartment.city)) {
        classDTOCreateDepartment.cityError = "Please enter city";
        classDTOCreateDepartment.isValidationSuccess = false;
      } else {
        classDTOCreateDepartment.cityError = "";
      }
    }

    updateClassDTOCreateDepartment(classDTOCreateDepartment);
  };

  handleButtonsCreateDepartment = (name) => {
    var { classDTOCreateDepartment } = this.props;

    switch (name) {
      case "submit": {
        this.checkValidations("all", classDTOCreateDepartment);
        if (classDTOCreateDepartment.isValidationSuccess) {
          classDTOCreateDepartment.clientId = getLocalStorageItem("clientId");
          this.props.submitCreateDepartmentDetails(classDTOCreateDepartment);
        }
        break;
      }
      default: {
        break;
      }
    }
  };

  render() {
    return (
      <CreateDepartmentComponent
        {...this.props}
        handleClassDTOCreateDepartment={this.handleClassDTOCreateDepartment}
        handleButtonsCreateDepartment={this.handleButtonsCreateDepartment}
      />
    );
  }
}

function mapDispatchToProps(dispatch) {
  return {
    updateClassDTOCreateDepartment: (payload) => {
      dispatch(actions.updateClassDTOCreateDepartment(payload));
    },

    submitCreateDepartmentDetails: (data) => {
      dispatch(actions.submitCreateDepartmentDetails(data));
    },

    getAllDepartmentDetails: () => {
      dispatch(actions.getAllDepartmentDetails());
    },

    getAllCountryDetails: () => {
      dispatch(actions.getAllCountryDetails());
    },

    getAllStateDetailsByCountryId: (payload) => {
      dispatch(actions.getAllStateDetailsByCountryId(payload));
    },
  };
}

function mapStateToProps() {
  return createStructuredSelector({
    classDTOCreateDepartment: selectors.getClassDTOCreateDepartment(),
    getAllDepartmentDetailsResponse: selectors.getAllDepartmentDetails(),
    getAllCountryDetailsResponse: selectors.getAllCountryDetails(),
    getAllStateDetailsByCountryIdResponse:
      selectors.getAllStateDetailsByCountryId(),
  });
}

const withReducer = injectReducer({ key: pageName, reducer });
const withSaga = injectSaga({ key: pageName, saga });
const withConnect = connect(mapStateToProps, mapDispatchToProps);

const enhance = compose(withReducer, withSaga, withConnect)(index);

export default enhance;
