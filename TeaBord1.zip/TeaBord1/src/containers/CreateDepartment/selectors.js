import { pageName } from "./constants";
import { createSelector } from "reselect";

const stateSelector = (state) => state.get(pageName);

export const getClassDTOCreateDepartment = () =>
  createSelector(stateSelector, (bstate) => bstate.classDTOCreateDepartment);

export const getAllDepartmentDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllDepartmentDetails);

export const getAllCountryDetails = () =>
  createSelector(stateSelector, (bstate) => bstate.getAllCountryDetails);

export const getAllStateDetailsByCountryId = () =>
  createSelector(
    stateSelector,
    (bstate) => bstate.getAllStateDetailsByCountryId
  );
