import { ActionTypes } from "./constants";

const initialState = {
  classDTOCreateDepartment: {
    clientId: 10,
    parentDeptId: "",
    deptName: "",
    tblCountry: "",
    tblState: "",
    city: "",
    address: "",
    phoneNo: "",
    gstNo: "",
  },
};

export default function reducer(state = initialState, action) {
  switch (action.type) {
    case ActionTypes.UPDATE_CLASS_DTO_CREATE_DEPARTMENT: {
      state.classDTOCreateDepartment = action.payload || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS: {
      state.getAllDepartmentDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_COUNTRY_DETAILS_SUCCESS: {
      state.getAllCountryDetails = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    case ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS: {
      state.getAllStateDetailsByCountryId = action.payload.value || {};
      return JSON.parse(JSON.stringify(state));
    }

    default:
      return JSON.parse(JSON.stringify(state));
  }
}
