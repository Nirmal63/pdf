import { all, put, takeLatest } from "redux-saga/effects";
import { ActionTypes } from "./constants";

import { apiFetch } from "../../utility/fetch-utils";
import { ERROR_MESSAGE_FOR_DEFAULT } from "../../commonConstants/constants";
import { CustomToast as toast } from "../../components/GenericComponents/Toast";
import { getLocalStorageItem } from "../../commonConstants/LocalStorageData";

export function* submitCreateDepartmentDetails({ payload }) {
  let response = yield apiFetch("common/dept/create", {
    method: "POST",
    body: JSON.stringify(payload.data),
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      var responseObj = responseJSON.responseData || {};
      yield put({
        type: ActionTypes.SUBMIT_CREATE_DEPARTMENT_DETAILS_SUCCESS,
        payload: {
          value: responseObj,
        },
      });
      toast.success(responseJSON.message);
    } else {
      toast.error(responseJSON.message);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.SUBMIT_CREATE_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllDepartmentDetails() {
  // clientId
  let response = yield apiFetch(
    `common/dept/getdepthierarchy/${getLocalStorageItem("clientId")}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    yield put({
      type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: responseJSON,
      },
    });

    // if (200 === responseJSON.statusCode) {
    //   let responseObj = responseJSON || {};
    //   yield put({
    //     type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
    //     payload: {
    //       value: responseObj.responseData,
    //     },
    //   });
    // } else {
    //   // toast.error(
    //   //   responseJSON.message ||ERROR_MESSAGE_FOR_DEFAULT
    //   // );
    // }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllCountryDetails() {
  let response = yield apiFetch("common/country/unauth/getAllCountry", {
    method: "GET",
  }).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};

      yield put({
        type: ActionTypes.GET_ALL_COUNTRY_DETAILS_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_COUNTRY_DETAILS_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export function* getAllStateDetailsByCountryId({ payload }) {
  let response = yield apiFetch(
    `common/state/unauth/getStateByCountryId/${payload.value}`,
    {
      method: "GET",
    }
  ).then((res) => res);

  if (200 === response.status) {
    let responseJSON = yield response.json() || {};

    if (200 === responseJSON.statusCode) {
      let responseObj = responseJSON || {};
      yield put({
        type: ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS,
        payload: {
          value: responseObj.responseData,
        },
      });
    } else {
      toast.error(responseJSON.message || ERROR_MESSAGE_FOR_DEFAULT);
    }
  } else if (204 === response.status) {
    yield put({
      type: ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID_SUCCESS,
      payload: {
        value: [],
      },
    });
  } else {
    toast.error(ERROR_MESSAGE_FOR_DEFAULT);
  }
}

export default function* root() {
  yield all([
    takeLatest(
      ActionTypes.SUBMIT_CREATE_DEPARTMENT_DETAILS,
      submitCreateDepartmentDetails
    ),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_DEPARTMENT_DETAILS, getAllDepartmentDetails),
  ]);

  yield all([
    takeLatest(ActionTypes.GET_ALL_COUNTRY_DETAILS, getAllCountryDetails),
  ]);

  yield all([
    takeLatest(
      ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID,
      getAllStateDetailsByCountryId
    ),
  ]);
}
