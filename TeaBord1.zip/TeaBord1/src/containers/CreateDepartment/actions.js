import { ActionTypes } from "./constants";

export function updateClassDTOCreateDepartment(payload) {
  return {
    type: ActionTypes.UPDATE_CLASS_DTO_CREATE_DEPARTMENT,
    payload,
  };
}

export function submitCreateDepartmentDetails(data) {
  return {
    type: ActionTypes.SUBMIT_CREATE_DEPARTMENT_DETAILS,
    payload: {
      data: data,
    },
  };
}

export function getAllDepartmentDetails() {
  return {
    type: ActionTypes.GET_ALL_DEPARTMENT_DETAILS,
  };
}

export function getAllCountryDetails() {
  return {
    type: ActionTypes.GET_ALL_COUNTRY_DETAILS,
  };
}

export function getAllStateDetailsByCountryId(value) {
  return {
    type: ActionTypes.GET_ALL_STATE_DETAILS_BY_COUNTRY_ID,
    payload: {
      value,
    },
  };
}
