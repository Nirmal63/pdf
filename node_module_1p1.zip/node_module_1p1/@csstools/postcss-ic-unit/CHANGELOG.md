# Changes to PostCSS IC Unit

### 1.0.1 (July 8, 2022)

- Fix case insensitive matching.

### 1.0.0 (February 15, 2022)

- Initial version
