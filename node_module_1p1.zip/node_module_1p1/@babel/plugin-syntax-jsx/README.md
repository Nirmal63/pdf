# @babel/plugin-syntax-jsx

> Allow parsing of jsx

See our website [@babel/plugin-syntax-jsx](https://babeljs.io/docs/en/babel-plugin-syntax-jsx) for more information.

## Install

Using npm:

```sh
npm install --save-dev @babel/plugin-syntax-jsx
```

or using yarn:

```sh
yarn add @babel/plugin-syntax-jsx --dev
```
