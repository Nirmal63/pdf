package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblCurrencyDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblCurrency;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCurrencyImpl extends AbcAbstractClass<TblCurrency> implements TblCurrencyDao {

    @Override
    public void addTblCurrency(TblCurrency tblCurrency){
        super.addEntity(tblCurrency);
    }

    @Override
    public void deleteTblCurrency(TblCurrency tblCurrency) {
        super.deleteEntity(tblCurrency);
    }

    @Override
    public void updateTblCurrency(TblCurrency tblCurrency) {
        super.updateEntity(tblCurrency);
    }

    @Override
    public List<TblCurrency> getAllTblCurrency() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCurrency> findTblCurrency(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCurrencyCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCurrency> findByCountTblCurrency(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCurrency(List<TblCurrency> tblCurrencys){
        super.updateAll(tblCurrencys);
    }
}
