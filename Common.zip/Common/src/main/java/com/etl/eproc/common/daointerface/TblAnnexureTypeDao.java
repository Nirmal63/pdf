package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblAnnexureType;

public interface TblAnnexureTypeDao {

    public void addTblAnnexureType(TblAnnexureType tblAnnexureType);

    public void deleteTblAnnexureType(TblAnnexureType tblAnnexureType);

    public void updateTblAnnexureType(TblAnnexureType tblAnnexureType);

    public List<TblAnnexureType> getAllTblAnnexureType();

    public List<TblAnnexureType> findTblAnnexureType(Object... values) throws Exception;

    public List<TblAnnexureType> findByCountTblAnnexureType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAnnexureTypeCount();
}