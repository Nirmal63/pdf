package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblDocUploadConfDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblDocUploadConf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDocUploadConfImpl extends AbcAbstractClass<TblDocUploadConf> implements TblDocUploadConfDao {

    @Override
    public void addTblDocUploadConf(TblDocUploadConf tblDocUploadConf){
        super.addEntity(tblDocUploadConf);
    }

    @Override
    public void deleteTblDocUploadConf(TblDocUploadConf tblDocUploadConf) {
        super.deleteEntity(tblDocUploadConf);
    }

    @Override
    public void updateTblDocUploadConf(TblDocUploadConf tblDocUploadConf) {
        super.updateEntity(tblDocUploadConf);
    }

    @Override
    public List<TblDocUploadConf> getAllTblDocUploadConf() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDocUploadConf> findTblDocUploadConf(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDocUploadConfCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDocUploadConf> findByCountTblDocUploadConf(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDocUploadConf(List<TblDocUploadConf> tblDocUploadConfs){
        super.updateAll(tblDocUploadConfs);
    }
}
