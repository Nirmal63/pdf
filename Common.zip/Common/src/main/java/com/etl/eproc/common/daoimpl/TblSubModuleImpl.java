package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblSubModuleDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblSubModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblSubModuleImpl extends AbcAbstractClass<TblSubModule> implements TblSubModuleDao {

    @Override
    public void addTblSubModule(TblSubModule tblSubModule){
        super.addEntity(tblSubModule);
    }

    @Override
    public void deleteTblSubModule(TblSubModule tblSubModule) {
        super.deleteEntity(tblSubModule);
    }

    @Override
    public void updateTblSubModule(TblSubModule tblSubModule) {
        super.updateEntity(tblSubModule);
    }

    @Override
    public List<TblSubModule> getAllTblSubModule() {
        return super.getAllEntity();
    }

    @Override
    public List<TblSubModule> findTblSubModule(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblSubModuleCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblSubModule> findByCountTblSubModule(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblSubModule(List<TblSubModule> tblSubModules){
        super.updateAll(tblSubModules);
    }
}
