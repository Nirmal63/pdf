package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblAuctionMarqueeHistory;
import com.etl.eproc.common.daointerface.TblAuctionMarqueeHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblAuctionMarqueeHistoryImpl extends AbcAbstractClass<TblAuctionMarqueeHistory> implements TblAuctionMarqueeHistoryDao {

    @Override
    public void addTblAuctionMarqueeHistory(TblAuctionMarqueeHistory tblAuctionMarqueeHistory){
        super.addEntity(tblAuctionMarqueeHistory);
    }

    @Override
    public void deleteTblAuctionMarqueeHistory(TblAuctionMarqueeHistory tblAuctionMarqueeHistory) {
        super.deleteEntity(tblAuctionMarqueeHistory);
    }

    @Override
    public void updateTblAuctionMarqueeHistory(TblAuctionMarqueeHistory tblAuctionMarqueeHistory) {
        super.updateEntity(tblAuctionMarqueeHistory);
    }

    @Override
    public List<TblAuctionMarqueeHistory> getAllTblAuctionMarqueeHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAuctionMarqueeHistory> findTblAuctionMarqueeHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAuctionMarqueeHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAuctionMarqueeHistory> findByCountTblAuctionMarqueeHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAuctionMarqueeHistory(List<TblAuctionMarqueeHistory> tblAuctionMarqueeHistorys){
        super.updateAll(tblAuctionMarqueeHistorys);
    }
}
