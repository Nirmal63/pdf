package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblOnlinePayment;
import com.etl.eproc.common.daointerface.TblOnlinePaymentDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblOnlinePaymentImpl extends AbcAbstractClass<TblOnlinePayment> implements TblOnlinePaymentDao {


    @Override
    public void addTblOnlinePayment(TblOnlinePayment tblOnlinePayment){
        super.addEntity(tblOnlinePayment);
    }

    @Override
    public void deleteTblOnlinePayment(TblOnlinePayment tblOnlinePayment) {
        super.deleteEntity(tblOnlinePayment);
    }

    @Override
    public void updateTblOnlinePayment(TblOnlinePayment tblOnlinePayment) {
        super.updateEntity(tblOnlinePayment);
    }

    @Override
    public List<TblOnlinePayment> getAllTblOnlinePayment() {
        return super.getAllEntity();
    }

    @Override
    public List<TblOnlinePayment> findTblOnlinePayment(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblOnlinePaymentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblOnlinePayment> findByCountTblOnlinePayment(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblOnlinePayment(List<TblOnlinePayment> tblOnlinePayments){
        super.updateAll(tblOnlinePayments);
    }

	@Override
	public void saveOrUpdateTblOnlinePayment(TblOnlinePayment tblOnlinePayment) {
	super.saveOrUpdateEntity(tblOnlinePayment);
	}
}
