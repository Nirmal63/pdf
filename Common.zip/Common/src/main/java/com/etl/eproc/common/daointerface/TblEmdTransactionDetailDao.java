package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblEMDTransactionDetail;
import java.util.List;

public interface TblEmdTransactionDetailDao  {

    public void addTblEMDTransactionDetail(TblEMDTransactionDetail tblEmdTransactionDetail);

    public void deleteTblEMDTransactionDetail(TblEMDTransactionDetail tblEmdTransactionDetail);

    public void updateTblEMDTransactionDetail(TblEMDTransactionDetail tblEmdTransactionDetail);

    public List<TblEMDTransactionDetail> getAllTblEMDTransactionDetail();

    public List<TblEMDTransactionDetail> findTblEMDTransactionDetail(Object... values) throws Exception;

    public List<TblEMDTransactionDetail> findByCountTblEMDTransactionDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEMDTransactionDetailCount();

    public void saveUpdateAllTblEMDTransactionDetail(List<TblEMDTransactionDetail> tblEmdTransactionDetails);
}