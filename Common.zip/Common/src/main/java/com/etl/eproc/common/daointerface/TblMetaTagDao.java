package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMetaTag;
import java.util.List;

public interface TblMetaTagDao  {

    public void addTblMetaTag(TblMetaTag tblMetaTag);

    public void deleteTblMetaTag(TblMetaTag tblMetaTag);

    public void updateTblMetaTag(TblMetaTag tblMetaTag);

    public List<TblMetaTag> getAllTblMetaTag();

    public List<TblMetaTag> findTblMetaTag(Object... values) throws Exception;

    public List<TblMetaTag> findByCountTblMetaTag(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMetaTagCount();

    public void saveUpdateAllTblMetaTag(List<TblMetaTag> tblMetaTags);
}