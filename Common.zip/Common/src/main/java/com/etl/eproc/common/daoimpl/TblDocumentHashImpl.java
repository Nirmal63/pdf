package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblDocumentHash;
import com.etl.eproc.common.daointerface.TblDocumentHashDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDocumentHashImpl extends AbcAbstractClass<TblDocumentHash> implements TblDocumentHashDao {

    @Override
    public void addTblDocumentHash(TblDocumentHash tblDocumentHash){
        super.addEntity(tblDocumentHash);
    }

    @Override
    public void deleteTblDocumentHash(TblDocumentHash tblDocumentHash) {
        super.deleteEntity(tblDocumentHash);
    }

    @Override
    public void updateTblDocumentHash(TblDocumentHash tblDocumentHash) {
        super.updateEntity(tblDocumentHash);
    }

    @Override
    public List<TblDocumentHash> getAllTblDocumentHash() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDocumentHash> findTblDocumentHash(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDocumentHashCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDocumentHash> findByCountTblDocumentHash(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDocumentHash(List<TblDocumentHash> tblDocumentHashs){
        super.updateAll(tblDocumentHashs);
    }

	@Override
	public void saveOrUpdateTblDocumentHash(TblDocumentHash tblDocumentHash) {
		super.saveOrUpdateEntity(tblDocumentHash);
	}
}
