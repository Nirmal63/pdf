/**
 * 
 */
package com.etl.eproc.common.daoimpl;

/**
 * @author janak
 *
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblPurchaseOrderItemAmendmentDao;
import com.etl.eproc.common.model.TblPurchaseOrderItemAmendment;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblPurchaseOrderItemAmendmentImpl extends AbcAbstractClass<TblPurchaseOrderItemAmendment> implements TblPurchaseOrderItemAmendmentDao {

    @Override
    public void addTblPurchaseOrderItemAmendment(TblPurchaseOrderItemAmendment tblPurchaseOrderItemAmendment){
        super.addEntity(tblPurchaseOrderItemAmendment);
    }

    @Override
    public void deleteTblPurchaseOrderItemAmendment(TblPurchaseOrderItemAmendment tblPurchaseOrderItemAmendment) {
        super.deleteEntity(tblPurchaseOrderItemAmendment);
    }

    @Override
    public void updateTblPurchaseOrderItemAmendment(TblPurchaseOrderItemAmendment tblPurchaseOrderItemAmendment) {
        super.updateEntity(tblPurchaseOrderItemAmendment);
    }

    @Override
    public List<TblPurchaseOrderItemAmendment> getAllTblPurchaseOrderItemAmendment() {
        return super.getAllEntity();
    }

    @Override
    public List<TblPurchaseOrderItemAmendment> findTblPurchaseOrderItemAmendment(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblPurchaseOrderItemAmendmentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblPurchaseOrderItemAmendment> findByCountTblPurchaseOrderItemAmendment(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblPurchaseOrderItemAmendment(List<TblPurchaseOrderItemAmendment> tblPurchaseOrderItemAmendments){
        super.updateAll(tblPurchaseOrderItemAmendments);
    }
}

