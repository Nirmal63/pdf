package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblAuditMaster;

public interface TblAuditMasterDao  {

    public void addTblAuditMaster(TblAuditMaster tblAuditMaster);

    public void deleteTblAuditMaster(TblAuditMaster tblAuditMaster);

    public void updateTblAuditMaster(TblAuditMaster tblAuditMaster);

    public List<TblAuditMaster> getAllTblAuditMaster();

    public List<TblAuditMaster> findTblAuditMaster(Object... values) throws Exception;

    public List<TblAuditMaster> findByCountTblAuditMaster(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAuditMasterCount();

    public void saveUpdateAllTblAuditMaster(List<TblAuditMaster> tblAuditMasters);
}