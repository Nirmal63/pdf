package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblNegotiationResult;
import java.util.List;

public interface TblNegotiationResultDao  {

    public void addTblNegotiationResult(TblNegotiationResult tblNegotiationResult);

    public void deleteTblNegotiationResult(TblNegotiationResult tblNegotiationResult);

    public void updateTblNegotiationResult(TblNegotiationResult tblNegotiationResult);

    public List<TblNegotiationResult> getAllTblNegotiationResult();

    public List<TblNegotiationResult> findTblNegotiationResult(Object... values) throws Exception;

    public List<TblNegotiationResult> findByCountTblNegotiationResult(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNegotiationResultCount();

    public void saveUpdateAllTblNegotiationResult(List<TblNegotiationResult> tblNegotiationResults);
}