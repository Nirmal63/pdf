/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblEmdBalanceDao;
import com.etl.eproc.eauction.model.TblEmdBalance;

/**
 *
 * @author shreyansh
 */
@Repository @Transactional    /*StackUpdate*/
public class TblEmdBalanceImpl extends AbcAbstractClass<TblEmdBalance> implements TblEmdBalanceDao {


    @Override
    public void addTblEmdBalance(TblEmdBalance tblEmdBalance){
        super.addEntity(tblEmdBalance);
    }

    @Override
    public void deleteTblEmdBalance(TblEmdBalance tblEmdBalance) {
        super.deleteEntity(tblEmdBalance);
    }

    @Override
    public void updateTblEmdBalance(TblEmdBalance tblEmdBalance) {
        super.updateEntity(tblEmdBalance);
    }

    @Override
    public List<TblEmdBalance> getAllTblEmdBalance() {
        return super.getAllEntity();
    }

    @Override
    public List<TblEmdBalance> findTblEmdBalance(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblEmdBalanceCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblEmdBalance> findByCountTblEmdBalance(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblEmdBalance(List<TblEmdBalance> tblEmdBalances){
        super.updateAll(tblEmdBalances);
    }

	@Override
	public void saveOrUpdateTblEmdBalance(TblEmdBalance tblEmdBalance) {
		super.saveOrUpdateEntity(tblEmdBalance);
		
	}
}

