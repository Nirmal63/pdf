package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblH1BidderReport;
import java.util.List;

public interface TblH1BidderReportDao  {

    public void addTblH1BidderReport(TblH1BidderReport tblH1BidderReport);

    public void deleteTblH1BidderReport(TblH1BidderReport tblH1BidderReport);

    public void updateTblH1BidderReport(TblH1BidderReport tblH1BidderReport);

    public List<TblH1BidderReport> getAllTblH1BidderReport();

    public List<TblH1BidderReport> findTblH1BidderReport(Object... values) throws Exception;

    public List<TblH1BidderReport> findByCountTblH1BidderReport(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblH1BidderReportCount();

    public void saveUpdateAllTblH1BidderReport(List<TblH1BidderReport> tblH1BidderReports);
}