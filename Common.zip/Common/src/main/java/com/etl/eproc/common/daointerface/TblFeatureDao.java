package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblFeature;
import java.util.List;

public interface TblFeatureDao  {

    public void addTblFeature(TblFeature tblFeature);

    public void deleteTblFeature(TblFeature tblFeature);

    public void updateTblFeature(TblFeature tblFeature);

    public List<TblFeature> getAllTblFeature();

    public List<TblFeature> findTblFeature(Object... values) throws Exception;

    public List<TblFeature> findByCountTblFeature(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFeatureCount();

    public void saveUpdateAllTblFeature(List<TblFeature> tblFeatures);
}