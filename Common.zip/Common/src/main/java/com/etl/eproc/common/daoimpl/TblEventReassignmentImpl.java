package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblEventReassignment;
import com.etl.eproc.common.daointerface.TblEventReassignmentDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblEventReassignmentImpl extends AbcAbstractClass<TblEventReassignment> implements TblEventReassignmentDao {

    @Override
    public void addTblEventReassignment(TblEventReassignment tblEventReassignment){
        super.addEntity(tblEventReassignment);
    }

    @Override
    public void deleteTblEventReassignment(TblEventReassignment tblEventReassignment) {
        super.deleteEntity(tblEventReassignment);
    }

    @Override
    public void updateTblEventReassignment(TblEventReassignment tblEventReassignment) {
        super.updateEntity(tblEventReassignment);
    }

    @Override
    public List<TblEventReassignment> getAllTblEventReassignment() {
        return super.getAllEntity();
    }

    @Override
    public List<TblEventReassignment> findTblEventReassignment(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblEventReassignmentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblEventReassignment> findByCountTblEventReassignment(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblEventReassignment(List<TblEventReassignment> tblEventReassignments){
        super.updateAll(tblEventReassignments);
    }
}
