package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblClientLinkConfig;
import com.etl.eproc.common.daointerface.TblClientLinkConfigDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientLinkConfigImpl extends AbcAbstractClass<TblClientLinkConfig> implements TblClientLinkConfigDao {

    @Override
    public void addTblClientLinkConfig(TblClientLinkConfig tblClientLinkConfig){
        super.addEntity(tblClientLinkConfig);
    }

    @Override
    public void deleteTblClientLinkConfig(TblClientLinkConfig tblClientLinkConfig) {
        super.deleteEntity(tblClientLinkConfig);
    }

    @Override
    public void updateTblClientLinkConfig(TblClientLinkConfig tblClientLinkConfig) {
        super.updateEntity(tblClientLinkConfig);
    }

    @Override
    public List<TblClientLinkConfig> getAllTblClientLinkConfig() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientLinkConfig> findTblClientLinkConfig(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientLinkConfigCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientLinkConfig> findByCountTblClientLinkConfig(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientLinkConfig(List<TblClientLinkConfig> tblClientLinkConfigs){
        super.updateAll(tblClientLinkConfigs);
    }
}
