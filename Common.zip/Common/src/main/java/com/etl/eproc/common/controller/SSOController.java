/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Iterator;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.jsoup.select.Evaluator.IsEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.WSCheckAvailService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SHA1HashEncryption;
import com.etl.eproc.common.utility.SHA256HashEncryption;
import com.etl.eproc.common.utility.WSCheckAvail;
import com.etl.eproc.common.webservice.DataObject;

/**
 *
 * @author dixit
 */
@Controller
public class SSOController {
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private WSCheckAvailService wSCheckAvailService;
    @Autowired
    private SHA256HashEncryption sha256HashEncryption;
    @Autowired
    private SHA1HashEncryption sha1HashEncryption;
    @Autowired
    private AbcUtility abcUtility; 
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
	private CommonService commonService;
    @Autowired
	private ModelToSelectItem modelToSelectItem;
    @Autowired
    private ManageBidderService manageBidderService;
    /**
     * To check unique email id
     * @param request
     * @return 
     */
    @RequestMapping(value = "/ajaxcall/uniqueEmailIdcheck", method = RequestMethod.POST)
    @ResponseBody
    public String uniqueEmailIdcheck(@RequestParam("txtemailId") String txtemailId, @RequestParam("txtdbemalId") String txtdbemalId,HttpServletRequest request) {
        String result = null;
        try {
            boolean isSSOEnabled = false;
            HttpSession httpSession = request.getSession();
            if (httpSession.getAttribute("clientObject") != null) {
                ClientBean clientBean = (ClientBean) httpSession.getAttribute("clientObject");
                isSSOEnabled = clientBean.isIsSsoEnabled();
            }
            if(isSSOEnabled){
                if(WSCheckAvail.isSsoAvailable()){
                result=WSCheckAvail.verifyMail(txtemailId, txtdbemalId);            
                }else{
                    result = "Valid"; //"Unable to process Your Request";
                }
            }else{
                result = "Valid"; //"in case of SSO Is not Required";
            }
            
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return result;
    }
    /**
     * To check unique email id
     * @param request
     * @return 
     */
    @RequestMapping(value = "/ajaxcall/resetPassword", method = RequestMethod.POST)
    @ResponseBody
    public String resetPassword(@RequestParam("txtemailId") String txtemailId,HttpServletRequest request) {
        String result = null;
        try {
            boolean isSSOEnabled = false;
            HttpSession httpSession = request.getSession();
            if (httpSession.getAttribute("clientObject") != null) {
                ClientBean clientBean = (ClientBean) httpSession.getAttribute("clientObject");
                isSSOEnabled = clientBean.isIsSsoEnabled();
            }
            if(isSSOEnabled){
                if(WSCheckAvail.isSsoAvailable()){
                    if(wSCheckAvailService.changePassword(txtemailId, sha256HashEncryption.encodeStringSHA256(txtemailId)+"~~"+sha1HashEncryption.encodeStringSHA1(txtemailId),0,abcUtility.getSessionClientId(request))){
                        result = "<div class=\"successMsg t_space\">Password reset successfully</div>";
                    }else{
                        result = "<div class=\"errorMsg t_space\">Password reset failed</div>";
                    }
                }else{
                    result = ""; //"Unable to process Your Request";
                }
            }else{
                result = ""; //"in case of SSO Is not Required";
            }    
            
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return result;
    }
    /**
     * To check unique email id
     * @param request
     * @return 
     */
    @RequestMapping(value = "/ajaxcall/dumpUser", method = RequestMethod.POST)
    @ResponseBody
    public String dumpUser(@RequestParam("txtemailId") String txtemailId,HttpServletRequest request) {
        String result = null;
        try {
            boolean isSSOEnabled = false;
            HttpSession httpSession = request.getSession();
            if (httpSession.getAttribute("clientObject") != null) {
                ClientBean clientBean = (ClientBean) httpSession.getAttribute("clientObject");
                isSSOEnabled = clientBean.isIsSsoEnabled();
            }
            if(isSSOEnabled){
                if(WSCheckAvail.isSsoAvailable()){
                    result = wSCheckAvailService.dumpSupplier(txtemailId,abcUtility.getSessionClientId(request),false,0,0);
                }else{
                    result = "fail"; //"Unable to process Your Request";
                }
            }else{
                result = "fail"; //"in case of SSO Is not Required";
            }    
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return result;
    }
    /**
     * To check unique email id
     * @param request
     * @return 
     */
    @RequestMapping(value = "/ajaxcall/searchUser", method = RequestMethod.POST)
    @ResponseBody
    public String searchUser(@RequestParam("txtemailId") String txtemailId,HttpServletRequest request) {
        String result = null;
        try {
           // if (!txtemailId.matches("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9\\-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")) {
        	if (txtemailId.isEmpty()) {
                    result = "<font color='red'>Please enter valid Email Id</font>";
                }else{
                    int clientId =0;
                    boolean isSSOEnabled = false;
                    HttpSession httpSession = request.getSession();
                    if (httpSession.getAttribute("clientObject") != null) {
                        ClientBean clientBean = (ClientBean) httpSession.getAttribute("clientObject");
                        isSSOEnabled = clientBean.isIsSsoEnabled();
                        clientId = clientBean.getClientId();
                    }
//                    System.out.println("isSSOEnabled :: "+isSSOEnabled);
                    if(isSSOEnabled){
                        if(WSCheckAvail.isSsoAvailable())
                        {
                        	   DataObject t = WSCheckAvail.getSSOLoginMastreDetailasObject(txtemailId);
                        	   if(t!=null && t.getData2().toString() !=null && t.getData13() == null && t.getData14() == null){
                        		   
                        		   StringBuilder sb = new StringBuilder();
                        		   String langId = WebUtils.getCookie(request, "locale").getValue();
                        		   sb.append("<table width='100%' cellspacing='0' cellpadding='0' border='0'>")
                        		   .append("<tr>").append("<td>Email Id</td>").append("<td>").append(t.getData2().toString()).append("</td>").append("</tr>")
                        		   .append("<tr>").append("<td>First Name</td>").append("<td>").append(t.getData7().toString()).append("</td>").append("</tr>")
                        		   .append("<tr>").append("<td>Company Name</td>").append("<td>").append(t.getData6().toString()).append("</td>").append("</tr>")
                        		   .append("<tr>").append("<td>Address</td>").append("<td>").append(t.getData9().toString()).append("</td>").append("</tr>")
                        		   .append("<tr>").append("<td>City</td>") .append("<td>").append(t.getData15().toString()).append("</td>").append("</tr>")
                        		   .append("<tr>").append("<td>Mobile No</td>").append("<td>").append(t.getData12().toString()).append("</td>").append("</tr>")
                        		   .append("<tr>").append("<td>Website</td>").append("<td>").append(t.getData22()!=null?t.getData22().toString():"").append("</td>").append("</tr>")
                        		   .append("<tr>").append("<td>Domain Name</td>").append("<td>").append(t.getData23().toString()).append("</td>").append("</tr>")
                        		    //Country
                        		   .append("<tr>")
                        		   .append("<td>Country</td>")
                        		   .append("<td>").append("<select id='selCountry' onchange='getStateList()'>")
                        		   .append(encryptDecryptUtils.getOptions("selContry", modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId),"countryId", "lang" + langId),false,"", "Please Select"))
                        		   .append("</td>")
                        		   .append("</select>").append("</tr>")
									// State
                        		   .append("<tr>").append("<td>State</td>")
                        		   .append("<td>").append("<select id='selState'>")
                        		   .append(encryptDecryptUtils.getOptions("selState",modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(commonService.getCountryIdFromName("India")), "stateId", "lang" + langId),false,"", "Please Select"))
                        		   .append("</td>")
                        		   .append("</select>").append("</tr>")
                        		   .append("<tr>") .append("<td>Action</td>")
                        		   .append("<td colspan='2'>")
                        		   .append("<a href='javascript:void(0)' onclick=\"registerSupplierManageSSO('")
                        		   .append(t.getData1().toString()).append("','").append(t.getData2().toString())
                        		   .append("')\" >Register Supplier</a></td>").append("</tr>")
                        		   .append("</table>");
                        		   /*End*/
                        		   result = sb.toString();
                        	   }else if(t!=null && t.getData2().toString() !=null){
                                   StringBuilder sb = new StringBuilder();
                                  /* sb.append("<table width='100%' cellspacing='0' cellpadding='0' border='0'>")
                                   .append("<tr class=\"gradi\">").append("<th>Email Id</th>").append("<th>First Name</th>").append("<th>Company Name</th>")
                                   .append("<th>Address</th>").append("<th>City</th>").append("<th>Mobile No</th>").append("<th>Website</th>")
                                   .append("<th>Action</th>").append("</tr>")
                                   .append("<tr>").append("<td>").append(t.getEmailId()).append("</td>")
                                   .append("<td>").append(t.getFirstName()).append("</td>")
                                   .append("<td>").append(t.getCompanyName()).append("</td>")
                                   .append("<td>").append(t.getAddress()).append("</td>")
                                   .append("<td>").append(t.getCity()).append("</td>")
                                   .append("<td>").append(t.getMobileNo()).append("</td>")
                                   .append("<td>").append(t.getWebsite()).append("</td>")
                                   .append("<td><a href='javascript:void(0)' onclick=\"resetPassword('").append(t.getEmailId()).append("')\" >Reset Password</a>")
                                   .append("&nbsp;|&nbsp;<a href='javascript:void(0)' onclick=\"registerSupplier('").append(t.getSsoUserId()).append("','").append(t.getEmailId()).append("')\" >Register Supplier</a></td>")
                                   .append("</tr>")
                                   .append("</table>");*/
                                   
                                   sb.append("<table width='100%' cellspacing='0' cellpadding='0' border='0'>")
                                   .append("<tr>").append("<td>Email Id</td>").append("<td>").append(t.getData2().toString()).append("</td>").append("</tr>")
                                   .append("<tr>").append("<td>First Name</td>").append("<td>").append(t.getData7().toString()).append("</td>").append("</tr>")
                                   .append("<tr>").append("<td>Company Name</td>").append("<td>").append(t.getData6().toString()).append("</td>").append("</tr>")
                                   .append("<tr>").append("<td>Address</td>").append("<td>").append(t.getData9().toString()).append("</td>").append("</tr>")
                                   .append("<tr>").append("<td>City</td>") .append("<td>").append(t.getData15().toString()).append("</td>").append("</tr>")
                                   .append("<tr>").append("<td>Mobile No</td>").append("<td>").append(t.getData12().toString()).append("</td>").append("</tr>")
                                   .append("<tr>").append("<td>Website</td>").append("<td>").append(t.getData22()!=null?t.getData22().toString():"").append("</td>").append("</tr>")
                                   .append("<tr>").append("<td>Domain Name</td>").append("<td>").append(t.getData23().toString()).append("</td>").append("</tr>")
                                   .append("<tr>") .append("<td>Action</td>")
                                   .append("<td colspan='2'>")
                                   //.append("<a href='javascript:void(0)' onclick=\"resetPassword('").append(t.getData2().toString()).append("')\" >Reset Password</a>&nbsp;|&nbsp;")
                                   .append("<a href='javascript:void(0)' onclick=\"registerSupplier('")
                                   .append(t.getData1().toString()).append("','").append(t.getData2().toString())
                                   .append("')\" >Register Supplier</a></td>").append("</tr>")
                                   .append("</table>");
                                   /*End*/
                                   result = sb.toString();
                            }else{
                                result = "<span>User is not Registered in SSO</span>";
                            }
                        }else{
                            result = "<span>Service is not available!! there might be some problem!!</span>";
                        }
                    }else{
                        result = "<span>Service is not available!! there might be some problem!!!</span>";
                }
                }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return result;
    }
    @RequestMapping(value = "common/admin/searchssouser/{enc}", method = RequestMethod.GET)
    public String searchssouser(HttpServletRequest request) {
        try {
             
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally{
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createDeptUserLinkId,getDeptUserCreateRemark, 0,0,"");
        }
        return "/common/admin/SearchSSOUser";
    }
    @RequestMapping(value = "common/admin/managessouser/{enc}", method = RequestMethod.GET)
    public String managessouser(HttpServletRequest request) {
        try {
             
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally{
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createDeptUserLinkId,getDeptUserCreateRemark, 0,0,"");
        }
        return "/common/admin/ManageSSOUser";
    }
    /**
      * @author umang.rathod
      * @param request
      * @return 
      */
     @RequestMapping(value = "/ajaxcall/dumpUserSSO", method = RequestMethod.POST)
     @ResponseBody
     public String dumpUser(@RequestParam("txtemailId") String txtemailId,@RequestParam("hdCountryId") int country,@RequestParam("hdStateId") int state, HttpServletRequest request) {
         String result = null;
         try {
             boolean isSSOEnabled = false;
             HttpSession httpSession = request.getSession();
             if (httpSession.getAttribute("clientObject") != null) {
                 ClientBean clientBean = (ClientBean) httpSession.getAttribute("clientObject");
                 isSSOEnabled = clientBean.isIsSsoEnabled();
             }
             if(isSSOEnabled){
                 if(WSCheckAvail.isSsoAvailable()){
                     result = wSCheckAvailService.dumpSupplier(txtemailId,abcUtility.getSessionClientId(request),true,country,state);
                 }else{
                     result = "fail"; //"Unable to process Your Request";
                 }
             }else{
                 result = "fail"; //"in case of SSO Is not Required";
             }    
         } catch (Exception e) {
             exceptionHandlerService.writeLog(e);
         }
         return result;
     }
}
