package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblCrlMasterDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblCrlMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCrlMasterImpl extends AbcAbstractClass<TblCrlMaster> implements TblCrlMasterDao {

    @Override
    public void addTblCrlMaster(TblCrlMaster tblCrlMaster){
        super.addEntity(tblCrlMaster);
    }

    @Override
    public void deleteTblCrlMaster(TblCrlMaster tblCrlMaster) {
        super.deleteEntity(tblCrlMaster);
    }

    @Override
    public void updateTblCrlMaster(TblCrlMaster tblCrlMaster) {
        super.updateEntity(tblCrlMaster);
    }

    @Override
    public List<TblCrlMaster> getAllTblCrlMaster() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCrlMaster> findTblCrlMaster(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCrlMasterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCrlMaster> findByCountTblCrlMaster(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCrlMaster(List<TblCrlMaster> tblCrlMasters){
        super.updateAll(tblCrlMasters);
    }
}
