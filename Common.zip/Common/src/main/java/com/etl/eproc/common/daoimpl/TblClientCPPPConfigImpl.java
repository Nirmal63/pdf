package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblClientCPPPConfig;
import com.etl.eproc.common.daointerface.TblClientCPPPConfigDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientCPPPConfigImpl extends AbcAbstractClass<TblClientCPPPConfig> implements TblClientCPPPConfigDao {

    @Override
    public void addTblClientCPPPConfig(TblClientCPPPConfig tblClientCPPPConfig){
        super.addEntity(tblClientCPPPConfig);
    }

    @Override
    public void deleteTblClientCPPPConfig(TblClientCPPPConfig tblClientCPPPConfig) {
        super.deleteEntity(tblClientCPPPConfig);
    }

    @Override
    public void updateTblClientCPPPConfig(TblClientCPPPConfig tblClientCPPPConfig) {
        super.updateEntity(tblClientCPPPConfig);
    }

    @Override
    public List<TblClientCPPPConfig> getAllTblClientCPPPConfig() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientCPPPConfig> findTblClientCPPPConfig(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientCPPPConfigCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientCPPPConfig> findByCountTblClientCPPPConfig(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientCPPPConfig(List<TblClientCPPPConfig> tblClientCPPPConfigs){
        super.updateAll(tblClientCPPPConfigs);
    }

	@Override
	public void saveOrUpdateTblClientCPPPConfig(TblClientCPPPConfig tblClientCPPPConfig) {
		super.saveOrUpdateEntity(tblClientCPPPConfig);
		
	}
}
