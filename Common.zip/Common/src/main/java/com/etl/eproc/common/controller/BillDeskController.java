package com.etl.eproc.common.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblClientPGConf;
import com.etl.eproc.common.model.TblOnlinePayment;
import com.etl.eproc.common.model.TblPayment;
import com.etl.eproc.common.services.BillDeskService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.TpslService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.Security;

@Controller
@RequestMapping("/common")
public class BillDeskController {
	
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private TpslService tpslService;
	@Autowired
	private ClientService clientService;
	@Autowired
	private BillDeskService billDeskService;
	
	private static final int TAB_DOC_FEES = 3;
    private static final int TAB_EMD = 4;
    private static final int TAB_REG_PAYMENT = 14;
    
    @RequestMapping(value = "/successBillDeskPayment", method = RequestMethod.POST)
    public String successBillDeskPayment( HttpSession httpSession,HttpServletRequest request, RedirectAttributes rea) throws IOException {
    	String authCode = "";
    	boolean isPaymentDone = false;
    	boolean isPaymentPending = false;
    	int paymentId = 0;
    	String page = "";
    	try{
//    		if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
    			String msg = "";//"XNSTNELCTT|125|PCIT6937915000|707871-009467|2.00|CIT|462271|03|INR|DIRECT|NA|NA|00000000.00|27-11-2018 18:56:25|0300|NA|125|8|NA|NA|NA|NA|NA|NA|Success|B96668447C25D3A3C08AB2700ADDBF9957C08EB95E1BCDA2E41294A17A5FCE23";
    			if (StringUtils.hasLength(request.getParameter("msg"))) {
    				msg = request.getParameter("msg");
				} 
    			int deptId=Integer.valueOf(clientService.getClientField(abcUtility.getSessionClientId(request), "deptId").toString());
    			String strArr[] = msg.split("\\|");
    			int payFor = Integer.parseInt(strArr[17]);
    			TblClientPGConf tblClientPGConf = tpslService.getPGConfiguration(abcUtility.getSessionClientId(request),payFor,deptId);
    			String returnCheckSum = strArr[strArr.length-1];
    			String actualCheckSum = Security.HmacSHA256(msg.substring(0, msg.lastIndexOf("|")).toString(),tblClientPGConf.getCheckSumKey());
    			if(returnCheckSum.equals(actualCheckSum)){
    				paymentId = StringUtils.hasLength(strArr[1]) ? Integer.parseInt(strArr[1]) : 0;
    				authCode = strArr[14];
    				if("0300".equals(authCode)){
    					isPaymentDone = true;
    				}else if("0002".equals(authCode)){
    					isPaymentPending = true;
    				}
    				TblPayment tblPayment = tpslService.getTblPayment(paymentId);
    				if(tblPayment.getCstatus()==0){
	    				if(isPaymentDone){
	    					tblPayment.setCstatus(1);
	    				}else if(isPaymentPending){
	    					tblPayment.setCstatus(0);
	    				}else{
	    					tblPayment.setCstatus(2);
	    				}
	    				TblOnlinePayment tblOnlinePaymentNew = new TblOnlinePayment();
	    				TblOnlinePayment tblOnlinePayment = tpslService.getTblOnlinePayment(paymentId);
	    				if(tblOnlinePayment!=null){
	    					tblOnlinePayment.setMerchantId(strArr[0]);
							tblOnlinePayment.setResponseCode(authCode);
							tblOnlinePayment.setResponseMessage(msg);
							tblOnlinePayment.setTblPayment(tblPayment);
							tblOnlinePayment.setTpslReferenceId(strArr[2]);
							billDeskService.updateOnlinePaymentDetail(tblOnlinePayment);
	    				}else{
	    					tblOnlinePaymentNew.setMerchantId(strArr[0]);
	    					tblOnlinePaymentNew.setResponseCode(authCode);
	    					tblOnlinePaymentNew.setResponseMessage(msg);
	    					tblOnlinePaymentNew.setTblPayment(tblPayment);
	    					tblOnlinePaymentNew.setTpslReferenceId(strArr[2]);
	    					tpslService.addOnlinePaymentDetail(tblOnlinePaymentNew);
	    				}
//	    				TblPaymentRequestParam tblPaymentRequestParam = billDeskService.getTblPaymentRequest(paymentReqId);
//	    				if(tblPaymentRequestParam!=null){
//	    					tblPaymentRequestParam.setResponseParam(msg);
//	    					tblPaymentRequestParam.setRespDateTime(commonService.getServerDateTime());
//	    					billDeskService.updatePaymentRequestParam(tblPaymentRequestParam);
//	    				}
						
    				}
    			}
    			System.out.println("paymentReqId : "+1);
    			TblPayment tblPayment = tpslService.getTblPayment(paymentId);
    			int moduleId=tblPayment.getTblModule().getModuleId();
    			if(moduleId==3){
    				page = "etender/bidder/biddingtenderdashboard/"+tblPayment.getObjectId()+"/";
    				if (tblPayment.getPaymentFor() == 1) {
    					//linkId = lnkDocfeePayment;
    					page += TAB_DOC_FEES;
    				}else if (tblPayment.getPaymentFor() == 2) {
    					//linkId = lnkEmdPayment;
    					page += TAB_EMD;
    				}else{
    					//linkId = lnkTenderEventPaymentPG;
    					page += TAB_REG_PAYMENT;
    				}
    			}
    			System.out.println("Response Message : "+msg);
//    		}
    	}catch(Exception e){
    		e.printStackTrace();
    	}
    	return "redirect:/" + page
				+ encryptDecryptUtils.generateRedirect(page, request);
    	
    }
    
}

