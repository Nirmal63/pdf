package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblBidderApprovalDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblBidderApproval;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBidderApprovalImpl extends AbcAbstractClass<TblBidderApproval> implements TblBidderApprovalDao {

    @Override
    public void addTblBidderApproval(TblBidderApproval tblBidderApproval){
        super.addEntity(tblBidderApproval);
    }

    @Override
    public void deleteTblBidderApproval(TblBidderApproval tblBidderApproval) {
        super.deleteEntity(tblBidderApproval);
    }

    @Override
    public void updateTblBidderApproval(TblBidderApproval tblBidderApproval) {
        super.updateEntity(tblBidderApproval);
    }

    @Override
    public List<TblBidderApproval> getAllTblBidderApproval() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBidderApproval> findTblBidderApproval(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBidderApprovalCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBidderApproval> findByCountTblBidderApproval(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBidderApproval(List<TblBidderApproval> tblBidderApprovals){
        super.updateAll(tblBidderApprovals);
    }
}
