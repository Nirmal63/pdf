package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblNegotiationDetail;
import java.util.List;

public interface TblNegotiationDetailDao  {

    public void addTblNegotiationDetail(TblNegotiationDetail tblNegotiationDetail);

    public void deleteTblNegotiationDetail(TblNegotiationDetail tblNegotiationDetail);

    public void updateTblNegotiationDetail(TblNegotiationDetail tblNegotiationDetail);

    public List<TblNegotiationDetail> getAllTblNegotiationDetail();

    public List<TblNegotiationDetail> findTblNegotiationDetail(Object... values) throws Exception;

    public List<TblNegotiationDetail> findByCountTblNegotiationDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNegotiationDetailCount();

    public void saveUpdateAllTblNegotiationDetail(List<TblNegotiationDetail> tblNegotiationDetails);
}
