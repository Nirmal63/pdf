package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblClientCertBannerMappingDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblClientCertBannerMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientCertBannerMappingImpl extends AbcAbstractClass<TblClientCertBannerMapping> implements TblClientCertBannerMappingDao {

    @Override
    public void addTblClientCertBannerMapping(TblClientCertBannerMapping tblClientCertBannerMapping){
        super.addEntity(tblClientCertBannerMapping);
    }

    @Override
    public void deleteTblClientCertBannerMapping(TblClientCertBannerMapping tblClientCertBannerMapping) {
        super.deleteEntity(tblClientCertBannerMapping);
    }

    @Override
    public void updateTblClientCertBannerMapping(TblClientCertBannerMapping tblClientCertBannerMapping) {
        super.updateEntity(tblClientCertBannerMapping);
    }

    @Override
    public List<TblClientCertBannerMapping> getAllTblClientCertBannerMapping() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientCertBannerMapping> findTblClientCertBannerMapping(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientCertBannerMappingCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientCertBannerMapping> findByCountTblClientCertBannerMapping(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientCertBannerMapping(List<TblClientCertBannerMapping> tblClientCertBannerMappings){
        super.updateAll(tblClientCertBannerMappings);
    }
}
