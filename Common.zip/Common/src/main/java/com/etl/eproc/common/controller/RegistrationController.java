package com.etl.eproc.common.controller;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.ccavenue.security.AesCryptUtil;
import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.TblBidderGstDetailsDao;
import com.etl.eproc.common.daointerface.TblCompanyDao;
import com.etl.eproc.common.daointerface.TblUserLoginDao;
import com.etl.eproc.common.databean.BidderRegistrationDataBean;
import com.etl.eproc.common.databean.DrtRetiredOffRegDataBean;
import com.etl.eproc.common.model.TblAuditTrail;
import com.etl.eproc.common.model.TblBidderDocMapping;
import com.etl.eproc.common.model.TblBidderDocument;
import com.etl.eproc.common.model.TblBidderGstDetails;
import com.etl.eproc.common.model.TblBidderStatus;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientPGBankMapping;
import com.etl.eproc.common.model.TblClientPGConf;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblDownloadDocument;
import com.etl.eproc.common.model.TblHintQuestion;
import com.etl.eproc.common.model.TblIndustryClassification;
import com.etl.eproc.common.model.TblIndustryType;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblModule;
import com.etl.eproc.common.model.TblOfflinePayment;
import com.etl.eproc.common.model.TblOnlinePayment;
import com.etl.eproc.common.model.TblOnlinePaymentTransHistory;
import com.etl.eproc.common.model.TblPasswordHistory;
import com.etl.eproc.common.model.TblPayment;
import com.etl.eproc.common.model.TblPaymentGatewayMaster;
import com.etl.eproc.common.model.TblPaymentType;
import com.etl.eproc.common.model.TblRegisteredIn;
import com.etl.eproc.common.model.TblRegistrationWorkflow;
import com.etl.eproc.common.model.TblSession;
import com.etl.eproc.common.model.TblTimeZone;
import com.etl.eproc.common.model.TblTrackLogin;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserHistory;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.AxisService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DrtService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.ISGPaymentService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.MailBoxService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.ManageContentService;
import com.etl.eproc.common.services.SbiService;
import com.etl.eproc.common.services.TblUserotpservice;
import com.etl.eproc.common.services.TpslService;
import com.etl.eproc.common.services.WSCheckAvailService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.FileEncryptDecryptUtil;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SHA1HashEncryption;
import com.etl.eproc.common.utility.SHA256HashEncryption;
import com.etl.eproc.common.utility.SMSContentUtillity;
import com.etl.eproc.common.utility.Security;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.factory.AbcCaptchaFactory;
import com.etl.eproc.vendor.model.TblBidderIndustry;
import com.etl.eproc.vendor.model.TblBidderRegisteredIn;
import com.etl.eproc.vendor.services.VendorEnlistmentService;

/**
 * 
 * @author japan
 * 
 */
@Controller
public class RegistrationController {

	@Autowired
	private DrtService drtService;
	@Autowired
	private ManageBidderService manageBidderService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
	@Autowired
	private ModelToSelectItem modelToSelectItem;
	@Autowired
	private CommonValidators commonValidators;
	@Autowired
	private ClientService clientService;
	@Autowired
	private AuditTrailService auditTrailService;
	@Autowired
	private MailContentUtillity mailContentUtillity;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private FileEncryptDecryptUtil fileEncryptDecryptUtil;
	@Autowired
	private WSCheckAvailService wSCheckAvailService;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private ConversionService conversionService;
	@Autowired
	private TpslService tpslService;
	@Autowired
	private SbiService sbiService;
	@Autowired
	private ISGPaymentService isgPaymentService;
	@Autowired
	private FileUploadService fileUploadService;
	@Autowired
	DynamicFieldService dynamicFieldService;
	@Autowired
	ManageContentService manageContentService;
	@Autowired
	AxisService axisService;
	@Value("#{paymentConfigProperties['axis_pg_type']}")
	private String axisPgType;
	@Autowired
	private LoginService loginService;
	@Autowired
	private TblBidderGstDetailsDao tblBidderGstDetailsDao;
	@Autowired
    private TblUserotpservice tbluserotpservice;
    @Autowired
    private SMSContentUtillity smsContentUtillity;
	

	@Value("#{projectProperties['captcha_publickey']}")
	private String publicKey;
	@Value("#{projectProperties['captcha_privatekey']}")
	private String privateKey;
	@Value("#{projectProperties['bidder.status.incomplete']?:5}")
	private int cstatusIncomplete;
	@Value("#{projectProperties['bidder.status.pending']?:0}")
	private int cstatusPending;
	@Value("#{projectProperties['bidder.status.approved']?:1}")
	private int cstatusApproved;
	@Value("#{projectProperties['bidder.status.approveincomplete']?:6}")
	private int cstatusApproveIncomplete;
	@Value("#{projectProperties['userhistory.actiontype.create']?:1}")
	private int userHistoryCreate;

	@Value("#{projectProperties['file.drive']}")
	private String tmpdrive;
	@Value("#{projectProperties['doc_upload_path']}")
	private String tmpPath;

	@Value("#{linkProperties['manage_bidder_register_bidder']?:24}")
	private int registrationLinkId;
	@Value("#{linkProperties['event_bidderRegcharges']?:135}")
	private int eventBidderRegcharges;
	

	@Value("#{linkProperties['bidder_registration_charges_offline_payment_upload']?:684}")
	private int offlinePaymentLinkId;
	@Value("#{linkProperties['manage_bidder_field_value']?:161}")
	private int manageBidderFieldValueId;

	@Value("#{adminAuditTrailProperties['getBidderRegistration']}")
	private String auditBidderRegistration;
	@Value("#{adminAuditTrailProperties['postBidderRegistered']}")
	private String auditBidderRegistered;
	@Value("#{adminAuditTrailProperties['getRegistrationFinalStep']}")
	private String auditRegFinalStep;
	@Value("#{adminAuditTrailProperties['getUploadRegDoc']}")
	private String auditUploadRegDoc;
	@Value("#{adminAuditTrailProperties['postUploadRegDoc']}")
	private String auditRegDocUploaded;
	@Value("#{adminAuditTrailProperties['postDownloadRegDoc']}")
	private String auditDownloadRegDoc;
	@Value("#{adminAuditTrailProperties['postRemoveRegDoc']}")
	private String auditRemoveRegDoc;
	@Value("#{adminAuditTrailProperties['postRetiredDRTOfficerRegistered']}")
	private String auditDRTRetOffReg;
	@Value("#{tenderlinkProperties['bidder_docfees_payment_through_tpsl']?:414}")
	private int lnkDocfeePaymentTpsl;
	@Value("#{tenderlinkProperties['bidder_emd_payment_through_tpsl']?:417}")
	private int lnkEmdPaymentTpsl;
	@Value("#{etenderAuditTrailProperties['postTpslPayment']}")
	private String postTpslPayment;
	@Value("#{linkProperties['bidder_registration_charges_online_payment_pg']?:932}")
	private int lnkRegiChargesThroughPG;
	@Value("#{projectProperties['rci_client_ids']}")
    private String rciClientIds;
	@Value("#{projectProperties['gsl_client']}")
    private String gslClientIds;
	@Value("#{linkProperties['hide_registration_link']?:3355}")
    private int hideRegistrationLinkId;
	@Value("#{adminAuditTrailProperties['postRemoveRegDocFromOfficer']}")
	private String auditRemoveRegDocFromOfficer;
	@Value("#{adminAuditTrailProperties['postUploadRegDocFromOfficer']}")
	private String auditRegDocUploadedFromOfficer;
	@Value("#{linkProperties['link_officer_upload_bidder_doc']?:4399}")
	private int lnkOfficerUploadBidderDoc;
	@Value("#{projectProperties['block_user_mail_to']}")
	 private String block_user_mail_Id;
	@Value("#{projectProperties['phone_no']}")
	private String contact_phoneno;
	@Value("#{projectProperties['email']}")
	private String contact_emailId;
	@Value("#{paymentConfigProperties['bankIdCode']}")
	private String bankIdCode;
	@Value("#{projectProperties['doc_upload_path']}")
	private String docUploadPath;
	@Value("#{projectProperties['default_contry_id']}")
    private int countryId;
	@Value("#{linkProperties['event_gst_doc']?:298}")
	private int eventGstDoc;
	@Value("#{linkProperties['link_gst_doc_config']?:4509}")
	private int linkGstDocConfig;
	@Value("#{adminAuditTrailProperties['submiGstDetails']}")
	private String auditSubmitGstDetails;
	@Value("#{adminAuditTrailProperties['downloadGstReceipt']}")
	private String auditDownloadGstReceipt;
	@Value("#{adminAuditTrailProperties['removeGstReceipt']}")
	private String auditRemoveGstReceipt;
	@Value("#{adminAuditTrailProperties['gstDetailsPage']}")
	private String auditGstDetailsPage;
	private final static String XFORWARDEDFOR = "X-FORWARDED-FOR";
	@Autowired
    private TblUserLoginDao tblUserLoginDao;
	@Autowired
    private SHA256HashEncryption sha256HashEncryption;
	@Autowired
    private SHA1HashEncryption sha1HashEncryption;
	@Autowired
    private TblCompanyDao tblCompanyDao;
	@Value("#{projectProperties['password.validity']?:30}")
    private int passValidity;
	
	/*
	 * private static final int FILESIGNATURE_ZIP[] = new int[]{0x50, 0x4B, 0x03,
	 * 0x04}; private static final int FILESIGNATURE_PDF[] = new int[]{0x25, 0x50,
	 * 0x44, 0x46}; private static final int FILESIGNATURE_RAR[] = new int[]{0x52,
	 * 0x61, 0x72, 0x21, 0x1A, 0x07, 0x00};
	 */

	private static final String REGISTRATION_SUCCESS_0 = "redirect_success_bidder_registration_0";
	
	@Value("#{adminAuditTrailProperties['getBidderRegistrationVerificationpage']}")
	private String auditGetBidderRegistrationVerificationpage;
	@Value("#{adminAuditTrailProperties['postBidderRegistrationVerificationpage']}")
	private String auditPostBidderRegistrationVerificationpage;
	@Value("#{adminAuditTrailProperties['RegistrationVerificationResendOTP']}")
	private String auditRegistrationVerificationResendOTP;
	@Value("#{smsProperties['msg_one_time_reg_otp']}")
	private String msgRegOTP;
	@Autowired
    private MailBoxService mailBoxService;
	private static final String TEMPSESSIONOBJECT = "tempSessionObject";
	private static final String SESSIONOBJECT = "sessionObject";
    @Autowired
    private VendorEnlistmentService vendorEnlistmentService;

	/**
	 * Displays the bidder registration page to the user.
	 * 
	 * @param bidderRegistrationDataBean
	 * @param modelMap
	 * @return
	 */

	@RequestMapping(value = "/bidderregistration", method = RequestMethod.GET)
	public String bidderRegistration(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean,
			HttpServletRequest request, ModelMap modelMap, RedirectAttributes redirectAttributes) {
		String pageName = "";
		try {
			int clientId = abcUtility.getSessionClientId(request);
			int counter = 0;
			Cookie[] cookies = request.getCookies();
			if (cookies != null) {
				for (Cookie cookie : cookies) {
					if ("locale".equals(cookie.getName())) {
						counter++;
					}
				}
			}
			if (counter == 0) {
				pageName = "redirect:/setcookie";
				redirectAttributes.addFlashAttribute("isForBidderRegistration", true);// If cookie is not found, then
																						// redirect to home
																						// url from this JSP
			} else {
				List<Object[]> clientDetails = commonService.getClientCountryStateTimezone(clientId);
				if (clientDetails != null && !clientDetails.isEmpty()) {
					bidderRegistrationDataBean.setSelTimezone(Integer.parseInt(clientDetails.get(0)[0].toString()));
					bidderRegistrationDataBean.setSelCountry(Integer.parseInt(clientDetails.get(0)[1].toString()));
					bidderRegistrationDataBean.setSelState(clientDetails.get(0)[2].toString());
				}
				String langId = WebUtils.getCookie(request, "locale").getValue();
				modelMap.put("timezoneList", modelToSelectItem
						.convertListIntoSelectItemList(commonService.getTimeZoneList(), "timeZoneId", "lang" + langId));
				modelMap.put("hintQueList", modelToSelectItem.convertListIntoSelectItemList(
						commonService.getHintQuestionList(), "hintQuestionId", "lang" + langId));
				modelMap.put("countryList", modelToSelectItem.convertListIntoSelectItemList(
						commonService.getCountryList(langId), "countryId", "lang" + langId));
				modelMap.put("stateList",
						modelToSelectItem.convertListIntoSelectItemList(
								commonService.getStateBycountryId(bidderRegistrationDataBean.getSelCountry()),
								"stateId", "lang" + WebUtils.getCookie(request, "locale").getValue()));

				if (CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)) {
					modelMap.addAttribute("chkRegisteredIn", manageBidderService.getRegisteredIn());
					modelMap.addAttribute("chkIndustryType", modelToSelectItem.convertListIntoSelectItemList(
							manageBidderService.getIndustryType(), "indTypeId", "indType"));
					modelMap.addAttribute("chkIndClassification",
							modelToSelectItem.convertListIntoSelectItemList(
									manageBidderService.getIndustryClassification(), "indClassificationId",
									"indClassification"));
				}
// @author : Jaynam 26/04/2014 11:00 am
//	 		 abcCaptcha Implemtation Start   				
				modelMap.put("captchaHtml", AbcCaptchaFactory.newAbcCaptcha(0));
// End				
				modelMap.put("lstClientMarquee", clientService.getClientMarqueeBylocation(
						(int) abcUtility.getSessionClientId(request), 3));/* For After Loging Marque */
				// PT: 20745
				if (abcUtility.isModuleAssignToClient(request, 9)) { // spend analysis module.
					modelMap.put("isCategoryAllow",
							commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
				} else {
					modelMap.put("isCategoryAllow", 0);
				}
				modelMap.put("isRegisterByAuthorizedUser", false);
				List<Object[]> contentManagement = manageContentService.getClientRegTerms(
						abcUtility.getSessionClientId(request), 8,
						Integer.parseInt(WebUtils.getCookie(request, "locale").getValue()));
				modelMap.put("contentManagementId",
						contentManagement != null && !contentManagement.isEmpty() ? contentManagement.get(0)[1] : 0);
				modelMap.addAttribute("clientId", clientId);
				modelMap.addAttribute("objectId", 0);
				modelMap.addAttribute("linkId", manageBidderFieldValueId);
				modelMap.addAttribute("dynFieldMap",
						dynamicFieldService.setDynamicField(manageBidderFieldValueId, clientId, 0));
				modelMap.addAttribute("isClientSectorApplicable",
						manageBidderService.isClientSectorApplicable(clientId));

				List<SelectItem> isCompanyName = new ArrayList<SelectItem>();
				isCompanyName.add(new SelectItem("Company Name", 1));
				isCompanyName.add(new SelectItem("Individual Name", 0));
				modelMap.addAttribute("isCompanyName", isCompanyName);
				modelMap.addAttribute("isSelCompanyName", 1);

				// PT : #38537. Hide Registration Link status
				boolean isRegistrationLinkHidden = clientService.isRegistrationLinkHidden(clientId,
						hideRegistrationLinkId, 1);
				if (isRegistrationLinkHidden) {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
							"redirect_registration_not_allow");
					pageName = "redirect:/";
				} else {
					pageName = "BidderRegistration";
				}
			}
			int ShowAccessDetail = abcUtility.getAccessDetail(request);
			if (ShowAccessDetail == 1) {
				int visitorCount = commonService.getVisitorDetail(request);
				modelMap.addAttribute("visitorCount", visitorCount);
			}
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					registrationLinkId, auditBidderRegistration, 0, 0);
		}
		return pageName;
	}
	
	
	@RequestMapping(value = "/addbidderregistration", method = RequestMethod.POST)
	public String addBidderRegistration(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean,
			BindingResult result, HttpServletRequest request, RedirectAttributes redirectAttributes,
			ModelMap modelMap) {
		boolean success = false;
		String retVal = "";
		int userId = 0;
		int clientId = abcUtility.getSessionClientId(request);
		int contentManagementId = 0;
		String selectedCategory[] = null;
		String isCategoryAllow = "0";
		List<Object> busCatKeywords = null;
	
		ClientBean clientBean = (ClientBean) (request.getSession()
				.getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null
						? request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString())
						: null);
		try {
			// PT : #38537 by Jitendra. Don't allow bidder registration if register link
			// hidden starts.
			boolean isRegistrationLinkHidden = clientService.isRegistrationLinkHidden(clientId, hideRegistrationLinkId,
					1);
			boolean isUserNotValid = clientService.isUserNotBlock(bidderRegistrationDataBean.getTxtEmailId(),
					bidderRegistrationDataBean.getTxtMobileNo(), 1);
			if (!isRegistrationLinkHidden && !isUserNotValid) {
				bidderRegistrationDataBean.setCommonValidators(commonValidators);

				List<LinkedHashMap<String, Object>> list = commonService.checkValidUserInClient(clientId,
						bidderRegistrationDataBean.getTxtEmailId(), 2);
				selectedCategory = request.getParameterValues("txtCategory");
				isCategoryAllow = request.getParameter("hdIsCategoryAllow");
				int bidderId = 0;
				int officerId = 0;
				int actionType = 0;
				if (list != null && !list.isEmpty()) {
					Map<String, Object> map  = list.get(0);
					if (map.get("actionType") != null) {
						actionType = Integer.parseInt(map.get("actionType").toString());
						bidderId = Integer.parseInt(map.get("bidderId").toString());
						officerId = Integer.parseInt(map.get("officerId").toString());
					}
				}

				// Bug #33494 By Jitendra. If category is allow then getting keyword names from
				// keyword ids and set in bidderRegistrationDataBean model.
				if (isCategoryAllow != null && isCategoryAllow.equals("1") && selectedCategory != null) {
					busCatKeywords = commonService.getKeywordNamesByIds(selectedCategory);
					bidderRegistrationDataBean
							.setTxtaBusCatKeywords(abcUtility.converObjectArrayToCommas(busCatKeywords));
				}

				boolean isCheckPassword = true;
				boolean isCheckEmail = true;
				boolean isCheckHintQnA = true;
				if (actionType == 4 && officerId > 0) {
					isCheckHintQnA = false;
					isCheckPassword = false;
					isCheckHintQnA = false;
				} else if (clientBean.getIsDIYClient() == 1)// Skip QnA validation in DIY client
				{
					isCheckHintQnA = false;
				}

				bidderRegistrationDataBean.validate(result, isCheckEmail, isCheckPassword, isCheckHintQnA, actionType);

				if (actionType == 2 && bidderId > 0) {
					result.rejectValue("txtEmailId", "msg_js_registration_bidderexists",
							"Email id already registered as bidder on this domain");
				} else if (actionType == 2 && officerId > 0) {
					result.rejectValue("txtEmailId", "msg_js_registration_officerexists",
							"Email id already registered as department user on this domain");
				}

				String successMsgCode = "";
				String langId = WebUtils.getCookie(request, "locale").getValue();
				if (result.hasErrors()) {
					modelMap.put("timezoneList", modelToSelectItem.convertListIntoSelectItemList(
							commonService.getTimeZoneList(), "timeZoneId", "lang" + langId));
					modelMap.put("hintQueList", modelToSelectItem.convertListIntoSelectItemList(
							commonService.getHintQuestionList(), "hintQuestionId", "lang" + langId));
					modelMap.put("countryList", modelToSelectItem.convertListIntoSelectItemList(
							commonService.getCountryList(langId), "countryId", "lang" + langId));
					if (bidderRegistrationDataBean.getSelCountry() != 0) {
						modelMap.put("stateList",
								modelToSelectItem.convertListIntoSelectItemList(
										commonService.getStateBycountryId(bidderRegistrationDataBean.getSelCountry()),
										"stateId", "lang" + WebUtils.getCookie(request, "locale").getValue()));
					}
					// @author : Jaynam 26/04/2014 11:00 am
					// abcCaptcha Implemtation Start
					modelMap.put("captchaHtml", AbcCaptchaFactory.newAbcCaptcha(0));
					// End
					modelMap.put("isRegisterByAuthorizedUser", false);

					// PT: 20745
					if (abcUtility.isModuleAssignToClient(request, 9)) { // Module assign Spend Analysis
						modelMap.put("isCategoryAllow",
								commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
					} else {
						modelMap.put("isCategoryAllow", 0);
					}
					success = false;
					retVal = "BidderRegistration";
				} else if (actionType == 3) {
					success = true;
					successMsgCode = "msg_js_registration_bidderprofileexists";
					retVal = "redirect:/";
				} else if (actionType != 3 && actionType != 2) {
					int bidderVerificationBy = clientService.getBidderRegistrationVerifiedBy(clientId);
					String verificationCode = "";
					if (bidderVerificationBy != 0 && bidderVerificationBy != 3) {
						verificationCode = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
					} else {
						verificationCode = "0";
					}
					TblUserLogin tblUserLogin = null;
					int registrationWorkflowId = 0;
					if (actionType == 4) {
						List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(officerId);
						if (tblUserLogins != null && !tblUserLogins.isEmpty()) {
							tblUserLogin = tblUserLogins.get(0);
						}
						registrationWorkflowId = manageBidderService.getClientRegWorkflowId(clientId,
								tblUserLogin.getIsEmailVerified() == 1 ? 3 : 0);
					} else {
						tblUserLogin = bidderRegistrationDataBean._toTblUserLogin(bidderVerificationBy,
								verificationCode, 0, 0);
						tblUserLogin.setTblClient(new TblClient(clientId));
						registrationWorkflowId = manageBidderService.getClientRegWorkflowId(clientId, 0);
					}

					int cstatus = cstatusIncomplete;
					int bidderCountry = Integer.parseInt(request.getParameter("selCountry"));
					if (registrationWorkflowId == 7 && bidderCountry != countryId) {
						registrationWorkflowId = 9;
					}
					if (registrationWorkflowId == 9) {
						cstatus = cstatusPending;
					}
					int isAutoApprove = Integer.parseInt(
							commonService.getField("TblClient", "isTwoStepBidderApproval", "clientId", clientId));
					if (isAutoApprove == 2) {
						registrationWorkflowId = 9;
						cstatus = 1;
					}
					// For CR #25825 - Keval Soni
					if (rciClientIds != null && !"".equals(rciClientIds)) {
						String[] rciIds = rciClientIds.split(",");
						if (rciIds.length != 0) {
							for (int i = 0; i < rciIds.length; i++) {
								if (!"".equals(rciIds[i])) {
									if (clientId == Integer.parseInt(rciIds[i])) {
										if (actionType == 1) {
											int clientCountryId = clientService.getCountryIdByClientId(clientId);
											int bidderCountryId = Integer.parseInt(request.getParameter("selCountry"));
											if (clientCountryId != bidderCountryId && registrationWorkflowId == 5) {
												registrationWorkflowId = 8;
												break;
											}
										}
									}
								}
							}
						}
					}

					contentManagementId = StringUtils.hasLength(request.getParameter("hdContentManagementId"))
							? Integer.parseInt(request.getParameter("hdContentManagementId").toString())
							: 0;
					TblBidderStatus tblBidderStatus = bidderRegistrationDataBean._toTblBidderStatus(clientId, cstatus,
							null, contentManagementId);
					tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(registrationWorkflowId));

					if (tblUserLogin.getPasswordUpdatedOn() == null) {
						tblUserLogin.setPasswordUpdatedOn(commonService.getServerDateTime());
					}
					
					
					TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();// Bug:18917
					tblPasswordHistory.setCreatedOn(commonService.getServerDateTime());
					tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
					tblPasswordHistory.setPasswordUpdatedFrom(4);
					TblUserLogin tblUserLog = bidderRegistrationDataBean._toTblUserLogin(clientId, verificationCode, isAutoApprove, isAutoApprove);
					tblUserLog.setMobileNo("");
					tblUserLog.setUserName("");
			        List<Object[]> clientCountryStateTimezone = commonService.getClientCountryStateTimezone(clientId);
			        tblUserLogin.setTblTimeZone(new TblTimeZone((Integer.valueOf(clientCountryStateTimezone.get(0)[0].toString()))));
					success = manageBidderService.addBidderRegistration(tblUserLogin,
							bidderRegistrationDataBean._toTblUserDetail(0),
							bidderRegistrationDataBean._toTblCompany(clientId), tblBidderStatus,
							bidderRegistrationDataBean._toTblUserHistory(userHistoryCreate, clientId),
							tblPasswordHistory, actionType);
					userId = tblUserLogin.getUserId();
					if (success) {
						// PT: 20745
						if (abcUtility.isModuleAssignToClient(request, 9) && isCategoryAllow != null
								&& isCategoryAllow.equals("1")) {// Module assign Spend Analysis
							commonService.insertUpdateCategory("edit", userId, selectedCategory, registrationLinkId);
						}
						success = dynamicFieldService.addDynamicFieldValueProcess(
								dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request), clientId,
								manageBidderFieldValueId, userId, userId);
					}
					if (success && CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)) {// CR:29488
																											// GSL
																											// Bidder
																											// Registration
																											// only
						String chkRegisteredIn[] = request.getParameterValues("hchkRegisteredIn");
						List<Integer> bidderDocIdList = new ArrayList<Integer>();
						if (chkRegisteredIn != null && chkRegisteredIn.length > 0) {
							List<TblBidderRegisteredIn> tblBidderRegisteredInList = new ArrayList<TblBidderRegisteredIn>();
							for (String registeredInId : chkRegisteredIn) {
								TblBidderRegisteredIn tblBidderRegisteredIn = new TblBidderRegisteredIn();
								tblBidderRegisteredIn
										.setTblRegisteredIn(new TblRegisteredIn(Integer.parseInt(registeredInId)));
								tblBidderRegisteredIn.setRegisteredNo(
										request.getParameter("txtRegisteredNo_" + registeredInId).toString());
								tblBidderRegisteredIn.setTblUserLogin(new TblUserLogin(userId));
								tblBidderRegisteredIn.setTblClient(new TblClient(clientId));
								tblBidderRegisteredInList.add(tblBidderRegisteredIn);
								bidderDocIdList.add(Integer.parseInt(encryptDecryptUtils
										.decrypt(
												request.getParameter("uploadedBidderFile_" + registeredInId).toString())
										.toString()));
							}
							if (tblBidderRegisteredInList != null && !tblBidderRegisteredInList.isEmpty()) {
								manageBidderService.addBidderRegistreredIn(tblBidderRegisteredInList);
							}
						}
						String industryType = request.getParameterValues("selIndustryType")[0];
						int industryTypeId = StringUtils.hasLength(industryType) && !"".equals(industryType)
								? Integer.parseInt(industryType)
								: 0;
						String industryClassification = request.getParameterValues("selIndClassification")[0];
						int industryClassificationId = StringUtils.hasLength(industryClassification)
								&& !"".equals(industryClassification) ? Integer.parseInt(industryClassification) : 0;
						String registeredInNo = request.getParameter("registreredInCapAndNo").toString();
						registeredInNo = StringUtils.hasLength(registeredInNo) && !"".equals(registeredInNo)
								? registeredInNo
								: "";
						if (industryTypeId != 0 && industryClassificationId != 0) {
							TblBidderIndustry tblBidderIndustry = new TblBidderIndustry();
							tblBidderIndustry.setTblIndustryType(new TblIndustryType(industryTypeId));
							tblBidderIndustry.setTblIndustryClassification(
									new TblIndustryClassification(industryClassificationId));
							tblBidderIndustry.setTblUserLogin(new TblUserLogin(userId));
							tblBidderIndustry.setTblClient(new TblClient(clientId));
							tblBidderIndustry.setRegisteredIn(registeredInNo);
							tblBidderIndustry.setUpdatedOn(commonService.getServerDateTime());
							manageBidderService.addBidderIndustry(tblBidderIndustry);

							bidderDocIdList.add(Integer.parseInt(encryptDecryptUtils
									.decrypt(request.getParameter("uploadedBidderFile_0").toString()).toString()));
							fileUploadService.updateRegistedInBidderDocPath(bidderDocIdList, clientId, userId,
									request.getSession().getId().toString(), false);
						}
					}
					if (success) {
						boolean isRegister = wSCheckAvailService.registerSSA(bidderRegistrationDataBean, null,
								tblUserLogin.getUserId(), 2, clientId, true);
						if (isRegister) {
							loginService.updateLoginSSOStatus(userId);// Is bidder register in SSO,change SSO-status 0
																		// to 1 in TblUserLogin
						}
						if (clientBean.getIsDIYClient() != 1) {
							Map<String, Object> mailParams = new HashMap<String, Object>();
							mailParams.put("UsersRegisteredEmailId", tblUserLogin.getLoginId());
							mailParams.put("Url", clientService.getClientNameById(clientId));
							Map<String, Object> gslMailParams = new HashMap<String, Object>();
							boolean isGslClient = CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)
									&& registrationWorkflowId == 9; // for GSL client, sent mail to bidder for complete
																	// registration process as step-1
							if (isGslClient) {
								gslMailParams.put("ClientName", clientService.getClientName(clientId));
								gslMailParams.put("SubDomainName", clientService.getClientNameById(clientId));
								gslMailParams.put("to", tblUserLogin.getLoginId());
								gslMailParams.put("RegisteredEmailID", tblUserLogin.getLoginId());
							}
							switch (bidderVerificationBy) {
							case 3: // bidderVerificationBy Mobile Number
								if (isGslClient) {
									mailContentUtillity.dynamicMailGeneration("239", String.valueOf(userId),
											String.valueOf(clientId), gslMailParams, "");
								} else {
									mailContentUtillity.dynamicMailGeneration("5", String.valueOf(userId),
											String.valueOf(clientId), mailParams, "");
								}

								break;

							case 2:
								if (tblUserLogin.getIsEmailVerified() == 0) {
									mailContentUtillity.dynamicMailGeneration("4", String.valueOf(userId),
											String.valueOf(clientId), null, "");
									// TODO :: Mobile verification code by SMS.
									successMsgCode = "redirect_success_bidder_registration_2";
								} else {
									if (isGslClient)
										mailContentUtillity.dynamicMailGeneration("239", String.valueOf(userId),
												String.valueOf(clientId), gslMailParams, "");
									else
										mailContentUtillity.dynamicMailGeneration("5", String.valueOf(userId),
												String.valueOf(clientId), mailParams, "");
									successMsgCode = REGISTRATION_SUCCESS_0;
								}
								break;

							case 1:
								if (tblUserLogin.getIsEmailVerified() == 0) {
									Map<String, Object> mailParamsEmail = new HashMap<String, Object>();
									mailParamsEmail.put("subdomainname", clientService.getClientNameById(clientId));
									mailParamsEmail.put("to", bidderRegistrationDataBean.getTxtEmailId());
									mailParamsEmail.put("loginId",
											encryptDecryptUtils
													.encrypt(bidderRegistrationDataBean.getTxtEmailId() + "@@" + 2 + "_"
															+ 0)
													+ "/"
													+ encryptDecryptUtils.encrypt(tblUserLogin.getVerificationCode()));
									mailContentUtillity.dynamicMailGeneration("1", String.valueOf(userId),
											String.valueOf(clientId), mailParamsEmail, "");
									successMsgCode = "redirect_success_bidder_registration_1";
								} else {
									if (isGslClient)
										mailContentUtillity.dynamicMailGeneration("239", String.valueOf(userId),
												String.valueOf(clientId), gslMailParams, "");
									else
										mailContentUtillity.dynamicMailGeneration("5", String.valueOf(userId),
												String.valueOf(clientId), mailParams, "");
									successMsgCode = REGISTRATION_SUCCESS_0;
								}
								break;

							case 0:
								if (isGslClient)
									mailContentUtillity.dynamicMailGeneration("239", String.valueOf(userId),
											String.valueOf(clientId), gslMailParams, "");
								else
									mailContentUtillity.dynamicMailGeneration("5", String.valueOf(userId),
											String.valueOf(clientId), mailParams, "");
								successMsgCode = registrationWorkflowId != 9 ? REGISTRATION_SUCCESS_0
										: "msg_registration_completed_successfully";
								break;

							default:
								break;
							}
							mailParams.put("ClientName", clientService.getClientName(clientId));
							mailParams.put("CompanyName", bidderRegistrationDataBean.getTxtCompanyName());
							mailParams.put("UserName", bidderRegistrationDataBean.getTxtFullName());
							mailParams.put("Mobile", bidderRegistrationDataBean.getTxtMobileNo());
							mailParams.put("Keywors", bidderRegistrationDataBean.getTxtaBusCatKeywords());
							mailContentUtillity.dynamicMailGeneration("236", String.valueOf(userId),
									String.valueOf(clientId), mailParams, "");
						}

					}
					if (success && bidderVerificationBy == 3 && tblUserLogin.getIsMobileNoVerified() == 0) {
						// Mobile Number verification
						successMsgCode = "redirect_msg_otp_sent_registered_mobileno";
						retVal = "redirect:/registrationOTPGenerate/0/"
								+ encryptDecryptUtils.encrypt(String.valueOf(tblUserLogin.getUserId()));
					} else {
						retVal = "redirect:/";
					}

				}

				redirectAttributes.addFlashAttribute(
						success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),
						success ? successMsgCode : CommonKeywords.ERROR_MSG_KEY.toString());
			} else {
				if (isUserNotValid) {
					String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR)
							: request.getRemoteAddr();
					Map<String, Object> mailParamsEmail = new HashMap<String, Object>();
					mailParamsEmail.put("ClientName", clientService.getClientNameById(clientId));
					mailParamsEmail.put("to", block_user_mail_Id);
					mailParamsEmail.put("emailId", bidderRegistrationDataBean.getTxtEmailId());
					mailParamsEmail.put("mobileNo", bidderRegistrationDataBean.getTxtMobileNo());
					mailParamsEmail.put("ipAddress", ipAddress);
					mailContentUtillity.dynamicMailGeneration("360", String.valueOf(userId), String.valueOf(clientId),
							mailParamsEmail, "");
					redirectAttributes.addFlashAttribute("phoneno", contact_phoneno);
					redirectAttributes.addFlashAttribute("emailId", contact_emailId);
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
							"redirect_registration_not_allow_contact");
					retVal = "redirect:/";
				} else {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
							"redirect_registration_not_allow");
					retVal = "redirect:/";
				}

			}
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					registrationLinkId, auditBidderRegistered, 0, userId);
		}
		return retVal;
	}
	
	
	
	/**
	 * Validates the form submitted by the user. If the data is valid then the
	 * information will be stored in the database otherwise the registration page
	 * will be shown with validation errors.
	 * 
	 * @param bidderRegistrationDataBean
	 * @param result
	 * @param session
	 * @param request
	 * @param redirectAttributes
	 * @param modelMap
	 * @return
	 */
	

	/** Project Task #58241 Start Here */
	@RequestMapping(value = { "/registrationOTPGenerate/{flag}/{userId}" }, method = RequestMethod.GET)
	public String bidderRegistrationOTPGenerat(@PathVariable("flag") int flag, @PathVariable("userId") String userId,
			HttpServletRequest request, ModelMap modelMap, HttpServletResponse response) {
		TblUserLogin tblUserLogin = null;
		String pageName = "";
		int userIds = 0;
		try {
			userIds = Integer.parseInt(encryptDecryptUtils.decrypt(userId));
			List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(userIds);
			if (tblUserLogins != null && !tblUserLogins.isEmpty()) {
				tblUserLogin = tblUserLogins.get(0);
			}

			modelMap.addAttribute("emailId", tblUserLogin.getLoginId());
			modelMap.addAttribute("userId", tblUserLogin.getUserId());
			modelMap.addAttribute("flag", flag);

			if (flag == 0) {
				int otp = commonService.genrateOtp(4);
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("otp", otp);
				boolean isIndian = commonService.getCountryIdByCompanyId(
						Integer.parseInt(String.valueOf(commonService.getCompanyIdByUserId(userIds)))) == countryId;
				smsContentUtillity.dynamicSMSGeneration(registrationLinkId, tblUserLogin.getMobileNo(), msgRegOTP,
						commonService.getSMSSenderIdFromLogo(request), paramMap, isIndian); // 1. parameter link Id 2.
																							// mobile no 3. template
																							// string 4. sender Id as
																							// per client 5. dynamic
																							// parameters
				manageBidderService.updateGenerateOTP(tblUserLogin.getUserId(), String.valueOf(otp));
			}
			pageName = "RegistrationVerification";
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					registrationLinkId, auditGetBidderRegistrationVerificationpage, 0, userIds);
		}
		return pageName;
	}

	@RequestMapping(value = "/registrationOTPVerfication", method = RequestMethod.POST)
	public String bidderRegOTPVerfication(ModelMap modelMap, HttpServletRequest request, HttpServletResponse response,
			RedirectAttributes redirectAttributes) {
		TblUserLogin tblUserLogin = null;
		String pageName = "redirect:/";
		boolean success = false;
		int hdUserId = 0;
		String otp = "";
		try {
			hdUserId = StringUtils.hasLength(request.getParameter("hdUserId"))
					&& !"".equals(request.getParameter("hdUserId")) ? Integer.parseInt(request.getParameter("hdUserId"))
							: 0;
			otp = StringUtils.hasLength(request.getParameter("txtOTP")) && !"".equals(request.getParameter("txtOTP"))
					? request.getParameter("txtOTP")
					: "";

			List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(hdUserId);
			if (tblUserLogins != null && !tblUserLogins.isEmpty()) {
				tblUserLogin = tblUserLogins.get(0);
			}

			if (tblUserLogin != null) {
				if (tblUserLogin.getVerificationCode().equals(otp)) {
					success = manageBidderService.updateOTPVerified(tblUserLogin.getUserId());
					if (success) {
						int regWorkflowId = manageBidderService
								.getClientRegWorkflowId(abcUtility.getSessionClientId(request), 3);
						manageBidderService.updateRegistrationWorkflowInBidderStatus(
								abcUtility.getSessionClientId(request), hdUserId, regWorkflowId);
						redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),
								"redirect_otp_verify_success");
						HttpSession session = request.getSession();
						if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null
								&& session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
							switch (regWorkflowId) {
							case 4: // Certificate Mapping
								pageName = "redirect:/certimap";
								break;
							case 5: // Registation Documents
								pageName = "redirect:/uploaddocument";
								break;
							case 6: // Registration Charges
								pageName = "redirect:/bidderregcharges";
								break;
							case 7: // Complete registration - final step
								pageName = "redirect:/gstDetails/0";
								break;
							case 8: // Complete registration - final step
								pageName = "redirect:/finishregistration";
								break;
							}
						} else {
							pageName = "redirect:/";
						}
					} else {
						modelMap.addAttribute("userId", tblUserLogin.getUserId());
						modelMap.addAttribute("emailId", tblUserLogin.getLoginId());
						redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_expired_otp");
						pageName = "redirect:/registrationOTPGenerate/1/"
								+ encryptDecryptUtils.encrypt(String.valueOf(tblUserLogin.getUserId()));
					}
				} else {
					modelMap.addAttribute("userId", tblUserLogin.getUserId());
					modelMap.addAttribute("emailId", tblUserLogin.getLoginId());
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_incorrect_otp");
					pageName = "redirect:/registrationOTPGenerate/1/"
							+ encryptDecryptUtils.encrypt(String.valueOf(tblUserLogin.getUserId()));
				}
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					registrationLinkId, auditPostBidderRegistrationVerificationpage, 0, hdUserId);
		}
		return pageName;
	}

	@RequestMapping(value = "/ajaxcall/registrationResendOTP", method = RequestMethod.POST)
	@ResponseBody
	public String resendOTP(@RequestParam("txtUserId") String userId, HttpServletRequest request) {
		TblUserLogin tblUserLogin = null;
		String resultString = null;
		try {
			List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(Integer.parseInt(userId));
			if (tblUserLogins != null && !tblUserLogins.isEmpty()) {
				tblUserLogin = tblUserLogins.get(0);
			}

			if (tblUserLogin != null) {
				int otp = commonService.genrateOtp(4);
				Map<String, Object> paramMap = new HashMap<String, Object>();
				paramMap.put("otp", otp);
				boolean isIndian = commonService.getCountryIdByCompanyId(Integer.parseInt(
						String.valueOf(commonService.getCompanyIdByUserId(Integer.parseInt(userId))))) == countryId;
				smsContentUtillity.dynamicSMSGeneration(registrationLinkId, tblUserLogin.getMobileNo(), msgRegOTP,
						commonService.getSMSSenderIdFromLogo(request), paramMap, isIndian); // 1. parameter link Id 2.
																							// mobile no 3. template
																							// string 4. sender Id as
																							// per client 5. dynamic
																							// parameters
				manageBidderService.updateGenerateOTP(tblUserLogin.getUserId(), String.valueOf(otp));
				resultString = "Success";
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					registrationLinkId, auditRegistrationVerificationResendOTP, 0, Integer.parseInt(userId));
		}
		return resultString;
	}

	/** Project Task #58241 End Here */

	@RequestMapping(value = "/finishregistration", method = RequestMethod.GET)
	public String showFinishRegistration(HttpServletRequest request, HttpSession session,
			RedirectAttributes redirectAttributes) {

		String retVal = "redirect:/";
		int cstatus = 0;
		if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
			SessionBean sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
			boolean isRegistrationLinkHidden = false;
			int remainingDocs = 0;
			try {
				isRegistrationLinkHidden = clientService
						.isRegistrationLinkHidden(abcUtility.getSessionClientId(request), hideRegistrationLinkId, 1);
				// Bug #71860
				// @ INDRAJIT MAHESHWARI
				ClientBean clientBean = (ClientBean) session.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
				int clientRegWorkflowId = 0;
				if (sessionBean.getUserTypeId() == 2) {
					clientRegWorkflowId = manageBidderService.getBidderWorkflowId(clientBean.getClientId(),
							sessionBean.getUserId());
				}
				if (clientRegWorkflowId != 0 && clientRegWorkflowId != 9 && clientRegWorkflowId == 5) {
					List<Object[]> list = manageBidderService.getMandatoryPendingDocCount(
							abcUtility.getSessionClientId(request), sessionBean.getUserId());
					remainingDocs = Integer.parseInt(list.get(0)[0].toString())
							- Integer.parseInt(list.get(0)[1].toString());
				}
				// INDRAJIT MAHESHWARI

				cstatus = manageBidderService.getBidderCstatus(abcUtility.getSessionClientId(request),
						sessionBean.getUserId());
				if (cstatus == cstatusIncomplete) {
					cstatus = cstatusPending;
					if (CommonUtility.isClientConditionExistInProperty(rciClientIds,
							abcUtility.getSessionClientId(request))) {
						cstatus = cstatusApproved;
					}
				} else if (cstatus == cstatusApproveIncomplete) {
					cstatus = cstatusApproved;
				}

				if (!isRegistrationLinkHidden) {
					// Bug #71860
					// @ INDRAJIT MAHESHWARI

					if (remainingDocs == 0) {
						/*
						 * int
						 * bidderRegVerifiedBy=clientService.getBidderRegistrationVerifiedBy(abcUtility.
						 * getSessionClientId(request)); if(bidderRegVerifiedBy == 3 ||
						 * bidderRegVerifiedBy == 2) { if(cstatus == cstatusPending) { cstatus =
						 * cstatusApproved; } }
						 */

						manageBidderService.updateRegistrationFinalStepBidderStatus(
								abcUtility.getSessionClientId(request), sessionBean.getUserId(),
								manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), 8),
								cstatus);
						redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),
								"redirect_success_bidder_registration_final_step");

						if (cstatus == cstatusApproved || cstatus == cstatusApproveIncomplete) {
							redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),
									"redirect_success_bidder_registration_verification");
							request.getSession().setAttribute(CommonKeywords.SESSION_OBJ.toString(),
									request.getSession().getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()));
						}

						/*
						 * if(!(bidderRegVerifiedBy == 3 || bidderRegVerifiedBy == 2)) {
						 * request.getSession().removeAttribute(
						 * CommonKeywords.TEMP_SESSIONOBJ.toString());
						 * request.getSession().removeAttribute( CommonKeywords.SESSION_OBJ.toString());
						 * request.getSession().invalidate(); }
						 */
					} else {
						redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
								"empty_mandatory_doclist");
						retVal = "redirect:/uploaddocument";
					}
					if(commonService.getSubUser(sessionBean.getUserId())) {
						if(commonService.isParentBidderApproved(sessionBean.getUserId(),clientBean.getClientId())) {
							//redirect page
							retVal = getRedirectPage(request);
						}else {
							//errormessage
							redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_error_profile_not_approved");
							//successnull
							redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),null);
							//redirectpage
							retVal = "redirect:/";
							//session invalidate
							request.getSession().removeAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
							request.getSession().removeAttribute(CommonKeywords.SESSION_OBJ.toString());
							request.getSession().invalidate();
						}
					}else {
					request.getSession().removeAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
					request.getSession().removeAttribute(CommonKeywords.SESSION_OBJ.toString());
					request.getSession().invalidate();
					}
					// INDRAJIT MAHESHWARI
				} else {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
							"msg_not_allow_to_register");
				}

			} catch (Exception e) {
				return exceptionHandlerService.writeLog(e);
			} finally {
				if (sessionBean.getTrackLoginId() != 0) {
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0,
							auditRegFinalStep, sessionBean.getUserId(), 0);
				}
			}
		}
		return retVal;
	}

	@RequestMapping(value = "/uploaddocument", method = RequestMethod.GET)
	public String uploadDocument(HttpServletRequest request, ModelMap modelMap, HttpSession session) {

		String retVal = null;
		int clientId = 0;
		int userId = 0;
		try {
			int mandatoryDocs = 0;
			int remainingDocs = 0;

			if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
				clientId = abcUtility.getSessionClientId(request);
				SessionBean sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
				userId = sessionBean.getUserId();
				List<Object[]> lstClientRegDocs = manageBidderService.getClientRegDoc(clientId);

				List<SelectItem> mandatoryDocList = abcUtility.convert(lstClientRegDocs);

				List<Object[]> list = manageBidderService.getMandatoryPendingDocCount(clientId, userId);
				mandatoryDocs = Integer.parseInt(list.get(0)[0].toString());
				remainingDocs = mandatoryDocs - Integer.parseInt(list.get(0)[1].toString());

				List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(14, clientId);
				int allowedSize = lstDocUploadConf.get(0).getMaxSize();

				StringBuilder allowedExt = new StringBuilder();
				allowedExt.append(lstDocUploadConf.get(0).getType());

				int index = allowedExt.toString().indexOf(",");
				allowedExt.insert(index + 1, "*.");
				while (index >= 0) {
					index = allowedExt.toString().indexOf(",", index + ",".length());
					allowedExt.insert(index + 1, "*.");
				}

				if (remainingDocs == 0) {
					int regWorkflowId = manageBidderService.getClientRegWorkflowId(clientId, 5);
					if (regWorkflowId == 7
							&& commonService.getCountryIdByCompanyId(sessionBean.getCompanyId()) != countryId) {
						regWorkflowId = 8;
					}
					modelMap.put("clientRegWorkflowId", regWorkflowId);
					/*
					 * manageBidderService.updateRegistrationWorkflowInBidderStatus(clientId,userId,
					 * regWorkflowId); if (regWorkflowId != 0) { switch (regWorkflowId) { case 4: //
					 * Certificate Mapping modelMap.put("nextStepAction", "/certimap"); break; case
					 * 5: // Registation Documents modelMap.put("nextStepAction",
					 * "/uploaddocument"); break; case 6: // Registration Charges
					 * modelMap.put("nextStepAction", "/bidderregcharges"); break; case 7: //
					 * Complete registration - final step
					 * modelMap.put("nextStepAction","/finishregistration"); break; } }
					 */
				}

				Map uploadedDocBucket = new HashMap();

				List<Map> manDocSummary = new ArrayList<Map>();
				List<Object[]> lstManDoc = manageBidderService.getUploadedPendingManDocLst(clientId, userId);
				List<Object> lstBidderDocMappingChId = manageBidderService.getBidderDocMappingChildId(clientId, userId);
				List<Object[]> lstUploadedDoc = manageBidderService.getBidderDocs(userId, clientId);

				if (!lstUploadedDoc.isEmpty()) {
					for (Object[] uploadedDocObj : lstUploadedDoc) {
						if (((Integer) uploadedDocObj[5]) == 0) { // Bug #12691 0 for non-mandatory doc, 1 for mandatory doc 
							if (uploadedDocBucket.containsKey(uploadedDocObj[4])) {
								String docName = (String) uploadedDocBucket.get(uploadedDocObj[4]);
								docName += ", " + (String) uploadedDocObj[0];

								uploadedDocBucket.remove(uploadedDocObj[4]);
								uploadedDocBucket.put(uploadedDocObj[4], docName);
							} else {
								uploadedDocBucket.put(uploadedDocObj[4], uploadedDocObj[0]);
							}
						}
					}
				}

				if (!lstManDoc.isEmpty()) {
					for (Object[] objects : lstManDoc) {
						Map docSummaryMap = new HashMap();
						docSummaryMap.put("clientRegDocId", objects[0]);
						docSummaryMap.put("mandatoryDocName", objects[1]);

						if (!lstBidderDocMappingChId.isEmpty()) {
							if (lstBidderDocMappingChId.contains(objects[0])) {
								docSummaryMap.put("isuploaded", "1");
							} else {
								docSummaryMap.put("isuploaded", "0");
							}
						} else {
							docSummaryMap.put("isuploaded", "0");
						}
						manDocSummary.add(docSummaryMap);
					}
				}
				modelMap.addAttribute("uploadedDocBucket", uploadedDocBucket);
				modelMap.addAttribute("manDocSummary", manDocSummary);
				modelMap.addAttribute("allowedSize", allowedSize / 1024);
				modelMap.addAttribute("allowedExt", allowedExt.toString());
				modelMap.addAttribute("uploadedDoc", manageBidderService.getTotalUploadedDocs(clientId, userId));
				modelMap.addAttribute("mandatoryDocs", mandatoryDocs);
				modelMap.addAttribute("remainingDocs", remainingDocs);
				modelMap.addAttribute("documentList", lstUploadedDoc);// For
																		// document
																		// list
				modelMap.addAttribute("mandatoryDocList", mandatoryDocList);
				modelMap.addAttribute("userId", userId);
				modelMap.addAttribute("officerDocUpload", true);
				modelMap.addAttribute("isRegistrationLinkHidden",
						clientService.isRegistrationLinkHidden(clientId, hideRegistrationLinkId, 1));
				retVal = "common/admin/UploadDocument";
			} else {
				retVal = "redirect:/loginfailed";
			}
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0,
					auditUploadRegDoc, userId, clientId);
		}
		return retVal;
	}

	@RequestMapping(value = "/gotonextstep", method = RequestMethod.POST)
	public String gotoNextStep(HttpSession session, HttpServletRequest request) {
		SessionBean sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
		String nextStepAction = "redirect:/sessionexpired";
		if (sessionBean != null) {
			try {
				int clientId = abcUtility.getSessionClientId(request);
				int userId = sessionBean.getUserId();
				boolean isRegistrationLinkHidden = clientService.isRegistrationLinkHidden(clientId,
						hideRegistrationLinkId, 1);
				if (!isRegistrationLinkHidden) {
					int regWorkflowId = StringUtils.hasLength(request.getParameter("hdClientRegWorkflowId"))
							? Integer.parseInt(request.getParameter("hdClientRegWorkflowId"))
							: 0;
					if (regWorkflowId == 7
							&& commonService.getCountryIdByCompanyId(sessionBean.getCompanyId()) != countryId) {
						regWorkflowId = 8;
					}
					if (regWorkflowId != 0 && manageBidderService.updateRegistrationWorkflowInBidderStatus(clientId,
							userId, regWorkflowId)) {
						switch (regWorkflowId) {
						case 4: // Certificate Mapping
							nextStepAction = "redirect:/certimap";
							break;
						case 5: // Registation Documents
							nextStepAction = "redirect:/uploaddocument";
							break;
						case 6: // Registration Charges
							nextStepAction = "redirect:/bidderregcharges";
							break;
						case 7: // Complete registration - final step
							nextStepAction = "redirect:/gstDetails/0";
							break;
						case 8: // Complete registration - final step
							nextStepAction = "redirect:/finishregistration";
							break;
						}
					}
				} else {
					nextStepAction = "redirect:/";
				}
			} catch (Exception e) {
				exceptionHandlerService.writeLog(e);
			}
		}
		return nextStepAction;
	}

	@RequestMapping(value = "/submitFileUpload", method = RequestMethod.POST)
	public String submitFileUpload(HttpSession session, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {
		boolean isValidate = true;
		String pageView = null;
		int clientId = 0;
		int userId = 0;
		try {

			String fileDesc = null;
//			int selMandatoryDoc = 0;		To remove Mandatory Document select drop down.
			int selMandatoryDoc = 2;
			clientId = abcUtility.getSessionClientId(request);

			List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(14, clientId);
			boolean fileUploadedSuccess = false;
			File file = null;
			File tmpDir;
			String fileDir = "";
			long fileSize = 0;
			String fileName = "";
			long fileMaxSize = lstDocUploadConf.get(0).getMaxSize() * 1024;
			String fileExtensions = lstDocUploadConf.get(0).getType();
			String path = lstDocUploadConf.get(0).getPath();
			String tmpDirPath = tmpPath + path;
			isDirExists(tmpDirPath);
			DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();

			fileItemFactory.setSizeThreshold(1 * 1024 * 1024);

			ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);

			List items = uploadHandler.parseRequest(request);
			Iterator itr = items.iterator();

			while (itr.hasNext()) {
				FileItem item = (FileItem) itr.next();

				if (item.isFormField()) {
//					To remove Mandatory Document select drop down.
//					if (item.getFieldName().equals("selMandatoryDoc")) {
//						selMandatoryDoc = Integer.parseInt(item.getString());
//					}
					if (item.getFieldName().equals("fileDesc")) {
						fileDesc = item.getString();

						if (fileDesc == null || "".equalsIgnoreCase(fileDesc.trim())) {
							redirectAttributes.addFlashAttribute("fileError", messageSource
									.getMessage("enter_document_brief", null, LocaleContextHolder.getLocale()));
							isValidate = false;
							break;
						}
					}
					if (item.getFieldName().equals("userId")) {
						userId = Integer.parseInt(item.getString());
					}
				} else {
					fileSize = item.getSize();

					if (item.getName().lastIndexOf("\\") != -1) {
						fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1,
								item.getName().length());
					} else {
						fileName = item.getName();
					}

					if (fileName != null && !fileName.equalsIgnoreCase("")) {
						if (fileSize == 0) {
							redirectAttributes.addFlashAttribute("fileError", messageSource
									.getMessage("size_zero_not_allowed", null, LocaleContextHolder.getLocale()));
							isValidate = false;
							break;
						}
						if (!checkFileSize(fileSize, fileMaxSize)) {
							redirectAttributes.addFlashAttribute("fileError", messageSource.getMessage("max_file_size",
									new Object[] { fileMaxSize / (1024 * 1024) }, LocaleContextHolder.getLocale()));
							isValidate = false;
							break;
						}
						if (!checkFileExn(fileName, fileExtensions)) {
							redirectAttributes.addFlashAttribute("fileError",
									messageSource.getMessage("not_allowed_other_filetype",
											new Object[] { fileExtensions }, LocaleContextHolder.getLocale()));
							isValidate = false;
							break;
						} else {
							fileDir = String.valueOf(userId);
							tmpDir = new File(tmpDirPath + "\\" + fileDir);

							isDirExists(tmpDir.getAbsolutePath());

 							file = new File(tmpDir, fileName);
    							if (abcUtility.ValidationForFileExist(file)) {
								redirectAttributes.addFlashAttribute("fileError", messageSource.getMessage("already_exists", null, LocaleContextHolder.getLocale()));
								isValidate = false;
								break;
							}
							item.write(file);
							/*
							 * if (!isValidContentType(file)) { file.delete();
							 * redirectAttributes.addFlashAttribute("fileError", "Invalid file type");
							 * fileUploadedSuccess = false; isValidate = false; } else {
							 */
							fileSize = fileEncryptDecryptUtil.fileEncryptUtil(file, (int) fileSize);
							fileUploadedSuccess = true;
							// }
						}
					}
				}
			}
			if (isValidate) {
				if (fileUploadedSuccess) {

					TblBidderDocument tblBidderDocument = new TblBidderDocument();
					tblBidderDocument.setDocName(fileName);
					tblBidderDocument.setTblClient(new TblClient(clientId));
					tblBidderDocument.setBidderFolderId(1);
					tblBidderDocument.setPath(path + "\\" + fileDir + "\\" + fileName);
					tblBidderDocument.setDescription(fileDesc);
					tblBidderDocument.setFileSize(fileSize);
					tblBidderDocument.setCreatedBy(userId);
					tblBidderDocument.setCstatus(1);

					if (manageBidderService.addBidderDocument(tblBidderDocument)) {

						TblBidderDocMapping tblBidderDocMapping = new TblBidderDocMapping();
						tblBidderDocMapping
								.setTblBidderDocument(new TblBidderDocument(tblBidderDocument.getBidderDocId()));
						tblBidderDocMapping.setObjectId(userId);
						tblBidderDocMapping.setDocumentId(0);
						tblBidderDocMapping.setDocumentName("");
						tblBidderDocMapping.setTblLink(new TblLink(1));
						tblBidderDocMapping.setChildId(selMandatoryDoc);
						tblBidderDocMapping.setMappedBy(userId);
						tblBidderDocMapping.setCstatus(1);
						tblBidderDocMapping.setTblCompany(new TblCompany(
								Integer.parseInt(commonService.getCompanyIdByUserId(userId).toString())));
						manageBidderService.addBidderDocMapping(tblBidderDocMapping);
					}
					redirectAttributes.addFlashAttribute("successMsg", "file_uploaded_successfully");

					pageView = "redirect:/uploaddocument";
				}
			} else {
				pageView = "redirect:/uploaddocument";
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0,
					auditRegDocUploaded, userId, clientId);
		}
		return pageView;
	}

	/**
	 * To download document
	 * 
	 * @author nirav.modi
	 * @param modelMap
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/downloaddoc", method = RequestMethod.POST)
	public void downloadBidderDocument(ModelMap modelMap, HttpServletResponse response, HttpServletRequest request) {
		String documentPath = tmpPath;
		int fileSize = 0;
		InputStream fis = null;
		ServletOutputStream outputStream = null;
		int bidderDocId = Integer.parseInt(request.getParameter("hdDownbidderDocId"));
		try {
			List<Object[]> docDetails = manageBidderService.getDocumentDetailsByBidderDocId(bidderDocId);
			if (!docDetails.isEmpty()) {
				Object[] docObj = docDetails.get(0);
				documentPath += docObj[0].toString();
				fileSize = Integer.parseInt(docObj[1].toString());
				File file = new File(documentPath);
				file = abcUtility.CheckDirExist(file);
				if (file.exists()) {
					fis = new FileInputStream(file);
					byte[] buf = new byte[fileSize];// obj[1]=filsize
					int offset = 0;
					int numRead = 0;
					while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
						offset += numRead;
					}
					buf = fileEncryptDecryptUtil.fileDecryptUtil(buf);
					response.setContentType("application/octet-stream");
					response.setHeader("Content-Disposition", "attachment;filename=\""
							+ documentPath.substring(documentPath.lastIndexOf('\\') + 1) + "\"");
					outputStream = response.getOutputStream();
					outputStream.write(buf);
					outputStream.flush();
					fis.close();
				}
			}
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
				if (outputStream != null) {
					outputStream.close();
				}
			} catch (IOException e) {
				exceptionHandlerService.writeLog(e);
			}
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0,
					auditDownloadRegDoc, 0, bidderDocId);
		}
	}

	@RequestMapping(value = "/RemoveDoc", method = RequestMethod.POST)
	public String deleteDocument(HttpServletRequest request, HttpSession session,
			RedirectAttributes redirectAttributes) {
		int bidderDocId = 0;
		try {
			bidderDocId = Integer.parseInt(request.getParameter("hdbidderDocId"));
			List<Object[]> docDetails = manageBidderService.getDocumentDetailsByBidderDocId(bidderDocId);
			if (!docDetails.isEmpty()) {

				String documentPath = tmpPath + docDetails.get(0)[0].toString();

				File file = new File(documentPath);
				file = abcUtility.CheckDirExist(file);
				if (file.exists()) {
					file.delete();
				}

				manageBidderService.deleteDocumentByBidderDocId(bidderDocId);
				redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),
						"file_removed_successfully");
			}
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0,
					auditRemoveRegDoc, 0, bidderDocId);
		}

		return "redirect:/uploaddocument";
	}

	/**
	 * STEP -6 Bidder Reg. charges.
	 * 
	 * @param request
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/bidderregcharges", method = RequestMethod.GET)
	public String bidderRegCharges(HttpServletRequest request, ModelMap modelMap, HttpSession session,
			RedirectAttributes rea) {
		String pageName = "common/admin/BidderRegCharges";
		int clientId = 0;
		int userId = 0;
		int payFor = 3; // 3 for registration Charges
		int payType = 1;
		int registrationCharge = 0;
		int regWorkflowId = 0;
		boolean isPaymentDone = false;
		try {
			if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
				clientId = abcUtility.getSessionClientId(request);
				SessionBean sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
				userId = sessionBean.getUserId();
				TblClient tblClient = clientService.getClientById(clientId);
				TblClientPGBankMapping tblClientPGBankMapping = clientService.getTblClientPGBankMapping(clientId, 1);
				int pgId = tblClientPGBankMapping != null
						? tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId()
						: 0;
				request.setAttribute("pgId", pgId);

				int registrationMode = tblClient.getRegistrationChargeMode();
				registrationCharge = Integer.valueOf(tblClient.getRegistrationCharges());

				List<TblUserLogin> userLogins = commonService.getUserLoginById(userId);
				TblUserLogin userLogin = userLogins != null && userLogins.isEmpty() ? null : userLogins.get(0);
				modelMap.put("userLogin", userLogin);

				TblPayment tblPayment = manageBidderService.getPaymentDetailByBidderId(userId, clientId, payFor, 1);

				modelMap.put("registrationMode", registrationMode);
				modelMap.addAttribute("registrationCharge", registrationCharge);
				modelMap.addAttribute("payFor", payFor);
				modelMap.addAttribute("linkId", offlinePaymentLinkId);
				modelMap.put("isRegistrationLinkHidden",
						clientService.isRegistrationLinkHidden(clientId, hideRegistrationLinkId, 1));
				if (tblPayment != null) {
					int paymentId = 0;
					paymentId = tblPayment.getPaymentId();

					modelMap.addAttribute("paymentId", paymentId);
					modelMap.addAttribute("payType", tblPayment.getTblPaymentType().getPaymentTypeId());
					regWorkflowId = manageBidderService.getClientRegWorkflowId(clientId, 6);
					if (regWorkflowId == 7
							&& commonService.getCountryIdByCompanyId(sessionBean.getCompanyId()) != countryId) {
						regWorkflowId = 8;
					}
					TblOfflinePayment tblOfflinePayment = manageBidderService.getOfflinePaymentDetail(paymentId);

					if (tblOfflinePayment != null) {
						modelMap.addAttribute("paymentDate", tblPayment.getCreatedOn());
						modelMap.addAttribute("paymentType", "Offline");

						if (modelMap.get(CommonKeywords.SUCCESS_MSG.toString()) == null) {

							request.setAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_payment_done");
						}
						modelMap.addAttribute("chRDModeOfPayment", 2);
						isPaymentDone = true;

					} else {

						/*
						 * boolean isReconcilationDone = tpslService .paymentReconcilation(3, paymentId,
						 * clientId, tblPayment.getCreatedOn().toString());
						 * 
						 * if (isReconcilationDone) {
						 */

						if (tpslService.isOnlinePaymentDone(tblPayment.getPaymentId())) {

							TblOnlinePayment tblOnlinePayment = manageBidderService.getOnlinePaymentDetail(paymentId);
							modelMap.addAttribute("paymentDate", tblPayment.getCreatedOn());
							modelMap.addAttribute("paymentType", "Online");

							if (modelMap.get(CommonKeywords.SUCCESS_MSG.toString()) == null) {

								request.setAttribute(CommonKeywords.ERROR_MSG.toString(),
										"redirect_error_payment_done");
							}
							modelMap.addAttribute("chRDModeOfPayment", 1);
							isPaymentDone = true;
						}
						/*
						 * } else {
						 * 
						 * System.out .println("Payment pending..............."); }
						 */
					}
				}

				if (tblPayment == null || !isPaymentDone) {
					boolean isReconcilationDone = false;
					tblPayment = manageBidderService.getPaymentDetailByBidderId(userId, clientId, payFor, 0);
					if (tblPayment != null) {
						try {
							isReconcilationDone = tpslService.paymentReconcilation(3, tblPayment.getPaymentId(),
									clientId, tblPayment.getCreatedOn().toString(),
									tblPayment.getTblDepartment().getDeptId());
						} catch (Exception ex) {
							exceptionHandlerService.writeLog(ex);
						}
					}
					if (!isReconcilationDone) {

						regWorkflowId = manageBidderService.getClientRegWorkflowId(clientId, 5);

						List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventBidderRegcharges,
								abcUtility.getSessionClientId(request));
						int allowedSize = 0;
						StringBuilder allowedExt = new StringBuilder();
						if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
							allowedSize = lstDocUploadConf.get(0).getMaxSize();
							allowedExt.append(lstDocUploadConf.get(0).getType());
							modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
						}
						int index = allowedExt.toString().indexOf(",");
						allowedExt.insert(index + 1, "*.");
						while (index >= 0) {
							index = allowedExt.toString().indexOf(",", index + ",".length());
							allowedExt.insert(index + 1, "*.");
						}

						fileUploadService.getOfficerDocDetailsForRemove(0, 650);
						modelMap.addAttribute("allowedExt", allowedExt);
						modelMap.addAttribute("allowedSize", allowedSize / 1024);

						List<SelectItem> lstModeOfPayment = new ArrayList<SelectItem>();
						if (registrationMode == 1 || registrationMode == 3) {
							lstModeOfPayment.add(new SelectItem("Online", 1));
						}

						if (registrationMode == 2 || registrationMode == 3) {
							lstModeOfPayment.add(new SelectItem("Offline", 0));
						}

						modelMap.put("lstModeOfPayment", lstModeOfPayment);

						if (modelMap.get("chRDModeOfPayment") == null) {
							modelMap.addAttribute("chRDModeOfPayment", registrationMode == 2 ? 0 : 1);
						}

						List<SelectItem> selTypeOfOnlinePayment = null;
						selTypeOfOnlinePayment = new ArrayList<SelectItem>();
						selTypeOfOnlinePayment.add(new SelectItem("Net Banking", 1));
						selTypeOfOnlinePayment.add(new SelectItem("Credit Card / Debit Card", 1));
						modelMap.put("rdTypeOfOnlinePayment", selTypeOfOnlinePayment);
						modelMap.addAttribute("chRDTypeOfOnlinePayment", 1);

						List<SelectItem> selTypeOfOfflinePayment = null;
						selTypeOfOfflinePayment = new ArrayList<SelectItem>();
						selTypeOfOfflinePayment.add(new SelectItem("Cash", 5));
						selTypeOfOfflinePayment.add(new SelectItem("Cheque / DD", 3));
						selTypeOfOfflinePayment.add(new SelectItem("BG/FD", 7));
						selTypeOfOfflinePayment.add(new SelectItem("Offline NEFT/RTGS", 10));
						modelMap.put("rdTypeOfOfflinePayment", selTypeOfOfflinePayment);

						if (modelMap.get("chRDTypeOfOfflinePayment") == null) {
							modelMap.addAttribute("chRDTypeOfOfflinePayment", 5);
						}
						modelMap.addAttribute("payFor", payFor);

						if (modelMap.get("payType") == null) {
							modelMap.addAttribute("payType", registrationMode == 1 ? 1 : registrationMode == 2 ? 5 : 1);
						}
						modelMap.put("hdBidderRegWorkflowId", regWorkflowId);
						modelMap.addAttribute("paymentId", 0);

					} else {
						pageName = "redirect:/bidderregcharges";
					}
				} else {
					modelMap.put("hdBidderRegWorkflowId", regWorkflowId);

					if (regWorkflowId != 0) {
						switch (regWorkflowId) {
						case 4: // Registation Documents
							modelMap.put("nextStepAction", "/uploaddocument");
							break;
						case 5: // Certificate Mapping
							modelMap.put("nextStepAction", "/certimap");
							break;
						case 6: // Registration Charges
							modelMap.put("nextStepAction", "/bidderregcharges");// pending
							break;
						case 7: // Complete registration - final step
							modelMap.put("nextStepAction", "/gstDetails/0");
							break;
						case 8: // Complete registration - final step
							modelMap.put("nextStepAction", "/finishregistration");
							break;
						}
					}
				}
			} else {
				pageName = "redirect:/loginfailed";
			}

		} catch (Exception e) {
			pageName = exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					registrationLinkId, "", 0, 0);
		}
		return pageName;
	}

	/**
	 * Creates the directory named by this abstract pathname, including any
	 * necessary but nonexistent parent directories. Note that if this operation
	 * fails it may have succeeded in creating some of the necessary parent
	 * directories.
	 * 
	 * @param apath
	 * @return true if and only if the directory has been created, along with all
	 *         necessary parent directories; false otherwise
	 */
	private boolean isDirExists(String apath) {
		boolean flag = false;
		File f = new File(apath);
		if (!f.isDirectory()) {
			f.mkdirs();
		}

		return flag;
	}

	/**
	 * create directory if it does not exists
	 * 
	 * @param drive
	 * @param rpath
	 * @return boolean String[] tpath = rpath.split("\\\\");
	 */
	private void isDirExists(String drive, String rpath) {
		String[] tpath = rpath.split("\\\\");
		StringBuilder path = new StringBuilder();
		path.append(drive);

		for (int i = 0; i < tpath.length; i++) {
			path.append("\\").append(tpath[i]);

			File f = new File(path.toString());

			if (!f.isDirectory()) {
				f.mkdir();
			}
		}
	}

	private boolean checkFileSize(long fielSize, long maxFileSize) {
		boolean chextn = false;
		if (maxFileSize > fielSize) {
			chextn = true;
		} else {
			chextn = false;
		}
		return chextn;
	}

	private boolean checkFileExn(String fileName, String allowExtensions) {
		boolean chextn = false;
		int j = fileName.lastIndexOf('.');
		String lst = fileName.substring(j + 1);
		String str = allowExtensions;
		String[] str1 = str.split(",");
		for (int i = 0; i < str1.length; i++) {
			if (str1[i].trim().equalsIgnoreCase(lst)) {
				chextn = true;
			}
		}
		return chextn;
	}

	/**
	 * Displays the DRT Retired Officer registration page to the user.
	 * 
	 * @author Nirav Raval
	 * @param drtOfficerRegistrationDataBean
	 * @param request
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/retireddrtofficerregistration", method = RequestMethod.GET)
	public String registerRetiredDRTOfficer(@ModelAttribute DrtRetiredOffRegDataBean drtRetiredOffRegDataBean,
			HttpServletRequest request, ModelMap modelMap) {
		try {
			List<Object[]> clientDetails = commonService
					.getClientCountryStateTimezone(abcUtility.getSessionClientId(request));
			if (clientDetails != null && !clientDetails.isEmpty()) {
				drtRetiredOffRegDataBean.setSelCountry(Integer.parseInt(clientDetails.get(0)[1].toString()));
				drtRetiredOffRegDataBean.setSelState(clientDetails.get(0)[2].toString());
			}
			String langId = WebUtils.getCookie(request, "locale").getValue();
			modelMap.put("countryList", modelToSelectItem
					.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang" + langId));
			modelMap.put("stateList",
					modelToSelectItem.convertListIntoSelectItemList(
							commonService.getStateBycountryId(drtRetiredOffRegDataBean.getSelCountry()), "stateId",
							"lang" + WebUtils.getCookie(request, "locale").getValue()));
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		return "registerretireddrtofficer";
	}

	/**
	 * Validates the form submitted by the Retired DRT Officer. If the data is valid
	 * then the information will be stored in the database otherwise the
	 * registration page will be shown with validation errors.
	 * 
	 * @author Nirav Raval
	 * @param drtOfficerRegistrationDataBean
	 * @param result
	 * @param session
	 * @param request
	 * @param redirectAttributes
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/addretireddrtofficerregistration", method = RequestMethod.POST)
	public String addRetiredDRTOfficerRegistration(@ModelAttribute DrtRetiredOffRegDataBean drtRetiredOffRegDataBean,
			BindingResult result, HttpServletRequest request, RedirectAttributes redirectAttributes,
			ModelMap modelMap) {
		boolean success = false;
		drtRetiredOffRegDataBean.setCommonValidators(commonValidators);
		drtRetiredOffRegDataBean.validate(result, true);
		String retVal = "redirect:/";

		String langId = WebUtils.getCookie(request, "locale").getValue();
		String successMsgCode = "";
		try {
			if (result.hasErrors()) {
				modelMap.put("countryList", modelToSelectItem.convertListIntoSelectItemList(
						commonService.getCountryList(langId), "countryId", "lang" + langId));
				if (drtRetiredOffRegDataBean.getSelCountry() != 0) {
					modelMap.put("stateList",
							modelToSelectItem.convertListIntoSelectItemList(
									commonService.getStateBycountryId(drtRetiredOffRegDataBean.getSelCountry()),
									"stateId", "lang" + WebUtils.getCookie(request, "locale").getValue()));
				}
				success = false;
				retVal = "Registerretireddrtofficer";
			} else {
				drtService.addDrtRetOff(drtRetiredOffRegDataBean._toTblRetiredOfficerReg());
				success = true;
				successMsgCode = "redirect_success_DRT_retired_registration";
				retVal = "redirect:/";
			}
			redirectAttributes.addFlashAttribute(
					success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),
					success ? successMsgCode : CommonKeywords.ERROR_MSG_KEY.toString());
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally {
			// auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
			// 0, auditDRTRetOffReg, 0, 0);
		}
		return retVal;
	}

	/*
	 * private boolean isValidContentType(File file) throws FileNotFoundException,
	 * IOException { boolean flag = false; int count = 0; FileInputStream fis = new
	 * FileInputStream(file);
	 * 
	 * int j = file.getName().lastIndexOf('.'); String fileExt =
	 * file.getName().substring(j + 1);
	 * 
	 * if ("pdf".equalsIgnoreCase(fileExt)) { for (int i = 0; i <
	 * FILESIGNATURE_PDF.length; ++i) { if (fis.read() != FILESIGNATURE_PDF[i]) {
	 * System.out.println("not a valid pdf file"); count++; } } } else if
	 * ("zip".equalsIgnoreCase(fileExt)) { for (int i = 0; i <
	 * FILESIGNATURE_ZIP.length; ++i) { if (fis.read() != FILESIGNATURE_ZIP[i]) {
	 * System.out.println("not a valid zip file"); count++; } } } else if
	 * ("rar".equalsIgnoreCase(fileExt)) { for (int i = 0; i <
	 * FILESIGNATURE_RAR.length; ++i) { System.out.println(fis.read()
	 * +" :: "+FILESIGNATURE_RAR[i]); if (fis.read() != FILESIGNATURE_RAR[i]) {
	 * System.out.println("not a valid rar file"); count++; } } }
	 * 
	 * if (count > 0) { flag = false; } else { flag = true; } fis.close(); return
	 * flag;
	 * 
	 * }
	 */

	/*
	 * @author Dipika Patel
	 * 
	 * @param session
	 * 
	 * @param request
	 * 
	 * @param modelMap
	 * 
	 * @return
	 */
	@RequestMapping(value = "/bidderonlinepayment", method = RequestMethod.POST)
	public String bidderOnlinePayment(@RequestParam("hdPayType") int payType,
			@RequestParam("hdAmount") BigDecimal registrationCharge, @RequestParam("hdPayFor") int payFor,
			HttpServletRequest request, ModelMap modelMap, HttpSession httpSession) {

		try {
			int paymentId = 0;
			try {
				if (httpSession.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {

					SessionBean sBean = (SessionBean) httpSession
							.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
					TblClientPGBankMapping tblClientPGBankMapping = clientService
							.getTblClientPGBankMapping(abcUtility.getSessionClientId(request), 1);
					int pgId = tblClientPGBankMapping != null
							? tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId()
							: 0;
					TblPayment tblPayment = null;
					if (pgId == 3) {
						tblPayment = new TblPayment();
					} else {
						tblPayment = tpslService.getPaymentDetail(paymentId);
						if (tblPayment == null) {
							tblPayment = new TblPayment();
						}
					}
					TblClient tblClient = new TblClient(abcUtility.getSessionClientId(request));
					tblPayment.setAmount(registrationCharge);
					tblPayment.setExemptionAmt(new BigDecimal(0));
					tblPayment.setCreatedBy(sBean.getUserDetailId());
					tblPayment.setObjectId(0);
					tblPayment.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
					tblPayment.setTblUserLogin(new TblUserLogin(sBean.getUserId()));
					tblPayment.setTblLink(new TblLink(lnkRegiChargesThroughPG)); // need to change
					tblPayment.setClientIds("");
					tblPayment.setRemark("");
					tblPayment.setPaymentFor(payFor);
					tblPayment.setTblPaymentType(new TblPaymentType(payType));
					tblPayment.setTblCompany(new TblCompany(sBean.getCompanyId()));
					int deptId = Integer.parseInt(
							clientService.getClientField(abcUtility.getSessionClientId(request), "deptId").toString());
					tblPayment.setTblDepartment(new TblDepartment(deptId));
					tblPayment.setTblModule(new TblModule(commonService.getModuleIdbyLinkId(lnkRegiChargesThroughPG)));

					paymentId = tpslService.makePaymentTransaction(tblPayment, pgId);

					modelMap.addAttribute("paymentId", paymentId);
					modelMap.addAttribute("registrationCharge", registrationCharge);
					modelMap.addAttribute("payFor", payFor);
					modelMap.addAttribute("payType", payType);
					request.setAttribute("pgId", pgId);
					if (pgId == 2) {
						TblClientPGConf tblClientPGConf = tpslService
								.getPGConfiguration(abcUtility.getSessionClientId(request), payFor, deptId);
						String merchantId = tblClientPGConf.getMerchantId(); // Put your merchant id here
						String accessCode = tblClientPGConf.getAccessCode(); // Put access code here
						String enckey = tblClientPGConf.getCheckSumKey(); // Put encryption key here
						String ccaRequest = "merchant_id=" + merchantId + "&order_id=" + paymentId
								+ "&currency=INR&amount=" + registrationCharge.toString() + "&redirect_url="
								+ tblClientPGConf.getResponseUrl() + "&cancel_url=" + tblClientPGConf.getResponseUrl()
								+ "&language=EN";
						AesCryptUtil aesUtil = new AesCryptUtil(enckey);
						String encRequest = aesUtil.encrypt(ccaRequest);

						modelMap.put("accessCode", accessCode);
						modelMap.put("encRequest", encRequest);
						modelMap.put("pgURL",
								commonService
										.getTblPaymentGatewayMaster(
												tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId())
										.getUrl());
					} else if (pgId == 3) {
						String encypt = "";
						TblClientPGConf tblClientPGConf = tpslService
								.getPGConfiguration(abcUtility.getSessionClientId(request), payFor, deptId);
						String merchantId = "";
						if (tblClientPGConf.getMerchantId().split("_").length > 0) {
							merchantId = tblClientPGConf.getMerchantId().split("_")[0];
						} else {
							throw new Exception("Invalid : merchantId ");
						}
						String accessCode = tblClientPGConf.getAccessCode(); // Put access code here
						String enckey = tblClientPGConf.getCheckSumKey(); // Put encryption key here
						String CRN = payFor + "" + tblPayment.getTblCompany().getCompanyId() + "" + paymentId;
						StringBuilder checkSum = new StringBuilder()
								.append(Security.checkSum(new StringBuilder().append(merchantId).append(paymentId)
										.append(CRN).append(tblPayment.getAmount()).append(enckey).toString()));
						List<Object[]> list = commonService.getBidderContactDetails(
								tblPayment.getTblCompany().getCompanyId(), abcUtility.getSessionClientId(request));
						String loginId = commonService.getEmailByUserId(sBean.getUserId());
						String mbnumber = list != null ? list.get(0)[2].toString() : "";
						StringBuilder PPI = new StringBuilder().append(sBean.getFullName().replaceAll("[^a-zA-Z ]", ""))
								.append("|").append(String.valueOf(mbnumber.replaceAll("[^0-9]", ""))).append("|")
								.append(loginId).append("|").append(tblPayment.getAmount());
						String retVal = tblClientPGConf.getResponseUrl();
						StringBuilder strToEncrypt = new StringBuilder().append("CID=").append(merchantId)
								.append("&RID=");
						strToEncrypt.append(paymentId).append("&CRN=").append(CRN).append("&AMT=")
								.append(registrationCharge.toString());
						strToEncrypt.append("&VER=1.0&TYP=").append(axisPgType).append("&CNY=INR").append("&RTU=");
						strToEncrypt.append(retVal).append("&PPI=").append(PPI);
						strToEncrypt.append("&RE1=MN&RE2=&RE3=&RE4=&RE5=&CKS=").append(checkSum);
						encypt = Security.encrypt(strToEncrypt.toString(), accessCode);
						modelMap.put("encRequest", encypt);
						modelMap.put("pgURL",
								commonService
										.getTblPaymentGatewayMaster(
												tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId())
										.getUrl());
					} else if (pgId == 5) {
						sbiService.setSbiPayment(request, httpSession, modelMap, tblPayment);
					} else if (pgId == 6) {
						isgPaymentService.setISGPaymentGatway(request, httpSession, modelMap, tblPayment, bankIdCode);
					}

					/** PT #41075 */
					TblClientPGConf tblClientPGConf = tpslService
							.getPGConfiguration(abcUtility.getSessionClientId(request), payFor, deptId);
					TblOnlinePaymentTransHistory onlinePaymentTransHistory = new TblOnlinePaymentTransHistory();
					onlinePaymentTransHistory.setTblPayment(new TblPayment(tblPayment.getPaymentId()));
					onlinePaymentTransHistory.setRequestFor(1);
					onlinePaymentTransHistory.setRemarks("");
					onlinePaymentTransHistory.setMerchantId(tblClientPGConf.getMerchantId());
					onlinePaymentTransHistory.setTblPaymentGatewayMaster(new TblPaymentGatewayMaster(pgId));
					tpslService.addTblOnlinePaymentTransHistory(onlinePaymentTransHistory);
				}
			} catch (Exception e) {
				exceptionHandlerService.writeLog(e);
			} finally {
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
						offlinePaymentLinkId, // need
												// to
												// change
						postTpslPayment, 0, paymentId);
			}

		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					registrationLinkId, auditBidderRegistration, 0, 0);
		}
		return "common/admin/BidderOnlinePayment";
	}

	/*
	 * @author Dipika Patel
	 * 
	 * @param session
	 * 
	 * @param request
	 * 
	 * @param modelMap
	 * 
	 * @param redirectAttributes
	 * 
	 * @return
	 */
	@RequestMapping(value = "/submitbidderofflinepayment", method = RequestMethod.POST)
	public String submitBidderOfflinePayment(HttpSession httpSession, HttpServletRequest request,
			RedirectAttributes redirectAttributes, ModelMap modelMap) {

		boolean isValidate = true;
		String pageView = null;
		int clientId = 0;
		int userId = 0;
		int payType = 0;
		int payFor = 0;
		BigDecimal registrationCharge = null;
		String bankName = null;
		String refno = null;
		String refdate = null;
		String docIds = "0";
		String docMapIds = "0";
		try {
			clientId = abcUtility.getSessionClientId(request);
			SessionBean sessionBean = (SessionBean) httpSession.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
			userId = sessionBean.getUserId();
			List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(14, clientId);
			String path = lstDocUploadConf.get(0).getPath();
			String tmpDirPath = tmpPath + path;
			int isEncryptionReq = lstDocUploadConf.get(0).getIsEncryptionReq();
			isDirExists(tmpDirPath);
			DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
			fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
			ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);

			List items = uploadHandler.parseRequest(request);
			Iterator itr = items.iterator();
			TblClient tblClient = clientService.getClientById(clientId);
			int registrationMode = tblClient.getRegistrationChargeMode();
			redirectAttributes.addFlashAttribute("registrationMode", registrationMode);
			redirectAttributes.addFlashAttribute("chRDModeOfPayment", 0);

			while (itr.hasNext()) {
				FileItem item = (FileItem) itr.next();
				if (item.isFormField()) {

					if (item.getFieldName().equals("jhdPayType")) {
						payType = Integer.parseInt(item.getString());
					}
					if (item.getFieldName().equals("jhdPayFor")) {
						payFor = Integer.parseInt(item.getString());
					}
					if (item.getFieldName().equals("jhdAmount")) {
						registrationCharge = new BigDecimal(item.getString().replace(",", ""));
					}
					if (item.getFieldName().equals("txtBankName")) {
						bankName = item.getString();
						if (bankName == null || "".equalsIgnoreCase(bankName.trim())) {
							redirectAttributes.addFlashAttribute("bankNameError", "Please Enter Bank name");
							isValidate = false;
							break;
						}
					}
					if (item.getFieldName().equals("txtPaymentDate")) {
						refdate = item.getString();
						if (refdate == null || "".equalsIgnoreCase(refdate.trim())) {
							redirectAttributes.addFlashAttribute("refDateError", "Please Select Payment Date");
							isValidate = false;
							break;
						}
					}
					if (item.getFieldName().equals("txtCheckDDNo")) {
						refno = item.getString();
					}
				}
			}
			if (payType == 3 || payType == 7 || payType == 10) {
				if (refno == null || "".equalsIgnoreCase(refno.trim())) {
					redirectAttributes.addFlashAttribute("refNoError", "Please Enter Check/DD No");
					isValidate = false;
				}
			} else {
				refno = "";
			}

			List<Object[]> listdocMapIds = fileUploadService.getBidderDocs(0, clientId, offlinePaymentLinkId, 1,
					userId);
			if (listdocMapIds != null) {

				TblPayment tblPayment = new TblPayment();
				tblPayment.setAmount(registrationCharge);
				tblPayment.setExemptionAmt(new BigDecimal(0));
				tblPayment.setCreatedBy(sessionBean.getUserId());
				tblPayment.setObjectId(0);
				tblPayment.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
				tblPayment.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
				tblPayment.setTblLink(new TblLink(offlinePaymentLinkId));
				tblPayment.setClientIds("");
				tblPayment.setRemark("");
				tblPayment.setPaymentFor(payFor);
				tblPayment.setCstatus(1);
				tblPayment.setTblPaymentType(new TblPaymentType(payType));
				tblPayment.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
				tblPayment.setTblDepartment(new TblDepartment(
						Integer.parseInt(clientService.getClientField(clientId, "deptId").toString())));
				tblPayment.setTblModule(new TblModule(commonService.getModuleIdbyLinkId(offlinePaymentLinkId)));

				TblOfflinePayment tblOfflinePayment = new TblOfflinePayment();
				tblOfflinePayment.setReferenceNo(refno);
				tblOfflinePayment.setReferenceDate(conversionService.convert(refdate, Date.class));
				tblOfflinePayment.setBankName(bankName);
				List<TblBidderStatus> bidderStatusList = new ArrayList<TblBidderStatus>();
				List<TblUserHistory> userHistoryList = new ArrayList<TblUserHistory>();

				TblUserHistory tblUserHistory = new TblUserHistory();
				tblUserHistory.setActionType(10);
				tblUserHistory.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
				tblUserHistory.setTblClient(new TblClient(clientId));
				tblUserHistory.setCreatedBy(userId);
				userHistoryList.add(tblUserHistory);

				boolean success = manageBidderService.approveBidder(tblPayment, tblOfflinePayment, bidderStatusList,
						userHistoryList);

				if (success) {
					redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_payment_success");
					int regWorkflowId = manageBidderService.getClientRegWorkflowId(clientId, 6);
					if (regWorkflowId == 7
							&& commonService.getCountryIdByCompanyId(sessionBean.getCompanyId()) != countryId) {
						regWorkflowId = 8;
					}
					manageBidderService.updateRegistrationWorkflowInBidderStatus(clientId, sessionBean.getUserId(),
							regWorkflowId);
					if (StringUtils.hasLength(listdocMapIds.get(0)[0].toString())) {

						TblPayment tblPaymentNew = manageBidderService
								.getPaymentDetailByBidderId(sessionBean.getUserId(), clientId, payFor, 1);
						int paymentId = 0;
						if (tblPaymentNew != null) {
							paymentId = tblPayment.getPaymentId();
						}
						fileUploadService.updateBidderDocsObjectId(listdocMapIds.get(0)[0].toString(), paymentId, 1);
					}

					Map<String, Object> mailParams = new HashMap<String, Object>();
					URL url = new URL(request.getRequestURL().toString().split(request.getRequestURI().toString())[0]);
					mailParams.put("domainName",
							clientService.getClientNameById(abcUtility.getSessionClientId(request)));
					mailParams.put("domainURL", url + request.getContextPath().toString());
					mailParams.put("amount", tblPayment.getAmount());
					mailParams.put("paymentType", commonService
							.getPaymentTypeDetail(tblPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
					mailParams.put("paymentMode", "Offline");
					mailParams.put("date", CommonUtility.convertTimezone(commonService.getServerDateTime()));
					mailParams.put("to", loginService.getLoginIdByUserId(sessionBean.getUserId()).get(0).toString());
					mailContentUtillity.dynamicMailGeneration("390",
							String.valueOf(abcUtility.getSessionUserId(request)), String.valueOf(clientId), mailParams,
							"");

				} else {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_payment_fail");
				}
			} else {
				redirectAttributes.addFlashAttribute("fileError", "Please Select File To Upload");
				redirectAttributes.addFlashAttribute("chRDModeOfPayment", 0);
				redirectAttributes.addFlashAttribute("chRDTypeOfOfflinePayment", payType);
				redirectAttributes.addFlashAttribute("bankName", bankName);
				redirectAttributes.addFlashAttribute("paymentDate", refdate);
				redirectAttributes.addFlashAttribute("checkNo", refno);
				redirectAttributes.addFlashAttribute("payType", payType);
			}
			pageView = "redirect:/bidderregcharges";

		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					offlinePaymentLinkId, auditRegDocUploaded, userId, clientId);
		}
		return pageView;
	}

	@RequestMapping(value = "/downloaddocsinfo/{moduleId}/{objectId}", method = RequestMethod.GET)
	public String getDownloadInfo(HttpServletRequest request, ModelMap modelMap, @PathVariable("moduleId") int moduleId,
			@PathVariable("objectId") int objectId) {
		try {
			List<Object[]> bidderlst = commonService.getBidderInformation(255, "nipun@localmail.com");
//			System.out.println(bidderlst.get(0)[0]);
//			System.out.println(bidderlst.get(0)[1]);
			String langId = WebUtils.getCookie(request, "locale").getValue();
			modelMap.put("captchaHtml", AbcCaptchaFactory.newAbcCaptcha(0));
			modelMap.put("countryList", modelToSelectItem
					.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang" + langId));
			modelMap.put("stateList",
					modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(3), "stateId",
							"lang" + WebUtils.getCookie(request, "locale").getValue()));
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {

		}
		return "FillInfoForDownloadDocuments";
	}

	@RequestMapping(value = "/addBidderInfo", method = RequestMethod.POST)
	public String addBidderInfoForDownloadDocs(HttpServletRequest request, RedirectAttributes redirectAttributes,
			ModelMap modelMap) {
		int moduleId = 0;
		int objectId = 0;
		String emailId = "";
		String companyName = "";
		String personName = "";
		String designation = "";
		String address = "";
		int countryId = 0;
		int stateId = 0;
		String mobileNo = "";
		String phoneNo = "";
		String faxNo = "";
		int clientId = 0;
		String userExist = "";
		String pageView = "";
		try {
			clientId = abcUtility.getSessionClientId(request);
			moduleId = request.getParameter("hdModuleId") != null ? Integer.parseInt(request.getParameter("hdModuleId"))
					: 0;
			objectId = request.getParameter("hdObjectId") != null ? Integer.parseInt(request.getParameter("hdObjectId"))
					: 0;
			userExist = request.getParameter("hdUserExist") != null ? request.getParameter("hdUserExist") : "";

			if (userExist.equals("0")) {
				emailId = request.getParameter("txtEmailId") != null ? request.getParameter("txtEmailId") : "";
				companyName = request.getParameter("txtCompanyName") != null ? request.getParameter("txtCompanyName")
						: "";
				personName = request.getParameter("txtPersonName") != null ? request.getParameter("txtPersonName") : "";
				designation = request.getParameter("txtDesignation") != null ? request.getParameter("txtDesignation")
						: "";
				address = request.getParameter("txtaAddress") != null ? request.getParameter("txtaAddress") : "";
				mobileNo = request.getParameter("txtMobileNo") != null ? request.getParameter("txtMobileNo") : "";
				phoneNo = request.getParameter("txtPhoneNo") != null ? request.getParameter("txtPhoneNo") : "";
				faxNo = request.getParameter("txtFaxNo") != null ? request.getParameter("txtFaxNo") : "";
				countryId = request.getParameter("selCountryId") != null
						? Integer.parseInt(request.getParameter("selCountryId"))
						: 0;
				stateId = request.getParameter("selStateId") != null
						? Integer.parseInt(request.getParameter("selStateId"))
						: 0;
			} else if (userExist.equals("1")) {
				List<Object[]> bidderlst = commonService.getBidderInformation(clientId, emailId);
				companyName = bidderlst.get(0)[2].toString();
				personName = bidderlst.get(0)[1].toString();
				designation = "";
				address = bidderlst.get(0)[3].toString();
				mobileNo = bidderlst.get(0)[4].toString();
				phoneNo = bidderlst.get(0)[5].toString();
				faxNo = "";
				countryId = Integer.parseInt(bidderlst.get(0)[6].toString());
				stateId = Integer.parseInt(bidderlst.get(0)[7].toString());
			}
			TblDownloadDocument tblDownloadDocument = new TblDownloadDocument();
			tblDownloadDocument.setModuleId(moduleId);
			tblDownloadDocument.setObjectId(objectId);
			tblDownloadDocument.setEmailId(emailId);
			tblDownloadDocument.setCompanyName(companyName);
			tblDownloadDocument.setPersonName(personName);
			tblDownloadDocument.setDesignation(designation);
			tblDownloadDocument.setAddress(address);
			tblDownloadDocument.setCountryId(countryId);
			tblDownloadDocument.setStateId(stateId);
			tblDownloadDocument.setMobileNo(mobileNo);
			tblDownloadDocument.setPhoneNo(phoneNo);
			tblDownloadDocument.setFaxNo(faxNo);

		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}

		pageView = "redirect:/downloadtenderdocuments/" + objectId;
		return pageView;
	}

	/* Project Task #37935 : Start */
	/**
	 * @author pradip.jinjala
	 * @return GMRTermsCondition
	 * @throws Exception
	 */
	@RequestMapping(value = "/gmrtermscondition", method = RequestMethod.GET)
	public String getGMRTermsCondition(ModelMap map, HttpServletRequest request) throws Exception {
		map.put("lstClientMarquee", clientService.getClientMarqueeBylocation(
				(int) abcUtility.getSessionClientId(request), 3));/* For After Loging Marque */
		int ShowAccessDetail = abcUtility.getAccessDetail(request);
		if (ShowAccessDetail == 1) {
			int visitorCount = commonService.getVisitorDetail(request);
			map.addAttribute("visitorCount", visitorCount);
		}
		return "GMRTermsCondition";
	}

	/**
	 * @author pradip.jinjala
	 * @return GMRTermsCondition
	 */
	@RequestMapping(value = "/supplierCOC", method = RequestMethod.GET)
	public String getSupplierCOC(ModelMap map, HttpServletRequest request) {
		int ShowAccessDetail = abcUtility.getAccessDetail(request);
		if (ShowAccessDetail == 1) {
			int visitorCount = commonService.getVisitorDetail(request);
			map.addAttribute("visitorCount", visitorCount);
		}
		return "GMRTermsCondition";
	}

	/**
	 * @author pradip.jinjala
	 * @param map
	 * @param request
	 * @return AboutProcureTiger
	 */
	@RequestMapping(value = "/aboutProcureTiger", method = RequestMethod.GET)
	public String getAboutProcureTiger(ModelMap map, HttpServletRequest request) {
		int ShowAccessDetail = abcUtility.getAccessDetail(request);
		if (ShowAccessDetail == 1) {
			int visitorCount = commonService.getVisitorDetail(request);
			map.addAttribute("visitorCount", visitorCount);
		}
		return "common/AboutProcureTiger";
	}

	/**
	 * @author pradip.jinjala
	 * @param map
	 * @param request
	 * @return AboutGMRGroup
	 */
	@RequestMapping(value = "/aboutGMRGroup", method = RequestMethod.GET)
	public String getAboutGMRGroup(ModelMap map, HttpServletRequest request) {
		int ShowAccessDetail = abcUtility.getAccessDetail(request);
		if (ShowAccessDetail == 1) {
			int visitorCount = commonService.getVisitorDetail(request);
			map.addAttribute("visitorCount", visitorCount);
		}
		return "common/AboutGMRGroup";
	}
	/* Project Task #37935 : END */

	/**
	 * @author um@ng.rathod
	 * @param request @ Officer upload Bidder Doc
	 */
	@RequestMapping(value = "/submitFileUploadFromOfficer", method = RequestMethod.POST)
	public String submitFileUploadFromOfficer(HttpSession session, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {
		boolean isValidate = true;
		String pageView = null;
		int clientId = 0;
		int userId = 0;
		int officerId = 0;
		try {

			String fileDesc = null;
//			int selMandatoryDoc = 0; To remove Mandatory Document select drop down.
			int selMandatoryDoc = 2;
			clientId = abcUtility.getSessionClientId(request);
			officerId = abcUtility.getSessionUserId(request);

			List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(14, clientId);
			boolean fileUploadedSuccess = false;
			File file = null;
			File tmpDir;
			String fileDir = "";
			long fileSize = 0;
			String fileName = "";
			long fileMaxSize = lstDocUploadConf.get(0).getMaxSize() * 1024;
			String fileExtensions = lstDocUploadConf.get(0).getType();
			String path = lstDocUploadConf.get(0).getPath();
			String tmpDirPath = tmpPath + path;
			isDirExists(tmpDirPath);
			DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();

			fileItemFactory.setSizeThreshold(1 * 1024 * 1024);

			ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);

			List items = uploadHandler.parseRequest(request);
			Iterator itr = items.iterator();

			while (itr.hasNext()) {
				FileItem item = (FileItem) itr.next();

				if (item.isFormField()) {
//					To remove Mandatory Document select drop down.
//					if (item.getFieldName().equals("selMandatoryDoc")) { 
//						selMandatoryDoc = Integer.parseInt(item.getString());
//					}
					if (item.getFieldName().equals("fileDesc")) {
						fileDesc = item.getString();

						if (fileDesc == null || "".equalsIgnoreCase(fileDesc.trim())) {
							redirectAttributes.addFlashAttribute("fileError", messageSource
									.getMessage("enter_document_brief", null, LocaleContextHolder.getLocale()));
							isValidate = false;
							break;
						}
					}
					if (item.getFieldName().equals("userId")) {
						userId = Integer.parseInt(item.getString());
					}
				} else {
					fileSize = item.getSize();

					if (item.getName().lastIndexOf("\\") != -1) {
						fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1,
								item.getName().length());
					} else {
						fileName = item.getName();
					}

					if (fileName != null && !fileName.equalsIgnoreCase("")) {
						if (fileSize == 0) {
							redirectAttributes.addFlashAttribute("fileError", messageSource
									.getMessage("size_zero_not_allowed", null, LocaleContextHolder.getLocale()));
							isValidate = false;
							break;
						}
						if (!checkFileSize(fileSize, fileMaxSize)) {
							redirectAttributes.addFlashAttribute("fileError", messageSource.getMessage("max_file_size",
									new Object[] { fileMaxSize / (1024 * 1024) }, LocaleContextHolder.getLocale()));
							isValidate = false;
							break;
						}
						if (!checkFileExn(fileName, fileExtensions)) {
							redirectAttributes.addFlashAttribute("fileError",
									messageSource.getMessage("not_allowed_other_filetype",
											new Object[] { fileExtensions }, LocaleContextHolder.getLocale()));
							isValidate = false;
							break;
						} else {
							fileDir = String.valueOf(userId);
							tmpDir = new File(tmpDirPath + "\\" + fileDir);

							isDirExists(tmpDir.getAbsolutePath());

							file = new File(tmpDir, fileName);
							if (abcUtility.ValidationForFileExist(file)) {
								redirectAttributes.addFlashAttribute("fileError", messageSource
										.getMessage("already_exists", null, LocaleContextHolder.getLocale()));
								isValidate = false;
								break;
							}
							item.write(file);
							fileSize = fileEncryptDecryptUtil.fileEncryptUtil(file, (int) fileSize);
							fileUploadedSuccess = true;
							// }
						}
					}
				}
			}
			if (isValidate) {
				if (fileUploadedSuccess) {

					TblBidderDocument tblBidderDocument = new TblBidderDocument();
					tblBidderDocument.setDocName(fileName);
					tblBidderDocument.setTblClient(new TblClient(clientId));
					tblBidderDocument.setBidderFolderId(1);
					tblBidderDocument.setPath(path + "\\" + fileDir + "\\" + fileName);
					tblBidderDocument.setDescription(fileDesc);
					tblBidderDocument.setFileSize(fileSize);
					tblBidderDocument.setCreatedBy(userId);
					tblBidderDocument.setCstatus(1);

					if (manageBidderService.addBidderDocument(tblBidderDocument)) {

						TblBidderDocMapping tblBidderDocMapping = new TblBidderDocMapping();
						tblBidderDocMapping
								.setTblBidderDocument(new TblBidderDocument(tblBidderDocument.getBidderDocId()));
						tblBidderDocMapping.setObjectId(userId);
						tblBidderDocMapping.setDocumentId(0);
						tblBidderDocMapping.setDocumentName("");
						tblBidderDocMapping.setTblLink(new TblLink(1));
						tblBidderDocMapping.setChildId(selMandatoryDoc);
						tblBidderDocMapping.setMappedBy(userId);
						tblBidderDocMapping.setCstatus(1);
						tblBidderDocMapping.setTblCompany(new TblCompany(
								Integer.parseInt(commonService.getCompanyIdByUserId(userId).toString())));
						manageBidderService.addBidderDocMapping(tblBidderDocMapping);
					}
					redirectAttributes.addFlashAttribute("successMsg", "file_uploaded_successfully");

					pageView = "common/admin/uploadDocument/" + userId;
					pageView = "redirect:/" + pageView + encryptDecryptUtils.generateRedirect(pageView, request);
				}
			} else {
				pageView = "common/admin/uploadDocument/" + userId;
				pageView = "redirect:/" + pageView + encryptDecryptUtils.generateRedirect(pageView, request);
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					lnkOfficerUploadBidderDoc, auditRegDocUploadedFromOfficer, officerId, clientId);
		}
		return pageView;
	}

	/**
	 * @author um@ng.rathod
	 * @param request @ Officer remove Bidder Doc
	 */
	@RequestMapping(value = "/RemoveDocFromOfficer", method = RequestMethod.POST)
	public String deleteDocumentFromOfficer(HttpServletRequest request, HttpSession session,
			RedirectAttributes redirectAttributes) {
		int bidderDocId = 0;
		int userId = 0;
		int officerId = 0;
		String pageView = null;
		try {
			bidderDocId = Integer.parseInt(request.getParameter("hdbidderDocId"));
			userId = Integer.parseInt(request.getParameter("userId"));
			officerId = abcUtility.getSessionUserId(request);
			List<Object[]> docDetails = manageBidderService.getDocumentDetailsByBidderDocId(bidderDocId);
			if (!docDetails.isEmpty()) {

				String documentPath = tmpPath + docDetails.get(0)[0].toString();

				File file = new File(documentPath);
				file = abcUtility.CheckDirExist(file);
				if (file.exists()) {
					file.delete();
				}

				manageBidderService.deleteDocumentByBidderDocId(bidderDocId);
				redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),
						"file_removed_successfully");
			}
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					lnkOfficerUploadBidderDoc, auditRemoveRegDocFromOfficer, 0, officerId);
		}
		pageView = "common/admin/uploadDocument/" + userId;
		pageView = "redirect:/" + pageView + encryptDecryptUtils.generateRedirect(pageView, request);

		return pageView;
	}

	@RequestMapping(value = { "/gstDetails/{objectId}", "/gstDetails/{objectId}/{enc}" }, method = RequestMethod.GET)
	public String getGSTDetails(HttpServletRequest request, ModelMap map, @PathVariable("objectId") int bidderId,
			HttpServletResponse response, HttpSession session) {
		ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
		String pageName = "";
		int clientId = 0;
		boolean isGstEntered = false;
		StringBuilder allowedExt = new StringBuilder();
		int allowedSize = 0;
		int userId = 0;
		try {
			if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null
					|| session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
				clientId = abcUtility.getSessionClientId(request);
				int gstDeclarationId = 0;
				boolean isGstReceiptUploaded = true;
				SessionBean sessionBean = null;
				map.put("isRegistrationLinkHidden",
						clientService.isRegistrationLinkHidden(clientId, hideRegistrationLinkId, 1));
				if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
					sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
				} else if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
					sessionBean = (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
				}
				int isGstRequired = Integer.parseInt(
						commonService.getField("TblClient", "isGSTRequired", "clientId", clientBean.getClientId()));
				List<SelectItem> selTaxClassification = commonService.getTaxClassification();
				map.addAttribute("selGSTDetailsRequired", selTaxClassification);
				List<SelectItem> selGstDeclaration = commonService.getGstDeclaration();
				map.addAttribute("selGstDeclaration", selGstDeclaration);
				map.addAttribute("isGstDeclaration", 1);
				if (sessionBean.getUserTypeId() == 1) {
					userId = bidderId;
				} else if (sessionBean.getUserTypeId() == 2) {
					userId = sessionBean.getUserId();
				}
				if (sessionBean.getUserTypeId() == 1 && bidderId != 0) {
					map.addAttribute("homeUrl", "common/admin/managebidder");
				} else if (sessionBean.getUserTypeId() == 2 && bidderId != 0) {
					map.addAttribute("homeUrl", getDeafultListringPageName(clientId, userId, map, request));
				}
				int companyId = commonService.getCompanyId(userId, clientId);
				String stateCode = commonService.getStateCodeByStateId(commonService.getStateIdByCompanyId(companyId));
				map.addAttribute("stateCode", stateCode);
				Object[] obj = manageBidderService.getGstFields("TblBidderGstDetails", userId, clientId,
						"gstTaxClassification,gstNo,gstDeclarationId,panNo,reason");
				List<Object[]> lstGstReceipt = manageBidderService.getBidderGstReceipt(userId, clientId);
				if (!lstGstReceipt.isEmpty()) {
					map.addAttribute("gstDocumentList", lstGstReceipt);
					map.addAttribute("documentListForBidder", lstGstReceipt.get(0));
				}
				List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventGstDoc, clientId);
				if (lstDocUploadConf != null) {
					allowedSize = lstDocUploadConf.get(0).getMaxSize();
					allowedExt.append(lstDocUploadConf.get(0).getType());

					int index = allowedExt.toString().indexOf(",");
					allowedExt.insert(index + 1, "*.");
					while (index >= 0) {
						index = allowedExt.toString().indexOf(",", index + ",".length());
						allowedExt.insert(index + 1, "*.");
					}
				}
				pageName = "/common/admin/GstDetails";
				if (obj != null) {
					int getTaxClassification = (Integer) obj[0];
					if (getTaxClassification == 1) {
						if (obj[1] != null) {
							if (!"".equalsIgnoreCase(obj[1].toString())) {
								if (lstGstReceipt != null && !lstGstReceipt.isEmpty()) {
									isGstEntered = true;
								} else {
									isGstEntered = true;
									isGstReceiptUploaded = false;
								}
							} else {
								isGstEntered = false;
							}
						} else {
							isGstEntered = false;
						}
					} else if (getTaxClassification == 2) {
						gstDeclarationId = (Integer) obj[2];
						if (gstDeclarationId != 0) {
							isGstEntered = true;
						} else {
							isGstEntered = false;
						}
					} else {
						isGstEntered = false;
					}
				}
				map.addAttribute("objectId", userId);
				if (isGstEntered) {
					int regWorkflowId = manageBidderService.getClientRegWorkflowId(clientId, 7);
					map.addAttribute("clientRegWorkflowId", regWorkflowId);

				}
				map.addAttribute("bidderId", bidderId);
				map.addAttribute("GstField", obj);
				map.addAttribute("isGstReceiptUploaded", isGstReceiptUploaded);
				map.addAttribute("isGstEntered", isGstEntered);
				map.addAttribute("allowedSize", allowedSize / 1024);
				map.addAttribute("allowedExt", allowedExt.toString());
				map.addAttribute("clientId", clientId);

				if (isGstRequired == 0 || commonService.getCountryIdByCompanyId(companyId) != countryId) {
					pageName = "redirect:/finishregistration";
				} else {
					pageName = "/common/admin/GstDetails";
				}
			} else {
				pageName = "redirect:/loginfailed";
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					linkGstDocConfig, auditGstDetailsPage, userId, clientId);
		}
		return pageName; /* /Web/src/main/webapp/WEB-INF/jsp/common/admin/GstDetails.jsp */
	}

	@RequestMapping(value = "/submitGstDetails", method = RequestMethod.POST)
	public String submitGstDetails(HttpSession session, HttpServletRequest request,
			RedirectAttributes redirectAttributes, ModelMap map) {
		String pageView = null;
		int clientId = 0;
		int userId = 0;
		String pageName = "";
		try {
			clientId = abcUtility.getSessionClientId(request);
			int previousGstTax = 0;
			String GstNo = "";
			String opType = "";
			int isGstEntered = 0;
			String reason = "";
			int docId = 0;
			int previousGstDeclaration = 0;
			String previousGstNo = request.getParameter("previousGstNo");
			if (request.getParameter("previousGstTax") != null
					&& !"".equalsIgnoreCase(request.getParameter("previousGstTax"))) {
				previousGstTax = Integer.parseInt(request.getParameter("previousGstTax"));
			}
			opType = request.getParameter("opType");
			if (request.getParameter("previousGstDeclaration") != null
					&& !"".equalsIgnoreCase(request.getParameter("previousGstDeclaration"))) {
				previousGstDeclaration = Integer.parseInt(request.getParameter("previousGstDeclaration"));
			}
			if (request.getParameter("isGstEntered") != null
					&& !"".equalsIgnoreCase(request.getParameter("isGstEntered"))) {
				isGstEntered = Integer.parseInt(request.getParameter("isGstEntered"));
			}
			if (request.getParameter("userId") != null) {
				userId = Integer.parseInt(request.getParameter("userId").toString());
			}

			int selGstTaxClassification = Integer.parseInt(request.getParameter("selgstTaxClassification"));
			int rdGstDeclarationId = 0;
			if (selGstTaxClassification == 2) {
				rdGstDeclarationId = Integer.parseInt(request.getParameter("rdgstDeclaration"));
			} else if (selGstTaxClassification == 1) {
				GstNo = request.getParameter("txtGstNo");
			}
			if (rdGstDeclarationId == 4) {
				reason = request.getParameter("txtreason");
			}
			String Pan = request.getParameter("txtpanNo");
			boolean isGstChanged = false;
			if (previousGstTax != selGstTaxClassification) {
				isGstChanged = true;
			} else if (!previousGstNo.equalsIgnoreCase(GstNo) && !"".equals(GstNo) && !"".equals(previousGstNo)
					&& previousGstNo != null && GstNo != null) {
				isGstChanged = true;
			} else if (rdGstDeclarationId != 0 && previousGstDeclaration != rdGstDeclarationId) {
				isGstChanged = true;
			}
			boolean bSuccess = false;
			if ("Edit".equalsIgnoreCase(opType) && isGstEntered == 1) {
				TblBidderGstDetails tblBidderGstDetails = new TblBidderGstDetails();
				bSuccess = manageBidderService.updateGstDetails(userId, tblBidderGstDetails, isGstChanged, Pan, GstNo,
						clientId, selGstTaxClassification, rdGstDeclarationId, reason);
			} else {
				TblBidderGstDetails tblBidderGstDetails = new TblBidderGstDetails();
				tblBidderGstDetails.setPanNo(Pan);
				tblBidderGstDetails.setGstNo(GstNo);
				tblBidderGstDetails.setTblClient(new TblClient(clientId));
				tblBidderGstDetails.setTblUserLogin(new TblUserLogin(userId));
				tblBidderGstDetails.setTblCompany(new TblCompany(commonService.getCompanyId(userId, clientId)));
				tblBidderGstDetails.setGstTaxClassification(selGstTaxClassification);
				tblBidderGstDetails.setGstDeclarationId(rdGstDeclarationId);
				tblBidderGstDetails.setReason(reason);
				tblBidderGstDetails.setCstatus(1);
				tblBidderGstDetails.setCreatedBy(userId);
				tblBidderGstDetails.setCreatedOn(commonService.getServerDateTime());
				tblBidderGstDetails.setUpdatedBy(userId);
				tblBidderGstDetails.setUpdatedOn(commonService.getServerDateTime());
				manageBidderService.addBidderGstDetails(tblBidderGstDetails);
				bSuccess = true;
			}
			if (selGstTaxClassification == 2 && isGstChanged) {
				List<Object[]> lstGstReceipt = manageBidderService.getBidderGstReceipt(userId, clientId);
				for (int i = 0; i < lstGstReceipt.size(); i++) {
					docId = (Integer) lstGstReceipt.get(i)[3];
					List<Object[]> docDetails = manageBidderService.getGstReceiptByBidderDocId(docId);
					if (!docDetails.isEmpty()) {

						String documentPath = tmpPath + docDetails.get(0)[0].toString();
						documentPath = documentPath + "\\" + docDetails.get(0)[2].toString();
						File file = new File(documentPath);
						file = abcUtility.CheckDirExist(file);
						if (file.exists()) {
							file.delete();
						}
						bSuccess = manageBidderService.updateBidderGSTDocForRemove(docId, 2);
					}

				}
			}
			if (bSuccess) {
				redirectAttributes.addFlashAttribute("successMsg", "msg_gst_details_submitted");

			}
			if ("Edit".equalsIgnoreCase(opType)) {
				if (abcUtility.getSessionUserTypeId(request) == 1) {
					pageView = "redirect:/common/admin/managebidder"
							+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
				} else if (abcUtility.getSessionUserTypeId(request) == 2) {
					pageName = getDeafultListringPageName(clientId, userId, map, request);
					pageView = "redirect:/" + pageName + encryptDecryptUtils.generateRedirect(pageName, request);
				}
			} else {
				pageView = "redirect:/gstDetails/0";
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					linkGstDocConfig, auditSubmitGstDetails, userId, clientId);
		}
		return pageView;
	}

	@RequestMapping(value = "/downloadGstReceipt", method = RequestMethod.POST)
	public void downloadBidderGstReceipt(ModelMap modelMap, HttpServletResponse response, HttpServletRequest request) {
		String documentPath = tmpPath;
		int fileSize = 0;
		InputStream fis = null;
		ServletOutputStream outputStream = null;
		int bidderDocId = Integer.parseInt(request.getParameter("hdgstDocbidderDocId"));
		try {
			List<Object[]> docDetails = manageBidderService.getGstReceiptByBidderDocId(bidderDocId);
			if (!docDetails.isEmpty()) {
				Object[] obj = docDetails.get(0);
				if (obj != null) {
					documentPath += obj[0].toString();
					documentPath = documentPath + "\\" + obj[2];
					fileSize = Integer.parseInt(obj[1].toString());
					File file = new File(documentPath);
					file = abcUtility.CheckDirExist(file);
					if (file.exists()) {
						fis = new FileInputStream(file);
						byte[] buf = new byte[fileSize];// obj[1]=filsize
						int offset = 0;
						int numRead = 0;
						while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
							offset += numRead;
						}
						response.setContentType("application/octet-stream");
						response.setHeader("Content-Disposition", "attachment;filename=\""
								+ documentPath.substring(documentPath.lastIndexOf('\\') + 1) + "\"");
						outputStream = response.getOutputStream();
						outputStream.write(buf);
						outputStream.flush();
						fis.close();
					}
				}
			}
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		} finally {
			try {
				if (fis != null) {
					fis.close();
				}
				if (outputStream != null) {
					outputStream.close();
				}
			} catch (IOException e) {
				exceptionHandlerService.writeLog(e);
			}
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					linkGstDocConfig, auditDownloadGstReceipt, 0, bidderDocId);
		}
	}

	@RequestMapping(value = "/RemoveGstReceipt", method = RequestMethod.POST)
	public String deleteGstReceipt(HttpServletRequest request, HttpSession session,
			RedirectAttributes redirectAttributes) {
		int bidderDocId = 0;
		try {
			bidderDocId = Integer.parseInt(request.getParameter("hdgstDocbidderDocId"));
			int objectId = StringUtils.hasLength(request.getParameter("txtobjectId"))
					? Integer.parseInt(request.getParameter("txtobjectId"))
					: 0;
			int clientId = StringUtils.hasLength(request.getParameter("txtClientId"))
					? Integer.parseInt(request.getParameter("txtClientId"))
					: 0;
			List<Object[]> lstGstReceipt = manageBidderService.getBidderGstReceipt(objectId, clientId);
			String docIds = "";
			for (int i = 0; i < lstGstReceipt.size(); i++) {
				docIds += lstGstReceipt.get(i)[3].toString() + ",";
			}
			docIds = docIds.substring(0, docIds.lastIndexOf(","));
			List<Object[]> docDetails = manageBidderService.getGstReceiptByBidderDocId(bidderDocId);
			if (!docDetails.isEmpty()) {

				String documentPath = tmpPath + docDetails.get(0)[0].toString();
				documentPath = documentPath + "\\" + docDetails.get(0)[2].toString();
				File file = new File(documentPath);
				file = abcUtility.CheckDirExist(file);
				if (file.exists()) {
					file.delete();
				}

				manageBidderService.deleteGstReceiptyBidderDocId(bidderDocId);
				redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),
						"file_removed_successfully");
			}
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					linkGstDocConfig, auditRemoveGstReceipt, 0, bidderDocId);
		}

		return "redirect:/gstDetails/0";
	}

	private String getDeafultListringPageName(int clientId, int userId, ModelMap map, HttpServletRequest request)
			throws Exception {
		List<Object> moduleIds = clientService.getDefaultModuleId(clientId);
		String defModuleId = moduleIds.get(0).toString();
		String pageName = "";
		ClientBean clientBean = (ClientBean) (request.getSession()
				.getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null
						? request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString())
						: null);

		if ("3".equalsIgnoreCase(defModuleId)) { /* Tender */
			pageName = "etender/bidder/tenderlisting/0";
		} else if ("5".equalsIgnoreCase(defModuleId)) /* Auction */
		{
			if (clientBean.getIsDIYClient() == 1) {
				pageName = "eauction/bidder/quickauctionlisting";
			} else {
				pageName = "eauction/bidder/auctionlisting";
			}

		} else {
			pageName = "common/bidder/viewbidderprofile/" + userId;
			map.addAttribute("isDeafaultPage", true);
		}
		return pageName;
	}

	@RequestMapping(value = "/ajaxRemoveGstReceipt", method = RequestMethod.POST)
	public void removeGstReceipt(HttpServletRequest request, HttpServletResponse response, HttpSession session,
			RedirectAttributes redirectAttributes) {
		boolean delflag = false;
		int docId = 0;
		try {
			int objectId = StringUtils.hasLength(request.getParameter("txtobjectId"))
					? Integer.parseInt(request.getParameter("txtobjectId"))
					: 0;
			int clientId = StringUtils.hasLength(request.getParameter("txtClientId"))
					? Integer.parseInt(request.getParameter("txtClientId"))
					: 0;
			int cStatusDoc = StringUtils.hasLength(request.getParameter("txtcStatusDoc"))
					? Integer.parseInt(request.getParameter("txtcStatusDoc"))
					: 0;
			List<Object[]> lstGstReceipt = manageBidderService.getBidderGstReceipt(objectId, clientId);

			for (int i = 0; i < lstGstReceipt.size(); i++) {
				docId = (Integer) lstGstReceipt.get(i)[3];
				List<Object[]> docDetails = manageBidderService.getGstReceiptByBidderDocId(docId);
				if (!docDetails.isEmpty()) {

					String documentPath = tmpPath + docDetails.get(0)[0].toString();
					documentPath = documentPath + "\\" + docDetails.get(0)[2].toString();
					File file = new File(documentPath);
					file = abcUtility.CheckDirExist(file);
					if (file.exists()) {
						file.delete();
					}
					delflag = manageBidderService.updateBidderGSTDocForRemove(docId, cStatusDoc);
				}

			}
			response.getWriter().write(delflag + "");
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					linkGstDocConfig, auditRemoveGstReceipt, 0, 0);
		}
	}

	@RequestMapping(value = "/submitGstReceipt", method = RequestMethod.POST)
	public void submitGstReceipt(HttpSession session, HttpServletResponse response, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {
		boolean isValidate = true;
		String pageView = null;
		int clientId = 0;
		int objectId = 0;
		int cStatusDoc = 0;
		try {
			int userId = 0;
			PrintWriter out = response.getWriter();
			objectId = StringUtils.hasLength(request.getParameter("txtobjectId"))
					? Integer.parseInt(request.getParameter("txtobjectId"))
					: 0;
			clientId = StringUtils.hasLength(request.getParameter("txtClientId"))
					? Integer.parseInt(request.getParameter("txtClientId"))
					: 0;
			cStatusDoc = StringUtils.hasLength(request.getParameter("txtcStatusDoc"))
					? Integer.parseInt(request.getParameter("txtcStatusDoc"))
					: 0;
			String description = StringUtils.hasLength(request.getParameter("txtDocDesc"))
					? request.getParameter("txtDocDesc")
					: null;
			List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventGstDoc, clientId);
			TblDocUploadConf tblDocUploadConf = lstDocUploadConf.get(0);
			Object sessionBean = session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
			response.setContentType("text/html");
			if (sessionBean != null) {
				userId = ((SessionBean) sessionBean).getUserId();
			} else if (session.getAttribute("sessionObject") != null) {
				sessionBean = session.getAttribute("sessionObject");
				userId = abcUtility.getSessionUserId(request);
			}
			List<Object[]> list = null;
			boolean fileUploadedSuccess = false;
			String result = "";
			File file = null;
			File tmpDir = null;
			File tmpDir2;
			String fileDir = "";
			long fileSize = 0;
			String fileName = "";
			long fileMaxSize = 0;
			String fileExtensions = null;
			String documentName = null;
			int maxFileUploadLimit = 0;
			String fileDesc = null;
			String path = lstDocUploadConf.get(0).getPath();
			String tmpDirPath = tmpPath + path;
			boolean success = false;
			if (!lstDocUploadConf.isEmpty()) {
				fileMaxSize = lstDocUploadConf.get(0).getMaxSize() * 1024;
				fileExtensions = lstDocUploadConf.get(0).getType();
				maxFileUploadLimit = lstDocUploadConf.get(0).getMaxLimit();
			}
			DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
			fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
			ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
			List items = uploadHandler.parseRequest(request);
			Iterator itr = items.iterator();
			while (itr.hasNext()) {
				if (description == null) {
					isValidate = false;
					result = messageSource.getMessage("msg_docbrief_empty", null, LocaleContextHolder.getLocale());
					break;
				}
				FileItem item = (FileItem) itr.next();
				if (item.isFormField()) {
					if (item.getFieldName().equals("txtDocDesc")) {
						fileDesc = item.getString();
						if (fileDesc == null || "".equalsIgnoreCase(fileDesc.trim())) {
							isValidate = false;
							break;
						}
					}
				} else {
					fileSize = item.getSize();
					if (item.getName().lastIndexOf("\\") != -1) {
						fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1,
								item.getName().length());
					} else {
						fileName = item.getName();
					}
					documentName = new String(fileName);
					if (StringUtils.hasLength(fileName)) {
						if (fileSize == 0) {
							result = messageSource.getMessage("msg_validation_filewithzerokb", null,
									LocaleContextHolder.getLocale());
							isValidate = false;
							break;
						}
						if (!checkFileSize(fileSize, fileMaxSize)) {
							result = messageSource.getMessage("msg_filesizeexceeds",
									new Object[] { fileMaxSize / (1024 * 1024) }, LocaleContextHolder.getLocale());
							isValidate = false;
							break;
						}
						if (!checkFileExn(fileName, fileExtensions)) {
							StringBuilder allowedExt = new StringBuilder();
							if (!lstDocUploadConf.isEmpty()) {
								allowedExt.append(lstDocUploadConf.get(0).getType());
							}
							int index = allowedExt.toString().indexOf(",");
							allowedExt.insert(index + 1, "*.");
							while (index >= 0) {
								index = allowedExt.toString().indexOf(",", index + ",".length());
								allowedExt.insert(index + 1, "*.");
							}
							result = messageSource.getMessage("msg_acceptablefiletypes", new Object[] { allowedExt },
									LocaleContextHolder.getLocale());
							isValidate = false;
							break;
						} else {

							fileDir = String.valueOf(objectId);
							tmpDir = new File(tmpDirPath + "\\" + fileDir);

							isDirExists(tmpDir.getAbsolutePath());

							file = new File(tmpDir, fileName);
							if (abcUtility.ValidationForFileExist(file)) {
								result = messageSource.getMessage("msg_fileexists", null,
										LocaleContextHolder.getLocale());
								isValidate = false;
								break;
							}
							item.write(file);
							fileSize = fileEncryptDecryptUtil.fileEncryptUtil(file, (int) fileSize);
							fileUploadedSuccess = true;
							if (isValidate) {
								if (fileUploadedSuccess) {

									TblBidderDocument tblBidderDocument = new TblBidderDocument();
									tblBidderDocument.setDocName(fileName);
									tblBidderDocument.setTblClient(new TblClient(clientId));
									tblBidderDocument.setBidderFolderId(1);
									tblBidderDocument.setPath(path + "\\" + fileDir);
									tblBidderDocument.setDescription(description);
									tblBidderDocument.setFileSize(fileSize);
									tblBidderDocument.setCreatedBy(userId);
									tblBidderDocument.setCstatus(1);

									if (manageBidderService.addBidderDocument(tblBidderDocument)) {

										TblBidderDocMapping tblBidderDocMapping = new TblBidderDocMapping();
										tblBidderDocMapping.setTblBidderDocument(
												new TblBidderDocument(tblBidderDocument.getBidderDocId()));
										tblBidderDocMapping.setObjectId(objectId);
										tblBidderDocMapping.setDocumentId(0);
										tblBidderDocMapping.setDocumentName("");
										tblBidderDocMapping.setTblLink(new TblLink(linkGstDocConfig));
										tblBidderDocMapping.setChildId(0);
										tblBidderDocMapping.setMappedBy(userId);
										tblBidderDocMapping.setCstatus(1);
										tblBidderDocMapping.setTblCompany(new TblCompany(Integer
												.parseInt(commonService.getCompanyIdByUserId(objectId).toString())));
										manageBidderService.addBidderDocMapping(tblBidderDocMapping);
										success = true;
										result = success + "";
									}
									out.print(result.trim());

								} else {
									out.print("Error:" + result);
								}
							} else {
								out.print("Error:" + result);
							}

						}
						// }

					}
				}
			}
		}

		catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					linkGstDocConfig, auditSubmitGstDetails, objectId, clientId);
		}
	}
	
	//apeksha

		@RequestMapping(value = "/bidderregistrationByAdmin/{userId}/{companyId}/{enc}",method = RequestMethod.GET)
		public String addminBidder(@PathVariable("userId") long userId, @PathVariable("companyId") long companyId, HttpServletRequest request, HttpServletResponse response, ModelMap map) {
			String retVal = null;			
			
			try {
				String publicKey = null;
				
				BidderRegistrationDataBean bidderRegistrationDataBean = new BidderRegistrationDataBean();
				String editBidderData = commonService.getUserData(userId);
				 bidderRegistrationDataBean.setTxtEmailIdFirst(editBidderData.toString());
				 bidderRegistrationDataBean.setTxtFullName(editBidderData.toString());
				 map.put("userId", userId);
				 map.put("isAdminBidder", commonService.getBidderStatus(userId));
				 
				 bidderRegistrationDataBean.setIsAdminBidder(commonService.getBidderStatus(userId)==true?"1" :"0");
				 Object[] getCompanyData = commonService.getOfficerCompanyData(companyId);
				 bidderRegistrationDataBean.setTxtCompanyName(getCompanyData[0].toString());
				 bidderRegistrationDataBean.setTxtaAddress(getCompanyData[1].toString());
				 map.put("companyId", companyId);
				 map.put("captchaHtml", AbcCaptchaFactory.newAbcCaptcha(0));
				
				map.put("lstClientMarquee", clientService.getClientMarqueeBylocation(
						(int) abcUtility.getSessionClientId(request), 3));/* For After Loging Marque */
				
				List<Object[]> clientDetails = commonService
						.getClientCountryStateTimezone(abcUtility.getSessionClientId(request));
				if (clientDetails != null && !clientDetails.isEmpty()) {
					
					bidderRegistrationDataBean.setSelTimezone(Integer.parseInt(clientDetails.get(0)[0].toString()));

				}
				String langId = WebUtils.getCookie(request, "locale").getValue();
				//map.addAttribute("BusinessCategoryList", commonService.getBusinessCategory());
				
				map.put("timezoneList", modelToSelectItem.convertListIntoSelectItemList(commonService.getTimeZoneList(),
						"timeZoneId", "lang" + langId));
				map.put("hintQueList", modelToSelectItem.convertListIntoSelectItemList(commonService.getHintQuestionList(),
						"hintQuestionId", "lang" + langId));
				map.put("publicKey", publicKey);
				map.put("isRegisterAddmin", true);
				map.addAttribute("opType", "create");
				int clientId = abcUtility.getSessionClientId(request);
				int objectId = abcUtility.getSessionUserId(request);
				map.addAttribute("clientId", clientId);
				map.addAttribute("objectId", objectId);
				map.addAttribute("linkId", manageBidderFieldValueId);
				map.addAttribute("dynFieldMap",
						dynamicFieldService.setDynamicField(manageBidderFieldValueId, clientId, objectId));

				if (abcUtility.isModuleAssignToClient(request, 9)) { // spend analysis module. PT: 20745
					map.put("isCategoryAllow", commonService.isCategoryAllow(abcUtility.getSessionClientId(request)));
				} else {
					map.put("isCategoryAllow", 0);
				}
				map.addAttribute("isClientSectorApplicable", manageBidderService.isClientSectorApplicable(clientId));
				List<SelectItem> isCompanyName = new ArrayList<SelectItem>();
				isCompanyName.add(new SelectItem("Company Name", 1));
				isCompanyName.add(new SelectItem("Individual Name", 0));
				map.addAttribute("isCompanyName", isCompanyName);
				map.addAttribute("isSelCompanyName", 1);
				map.addAttribute("bidderRegistrationDataBean", bidderRegistrationDataBean);
				List<Object[]> clientCountryStateTimezone = commonService.getClientCountryStateTimezone(clientId);
				TblTimeZone tblTimeZone = commonService.getTimezoneById(Integer.valueOf(clientCountryStateTimezone.get(0)[0].toString()));
				map.addAttribute("strTimeZone", tblTimeZone.getLang1());
				
				retVal = "BidderRegistration";
				
				
			}

			catch (Exception ex) {
				return exceptionHandlerService.writeLog(ex);
			} finally {
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
						registrationLinkId, auditBidderRegistration, 0, 0);
			}
			return retVal;
		}
		
		//apeksha
		@RequestMapping(value = "/addbidderbyadmin", method = RequestMethod.POST)
		public String addBidderbyAdmin(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean,
				BindingResult result, HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes,
				ModelMap modelMap) {
			String isAdmin=request.getParameter("isAdminBidder");
			String password= bidderRegistrationDataBean.getTxtUserPassword();			
			String hintque=bidderRegistrationDataBean.getSelHintQue();
			String hintAns=bidderRegistrationDataBean.getTxtHintAns();
			//String isAdmin =bidderRegistrationDataBean.getIsAdminBidder();
			String phone=bidderRegistrationDataBean.getTxtPhone();
			String Address=bidderRegistrationDataBean.getTxtaAddress();
			String mobile=bidderRegistrationDataBean.getTxtMobileNo();

			boolean success = false;
			String retVal = null;
			int userId=Integer.valueOf(request.getParameter("hdUserId"));
			int companyId=Integer.valueOf(request.getParameter("hdCompanyId"));
			int clientId = abcUtility.getSessionClientId(request);
			int contentManagementId = 0;
			String selectedCategory[] = null; // PT: 20745
			String isCategoryAllow = "0";
			  String cnt = request.getParameter("countBidder"); 
			  int countOfMapSubBidder =	  Integer.parseInt(cnt);
			  int zone=0;
			try {
				zone = Integer.valueOf(commonService.getClientCountryStateTimezone(clientId).get(0)[0].toString());
			} catch (NumberFormatException e) {
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}
			bidderRegistrationDataBean.setSelTimezone(zone);
			try{				
				bidderRegistrationDataBean.setCommonValidators(commonValidators);
				selectedCategory = request.getParameterValues("txtCategory");
				isCategoryAllow = request.getParameter("hdIsCategoryAllow");
				List<Object> busCatKeywords = null;
				List<LinkedHashMap<String, Object>> list = commonService.checkValidUserInClient(clientId, bidderRegistrationDataBean.getTxtEmailId(), 2);
				  String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR)
							: request.getRemoteAddr();
				   
				int actionType = 0;
				int bidderId = 0;
				int officerId = 0;
				if(list != null && !list.isEmpty()) {
					Map<String, Object> map  = list.get(0);
					if(map.get("actionType") != null) {
					actionType = Integer.parseInt(map.get("actionType").toString());
					bidderId = Integer.parseInt(map.get("bidderId").toString());
					officerId = Integer.parseInt(map.get("officerId").toString());
					}
				}				
				//Bug #33494 By Jitendra. If category is allow then getting keyword names from keyword ids and set in bidderRegistrationDataBean model. 
				if(isCategoryAllow != null && isCategoryAllow.equals("1") && selectedCategory != null){
					busCatKeywords = commonService.getKeywordNamesByIds(selectedCategory);
					bidderRegistrationDataBean.setTxtaBusCatKeywords(abcUtility.converObjectArrayToCommas(busCatKeywords));
				}				
				boolean isCheckPassword = false;
				if(actionType == 1) {
					//pass = UUID.randomUUID().toString().substring(0, 4)+"@"+UUID.randomUUID().toString().substring(0, 4);
					String encryptedPassword = sha256HashEncryption.encodeStringSHA256(password);
					bidderRegistrationDataBean.setTxtUserPassword(encryptedPassword);
					bidderRegistrationDataBean.setTxtConfirmPassword(encryptedPassword);
					
					isCheckPassword = true;
				}
           if(actionType==2 && bidderId>0) {
					result.rejectValue("txtEmailId", "msg_js_registration_bidderexists", "Email id already registered as bidder on this domain");
				} else if(actionType==2 && officerId>0) {
					result.rejectValue("txtEmailId", "msg_js_registration_officerexists", "Email id already registered as department user on this domain");
				}
				
				if(actionType == 3) {
					success = manageBidderService.addBidderWithProfileInOtherDomain(clientId ,bidderId,false,0,0);
					retVal = "redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
				} 
				else if(actionType!=3 && actionType!=2) {
					int bidderVerificationBy =  clientService.getBidderRegistrationVerifiedBy(clientId);
					String verificationCode = null;
					if(bidderVerificationBy != 0 && bidderVerificationBy != 3) {
						verificationCode=UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
					} else {
						verificationCode="0";
					}
					
					TblUserLogin tblUserLogin = null;
					int registrationWorkflowId = 0;
					if(actionType == 4) {
						List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(officerId);
						if(tblUserLogins!=null && !tblUserLogins.isEmpty()) {
							tblUserLogin = tblUserLogins.get(0);
						}
						registrationWorkflowId = manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), tblUserLogin.getIsEmailVerified()==1? 3 : 0);
					} else {
						tblUserLogin = bidderRegistrationDataBean._toTblUserLogin(bidderVerificationBy, verificationCode, abcUtility.getSessionUserId(request), 1);
						tblUserLogin.setTblClient(new TblClient(clientId));
						registrationWorkflowId = manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), 0);
						if(bidderVerificationBy == 3){
							tblUserLogin.setIsEmailVerified(1);
							tblUserLogin.setIsMobileNoVerified(1);
							registrationWorkflowId=manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), 3);
						}
					}
					
					tblUserLogin.setTblHintQuestion(new TblHintQuestion(1));
					tblUserLogin.setHintAnswer(sha256HashEncryption.encodeStringSHA256("abc"));
					
					if(tblUserLogin.getPasswordUpdatedOn()==null){
						tblUserLogin.setPasswordUpdatedOn(commonService.getServerDateTime());
					}

					int cstatus = cstatusIncomplete;
					if(registrationWorkflowId == 9) {
						cstatus=cstatusPending;
					}
					int isAutoApprove= Integer.parseInt(commonService.getField("TblClient", "isTwoStepBidderApproval", "clientId", clientId));
					if(isAutoApprove==2){
						registrationWorkflowId=9;
						cstatus=1;
					}
					//For CR #25825 - Keval Soni
					if(rciClientIds != null && !"".equals(rciClientIds)){
						String[] rciIds = rciClientIds.split(",");
						if(rciIds.length != 0){
							for(int i = 0;i<rciIds.length;i++){
								if(!"".equals(rciIds[i])){
									if(clientId == Integer.parseInt(rciIds[i])){
										if(actionType == 1){
											int clientCountryId=clientService.getCountryIdByClientId(clientId);
											int bidderCountryId=Integer.parseInt(request.getParameter("selCountry"));
											if(clientCountryId != bidderCountryId && registrationWorkflowId == 5){
												registrationWorkflowId=8;
												break;
											}
										}
									}
								}
							}
						}
					}

					
					contentManagementId = StringUtils.hasLength(request.getParameter("hdContentManagementId"))?Integer.parseInt(request.getParameter("hdContentManagementId").toString()):0;
					TblBidderStatus tblBidderStatus = bidderRegistrationDataBean._toTblBidderStatus(clientId, cstatus, abcUtility.getSessionUserId(request),contentManagementId);
					tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(4));
					TblPasswordHistory tblPasswordHistory = new TblPasswordHistory(); //Bug:18917
			        tblPasswordHistory.setCreatedOn(commonService.getServerDateTime());
			        tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
			        tblPasswordHistory.setPasswordUpdatedFrom(4);
			        
			        tblBidderStatus.setIsAdminBidder(1);
			        tblBidderStatus.setIsParentBidderId(0);
			     
			       
			        tblUserLogin.setLoginId("");
			        tblUserLogin.setIpAddress("");
			        bidderRegistrationDataBean.setTxtFullNameFirst(request.getParameter("txtFullName"));
			        tblUserLogin.setHintAnswer(hintAns);
			        tblUserLogin.setIsFirstLogin(0);
			        TblCompany tblCompany = tblCompanyDao.findTblCompany("companyId",Operation_enum.EQ,companyId).get(0);
			        tblCompany.setPhoneNo(phone);
			        // update
			        success = manageBidderService.updateRegistrationByMainUser(isCheckPassword,bidderVerificationBy, verificationCode, bidderRegistrationDataBean,
							tblUserLogin,tblCompany, bidderRegistrationDataBean._toTblUserHistory(userHistoryCreate, clientId), 
							bidderRegistrationDataBean.getTxtaBusCatKeywords(), success, abcUtility.getSessionUserId(request), success,
							clientId,userId,companyId);
			        
			        //Sub bidder info 
				
					ArrayList<BidderRegistrationDataBean> bidderList = new ArrayList<>();
					 for (int i = 0; i <=countOfMapSubBidder - 1; i++) { 
						 
						 BidderRegistrationDataBean bidderRegistrationDataBean1 = new BidderRegistrationDataBean();
						String email=request.getParameter("txtEmailId_" + (i + 1));
						String name=request.getParameter("txtFullName_" + (i + 1));
						if(email!= "" && email!=null) {
						bidderRegistrationDataBean1.setTxtEmailId(email);
						 bidderRegistrationDataBean1.setTxtFullName(name);
						 bidderRegistrationDataBean1.setTxtMobileNo(mobile);
						 bidderRegistrationDataBean1.setTxtHintAns(hintAns);
						 bidderRegistrationDataBean1.setTxtUserPassword("");
						 bidderRegistrationDataBean1.setTxtConfirmPassword("");
						 bidderRegistrationDataBean1.setSelHintQue(hintque);
						 bidderRegistrationDataBean1.setSelTimezone(zone);
						 
						 bidderRegistrationDataBean1.setTxtCity("");
						 bidderRegistrationDataBean1.setTxtWebsite("");
						 bidderRegistrationDataBean1.setTxtaAddress(Address);
						 bidderRegistrationDataBean1.setTxtPhone(phone);
						 bidderRegistrationDataBean1.setSelCountry(1);
						 bidderRegistrationDataBean1.setSelState("");
						 bidderRegistrationDataBean1.setTxtCompanyName(bidderRegistrationDataBean.getTxtCompanyName());
						 
						 List<Object[]> clientDetails = commonService.getClientCountryStateTimezone(clientId);						 
							if (clientDetails != null && !clientDetails.isEmpty()) {
								bidderRegistrationDataBean1.setSelTimezone(Integer.parseInt(clientDetails.get(0)[0].toString()));
								bidderRegistrationDataBean1.setSelCountry(Integer.parseInt(clientDetails.get(0)[1].toString()));
								bidderRegistrationDataBean1.setSelState(clientDetails.get(0)[2].toString());
							}
													                                              
							addBidderSubBidder(bidderRegistrationDataBean1, result, request, redirectAttributes, modelMap,userId,companyId);
							bidderRegistrationDataBean1.setHdBidderId(bidderId);
						 bidderList.add(bidderRegistrationDataBean1);
					 }					
					  }		
					        			    	
		    		success = dynamicFieldService.addDynamicFieldValueProcess(dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request),clientId,manageBidderFieldValueId,userId,userId);
		    		
//		    		SessionBean sessionBean = new SessionBean();
//    				sessionBean.setUserId(userId);
//    				request.getSession().setAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString(),sessionBean);
					retVal = "redirect:/certimap";
		    		TblUserLogin tblUserLogin2 = null;
		            boolean loginSuccess = false;
		            boolean isFirstLogin = false;
		            boolean isChngPass = false;
		            SessionBean bean = null;
		            int clientId2 = 0;
		            boolean pkiRequired = false;
		            boolean isEventSpecific = false;
		            int clientRegWorkflowId = 0;
		            Date serverDate = null;
		            ClientBean clientBean = null;
		            String userName = "";
		            int isCaptchaConfigured = 0;
		            int bidderCstatus=0;
		            int userTypeId=0;
		            boolean isGstEntered = true;
		            
		            if (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) {
		                clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
		                clientId2 = clientBean.getClientId();
		                pkiRequired = (clientBean.getIsPkiEnabled() == 1);
		                isEventSpecific = (clientBean.getIsPkiEnabled() == 2);
		            }
		            try {
		            String ipAddress2 = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
	                TblTrackLogin trackLogin = new TblTrackLogin();
//	                userName = loginService.getLoginIdByUserId(tblUserLogin.getUserId()).get(0).toString();
	                userName=request.getParameter("txtEmailIdFirst");
	                tblUserLogin2 = loginService.getUserLoginByLoginId(userName);
	                trackLogin.setBrowserType(request.getHeader("User-Agent"));
	                trackLogin.setIpAddress(ipAddress2);
	                trackLogin.setOperatingSystem(request.getHeader("User-Agent"));
	                trackLogin.setTblClient(new TblClient(clientId2));
	                trackLogin.setUserId(tblUserLogin2.getUserId());
	                trackLogin.setLoginId(tblUserLogin2.getLoginId());
	                loginSuccess=true;
	                isCaptchaConfigured = (Integer) request.getSession().getAttribute("isCaptchaConfigured");
	                if (loginSuccess) {
	                	
	                	if(isCaptchaConfigured == 1 && Integer.parseInt(request.getSession().getAttribute("isCaptchaValid").toString()) == 1){
	                		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_unlockaccount");
	                	}
	                	SessionBean sessionBean = new SessionBean();
	                    sessionBean.setUserName(tblUserLogin2.getLoginId());
	                    sessionBean.setUserId(tblUserLogin2.getUserId());
	                    sessionBean.setUserTypeId(2);
                        trackLogin.setUserTypeId(sessionBean.getUserTypeId());
                        userTypeId=sessionBean.getUserTypeId();
                        sessionBean.setFullName(tblUserLogin2.getUserName());
                        sessionBean.setUserDetailId(loginService.getUserDetailId(sessionBean.getUserId(), sessionBean.getUserTypeId() == 3 ? clientId2 : sessionBean.getUserTypeId() == 2 ? 0 : -1));
                        List<Object[]> lstObj = loginService.getLstLoginDtIpAddrById(sessionBean.getUserId(), clientId2);
                        if (lstObj != null & !lstObj.isEmpty()) {
                            for (int i = 0; i < lstObj.size(); i++) {
                                Object[] object = lstObj.get(i);
                                sessionBean.setLastLoginDateTime((Date) object[0]);
                                sessionBean.setIpAddress(String.valueOf(object[1]));
                            }
                        }
                        List<Object[]> timeZone = loginService.getUserTimeZone(sessionBean.getUserId());
                        if (timeZone != null && !timeZone.isEmpty()) {
                            if(sessionBean.getUserTypeId()==1){
                                sessionBean.setTimeZoneOffset(clientBean.getTimeZone());
                                sessionBean.setTimeZoneAbbr(clientBean.getTimeZoneAbbr());                                                                                    
                            }else{
                                sessionBean.setTimeZoneOffset(timeZone.get(0)[0].toString());
                                sessionBean.setTimeZoneAbbr(timeZone.get(0)[1].toString());
                            }
                        }
                        sessionBean.setTrackLoginId(-1);
                      //Set the mail unread count
            			if(sessionBean.getUserId()!=0){
            				List<Object[]> inboxCountDetails=mailBoxService.getInboxCount(sessionBean.getUserId(),clientBean.getClientId(),sessionBean.getUserTypeId());
            				if(inboxCountDetails!=null && !inboxCountDetails.isEmpty()){
            					for(Object[] data: inboxCountDetails){
            						if(data[1].toString().equalsIgnoreCase("inbox")){
            							   sessionBean.setUnReadCount((Long)data[2]);
            							   break;
            						}
            					}
            				}
            			}
                        //Ended
                        
            			if(clientBean.getIsDIYClient() == 1){
                         	int isEmailVeriReq = sessionBean.getUserTypeId() == 2 ? clientService.getBidderRegistrationVerifiedBy(abcUtility.getSessionClientId(request)):sessionBean.getUserTypeId() == 3 ? clientService.getOfficerRegistrationVerifiedBy(abcUtility.getSessionClientId(request)):0; 	
                         	if(tblUserLogin2.getIsEmailVerified() == 0 && isEmailVeriReq == 1)
                         	{
                         		response.addCookie(new Cookie("IsEmailVerifiedForDIY", "1"));
                         	}
                         }
                        
            			if (sessionBean.getUserTypeId() == 2) {
                            clientRegWorkflowId = manageBidderService.getBidderWorkflowId(clientId2, sessionBean.getUserId());
                            bidderCstatus=manageBidderService.getBidderCstatus(clientBean.getClientId(), sessionBean.getUserId());
                            sessionBean.setCompanyId(loginService.getCompanyId(sessionBean.getUserId(), clientBean.getClientId()));
                        }
            			
            			if(bidderCstatus==1){
                        	int isGstRequired = (Integer)clientService.getClientField(clientId2, "isGSTRequired");
                        	if(isGstRequired==1){
                        		Object[] obj = manageBidderService.getGstFields("TblBidderGstDetails", sessionBean.getUserId(),clientId2 ,"gstDetailId,panNo");
                        		if(obj==null  && commonService.getCountryIdByCompanyId(sessionBean.getCompanyId())==countryId){
                        			isGstEntered = false;
                        		}
                        	}
                        }
            			
            			sessionBean.setCountryId(commonService.getCountryIdByCompanyId(sessionBean.getCompanyId()));
            			if ((clientRegWorkflowId != 0 && clientRegWorkflowId != 9) || pkiRequired) {
                            request.getSession().setAttribute(TEMPSESSIONOBJECT, sessionBean);
                        } else {
                            request.getSession().setAttribute(SESSIONOBJECT, sessionBean);
                        }
                        bean = sessionBean;
                        if (tblUserLogin2.getIsFirstLogin() == 1) {
                            isFirstLogin = true;
                        } else {
                            loginSuccess = true;
                        }
                        loginService.updateLoginStatus(0, false, tblUserLogin2.getUserId());
                        trackLogin.setRemark("Login Success");
                        trackLogin.setCstatus(1);
                        trackLogin.setUserDetailId(sessionBean.getUserDetailId());
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(tblUserLogin2.getPasswordUpdatedOn());
                        calendar.add(Calendar.DAY_OF_MONTH, passValidity);
                        serverDate = commonService.getServerDateTime();
                        isChngPass = calendar.getTime().before(serverDate);
            			
                     // Start - Task list reminder : purvesh
//                        setTaskListData(tblUserLogin.getUserId(),clientBean.getClientId(),request);
                        // End - Task list reminder : purvesh
                        
                        //Start - Lipi 
                        //Dump user in SSO from Local - not changed the pass
//                        if(CommonUtility.isSSOEnabled(request)){
//                        	wSCheckAvailService.dumpUserWithChngPwd(tblUserLogin.getUserId(),clientBean.getClientId(),sessionBean.getUserTypeId(),false);
//                        }
                        //End - Lipi
                        if(request.getSession().getAttribute("isDRT") == null){
                            List sectorList = clientService.getClientSector(clientBean.getClientId());
                            boolean isDRT = false;
                            boolean isBank = false;
                            boolean isSarfaesi = false;
                            for(Object obj : sectorList){
                                if(obj.equals(1)){
                                    isDRT = true;
                                }else if(obj.equals(2)){
                                    isSarfaesi = true;
                                }else if(obj.equals(3)){
                                    isBank = true;
                                }
                            }
                            request.getSession().setAttribute("sectorList",sectorList);
                            request.getSession().setAttribute("isDRT", isDRT);
                            request.getSession().setAttribute("isBank", isBank);
                            request.getSession().setAttribute("isSarfaesi", isSarfaesi);
                        }
	                }
//	                else {
//	                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "Your login Account has been locked because of " + failedAttempt + " consecutive failed Login attempts , please click on Forgot Password Link");
//	                    trackLogin.setRemark("Failed Login Attempt Exceeded");
//	                    trackLogin.setCstatus(0);
//	                }  
	                loginService.addTrackLogin(trackLogin);
	                if (bean != null && bean.getTrackLoginId() == -1) {
	                    bean.setTrackLoginId(trackLogin.getTrackLoginId());
	                    if ((bean.getUserTypeId()==2 && clientRegWorkflowId != 9) || pkiRequired) {
	                        request.getSession().removeAttribute(TEMPSESSIONOBJECT);
	                        request.getSession().setAttribute(TEMPSESSIONOBJECT, bean);
	                    } else {
	                        TblSession tblSession = new TblSession();
	                        tblSession.setCertId("0");
	                        tblSession.setLoginDate(serverDate != null ? serverDate : commonService.getServerDateTime());
	                        tblSession.setLogoutDate(serverDate != null ? serverDate : commonService.getServerDateTime());
	                        tblSession.setJSessionId(request.getSession().getId());
	                        tblSession.setTblTrackLogin(trackLogin);
	                        loginService.addSession(tblSession);
	                        request.getSession().removeAttribute(SESSIONOBJECT);
	                        request.getSession().setAttribute(SESSIONOBJECT, bean);
	                    }
	                
				}
		            }catch (Exception ex) {
		                tblUserLogin2 = null;
		                loginSuccess = false;
		                request.getSession().removeAttribute(TEMPSESSIONOBJECT);
		                return exceptionHandlerService.writeLog(ex);
		            } finally {
		                if (bean != null) {
//		                    auditTrailService.makeAuditTrail(new TblAuditTrail(request.getRequestURL().toString(), bean.getTrackLoginId()), loginLink,submitLoginAudit, 0, tblUserLogin != null ? tblUserLogin.getUserId() : 0);
		                }
		            }
			
					redirectAttributes.addFlashAttribute("successMsg", "redirect_success_bidder_registration");								
				//redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? successMsgCode : CommonKeywords.ERROR_MSG_KEY.toString());
			}
			}
			catch(Exception ex){
				return exceptionHandlerService.writeLog(ex);
			} finally {
				if(clientId==1){
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), registrationLinkId, success ? auditBidderRegistered : auditBidderRegistered, 0, userId, "",request.getParameter("skpSignText"));
				} else {
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), registrationLinkId, success ? auditBidderRegistered : auditBidderRegistered, 0, userId);
				}
			}
			return retVal;
		}				
		public String addBidderSubBidder(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean,
				BindingResult result, HttpServletRequest request, RedirectAttributes redirectAttributes,ModelMap modelMap, int parentUserId, int parentcompanyId) {
			boolean success = false;
			String retVal = "";
			int userId = 0;
			int clientId = abcUtility.getSessionClientId(request);
			int contentManagementId = 0;
			String selectedCategory[] = null;
			String isCategoryAllow = "0";
			List<Object> busCatKeywords = null;
		
			ClientBean clientBean = (ClientBean) (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null
							? request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()): null);
			try {
				// PT : #38537 by Jitendra. Don't allow bidder registration if register link
				// hidden starts.
				 String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR)
							: request.getRemoteAddr();
				boolean isRegistrationLinkHidden = clientService.isRegistrationLinkHidden(clientId, hideRegistrationLinkId,1);
				boolean isUserNotValid = clientService.isUserNotBlock(bidderRegistrationDataBean.getTxtEmailId(),
						bidderRegistrationDataBean.getTxtMobileNo(), 1);
				if (!isRegistrationLinkHidden && !isUserNotValid) {
					bidderRegistrationDataBean.setCommonValidators(commonValidators);

					List<LinkedHashMap<String, Object>> list = commonService.checkValidUserInClient(clientId,
							bidderRegistrationDataBean.getTxtEmailId(), 2);
					selectedCategory = request.getParameterValues("txtCategory");
					isCategoryAllow = request.getParameter("hdIsCategoryAllow");
					int bidderId = 0;
					int officerId = 0;
					int actionType = 0;
					if (list != null && !list.isEmpty()) {
						Map<String, Object> map  = list.get(0);
						if (map.get("actionType") != null) {
							actionType = Integer.parseInt(map.get("actionType").toString());
							bidderId = Integer.parseInt(map.get("bidderId").toString());
							officerId = Integer.parseInt(map.get("officerId").toString());
						}
					}
				
					if (isCategoryAllow != null && isCategoryAllow.equals("1") && selectedCategory != null) {
						busCatKeywords = commonService.getKeywordNamesByIds(selectedCategory);
						bidderRegistrationDataBean
								.setTxtaBusCatKeywords(abcUtility.converObjectArrayToCommas(busCatKeywords));
					}

					boolean isCheckPassword = true;
					boolean isCheckEmail = true;
					boolean isCheckHintQnA = true;
					if (actionType == 4 && officerId > 0) {
						isCheckHintQnA = false;
						isCheckPassword = false;
						isCheckHintQnA = false;
					} else if (clientBean.getIsDIYClient() == 1)// Skip QnA validation in DIY client
					{
						isCheckHintQnA = false;
					}

					bidderRegistrationDataBean.validate(result, isCheckEmail, isCheckPassword, isCheckHintQnA, actionType);
					String pass = null;
					
					if(actionType == 1) {
						pass = UUID.randomUUID().toString().substring(0, 4)+"@"+UUID.randomUUID().toString().substring(0, 4);
						String encryptedPassword = sha256HashEncryption.encodeStringSHA256(pass);
						bidderRegistrationDataBean.setTxtUserPassword(encryptedPassword);
						bidderRegistrationDataBean.setTxtConfirmPassword(encryptedPassword);						
						isCheckPassword = true;
					}

					if (actionType == 2 && bidderId > 0) {
						result.rejectValue("txtEmailId", "msg_js_registration_bidderexists",
								"Email id already registered as bidder on this domain");
					} else if (actionType == 2 && officerId > 0) {
						result.rejectValue("txtEmailId", "msg_js_registration_officerexists",
								"Email id already registered as department user on this domain");
					}

					String successMsgCode = "";
					String langId = WebUtils.getCookie(request, "locale").getValue();
					//Error
					 if (actionType == 3) {
						success = true;
						successMsgCode = "msg_js_registration_bidderprofileexists";
						retVal = "redirect:/";
					} else if (actionType != 3 && actionType != 2) {
						int bidderVerificationBy = clientService.getBidderRegistrationVerifiedBy(clientId);
						String verificationCode = "";
						if (bidderVerificationBy != 0 && bidderVerificationBy != 3) {
							verificationCode = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
						} else {
							verificationCode = "0";
						}
						TblUserLogin tblUserLogin = null;
						int registrationWorkflowId = 0;
						if (actionType == 4) {
							List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(officerId);
							if (tblUserLogins != null && !tblUserLogins.isEmpty()) {
								tblUserLogin = tblUserLogins.get(0);
							}
							registrationWorkflowId = manageBidderService.getClientRegWorkflowId(clientId,tblUserLogin.getIsEmailVerified() == 1 ? 3 : 0);
						} else {
							tblUserLogin = bidderRegistrationDataBean._toTblUserLogin(bidderVerificationBy,
									verificationCode, 0, 0);
							tblUserLogin.setTblClient(new TblClient(clientId));
							registrationWorkflowId = manageBidderService.getClientRegWorkflowId(clientId, 0);
						}

						int cstatus = cstatusIncomplete;
						
						if (registrationWorkflowId == 9) {
							cstatus = cstatusPending;
						}
						int isAutoApprove = Integer.parseInt(
								commonService.getField("TblClient", "isTwoStepBidderApproval", "clientId", clientId));
						if (isAutoApprove == 2) {
							registrationWorkflowId = 9;
							cstatus = 1;
						}
						
						// For CR #25825 - Keval Soni
						if (rciClientIds != null && !"".equals(rciClientIds)) {
							String[] rciIds = rciClientIds.split(",");
							if (rciIds.length != 0) {
								for (int i = 0; i < rciIds.length; i++) {
									if (!"".equals(rciIds[i])) {
										if (clientId == Integer.parseInt(rciIds[i])) {
											if (actionType == 1) {
												int clientCountryId = clientService.getCountryIdByClientId(clientId);
												int bidderCountryId = Integer.parseInt(request.getParameter("selCountry"));
												if (clientCountryId != bidderCountryId && registrationWorkflowId == 5) {
													registrationWorkflowId = 8;
													break;
												}
											}
										}
									}
								}
							}
						}

						contentManagementId = StringUtils.hasLength(request.getParameter("hdContentManagementId"))
								? Integer.parseInt(request.getParameter("hdContentManagementId").toString())
								: 0;
						TblBidderStatus tblBidderStatus = bidderRegistrationDataBean._toTblBidderStatus(clientId, cstatus,null, contentManagementId);
						tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(4));
						 
						
						if (tblUserLogin.getPasswordUpdatedOn() == null) {
							tblUserLogin.setPasswordUpdatedOn(commonService.getServerDateTime());
						}
						
						tblBidderStatus.setIsParentBidderId(parentUserId);
						tblBidderStatus.setTblCompany(new TblCompany(parentcompanyId));
						tblBidderStatus.setIsAdminBidder(0);
						
						TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();// Bug:18917
						tblPasswordHistory.setCreatedOn(commonService.getServerDateTime());
						tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
						tblPasswordHistory.setPasswordUpdatedFrom(4);
						TblUserLogin tblUserLog = bidderRegistrationDataBean._toTblUserLogin(clientId, verificationCode, isAutoApprove, isAutoApprove);
						tblUserLog.setMobileNo("");
						tblUserLog.setUserName("");
						tblUserLogin.setIsFirstLogin(0);
						tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(4));
						 tblUserLogin.setIpAddress("");
						 
				        List<Object[]> clientCountryStateTimezone = commonService.getClientCountryStateTimezone(clientId);
				        tblUserLogin.setTblTimeZone(new TblTimeZone((Integer.valueOf(clientCountryStateTimezone.get(0)[0].toString()))));
						success = manageBidderService.addBidderRegistration(tblUserLogin,
								bidderRegistrationDataBean._toTblUserDetail(0),
								bidderRegistrationDataBean._toTblCompany(clientId), tblBidderStatus,
								bidderRegistrationDataBean._toTblUserHistory(userHistoryCreate, clientId),
								tblPasswordHistory, actionType);
						userId = tblUserLogin.getUserId();
						if (success) {
							// PT: 20745
							if (abcUtility.isModuleAssignToClient(request, 9) && isCategoryAllow != null
									&& isCategoryAllow.equals("1")) {// Module assign Spend Analysis
								commonService.insertUpdateCategory("edit", userId, selectedCategory, registrationLinkId);
							}
							success = dynamicFieldService.addDynamicFieldValueProcess(
									dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request), clientId,
									manageBidderFieldValueId, userId, userId);
						}
						if (success && CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)) {// CR:29488
																												// GSL
																												// Bidder
																												// Registration
																												// only
							String chkRegisteredIn[] = request.getParameterValues("hchkRegisteredIn");
							List<Integer> bidderDocIdList = new ArrayList<Integer>();
							if (chkRegisteredIn != null && chkRegisteredIn.length > 0) {
								List<TblBidderRegisteredIn> tblBidderRegisteredInList = new ArrayList<TblBidderRegisteredIn>();
								for (String registeredInId : chkRegisteredIn) {
									TblBidderRegisteredIn tblBidderRegisteredIn = new TblBidderRegisteredIn();
									tblBidderRegisteredIn
											.setTblRegisteredIn(new TblRegisteredIn(Integer.parseInt(registeredInId)));
									tblBidderRegisteredIn.setRegisteredNo(
											request.getParameter("txtRegisteredNo_" + registeredInId).toString());
									tblBidderRegisteredIn.setTblUserLogin(new TblUserLogin(userId));
									tblBidderRegisteredIn.setTblClient(new TblClient(clientId));
									tblBidderRegisteredInList.add(tblBidderRegisteredIn);
									bidderDocIdList.add(Integer.parseInt(encryptDecryptUtils
											.decrypt(
													request.getParameter("uploadedBidderFile_" + registeredInId).toString())
											.toString()));
								}
								if (tblBidderRegisteredInList != null && !tblBidderRegisteredInList.isEmpty()) {
									manageBidderService.addBidderRegistreredIn(tblBidderRegisteredInList);
								}
							}
							String industryType = request.getParameterValues("selIndustryType")[0];
							int industryTypeId = StringUtils.hasLength(industryType) && !"".equals(industryType)
									? Integer.parseInt(industryType)
									: 0;
							String industryClassification = request.getParameterValues("selIndClassification")[0];
							int industryClassificationId = StringUtils.hasLength(industryClassification)
									&& !"".equals(industryClassification) ? Integer.parseInt(industryClassification) : 0;
							String registeredInNo = request.getParameter("registreredInCapAndNo").toString();
							registeredInNo = StringUtils.hasLength(registeredInNo) && !"".equals(registeredInNo)
									? registeredInNo
									: "";
							if (industryTypeId != 0 && industryClassificationId != 0) {
								TblBidderIndustry tblBidderIndustry = new TblBidderIndustry();
								tblBidderIndustry.setTblIndustryType(new TblIndustryType(industryTypeId));
								tblBidderIndustry.setTblIndustryClassification(
										new TblIndustryClassification(industryClassificationId));
								tblBidderIndustry.setTblUserLogin(new TblUserLogin(userId));
								tblBidderIndustry.setTblClient(new TblClient(clientId));
								tblBidderIndustry.setRegisteredIn(registeredInNo);
								tblBidderIndustry.setUpdatedOn(commonService.getServerDateTime());
								manageBidderService.addBidderIndustry(tblBidderIndustry);

								bidderDocIdList.add(Integer.parseInt(encryptDecryptUtils
										.decrypt(request.getParameter("uploadedBidderFile_0").toString()).toString()));
								fileUploadService.updateRegistedInBidderDocPath(bidderDocIdList, clientId, userId,
										request.getSession().getId().toString(), false);
							}
						}
						if(success) {
							boolean isRegister = wSCheckAvailService.registerSSA(bidderRegistrationDataBean,null,tblUserLogin.getUserId(),2,clientId,true);
							if(isRegister){
								loginService.updateLoginSSOStatus(userId);//Is bidder register in SSO,change SSO-status 0 to 1 in TblUserLogin
							}
							URL url = new URL(request.getRequestURL().toString());
							Map<String, Object> emailDataMap = new HashMap<String, Object>();
							emailDataMap.put("to", tblUserLogin.getLoginId());
							emailDataMap.put("subdomainname", url.getHost());
							emailDataMap.put("emailid", tblUserLogin.getLoginId());
							emailDataMap.put("password", pass);
							emailDataMap.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
							emailDataMap.put("RegByAdminLink","<a href=\"/bidderregistrationByAdmin/"+tblUserLogin.getUserId() + "/"+ commonService.getCompanyIdByuserId(userId) + generateRedirect("bidderregistrationByAdmin/" + tblUserLogin.getUserId() + "/"+ commonService.getCompanyIdByuserId(userId),tblUserLogin.getUserName(), request)+"\">Registration Link</a>");
							
							Map<String, Object> mailParams = new HashMap<String, Object>();
							mailParams.put("to", tblUserLogin.getLoginId());
							mailParams.put("ClientName",clientService.getClientNameByClientId(abcUtility.getSessionClientId(request)));
							mailParams.put("RegisteredEmailID", tblUserLogin.getLoginId());
							mailParams.put("Password", pass);
							mailParams.put("SubDomainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
							
							boolean isGslClient = CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId) && registrationWorkflowId==9; //for GSL client, sent mail to bidder for complete registration process as step-1
							switch (bidderVerificationBy) {
							case 3:
								if(actionType == 1) {
									if(isGslClient){
										mailContentUtillity.dynamicMailGeneration("241", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
									}else{
										mailContentUtillity.dynamicMailGeneration("18", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
									}
								} else {
									if(isGslClient){
										mailContentUtillity.dynamicMailGeneration("240", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
									}else{
										mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
									}
								}
							case 2:
								if(actionType == 1) {
									if(tblUserLogin.getIsEmailVerified() == 0) {
										emailDataMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(bidderRegistrationDataBean.getTxtEmailId()+"@@"+2+"_"+0)+"\">Email Verification Link</a>");
										mailContentUtillity.dynamicMailGeneration("19", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
										// TODO :: Mobile verification code by SMS.
									} else {
										mailContentUtillity.dynamicMailGeneration("18", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
									}
								} else {
									mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
								}
								break;

							case 1:
								if(actionType == 1) {
									emailDataMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(bidderRegistrationDataBean.getTxtEmailId()+"@@"+2+"_"+0)+"/"+encryptDecryptUtils.encrypt(tblUserLogin.getVerificationCode())+"\">Email Verification Link</a>");
									mailContentUtillity.dynamicMailGeneration("20", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");  //This template is getting called
								} else {
									mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
								}
								break;

							case 0:
								if(actionType == 1) {
									if(isGslClient){
										mailContentUtillity.dynamicMailGeneration("241", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
									}else{
										mailContentUtillity.dynamicMailGeneration("18", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
									}
								} else {
									if(isGslClient){
										mailContentUtillity.dynamicMailGeneration("240", String.valueOf(userId), String.valueOf(clientId), mailParams,"");
									}else{
										mailContentUtillity.dynamicMailGeneration("26", String.valueOf(userId), String.valueOf(clientId), emailDataMap,"");
									}
								}
								break;

							default:
								break;
							}
							// PT: 20745
							if(abcUtility.isModuleAssignToClient(request,9) && isCategoryAllow != null && isCategoryAllow.equals("1")){ // Module assign Spend Analysis and Statistic 
		                    	commonService.insertUpdateCategory("edit",userId,selectedCategory,registrationLinkId);
		                    }
							successMsgCode = "redirect_success_bidder_registration";
						}
						if (success && bidderVerificationBy == 3 && tblUserLogin.getIsMobileNoVerified() == 0) {
							// Mobile Number verification
							successMsgCode = "redirect_msg_otp_sent_registered_mobileno";
							retVal = "redirect:/registrationOTPGenerate/0/"
									+ encryptDecryptUtils.encrypt(String.valueOf(tblUserLogin.getUserId()));
						} else {
							retVal = "redirect:/";
						}

					}

					redirectAttributes.addFlashAttribute(
							success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),
							success ? successMsgCode : CommonKeywords.ERROR_MSG_KEY.toString());
				} else {
					if (isUserNotValid) {
						String ipAddress2 = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR)
								: request.getRemoteAddr();
						Map<String, Object> mailParamsEmail = new HashMap<String, Object>();
						mailParamsEmail.put("ClientName", clientService.getClientNameById(clientId));
						mailParamsEmail.put("to", block_user_mail_Id);
						mailParamsEmail.put("emailId", bidderRegistrationDataBean.getTxtEmailId());
						mailParamsEmail.put("mobileNo", bidderRegistrationDataBean.getTxtMobileNo());
						mailParamsEmail.put("ipAddress", ipAddress);
						mailContentUtillity.dynamicMailGeneration("360", String.valueOf(userId), String.valueOf(clientId),
								mailParamsEmail, "");
						redirectAttributes.addFlashAttribute("phoneno", contact_phoneno);
						redirectAttributes.addFlashAttribute("emailId", contact_emailId);
						redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
								"redirect_registration_not_allow_contact");
						retVal = "redirect:/";
					} else {
						redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
								"redirect_registration_not_allow");
						retVal = "redirect:/";
					}

				}
			} catch (Exception ex) {
				return exceptionHandlerService.writeLog(ex);
			} finally {
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
						registrationLinkId, auditBidderRegistered, 0, userId);
			}
			return retVal;
		}
		//SubBidderMail_encryptDecrypt
		 public String generateRedirect(String href, String userName, HttpServletRequest request) {
				StringBuilder data = new StringBuilder();
				Object sessionStr = userName;
				boolean ISSECURE = true;
				data.append("/").append(ISSECURE ? encryptDecryptUtils.encrypt(href + sessionStr.toString()) : "abc123");
				return data.toString();
		}
		
		
		
		//UpdateSubBidder info
				@RequestMapping(value = "/editSubBidder", method = RequestMethod.POST)
				public String addBidderbyAdmin1(@ModelAttribute BidderRegistrationDataBean bidderRegistrationDataBean,
						BindingResult result, HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes,
						ModelMap modelMap) {
				
					String password= bidderRegistrationDataBean.getTxtUserPassword();				
					String hintAns=bidderRegistrationDataBean.getTxtHintAns();					
					boolean success = false;
					String successMsgCode = null;
					String retVal = null;
					int userId=Integer.valueOf(request.getParameter("hdUserId"));
					int companyId=Integer.valueOf(request.getParameter("hdCompanyId"));
					int clientId = abcUtility.getSessionClientId(request);
					int contentManagementId = 0;
					String selectedCategory[] = null; // PT: 20745
					String isCategoryAllow = "0";
					String contactPersonName = request.getParameter("txtContactPersonName");
					try {
						List<Object[]> clientCountryStateTimezone = commonService.getClientCountryStateTimezone(clientId);
						bidderRegistrationDataBean.setSelTimezone(Integer.valueOf(clientCountryStateTimezone.get(0)[0].toString()));
					} catch (Exception e) {
						e.printStackTrace();
					}
					 
					try{				
						bidderRegistrationDataBean.setCommonValidators(commonValidators);
						selectedCategory = request.getParameterValues("txtCategory");
						isCategoryAllow = request.getParameter("hdIsCategoryAllow");
						List<Object> busCatKeywords = null;
						List<LinkedHashMap<String, Object>> list = commonService.checkValidUserInClient(clientId, bidderRegistrationDataBean.getTxtEmailId(), 2);
						  String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR)
									: request.getRemoteAddr();
						   
						int actionType = 0;
						int bidderId = 0;
						int officerId = 0;
						if(list != null && !list.isEmpty()) {
							Map<String, Object> map  = list.get(0);
							if(map.get("actionType") != null) {
							actionType = Integer.parseInt(map.get("actionType").toString());
							bidderId = Integer.parseInt(map.get("bidderId").toString());
							officerId = Integer.parseInt(map.get("officerId").toString());
							}
						}				
						//Bug #33494 By Jitendra. If category is allow then getting keyword names from keyword ids and set in bidderRegistrationDataBean model. 
						if(isCategoryAllow != null && isCategoryAllow.equals("1") && selectedCategory != null){
							busCatKeywords = commonService.getKeywordNamesByIds(selectedCategory);
							bidderRegistrationDataBean.setTxtaBusCatKeywords(abcUtility.converObjectArrayToCommas(busCatKeywords));
						}				
						String pass = null;
						boolean isCheckPassword = false;
						if(actionType == 1) {
							//pass = UUID.randomUUID().toString().substring(0, 4)+"@"+UUID.randomUUID().toString().substring(0, 4);
							String encryptedPassword = sha256HashEncryption.encodeStringSHA256(password);
							bidderRegistrationDataBean.setTxtUserPassword(encryptedPassword);
							bidderRegistrationDataBean.setTxtConfirmPassword(encryptedPassword);
							
							isCheckPassword = true;
						}
		           if(actionType==2 && bidderId>0) {
							result.rejectValue("txtEmailId", "msg_js_registration_bidderexists", "Email id already registered as bidder on this domain");
						} else if(actionType==2 && officerId>0) {
							result.rejectValue("txtEmailId", "msg_js_registration_officerexists", "Email id already registered as department user on this domain");
						}
						
						if(actionType == 3) {
							success = manageBidderService.addBidderWithProfileInOtherDomain(clientId ,bidderId,false,0,0);
							successMsgCode = "redirect_success_bidder_registration";
							retVal = "redirect:/common/admin/managebidder"+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
						} 
						else if(actionType!=3 && actionType!=2) {
							int bidderVerificationBy =  clientService.getBidderRegistrationVerifiedBy(clientId);
							String verificationCode = null;
							if(bidderVerificationBy != 0 && bidderVerificationBy != 3) {
								verificationCode=UUID.randomUUID().toString().replaceAll("-", "").substring(0, 10);
							} else {
								verificationCode="0";
							}
							
							TblUserLogin tblUserLogin = null;
							TblUserDetail tblUserDetail = null;
							
							int registrationWorkflowId = 0;
							if(actionType == 4) {
								List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(officerId);
								if(tblUserLogins!=null && !tblUserLogins.isEmpty()) {
									tblUserLogin = tblUserLogins.get(0);
								}
								registrationWorkflowId = manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), tblUserLogin.getIsEmailVerified()==1? 3 : 0);
							} else {
								tblUserLogin = bidderRegistrationDataBean._toTblUserLogin(bidderVerificationBy, verificationCode, abcUtility.getSessionUserId(request), 1);
								tblUserLogin.setTblClient(new TblClient(clientId));
								registrationWorkflowId = manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), 0);
								if(bidderVerificationBy == 3){
									tblUserLogin.setIsEmailVerified(1);
									tblUserLogin.setIsMobileNoVerified(1);
									registrationWorkflowId=manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), 3);
								}
							}
							tblUserLogin.setTblHintQuestion(new TblHintQuestion(1));
							tblUserLogin.setHintAnswer(sha256HashEncryption.encodeStringSHA256("abc"));
							tblUserLogin.setUserName(contactPersonName);
							
							if(tblUserLogin.getPasswordUpdatedOn()==null){
								tblUserLogin.setPasswordUpdatedOn(commonService.getServerDateTime());
							}

							int cstatus = cstatusIncomplete;
							if(registrationWorkflowId == 9) {
								cstatus=cstatusPending;
							}
							int isAutoApprove= Integer.parseInt(commonService.getField("TblClient", "isTwoStepBidderApproval", "clientId", clientId));
							if(isAutoApprove==2){
								registrationWorkflowId=9;
								cstatus=1;
							}
							//For CR #25825 - Keval Soni
							if(rciClientIds != null && !"".equals(rciClientIds)){
								String[] rciIds = rciClientIds.split(",");
								if(rciIds.length != 0){
									for(int i = 0;i<rciIds.length;i++){
										if(!"".equals(rciIds[i])){
											if(clientId == Integer.parseInt(rciIds[i])){
												if(actionType == 1){
													int clientCountryId=clientService.getCountryIdByClientId(clientId);
													int bidderCountryId=Integer.parseInt(request.getParameter("selCountry"));
													if(clientCountryId != bidderCountryId && registrationWorkflowId == 5){
														registrationWorkflowId=8;
														break;
													}
												}
											}
										}
									}
								}
							}
							contentManagementId = StringUtils.hasLength(request.getParameter("hdContentManagementId"))?Integer.parseInt(request.getParameter("hdContentManagementId").toString()):0;
							TblBidderStatus tblBidderStatus = bidderRegistrationDataBean._toTblBidderStatus(clientId, cstatus, abcUtility.getSessionUserId(request),contentManagementId);
							tblBidderStatus.setTblRegistrationWorkflow(new TblRegistrationWorkflow(4));
							TblPasswordHistory tblPasswordHistory = new TblPasswordHistory(); //Bug:18917
					        tblPasswordHistory.setCreatedOn(commonService.getServerDateTime());
					        tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
					        tblPasswordHistory.setPasswordUpdatedFrom(4);
					        					        					       
					        tblUserLogin.setIpAddress("");
					        bidderRegistrationDataBean.setTxtFullNameFirst(request.getParameter("txtFullName"));
					        tblUserLogin.setHintAnswer(hintAns);
					        tblUserLogin.setIsEmailVerified(1);
					        TblCompany tblCompany = tblCompanyDao.findTblCompany("companyId",Operation_enum.EQ,companyId).get(0);
					        tblCompany.setPhoneNo(bidderRegistrationDataBean.getTxtPhone());
					        tblCompany.setAddress(tblCompany.getAddress());
					        // update
					        success = manageBidderService.updateChildUserDetail(isCheckPassword,bidderVerificationBy, verificationCode, bidderRegistrationDataBean,
									tblUserLogin,tblCompany, bidderRegistrationDataBean._toTblUserHistory(userHistoryCreate, clientId), 
									bidderRegistrationDataBean.getTxtaBusCatKeywords(), success, abcUtility.getSessionUserId(request), success,
									clientId,userId,companyId,contactPersonName);
					        
					        		        			    	
				    		success = dynamicFieldService.addDynamicFieldValueProcess(dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request),clientId,manageBidderFieldValueId,userId,userId);
				
//							retVal = "redirect:/";
							
							
							
							retVal = "redirect:/certimap";
				    		TblUserLogin tblUserLogin2 = null;
				            boolean loginSuccess = false;
				            boolean isFirstLogin = false;
				            boolean isChngPass = false;
				            SessionBean bean = null;
				            int clientId2 = 0;
				            boolean pkiRequired = false;
				            boolean isEventSpecific = false;
				            int clientRegWorkflowId = 0;
				            Date serverDate = null;
				            ClientBean clientBean = null;
				            String userName = "";
				            int isCaptchaConfigured = 0;
				            int bidderCstatus=0;
				            int userTypeId=0;
				            boolean isGstEntered = true;
				            
				            if (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) {
				                clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
				                clientId2 = clientBean.getClientId();
				                pkiRequired = (clientBean.getIsPkiEnabled() == 1);
				                isEventSpecific = (clientBean.getIsPkiEnabled() == 2);
				            }
				            try {
				            String ipAddress2 = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
			                TblTrackLogin trackLogin = new TblTrackLogin();
//			                userName = loginService.getLoginIdByUserId(tblUserLogin.getUserId()).get(0).toString();
			                userName=request.getParameter("txtEmailIdFirst");
			                tblUserLogin2 = loginService.getUserLoginByLoginId(userName);
			                trackLogin.setBrowserType(request.getHeader("User-Agent"));
			                trackLogin.setIpAddress(ipAddress2);
			                trackLogin.setOperatingSystem(request.getHeader("User-Agent"));
			                trackLogin.setTblClient(new TblClient(clientId2));
			                trackLogin.setUserId(tblUserLogin2.getUserId());
			                trackLogin.setLoginId(tblUserLogin2.getLoginId());
			                loginSuccess=true;
			                isCaptchaConfigured = (Integer) request.getSession().getAttribute("isCaptchaConfigured");
			                if (loginSuccess) {
			                	
			                	if(isCaptchaConfigured == 1 && Integer.parseInt(request.getSession().getAttribute("isCaptchaValid").toString()) == 1){
			                		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_unlockaccount");
			                	}
			                	SessionBean sessionBean = new SessionBean();
			                    sessionBean.setUserName(tblUserLogin2.getLoginId());
			                    sessionBean.setUserId(tblUserLogin2.getUserId());
			                    sessionBean.setUserTypeId(2);
		                        trackLogin.setUserTypeId(sessionBean.getUserTypeId());
		                        userTypeId=sessionBean.getUserTypeId();
		                        sessionBean.setFullName(tblUserLogin2.getUserName());
		                        sessionBean.setUserDetailId(loginService.getUserDetailId(sessionBean.getUserId(), sessionBean.getUserTypeId() == 3 ? clientId2 : sessionBean.getUserTypeId() == 2 ? 0 : -1));
		                        List<Object[]> lstObj = loginService.getLstLoginDtIpAddrById(sessionBean.getUserId(), clientId2);
		                        if (lstObj != null & !lstObj.isEmpty()) {
		                            for (int i = 0; i < lstObj.size(); i++) {
		                                Object[] object = lstObj.get(i);
		                                sessionBean.setLastLoginDateTime((Date) object[0]);
		                                sessionBean.setIpAddress(String.valueOf(object[1]));
		                            }
		                        }
		                        List<Object[]> timeZone = loginService.getUserTimeZone(sessionBean.getUserId());
		                        if (timeZone != null && !timeZone.isEmpty()) {
		                            if(sessionBean.getUserTypeId()==1){
		                                sessionBean.setTimeZoneOffset(clientBean.getTimeZone());
		                                sessionBean.setTimeZoneAbbr(clientBean.getTimeZoneAbbr());                                                                                    
		                            }else{
		                                sessionBean.setTimeZoneOffset(timeZone.get(0)[0].toString());
		                                sessionBean.setTimeZoneAbbr(timeZone.get(0)[1].toString());
		                            }
		                        }
		                        sessionBean.setTrackLoginId(-1);
		                      //Set the mail unread count
		            			if(sessionBean.getUserId()!=0){
		            				List<Object[]> inboxCountDetails=mailBoxService.getInboxCount(sessionBean.getUserId(),clientBean.getClientId(),sessionBean.getUserTypeId());
		            				if(inboxCountDetails!=null && !inboxCountDetails.isEmpty()){
		            					for(Object[] data: inboxCountDetails){
		            						if(data[1].toString().equalsIgnoreCase("inbox")){
		            							   sessionBean.setUnReadCount((Long)data[2]);
		            							   break;
		            						}
		            					}
		            				}
		            			}
		                        //Ended
		                        
		            			if(clientBean.getIsDIYClient() == 1){
		                         	int isEmailVeriReq = sessionBean.getUserTypeId() == 2 ? clientService.getBidderRegistrationVerifiedBy(abcUtility.getSessionClientId(request)):sessionBean.getUserTypeId() == 3 ? clientService.getOfficerRegistrationVerifiedBy(abcUtility.getSessionClientId(request)):0; 	
		                         	if(tblUserLogin2.getIsEmailVerified() == 0 && isEmailVeriReq == 1)
		                         	{
		                         		response.addCookie(new Cookie("IsEmailVerifiedForDIY", "1"));
		                         	}
		                         }
		                        
		            			if (sessionBean.getUserTypeId() == 2) {
		                            clientRegWorkflowId = manageBidderService.getBidderWorkflowId(clientId2, sessionBean.getUserId());
		                            bidderCstatus=manageBidderService.getBidderCstatus(clientBean.getClientId(), sessionBean.getUserId());
		                            sessionBean.setCompanyId(loginService.getCompanyId(sessionBean.getUserId(), clientBean.getClientId()));
		                        }
		            			
		            			if(bidderCstatus==1){
		                        	int isGstRequired = (Integer)clientService.getClientField(clientId2, "isGSTRequired");
		                        	if(isGstRequired==1){
		                        		Object[] obj = manageBidderService.getGstFields("TblBidderGstDetails", sessionBean.getUserId(),clientId2 ,"gstDetailId,panNo");
		                        		if(obj==null  && commonService.getCountryIdByCompanyId(sessionBean.getCompanyId())==countryId){
		                        			isGstEntered = false;
		                        		}
		                        	}
		                        }
		            			
		            			sessionBean.setCountryId(commonService.getCountryIdByCompanyId(sessionBean.getCompanyId()));
		            			if ((clientRegWorkflowId != 0 && clientRegWorkflowId != 9) || pkiRequired) {
		                            request.getSession().setAttribute(TEMPSESSIONOBJECT, sessionBean);
		                        } else {
		                            request.getSession().setAttribute(SESSIONOBJECT, sessionBean);
		                        }
		                        bean = sessionBean;
		                        if (tblUserLogin2.getIsFirstLogin() == 1) {
		                            isFirstLogin = true;
		                        } else {
		                            loginSuccess = true;
		                        }
		                        loginService.updateLoginStatus(0, false, tblUserLogin2.getUserId());
		                        trackLogin.setRemark("Login Success");
		                        trackLogin.setCstatus(1);
		                        trackLogin.setUserDetailId(sessionBean.getUserDetailId());
		                        Calendar calendar = Calendar.getInstance();
		                        calendar.setTime(tblUserLogin2.getPasswordUpdatedOn());
		                        calendar.add(Calendar.DAY_OF_MONTH, passValidity);
		                        serverDate = commonService.getServerDateTime();
		                        isChngPass = calendar.getTime().before(serverDate);
		            			
		                     // Start - Task list reminder : purvesh
//		                        setTaskListData(tblUserLogin.getUserId(),clientBean.getClientId(),request);
		                        // End - Task list reminder : purvesh
		                        
		                        //Start - Lipi 
		                        //Dump user in SSO from Local - not changed the pass
//		                        if(CommonUtility.isSSOEnabled(request)){
//		                        	wSCheckAvailService.dumpUserWithChngPwd(tblUserLogin.getUserId(),clientBean.getClientId(),sessionBean.getUserTypeId(),false);
//		                        }
		                        //End - Lipi
		                        if(request.getSession().getAttribute("isDRT") == null){
		                            List sectorList = clientService.getClientSector(clientBean.getClientId());
		                            boolean isDRT = false;
		                            boolean isBank = false;
		                            boolean isSarfaesi = false;
		                            for(Object obj : sectorList){
		                                if(obj.equals(1)){
		                                    isDRT = true;
		                                }else if(obj.equals(2)){
		                                    isSarfaesi = true;
		                                }else if(obj.equals(3)){
		                                    isBank = true;
		                                }
		                            }
		                            request.getSession().setAttribute("sectorList",sectorList);
		                            request.getSession().setAttribute("isDRT", isDRT);
		                            request.getSession().setAttribute("isBank", isBank);
		                            request.getSession().setAttribute("isSarfaesi", isSarfaesi);
		                        }
			                }
//			                else {
//			                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "Your login Account has been locked because of " + failedAttempt + " consecutive failed Login attempts , please click on Forgot Password Link");
//			                    trackLogin.setRemark("Failed Login Attempt Exceeded");
//			                    trackLogin.setCstatus(0);
//			                }  
			                loginService.addTrackLogin(trackLogin);
			                if (bean != null && bean.getTrackLoginId() == -1) {
			                    bean.setTrackLoginId(trackLogin.getTrackLoginId());
			                    if ((bean.getUserTypeId()==2 && clientRegWorkflowId != 9) || pkiRequired) {
			                        request.getSession().removeAttribute(TEMPSESSIONOBJECT);
			                        request.getSession().setAttribute(TEMPSESSIONOBJECT, bean);
			                    } else {
			                        TblSession tblSession = new TblSession();
			                        tblSession.setCertId("0");
			                        tblSession.setLoginDate(serverDate != null ? serverDate : commonService.getServerDateTime());
			                        tblSession.setLogoutDate(serverDate != null ? serverDate : commonService.getServerDateTime());
			                        tblSession.setJSessionId(request.getSession().getId());
			                        tblSession.setTblTrackLogin(trackLogin);
			                        loginService.addSession(tblSession);
			                        request.getSession().removeAttribute(SESSIONOBJECT);
			                        request.getSession().setAttribute(SESSIONOBJECT, bean);
			                    }
			                
						}
				            }catch (Exception ex) {
				                tblUserLogin2 = null;
				                loginSuccess = false;
				                request.getSession().removeAttribute(TEMPSESSIONOBJECT);
				                return exceptionHandlerService.writeLog(ex);
				            } finally {
				                if (bean != null) {
//				                    auditTrailService.makeAuditTrail(new TblAuditTrail(request.getRequestURL().toString(), bean.getTrackLoginId()), loginLink,submitLoginAudit, 0, tblUserLogin != null ? tblUserLogin.getUserId() : 0);
				                }
				            }
							
							
				            
							
							
							
							
							
							
							
							
							
							
						}
						redirectAttributes.addFlashAttribute("successMsg", "msg_firststep_registration_completed_successfully");
						
						//redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? successMsgCode : CommonKeywords.ERROR_MSG_KEY.toString());
					}
					catch(Exception ex){
						return exceptionHandlerService.writeLog(ex);
					} finally {
						if(clientId==1){
							auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), registrationLinkId, success ? auditBidderRegistered : auditBidderRegistered, 0, userId, "",request.getParameter("skpSignText"));
						} else {
							auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), registrationLinkId, success ? auditBidderRegistered : auditBidderRegistered, 0, userId);
						}
					}
					return retVal;
				}	
		
		//@RequestMapping(value = "/addbidderbyadmin", method = RequestMethod.POST)
		 @RequestMapping(value = "/addbidderbyadmin1", method = RequestMethod.POST)
		    @ResponseBody
		    public String getDepartmentOfficer(@RequestParam("emailId") String emailId, @RequestParam(value = "isDRT", required = false) String isDRT, @RequestParam(value = "isBank", required = false) String isBank, @RequestParam(value = "isSarfaesi", required = false) String isSarfaesi, @RequestParam(value = "jsRequire", required = false) String jsRequire, HttpServletRequest request) {
		        String retVal = null;
		        System.out.println(emailId);
		        try {
		            
		        } catch (Exception e) {
		            exceptionHandlerService.writeLog(e);
		        }
		       
		        return retVal;
		    }
		 
		    private String getRedirectPage(HttpServletRequest request) throws Exception{
		        int userTypeId = abcUtility.getSessionUserTypeId(request);
		        String pageName = "redirect:/loginfailed";
		        String moduleId = WebUtils.getCookie(request, "moduleId").getValue();
		        int isCategoryAllow = 0;
		        if(abcUtility.isModuleAssignToClient(request,9) ){  // Module Assign Spend Analysis 
		        	isCategoryAllow = commonService.isCategoryStaticsAllow(abcUtility.getSessionClientId(request));
		        }
		        ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
		        int clientId = abcUtility.getSessionClientId(request);
		        int userId = abcUtility.getSessionUserId(request); 
		        
		        switch(userTypeId){
		            case 1 : 
//		                pageName = "redirect:/common/admin/searchlistclient" + encryptDecryptUtils.generateRedirect("common/admin/searchlistclient", request);
//		                break;
		            	if(isCategoryAllow == 1){
		            		pageName = "redirect:/common/CategoryWiseListingReport"+encryptDecryptUtils.generateRedirect("common/CategoryWiseListingReport", request);		
		            	}else if("3".equals(moduleId)){
		                    pageName = "redirect:/etender/buyer/tenderlisting"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderlisting", request);
		                }else if("5".equals(moduleId)){
		                		pageName = "redirect:/eauction/auctioneer/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/auctionlisting", request);	
		                }else if("8".equals(moduleId)){
		                    pageName = "redirect:/enlistment/admin/tasklist/0" + encryptDecryptUtils.generateRedirect("enlistment/admin/tasklist/0", request);
		                }else{
		                	pageName = "redirect:/welcome" + encryptDecryptUtils.generateRedirect("welcome", request);
		                }
		                break;
		            case 2 :
		            	if(isCategoryAllow == 1){
		            		pageName = "redirect:/common/CategoryWiseListingReport"+encryptDecryptUtils.generateRedirect("common/CategoryWiseListingReport", request);		
		            	}else if("3".equals(moduleId)){
		                    pageName = "redirect:/etender/bidder/tenderlisting/0"+encryptDecryptUtils.generateRedirect("etender/bidder/tenderlisting/0", request);
		                }else if("5".equals(moduleId)){
		                	if(clientBean!=null && clientBean.getIsDIYClient()==1) {
		                		pageName = "redirect:/eauction/bidder/quickauctionlisting" + encryptDecryptUtils.generateRedirect("eauction/bidder/quickauctionlisting", request);
		                	}
		                	else {
		                		pageName = "redirect:/eauction/bidder/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/bidder/auctionlisting", request);
		                	}
		                }else if("8".equals(moduleId)){
		                    pageName = "redirect:/enlistment/bidder/pqpreferencelisting" + encryptDecryptUtils.generateRedirect("enlistment/bidder/pqpreferencelisting", request);
		                }else{
		                	pageName = "redirect:/welcome" + encryptDecryptUtils.generateRedirect("welcome", request);
		                }
		            	if(CommonUtility.isClientConditionExistInProperty(rciClientIds, clientId)){
		            		boolean isRciBidderEnlisted = request.getSession().getAttribute("isRciBidderEnlisted") == null ? false : (Boolean) request.getSession().getAttribute("isRciBidderEnlisted");
		            		if(!isRciBidderEnlisted){ // if company is not enlisted or approved
		            			isRciBidderEnlisted = vendorEnlistmentService.isCompanyEnlistedAndApproved(clientId,commonService.getCompanyId(userId, clientId));
		            			request.getSession().setAttribute("isRciBidderEnlisted",isRciBidderEnlisted);
		            			if(!isRciBidderEnlisted){
		            				pageName = "redirect:/enlistment/bidder/pqpreferencelisting" + encryptDecryptUtils.generateRedirect("enlistment/bidder/pqpreferencelisting", request);
		            			}
		            		}
		            	}
		            	if(CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)){
		            		boolean isGslBidderRegDone = request.getSession().getAttribute("isGslBidderRegDone") == null ? false : (Boolean) request.getSession().getAttribute("isGslBidderRegDone");
		            		if(!isGslBidderRegDone){ // if bidder reg for industry type and classification - gsl only
		            			isGslBidderRegDone = manageBidderService.isBidderRegInBidderIndustry(clientId, userId);
		            			request.getSession().setAttribute("isGslBidderRegDone",isGslBidderRegDone);
		            			if(!isGslBidderRegDone){
		            				pageName = "redirect:/eauction/bidder/editbidder/"+ userId +encryptDecryptUtils.generateRedirect("eauction/bidder/editbidder/"+ userId , request);
		            			}
		            		}
		            	}
		                break;
		            case 3 :
		            	if(isCategoryAllow == 1){
		            		pageName = "redirect:/common/CategoryWiseListingReport"+encryptDecryptUtils.generateRedirect("common/CategoryWiseListingReport", request);		
		            	}else if("3".equals(moduleId)){
		                    pageName = "redirect:/etender/buyer/tenderlisting"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderlisting", request);
		                }else if("5".equals(moduleId)){
		                	if(clientBean!=null && clientBean.getIsDIYClient()==1) {
		                		pageName = "redirect:/eauction/auctioneer/quickauctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/quickauctionlisting", request);
		                	}
		                	else {
		                		pageName = "redirect:/eauction/auctioneer/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/auctionlisting", request);
		                	}
		                }else if("8".equals(moduleId)){
		                    pageName = "redirect:/enlistment/admin/tasklist/0" + encryptDecryptUtils.generateRedirect("enlistment/admin/tasklist/0", request);
		                }else{
		                	pageName = "redirect:/welcome" + encryptDecryptUtils.generateRedirect("welcome", request);
		                }
		                break;
		        }
		        return pageName;
		    }
		 
		
		/**
		 * Use for Bidder details in view page of RegistrationDetails.jsp
		 * @author nirav.modi
		 * @param bidderId
		 * @return HashMap of <code><String, Object></code>
		 * @throws Exception
		 */
		 
		 
}
