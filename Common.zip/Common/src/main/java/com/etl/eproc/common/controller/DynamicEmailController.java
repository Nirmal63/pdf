package com.etl.eproc.common.controller;

import com.etl.eproc.common.databean.DynMailContentDataBean;
import com.etl.eproc.common.databean.TemplateQueryDataBean;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblDynMailContent;
import com.etl.eproc.common.model.TblEvent;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblModule;
import com.etl.eproc.common.model.TblSubModule;
import com.etl.eproc.common.model.TblTemplateQuery;
import com.etl.eproc.common.model.TblType;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.MailConfigureService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.eauction.model.TblClientMailTemplate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

/**
 *
 * @author vipul
 */
@Controller
public class DynamicEmailController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private MailConfigureService mailConfigureService;
    @Autowired
    private ModelToSelectItem modelToSelectItem;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Value("#{linkProperties['report_email_template']?:58}")
    private int manageEmailTemplateReportId;
//    @Value("#{adminAuditTrailProperties['getdynamicmailcontentgen']}")
//    private String getDynamicMailContentGenAuditMsg;
//    @Value("#{adminAuditTrailProperties['postdynamicmailcontentgen']}")
//    private String postDynamicMailContentGenAuditMsg;
    private static final int INTERVALTYPE_MINUTES = 1;
    private static final int INTERVALTYPE_HOURLY = 2;
    private static final int INTERVALTYPE_DAILY = 3;
    private static final int INTERVALTYPE_WEEKLY = 4;
    private static final int INTERVALTYPE_MONTHLY = 5;
    private static final int INTERVALTYPE_YEARLY = 6;
    private static final String CREATE = "create";
    private static final String EDIT = "edit";
    private static final String OPTYPE = "opType";
    
    private final static String XFORWARDEDFOR = "X-FORWARDED-FOR";
    
    @RequestMapping(value = "/common/admin/manageemailtemplate/{enc}", method = RequestMethod.GET)
    public String manageEmailTemplate(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", manageEmailTemplateReportId);
            reportGeneratorService.getReportConfigDetails(manageEmailTemplateReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getManageDeptRemark, 0, 0);
        }
        return "/eauction/report/emailtemplatereport";
    }

    @RequestMapping(value = "/common/admin/emailinterface/{enc}", method = RequestMethod.GET)
    public String displayEmailInterface(@ModelAttribute DynMailContentDataBean dynMailContentDataBean, ModelMap map, HttpServletRequest request) {
        try {
            List<TblModule> lstModule = commonService.getModuleList();
            List<SelectItem> selModule = modelToSelectItem.convertListIntoSelectItemList(lstModule, "moduleId", "lang" + WebUtils.getCookie(request, "locale").getValue());

            List<SelectItem> radYesNo = new ArrayList<SelectItem>();
            radYesNo.add(new SelectItem("Yes", 1));
            radYesNo.add(new SelectItem("No", 0));
            map.put("radYesNo", radYesNo);
            
            List<SelectItem> radAttachment = new ArrayList<SelectItem>();
            radAttachment.add(new SelectItem("No", 0));
            radAttachment.add(new SelectItem("Officer Attachment", 1));
            radAttachment.add(new SelectItem("Bidder Attachment", 2));
            map.put("radAttachment", radAttachment);

            List<SelectItem> selIntervalType = new ArrayList<SelectItem>();
            selIntervalType.add(new SelectItem("Select Interval Type", 0));
            selIntervalType.add(new SelectItem("Minutes", 1));
            selIntervalType.add(new SelectItem("Hourly", 2));
            selIntervalType.add(new SelectItem("Daily", 3));
            selIntervalType.add(new SelectItem("Weekly", 4));
            selIntervalType.add(new SelectItem("Monthly", 5));
            selIntervalType.add(new SelectItem("Yearly", 6));
            map.put("selIntervalType", selIntervalType);

            List<SelectItem> lstDayOfWeek = new ArrayList<SelectItem>();
            lstDayOfWeek.add(new SelectItem("Monday", 2));
            lstDayOfWeek.add(new SelectItem("Tuesday", 3));
            lstDayOfWeek.add(new SelectItem("Wednesday", 4));
            lstDayOfWeek.add(new SelectItem("Thrusday", 5));
            lstDayOfWeek.add(new SelectItem("Friday", 6));
            lstDayOfWeek.add(new SelectItem("Saturday", 7));
            lstDayOfWeek.add(new SelectItem("Sunday", 1));
            map.put("lstDayOfWeek", lstDayOfWeek);

            List<SelectItem> lstMonth = new ArrayList<SelectItem>();
            lstMonth.add(new SelectItem("January", 1));
            lstMonth.add(new SelectItem("February", 2));
            lstMonth.add(new SelectItem("March", 3));
            lstMonth.add(new SelectItem("April", 4));
            lstMonth.add(new SelectItem("May", 5));
            lstMonth.add(new SelectItem("June", 6));
            lstMonth.add(new SelectItem("July", 7));
            lstMonth.add(new SelectItem("August", 8));
            lstMonth.add(new SelectItem("September", 9));
            lstMonth.add(new SelectItem("October", 10));
            lstMonth.add(new SelectItem("November", 11));
            lstMonth.add(new SelectItem("December", 12));
            map.put("lstMonth", lstMonth);

            List<SelectItem> lstWeek = new ArrayList<SelectItem>();
            lstWeek.add(new SelectItem("First", 1));
            lstWeek.add(new SelectItem("Second", 2));
            lstWeek.add(new SelectItem("Third", 3));
            lstWeek.add(new SelectItem("Fourth", 4));
            map.put("lstWeek", lstWeek);

            List<SelectItem> rdDailyOpt = new ArrayList<SelectItem>();
            rdDailyOpt.add(new SelectItem("", 0));
            rdDailyOpt.add(new SelectItem("", 1));
            map.put("rdDailyOpt", rdDailyOpt);

            List<SelectItem> lstHrs = new ArrayList<SelectItem>();
            List<SelectItem> lstMins = new ArrayList<SelectItem>();
            for (int i = 0; i < 24; i++) {
                if (i < 10) {
                    lstHrs.add(new SelectItem("0" + i, i));
                } else {
                    lstHrs.add(new SelectItem(i, i));
                }
            }
            for (int i = 0; i < 60; i++) {
                if (i < 10) {
                    lstMins.add(new SelectItem("0" + i, i));
                } else {
                    lstMins.add(new SelectItem(i, i));
                }
            }

            dynMailContentDataBean.setRdDailyOpt(1);
            dynMailContentDataBean.setRdMthlyOpt(1);
            dynMailContentDataBean.setRdYrlyOpt(1);
            dynMailContentDataBean.setRdisFromStatic(1);
            dynMailContentDataBean.setRdisToStatic(1);
            dynMailContentDataBean.setRdisscheduled(0);
            dynMailContentDataBean.setRdhasAttachment(0);
            dynMailContentDataBean.setRdisstaticsign(1);


            map.put("dynMailContentDataBean", dynMailContentDataBean);
            map.put("lstHrs", lstHrs);
            map.put("lstMins", lstMins);
            map.put("lstModule", selModule);
            map.put(OPTYPE, CREATE);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getDynamicMailContentGenAuditMsg, 0, 0);
//        }
        return "/common/EmailContentCreation";
    }

    @RequestMapping(value = "/common/admin/submitmailcontents/{opType}/{mailTemplateId}", method = RequestMethod.POST)
    public String submitmailContent(@ModelAttribute DynMailContentDataBean dynMailContentDataBean, @PathVariable("opType") String opType, @PathVariable("mailTemplateId") Integer mailTemplateId, HttpServletRequest request, RedirectAttributes redirectAttributes) {

    	String ipAddress="";
        Map<Integer, String> mapMonth = new HashMap<Integer, String>();
        mapMonth.put(1, "January");
        mapMonth.put(2, "February");
        mapMonth.put(3, "March");
        mapMonth.put(4, "April");
        mapMonth.put(5, "May");
        mapMonth.put(6, "June");
        mapMonth.put(7, "July");
        mapMonth.put(8, "August");
        mapMonth.put(9, "September");
        mapMonth.put(10, "October");
        mapMonth.put(11, "November");
        mapMonth.put(12, "December");

        Map<Integer, String> mapWeek = new HashMap<Integer, String>();
        mapWeek.put(1, "First");
        mapWeek.put(2, "Second");
        mapWeek.put(3, "Third");
        mapWeek.put(4, "Fourth");

        Map<Integer, String> mapDayOfWeek = new HashMap<Integer, String>();
        mapDayOfWeek.put(2, "Monday");
        mapDayOfWeek.put(3, "Tuesday");
        mapDayOfWeek.put(4, "Wednesday");
        mapDayOfWeek.put(5, "Thursday");
        mapDayOfWeek.put(6, "Friday");
        mapDayOfWeek.put(7, "Saturday");
        mapDayOfWeek.put(1, "Sunday");

        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            	ipAddress= request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();
                String startTime = " Start time " + dynMailContentDataBean.getSelhrs() + " Hour " + dynMailContentDataBean.getSelmins() + " Minute";
                StringBuilder cronString = new StringBuilder();
                StringBuilder cronExpression = new StringBuilder();
                if (dynMailContentDataBean.getRdisscheduled() == 1) {
                    int val = dynMailContentDataBean.getHdEditValue() != null ? 1 : 0;
                    if (dynMailContentDataBean.getSelintervalType() == 0 && opType.equals(EDIT)) {
                        dynMailContentDataBean.setCronExpression(request.getParameter("hdScheduleExpression"));
                        dynMailContentDataBean.setDescriptionForCronExpression(request.getParameter("hdDescriptionForCronExpression"));
                    } else {
                        switch (dynMailContentDataBean.getSelintervalType()) {
                            case INTERVALTYPE_MINUTES:
                                cronExpression.append("0 ").append(dynMailContentDataBean.getSelmins()).append("/").
                                        append(dynMailContentDataBean.getTxtEveryMin()).append(" ").append(dynMailContentDataBean.getSelhrs()).append(" 1/1 * ? *");
                                cronString.append("Every ").append(dynMailContentDataBean.getTxtEveryMin()).append(" minute(s)").append(startTime);
                                break;
                            case INTERVALTYPE_HOURLY:
                                cronExpression.append("0 ").append(dynMailContentDataBean.getSelmins()).append(" ").
                                        append(dynMailContentDataBean.getSelhrs()).append("/").append(dynMailContentDataBean.getTxtEveryHr()).
                                        append(" 1/1 * ? *");
                                cronString.append("Every ").append(dynMailContentDataBean.getTxtEveryHr()).append(" hour(s)").append(startTime);
                                break;
                            case INTERVALTYPE_DAILY:
                                if (dynMailContentDataBean.getRdDailyOpt() == 0) {
                                    cronExpression.append("0 ").append(dynMailContentDataBean.getSelmins()).append(" ").
                                            append(dynMailContentDataBean.getSelhrs()).append(" 1/").append(dynMailContentDataBean.getTxtEveryDay()).
                                            append(" * ? *");
                                    cronString.append("Every ").append(dynMailContentDataBean.getTxtEveryDay()).append(" day(s)").append(startTime);

                                } else {
                                    cronExpression.append("0 ").append(dynMailContentDataBean.getSelmins()).append(" ").
                                            append(dynMailContentDataBean.getSelhrs()).append(" ? * 2-7 *");
                                    cronString.append("Every Week Day").append(startTime);
                                }
                                break;
                            case INTERVALTYPE_WEEKLY:
                                String dayOfWeek = Arrays.toString(dynMailContentDataBean.getChkDayOfWeek()).substring(1,
                                        Arrays.toString(dynMailContentDataBean.getChkDayOfWeek()).lastIndexOf("]"));
                                Pattern p = Pattern.compile("[,\\s]+");
                                String index[] = p.split(dayOfWeek);
                                StringBuilder arr= new StringBuilder();
                               for (String string : index) {
                                   arr.append(mapDayOfWeek.get(Integer.parseInt(string))).append(",");
                                }
                                cronExpression.append("0 ").append(dynMailContentDataBean.getSelmins()).append(" ").
                                        append(dynMailContentDataBean.getSelhrs()).append(" ? * ").append(dayOfWeek).append(" *");
                                cronString.append("Every ").append(arr.substring(0, arr.length()-1).toString()).append(" ").append(startTime);
                                break;
                            case INTERVALTYPE_MONTHLY:
                                if (dynMailContentDataBean.getRdMthlyOpt() == 0) {
                                    cronExpression.append("0 ").append(dynMailContentDataBean.getSelmins()).append(" ").
                                            append(dynMailContentDataBean.getSelhrs()).append(" ").append(dynMailContentDataBean.getTxtDayOfMonth()).append(" ").
                                            append("1/").append(dynMailContentDataBean.getTxtEveryMonth()).append(" ? *");

                                    cronString.append("Day ").append(dynMailContentDataBean.getTxtDayOfMonth()).append(" of every ").append(dynMailContentDataBean.getTxtEveryMonth()).append(" month(s)").append(startTime);
                                } else {
                                    cronExpression.append("0 ").append(dynMailContentDataBean.getSelmins()).append(" ").
                                            append(dynMailContentDataBean.getSelhrs()).append(" ? 1/").append(dynMailContentDataBean.getTxtEveryMonth()).append(" ").
                                            append(dynMailContentDataBean.getSelDayOfWeek()).append("#").append(dynMailContentDataBean.getSelNoOfWeek()).append(" *");
                                    cronString.append("The ").append(mapWeek.get(dynMailContentDataBean.getSelNoOfWeek())).append(" ").append(mapDayOfWeek.get(dynMailContentDataBean.getSelDayOfWeek())).append(" of every ").append(dynMailContentDataBean.getTxtEveryMonth()).append(startTime);
                                }
                                break;
                            case INTERVALTYPE_YEARLY:
                                if (dynMailContentDataBean.getRdYrlyOpt() == 0) {
                                    cronExpression.append("0 ").append(dynMailContentDataBean.getSelmins()).append(" ").
                                            append(dynMailContentDataBean.getSelhrs()).append(" ").append(dynMailContentDataBean.getTxtDayOfMonth()).append(" ").
                                            append(dynMailContentDataBean.getSelMonth()).append(" ? *");
                                    cronString.append("Every ").append(mapMonth.get(dynMailContentDataBean.getSelMonth())).append(" ").append(dynMailContentDataBean.getTxtDayOfMonth()).append(startTime);
                                } else {
                                    cronExpression.append("0 ").append(dynMailContentDataBean.getSelmins()).append(" ").
                                            append(dynMailContentDataBean.getSelhrs()).append(" ? ").append(dynMailContentDataBean.getSelMonth()).append(" ").
                                            append(dynMailContentDataBean.getSelDayOfWeek()).append("#").append(dynMailContentDataBean.getSelNoOfWeek()).append(" *");
                                    cronString.append("The ").append(mapWeek.get(dynMailContentDataBean.getSelNoOfWeek())).append(" ").append(mapDayOfWeek.get(dynMailContentDataBean.getSelDayOfWeek())).append(" of every ").append(mapMonth.get(dynMailContentDataBean.getSelMonth())).append(startTime);
                                }
                                break;
                        }
                        dynMailContentDataBean.setCronExpression(cronExpression.toString());
                        dynMailContentDataBean.setDescriptionForCronExpression(cronString.toString());
                    }
                }

                TblDynMailContent tblDynMailContent = new TblDynMailContent();
                tblDynMailContent.setMailContent(dynMailContentDataBean.getRtfcontent());
                tblDynMailContent.setSubject(dynMailContentDataBean.getTxtsubject());
                tblDynMailContent.setToDescription(dynMailContentDataBean.getTxtatodescription());
                tblDynMailContent.setTblLink(new TblLink(dynMailContentDataBean.getSelLinkId()));
                tblDynMailContent.setIsScheduled(dynMailContentDataBean.getRdisscheduled());
                tblDynMailContent.setCronExpression(dynMailContentDataBean.getCronExpression());
                tblDynMailContent.setIsStaticSign(dynMailContentDataBean.getRdisstaticsign());
                tblDynMailContent.setSignature(dynMailContentDataBean.getRtfsignature());
                tblDynMailContent.setTemplateDescription(dynMailContentDataBean.getTxtatemplateDescription());
                tblDynMailContent.setHasAttachment(dynMailContentDataBean.getRdhasAttachment());
                tblDynMailContent.setDescriptionForCronExpression(dynMailContentDataBean.getDescriptionForCronExpression());
                tblDynMailContent.setIsActive(1);
                tblDynMailContent.setMessageContent(dynMailContentDataBean.getRtfmessageContent());
                tblDynMailContent.setMessageSubject(dynMailContentDataBean.getTxtmessageSubject());
                tblDynMailContent.setIpAddress(ipAddress);
                tblDynMailContent.setUpdatedBy(abcUtility.getSessionUserDetailId(request));
                tblDynMailContent.setUpdatedOn(commonService.getServerDateTime());
                
                if (dynMailContentDataBean.getRdisFromStatic()==1) {
                    tblDynMailContent.setFromId(dynMailContentDataBean.getTxtfromId());
                    tblDynMailContent.setDynamicFromDesc("");
                    
                } else {
                    tblDynMailContent.setFromId("");
                    tblDynMailContent.setDynamicFromDesc(dynMailContentDataBean.getTxtadynamicFromDesc());
                }
                if (dynMailContentDataBean.getRdisToStatic()==1) {
                    tblDynMailContent.setToId(dynMailContentDataBean.getTxttoid());
                    tblDynMailContent.setDynamicToDesc("");
                } else {
                    tblDynMailContent.setToId("");
                   tblDynMailContent.setDynamicToDesc(dynMailContentDataBean.getTxtadynamicToDesc());
                }

                boolean success;
                if (opType.equals(CREATE)) {
                    success = mailConfigureService.addTblDynMailContent(tblDynMailContent);
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "email_template_added_successfully");
                } else {
                    tblDynMailContent.setMailTemplateId(mailTemplateId);
                    success = mailConfigureService.updateTblDynMailTemplate(tblDynMailContent);
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "email_template_updated_successfully");
                }
            } else {
                redirectAttributes.addFlashAttribute("sessionExpired", true);
            }
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postDynamicMailContentGenAuditMsg, 0, 0);
//        }
        return "redirect:/common/admin/manageemailtemplate"+encryptDecryptUtils.generateRedirect("common/admin/manageemailtemplate", request);
    }

    /**
     * update mailContent and redirect EmailContentCreation
     *
     * @param dynMailContentDataBean
     * @param mailTemplateId
     * @param modelMap
     * @param request
     * @return String
     */
    @RequestMapping(value = "/common/admin/editmailcontent/{mailTemplateId}/{enc}", method = RequestMethod.GET)
    public String updateMailContent(@ModelAttribute DynMailContentDataBean dynMailContentDataBean, @PathVariable("mailTemplateId") Integer mailTemplateId, ModelMap modelMap, HttpServletRequest request) {
        int sessionUserId = abcUtility.getSessionUserId(request);
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {

                TblDynMailContent dynMailContent = mailConfigureService.getDynMailContentById(mailTemplateId);

                List<Object[]> lstModuleSubModuleEvent = mailConfigureService.getModuleSubmoduleEventList(mailTemplateId);

                List<TblModule> lstModule = commonService.getModuleList();
                List<SelectItem> selModule = modelToSelectItem.convertListIntoSelectItemList(lstModule, "moduleId", "lang" + WebUtils.getCookie(request, "locale").getValue());

                List<TblSubModule> lstSubModule = commonService.getSubModuleList((Integer) lstModuleSubModuleEvent.get(0)[6]);
                List<SelectItem> selSubModule = modelToSelectItem.convertListIntoSelectItemList(lstSubModule, "subModuleId", "lang" + WebUtils.getCookie(request, "locale").getValue());

                List<TblEvent> lstEvent = commonService.getEventList((Integer) lstModuleSubModuleEvent.get(0)[4]);
                List<SelectItem> selEvent = modelToSelectItem.convertListIntoSelectItemList(lstEvent, "eventId", "lang" + WebUtils.getCookie(request, "locale").getValue());

                List<TblLink> lstLink = commonService.getLinkList((Integer) lstModuleSubModuleEvent.get(0)[2]);
                List<SelectItem> selLink = modelToSelectItem.convertListIntoSelectItemList(lstLink, "linkId", "lang" + WebUtils.getCookie(request, "locale").getValue());

                dynMailContentDataBean.setTxtatemplateDescription(dynMailContent.getTemplateDescription());
                dynMailContentDataBean.setTxtsubject(dynMailContent.getSubject());

                if (dynMailContent.getDynamicFromDesc().length() != 0) {
                    dynMailContentDataBean.setTxtadynamicFromDesc(dynMailContent.getDynamicFromDesc());
                    dynMailContentDataBean.setRdisFromStatic(0);
                } else {
                    dynMailContentDataBean.setTxtfromId(dynMailContent.getFromId());
                    dynMailContentDataBean.setRdisFromStatic(1);
                }
                if (dynMailContent.getDynamicToDesc().length() != 0) {
                    dynMailContentDataBean.setTxtadynamicToDesc(dynMailContent.getDynamicToDesc());
                    dynMailContentDataBean.setRdisToStatic(0);
                } else {
                    dynMailContentDataBean.setTxttoid(dynMailContent.getToId());
                    dynMailContentDataBean.setRdisToStatic(1);
                }
                dynMailContentDataBean.setTxtatodescription(dynMailContent.getToDescription());
                dynMailContentDataBean.setSelModuleId((Integer) lstModuleSubModuleEvent.get(0)[6]);
                dynMailContentDataBean.setSelSubModuleId((Integer) lstModuleSubModuleEvent.get(0)[4]);
                dynMailContentDataBean.setSelEventId((Integer) lstModuleSubModuleEvent.get(0)[2]);
                dynMailContentDataBean.setSelLinkId(dynMailContent.getTblLink().getLinkId());
                dynMailContentDataBean.setRtfcontent(dynMailContent.getMailContent());
                dynMailContentDataBean.setRdisstaticsign(dynMailContent.getIsStaticSign());
                dynMailContentDataBean.setRtfsignature(dynMailContent.getSignature());
                dynMailContentDataBean.setRdhasAttachment(dynMailContent.getHasAttachment());
                dynMailContentDataBean.setRdisscheduled(dynMailContent.getIsScheduled());
                dynMailContentDataBean.setTxtmessageSubject(dynMailContent.getMessageSubject());
                dynMailContentDataBean.setRtfmessageContent(dynMailContent.getMessageContent());

                List<SelectItem> selIntervalType = new ArrayList<SelectItem>();
                selIntervalType.add(new SelectItem("Select Interval Type", 0));
                selIntervalType.add(new SelectItem("Minutes", 1));
                selIntervalType.add(new SelectItem("Hourly", 2));
                selIntervalType.add(new SelectItem("Daily", 3));
                selIntervalType.add(new SelectItem("Weekly", 4));
                selIntervalType.add(new SelectItem("Monthly", 5));
                selIntervalType.add(new SelectItem("Yearly", 6));
                modelMap.addAttribute("selIntervalType", selIntervalType);

                List<SelectItem> lstDayOfWeek = new ArrayList<SelectItem>();
                lstDayOfWeek.add(new SelectItem("Monday", 2));
                lstDayOfWeek.add(new SelectItem("Tuesday", 3));
                lstDayOfWeek.add(new SelectItem("Wednesday", 4));
                lstDayOfWeek.add(new SelectItem("Thrusday", 5));
                lstDayOfWeek.add(new SelectItem("Friday", 6));
                lstDayOfWeek.add(new SelectItem("Saturday", 7));
                lstDayOfWeek.add(new SelectItem("Sunday", 1));
                modelMap.addAttribute("lstDayOfWeek", lstDayOfWeek);

                List<SelectItem> lstMonth = new ArrayList<SelectItem>();
                lstMonth.add(new SelectItem("January", 1));
                lstMonth.add(new SelectItem("February", 2));
                lstMonth.add(new SelectItem("March", 3));
                lstMonth.add(new SelectItem("April", 4));
                lstMonth.add(new SelectItem("May", 5));
                lstMonth.add(new SelectItem("June", 6));
                lstMonth.add(new SelectItem("July", 7));
                lstMonth.add(new SelectItem("August", 8));
                lstMonth.add(new SelectItem("September", 9));
                lstMonth.add(new SelectItem("October", 10));
                lstMonth.add(new SelectItem("November", 11));
                lstMonth.add(new SelectItem("December", 12));
                modelMap.addAttribute("lstMonth", lstMonth);

                List<SelectItem> lstWeek = new ArrayList<SelectItem>();
                lstWeek.add(new SelectItem("First", 1));
                lstWeek.add(new SelectItem("Second", 2));
                lstWeek.add(new SelectItem("Third", 3));
                lstWeek.add(new SelectItem("Fourth", 4));
                modelMap.addAttribute("lstWeek", lstWeek);

                List<SelectItem> rdDailyOpt = new ArrayList<SelectItem>();
                rdDailyOpt.add(new SelectItem("", 0));
                rdDailyOpt.add(new SelectItem("", 1));
                modelMap.addAttribute("rdDailyOpt", rdDailyOpt);

                List<SelectItem> lstHrs = new ArrayList<SelectItem>();
                List<SelectItem> lstMins = new ArrayList<SelectItem>();
                for (int i = 0; i < 24; i++) {
                    if (i < 10) {
                        lstHrs.add(new SelectItem("0" + i, i));
                    } else {
                        lstHrs.add(new SelectItem(i, i));
                    }
                }
                for (int i = 0; i < 60; i++) {
                    if (i < 10) {
                        lstMins.add(new SelectItem("0" + i, i));
                    } else {
                        lstMins.add(new SelectItem(i, i));
                    }
                }

                dynMailContentDataBean.setCronExpression(dynMailContent.getCronExpression());
                dynMailContentDataBean.setDescriptionForCronExpression(dynMailContent.getDescriptionForCronExpression());
                modelMap.addAttribute("lstHrs", lstHrs);
                modelMap.addAttribute("lstMins", lstMins);


                List<SelectItem> radYesNo = new ArrayList<SelectItem>();
                radYesNo.add(new SelectItem("Yes", 1));
                radYesNo.add(new SelectItem("No", 0));
                modelMap.addAttribute("radYesNo", radYesNo);
                
                List<SelectItem> radAttachment = new ArrayList<SelectItem>();
                radAttachment.add(new SelectItem("No", 0));
                radAttachment.add(new SelectItem("Officer Attachment", 1));
                radAttachment.add(new SelectItem("Bidder Attachment", 2));
                modelMap.put("radAttachment", radAttachment);


                List<SelectItem> lstEditBox = new ArrayList<SelectItem>();
                lstEditBox.add(new SelectItem(" Do you want to edit Schedule ?", 1));
                modelMap.addAttribute("lstEditBox", lstEditBox);

                modelMap.addAttribute("dynMailContentDataBean", dynMailContentDataBean);
                modelMap.addAttribute("dynMailContent", dynMailContent);
                modelMap.addAttribute("lstModuleSubModuleEvent", lstModuleSubModuleEvent);
                modelMap.addAttribute("lstModule", selModule);
                modelMap.addAttribute("lstEvent", selEvent);
                modelMap.addAttribute("lstSubModule", selSubModule);
                modelMap.addAttribute("lstLink", selLink);
                modelMap.addAttribute("opType", EDIT);
            } else {
                modelMap.addAttribute("sessionExpired", true);
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auctioneditlink, getaucedit, auctionId, 0);
        }
        return "/common/EmailContentCreation";
    }

    /**
     * viewEmailTemplate
     *
     * @param enc
     * @param mailTemplateId
     * @return to String
     */
    @RequestMapping(value = {"/common/admin/viewmailcontent/{mailTemplateId}/{enc}"}, method = RequestMethod.GET)
    public String viewEmailTemplate(@ModelAttribute DynMailContentDataBean dynMailContentDataBean, @PathVariable("mailTemplateId") Integer mailTemplateId, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {

                List<Object[]> lstDynMailContent = mailConfigureService.viewMailTemplate(mailTemplateId, "lang" + WebUtils.getCookie(request, "locale").getValue());
                
                dynMailContentDataBean.setTxtatemplateDescription(lstDynMailContent.get(0)[10].toString());
                dynMailContentDataBean.setTxtsubject(lstDynMailContent.get(0)[3].toString());

                dynMailContentDataBean.setTxtatodescription(lstDynMailContent.get(0)[4].toString());
                dynMailContentDataBean.setRtfcontent(lstDynMailContent.get(0)[2].toString());
                dynMailContentDataBean.setRdisstaticsign((Integer)lstDynMailContent.get(0)[6]);
                dynMailContentDataBean.setRtfsignature(lstDynMailContent.get(0)[7].toString());
                dynMailContentDataBean.setRdhasAttachment((Integer)lstDynMailContent.get(0)[11]);
                dynMailContentDataBean.setRdisscheduled((Integer)lstDynMailContent.get(0)[5]);
                
                dynMailContentDataBean.setModuleName(lstDynMailContent.get(0)[13].toString());
                dynMailContentDataBean.setSubModuleName(lstDynMailContent.get(0)[14].toString());
                dynMailContentDataBean.setEventName(lstDynMailContent.get(0)[15].toString());
                dynMailContentDataBean.setLinkName(lstDynMailContent.get(0)[16].toString());
                
                dynMailContentDataBean.setTxtfromId(lstDynMailContent.get(0)[0].toString());
                dynMailContentDataBean.setTxttoid(lstDynMailContent.get(0)[1].toString());
                
                dynMailContentDataBean.setDescriptionForCronExpression(lstDynMailContent.get(0)[12]==null?"":lstDynMailContent.get(0)[12].toString());
                
                if (dynMailContentDataBean.getTxtfromId().length() != 0) {
                    dynMailContentDataBean.setTxtadynamicFromDesc("");
                    dynMailContentDataBean.setRdisFromStatic(1);
                } else {
                    dynMailContentDataBean.setTxtadynamicFromDesc(lstDynMailContent.get(0)[8].toString());
                    dynMailContentDataBean.setRdisFromStatic(0);
                }
                if (dynMailContentDataBean.getTxttoid().length() != 0) {
                    dynMailContentDataBean.setTxtadynamicToDesc("");
                    dynMailContentDataBean.setRdisToStatic(1);
                } else {
                    dynMailContentDataBean.setTxtadynamicToDesc(lstDynMailContent.get(0)[9].toString());
                    dynMailContentDataBean.setRdisToStatic(0);
                }
                 modelMap.addAttribute("dynMailContentDataBean", dynMailContentDataBean);
            } else {
                modelMap.addAttribute("sessionExpired", true);
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auctioneditlink, getaucedit, auctionId, 0);
        }
        return "/common/ViewEmailtemplate";
    }

    @RequestMapping(value = {"/common/admin/getclient/{mailTemplateId}/{enc}"}, method = RequestMethod.GET)
    public String mapEmailTemplate(@ModelAttribute DynMailContentDataBean dynMailContentDataBean, @PathVariable("mailTemplateId") Integer mailTemplateId, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {


        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {

                TblDynMailContent dynMailContent = mailConfigureService.getDynMailContentById(mailTemplateId);
                dynMailContentDataBean.setTxtsubject(dynMailContent.getSubject());
                dynMailContentDataBean.setHdmailTemplateId(mailTemplateId);
                List<Object[]> lstClient = mailConfigureService.getClientDetails(mailTemplateId);
                List<SelectItem> selModule = abcUtility.convertSelected(lstClient);
                modelMap.put("lstClient", selModule);
                modelMap.put("dynMailContentDataBean", dynMailContentDataBean);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return "/common/MapClientforEmailtemplate";
    }

    @RequestMapping(value = {"/common/admin/editmailcontent/mapClient"}, method = RequestMethod.POST)
    public String mapEmailTemplate(@ModelAttribute DynMailContentDataBean dynMailContentDataBean, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {


        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {

                String hdmailTemplateId = request.getParameter("hdmailTemplateId");
                List<Object[]> selectedClientMailtemplateList = mailConfigureService.getClientMailTemplateBymailTemplateId(Integer.parseInt(hdmailTemplateId));
                String chkClients[] = null;
                List<TblClientMailTemplate> listClientMailtemplate = new ArrayList<TblClientMailTemplate>();

                if (request.getParameterValues("chkClientId") != null) {
                    chkClients = request.getParameterValues("chkClientId");
                }
                List<String> clientListforUnmap = new ArrayList<String>();
                List<String> clientListforMap = new ArrayList<String>();
                boolean flag;
                for (Object obj : selectedClientMailtemplateList) {
                    flag = false;
                    for (String clientId : chkClients) {
                        if (obj.toString().equals(clientId)) {
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) {
                        clientListforUnmap.add(obj.toString());
                    }
                }
                for (String clientId : chkClients) {
                    flag = false;
                    for (Object obj : selectedClientMailtemplateList) {
                        if (obj.toString().equals(clientId)) {
                            flag = true;
                            break;
                        }
                    }
                    if (!flag) {
                        clientListforMap.add(clientId);
                    }
                }
                TblClientMailTemplate tblClientMailTemplate;

                for (String clientId : clientListforMap) {

                    tblClientMailTemplate = new TblClientMailTemplate();
                    tblClientMailTemplate.setTblClient(new TblClient(Integer.parseInt(clientId)));
                    tblClientMailTemplate.setTblMailTemplate(new TblDynMailContent(Integer.parseInt(hdmailTemplateId)));
                    tblClientMailTemplate.setCreatedBy(abcUtility.getSessionUserId(request));
                    tblClientMailTemplate.setIsActive(1);
                    tblClientMailTemplate.setUpdatedOn((commonService.getServerDateTime()));
                    tblClientMailTemplate.setUpdatedBy(abcUtility.getSessionUserId(request));
                    listClientMailtemplate.add(tblClientMailTemplate);

                }
                boolean success=false;
                if(listClientMailtemplate.size()>0){
                    success=mailConfigureService.addTblClientMailTemplate(listClientMailtemplate);
                }
                if(clientListforUnmap.size()>0){
                success=mailConfigureService.unMapTblClientMailTemplate(clientListforUnmap, abcUtility.getSessionUserId(request), commonService.getServerDateTime());
                }
                if(success){
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "client_map_unmap");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/common/admin/manageemailtemplate"+encryptDecryptUtils.generateRedirect("common/admin/manageemailtemplate", request);
    }

    @RequestMapping(value = {"/common/admin/deletemailcontent/{mailTemplateId}/{enc}"}, method = RequestMethod.GET)
    public String deleteEmailTemplate(@PathVariable("mailTemplateId") Integer mailTemplateId, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {

                boolean result = mailConfigureService.deleteTblDynMailContent(mailTemplateId);
                if(result){
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "email_template_deleted_successfully");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "common/admin/manageemailtemplate";
    }

    @RequestMapping(value = {"/common/admin/loadTemplateQuery/{mailTemplateId}/{enc}"}, method = RequestMethod.GET)
    public String loadTemplateQuery(@ModelAttribute TemplateQueryDataBean templateQueryDataBean, @PathVariable("mailTemplateId") Integer mailTemplateId, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {

                List<Object[]> lstType = mailConfigureService.getTypeList();
                List<SelectItem> lstTypeSelectType = abcUtility.convert(lstType);
                List<SelectItem> lstInputParam = new ArrayList<SelectItem>();
                lstInputParam.add(new SelectItem("userId", "userId"));
                lstInputParam.add(new SelectItem("clientId", "clientId"));
                modelMap.put("lstInputParam", lstInputParam);
                modelMap.put("lstType", lstTypeSelectType);
                modelMap.put("mailTemplateId", mailTemplateId);
                modelMap.put(OPTYPE, CREATE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "/common/DynamicMailContentQuery";
    }

    @RequestMapping(value = {"/common/admin/submitTemplateQuery/{opType}/{mailTemplateId}/{templateQueryId}"}, method = RequestMethod.POST)
    public String submitTemplateQuery(@ModelAttribute TemplateQueryDataBean templateQueryDataBean, @PathVariable("templateQueryId") Integer templateQueryId, @PathVariable("opType") String opType, @PathVariable("mailTemplateId") Integer mailTemplateId, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {

                TblTemplateQuery tblTemplateQuery = new TblTemplateQuery();
                tblTemplateQuery.setInputParam(templateQueryDataBean.getSelInputParam());
                tblTemplateQuery.setTblDynMailContent(new TblDynMailContent(mailTemplateId));
                tblTemplateQuery.setTblType(new TblType(templateQueryDataBean.getSelTypeId()));
                tblTemplateQuery.setTemplateQuery(templateQueryDataBean.getTxtaTemplateQuery());
                boolean success;
                if (opType.equals(CREATE)) {
                     success = mailConfigureService.addTblTemplateQuery(tblTemplateQuery);
                    redirectAttributes.addFlashAttribute("successMsg", "email_template_added_successfully");

                } else {
                    tblTemplateQuery.setTemplateQueryId(templateQueryId);
                    success = mailConfigureService.updateTblTemplateQuery(tblTemplateQuery);
                    redirectAttributes.addFlashAttribute("successMsg", "email_template_updated_successfully");
                    modelMap.put(OPTYPE, CREATE);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/common/admin/manageemailtemplate"+encryptDecryptUtils.generateRedirect("common/admin/manageemailtemplate", request);
    }
    
    @RequestMapping(value = {"/common/admin/gettemplatequery/{mailTemplateId}/{templateQueryId}/{enc}"}, method = RequestMethod.GET)
    public String getTemplateQuery(@ModelAttribute TemplateQueryDataBean templateQueryDataBean, @PathVariable("mailTemplateId") Integer mailTemplateId,@PathVariable("templateQueryId") Integer templateQueryId, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                
                TblTemplateQuery tblTemplateQuery  = mailConfigureService.getTblTemplateQueryById(templateQueryId,mailTemplateId);
               
                templateQueryDataBean.setSelInputParam(tblTemplateQuery.getInputParam());
                templateQueryDataBean.setSelTypeId(tblTemplateQuery.getTblType().getTypeId());
                templateQueryDataBean.setTxtaTemplateQuery(tblTemplateQuery.getTemplateQuery());
                templateQueryDataBean.setTemplateQueryId(templateQueryId);
                templateQueryDataBean.setMailTemplateId(mailTemplateId);
                
                
                List<Object[]> lstType = mailConfigureService.getTypeList();
                List<SelectItem> lstTypeSelectType = abcUtility.convert(lstType);
                List<SelectItem> lstInputParam = new ArrayList<SelectItem>();
                lstInputParam.add(new SelectItem("userId", "userId"));
                lstInputParam.add(new SelectItem("clientId", "clientId"));
                modelMap.put("lstInputParam", lstInputParam);
                modelMap.put("lstType", lstTypeSelectType);
                modelMap.put("mailTemplateId", mailTemplateId);
                modelMap.put(OPTYPE, EDIT);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "/common/DynamicMailContentQuery";
    }
    
}
