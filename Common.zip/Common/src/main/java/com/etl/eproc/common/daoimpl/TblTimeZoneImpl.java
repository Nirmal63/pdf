package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblTimeZoneDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblTimeZone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblTimeZoneImpl extends AbcAbstractClass<TblTimeZone> implements TblTimeZoneDao {

    @Override
    public void addTblTimeZone(TblTimeZone tblTimeZone){
        super.addEntity(tblTimeZone);
    }

    @Override
    public void deleteTblTimeZone(TblTimeZone tblTimeZone) {
        super.deleteEntity(tblTimeZone);
    }

    @Override
    public void updateTblTimeZone(TblTimeZone tblTimeZone) {
        super.updateEntity(tblTimeZone);
    }

    @Override
    public List<TblTimeZone> getAllTblTimeZone() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTimeZone> findTblTimeZone(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTimeZoneCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTimeZone> findByCountTblTimeZone(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTimeZone(List<TblTimeZone> tblTimeZones){
        super.updateAll(tblTimeZones);
    }
}
