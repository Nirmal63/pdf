package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCrlDetail;
import java.util.List;

public interface TblCrlDetailDao  {

    public void addTblCrlDetail(TblCrlDetail tblCrlDetail);

    public void deleteTblCrlDetail(TblCrlDetail tblCrlDetail);

    public void updateTblCrlDetail(TblCrlDetail tblCrlDetail);

    public List<TblCrlDetail> getAllTblCrlDetail();

    public List<TblCrlDetail> findTblCrlDetail(Object... values) throws Exception;

    public List<TblCrlDetail> findByCountTblCrlDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCrlDetailCount();

    public void saveUpdateAllTblCrlDetail(List<TblCrlDetail> tblCrlDetails);
}