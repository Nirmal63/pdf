package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblWorkflowDetail;
import com.etl.eproc.common.daointerface.TblWorkflowDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblWorkflowDetailImpl extends AbcAbstractClass<TblWorkflowDetail> implements TblWorkflowDetailDao {

    @Override
    public void addTblWorkflowDetail(TblWorkflowDetail tblWorkflowDetail){
        super.addEntity(tblWorkflowDetail);
    }

    @Override
    public void deleteTblWorkflowDetail(TblWorkflowDetail tblWorkflowDetail) {
        super.deleteEntity(tblWorkflowDetail);
    }

    @Override
    public void updateTblWorkflowDetail(TblWorkflowDetail tblWorkflowDetail) {
        super.updateEntity(tblWorkflowDetail);
    }

    @Override
    public List<TblWorkflowDetail> getAllTblWorkflowDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblWorkflowDetail> findTblWorkflowDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblWorkflowDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblWorkflowDetail> findByCountTblWorkflowDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblWorkflowDetail(List<TblWorkflowDetail> tblWorkflowDetails){
        super.updateAll(tblWorkflowDetails);
    }
}
