package com.etl.eproc.common.daointerface;

import java.util.List;


import com.etl.eproc.common.model.TblBidderGstDetails;


public interface TblBidderGstDetailsDao  {
	
	public void addTblBidderGstDetails(TblBidderGstDetails tblBidderGstDetails);

    public void deleteTblBidderGstDetails(TblBidderGstDetails tblBidderGstDetails);

    public void updateTblBidderGstDetails(TblBidderGstDetails tblBidderGstDetails);

    public List<TblBidderGstDetails> getAllTblBidderGstDetails();

    public List<TblBidderGstDetails> findTblBidderGstDetails(Object... values) throws Exception;

    public List<TblBidderGstDetails> findByCountTblBidderGstDetails(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidderGstDetailsCount();

    public void saveUpdateAllTblBidderGstDetails(List<TblBidderGstDetails> tblBidderGstDetails);

	public void saveOrUpdateTblBidderGstDetails(TblBidderGstDetails tblBidderGstDetails);
}
