package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblEmarketUserRightDao;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblEmarketUserRight;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblEmarketUserRightImpl extends AbcAbstractClass<TblEmarketUserRight> implements TblEmarketUserRightDao {

    @Override
    public void addTblEmarketUserRight(TblEmarketUserRight tblEmarketUserRight){
        super.addEntity(tblEmarketUserRight);
    }

    @Override
    public void deleteTblEmarketUserRight(TblEmarketUserRight tblEmarketUserRight) {
        super.deleteEntity(tblEmarketUserRight);
    }

    @Override
    public void updateTblEmarketUserRight(TblEmarketUserRight tblEmarketUserRight) {
        super.updateEntity(tblEmarketUserRight);
    }

    @Override
    public List<TblEmarketUserRight> getAllTblEmarketUserRight() {
        return super.getAllEntity();
    }

    @Override
    public List<TblEmarketUserRight> findTblEmarketUserRight(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblEmarketUserRightCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblEmarketUserRight> findByCountTblEmarketUserRight(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblEmarketUserRight(List<TblEmarketUserRight> tblEmarketUserRights){
        super.updateAll(tblEmarketUserRights);
    }
}
