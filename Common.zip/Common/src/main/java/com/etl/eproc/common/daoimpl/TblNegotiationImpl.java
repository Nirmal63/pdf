package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblNegotiation;
import com.etl.eproc.common.daointerface.TblNegotiationDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblNegotiationImpl extends AbcAbstractClass<TblNegotiation> implements TblNegotiationDao {

    @Override
    public void addTblNegotiation(TblNegotiation tblNegotiation){
        super.addEntity(tblNegotiation);
    }

    @Override
    public void deleteTblNegotiation(TblNegotiation tblNegotiation) {
        super.deleteEntity(tblNegotiation);
    }

    @Override
    public void updateTblNegotiation(TblNegotiation tblNegotiation) {
        super.updateEntity(tblNegotiation);
    }

    @Override
    public List<TblNegotiation> getAllTblNegotiation() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNegotiation> findTblNegotiation(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNegotiationCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNegotiation> findByCountTblNegotiation(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNegotiation(List<TblNegotiation> tblNegotiations){
        super.updateAll(tblNegotiations);
    }
}

