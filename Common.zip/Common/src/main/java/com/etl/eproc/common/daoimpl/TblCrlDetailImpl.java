package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblCrlDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblCrlDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCrlDetailImpl extends AbcAbstractClass<TblCrlDetail> implements TblCrlDetailDao {

    @Override
    public void addTblCrlDetail(TblCrlDetail tblCrlDetail){
        super.addEntity(tblCrlDetail);
    }

    @Override
    public void deleteTblCrlDetail(TblCrlDetail tblCrlDetail) {
        super.deleteEntity(tblCrlDetail);
    }

    @Override
    public void updateTblCrlDetail(TblCrlDetail tblCrlDetail) {
        super.updateEntity(tblCrlDetail);
    }

    @Override
    public List<TblCrlDetail> getAllTblCrlDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCrlDetail> findTblCrlDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCrlDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCrlDetail> findByCountTblCrlDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCrlDetail(List<TblCrlDetail> tblCrlDetails){
        super.updateAll(tblCrlDetails);
    }
}
