package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblPaymentGatewayMaster;
import com.etl.eproc.common.daointerface.TblPaymentGatewayMasterDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblPaymentGatewayMasterImpl extends AbcAbstractClass<TblPaymentGatewayMaster> implements TblPaymentGatewayMasterDao {

    @Override
    public void addTblPaymentGatewayMaster(TblPaymentGatewayMaster tblPaymentGatewayMaster){
        super.addEntity(tblPaymentGatewayMaster);
    }

    @Override
    public void deleteTblPaymentGatewayMaster(TblPaymentGatewayMaster tblPaymentGatewayMaster) {
        super.deleteEntity(tblPaymentGatewayMaster);
    }

    @Override
    public void updateTblPaymentGatewayMaster(TblPaymentGatewayMaster tblPaymentGatewayMaster) {
        super.updateEntity(tblPaymentGatewayMaster);
    }

    @Override
    public List<TblPaymentGatewayMaster> getAllTblPaymentGatewayMaster() {
        return super.getAllEntity();
    }

    @Override
    public List<TblPaymentGatewayMaster> findTblPaymentGatewayMaster(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblPaymentGatewayMasterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblPaymentGatewayMaster> findByCountTblPaymentGatewayMaster(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblPaymentGatewayMaster(List<TblPaymentGatewayMaster> tblPaymentGatewayMasters){
        super.updateAll(tblPaymentGatewayMasters);
    }
}
