package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblAuctionDigitalSignHistoryNewDao;
import com.etl.eproc.eauction.model.TblAuctionDigitalSignHistoryNew;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblAuctionDigitalSignHistoryNewImpl extends AbcAbstractClass<TblAuctionDigitalSignHistoryNew> implements TblAuctionDigitalSignHistoryNewDao {

    @Override
    public void addTblAuctionDigitalSignHistoryNew(TblAuctionDigitalSignHistoryNew TblAuctionDigitalSignHistoryNew){
        super.addEntity(TblAuctionDigitalSignHistoryNew);
    }

    @Override
    public void deleteTblAuctionDigitalSignHistoryNew(TblAuctionDigitalSignHistoryNew TblAuctionDigitalSignHistoryNew) {
        super.deleteEntity(TblAuctionDigitalSignHistoryNew);
    }

    @Override
    public void updateTblAuctionDigitalSignHistoryNew(TblAuctionDigitalSignHistoryNew TblAuctionDigitalSignHistoryNew) {
        super.updateEntity(TblAuctionDigitalSignHistoryNew);
    }

    @Override
    public List<TblAuctionDigitalSignHistoryNew> getAllTblAuctionDigitalSignHistoryNew() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAuctionDigitalSignHistoryNew> findTblAuctionDigitalSignHistoryNew(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAuctionDigitalSignHistoryNewCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAuctionDigitalSignHistoryNew> findByCountTblAuctionDigitalSignHistoryNew(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAuctionDigitalSignHistoryNew(List<TblAuctionDigitalSignHistoryNew> TblAuctionDigitalSignHistoryNews){
        super.updateAll(TblAuctionDigitalSignHistoryNews);
    }
}
