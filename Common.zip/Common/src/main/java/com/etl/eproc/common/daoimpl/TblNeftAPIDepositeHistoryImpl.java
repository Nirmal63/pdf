package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblNeftAPIDepositeHistory;
import com.etl.eproc.common.daointerface.TblNeftAPIDepositeHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblNeftAPIDepositeHistoryImpl extends AbcAbstractClass<TblNeftAPIDepositeHistory> implements TblNeftAPIDepositeHistoryDao {

    @Override
    public void addTblNeftAPIDepositeHistory(TblNeftAPIDepositeHistory tblNeftAPIDepositeHistory){
        super.addEntity(tblNeftAPIDepositeHistory);
    }

    @Override
    public void deleteTblNeftAPIDepositeHistory(TblNeftAPIDepositeHistory tblNeftAPIDepositeHistory) {
        super.deleteEntity(tblNeftAPIDepositeHistory);
    }

    @Override
    public void updateTblNeftAPIDepositeHistory(TblNeftAPIDepositeHistory tblNeftAPIDepositeHistory) {
        super.updateEntity(tblNeftAPIDepositeHistory);
    }

    @Override
    public List<TblNeftAPIDepositeHistory> getAllTblNeftAPIDepositeHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNeftAPIDepositeHistory> findTblNeftAPIDepositeHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNeftAPIDepositeHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNeftAPIDepositeHistory> findByCountTblNeftAPIDepositeHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNeftAPIDepositeHistory(List<TblNeftAPIDepositeHistory> tblNeftAPIDepositeHistorys){
        super.updateAll(tblNeftAPIDepositeHistorys);
    }

	@Override
	public void saveOrUpdateTblNeftAPIDepositeHistory(TblNeftAPIDepositeHistory tblNeftAPIDepositeHistory) {
		super.saveOrUpdateEntity(tblNeftAPIDepositeHistory);
	}
}
