package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblClientModuleDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblClientModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientModuleImpl extends AbcAbstractClass<TblClientModule> implements TblClientModuleDao {

    @Override
    public void addTblClientModule(TblClientModule tblClientModule){
        super.addEntity(tblClientModule);
    }

    @Override
    public void deleteTblClientModule(TblClientModule tblClientModule) {
        super.deleteEntity(tblClientModule);
    }

    @Override
    public void updateTblClientModule(TblClientModule tblClientModule) {
        super.updateEntity(tblClientModule);
    }

    @Override
    public List<TblClientModule> getAllTblClientModule() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientModule> findTblClientModule(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientModuleCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientModule> findByCountTblClientModule(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientModule(List<TblClientModule> tblClientModules){
        super.updateAll(tblClientModules);
    }
}
