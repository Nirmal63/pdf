/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.SelectItem;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.etl.eproc.common.databean.ReportDataBean;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.bind.annotation.ModelAttribute;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ReportEntryService;


/**
 *
 * @author vanita
 */
@Controller
public class ReportEntryController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private ReportEntryService reportService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private ReloadableResourceBundleMessageSource messageSource;

    /**
     * Create Report
     *
     * @param request
     * @param modelMap
     * @return to String
     */
    @RequestMapping(value = "/createreport", method = RequestMethod.GET)
    public String createReport(ModelMap modelMap, HttpServletRequest request) {
        try {
            List<SelectItem> pagination = new ArrayList<SelectItem>();
            pagination.add(new SelectItem(messageSource.getMessage("label_yes", null, LocaleContextHolder.getLocale()), "Yes"));
            pagination.add(new SelectItem(messageSource.getMessage("label_no", null, LocaleContextHolder.getLocale()), "No"));
            modelMap.put("rdpagination", pagination);
            List<SelectItem> reportType = new ArrayList<SelectItem>();
            reportType.add(new SelectItem(messageSource.getMessage("reporttype_vertical", null, LocaleContextHolder.getLocale()), "V"));
            reportType.add(new SelectItem(messageSource.getMessage("reporttype_linear", null, LocaleContextHolder.getLocale()), "L"));
            reportType.add(new SelectItem(messageSource.getMessage("reporttype_horizontal", null, LocaleContextHolder.getLocale()), "H"));
            modelMap.put("reportType", reportType);
            List<SelectItem> pdfRequire = new ArrayList<SelectItem>();
            pdfRequire.add(new SelectItem(messageSource.getMessage("label_yes", null, LocaleContextHolder.getLocale()), "Y"));
            pdfRequire.add(new SelectItem(messageSource.getMessage("label_no", null, LocaleContextHolder.getLocale()), "N"));
            modelMap.put("rdpdfrequire", pdfRequire);
            List<SelectItem> excelRequire = new ArrayList<SelectItem>();
            excelRequire.add(new SelectItem(messageSource.getMessage("label_yes", null, LocaleContextHolder.getLocale()), "Y"));
            excelRequire.add(new SelectItem(messageSource.getMessage("label_no", null, LocaleContextHolder.getLocale()), "N"));
            modelMap.put("rdexcelrequire", excelRequire);
            List<SelectItem> dispSearchCriteria = new ArrayList<SelectItem>();
            dispSearchCriteria.add(new SelectItem(messageSource.getMessage("label_yes", null, LocaleContextHolder.getLocale()), "Y"));
            dispSearchCriteria.add(new SelectItem(messageSource.getMessage("label_no", null, LocaleContextHolder.getLocale()), "N"));
            modelMap.put("rddisplaysearchcriteria", dispSearchCriteria);
            List<SelectItem> dispAllTabCount = new ArrayList<SelectItem>();
            dispAllTabCount.add(new SelectItem(messageSource.getMessage("label_yes", null, LocaleContextHolder.getLocale()), "Y"));
            dispAllTabCount.add(new SelectItem(messageSource.getMessage("label_no", null, LocaleContextHolder.getLocale()), "N"));
            modelMap.put("rddispalltabcount", dispAllTabCount);
            List<SelectItem> isFromSp = new ArrayList<SelectItem>();
            isFromSp.add(new SelectItem(messageSource.getMessage("label_yes", null, LocaleContextHolder.getLocale()), "1"));
            isFromSp.add(new SelectItem(messageSource.getMessage("label_no", null, LocaleContextHolder.getLocale()), "0"));
            modelMap.put("rdisfromsp", isFromSp);
            List<SelectItem> controlType = new ArrayList<SelectItem>();
            controlType.add(new SelectItem(messageSource.getMessage("controltype_combo", null, LocaleContextHolder.getLocale()), "combo"));
            controlType.add(new SelectItem(messageSource.getMessage("controltype_tab", null, LocaleContextHolder.getLocale()), "tab"));
            controlType.add(new SelectItem(messageSource.getMessage("controltype_tree", null, LocaleContextHolder.getLocale()), "tree"));
            modelMap.put("controltype", controlType);
            List<SelectItem> isdefSelected = new ArrayList<SelectItem>();
            isdefSelected.add(new SelectItem(messageSource.getMessage("label_yes", null, LocaleContextHolder.getLocale()), "Y"));
            isdefSelected.add(new SelectItem(messageSource.getMessage("label_no", null, LocaleContextHolder.getLocale()), "N"));
            modelMap.put("isDefSelected", isdefSelected);
            List<SelectItem> datatype = new ArrayList<SelectItem>();
            datatype.add(new SelectItem(messageSource.getMessage("label_text", null, LocaleContextHolder.getLocale()), "text"));
            datatype.add(new SelectItem(messageSource.getMessage("label_date", null, LocaleContextHolder.getLocale()), "date"));
            datatype.add(new SelectItem(messageSource.getMessage("label_datetime", null, LocaleContextHolder.getLocale()), "datetime"));
            datatype.add(new SelectItem(messageSource.getMessage("label_numeric", null, LocaleContextHolder.getLocale()), "numeric"));
            modelMap.put("datatype", datatype);
            List<SelectItem> isSearchRequired = new ArrayList<SelectItem>();
            isSearchRequired.add(new SelectItem(messageSource.getMessage("label_yes", null, LocaleContextHolder.getLocale()), "yes"));
            isSearchRequired.add(new SelectItem(messageSource.getMessage("label_no", null, LocaleContextHolder.getLocale()), "no"));
            modelMap.put("isSearchRequired", isSearchRequired);
            List<SelectItem> searchType = new ArrayList<SelectItem>();
            searchType.add(new SelectItem(messageSource.getMessage("label_normalsearch", null, LocaleContextHolder.getLocale()), "N"));
            searchType.add(new SelectItem(messageSource.getMessage("label_advancesearch", null, LocaleContextHolder.getLocale()), "A"));
            modelMap.put("searchType", searchType);
            List<SelectItem> searchCriteria = new ArrayList<SelectItem>();
            searchCriteria.add(new SelectItem(messageSource.getMessage("label_like", null, LocaleContextHolder.getLocale()), "0"));
            searchCriteria.add(new SelectItem(messageSource.getMessage("label_equal", null, LocaleContextHolder.getLocale()), "1"));
            modelMap.put("searchCriteria", searchCriteria);
            List<SelectItem> flag = new ArrayList<SelectItem>();
            flag.add(new SelectItem(messageSource.getMessage("label_regular", null, LocaleContextHolder.getLocale()), "R"));
            flag.add(new SelectItem(messageSource.getMessage("label_advance", null, LocaleContextHolder.getLocale()), "E"));
            modelMap.put("flag", flag);
           
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 100, "Create Report", 0, 0);
        }
        return "CreateReport";
    }

    @RequestMapping(value = "/addreport", method = RequestMethod.POST)
    public String addReport(@ModelAttribute ReportDataBean reportDataBean, ModelMap map,RedirectAttributes redirectAttributes, HttpServletRequest request) {     
        boolean status=false;
        String successMsgCode = "";
       String retVal = "";
        try{
        status=reportService.addReportDtl(reportDataBean);
        if(status){
            successMsgCode="msg_success_reportCreation";
            retVal = "redirect:/";
            
        }else{
            successMsgCode = CommonKeywords.ERROR_MSG_KEY.toString();
            retVal = "redirect:/createreport";
        }
        redirectAttributes.addFlashAttribute(status ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), status ? successMsgCode : CommonKeywords.ERROR_MSG_KEY.toString());
        }catch(Exception e){
            return exceptionHandlerService.writeLog(e);
        }finally{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 100, "Create Report", 0, 0);
        }
        return retVal;
        
    }
}
