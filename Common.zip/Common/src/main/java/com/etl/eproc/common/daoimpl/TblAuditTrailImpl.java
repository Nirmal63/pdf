package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblAuditTrailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblAuditTrail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblAuditTrailImpl extends AbcAbstractClass<TblAuditTrail> implements TblAuditTrailDao {

    @Override
    public void addTblAuditTrail(TblAuditTrail tblAuditTrail){
        super.addEntity(tblAuditTrail);
    }

    @Override
    public void deleteTblAuditTrail(TblAuditTrail tblAuditTrail) {
        super.deleteEntity(tblAuditTrail);
    }

    @Override
    public void updateTblAuditTrail(TblAuditTrail tblAuditTrail) {
        super.updateEntity(tblAuditTrail);
    }

    @Override
    public List<TblAuditTrail> getAllTblAuditTrail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAuditTrail> findTblAuditTrail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAuditTrailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAuditTrail> findByCountTblAuditTrail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAuditTrail(List<TblAuditTrail> tblAuditTrails){
        super.updateAll(tblAuditTrails);
    }
}
