package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblTaskList;
import com.etl.eproc.common.daointerface.TblTaskListDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblTaskListImpl extends AbcAbstractClass<TblTaskList> implements TblTaskListDao {

    @Override
    public void addTblTaskList(TblTaskList tblTaskList){
        super.addEntity(tblTaskList);
    }

    @Override
    public void deleteTblTaskList(TblTaskList tblTaskList) {
        super.deleteEntity(tblTaskList);
    }

    @Override
    public void updateTblTaskList(TblTaskList tblTaskList) {
        super.updateEntity(tblTaskList);
    }

    @Override
    public List<TblTaskList> getAllTblTaskList() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTaskList> findTblTaskList(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTaskListCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTaskList> findByCountTblTaskList(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTaskList(List<TblTaskList> tblTaskLists){
        super.updateAll(tblTaskLists);
    }
}
