/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.util.ArrayList;
import java.util.List;

import com.etl.eproc.common.databean.DesignationDataBean;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblDesignation;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DesignationService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ManageContentService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.xmlbeans.impl.regex.REUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/**
 *
 * @author vipul
 */
@Controller
public class ManageDesignationController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private DesignationService designationService;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private ClientService clientService;
    private ManageContentService manageContentService;
    @Autowired
    @Value("#{projectProperties['errormsg.operation.fail']}")
    private String errorMsg;
    @Value("#{linkProperties['manage_designation_create_designation']?:9}")
    private String createDesignationLinkId;
    @Value("#{linkProperties['manage_designation_edit_designation']?:10}")
    private String editDesignationLinkId;
    @Value("#{linkProperties['manage_designation_approve']?:68}")
    private String approveDesignationLinkId;
    @Value("#{linkProperties['report_admin_manage_designation']?:3}")
    private int manageDesignationReportId;
    @Value("#{adminAuditTrailProperties['getmanagedesignation']}")
    private String getManageDesignationAuditMsg;
    @Value("#{adminAuditTrailProperties['getcreatedesignation']}")
    private String getCreateDesignationAuditMsg;
    @Value("#{adminAuditTrailProperties['posteditdesignation']}")
    private String postEditDesignationAuditMsg;
    @Value("#{adminAuditTrailProperties['postcreatedesignation']}")
    private String postCreateDesignationAuditMsg;
    @Value("#{adminAuditTrailProperties['geteditdesignation']}")
    private String getEditDesignationAuditMsg;
    @Value("#{adminAuditTrailProperties['getapprovedesignation']}")
    private String getApproveDesignationAuditMsg;
    @Value("#{adminAuditTrailProperties['postapprovedesignation']}")
    private String postApproveDesignationAuditMsg;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private CommonValidators commonValidators;

    @RequestMapping(value = "/common/admin/managedesignation/{enc}", method = RequestMethod.GET)
    public String searchAndListDesignation(ModelMap modelMap, HttpServletRequest req) {
        try {
            //int reportId = 3;
            modelMap.addAttribute("reportId", manageDesignationReportId);
            reportGeneratorService.getReportConfigDetails(manageDesignationReportId, modelMap);
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageDesignationReportId, getManageDesignationAuditMsg, 0, 0);
        }
        return "common/admin/ManageDesignation";
    }

    @RequestMapping(value = "/common/admin/createdesignation/{enc}", method = RequestMethod.GET)
    public String createDesignation(ModelMap modelMap, HttpServletRequest req) {
        try {
            modelMap.addAttribute("createDesig", "y");
            List<SelectItem> selGrades = new ArrayList<SelectItem>();
            List<Object[]> lstGradeNames = designationService.getGradeNames(abcUtility.getSessionClientId(req));
            selGrades.add(new SelectItem("--Please Select--", 0));
            for(int i=0; i<lstGradeNames.size(); i++){
            	selGrades.add(new SelectItem(lstGradeNames.get(i)[1], lstGradeNames.get(i)[0]));
            }
            modelMap.addAttribute("selGrades", selGrades);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(createDesignationLinkId), getCreateDesignationAuditMsg, 0, 0);
        }
        return "common/admin/CreateDesignation";
    }
    
    @ResponseBody
    @RequestMapping(value="common/admin/getfnlimit", method=RequestMethod.POST)
    public String getFnLimit(HttpServletRequest request,HttpServletResponse response){
    	StringBuilder retVal=new StringBuilder();
    	List<Object[]> result = null;
    	int userId = 0;
    	try {
			userId = abcUtility.getSessionUserId(request);
			if(userId!=0){
				int gradeId = StringUtils.hasLength(request.getParameter("txtGradeId")) ? Integer.parseInt(request.getParameter("txtGradeId")) : 0;
				result = designationService.getFnLimits(gradeId, abcUtility.getSessionClientId(request));
				if(result!=null && !result.isEmpty()){
					retVal.append(result.get(0)[0]+","+result.get(0)[1]+","+result.get(0)[2]);
				}
			}
			else{
				retVal.append("sessionexpired");
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
    	return retVal.toString();
    }
    @RequestMapping(value = "common/admin/adddesignation", method = RequestMethod.POST)
    public String addDesignation(@ModelAttribute DesignationDataBean designationDataBean, HttpServletRequest req, HttpSession httpSession,
            RedirectAttributes redirectAttributes, BindingResult result,ModelMap modelMap) {
        String pageView = "redirect:/sessionexpired";
        boolean isSuccess = false;
        try {
            if (req.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                
                designationDataBean.setCommonValidators(commonValidators);
                designationDataBean.validateBean(result);
                int gradeId = StringUtils.hasLength(req.getParameter("selGradeId")) ? Integer.parseInt(req.getParameter("selGradeId")) : 0;
                
                if(result.hasErrors()){
                    if(designationDataBean.getHdDesigationId() != 0){
                        TblDesignation tblDesignation = designationService.getDesignationById(designationDataBean.getHdDesigationId());
                        modelMap.addAttribute("designationDtls", tblDesignation);
                    }else{
                        modelMap.addAttribute("createDesig", "y");
                    }
                    pageView = "common/admin/CreateDesignation";
                }else{
                	TblDesignation tblDesignation1 = designationService.getDesignationById(designationDataBean.getHdDesigationId());
                    int userId = abcUtility.getSessionUserId(req);
                    TblDesignation tblDesignation = new TblDesignation();
                    tblDesignation.setDesignationName(designationDataBean.getTxtDesigName());
                    tblDesignation.setTblDepartment(new TblDepartment(designationDataBean.getTxtDept()));
                    tblDesignation.setParentDesignationId(designationDataBean.getTxtParentDesig());
                    tblDesignation.setGradeId(0);
                    tblDesignation.setCreatedBy(userId);
                    
                    
                    if (designationDataBean.getHdDesigationId() != 0) {
                        tblDesignation.setDesignationId(designationDataBean.getHdDesigationId());
                        tblDesignation.setCstatus(tblDesignation1.getCstatus());
                        if (designationService.updateDesignation(tblDesignation,gradeId,abcUtility.getSessionClientId(req))) {
                            redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_designation_update_success");
                            isSuccess = true;
                        }
                    } else {
                    	tblDesignation.setCstatus(0);
                        if (designationService.addDesignation(tblDesignation,gradeId,abcUtility.getSessionClientId(req))) {
                            redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_designation_create_success");
                            isSuccess = true;
                        }
                    }
                }
                if (isSuccess) {
                    pageView = "redirect:/common/admin/managedesignation" + encryptDecryptUtils.generateRedirect("common/admin/managedesignation", req);
                } else {
                    if(!result.hasErrors()){
                        pageView = "redirect:/common/admin/createdesignation" + encryptDecryptUtils.generateRedirect("common/admin/createdesignation", req);
                    }
                }
            }
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), errorMsg);
            return exceptionHandlerService.writeLog(ex);
        } finally {
            if (designationDataBean.getHdDesigationId() != 0) {
                auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(editDesignationLinkId), postEditDesignationAuditMsg, 0, 0);
            } else {
                auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(createDesignationLinkId), postCreateDesignationAuditMsg, 0, 0);
            }
        }
        return pageView;
    }

    @RequestMapping(value = "/common/admin/editdesignation/{desigId}/{enc}", method = RequestMethod.GET)
    public String getEditDesignationDetails(@PathVariable("desigId") int desigId, HttpServletRequest req,
            ModelMap modelMap) {
        try {
            TblDesignation tblDesignation = designationService.getDesignationById(desigId);
            modelMap.addAttribute("designationDtls", tblDesignation);
            List<SelectItem> selGrades = new ArrayList<SelectItem>();
            List<Object[]> lstGradeNames = designationService.getGradeNames(abcUtility.getSessionClientId(req));
            selGrades.add(new SelectItem("--Please Select--", 0));
            for(int i=0; i<lstGradeNames.size(); i++){
            	selGrades.add(new SelectItem(lstGradeNames.get(i)[1], lstGradeNames.get(i)[0]));
            }
            modelMap.addAttribute("selGrades", selGrades);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(editDesignationLinkId), getEditDesignationAuditMsg, 0, 0);
        }
        return "common/admin/CreateDesignation";
    }

    @RequestMapping(value = "/common/admin/initapprovedesig/{designationId}/{enc}", method = RequestMethod.GET)
    public String initApproveDesig(@PathVariable("designationId") int designationId, ModelMap modelMap, HttpServletRequest req) {
    	String moduleId=null;
    	List<Object[]> lstModules=null;
    	try {
            if (req.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            	lstModules = clientService.getClientModuleForView(abcUtility.getSessionClientId(req));
                Cookie[] cookies = req.getCookies();
                if (cookies != null) {
                    for (Cookie cookie : cookies) {
                        if ("moduleId".equals(cookie.getName())) {
                            moduleId = cookie.getValue();
                            break;
                        }
                    }
                }
                String publicKey = null;
                if (abcUtility.getSessionIsPkiEnabled(req) == 1) {
                    String certIds[] = ((SessionBean) req.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
                    if (certIds != null && certIds.length != 0) {
                        publicKey = commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
                        modelMap.addAttribute("publicKey", publicKey);
                    }
                }
            }
            modelMap.put("viewOnly", true);
            modelMap.put("readOnly", 1);
            modelMap.put("moduleId", moduleId);
            modelMap.put("lstModules", lstModules);
            modelMap.addAttribute("designationId", designationId);
            modelMap.addAttribute("designationDtls", designationService.getDesignationDetails(designationId));
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(approveDesignationLinkId), getApproveDesignationAuditMsg, 0, 0);
        }
        return "common/admin/ApproveDesignation";
    }

    @RequestMapping(value = "/common/admin/approvedesignation", method = RequestMethod.POST)
    public String approveDesignation(@ModelAttribute DesignationDataBean designationDataBean, HttpServletRequest req, RedirectAttributes redirectAttributes) {
        try {
            if (designationService.initApproveDesig(designationDataBean.getHdDesigationId())) {
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_designation_approve_success");
            } else {
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), errorMsg);
            }
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } finally {
            if (abcUtility.getSessionIsPkiEnabled(req) == 1) {
                String signText = req.getParameter("skpSignText");
                auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(approveDesignationLinkId), postApproveDesignationAuditMsg, 0, designationDataBean.getHdDesigationId(), designationDataBean.getTxtaRemarks(), signText);
            } else {
                auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(approveDesignationLinkId), postApproveDesignationAuditMsg, 0, designationDataBean.getHdDesigationId(), designationDataBean.getTxtaRemarks());
            }
        }
        return "redirect:/common/admin/managedesignation" + encryptDecryptUtils.generateRedirect("common/admin/managedesignation", req);
    }
}
