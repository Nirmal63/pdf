package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDynField;
import java.util.List;

public interface TblDynFieldDao  {

    public void addTblDynField(TblDynField tblDynField);

    public void deleteTblDynField(TblDynField tblDynField);

    public void updateTblDynField(TblDynField tblDynField);

    public List<TblDynField> getAllTblDynField();

    public List<TblDynField> findTblDynField(Object... values) throws Exception;

    public List<TblDynField> findByCountTblDynField(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynFieldCount();

    public void saveUpdateAllTblDynField(List<TblDynField> tblDynFields);

	public void saveOrUpdateTblDynField(TblDynField tblDynField);
}