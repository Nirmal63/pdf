/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

import com.etl.eproc.common.model.TblLOI;
import com.etl.eproc.common.daointerface.TblLOIDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author urja
 */
@Repository @Transactional    /*StackUpdate*/
public class TblLOIImpl extends AbcAbstractClass<TblLOI> implements TblLOIDao {

    @Override
    public void addTblLOI(TblLOI tblLOI){
        super.addEntity(tblLOI);
    }

    @Override
    public void deleteTblLOI(TblLOI tblLOI) {
        super.deleteEntity(tblLOI);
    }

    @Override
    public void updateTblLOI(TblLOI tblLOI) {
        super.updateEntity(tblLOI);
    }

    @Override
    public List<TblLOI> getAllTblLOI() {
        return super.getAllEntity();
    }

    @Override
    public List<TblLOI> findTblLOI(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblLOICount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblLOI> findByCountTblLOI(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblLOI(List<TblLOI> tblLOIs){
        super.updateAll(tblLOIs);
    }
}

