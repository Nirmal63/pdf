package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblGrade;
import com.etl.eproc.common.daointerface.TblGradeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblGradeImpl extends AbcAbstractClass<TblGrade> implements TblGradeDao {

    @Override
    public void addTblGrade(TblGrade tblGrade){
        super.addEntity(tblGrade);
    }

    @Override
    public void deleteTblGrade(TblGrade tblGrade) {
        super.deleteEntity(tblGrade);
    }

    @Override
    public void updateTblGrade(TblGrade tblGrade) {
        super.updateEntity(tblGrade);
    }

    @Override
    public List<TblGrade> getAllTblGrade() {
        return super.getAllEntity();
    }

    @Override
    public List<TblGrade> findTblGrade(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblGradeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblGrade> findByCountTblGrade(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblGrade(List<TblGrade> tblGrades){
        super.updateAll(tblGrades);
    }
}
