package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblTableMaster;
import com.etl.eproc.common.daointerface.TblTableMasterDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblTableMasterImpl extends AbcAbstractClass<TblTableMaster> implements TblTableMasterDao {

    @Override
    public void addTblTableMaster(TblTableMaster tblTableMaster){
        super.addEntity(tblTableMaster);
    }

    @Override
    public void deleteTblTableMaster(TblTableMaster tblTableMaster) {
        super.deleteEntity(tblTableMaster);
    }

    @Override
    public void updateTblTableMaster(TblTableMaster tblTableMaster) {
        super.updateEntity(tblTableMaster);
    }

    @Override
    public List<TblTableMaster> getAllTblTableMaster() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTableMaster> findTblTableMaster(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTableMasterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTableMaster> findByCountTblTableMaster(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTableMaster(List<TblTableMaster> tblTableMasters){
        super.updateAll(tblTableMasters);
    }

	@Override
	public void saveOrUpdateTblTableMaster(TblTableMaster tblTableMaster) {
		super.saveOrUpdateEntity(tblTableMaster);
	}
}
