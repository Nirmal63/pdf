package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDynScreen;
import java.util.List;

public interface TblDynScreenDao  {

    public void addTblDynScreen(TblDynScreen tblDynScreen);

    public void deleteTblDynScreen(TblDynScreen tblDynScreen);

    public void updateTblDynScreen(TblDynScreen tblDynScreen);

    public List<TblDynScreen> getAllTblDynScreen();

    public List<TblDynScreen> findTblDynScreen(Object... values) throws Exception;

    public List<TblDynScreen> findByCountTblDynScreen(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynScreenCount();

    public void saveUpdateAllTblDynScreen(List<TblDynScreen> tblDynScreens);
}