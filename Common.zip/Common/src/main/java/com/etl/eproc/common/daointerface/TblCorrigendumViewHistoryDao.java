package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblCorrigendumViewHistory;

/**
*
* @author anjali
*/

public interface TblCorrigendumViewHistoryDao {

	public void addTblCorrigendumViewHistory(TblCorrigendumViewHistory tblCorrigendumViewHistory);

    public void deleteTblCorrigendumViewHistory(TblCorrigendumViewHistory tblCorrigendumViewHistory);

    public void updateTblCorrigendumViewHistory(TblCorrigendumViewHistory tblCorrigendumViewHistory);

    public List<TblCorrigendumViewHistory> getAllTblCorrigendumViewHistory();

    public List<TblCorrigendumViewHistory> findTblCorrigendumViewHistory(Object... values) throws Exception;

    public List<TblCorrigendumViewHistory> findByCountTblCorrigendumViewHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCorrigendumViewHistoryCount();

    public void saveUpdateAllTblCorrigendumViewHistory(List<TblCorrigendumViewHistory> tblCorrigendumViewHistory);

	public void saveOrUpdateTblCorrigendumViewHistory(TblCorrigendumViewHistory tblActionViewHistory);
}
