package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDownloadDocument;
import java.util.List;

public interface TblDownloadDocumentDao  {

    public void addTblDownloadDocument(TblDownloadDocument tblDownloadDocument);

    public void deleteTblDownloadDocument(TblDownloadDocument tblDownloadDocument);

    public void updateTblDownloadDocument(TblDownloadDocument tblDownloadDocument);

    public List<TblDownloadDocument> getAllTblDownloadDocument();

    public List<TblDownloadDocument> findTblDownloadDocument(Object... values) throws Exception;

    public List<TblDownloadDocument> findByCountTblDownloadDocument(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDownloadDocumentCount();

    public void saveUpdateAllTblDownloadDocument(List<TblDownloadDocument> tblDownloadDocuments);
}