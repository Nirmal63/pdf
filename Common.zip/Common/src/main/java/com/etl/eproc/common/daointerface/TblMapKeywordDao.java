package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMapKeyword;
import java.util.List;

public interface TblMapKeywordDao  {

    public void addTblMapKeyword(TblMapKeyword tblMapKeyword);

    public void deleteTblMapKeyword(TblMapKeyword tblMapKeyword);

    public void updateTblMapKeyword(TblMapKeyword tblMapKeyword);

    public List<TblMapKeyword> getAllTblMapKeyword();

    public List<TblMapKeyword> findTblMapKeyword(Object... values) throws Exception;

    public List<TblMapKeyword> findByCountTblMapKeyword(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMapKeywordCount();

    public void saveUpdateAllTblMapKeyword(List<TblMapKeyword> tblMapKeywords);
}