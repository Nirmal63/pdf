package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblKeywordDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblKeyword;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblKeywordImpl extends AbcAbstractClass<TblKeyword> implements TblKeywordDao {

    @Override
    public void addTblKeyword(TblKeyword tblKeyword){
        super.addEntity(tblKeyword);
    }

    @Override
    public void deleteTblKeyword(TblKeyword tblKeyword) {
        super.deleteEntity(tblKeyword);
    }

    @Override
    public void updateTblKeyword(TblKeyword tblKeyword) {
        super.updateEntity(tblKeyword);
    }

    @Override
    public List<TblKeyword> getAllTblKeyword() {
        return super.getAllEntity();
    }

    @Override
    public List<TblKeyword> findTblKeyword(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblKeywordCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblKeyword> findByCountTblKeyword(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblKeyword(List<TblKeyword> tblKeywords){
        super.updateAll(tblKeywords);
    }
}
