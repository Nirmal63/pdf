package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblUserEnableDisableDataDao;
import com.etl.eproc.common.model.TblUserEnableDisableData;
/**
*
* @author geetansh
*/
@Repository @Transactional    /*StackUpdate*/
public class TblUserEnableDisableDataDaoImpl extends AbcAbstractClass<TblUserEnableDisableData> implements TblUserEnableDisableDataDao {

	@Override
	public boolean addTblUserEnableDisableData(TblUserEnableDisableData tblUserEnableDisableData) {
		super.saveOrUpdateEntity(tblUserEnableDisableData);
		return true;
	}

	@Override
	public void deleteTblEventEnqiry(TblUserEnableDisableData tblUserEnableDisableData) {
		super.deleteEntity(tblUserEnableDisableData);
		
	}

	@Override
	public List<TblUserEnableDisableData> findTblUserEnableDisableData(Object... values) throws Exception {
		 return super.findEntity(values);
	}

	@Override
	public List<TblUserEnableDisableData> findByCountTblUserEnableDisableData(int firstResult, int maxResult, Object... values)
			throws Exception {
		   return super.findByCountEntity(firstResult, maxResult, values);
	}

	@Override
	public void saveUpdateAllTblUserEnableDisableData(List<TblUserEnableDisableData> tblUserEnableDisableDatas) {
		 super.updateAll(tblUserEnableDisableDatas);
	}

}
