package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblClientExemptionCertificate;
import com.etl.eproc.common.daointerface.TblClientExemptionCertificateDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientExemptionCertificateImpl extends AbcAbstractClass<TblClientExemptionCertificate> implements TblClientExemptionCertificateDao {


    @Override
    public void addTblClientExemptionCertificate(TblClientExemptionCertificate tblClientExemptionCertificate){
        super.addEntity(tblClientExemptionCertificate);
    }

    @Override
    public void deleteTblClientExemptionCertificate(TblClientExemptionCertificate tblClientExemptionCertificate) {
        super.deleteEntity(tblClientExemptionCertificate);
    }

    @Override
    public void updateTblClientExemptionCertificate(TblClientExemptionCertificate tblClientExemptionCertificate) {
        super.updateEntity(tblClientExemptionCertificate);
    }

    @Override
    public List<TblClientExemptionCertificate> getAllTblClientExemptionCertificate() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientExemptionCertificate> findTblClientExemptionCertificate(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientExemptionCertificateCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientExemptionCertificate> findByCountTblClientExemptionCertificate(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientExemptionCertificate(List<TblClientExemptionCertificate> tblClientExemptionCertificates){
        super.updateAll(tblClientExemptionCertificates);
    }
}
