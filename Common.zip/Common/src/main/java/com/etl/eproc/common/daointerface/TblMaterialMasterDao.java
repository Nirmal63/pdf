package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMaterialMaster;
import java.util.List;

public interface TblMaterialMasterDao  {

    public void addTblMaterialMaster(TblMaterialMaster tblMaterialMaster);

    public void deleteTblMaterialMaster(TblMaterialMaster tblMaterialMaster);

    public void updateTblMaterialMaster(TblMaterialMaster tblMaterialMaster);

    public List<TblMaterialMaster> getAllTblMaterialMaster();

    public List<TblMaterialMaster> findTblMaterialMaster(Object... values) throws Exception;

    public List<TblMaterialMaster> findByCountTblMaterialMaster(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMaterialMasterCount();

    public void saveUpdateAllTblMaterialMaster(List<TblMaterialMaster> tblMaterialMasters);
}