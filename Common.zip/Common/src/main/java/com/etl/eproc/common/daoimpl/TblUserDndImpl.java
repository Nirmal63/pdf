package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblUserDnd;
import com.etl.eproc.common.daointerface.TblUserDndDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserDndImpl extends AbcAbstractClass<TblUserDnd> implements TblUserDndDao {

    @Override
    public void addTblUserDnd(TblUserDnd tblUserDnd){
        super.addEntity(tblUserDnd);
    }

    @Override
    public void deleteTblUserDnd(TblUserDnd tblUserDnd) {
        super.deleteEntity(tblUserDnd);
    }

    @Override
    public void updateTblUserDnd(TblUserDnd tblUserDnd) {
        super.updateEntity(tblUserDnd);
    }

    @Override
    public List<TblUserDnd> getAllTblUserDnd() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserDnd> findTblUserDnd(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserDndCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserDnd> findByCountTblUserDnd(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserDnd(List<TblUserDnd> tblUserDnds){
        super.updateAll(tblUserDnds);
    }
}
