package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblOfficerDocFolder;
import java.util.List;

public interface TblOfficerDocFolderDao  {

    public void addTblOfficerDocFolder(TblOfficerDocFolder tblOfficerDocFolder);

    public void deleteTblOfficerDocFolder(TblOfficerDocFolder tblOfficerDocFolder);

    public void updateTblOfficerDocFolder(TblOfficerDocFolder tblOfficerDocFolder);

    public List<TblOfficerDocFolder> getAllTblOfficerDocFolder();

    public List<TblOfficerDocFolder> findTblOfficerDocFolder(Object... values) throws Exception;

    public List<TblOfficerDocFolder> findByCountTblOfficerDocFolder(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblOfficerDocFolderCount();

    public void saveUpdateAllTblOfficerDocFolder(List<TblOfficerDocFolder> tblOfficerDocFolders);
}