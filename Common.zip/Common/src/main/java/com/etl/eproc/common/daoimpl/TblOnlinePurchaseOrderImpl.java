package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblOnlinePurchaseOrder;
import com.etl.eproc.common.daointerface.TblOnlinePurchaseOrderDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblOnlinePurchaseOrderImpl extends AbcAbstractClass<TblOnlinePurchaseOrder> implements TblOnlinePurchaseOrderDao {

    @Override
    public void addTblOnlinePurchaseOrder(TblOnlinePurchaseOrder tblOnlinePurchaseOrder){
        super.addEntity(tblOnlinePurchaseOrder);
    }

    @Override
    public void deleteTblOnlinePurchaseOrder(TblOnlinePurchaseOrder tblOnlinePurchaseOrder) {
        super.deleteEntity(tblOnlinePurchaseOrder);
    }

    @Override
    public void updateTblOnlinePurchaseOrder(TblOnlinePurchaseOrder tblOnlinePurchaseOrder) {
        super.updateEntity(tblOnlinePurchaseOrder);
    }

    @Override
    public List<TblOnlinePurchaseOrder> getAllTblOnlinePurchaseOrder() {
        return super.getAllEntity();
    }

    @Override
    public List<TblOnlinePurchaseOrder> findTblOnlinePurchaseOrder(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblOnlinePurchaseOrderCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblOnlinePurchaseOrder> findByCountTblOnlinePurchaseOrder(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblOnlinePurchaseOrder(List<TblOnlinePurchaseOrder> tblOnlinePurchaseOrders){
        super.updateAll(tblOnlinePurchaseOrders);
    }
}
