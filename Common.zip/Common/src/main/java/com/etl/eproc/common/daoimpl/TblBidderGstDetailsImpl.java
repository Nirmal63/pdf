package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblBidderGstDetailsDao;
import com.etl.eproc.common.model.TblBidderGstDetails;

@Repository @Transactional    /*StackUpdate*/
public class TblBidderGstDetailsImpl extends AbcAbstractClass<TblBidderGstDetails> implements TblBidderGstDetailsDao{
	
	@Override
	public void addTblBidderGstDetails(TblBidderGstDetails tblBidderGstDetails) {
		super.addEntity(tblBidderGstDetails);
	}

	@Override
	public void deleteTblBidderGstDetails(
			TblBidderGstDetails tblBidderGstDetails) {
		super.deleteEntity(tblBidderGstDetails);
	}

	@Override
	public void updateTblBidderGstDetails(
			TblBidderGstDetails tblBidderGstDetails) {
		super.updateEntity(tblBidderGstDetails);
	}

	@Override
	public List<TblBidderGstDetails> getAllTblBidderGstDetails() {
		return super.getAllEntity();
	}

	@Override
	public List<TblBidderGstDetails> findTblBidderGstDetails(Object... values)
			throws Exception {
		return super.findEntity(values);
	}

	@Override
	public List<TblBidderGstDetails> findByCountTblBidderGstDetails(
			int firstResult, int maxResult, Object... values) throws Exception {
		return super.findByCountEntity(firstResult, maxResult, values);
	}

	@Override
	public long getTblBidderGstDetailsCount() {
		return super.getEntityCount();
	}

	@Override
	public void saveUpdateAllTblBidderGstDetails(
			List<TblBidderGstDetails> tblBidderGstDetails) {
		super.updateAll(tblBidderGstDetails);
	}

	@Override
	public void saveOrUpdateTblBidderGstDetails(TblBidderGstDetails tblBidderGstDetails) {
		super.saveOrUpdateEntity(tblBidderGstDetails);
	}

}
