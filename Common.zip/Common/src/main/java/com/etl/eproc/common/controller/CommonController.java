/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.SocketException;
import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbcp.BasicDataSource;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.HtmlUtils;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.bean.AbcCaptchaResponse;
import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.TblAgreementTypeDao;
import com.etl.eproc.common.daointerface.TblAnnexureTypeDao;
import com.etl.eproc.common.daointerface.TblEventTypeDao;
import com.etl.eproc.common.daointerface.TblMapAlternateEmailIdsDao;
import com.etl.eproc.common.daointerface.TblMapAuthUserDao;
import com.etl.eproc.common.daointerface.TblModuleDao;
import com.etl.eproc.common.daointerface.TblUserLoginDao;
import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.databean.RuleLinkDataBean;
import com.etl.eproc.common.model.TblAgreementType;
import com.etl.eproc.common.model.TblAnnexureType;
import com.etl.eproc.common.model.TblBidderStatus;
import com.etl.eproc.common.model.TblChat;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientPGBankMapping;
import com.etl.eproc.common.model.TblClientRule;
import com.etl.eproc.common.model.TblColumnType;
import com.etl.eproc.common.model.TblCommitteeDetail;
import com.etl.eproc.common.model.TblCommitteeUserDetail;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblCountry;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblDocument;
import com.etl.eproc.common.model.TblEvent;
import com.etl.eproc.common.model.TblEventReassignment;
import com.etl.eproc.common.model.TblEventType;
import com.etl.eproc.common.model.TblIssuer;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblMapAlternateEmailIds;
import com.etl.eproc.common.model.TblMapAuthUser;
import com.etl.eproc.common.model.TblModule;
import com.etl.eproc.common.model.TblOfflinePayment;
import com.etl.eproc.common.model.TblPayment;
import com.etl.eproc.common.model.TblPaymentITSDetail;
import com.etl.eproc.common.model.TblPaymentType;
import com.etl.eproc.common.model.TblProductCategory;
import com.etl.eproc.common.model.TblRuleLink;
import com.etl.eproc.common.model.TblState;
import com.etl.eproc.common.model.TblSubModule;
import com.etl.eproc.common.model.TblSupplierInquiry;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserDnd;
import com.etl.eproc.common.model.TblUserFeedBack;
import com.etl.eproc.common.model.TblUserHistory;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.model.TblUserOtp;
import com.etl.eproc.common.model.Tblappversion;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FaqService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.ManageContentService;
import com.etl.eproc.common.services.MessageQueueService;
import com.etl.eproc.common.services.NegotiationService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.services.TblUserotpservice;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.DateUtils;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.FileEncryptDecryptUtil;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SMSContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.common.utility.WSCheckAvail;
import com.etl.eproc.common.webservice.DataObject;
import com.etl.eproc.eindent.model.TblClientBoqColumn;
import com.etl.eproc.factory.AbcCaptchaFactory;
import com.etl.eproc.vendor.services.VendorEnlistmentService;
import com.etl.keywords.webservice.ArrayOfString;
import com.etl.keywords.webservice.Service;
import com.etl.keywords.webservice.ServiceSoap;


@Controller
public class CommonController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private ManageBidderService manageBidderService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private ModelToSelectItem modelToSelectItem;
    @Autowired
    private LoginService loginService;
    @Autowired
    private DepartmentUserService departmentUserService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private CommonValidators commonValidators;
    @Autowired
    private DateUtils dateUtils;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private ManageContentService manageContentService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
	private FileUploadService fileUploadService;
    @Autowired
	private ConversionService conversionService;
    @Autowired
    private BasicDataSource basicDataSource;
    @Autowired
    private VendorEnlistmentService vendorEnlistmentService;
    @Autowired
    private TblMapAlternateEmailIdsDao tblMapAlternateEmailIdsDao;
    @Autowired
    private TblUserotpservice tbluserotpservice;
    @Autowired
    private SMSContentUtillity smsContentUtillity;
    @Autowired
    private TblMapAuthUserDao tblMapAuthorisedUserDao;
    @Autowired
    private TblEventTypeDao tblEventTypeDao;
    @Autowired
    private TblModuleDao tblModuleDao;
    @Autowired
    private TblUserLoginDao tblUserLoginDao;

    
    @Value("#{linkProperties['supplier_inquiry_mail_template_id']?:179}")
	private int supplierInquiryMailTemplateId; 
    @Value("#{projectProperties['support_supplier_inquiry']}")
    private String supportTeamEmailId;
    @Value("#{projectProperties['negotiation.minimum.member.reqired']}")
    private String negotiationminimummemberreqired;
    @Value("#{projectProperties['captcha_privatekey']}")
    private String privateKey;
    @Value("#{projectProperties['keyword_ws_url_islive']?:false}")
    private Boolean keyword_ws_url_islive;
    @Value("#{projectProperties['keyword_ws_url_live']}")
    private String keyword_ws_url_live;
    @Value("#{projectProperties['keyword_ws_url_inhouse']}")
    private String keyword_ws_url_inhouse;
    
    @Value("#{projectProperties['keyword_db_connection_allow']}")
    private String keyword_db_connection_allow;
    @Value("#{projectProperties['keyword_db_driver_name']}")
    private String keyword_db_driver_name;
    @Value("#{projectProperties['keyword_db_connection_url']}")
    private String keyword_db_connection_url;
    @Value("#{projectProperties['keyword_db_username']}")
    private String keyword_db_username;
    @Value("#{projectProperties['keyword_db_password']}")
    private String keyword_db_password;
    @Value("#{projectProperties['rci_client_ids']}")
    private String rciClientIds;
    @Value("#{projectProperties['gsl_client']}")
    private String gslClientIds;
    @Value("#{linkProperties['manage_bidder_register_bidder']?:24}")
	private int registrationLinkId;
    @Value("#{smsProperties['msg_one_time_reset_otp']}")
	private String msgResetPass;
    @Autowired
	private FileEncryptDecryptUtil fileEncryptDecryptUtil;
    @Value("#{projectProperties['prime_auction_url']}")
    private String primeAuctionUrl;
    @Value("#{projectProperties['GST_validate_url']}")
    private String gstValidateUrl;
    @Value("#{clientProperties['crawl_ipaddresses']}")
   	private String[] crawlIpAddress;
    
    private static Connection connection = null;
    private final static String VALID = "valid";
    private final static String EMAILID = "emailId";
    private static final String SESSIONOBJECT = "sessionObject";  
    private static final String CLIENT_ID = "clientId";
    private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
/*    @Value("#{adminAuditTrailProperties['ajaxgetdepttree']}")
    private String ajaxGetDeptTreeAuditMsg;
    @Value("#{adminAuditTrailProperties['ajaxcheckuniquedeptname']}")
    private String ajaxCheckUniqueDeptNameAuditMsg;
    @Value("#{linkProperties['manage_department_department_tree']?:147}")
    private int deptTreeLinkId;
    @Value("#{linkProperties['manage_department_create_department']?:6}")
    private int createDeptLinkId;
    @Value("#{adminAuditTrailProperties['ajaxgetstatebycountrysuccess']}")
    private String ajaxGetStateByCountryIdSuccessAuditMsg;
    @Value("#{adminAuditTrailProperties['ajaxgetstatebycountryfail']}")
    private String ajaxGetStateByCountryIdFailAuditMsg;
    @Value("#{adminAuditTrailProperties['ajaxcaptcavalidatesuccess']}")
    private String ajaxCaptchaValidateSuccessAuditMsg;
    @Value("#{adminAuditTrailProperties['ajaxcaptchavalidatefail']}")
    private String ajaxCaptchaValidateFailAuditMsg;
    @Value("#{adminAuditTrailProperties['ajaxgetsubmodulelist']}")
    private String ajaxGetSubModuleListAuditMsg;
    @Value("#{adminAuditTrailProperties['ajaxgeteventlist']}")
    private String ajaxGetEventListAuditMsg;
    @Value("#{adminAuditTrailProperties['ajaxgetlinklist']}")
    private String ajaxGetLinkListAuditMsg;
    @Value("#{adminAuditTrailProperties['ajaxcheckloginid']}")
    private String ajaxCheckLoginIdAuditMsg;
    @Value("#{adminAuditTrailProperties['ajaxcheckdomainname']}")
    private String ajaxCheckDomainNameAuditMsg;*/
//    @Value("#{adminAuditTrailProperties['ajaxgetdepttree']}")
//    private String ajaxGetDeptTreeAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxcheckuniquedeptname']}")
//    private String ajaxCheckUniqueDeptNameAuditMsg;
//    @Value("#{linkProperties['manage_department_department_tree']?:147}")
//    private int deptTreeLinkId;
//    @Value("#{linkProperties['manage_department_create_department']?:6}")
//    private int createDeptLinkId;
//    @Value("#{adminAuditTrailProperties['ajaxgetstatebycountrysuccess']}")
//    private String ajaxGetStateByCountryIdSuccessAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxgetstatebycountryfail']}")
//    private String ajaxGetStateByCountryIdFailAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxcaptcavalidatesuccess']}")
//    private String ajaxCaptchaValidateSuccessAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxcaptchavalidatefail']}")
//    private String ajaxCaptchaValidateFailAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxgetsubmodulelist']}")
//    private String ajaxGetSubModuleListAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxgeteventlist']}")
//    private String ajaxGetEventListAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxgetlinklist']}")
//    private String ajaxGetLinkListAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxcheckloginid']}")
//    private String ajaxCheckLoginIdAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxcheckdomainname']}")
//    private String ajaxCheckDomainNameAuditMsg;
    @Value("#{adminAuditTrailProperties['bidderemailverificationsuccess']}")
    private String bidderEmailVerificationSuccessAuditMsg;
    @Value("#{adminAuditTrailProperties['getEventTypeList']}")
    private String getEventTypeList;
    @Value("#{adminAuditTrailProperties['bidderemailverificationfail']}")
    private String bidderEmailVerificationFailAuditMsg;
    @Value("#{adminAuditTrailProperties['bidderemailmobileverification']}")
    private String bidderEmailMobileVerificationAuditMsg;
    @Value("#{adminAuditTrailProperties['postemailmobileverification']}")
    private String postEmailMobileVerificationAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxgetparentdesigtree']}")
//    private String ajaxGetParentDesigTreeAuditMsg;
//    @Value("#{linkProperties['manage_designation_designation_tree']?:148}")
//    private int desigTreeLinkId;
//    @Value("#{linkProperties['manage_catagory_category_tree']?:149}")
//    private int categoryTreeLinkId;
//    @Value("#{adminAuditTrailProperties['ajaxgetcategorytree']}")
//    private String ajaxGetCategoryTreeAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxcheckcategoryname']}")
//    private String ajaxCheckCategoryNameAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxcheckproductname']}")
//    private String ajaxCheckProductNameAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxcheckvaliduser']}")
//    private String ajaxCheckValidUserAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxcheckuniquedesigname']}")
//    private String ajaxCheckUniqueDesigAuditMsg;
//    @Value("#{adminAuditTrailProperties['ajaxgetserverdatetime']}")
//    private String ajaxGetServerDateTimeAuditMsg;
    @Value("#{linkProperties['report_admin_manage_dc_history']?:24}")
    private int manageDCReportId;
    @Value("#{adminAuditTrailProperties['getManageDCRemark']}")
    private String getManageDCRemark;
    @Value("#{adminAuditTrailProperties['getOnlineHelpPage']}")
    private String auditOnlineHelp;
    @Value("#{linkProperties['report_admin_manage_user_management_history']?:28}")
    private int manageUserManagementHistoryReportId;
    @Value("#{linkProperties['report_user_management_history']?:162}")
    private int manageUserManagementHistoryLinkId;
    @Value("#{adminAuditTrailProperties['getManageUserManageHistoryReportRemark']}")
    private String getManageUserManageHistoryReportRemark;
    
    @Value("#{linkProperties['report_manage_login_report']?:29}")
    private int manageLoginReportId;
    @Value("#{linkProperties['report_login_report']?:163}")
    private int manageLoginReportLinkId;
    @Value("#{linkProperties['bidder_login_report']?:355}")
    private int manageBidderLoginReportLinkId;
    @Value("#{adminAuditTrailProperties['getManageLoginReportRemark']}")
    private String getManageLoginReportRemark;
    @Value("#{adminAuditTrailProperties['getWipRemark']}")
    private String getWipReportRemark;
    
    @Value("#{linkProperties['report_manage_digital_certificate_renewal_report_bidder']?:30}")
    private int manageDCRenewalBidderReportId;
    @Value("#{linkProperties['report_digital_certificate_renewal_report_for_bidder']?:166}")
    private int manageDCRenewalReportBidderLinkId;
    @Value("#{adminAuditTrailProperties['getManageDCRenewalReportRemark']}")
    private String getManageDCRenewalReportRemark;
    
    @Value("#{linkProperties['report_manage_digital_certificate_renewal_report_officer']?:31}")
    private int manageDCRenewalOfficerReportId;
    @Value("#{linkProperties['report_digital_certificate_renewal_report_for_officer']?:164}")
    private int manageDCRenewalReportOfficerLinkId;
    
    @Value("#{auclinkProperties['negotiation_negotiation_process_start_chat']?:628}")
    private int auctionnegotiationbuyerstartchatid;
    @Value("#{auclinkProperties['negotiation_bidder_start_chat']?:638}")
    private int auctionnegotiationbidderstartchatid; 
    @Value("#{auclinkProperties['negotiation_committee_create']?:618}")
    private int aucnegotiationcreatecommitteelinkId; 
    @Value("#{auclinkProperties['negotiation_committee_edit']?:619}")
    private int aucnegotiationeditcommitteelinkId; 
    @Value("#{auclinkProperties['negotiation_committee_view']?:620}")
    private int aucnegotiationviewcommitteelinkId; 
    @Value("#{auclinkProperties['negotiation_committee_publish']?:621}")
    private int aucnegotiationpublishcommitteelinkId; 
    @Value("#{auclinkProperties['negotiation_committee_use_existing_committee']?:625}")
    private int aucnegotiationexistingcommitteelinkId;
   
    
    @Value("#{tenderlinkProperties['negotiation_negotiation_process_start_chat']?:604}")
    private int tendernegotiationbuyerstartchatid;
    @Value("#{tenderlinkProperties['negotiation_bidder_start_chat']?:614}")
    private int tendernegotiationbidderstartchatid; 
    @Value("#{tenderlinkProperties['negotiation_committee_create']?:594}")
    private int tendernegotiationcreatecommitteelinkId; 
    @Value("#{tenderlinkProperties['negotiation_committee_edit']?:595}")
    private int tendernegotiationeditcommitteelinkId; 
    @Value("#{tenderlinkProperties['negotiation_committee_view']?:596}")
    private int tendernegotiationviewcommitteelinkId; 
    @Value("#{tenderlinkProperties['negotiation_committee_publish']?:597}")
    private int tendernegotiationpublishcommitteelinkId; 
    @Value("#{tenderlinkProperties['negotiation_committee_use_existing_committee']?:601}")
    private int tendernegotiationexistingcommitteelinkId; 
    
    @Value("#{adminAuditTrailProperties['negocreatecommittee']}")
    private String negocreatecommittee;
    @Value("#{adminAuditTrailProperties['negoeditcommittee']}")
    private String negoeditcommittee;
    @Value("#{adminAuditTrailProperties['negocommitteecreated']}")
    private String negocommitteecreated;
    @Value("#{adminAuditTrailProperties['negocommitteeupdated']}")
    private String negocommitteeupdated;
    @Value("#{adminAuditTrailProperties['negoviewcommittee']}")
    private String negoviewcommittee;
    @Value("#{adminAuditTrailProperties['negopublishcommittee']}")
    private String negopublishcommittee;
    @Value("#{adminAuditTrailProperties['negopublishedcommittee']}")
    private String negopublishedcommittee;
    @Value("#{adminAuditTrailProperties['negocreateexistingcommittee']}")
    private String negocreateexistingcommittee;
    
    @Value("#{adminAuditTrailProperties['accessedchatdialog']}")
    private String accessedchatdialog;
    @Value("#{adminAuditTrailProperties['sendchat']}")
    private String sendchat;
    @Value("#{adminAuditTrailProperties['viewchathistory']}")
    private String viewchathistory;
    
    @Value("#{linkProperties['report_manage_audit_trail_report']?:32}")
    private int manageAuditTrailReportId;
    @Value("#{linkProperties['report_bidder_audit_trail_reportid']?:45}")
    private int manageBidderAuditTrailReportId;
    @Value("#{linkProperties['report_daily_payment_buyer_reportid']?:48}")
    private int manageDailyPaymentReportId;
    @Value("#{linkProperties['report_bidder_login_reportid']?:46}")
    private int manageBidderLoginReportId;
    @Value("#{tenderlinkProperties['report_daily_payment_report']?:200}")
    private int manageDailyPaymentLinkId;
    @Value("#{linkProperties['report_audit_trail_report']?:165}")
    private int manageAuditTrailReportLinkId;
    @Value("#{linkProperties['bidder_audit_trail_report']?:354}")
    private int manageBidderAuditTrailReportLinkId;
    @Value("#{linkProperties['application_version_reportid']?:95}")
    private int applicationVersionReportId;
    @Value("#{linkProperties['create_application_version_link']?:811}")
    private int createApplicationVersionLink;
    @Value("#{linkProperties['manage_application_version_link']?:812}")
    private int manageApplicationVersionLink;
    @Value("#{adminAuditTrailProperties['getManageAuditTrailReportRemark']}")
    private String getManageAuditTrailReportRemark;
    @Value("#{adminAuditTrailProperties['getDailyPaymentReportRemark']}")
    private String getDailyPaymentReportRemark;
    @Value("#{adminAuditTrailProperties['postProcessAssignment']}")
    private String postProcessAssignment;
    @Value("#{linkProperties['manage_client_add_rule']?:406}")
    private int createRuleEngineLinkId;
    @Value("#{adminAuditTrailProperties['getRuleEngineRemark']}")
    private String getRuleEngineRemark;
    @Value("#{adminAuditTrailProperties['postRuleEngineRemark']}")
    private String postRuleEngineRemark;
    @Value("#{adminAuditTrailProperties['getclientboqcolumn']}")
    private String getClientBoqColumn;
    @Value("#{adminAuditTrailProperties['postsaveclinetboqcolumn']}")
    private String postSaveClinetBoqColumn;
    @Value("#{adminAuditTrailProperties['postdeleteclientboqcolumn']}")
    private String postDeleteCientBoqColumn;
    @Value("#{adminAuditTrailProperties['categorywise_statistic']}")
    private String categorywise_statistic;
    @Value("#{adminAuditTrailProperties['create_app_version']}")
    private String create_app_version;
    @Value("#{adminAuditTrailProperties['manage_app_version']}")
    private String manage_app_version;
    
    
    @Value("#{vendorlinkProperties['enlistment_form_create_mandatory_docs']?:543}")
    private int createMandatoryDocLinkId;
    @Value("#{vendorlinkProperties['enlistment_form_edit_mandatory_docs']?:545}")
    private int editMandatoryDocLinkId;
    @Value("#{eauctionProperties['auc_negotiation_publish_committee_templateId']?:89}")
    private int aucNegotiationPublishCommitteeTempleteId;
    @Value("#{etenderProperties['ten_negotiation_publish_committee_templateId']?:90}")
    private int tenNegotiationPublishCommitteeTempleteId;
    
    @Value("#{adminAuditTrailProperties['getopenmenddocreq']}")
    private String getopenmenddocreq;
    @Value("#{adminAuditTrailProperties['manDoccreated']}")
    private String manDoccreated;
    @Value("#{adminAuditTrailProperties['manDoccreatefail']}")
    private String manDoccreatefail;
    @Value("#{adminAuditTrailProperties['getopeneditmenddocreq']}")
    private String getopeneditmenddocreq;
    @Value("#{adminAuditTrailProperties['getopenviewmenddocreq']}")
    private String getopenviewmenddocreq;
    @Value("#{adminAuditTrailProperties['manDocupdated']}")
    private String manDocupdated;
    @Value("#{adminAuditTrailProperties['manDocupdatedfail']}")
    private String manDocupdatedfail;
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
    private String queueName;
    @Value("#{projectProperties['client_id']?:'184,185,255'}")
    private String clientIds;
    @Value("#{linkProperties['report_work_in_progress']?:81}")
    private int workInProgressReportId;
    @Value("#{linkProperties['link_statics_report_home_page']?:88}")
    private int linkStaticsReportHomePage;
    @Value("#{linkProperties['manage_download_view']?:736}")
	private int manageDownloadView; 
//    @Value("#{adminAuditTrailProperties['ajaxgetkeyordsuggestion']}")
//    private String auditKeywordSuggestion;
    @Value("#{auclinkProperties['bid_submission_registration_charges_offline_payment']?:794}")
    private int linkBidSubRegChargesOfflinePayment;
//PT#4316 start
  	@Value("#{linkProperties['view_event_inquiry_report']?:156}") 
  	private int eventInquiryReportId;
  	@Value("#{linkProperties['event_inquiry_Report_LinkId']?:5557}")
  	private int eventInquiryReportLinkId;
  	@Value("#{adminAuditTrailProperties['getEventInquiryReportRemark']}")
  	private String getEventInquiryReportRemark;
//PT#4316 end
    @Autowired
    ReportGeneratorService reportGeneratorService;
    @Autowired
    NegotiationService negotiationService;
    @Autowired
    MessageSource messageSource;
    @Autowired
    FaqService faqService;
    @Autowired
    MessageQueueService messageQueueService;
    @Value("#{projectProperties['auction_Admin_userId']}")
    private String auctionAdminuserId;
    @Value("#{projectProperties['doc_upload_path']}")
	private String tmpPath;
    @Value("#{projectProperties['create_application_version.eventid']}")
    private int createapplicationversioneventid;
    @Value("#{projectProperties['manage_application_version.eventid']}")
    private int manageapplicationversioneventid;
    
    @Value("#{linkProperties['report_mail_acknowledgement_reportid']?:123}")
    private int mailAcknowledgmentReportId;
    @Value("#{linkProperties['mail_acknowledge_report']?:3336}")
    private int mailAcknowledgmentReportLinkId;
    @Value("#{adminAuditTrailProperties['getMailAcknowledgmentReportRemark']}")
    private String getMailAcknowledgmentReportRemark;
    @Value("#{linkProperties['report_bidder_profile_details_reportid']?:124}")
    private int bidderProfileDetailsReportId;
    @Value("#{linkProperties['bidder_profile_details_report']?:3339}")
    private int bidderProfileDetailsReportLinkId;
    @Value("#{adminAuditTrailProperties['getBidderProfileDetailsReportRemark']}")
    private String getBidderProfileDetailsReportRemark;
    @Value("#{etenderProperties['sumit_feedback_templateId']?:267}")
    private int submitFeedbackTemplateId;
    @Value("#{adminAuditTrailProperties['getAltEmailidSavedRemark']}")
    private String getAltEmailidSavedRemark;
    @Value("#{adminAuditTrailProperties['getAltEmailidDeletedRemark']}")
    private String getAltEmailidDeletedRemark;
    @Value("#{adminAuditTrailProperties['getAltEmailidUpdatedRemark']}")
    private String getAltEmailidUpdatedRemark;
    @Value("#{projectProperties['server_uptime_report_path']}")
    private String serverUptimeRreportPath;
    @Value("#{linkProperties['server_uptime_report_linkId']?:4505}")
    private int serverUptimeReportLinkId;
    @Value("#{adminAuditTrailProperties['getServerUptimeReport']}")
    private String msgGetServerUptimeReport;
    @Value("#{adminAuditTrailProperties['getDownloadServerUptimeReport']}")
    private String msgGetDownloadServerUptimeReport;
    @Value("#{projectProperties['default_contry_id']}")
    private int countryId;
    @Value("#{adminAuditTrailProperties['getPaymentITSDetailpage']}")
    private String getPaymentITSDetailpage;
    @Value("#{adminAuditTrailProperties['postPaymentITSDetailpage']}")
    private String postPaymentITSDetailpage;
    @Value("#{projectProperties['ITSLead_validate_url']}")
    private String ITSLeadvalidateurl;
    @Value("#{projectProperties['ITSLead_API_KEY']}")
    private String ITSLeadAPIKEY;
    @Value("#{adminAuditTrailProperties['postPaymentDetailSendtoITS']}")
    private String postPaymentDetailSendtoITS;
    @Value("#{adminAuditTrailProperties['getPaymentITSDetailviewpage']}")
    private String getPaymentITSDetailviewpage;
    @Value("#{auctionAuditTrailProperties['getMapAuthorizedUserAuction']}")
    private String getMapAuthorizedUserAuction;
    @Value("#{auctionAuditTrailProperties['postMapAuthorizedUserAuction']}")
    private String postMapAuthorizedUserAuction;
    @Value("#{etenderAuditTrailProperties['getMapAuthorizedUserTender']}")
    private String getMapAuthorizedUserTender;
    @Value("#{etenderAuditTrailProperties['postMapAuthorizedUserTender']}")
    private String postMapAuthorizedUserTender;
    @Value("#{auclinkProperties['map_authorized_user_auction_link']?:5543}")
	private int mapAuthorizedUserAuctionLink;
    @Value("#{tenderlinkProperties['map_authorized_user_tender_link']?:5541}")
    private int mapAuthorizedUserTenderLink;
	@Value("#{etenderAuditTrailProperties['getDelegatePageFromNoticeTab']}")
    private String getDelegatePageFromNoticeTab;
    @Value("#{etenderAuditTrailProperties['postDelegateProcessAssignment']}")
    private String postDelegateProcessAssignment;
    @Value("#{etenderAuditTrailProperties['getDelegateHistoryPageFromNoticeTab']}")
    private String getDelegateHistoryPageFromNoticeTab;
    @Value("#{linkProperties['admin_manage_annexure']?:157}")
    private int manageAnnexureReportId;
    @Value("#{linkProperties['manage_Annexure']?:6573}")
    private int manageAnnexureLinkId;
    @Value("#{adminAuditTrailProperties['getManageAnnexureRemark']}")
    private String getManageAnnexureRemark;
    
    @Value("#{linkProperties['admin_manage_annexure_type']?:158}")
    private int manageAnnexureTypeReportId;
    @Value("#{linkProperties['manage_Annexure_type']?:6580}")
    private int manageAnnexureTypeLinkId;
    @Value("#{linkProperties['admin_manage_agreement_type']?:160}")
    private int manageAgreementTypeReportId;
	private static final String OPTYPE = "opType";
	private static final String CREATE = "create";
	@Autowired
	private TblAnnexureTypeDao tblAnnexureTypeDao;
	@Autowired
	private TblAgreementTypeDao tblAgreementTypeDao;
     /**
  	 * Use to open Mandatory Document Requirement page
  	 * @author heeral.soni
  	 * @param tenderId
  	 * @param formId
  	 * @param modelMap
  	 * @param request
  	 * @throws Exception
  	 * @return
  	 */
     @RequestMapping(value = "/common/createmandatdocreq/{parentId}/{objectId}/{linkId}/{enc}", method = RequestMethod.GET)
      public String createMandatDocReq(@PathVariable("parentId") int parentId,@PathVariable("objectId") int objectId,@PathVariable("linkId") int linkId,ModelMap modelMap,HttpServletRequest request) {
         String retVal="common/CreateMandDocReq";
          try {
        	  /*** get Yes No list from common services **/
                  modelMap.addAttribute("mandatoryList", commonService.getYesNo());
                  modelMap.put("objectId", objectId);
                  modelMap.put("parentId", parentId);
                  modelMap.put("linkId", linkId);
          } catch (Exception e) {
              return exceptionHandlerService.writeLog(e);
          }finally {
              auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createMandatoryDocLinkId,getopenmenddocreq,parentId,objectId);
          }
          return retVal;
      }
     
      /**
 	 * Use to add Mandatory Document Requirement page
 	 * @author heeral.soni
 	 * @param request
 	 * @throws Exception
 	 * @return
 	 */
     @RequestMapping(value = "/common/addmandatorydoc", method = RequestMethod.POST)
     public String addMandatoryDoc(RedirectAttributes redirectAttributes, HttpServletRequest request) {
     	boolean success=false;
     	String retVal="common/admin/managevendorform";
         int objectId = 0;
         int parentId = 0;
         int linkId = 0;
         boolean valid=true;
         try{
        	 int sessionUserId = abcUtility.getSessionUserId(request);
       		 if(sessionUserId!=0){
                        TblDocument tblDocument=null;
                        List<TblDocument> tblDocuments=new ArrayList<TblDocument>();
                        int cnt = StringUtils.hasLength(request.getParameter("txtRowCnt")) && !"".equals(request.getParameter("txtRowCnt"))? Integer.parseInt(request.getParameter("txtRowCnt")):0;
                        objectId = StringUtils.hasLength(request.getParameter("hdObjectId")) && !"".equals(request.getParameter("hdObjectId"))? Integer.parseInt(request.getParameter("hdObjectId")):0;
                        parentId = StringUtils.hasLength(request.getParameter("hdParentId")) && !"".equals(request.getParameter("hdParentId"))? Integer.parseInt(request.getParameter("hdParentId")):0;
                        linkId = StringUtils.hasLength(request.getParameter("hdLinkId")) && !"".equals(request.getParameter("hdLinkId"))? Integer.parseInt(request.getParameter("hdLinkId")):0;
	         	
                        String[] docName = request.getParameterValues("txtDocumentName");
	         	String[] mandatory=request.getParameterValues("selMandatory");
	         	int userId = abcUtility.getSessionUserDetailId(request);
	         	for(int i=0;i<cnt;i++){
	         		if(docName[i]==null || "".equals(docName[i])){
	         			valid=false;
	         			break;
	         		}
	         	}
	         	if(valid){
	 	        	for(int i=0;i<cnt;i++){
	 	        		tblDocument=new TblDocument();
	 	        		tblDocument.setDocumentName(docName[i]);
	 	        		tblDocument.setObjectId(objectId);//formId set as objectId
	 	        		tblDocument.setTblLink(new TblLink(linkId));
	 	        		tblDocument.setParentId(parentId);
	 	        		tblDocument.setIsMandatory(StringUtils.hasLength(mandatory[i]) && !"".equals(mandatory[i])?Integer.parseInt(mandatory[i]):0);
	 	        		tblDocument.setCreatedBy(userId);
	 	        		tblDocuments.add(tblDocument);
	 	        	}
	 	        	success=commonService.addReqDocuments(tblDocuments);
	         	}
       		}
                 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
                 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_mandatory_document_created" : CommonKeywords.ERROR_MSG_KEY.toString());
         }catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),createMandatoryDocLinkId, success ? manDoccreated : manDoccreatefail,parentId,objectId);
         }
         return retVal;
     }
    
      /**
   	 * Use to open Mandatory Document Requirement page for edit/view
   	 * @author heeral.soni
   	 * @param tenderId
   	 * @param formId
   	 * @param modelMap
   	 * @param request
   	 * @throws Exception
   	 * @return
   	 */
     @RequestMapping(value = "/common/editviewmandatorydoc/{parentId}/{objectId}/{linkId}/{from}/{enc}", method = RequestMethod.GET)
     public String editViewMandatoryDoc(@PathVariable("parentId") int parentId,@PathVariable("objectId") int objectId,@PathVariable("linkId") int linkId,@PathVariable("from") int from,ModelMap modelMap,HttpServletRequest request) {
         String retVal="common/ViewMandDocReq";
         String page=getopenviewmenddocreq;
         try {
        	 /*** get Yes No list from common services **/
                 modelMap.addAttribute("mandatoryList", commonService.getYesNo());
	         /*** get document table data services **/
	         modelMap.addAttribute("tblDocuments", commonService.getDocumentsByObjectId(objectId));
                 modelMap.put("objectId", objectId);
                 modelMap.put("parentId", parentId);
                 if(from == 0){// 0 : access edit page
                     retVal = "common/CreateMandDocReq";
                     page=getopeneditmenddocreq;
                     modelMap.put("linkId", linkId);
                 }
         } catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, page, parentId,objectId);
         }
         return retVal;
     }
     
     /**
  	 * Use to update Mandatory Document Requirement page
  	 * @author heeral.soni
  	 * @param request
  	 * @throws Exception
  	 * @return
  	 */
     @RequestMapping(value = "/common/updatemandatorydoc", method = RequestMethod.POST)
     public String updateMandatoryDoc(RedirectAttributes redirectAttributes, HttpServletRequest request) {
     	boolean success=false;
     	String retVal="common/admin/managevendorform";
         int objectId = 0;
         int parentId = 0;
         boolean valid=true;
         try{
        	int sessionUserId = abcUtility.getSessionUserId(request);
       		if(sessionUserId!=0){
                        TblDocument tblDocument=null;
	         	List<TblDocument> tblDocuments=new ArrayList<TblDocument>();
	         	
	         	int cnt = StringUtils.hasLength(request.getParameter("txtRowCnt")) && !"".equals(request.getParameter("txtRowCnt"))? Integer.parseInt(request.getParameter("txtRowCnt")):0;
	         	objectId = StringUtils.hasLength(request.getParameter("hdObjectId")) && !"".equals(request.getParameter("hdObjectId"))? Integer.parseInt(request.getParameter("hdObjectId")):0;
                        parentId = StringUtils.hasLength(request.getParameter("hdParentId")) && !"".equals(request.getParameter("hdParentId"))? Integer.parseInt(request.getParameter("hdParentId")):0;
	         	
	         	String[] docName=request.getParameterValues("txtDocumentName");
	         	String[] mandatory=request.getParameterValues("selMandatory");
	         	int userId = abcUtility.getSessionUserDetailId(request);
	         	for(int i=0;i<cnt;i++){
                            if(docName[i]==null || "".equals(docName[i])){
                                    valid=false;
                                    break;
                            }
	         	}
	         	if(valid){
                            for(int i=0;i<cnt;i++){
                                    tblDocument=new TblDocument();
                                    tblDocument.setDocumentName(docName[i]);
                                    tblDocument.setObjectId(objectId);
                                    tblDocument.setTblLink(new TblLink(createMandatoryDocLinkId));
                                    tblDocument.setParentId(parentId);
                                    tblDocument.setIsMandatory(StringUtils.hasLength(mandatory[i]) && !"".equals(mandatory[i])?Integer.parseInt(mandatory[i]):0);
                                    tblDocument.setCreatedBy(userId);
                                    tblDocuments.add(tblDocument);
                            }
                            /*** update services call in which first all row delete form table than after insert new row  **/
                            success = commonService.updateReqDocuments(objectId, tblDocuments);
                    }
                }
         }catch(Exception e){
         	return exceptionHandlerService.writeLog(e);
         }finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editMandatoryDocLinkId, success ? manDocupdated : manDocupdatedfail,parentId,objectId);
         }
  		 retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
  		 redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_success_mandatory_document_updated" : CommonKeywords.ERROR_MSG_KEY.toString());
         return retVal;
     }
     
    /**
     * @author nirav.modi
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/manageaudittrailreport/{enc}", method = RequestMethod.GET)
    public String manageAuditTrailReport(ModelMap modelMap, HttpServletRequest request) {
    	int userTypeId=abcUtility.getSessionUserTypeId(request) ;
    	String retVal="common/ManageAuditTrailReport";
        try {
        	int reportId=0;
        	if(userTypeId == 2){// For Bidder
        		reportId=manageBidderAuditTrailReportId;
        	}else{
        		reportId=manageAuditTrailReportId;
        	}
            modelMap.addAttribute("reportId", reportId);
            reportGeneratorService.getReportConfigDetails(reportId, modelMap);
        } catch (Exception ex) {
            retVal= exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),userTypeId==2 ? manageBidderAuditTrailReportLinkId : manageAuditTrailReportLinkId, getManageAuditTrailReportRemark, 0, 0);
        }
        return retVal;
    }
    
    /**
     * @author heeral.soni
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/managedailypaymentreport/{enc}", method = RequestMethod.GET)
    public String manageDailyPaymentReport(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", manageDailyPaymentReportId);// 48 for daily payment report
            reportGeneratorService.getReportConfigDetails(manageDailyPaymentReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageDailyPaymentLinkId, getDailyPaymentReportRemark, 0, 0);
        }
        return "common/ManageDailyPaymentReport";
    }   
    
    
    /**
     * @author nirav.modi
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/managedcrenewalreport/{userType}/{enc}", method = RequestMethod.GET)
    public String manageDCRenewalReport(ModelMap modelMap, HttpServletRequest request,@PathVariable("userType") int userType) {
        try {
        	int reportId=0;
        	if(userType==2){
        		reportId=manageDCRenewalBidderReportId;
        	}else if(userType==1){
        		reportId=manageDCRenewalOfficerReportId;
        	}
        	modelMap.addAttribute("reportId", reportId);
    		reportGeneratorService.getReportConfigDetails(reportId,modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),userType==2? manageDCRenewalReportBidderLinkId:manageDCRenewalReportOfficerLinkId, getManageDCRenewalReportRemark, 0, 0);
        }
        return "common/ManageDCRenewalReport";
    }
    
    /**
     * @author nirav.modi
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/manageloginreport/{enc}", method = RequestMethod.GET)
    public String manageLoginReport(ModelMap modelMap, HttpServletRequest request) {
    	int userType=0;
    	String retVal="common/ManageLoginReport";
        try {
        	int reportId=0;
        	userType= abcUtility.getSessionUserTypeId(request);
        	if(userType==2){
        		reportId=manageBidderLoginReportId;
        	}else{
        		reportId=manageLoginReportId;
        	}
        	modelMap.addAttribute("reportId", reportId);
            reportGeneratorService.getReportConfigDetails(reportId, modelMap);
        } catch (Exception ex) {
            retVal= exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),userType==2 ?manageBidderLoginReportLinkId  : manageLoginReportLinkId , getManageLoginReportRemark, 0, 0);
        }
        return retVal;
    }
    
    /**
     * @author nirav.modi
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/manageusermanagementhistory/{enc}", method = RequestMethod.GET)
    public String manageUserManagementHistory(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", manageUserManagementHistoryReportId);
            reportGeneratorService.getReportConfigDetails(manageUserManagementHistoryReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageUserManagementHistoryLinkId, getManageUserManageHistoryReportRemark, 0, 0);
        }
        return "common/ManageUserManagementHistoryReport";
    }
    
    /**
     * @author nirav.modi
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/managedcreport/{enc}", method = RequestMethod.GET)
    public String manageDCReport(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", manageDCReportId);
            reportGeneratorService.getReportConfigDetails(manageDCReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getManageDCRemark, 0, 0);
        }
        return "common/ManageDCReport";
    }

//    @RequestMapping(value = "/", method = RequestMethod.GET)
//    public String generatePDF(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {
//        List<SelectItem> items = new ArrayList<SelectItem>();
//        items.add(new SelectItem("Yes", "yes"));
//        items.add(new SelectItem("No", "no"));
//        items.add(new SelectItem("No", "no"));        
//        modelMap.put("yesno", items);
//        String date="2012-06-29 10:26";
//        //25-01-2013 12:11 dd-MM-yyyy HH:mm
//        try {
//            modelMap.put("datecheck1", new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(date));
//        } catch (ParseException ex) {
//            System.out.println("sssssssssssss :: "+ex);
//        }
//        modelMap.put("datecheck2", date);
//        return "home";
//    }
//    
//    @RequestMapping(value = "/test", method = RequestMethod.GET)
//    public String viewTest(HttpServletRequest request, HttpServletResponse response, ModelMap modelMap) {
//        return "test";
//    }
//    @RequestMapping(value = "/", method = RequestMethod.GET)
//    public String generatePDF(HttpServletRequest request, HttpServletResponse response) {
//        return "redirect:/?theme=orange";
//    }
//    @RequestMapping(value = "/", params = {"theme"}, method = RequestMethod.GET)
//    public String showHome(@RequestParam(value = "theme", required = true, defaultValue = "orange") String themeName, HttpServletRequest request, HttpServletResponse response) {
//        List<SelectItem> hintQueList = new ArrayList<SelectItem>();
//        hintQueList.add(new SelectItem("What is your mother's maiden name?", "1"));
//        request.setAttribute("hintQueList", hintQueList);
//
//        List<SelectItem> checkBoxList = new ArrayList<SelectItem>();
//        checkBoxList.add(new SelectItem("Box 1", "1"));
//        checkBoxList.add(new SelectItem("Box 2", "2"));
//        request.setAttribute("checkBoxList", checkBoxList);
//
//        List<SelectItem> radioList = new ArrayList<SelectItem>();
//        radioList.add(new SelectItem("Radio 1", "1"));
//        radioList.add(new SelectItem("Radio 2", "2"));
//        request.setAttribute("radioList", radioList);
//
//        return "home";
//    }
    @RequestMapping(value = "/contactus", method = RequestMethod.GET)
    public String contactUs(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap) {
    	try {
    		List<Object[]> data =manageContentService.getContAbout(abcUtility.getSessionClientId(request),4);
    		int ShowAccessDetail=abcUtility.getAccessDetail(request);
    		if(ShowAccessDetail==1){
    		int visitorCount=commonService.getVisitorDetail(request);
    		modelMap.addAttribute("visitorCount",visitorCount);
    		}
    		modelMap.addAttribute("contactUsData", data!=null && ! data.isEmpty() ? data.get(0)[0] : "");
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
        return "common/ContactUs";
    }
    
    @RequestMapping(value = "/aboutus", method = RequestMethod.GET)
    public String abouttUs(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap) {
    	try {
    		List<Object[]> data=manageContentService.getContAbout(abcUtility.getSessionClientId(request),3);
    		modelMap.addAttribute("aboutUsData",data!=null && ! data.isEmpty() ? data.get(0)[0] : "");
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
        return "common/AboutUs";
    }
    @RequestMapping(value = "/faqs/{isBidderFaq}", method = RequestMethod.GET)
    public String freqAskQue(@PathVariable("isBidderFaq")int isBidderFaq, HttpServletResponse response, HttpServletRequest request,ModelMap modelMap) {
    	try {
    		if(isBidderFaq!=0){
    			modelMap.addAttribute("faqFile", "FaqBidder");
    			modelMap.addAttribute("isBidderFaq", 1);
    		}
    		else{
    			modelMap.addAttribute("faqFile", "FaqGeneral");
    			modelMap.addAttribute("isBidderFaq", 0);
    		}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
        return "common/Faqs";
    }
    /**
     * PT:20745
     * @author bharat
     * @param response
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/getinquries", method = RequestMethod.POST)
    public String getInqueries(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap) {
    	String pageName="common/GetInquiery";
    	Integer categoryId=0;
    	int linkType=0;
    	try {
    		categoryId = Integer.parseInt(StringUtils.hasLength(request.getParameter("hdCatId")) ? request.getParameter("hdCatId") : "0");
    		linkType = StringUtils.hasLength(request.getParameter("txtLinkType")) ? Integer.parseInt(request.getParameter("txtLinkType")):0;
    		int clientId = abcUtility.getSessionClientId(request);
    		TblProductCategory tblProductCategory = commonService.getCategoryDetail(categoryId,clientId);
    		String langId=WebUtils.getCookie(request, "locale").getValue();
    		modelMap.addAttribute("CategoryId", categoryId);
    		modelMap.addAttribute("CategoryName", tblProductCategory.getCategoryName());
    		modelMap.addAttribute("LinkType", linkType);
    		modelMap.put("countryList", modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId),"countryId", "lang" + langId));
			modelMap.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(3), "stateId", "lang"+ WebUtils.getCookie(request, "locale").getValue()));
			
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, categorywise_statistic, 0, 0);
        }
    	return pageName;
    }
    
    /**
     * PT: 20745
     * Get listing of category wise statistics 
     * @param response
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/common/CategoryWiseListingReport/{enc}", method = RequestMethod.GET)
    public String getCategoryListing(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap) {
    	String pageName="/eauction/common/CategoryListing";
    	try {
    		modelMap.addAttribute("isStatisticsAdded", true);
    		modelMap.put("reportId", linkStaticsReportHomePage);
     		reportGeneratorService.getReportConfigDetails(linkStaticsReportHomePage, modelMap);
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, categorywise_statistic, 0, 0);
        }
    	return pageName;
    }
    /**
     * To add supplier inquiry
     * @param response
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/addinquries", method = RequestMethod.POST)
    public String addInqueries(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap, RedirectAttributes redirectAttributes) {
    	String retVal="redirect:/";
    	boolean success = false;
    	String categoryName=null;
    	String companyName=null;
    	String personName=null;
    	String emailId=null;
    	String phoneNo=null;
    	String mobileNo=null;
    	String comments=null;
    	String countryName=null;
    	String stateName=null;
    	String city=null;
    	String linkType=null;
    	int inquiryType=0;
    	int countryId = 0;
    	int stateId = 0;
    	int clientId = 0;
    	int userId = 0;
    	int objectId = 0;
    	try {
    		userId = abcUtility.getSessionUserId(request);
    		emailId = StringUtils.hasLength(request.getParameter("txtEmailId")) ? request.getParameter("txtEmailId") :"";
    		categoryName = StringUtils.hasLength(request.getParameter("hdCategoryName")) ? request.getParameter("hdCategoryName") :"";
    		inquiryType = StringUtils.hasLength(request.getParameter("hdInquiryType")) ? Integer.parseInt(request.getParameter("hdInquiryType")) :0;
    		companyName = StringUtils.hasLength(request.getParameter("txtCompanyName")) ? request.getParameter("txtCompanyName") :"";
    		personName = StringUtils.hasLength(request.getParameter("txtPersonName")) ? request.getParameter("txtPersonName") :"";
    		city = StringUtils.hasLength(request.getParameter("txtCity")) ? request.getParameter("txtCity") :"";
    		phoneNo = StringUtils.hasLength(request.getParameter("txtPhone")) ? request.getParameter("txtPhone") :"";
    		mobileNo = StringUtils.hasLength(request.getParameter("txtMobileNo")) ? request.getParameter("txtMobileNo") :"";
    		countryId = StringUtils.hasLength(request.getParameter("selCountry")) ? Integer.parseInt(request.getParameter("selCountry")):0;
    		stateId = StringUtils.hasLength(request.getParameter("selState")) ? Integer.parseInt(request.getParameter("selState")):0;
    		comments = StringUtils.hasLength(request.getParameter("txtaComments")) ? request.getParameter("txtaComments") :"";
    		clientId = abcUtility.getSessionClientId(request);
    		
    		if(categoryName!=null && !"".equalsIgnoreCase(categoryName) && companyName!=null && !"".equalsIgnoreCase(companyName) && mobileNo!=null && 
    				!"".equalsIgnoreCase(mobileNo) && personName!=null && !"".equalsIgnoreCase(personName) && city!=null && !"".equalsIgnoreCase(city) && 
    				countryId!=0 && stateId!=0 && clientId!=0) {
    			
    			linkType = inquiryType==1 ? messageSource.getMessage("manage_statistics_get_specs", null, LocaleContextHolder.getLocale()) :
    						inquiryType==2 ? messageSource.getMessage("manage_statistics_get_quote", null, LocaleContextHolder.getLocale()) :
    							messageSource.getMessage("manage_statistics_get_suppliers", null, LocaleContextHolder.getLocale());
    			
    			TblSupplierInquiry tblSupplierInquiry = new TblSupplierInquiry();
    			tblSupplierInquiry.setCategory(categoryName);
    			tblSupplierInquiry.setEmailId(emailId);
    			tblSupplierInquiry.setInquiryType(inquiryType);
    			tblSupplierInquiry.setCompanyName(companyName);
    			tblSupplierInquiry.setPersonName(personName);
    			tblSupplierInquiry.setPhoneNo(phoneNo);
    			tblSupplierInquiry.setMobileNo(mobileNo);
    			tblSupplierInquiry.setTblCountry(new TblCountry(countryId));
    			tblSupplierInquiry.setTblState(new TblState(stateId));
    			tblSupplierInquiry.setTblClient(new TblClient(clientId));
    			tblSupplierInquiry.setCity(city);
    			tblSupplierInquiry.setComments(comments);
    			commonService.addTblSupplierInquiry(tblSupplierInquiry);
    			countryName = commonService.getField("TblCountry", "lang"+WebUtils.getCookie(request, "locale").getValue(), "countryId", countryId);
    			stateName = commonService.getField("TblState", "lang"+WebUtils.getCookie(request, "locale").getValue(), "stateId", stateId);
    			success = true;
    			Map<String, Object> paramMap = new HashMap<String, Object>();
    			paramMap.put("to", supportTeamEmailId);
    			paramMap.put("LinkType", linkType);
    			paramMap.put("CompanyName", companyName);
    			paramMap.put("EmailId", emailId);
    			paramMap.put("Category", categoryName);
    			paramMap.put("PersonName", personName);
    			paramMap.put("EmailId", emailId);
    			paramMap.put("PhoneNo", phoneNo);
    			paramMap.put("MobileNo", mobileNo);
    			paramMap.put("Country", countryName);
    			paramMap.put("State", stateName);
    			paramMap.put("City", city);
    			paramMap.put("Comments", comments);
    			mailContentUtillity.dynamicMailGeneration(String.valueOf(supplierInquiryMailTemplateId), String.valueOf(userId), String.valueOf(objectId), paramMap, null);
    		}
    		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), 
    								success ? "msg_success_add_supplier_inquiry" : CommonKeywords.ERROR_MSG_KEY.toString());
    		
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
    	return retVal;
    }
    @RequestMapping(value = "/jsinstruction", method = RequestMethod.GET)
    public String jsInstruction(HttpServletResponse response, HttpServletRequest request) {
        return "common/JSInstruction";
    }

    @RequestMapping(value = "/jcepolicy", method = RequestMethod.GET)
    public String jcePolicy(HttpServletResponse response, HttpServletRequest request) {
        return "common/JCEPolicy";
    }

    @RequestMapping(value = "/activexenable", method = RequestMethod.GET)
    public String activeXEnable(HttpServletResponse response, HttpServletRequest request) {
        return "common/ActiveXEnable";
    }

    @RequestMapping(value = "/signerenable", method = RequestMethod.GET)
    public String signerEnable(HttpServletResponse response, HttpServletRequest request) {
        return "common/SignerEnable";
    }
    
    @RequestMapping(value = "/checkbrowser", method = RequestMethod.GET)
    public String checkBrowser(HttpServletResponse response, HttpServletRequest request) {
        return "common/CheckBrowser";
    }
    
    @RequestMapping(value = "/checkBrowser64bit", method = RequestMethod.GET)
    public String checkBrowser64bit(HttpServletResponse response, HttpServletRequest request) {
        return "common/CheckBrowser64bit";
    }

    @RequestMapping(value = "/sessionexpired", method = RequestMethod.GET)
    public String sessionExpired(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap) {
    	modelMap.addAttribute("sessionTimeOutMinutes", request.getSession().getMaxInactiveInterval()/60);
        return "common/SessionExpired";
    }

    @RequestMapping(value = "/privacypolicy", method = RequestMethod.GET)
    public String privacyPolicy(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap) {
    	int ShowAccessDetail=abcUtility.getAccessDetail(request);
		if(ShowAccessDetail==1){
    	int visitorCount=commonService.getVisitorDetail(request);
		modelMap.addAttribute("visitorCount",visitorCount);
		}
        return "common/PrivacyPolicy";
    }
    
    @RequestMapping(value = "/disclaimer", method = RequestMethod.GET)
    public String disclaimer(HttpServletResponse response, HttpServletRequest request) {
        return "common/Disclaimer";
    }

    @RequestMapping(value = "/termsandconditions", method = RequestMethod.GET)
    public String termsAndConditions(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap) throws NumberFormatException, Exception {
    	String langId=WebUtils.getCookie(request, "locale").getValue();
    	List<Object[]> data=manageContentService.getClientRegTerms(abcUtility.getSessionClientId(request),8,Integer.parseInt(langId));
		modelMap.addAttribute("regterms",data!=null && ! data.isEmpty() ? data.get(0)[0] : "");
		int ShowAccessDetail=abcUtility.getAccessDetail(request);
		if(ShowAccessDetail==1){
		int visitorCount=commonService.getVisitorDetail(request);
		modelMap.addAttribute("visitorCount",visitorCount);
		}
		ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    	modelMap.addAttribute("isDcVerificationRequired",clientBean.getIsDcVerificationRequired());
        return "common/TermsAndConditions";
    }

    @RequestMapping(value = "/exception", method = RequestMethod.GET)
    public String goException(HttpServletResponse response, HttpServletRequest request) {
        return "common/ExceptionPage";
    }

    @RequestMapping(value = "/pagenotfound", method = RequestMethod.GET)
    public String pageNotFound(HttpServletResponse response, HttpServletRequest request) {
        return "common/PageNotFound";
    }
    
    @RequestMapping(value = "/clientnotfound", method = RequestMethod.GET)
    public String clientNotFound(HttpServletResponse response, HttpServletRequest request) {
        return "common/ClientNotFound";
    }
    
    @RequestMapping(value = "/ajaxsessionexpired", method = RequestMethod.GET)
    public String ajaxSessionExpired(HttpServletResponse response, HttpServletRequest request) {
        return "common/AjaxSessionExpired";
    }

    @RequestMapping(value = "/error", method = RequestMethod.GET)
    public String error(HttpServletResponse response, HttpServletRequest request) {
        return "common/Error";
    }

    @RequestMapping(value = "/javaenabled/{paramId}", method = RequestMethod.GET)
    public String javaEnabled(@PathVariable("paramId") Integer paramId, HttpServletResponse response, HttpServletRequest request) {
        return "common/JavaEnabled";
    }

    @RequestMapping(value = "/common/admin/depttree", method = RequestMethod.GET)
    public String deptTree() {
        return "/common/admin/DeptTree";
    }
    
    @RequestMapping(value = "/welcome/{enc}", method = RequestMethod.GET)
    public String welcome() {
        return "welcome";
    }

    @RequestMapping(value="/ajax/checkuniquedepartmentname", method=RequestMethod.POST)
    @ResponseBody
    public String checkUniqueDepartmentName(@RequestParam("txtDepartmentName") String departmentName,@RequestParam("hdClientId") int clientId,@RequestParam("hdDeptId") int deptId,@RequestParam("txtParentDeptId") int parentDeptId,HttpServletRequest request){
    	boolean isExist = false;
    	try{
    		if(abcUtility.getSessionUserId(request)!=0){
    			isExist = commonService.checkUniqueDepartmentName(clientId, departmentName,deptId,parentDeptId);
    		}else{
    			return "sessionexpired";
    		}
    	} catch (Exception e) {
    		exceptionHandlerService.writeLog(e);
    	} 
//    	finally {
//             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createDeptLinkId, ajaxCheckUniqueDeptNameAuditMsg, 0, deptId);
//        }
    	return isExist+"";
    } 
    

    @RequestMapping(value = {"/common/admin/ajaxgetdeptlist", "/ajaxcall/ajaxgetdeptlist"}, method = RequestMethod.POST)
    public void getDepartmentList(@RequestParam("hdFullTree") boolean isFullTree,@RequestParam("hdDeptId") int hdDeptId, HttpServletResponse response, HttpSession httpSession, HttpServletRequest request) throws IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        try {
            int clientId = 0;
            String deptTree = null;
            int userTypeId=0;
            int sessionDeptId=0;
            String treeStatus = "open";
            String isAnalysisReport = request.getParameter("hdIsAnalysisReport");
            String selBankClientId = request.getParameter("SelectedBankClient");
            clientId = abcUtility.getSessionClientId(request);
            if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            	SessionBean sessionBean= (SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
                userTypeId = sessionBean.getUserTypeId();
                if(userTypeId == 1 || userTypeId == 2){
                	isFullTree = true;
                }
                sessionDeptId=sessionBean.getDeptId();
            }
            //CR:18014
            int allDepAllow = 0;
            if(isAnalysisReport != null && isAnalysisReport.equals("1")){
            	int isDRT = (request.getSession().getAttribute("isDRT").toString().equals("true"))?1:0;
            	if(isDRT == 1){
            		allDepAllow = 1;
            	}
            }
            
            if(request.getHeader("referer").contains("auctiondetailreport") && allDepAllow==0){
            	List<Object> lstSector = clientService.getClientSector(clientId);            
                for(Object obj:lstSector){
                	if((Integer)obj == 1 || (Integer)obj == 2 || (Integer)obj == 3){
                		allDepAllow = 1;
                            break;
                    }
                }
            	
            }
            List<Map<String, Object>> lst = null;
            if(allDepAllow == 1){
            	treeStatus = "closed"; // Bug:19502 changes done for fast loading.
            	lst = commonService.getDeptTreeForDRTReport(clientId,userTypeId,sessionDeptId,isFullTree,hdDeptId,allDepAllow,selBankClientId,"false");
            }else{
            	treeStatus = "open";
            	lst = commonService.getDeptTree(clientId,userTypeId,sessionDeptId,isFullTree,hdDeptId);
            }
            
            deptTree = commonService.getJasionFormat(lst,treeStatus);
            
            out.print(deptTree);
           
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            out.close();
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deptTreeLinkId, ajaxGetDeptTreeAuditMsg, 0, hdDeptId);
        }
    }

   
	/**
     * Generates the options of States provided by the countryId passed. Used for the pages with login.
     *
     * @param countryId
     * @return
     */
    @RequestMapping(value = "/ajax/getstatebycountryid", method = RequestMethod.POST)
    @ResponseBody
    public String getStateListByCountryId(@RequestParam("txtCountryId") Integer countryId, HttpSession session, HttpServletRequest request) {
        String retVal = "sessionexpired";
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		retVal = encryptDecryptUtils.getOptions("selState", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(countryId), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()), false, "", "Please Select");
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, !"".equalsIgnoreCase(retVal) ? ajaxGetStateByCountryIdSuccessAuditMsg : ajaxGetStateByCountryIdFailAuditMsg, 0, countryId);
//        }
        return retVal;
    }
    /**
     * Generates the options of States provided by the countryId passed. Used for the report search criteria.
     *
     * @param countryId
     * @return
     */
    @RequestMapping(value = "/ajax/getreportstatebycountryid", method = RequestMethod.POST)
    @ResponseBody
    public String getreportStateListByCountryId(@RequestParam("txtCountryId") Integer countryId,@RequestParam("hdfieldName") String fieldName, HttpSession session, HttpServletRequest request) {
        String retVal = "sessionexpired";
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		List<TblState> statelist = countryId!=null?commonService.getStateBycountryId(countryId):null;
        		if(countryId!=null && (statelist!=null && !statelist.isEmpty())){
        				retVal = encryptDecryptUtils.getOptions(fieldName, modelToSelectItem.convertListIntoSelectItemList(statelist, "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()), true, "", "Select");
        				retVal=retVal.subSequence(0,retVal.lastIndexOf("</option>")+9).toString();//To remove jhselsel_* in case of reporting opitons
        		}else{
        			retVal="<option value=''>Select</option>";
        		}
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return retVal;
    }
    /**
     * Generates the options of States provided by the countryId passed. Used for the pages without login.
     *
     * @param countryId
     * @return
     */
    @RequestMapping(value = "/ajaxcall/getstatebycountryid", method = RequestMethod.POST)
    @ResponseBody
    public String getStateListByCountryId(@RequestParam("txtCountryId") Integer countryId, HttpServletRequest request) {
        String retVal = null;
        try {
            retVal = encryptDecryptUtils.getOptions("selState", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(countryId), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()), false, "", "Please Select");
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, !"".equalsIgnoreCase(retVal) ? ajaxGetStateByCountryIdSuccessAuditMsg : ajaxGetStateByCountryIdFailAuditMsg, 0, countryId);
//        }
        return retVal;
    }
    
    @RequestMapping(value = "/ajaxcall/gettimezonebycountryid", method = RequestMethod.POST)
    @ResponseBody
    public String getTimeZoneByCountryId(@RequestParam("txtCountryId") Integer countryId, HttpServletRequest request) {
        String retVal = null;
        try {
            retVal = commonService.getTimezoneBycountryId(countryId);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return retVal;
    }
    @RequestMapping(value = "/ajaxcall/validatecaptcha", method = RequestMethod.POST)
    @ResponseBody
    public String validateCaptcha(@RequestParam("challenge") String challenge, @RequestParam("userInput") String userInput, HttpServletRequest request) {
        String result = null;
        try {
//   @author Jaynam 
//   abcCaptcha Response code Start 
        	 AbcCaptchaResponse abcCaptchaResponse =  AbcCaptchaFactory.checkResponse(request.getRemoteAddr(), challenge, userInput);
          	 if (abcCaptchaResponse.isValid()) {
          		 HttpSession session = request.getSession();
          		 if(session.getAttribute("abcCaptcha") != null)
          		 {
          			 session.removeAttribute("abcCaptcha");
          		 }
              result = "Valid";              
	          } else {
	              result = "Verification code is invalid";
	          }
//   End         	 
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
		/*
		 * finally {
		 * auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.
		 * AUDIT_BEAN.toString()), 0, "OK".equalsIgnoreCase(result) ?
		 * ajaxCaptchaValidateSuccessAuditMsg : ajaxCaptchaValidateFailAuditMsg, 0, 0);
		 * }
		 */
        return result;
    }
    @RequestMapping(value = "/common/GetSubModuleList", method = RequestMethod.POST)
    public void getSubModuleList(@RequestParam("txtmoduleId") int txtModuleId, ModelMap map, HttpServletResponse response, HttpServletRequest request) {
        StringBuilder str = new StringBuilder();
        try {
            List<TblSubModule> lstSubModule = commonService.getSubModuleBymoduleId(txtModuleId);
            List<SelectItem> lstSelSubmodule = modelToSelectItem.convertListIntoSelectItemList(lstSubModule, "subModuleId", "lang"+WebUtils.getCookie(request, "locale").getValue());

            /*for (TblSubModule tblSubModule : lstSubModule) {
                lstSelSubmodule.add(new SelectItem(tblSubModule.getSubModuleName(), tblSubModule.getSubModuleId()));
            }*/

            str.append(encryptDecryptUtils.getOptions("selSubModuleId", lstSelSubmodule, true, null, "Select Sub Module"));
            response.getWriter().write(str.toString());
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxGetSubModuleListAuditMsg, 0, txtModuleId);
//        }
    }

    @RequestMapping(value = "/common/GetEventList", method = RequestMethod.POST)
    public void getEventList(@RequestParam("txtsubModuleId") int txtSubModuleId, ModelMap map, HttpServletResponse response, HttpServletRequest request) {
        StringBuilder str = new StringBuilder();
        try {
            List<TblEvent> lstEvents = commonService.getEventBysubModuleId(txtSubModuleId);
            
            List<SelectItem> lstSelEvent = modelToSelectItem.convertListIntoSelectItemList(lstEvents, "eventId", "lang"+WebUtils.getCookie(request, "locale").getValue());

            
            /*for (TblEvent tblEvent : lstEvents) {
                lstSelEvent.add(new SelectItem(tblEvent.getLang1(), tblEvent.getEventId()));
            }*/

            str.append(encryptDecryptUtils.getOptions("selEventId", lstSelEvent, true, null, "Select Event"));
            response.getWriter().write(str.toString());
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxGetEventListAuditMsg, 0, txtSubModuleId);
//        }
    }

    @RequestMapping(value = "/common/GetLinkList", method = RequestMethod.POST)
    public void getLinkList(@RequestParam("txteventId") int txtEventId, ModelMap map, HttpServletResponse response, HttpServletRequest request) {
        StringBuilder str = new StringBuilder();
        try {
            List<TblLink> lstLink = commonService.getLinkByeventId(txtEventId);
            List<SelectItem> lstSelLink = modelToSelectItem.convertListIntoSelectItemList(lstLink, "linkId", "lang"+WebUtils.getCookie(request, "locale").getValue());

            /*for (TblLink tblLink : lstLink) {
                lstSelLink.add(new SelectItem(tblLink.getLinkName(), tblLink.getLinkId()));
            }*/

            str.append(encryptDecryptUtils.getOptions("selLinkId", lstSelLink, true, null, "Select Link"));
            response.getWriter().write(str.toString());
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxGetLinkListAuditMsg, 0, txtEventId);
//        }
    }
    @RequestMapping(value = "/common/getsubmodulelist", method = RequestMethod.POST)
    public void getAllSubModuleListByModuleId(@RequestParam("selModuleId") int selModuleId, ModelMap map, HttpServletResponse response, HttpServletRequest request) {
        StringBuilder str = new StringBuilder("sessionexpired");
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		str.setLength(0);
        		List<Object[]> lstSubModule = commonService.getAllSubModuleBymoduleId(selModuleId);
        		List<SelectItem> lstSelSubmodule = abcUtility.convert(lstSubModule);
        		str.append(encryptDecryptUtils.getOptions("selSubModuleId", lstSelSubmodule, false, null, "Select Sub Module"));
        	}
        	response.getWriter().write(str.toString());
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxGetSubModuleListAuditMsg, 0, selModuleId);
//        }
    }

    @RequestMapping(value = "/common/geteventlist", method = RequestMethod.POST)
    public void getAllEventBysubModuleId(@RequestParam("selSubModuleId") int selSubModuleId, ModelMap map, HttpServletResponse response, HttpServletRequest request) {
        StringBuilder str = new StringBuilder("sessionexpired");
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		str.setLength(0);
	            List<Object[]> lstEvents = commonService.getAllEventBysubModuleId(selSubModuleId);
	            List<SelectItem> lstSelEvent = abcUtility.convert(lstEvents);
	            str.append(encryptDecryptUtils.getOptions("selEventId", lstSelEvent, false, null, "Select Event"));
        	}
            response.getWriter().write(str.toString());
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxGetEventListAuditMsg, 0, selSubModuleId);
//        }
    }

    @RequestMapping(value = "/common/getlinklist", method = RequestMethod.POST)
    public void getAllLinksByEventId(@RequestParam("selEventId") int selEventId, ModelMap map, HttpServletResponse response, HttpServletRequest request) {
        StringBuilder str = new StringBuilder("sessionexpired");
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		str.setLength(0);
	            List<Object[]> lstLink = commonService.getAllLinksByEventId(selEventId);
	            List<SelectItem> lstSelLink = abcUtility.convert(lstLink);
	            str.append(encryptDecryptUtils.getOptions("selScreenId", lstSelLink, false, null, "Select Link"));
	            response.getWriter().write(str.toString());
        	}
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxGetLinkListAuditMsg, 0, selEventId);
//        }
    }
    /**
     * Use case: Get Optional Rule Config
     * @author mitesh
     * @param clientId
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value="/common/admin/ruleengine/getoptionalrule/{enc}", method= RequestMethod.GET)
    public String getOptionalRuleConfigPage(HttpServletRequest request, ModelMap modelMap){
    	String retVal="/common/admin/OptionalRuleConfig";
    	int clientId=abcUtility.getSessionClientId(request);
    	try {
    		List<Object[]> clientConfigList=commonService.getClientConfigurations(clientId);
    		List<SelectItem> itemsyesno = new ArrayList<SelectItem>();
    		if(clientConfigList!=null){
    			modelMap.put("clientConfigList",clientConfigList.get(0));
    			itemsyesno.add(new SelectItem("Yes", 1)); 
    			itemsyesno.add(new SelectItem("No", 0));
    			modelMap.addAttribute("itemsyesno", itemsyesno);
    		}
		} catch (Exception e) {
			retVal= exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),createRuleEngineLinkId,getRuleEngineRemark, 0, clientId);
		}
    	return retVal;
    }
    
    /**
     * @author sagar
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value="/common/admin/appversion/{versionId}/{enc}", method= RequestMethod.GET)
    public String appversion(@PathVariable(value = "versionId") int versionId,HttpServletRequest request,ModelMap modelMap){
    	String retVal="/common/admin/AppVersion";
    	int clientId=abcUtility.getSessionClientId(request);
    	List<TblDocUploadConf> lstDocUploadConf;
		try {
			lstDocUploadConf = commonService.getDocUploadConf(createapplicationversioneventid, clientId);
			int allowedSize = 0;
		    StringBuilder allowedExt = new StringBuilder();
		    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
			allowedSize = lstDocUploadConf.get(0).getMaxSize();
			allowedExt.append(lstDocUploadConf.get(0).getType());
			modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
		    }
		    int index = allowedExt.toString().indexOf(",");
		    allowedExt.insert(index + 1, "*.");
		    while (index >= 0) {
			index = allowedExt.toString().indexOf(",", index + ",".length());
			allowedExt.insert(index + 1, "*.");
		    }
		    String txtHidDocIds = request.getParameter("txtHidDocIds");
		    modelMap.addAttribute("allowedExt", allowedExt);
		    modelMap.addAttribute("allowedSize", allowedSize/1024);
		    modelMap.addAttribute("allowFileExist", "y");
		    modelMap.addAttribute("linkId", createApplicationVersionLink); //794
		    modelMap.addAttribute("objectId",versionId);
		    modelMap.addAttribute("cStatusDoc", 5);
            modelMap.addAttribute("cStatusDocView",1);
	        modelMap.addAttribute("mode",versionId == 0 ? 0 : 1);
	        if(versionId!=0)
	        {
	        	Tblappversion tblappversion=commonService.getAppVersion(versionId);
	        	modelMap.addAttribute("tblappversion",tblappversion);
	        	modelMap.addAttribute("objectId",tblappversion.getAppversionId());
	        }
	 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),createApplicationVersionLink,create_app_version, 0, clientId);
		}
	    return retVal;
    }
    
    /**
     * @author sagar
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value="/common/admin/insertupdateappversion", method= RequestMethod.POST)
    public String insertAppVersionDetail(RedirectAttributes redirectAttributes, HttpServletRequest request){
    	String retVal="common/admin/AppVersion";
    	Tblappversion tblappversion=new Tblappversion();
    	boolean success=false;
    	
    	try {
    		String versionNo = request.getParameter("txtVersionNo") !=null?request.getParameter("txtVersionNo"):"";
        	String releaseDate = request.getParameter("txtReleaseDate")!=null?request.getParameter("txtReleaseDate"):"";
        	String changesData = request.getParameter("txtaChanges")!=null?request.getParameter("txtaChanges"):"";
        	String txtHidDocIds = request.getParameter("txtHidDocIds")!=null?request.getParameter("txtHidDocIds"):"";
        	int versionId=Integer.parseInt(request.getParameter("hdVersionId"));
        	tblappversion.setVersionNo(versionNo);
        	tblappversion.setReleaseDate(conversionService.convert(releaseDate, Date.class));
        	tblappversion.setChangesData(changesData);
           	tblappversion.setCreatedOn(commonService.getServerDateTime());
        	int userId = abcUtility.getSessionUserId(request);
        	tblappversion.setCreatedBy(userId);
        	int clientId=abcUtility.getSessionClientId(request);
        	tblappversion.setTblClient(new TblClient(clientId));
        	tblappversion.setUpdatedBy(userId);
        	tblappversion.setUpdatedOn(commonService.getServerDateTime());
          	if(versionId != 0)
	        {
          		tblappversion.setAppversionId(versionId);
	        }
          	success=commonService.addAppVersion(tblappversion);
          //	System.out.println("tblappversion.getAppversionId()"+tblappversion.getAppversionId());
          	if (StringUtils.hasLength(txtHidDocIds)) {
          		fileUploadService.updateOfficerDocsObjectId(txtHidDocIds,tblappversion.getAppversionId(),1);
          		fileUploadService.changeDocFolderByDocMappingId(txtHidDocIds);
            }
          	retVal = success?"common/admin/manageAppVersion" : "common/admin/insertupdateappversion/0";		
         if (versionId == 0) {
            	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_create_AppVersion" : CommonKeywords.ERROR_MSG_KEY.toString());
         } else {
           	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_update_AppVersion" : CommonKeywords.ERROR_MSG_KEY.toString());
         }
          	
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),createApplicationVersionLink,create_app_version, 0, abcUtility.getSessionClientId(request));
		}
      return "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    }
 
    /**
     * 
     * @author sagar 
     * @param versionId
     * @param redirectAttributes
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value="/common/admin/viewAppVersion/{versionId}/{enc}", method= RequestMethod.GET)
    public String viewAppVersionDetail(@PathVariable(value = "versionId") int versionId,RedirectAttributes redirectAttributes, HttpServletRequest request,ModelMap modelMap){
    	String retVal="/common/admin/viewAppVersion";
    	List<Object[]> list=new ArrayList<Object[]>();
		try {

			if (versionId != 0) {
				Tblappversion tblappversion = commonService.getAppVersion(versionId);
				modelMap.addAttribute("tblappversion", tblappversion);
				modelMap.addAttribute("objectId", versionId);
				int clientId=abcUtility.getSessionClientId(request);
				list=fileUploadService.getOfficerDocs(versionId,clientId, createApplicationVersionLink, 1);
				modelMap.addAttribute("list", list);
				}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	
	    return retVal;
    }

    
    
    @RequestMapping(value = "/common/admin/manageAppVersion/{enc}", method = RequestMethod.GET)
    public String viewSupplierStatus(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId",applicationVersionReportId);
            
            reportGeneratorService.getReportConfigDetails(applicationVersionReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageApplicationVersionLink,manage_app_version, 0, 0);
        }
        return "/common/admin/appVersionHistory";
    }
    
    /**
     * @author mitesh
     **/
    @RequestMapping(value = "/common/admin/setoptionalclientconfiguration", method = RequestMethod.POST)
    public String setClientConfiguration(ModelMap map, HttpServletResponse response, HttpServletRequest request,RedirectAttributes redirectAttributes) {
        String retVal="sessionexpired";
        boolean success=false;
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		int clientId=abcUtility.getSessionClientId(request);
        		String btnSubmit=request.getParameter("Submit");
	        	if(btnSubmit.equalsIgnoreCase("update")){
			            int isPrebidPublish=StringUtils.hasLength(request.getParameter("selisprebidpublishwithtender"))?Integer.parseInt(request.getParameter("selisprebidpublishwithtender")):0;
			            int istocPublishWithTender=StringUtils.hasLength(request.getParameter("selistocPublishWithTender"))?Integer.parseInt(request.getParameter("selistocPublishWithTender")):0;
			            int istecPublishWithTender=StringUtils.hasLength(request.getParameter("selistecPublishWithTender"))?Integer.parseInt(request.getParameter("selistecPublishWithTender")):0;
			            int isbiddingFormPublishWithTender=StringUtils.hasLength(request.getParameter("selisbiddingFormPublishWithTender"))?Integer.parseInt(request.getParameter("selisbiddingFormPublishWithTender")):0;
			            success=commonService.updateClientConfigDetails(clientId, isPrebidPublish, istocPublishWithTender, istecPublishWithTender, isbiddingFormPublishWithTender);
			            if(success){
			            	retVal="redirect:/common/admin/ruleengine/getoptionalrule"+encryptDecryptUtils.generateRedirect("common/admin/ruleengine/getoptionalrule", request);
			            	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),success ?  "redirect_success_Default_clientConfiguration" : CommonKeywords.ERROR_MSG.toString());
			            }
        		}
	        	else{
	        		retVal="redirect:/common/admin/ruleengine/"+clientId+encryptDecryptUtils.generateRedirect("common/admin/ruleengine/"+clientId, request);
	        	}
        	}
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } 
        return retVal;
    }
    
    /** Ajecx call for the search content
     * @author mitesh
     * @throws IOException 
     **/
    
    @RequestMapping(value = "/common/ruleengine/searchlink", method = RequestMethod.POST)
    @ResponseBody
    public String getSearchLinkdetails(ModelMap map, HttpServletResponse response, HttpServletRequest request,RedirectAttributes redirectAttributes) throws IOException {
        StringBuffer retVal=new StringBuffer("sessionexpired");
        List<Object[]> result=null;
        
        JSONArray array =null;
        try {
        	if(abcUtility.getSessionUserId(request)!=0){	
			            String keyword=request.getParameter("txtSearch").replace("@@@", "&");
			            
			            result=commonService.getFilterLinkedName(keyword);
			            if(result!=null && result.size()>0){
			            	retVal=new StringBuffer();
			            	/*for (Object[] objects : result) {
			            		retVal.append("<br><a href='javascript:void(0); onclick=loadtree("+objects[4]+");'>"+objects[0]+"_"+objects[1]+"_"+objects[2]+"_"+objects[3]+"</a>");
							}*/
			            	array = new JSONArray();
			            	for (Object[] objects : result) {
			            		 JSONObject jSONObject = new JSONObject();
			                     jSONObject.put(objects[4].toString(),objects[0]+"_"+objects[2]+"_"+objects[3]+"_"+objects[1]);
//			                     jSONObject.put("keyword",objects[0]+"_"+objects[1]+"_"+objects[2]+"_"+objects[3]);
			                     array.put(jSONObject);
							}
			            }
        	}
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } 
        return array!=null?array.toString():"";
    }
    
    /**
     * comboo tree load the json object from the database
     * @author mitesh
     * 
     */
    @RequestMapping(value = "/common/admin/ajaxgetconfiguredrulelinklist", method = RequestMethod.POST)
    @ResponseBody
    public String getConfiguredRuleLinkList(HttpServletResponse response, HttpSession httpSession, HttpServletRequest request) throws IOException {
    	List<Object> configRuleIdsList=null;
    	StringBuilder sb=new StringBuilder();
        try {
        	int clientId=abcUtility.getSessionClientId(request);
        	int linkId= StringUtils.hasLength(request.getParameter("txtlinkId"))?Integer.parseInt(request.getParameter("txtlinkId")):0;   
        	configRuleIdsList=commonService.getConfiguredLinkedIds(clientId, linkId);
        	for (Object object : configRuleIdsList) {
        		sb.append((Integer)object).append(",");
			}
        	if(configRuleIdsList.size()>0)
        		sb.deleteCharAt(sb.lastIndexOf(","));
		} catch (Exception e) {
			e.printStackTrace();
		}
        finally{
        	
        }
        return sb.toString();
    }
    
    
    /**
     * comboo tree load the json object from the database
     * @author mitesh
     * 
     */
    @RequestMapping(value = "/common/admin/ajaxgetrulelinklist", method = RequestMethod.POST)
    public void getRuleLinkList(HttpServletResponse response, HttpSession httpSession, HttpServletRequest request) throws IOException {
    	response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        String retVal="";
     
        try {
        	int clientId=abcUtility.getSessionClientId(request);
        	int linkId= StringUtils.hasLength(request.getParameter("txtlinkId"))?Integer.parseInt(request.getParameter("txtlinkId")):0;   
        	List<Object[]> commonDataList=commonService.getLinkedTree(clientId, linkId);
			List<RuleLinkDataBean> listOfParentRule=new ArrayList<RuleLinkDataBean>();
			List<RuleLinkDataBean> childList=new ArrayList<RuleLinkDataBean>();
			List<RuleLinkDataBean> commonList=new ArrayList<RuleLinkDataBean>();
			List<RuleLinkDataBean> ogList=new ArrayList<RuleLinkDataBean>();
        	RuleLinkDataBean commonBean=null;
        	//parent databean
        	for(Object[] parentObjects : commonDataList) {
        		if(parentObjects[4].equals(new Integer(0))){
	    			commonBean=new RuleLinkDataBean();
					commonBean.setRuleLinkId((Integer)parentObjects[3]);
					commonBean.setRuleName((String)parentObjects[1]);
					commonBean.setRuleId((Integer)parentObjects[0]);
					commonBean.setParentRuleId((Integer)parentObjects[4]);
					commonBean.setSortOrder((Integer)parentObjects[5]);
					commonBean.setClientRuleId((Integer)parentObjects[6]);
					listOfParentRule.add(commonBean);
        		}
			}
        	//common list
        	for(Object[] parentObjects : commonDataList) {
        		
	    			commonBean=new RuleLinkDataBean();
					commonBean.setRuleLinkId((Integer)parentObjects[3]);
					commonBean.setRuleName((String)parentObjects[1]);
					commonBean.setRuleId((Integer)parentObjects[0]);
					commonBean.setParentRuleId((Integer)parentObjects[4]);
					commonBean.setSortOrder((Integer)parentObjects[5]);
					commonBean.setClientRuleId((Integer)parentObjects[6]);
					commonList.add(commonBean);
        		
			}
        	StringBuilder sb=new StringBuilder("[{");
        	for (RuleLinkDataBean ruleLinkDataBean : listOfParentRule) {
        		ogList.add(createTree(ruleLinkDataBean, commonList, ruleLinkDataBean.getRuleId(),childList,sb));
        		//System.out.println(ogList);
			}
        	
        	  JSONArray jSONArray = new JSONArray();
              List<Integer> processed = new ArrayList<Integer>();
              for (RuleLinkDataBean ruleLinkDataBean : listOfParentRule) {
                  JSONObject jSONObject = new JSONObject();
                  jSONObject.put("id",ruleLinkDataBean.getRuleLinkId());
                  jSONObject.put("title",ruleLinkDataBean.getRuleName());
                  if(ruleLinkDataBean.getClientRuleId()!=null){
                	  jSONObject.put("select",true);
                  }
                 
                 
                  if(!ruleLinkDataBean.getRuleLinkDataBean().isEmpty())// && !processed.contains(ruleLinkDataBean.getRuleId()))
                  {    processed.add(ruleLinkDataBean.getRuleId());
                      jSONObject.put("state","closed");
                      jSONObject.put("children",getChildDetail(ruleLinkDataBean.getRuleLinkDataBean(),jSONArray,processed));
                      //getChildDetail(ruleLinkDataBean.getRuleLinkDataBean(),jSONArray,processed);
                  }
                  jSONArray.put(jSONObject);
              }
           // System.out.println(jSONArray.toString());
        	out.print(jSONArray.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
        finally{
        	out.close();
        }
    }
    
    public RuleLinkDataBean createTree(RuleLinkDataBean ruleLinkDataBean,List<RuleLinkDataBean> commonDataList,Integer parentRuleId,List<RuleLinkDataBean> childList,StringBuilder sb)
    {
    	RuleLinkDataBean childBean=new RuleLinkDataBean();
    	boolean flag=false;
    	childList=new ArrayList<RuleLinkDataBean>();
    	//sb.append("\"id\":"+ruleLinkDataBean.getRuleLinkId()+",\"text\":"+ruleLinkDataBean.getRuleName()+"\"");
    	for (RuleLinkDataBean singleObjects : commonDataList) {
    		flag=false;
			if(singleObjects.getParentRuleId().equals(parentRuleId)){//parent id
				childBean=new RuleLinkDataBean();
				childBean.setRuleLinkId(singleObjects.getRuleLinkId());
				childBean.setRuleName(singleObjects.getRuleName());
				childBean.setRuleId(singleObjects.getRuleId());
				childBean.setParentRuleId(singleObjects.getParentRuleId());
				childBean.setSortOrder(singleObjects.getSortOrder());
				childBean.setClientRuleId(singleObjects.getClientRuleId());
				childList.add(childBean);
				createTree(childBean,commonDataList,childBean.getRuleId(),childList,sb);
				flag=true;
				}
    		}
    	ruleLinkDataBean.setRuleLinkDataBean(childList);
    	
    	//System.out.println(sb.toString());
    	//return childList.size()!=0?ruleLinkDataBean:null;
    	return ruleLinkDataBean;
    	
	}
    private JSONArray getChildDetail(List<RuleLinkDataBean> ruleLinkDataBean,
            JSONArray jSONArray, List<Integer> processed) throws JSONException {
         
         JSONObject j = null;
         JSONArray child = new JSONArray();
         for(RuleLinkDataBean bean : ruleLinkDataBean){
            // if(!processed.contains(bean.getRuleId())){
                 j = new JSONObject();
                 j.put("id",bean.getRuleLinkId());
                 j.put("title",bean.getRuleName());
                 if(bean.getClientRuleId()!=null){
                	 j.put("select", true);
                 }
                 child.put(j);
                 if(!bean.getRuleLinkDataBean().isEmpty()){
                     j.put("state","closed");
                     if(bean.getClientRuleId()!=null){
                    	 j.put("select", true);
                     }
                     j.put("children",getChildDetail(bean.getRuleLinkDataBean(),child,processed));
                     
                 }
               
             //   processed.add(bean.getRuleId());
            //   }
         }
         return child;
    }

  /**
     * Use case: Rule Engine
     * @author nirav.modi
     * @param clientId
     * @param request
     * @param modelMap
     * @return
     */
    @RequestMapping(value="/common/admin/ruleengine/{clientId}/{enc}", method= RequestMethod.GET)
    public String getRuleEnginePage(@PathVariable("clientId") int clientId, HttpServletRequest request, ModelMap modelMap){
    	String retVal="/common/admin/RuleEngine";
    	try {
    		//modelMap.put("moduleList",abcUtility.convert(commonService.getAllModules())); not required
		} catch (Exception e) {
			retVal= exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),createRuleEngineLinkId,getRuleEngineRemark, 0, clientId);
		}
    	return retVal;
    }
    
    /**
     * Use Case: Rule engine
     * @author nirav.modi
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/common/admin/configurerules", method = RequestMethod.POST)
    public String configureRules(HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	String retVal="redirect:/sessionexpired";
    	int linkId=0;
    	int clientId=0;
    	boolean success=false;
    	try {
    		if(abcUtility.getSessionUserId(request)!=0){
    			clientId= abcUtility.getSessionClientId(request);
    			linkId= StringUtils.hasLength(request.getParameter("LinkedId"))?Integer.parseInt(request.getParameter("LinkedId")):0;
    			String ruleLinkIds=request.getParameter("txtSelctedRuleLinkIds");
    			String RuleLinkIds=request.getParameter("txtRuleLinkIds");
    			int userId = abcUtility.getSessionUserId(request); 
    			if(userId==Integer.parseInt(auctionAdminuserId))//update the RuleLink table if user is super admin user.
    			{
    				success=commonService.configureRulesLinks(linkId,RuleLinkIds);
    			}
    			String ruleLinkIdsArray[]=ruleLinkIds.split(",");
    			if(ruleLinkIdsArray!=null && ruleLinkIdsArray.length>0){
    				List<TblClientRule> tblClientRules = new ArrayList<TblClientRule>();
    				int sortOrder=1;
    				for(String ruleLinkId : ruleLinkIdsArray){
    					TblClientRule tblClientRule = new TblClientRule();
    					tblClientRule.setIsActive(1);
    					tblClientRule.setTblClient(new TblClient(clientId));
    					tblClientRule.setTblRuleLink(new TblRuleLink(Integer.parseInt(ruleLinkId)));
    					//tblClientRule.setCondition("");
    					tblClientRule.setSortOrder(sortOrder);
    					tblClientRules.add(tblClientRule);
    					sortOrder+=1;
    				}
    				success=commonService.configureRules(clientId, linkId, tblClientRules);
    			}
				retVal="common/admin/ruleengine/"+clientId;
				retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    		}
    	} catch (Exception ex) {
    		retVal= exceptionHandlerService.writeLog(ex);
    	} 
    	finally {
    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createRuleEngineLinkId , postRuleEngineRemark, linkId,clientId);
    	}
    	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_rule_configure" : CommonKeywords.ERROR_MSG_KEY.toString());
    	return retVal;
    }
   

	@RequestMapping(value = "/ajaxcall/checkloginid", method = RequestMethod.POST)
    @ResponseBody
    public String checkLoginId(@RequestParam("txtemailId") String emailId, @RequestParam("txtisFrmForgtPwd") String isFrmForgtPwd, HttpSession session, HttpServletRequest request) {
        String resultString = null;
        try {
            if (commonValidators.isValidEmailId(emailId)) {
                boolean result = true;
                if (isFrmForgtPwd != null && "Y".equalsIgnoreCase(isFrmForgtPwd)) {
                    String verifyeMail = WSCheckAvail.verifyMail(emailId,"");
                    if(!"Valid".equalsIgnoreCase(verifyeMail) && !"service is not working".equalsIgnoreCase(verifyeMail)){
                        result = false;
                    }
                }
                if(result){
                    result = commonService.checkUniqueLoginId(emailId);
                }
                if (isFrmForgtPwd != null && "Y".equalsIgnoreCase(isFrmForgtPwd)) {
                    resultString = !result ? VALID : "invalid";
                }else{
                    resultString = result ? VALID : "invalid";
                }
                if (isFrmForgtPwd != null && "Y".equalsIgnoreCase(isFrmForgtPwd) && !result) {
                     DataObject dataObject = WSCheckAvail.gethintQuestDetail(emailId);
                     if(dataObject!=null && dataObject.getData2()!=null){
                         resultString = dataObject.getData2().toString();
                     }else{
                         resultString = loginService.getHintQue(emailId);
                     }
                }
            } else {
                resultString = "InValidEmail";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxCheckLoginIdAuditMsg, 0, 0);
//        }
        return resultString;
    }
	
	@RequestMapping(value = "/ajaxcall/checkloginidconditional", method = RequestMethod.POST)
    @ResponseBody
    public String checkLoginIdConditional(@RequestParam("txtemailId") String emailId, @RequestParam("txtisFrmForgtPwd") String isFrmForgtPwd,@RequestParam("txtsessionloginUrl") String sessionLoginUrl,HttpSession session, HttpServletRequest request) {
        String resultString = null;
        try {
        	 int userType = commonService.getUserTypeId(commonService.getUserIdByLoginId(emailId));
            if (commonValidators.isValidEmailId(emailId) && ((sessionLoginUrl.equals("bidderlogin") && userType== 2) || (sessionLoginUrl.equals("buyerlogin") && userType != 2)))
            {
                boolean result = true;
                if (isFrmForgtPwd != null && "Y".equalsIgnoreCase(isFrmForgtPwd)) {
                    String verifyeMail = WSCheckAvail.verifyMail(emailId,"");
                    if(!"Valid".equalsIgnoreCase(verifyeMail) && !"service is not working".equalsIgnoreCase(verifyeMail)){
                        result = false;
                    }
                }
                if(result){
                    result = commonService.checkUniqueLoginId(emailId);
                }
                
                if (isFrmForgtPwd != null && "Y".equalsIgnoreCase(isFrmForgtPwd)) {
                    resultString = !result ? VALID : "invalid";
                }else{
                    resultString = result ? VALID : "invalid";
                }
                if (isFrmForgtPwd != null && "Y".equalsIgnoreCase(isFrmForgtPwd) && !result) {
                     DataObject dataObject = WSCheckAvail.gethintQuestDetail(emailId);
                     if(dataObject!=null && dataObject.getData2()!=null){
                         resultString = dataObject.getData2().toString();
                     }else{
                         resultString = loginService.getHintQue(emailId);
                     }
                }
                
                
            } else {
                resultString = "InValidEmail";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxCheckLoginIdAuditMsg, 0, 0);
//        }
        return resultString;
    }
	
	@RequestMapping(value = "/ajaxcall/getUserTypeId", method = RequestMethod.POST)
    @ResponseBody
    public String getUserTypeId(@RequestParam("txtemailId") String emailId, HttpSession session, HttpServletRequest request) {
        String userTypeId ="";
        try {
        	userTypeId = String.valueOf(commonService.getUserTypeId(commonService.getUserIdByLoginId(emailId)));
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return userTypeId;
    }
	
	@RequestMapping(value = "/ajaxcall/setIsCaptchValid", method = RequestMethod.POST)
    @ResponseBody
    public String setIsCaptchValid(@RequestParam("isCaptchaValid") String isCaptchValid,HttpSession session, HttpServletRequest request) {
        String resultString = "ok";
        request.getSession().setAttribute("isCaptchaValid", isCaptchValid);
        return resultString;
    }
    @RequestMapping(value = "/ajax/checkDomainName", method = RequestMethod.POST)
    @ResponseBody
    public String checkDomainName(@RequestParam("txtDomainName") String domainName,@RequestParam("hdclientId") String clientId, HttpSession session,HttpServletRequest request){
    	String resultString="sessionexpired";
    	try{
    		if(abcUtility.getSessionUserId(request)!=0){
    			boolean result=commonService.checkUniqueDomainName(domainName,Integer.parseInt(clientId));
    			resultString=result?VALID:"inValid";
    		}
    	} catch (Exception e) {
    		return exceptionHandlerService.writeLog(e);
    	} 
//    	finally{
//    		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxCheckDomainNameAuditMsg, 0,0);
//    	}
    	return resultString;
    }
    
    
    @RequestMapping(value = "/authbiddermail/{encEmail}/{encCode}", method = RequestMethod.GET)
    public String authBidderMail(@PathVariable("encEmail") String encEmail, @PathVariable("encCode") String encCode, HttpServletRequest request, HttpSession session, ModelMap map, RedirectAttributes redirectAttributes) {
        String retVal = null;
        try {
            String emailAndUserType = encryptDecryptUtils.decrypt(encEmail);
            String emailId = emailAndUserType.split("@@")[0];
            Integer userType = Integer.parseInt(emailAndUserType.split("@@")[1].split("_")[0]);
            String verificationCode = encryptDecryptUtils.decrypt(encCode);
            if (StringUtils.hasLength(emailId) && StringUtils.hasLength(verificationCode)) {
                boolean isSuccess = manageBidderService.updateEmailVerified(emailId, verificationCode);
                int regWorkFlowId = manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), 2);
                int companyId = Integer.valueOf((commonService.getCompanyIdByUserId(commonService.getUserIdByLoginId(emailId)).toString()));
                if(regWorkFlowId==7 && commonService.getCountryIdByCompanyId(companyId)!=countryId){// 105 - India
        			regWorkFlowId = 8;
        		}
                manageBidderService.updateRegistrationWorkflowInBidderStatus(abcUtility.getSessionClientId(request), commonService.getUserIdByLoginId(emailId), regWorkFlowId);
                if(manageBidderService.isClientRegWorkflowIdAllowedToPending(abcUtility.getSessionClientId(request)) && isSuccess){
                	manageBidderService.updateRegistrationWorkflowInBidderStatus(abcUtility.getSessionClientId(request), commonService.getUserIdByLoginId(emailId), 9);
                	manageBidderService.updateBidderFieldBidderStatus(abcUtility.getSessionClientId(request),commonService.getUserIdByLoginId(emailId),0 );
                }
                if(userType == 3) {
                	departmentUserService.updateCstatus(Integer.parseInt(emailAndUserType.split("@@")[1].split("_")[1]));
                }
                if (isSuccess) {
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_email_verify_Only");
                    retVal = "redirect:/setcookie";
                }
            } else {
                map.put("bidderVerificationBy", clientService.getBidderRegistrationVerifiedBy(abcUtility.getSessionClientId(request)));
                map.put(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                map.put(EMAILID, emailAndUserType);
                map.put("displayEmailId", emailAndUserType.split("@@")[0]);
                retVal = "AuthBidderMail";
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, map.containsKey("successMsg") ? bidderEmailVerificationSuccessAuditMsg : bidderEmailVerificationFailAuditMsg, 0, 0);
        }
        return retVal;
    }
    
    @RequestMapping(value = "/authbiddermail/{encemail}", method = RequestMethod.GET)
    public String authBidderMailAndMobile(@PathVariable("encemail") String encemail, HttpSession session, ModelMap map,HttpServletRequest request){
        String retVal=null;
        try{
        	String emailAndUserType = encryptDecryptUtils.decrypt(encemail);
        	map.put("bidderVerificationBy", clientService.getBidderRegistrationVerifiedBy(abcUtility.getSessionClientId(request)));
        	map.put(EMAILID, emailAndUserType);
        	map.put("displayEmailId", emailAndUserType.split("@@")[0].split("_")[0]);
        	retVal="AuthBidderMail";
        }
        catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, bidderEmailMobileVerificationAuditMsg, 0, 0);
        }
        return retVal;
    }
    
    @RequestMapping(value = "/addauthbiddermail", method = RequestMethod.POST)
    public String addAuthBidderMail(HttpServletRequest request, ModelMap map, RedirectAttributes redirectAttributes){
        String retVal=null;
        try{
        	String emailAndUserType = request.getParameter("hdEmailId");
        	
            String emailId = emailAndUserType.split("@@")[0].split("_")[0];
            boolean isUpdated = false;
            isUpdated = emailAndUserType.split("@@")[0].split("_").length > 1 && Integer.parseInt(emailAndUserType.split("@@")[0].split("_")[1]) == 1;
            Integer userType = Integer.parseInt(emailAndUserType.split("@@")[1].split("_")[0]);
        	String verificationCode = request.getParameter("txtCodeVerification");
        	if(StringUtils.hasLength(emailId) && StringUtils.hasLength(verificationCode)) {
        		boolean isSuccess = manageBidderService.updateEmailVerified(emailId, verificationCode);
        		int userId = commonService.getUserIdByLoginId(emailId);
        		int regWorkFlowId = manageBidderService.getClientRegWorkflowId(abcUtility.getSessionClientId(request), 3);
        		int companyId = Integer.valueOf((commonService.getCompanyIdByUserId(userId).toString()));
        		if(regWorkFlowId==7 && commonService.getCountryIdByCompanyId(companyId)!=countryId){
        			regWorkFlowId = 8;
        		}
        		if(!isUpdated){
        			manageBidderService.updateRegistrationWorkflowInBidderStatus(abcUtility.getSessionClientId(request),userId , regWorkFlowId);
        		}
        		if(userType == 3) {
                	departmentUserService.updateCstatus(Integer.parseInt(emailAndUserType.split("@@")[1].split("_")[1]));
                }
        		if(isSuccess) {
        			redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_email_mobile_verify");
        			if(regWorkFlowId==8){
        				SessionBean sessionBean = new SessionBean();
        				sessionBean.setUserId(userId);
        				request.getSession().setAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString(),sessionBean);
        			}
        			retVal=(regWorkFlowId==8) ? "redirect:/finishregistration" : "redirect:/";
        		}
        	} else {
        		map.put(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
        		retVal = "AuthBidderMail";
        	}
        }
        catch(Exception ex){
        	 return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postEmailMobileVerificationAuditMsg, 0, 0);
        }
        return retVal;
    }

    @RequestMapping(value = "/common/getParentDesignation", method = RequestMethod.POST)
    public void getParentDesignation(@RequestParam("txtDeptId") String txtDeptId,@RequestParam("hdFullTree") boolean hdFullTree, 
    HttpServletResponse response, HttpServletRequest request, HttpSession httpSession) throws IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        try {
            String deptTree = null;           
            SessionBean sessionBean= (SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
            List<Map<String, Object>> lst = commonService.getDesigTree(Integer.parseInt(txtDeptId), sessionBean.getUserTypeId(),sessionBean.getDeptId(),sessionBean.getDesignationId(),hdFullTree);
            StringBuilder jsonString = new StringBuilder();
            if (lst != null && !lst.isEmpty()) {
                Iterator<Map<String, Object>> itr = lst.iterator();
                jsonString.append("[{");
                int prevLevel = 0;
                int level = 0;
                int deptLevel = 0;
                int deptId = 0;
                boolean isFirstLevel = true;
                while (itr.hasNext()) {
                    deptLevel = 0;
                    deptId = 0;                    
                    Map<String, Object> map = (Map<String, Object>) itr.next();
                    deptId = Integer.parseInt(map.get("designationId").toString());
                    if(map.get("deptLevel")!=null){
                    	deptLevel = Integer.parseInt(map.get("deptLevel").toString());
                    }
                    String deptName = map.get("designationName").toString();
                    if(isFirstLevel)
                    {
                       prevLevel  = deptLevel;
                       level = deptLevel;
                    }
                    if (deptLevel == prevLevel) {
                        if (!isFirstLevel) {
                            jsonString.append("}, {");
                        } else {
                            isFirstLevel = false;
                        }
                        jsonString.append("\"id\":").append(deptId).append(",")
                                .append("\"text\":").append("\"").append(deptName).append("\"").append(",")
                                .append("\"state\":").append("\"").append("closed").append("\"").append(",")
                                .append("\"children\":[{");
                    } else if (deptLevel > prevLevel) {
                        jsonString.append("\"id\":").append(deptId).append(",")
                                .append("\"text\":").append("\"").append(deptName).append("\"").append(",")
                                .append("\"state\":").append("\"").append("closed").append("\"").append(",")
                                .append("\"children\":[{");
                    } else if (deptLevel < prevLevel) {
                        int diff = prevLevel - deptLevel;
                        for (int i = level; i < level + diff; i++) {
                            jsonString.append("}]");
                        }
                        jsonString.append("}, {\"id\":").append(deptId).append(",")
                                .append("\"text\":").append("\"").append(deptName).append("\"").append(",")
                                .append("\"state\":").append("\"").append("closed").append("\"").append(",")
                                .append("\"children\":[{");
                    }

                    prevLevel = deptLevel;
                }
                for (int i = level; i <= deptLevel; i++) {
                    jsonString.append("}]");
                }
                deptTree = jsonString.toString().replace(",\"state\":\"closed\",\"children\":[{}", "}");
            }else{
               deptTree= "\"[{\"id\":,\"text\":none,\"state\":none,\"children\":[{}]}]";
            }
            out.print(deptTree);
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } finally {
            out.close();
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), desigTreeLinkId, ajaxGetParentDesigTreeAuditMsg, 0, 0);
        }
    }
    /**
     * Change for PT:20745
     * @author bharat
     * @param response
     * @param httpSession
     * @param request
     * @throws IOException
     */

    @RequestMapping(value = {"/common/admin/ajaxgetcatlist","/ajaxcall/ajaxgetcatlist"}, method = RequestMethod.POST)
    public void getCategoryList(HttpServletResponse response, HttpSession httpSession, HttpServletRequest request) throws IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        try {
            //int clientId = 0;
            String catTree = null;
            /*if (httpSession.getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) {
                ClientBean clientBean = (ClientBean) httpSession.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
                clientId = clientBean.getClientId();
            }*/

            List<Map<String, Object>> lst = commonService.getCatTree(abcUtility.getSessionClientId(request));
            StringBuilder jsonString = new StringBuilder();
            if (lst != null && !lst.isEmpty()) {
                Iterator<Map<String, Object>> itr = lst.iterator();
                jsonString.append("[{");
                int prevLevel = 1;
                int currLevel = 1;
                boolean isFirstLevel = true;
                while (itr.hasNext()) {
                    int catLevel = 1;
                    int categoryId = 0;
                    String categoryName = null;

                    Map<String, Object> map = (Map<String, Object>) itr.next();
                    categoryId = Integer.parseInt(map.get("categoryId").toString());
                    catLevel = Integer.parseInt(map.get("catLevel") != null ? (String) map.get("catLevel").toString() : "1");
                    categoryName = abcUtility.reverseReplaceSpecialChars(map.get("categoryName").toString());
                    currLevel = catLevel;
                    if (currLevel == prevLevel) {
                        if (!isFirstLevel) {
                            jsonString.append("}, {");
                        } else {
                            isFirstLevel = false;
                        }
                        jsonString.append("\"id\":").append(categoryId).append(",")
                                .append("\"text\":").append("\"").append(categoryName).append("\"").append(",")
                                .append("\"state\":").append("\"").append("closed").append("\"").append(",")
                                .append("\"children\":[{");
                    } else if (currLevel > prevLevel) {
                        jsonString.append("\"id\":").append(categoryId).append(",")
                                .append("\"text\":").append("\"").append(categoryName).append("\"").append(",")
                                .append("\"state\":").append("\"").append("closed").append("\"").append(",")
                                .append("\"children\":[{");
                    } else if (currLevel < prevLevel) {
                        int diff = prevLevel - currLevel;
                        for (int i = 0; i < diff; i++) {
                            jsonString.append("}]");
                        }
                        jsonString.append("}, {\"id\":").append(categoryId).append(",")
                                .append("\"text\":").append("\"").append(categoryName).append("\"").append(",")
                                .append("\"state\":").append("\"").append("closed").append("\"").append(",")
                                .append("\"children\":[{");
                    }

                    prevLevel = currLevel;
                }
                for (int i = 0; i < currLevel; i++) {
                    jsonString.append("}]");
                }
                //System.out.println(jsonString.toString().replace(",\"state\":\"closed\",\"children\":[{}", "}"));
            }
            catTree = jsonString.length()==0 ? " " :  jsonString.toString().replace(",\"state\":\"closed\",\"children\":[{}", "}");            
            out.print(catTree);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            out.close();
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), categoryTreeLinkId, ajaxGetCategoryTreeAuditMsg, 0, 0);
        }
    }

    /**
     * Ajax function  to check unique category name
     * @param categoryName
     * @param clientId
     * @param categoryId
     * @param session
     * @param request
     * @return
     */
    @RequestMapping(value = "/ajax/checkcatname", method = RequestMethod.POST)
    @ResponseBody
    public String checkCategoryName(@RequestParam("txtcategoryName") String categoryName, @RequestParam("txtclientId") int clientId, @RequestParam("txtcategoryId") String categoryId, HttpSession session, HttpServletRequest request) {
        String resultString = "sessionexpired";
        try {
        	if(session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
        		boolean result = commonService.checkUniqueCategoryName(clientId, categoryName, categoryId != null && !"".equals(categoryId) ? Integer.parseInt(categoryId) : 0);
        		resultString = result ? "inValid" : VALID;
        	}
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxCheckCategoryNameAuditMsg, 0, clientId);
//        }
        return resultString;
    }

    /**
     * Ajax function to check unique product name
     * @param productName
     * @param categoryId
     * @param productId
     * @param session
     * @param request
     * @return
     */
    @RequestMapping(value = "/ajax/checkproductname", method = RequestMethod.POST)
    @ResponseBody
    public String checkProductName(@RequestParam("txtproductName") String productName, @RequestParam("txtcategoryId") int categoryId, @RequestParam("txtproductId") String productId, HttpSession session, HttpServletRequest request) {
        String resultString = "sessionexpired";
        try {
        	 if(session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	            boolean result = commonService.checkUniqueProductName(categoryId, productName, productId);
	            resultString = result ? "inValid" : VALID;
        	 }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxCheckProductNameAuditMsg, 0, categoryId);
//        }
        return resultString;
    }

    @RequestMapping(value = "/ajax/checkuniquedesignationname", method = RequestMethod.POST)
    @ResponseBody
    public String checkUniqueDesignationName(@RequestParam("txtdesignationName") String departmentName, @RequestParam("txtDeptId") int deptId,
           @RequestParam("txtparentDesigId") int parentDesigId, HttpServletRequest request) {
        boolean isExist = false;
        try {
            isExist = commonService.checkUniqueDesignationName(deptId, departmentName,parentDesigId);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxCheckUniqueDesigAuditMsg, 0, deptId);
//        }
        return isExist + "";
    }

    @RequestMapping(value = {"ajaxcall/checkvaliduserinclient","ajax/checkvaliduserinclient"}, method = RequestMethod.POST)
    @ResponseBody
    public String checkValidUserInClient(@RequestParam("txtEmailId") String emaild, @RequestParam("txtUserType") int userType, HttpSession session, HttpServletRequest request) {
        StringBuilder result = new StringBuilder();
        try {
        	ClientBean clientBean = (ClientBean) session.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	List<LinkedHashMap<String, Object>> list = commonService.checkValidUserInClient(clientBean.getClientId(), emaild, userType);
        	
        	if(list != null && !list.isEmpty()) {
        		Map<String, Object> map  = list.get(0);
        		int bidderId = Integer.parseInt(map.get("bidderId").toString());
        		int officerId = Integer.parseInt(map.get("officerId").toString());
        		int actionType = Integer.parseInt(map.get("actionType").toString());
        		result.append(actionType).append(",").append(bidderId).append(",").append(officerId);
        	}
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxCheckValidUserAuditMsg, 0, 0);
//        }
        return result.toString();
    }
    
    /**
     * @author SULABH
     * @param emailId
     * @param request
     * @return
     */
    @RequestMapping(value ="ajaxcall/checkvalidretiredofficer", method = RequestMethod.POST)
    @ResponseBody
    public String checkValidUserForRetiredOfficer(@RequestParam("txtEmailId") String emailId, HttpServletRequest request) {
    	String result = "";
        try {
        	if(commonService.isRetiredOfficerExist(emailId)==0){
        		result="0";
        	}else{
        		result="1";
        	}
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } 
        return result.toString();
    }
    
    /**
     * Ajax call to get server datetime
     *
     * @param request
     * @param response
     * @return String
     */
    @RequestMapping(value = "/ajaxcall/getserverdatetime", method = RequestMethod.POST)
    @ResponseBody
    public String showDateTime(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
        String result = "";
        try {
        	//ClientBean clientBean = (ClientBean) session.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            //DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.MEDIUM);
        	//System.out.println(CommonUtility.convertTimezone(commonService.getServerDateTime()));
            //result = dateUtils.convertStringtoDate(CommonUtility.convertTimezone(commonService.getServerDateTime()),CommonUtility.getClientDateFormat()+" HH:mm:ss").toString();
        	Date d=dateUtils.convertStringtoDate(CommonUtility.convertTimezone(commonService.getServerDateTime()), CommonUtility.getClientDateFormat()+" HH:mm:ss");
        	result = dateUtils.convertStringtoDate(d,"MMMMM dd, yyyy hh:mm:ss a");
        } catch (Exception ex) {
            // new AbcException(ex, exceptionHandlerService);
            exceptionHandlerService.writeLog(ex);
        }
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxGetServerDateTimeAuditMsg, 0, 0);
//        }
        return result;
    }
    
    
    @RequestMapping(value="/common/help/{helpLinkId}/{languageId}/{enc}")
    public String getHelpPage(@PathVariable("helpLinkId") int helpLinkId, @PathVariable("languageId") int languageId, HttpServletRequest request, ModelMap modelMap){
    	try {
			modelMap.put("helpContent", commonService.getHelpContent(helpLinkId, languageId));
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, auditOnlineHelp, 0, 0);
		}
    	return "/common/OnlineHelp";
    }
    
    /**
     * ajax call for get officer from department
     *
     * @param deptId
     * @return String
     */
    @RequestMapping(value = "/etender/buyer/ajax/getdesignationofficer", method = RequestMethod.POST)
    @ResponseBody
    public String getDepartmentOfficer(@RequestParam("txtDesignationId") String designationId,@RequestParam("txtCertIdRequired") boolean certIdRequired,@RequestParam("txtTenderOpeningDateTime") String tenderOpeningDateTime,@RequestParam("searchType") String searchType,@RequestParam("estiMatedValue") String estiMatedValue, HttpServletRequest request) {
        String retVal = null;
        List<SelectItem> items = new ArrayList<SelectItem>();
        try {
            if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
                ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
                List<Object[]> list = commonService.getOfficerByDesignationId(Integer.parseInt(designationId), abcUtility.getSessionClientId(request),clientBean.getIsDualCerti(),certIdRequired,tenderOpeningDateTime,searchType,estiMatedValue);                
                if (list != null) {
                    String certEndDate = "";
                    for (Object[] objects : list) {
                        if (objects.length >= 2) {
                            if(objects[4]!=null){
                                certEndDate = objects[4].toString();
                            }
                            if(certIdRequired){
                                boolean isCertiRevoked = false;
                                if(objects[3]!=null && Integer.parseInt(objects[3].toString())!=0){
                                    if("true".equalsIgnoreCase(objects[6].toString())){
                                        if("true".equalsIgnoreCase(objects[5].toString())){
                                            isCertiRevoked = commonService.checkCertificateRevoked(objects[8].toString(),objects[10].toString());
                                        }
                                    }
                                }
                                if(objects[0]!=null && objects[1]!=null && objects[2]!=null && objects[3]!=null && objects[5]!=null && objects[6]!=null && objects[7]!=null && certEndDate!=null && objects[9]!=null){
                                    items.add(new SelectItem(objects[1], encryptDecryptUtils.encrypt(objects[0].toString())+"@@"+encryptDecryptUtils.encrypt(objects[2].toString())+"@@"+objects[2].toString()+"@@"+objects[3].toString()+"@@"+certEndDate+"@@"+objects[5].toString()+"@@"+objects[6].toString()+"@@"+CommonUtility.convertTimezone(objects[7].toString())+"@@"+CommonUtility.convertTimezone(certEndDate)+"@@"+isCertiRevoked+"@@"+objects[9].toString()));
                                }
                            }else{
                                if(objects[0]!=null && objects[1]!=null && objects[2]!=null && objects[3]!=null && objects[5]!=null && objects[6]!=null && objects[9]!=null){
                                    items.add(new SelectItem(objects[1], encryptDecryptUtils.encrypt(objects[0].toString())+"@@"+encryptDecryptUtils.encrypt(objects[2].toString())+"@@"+objects[2].toString()+"@@"+objects[3].toString()+"@@"+certEndDate+"@@"+objects[5].toString()+"@@"+objects[6].toString()+"@@"+objects[9].toString()));
                                }
                            }
                        }                        
                    }
                }
                retVal = encryptDecryptUtils.getOptions("selDesignationOfficial", items, true, "", messageSource.getMessage("auc_please_selectmsg", null, LocaleContextHolder.getLocale()));
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            // auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auctioncreationlink, !"".equalsIgnoreCase(retVal) ? postgetofficer : postgetofficerfail, 0, 0);
        }
        return retVal;
    }
    /**
     * ajax call for get department
     * @param objectId
     * @return String
     */
    @RequestMapping(value = "/common/admin/ajaxgetdeptcombo", method = RequestMethod.POST)
    @ResponseBody
    public String getDepartmentOfficerCombo(@RequestParam("objectId") int objectId,@RequestParam("searchType") String searchType,@RequestParam("estiMatedValue") String estiMatedValue,HttpServletRequest request) {
        String retVal = null;
        List<SelectItem> items = new ArrayList<SelectItem>();
        try {
            if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
                int clientId = abcUtility.getSessionClientId(request);
                int deptLevel = commonService.getLevelOfTenderer(objectId,clientId);
                if(deptLevel>=0){
                    List<Object[]> list  = commonService.getDeptOnHierarchyBase(clientId,deptLevel,1,searchType,estiMatedValue);
                    if(list!=null && !list.isEmpty()){
                        for (Object[] objects : list) {
                            items.add(new SelectItem(objects[1], objects[0]));
                        }
                    }
                    retVal = encryptDecryptUtils.getOptions("selHierarchybaseDept", items, true, "", messageSource.getMessage("auc_please_selectmsg", null, LocaleContextHolder.getLocale()));
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            // auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auctioncreationlink, !"".equalsIgnoreCase(retVal) ? postgetofficer : postgetofficerfail, 0, 0);
        }
        return retVal;
    }
    
    /**
	 * To check the status code of wsdl url.
	 * @param urlString
	 * @return
	 * @throws MalformedURLException
	 * @throws IOException
	 */
	private int getRespCodeHTTP(String urlString) throws MalformedURLException, IOException {
        int code = 0;
        try {
            URL url = new URL(urlString);
            HttpURLConnection huc = (HttpURLConnection) url.openConnection();
            huc.setRequestMethod("GET");
            huc.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 6.0; en-US; rv:1.9.1.2) Gecko/20090729 Firefox/3.5.2 (.NET CLR 3.5.30729)");
            huc.connect();
            code = huc.getResponseCode();
        } catch (SocketException e) {
            code = 500;
        }
        return code;
    }
	
	/**
	 * To get the suggestions from the web service for available keywords.
	 * @param text
	 * @param request
	 * @return
	 * UiIssue:17870 call direct db instead of use webservice, configuration depends on properties. @author bharat 
	 */
	@RequestMapping(value={"/ajaxcall/getkeywordsuggestion","/commonWebservice/keywords"}, method=RequestMethod.POST, produces="application/json")
	public @ResponseBody String getKeywordsSuggestion(@RequestParam("text") String text, HttpServletRequest request){
		StringBuilder jsonString = new StringBuilder();
		List<String> keywords = new ArrayList<String>();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			if (keyword_db_connection_allow != null && keyword_db_connection_allow.equalsIgnoreCase("true")) {
				try{
					getSQLConnection();
					pst = CommonController.connection.prepareStatement("select top 100 keyword from dbo.cpvKeywords where keyword like ?");
					pst.setString(1,"%"+text+"%");
					rs = pst.executeQuery();
					while (rs.next()) {
						keywords.add(rs.getString("keyword"));
					}
				}catch(Exception e)
				{
					exceptionHandlerService.writeLog(e);
					getSQLConnection();
				}finally{
					try{
					if(pst != null && !pst.isClosed())
					{
						pst.close();
					}
					if(rs != null && !rs.isClosed()){
						rs.close();	
					}	
					}catch(Exception e)
					{
						exceptionHandlerService.writeLog(e);
					}
				}
			} else {
				ArrayOfString arrayOfString;

				String keywordWSURL = keyword_ws_url_islive ? keyword_ws_url_live
						: keyword_ws_url_inhouse;

				int flag = getRespCodeHTTP(keywordWSURL);
				if (flag == 200 && StringUtils.hasLength(text)
						&& text.length() >= 3) {
					Service service = new Service();
					ServiceSoap serviceSoap = service.getServiceSoap();
					arrayOfString = serviceSoap.getKeywords(text,
							"65788354442663937");
					keywords = arrayOfString.getString();
				}
			}

			if (keywords != null && !keywords.isEmpty()) {
				jsonString.append("[");
				for (String string : keywords) {
					jsonString.append("{\"keyword\":\"").append(string)
							.append("\"},");
				}
				jsonString.deleteCharAt(jsonString.length() - 1)
						.append("]");
			}
		} catch (Exception ex) {
			exceptionHandlerService.writeLog(ex);
		}
//		finally {
//			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, auditKeywordSuggestion, 0, 0);
//		}
		return jsonString.toString();
	}
	@RequestMapping(value="/ajaxcall/chechKeywordExists",method=RequestMethod.POST, produces="application/json")
	public @ResponseBody String checkIsKeywordsExists(@RequestParam("text") String keyWords) throws Exception, IOException{
		String jsonString = null;
		String keywordWSURL = keyword_ws_url_islive ? keyword_ws_url_live
				: keyword_ws_url_inhouse;

		int flag = getRespCodeHTTP(keywordWSURL);
		if (flag == 200 && StringUtils.hasLength(keyWords)) {
			Service service = new Service();
			ServiceSoap serviceSoap = service.getServiceSoap();
			//jsonString = serviceSoap.keywordexists(keyWords);
		}
		return jsonString;
	}

	private void getSQLConnection() {
		
		try {
			if (CommonController.connection == null || CommonController.connection.isClosed()) {
				Class.forName(keyword_db_driver_name);
				CommonController.connection = DriverManager.getConnection(keyword_db_connection_url, keyword_db_username,HtmlUtils.htmlUnescape(keyword_db_password));
			}
		} catch (SQLException e) {
			  exceptionHandlerService.writeLog(e);
		} catch (ClassNotFoundException e) {
			exceptionHandlerService.writeLog(e);
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		
	}

	/**
	 * To get event type list : used on CreateClient.jsp Page 
	 * @author nirav.modi
	 * @param txtModuleId
	 * @param txtClientId
	 * @param txtIsEditMode
	 * @param response
	 * @param request
	 */
	@ResponseBody
	@RequestMapping(value = "/common/geteventtypelist", method = RequestMethod.POST)
    public String getEventTypeList(@RequestParam("txtModuleId") int moduleId,@RequestParam("txtClientId")int clientId,@RequestParam("txtIsEditMode")boolean isEditMode, ModelMap modelMap, HttpServletResponse response, HttpServletRequest request) {
        StringBuilder data = new StringBuilder("sessionexpired");
        try {
    		if(abcUtility.getSessionUserId(request)!=0){
    			data.setLength(0);
	        	List<Object[]> eventTypes=null;
	            List<Object[]> eventTypeList = commonService.getEventTypeModuleId(moduleId);
	            if(isEditMode){
	        		eventTypes = clientService.getEventTypeId(clientId);
	        	}
	            if(eventTypeList!=null && !eventTypeList.isEmpty()){
	            	String event= messageSource.getMessage("field_eventtype", null, LocaleContextHolder.getLocale())+" "+eventTypeList.get(0)[2];
	            	if(moduleId==5){
	            		event="Auction variant";
	            	}	            	
	            	data.append("<td "+(eventTypeList.get(0)[3].equals(0) ? " style='display:none;' " : "")+" class='clsModule_").append(moduleId).append("' id='tdModule_").append(moduleId).append("' >");
	            	data.append("<label>").append(event).append("<span class='red'> *</span></label><div class='multiselect prefix1_1'>");
	            	for(Object[] object: eventTypeList){
	                	data.append("<script type='text/javascript'>var comp=$('#echkEventTypeList").append(moduleId).append("'); createMandatoryCheckBoxArray(comp);</script>");
	                	data.append("<label><input isrequired='true' id='echkEventTypeList").append(moduleId).append("' type='checkbox' value='").append(object[0]).append("' name='echkEventTypeList").append(moduleId).append("' "+(eventTypeList.get(0)[3].equals(0) ? " checked='' " : "")+" title='").append(messageSource.getMessage("field_eventtype", null, LocaleContextHolder.getLocale())).append(" ").append(object[2]).append("'");
	                	if(isEditMode && eventTypes != null && !eventTypes.isEmpty()){
	                		for(Object obj[] : eventTypes){
	                			if(object[0].toString().equals((obj)[0].toString())){
	                				data.append("checked='checked'");
	                			}
	                		}
	                	}
	                	data.append("/>");
	                	data.append(object[1]);
	                	data.append("  </label>");
	            }
            	data.append("</div><div id=\"errDiv").append("echkEventTypeList").append(moduleId).append("\"></div>");
            	data.append("</td>");
	            }
    		}
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } 
        finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getEventTypeList, 0, moduleId);
        }
        return data.toString();
    }

    @RequestMapping(value="/ajax/getdeptdetailsbyemailidoruserName",method= RequestMethod.POST)
    @ResponseBody
    public String getDeptDetailsByEmailIdOrUserName(@RequestParam("txtemailId") String emailIdorPersonName,@RequestParam("txtsearchby") String searchby,@RequestParam("txtcertIdRequired") boolean certIdRequired,@RequestParam("txttenderOpeningDateTime") String tenderOpeningDateTime,@RequestParam("searchType") String searchType,@RequestParam("estiMatedValue") String estiMatedValue,@RequestParam("objectId") int objectId,@RequestParam("deptId") int deptId, HttpServletRequest request) {
        StringBuilder strDept = new StringBuilder();
        List<Object[]> deptDetailsList = new ArrayList<Object[]>();
        try {
            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            if("emailId".equalsIgnoreCase(searchby)){
                if("hierarchyBaseSearch".equalsIgnoreCase(searchType)){ //hierarchy Base Search
                    int deptLevel = commonService.getLevelOfTenderer(objectId,abcUtility.getSessionClientId(request));
                    if(deptLevel>=0){
                        deptDetailsList = commonService.getDeptDetailsByEmailIdOnHierarchyBase(emailIdorPersonName, abcUtility.getSessionClientId(request),clientBean.getIsDualCerti(),certIdRequired,tenderOpeningDateTime,deptLevel,searchType,estiMatedValue);
                    }
                }else if("financiallimitBaseSearch".equalsIgnoreCase(searchType)){ //financial limit Base Search 
                    deptDetailsList = commonService.getDeptDetailsByEmailId(emailIdorPersonName, abcUtility.getSessionClientId(request),clientBean.getIsDualCerti(),certIdRequired,tenderOpeningDateTime,searchType,estiMatedValue,deptId);
                }else if("financiallimitandhierarchyBaseSearch".equalsIgnoreCase(searchType)){ //financial limit and hierarchy Base Search
                    int deptLevel = commonService.getLevelOfTenderer(objectId,abcUtility.getSessionClientId(request));
                    if(deptLevel>=0){
                        deptDetailsList = commonService.getDeptDetailsByEmailIdOnHierarchyBase(emailIdorPersonName, abcUtility.getSessionClientId(request),clientBean.getIsDualCerti(),certIdRequired,tenderOpeningDateTime,deptLevel,searchType,estiMatedValue);
                    }
                }else{  //normal base search
                    deptDetailsList = commonService.getDeptDetailsByEmailId(emailIdorPersonName, abcUtility.getSessionClientId(request),clientBean.getIsDualCerti(),certIdRequired,tenderOpeningDateTime,searchType,estiMatedValue,deptId);
                }
                if(deptDetailsList!=null && !deptDetailsList.isEmpty() && deptDetailsList.get(0)[6]!=null && !"".equalsIgnoreCase(deptDetailsList.get(0)[6].toString())){
                    for (Object[] object : deptDetailsList) {
                        strDept.append("<table id='emailidsearch' width='100%'>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxdeptName").append("\" name=\"").append("deptName").append("\" value=\"").append(object[0].toString()).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxdesignation").append("\" name=\"").append("designation").append("\" value=\"").append(object[1].toString()).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxusername").append("\" name=\"").append("username").append("\" value=\"").append(object[2].toString()).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxdeptid").append("\" name=\"").append("deptid").append("\" value=\"").append(object[3].toString()).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxdesignationid").append("\" name=\"").append("designationid").append("\" value=\"").append(object[4].toString()).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxseluserid").append("\" name=\"").append("hduserid").append("\" value=\"").append(encryptDecryptUtils.encrypt(object[5].toString())).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxuserdetailid").append("\" name=\"").append("hduserdetailid").append("\" value=\"").append(encryptDecryptUtils.encrypt(object[6].toString())).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxuniqueId").append("\" name=\"").append("uniqueId").append("\" value=\"").append(object[6].toString()).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxcertId").append("\" name=\"").append("certId").append("\" value=\"").append(object[7].toString()).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxcertEndDate").append("\" name=\"").append("certEndDate").append("\" value=\"").append(object[8]!=null ? object[8].toString() : "").append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxIsCertExpired").append("\" name=\"").append("IsCertExpired").append("\" value=\"").append(object[9].toString()).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxIsRealCertExpired").append("\" name=\"").append("IsRealCertExpired").append("\" value=\"").append(object[10].toString()).append("\"/>");
                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxIsLoginId").append("\" name=\"").append("ajaxIsLoginId").append("\" value=\"").append(object[13].toString()).append("\"/>");
                        if(certIdRequired){
                            strDept.append("<input type=\"hidden\" id=\"").append("ajaxcertEndDateTimeZone").append("\" name=\"").append("certEndDateTimeZone").append("\" value=\"").append(object[8]!=null?CommonUtility.convertTimezone(object[8].toString()):0).append("\"/>");
                            strDept.append("<input type=\"hidden\" id=\"").append("ajaxutcDateTimeZone").append("\" name=\"").append("utcDateTimeZone").append("\" value=\"").append(CommonUtility.convertTimezone(object[11].toString())).append("\"/>");
                            if(object[7]!=null && Integer.parseInt(object[7].toString())!=0){
                                if("true".equalsIgnoreCase(object[10].toString())){
                                    if("true".equalsIgnoreCase(object[9].toString())){
                                        strDept.append("<input type=\"hidden\" id=\"").append("ajaxisCertiRevoked").append("\" name=\"").append("isCertiRevoked").append("\" value=\"").append(object[12]!=null?commonService.checkCertificateRevoked(object[12].toString(),object[14].toString()):0).append("\"/>");
                                    }
                                }
                            }
                        }
                        //strDept.append("<tr id=\"secondtr\"><td>&nbsp;</td><td>&nbsp;</td></tr>");
                        strDept.append("<tr id=\"secondtr\"><td class='no-padding' width='27%'>User : </td><td>").append(object[2].toString()).append("</td></tr>");                    
                        //strDept.append("<tr><td>&nbsp;</td><td>&nbsp;</td></tr>");
                        strDept.append("<tr><td class='no-padding' width='27%'>Designation : </td><td>").append(object[1].toString()).append("</td></tr>");
                        //strDept.append("<tr><td>&nbsp;</td><td>&nbsp;</td></tr>");
                        strDept.append("<tr><td class='no-padding' width='27%'>Department : </td><td>").append(object[0].toString()).append("</td></tr></table>");
                    }
                }else{
                    //strDept.append("<table><tr><td>&nbsp;</td></tr>");
                    strDept.append("<table><tr class=\"err\"><td width='51%'>&nbsp;</td><td><font color='red'>No record found</font></td></tr></table>");
                }
            }else{
            	emailIdorPersonName = emailIdorPersonName.replace("$$", "'");
                if("hierarchyBaseSearch".equalsIgnoreCase(searchType)){ //hierarchy Base Search
                    int deptLevel = commonService.getLevelOfTenderer(objectId,abcUtility.getSessionClientId(request));
                    if(deptLevel>=0){
                        deptDetailsList = commonService.getDeptDetailsByUserNameOnHierarchyBase(emailIdorPersonName, abcUtility.getSessionClientId(request),clientBean.getIsDualCerti(),certIdRequired,tenderOpeningDateTime,deptLevel,searchType,estiMatedValue);
                    }
                }else if("financiallimitBaseSearch".equalsIgnoreCase(searchType)){ //financial limit Base Search 
                    deptDetailsList = commonService.getDeptDetailsByUserName(emailIdorPersonName, abcUtility.getSessionClientId(request),clientBean.getIsDualCerti(),certIdRequired,tenderOpeningDateTime,searchType,estiMatedValue,deptId);  
                }else if("financiallimitandhierarchyBaseSearch".equalsIgnoreCase(searchType)){ //financial limit and hierarchy Base Search
                    int deptLevel = commonService.getLevelOfTenderer(objectId,abcUtility.getSessionClientId(request));
                    if(deptLevel>=0){
                        deptDetailsList = commonService.getDeptDetailsByUserNameOnHierarchyBase(emailIdorPersonName, abcUtility.getSessionClientId(request),clientBean.getIsDualCerti(),certIdRequired,tenderOpeningDateTime,deptLevel,searchType,estiMatedValue);
                    }
                }else{  //normal base search
                	emailIdorPersonName = emailIdorPersonName.replace("'","&#39;").replace("-","&#45;");
                    deptDetailsList = commonService.getDeptDetailsByUserName(emailIdorPersonName, abcUtility.getSessionClientId(request),clientBean.getIsDualCerti(),certIdRequired,tenderOpeningDateTime,searchType,estiMatedValue,deptId);  
                }
                if(deptDetailsList!=null && !deptDetailsList.isEmpty()){
                    
                        strDept.append("<table width='100%'>");
                        //strDept.append("<tr id=\"secondtr\"><td>&nbsp;</td><td>&nbsp;</td></tr>");
                        strDept.append("<tr id=\\\"secondtr\\\"><td width='27%' class='no-padding'>Select user</td><td>");
                        strDept.append("<select id='sameusercombo' width='27%' style='margin-left:0px; width:295px;'>");
                        strDept.append("<option value='0'>--please select--</option>");
                        boolean bool = false;
                        for (Object[] object : deptDetailsList) {
                            bool = false;
                            String certEndDate ="";
                            if(object[8]!=null){
                                certEndDate = object[8].toString();
                            }
                            if(certIdRequired){
                                boolean isCertiRevoked = false;
                                if(object[7]!=null && Integer.parseInt(object[7].toString())!=0){
                                    if("true".equalsIgnoreCase(object[10].toString())){
                                        if("true".equalsIgnoreCase(object[9].toString())){
                                            isCertiRevoked = commonService.checkCertificateRevoked(object[12].toString(),object[14].toString());
                                        }
                                    }
                                }
                                if(object[0]!=null && object[1]!=null && object[2]!=null && object[3]!=null && object[4]!=null && object[5]!=null && object[6]!=null && object[7]!=null && object[9]!=null && object[10]!=null && object[11]!=null && certEndDate!=null && object[13]!=null){
                                    bool = true;
                                    strDept.append("<option value=\"").append(object[2].toString()+"@@"+object[0].toString()+"@@"+object[1].toString()+"@@"+object[3].toString()+"@@"+object[4].toString()+"@@"+encryptDecryptUtils.encrypt(object[5].toString())+"@@"+encryptDecryptUtils.encrypt(object[6].toString())+"@@"+object[6].toString()+"@@"+object[7].toString()+"@@"+certEndDate+"@@"+object[9].toString()+"@@"+object[10].toString()+"@@"+CommonUtility.convertTimezone(object[11].toString())+"@@"+(!certEndDate.isEmpty() ? CommonUtility.convertTimezone(certEndDate) : "")+"@@"+isCertiRevoked+"@@"+object[13].toString()).append("\">");
                                }
                            }else{ 
                                    if(object[0]!=null && object[1]!=null && object[2]!=null && object[3]!=null && object[4]!=null && object[5]!=null && object[6]!=null && object[7]!=null && object[9]!=null && object[10]!=null && object[13]!=null){
                                        bool = true;
                                        strDept.append("<option value=\"").append(object[2].toString()+"@@"+object[0].toString()+"@@"+object[1].toString()+"@@"+object[3].toString()+"@@"+object[4].toString()+"@@"+encryptDecryptUtils.encrypt(object[5].toString())+"@@"+encryptDecryptUtils.encrypt(object[6].toString())+"@@"+object[6].toString()+"@@"+object[7].toString()+"@@"+certEndDate+"@@"+object[9].toString()+"@@"+object[10].toString()+"@@"+object[13].toString()).append("\">");
                                    }
                            }
                            if(object[0]!=null && object[1]!=null && object[2]!=null && bool){
                                strDept.append(object[2].toString()+"-"+object[0].toString()+"-"+object[1].toString());
                                strDept.append("</option>");    
                            } 
                        }
                        strDept.append("</select></td></tr></table>");                    
                }else{
                    //strDept.append("<table><tr><td>&nbsp;</td></tr>");
                    strDept.append("<table><tr class=\"err\"><td width='51%'>&nbsp;</td><td><font color='red'>No record found</font></td></tr></table>");
                }
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getEventTypeList, 0, moduleId);
        }
        return strDept.toString();
    }
    /** get Process Reassignment page
     * @author dixit
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/processreassignment/{processId}/{objectId}/{linkId}/{eventTypeId}/{tabId}/{flag}/{enc}", method = RequestMethod.GET)
    public String processReassignment(@PathVariable("processId") int processId,@PathVariable("objectId") int objectId,@PathVariable("linkId") int linkId,@PathVariable("eventTypeId") int eventTypeId,@PathVariable("tabId") int tabId,@PathVariable("flag") boolean flag,ModelMap modelMap, HttpServletRequest request) {
        int moduleId = 0;
        try {
            moduleId = commonService.getModuleIdbyEventTypeId(eventTypeId);
            int clientId = abcUtility.getSessionClientId(request);            
            modelMap.addAttribute("processId",processId);
            modelMap.addAttribute("objectId",objectId);
            modelMap.addAttribute("linkId",linkId);
            modelMap.addAttribute("moduleId",moduleId);
            modelMap.addAttribute("tabId",tabId);
            modelMap.addAttribute("titleFlag",flag);            
            modelMap.addAttribute("eventTypeId",eventTypeId);            
            if(flag){modelMap.addAttribute("showheader",true);}
            List<Object[]> list = commonService.getReassignmentProcessHistory(objectId,processId);
            if(list!=null && !list.isEmpty()){
                modelMap.addAttribute("ReassignmentProcessHistory",list);
            }
            switch(processId){
                case 1:
                        commonService.commontenderSummary(objectId, modelMap, clientId);
                        modelMap.addAttribute("assignUserId", commonService.getField("TblTender", "assignUserId", "tenderId", objectId));
                        modelMap.addAttribute("tenderId", objectId);
                        break;
                case 5:
                        commonService.getIndentSummary(objectId,modelMap);
                        modelMap.addAttribute("assignUserId", commonService.getField("TblIndent", "assignUserId", "indentId", objectId));
                        break;    
                default:
                        break;    
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
			String message = "";
        	if(flag){
        		message = getDelegatePageFromNoticeTab;
        	}else{
        		message = getDelegateHistoryPageFromNoticeTab;
        	}
           if(moduleId==3){
        	   auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, message, objectId,objectId,"");
           }
           else
           {
        	   auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, message, objectId,objectId,"");
           }
        	/* switch(moduleId){
                case 3:
                        auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getProcessAssignment, objectId,objectId,"");
                        break;
                default:
                        auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getProcessAssignment, objectId,objectId,"");
            }*/
        }
        return "common/ProcessReassignment";
    }
    /** submit Process Reassignment page
     * @author dixit
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/submitprocessreassignment", method = RequestMethod.POST)
    public String submitProcessReassignment(HttpServletRequest request,RedirectAttributes redirectAttributes) {
        String returnStr = "";
        String hdlinkId = "";
        String hdobjectId = "";
        String hdmoduleId = "";
        try {
            int userId = abcUtility.getSessionUserId(request);
            int sessonUserDetailId = abcUtility.getSessionUserDetailId(request);
            if(userId!=0 && sessonUserDetailId!=0){
                boolean flag = false;
                String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
                String txtaComments = StringUtils.hasLength(request.getParameter("txtaComments")) ? request.getParameter("txtaComments") : "";
                String compoSearchUserid = StringUtils.hasLength(request.getParameter("hduserId")) ? request.getParameter("hduserId") : "0";
                String compoSearchUserDetailId = StringUtils.hasLength(request.getParameter("hduserDetailId")) ? request.getParameter("hduserDetailId") : "0";
                String hdprocessId = StringUtils.hasLength(request.getParameter("hdprocessId")) ? request.getParameter("hdprocessId") : "0";
                hdobjectId = StringUtils.hasLength(request.getParameter("hdobjectId")) ? request.getParameter("hdobjectId") : "0";
                hdlinkId = StringUtils.hasLength(request.getParameter("hdlinkId")) ? request.getParameter("hdlinkId") : "0";
                hdmoduleId = StringUtils.hasLength(request.getParameter("hdmoduleId")) ? request.getParameter("hdmoduleId") : "0";
                String hdtabId = StringUtils.hasLength(request.getParameter("hdtabId")) ? request.getParameter("hdtabId") : "";
                String hdtenderNo = StringUtils.hasLength(request.getParameter("hdtenderNo")) ? request.getParameter("hdtenderNo") : "";
                int hdassignUserId = StringUtils.hasLength(request.getParameter("hdassignUserId")) ? Integer.parseInt(request.getParameter("hdassignUserId")) : 0;
                int hdeventTypeId = StringUtils.hasLength(request.getParameter("hdeventTypeId")) ? Integer.parseInt(request.getParameter("hdeventTypeId")) : 0;
                
                TblEventReassignment tblEventReassignment = new TblEventReassignment();
                tblEventReassignment.setProcessId(Integer.parseInt(hdprocessId));
                tblEventReassignment.setObjectId(Integer.parseInt(hdobjectId));
                tblEventReassignment.setFromUserDetailId(sessonUserDetailId);
                tblEventReassignment.setToUserDetailId(Integer.parseInt(compoSearchUserDetailId));
                tblEventReassignment.setRemark(txtaComments);
                tblEventReassignment.setIpAddress(ipAddress);
                tblEventReassignment.setCreatedBy(sessonUserDetailId);
                if(commonService.addTblEventReassignment(tblEventReassignment,compoSearchUserid,hdassignUserId)){
                    switch(Integer.parseInt(hdprocessId)){
                        case 1:
                                String eventBrief = StringUtils.hasText(request.getParameter("hiddenEventBrief")) ? request.getParameter("hiddenEventBrief") : "";
                                Map<String, Object> paramMap =  new HashMap<String, Object>();
                                paramMap.put("EventId", hdobjectId);
                                paramMap.put("ReferenceNo", hdtenderNo);
                                paramMap.put("EventBrief",eventBrief);
                                paramMap.put("EventType",commonService.getEventNameFromEventId(hdeventTypeId).get(0).toString());
                                paramMap.put("SubDomainName",clientService.getClientNameById(abcUtility.getSessionClientId(request)));
                                mailContentUtillity.dynamicMailGeneration("52", String.valueOf(compoSearchUserid), String.valueOf(sessonUserDetailId),paramMap,hdlinkId);
                                mailContentUtillity.dynamicMailGeneration("51", String.valueOf(userId), String.valueOf(compoSearchUserDetailId),paramMap,hdlinkId);
                                returnStr = "redirect:/etender/buyer/tenderdashboard/"+hdobjectId+"/"+hdtabId+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+hdobjectId+"/"+hdtabId, request);
                                break;
                        case 5:
                                returnStr = "redirect:/eindent/buyer/indentdashboard/"+hdobjectId+encryptDecryptUtils.generateRedirect("eindent/buyer/indentdashboard/"+hdobjectId, request);
                                break;
                        default:
                                break;    
                    }
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"msg_assignment_process");
                }else{
                    switch(Integer.parseInt(hdprocessId)){
                        case 1:
                                returnStr = "redirect:/processreassignment/"+hdprocessId+"/"+hdobjectId+"/"+hdlinkId+"/"+hdeventTypeId+"/"+hdtabId+"/true"+encryptDecryptUtils.generateRedirect("processreassignment/"+hdprocessId+"/"+hdobjectId+"/"+hdlinkId+"/"+hdeventTypeId+"/"+hdtabId+"/true", request);
                                break;
                        case 5:
                                returnStr = "redirect:/processreassignment/"+hdprocessId+"/"+hdobjectId+"/"+hdlinkId+"/"+hdeventTypeId+"/"+hdtabId+"/true"+encryptDecryptUtils.generateRedirect("processreassignment/"+hdprocessId+"/"+hdobjectId+"/"+hdlinkId+"/"+hdeventTypeId+"/"+hdtabId+"/true", request);
                                break;
                        default:
                                break;    
                    }
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
            }
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            if(Integer.parseInt(hdmoduleId) == 3)
        	{
        		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),Integer.parseInt(hdlinkId), postDelegateProcessAssignment, Integer.parseInt(hdobjectId),Integer.parseInt(hdobjectId), "");
        	}
        	else
        	{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),Integer.parseInt(hdlinkId), postDelegateProcessAssignment, Integer.parseInt(hdobjectId),Integer.parseInt(hdobjectId), "");
        	}
            /*switch(Integer.parseInt(hdmoduleId)){
                case 3:
                        auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),Integer.parseInt(hdlinkId), postDelegateProcessAssignment, Integer.parseInt(hdobjectId),Integer.parseInt(hdobjectId), "");
                        break;
                default:
                        auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),Integer.parseInt(hdlinkId), postDelegateProcessAssignment, Integer.parseInt(hdobjectId),Integer.parseInt(hdobjectId), "");
                        break;    
            }*/
        }
        return returnStr;
    }

    /**
     *
     * @param jreVersion
     * @param response
     * @param request
     */
    @RequestMapping(value = "/downloadjre/{jreversion}", method = RequestMethod.GET)
    public void downloadJre(@PathVariable("jreversion") int jreVersion, HttpServletResponse response, HttpServletRequest request) {
        InputStream fis = null;
        ServletOutputStream outputStream = null;
        try {
            String documentPath = "";
            String jrepath = "\\zip\\" + (jreVersion == 1 ? "jre.exe" : "jre-x64.exe");
            String resHeader = (jreVersion == 1 ? "attachment;filename=\"jre.exe\"" : "attachment;filename=\"jre-x64.exe\"");
//            documentPath = CommonController.class.getResource("/").toString().replace("WEB-INF/classes", jrepath).replace("file:/", "");
            documentPath = request.getServletContext().getRealPath("/resources")+jrepath;
            
            File file = new File(documentPath);
            fis = new FileInputStream(file);
            byte[] buf = new byte[fis.available()];
            int offset = 0;
            int numRead = 0;
            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                offset += numRead;
            }
            fis.close();

            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", resHeader);

            outputStream = response.getOutputStream();
            outputStream.write(buf);
            outputStream.flush();
            outputStream.close();
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
    }
    
    /**
     * to get column types to configure indent boq columns
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value="/common/getClientColumnTypes/{enc}", method = RequestMethod.GET)
    public String getClientColumnTypes(HttpServletRequest request, ModelMap modelMap){
    	String retVal = "/common/admin/MapClientBoqColumn";
    	int clientId = 0;
        try {
        	clientId = abcUtility.getSessionClientId(request);
            modelMap.put("lstColumnType", commonService.getColumnTypesForIndent(clientId));
            long totalBoqColumn = commonService.checkClientBoqColumnTypesExist(clientId);
            modelMap.put("lstBoqColumn", commonService.getClientBoqColumnList(clientId,totalBoqColumn));
            modelMap.put("clientId",clientId);
        } catch (Exception e) {
             retVal = exceptionHandlerService.writeLog(e);
        } finally {
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getClientBoqColumn, clientId, 0);
        }
    	return retVal;
    }
    
    /**
     * 
     * @param request
     * @param map
     * @param redirectAttributes
     * @return 
     * Data type of column value. 0 for Not Set, 1 for Small Text, 2 for Long Text, 3 for Numeric, 4 for Money, 5 for Money All, 6 for Combo Box, 7 for Date
     */
    @RequestMapping(value = "/common/addClientBoqColumn", method = RequestMethod.POST)
    public String addClientBoqColumn(HttpServletRequest request, ModelMap map, RedirectAttributes redirectAttributes) {
        String retVal = null;
        int clientId = 0;
        try {
            int columnTypeId = StringUtils.hasLength(request.getParameter("selColType")) ? Integer.parseInt(request.getParameter("selColType")) : 0;
            clientId = StringUtils.hasLength(request.getParameter("hdClientId"))?Integer.parseInt(request.getParameter("hdClientId")):0;
            long totalBoqColumn = commonService.checkClientBoqColumnTypesExist(clientId);
            int i = (int)totalBoqColumn + 1;
            int dataType = 3;
            int userDetailId = abcUtility.getSessionUserDetailId(request);
            TblClientBoqColumn tblClientBoqColumn1 = new TblClientBoqColumn();
            tblClientBoqColumn1.setColumnHeader(request.getParameter("txtColHeader"));
            tblClientBoqColumn1.setIsActive(1);
            tblClientBoqColumn1.setIsMandatory(StringUtils.hasLength(request.getParameter("chkMandatory"))?Integer.parseInt(request.getParameter("chkMandatory")):0);
            tblClientBoqColumn1.setTblClient(new TblClient(clientId));
            tblClientBoqColumn1.setTblColumnType(new TblColumnType(columnTypeId));
            tblClientBoqColumn1.setCreatedBy(userDetailId);
            tblClientBoqColumn1.setDataType(dataType);
            if(totalBoqColumn < 4){
                int hdColumnTypeId = 0;
                TblClientBoqColumn tblClientBoqColumn = null;
                List<TblClientBoqColumn> list = new ArrayList<TblClientBoqColumn>();
                for(i=1; i<=4; i++){
                    hdColumnTypeId = StringUtils.hasLength(request.getParameter("hdColType"+i)) ? Integer.parseInt(request.getParameter("hdColType"+i)) : 0;
                    tblClientBoqColumn = new TblClientBoqColumn();
                    tblClientBoqColumn.setColumnHeader(StringUtils.hasLength(request.getParameter("hdColHeader"+i))?request.getParameter("hdColHeader"+i):"");
                    tblClientBoqColumn.setIsActive(1);
                    tblClientBoqColumn.setIsMandatory(1);
                    tblClientBoqColumn.setTblClient(new TblClient(clientId));
                    tblClientBoqColumn.setTblColumnType(new TblColumnType(hdColumnTypeId));
                    tblClientBoqColumn.setColumnNo(i);
                    if(hdColumnTypeId == 1 || hdColumnTypeId == 12  || hdColumnTypeId == 14){
                        dataType = 1;
                    }else{
                        dataType = 3;
                    }
                    tblClientBoqColumn.setDataType(dataType);
                    tblClientBoqColumn.setCreatedBy(userDetailId);
                    list.add(tblClientBoqColumn);
                }
                tblClientBoqColumn1.setColumnNo(i);
                list.add(tblClientBoqColumn1);
                commonService.addAllClientBoqColumn(list);
            }else{
                tblClientBoqColumn1.setColumnNo(i);
                commonService.addClientBoqColumn(tblClientBoqColumn1);   
            }
            redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_post_boqcolumn");
            retVal = "redirect:/common/admin/createcategory" + encryptDecryptUtils.generateRedirect("common/admin/createcategory", request);
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
            retVal = exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postSaveClinetBoqColumn, clientId, 0);
        }
        return retVal;
    }
    
    /**
     * 
     * @param request
     * @param redirectAttributes
     * @return 
     */
    @RequestMapping(value = "/common/deleteClientBoqColumn", method = RequestMethod.POST)
    public String deleteClientBoqColumn(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String retVal = null;
        int clientId = 0;
        try {
            clientId = StringUtils.hasLength(request.getParameter("hdClientId"))?Integer.parseInt(request.getParameter("hdClientId")):0;
            String [] columnIds;
            String delColumnIds = "-1";
            if(StringUtils.hasLength(request.getParameter("chkSelect"))){
                columnIds = request.getParameterValues("chkSelect");
                for (int i = 0; i < columnIds.length; i++) {
                    delColumnIds += ","+ columnIds[i];
                }
            }
            boolean isSuccess = commonService.deleteClientBoqColumn(delColumnIds);
            redirectAttributes.addFlashAttribute(isSuccess? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_delete_boqcolumn" : CommonKeywords.ERROR_MSG_KEY.toString());  
            retVal = "redirect:/common/getClientColumnTypes" + encryptDecryptUtils.generateRedirect("common/getClientColumnTypes", request);
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
            retVal = exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postDeleteCientBoqColumn, clientId, 0);
        }
        return retVal;
    }
    /**
     * Method to view display create committee
     * @Author Shreyansh shah
     * @param tenderId
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/common/createdyncommittee/{commiitteetypeid}/{eventId}/{tabId}/{enc}", method = RequestMethod.GET)
    public String createcommiittee(@PathVariable("commiitteetypeid") int commiitteetypeid,@PathVariable("eventId") int eventId,@PathVariable("tabId") int tabId, ModelMap modelMap, HttpServletRequest request) {
    String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    int linkId = 0;
	int committeeId = 0;
        String auditTrialMessage = "";             
        try {
            if(commiitteetypeid==1){
            	commonService.commontenderSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
                //commonService.commonauctionSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
            }else if(commiitteetypeid==2){
                commonService.commontenderSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
            }
            List<Object[]> list = commonService.getAllDynCommitteeMemberDetails(abcUtility.getSessionClientId(request), commiitteetypeid, eventId);
	    //if(list!=null && !list.isEmpty()){                
                modelMap.addAttribute("committeeName", (list!=null && !list.isEmpty() && list.get(0)[9]!=null)?list.get(0)[9].toString():"dix");                
                modelMap.addAttribute("isStandard", (list!=null && !list.isEmpty() && list.get(0)[8]!=null && Integer.parseInt(list.get(0)[8].toString())!=0)?list.get(0)[8].toString():"0");                
                modelMap.addAttribute("minApprovalReq", (list!=null && !list.isEmpty() && list.get(0)[10]!=null && Integer.parseInt(list.get(0)[10].toString())!=0)?Integer.parseInt(list.get(0)[10].toString()):0);
                modelMap.addAttribute("isApproved", (list!=null && !list.isEmpty() && list.get(0)[12]!=null && Integer.parseInt(list.get(0)[12].toString())!=0)?Integer.parseInt(list.get(0)[12].toString()):0);
            //}
            modelMap.addAttribute("committeeDetails", (list!=null && !list.isEmpty())?list:null);
	    modelMap.addAttribute("commiitteetypeid", commiitteetypeid);	    
	    modelMap.addAttribute("eventId", eventId);
	    modelMap.addAttribute("tabId", tabId);
	    modelMap.addAttribute("negotiationminimummemberreqired", negotiationminimummemberreqired);
            committeeId = (list!=null && !list.isEmpty())?Integer.parseInt(list.get(0)[7].toString()):0;
            modelMap.addAttribute("committeeId", committeeId);
            if(commiitteetypeid==1){
                auditTrialMessage = (list!=null && !list.isEmpty())?negoeditcommittee:negocreatecommittee;
                linkId = (list!=null && !list.isEmpty())?aucnegotiationeditcommitteelinkId:aucnegotiationcreatecommitteelinkId;
            }else if(commiitteetypeid==2){
                auditTrialMessage = (list!=null && !list.isEmpty())?negoeditcommittee:negocreatecommittee;
                linkId = (list!=null && !list.isEmpty())?tendernegotiationeditcommitteelinkId:tendernegotiationcreatecommitteelinkId;
            }
	} catch (Exception ex) {
	    return exceptionHandlerService.writeLog(ex);
	} finally {
		if(commiitteetypeid==1){
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, ipAddress,committeeId, eventId);
		}else{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, committeeId, eventId);
		}
	}
	return "/common/negotiation/buyer/DynamicCommiittee";
    }    
    @RequestMapping(value = "/ajaxcall/validatecommitteeName", method = RequestMethod.POST)
    @ResponseBody
    public String validateCommitteeName(@RequestParam("txtCommitteName") String txtCommitteName,@RequestParam("hdcommitteeId") int committeeId,@RequestParam("flag") boolean flag,HttpServletRequest request) {
        String result = null;
        try {
        if (commonService.getCommitteeDetailByName(txtCommitteName,committeeId,flag)){
                result = "valid";
            } else {
                result = "invalid";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return result;
    }
    /**
     * create commiittee page
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/common/submitdyncomittee", method = RequestMethod.POST)    
    public String submitcomittee(ModelMap modelMap,HttpServletRequest request, RedirectAttributes redirectAttributes) {                
        HttpSession session = request.getSession();
    String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();    
	String retVal = REDIRECT_SESSION_EXPIRED;
	boolean isSuccess = false;
	SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;
	int eventId = 0;
	int hdtabId = 0;
	int committeeId = 0;
	int isApproved=0;
	int dumpAsTec = 0;
	boolean isEdit = false;
	int commiitteetypeid = 0;
        String auditTrialMessage = "";  
	TblCommitteeDetail tblCommitteeDetail = null;
	String redirectMsg = "redirect_success_common_comittee";
	int linkId = 0;
        int clientId = 0;
	try {
            List<TblCommitteeUserDetail> tblCommitteeUserDetaillist = new ArrayList<TblCommitteeUserDetail>();
	    int userId = abcUtility.getSessionUserId(request);
            clientId = abcUtility.getSessionClientId(request);
	    if (userId != 0) {
		String committeeName = StringUtils.hasLength(request.getParameter("txtCommitteeName")) ? request.getParameter("txtCommitteeName") : "";
		String hdcommitteeName = StringUtils.hasLength(request.getParameter("hdcommitteeName")) ? request.getParameter("hdcommitteeName") : "";
		int minmemreqforcommittee = StringUtils.hasLength(request.getParameter("txtMinimumMemberRequired")) ? Integer.parseInt(request.getParameter("txtMinimumMemberRequired")) : 0;
		int hdminApprovalReq = StringUtils.hasLength(request.getParameter("hdminApprovalReq")) ? Integer.parseInt(request.getParameter("hdminApprovalReq")) : 0;
		int chkIsStandard = StringUtils.hasLength(request.getParameter("chkIsStandard")) ? Integer.parseInt(request.getParameter("chkIsStandard")) : 0;
		commiitteetypeid = StringUtils.hasLength(request.getParameter("hdcommiitteetypeid")) ? Integer.parseInt(request.getParameter("hdcommiitteetypeid")) : 0;		
		eventId = StringUtils.hasLength(request.getParameter("hdeventId")) ? Integer.parseInt(request.getParameter("hdeventId")) : 0;		
		hdtabId = StringUtils.hasLength(request.getParameter("hdtabId")) ? Integer.parseInt(request.getParameter("hdtabId")) : 0;		
		committeeId = StringUtils.hasLength(request.getParameter("hdCommitteeId")) ? Integer.parseInt(request.getParameter("hdCommitteeId")) : 0;

    	int isNegotiationAllowed = negotiationService.getisNegotiationAllowedOfficcerSide(3,eventId);
    	boolean consentGiven = false;
    	boolean approvedInWorkflow = false;
  		if(Integer.valueOf(isNegotiationAllowed) == 1 || Integer.valueOf(isNegotiationAllowed) == 2){	
  		   Object[] committeDetail = negotiationService.getCommitteeIdMinApprovalReq(eventId,2);
  		   if(committeDetail!=null){
  		   long count =  negotiationService.countApprovedOn(Integer.valueOf(committeDetail[0].toString()));
  		   if(Integer.parseInt(committeDetail[1].toString())==count){
  			 redirectMsg = "redirect_error_editnegotiation_committee";
  			 consentGiven = true;
  		    }
  		   }
  		}
  		if((Integer.valueOf(isNegotiationAllowed) == 1 || Integer.valueOf(isNegotiationAllowed) == 2) && !consentGiven && commiitteetypeid==2){
  			boolean isCommitteeApproved = negotiationService.isCommitteeApproved(committeeId);
  			if(isCommitteeApproved){
  				int workflowActionid=commonService.checkEntryTblWorkflow(committeeId,eventId);
  				if(workflowActionid==3 || workflowActionid==5){
  					approvedInWorkflow = true;
  					redirectMsg = "msg_workflow_complete";
  				}
  			}
  		}
		if(!consentGiven && !approvedInWorkflow){
		if(commiitteetypeid==2){
			isApproved=StringUtils.hasLength(request.getParameter("hdisApproved")) ? Integer.parseInt(request.getParameter("hdisApproved")) : 0;
			isEdit = committeeId != 0;
			if(isApproved==1 && committeeId != 0){
				commonService.reEditedCommittee(committeeId);
				redirectMsg = "redirect_success_editcommon_comittee";
				isEdit=false; 
			}
			
		}else{
			isEdit = committeeId != 0;
		}
		if (!isEdit) {
		    tblCommitteeDetail = new TblCommitteeDetail();
		    tblCommitteeDetail.setCommitteeName(committeeName);
		    tblCommitteeDetail.setCommitteeType(commiitteetypeid);
                    tblCommitteeDetail.setTblClient(new TblClient(clientId));
		    tblCommitteeDetail.setObjectId(eventId);
		    tblCommitteeDetail.setIsStandard(chkIsStandard);
                    tblCommitteeDetail.setMinApprovalReq(minmemreqforcommittee);
		    tblCommitteeDetail.setRemarks("");		    		    
                    tblCommitteeDetail.setCreatedBy(sessionBean.getUserDetailId());
		    tblCommitteeDetail.setIsActive(1);
		    tblCommitteeDetail.setIsApproved(0);
		}
		int count = 0;
		String userIds[];
		String userDetailIds[];
		String ConsentGivenorNots[];
		userIds = request.getParameterValues("hduserId");
		userDetailIds = request.getParameterValues("hduserDetailId");
		ConsentGivenorNots = request.getParameterValues("hdConsentGivenorNot");
		if (userIds != null && userDetailIds != null) {
		    for (count = 0; count < userDetailIds.length; count++) {
			TblCommitteeUserDetail tblCommitteeUserDetail = new TblCommitteeUserDetail();
			tblCommitteeUserDetail.setTblCommitteeDetail(isEdit ? new TblCommitteeDetail(committeeId) : tblCommitteeDetail);
			tblCommitteeUserDetail.setTblUserLogin(new TblUserLogin(Integer.parseInt(userIds[count])));
			tblCommitteeUserDetail.setTblUserDetail(new TblUserDetail(Integer.parseInt(userDetailIds[count])));
			tblCommitteeUserDetail.setRemarks("");
			tblCommitteeUserDetail.setCreatedBy(sessionBean.getUserDetailId());
			tblCommitteeUserDetail.setIsApproved(0);
                        if(isEdit){
                            if(ConsentGivenorNots!=null && ConsentGivenorNots.length>count){                                
                                if("0".equalsIgnoreCase(ConsentGivenorNots[count].toString())){
                                    tblCommitteeUserDetaillist.add(tblCommitteeUserDetail);
                                }
                            }else{
                                tblCommitteeUserDetaillist.add(tblCommitteeUserDetail);
                            }
                        }else{
                            tblCommitteeUserDetaillist.add(tblCommitteeUserDetail);
                        }
		    } 
		}
		if (isEdit) {    
                    boolean bool = false;
                    if(!committeeName.equalsIgnoreCase(hdcommitteeName) || minmemreqforcommittee!=hdminApprovalReq){
                        bool = true;
                    }
		    isSuccess = commonService.updateRemoveDynCommitteeMembers(committeeId,tblCommitteeUserDetaillist,committeeName,minmemreqforcommittee,bool);
		    redirectMsg = "redirect_success_editcommon_comittee";
		} else {
                    List<Object[]> list = commonService.getAllDynCommitteeMemberDetails(abcUtility.getSessionClientId(request), commiitteetypeid, eventId);
                    if(list==null || list.isEmpty()){
                        isSuccess = commonService.addDynCommitteDetails(tblCommitteeDetail, tblCommitteeUserDetaillist);
                        committeeId = tblCommitteeDetail.getCommitteeId();
                    }
		}
		
		//Copy TOC as TEC - @Auther Abhi
//		if(request.getParameter("chkSameAsTec") != null){
//			dumpAsTec = StringUtils.hasLength(request.getParameter("chkSameAsTec")) ? Integer.parseInt(request.getParameter("chkSameAsTec")) : 0;
//			if(dumpAsTec == 1){
//				spDumpEvaluationCommittee.executeProcedure(clientId, 0, committeeId, eventId);
//			}
//		}
		//Abhi
		
	   }
		if (isSuccess) {
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),redirectMsg);                    
		}else{
			if(consentGiven){
  			 redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),redirectMsg); 
			}else if(approvedInWorkflow){
				redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),redirectMsg); 
			}else{
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
             }  
			}            
                StringBuilder strQuery = new StringBuilder();
                if(commiitteetypeid==1){
//                  strQuery.append("redirect:/eauction/auctioneer/auctiondashboard/").append(eventId).append("/").append(hdtabId).append(encryptDecryptUtils.generateRedirect(strQuery.substring(strQuery.indexOf("/")+1), request));
                	strQuery.append("redirect:/etender/buyer/tenderdashboard/").append(eventId).append("/").append(hdtabId).append(encryptDecryptUtils.generateRedirect(strQuery.substring(strQuery.indexOf("/")+1), request));
                    retVal = strQuery.toString();
                    auditTrialMessage = isEdit?negocommitteeupdated:negocommitteecreated;
                    linkId = isEdit?aucnegotiationeditcommitteelinkId:aucnegotiationcreatecommitteelinkId;
                }else if(commiitteetypeid==2){
                    strQuery.append("redirect:/etender/buyer/tenderdashboard/").append(eventId).append("/").append(hdtabId).append(encryptDecryptUtils.generateRedirect(strQuery.substring(strQuery.indexOf("/")+1), request));
                    retVal = strQuery.toString();
                    auditTrialMessage = isEdit?negocommitteeupdated:negocommitteecreated;
                    linkId = isEdit?tendernegotiationeditcommitteelinkId:tendernegotiationcreatecommitteelinkId;
                }
	    }
	} catch (Exception ex) {
	    retVal = exceptionHandlerService.writeLog(ex);
	}
        finally{
        	if(commiitteetypeid==1){
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, ipAddress,committeeId, eventId);
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, committeeId, eventId);
        	}
        }
        return retVal;
    }
    
    /**
     * Method to view committee details
     *
     * @Author 
     * @param tenderId
     * @param comitteeId
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/common/viewdyncommitee/{commiitteetypeid}/{eventId}/{operType}/{isWorkFlow}/{tabId}/{enc}", method = RequestMethod.GET)
    public String viewDynCommitteeDetails(@PathVariable("commiitteetypeid") int commiitteetypeid, @PathVariable("eventId") int eventId,@PathVariable("operType") int operType,@PathVariable("isWorkFlow") int isWorkFlow,@PathVariable("tabId") int tabId, ModelMap modelMap, HttpServletRequest request) {
    	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();	
        int linkId = 0;
	int committeeId = 0;
        String auditTrialMessage = "";             
	try {
//	    if(commiitteetypeid==1){
//                commonService.commonauctionSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
//            }else if(commiitteetypeid==2){
//                commonService.commontenderSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
//            }
	    commonService.commontenderSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
	    
            List<Object[]> list = commonService.getAllDynCommitteeMemberDetails(abcUtility.getSessionClientId(request), commiitteetypeid, eventId);
	    if(list!=null && !list.isEmpty()){                
                modelMap.addAttribute("committeeDetails", list);                
                modelMap.addAttribute("committeeName", list.get(0)[9]!=null?list.get(0)[9].toString():"");                
                modelMap.addAttribute("isStandard", (list.get(0)[8]!=null && Integer.parseInt(list.get(0)[8].toString())!=0)?list.get(0)[8].toString():"0");                
                modelMap.addAttribute("minApprovalReq", (list.get(0)[10]!=null && Integer.parseInt(list.get(0)[10].toString())!=0)?Integer.parseInt(list.get(0)[10].toString()):0);                
            }
	    modelMap.addAttribute("commiitteetypeid", commiitteetypeid);	    
	    modelMap.addAttribute("eventId", eventId);	    
	    modelMap.addAttribute("tabId", tabId);	    
	    modelMap.addAttribute("operType", operType);	 // 1 - for publish, 0 - for view   
	    modelMap.addAttribute("isWorkFlow", isWorkFlow);	                
            committeeId = (list!=null && !list.isEmpty())?Integer.parseInt(list.get(0)[7].toString()):0;
            modelMap.addAttribute("committeeId", committeeId);
            if(commiitteetypeid==1){
                auditTrialMessage = (operType==1)?negopublishcommittee:negoviewcommittee;
                linkId = (operType==1)?aucnegotiationpublishcommitteelinkId:aucnegotiationviewcommitteelinkId;
            }else if(commiitteetypeid==2){
                auditTrialMessage = (operType==1)?negopublishcommittee:negoviewcommittee;
                linkId = (operType==1)?tendernegotiationpublishcommitteelinkId:tendernegotiationviewcommitteelinkId;
            }
            if(isWorkFlow == -1){
            	modelMap.addAttribute("isWorkFlow", 0);
            	modelMap.addAttribute("viewpopup", 1);
            }
	} catch (Exception ex) {
	    return exceptionHandlerService.writeLog(ex);
	} finally {
		if(commiitteetypeid==1){
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, ipAddress,committeeId, eventId);
		}else{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, committeeId, eventId);
		}
	}
	return "/common/negotiation/buyer/ViewDynamicCommiittee";
    }
    /**
     * Method to post approve committee details
     *
     * @Author Shreyansh shah
     * @param committeeId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/publishdyncommitee", method = RequestMethod.POST)
    public String publishDyncommitee(HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes) {
    	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    	int linkId = 0;	
        String auditTrialMessage = "";             
        boolean isSuccess = false;
	int eventId = 0;
	int hdcommiitteetypeid = 0;
	int hdcommitteeId = 0;
	int hdtabId = 0;
	String retVal = REDIRECT_SESSION_EXPIRED;
	SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;
	try {
            int userId = abcUtility.getSessionUserId(request);
	    if (userId != 0) {
                int clientId = abcUtility.getSessionClientId(request);
		eventId = StringUtils.hasLength(request.getParameter("hdeventId")) ? Integer.parseInt(request.getParameter("hdeventId")) : 0;
		hdcommitteeId = StringUtils.hasLength(request.getParameter("hdcommitteeId")) ? Integer.parseInt(request.getParameter("hdcommitteeId")) : 0;
		hdcommiitteetypeid = StringUtils.hasLength(request.getParameter("hdcommiitteetypeid")) ? Integer.parseInt(request.getParameter("hdcommiitteetypeid")) : 0;
                hdtabId = StringUtils.hasLength(request.getParameter("hdtabId")) ? Integer.parseInt(request.getParameter("hdtabId")) : 0;		
		String remarks = request.getParameter("txtaRemarks");
		isSuccess = commonService.publishDyncommitee(remarks, sessionBean.getUserDetailId(), hdcommitteeId);
		if (isSuccess) {
			
			
			
			//add data in DynReportCell 
			commonService.insertDetailsOfTblDynReportCell(eventId);
                    Map<String, Object> mailParams = new HashMap<String, Object>();
                    
                    if(hdcommiitteetypeid==1 || hdcommiitteetypeid==2){
                        String ccEmailIds = "";
                        List<Object[]> committeeMemberLoginIds = negotiationService.getCommitteeMemberLoginId(clientId,hdcommiitteetypeid, eventId); //1 for Auction Negotiation Committe, 
                        if (committeeMemberLoginIds != null && !committeeMemberLoginIds.isEmpty()) {
                            for (Object[] data : committeeMemberLoginIds) {
                                ccEmailIds = ccEmailIds + "," + data[0];
                            }
                        }
                    
                        mailParams.put("to", ccEmailIds.substring(1, ccEmailIds.length()));                        
                        mailParams.put("eventId", eventId);
                        List<Object[]> list = clientService.getClientNameAndCountry(clientId);
                        if(list!=null && !list.isEmpty()){
                            mailParams.put("clientName", list.get(0)[2]!=null?list.get(0)[2]:0);
                            mailParams.put("countryName", list.get(0)[3]!=null?list.get(0)[3]:0);
                            mailParams.put("domainName", list.get(0)[1]!=null?list.get(0)[1]:0);
                        }                        
                        if(hdcommiitteetypeid==1){
                            mailParams.put("briefScopeOfWork", commonService.getField("TblAuction", "auctionBrief", "auctionId", eventId));
                            
                            String strEventType = Integer.parseInt(commonService.getField("TblAuction", "eventTypeId", "auctionId", eventId)) == 1 ? "Forward" : "Reverse";
          				  	strEventType += " "+commonService.getEventType(Integer.parseInt(commonService.getField("TblAuction", "typeOfAuction", "auctionId", eventId))).get(0);
                            mailParams.put("eventType", strEventType);
                        }else if(hdcommiitteetypeid==2){
                            mailParams.put("briefScopeOfWork", commonService.getField("TblTender", "tenderBrief", "tenderId", eventId));
                            mailParams.put("eventType", commonService.getEventType(Integer.parseInt(commonService.getField("TblTender", "tblEventType.eventTypeId", "tenderId", eventId))).get(0));
                        }
                        MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
                        messageConfigDatabean.setTemplateId(hdcommiitteetypeid==1 ? aucNegotiationPublishCommitteeTempleteId : tenNegotiationPublishCommitteeTempleteId);
                        messageConfigDatabean.setQueueName(queueName);
                        messageConfigDatabean.setUserId(userId);
                        messageConfigDatabean.setClientId(clientId);
                        messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
                        messageConfigDatabean.setContextPath(request.getContextPath());
                        messageConfigDatabean.setParamMap(mailParams);
                        messageQueueService.sendMessage(messageConfigDatabean);
                    }
                    StringBuilder strQuery = new StringBuilder();
                    if(hdcommiitteetypeid==1){
                        //strQuery.append("redirect:/eauction/auctioneer/auctiondashboard/").append(eventId).append("/").append(hdtabId).append(encryptDecryptUtils.generateRedirect(strQuery.substring(strQuery.indexOf("/")+1), request));
                        strQuery.append("redirect:/etender/buyer/tenderdashboard/").append(eventId).append("/").append(hdtabId).append(encryptDecryptUtils.generateRedirect(strQuery.substring(strQuery.indexOf("/")+1), request));
                    }else if(hdcommiitteetypeid==2){
                        strQuery.append("redirect:/etender/buyer/tenderdashboard/").append(eventId).append("/").append(hdtabId).append(encryptDecryptUtils.generateRedirect(strQuery.substring(strQuery.indexOf("/")+1), request));
                    }
                    retVal = strQuery.toString();
		}
                if(hdcommiitteetypeid==1){
                    auditTrialMessage = negopublishedcommittee;
                    linkId = aucnegotiationpublishcommitteelinkId;
                }else if(hdcommiitteetypeid==2){
                    auditTrialMessage = negopublishedcommittee;
                    linkId = tendernegotiationpublishcommitteelinkId;
                }
	    }
	} catch (Exception ex) {
	    retVal = exceptionHandlerService.writeLog(ex);
	} finally {
		if(hdcommiitteetypeid==1){
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, ipAddress,hdcommitteeId, eventId);
		}else{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, hdcommitteeId, eventId);
		}
	}
	redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_committee_published_successfully" : CommonKeywords.ERROR_MSG_KEY.toString());
	return retVal;
    }

    /**
     * use existing commiittee
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/common/usedynexistingcommiittee/{commiitteetypeid}/{eventId}/{tabId}/{enc}", method = RequestMethod.GET)
    public String useexistingcommiittee(@PathVariable("commiitteetypeid") int commiitteetypeid,@PathVariable("eventId") int eventId,@PathVariable("tabId") int tabId,ModelMap modelMap,HttpServletRequest request) {
    	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
        String strReturn ="common/negotiation/buyer/ExistingCommiittee";
        int linkId = 0;	
        String auditTrialMessage = "";             
        try {
//                modelMap.addAttribute("tenderResult", tenderCommonService.getTenderField(tenderId,"tenderResult"));
//    		modelMap.addAttribute("envelopeList",abcUtility.convert(tenderFormService.getTenderEnvelopeList(tenderId), 1,2));
    		modelMap.addAttribute("eventId", eventId);
    		modelMap.addAttribute("clientId", abcUtility.getSessionClientId(request));
    		modelMap.addAttribute("tabId", tabId);
    		modelMap.addAttribute("reportId", 73);
    		modelMap.addAttribute("commiitteetypeid", commiitteetypeid);
    		reportGeneratorService.getReportConfigDetails(73, modelMap);
                if(commiitteetypeid==1){
                    commonService.commonauctionSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
                }else if(commiitteetypeid==2){
                    commonService.commontenderSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
                }
                if(commiitteetypeid==1){
                    auditTrialMessage = negocreateexistingcommittee;
                    linkId = aucnegotiationexistingcommitteelinkId;
                }else if(commiitteetypeid==2){
                    auditTrialMessage = negocreateexistingcommittee;
                    linkId = tendernegotiationexistingcommitteelinkId;
                }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally{
        	if(commiitteetypeid==1){
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, ipAddress,0, eventId);
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, 0, eventId);
        	}
        }
        return strReturn;
    }
    /**
     * post existing committee
     * @Author Shreyansh shah
     * @param tenderId
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/common/submitdynexistingcommittee", method = RequestMethod.POST)
    public String submitdynexistingcommittee(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    	HttpSession session = request.getSession();
        String retVal = REDIRECT_SESSION_EXPIRED;
        boolean isSuccess = false;
        SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;
        int eventId = 0;
        int hdtabId = 0;
        int hdcommiitteetypeid = 0;
        int existingCommitteeId = 0;                
        int newCommitteeId = 0;                
        TblCommitteeDetail tblCommitteeDetail = null;        
        int linkId = 0;	
        String auditTrialMessage = "";             
        try {
            List<TblCommitteeUserDetail> tblCommitteeUserDetaillist = new ArrayList<TblCommitteeUserDetail>();
            int userId = abcUtility.getSessionUserId(request);            
            if (userId != 0) {
                String committeeName = StringUtils.hasLength(request.getParameter("txtCommitteeName")) ? request.getParameter("txtCommitteeName") : "";
                existingCommitteeId = StringUtils.hasLength(request.getParameter("hdcommitteeId")) ? Integer.parseInt(request.getParameter("hdcommitteeId")) : 0;                
                hdcommiitteetypeid = StringUtils.hasLength(request.getParameter("hdcommiitteetypeid")) ? Integer.parseInt(request.getParameter("hdcommiitteetypeid")) : 0;
                eventId = StringUtils.hasLength(request.getParameter("hdeventId")) ? Integer.parseInt(request.getParameter("hdeventId")) : 0;
                hdtabId = StringUtils.hasLength(request.getParameter("hdtabId")) ? Integer.parseInt(request.getParameter("hdtabId")) : 0;		
                TblCommitteeDetail  existingTblCommitteeDetail = commonService.getCommitteeDetailById(existingCommitteeId);
                List<TblCommitteeUserDetail>  existingTblCommitteeUserDetail = commonService.getCommitteeUserDetailByUserDetailId(existingCommitteeId);
                if(existingTblCommitteeDetail!=null){
                    tblCommitteeDetail = new TblCommitteeDetail();
		    tblCommitteeDetail.setCommitteeName(committeeName);
		    tblCommitteeDetail.setCommitteeType(existingTblCommitteeDetail.getCommitteeType());
                    tblCommitteeDetail.setTblClient(existingTblCommitteeDetail.getTblClient());
		    tblCommitteeDetail.setObjectId(eventId);
		    tblCommitteeDetail.setIsStandard(existingTblCommitteeDetail.getIsStandard());
                    tblCommitteeDetail.setMinApprovalReq(existingTblCommitteeDetail.getMinApprovalReq());
		    tblCommitteeDetail.setRemarks("");		    		    
                    tblCommitteeDetail.setCreatedBy(sessionBean.getUserDetailId());
		    tblCommitteeDetail.setIsActive(1);
		    tblCommitteeDetail.setIsApproved(0);
                }
                if(existingTblCommitteeUserDetail!=null && !existingTblCommitteeUserDetail.isEmpty()){
                    for(TblCommitteeUserDetail existingtblCommitteeUserDetail : existingTblCommitteeUserDetail){
                        TblCommitteeUserDetail tblCommitteeUserDetail = new TblCommitteeUserDetail();
			tblCommitteeUserDetail.setTblCommitteeDetail(tblCommitteeDetail);
			tblCommitteeUserDetail.setTblUserLogin(existingtblCommitteeUserDetail.getTblUserLogin());
			tblCommitteeUserDetail.setTblUserDetail(existingtblCommitteeUserDetail.getTblUserDetail());
			tblCommitteeUserDetail.setRemarks("");
			tblCommitteeUserDetail.setCreatedBy(sessionBean.getUserDetailId());
			tblCommitteeUserDetail.setIsApproved(0);
			tblCommitteeUserDetaillist.add(tblCommitteeUserDetail);
                    }
                }
                List<Object[]> list = commonService.getAllDynCommitteeMemberDetails(abcUtility.getSessionClientId(request), hdcommiitteetypeid, eventId);
                if(list==null || list.isEmpty()){
                    isSuccess = commonService.addDynCommitteDetails(tblCommitteeDetail, tblCommitteeUserDetaillist);    
                    newCommitteeId = tblCommitteeDetail.getCommitteeId();
                }
                StringBuilder strQuery = new StringBuilder();
                if (isSuccess){
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_common_comittee");                    
		}else{
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
                }
                if(hdcommiitteetypeid==1){
                    strQuery.append("redirect:/eauction/auctioneer/auctiondashboard/").append(eventId).append("/").append(hdtabId).append(encryptDecryptUtils.generateRedirect(strQuery.substring(strQuery.indexOf("/")+1), request));
                    retVal = strQuery.toString();
                    auditTrialMessage = negocommitteecreated;
                    linkId = aucnegotiationexistingcommitteelinkId;
                }else if(hdcommiitteetypeid==2){
                    strQuery.append("redirect:/etender/buyer/tenderdashboard/").append(eventId).append("/").append(hdtabId).append(encryptDecryptUtils.generateRedirect(strQuery.substring(strQuery.indexOf("/")+1), request));
                    retVal = strQuery.toString();
                    auditTrialMessage = negocommitteecreated;
                    linkId = tendernegotiationexistingcommitteelinkId;
                }
            }
	} catch (Exception ex) {
	    return exceptionHandlerService.writeLog(ex);
	} finally {
		if(hdcommiitteetypeid==1){
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, ipAddress,newCommitteeId, eventId);
		}else{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMessage, newCommitteeId, eventId);
		}
	}
	return retVal;
    }    
    /**
     * post existing committee
     * @Author Shreyansh shah
     * @param tenderId
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/common/ajax/sendchat", method = RequestMethod.POST)
    @ResponseBody
    public String sendchat(@RequestParam("linkId") int linkId,@RequestParam("sendtext") String sendtext,@RequestParam("eventId") int eventId,@RequestParam("childId") int childId,HttpServletRequest request) {
        HttpSession session = request.getSession();
        String retVal = "fail";
        boolean isSuccess = false;
        int chatId=0;
        SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;        
        try {
            int userId = abcUtility.getSessionUserId(request); 
            int clientId = abcUtility.getSessionClientId(request);
            if (userId!=0) {
                if(sendtext!=null && !"".equalsIgnoreCase(sendtext)){
                    TblChat tblChat = new TblChat();
                    tblChat.setTblLink(new TblLink(linkId));
                    tblChat.setObjectId(eventId);
                    tblChat.setChildId(childId);
                    tblChat.setMessageText(sendtext);
                    tblChat.setTblUserLogin(new TblUserLogin(userId));
                    tblChat.setCreatedBy(sessionBean.getUserDetailId());
                    if(commonService.submitChat(tblChat)){
                        chatId = tblChat.getChatId();
                        int bidderstartchatlinkId = 0;
                        int buyerstartchatlinkId = 0;
                        if(linkId == tendernegotiationbuyerstartchatid || linkId==tendernegotiationbidderstartchatid){
                            buyerstartchatlinkId = tendernegotiationbuyerstartchatid;
                            bidderstartchatlinkId = tendernegotiationbidderstartchatid;
                        }else if(linkId == auctionnegotiationbuyerstartchatid || linkId==auctionnegotiationbidderstartchatid){
                            buyerstartchatlinkId = auctionnegotiationbuyerstartchatid;
                            bidderstartchatlinkId = auctionnegotiationbidderstartchatid; 
                        }
                        List<Object[]> list = commonService.getChatData(buyerstartchatlinkId,bidderstartchatlinkId,eventId,childId,userId,0,clientId);
                        if(list!=null && !list.isEmpty()){
                            String trClass = "";
                            for (Object[] objects : list) {                            
                               if(userId!=Integer.parseInt(objects[5].toString())){
                                    trClass = "form-hd-ft-clr";
                               }
                            //retVal = retVal + "<tr class='"+trClass+"'><td>"+objects[2]+" : "+objects[1]+"</td><td><span class='chat-date'>"+CommonUtility.convertTimezoneToClientTimezone(objects[4])+"</span></td></tr>";  
                               retVal = retVal + "<tr class='"+trClass+"'><td class='border-top-none'>"+objects[2]+" : <span class='dark-gray'>"+objects[1]+"</span><br/><span style='float:right;color:#B9B9B9;top:8px;font-size:11px;'>"+CommonUtility.convertTimezoneToClientTimezone(objects[4])+"</span></td></tr>";  
                                trClass = "";
                            }
                        }
                    }else{
                        retVal = "fail";
                    }
                }
            }else{
                retVal = REDIRECT_SESSION_EXPIRED;
            }
	} catch (Exception ex) {
	    return exceptionHandlerService.writeLog(ex);
	} finally {
	    auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, sendchat, chatId, eventId);
	}
//        System.out.println(" ret val "+retVal);
	return retVal;
    }    
    /**
     * post existing committee
     * @Author Shreyansh shah
     * @param tenderId
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/common/ajax/getchatdata", method = RequestMethod.POST)
    @ResponseBody
    public String getchatdata(@RequestParam("linkId") int linkId,@RequestParam("eventId") int eventId,@RequestParam("childId") int childId,HttpServletRequest request) {
    	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    	HttpSession session = request.getSession();
        String retVal = "";
        boolean isSuccess = false;
        boolean result = false;
        SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;                      
        try {
            int userId = abcUtility.getSessionUserId(request);
            int clientId = abcUtility.getSessionClientId(request);
            if (userId!= 0) {                
                int bidderstartchatlinkId = 0;
                int buyerstartchatlinkId = 0;
                if(linkId == tendernegotiationbuyerstartchatid || linkId==tendernegotiationbidderstartchatid){
                    buyerstartchatlinkId = tendernegotiationbuyerstartchatid;
                    bidderstartchatlinkId = tendernegotiationbidderstartchatid;
                }else if(linkId == auctionnegotiationbuyerstartchatid || linkId==auctionnegotiationbidderstartchatid){
                    buyerstartchatlinkId = auctionnegotiationbuyerstartchatid;
                    bidderstartchatlinkId = auctionnegotiationbidderstartchatid; 
                }
                if(linkId == bidderstartchatlinkId) {
                	result = commonService.updateChat(buyerstartchatlinkId);
                }else if( linkId ==buyerstartchatlinkId ) {
                	result = commonService.updateChat(bidderstartchatlinkId);
                	
                }
                List<Object[]> list = commonService.getChatData(buyerstartchatlinkId,bidderstartchatlinkId,eventId,childId,userId,0,clientId);
                if(list!=null && !list.isEmpty()){
                    String trClass = "";
                    for (Object[] objects : list) {
                        if(userId!=Integer.parseInt(objects[5].toString())){
                            trClass = "form-hd-ft-clr";
                        }
                       //retVal = retVal + "<tr class='"+trClass+"'><td>"+objects[2]+" : "+objects[1]+"</td><td><span class='chat-date'>"+CommonUtility.convertTimezoneToClientTimezone(objects[4])+"</span></td></tr>";  
                        retVal = retVal + "<tr class='"+trClass+"'><td class='border-top-none'>"+objects[2]+" : <span class='dark-gray'>"+objects[1]+"</span><br/><span style='float:right;color:#B9B9B9;top:8px;font-size:11px;'>"+CommonUtility.convertTimezoneToClientTimezone(objects[4])+"</span></td></tr>";  
                        trClass = "";
                    }
                }
            }else{
                retVal = REDIRECT_SESSION_EXPIRED;
            }
	} catch (Exception ex) {
	    return exceptionHandlerService.writeLog(ex);
	} finally {
		if(linkId == auctionnegotiationbuyerstartchatid || linkId==auctionnegotiationbidderstartchatid){
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, accessedchatdialog, ipAddress,eventId, childId);
		}else{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, accessedchatdialog, eventId, childId);
		}
	}
//        System.out.println(" ret val "+retVal);
	return retVal;
    }    
//    /**
//     * post existing committee
//     * @Author Shreyansh shah
//     * @param tenderId
//     * @param modelMap
//     * @return
//     */
//    @RequestMapping(value = "/common/ajax/getcompanyName", method = RequestMethod.POST)
//    @ResponseBody
//    public String getcompanyName(@RequestParam("companyId") int companyId,HttpServletRequest request) {
//        HttpSession session = request.getSession();
//        String retVal = "";
//        boolean isSuccess = false;
//        SessionBean sessionBean = session != null && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ? (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) : null;                      
//        try {
//            int userId = abcUtility.getSessionUserId(request);            
//            if (userId!= 0) {                
//                retVal = commonService.getCompanyNameByCompanyId(companyId);
//            }else{
//                retVal = REDIRECT_SESSION_EXPIRED;
//            }
//	} catch (Exception ex) {
//	    return exceptionHandlerService.writeLog(ex);
//	} finally {
//	    //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "", newCommitteeId, eventId);
//	}
//	return retVal;
//    }    
    /**
     * Common Chat History
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/common/CommonChatHistory/{linkId}/{eventId}/{childId}/{tabId}/{companyId}/{enc}", method = RequestMethod.GET)
    public String CommonChatHistory(@PathVariable("linkId") int linkId,@PathVariable("eventId") int eventId,@PathVariable("childId") int childId,@PathVariable("tabId") int tabId,@PathVariable("companyId") int companyId,ModelMap modelMap,HttpServletRequest request) {        
    	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    	String strReturn ="common/CommonChatModuleHistory";
        try {
            HttpSession httpSession = request.getSession();
            int clientId = abcUtility.getSessionClientId(request);
            int sessionUserId = 0;
            int sessioncompanyId = 0;
            int eventType = 0;
            if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                    SessionBean sessionBean= (SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
                    sessionUserId = sessionBean.getUserId();
                    sessioncompanyId = sessionBean.getCompanyId();
            }
            if(sessionUserId!=0){
                modelMap.addAttribute("linkId", linkId);
                modelMap.addAttribute("eventId", eventId);
                modelMap.addAttribute("childId", childId);
                modelMap.addAttribute("tabId", tabId);            
                int bidderstartchatlinkId = 0;
                int buyerstartchatlinkId = 0;
                if(linkId == tendernegotiationbuyerstartchatid || linkId==tendernegotiationbidderstartchatid){
                    eventType = 2;
                    buyerstartchatlinkId = tendernegotiationbuyerstartchatid;
                    bidderstartchatlinkId = tendernegotiationbidderstartchatid;
                }else if(linkId == auctionnegotiationbuyerstartchatid || linkId==auctionnegotiationbidderstartchatid){
                    eventType = 1;
                    buyerstartchatlinkId = auctionnegotiationbuyerstartchatid;
                    bidderstartchatlinkId = auctionnegotiationbidderstartchatid; 
                }                
                modelMap.addAttribute("list", commonService.getChatData(buyerstartchatlinkId,bidderstartchatlinkId, eventId,0,companyId!=0?companyId:sessioncompanyId,eventType,clientId));                
                  //int requestedUserId=0;
//                if(companyId!=0){
//                    List<Object[]> list = commonService.getBidderIdFromCompanyId(companyId,abcUtility.getSessionClientId(request));
//                    if(list!=null && !list.isEmpty()){
//                        requestedUserId = list.get(0)[0]!=null?Integer.parseInt(list.get(0)[0].toString()):0;
//                    }
//                }
//                modelMap.addAttribute("list", commonService.getChatData(buyerstartchatlinkId,bidderstartchatlinkId, eventId,0,companyId!=0?requestedUserId:sessionUserId));                
            }else{
                strReturn = REDIRECT_SESSION_EXPIRED;
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally{
        	if(linkId == auctionnegotiationbuyerstartchatid || linkId==auctionnegotiationbidderstartchatid){
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewchathistory, ipAddress,eventId, childId);
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, viewchathistory, eventId, childId);
        	}
        }
        return strReturn;
    }
    
    @RequestMapping(value = "common/admin/gobackredirection", method = RequestMethod.POST)
    public String goBackRedirection(HttpServletRequest request, ModelMap modelMap,RedirectAttributes redirectAttributes) {
        String resultString = "sessionexpired";
        try {
        	int userId=abcUtility.getSessionUserId(request);
        	 if(userId !=0) {
        		 resultString="redirect:/";
        		 String[] param=request.getParameterValues("hdParam");
        		 int reportId=StringUtils.hasLength(request.getParameter("hdReportId")) ? Integer.parseInt(request.getParameter("hdReportId")) : 0;
        		 List<HashMap<String,Object>> paramList=new ArrayList<HashMap<String,Object>>();
        		 if(param != null){
        			 for(String data : param){
        				 HashMap<String,Object> paramMap=new HashMap<String, Object>();
        				 String[] dataString=data.split(",");
        				 paramMap.put("searchVal", dataString[0]);
        				 paramMap.put("paramId", dataString[1]);
        				 paramMap.put("componentType", dataString[2]);
        				 paramList.add(paramMap);
        			 }
        		 }
        		 redirectAttributes.addFlashAttribute("paramList",paramList);
        		 switch (reportId) {
				case 1:
						resultString="common/admin/searchlistclient";
					break;

				default:
					break;
				}
        	 }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } 
        return  "redirect:/"+resultString+encryptDecryptUtils.generateRedirect(resultString, request);
    }
    /**
     * @param countryId
     * @return
     */
    @RequestMapping(value = "/ajaxcall/isAbcUsersCheck", method = RequestMethod.POST)
    @ResponseBody
    public String isAbcUsersCheck(@RequestParam("txtemailId") String txtemailId, HttpServletRequest request) {
        String retVal = "show";
        try {
           int i = commonService.checkAbcUserCount(txtemailId);
           if(i>0){
               retVal = "hide";
           }           
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return retVal;
    }
    /**
     * @author jaynam
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/workinprogressreport/{enc}", method = RequestMethod.GET)
    public String workInProgessReport(ModelMap modelMap, HttpServletRequest request) {
    
    	String retVal="common/WorkInProgressReport";
    	int reportId=0;
        try {
            reportId=workInProgressReportId;
            modelMap.addAttribute("lang",WebUtils.getCookie(request, "locale").getValue());
            modelMap.addAttribute("clientIds", clientIds);
            modelMap.addAttribute("reportId", reportId);
            reportGeneratorService.getReportConfigDetails(reportId, modelMap);
        } catch (Exception ex) {
            retVal= exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),workInProgressReportId, getWipReportRemark, 0, 0);
        }
        return retVal;
    }
    
    
	
	/* @author Dipika Patel
	 * @param session
	 * @param request
	 * @param modelMap
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value = {"/eauction/bidder/submitbidderofflinepayment","/etender/bidder/submitbidderofflinepayment"}, method = RequestMethod.POST)
	public String submitBidderOfflinePayment(HttpSession httpSession,HttpServletRequest request, RedirectAttributes redirectAttributes,ModelMap modelMap) {
		
		String pageView = null;
		int clientId = 0;
		int userId = 0;
		int payType = 0;
		int payFor = 0;
		String registrationCharge ="0";
		String bankName = null;
		String refno = null;
		String refdate = null;
		int moduleId=0;
		int eventId=0;
		int linkId=0;
		int redirectOnBiddingHall = 0;
		boolean isServerSideValid = true;
		String redirectMsg=CommonKeywords.ERROR_MSG_KEY.toString();
		boolean isEventLive = true;
    	long count = 0;
		try {
			clientId = abcUtility.getSessionClientId(request);
			SessionBean sessionBean = (SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
			userId = sessionBean.getUserId();
			String docMapIds = StringUtils.hasLength(request.getParameter("txtHidDocIds"))? request.getParameter("txtHidDocIds") :"0";
            eventId = StringUtils.hasLength(request.getParameter("jhdEventId")) ? Integer.parseInt(request.getParameter("jhdEventId")) : 0;
            moduleId = StringUtils.hasLength(request.getParameter("jhdModuleId")) ? Integer.parseInt(request.getParameter("jhdModuleId")) : 0;
        	linkId = StringUtils.hasLength(request.getParameter("jhdLinkId")) ? Integer.parseInt(request.getParameter("jhdLinkId")) : 0;
        	registrationCharge=StringUtils.hasLength(request.getParameter("jhdAmount")) ? request.getParameter("jhdAmount") : "0";
        	payFor=StringUtils.hasLength(request.getParameter("jhdPayFor")) ? Integer.parseInt(request.getParameter("jhdPayFor")) : 0;
        	payType=StringUtils.hasLength(request.getParameter("jhdPayType")) ? Integer.parseInt(request.getParameter("jhdPayType")) : 0;
        	refno=StringUtils.hasLength(request.getParameter("txtCheckDDNo")) ? request.getParameter("txtCheckDDNo") : "";
        	refdate=StringUtils.hasLength(request.getParameter("txtPaymentDate")) ? request.getParameter("txtPaymentDate") : "";
        	bankName=StringUtils.hasLength(request.getParameter("txtBankName")) ? request.getParameter("txtBankName") : "";
        	
        	if(moduleId == 5){
				int errCode = commonService.getAuctionStatus(eventId);
	            if (errCode == 2 || errCode == 4 ) { // errCode = 2 is Stop auction and errCode = 4 is Cancel auction
	            	redirectOnBiddingHall = errCode;  
	            } 
	            if(redirectOnBiddingHall != 2 && redirectOnBiddingHall != 4 && commonService.checkAuctionIsClosed(eventId) == false){
	            	isServerSideValid = true;
	            }else{
	            	isServerSideValid = false;
	            }
			}else if(moduleId==3){
       		 count = commonService.checkTenderCancel(eventId);
        	 isEventLive = commonService.isEventLive(eventId)==-1?false:true;
        	 	if(count>0 || !isEventLive){
        	 		isServerSideValid = false;
     			}else {
     				isServerSideValid = true;
     			}
			}
        	if(isServerSideValid){
				TblPayment tblPayment = new TblPayment();
				tblPayment.setAmount(new BigDecimal(registrationCharge));
				tblPayment.setExemptionAmt(new BigDecimal(0));
				tblPayment.setCreatedBy(sessionBean.getUserId());
				tblPayment.setObjectId(eventId); //eventId
				tblPayment.setTblClient(new TblClient(clientId));
				tblPayment.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
				tblPayment.setTblLink(new TblLink(linkId));
				tblPayment.setClientIds("");
				tblPayment.setRemark("");
				tblPayment.setPaymentFor(payFor);
				tblPayment.setCstatus(0);
				tblPayment.setTblPaymentType(new TblPaymentType(payType));
				tblPayment.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
				tblPayment.setTblDepartment(new TblDepartment(Integer.parseInt(clientService.getClientField(clientId, "deptId").toString())));				
				tblPayment.setTblModule(new TblModule(moduleId));

				TblOfflinePayment tblOfflinePayment = new TblOfflinePayment();				
				tblOfflinePayment.setReferenceNo(refno);
				tblOfflinePayment.setReferenceDate(CommonUtility.getDateObj(refdate));
				tblOfflinePayment.setBankName(bankName);

				List<TblBidderStatus> bidderStatusList = new ArrayList<TblBidderStatus>();
				List<TblUserHistory> userHistoryList = new ArrayList<TblUserHistory>();

				TblUserHistory tblUserHistory = new TblUserHistory();
				tblUserHistory.setActionType(10);
				tblUserHistory.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
				tblUserHistory.setTblClient(new TblClient(clientId));
				tblUserHistory.setCreatedBy(userId);
				userHistoryList.add(tblUserHistory);
				boolean success = manageBidderService.approveBidder(tblPayment,tblOfflinePayment, bidderStatusList, userHistoryList);

				if (success) {

					redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"msg_success_reg_payment");										
					if (StringUtils.hasLength(docMapIds)) {
						TblPayment tblPaymentNew = commonService.getPaymentDetailByEventId(sessionBean.getUserId(), clientId, payFor, eventId, moduleId);
						int paymentId = 0;
						if (tblPaymentNew != null) {
							paymentId = tblPayment.getPaymentId();
						}
						fileUploadService.updateBidderDocsObjectId(docMapIds,paymentId, 1);
					}			
				} else {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_error_reg_payment");
				}
        	}
        	if(moduleId==3){
				pageView = "etender/bidder/biddingtenderdashboard/" + eventId + "/14";
				pageView = "redirect:/" + pageView + encryptDecryptUtils.generateRedirect(pageView,request);
			}else if(moduleId==5){
				if(redirectOnBiddingHall == 2 || redirectOnBiddingHall == 4 || commonService.checkAuctionIsClosed(eventId) == true){
		    		if(redirectOnBiddingHall == 2){
		    			redirectMsg = "msg_auc_stop";
		    			
		    		}else if(redirectOnBiddingHall == 4) {
		    			redirectMsg = "msg_auc_cancel";
		    		}else{
		    			redirectMsg = "msg_auc_bidtimeover";
		    		}
	        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString() ,redirectMsg);
	        		if(payFor == 2){
	        			pageView = "eauction/bidder/bidsubmission/"+eventId+"/0";
	        		}else if(payFor == 8){
	        			pageView ="eauction/bidder/auctionlisting";
	        		}
	        		pageView="redirect:/"+pageView+ encryptDecryptUtils.generateRedirect(pageView, request);
	            }else{
	            	pageView = "eauction/bidder/eventwisebidderregcharges/" + linkBidSubRegChargesOfflinePayment + "/"+eventId+"/5";
					pageView = "redirect:/" + pageView + encryptDecryptUtils.generateRedirect(pageView,request);
	        			
	        	}
			}
        } catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId,"", userId, clientId);
		}
		return pageView;
	}
	
	
	@RequestMapping(value = "ajaxcall/checkuniquedeptname", method = RequestMethod.POST)
    @ResponseBody
    public String checkUniqueDepartMentName(@RequestParam("txtDeptname") String deptName,HttpServletRequest request) {
        boolean isExist = false;
        try {
            isExist = commonService.checkUniqueDeptName(deptName,abcUtility.getSessionClientId(request));
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return isExist + "";
    }	
	/**
     * @Author dipika
     * Generates the options of payment gateway provided by the bankId passed. Used for the pages with login.
     * @param bankId
     * @return
     */
    @RequestMapping(value = "/ajax/getPaymentGatewaybyBankId", method = RequestMethod.POST)
    @ResponseBody
    public String getPaymentGatewaybyBankId(@RequestParam("hdBankId") Integer bankId,@RequestParam("txtClientId") Integer clientId, HttpSession session, HttpServletRequest request) {
        String retVal = "sessionexpired";
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		TblClientPGBankMapping tblClientPGBankMapping=clientService.getTblClientPGBankMapping(clientId, 1);
        		int selectedPG=0;
                if(tblClientPGBankMapping!=null){
                	selectedPG=tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId();
                }                
        		retVal = encryptDecryptUtils.getOptions("selPaymentGateway", abcUtility.convert(commonService.getPaymentGatewayByBankId(bankId)), false,String.valueOf(selectedPG), "");
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return retVal;
    }
    /**
     * @Author dharmesh
     * Generates the options of payment mode
     * @param isonline
     * @return
     */
    @RequestMapping(value = "/ajax/getPaymentModebyIsonline", method = RequestMethod.POST)
    @ResponseBody
    public String getPaymentModebyIsonline(@RequestParam("txtIsonline") Integer Isonline,@RequestParam("txtClientId") Integer clientId, HttpSession session, HttpServletRequest request) {
        String retVal = "sessionexpired";
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		 List<Object[]> payList = clientService.getClientIsOnlinePaymentType( clientId, Isonline);    
        		 retVal = encryptDecryptUtils.getOptions("selModeOfPayment",(clientId==0)?abcUtility.convert(payList):abcUtility.convertSelected(payList),false,"selected","");
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return retVal;
    }
    @RequestMapping(value="/monitorDatasource", method=RequestMethod.GET)
    public String monitorDatasource(HttpSession httpSession,HttpServletRequest request, RedirectAttributes redirectAttributes,ModelMap modelMap) {
    	modelMap.addAttribute("maxActive",basicDataSource.getMaxActive());
    	modelMap.addAttribute("numActive",basicDataSource.getNumActive());
    	modelMap.addAttribute("idle",basicDataSource.getNumIdle());
    	return "monitorDatasource";
    }
    
    
    /**
     * @author dhruvil
     * @param response
     * @param httpSession
     * @param request
     * @param countryId
     * @throws IOException
     */
    @RequestMapping(value = "/common/admin/ajaxgetcountrystatelist", method = RequestMethod.POST)
    public void getCountryStateList(HttpServletResponse response, HttpSession httpSession, HttpServletRequest request,@RequestParam("txtCountryId") Integer countryId) throws IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        try {
        	
        	List<TblState> lst = commonService.getStateBycountryId(countryId);
            
            StringBuilder jsonString = new StringBuilder();
            if (lst != null && !lst.isEmpty()) {
                jsonString.append("[{");
                
                for(int i=0;i<lst.size();i++){
                	jsonString.append("\"id\":").append(lst.get(i).getStateId()).append(",")
                    .append("\"text\":").append("\"").append(lst.get(i).getLang1()).append("\"").append("}");
                	if(i <= lst.size()-2){
                		jsonString.append(",{");
                	}
                }
                jsonString.append("]");
                out.print(jsonString);
            }
       } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            out.close();
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), categoryTreeLinkId, ajaxGetCategoryTreeAuditMsg, 0, 0);
        }
    }
    
    /**
     * @author vivek.rajyaguru
     * @param deptId
     * @param isDRT
     * @param isBank
     * @param isSarfaesi
     * @param jsRequire
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/admin/ajax/getdepartmentofficer", method = RequestMethod.POST)
    @ResponseBody
    public String getDepartmentOfficer(@RequestParam("deptId") String deptId, @RequestParam(value = "isDRT", required = false) String isDRT, @RequestParam(value = "isBank", required = false) String isBank, @RequestParam(value = "isSarfaesi", required = false) String isSarfaesi, @RequestParam(value = "jsRequire", required = false) String jsRequire, HttpServletRequest request) {
        String retVal = null;
        try {
            if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
                retVal = encryptDecryptUtils.getOptions("selDeptOfficial", abcUtility.convert(commonService.getDepartmentOfficer(Integer.parseInt(deptId), abcUtility.getSessionClientId(request), Boolean.valueOf(isDRT), Boolean.valueOf(isBank), Boolean.valueOf(isSarfaesi))), Boolean.valueOf(jsRequire), "", "-- "+messageSource.getMessage("auc_please_selectmsg", null, LocaleContextHolder.getLocale())+" --");
            } else {
                retVal = "sessionexpired";
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0,"getDepartmentOfficer", 0, 0);
        }
        return retVal;
    }
    @RequestMapping(value = "/faq", method = RequestMethod.GET)
    public String faqHome(HttpServletResponse response, HttpServletRequest request,ModelMap modelMap) {
    	try {
    		int clientId = abcUtility.getSessionClientId(request);
        	List<Object[]>faqList=faqService.getFAQHomeContent(clientId);
        	if(faqList.size()!=0){
        		Object[] frqFirst=faqList.get(0);
            	modelMap.addAttribute("frqFirst", frqFirst);
            	modelMap.addAttribute("faqList", faqList);
        	}
        	
    		
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		 finally {
	        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0,"getDepartmentOfficer", 0, 0);
	        }
        return "common/faq";
    }
  
    /**
     * @Author um@ng.rathod
     * Use for Country Combo to State list.
     * @param countryId
     * @return
     */
    @RequestMapping(value = "/ajax/getstatebycountryidSSO", method = RequestMethod.POST)
    @ResponseBody
    public String getStateListByCountryId(@RequestParam("hdCountryId") String countryId, HttpSession session, HttpServletRequest request) {
        String retVal = "sessionexpired";
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		retVal = encryptDecryptUtils.getOptions("selState", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(Integer.parseInt(countryId) ), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()), false, "", "Please Select");
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return retVal;
    }
    
    /**
     * @Author um@ng.rathod
     * Use for Country Combo to State list.
     * @param countryId
     * @return
     */
    @RequestMapping(value = "/ajaxcall/getstatebycountryidSSO", method = RequestMethod.POST)
    @ResponseBody
    public String getStateListByCountryId(@RequestParam("hdCountryId") String countryId, HttpServletRequest request) {
        String retVal = null;
        try {
            retVal = encryptDecryptUtils.getOptions("selState", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(Integer.parseInt(countryId)), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()), false, "", "Please Select");
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return retVal;
    }
    
    @RequestMapping(value = "/ajaxcall/getcertverificationstatus", method = RequestMethod.POST)
    @ResponseBody
    public String getCertVerficationStatus(@RequestParam("txtIsCertRequired") int isCertRequired,@RequestParam("txtCertType") int certType,@RequestParam("txtTenderId") int tenderId, HttpServletRequest request) {
        try {
        	 Boolean isCertVerified = commonService.checkIsCertificateVerified(isCertRequired,certType, request);
        	 if(isCertVerified)
        	 {
        		return "true"; 
        	 }
        	 
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return "false";
    }
    
    /**
     * This method is used to get mail acknowledgment report. PT : #33531
     * @author jitendra
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/mailAcknowledgmentReport/{enc}", method = RequestMethod.GET)
    public String getMailAcknowledgmentReport(ModelMap modelMap, HttpServletRequest request){
    	try {
    		modelMap.addAttribute("reportId", mailAcknowledgmentReportId);
        	reportGeneratorService.getReportConfigDetails(mailAcknowledgmentReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),mailAcknowledgmentReportLinkId, getMailAcknowledgmentReportRemark, 0, 0);
        }
        return "common/MailAcknowledgmentReport";
    }
    
    /**
     * This method is used to get bidder profile details report. PT : #35360
     * @author jitendra
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/bidderProfileDetailsReport/{enc}", method = RequestMethod.GET)
    public String getBidderProfileDetailsReport(ModelMap modelMap, HttpServletRequest request){
    	try {
    		modelMap.addAttribute("reportId", bidderProfileDetailsReportId);
        	reportGeneratorService.getReportConfigDetails(bidderProfileDetailsReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),bidderProfileDetailsReportLinkId, getBidderProfileDetailsReportRemark, 0, 0);
        }
        return "common/BidderProfileDetailsReport";
    }
    

    /**
     * This method is used to add Feedback of user. PT : #36316
     * @author Meghna
     * @param request
     * @return
     */
    @RequestMapping(value = "/common/submitfeedback", method = RequestMethod.POST)
    public String submitFeedback(HttpServletRequest request, RedirectAttributes redirectAttributes)
    		throws Exception {
    	String retVal = "";
    	boolean isSuccess = false;
    	try {
    		String txtDescription = StringUtils.hasLength(request.getParameter("txtaFeedbackDescription")) ? request.getParameter("txtaFeedbackDescription") : "";
            String txtSubject  = StringUtils.hasLength(request.getParameter("txtFeedbackSubject")) ? request.getParameter("txtFeedbackSubject") : "";
            if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
            	TblUserFeedBack tblUserFeedBack = new TblUserFeedBack();
            	tblUserFeedBack.setSubject(txtSubject);
            	tblUserFeedBack.setDescription(txtDescription);
            	tblUserFeedBack.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
            	tblUserFeedBack.setTblUserLogin(new TblUserLogin(abcUtility.getSessionUserId(request)));
            	tblUserFeedBack.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));

            	isSuccess = commonService.addFeedback(tblUserFeedBack);
            	if(isSuccess){
            		List<String> params = new ArrayList<String>();
            		Map<String, Object> mailParams = new HashMap<String, Object>();
            		MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
            		params.add(String.valueOf(abcUtility.getSessionUserId(request))); //@v-Param1
            		mailParams.put("to", commonService.getFromIdFromLogo(request));
            		mailParams.put("Subject", txtSubject);
            		mailParams.put("Description",txtDescription);
            		mailParams.put("domainName",clientService.getClientNameById(abcUtility.getSessionClientId(request)));
            		messageConfigDatabean.setTemplateId(submitFeedbackTemplateId);
            		messageConfigDatabean.setQueueName(queueName);
            		messageConfigDatabean.setUserId(abcUtility.getSessionUserId(request));
            		messageConfigDatabean.setClientId(abcUtility.getSessionClientId(request));
            		messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
            		messageConfigDatabean.setContextPath(request.getContextPath());
            		messageConfigDatabean.setParamMap(mailParams);
            		messageConfigDatabean.setLstParams(params);
            		messageQueueService.sendMessage(messageConfigDatabean);
            	}
            	retVal=getRedirectPage(request);
            }
            else{
            	retVal = REDIRECT_SESSION_EXPIRED;
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } 
    	redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), !isSuccess ? "redirect_failure_common" : null);
		return retVal;
    }
    
    /**
     * This method is used to redirect after user submit Feedback. PT : #36316
     * @author Meghna
     * @param request
     * @return
     */
    public String getRedirectPage(HttpServletRequest request) throws Exception{
        int userTypeId = abcUtility.getSessionUserTypeId(request);
        String pageName = "";
        String moduleId = WebUtils.getCookie(request, "moduleId").getValue();
        int isCategoryAllow = 0;
        if(abcUtility.isModuleAssignToClient(request,9) ){  // Module Assign Spend Analysis 
        	isCategoryAllow = commonService.isCategoryStaticsAllow(abcUtility.getSessionClientId(request));
        }
        ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        int clientId = abcUtility.getSessionClientId(request);
        int userId = abcUtility.getSessionUserId(request); 
        
        switch(userTypeId){
            case 1 : 
            	if(isCategoryAllow == 1){
            		pageName = "redirect:/common/CategoryWiseListingReport"+encryptDecryptUtils.generateRedirect("common/CategoryWiseListingReport", request);		
            	}else if("3".equals(moduleId)){
                    pageName = "redirect:/etender/buyer/tenderlisting"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderlisting", request);
                }else if("5".equals(moduleId)){
                		pageName = "redirect:/eauction/auctioneer/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/auctionlisting", request);	
                }else if("8".equals(moduleId)){
                    pageName = "redirect:/enlistment/admin/tasklist/0" + encryptDecryptUtils.generateRedirect("enlistment/admin/tasklist/0", request);
                }else{
                	pageName = "redirect:/welcome" + encryptDecryptUtils.generateRedirect("welcome", request);
                }
                break;
            case 2 :
            	if(isCategoryAllow == 1){
            		pageName = "redirect:/common/CategoryWiseListingReport"+encryptDecryptUtils.generateRedirect("common/CategoryWiseListingReport", request);		
            	}else if("3".equals(moduleId)){
                    pageName = "redirect:/etender/bidder/tenderlisting/0"+encryptDecryptUtils.generateRedirect("etender/bidder/tenderlisting/0", request);
                }else if("5".equals(moduleId)){
                	if(clientBean!=null && clientBean.getIsDIYClient()==1) {
                		pageName = "redirect:/eauction/bidder/quickauctionlisting" + encryptDecryptUtils.generateRedirect("eauction/bidder/quickauctionlisting", request);
                	}
                	else {
                		pageName = "redirect:/eauction/bidder/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/bidder/auctionlisting", request);
                	}
                }else if("8".equals(moduleId)){
                    pageName = "redirect:/enlistment/bidder/pqpreferencelisting" + encryptDecryptUtils.generateRedirect("enlistment/bidder/pqpreferencelisting", request);
                }else{
                	pageName = "redirect:/welcome" + encryptDecryptUtils.generateRedirect("welcome", request);
                }
            	if(CommonUtility.isClientConditionExistInProperty(rciClientIds, clientId)){
            		boolean isRciBidderEnlisted = request.getSession().getAttribute("isRciBidderEnlisted") == null ? false : (Boolean) request.getSession().getAttribute("isRciBidderEnlisted");
            		if(!isRciBidderEnlisted){ // if company is not enlisted or approved
            			isRciBidderEnlisted = vendorEnlistmentService.isCompanyEnlistedAndApproved(clientId,commonService.getCompanyId(userId, clientId));
            			request.getSession().setAttribute("isRciBidderEnlisted",isRciBidderEnlisted);
            			if(!isRciBidderEnlisted){
            				pageName = "redirect:/enlistment/bidder/pqpreferencelisting" + encryptDecryptUtils.generateRedirect("enlistment/bidder/pqpreferencelisting", request);
            			}
            		}
            	}
            	if(CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)){
            		boolean isGslBidderRegDone = request.getSession().getAttribute("isGslBidderRegDone") == null ? false : (Boolean) request.getSession().getAttribute("isGslBidderRegDone");
            		if(!isGslBidderRegDone){ // if bidder reg for industry type and classification - gsl only
            			isGslBidderRegDone = manageBidderService.isBidderRegInBidderIndustry(clientId, userId);
            			request.getSession().setAttribute("isGslBidderRegDone",isGslBidderRegDone);
            			if(!isGslBidderRegDone){
            				pageName = "redirect:/eauction/bidder/editbidder/"+ userId +encryptDecryptUtils.generateRedirect("eauction/bidder/editbidder/"+ userId , request);
            			}
            		}
            	}
                break;
            case 3 :
            	if(isCategoryAllow == 1){
            		pageName = "redirect:/common/CategoryWiseListingReport"+encryptDecryptUtils.generateRedirect("common/CategoryWiseListingReport", request);		
            	}else if("3".equals(moduleId)){
                    pageName = "redirect:/etender/buyer/tenderlisting"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderlisting", request);
                }else if("5".equals(moduleId)){
                	if(clientBean!=null && clientBean.getIsDIYClient()==1) {
                		pageName = "redirect:/eauction/auctioneer/quickauctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/quickauctionlisting", request);
                	}
                	else {
                		pageName = "redirect:/eauction/auctioneer/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/auctionlisting", request);
                	}
                }else if("8".equals(moduleId)){
                    pageName = "redirect:/enlistment/admin/tasklist/0" + encryptDecryptUtils.generateRedirect("enlistment/admin/tasklist/0", request);
                }else{
                	pageName = "redirect:/welcome" + encryptDecryptUtils.generateRedirect("welcome", request);
                }
                break;
        }
        return pageName;
    }
    
    /**
     * @Author Hira Chaudhary
     * Generates the options of Event payment mode
     * @return
     */
    @RequestMapping(value = "/ajax/getEventPaymentMode", method = RequestMethod.POST)
    @ResponseBody
    public String getEventPaymentMode(@RequestParam("txtPayMode") Integer payMode,@RequestParam("txtClientId") Integer clientId,@RequestParam("txtEventId") Integer objectID,@RequestParam("txtPayFor") Integer payFor,@RequestParam("txtModuleId") Integer moduleId,@RequestParam("txtopType") Integer opType, HttpSession session, HttpServletRequest request) {
        String retVal = "sessionexpired";
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		 List<Object[]> payList = clientService.getEventModePaymentType(clientId, objectID , payMode, payFor, moduleId);    
        		 retVal = encryptDecryptUtils.getOptions("selModeOfPayment",(opType == 0 || objectID == 0)?abcUtility.convert(payList):abcUtility.convertSelected(payList),false,"selected","");
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return retVal;
    }
    
    /**
     * Function for adding alter emailId
     * @param txtSearchString
     * @param txtSearchOpt
     * @param txTenderId
     * @param txtRowId
     * @param txtMappingType
     * @param txtTableId
     * @param request
     * @param modelMap
     * @return
     * @throws IOException 
     */
    
    @RequestMapping(value = "/ajaxcall/addalternateemailid", method = RequestMethod.POST)
    @ResponseBody
    public String addAlternateEmailId(@RequestParam("txtTenderId") Integer tenderId, @RequestParam("txtAltEmail") String emailAlt, 
    		@RequestParam("txtMapBidderId") int mapBidderId,@RequestParam("txtsaveOrUpdate") int altEmailId,
    		HttpServletRequest request, ModelMap modelMap, HttpServletResponse response,RedirectAttributes redirectAttributes) throws IOException {
    	StringBuilder retVal = new StringBuilder("");
    	try {
	        int userId = abcUtility.getSessionUserId(request); 
	        String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
	        boolean isEmailExists = commonService.checkAltEmailIdAlreadyExists(emailAlt,mapBidderId,tenderId,3);
	        boolean isEmailisBidder = commonService.checkAltEmailIdisBidderItself(emailAlt, mapBidderId);
	        
			TblMapAlternateEmailIds tblMapAlternateEmailIds = new TblMapAlternateEmailIds();
			
			tblMapAlternateEmailIds.setAlternateEmail(emailAlt);
			tblMapAlternateEmailIds.setMapBidderId(mapBidderId);
			tblMapAlternateEmailIds.setObjectId(tenderId);
			tblMapAlternateEmailIds.setTblModuleByModuleId(new TblModule(3));
			tblMapAlternateEmailIds.setIpAddress(ipAddress);
			tblMapAlternateEmailIds.setCreatedOn(new Date());
			tblMapAlternateEmailIds.setTblUserLogin(new TblUserLogin(userId));
			tblMapAlternateEmailIds.setIsActive(1);
			
			if(isEmailExists==true || isEmailisBidder==true)
			{
				retVal.append("true");
			}
			else
			{
				if(altEmailId==0)
				{
					tblMapAlternateEmailIdsDao.addTblMapAlternateEmailIds(tblMapAlternateEmailIds);
				}
				else
				{
				tblMapAlternateEmailIds.setAlternateEmailId(altEmailId);
				tblMapAlternateEmailIdsDao.updateTblMapAlternateEmailIds(tblMapAlternateEmailIds);
				
				}
				List<Object[]> listEmailIds = commonService.getEmailIdBasedOnMapBidderId(mapBidderId);
				for(Object[] object: listEmailIds){
					retVal.append("<tr><td><a href='javascript:void(0)' onclick='addEmailAddress("+object[2]+","+object[0]+")' id='altEmailLink_"+object[0]+"' >"+object[1]+"</a></td><td><a href='javascript:void(0)' title='Delete' onclick='deleteAltEmail("+object[2]+","+object[0]+")' class='delete-icn'>Delete</a></td></tr>");
					
				}
			}
				
			
			
			/*if(altEmailId==0)
			{
				if(isEmailExists==true || isEmailisBidder==true)
				{
					retVal.append("true");
				}
				else
				{
					tblMapAlternateEmailIdsDao.addTblMapAlternateEmailIds(tblMapAlternateEmailIds);
					List<Object[]> listEmailIds = commonService.getEmailIdBasedOnMapBidderId(mapBidderId);
					for(Object[] object: listEmailIds){
						retVal.append("<tr><td><a href='javascript:void(0)' onclick='addEmailAddress("+object[2]+","+object[0]+")' id='altEmailLink_"+object[0]+"' >"+object[1]+"</a></td><td><a href='javascript:void(0)' title='Delete' onclick='deleteAltEmail("+object[2]+","+object[0]+")' class='delete-icn'>Delete</a></td></tr>");
					}
				}
			}
			else
			{
				if(isEmailExists==true || isEmailisBidder==true)
				{
					retVal.append("true");
				}
				else
				{
					tblMapAlternateEmailIds.setAlternateEmailId(altEmailId);
					tblMapAlternateEmailIdsDao.updateTblMapAlternateEmailIds(tblMapAlternateEmailIds);
					List<Object[]> listEmailIds = commonService.getEmailIdBasedOnMapBidderId(mapBidderId);
					for(Object[] object: listEmailIds){
						retVal.append("<tr><td><a href='javascript:void(0)' onclick='addEmailAddress("+object[2]+","+object[0]+")' id='altEmailLink_"+object[0]+"' >"+object[1]+"</a></td><td><a href='javascript:void(0)' title='Delete' onclick='deleteAltEmail("+object[2]+","+object[0]+")' class='delete-icn'>Delete</a></td></tr>");
					}
				}
				
			}*/
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		finally{
			if(altEmailId==0)
			{
				auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, getAltEmailidSavedRemark, tenderId,tenderId,"");
			}
			else
			{
				auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, getAltEmailidUpdatedRemark, tenderId,tenderId,"");
			}
		}
		return retVal.toString(); 
    }
    
    
    /**
     * 
     * @param tenderId
     * @param emailAlt
     * @param mapBidderId
     * @param altEmailId
     * @param request
     * @param modelMap
     * @param response
     * @param redirectAttributes
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/ajaxcall/deletealtemailid", method = RequestMethod.POST)
    @ResponseBody
    public String deleteAltemailId(@RequestParam("txtMapBidderId") int mapBidderId,@RequestParam("txtalternateEmailId") Integer alternateEmailId,@RequestParam("txtTenderId") Integer tenderId,  
    		HttpServletRequest request, ModelMap modelMap, HttpServletResponse response,RedirectAttributes redirectAttributes) throws IOException {

    	StringBuilder retVal = new StringBuilder("");
    	commonService.updateTableField("TblMapAlternateEmailIds tblMapAlternateEmailIds","isActive","alternateEmailId",alternateEmailId,String.valueOf(0));
    	try {
    	List<Object[]> listEmailIds = commonService.getEmailIdBasedOnMapBidderId(mapBidderId);

    	for(Object[] object: listEmailIds){
			retVal.append("<tr><td><a href='javascript:void(0)' onclick='addEmailAddress("+object[2]+","+object[0]+")' id='altEmailLink_"+object[0]+"' >"+object[1]+"</a></td><td><a href='javascript:void(0)' title='Delete' onclick='deleteAltEmail("+object[2]+","+object[0]+")' class='delete-icn'>Delete</a></td></tr>");
		}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
    	finally{
    		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, getAltEmailidDeletedRemark, tenderId,tenderId,"");
    	}
    	return retVal.toString();
    }  
    
    /**
     * 
     * @param tenderId
     * @param request
     * @param modelMap
     * @param response
     * @param redirectAttributes
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/ajaxcall/checkenddateelapsed", method = RequestMethod.POST)
    @ResponseBody
    public String checkenddateelapsed(@RequestParam("txtTenderId") Integer tenderId,
    		HttpServletRequest request, ModelMap modelMap, HttpServletResponse response,RedirectAttributes redirectAttributes) throws IOException {
    	StringBuilder retVal = new StringBuilder("");

    	
		try {
			Date serverDate = commonService.getServerDateTime();
			Date endDate = null;
			boolean showlink=false;
			Object[] lstTender = commonService.getTenderFields(tenderId, "submissionStartDate,submissionEndDate");
			if(lstTender[1]!=null)
			{
				endDate=(Date)lstTender[1];
				showlink =  (endDate).before(serverDate);
			}
	       	if(showlink)
	       	{
	       		retVal.append("true");
	       	}
	       	else
	       	{
	       		retVal.append("false");
	       	}
	       	
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
    	return retVal.toString();
    }
    
    /**
     * @author Hardik Gohil
     * @used to access server Uptime Report page  
     * Project Task #54207
     */
    @RequestMapping(value = "common/serverUptimeReport/{enc}", method = RequestMethod.GET)
    public String serverUptimeReport(HttpServletRequest request,ModelMap modelMap) {
    	   try {
    		   String path=CommonController.class.getResource("/").toString().replace("WEB-INF/classes/",serverUptimeRreportPath).replace("file:/", "").replace("target"+request.getContextPath(),"src/main/webapp").replace("%20", " ");
               File file = new File(path);
               
               if(file.exists()) {
            	   modelMap.put("isFileExist", "Yes");
               }else {
            	   modelMap.put("isFileExist", "No");
               }
               
           } catch (Exception e) {
               return exceptionHandlerService.writeLog(e);
           }finally{
               auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),serverUptimeReportLinkId,msgGetServerUptimeReport,0,0);
           }
        return "/common/serverUptimeReport";
    }
    
    /**
     * @author Hardik Gohil
     * @used to download Server Uptime Report
     * Project Task #54207
     */
    @RequestMapping(value = "common/downloadServerUptimeReport/{enc}", method = RequestMethod.GET)
    public void downloadServerUptimeReport(HttpServletRequest request,HttpServletResponse resonse) throws IOException {
    	
    	try {
    		String path=CommonController.class.getResource("/").toString().replace("WEB-INF/classes/",serverUptimeRreportPath).replace("file:/", "").replace("target"+request.getContextPath(),"src/main/webapp").replace("%20", " ");
            File file = new File(path);

            resonse.setContentType("application/pdf");
            resonse.setHeader("Content-Disposition", "attachment;filename=" + file.getName());
            BufferedInputStream inStrem = new BufferedInputStream(new FileInputStream(file));
            BufferedOutputStream outStream = new BufferedOutputStream(resonse.getOutputStream());
            
            byte[] buffer = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = inStrem.read(buffer)) != -1) {
              outStream.write(buffer, 0, bytesRead);
            }
            outStream.flush();
            inStrem.close();
           
           } catch (Exception e) {
               exceptionHandlerService.writeLog(e);
           }finally{
               auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),serverUptimeReportLinkId,msgGetDownloadServerUptimeReport, 0,0);
           }

     }
    
    /**
     * @author Hardik Gohil
     * @used to access check DND page
     * Project Task #54694
     */
    @RequestMapping(value = "common/checkDND/{enc}", method = RequestMethod.GET)
    public String checkDND(HttpServletRequest request) {
    	   try {
               
           } catch (Exception e) {
               return exceptionHandlerService.writeLog(e);
           }finally{
               //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),LinkId,Remark, 0,0,"");
           }
        return "/common/checkDND";
    }
    
    /**
     * @author Hardik Gohil
     * @used to check dnd status of MobileNo
     * @param MobileNo
     * @param request
     * @return isDndAactive
     * Project Task #54694
     */
    @RequestMapping(value = "/ajaxcall/checkDND", method = RequestMethod.POST)
    @ResponseBody
    public String checkDND(@RequestParam("txtMobileNo") String txtMobileNo,HttpServletRequest request) {
 
    	String isDndAactive="";
    	
         try { 
	        	// Create a trust manager that does not validate certificate chains
	            TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
	                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                    return null;
	                }
	                public void checkClientTrusted(X509Certificate[] certs, String authType) {
	                }
	                public void checkServerTrusted(X509Certificate[] certs, String authType) {
	                }
	            } };
	                     
	            // Install the all-trusting trust manager
	            final SSLContext sc = SSLContext.getInstance("SSL");
	            sc.init(null, trustAllCerts, new java.security.SecureRandom());
	            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	            // Create all-trusting host name verifier
	            HostnameVerifier allHostsValid = new HostnameVerifier() {
	                public boolean verify(String hostname, SSLSession session) {
	                    return true;
	                }
	            };
	            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	        	 
	         	String url = "https://www.dndcheck.org/DndcheckApi/is_dnd";
	         	URL urlObj = new URL(url);
	     		HttpsURLConnection con = (HttpsURLConnection) urlObj.openConnection();
		     		//add reuqest header
		     		con.setRequestMethod("POST");
		     		con.setRequestProperty("User-Agent", "Mozilla/5.0");
		     		con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
		     		con.setReadTimeout(0);
		     		con.setDoInput(true);
		     		con.setDoOutput(true);
		     		con.setUseCaches(false);
		     		con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
	     		String urlParameters = "api_key=5q5CI0cCYM1g1Fm5&number="+txtMobileNo;
	     		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
		     		wr.writeBytes(urlParameters);
		     		wr.flush();
		     		wr.close();
		     		
		     	int responseCode = con.getResponseCode();
		     	if(responseCode==200){
		     		BufferedReader in = new BufferedReader(
		     		        new InputStreamReader(con.getInputStream()));
		     		String inputLine;
		     		StringBuffer response = new StringBuffer();
		
		     		while ((inputLine = in.readLine()) != null) {
		     			response.append(inputLine);
		     		}
		     		in.close();
		
		     		isDndAactive=response.toString();
		     	}
         } 
		 catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }
         finally{
             //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), LinkId,Remark, 0,0,"");
         }
		 
       return isDndAactive;
    }
    
    /**
     * @author Hardik Gohil
     * @used  to save all user dnd status
     * @return retVal
     * Project Task #54694
     */
    @RequestMapping(value = "/ajaxcall/saveAllUserDndStatus", method = RequestMethod.POST)
    @ResponseBody
    public String saveAllUserDndStatus() {
    	
    	String retVal="";
    	
         try { 
	        	// Create a trust manager that does not validate certificate chains
	            TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
	                public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                    return null;
	                }
	                public void checkClientTrusted(X509Certificate[] certs, String authType) {
	                }
	                public void checkServerTrusted(X509Certificate[] certs, String authType) {
	                }
	            } };
	                 
	            // Install the all-trusting trust manager
	            final SSLContext sc = SSLContext.getInstance("SSL");
	            sc.init(null, trustAllCerts, new java.security.SecureRandom());
	            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	            // Create all-trusting host name verifier
	            HostnameVerifier allHostsValid = new HostnameVerifier() {
	                public boolean verify(String hostname, SSLSession session) {
	                    return true;
	                }
	            };
	            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	        	 
	         	String url = "https://www.dndcheck.org/DndcheckApi/is_dnd";
	         
	         	List<Object[]> allTblUserLoginList=commonService.getAllTblUserLogin();
	         	List<TblUserDnd> tblUserDndList=new ArrayList<TblUserDnd>();
	         	Date createdOn=commonService.getServerDateTime();
	    
	         	for(Object[] user:allTblUserLoginList) {
	         		String isDndAactive="";
	         		Integer userId=Integer.parseInt(user[0].toString());
	        		String mobileNo=(String)user[1];
		     		TblUserDnd tblUserDnd= new TblUserDnd();
			     		tblUserDnd.setTblUserLogin(new TblUserLogin(userId));
			     		tblUserDnd.setMobileNo(mobileNo);
			     		tblUserDnd.setDndId(Integer.parseInt(user[2].toString()));
			     		tblUserDnd.setCreatedOn(createdOn);
		     		mobileNo=mobileNo.replaceFirst("\\+91", "");
		     
		     		if(mobileNo.length()==10) {
		     		 	URL urlObj = new URL(url);
			     		HttpsURLConnection con = (HttpsURLConnection) urlObj.openConnection();
				     		//add reuqest header
				     		con.setRequestMethod("POST");
				     		con.setRequestProperty("User-Agent", "Mozilla/5.0");
				     		con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
				     		con.setReadTimeout(0);
				     		con.setDoInput(true);
				     		con.setDoOutput(true);
				     		con.setUseCaches(false);
				     		con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
			     		String urlParameters = "api_key=5q5CI0cCYM1g1Fm5&number="+mobileNo;
			     		DataOutputStream wr = new DataOutputStream(con.getOutputStream());
				     		wr.writeBytes(urlParameters);
				     		wr.flush();
				     		wr.close();
			     		
			     		int responseCode = con.getResponseCode();
			     		if(responseCode==200) {
				     		BufferedReader in = new BufferedReader(
				     		        new InputStreamReader(con.getInputStream()));
				     		String inputLine;
				     		StringBuffer response = new StringBuffer();
				
				     		while ((inputLine = in.readLine()) != null) {
				     			response.append(inputLine);
				     		}
				     		in.close();
				
				    		isDndAactive=response.toString();
				    		if(isDndAactive.equalsIgnoreCase("true")) {
				    			tblUserDnd.setDndStatus(0);
				    		}else if(isDndAactive.equalsIgnoreCase("false")) {
				    			tblUserDnd.setDndStatus(1);
				    		}else {
				    			tblUserDnd.setDndStatus(2);
				    		}
			     		}else {
			     			tblUserDnd.setDndStatus(2);
			     		}		
			    		
		     		}else {
		     			tblUserDnd.setDndStatus(2);
		     		}
		     		
		     		tblUserDndList.add(tblUserDnd);
	         	}
	        	boolean sucess=commonService.addTblUserDnd(tblUserDndList);
	        	retVal= (sucess)?"true":"false";
         } 
		 catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }
         finally{
             //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), LinkId,Remark, 0,0,"");
         }
         
       return retVal;
    }
    @RequestMapping(value = "/ajax/getstateCodebyStateid", method = RequestMethod.POST)
    @ResponseBody
    public String getStateCodeListByStateId(@RequestParam("txtStateId") String stateId, HttpSession session, HttpServletRequest request) {
        String retVal = "sessionexpired";
        try {
        	if(abcUtility.getSessionUserId(request)!=0){
        		stateId = encryptDecryptUtils.decrypt(stateId);
        		retVal = commonService.getStateCodeByStateId(Integer.parseInt(stateId));
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, !"".equalsIgnoreCase(retVal) ? ajaxGetStateByCountryIdSuccessAuditMsg : ajaxGetStateByCountryIdFailAuditMsg, 0, countryId);
//        }
        return retVal;
    }
    
    
    
    /**
     * Generate OTP
     * @param request
     * @return message
     * Project Task #
     */
    @RequestMapping(value = "/ajaxcall/generateNewOTP", method = RequestMethod.POST)
    @ResponseBody
    public String generateNewOTP(@RequestParam("txtemailId") String emailId,@RequestParam("txtobjectId") String objectId, @RequestParam("txtlinkId") String linkId,HttpServletRequest request) {
    	JSONObject jsonObject=new JSONObject();
    	TblUserLogin tblUserLogin = null;
        int lengthofotp=4;
        int validityofotp=30;
    	try {
    		String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
    		int clientId=abcUtility.getSessionClientId(request);
    		
    		tblUserLogin = loginService.getUserLoginByLoginId(emailId);
    		
    		if(tblUserLogin != null){
    			int otp=commonService.genrateOtp(lengthofotp);
          	    java.util.Date enddate = commonService.getServerDateTimesaddminute(validityofotp);
          	    
          	    TblUserOtp  tblUserOtp = new TblUserOtp();
          	    tblUserOtp.setUserId(tblUserLogin.getUserId());
          	    tblUserOtp.setObjectId(Integer.parseInt(objectId)); 
          	    tblUserOtp.setOtp(otp);
          	    tblUserOtp.setStartDate(commonService.getServerDateTime());
          	    tblUserOtp.setEndDate(enddate);
          	    tblUserOtp.setIsRegistered(0);
          	    tblUserOtp.setIsVerified(0);
          	    tblUserOtp.setIpAddress(ipAddress);
          	    int otpId = tbluserotpservice.addUserOtp(tblUserOtp, Integer.parseInt(linkId), clientId); 
          	    if(otpId !=0){
          	    	Map<String, Object> paramMap = new HashMap<String, Object>();
    				paramMap.put("otp", otp);
    				boolean isIndian=commonService.getCountryIdByCompanyId(Integer.parseInt(String.valueOf(commonService.getCompanyIdByUserId(tblUserLogin.getUserId()))))==countryId;
    				smsContentUtillity.dynamicSMSGeneration(Integer.parseInt(linkId), tblUserLogin.getMobileNo(), msgResetPass,commonService.getSMSSenderIdFromLogo(request), paramMap,isIndian);   // 1. parameter link Id 2. mobile no 3. template string 4. sender Id as per client 5. dynamic parameters
        			
        			jsonObject.put("message", "success");
        			jsonObject.put("otpId", otpId);
        			jsonObject.put("otp", otp);
        			jsonObject.put("userId", tblUserLogin.getUserId());
          	    }else{
          	    	jsonObject.put("message", "failure");
          	    }
    		}else{
    			jsonObject.put("message", "");
    		}
         } 
		 catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }finally{
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(linkId), "generateNewOTP", 0,0,"");
         }
       return jsonObject.toString();
    }
  
    @RequestMapping(value = "/ajaxcall/enteredOTPVerify", method = RequestMethod.POST)
    @ResponseBody
    public String verfiyUserEnteredOTP(@RequestParam("txtlinkId") String linkId,@RequestParam("txtOTP") String otp,@RequestParam("userId") String userId,@RequestParam("otpId") String otpId,HttpServletRequest request) {
        String message="";
        TblUserOtp tbluserotp = null;
        boolean success = false;
    	try {
    		tbluserotp = tbluserotpservice.getUserOtp(Integer.parseInt(otpId));
    		if(tbluserotp != null && Integer.parseInt(otpId) == tbluserotp.getOtpId() && Integer.parseInt(otp) == tbluserotp.getOtp() && Integer.parseInt(userId)== tbluserotp.getUserId()){
    			success = tbluserotpservice.otpisverify(tbluserotp.getOtpId());	
    			if(success){
    				message ="OTPVerified";
    			}else{
    				message ="OTPExpired";
    			}
    		}else{
    			message ="OTPIncorrect";
    		}
         } 
		 catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }finally{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(linkId), "verfiyUserEnteredOTP", 0,0,"");
        }
       return message;
    }

    /**@PT #68147  Broker\Agent page 
     * @USE For auctiontiger.in Inquiry submit.
     * @author Dhruvil.panchal
     * @param request
     * @param map
     * @param response
     * @return
     * @throws Exception 
     */
    
    @RequestMapping(value ="/inquiryform", method = RequestMethod.GET)
	public String Inquiryform(HttpServletRequest request,ModelMap map, HttpServletResponse response) {
    	String pageName = null;
    	try {
			map.put("captchaHtml",AbcCaptchaFactory.newAbcCaptcha(0));
			URL url = new URL(request.getRequestURL().toString());
			String subdomainname = url.getHost();
			map.put("subdomainname",subdomainname);
			pageName = "Inquiryform";
    	}catch (MalformedURLException e) {
    		 return exceptionHandlerService.writeLog(e);
    	}
    	return pageName; 
    }
    
    @RequestMapping(value ="/submitinquiry", method = RequestMethod.POST)
    public String submitInquiryform(HttpServletRequest request,ModelMap map, HttpServletResponse response,RedirectAttributes redirectAttributes) {
    	String  pageName = "redirect:/inquiryform";
    	try {
			String name = request.getParameter("txtname");
			String email = request.getParameter("txtEmailId");
			String mobileNo = request.getParameter("txtPhone");
			String stateId = request.getParameter("StateId");
			String cityId = request.getParameter("cityId");
			URL baseurl = new URL(request.getRequestURL().toString());
			String domainName = baseurl.getHost();
     		String urlConnection=primeAuctionUrl+"/webservice/inquirysubmit";
     		URL url = new URL(urlConnection);
     		HttpURLConnection hConnection = (HttpURLConnection)
     		url.openConnection();
     		HttpURLConnection.setFollowRedirects( true );
     		hConnection.setDoOutput( true );
     	    hConnection.setRequestMethod("POST");	
     	    PrintStream ps = new PrintStream( hConnection.getOutputStream() );
     	    ps.print("name="+name+"&emailId="+email+"&stateId="+stateId+"&cityId="+cityId+"&mobileNo="+mobileNo+"&domainName="+domainName);
     	    ps.close();
     	    hConnection.connect();
     	    if( HttpsURLConnection.HTTP_OK == hConnection.getResponseCode() ){
     	    	redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_business_inquiry");
     	    }else {
     	    	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_common");
     	    }
    	}catch (Exception e) {
    		 return exceptionHandlerService.writeLog(e);
    	}
    	return pageName; 
    }
    
    @RequestMapping(value ="/webservice/primestate", method = RequestMethod.GET , produces = { "application/json" })
   	@ResponseBody
    public String getAuctionTigerState(HttpServletRequest request,ModelMap map, HttpServletResponse response) {
       	StringBuilder result = new StringBuilder();
       	try {
       		String urlConnection=primeAuctionUrl+"/webservice/getState";
     		URL url = new URL(urlConnection);
     		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    		conn.setRequestMethod("GET");
    		BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
    		if( HttpsURLConnection.HTTP_OK == conn.getResponseCode() ){
	    		String line;
	    		while ((line = rd.readLine()) != null) {
	    			result.append(line);
	    		}
    		}
    		rd.close();
       	}catch (Exception e) {
       		 return exceptionHandlerService.writeLog(e);
       	}
		return result.toString(); 
    }
    
    @RequestMapping(value ="/webservice/primecity/{stateId}", method = RequestMethod.GET , produces = { "application/json" })
    @ResponseBody
   	public String getAuctionTigerCityByStateId(@PathVariable("stateId") int stateId,HttpServletRequest request,ModelMap map, HttpServletResponse response) {
    	StringBuilder result = new StringBuilder();
       	try {
       		String urlConnection=primeAuctionUrl+"/webservice/getcity/"+stateId;
       		URL url = new URL(urlConnection);
       		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
    		conn.setRequestMethod("GET");
    		BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
    		if(HttpURLConnection.HTTP_OK == conn.getResponseCode()){
	    		String line;
	    		while ((line = rd.readLine()) != null) {
	    			result.append(line);
	    		}
    		}
    		rd.close();
   		}catch (Exception e) {
       		 return exceptionHandlerService.writeLog(e);
       	}
		return result.toString(); 
    }
	
	@RequestMapping(value="/downloadRegistry/{registryMode}", method=RequestMethod.GET)
    public void downloadReg(@PathVariable("registryMode") int registryMode, HttpServletRequest request, HttpServletResponse response){
		try {
			StringBuilder registryText = new StringBuilder();
			registryText.append("Windows Registry Editor Version 5.00\r\n");
	  
			  if(registryMode == 1 || registryMode == 2) {
				 URL url = new URL(request.getRequestURL().toString());
				 String[] clientName= request.getServerName().split("\\.");
				 int clientNameSize = clientName.length;
				 registryText.append("\r\n");
				 
				 if(clientNameSize == 1) {
					 registryText.append("[HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\ZoneMap\\Domains\\"+clientName[0]+"]\r\n");
				 }else if(clientNameSize == 2) {
					 registryText.append("[HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\ZoneMap\\Domains\\"+clientName[0]+"."+clientName[1]+"]\r\n");
				 }else {
					 registryText.append("[HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\ZoneMap\\Domains\\"+clientName[clientNameSize-2]+"."+clientName[clientNameSize-1]+"]\r\n");
					 registryText.append("\r\n");
					 registryText.append("[HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\ZoneMap\\Domains\\"+clientName[clientNameSize-2]+"."+clientName[clientNameSize-1]+"\\");
					 for(int i=0; i < clientNameSize-2; i++) {
						 registryText.append(clientName[i]);
						 if(i != clientNameSize-3) {
							 registryText.append(".");
						 }
					 }
					 registryText.append("]\r\n");
				 }
				 registryText.append("\""+(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "https")+"\"=dword:00000002\r\n ");
			  }
			  if(registryMode == 1) {
				  registryText.append("\r\n");
				  registryText.append("[HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones]\r\n");
				  registryText.append("@=\"\"\r\n");
				  registryText.append("\"SecuritySafe\"=dword:00000000\r\n");
				  registryText.append("\r\n");
				  registryText.append("[HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones\\2]\r\n");
				  registryText.append("@=\"\"\r\n");
				  registryText.append("\"DisplayName\"=\"Trusted sites\"\r\n");
				  registryText.append("\"PMDisplayName\"=\"Trusted sites [Protected Mode]\"\r\n");
				  registryText.append("\"Description\"=\"This zone contains websites that you trust not to damage your computer or data.\"\r\n");
				  registryText.append("\"1200\"=dword:00000000\r\n"); 
				  registryText.append("\"2201\"=dword:00000000\r\n"); 
				  registryText.append("\"1201\"=dword:00000000\r\n"); 
				  registryText.append("\"1208\"=dword:00000000\r\n"); 
				  registryText.append("\"1209\"=dword:00000000\r\n"); 
				  registryText.append("\"1405\"=dword:00000000\r\n"); 
				  registryText.append("\"2702\"=dword:00000000\r\n"); 
				  registryText.append("\"2000\"=dword:00000000\r\n"); 
				  registryText.append("\"120A\"=dword:00000000\r\n"); 
				  registryText.append("\"120B\"=dword:00000003\r\n"); 
				  registryText.append("\"1001\"=dword:00000000\r\n"); 
				  registryText.append("\"1004\"=dword:00000000\r\n");
				  registryText.append("\r\n");
				  registryText.append("[HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings\\Zones\\3]\r\n");
				  registryText.append("@=\"\"\r\n");
				  registryText.append("\"DisplayName\"=\"Internet\"\r\n");
				  registryText.append("\"PMDisplayName\"=\"Internet [Protected Mode]\"\r\n");
				  registryText.append("\"Description\"=\"This zone contains all websites you haven't placed in other zones\"\r\n");
				  registryText.append("\"1200\"=dword:00000000\r\n"); 
				  registryText.append("\"2201\"=dword:00000000\r\n"); 
				  registryText.append("\"1201\"=dword:00000000\r\n"); 
				  registryText.append("\"1208\"=dword:00000000\r\n"); 
				  registryText.append("\"1209\"=dword:00000000\r\n"); 
				  registryText.append("\"1405\"=dword:00000000\r\n"); 
				  registryText.append("\"2702\"=dword:00000000\r\n"); 
				  registryText.append("\"2000\"=dword:00000000\r\n"); 
				  registryText.append("\"120A\"=dword:00000000\r\n"); 
				  registryText.append("\"120B\"=dword:00000003\r\n"); 
				  registryText.append("\"1001\"=dword:00000000\r\n"); 
				  registryText.append("\"1004\"=dword:00000000\r\n");
			  }
		  	 
	  	 	if(registryMode == 1) {
	  	 		response.addHeader("Content-Disposition", "attachment; filename=EnableActiveX-AddTrustedSite.reg");
	  	 	}else if(registryMode == 2) {
	  	 		response.addHeader("Content-Disposition", "attachment; filename=AddTrustedSite.reg");
	  	 	}
	  	 
    		ServletOutputStream outputStream = response.getOutputStream();
	  		outputStream.write(registryText.toString().getBytes());
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
    }
	

    @RequestMapping(value="/crawling", method=RequestMethod.GET)
    public String getCrawling(HttpServletRequest request, ModelMap modelMap,RedirectAttributes redirectAttributes){
    	String retval = "common/Crawling";
         try{
        	 	boolean isCrwalIp = false;
	         	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
	         	for(String validIp :  crawlIpAddress){
	         		if(validIp.equals(ipAddress)){
	         			isCrwalIp = true;
	         			break;
	         		}
	         	}
	         	if(isCrwalIp){
                List<SelectItem> domainNamelst = new ArrayList<SelectItem>();
                domainNamelst = clientService.getActiveClient();
               modelMap.addAttribute("selDomainName", domainNamelst);
               
               List<SelectItem> ls=new ArrayList<SelectItem>();
               ls.add(new SelectItem("Tender","1"));
               ls.add(new SelectItem("Auction","2"));
    
               modelMap.addAttribute("ModuleNamelst",ls);
               
	         	}
	         	else {
	        	 retval = "redirect:/";
	         	}
                return retval;
    	}catch(Exception e){
    		exceptionHandlerService.writeLog(e);
    	}finally{
    		//auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), cancelledChequedocUploadLinkId, getCancelledUploadChequeDocumentsRemark, processId, 0);
    	}
    	return retval;
    }
    
    @RequestMapping(value ="/postcrawl", method = RequestMethod.POST)
    public String postCrawling(HttpServletRequest request,ModelMap map, HttpServletResponse response,RedirectAttributes redirectAttributes) {
    	String retval = "common/Crawling";
    	int clientId=0;
    	String date = "";
    	List<Object[]> lstClienttenderdetails = null;
    	List<Object[]> lstClientAuctiondetails = null;
    	List<Object[]> clientDateFormate = null;
    	try {
    		boolean isCrwalIp = false;
         	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
         	for(String validIp :  crawlIpAddress){
         		if(validIp.equals(ipAddress)){
         			isCrwalIp = true;
         			break;
         		}
         	}
         	if(isCrwalIp){
    		clientId =Integer.parseInt(request.getParameter("seldomainNames")); //yyyy-MM-dd HH:mm:ss.SSSselectedDomain
     		String selectedDomain =request.getParameter("setDomain");
     		String Module=request.getParameter("setModule");
			date = request.getParameter("txtDateFrom");
			SimpleDateFormat df = new SimpleDateFormat(CommonUtility.getClientDateFormat());
			if(Module.equalsIgnoreCase("Tender"))
			{
				lstClienttenderdetails = clientService.getClientAndTenderDetails(clientId,df.parse(date));
				map.put("lstClienttenderdetails", lstClienttenderdetails);
				map.put("lstClientAuctiondetails", lstClientAuctiondetails);
			}
			else
			{
				lstClientAuctiondetails = clientService.getClientAndAuctionDetails(clientId,df.parse(date));
				map.put("lstClientAuctiondetails", lstClientAuctiondetails);
				map.put("lstClienttenderdetails", lstClienttenderdetails);
			}
			clientDateFormate = clientService.getClientDateFormate(clientId);
			 List<SelectItem> domainNamelst = new ArrayList<SelectItem>();
             domainNamelst = clientService.getActiveClient();
             map.addAttribute("selDomainName", domainNamelst);
             map.addAttribute("selectedDomain",selectedDomain);
             map.addAttribute("clientDateFormate",clientDateFormate.get(0));
             List<SelectItem> ls = new ArrayList<SelectItem>();
             ls.add(new SelectItem("Tender","1"));
             ls.add(new SelectItem("Auction","2"));
             map.addAttribute("ModuleNamelst", ls);
              
         	}
         	else {
         		retval = "redirect:/";
         	}
             
		} catch (Exception e) {
			e.printStackTrace();
			exceptionHandlerService.writeLog(e);
		}
    	return retval;
    	
    	}
    
    @RequestMapping(value = "/viewtenderevent/{tenderId}/{domainName:.+}", method = RequestMethod.GET)
    public String getEventView(HttpServletRequest request, ModelMap modelMap,RedirectAttributes redirectAttributes,@PathVariable("tenderId") int tenderId,@PathVariable("domainName")String domainName){
	    String retVal = "";
    	try {
    		redirectAttributes.addAttribute("crawlingPage", "123");
	    	retVal = "redirect:"+request.getScheme()+"://"+domainName+":"+request.getServerPort()+request.getContextPath()+"/viewtender/"+tenderId;
	    } catch (Exception e) {
			e.printStackTrace();
			exceptionHandlerService.writeLog(e);
		}
	    return retVal;
    }
    
    @RequestMapping(value = "/viewauctionevent/{auctionId}/{domainName:.+}", method = RequestMethod.GET)
    public String getAuctionView(HttpServletRequest request, ModelMap modelMap,RedirectAttributes redirectAttributes,@PathVariable("auctionId") int auctionId,@PathVariable("domainName")String domainName){
	    String retVal = "";
    	try {
    		redirectAttributes.addAttribute("crawlingPage", "123");
	    	retVal = "redirect:"+request.getScheme()+"://"+domainName+":"+request.getServerPort()+request.getContextPath()+"/viewauction/"+auctionId+"/1/0";
	    } catch (Exception e) {
			e.printStackTrace();
			exceptionHandlerService.writeLog(e);
		}
	    return retVal;
    }
	
	
    
    @RequestMapping(value = {"/common/createPaymentITSDetail/{objectId}/{linkId}/{moduleId}/{opType}/{enc}", "/common/viewPaymentITSDetail/{objectId}/{linkId}/{moduleId}/{opType}/{enc}"}, method = RequestMethod.GET)
    public String createPaymentITSDetail(@PathVariable("objectId") int objectId,@PathVariable("linkId") int linkId,@PathVariable("moduleId") int moduleId,@PathVariable("opType") String opType,ModelMap modelMap,HttpServletRequest request) {
       String retVal="common/CreatePaymentITSDetail";
       String auditMsg = getPaymentITSDetailpage;
        try {
	        	int clientId = abcUtility.getSessionClientId(request);
	        	int eventDeptOfficer=0;
	    		if(moduleId == 5){
	    			commonService.commonauctionSummary(objectId, modelMap, clientId);
	    			List<Object[]> auctionFields = commonService.getAuctionFields(objectId, "auctioneerId,auctionId");
	    			if(!auctionFields.isEmpty() && auctionFields != null){
	    				eventDeptOfficer = Integer.valueOf(auctionFields.get(0)[0].toString());
	    			}
	    		}else if(moduleId == 3){
	    			commonService.commontenderSummary(objectId, modelMap, clientId);
	    			eventDeptOfficer = (Integer) modelMap.get("officerId");
	    		}
	    		
	    		if(opType.equalsIgnoreCase("create") || opType.equalsIgnoreCase("edit")){
	    			List<TblPaymentITSDetail> tenderITSPaymentDetail = commonService.getPaymentITSDetailByObjectId(objectId,moduleId,-1); //no need to add isActive condition
	    			List<Object> paymentITSOfficerEmail = commonService.getPaymentITSDetailByOfficerId(eventDeptOfficer,0,-1); //no need to add isActive condition
	    			if(tenderITSPaymentDetail!=null && !tenderITSPaymentDetail.isEmpty()){
	    				modelMap.addAttribute("userEmail", tenderITSPaymentDetail.get(0).getEmailId());
	    				modelMap.addAttribute("address", tenderITSPaymentDetail.get(0).getAddress());
	    				modelMap.addAttribute("amount", tenderITSPaymentDetail.get(0).getAmount());
	    				modelMap.addAttribute("minmaxAmount", tenderITSPaymentDetail.get(0).getMinMaxAmount());
	    				modelMap.addAttribute("leadId", tenderITSPaymentDetail.get(0).getLeadId());
	    				modelMap.addAttribute("paymentITSId", tenderITSPaymentDetail.get(0).getPaymentITSId());
	    			}else if (paymentITSOfficerEmail!=null && !paymentITSOfficerEmail.isEmpty()){
	    				List<SelectItem> lst = new ArrayList<SelectItem>();
	    				for(Object paymentITSDetail : paymentITSOfficerEmail){
	    					lst.add(new SelectItem(paymentITSDetail,1));
	    				}
	    				lst.add(new SelectItem("other",2));
	    				modelMap.addAttribute("paymentDetail", lst);
	    			}else{
	    				modelMap.addAttribute("userEmail", commonService.getEmailByUserId(eventDeptOfficer));
	    			}
	    		}else{
	    			List<TblPaymentITSDetail> tenderITSPaymentDetail = commonService.getPaymentITSDetailByObjectId(objectId,moduleId,1);
	    			if(tenderITSPaymentDetail!=null && !tenderITSPaymentDetail.isEmpty()){
	    				modelMap.addAttribute("eventPaymentITSDetail", tenderITSPaymentDetail.get(0));
	    			}
	    			auditMsg = getPaymentITSDetailviewpage;
	    		}
	    		
                modelMap.put("objectId", objectId);
                modelMap.put("moduleId", moduleId);
                modelMap.put("linkId",linkId);
                modelMap.put("eventDeptOfficer", eventDeptOfficer);
                modelMap.put("opType",opType);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally {
        	if(moduleId == 3)
        	{
        		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, auditMsg, objectId,objectId, "");
        	}
        	else
        	{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, auditMsg, objectId,objectId, "");
        	}
        }
        return retVal;
    }	
    
    @RequestMapping(value="/common/ajax/getPaymentITSDetailByEmail", method=RequestMethod.POST)
    @ResponseBody
	public String getPaymentITSDetailByEmail(@RequestParam("txtEmailId") String txtEmailId, HttpServletRequest request,ModelMap modelMap){
    	StringBuilder data = new StringBuilder("sessionexpired");
		try {
			if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
				List<Object> paymentAddDetail = commonService.getPaymentITSDetailByEmailId(txtEmailId);
				data.setLength(0);
				if(paymentAddDetail!=null && !paymentAddDetail.isEmpty()){
					data.append("<table width='100%'>");
	            	
	            	for(Object object: paymentAddDetail){
	            		int addLen = object.toString().length();
	            		data.append("<tr>");
	            		data.append("<td width='100%' colspan='2'> ");
	                	data.append("<label><input id='rdAddressList' type='radio' value='1'' name='rdAddressList' onclick='changeAddress()' ");
	                	data.append("/>");
	                	data.append("<span class=\"label-span m-top1").append("\" id=\"sprdAddressList\">").append(addLen > 100 ? object.toString().substring(0,100) : object.toString()).append("</span>&nbsp;&nbsp;</label>&nbsp;&nbsp;");
	                	data.append("</td>");
	                	data.append("</tr>");
	            	}
	            	data.append("<tr>");
            		data.append("<td width='100%' colspan='2'> ");
	            	data.append("<label><input id='rdAddressList' type='radio' value='2'' name='rdAddressList' onclick='changeAddress()' ");
                	data.append("/>");
                	data.append("<span class=\"label-span m-top1").append("\" id=\"sprdAddressList\"> other ").append("</span>&nbsp;&nbsp;</label>&nbsp;&nbsp;");
                	data.append("</td>");
                	data.append("</tr>");
                	data.append("</table>");
	            }
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return data.toString();
	}
    
    @RequestMapping(value="/common/ajax/checkLeadIdExists", method=RequestMethod.POST,produces = "application/json")
	@ResponseBody
	public String checkLeadIdExists(@RequestParam("txtLeadId") String txtLeadId,  HttpServletRequest request){
    	String data = "";
		try {
			if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null){
				data = getResponseFromITS(txtLeadId);
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return data;
	}
    
    @RequestMapping(value = "/submitpaymentitsdetail", method = RequestMethod.POST)
    public String submitPaymentITSDetail(HttpServletRequest request,RedirectAttributes redirectAttributes) {
        String returnStr = "";
        int hdobjectId = 0;
        int hdmoduleId = 0;
        int hdlinkId=0;
        String redirectMsg = "msg_sucess_ITSPayment_detail";
        String auditMsg = postPaymentITSDetailpage;
        try {
            int userId = abcUtility.getSessionUserId(request);
            int sessonUserDetailId = abcUtility.getSessionUserDetailId(request);
            int clientId = abcUtility.getSessionClientId(request);
            if(userId!=0 && sessonUserDetailId!=0){
                boolean isSuccess = false;
                String address = StringUtils.hasLength(request.getParameter("txtaAddress")) ? request.getParameter("txtaAddress") : "";
                String email = StringUtils.hasLength(request.getParameter("txtEmailId")) ? request.getParameter("txtEmailId") : "";
                String amount = StringUtils.hasLength(request.getParameter("txtAmount")) ? request.getParameter("txtAmount") : "";
                String minMaxAmt = StringUtils.hasLength(request.getParameter("txtminMaxAmount")) ? request.getParameter("txtminMaxAmount") : "";
                String leadId = StringUtils.hasLength(request.getParameter("txtLeadId")) ? request.getParameter("txtLeadId") : "0";
                hdobjectId = StringUtils.hasLength(request.getParameter("hdobjectId")) ? Integer.parseInt(request.getParameter("hdobjectId")) : 0;
                hdmoduleId = StringUtils.hasLength(request.getParameter("hdmoduleId")) ? Integer.parseInt(request.getParameter("hdmoduleId")) : 0;
                hdlinkId = StringUtils.hasLength(request.getParameter("hdlinkId")) ? Integer.parseInt(request.getParameter("hdlinkId")) : 0;
                String hdeventTypeId = StringUtils.hasLength(request.getParameter("hdeventTypeId")) ? request.getParameter("hdeventTypeId") : "0";
                int officerId = StringUtils.hasLength(request.getParameter("hdofficerId")) ? Integer.parseInt(request.getParameter("hdofficerId")) : 0;
                int paymentITSId = StringUtils.hasLength(request.getParameter("hdpaymentITSId")) ? Integer.parseInt(request.getParameter("hdpaymentITSId")) : 0;
                //paymentStatus = 0 (add payment detail) , 1 (edit payment detail) , 2 (payment detail send to ITS) 
                int paymentStatus = StringUtils.hasLength(request.getParameter("txtAction")) ? Integer.parseInt(request.getParameter("txtAction")) : 0;
                if(paymentStatus==0 || paymentStatus==1){
                List<TblPaymentITSDetail> tblPaymentITSDetails = new ArrayList();
                TblPaymentITSDetail tblPaymentITSDetail = new TblPaymentITSDetail();
                tblPaymentITSDetail.setObjectId(hdobjectId);
                tblPaymentITSDetail.setModuleId(hdmoduleId);
                tblPaymentITSDetail.setTblEventType(new TblEventType(Integer.parseInt(hdeventTypeId)));
                tblPaymentITSDetail.setOfficerId(officerId);
                tblPaymentITSDetail.setEmailId(email);
                tblPaymentITSDetail.setAddress(address);
                tblPaymentITSDetail.setAmount(amount);
                tblPaymentITSDetail.setMinMaxAmount(minMaxAmt);
                tblPaymentITSDetail.setLeadId(leadId);
                tblPaymentITSDetail.setCreatedBy(sessonUserDetailId);
                tblPaymentITSDetail.setIsActive(0);
                tblPaymentITSDetail.setClientId(clientId);
                tblPaymentITSDetail.setServerCode(2);
                tblPaymentITSDetail.setCompanyId(0);
                if(paymentITSId!=0){
                	tblPaymentITSDetail.setPaymentITSId(paymentITSId);
                }
                tblPaymentITSDetails.add(tblPaymentITSDetail);
                isSuccess = commonService.addTblPaymentITSDetail(tblPaymentITSDetails,hdobjectId,hdmoduleId);
                }else{
                	isSuccess = commonService.updatePaymentITSDetail(hdobjectId, hdmoduleId); 
                	auditMsg = postPaymentDetailSendtoITS;
                }
                if(isSuccess){      
                	if(paymentStatus==2){
                		redirectMsg = "msg_sucess_paymentdetail_sendto_ITS";
                	}
                    if(hdmoduleId == 3){
                    	returnStr = "etender/buyer/tenderdashboard/"+hdobjectId+"/1";
                    	returnStr = "redirect:/"+returnStr + encryptDecryptUtils.generateRedirect(returnStr, request);
            		}else{
            			returnStr = "eauction/auctioneer/auctiondashboard/"+ hdobjectId + "/1";
                    	returnStr = "redirect:/"+returnStr + encryptDecryptUtils.generateRedirect(returnStr, request);
            		}
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),redirectMsg);
                }else{
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
                    returnStr = "redirect:/common/createPaymentITSDetail/"+hdobjectId+"/1/"+hdmoduleId+encryptDecryptUtils.generateRedirect("common/createPaymentITSDetail/"+hdobjectId+"/1/"+hdmoduleId, request);
                }
            }else{
                return REDIRECT_SESSION_EXPIRED;
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
        	if(hdmoduleId == 3)
        	{
        		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),hdlinkId, auditMsg, hdobjectId,hdobjectId, "");
        	}
        	else
        	{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),hdlinkId, auditMsg, hdobjectId,hdobjectId, "");
        	}
        }
        return returnStr;
    }
	
    private String getResponseFromITS(String leadId) throws Exception {
        HttpURLConnection conn = null;
        OutputStream os = null;
        JSONObject obj = new JSONObject();
        try {
        	String leadParam = "{\n" + "\"LeadId\":"+leadId+" \r\n}";
        
        	URL url = new URL(ITSLeadvalidateurl);
    		conn = (HttpURLConnection) url.openConnection();
    		conn.setDoOutput(true);
    		conn.setRequestMethod("POST");
    		conn.setRequestProperty("Content-Type", "application/json");
    		conn.setRequestProperty("apiKey", ITSLeadAPIKEY);
    		
    		os = conn.getOutputStream();
    		os.write(leadParam.getBytes());
    		os.close();
    		String responseString = "";
    		if(conn.getResponseCode()==200){
    			BufferedReader streamReader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
    			String inputStr;
                while ((inputStr = streamReader.readLine()) != null) {
                	 responseString += inputStr;
                }
                JSONObject response = new JSONObject(responseString.toString());
        		JSONObject jsonResponse = new JSONObject(response.getString("d"));
        		obj.put("IsLeadAvailable", jsonResponse.getString("IsLeadAvailable"));
        		obj.put("companyName", jsonResponse.getString("CompanyName"));
    		}
        } catch (Exception ex) {
        	 exceptionHandlerService.writeLog(ex);
        }
        return obj.toString();
    }
    @RequestMapping(value = "/getValidIssuer", method = RequestMethod.POST,produces = "application/json")
    @ResponseBody
    public String getValidIssuer(@RequestParam("Issuer") String Issuer,@RequestParam("certAliasSerialjson") String certAliasSerialjson,  HttpServletRequest request)throws Exception{
		JSONObject obj = new JSONObject();
    	try {
    		JSONParser parser = new JSONParser();
    		org.json.simple.JSONObject json =  (org.json.simple.JSONObject) parser.parse(certAliasSerialjson);
    		
    		for(int j = 1;j<=json.size();j++){
    			String aliasNserial = json.get(j+"").toString();
    			String[] aliasNserial2 = aliasNserial.split("```");
    			if(!commonService.checkCertRevoked(aliasNserial2[1])){
    				obj.put(aliasNserial2[0],aliasNserial2[1]); //aliasNserial2[1] == serial number & aliasNserial2[0] == aliasname
    			}
    		}
    		List<String> list = new ArrayList<String>(Arrays.asList(Issuer.split("===")));
			List<TblIssuer> issuerList = manageContentService.getIssuerList();
			boolean checkIssuer = false;
			for (int i = 0; i < list.size(); i++) {
				checkIssuer = issuerList.toString().contains("'"+list.get(i).toString()+"'");
				if(checkIssuer){
					obj.put(list.get(i),checkIssuer); // checkIssuer == boolean & list.get(i) == Issuer
				}
			}
		} catch (JSONException e) {
			return exceptionHandlerService.writeLog(e);
		}
    	return obj.toString();
    }
    
    @RequestMapping(value = "/common/ajax/getGstValidate",method = RequestMethod.POST)
    @ResponseBody
    public String getGstValidate(@RequestParam("txtGstNo") String gstNo,HttpServletRequest request) throws Exception{
    	HttpsURLConnection conn = null;
    	String isValid = "false";
    	try{
    		URL url = new URL(gstValidateUrl+gstNo);
    		conn = (HttpsURLConnection) url.openConnection();
    		SSLSocketFactory sslSocketFactory = createTrustAllSslSocketFactory();
    		conn.setSSLSocketFactory(sslSocketFactory);
    		conn.setRequestMethod("GET");
    		conn.setDoOutput(true);
    		conn.connect();
    		BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
    		if(HttpURLConnection.HTTP_OK == conn.getResponseCode()){
	    		String line;
	    		while ((line = rd.readLine()) != null) {
	    			isValid = "true";
	    		}
    		}
    		rd.close();
    	
    	}catch(Exception e){
    		if(conn.getResponseCode()==400){
    			exceptionHandlerService.logToFile(e);
    		}else{
    			exceptionHandlerService.writeLog(e);
    		}
    		isValid = "false";
    	}
    	return isValid;
    }
    private static SSLSocketFactory createTrustAllSslSocketFactory() throws Exception {
        TrustManager[] byPassTrustManagers = new TrustManager[] { new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }

            public void checkClientTrusted(X509Certificate[] chain, String authType) {
            }

            public void checkServerTrusted(X509Certificate[] chain, String authType) {
            }
        } };
        SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
        sslContext.init(null, byPassTrustManagers, new SecureRandom());
        return sslContext.getSocketFactory();
    }
    @RequestMapping(value = {"/etender/buyer/mapAuthorizedEvent/{eventId}/{moduleId}/{eventTypeId}/{enc}", "/eauction/buyer/mapAuthorizedEvent/{eventId}/{moduleId}/{eventTypeId}/{enc}"}, method = RequestMethod.GET)
    public String mapAuthorizedUserWithEvent(@PathVariable("eventId") int objectId,@PathVariable("moduleId") int moduleId,@PathVariable("eventTypeId") int eventTypeId,ModelMap modelMap, HttpServletRequest request)
    {
    	String pageName="common/MapAuthorizedUserWithEvent";
    	
    	boolean isEdit=false;
    	try 
    	{
    		  ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	  int clientId=clientBean.getClientId();  
    		  modelMap.addAttribute("minMember",1);
    		  modelMap.addAttribute("eventId",objectId);
        	  modelMap.addAttribute("moduleId",moduleId);
        	  modelMap.addAttribute("eventTypeId",eventTypeId);
        	  modelMap.addAttribute("clientId",clientId);
        	  List<Object[]> userData=commonService.getAuthorizedUserForEvent(clientId,objectId,moduleId,eventTypeId);
        	  if(moduleId==5){
                  commonService.commonauctionSummary(objectId, modelMap, abcUtility.getSessionClientId(request));
              }else if(moduleId==3){
                  commonService.commontenderSummary(objectId, modelMap, abcUtility.getSessionClientId(request));
              }
        	  if(userData != null && !(userData.isEmpty()))
			  {
        		  isEdit=true;
        		  modelMap.addAttribute("isEdit",isEdit);
        		  modelMap.addAttribute("userData",userData);
			  }
        	  
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
    	finally {
    		if(moduleId == 3)
        	{
        		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),mapAuthorizedUserTenderLink, getMapAuthorizedUserTender, objectId,0, "");
        	}
        	else
        	{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),mapAuthorizedUserAuctionLink, getMapAuthorizedUserAuction, objectId,0, "");
        	}
    	}
    	
    	return pageName;
    }
    @RequestMapping(value = {"/etender/buyer/mapUserWithEvent" , "/eauction/buyer/mapUserWithEvent"} , method = RequestMethod.POST)
    public String mapUserWithEvent(HttpServletRequest request, RedirectAttributes redirectAttributes) 
    {
		
		  int clientId=0;
		  String returnPage=null;
		  int objectId=0;
		  int moduleId=0; 
		  int eventTypeId=0;
		  boolean isSuccess=false;
		  int createdBy=0; 
		  String ipaddress=request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
		  try 
		  { 
			  	clientId = abcUtility.getSessionClientId(request);
			  	createdBy = abcUtility.getSessionUserDetailId(request);
			  	objectId = StringUtils.hasLength(request.getParameter("hdEventId")) ? Integer.parseInt(request.getParameter("hdEventId")) : 0;
			  	moduleId=StringUtils.hasLength(request.getParameter("hdModuleId")) ? Integer.parseInt(request.getParameter("hdModuleId")) : 0;
			    eventTypeId=StringUtils.hasLength(request.getParameter("hdEventTypeId")) ? Integer.parseInt(request.getParameter("hdEventTypeId")) : 0;
			    if(moduleId == 3){
			    	returnPage = "etender/buyer/tenderdashboard/"+objectId+"/1";
			    	returnPage = "redirect:/"+returnPage + encryptDecryptUtils.generateRedirect(returnPage, request);
        		}else{
        			returnPage = "eauction/auctioneer/auctiondashboard/"+ objectId + "/1";
        			returnPage = "redirect:/"+returnPage + encryptDecryptUtils.generateRedirect(returnPage, request);
        		}
			    String[] officerIds=null ;
			    if(request.getParameterValues("hdOfficerId") != null) {
			    	officerIds=request.getParameterValues("hdOfficerId");	
			    }
			    List<TblMapAuthUser> mappedUserd=new ArrayList<TblMapAuthUser>();
			    List<TblMapAuthUser> mappedUpdatedUserd=new ArrayList<TblMapAuthUser>();
			    TblEventType eventType=tblEventTypeDao.findTblEventType("eventTypeId",Operation_enum.EQ,eventTypeId).get(0);
			    TblModule module=tblModuleDao.findTblModule("moduleId",Operation_enum.EQ,moduleId).get(0);
			    List<Object[]> userData=commonService.getAuthorizedUserForEvent(clientId,objectId,moduleId,eventTypeId);
			    if(userData == null || (userData.isEmpty()))
			    {
			    	if(officerIds != null)
			    	{
			    		for(String userId:officerIds)
					    {
					    	TblUserLogin userLogin=tblUserLoginDao.findTblUserLogin("userId",Operation_enum.EQ,Integer.parseInt(userId)).get(0);
					    	TblMapAuthUser tblMapAuthUser=new TblMapAuthUser();
					    	tblMapAuthUser.setClientId(clientId);
					    	tblMapAuthUser.setCreatedBy(createdBy);
					    	tblMapAuthUser.setCreatedOn(commonService.getServerDateTime());
					    	tblMapAuthUser.setIsActive(1);
					    	tblMapAuthUser.setObjectId(objectId);
					    	tblMapAuthUser.setTblEventType(eventType);
					    	tblMapAuthUser.setTblModule(module);
					    	tblMapAuthUser.setTblUserLogin(userLogin);
					    	mappedUserd.add(tblMapAuthUser);
					    	tblMapAuthorisedUserDao.saveUpdateAllTblMapAuthUser(mappedUserd);
					    	isSuccess=true;
					    }
			    	}
			    }
			    else 
			    {
			    	if(userData != null && !userData.isEmpty())
			    	{
			    		for(Object[] o:userData)
						{
							TblMapAuthUser user=  tblMapAuthorisedUserDao.findTblMapAuthUser("mapAuthUserId",Operation_enum.EQ,(Integer)o[5]).get(0);
							user.setIsActive(0);
							tblMapAuthorisedUserDao.updateTblMapAuthUser(user);
						}
			    	}
					if(officerIds != null)
					{
						for(String userId:officerIds)
					    {
					    	TblUserLogin userLogin=tblUserLoginDao.findTblUserLogin("userId",Operation_enum.EQ,Integer.parseInt(userId)).get(0);
					    	TblMapAuthUser tblMapAuthUser=new TblMapAuthUser();
					    	tblMapAuthUser.setClientId(clientId);
					    	tblMapAuthUser.setCreatedBy(createdBy);
					    	tblMapAuthUser.setCreatedOn(commonService.getServerDateTime());
					    	tblMapAuthUser.setIsActive(1);
					    	tblMapAuthUser.setObjectId(objectId);
					    	tblMapAuthUser.setTblEventType(eventType);
					    	tblMapAuthUser.setTblModule(module);
					    	tblMapAuthUser.setTblUserLogin(userLogin);
					    	mappedUserd.add(tblMapAuthUser);
					    	tblMapAuthorisedUserDao.saveUpdateAllTblMapAuthUser(mappedUserd);
					    	isSuccess=true;
					    }
					}
					else {
				    	isSuccess=true;
					}
				}
		  }
		  catch(Exception e) 
		  {
				exceptionHandlerService.writeLog(e); 
		  } finally 
		  {
			  if(moduleId == 3)
	        	{
	        		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),mapAuthorizedUserTenderLink, postMapAuthorizedUserTender, objectId,0, "");
	        	}
	        	else
	        	{
	        		auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),mapAuthorizedUserAuctionLink,postMapAuthorizedUserAuction,ipaddress,objectId,0,"");
	        	}
		  }
		  redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_update_authorized_user_success" : "redirect_failure_common");
    	return returnPage;
    }
    
    /**
	 * @author jayesh.t
	 *
	 * @param modelMap
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/common/eventInquiryReport/{enc}", method = RequestMethod.GET)
	public String eventInquiryReport(ModelMap modelMap, HttpServletRequest request) {
		 try {
	        	int clientId =abcUtility.getSessionClientId(request);
	            
	            modelMap.addAttribute("reportId", eventInquiryReportId);
	        	reportGeneratorService.getReportConfigDetails(eventInquiryReportId, modelMap);
	        	
	        } catch (Exception ex) {
	            return exceptionHandlerService.writeLog(ex);
	        } finally {
	            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), eventInquiryReportLinkId, getEventInquiryReportRemark, 0, 0);
	        }
		
		 
		return "common/admin/EventInquiryReport";
	}
	
	/*
	 * @Author : Hema.Barmeda
	 * Manage Annexure 
	 * 
	 * */
	@RequestMapping(value = "/common/manageannexure/{enc}", method = RequestMethod.GET)
    public String manageAnnexure(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", manageAnnexureReportId);
            reportGeneratorService.getReportConfigDetails(manageAnnexureReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageAnnexureLinkId, getManageAnnexureRemark, 0, 0);
        }
        return "common/ManageAnnexure";
    }
	
	/*
	 * @Author : Hema.Barmeda
	 * Manage Annexure Type Master
	 * 
	 * */
	@RequestMapping(value = "/common/manageannexuretype/{enc}", method = RequestMethod.GET)
    public String manageAnnexureType(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", manageAnnexureTypeReportId);
            reportGeneratorService.getReportConfigDetails(manageAnnexureTypeReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageAnnexureLinkId, getManageAnnexureRemark, 0, 0);
        }
        return "common/ManageAnnexureType";
    }
	
	/*
	 * @Author : Hema.Barmeda
	 * Create Annexure Type Master
	 * 
	 * */
	@RequestMapping(value = {"/common/createannexuretype/{clmAnnexureTypeId}/{enc}"}, method = RequestMethod.GET)     
	 public String loadContractDocPage(@PathVariable("clmAnnexureTypeId") int clmAnnexuretpeId,  ModelMap modelMap, HttpServletRequest request) throws Exception{
		String retVal = null;
		int clientId = 0;
	    if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	    	try {
	    			clientId = abcUtility.getSessionClientId(request); 
	    			modelMap.put("clientId", clientId);
	    			if(clmAnnexuretpeId == 0 ) {
	    				modelMap.put(OPTYPE,CREATE);
	    			}
	    			retVal = "common/CreateAnnexureType";
	    			
	            } catch(Exception ex){
	                    return exceptionHandlerService.writeLog(ex);
	            }
	        } else {
	            return REDIRECT_SESSION_EXPIRED;
	        }
	    return retVal;
	 }
	
	/*
	 * @Author : Hema.Barmeda
	 *  Annexure Type Master Validations for Name
	 * 
	 * */
	@RequestMapping(value ="/ajaxcall/ajaxChkAnnexureTypeName", method = RequestMethod.POST)
	@ResponseBody
	  public String chkContractDocumentName(@RequestParam("annexureTypeId") int annexureTypeId, @RequestParam("annexureTypeName") String annexureTypeName, HttpSession httpSession, HttpServletRequest request) throws IOException {

	  	String output="1";//Valid.
	  	try{
		       boolean isTrue = commonService.chkContractAnnexureName(annexureTypeName,annexureTypeId);
		       if(isTrue) {
		    	   output ="0";//Annexure Type Name already exist..!!
		       }
			       
	      } catch (Exception e) {
	          	exceptionHandlerService.writeLog(e);
	      } finally {
	      	//  auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deptTreeLinkId, ajaxGetDeptTreeAuditMsg, 0, hdDeptId);
	      }
	      return output;
	  }
	
	
	/*
	 * @Author : Hema.Barmeda
	 * Post Call to dump Annexure Type Master
	 * 
	 * */
	@RequestMapping(value = {"/common/addcannexuretype"} , method = RequestMethod.POST)
    public String addAnnexureType(HttpServletRequest request, RedirectAttributes redirectAttributes) 
    {
	  int clientId=0;
	  String returnPage="";
	  boolean isSuccess=false;
	  int createdBy=0; 
	  String ipaddress=request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
	  try 
	  { 
	  	clientId = abcUtility.getSessionClientId(request);
	  	createdBy = abcUtility.getSessionUserDetailId(request);
	  	String annexureName = StringUtils.hasLength(request.getParameter("txtAnnexureTypeName")) ? request.getParameter("txtAnnexureTypeName") : "";
	  	TblAnnexureType tblAnnexureType=new TblAnnexureType();
		tblAnnexureType.setIsActive(1);
		tblAnnexureType.setAnnexureName(annexureName);
		tblAnnexureTypeDao.addTblAnnexureType(tblAnnexureType);
		isSuccess=true;
		returnPage = "common/manageannexuretype";
    	returnPage = "redirect:/"+returnPage + encryptDecryptUtils.generateRedirect(returnPage, request);
	  }catch(Exception e) {
			exceptionHandlerService.writeLog(e); 
	  } finally {
		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, "AnnexureType", 0,0, "");
	  }
	  redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_type_annexure_create_success" : "redirect_failure_common");
      return returnPage;
    }
	
	/*
	 * @Author : Hema.Barmeda
	 * Update Status for Annexure Type Master
	 * 
	 * */
	@RequestMapping(value = {"/common/updateannexuretypestatus/{clmAnnexureTypeId}/{status}/{enc}"}, method = RequestMethod.GET)     
	 public String enableannexuretype(@PathVariable("clmAnnexureTypeId") int clmAnnexuretpeId,@PathVariable("status")int status, ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) throws Exception{
		String retVal = null;
		int clientId = 0;
		boolean isSuccess=false;
	    if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	    	try {
	    			clientId = abcUtility.getSessionClientId(request); 
	    			modelMap.put("clientId", clientId);
	    			if(clmAnnexuretpeId != 0 ) {
	    				int cnt = commonService.updateAnnexureTypeStatus(clmAnnexuretpeId, status);
	    				isSuccess = cnt > 0 ? true : false;
	    			}
	    			retVal = "common/manageannexuretype";
	    			retVal = "redirect:/"+retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	    			String msg = status == 0 ? "msg_type_annexure_disable_success" : "msg_type_annexure_enable_success";
	    			redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? msg : "redirect_failure_common");
	            } catch(Exception ex){
	                    return exceptionHandlerService.writeLog(ex);
	            }
	        } else {
	            return REDIRECT_SESSION_EXPIRED;
	        }
	    
	    return retVal;
	 }
	@RequestMapping(value = {"ajax/checkvalidmainuser"}, method = RequestMethod.POST)
    @ResponseBody
    public String checkValidMainUser(@RequestParam("txtMainUserEmailId") String emaild, HttpSession session, HttpServletRequest request) {
        StringBuilder result = new StringBuilder();
        try {
        	List<Object[]> list = commonService.getCompanyNameIdFromMainUserEmail(emaild);
        	
        	if(list != null && !list.isEmpty()) {
        		String companyId=(String) list.get(0)[0];
        		String companyName=(String) list.get(0)[1];
        		result.append(companyId).append(",").append(companyName);
        	}
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } 
//        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, ajaxCheckValidUserAuditMsg, 0, 0);
//        }
        return result.toString();
    }
	
	/*
	 * @Author : Abhi.Sundesha
	 * Get All Officer from Department
	 * 
	 * */
	@RequestMapping(value = "/common/getAllOfficer", method = RequestMethod.POST)
    @ResponseBody 
    public String getAllOfficer(@RequestParam("txtDeptId") String txtDeptId,@RequestParam("hdFullTree") boolean hdFullTree, 
    HttpServletResponse response, HttpServletRequest request, HttpSession httpSession) throws IOException {
    	String retVal = null;

        try {

            List<Object[]> list = commonService.getUserOfCommittee(txtDeptId);
            
            List<SelectItem> items = new ArrayList<SelectItem>();
            
            if (list != null) {
                String certEndDate = "";
                for (Object[] objects : list) {
                    if (objects.length >= 2) {

                        if(objects[0]!=null && objects[1]!=null && objects[2]!=null && objects[3]!=null && objects[4]!=null){
                            items.add(new SelectItem(objects[1], encryptDecryptUtils.encrypt(objects[0].toString())+"@@"+encryptDecryptUtils.encrypt(objects[2].toString())+"@@"+objects[2].toString()+"@@"+certEndDate+"@@"+objects[3].toString()));
                        }

                    }                        
                }
            }

        //
        
        retVal = encryptDecryptUtils.getOptions("selDesignationOfficial", items, true, "", messageSource.getMessage("auc_please_selectmsg", null, LocaleContextHolder.getLocale()));
	    
	   } catch (Exception ex) {
	    return exceptionHandlerService.writeLog(ex);
	   } finally {
	    // auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auctioncreationlink, !"".equalsIgnoreCase(retVal) ? postgetofficer : postgetofficerfail, 0, 0);
	}
	return retVal;
	}
        
	@RequestMapping(value = "/common/manageagreementtype/{enc}", method = RequestMethod.GET)
    public String manageAgreementType(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", manageAgreementTypeReportId);
            reportGeneratorService.getReportConfigDetails(manageAgreementTypeReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageAnnexureLinkId, getManageAnnexureRemark, 0, 0);
        }
        return "common/ManageAgreementType";
    }
	
	@RequestMapping(value = {"/common/createagreementtype/{agreementTypeId}/{enc}"}, method = RequestMethod.GET)     
	 public String createAgreementType(@PathVariable("agreementTypeId") int agreementTypeId,  ModelMap modelMap, HttpServletRequest request) throws Exception{
		String retVal = null;
		int clientId = 0;
	    if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	    	try {
	    			clientId = abcUtility.getSessionClientId(request); 
	    			modelMap.put("clientId", clientId);
	    			if(agreementTypeId == 0 ) {
	    				modelMap.put(OPTYPE,CREATE);
	    			}
	    			retVal = "common/CreateAgreementType";
	    			
	            } catch(Exception ex){
	                    return exceptionHandlerService.writeLog(ex);
	            }
	        } else {
	            return REDIRECT_SESSION_EXPIRED;
	        }
	    return retVal;
	 }
	
	@RequestMapping(value ="/ajaxcall/ajaxChkAgreementTypeName", method = RequestMethod.POST)
	@ResponseBody
	  public String chkAgreementTypeName(@RequestParam("agreementTypeId") int agreementTypeId, @RequestParam("agreementTypeName") String agreementTypeName, HttpSession httpSession, HttpServletRequest request) throws IOException {

	  	String output="1";//Valid.
	  	try{
//		       boolean isTrue = commonService.chkContractAnnexureName(agreementTypeName,agreementTypeId);
	  		boolean isTrue = commonService.chkAgreementTypeName(agreementTypeName,agreementTypeId);
		       if(isTrue) {
		    	   output ="0";//Annexure Type Name already exist..!!
		       }
			       
	      } catch (Exception e) {
	          	exceptionHandlerService.writeLog(e);
	      } finally {
	      	//  auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deptTreeLinkId, ajaxGetDeptTreeAuditMsg, 0, hdDeptId);
	      }
	      return output;
	  }
	
	
	/*
	 * @Author : aditya.b
	 * Post Call to dump Agreement Type Master
	 * 
	 * */
	@RequestMapping(value = {"/common/addagreementtype"} , method = RequestMethod.POST)
    public String addAgreementType(HttpServletRequest request, RedirectAttributes redirectAttributes) 
    {
	  int clientId=0;
	  String returnPage="";
	  boolean isSuccess=false;
	  int createdBy=0; 
	  String ipaddress=request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
	  try 
	  { 
//	  	clientId = abcUtility.getSessionClientId(request);
//	  	createdBy = abcUtility.getSessionUserDetailId(request);
	  	String agreementTypeName = StringUtils.hasLength(request.getParameter("txtAgreementTypeName")) ? request.getParameter("txtAgreementTypeName") : "";
	  	TblAgreementType tblAgreementType=new TblAgreementType();
	  	tblAgreementType.setIsActive(1);
	  	tblAgreementType.setAgreementTypeName(agreementTypeName);
	  	tblAgreementTypeDao.addTblAgreementType(tblAgreementType);
		isSuccess=true;
		returnPage = "common/manageagreementtype";
    	returnPage = "redirect:/"+returnPage + encryptDecryptUtils.generateRedirect(returnPage, request);
	  }catch(Exception e) {
			exceptionHandlerService.writeLog(e); 
	  } finally {
		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, "AgreementType", 0,0, "");
	  }
	  redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_type_agreement_create_success" : "redirect_failure_common");
      return returnPage;
    }
	
	@RequestMapping(value = {"/common/updateagreementtypestatus/{agreementTypeId}/{status}/{enc}"}, method = RequestMethod.GET)     
	 public String enableagreementtype(@PathVariable("agreementTypeId") int agreementTypeId,@PathVariable("status")int status, ModelMap modelMap, HttpServletRequest request, RedirectAttributes redirectAttributes) throws Exception{
		String retVal = null;
		int clientId = 0;
		boolean isSuccess=false;
	    if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	    	try {
	    			clientId = abcUtility.getSessionClientId(request); 
	    			modelMap.put("clientId", clientId);
	    			if(agreementTypeId != 0 ) {
	    				int cnt = commonService.updateAgreementTypeStatus(agreementTypeId, status);
	    				isSuccess = cnt > 0 ? true : false;
	    			}
	    			retVal = "common/manageagreementtype";
	    			retVal = "redirect:/"+retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	    			String msg = status == 0 ? "msg_type_agreement_disable_success" : "msg_type_agreement_enable_success";
	    			redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? msg : "redirect_failure_common");
	            } catch(Exception ex){
	                    return exceptionHandlerService.writeLog(ex);
	            }
	        } else {
	            return REDIRECT_SESSION_EXPIRED;
	        }
	    
	    return retVal;
	 }
	
	  @RequestMapping(value = {"/common/checkistendereventid"}, method =
			  RequestMethod.POST)
			  
			  @ResponseBody public String checkistendereventid(@RequestParam("txtTenderRefEventId")
			  String tenderid) {
			  
			  boolean success=commonService.checkopencommitte(Integer.parseInt(tenderid));
			  if(success)
			  {
				  return "valid";   
			  }else {
				  return "Invalid";   
			  }
			  
			 }
	  @RequestMapping(value = "/common/ajax/chatcount", method = RequestMethod.POST)
	    @ResponseBody
	    public List<Object[]> chatcount(@RequestParam("linkId") int linkId,@RequestParam("eventId") int eventId, HttpServletRequest request) {
	        List<Object[]> retVal = null;
	        try {
	        	int buyerstartchatlinkId = tendernegotiationbuyerstartchatid;
              int bidderstartchatlinkId = tendernegotiationbidderstartchatid;
	                //retVal =  eventCreationService.checkTenderNo(tenderNo);
	            	if(linkId == bidderstartchatlinkId) {
	            		  retVal = CommonService.chatCount(eventId,bidderstartchatlinkId);
	                }else if( linkId ==buyerstartchatlinkId ) {
	                	  retVal = CommonService.chatCount(eventId,bidderstartchatlinkId);
	                	
	                }
	                //List<Object[]> retVal = tenderCommonService.chatCount(tenderId,bidderstartchatlinkId);
// 	             modelMap.addAttribute("chatcount", chatcount);
	            
	        } catch (Exception e) {
	            exceptionHandlerService.writeLog(e);
	        }
	        return retVal;
	    }
	
}
