package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.common.model.TblCentralizedCommitteeUser;

public interface TblCentralizedCommitteeUserDao  {

    public void addTblCentralizedCommitteeUser(TblCentralizedCommitteeUser tblCentralizedCommitteeUser);

    public void deleteTblCentralizedCommitteeUser(TblCentralizedCommitteeUser tblCentralizedCommitteeUser);

    public void updateTblCentralizedCommitteeUser(TblCentralizedCommitteeUser tblCentralizedCommitteeUser);

    public List<TblCentralizedCommitteeUser> getAllTblCentralizedCommitteeUser();

    public List<TblCentralizedCommitteeUser> findTblCentralizedCommitteeUser(Object... values) throws Exception;

    public List<TblCentralizedCommitteeUser> findByCountTblCentralizedCommitteeUser(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCentralizedCommitteeUserCount();

    public void saveUpdateAllTblCentralizedCommitteeUser(List<TblCentralizedCommitteeUser> tblCentralizedCommitteeUsers);

	public void saveOrUpdateTblCentralizedCommitteeUser(TblCentralizedCommitteeUser tblCentralizedCommitteeUsers);
}