package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblEventReassignment;
import java.util.List;

public interface TblEventReassignmentDao  {

    public void addTblEventReassignment(TblEventReassignment tblEventReassignment);

    public void deleteTblEventReassignment(TblEventReassignment tblEventReassignment);

    public void updateTblEventReassignment(TblEventReassignment tblEventReassignment);

    public List<TblEventReassignment> getAllTblEventReassignment();

    public List<TblEventReassignment> findTblEventReassignment(Object... values) throws Exception;

    public List<TblEventReassignment> findByCountTblEventReassignment(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEventReassignmentCount();

    public void saveUpdateAllTblEventReassignment(List<TblEventReassignment> tblEventReassignments);
}