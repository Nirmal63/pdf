package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.common.model.TblClientWorkflowType;

public interface TblClientWorkflowTypeDao  {

    public void addTblClientWorkflowType(TblClientWorkflowType tblClientWorkflowType);

    public void deleteTblClientWorkflowType(TblClientWorkflowType tblClientWorkflowType);

    public void updateTblClientWorkflowType(TblClientWorkflowType tblClientWorkflowType);

    public List<TblClientWorkflowType> getAllTblClientWorkflowType();

    public List<TblClientWorkflowType> findTblClientWorkflowType(Object... values) throws Exception;

    public List<TblClientWorkflowType> findByCountTblClientWorkflowType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientWorkflowTypeCount();

    public void saveUpdateAllTblClientWorkflowType(List<TblClientWorkflowType> tblClientWorkflowTypes);
}