package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblContentMobile;
import java.util.List;


public interface TblContentMobileDao  {

    public void addTblContentMobile(TblContentMobile tblContentMobile);

    public void deleteTblContentMobile(TblContentMobile tblContentMobile);

    public void updateTblContentMobile(TblContentMobile tblContentMobile);

    public List<TblContentMobile> getAllTblContentMobile();

    public List<TblContentMobile> findTblContentMobile(Object... values) throws Exception;

    public List<TblContentMobile> findByCountTblContentMobile(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblContentMobileCount();

    public void saveUpdateAllTblContentMobile(List<TblContentMobile> tblContentMobiles);
}