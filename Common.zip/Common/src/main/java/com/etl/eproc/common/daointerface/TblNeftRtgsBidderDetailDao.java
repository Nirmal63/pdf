package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblNeftRtgsBidderDetail;
import java.util.List;

public interface TblNeftRtgsBidderDetailDao  {

    public void addTblNeftRtgsBidderDetail(TblNeftRtgsBidderDetail tblNeftRtgsBidderDetail);

    public void deleteTblNeftRtgsBidderDetail(TblNeftRtgsBidderDetail tblNeftRtgsBidderDetail);

    public void updateTblNeftRtgsBidderDetail(TblNeftRtgsBidderDetail tblNeftRtgsBidderDetail);

    public List<TblNeftRtgsBidderDetail> getAllTblNeftRtgsBidderDetail();

    public List<TblNeftRtgsBidderDetail> findTblNeftRtgsBidderDetail(Object... values) throws Exception;

    public List<TblNeftRtgsBidderDetail> findByCountTblNeftRtgsBidderDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNeftRtgsBidderDetailCount();

    public void saveUpdateAllTblNeftRtgsBidderDetail(List<TblNeftRtgsBidderDetail> tblNeftRtgsBidderDetails);
}