package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientLinkConfig;
import java.util.List;

public interface TblClientLinkConfigDao  {

    public void addTblClientLinkConfig(TblClientLinkConfig tblClientLinkConfig);

    public void deleteTblClientLinkConfig(TblClientLinkConfig tblClientLinkConfig);

    public void updateTblClientLinkConfig(TblClientLinkConfig tblClientLinkConfig);

    public List<TblClientLinkConfig> getAllTblClientLinkConfig();

    public List<TblClientLinkConfig> findTblClientLinkConfig(Object... values) throws Exception;

    public List<TblClientLinkConfig> findByCountTblClientLinkConfig(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientLinkConfigCount();

    public void saveUpdateAllTblClientLinkConfig(List<TblClientLinkConfig> tblClientLinkConfigs);
}