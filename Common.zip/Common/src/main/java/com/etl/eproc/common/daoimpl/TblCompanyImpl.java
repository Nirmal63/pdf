package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblCompanyDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblCompany;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCompanyImpl extends AbcAbstractClass<TblCompany> implements TblCompanyDao {

    @Override
    public void addTblCompany(TblCompany tblCompany){
        super.addEntity(tblCompany);
    }

    @Override
    public void deleteTblCompany(TblCompany tblCompany) {
        super.deleteEntity(tblCompany);
    }

    @Override
    public void updateTblCompany(TblCompany tblCompany) {
        super.updateEntity(tblCompany);
    }

    @Override
    public List<TblCompany> getAllTblCompany() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCompany> findTblCompany(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCompanyCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCompany> findByCountTblCompany(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCompany(List<TblCompany> tblCompanys){
        super.updateAll(tblCompanys);
    }

	@Override
	public void saveOrUpdateTblCompany(TblCompany tblCompany) {
		super.saveOrUpdateEntity(tblCompany);
		
	}
}
