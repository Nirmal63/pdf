package com.etl.eproc.annuxure.model;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="tbl_Clause",schema="appcommon")
public class TblAnxClause implements java.io.Serializable {
	
	
	private int  clauseId;
	private String clauseName;
	private String clauseDescription;
	private int createdBy;
	private Date createdOn;
	private int updatedBy;
	private Date updatedOn;
    private TblAnnexure tblAnnexure;	
    private int isNegotiable;
	
    private Set<Tbl_subClause> tblSubClause = new HashSet<Tbl_subClause>();

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "tblClause")
	public Set<Tbl_subClause> getTblSubClause() {
		return tblSubClause;
	}

	public void setTblSubClause(Set<Tbl_subClause> tblSubClause) {
		this.tblSubClause = tblSubClause;
	}
	
    @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getClauseId() {
		return clauseId;
	}
	public void setClauseId(int clauseId) {
		this.clauseId = clauseId;
	}
	public String getClauseName() {
		return clauseName;
	}
	public void setClauseName(String clauseName) {
		this.clauseName = clauseName;
	}
	public String getClauseDescription() {
		return clauseDescription;
	}
	public void setClauseDescription(String clauseDescription) {
		this.clauseDescription = clauseDescription;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	
	@ManyToOne()
	@JoinColumn(name = "annexureId")
	public TblAnnexure getTblAnnexure() {
		return tblAnnexure;
	}

	public void setTblAnnexure(TblAnnexure tblAnnexure) {
		this.tblAnnexure = tblAnnexure;
	}

	public int getIsNegotiable() {
		return isNegotiable;
	}
	public void setIsNegotiable(int isNegotiable) {
		this.isNegotiable = isNegotiable;
	}
	
	
	

}
