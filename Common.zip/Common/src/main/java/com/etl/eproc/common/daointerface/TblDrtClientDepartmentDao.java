package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDrtClientDepartment;
import java.util.List;

public interface TblDrtClientDepartmentDao  {

    public void addTblDrtClientDepartment(TblDrtClientDepartment TblDrtClientDepartment);

    public void deleteTblDrtClientDepartment(TblDrtClientDepartment TblDrtClientDepartment);

    public void updateTblDrtClientDepartment(TblDrtClientDepartment TblDrtClientDepartment);

    public List<TblDrtClientDepartment> getAllTblDrtClientDepartment();

    public List<TblDrtClientDepartment> findTblDrtClientDepartment(Object... values) throws Exception;

    public List<TblDrtClientDepartment> findByCountTblDrtClientDepartment(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDrtClientDepartmentCount();

    public void saveUpdateAllTblDrtClientDepartment(List<TblDrtClientDepartment> TblDrtClientDepartments);
    
    public void saveOrUpdateTblDrtClientDepartment(TblDrtClientDepartment TblDrtClientDepartments);
}