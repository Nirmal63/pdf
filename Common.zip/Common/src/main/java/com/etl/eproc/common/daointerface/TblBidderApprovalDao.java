package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBidderApproval;

public interface TblBidderApprovalDao  {

    public void addTblBidderApproval(TblBidderApproval tblBidderApproval);

    public void deleteTblBidderApproval(TblBidderApproval tblBidderApproval);

    public void updateTblBidderApproval(TblBidderApproval tblBidderApproval);

    public List<TblBidderApproval> getAllTblBidderApproval();

    public List<TblBidderApproval> findTblBidderApproval(Object... values) throws Exception;

    public List<TblBidderApproval> findByCountTblBidderApproval(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidderApprovalCount();

    public void saveUpdateAllTblBidderApproval(List<TblBidderApproval> tblBidderApprovals);
}