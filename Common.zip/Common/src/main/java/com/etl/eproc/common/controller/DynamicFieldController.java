package com.etl.eproc.common.controller;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientField;
import com.etl.eproc.common.model.TblDynControlType;
import com.etl.eproc.common.model.TblDynField;
import com.etl.eproc.common.model.TblDynRegexKeyword;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ManageContentService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.services.SectorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SelectItem;

@Controller
@RequestMapping("/common")
public class DynamicFieldController {

	private static final String NOT_REQUIRED = "Not Required";
	private static final String NORMAL_SEARCH = "Normal Search";
	private static final String ADVANCE_SEARCH = "Advance Search";
	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
	@Autowired
	private ManageContentService manageContentService;
	@Autowired
	private ModelToSelectItem modelToSelectItem;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private AuditTrailService auditTrailService;
	@Autowired
	private ReportGeneratorService reportGeneratorService;
	@Autowired
	private AbcUtility abcUtility; 
	@Autowired
	private CommonService commonService;
	@Autowired
	private SectorService sectorService;
	@Autowired
	private DynamicFieldService dynamicFieldService;
	
	@Value("#{linkProperties['manage_new_fields_add_field']?:64}")
	private int addFieldLinkId;
	@Value("#{linkProperties['manage_new_fields_edit_field']?:65}")
	private int editFieldLinkId;
	@Value("#{linkProperties['manage_new_fields_view_field']?:66}")
	private int viewFieldLinkId;
	@Value("#{linkProperties['manage_new_fields_cancel']?:67}")
	private int cancelFieldLinkId;
	@Value("#{linkProperties['report_admin_manage_field']?:12}")
	private int manageFieldReportId;
	
	@Value("#{adminAuditTrailProperties['getCreateFieldRemark']}")
    private String getCreateFieldRemark;
    @Value("#{adminAuditTrailProperties['postAddFieldRemark']}")
    private String postAddFieldRemark;
    @Value("#{adminAuditTrailProperties['getEditFieldRemark']}")
    private String getEditFieldRemark;
    @Value("#{adminAuditTrailProperties['postEditFieldRemark']}")
    private String postEditFieldRemark;
    
    @Value("#{adminAuditTrailProperties['postFieldCancelRemark']}")
    private String postFieldCancelRemark;
    @Value("#{adminAuditTrailProperties['getViewFieldRemark']}")
    private String getViewFieldRemark;
    @Value("#{adminAuditTrailProperties['getManageFieldRemark']}")
    private String getManageFieldRemark;
    @Value("#{projectProperties['sector_dyn_fields_linkid']}")
    private String secDynFieldLinkId;

	/**
	 * setting the common modal map for create and edit case of Dynamic Add Field creation
	 * @param modelMap
	 * @throws Exception 
	 */
	public void addFieldCommonModelmap(ModelMap modelMap,HttpServletRequest request)throws Exception{
		List<TblDynControlType> dynContolTypeList=manageContentService.getDynControlTypeList();
		ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
		if(clientBean.getSectorTableName().equalsIgnoreCase("")){
			for(int i=0;i<dynContolTypeList.size();i++){
				if(dynContolTypeList.get(i).getControlTypeId()==8){
					dynContolTypeList.remove(i);
				}
			}
		}/*else{
			for(int i=0;i<dynContolTypeList.size();i++){
				if(dynContolTypeList.get(i).getControlTypeId()==2 || dynContolTypeList.get(i).getControlTypeId()==7 || dynContolTypeList.get(i).getControlTypeId()==3 || dynContolTypeList.get(i).getControlTypeId()==5){
					dynContolTypeList.remove(i);
				}
			}
		}*/
		modelMap.put("controlTypeList",modelToSelectItem.convertListIntoSelectItemList(dynContolTypeList, "controlTypeId", "controlType"));
		modelMap.put("mandatoryList",commonService.getYesNo());
		modelMap.put("moduleList",abcUtility.convert(commonService.getAllModules()));
	}
	/**
	 * Dynamic Add Field creation handler - which serves the Dynamic Add Field creation request for page display purpose
	 * @param request
	 * @param modelMap
	 * @return to view
	 */
	@RequestMapping(value = "/admin/addfield/{enc}",  method= RequestMethod.GET)
	public String addField(HttpServletRequest request,ModelMap modelMap) {
		String retVal="common/admin/AddField";
		try {
			int clientId= abcUtility.getSessionClientId(request);
			addFieldCommonModelmap(modelMap,request);
			modelMap.put("dateValidationList",manageContentService.getDateValidationList());
			modelMap.put("patternList",modelToSelectItem.convertListIntoSelectItemList(manageContentService.getDynRegexPatternList(), "keyword", "regexKeyword"));
			//Added for Project Task #18877 by Mitesh Patel
			ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
			if(!clientBean.getSectorTableName().equalsIgnoreCase("")){
				setSpecialClientProperties(modelMap,clientBean.getSectorTableName());
			}
			//Ended by Mitesh
		} catch (Exception ex) {
			retVal= exceptionHandlerService.writeLog(ex);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addFieldLinkId, getCreateFieldRemark, 0, 0);
		}
		return retVal;
	}
	public void setSpecialClientProperties(ModelMap modelMap,String clientSector){
			// 1.column Name combo list
			List<SelectItem> items=new ArrayList<SelectItem>();
			List<Object[]> result = null;
			result = sectorService.getAttributeByTableName(clientSector);
			if(result!=null){
				for (Object[] objects : result) {
					items.add(new SelectItem(objects[0].toString(),objects[1].toString()));
				}
			}
			modelMap.addAttribute("vehicalColumnList", items);
			//2. serach type list
			items=new ArrayList<SelectItem>();
			items.add(new SelectItem(NOT_REQUIRED, "0"));
			items.add(new SelectItem(NORMAL_SEARCH, "1"));
			items.add(new SelectItem(ADVANCE_SEARCH, "2"));
			modelMap.addAttribute("searchTypeList", items);
			//3. for Listing
			items=new ArrayList<SelectItem>();
			items.add(new SelectItem("Yes", "1"));
			items.add(new SelectItem("No", "0"));
			modelMap.addAttribute("forListingList", items);
			modelMap.addAttribute("isSpecialClient", true);
}
	/**
	 * Dynamic Add Field data Post handler - which serves the Dynamic Add Field creation and edition request for database submission purpose
	 * @param request
	 * @param session
	 * @param redirectAttributes
	 * @return to view
	 */
	@RequestMapping(value = "/admin/addnewfield", method = RequestMethod.POST)
	public String addNewField(HttpServletRequest request,HttpSession session,RedirectAttributes redirectAttributes) {
		boolean flag = false;
		int linkId=0;
		String returnStr = "redirect:/sessionexpired";
		int errorCount=0;//Its for errorCount All field completely setted.
		TblDynField tblDynField =null;
		try {
			int userId = abcUtility.getSessionUserId(request);
			int clientId = abcUtility.getSessionClientId(request);
			if(userId!=0 || clientId!=0){
				tblDynField = new TblDynField();
				String fieldCaption = request.getParameter("txtFieldCaption");
				String fieldType=request.getParameter("selFieldType");
				String isMandatory=request.getParameter("selIsMandatory");
				String columnName="";
				boolean alreadyExistFlag=true;
				linkId=StringUtils.hasLength(request.getParameter("selScreenId"))?Integer.parseInt(request.getParameter("selScreenId")):0;
				String validationMessage = request.getParameter("txtValidationMessage")!=null && !"".equals(request.getParameter("txtValidationMessage"))?request.getParameter("txtValidationMessage"):"";
	
				if(linkId!=0 && StringUtils.hasLength(fieldCaption) && StringUtils.hasLength(fieldType) && StringUtils.hasLength(isMandatory)){
					tblDynField.setFieldName(fieldCaption);
					tblDynField.setTblDynControlType(new TblDynControlType(Integer.parseInt(fieldType)));
					tblDynField.setIsMandatory(Integer.parseInt(isMandatory));
					tblDynField.setValidationMessage(validationMessage);
					if("1".equals(fieldType) || "2".equals(fieldType) || "8".equals(fieldType)){ //Text box,Text Area,Numeric
						String defaultValue=request.getParameter("txtDefaultValue")!=null?request.getParameter("txtDefaultValue"):"";
						String minLength = request.getParameter("txtMinLength");
						String maxLength = request.getParameter("txtMaxLength");
						if(StringUtils.hasLength(minLength) && StringUtils.hasLength(maxLength)){
							tblDynField.setMinLength(Integer.parseInt(minLength));
							tblDynField.setMaxLength(Integer.parseInt(maxLength));
							tblDynField.setDefaultValues(defaultValue);//not manadatory
						}else{
							errorCount++;
						}
						String[] validations = request.getParameterValues("selValidation");
						if(validations!=null && validations.length!=0){
							StringBuilder validationString = new StringBuilder();
							for (String validation:validations) {
								validationString.append(validation).append(",");
							}
							if(validationString.length()!=0){
								tblDynField.setValidation(validationString.length()>0 && validationString.toString().endsWith(",") ? validationString.deleteCharAt(validationString.length()-1).toString(): validationString.toString());
							}
						}
					}else if("3".equals(fieldType)|| "4".equals(fieldType)|| "5".equals(fieldType)){//Radio button,Drop down,check box
						tblDynField.setMinLength(0);
						tblDynField.setMaxLength(0);
	
						String value = request.getParameter("txtaValue");
						if(StringUtils.hasLength(value) && !value.endsWith(",") && !value.startsWith(",")){
							tblDynField.setSelectedValue(value);
							String defaultValues[]=request.getParameterValues("txtDefaultValue");
							if(defaultValues!=null && defaultValues.length!=0){
								StringBuilder appendValue= new StringBuilder();
								for (String defaultValue:defaultValues) {
									appendValue.append(defaultValue).append(",");
								}
								tblDynField.setDefaultValues(appendValue.length()>0 && appendValue.toString().endsWith(",") ? appendValue.deleteCharAt(appendValue.length()-1).toString(): appendValue.toString());//not manadatory
							}
						}else{
							errorCount++;
						}
					}else if("6".equals(fieldType)){//Date Picker
						String validation = request.getParameter("selDateValidation");//Is mandatory
						if(StringUtils.hasLength(validation)){
							tblDynField.setValidation(validation);
						}
						String defaultValue=request.getParameter("txtDefaultValue")!=null?request.getParameter("txtDefaultValue"):"";
						tblDynField.setDefaultValues(defaultValue);//not manadatory
					}else if("7".equals(fieldType)){//Ck Editor
						String defaultValue=request.getParameter("txtDefaultValue")!=null?request.getParameter("txtDefaultValue"):"";
						tblDynField.setDefaultValues(defaultValue);//not manadatory
					}else if("9".equals(fieldType)){
						String defaultValue=request.getParameter("txtDefaultValue");
						if(StringUtils.hasLength(defaultValue)){
							tblDynField.setDefaultValues(defaultValue);
						}
						tblDynField.setMinLength(0);
						tblDynField.setMaxLength(0);
					}else{
						errorCount++;
					}
				//Added for Project Task #18877 by Mitesh Patel
					String selDynaFeildsArray[]=secDynFieldLinkId.split(",");
					columnName=request.getParameter("selColumnName")!=null?request.getParameter("selColumnName"):"";
					int searchType=StringUtils.hasLength(request.getParameter("selSearchType"))?Integer.parseInt(request.getParameter("selSearchType")):0;
					int forListing=StringUtils.hasLength(request.getParameter("selForListing"))?Integer.parseInt(request.getParameter("selForListing")):0;
					ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
					if(columnName!="" && Arrays.asList(selDynaFeildsArray).contains(String.valueOf(linkId)) && !clientBean.getSectorTableName().equalsIgnoreCase(""))
					{
						List<Object[]> lstEvents = dynamicFieldService.getDynFieldConfigured(linkId, clientId, columnName,0);
						if(lstEvents!=null && lstEvents.size()>0)
							alreadyExistFlag=false;
						tblDynField.setColumnName(columnName);
						tblDynField.setSearchType(searchType);
						tblDynField.setForListing(forListing);
					}
					else{
						tblDynField.setColumnName("");
						tblDynField.setSearchType(0);
						tblDynField.setForListing(0);
					}
				//Ended by Mitesh
				}else{
					errorCount++;
				}
				//duplicate filedinsert validation server side.
			
        						
				if(errorCount==0 && alreadyExistFlag){
					TblClientField tblClientField = new TblClientField();
					tblClientField.setTblClient(new TblClient(clientId));
					tblClientField.setTblLink(new TblLink(linkId));
					tblClientField.setTblDynField(tblDynField);
					tblClientField.setCreatedBy(userId);
					tblClientField.setIsActive(1);
					flag = manageContentService.addNewField(tblDynField, tblClientField);
				}
				if(flag){
					redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_newfield_create_success");
					returnStr = "common/admin/fieldlisting";
				}else {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_columnName_already_config");
					returnStr = "common/admin/addfield";
				}
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), addFieldLinkId, postAddFieldRemark, 0,tblDynField!=null?tblDynField.getFieldId():0 );
		}
		return "redirect:/"+returnStr+ encryptDecryptUtils.generateRedirect(returnStr, request);
	}

	/**
	 * Dynamic Add Field edition handler - which serves the Dynamic Add Field edition request for page display purpose
	 * @param request
	 * @param scenario
	 * @param fieldId
	 * @param modelMap
	 * @return to view 
	 */
	@RequestMapping(value = "/admin/editfield/{fieldId}/{enc}",  method= RequestMethod.GET)
	public String getEditFieldDetails(HttpServletRequest request,@PathVariable("fieldId") int fieldId,ModelMap modelMap) {
		List<SelectItem> patternList=null;
		try {
			int clientId= abcUtility.getSessionClientId(request);
			addFieldCommonModelmap(modelMap,request);
			List<Object[]> fieldList = manageContentService.getAddNewFieldData(fieldId,abcUtility.getSessionClientId(request));
			if(fieldList!=null && !fieldList.isEmpty()){
				List<TblDynRegexKeyword> tblDynRegexlist = manageContentService.getDynRegexPatternList();
				Object[] object=fieldList.get(0);
				HashMap<String, Object> fieldMap = new HashMap<String, Object>();
				Integer controlTypeId = (Integer)object[3];
				String defaultValues=null;
				Integer subModuleId = (Integer)object[11];
				Integer moduleId = (Integer)object[12];
				Integer eventId = (Integer)object[10];
				Integer linkId = (Integer)object[9];
				if(object[4]!=null){
					defaultValues=object[4].toString();
				}
				fieldMap.put("clientFieldId", object[0]);
				fieldMap.put("fieldId", object[1]);
				fieldMap.put("fieldName", object[2]);
				fieldMap.put("controlTypeId", object[3]);
				fieldMap.put("isMandatory", object[5]);
				fieldMap.put("maxLength", object[6]);
				fieldMap.put("minLength", object[7]);
				fieldMap.put("selectedValue", object[8]);
				if(controlTypeId==7){//If control is rich text area
					fieldMap.put("rtfDefaultValues", defaultValues);
				}else{
					fieldMap.put("defaultValues", defaultValues != null ? defaultValues.replaceAll("(\\r|\\n|\\r\\n)+", "") : "");
				}
				fieldMap.put("linkId", linkId);
				fieldMap.put("eventId",eventId);
				fieldMap.put("subModuleId",subModuleId);
				fieldMap.put("moduleId",moduleId);
				fieldMap.put("validationMessage", object[14]);

				fieldMap.put("subModuleList",abcUtility.convert(commonService.getAllSubModuleBymoduleId(moduleId)));
				fieldMap.put("eventList",abcUtility.convert(commonService.getAllEventBysubModuleId(subModuleId)));
				fieldMap.put("screenList",abcUtility.convert(commonService.getAllLinksByEventId(eventId)));
				
				//TODO:Start: Whole Process For Fill Combo of Validation and Selected validation in edit mode
				if(tblDynRegexlist!=null && !tblDynRegexlist.isEmpty()){
					if(controlTypeId==1 || controlTypeId==2){
						if(object[13]!=null){//This case is use to give selected validation in combo of validation
							String validationArr[] = object[13].toString().split(",");
							List<Object> selectedValidationList = new ArrayList<Object>();
							for (String validation : validationArr) { 
								selectedValidationList.add(validation);
							}
							patternList=modelToSelectItem.convertListIntoSelectItemList(tblDynRegexlist,selectedValidationList, "keyword", "regexKeyword");
						}else{//If selected validation list is not available at that time
							patternList=modelToSelectItem.convertListIntoSelectItemList(tblDynRegexlist,"keyword","regexKeyword");
						}
					}else{
						patternList=modelToSelectItem.convertListIntoSelectItemList(tblDynRegexlist,"keyword","regexKeyword");
					}
					modelMap.put("patternList",patternList);
				}
				//TODO:End Whole Process For Fill Combo of Validation and Selected validation in edit mode
				if(controlTypeId==6){
					String validation = object[13].toString();
					modelMap.put("dateValidation",validation);
				}
				//Added for Project Task #18877 by Mitesh Patel
				fieldMap.put("columnName",object[15].toString());
				fieldMap.put("searchType",object[16].toString());
				fieldMap.put("forListing",object[17].toString());
				
				ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
				if(!clientBean.getSectorTableName().equalsIgnoreCase("")){
					setSpecialClientProperties(modelMap,clientBean.getSectorTableName());
				}
				
				//Ended by Mitesh Patel
				modelMap.put("fieldMap",fieldMap);
			}
			modelMap.put("dateValidationList",manageContentService.getDateValidationList());
			modelMap.put("opType","update");
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editFieldLinkId, getEditFieldRemark, 0, fieldId);
		}
		return "common/admin/AddField";
	}
	
	@RequestMapping(value = "/admin/updatenewfield", method = RequestMethod.POST)
	public String updateNewField(HttpServletRequest request,RedirectAttributes redirectAttributes) {
		boolean flag = false;
		int linkId=0;
		int fieldId = 0;
		String returnStr = "redirect:/sessionexpired";
		int errorCount=0;//Its for errorCount All field completely setted.
		TblDynField tblDynField =null;
		try {
			int userId = abcUtility.getSessionUserId(request);
			int clientId = abcUtility.getSessionClientId(request);
			if(userId!=0 || clientId!=0){
				int clientFieldId=StringUtils.hasLength(request.getParameter("hdClientfieldId"))?Integer.parseInt(request.getParameter("hdClientfieldId")):0;
				fieldId=StringUtils.hasLength(request.getParameter("hdFieldId"))?Integer.parseInt(request.getParameter("hdFieldId")):0;
				linkId=StringUtils.hasLength(request.getParameter("selScreenId"))?Integer.parseInt(request.getParameter("selScreenId")):0;
				tblDynField = new TblDynField();
				String fieldCaption = request.getParameter("txtFieldCaption");
				String fieldType=request.getParameter("selFieldType");
				String isMandatory=request.getParameter("selIsMandatory");
				boolean alreadyExistFlag=true;
				String validationMessage = request.getParameter("txtValidationMessage")!=null && !"".equals(request.getParameter("txtValidationMessage"))?request.getParameter("txtValidationMessage"):"";
	
				if(fieldId!=0 && clientFieldId!=0 && linkId!=0 && StringUtils.hasLength(fieldCaption) && StringUtils.hasLength(fieldType) && StringUtils.hasLength(isMandatory)){
					tblDynField.setFieldId(fieldId);
					tblDynField.setFieldName(fieldCaption);
					tblDynField.setTblDynControlType(new TblDynControlType(Integer.parseInt(fieldType)));
					tblDynField.setIsMandatory(Integer.parseInt(isMandatory));
					tblDynField.setValidationMessage(validationMessage);
					
					if("1".equals(fieldType)|| "2".equals(fieldType) || "8".equals(fieldType)){ //Text box,Text Area,Numeric
						String defaultValue=request.getParameter("txtDefaultValue")!=null?request.getParameter("txtDefaultValue"):"";
						String minLength = request.getParameter("txtMinLength");
						String maxLength = request.getParameter("txtMaxLength");
						if(StringUtils.hasLength(minLength) && StringUtils.hasLength(maxLength)){
							tblDynField.setMinLength(Integer.parseInt(minLength));
							tblDynField.setMaxLength(Integer.parseInt(maxLength));
							tblDynField.setDefaultValues(defaultValue);//not manadatory
						}else{
							errorCount++;
						}
	
						String[] validations = request.getParameterValues("selValidation");
						if(validations!=null && validations.length!=0){
							StringBuilder validationString = new StringBuilder();
							for (String validation : validations) {
								validationString.append(validation).append(",");
							}
							tblDynField.setValidation(validationString.length()>0 && validationString.toString().endsWith(",") ? validationString.deleteCharAt(validationString.length()-1).toString(): validationString.toString());
						}
					}else if("3".equals(fieldType)|| "4".equals(fieldType)|| "5".equals(fieldType)){
						tblDynField.setMinLength(0);
						tblDynField.setMaxLength(0);
	
						String value = request.getParameter("txtaValue");
						if(StringUtils.hasLength(value) && !value.endsWith(",") && !value.startsWith(",")){
							tblDynField.setSelectedValue(value);
							String defaultValues[]=request.getParameterValues("txtDefaultValue");
							if(defaultValues!=null && defaultValues.length!=0){
								StringBuilder appendValue= new StringBuilder();
								for (String defaultValue:defaultValues) {
									appendValue.append(defaultValue).append(",");
								}
								tblDynField.setDefaultValues(appendValue.length()>0 && appendValue.toString().endsWith(",") ? appendValue.deleteCharAt(appendValue.length()-1).toString(): appendValue.toString());//not manadatory
							}
						}else{
							errorCount++;
						}
					}else if("6".equals(fieldType)){//Date Picker
						String validation = request.getParameter("selDateValidation");//Is mandatory
						if(StringUtils.hasLength(validation)){
							tblDynField.setValidation(validation);
						}
						String defaultValue=request.getParameter("txtDefaultValue")!=null?request.getParameter("txtDefaultValue"):"";
						tblDynField.setDefaultValues(defaultValue);//not manadatory
					}else if("7".equals(fieldType)){//Ck Editor
						String defaultValue=request.getParameter("txtDefaultValue")!=null?request.getParameter("txtDefaultValue"):"";
						tblDynField.setDefaultValues(defaultValue);//not manadatory
					}else{
						errorCount++;
					}
					//Added for Project Task #18877 by Mitesh Patel
					String selDynaFeildsArray[]=secDynFieldLinkId.split(",");
					String columnName=request.getParameter("selColumnName")!=null?request.getParameter("selColumnName"):"";
					int searchType=StringUtils.hasLength(request.getParameter("selSearchType"))?Integer.parseInt(request.getParameter("selSearchType")):0;
					int forListing=StringUtils.hasLength(request.getParameter("selForListing"))?Integer.parseInt(request.getParameter("selForListing")):0;
					ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
					if(columnName!="" && Arrays.asList(selDynaFeildsArray).contains(String.valueOf(linkId)) && !clientBean.getSectorTableName().equalsIgnoreCase(""))
					{
						List<Object[]> lstEvents = dynamicFieldService.getDynFieldConfigured(linkId, clientId, columnName,fieldId);
						if(lstEvents!=null && lstEvents.size()>0)
							alreadyExistFlag=false;
						tblDynField.setColumnName(columnName);
						tblDynField.setSearchType(searchType);
						tblDynField.setForListing(forListing);
					}
					else{
						tblDynField.setColumnName("");
						tblDynField.setSearchType(0);
						tblDynField.setForListing(0);
					}
				//Ended by Mitesh
				}else{
					errorCount++;
				}
				if(errorCount==0 && alreadyExistFlag){
					TblClientField tblClientField = new TblClientField();
					tblClientField.setClientFieldId(clientFieldId);
					tblClientField.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
					tblClientField.setTblLink(new TblLink(linkId));
					tblClientField.setTblDynField(tblDynField);
					tblClientField.setCreatedBy(abcUtility.getSessionUserId(request));
					tblClientField.setIsActive(1);
					flag = manageContentService.addNewField(tblDynField, tblClientField);
				}
				if(flag){
					redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_newfield_edit_success");
					returnStr = "common/admin/fieldlisting";
				}else {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_columnName_already_config");
					returnStr = "common/admin/editfield/"+fieldId;
				}
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editFieldLinkId, postEditFieldRemark, 0,fieldId);
		}
		return "redirect:/"+returnStr+ encryptDecryptUtils.generateRedirect(returnStr, request);
	}
	/**
	 * To cancel Field from screen
	 * @param modelMap
	 * @return 
	 */
	@RequestMapping(value = "/admin/cancelfield/{fieldId}/{enc}",  method= RequestMethod.GET)
	public String cancelField(@PathVariable("fieldId") int fieldId,HttpServletRequest request,RedirectAttributes redirectAttributes) {
		boolean success=false;
		try{
			success = manageContentService.cancelorUpdateField(fieldId);
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),cancelFieldLinkId,postFieldCancelRemark,0, fieldId);
		}
		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_cancel_newField" : CommonKeywords.ERROR_MSG_KEY.toString());
		return "redirect:/common/admin/fieldlisting"+ encryptDecryptUtils.generateRedirect("common/admin/fieldlisting", request);
	}

	@RequestMapping(value = "/admin/fieldlisting/{enc}",  method= RequestMethod.GET)
	public String attributeListing(ModelMap modelMap , HttpServletRequest request) {
		try {
			modelMap.addAttribute("reportId", manageFieldReportId);
			reportGeneratorService.getReportConfigDetails(manageFieldReportId, modelMap);
			
		} catch (Exception ex) {
			ex.printStackTrace();
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0,getManageFieldRemark,0,0);
		}
		return "common/admin/FieldListing";
	}

	@RequestMapping(value = "/admin/viewfield/{fieldId}/{enc}", method= RequestMethod.GET)
	public String viewDelAttibute(ModelMap modelMap,@PathVariable("fieldId") int fieldId,HttpServletRequest request) {
		HashMap<String, Object> fieldMap = null;
		String retVal="common/admin/ViewField";
		try {
			List<Object[]> fieldList = manageContentService.getNewFieldDataForView(fieldId,abcUtility.getSessionClientId(request));
			if(fieldList!=null && !fieldList.isEmpty()){
				Object[] object = fieldList.get(0);
				fieldMap = new HashMap<String, Object>();
				fieldMap.put("fieldName", object[0]);
				fieldMap.put("defaultValues", object[1]);
				fieldMap.put("isMandatory", (Integer)object[2]==1?"Yes":"No" );
				fieldMap.put("maxLength", object[3]);
				fieldMap.put("minLength", object[4]);
				fieldMap.put("selectedValue", object[5]);
				fieldMap.put("linkName", object[6]);
				fieldMap.put("eventName", object[7]);
				fieldMap.put("subModuleName", object[8]);
				fieldMap.put("moduleName", object[9]);
				fieldMap.put("controlType", object[10]);
				fieldMap.put("validation", object[11]);
				fieldMap.put("validationMessage", object[12]);
				fieldMap.put("controlTypeId", object[13]);
				//Added for Project Task #18877 by Mitesh Patel
				ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
				String selDynaFeildsArray[]=secDynFieldLinkId.split(",");
				if(!clientBean.getSectorTableName().equalsIgnoreCase("") && Arrays.asList(selDynaFeildsArray).contains(String.valueOf(object[17]))){
					modelMap.addAttribute("isSpecialClient", true);
					fieldMap.put("fieldValue",object[14]);
					String searchTypeVal="";
					switch ((Integer)object[15]) {
					case 0:
						searchTypeVal=NOT_REQUIRED;
						break;
					case 1:
						searchTypeVal=NORMAL_SEARCH;
						break;
					case 2:
						searchTypeVal=ADVANCE_SEARCH;
						break;
					default:
						break;
					}
					fieldMap.put("searchType",searchTypeVal);
					fieldMap.put("forListing",(Integer)object[16]==1?"Yes":"No");
				}
				//Ended by Mitesh Patel
			}
			modelMap.put("fieldMap",fieldMap);
		} catch (Exception ex) {
			retVal=exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),viewFieldLinkId,getViewFieldRemark,0, fieldId);
		}
		return retVal;
	}
	 @RequestMapping(value = "/isfeildalreadyconfig", method = RequestMethod.POST)
	 @ResponseBody
	    public String checkIsFielsAlreadyConfig(@RequestParam("selScreenId") int linkId,@RequestParam("selColumnName") String columnName, @RequestParam("hdFieldId") Integer fieldId ,ModelMap map, HttpServletResponse response, HttpServletRequest request) {
	        StringBuilder str = new StringBuilder("sessionexpired");
	    	int clientId = abcUtility.getSessionClientId(request);
	        try {
	        
	        	if(abcUtility.getSessionUserId(request)!=0){
	        		str.setLength(0);
	        		List<Object[]> lstEvents = dynamicFieldService.getDynFieldConfigured(linkId, clientId, columnName,fieldId);
	        		if(lstEvents!=null && lstEvents.size()==0){
	        			return "0";
	        		}
	        	}
	        	
	        } catch (Exception ex) {
	            exceptionHandlerService.writeLog(ex);
	        }
	        return "1";
	    }
}
