package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblTemplateQueryDao;
import com.etl.eproc.common.model.TblTemplateQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblTemplateQueryImpl extends AbcAbstractClass<TblTemplateQuery> implements TblTemplateQueryDao {

    @Override
    public void addTblTemplateQuery(TblTemplateQuery tblTemplateQuery) {
        super.addEntity(tblTemplateQuery);
    }

    @Override
    public void deleteTblTemplateQuery(TblTemplateQuery tblTemplateQuery) {
        super.deleteEntity(tblTemplateQuery);
    }

    @Override
    public void updateTblTemplateQuery(TblTemplateQuery tblTemplateQuery) {
        super.updateEntity(tblTemplateQuery);
    }

    @Override
    public List<TblTemplateQuery> getAllTblTemplateQuery() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTemplateQuery> findTblTemplateQuery(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTemplateQueryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTemplateQuery> findByCountTblTemplateQuery(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTemplateQuery(List<TblTemplateQuery> tblTemplateQuerys) {
        super.updateAll(tblTemplateQuerys);
    }
}
