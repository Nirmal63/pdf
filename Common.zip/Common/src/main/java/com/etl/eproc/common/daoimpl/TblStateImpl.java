package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblStateDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblState;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblStateImpl extends AbcAbstractClass<TblState> implements TblStateDao {

    @Override
    public void addTblState(TblState tblState){
        super.addEntity(tblState);
    }

    @Override
    public void deleteTblState(TblState tblState) {
        super.deleteEntity(tblState);
    }

    @Override
    public void updateTblState(TblState tblState) {
        super.updateEntity(tblState);
    }

    @Override
    public List<TblState> getAllTblState() {
        return super.getAllEntity();
    }

    @Override
    public List<TblState> findTblState(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblStateCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblState> findByCountTblState(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblState(List<TblState> tblStates){
        super.updateAll(tblStates);
    }
}
