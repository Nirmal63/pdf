/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;

import com.etl.eproc.common.model.TblLOI;
import java.util.List;

/**
 *
 * @author urja
 */

public interface TblLOIDao  {

    public void addTblLOI(TblLOI tblLOI);

    public void deleteTblLOI(TblLOI tblLOI);

    public void updateTblLOI(TblLOI tblLOI);

    public List<TblLOI> getAllTblLOI();

    public List<TblLOI> findTblLOI(Object... values) throws Exception;

    public List<TblLOI> findByCountTblLOI(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblLOICount();

    public void saveUpdateAllTblLOI(List<TblLOI> tblLOIs);
}
