package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBulkAuctionRevive;

public interface TblBulkAuctionReviveDao {

    public void addTblBulkAuctionRevive(TblBulkAuctionRevive tblBulkAuctionRevive);

    public void deleteTblBulkAuctionRevive(TblBulkAuctionRevive tblBulkAuctionRevive);

    public void updateTblBulkAuctionRevive(TblBulkAuctionRevive tblBulkAuctionRevive);

    public List<TblBulkAuctionRevive> getAllTblBulkAuctionRevive();

    public List<TblBulkAuctionRevive> findTblBulkAuctionRevive(Object... values) throws Exception;

    public List<TblBulkAuctionRevive> findByCountTblBulkAuctionRevive(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBulkAuctionReviveCount();

    public void saveUpdateAllTblBulkAuctionRevive(List<TblBulkAuctionRevive> tblBulkAuctionRevives);

	public void saveOrUpdateTblBulkAuctionRevive(TblBulkAuctionRevive tblBulkAuctionRevive);
}