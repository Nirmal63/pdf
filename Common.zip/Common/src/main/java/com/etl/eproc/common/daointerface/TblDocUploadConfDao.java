package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDocUploadConf;
import java.util.List;

public interface TblDocUploadConfDao  {

    public void addTblDocUploadConf(TblDocUploadConf tblDocUploadConf);

    public void deleteTblDocUploadConf(TblDocUploadConf tblDocUploadConf);

    public void updateTblDocUploadConf(TblDocUploadConf tblDocUploadConf);

    public List<TblDocUploadConf> getAllTblDocUploadConf();

    public List<TblDocUploadConf> findTblDocUploadConf(Object... values) throws Exception;

    public List<TblDocUploadConf> findByCountTblDocUploadConf(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDocUploadConfCount();

    public void saveUpdateAllTblDocUploadConf(List<TblDocUploadConf> tblDocUploadConfs);
}