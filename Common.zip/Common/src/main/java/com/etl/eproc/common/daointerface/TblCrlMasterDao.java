package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCrlMaster;
import java.util.List;

public interface TblCrlMasterDao  {

    public void addTblCrlMaster(TblCrlMaster tblCrlMaster);

    public void deleteTblCrlMaster(TblCrlMaster tblCrlMaster);

    public void updateTblCrlMaster(TblCrlMaster tblCrlMaster);

    public List<TblCrlMaster> getAllTblCrlMaster();

    public List<TblCrlMaster> findTblCrlMaster(Object... values) throws Exception;

    public List<TblCrlMaster> findByCountTblCrlMaster(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCrlMasterCount();

    public void saveUpdateAllTblCrlMaster(List<TblCrlMaster> tblCrlMasters);
}