package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblUserDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblUserDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserDetailImpl extends AbcAbstractClass<TblUserDetail> implements TblUserDetailDao {

    @Override
    public void addTblUserDetail(TblUserDetail tblUserDetail){
        super.addEntity(tblUserDetail);
    }

    @Override
    public void deleteTblUserDetail(TblUserDetail tblUserDetail) {
        super.deleteEntity(tblUserDetail);
    }

    @Override
    public void updateTblUserDetail(TblUserDetail tblUserDetail) {
        super.updateEntity(tblUserDetail);
    }

    @Override
    public List<TblUserDetail> getAllTblUserDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserDetail> findTblUserDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserDetail> findByCountTblUserDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserDetail(List<TblUserDetail> tblUserDetails){
        super.updateAll(tblUserDetails);
    }

	@Override
	public void saveOrUpdateTblUserDetail(TblUserDetail tblUserDetail) {
		super.saveOrUpdateEntity(tblUserDetail);
	}
}
