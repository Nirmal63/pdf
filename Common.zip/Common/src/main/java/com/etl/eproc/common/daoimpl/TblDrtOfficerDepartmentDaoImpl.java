package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblDrtOfficerDepartmentDao;
import com.etl.eproc.common.model.TblDrtOfficerDepartment;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDrtOfficerDepartmentDaoImpl extends AbcAbstractClass<TblDrtOfficerDepartment> implements TblDrtOfficerDepartmentDao {

    

    @Override
    public void addTblDrtOfficerDepartment(TblDrtOfficerDepartment TblDrtOfficerDepartment){
        super.addEntity(TblDrtOfficerDepartment);
    }

    @Override
    public void deleteTblDrtOfficerDepartment(TblDrtOfficerDepartment TblDrtOfficerDepartment) {
        super.deleteEntity(TblDrtOfficerDepartment);
    }

    @Override
    public void updateTblDrtOfficerDepartment(TblDrtOfficerDepartment TblDrtOfficerDepartment) {
        super.updateEntity(TblDrtOfficerDepartment);
    }

    @Override
    public List<TblDrtOfficerDepartment> getAllTblDrtOfficerDepartment() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDrtOfficerDepartment> findTblDrtOfficerDepartment(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDrtOfficerDepartmentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDrtOfficerDepartment> findByCountTblDrtOfficerDepartment(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

	@Override
	public void saveOrUpdateTblDrtOfficerDepartment(TblDrtOfficerDepartment TblDrtOfficerDepartments) {
		super.saveOrUpdateEntity(TblDrtOfficerDepartments);
	}
}
