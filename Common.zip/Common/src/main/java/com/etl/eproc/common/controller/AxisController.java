package com.etl.eproc.common.controller;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.axis.types.URI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblClientPGConf;
import com.etl.eproc.common.model.TblOnlinePayment;
import com.etl.eproc.common.model.TblPayment;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.TpslService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.Security;
import com.etl.eproc.eauction.model.TblEmdBalance;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.utility.SessionBean;

@Controller
@RequestMapping("/common")
public class AxisController {
	/**
	 * @author dharmesh parmar
	 * @url Axis Payment Success URL
	 * @param deptId
	 * @param payFor 
	 * @param enc 
	 * @return Payment Report
	 * @throws IOException
	 */
	private static final int TAB_DOC_FEES = 3;
	private static final int TAB_EMD = 4;
	 private static final int TAB_REG_PAYMENT = 14;
	 private static final int TAB_PARTICIPATION_FEES = 17;
	 private static final int TAB_RESTEVENTMONEY = 18;

	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private CommonService commonService;
	@Autowired
	private ExceptionHandlerService  exceptionHandlerService;
	@Autowired
	private TpslService tpslService;
	@Autowired
	private ManageBidderService manageBidderService;
	@Autowired
	private ClientService clientService;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private LoginService loginService;
	@Autowired
	private MailContentUtillity mailContentUtillity;
	@Value("#{etenderAuditTrailProperties['getPaymentDataDashboard']}")
	private String getPaymentDataDashboard;
	@Value("#{etenderAuditTrailProperties['restofAucMoneyAccesse']}")
	private String restofAucMoneyAccesse;
	
	@Autowired
	private AuditTrailService auditTrailService;
	private int lnkDocfeePayment;
	@Value("#{tenderlinkProperties['bidder_emd_payment_through_tpsl']?:417}")
	private int lnkEmdPayment;
    @Value("#{tenderlinkProperties['eventReg_payment_through_pg']?:937}")
	private int lnkTenderEventPaymentPG;
    @Value("#{tenderlinkProperties['restOfEventMoney']?:3321}") 
    private int lnkTenderRestOfEventMoney;
    @Value("#{auclinkProperties['bidder_auc_emd_payment_through_tpsl']?:814}")
    private int lnkAucEmdPaymentTpsl;
    @Value("#{auclinkProperties['restofaucmoney_payment_through_pg']?:2295}") 
    private int lnkrestofaucmoneypaymentthroughpg;
    @Value("#{auclinkProperties['security_payment_through_pg']?:4433}")
    private int lnkAuctionSecurityPaymentPG;
    
    @RequestMapping(value = "/successAxisPayment/{deptId}/{payFor}/{enc}", method = RequestMethod.GET)
	public String successAxisPayment(@PathVariable("deptId") int deptId,@PathVariable("payFor") int payFor, HttpSession httpSession,HttpServletRequest request, RedirectAttributes rea) throws IOException {
    	String page = "";
		int linkId = 0;
		int paymentId = 0;
		int objectId = 0;
		boolean isPaymentDone = false;
		try{
			
			if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
				String i = "";
				if (StringUtils.hasLength(request.getParameter("i"))) {
					i = request.getParameter("i");
				} 
				//Response
				//CID=2592&RID=2283&CRN=18811&AMT=10.00&VER=1.0&TYP=test&CNY=INR&BRN=123&STC=000&RMK=demo&TRN=18811&TET=5&PMD=AIB&CKS=1b282ca34a415d6fbe170dcc7a8656219045c943c209f49b7549d6287b0c4664
		TblClientPGConf tblClientPGConf = tpslService.getPGConfiguration(abcUtility.getSessionClientId(request), payFor,deptId);
		String decResp = Security.decrypt(i, tblClientPGConf.getAccessCode());
		StringTokenizer tokenizer = new StringTokenizer(decResp, "&");
		Hashtable<String, String> hs=new Hashtable<String, String>();
		String pair=null, pname=null, pvalue=null;
		while (tokenizer.hasMoreTokens()) {
			pair = (String)tokenizer.nextToken();
			if(pair!=null) {
				StringTokenizer strTok=new StringTokenizer(pair, "=");
				pname=""; pvalue="";
				if(strTok.hasMoreTokens()) {
					pname=(String)strTok.nextToken();
					if(strTok.hasMoreTokens()){
						pvalue=(String)strTok.nextToken();
					}
					hs.put(pname, pvalue!=null?pvalue:"");
				}
			}
		}
		
		int status=1;
		String resCode = null;
		String Unique_paymentId = hs.get("RID") !="" ? hs.get("RID").toString() : "0";
		paymentId = Integer.parseInt(Unique_paymentId);
		
		 //Response code : STC-000 success 101-fail 101 - pending/processing 
		if (tpslService.isOnlinePaymentDone(paymentId)) {
			resCode = "1300";
			isPaymentDone = true;
		} else {
			resCode = (!hs.get("STC").equals(""))?hs.get("STC").equalsIgnoreCase("000")?"0300":hs.get("STC").equalsIgnoreCase("101")?"0399":"0388":"0388";
			if ("0300".equals(resCode)) {
				isPaymentDone = true;
				status=0;
			}
		}
		TblPayment tblPayment = tpslService.getTblPayment(paymentId);
		int itemwisePayment = 0;
		int isItemwiseWinner = 0;
		if(resCode.equals("0300") || resCode.equals("0399")){
			objectId = tblPayment.getObjectId();
			tblPayment.setCstatus(isPaymentDone ? 1 : 2);
			TblOnlinePayment tblOnlinePayment = new TblOnlinePayment();
			tblOnlinePayment.setMerchantId(tblClientPGConf.getMerchantId());
			tblOnlinePayment.setResponseCode(resCode);
			tblOnlinePayment.setResponseMessage(decResp);
			tblOnlinePayment.setTblPayment(tblPayment);
			tblOnlinePayment.setTpslReferenceId((!hs.get("TRN").equals(""))? hs.get("TRN").toString() :"0");
			tpslService.addOnlinePaymentDetail(tblOnlinePayment);
				if(tblPayment.getTblModule().getModuleId()==3){
					isItemwiseWinner = Integer.parseInt(commonService.getField("TblTender", "isItemwiseWinner","tenderId",tblPayment.getObjectId()).toString());
					itemwisePayment = Integer.parseInt(commonService.getField("TblTender",tblPayment.getPaymentFor()==1?"isDocfeesApplicable":tblPayment.getPaymentFor()==2 || tblPayment.getPaymentFor()==9?"isEMDApplicable":"isRegistrationCharges","tenderId",objectId).toString());
				}else if((tblPayment.getTblModule().getModuleId()==5)){
            		itemwisePayment = Integer.parseInt(commonService.getField("TblAuction",tblPayment.getPaymentFor()==2?"isEmdReq":"isRegistrationCharges","auctionId",tblPayment.getObjectId()).toString());
            	}
			if(itemwisePayment==2 || isItemwiseWinner==1 || tblPayment.getPaymentFor()==11){
				int companyId = tpslService.getCompanyIdByPaymentId(tblPayment.getPaymentId());
				tpslService.tenderFeesUpdateAndInsertOnFailure(companyId,tblPayment.getObjectId() ,tblPayment.getUniqueId(),isPaymentDone,isPaymentDone?1:2);
			}
		}
		int moduleId=tblPayment.getTblModule().getModuleId();
		if(moduleId==3){
			page = "etender/bidder/biddingtenderdashboard/"+objectId+"/";
			if (tblPayment.getPaymentFor() == 1) {
				linkId = lnkDocfeePayment;
				page += TAB_DOC_FEES;
			}else if (tblPayment.getPaymentFor() == 2) {
				linkId = lnkEmdPayment;
				page += TAB_EMD;
			}else if (tblPayment.getPaymentFor() == 9) {
				linkId = lnkTenderRestOfEventMoney;
				page += TAB_RESTEVENTMONEY;
			}else{
				linkId = lnkTenderEventPaymentPG;
				page += itemwisePayment ==2 ? TAB_PARTICIPATION_FEES : TAB_REG_PAYMENT;
			}
		}else if(moduleId==5 && tblPayment.getPaymentFor()!=5){
			BigDecimal amount=tblPayment.getAmount();
			TblEmdBalance tblEmdBalance=commonService.checkTblEmdBalance(tblPayment.getTblCompany().getCompanyId(), objectId, tblPayment.getTblClient().getClientId());
			if(tblEmdBalance!=null){
				tblEmdBalance.setEmdAmount(amount.add(tblEmdBalance.getEmdAmount()));
				tblEmdBalance.setEmdBalance(amount.add(tblEmdBalance.getEmdBalance()));
				tblEmdBalance.setUpdatedOn(commonService.getServerDateTime());
				tblEmdBalance.setUpdatedBy(abcUtility.getSessionUserId(request));
			}else{
				tblEmdBalance=new TblEmdBalance();
				tblEmdBalance.setAuctionId(objectId);
				tblEmdBalance.setBidderId(abcUtility.getSessionUserId(request));
				tblEmdBalance.setClientId(tblPayment.getTblClient().getClientId());
				tblEmdBalance.setTblCompany(tblPayment.getTblCompany());
				tblEmdBalance.setEmdAmount(amount);
				tblEmdBalance.setEmdBalance(amount);
				tblEmdBalance.setCreatedBy(abcUtility.getSessionUserId(request));
				tblEmdBalance.setUpdatedOn(commonService.getServerDateTime());
				tblEmdBalance.setUpdatedBy(abcUtility.getSessionUserId(request));
			}						
			commonService.addTblEmdBalance(tblEmdBalance);
			if(payFor==9){
				page = "restOfAuction/bidder/getRestOfAucPaymentDetail/"+moduleId + "/"+objectId+"/"+tblPayment.getPaymentFor()+"/"+paymentId;
			}else if(payFor==11){
				page = "common/bidder/payment/"+objectId + "/"+moduleId+"/"+tblPayment.getPaymentFor();
				linkId = lnkAuctionSecurityPaymentPG;
			}else{
				page = "common/bidder/payment/"+objectId + "/"+moduleId+"/"+tblPayment.getPaymentFor();				
			}
			if (tblPayment.getPaymentFor() == 2) {
				linkId = lnkAucEmdPaymentTpsl;
			}
		}
		
		if (status==0 &&StringUtils.hasLength(resCode) && isPaymentDone) {
			rea.addFlashAttribute("successMsg", tblPayment.getPaymentFor() == 1 ? "msg_doc_payment_success" : tblPayment.getPaymentFor() ==2 ?"msg_emd_payment_success":tblPayment.getPaymentFor()==5?"msg_eventReg_payment_success":(tblPayment.getPaymentFor()==9 && moduleId==3)? "msg_restEventMoney_payment_success" : (tblPayment.getPaymentFor()==9 && moduleId==5)? "msg_restAucMoney_payment_success":"msg_payment_success");
			Map<String, Object> mailParams = new HashMap<String, Object>();
			mailParams.put("domainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
			mailParams.put("eventType", commonService.getEventTypeModuleId(moduleId).get(0)[2]);
			mailParams.put("eventId", objectId);
			mailParams.put("amount", tblPayment.getAmount());
			mailParams.put("paymentType", commonService.getPaymentTypeDetail(tblPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
			mailParams.put("paymentMode", "Online");
			mailParams.put("date", CommonUtility.convertTimezone(commonService.getServerDateTime()));
			if(payFor == 1){
				mailContentUtillity.dynamicMailGeneration("387", "0", null, mailParams, String.valueOf(tblPayment.getTblCompany().getCompanyId()), String.valueOf(abcUtility.getSessionClientId(request)));
			}else if(payFor == 2){
				mailContentUtillity.dynamicMailGeneration("388", "0", null, mailParams, String.valueOf(tblPayment.getTblCompany().getCompanyId()), String.valueOf(abcUtility.getSessionClientId(request)));
			}else if(payFor == 8){
				mailContentUtillity.dynamicMailGeneration("389", "0", null, mailParams, String.valueOf(tblPayment.getTblCompany().getCompanyId()), String.valueOf(abcUtility.getSessionClientId(request)));
			}
		} else{
			rea.addFlashAttribute("errorMsg", "msg_payment_fail");
		}	
		
		}
	} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
} finally {
			if(payFor == 9){
				auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),lnkrestofaucmoneypaymentthroughpg, restofAucMoneyAccesse, objectId, paymentId);
			}else{
			auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getPaymentDataDashboard, objectId, paymentId);
			}
		}
		return "redirect:/" + page
				+ encryptDecryptUtils.generateRedirect(page, request);
	}
	
    
    /**
     * Success Registration payment 
	 * @author priyanka 
	 * @param httpSession
	 * @param request
	 * @param rea
	 * @return
	 * @throws IOException
	 */
   
	@RequestMapping(value = "/successRegAxisPayment", method = RequestMethod.GET)
	public String successRegAxisPayment(HttpSession httpSession,HttpServletRequest request, RedirectAttributes rea) throws IOException {
		String page = "";
		int paymentId = 0;
		int objectId = 0;
		int linkId = 0;
		boolean isPaymentDone = false;
		try {
			if (httpSession.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
				SessionBean sessionBean = (SessionBean) httpSession.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
				String encResp = request.getParameter("i");
				//
				if (StringUtils.hasLength(request.getParameter("i"))) {
					encResp = request.getParameter("i");
				}	
				//Response
				//CID=2592&RID=2282&CRN=18811&AMT=1&VER=1.0&TYP=test&CNY=INR&BRN=123&STC=000&RMK=demo&TRN=18811&TET=5&PMD=AIB&CKS=3c3ab9fc42ae4fbd66ef9085b9024740aed45317105f05d49ec6ec658c7ddb49
				int deptId=Integer.valueOf(clientService.getClientField(abcUtility.getSessionClientId(request), "deptId").toString());
				TblClientPGConf tblClientPGConf = tpslService.getPGConfiguration(abcUtility.getSessionClientId(request), 3,deptId);
				
				String decResp = Security.decrypt(encResp,tblClientPGConf.getAccessCode());
				StringTokenizer tokenizer = new StringTokenizer(decResp, "&");
				Hashtable<String, String> hs=new Hashtable<String, String>();
				String pair=null, pname=null, pvalue=null;
				while (tokenizer.hasMoreTokens()) {
					pair = (String)tokenizer.nextToken();
					if(pair!=null) {
						StringTokenizer strTok=new StringTokenizer(pair, "=");
						pname=""; pvalue="";
						if(strTok.hasMoreTokens()) {
							pname=(String)strTok.nextToken();
							if(strTok.hasMoreTokens()){
								pvalue=(String)strTok.nextToken();
							}
							hs.put(pname, pvalue!=null?pvalue:"");
						}
					}
				}
				
				int status=1;
				String resCode = null;
				paymentId = Integer.parseInt(hs.get("RID") !="" ? hs.get("RID") : "0");
				page = "bidderregcharges";
				if (tpslService.isOnlinePaymentDone(paymentId)) {
					resCode = "1300";
					isPaymentDone = true;
				} else {
					resCode = hs.get("STC") != "" ? hs.get("STC").toString().equalsIgnoreCase("000")? "0300":"0399": ""; // need to change as per response
					if ("0300".equals(resCode)) {
						isPaymentDone = true;
						status=0;
					}
				}	
				TblPayment tblPayment = tpslService.getTblPayment(paymentId);
				objectId = tblPayment.getObjectId();
				tblPayment.setCstatus(isPaymentDone ? 1 : 2);
				TblOnlinePayment tblOnlinePayment = new TblOnlinePayment();
				tblOnlinePayment.setMerchantId(tblClientPGConf.getMerchantId());
				tblOnlinePayment.setResponseCode(resCode);
				tblOnlinePayment.setResponseMessage(decResp);
				tblOnlinePayment.setTblPayment(tblPayment);
				tblOnlinePayment.setTpslReferenceId(hs.get("TRN") != "" ? hs.get("TRN").toString() :"0");
				tpslService.addOnlinePaymentDetail(tblOnlinePayment);
				
				if (status==0 && StringUtils.hasLength(resCode) && isPaymentDone) {
					rea.addFlashAttribute("successMsg", "msg_payment_success");
					int isGstRequired = (Integer)clientService.getClientField(abcUtility.getSessionClientId(request), "isGSTRequired");
					if(isGstRequired==1){
						manageBidderService.updateRegistrationWorkflowInBidderStatus(abcUtility.getSessionClientId(request),sessionBean.getUserId(), 7);
					}else{
						manageBidderService.updateRegistrationWorkflowInBidderStatus(abcUtility.getSessionClientId(request),sessionBean.getUserId(), 8);
					}
					Map<String, Object> mailParams = new HashMap<String, Object>();
					URL url = new URL(request.getRequestURL().toString().split(request.getRequestURI().toString())[0]);
					mailParams.put("domainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
					mailParams.put("domainURL",  url + request.getContextPath().toString());
					mailParams.put("amount", tblPayment.getAmount());
					mailParams.put("paymentType", commonService.getPaymentTypeDetail(tblPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
					mailParams.put("paymentMode", "Online");
					mailParams.put("date", CommonUtility.convertTimezone(commonService.getServerDateTime()));
					mailParams.put("to", loginService.getLoginIdByUserId(sessionBean.getUserId()).get(0).toString());
					mailContentUtillity.dynamicMailGeneration("390", String.valueOf(abcUtility.getSessionUserId(request)), String.valueOf(abcUtility.getSessionClientId(request)), mailParams, "");
					
				} else{
					rea.addFlashAttribute("errorMsg", "msg_payment_fail");
				}
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			
			auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getPaymentDataDashboard, objectId, paymentId);
		}
		return "redirect:/" + page;
	}
		
}
