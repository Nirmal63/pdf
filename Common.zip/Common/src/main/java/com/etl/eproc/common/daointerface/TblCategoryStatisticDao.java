package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCategoryStatistic;
import java.util.List;

public interface TblCategoryStatisticDao  {

    public void addTblCategoryStatistic(TblCategoryStatistic tblCategoryStatistic);

    public void deleteTblCategoryStatistic(TblCategoryStatistic tblCategoryStatistic);

    public void updateTblCategoryStatistic(TblCategoryStatistic tblCategoryStatistic);

    public List<TblCategoryStatistic> getAllTblCategoryStatistic();

    public List<TblCategoryStatistic> findTblCategoryStatistic(Object... values) throws Exception;

    public List<TblCategoryStatistic> findByCountTblCategoryStatistic(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCategoryStatisticCount();

    public void saveUpdateAllTblCategoryStatistic(List<TblCategoryStatistic> tblCategoryStatistics);
}