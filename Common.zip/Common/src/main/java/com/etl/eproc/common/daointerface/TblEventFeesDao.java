package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.etender.model.TblEventFees;
import java.util.List;

public interface TblEventFeesDao  {

    public void addTblTenderFees(TblEventFees tblEventFees);

    public void deleteTblTenderFees(TblEventFees tblEventFees);

    public void updateTblTenderFees(TblEventFees tblEventFees);

    public List<TblEventFees> getAllTblEventFees();

    public List<TblEventFees> findTblEventFees(Object... values) throws Exception;

    public List<TblEventFees> findByCountTblEventFees(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEventFeesCount();
    
    void saveOrUpdateTblEventFees(TblEventFees tblEventFees);

    public void saveUpdateAllTblEventFees(List<TblEventFees> tblTenderFeess);
}