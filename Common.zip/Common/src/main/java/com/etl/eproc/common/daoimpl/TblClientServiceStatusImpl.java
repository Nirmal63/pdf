package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblClientServiceStatus;
import com.etl.eproc.common.daointerface.TblClientServiceStatusDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientServiceStatusImpl extends AbcAbstractClass<TblClientServiceStatus> implements TblClientServiceStatusDao {

    @Override
    public void addTblClientServiceStatus(TblClientServiceStatus tblClientServiceStatus){
        super.addEntity(tblClientServiceStatus);
    }

    @Override
    public void deleteTblClientServiceStatus(TblClientServiceStatus tblClientServiceStatus) {
        super.deleteEntity(tblClientServiceStatus);
    }

    @Override
    public void updateTblClientServiceStatus(TblClientServiceStatus tblClientServiceStatus) {
        super.updateEntity(tblClientServiceStatus);
    }

    @Override
    public List<TblClientServiceStatus> getAllTblClientServiceStatus() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientServiceStatus> findTblClientServiceStatus(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientServiceStatusCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientServiceStatus> findByCountTblClientServiceStatus(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientServiceStatus(List<TblClientServiceStatus> tblClientServiceStatuss){
        super.updateAll(tblClientServiceStatuss);
    }
}
