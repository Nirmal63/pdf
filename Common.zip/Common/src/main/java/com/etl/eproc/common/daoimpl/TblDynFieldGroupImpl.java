package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblDynFieldGroup;
import com.etl.eproc.common.daointerface.TblDynFieldGroupDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDynFieldGroupImpl extends AbcAbstractClass<TblDynFieldGroup> implements TblDynFieldGroupDao {

    @Override
    public void addTblDynFieldGroup(TblDynFieldGroup tblDynFieldGroup){
        super.addEntity(tblDynFieldGroup);
    }

    @Override
    public void deleteTblDynFieldGroup(TblDynFieldGroup tblDynFieldGroup) {
        super.deleteEntity(tblDynFieldGroup);
    }

    @Override
    public void updateTblDynFieldGroup(TblDynFieldGroup tblDynFieldGroup) {
        super.updateEntity(tblDynFieldGroup);
    }

    @Override
    public List<TblDynFieldGroup> getAllTblDynFieldGroup() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynFieldGroup> findTblDynFieldGroup(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynFieldGroupCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynFieldGroup> findByCountTblDynFieldGroup(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDynFieldGroup(List<TblDynFieldGroup> tblDynFieldGroups){
        super.updateAll(tblDynFieldGroups);
    }
}
