package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblProductCategoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblProductCategory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblProductCategoryImpl extends AbcAbstractClass<TblProductCategory> implements TblProductCategoryDao {

    @Override
    public void addTblProductCategory(TblProductCategory tblProductCategory){
        super.addEntity(tblProductCategory);
    }

    @Override
    public void deleteTblProductCategory(TblProductCategory tblProductCategory) {
        super.deleteEntity(tblProductCategory);
    }

    @Override
    public void updateTblProductCategory(TblProductCategory tblProductCategory) {
        super.updateEntity(tblProductCategory);
    }

    @Override
    public List<TblProductCategory> getAllTblProductCategory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblProductCategory> findTblProductCategory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblProductCategoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblProductCategory> findByCountTblProductCategory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblProductCategory(List<TblProductCategory> tblProductCategorys){
        super.updateAll(tblProductCategorys);
    }
}
