package com.etl.eproc.common.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.TblBankMasterDao;
import com.etl.eproc.common.model.TblBankMaster;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.NeftRtgsService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.SelectItem;

@Controller  
public class H2HClientController {

	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private AuditTrailService auditTrailService;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private ClientService clientService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private NeftRtgsService neftRtgsService;
	@Autowired
	private TblBankMasterDao tblBankMasterDao;
	
	@Value("#{paymentConfigProperties['indBankInSuccesFiles']}")
    private String indBankInSuccesFiles;
	@Value("#{paymentConfigProperties['iciciBankInputSuccesFiles']}")
    private String iciciBankInputSuccesFiles;
	@Value("#{paymentConfigProperties['masterBackupFiles']}")
    private String masterBackupFiles;
	
	/**
	 * @param modelMap
	 * @param request
	 */
	@RequestMapping(value = "/common/admin/h2hClient/h2hUtility/{enc}", method = RequestMethod.GET)                       
	public String getH2HData(ModelMap modelMap,HttpServletRequest request){
		String retVal=null;
		try{
			modelMap.addAttribute("lstNeftClient",abcUtility.convert(clientService.getNeftRtgsActiveClient()));
			
			List<SelectItem> lstTypeOfFolder = new ArrayList<SelectItem>();
	    	lstTypeOfFolder.add(new SelectItem("CSV Input File", 1));
	    	lstTypeOfFolder.add(new SelectItem("CSV Report File", 2));
	    	lstTypeOfFolder.add(new SelectItem("Bank Archive File", 3));
	    	lstTypeOfFolder.add(new SelectItem("Bank MasterBackup File", 4));
	    	
	    	modelMap.addAttribute("lstTypeOfFolder", lstTypeOfFolder);
	    	
	    	List<Object[]> allDomainList=  commonService.getAllOnlinePaymentDomain();
			List<SelectItem> domainList = new ArrayList<SelectItem>();
			if(allDomainList!=null && !allDomainList.isEmpty()){
				for (Object[] objects : allDomainList) {
					domainList.add(new SelectItem(objects[1], objects[0]));
				}
			}
			modelMap.addAttribute("domainList", domainList);
			
			List<TblBankMaster> list= tblBankMasterDao.findTblBankMaster("isActive",Operation_enum.EQ,1);
			List<SelectItem> lstBankName = new ArrayList<SelectItem>();
			if(list!=null && !list.isEmpty()){
				for (TblBankMaster bankMaster : list) {
					lstBankName.add(new SelectItem(bankMaster.getBankName(), bankMaster.getBankId()));
				}
			}
			modelMap.addAttribute("lstBankName", lstBankName);
			modelMap.addAttribute("selNumOperation", getSearch4Numeric());
			
			retVal="common/admin/H2HUtil";
		}
		catch(Exception ex){
			retVal= exceptionHandlerService.writeLog(ex);
		}
		return retVal;
	}

	/***
	 * @param request
	 * @return
	 */
	@RequestMapping(value ="/ajax/common/admin/h2hUtility/getH2hFileList", method = RequestMethod.POST)
	@ResponseBody
	public String getH2HFileList(HttpServletRequest request,HttpServletResponse response){
		StringBuffer retVal = new StringBuffer();
		try {
			int bankId=Integer.parseInt(request.getParameter("hdBankId")!=null?request.getParameter("hdBankId"):"1");
			int fileTypeId=Integer.parseInt(request.getParameter("hdFileTypeId")!=null?request.getParameter("hdFileTypeId"):"1");
			int OpFrom = StringUtils.hasLength(request.getParameter("opFrom")) ? Integer.parseInt(request.getParameter("opFrom")) : 1;
			String serchStartDate=StringUtils.hasLength(request.getParameter("txtStartDate")) ? request.getParameter("txtStartDate") : null;
			String serchEndDate=StringUtils.hasLength(request.getParameter("txtEndDate")) ? request.getParameter("txtEndDate") : serchStartDate;
			SimpleDateFormat  dt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			
			File[] files=getH2HFileFromDirectory(OpFrom, serchStartDate, serchEndDate, fileTypeId, bankId);
			
			if(files != null && files.length > 0){
				SimpleDateFormat sdf1 = new SimpleDateFormat(CommonUtility.getClientDateFormat().replace("/", "-"));
				SimpleDateFormat sdf2 = new SimpleDateFormat(CommonUtility.getClientDateFormat());
				String encryptUrl = encryptDecryptUtils.generateRedirect("common/admin/h2hUtility/downloadAllFile/"+OpFrom+"/"+sdf1.format(sdf2.parse(serchStartDate))+"/"+sdf1.format(sdf2.parse(serchEndDate))+"/"+fileTypeId+"/"+bankId,request);
            	retVal.append("<span class='pull-right' style='margin-right: 20px'><a href="+request.getServletContext().getContextPath()+"/common/admin/h2hUtility/downloadAllFile").append("/").append(OpFrom).append("/").append(sdf1.format(sdf2.parse(serchStartDate))).append("/").append(sdf1.format(sdf2.parse(serchEndDate))).append("/").append(fileTypeId).append("/").append(bankId).append(encryptUrl).append(">Download All</a></span> ");
			}
			retVal.append("<table id=\"datatablePagination\" width=\"100%\" >");
			retVal.append(" <thead>");
			retVal.append("  	<tr class=\"gradi\">");
			retVal.append("      	<th width=\"50%\">File Name </th><th width=\"40%\">Last Modified Date</th><th width=\"10%\">Download</th>                                  ");
			retVal.append("          	</tr>");
			retVal.append(" <thead>");
			
			if(files != null && files.length > 0){
				retVal.append(" <tbody>");
				for (File file : files) {
					retVal.append("<tr>");
	     			retVal.append("<td>").append(file.getName()).append("</td>");
	            	retVal.append("<td>").append(CommonUtility.convertTimezone(dt.format(new Date(file.lastModified())))).append("</td>");
	            	String encryptUrl = encryptDecryptUtils.generateRedirect("common/admin/h2hUtility/downloadFile/"+file.getName()+"/"+fileTypeId+"/"+bankId,request);
	            	retVal.append("<td><a href="+request.getServletContext().getContextPath()+"/common/admin/h2hUtility/downloadFile").append("/").append(file.getName()).append("/").append(fileTypeId).append("/").append(bankId).append(encryptUrl).append(">Download</a></td>");
	            	retVal.append("</tr>");
				}
				retVal.append("  </tbody>");
			}
			retVal.append(" </table>");
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return retVal.toString();
	}
	
	/***
	 * @param date
	 * @param fileTypeId
	 * @param bankId
	 * @return
	 */
	 public File[] getH2HFileFromDirectory(int OpFrom, String startDate, String endDate, int fileTypeId, int bankId) {
        File dir = null;
        File[] files  = null;
        StringBuilder filePath = null;
        FileFilterDateIntervalUtils filter= null;
        try{
        	filePath = new StringBuilder();
            TblBankMaster bankMaster= commonService.getTblBankMaster(bankId);
            filter = new FileFilterDateIntervalUtils(OpFrom, startDate, endDate);
            if(fileTypeId == 1){
            	filePath.append(bankMaster.getRequestBackupPath() + File.separator +"");
                dir  = new File(filePath.toString()); 
            }else if(fileTypeId == 2){
            	filePath.append(bankMaster.getResponseBackupPath() + File.separator +"");
                dir  = new File(filePath.toString()); 
            }else if(fileTypeId == 3){
            	String requestPath = bankMaster.getRequestPath().substring(0,bankMaster.getRequestPath().lastIndexOf(File.separator));
                if(bankId == 4){
                	requestPath = requestPath.substring(0,requestPath.lastIndexOf(File.separator)) +indBankInSuccesFiles;
                	filePath.append(requestPath + File.separator +"");
                }else{
                	requestPath = requestPath.substring(0,requestPath.lastIndexOf(File.separator)) +iciciBankInputSuccesFiles;
	                filePath.append(requestPath + File.separator +"");
                }
                dir  = new File(filePath.toString()); 
            }else if(fileTypeId == 4){
            	String requestPath = bankMaster.getRequestPath().substring(0,bankMaster.getRequestPath().lastIndexOf(File.separator));
                	requestPath = requestPath.substring(0,requestPath.lastIndexOf(File.separator))+masterBackupFiles;
	            filePath.append(requestPath + File.separator +"");
                dir  = new File(filePath.toString()); 
            }
            files = dir.listFiles(filter);
        }catch(Exception e){
        	exceptionHandlerService.writeLog(e);	        }
        return files;
	 }
	 
	 /***
	  * @param request
	  * @param response
	  * @return
	  */
	 @RequestMapping(value ="/common/admin/h2hUtility/downloadAllFile/{OpFrom}/{serchStartDate}/{serchEndDate}/{fileTypeId}/{bankId}/{enc}",method=RequestMethod.GET)
	 public void downloadAllH2HFile(HttpServletResponse response,@PathVariable("OpFrom")int OpFrom,@PathVariable("serchStartDate")String serchStartDate,@PathVariable("serchEndDate")String serchEndDate,@PathVariable("fileTypeId")int fileTypeId,@PathVariable("bankId")int bankId){
		 SimpleDateFormat sdf1 = new SimpleDateFormat(CommonUtility.getClientDateFormat().replace("/", "-"));
		 SimpleDateFormat sdf2 = new SimpleDateFormat(CommonUtility.getClientDateFormat());
		 FileOutputStream fos = null;
	     ZipOutputStream zipOut = null;
	     FileInputStream fis = null;
     	 try {
			 File[] files = getH2HFileFromDirectory(OpFrom, sdf2.format(sdf1.parse(serchStartDate)), sdf2.format(sdf1.parse(serchEndDate)), fileTypeId, bankId);
			 if(files.length > 0){
				 
	 			String fileName="AllH2hFile_"+new SimpleDateFormat(CommonUtility.getClientDateFormat().replace("/", "_")).format(sdf1.parse(serchStartDate))+"To"+new SimpleDateFormat(CommonUtility.getClientDateFormat().replace("/", "_")).format(sdf1.parse(serchEndDate))+".zip";
	 			String zipFilePath=System.getProperty("java.io.tmpdir")+fileName;
	 			
	 			fos = new FileOutputStream(zipFilePath);
 				zipOut = new ZipOutputStream(new BufferedOutputStream(fos));
 				for (int i = 0; i < files.length; i++) {				
 					fis = new FileInputStream(files[i]);
	                ZipEntry ze = new ZipEntry(files[i].getName());
	                
	                zipOut.putNextEntry(ze);
	                byte[] tmp = new byte[4*1024];
	                int size = 0;
	                while((size = fis.read(tmp)) != -1){
	                	zipOut.write(tmp, 0, size);
	                }
	                zipOut.flush();
	                fis.close();
				}
 				zipOut.close();
 				fos.close();
 	            File zipFile = new File(zipFilePath);
 	            if(zipFile.exists()){
 					response.setContentType("APPLICATION/OCTET-STREAM");
 		            response.setHeader("Content-Disposition","attachment; filename=\"" + fileName + "\"");

	 		        OutputStream out = response.getOutputStream();
 		            FileInputStream in = new FileInputStream(zipFile);
 		            byte[] buffer = new byte[4096];
 		            int length;
 		            while ((length = in.read(buffer)) > 0){
 		               out.write(buffer, 0, length);
 		            }
 		            in.close();
 		            out.flush();
 		            zipFile.delete();
 				}
		 	 }
		} catch (Exception e) {
			e.printStackTrace();
		}
	 }
	 
	/***
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value ="/common/admin/h2hUtility/downloadFile/{fileName}/{fileTypeId}/{bankId}/{enc}",method=RequestMethod.GET)
	public String downloadH2HFile(HttpServletResponse response,@PathVariable("fileName")String fileName,@PathVariable("fileTypeId")int fileTypeId,@PathVariable("bankId")int bankId){
		ServletOutputStream outputStream;
		InputStream fis = null;
		try {
			StringBuffer filePath = new StringBuffer();
			TblBankMaster bankMaster= commonService.getTblBankMaster(bankId);
				
			if(fileTypeId == 1){
					 filePath.append(bankMaster.getRequestBackupPath() + File.separator +"");
		             filePath.append(fileName);
		    }else if(fileTypeId == 2){
	                filePath.append(bankMaster.getResponseBackupPath() + File.separator +"");
	                filePath.append(fileName);
		    }else if(fileTypeId == 3){
		    	String requestPath = bankMaster.getRequestPath().substring(0,bankMaster.getRequestPath().lastIndexOf(File.separator));
		        if(bankId == 4){
	               	requestPath = requestPath.substring(0,requestPath.lastIndexOf(File.separator)) +indBankInSuccesFiles;
	               	filePath.append(requestPath + File.separator +"");
	               	filePath.append(fileName);
		        }else{
	             	requestPath = requestPath.substring(0,requestPath.lastIndexOf(File.separator)) +iciciBankInputSuccesFiles;
		            filePath.append(requestPath + File.separator +"");
		            filePath.append(fileName);
		        }
		    }else if(fileTypeId == 4){
		    	String requestPath = bankMaster.getRequestPath().substring(0,bankMaster.getRequestPath().lastIndexOf(File.separator));
		             	requestPath = requestPath.substring(0,requestPath.lastIndexOf(File.separator)) +masterBackupFiles;
			    filePath.append(requestPath + File.separator +"");
			    filePath.append(fileName);
		    }
				 
	        File file = new File(filePath.toString());
	        fis = new FileInputStream(filePath.toString());
            byte[] buf = new byte[(int) file.length()];
            int offset = 0;
            int numRead = 0;
            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                offset += numRead;
            }
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
            outputStream = response.getOutputStream();
            outputStream.write(buf);
            outputStream.flush();
            outputStream.close();
            fis.close();
            return null;    
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	 
	public List<SelectItem> getSearch4Numeric() {
	    List<SelectItem> items = new ArrayList<SelectItem>();
	     items.add(new SelectItem("equal", 1));
	     items.add(new SelectItem("not equal", 2));
	     items.add(new SelectItem("less", 3));
	     items.add(new SelectItem("less or equal", 4));
	     items.add(new SelectItem("greater", 5));
	     items.add(new SelectItem("greater or equal", 6));
	     items.add(new SelectItem("between", 7));
	    return items;
	}
}





class FileFilterDateIntervalUtils implements FilenameFilter{
	int OpFrom; 
	String dateStart;
	String dateEnd;
	SimpleDateFormat sdf;

	public FileFilterDateIntervalUtils(int OpFrom,String dateStart, String dateEnd) {
	    this.dateStart = dateStart;
	    this.dateEnd = dateEnd;
	    this.OpFrom=OpFrom;
	    sdf = new SimpleDateFormat(CommonUtility.getClientDateFormat());
	}
	
	public boolean accept(File dir, String name) {
		Date d = new Date(new File(dir, name).lastModified());
		String current = sdf.format(d);
		boolean isSearch=false;
		try {
			if(OpFrom == 1 && dateStart.compareTo(current) == 0){
				isSearch=true;
			}else if(OpFrom == 2 && dateStart.compareTo(current) != 0){
				isSearch=true;
			}else if(OpFrom == 3 && dateStart.compareTo(current) < 0){
				isSearch=true;
			}else if(OpFrom == 4 && dateStart.compareTo(current) <= 0){
				isSearch=true;
			}else if(OpFrom == 5 && dateStart.compareTo(current) > 0){
				isSearch=true;
			}else if(OpFrom == 6 && dateStart.compareTo(current) >= 0){
				isSearch=true;
			}else if(OpFrom == 7){
				SimpleDateFormat sdf1 = null;
				SimpleDateFormat sdf2 = null;
				if(sdf.toPattern().equalsIgnoreCase("DD/MM/YYYY")){
					sdf1 = new SimpleDateFormat("dd/MM/yyyy");
					sdf2 = new SimpleDateFormat("yyyy/MM/dd");
					if(((sdf2.format(sdf1.parse(dateStart)).compareTo(sdf2.format(sdf1.parse(current))) <= 0 && (sdf2.format(sdf1.parse(dateEnd)).compareTo(sdf2.format(sdf1.parse(current))) >= 0)))){
						isSearch=true;
					}
				}else if(sdf.toPattern().equalsIgnoreCase("MM/DD/YYYY")){
					sdf1 = new SimpleDateFormat("MM/dd/yyyy");
					sdf2 = new SimpleDateFormat("yyyy/MM/dd");
					if(((sdf2.format(sdf1.parse(dateStart)).compareTo(sdf2.format(sdf1.parse(current))) <= 0 && (sdf2.format(sdf1.parse(dateEnd)).compareTo(sdf2.format(sdf1.parse(current))) >= 0)))){
						isSearch=true;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isSearch;
	}
}
