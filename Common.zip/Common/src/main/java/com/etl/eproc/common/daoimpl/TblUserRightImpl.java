package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblUserRightDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblUserRight;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserRightImpl extends AbcAbstractClass<TblUserRight> implements TblUserRightDao {

    @Override
    public void addTblUserRight(TblUserRight tblUserRight){
        super.addEntity(tblUserRight);
    }

    @Override
    public void deleteTblUserRight(TblUserRight tblUserRight) {
        super.deleteEntity(tblUserRight);
    }

    @Override
    public void updateTblUserRight(TblUserRight tblUserRight) {
        super.updateEntity(tblUserRight);
    }

    @Override
    public List<TblUserRight> getAllTblUserRight() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserRight> findTblUserRight(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserRightCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserRight> findByCountTblUserRight(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserRight(List<TblUserRight> tblUserRights){
        super.updateAll(tblUserRights);
    }
}
