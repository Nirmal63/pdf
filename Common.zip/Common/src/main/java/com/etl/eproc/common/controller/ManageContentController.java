/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.security.cert.CRLException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509CRLEntry;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.HtmlUtils;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daoimpl.TblCertBannerImpl;
import com.etl.eproc.common.databean.IssuerDataBean;
import com.etl.eproc.common.model.TblCertBanner;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientBidTerm;
import com.etl.eproc.common.model.TblClientCertBannerMapping;
import com.etl.eproc.common.model.TblClientContentMapping;
import com.etl.eproc.common.model.TblClientDocLink;
import com.etl.eproc.common.model.TblCombo;
import com.etl.eproc.common.model.TblComboDetail;
import com.etl.eproc.common.model.TblContentManagement;
import com.etl.eproc.common.model.TblCrlDetail;
import com.etl.eproc.common.model.TblCrlMaster;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblDocumentLink;
import com.etl.eproc.common.model.TblDynControlType;
import com.etl.eproc.common.model.TblDynField;
import com.etl.eproc.common.model.TblDynFieldGroup;
import com.etl.eproc.common.model.TblDynFieldGroupMapping;
import com.etl.eproc.common.model.TblEventType;
import com.etl.eproc.common.model.TblGrade;
import com.etl.eproc.common.model.TblLanguage;
import com.etl.eproc.common.model.TblMetaTag;
import com.etl.eproc.common.model.TblSupplierInquiry;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.ManageContentService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.common.utility.SignerVerify;

/**
 *
 * @author vanita
 */
@Controller
@RequestMapping("/common")
public class ManageContentController {

	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private SignerVerify signerVerify;
	@Autowired
	private ManageContentService manageContentService;
	@Autowired
	private ClientService clientService;
	@Autowired
	private FileUploadService fileUploadService;
	@Autowired
	private AuditTrailService auditTrailService;
	@Autowired
	private DynamicFieldService dynamicFieldService;
	
	@Value("#{projectProperties['crl.allowedSize']}")
	private String allowedSize;
	@Value("#{projectProperties['fileItem_thresolSize']?:1048576}")
	private int thresoldSize;
	@Value("#{projectProperties['crl.allowedExt']}")
	private String fileExtensions;
	@Value("#{projectProperties['file.drive']}")
	private String tmpdrive;
	@Value("#{projectProperties['certfile.upload']}")
	private String tmpPath;
	@Value("#{projectProperties['errormsg.operation.fail']}")
	private String errorMsg;
	@Value("#{linkProperties['manage_combo_create_combo']?:45}")
	private int createComboLinkId; 
	@Value("#{linkProperties['manage_combo_edit_combo']?:46}")
	private int editComboLinkId; 
	@Value("#{linkProperties['manage_combo_cancel']?:48}")
	private int cancelComboLinkId; 
	@Autowired
	private ReportGeneratorService reportGeneratorService;
	@Value("#{linkProperties['report_admin_manage_combo']?:8}")
	private int manageComboReportId;
	@Value("#{linkProperties['report_admin_manage_marquee']?:9}")
	private int manageMarqueeReportId;
	@Value("#{linkProperties['report_admin_manage_news']?:10}")
	private int manageNewsReportId;
	@Value("#{linkProperties['report_admin_manage_certificatecontact']?:11}")
	private int manageCertContactReportId;
	@Value("#{linkProperties['report_admin_manage_help']?:23}")
	private int manageHelpReportId;
	@Value("#{linkProperties['report_admin_manage_client_terms_condition']?:26}")
	private int manageClientTermsConditionReportId;
	@Value("#{linkProperties['manage_marquee_view_marquee']?:51}")
	private int viewMarqueeLinkId;
	@Value("#{linkProperties['report_manage_grade_listing']?:56}")
	private int gradeListingReportId;
	@Value("#{linkProperties['report_view_supplier_inquiry']?:85}")
	private int viewSupplierInquiryReportId;
	@Value("#{linkProperties['manage_statistics_link']?:787}")
	private int manageStatisticsLinkId;
        @Value("#{linkProperties['manage_home_page_content']?:1630}")
	private int manageHomePageLinkId;
	@Value("#{linkProperties['view_supplier_link']?:788}")
	private int viewSupplierLinkId;
	@Value("#{projectProperties['file.drive']}")
    private String drive;
    @Value("#{projectProperties['file.upload']}")
    private String upload;
    @Value("#{projectProperties['doc_upload_path']}")
    private String docUpload;
	@Value("#{linkProperties['registration_terms_and_conditions_create_create']?:790}")
    private int createBidderTermsLinkId;
	@Value("#{linkProperties['registration_terms_and_conditions_manage_edit']?:791}")
    private int editBidderTermsLinkId;
	@Value("#{linkProperties['registration_terms_and_conditions_manage_view']?:793}")
    private int viewBidderTermsLinkId;
	@Value("#{linkProperties['report_manage_group_listing']?:103}")
	private int groupListingReportId;

	private static final String CONTENTYPE="contentType";
	private static final String HIDDEN_CLIENT_ID="hdClientId";
	private static final String REDIRECT="redirect:/";
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private CommonService commonService;

	@Value("#{linkProperties['report_admin_manage_help']?:23}")
	private int manageHelpLinkId;

	@Autowired
	private ConversionService conversionService;
	@Autowired
	private MessageSource messageSource;

	@Value("#{linkProperties['manage_client_client_terms_and_condition']?:154}")
	private int manageClientTermsConditionLinkId;
	@Value("#{linkProperties['manage_certificate_contacts_create_certificate_contacts']?:60}")
	private int manageCertificateCreateContactLinkId;

	@Value("#{linkProperties['manage_certificate_contacts_edit_certificate_contacts']?:61}")
	private int manageCertificateEditContactLinkId;

	@Value("#{linkProperties['manage_crls_manage_crls']?:63}")
	private int manageCrlLinkId;

	@Value("#{linkProperties['manage_meta_tags_manage_meta_tags']?:59}")
	private int manageMetaTagLinkId;

	@Value("#{linkProperties['manage_marquee_create_marquee']?:49}")
	private int marqueeLinkId;

	@Value("#{linkProperties['manage_marquee_edit_marquee']?:50}")
	private int editMarqueeLinkId;

	@Value("#{linkProperties['manage_marquee_cancel']?:52}")
	private int cancelMarqueeLinkId;

	@Value("#{linkProperties['manage_news_create_news']?:53}")
	private int createNewsLinkId;

	@Value("#{linkProperties['manage_news_edit_news']?:54}")
	private int editNewsLinkId;

	@Value("#{linkProperties['manage_news_cancel']?:56}")
	private int cancelNewsLinkId;

	@Value("#{linkProperties['manage_about_us_manage_about_us']?:57}")
	private int manageAboutUs;
        @Value("#{linkProperties['manage_home_page_content']?:1630}")
	private int manageHomeContent;

	@Value("#{linkProperties['manage_contact_us_manage_contact_us']?:58}")
	private int manageContactUs;
	@Value("#{linkProperties['manage_banner_create_banner']?:591}")
	private int manageBannerCreateBanner;
	@Value("#{linkProperties['manage_banner_manage_banner']?:592}")
	private int manageBannerManageBanner;
	@Value("#{linkProperties['manage_banner_remove_banner']?:593}")
	private int manageBannerRemoveBanner;
	
	@Value("#{adminAuditTrailProperties['getManageHelp']}")
	private String getManageHelp;
	@Value("#{adminAuditTrailProperties['getComboCreatePage']}")
	private String getComboCreatePage;
	@Value("#{adminAuditTrailProperties['getEditComboPage']}")
	private String getEditComboPage;
	@Value("#{adminAuditTrailProperties['getManageComboPage']}")
	private String getManageComboPage;
	@Value("#{adminAuditTrailProperties['getClientTermsCondition']}")
	private String getClientTermsCondition;
	@Value("#{adminAuditTrailProperties['getUpdateClientTermsCondition']}")
	private String getUpdateClientTermsCondition;
	@Value("#{adminAuditTrailProperties['getViewBidderTermsCondition']}")
	private String getViewBidderTermsCondition;
	@Value("#{adminAuditTrailProperties['getAddBidderTermsCondition']}")
	private String getAddBidderTermsCondition;
        @Value("#{adminAuditTrailProperties['getHomePageContent']}")
	private String getHomePageContent;
	@Value("#{adminAuditTrailProperties['getEditBidderTermsCondition']}")
	private String getUpdateBidderTermsCondition;
	@Value("#{adminAuditTrailProperties['postClientTermsConditionAdd']}")
	private String postClientTermsConditionAdd;
	@Value("#{adminAuditTrailProperties['postClientTermsConditionUpdate']}")
	private String postClientTermsConditionUpdate;
	@Value("#{adminAuditTrailProperties['getManageClientTermsCondition']}")
	private String getManageClientTermsCondition;
	@Value("#{adminAuditTrailProperties['getCRLDocumentPage']}")
	private String getCRLDocumentPage;
	@Value("#{adminAuditTrailProperties['postCRLDocumentUploaded']}")
	private String postCRLDocumentUploaded;
	@Value("#{adminAuditTrailProperties['getMetaTagPage']}")
	private String getMetaTagPage;
	@Value("#{adminAuditTrailProperties['postMetaTagCreated']}")
	private String postMetaTagCreated;
	@Value("#{adminAuditTrailProperties['postMetaTagEdited']}")
	private String postMetaTagEdited;
	@Value("#{adminAuditTrailProperties['getAddIssuer']}")
	private String getAddIssuer;
	@Value("#{adminAuditTrailProperties['getCertiContactPage']}")
	private String getCertiContactPage;
	@Value("#{adminAuditTrailProperties['postComboCreated']}")
	private String postComboCreated;
	@Value("#{adminAuditTrailProperties['postUpdateCombo']}")
	private String postUpdateCombo;
	@Value("#{adminAuditTrailProperties['postCertiContactCreated']}")
	private String postCertiContactCreated;
	@Value("#{adminAuditTrailProperties['postCertiContactUpdated']}")
	private String postCertiContactUpdated;
	@Value("#{adminAuditTrailProperties['gettCertiContactEdit']}")
	private String gettCertiContactEdit;
	@Value("#{adminAuditTrailProperties['getDeactivateCertContact']}")
	private String getDeactivateCertContact;
	@Value("#{adminAuditTrailProperties['postAddnewIssuer']}")
	private String postAddnewIssuer;
	@Value("#{adminAuditTrailProperties['getDeleteIssuerPage']}")
	private String getDeleteIssuerPage;
	@Value("#{adminAuditTrailProperties['getComboCancelled']}")
	private String getComboCancelled;

	@Value("#{adminAuditTrailProperties['getEditHelpPage']}")
	private String getEditHelpPage;
	@Value("#{adminAuditTrailProperties['postEditHelpPage']}")
	private String postEditHelpPage;
	@Value("#{adminAuditTrailProperties['getViewHelpPage']}")
	private String getViewHelpPage;

	@Value("#{adminAuditTrailProperties['getCreateNews']}")
	private String getCreateNews;

	@Value("#{adminAuditTrailProperties['getEditNews']}")
	private String getEditNews;

	@Value("#{adminAuditTrailProperties['getEditMarquee']}")
	private String getEditMarquee;
	@Value("#{adminAuditTrailProperties['getCreateMarquee']}")
	private String getCreateMarquee;
	@Value("#{adminAuditTrailProperties['getContactUs']}")
	private String getContactUs;
	@Value("#{adminAuditTrailProperties['getAboutUs']}")
	private String getAboutUs;
	@Value("#{adminAuditTrailProperties['postEditMarquee']}")
	private String postEditMarquee;
	@Value("#{adminAuditTrailProperties['postCreateMarquee']}")
	private String postCreateMarquee;
	@Value("#{adminAuditTrailProperties['postEditNews']}")
	private String postEditNews;
	@Value("#{adminAuditTrailProperties['postCreateNews']}")
	private String postCreateNews;
	@Value("#{adminAuditTrailProperties['postContactUs']}")
	private String postContactUs;
	@Value("#{adminAuditTrailProperties['postAboutUs']}")
	private String postAboutUs;
	@Value("#{adminAuditTrailProperties['postGetDomains']}")
	private String postGetDomains;
	@Value("#{adminAuditTrailProperties['getDeleteMarquee']}")
	private String getDeleteMarquee;
	@Value("#{adminAuditTrailProperties['getDeleteNews']}")
	private String getDeleteNews;

	@Value("#{adminAuditTrailProperties['getViewMarquee']}")
	private String getViewMarquee;
	@Value("#{adminAuditTrailProperties['getViewNews']}")
	private String getViewNews;
	
	@Value("#{adminAuditTrailProperties['getManagebannerPage']}")
	private String getManagebannerPage;
	@Value("#{adminAuditTrailProperties['getDeactivemanagerbannerPage']}")
	private String getDeactivemanagerbannerPage;
	@Value("#{adminAuditTrailProperties['postManagebanner']}")
	private String postManagebanner;
	@Value("#{adminAuditTrailProperties['getManageStatistics']}")
	private String getManageStatistics;
	@Value("#{adminAuditTrailProperties['postManageStatistics']}")
	private String postManageStatistics;
	@Value("#{adminAuditTrailProperties['getViewInquiry']}")
	private String getViewInquiry;
	@Value("#{adminAuditTrailProperties['getViewInquiryComments']}")
	private String getViewInquiryComments;
	
	@Value("#{adminAuditTrailProperties['createBanner']}")
	private String createBanner;
	@Value("#{adminAuditTrailProperties['saveBanner']}")
	private String saveBanner;
	@Value("#{linkProperties['manage_download_create']?:734}")
	private int manageDownloadCreate; 
	@Value("#{linkProperties['manage_download_edit']?:735}")
	private int manageDownloadEdit; 
	@Value("#{linkProperties['manage_download_view']?:736}")
	private int manageDownloadView; 
	@Value("#{linkProperties['manage_download_document_upload']?:737}")
	private int manageDownloadDocumentUpload; 
	@Value("#{linkProperties['manage_download_document_download']?:738}")
	private int manageDownloadDocumentDownload; 
	@Value("#{linkProperties['manage_download_document_delete']?:739}")
	private int manageDownloadDocumentDelete; 
	@Value("#{projectProperties['officer.docstatus.approve']?:1}")
	private int officerDocStatusApprove;
	@Value("#{linkProperties['report_mobile_list']?:138}")
	private int mobileListingReportId;
	@Autowired
	private ModelToSelectItem modelToSelectItem;
	
        
	private void setCreateComboValues(ModelMap modelMap) {
		List<SelectItem> calcRadio = new ArrayList<SelectItem>();
		calcRadio.add(new SelectItem("Yes", 1)); 
		calcRadio.add(new SelectItem("No", 0));
		modelMap.addAttribute("calcRadio", calcRadio);
		
		List<SelectItem> listType = new ArrayList<SelectItem>();
		listType.add(new SelectItem("Combo box", 1)); 
		listType.add(new SelectItem("List box", 2));
		modelMap.addAttribute("listType", listType);
	}

	/** To Display create combo page
	 * @Author Shreyansh.shah
	 * @param modelMap
	 * @return 
	 */
	@RequestMapping(value = "/admin/createcombo/{enc}", method = RequestMethod.GET)
	public String initCreateCombo(ModelMap modelMap,HttpServletRequest request) {
		try {
			setCreateComboValues(modelMap);
			modelMap.addAttribute("operType","create");
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createComboLinkId, getComboCreatePage,0,0);
		}
		return "common/admin/CreateCombo";
	}
	/** To Display edit combo page
	 * @Author Shreyansh.shah
	 * @param modelMap
	 * @param request
	 * @param comboId
	 * @return 
	 */
	@RequestMapping(value = "/admin/editcombo/{comboId}/{enc}", method = RequestMethod.GET)
	public String initeditCombo(ModelMap modelMap,HttpServletRequest request,@PathVariable("comboId") int comboId) {
		try {
			setCreateComboValues(modelMap);
			modelMap.addAttribute("tblCombo",manageContentService.getComboById(comboId));
			modelMap.addAttribute("tblComboDetails",manageContentService.getComboDetailByComboId(comboId));
			modelMap.addAttribute("operType","edit");
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
                finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editComboLinkId, getEditComboPage,0,comboId);
		}
		return "common/admin/CreateCombo";
	}

	@RequestMapping(value = "/admin/managecombo/{enc}", method = RequestMethod.GET)
	public String listCombo(ModelMap modelMap,HttpServletRequest request) {
		try {
			modelMap.addAttribute("reportId", manageComboReportId);
			reportGeneratorService.getReportConfigDetails(manageComboReportId, modelMap);
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getManageComboPage,0,0);
		}
		return "common/admin/ManageCombo";
	}
	@RequestMapping(value = "/admin/managehelp/{enc}", method = RequestMethod.GET)
	public String manageHelp(ModelMap modelMap,HttpServletRequest request) {
		try {
			modelMap.addAttribute("reportId", manageHelpReportId);
			reportGeneratorService.getReportConfigDetails(manageHelpReportId, modelMap);
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getManageHelp,0,0);
		}
		return "common/admin/ManageHelp";
	}
	
	/**
	 * To create client terms and condition
	 * @author nirav.modi
	 * @param modelMap
	 * @param request
	 */
	@RequestMapping(value = "/admin/createclienttermscondition/{clientId}/{enc}", method = RequestMethod.GET)                       
	public String createClientTermsCondition(@PathVariable("clientId") int clientId, ModelMap modelMap,HttpServletRequest request,RedirectAttributes redirectAttributes){
		String retVal=null;
		try{
			List<Object[]> eventTypeList=manageContentService.getEventTypeByClientId(clientId);
			if(eventTypeList!=null && !eventTypeList.isEmpty()){
				modelMap.addAttribute("clientLanguageList", clientService.getClientLanguageToSelect(clientId));
				modelMap.addAttribute("eventTypeList",abcUtility.convert(eventTypeList));
				retVal="common/admin/ClientTermsCondition";
			}else{//Condition: if Configurations are already done at that time 
				redirectAttributes.addFlashAttribute("waringMsg","redirect_warning_terms_condition_already_done");
				retVal="redirect:/common/admin/searchlistclient"+ encryptDecryptUtils.generateRedirect("common/admin/searchlistclient", request);	
			}
		}
		catch(Exception ex){
			retVal= exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageClientTermsConditionLinkId, getClientTermsCondition,0,clientId);
		}
		return retVal;
	}

	/**
	 * To add client terms and condition
	 * @author nirav.modi
	 * @param redirectAttributes
	 * @param request
	 */
	@RequestMapping(value = "/admin/addclienttermscondition", method = RequestMethod.POST)                       
	public String addClientTermsCondition(RedirectAttributes redirectAttributes, HttpServletRequest request){
		boolean success = false;
		int clientId=0;
		String bidTerm=null;
		String retVal=null;
		TblClientBidTerm tblClientBidTerm = null;
		try{
			int userId=abcUtility.getSessionUserId(request);
			int bidTermFor=StringUtils.hasLength(request.getParameter("selBidTermFor"))?Integer.parseInt(request.getParameter("selBidTermFor")):0;
			clientId=StringUtils.hasLength(request.getParameter(HIDDEN_CLIENT_ID))?Integer.parseInt(request.getParameter(HIDDEN_CLIENT_ID)):0;
			List<Object[]> clientLanguageList = clientService.getClientLanguageToSelect(clientId);
			if(clientId !=0 && userId!=0 && bidTermFor!=0 && clientLanguageList!=null && !clientLanguageList.isEmpty()){
				List<TblClientBidTerm> tblClientBidTerms= new ArrayList<TblClientBidTerm>();
					for(Object[] languageData: clientLanguageList){
						TblClientBidTerm tblClientBidTerm1 =manageContentService.getClientBidTermByEventTypeId(bidTermFor,clientId,(Integer)languageData[0]);
						if(tblClientBidTerm1 == null){
							bidTerm=request.getParameter("rtfBidTerm_"+languageData[0]);
							tblClientBidTerm = new TblClientBidTerm();
							tblClientBidTerm.setTblLanguage(new TblLanguage((Integer)languageData[0]));
							tblClientBidTerm.setBidTerm(bidTerm);
							tblClientBidTerm.setTblEventType(new TblEventType(bidTermFor));
							tblClientBidTerm.setCreatedBy(userId);
							tblClientBidTerm.setIsActive(1);
							tblClientBidTerm.setTblClient(new TblClient(clientId));
							tblClientBidTerms.add(tblClientBidTerm);
					}
				}
				success= manageContentService.addClientTermsCondition(tblClientBidTerms);
			}
			retVal= success?"common/admin/manageclienttermscondition/"+clientId : "common/admin/createclienttermscondition/"+clientId;
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageClientTermsConditionLinkId, postClientTermsConditionAdd,success?tblClientBidTerm.getClientBidTermId(): 0,clientId);
		}
		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_terms_condition" : CommonKeywords.ERROR_MSG_KEY.toString());
		return REDIRECT+retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	}
	
	/**
	 * To edit client terms and condition
	 * @author nirav.modi
	 * @param modelMap
	 * @param request
	 */
	@RequestMapping(value = "/admin/editclienttermscondition/{clientId}/{clientBidTermId}/{languageId}/{eventTypeId}/{enc}", method = RequestMethod.GET)                       
	public String editClientTermsCondition(@PathVariable("clientId") int clientId,@PathVariable("clientBidTermId") int clientBidTermId,@PathVariable("languageId") int languageId,@PathVariable("eventTypeId") int eventTypeId,ModelMap modelMap,HttpServletRequest request){
		String retVal=null;
		try{
			if(clientBidTermId!=0){
				List<Object[]> clientBidTermDataList= manageContentService.getClientBidTermDataByClientBidTermId(clientBidTermId);
				if(clientBidTermDataList!=null && !clientBidTermDataList.isEmpty()){
					modelMap.addAttribute("clientBidTermData",clientBidTermDataList.get(0));
				}
			}else{
    			TblEventType tblEventType=manageContentService.getEventTypeById(eventTypeId);
    			modelToSelectItem.getLangObject(tblEventType,WebUtils.getCookie(request, "locale").getValue(),"eventType");
				modelMap.addAttribute("tblEventType",tblEventType);
				modelMap.put("languageName", clientService.getLanguageById(languageId).getLanguage());
			}
			retVal="common/admin/UpdateClientTermsCondition";
		}
		catch(Exception ex){
			retVal= exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageClientTermsConditionLinkId, getUpdateClientTermsCondition,0,clientBidTermId);
		}
		return retVal;
	}
	
	
	/**
	 * To edit client terms and condition
	 * @author nirav.modi
	 * @param modelMap
	 * @param request
	 */
	@RequestMapping(value = "/admin/viewclienttermscondition/{clientBidTermId}/{clientId}/{enc}", method = RequestMethod.GET)                       
	public String viewClientTermsCondition(@PathVariable("clientBidTermId") int clientBidTermId,@PathVariable("clientId") int clientId,ModelMap modelMap,HttpServletRequest request){
		String retVal=null;
		try{
			if(clientBidTermId!=0){
				List<Object[]> clientBidTermDataList= manageContentService.getClientBidTermDataByClientBidTermId(clientBidTermId);
				if(clientBidTermDataList!=null && !clientBidTermDataList.isEmpty()){
					modelMap.addAttribute("clientBidTermData",clientBidTermDataList.get(0));
				}
			}
			retVal="common/admin/ViewClientTermsCondition";
		}
		catch(Exception ex){
			retVal= exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageClientTermsConditionLinkId, getUpdateClientTermsCondition,0,clientBidTermId);
		}
		return retVal;
	}
	
	/**
	 * To update client terms condition by language id
	 * @author nirav.modi
	 * @param redirectAttributes
	 * @param request
	 */
	@RequestMapping(value = "/admin/updateclienttermscondition", method = RequestMethod.POST)                       
	public String updateClientTermsCondition(RedirectAttributes redirectAttributes, HttpServletRequest request){
		boolean success = false;
		int clientId=0;
		int clientBidTermId=0;
		String retVal=null;
		TblClientBidTerm tblClientBidTerm = null;
		try{
			int userId=abcUtility.getSessionUserId(request);
			int languageId=StringUtils.hasLength(request.getParameter("hdLanguageId"))?Integer.parseInt(request.getParameter("hdLanguageId")):0;
			int eventTypeId=StringUtils.hasLength(request.getParameter("hdEventTypeId"))?Integer.parseInt(request.getParameter("hdEventTypeId")):0;
			String bidTerm=request.getParameter("rtfBidTerm");
			clientId=StringUtils.hasLength(request.getParameter(HIDDEN_CLIENT_ID))?Integer.parseInt(request.getParameter(HIDDEN_CLIENT_ID)):0;
			clientBidTermId=StringUtils.hasLength(request.getParameter("hdClientBidTermId"))?Integer.parseInt(request.getParameter("hdClientBidTermId")):0;
			TblClientBidTerm tblClientBidTerm1 = null;
			if(clientBidTermId==0){
				 tblClientBidTerm1 =manageContentService.getClientBidTermByEventTypeId(eventTypeId,clientId,languageId);
			}else{
				 tblClientBidTerm1 =manageContentService.getClientBidTermById(clientBidTermId);
			}
			if(userId!=0 && StringUtils.hasLength(bidTerm)&& (tblClientBidTerm1==null || (tblClientBidTerm1.getIsActive()==1 && clientBidTermId!=0))){
				tblClientBidTerm = new TblClientBidTerm();
				tblClientBidTerm.setClientBidTermId(clientBidTermId);
				tblClientBidTerm.setTblLanguage(new TblLanguage(languageId));
				tblClientBidTerm.setBidTerm(bidTerm);
				tblClientBidTerm.setTblEventType(new TblEventType(eventTypeId));
				tblClientBidTerm.setIsActive(1);
				tblClientBidTerm.setCreatedBy(userId);
				tblClientBidTerm.setTblClient(new TblClient(clientId));
				tblClientBidTerm.setChildId(0);
				success= manageContentService.addOrUpdateClientTermsCondition(tblClientBidTerm);
			}
			retVal= success?"common/admin/manageclienttermscondition/"+clientId : "common/admin/editclienttermscondition/"+clientId+"/"+clientBidTermId+"/"+languageId+"/"+eventTypeId;
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageClientTermsConditionLinkId, postClientTermsConditionUpdate,success?tblClientBidTerm.getClientBidTermId():0,clientId);
		}
		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? clientBidTermId==0 ?"redirect_success_terms_condition": "redirect_success_terms_condition_update" : CommonKeywords.ERROR_MSG_KEY.toString());
		return REDIRECT+retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	}
	
	/**
	 * To manage client terms and condition
	 * @author nirav.modi
	 * @param modelMap
	 * @param request
	 */
	@RequestMapping(value = "/admin/manageclienttermscondition/{clientId}/{enc}", method = RequestMethod.GET)                       
	public String manageClientTermsCondition(ModelMap modelMap, HttpServletRequest request,@PathVariable("clientId")int clientId){
		try{
			modelMap.addAttribute("reportId", manageClientTermsConditionReportId);
			reportGeneratorService.getReportConfigDetails(manageClientTermsConditionReportId, modelMap);
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageClientTermsConditionLinkId, getManageClientTermsCondition,0,0);
		}
		return "common/admin/ManageClientTermsCondition";
	}
	
	/**
	 * Use to get listing of crl
	 * @author nirav.modi
	 * @param modelMap
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/manageCRL/{enc}", method = RequestMethod.GET)
	public String listAndUploadCRLFile(ModelMap modelMap,HttpServletRequest request) {
		try {
			modelMap.put("crlMasterList", manageContentService.getCrlMasterList());
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageCrlLinkId, getCRLDocumentPage, 0,0);
		}
		return "common/admin/ManageCRL";
	}

	/**
	 * Use to submit  crl
	 * @author nirav.modi
	 * @param session
	 * @param redirectAttributes
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/addcrl", method = RequestMethod.POST)
	public String addCrl(HttpSession session, RedirectAttributes redirectAttributes, HttpServletRequest request) {// TODO : Remove unused method param.
		boolean success = false;
		//String signedData = null; 
		//Object[] data = null; 
		File tmpDir = null;
		String fileName = null;
		InputStream inStream = null;
		TblCrlMaster tblCrlMaster = null;
		int isProcedureExecuted = 0;
		try {
			if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
				SessionBean sessionBean = (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
				if (sessionBean != null) {
					boolean fileUploadedSuccess = false;
					File file = null;
					String fileDir = ""; //TODO : declare in else only. Limited scope.
					long fileSize = 0; //TODO : declare in if only. Limited scope.
					long fileMaxSize = Long.parseLong(allowedSize) * 1024; //TODO : declare in if only. Limited scope.
					isDirExists(tmpdrive, tmpPath);
					String tmpDirPath = tmpdrive + tmpPath;
					DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
					fileItemFactory.setSizeThreshold(1 * thresoldSize);
					ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
					List items = uploadHandler.parseRequest(request);
					Iterator itr = items.iterator();

					while (itr.hasNext()) {
						FileItem item = (FileItem) itr.next();

						if (!item.isFormField()) {
							fileSize = item.getSize();

							if (item.getName().lastIndexOf("\\") != -1) {
								fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1, item.getName().length());
							} else {
								fileName = item.getName();
							}

							if (StringUtils.hasLength(fileName) ) { 
								if (!checkFileSize(fileSize, fileMaxSize)) {
									redirectAttributes.addFlashAttribute("fileError", messageSource.getMessage("msg_crl_maxfilesize", new Object[]{fileMaxSize / 1024 / 1024}, LocaleContextHolder.getLocale()));
									return "redirect:/common/admin/manageCRL" + encryptDecryptUtils.generateRedirect("common/admin/manageCRL", request); //TODO : use single return statement.
								}
								if (!checkFileExn(fileName, fileExtensions)) {
									redirectAttributes.addFlashAttribute("fileError", messageSource.getMessage("invalid_crl_file", null, LocaleContextHolder.getLocale()));
									return "redirect:/common/admin/manageCRL" + encryptDecryptUtils.generateRedirect("common/admin/manageCRL", request);
								} else {
									fileDir = "CRL";
									tmpDir = new File(tmpDirPath + "\\" + fileDir);

									if (!tmpDir.isDirectory()) {
										tmpDir.mkdir();
									}

									file = new File(tmpDir, fileName);

									if (file.isFile()) {
										file.delete();
									}
									item.write(file);
									fileUploadedSuccess = true;
								}
							}
						} else {
							if (item.getFieldName().equals("signEncData")) {
								String signedData = item.getString();
								Object[] data = null;
								if (StringUtils.hasLength(signedData)) { 
									data = signerVerify.verify(signedData);
								}
								if (!(StringUtils.hasLength(signedData) && !signedData.contains("'") && !signedData.contains("\"") && data[1] != null && (Boolean) data[1])) {
									fileUploadedSuccess = false;
									success = false;
									break;
								}
							}
						}
					}
					try{
						if (fileUploadedSuccess) {
							tblCrlMaster = new TblCrlMaster();
							List<TblCrlDetail> tblCrlDetailList = new ArrayList<TblCrlDetail>();
							inStream = new FileInputStream(file.getAbsolutePath());
							CertificateFactory cf = CertificateFactory.getInstance("X.509");
							X509CRL crl = (X509CRL) cf.generateCRL(inStream);
							String issuer = crl.getIssuerDN().getName();
							inStream.close();
							Set<? extends X509CRLEntry> s =  crl.getRevokedCertificates();
							if(s!=null && !s.isEmpty()){
								Iterator<? extends X509CRLEntry> i = s.iterator();
								tblCrlMaster.setIssuer(issuer);
								tblCrlMaster.setCreatedBy(sessionBean.getUserId());
								tblCrlMaster.setCstatus(1);
								while (i.hasNext()) {
									TblCrlDetail tblCrlDetail = new TblCrlDetail();
									X509CRLEntry certEntry = (X509CRLEntry) i.next();
									BigInteger srNo = certEntry.getSerialNumber();
									java.util.Date rDate = certEntry.getRevocationDate();
									tblCrlDetail.setSerialNo(srNo.toString(16).toUpperCase());
									tblCrlDetail.setRevokedOn(rDate);
									tblCrlDetailList.add(tblCrlDetail);
								}
								success = manageContentService.addCRL(tblCrlMaster, tblCrlDetailList);
								Map<String,Object> outMap= manageContentService.getRevokedDCTransferToAllServer();
								if(outMap != null && !outMap.isEmpty())
								isProcedureExecuted = (Integer)((List<Map<String, Object>>) outMap.get("#result-set-1")).get(0).get("cStatus");
							}
						}
					}catch (CRLException e) {
						redirectAttributes.addFlashAttribute("fileError", messageSource.getMessage("invalid_crl_file", null,LocaleContextHolder.getLocale()));
						if (inStream != null) {
							try {
								inStream.close();
							} catch (IOException ie) {
								return exceptionHandlerService.writeLog(e);
							}
						}
						File f = new File(tmpDir, fileName);
						if (f.exists()) {
							f.delete();
						}
					}
				} else {
					return "redirect:/common/admin/manageCRL" + encryptDecryptUtils.generateRedirect("common/admin/manageCRL", request);
				}
			}
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageCrlLinkId, postCRLDocumentUploaded, 0,tblCrlMaster!=null && success?tblCrlMaster.getCrlId():0);
		}
		if(success && isProcedureExecuted==1){
		redirectAttributes.addFlashAttribute(success? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG_KEY.toString(),
				success? "redirect_success_crl_file" : CommonKeywords.ERROR_MSG.toString());
		}
		else 
		{
		redirectAttributes.addFlashAttribute(success? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG_KEY.toString(),
				success? "redirect_success_crl_file_revoked_DC_failed" : CommonKeywords.ERROR_MSG.toString());
		}
		return "redirect:/common/admin/manageCRL" + encryptDecryptUtils.generateRedirect("common/admin/manageCRL", request);
	}

	/**
	 * check file extension
	 *
	 * @param fileName
	 * @param allowExtensions
	 * @return boolean
	 */
	private boolean checkFileExn(String fileName, String allowExtensions) {
		boolean chextn = false;
		int j = fileName.lastIndexOf('.');
		String lst = fileName.substring(j + 1);
		String str = allowExtensions;
		String[] str1 = str.split(",");
		for (int i = 0; i < str1.length; i++) {
			if (str1[i].trim().equalsIgnoreCase(lst)) {
				chextn = true;
			}
		}
		return chextn;
	}

	/**
	 * Check file Size
	 *
	 * @param fielSize
	 * @param maxFileSize
	 * @return boolean
	 */
	private boolean checkFileSize(long fielSize, long maxFileSize) {
		boolean chextn = false;
		if (maxFileSize>fielSize) {
			chextn = true;
		} else {
			chextn = false;
		}
		return chextn;
	}

	/**
	 * create directory if it does not exists
	 *
	 * @param drive
	 * @param rpath
	 * @return boolean
	 */
	private boolean isDirExists(String drive, String rpath) {
		boolean flag = false;
		String[] tpath = rpath.split("\\\\");
		StringBuilder path = new StringBuilder();
		path.append(drive);

		for (int i = 0; i < tpath.length; i++) {
			path.append("\\").append(tpath[i]);

			File f = new File(path.toString());

			if (!f.isDirectory()) {
				f.mkdir();
			}
		}
		return flag;
	}


	/**
	 * Use for creation of Meta tag and edit case of meta tag 
	 * @author nirav.modi
	 * @param modelMap
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/metatag/{enc}", method = RequestMethod.GET)
	public String metaTag(ModelMap modelMap,HttpServletRequest request) {
		ClientBean clientBean = null;
		try {              
			clientBean= (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
			List<Object[]> metaTagDetails= manageContentService.getMetaTagByClientId(clientBean!=null?clientBean.getClientId():0); // if meta tag already added then it will get details of that metatag by client id
			if(metaTagDetails!= null && !metaTagDetails.isEmpty()){
				Object[] objects= metaTagDetails.get(0);
				if(objects!=null && objects.length!=0){
					modelMap.addAttribute("metaTagId",objects[0]);
					modelMap.addAttribute("titleVal", objects[1]);
					modelMap.addAttribute("keywordVal", objects[2]);
					modelMap.addAttribute("descriptionVal", objects[3]);
					modelMap.addAttribute("opType","update");
				}
			}
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageMetaTagLinkId, getMetaTagPage, 0,clientBean!=null?clientBean.getClientId():0);
		}
		return "common/admin/MetaTag";
	}

	/**
	 * Use to create new metatag for client
	 * @author nirav.modi
	 * @param redirectAttributes
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/addmetatag", method = RequestMethod.POST)                       
	public String addMetaTag(RedirectAttributes redirectAttributes, HttpServletRequest request){ 
		boolean success = false;
		String retVal=null;
		TblMetaTag tblMetaTag = null;
		try{
			String title =request.getParameter("txtTitle");
			String description =request.getParameter("txtaDescription");
			String keyword =request.getParameter("txtaKeyword");
			int createdBy = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserId();
			ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
			if(StringUtils.hasLength(title) && StringUtils.hasLength(description) && StringUtils.hasLength(keyword)){
				tblMetaTag = new TblMetaTag();
				tblMetaTag.setKeyword(keyword);
				tblMetaTag.setDescription(description);
				tblMetaTag.setTitle(title);
				tblMetaTag.setTblClient(new TblClient(clientBean.getClientId()));
				tblMetaTag.setCreatedBy(createdBy);
				success=manageContentService.addMetaTag(tblMetaTag);
			}
			retVal="common/admin/metatag";
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageMetaTagLinkId, postMetaTagCreated, 0,tblMetaTag!=null?tblMetaTag.getMetaTagId():0);
		}
		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_create_metatag" : CommonKeywords.ERROR_MSG_KEY.toString());
		return REDIRECT+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
	}

	/**
	 * Use to update metatag 
	 * @author nirav.modi
	 * @param redirectAttributes
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/updatemetatag", method = RequestMethod.POST)                       
	public String updateMetaTag(RedirectAttributes redirectAttributes, HttpServletResponse response, HttpServletRequest request){
		boolean success = false;
		String retVal=null;
		String metaTagId =null;
		try{
			String title =request.getParameter("txtTitle");
			String description =request.getParameter("txtaDescription");
			String keyword =request.getParameter("txtaKeyword");
			metaTagId = request.getParameter("hdMetaTagId");
			//int createdBy = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserId();
			if(StringUtils.hasLength(metaTagId) && StringUtils.hasLength(title) && StringUtils.hasLength(description) && StringUtils.hasLength(keyword)){ 
				TblMetaTag tblMetaTag = new TblMetaTag();
				tblMetaTag.setMetaTagId(Integer.parseInt(metaTagId));
				tblMetaTag.setKeyword(keyword);
				tblMetaTag.setDescription(description);
				tblMetaTag.setTitle(title);
				tblMetaTag.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
				//tblMetaTag.setCreatedBy(createdBy);
				success=manageContentService.updateMetaTag(tblMetaTag);
			}
			retVal="common/admin/metatag";
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageMetaTagLinkId, postMetaTagEdited, 0,metaTagId!=null && !metaTagId.equals("")?Integer.parseInt(metaTagId):0, "");
		}
		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_update_metatag" :CommonKeywords.ERROR_MSG_KEY.toString());
		return REDIRECT+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
	}

	@RequestMapping(value = "/admin/addissuer/{enc}", method = RequestMethod.GET)
	public String addIssuer(ModelMap modelMap, HttpServletRequest req) {
		try {
			modelMap.addAttribute("issuerLst", manageContentService.getIssuerList());
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getAddIssuer, 0,0);
		}
		return "common/admin/Issuer";
	}

	@RequestMapping(value = "/admin/managecertificatecontacts/{enc}", method = RequestMethod.GET)
	public String manageCertificateContacts(ModelMap modelMap) {
		try {
			//int reportId = 11;
			modelMap.addAttribute("reportId", manageCertContactReportId);
			reportGeneratorService.getReportConfigDetails(manageCertContactReportId, modelMap);
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		return "common/admin/ContentManagement";
	}

	/**
	 * Use to get the page of manage certificate contacts with all domain
	 * @author nirav.modi
	 * @param modelMap
	 * @return
	 */
	@RequestMapping(value = "/admin/addnewcontact/{enc}", method = RequestMethod.GET)
	public String addNewContact(ModelMap modelMap,HttpServletRequest request) {
		try {
			List<Object[]> allDomainList=  commonService.getAllDomain();
			List<SelectItem> domainList = new ArrayList<SelectItem>();
			if(allDomainList!=null && !allDomainList.isEmpty()){
				for (Object[] objects : allDomainList) {
					domainList.add(new SelectItem(objects[1], objects[0]));
				}
			}
			
			
			List<SelectItem> contactTypelst = new ArrayList<SelectItem>();
			contactTypelst.add(new SelectItem("Digital Certificate",1));
			contactTypelst.add(new SelectItem("Support Team ",2));
			
			
			modelMap.put("contactTypelst", contactTypelst);
			modelMap.put("domainList", domainList);
		} catch (Exception ex) {
			
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageCertificateCreateContactLinkId, getCertiContactPage, 0,0);
		}
		return "common/admin/AddNewContact";
	}

	/** To insert combo and combodetails
	 * @Author Shreyansh.shah
	 * @param modelMap
	 * @param redirectAttributes
	 * @param httpSession
	 * @param request
	 * @return 
	 */
	@RequestMapping(value="/admin/addcombo/",method= RequestMethod.POST)
	public String addCombo(ModelMap modelMap,RedirectAttributes redirectAttributes,HttpSession httpSession,HttpServletRequest request) {
		String retVal = "";
		TblCombo tblCombo = new TblCombo();
		boolean isSucces = false;
		try {
			String comboName = request.getParameter("txtComboName");
			int listType = StringUtils.hasLength(request.getParameter("selListType")) ? Integer.parseInt(request.getParameter("selListType")) : 0;
			int forCalculation = 0;
			int pleaseSelectRequired = Integer.parseInt(request.getParameter("rdpleaseSelectRequired"));
			if(listType==1){
				forCalculation = Integer.parseInt(request.getParameter("rdCalculation"));
			}
			if(comboName != null) {
				tblCombo.setComboName(comboName);
				tblCombo.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
				tblCombo.setForCalculation(forCalculation);
				tblCombo.setCreatedBy(abcUtility.getSessionUserId(request));
				tblCombo.setIsActive(1);
				tblCombo.setComboType(listType);
				tblCombo.setPleaseSelectRequired(pleaseSelectRequired);
				List<TblComboDetail> tblComboList = new ArrayList<TblComboDetail>();
				String itemLabels[] = request.getParameterValues("txtItemLabel_");
				String itemValues[] = request.getParameterValues("txtItemValue_");
				
				if(itemLabels.length>0)
				{
					if(pleaseSelectRequired == 1)
					{
						TblComboDetail pleaseSelectOption = new TblComboDetail();
						pleaseSelectOption.setOptionName("Please Select");
						pleaseSelectOption.setOptionValue("");
						pleaseSelectOption.setIsCommentRequired(0);
						pleaseSelectOption.setIsDefault(1);
						pleaseSelectOption.setTblCombo(tblCombo);
						tblComboList.add(pleaseSelectOption);
					}
				}
					
				int defaultVal = StringUtils.hasLength(request.getParameter("txtDefaultSelectedValue")) ? Integer.parseInt(request.getParameter("txtDefaultSelectedValue")) : 0;
				
				for(int i = 0; i < itemLabels.length; i++) {
					TblComboDetail tblComboDetail = new TblComboDetail();
					if(pleaseSelectRequired==0)
					{
						if(defaultVal == (i+1) && listType==1) { // Default value in case of Combo Box 
							tblComboDetail.setIsDefault(1);
						} else {
							tblComboDetail.setIsDefault(0);
						}	
					}
					else{
						tblComboDetail.setIsDefault(0);
					}
					
						// Project Task #15936 : purvesh - start
						if(listType!=2 && forCalculation!=1){ // Is comment required in case of combo box and calculation required is NO
							int isCommentReq = StringUtils.hasLength(request.getParameter("chkIsCommentReq_"+(i+1))) ? Integer.parseInt(request.getParameter("chkIsCommentReq_"+(i+1))): 0 ;
							tblComboDetail.setIsCommentRequired(isCommentReq);
						}
					else{
						tblComboDetail.setIsCommentRequired(0);
					}
					// Project Task #15936 : purvesh - end
					tblComboDetail.setOptionName(itemLabels[i]);
					if((listType==2 || (listType==1 && forCalculation!=1))){ //In case of list box or combo box and calculation required is NO 
						tblComboDetail.setOptionValue(itemLabels[i]);
					}
					else{
						tblComboDetail.setOptionValue(itemValues[i]);
					}
					tblComboDetail.setTblCombo(tblCombo);
					tblComboList.add(tblComboDetail);
				}
				isSucces = manageContentService.addCombo(tblCombo, tblComboList);
				if (isSucces) {
					retVal = "common/admin/managecombo";
				} else {
					retVal = "common/admin/createcombo";
				}
			}
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createComboLinkId, postComboCreated, 0,tblCombo.getComboId());
		}
		redirectAttributes.addFlashAttribute(isSucces ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSucces ? "redirect_success_createcombo" : CommonKeywords.ERROR_MSG_KEY.toString());
		return  REDIRECT+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
	}

	/** To update data in combodetails 
	 * @Author Shreyansh.shah
	 * @param modelMap
	 * @param redirectAttributes
	 * @param httpSession
	 * @param request
	 * @return 
	 */
	@RequestMapping(value="/admin/updatecombo/",method= RequestMethod.POST)
	public String updateCombo(ModelMap modelMap,RedirectAttributes redirectAttributes,HttpSession httpSession,HttpServletRequest request) {
		String retVal = "";
		int comboId = StringUtils.hasLength(request.getParameter("hdComboId")) ? Integer.parseInt(request.getParameter("hdComboId")) : 0;
		int listType = StringUtils.hasLength(request.getParameter("hdComboType")) ? Integer.parseInt(request.getParameter("hdComboType")) : 0;
		int forCalculation = StringUtils.hasLength(request.getParameter("hdForCalculation")) ? Integer.parseInt(request.getParameter("hdForCalculation")) : 0;
		int startOpt = StringUtils.hasLength(request.getParameter("hdStartOpt")) ? Integer.parseInt(request.getParameter("hdStartOpt")) : 0;
		int endOpt = StringUtils.hasLength(request.getParameter("hdEndOpt")) ? Integer.parseInt(request.getParameter("hdEndOpt")) : 0;
		int uiSelectRequired = 0;
		boolean isSucces = false;
		try {
			if(httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ) {
				List<TblComboDetail> tblComboList = new ArrayList<TblComboDetail>();
				String itemLabels[] = request.getParameterValues("txtItemLabel_");
				String itemValues[] = request.getParameterValues("txtItemValue_");
				int startCommentId = StringUtils.hasLength(request.getParameter("hdStartCommentId")) ? Integer.parseInt(request.getParameter("hdStartCommentId")) : 0;
				TblCombo comboBox=manageContentService.getComboById(comboId);
				int dbSelectRequired= comboBox.getPleaseSelectRequired();
				if(dbSelectRequired == 0)
				{
					uiSelectRequired = Integer.parseInt(request.getParameter("rdpleaseSelectRequired"));					
				}

				if(itemLabels != null) {
					for(int i = 0; i < itemLabels.length; i++) {
						TblComboDetail tblComboDetail = new TblComboDetail();
						tblComboDetail.setIsDefault(0);
						tblComboDetail.setOptionName(itemLabels[i]);
						// Project Task #15936 : purvesh - start
						if(listType!=2 && forCalculation!=1){ // Is comment required in case of combo box and calculation required is NO
							int isCommentReq = StringUtils.hasLength(request.getParameter("chkIsCommentReq_"+startCommentId)) ? Integer.parseInt(request.getParameter("chkIsCommentReq_"+startCommentId)): 0 ;
							tblComboDetail.setIsCommentRequired(isCommentReq);
							startCommentId++;
						}
						else{
							tblComboDetail.setIsCommentRequired(0);
						}
						// Project Task #15936 : purvesh - end
						
						if(listType==2 || (listType==1 && forCalculation!=1)){ //In case of list box or combo box and calcaulation required is NO
							tblComboDetail.setOptionValue(itemLabels[i]);
						}
						else{
							tblComboDetail.setOptionValue(itemValues[i]);
						}
						tblComboDetail.setTblCombo(comboBox);
						tblComboList.add(tblComboDetail);
					}
				}
				boolean ispleaseSelectRequired = false;
				if(dbSelectRequired != uiSelectRequired)
				{
					
					if(uiSelectRequired == 1) //add code and change default selected as Please Select
					{
						TblComboDetail pleaseSelectOption = new TblComboDetail();
						pleaseSelectOption.setOptionName("Please Select");
						pleaseSelectOption.setOptionValue("");
						pleaseSelectOption.setIsCommentRequired(0);
						pleaseSelectOption.setIsDefault(1);
						pleaseSelectOption.setTblCombo(new TblCombo(comboId));
						tblComboList.add(pleaseSelectOption);
						ispleaseSelectRequired=true;
						comboBox.setPleaseSelectRequired(1);
						List<TblComboDetail> tempComboDetailList = manageContentService.getComboDetailByComboId(comboId);
						Iterator iterator = tempComboDetailList.iterator();
						while(iterator.hasNext())
						{
							TblComboDetail tempComboDetail = (TblComboDetail) iterator.next();
							tempComboDetail.setIsDefault(0);
							tblComboList.add(tempComboDetail);
						}
						
					}
				}
				if(ispleaseSelectRequired || itemLabels!=null)
				{
					isSucces = manageContentService.updateComboBox(comboBox);
					if(isSucces)
					{
						isSucces = manageContentService.updateCombo(tblComboList);
					}
				}
				if (isSucces){
					retVal = "common/admin/managecombo";
				}
				else
				{
					retVal = "common/admin/editcombo/"+comboId;
				}
			}
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editComboLinkId, postUpdateCombo, 0,comboId);
		}
		redirectAttributes.addFlashAttribute(isSucces ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSucces ? "redirect_success_updatecombo" : CommonKeywords.ERROR_MSG_KEY.toString());
		return  REDIRECT+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
	}



	/**
	 * Use to create new Manage certificate contacts 
	 * @author nirav.modi
	 * @param redirectAttributes
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/addnewcontactdetails", method = RequestMethod.POST)                       
	public String addNewContactDetails(RedirectAttributes redirectAttributes, HttpServletRequest request){ 
		boolean success = false;
		String retVal = null;
		TblCertBanner tblCertBanner = new TblCertBanner();
		try{
			String personName = request.getParameter("txtPersonName");
			String mobile = request.getParameter("txtMobile");
			String phone = request.getParameter("txtPhone");
			String emailID = request.getParameter("txtEmailID");
			String alternateEmail = request.getParameter("txtAlternateEmail");//not mandatory
			String faxNo = request.getParameter("txtFaxNo");//not mandatory
			String address = request.getParameter("txtaAddress");//not mandatory
			int bannerType =  StringUtils.hasLength(request.getParameter("selBannerType")) ? Integer.parseInt(request.getParameter("selBannerType")) : 0 ; 
			String [] domainArray=request.getParameterValues("chkMultipleDomain");

			if(domainArray!=null && domainArray.length!=0 && StringUtils.hasLength(personName) && StringUtils.hasLength(phone) && StringUtils.hasLength(mobile) && StringUtils.hasLength(emailID)){ 
				List<TblClientCertBannerMapping> tblClientCertBannerMappingList = new ArrayList<TblClientCertBannerMapping>();
				tblCertBanner.setPersonName(personName);
				tblCertBanner.setMobileNo(mobile);
				tblCertBanner.setPhoneNo(phone);
				tblCertBanner.setEmail(emailID);
				tblCertBanner.setEmailCC(alternateEmail);
				tblCertBanner.setAddress(address);
				tblCertBanner.setFaxNo(faxNo);
				tblCertBanner.setIsActive(1);
				tblCertBanner.setBannerType(bannerType);
				for (int i = 0; i < domainArray.length; i++) {
					TblClientCertBannerMapping tblClientCertBannerMapping = new TblClientCertBannerMapping();
					tblClientCertBannerMapping.setTblClient(new TblClient(Integer.parseInt(domainArray[i])));
					tblClientCertBannerMapping.setTblCertBanner(tblCertBanner);
					tblClientCertBannerMapping.setIsActive(1);
					tblClientCertBannerMappingList.add(tblClientCertBannerMapping);
				}
				success = manageContentService.addNewContactDetails(tblCertBanner,tblClientCertBannerMappingList);
			}
			if(success){
				retVal="common/admin/managecertificatecontacts";
			}else{
				retVal="common/admin/addnewcontact";
			}
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageCertificateCreateContactLinkId, postCertiContactCreated, 0,tblCertBanner.getCertBannerId());
		}
		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_create_contact" : CommonKeywords.ERROR_MSG_KEY.toString());
		return REDIRECT+retVal+ encryptDecryptUtils.generateRedirect(retVal, request);
	}

	/**
	 * @author nirav.modi
	 * @param modelMap
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/editcontact/{certBannerId}/{enc}", method = RequestMethod.GET)                       
	public String getEditContact(@PathVariable("certBannerId") int certBannerId,ModelMap modelMap, HttpServletRequest request){ 
		TblCertBanner tblCertBanner=null;
		try{
			List<Object[]> allDomainList=  commonService.getAllDomain();
			List<SelectItem> domainList = new ArrayList<SelectItem>();
			if(allDomainList!=null && !allDomainList.isEmpty()){
				for (Object[] objects : allDomainList) {
					domainList.add(new SelectItem(objects[1], objects[0]));
				}
			}
			
			
			List<SelectItem> contactTypelst = new ArrayList<SelectItem>();
			contactTypelst.add(new SelectItem("Digital Certificate",1));
			contactTypelst.add(new SelectItem("Support Team ",2));
			
			
			tblCertBanner=manageContentService.getCertBannerById(certBannerId);
			
			modelMap.put("contactTypelst", contactTypelst);
			modelMap.addAttribute("domainList",domainList);
			modelMap.addAttribute("activeDomainList",manageContentService.getActiveDomainByClientCertBannerId(certBannerId));
			modelMap.addAttribute("tblCertBanner",tblCertBanner);
			modelMap.addAttribute("opType","update");
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageCertificateEditContactLinkId, gettCertiContactEdit, 0,certBannerId);
		}
		return "common/admin/AddNewContact";
	}

	/**
	 * @author nirav.modi
	 * @param redirectAttributes
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/updatecontact", method = RequestMethod.POST)                       
	public String updateContact(RedirectAttributes redirectAttributes,HttpServletRequest request){ 
		boolean success = false;
		String certBannerId= null;
		String retVal = null;
		TblCertBanner tblCertBanner = new TblCertBanner();
		try{
			String personName = request.getParameter("txtPersonName");
			String mobile = request.getParameter("txtMobile");
			String phone = request.getParameter("txtPhone");
			String emailID = request.getParameter("txtEmailID");
			String alternateEmail = request.getParameter("txtAlternateEmail");//not mandatory
			String faxNo = request.getParameter("txtFaxNo");//not mandatory
			String address = request.getParameter("txtaAddress");//not mandatory
			certBannerId = request.getParameter("hdCertBannerId");
			int bannerType =  StringUtils.hasLength(request.getParameter("selBannerType")) ? Integer.parseInt(request.getParameter("selBannerType")) : 0 ;
			String [] domainArray=request.getParameterValues("chkMultipleDomain");

			if(domainArray!=null && domainArray.length!=0 && StringUtils.hasLength(certBannerId) && StringUtils.hasLength(personName) && StringUtils.hasLength(mobile) && StringUtils.hasLength(phone) && StringUtils.hasLength(emailID)){
				List<TblClientCertBannerMapping> tblClientCertBannerMappingList = new ArrayList<TblClientCertBannerMapping>();
				tblCertBanner.setCertBannerId(Integer.parseInt(certBannerId));
				tblCertBanner.setPersonName(personName);
				tblCertBanner.setMobileNo(mobile);
				tblCertBanner.setPhoneNo(phone);
				tblCertBanner.setEmail(emailID);
				tblCertBanner.setEmailCC(alternateEmail);
				tblCertBanner.setAddress(address);
				tblCertBanner.setFaxNo(faxNo);
				tblCertBanner.setIsActive(1);
				tblCertBanner.setBannerType(bannerType);
				for (int i = 0; i < domainArray.length; i++) {
					TblClientCertBannerMapping tblClientCertBannerMapping = new TblClientCertBannerMapping();
					tblClientCertBannerMapping.setTblClient(new TblClient(Integer.parseInt(domainArray[i])));
					tblClientCertBannerMapping.setTblCertBanner(tblCertBanner);
					tblClientCertBannerMapping.setIsActive(1);
					tblClientCertBannerMappingList.add(tblClientCertBannerMapping);
				}
				success = manageContentService.updateContact(tblCertBanner,tblClientCertBannerMappingList);
			}
			if(success){
				retVal="common/admin/managecertificatecontacts";
			}else{
				retVal="common/admin/editcontact/"+certBannerId;
			}
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageCertificateEditContactLinkId, postCertiContactUpdated, 0,tblCertBanner.getCertBannerId());
		}
		redirectAttributes.addFlashAttribute(success ?  CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_update_contact" : CommonKeywords.ERROR_MSG_KEY.toString());
		return REDIRECT+retVal+ encryptDecryptUtils.generateRedirect(retVal, request);
	}

	/**
	 * @author nirav.modi
	 * @param modelMap
	 * @param response
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/removecontact/{certBannerId}/{enc}", method = RequestMethod.GET)                       
	public String removeContact(RedirectAttributes redirectAttributes, HttpServletRequest request,@PathVariable("certBannerId") int certBannerId){
		boolean success=false;
		try{
			success = manageContentService.deActiveContact(certBannerId);
		}
		catch(Exception ex){
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getDeactivateCertContact, 0,certBannerId);
		}
		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_remove_contact" : CommonKeywords.ERROR_MSG_KEY.toString());
		return "redirect:/common/admin/managecertificatecontacts"+ encryptDecryptUtils.generateRedirect("common/admin/managecertificatecontacts", request);
	}


    @RequestMapping(value = "admin/addnewissuser", method = RequestMethod.POST)
    public String addNewIssuer(@ModelAttribute IssuerDataBean issuerDataBean, HttpServletRequest req,
            HttpSession httpSession, RedirectAttributes redirectAttributes) {
        try {
            String issuer = StringUtils.hasLength(req.getParameter("txtaIssuer"))?req.getParameter("txtaIssuer"):" ";
            issuerDataBean.setTxtCreatedBy(String.valueOf(abcUtility.getSessionUserId(req)));
            issuerDataBean.setTxtaIssuer(abcUtility.reverseReplaceSpecialChars(issuer));
            if (manageContentService.addIssuer(issuerDataBean._toTblIssuer())) {
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_issuer_add_success");
            } else {
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postAddnewIssuer, 0, 0);
        }
        return "redirect:/common/admin/addissuer" + encryptDecryptUtils.generateRedirect("common/admin/addissuer", req);
    }

	@RequestMapping(value = "/admin/deleteissuser/{issuerId}/{enc}", method = RequestMethod.GET)
	public String getDeleteIssuerDetails(@PathVariable("issuerId") int issuerId,
			HttpServletRequest req, RedirectAttributes redirectAttributes) {//TODO : remove unused method params.
		try {
			if (manageContentService.updateIsActiveTblIssuerById(issuerId)) {
				redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_issuer_delete_success");
			}else{
				redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
			}
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getDeleteIssuerPage, 0,0);
		}
		return "redirect:/common/admin/addissuer" + encryptDecryptUtils.generateRedirect("common/admin/addissuer", req);
	}

	/** Called before administrator wants to create news
	 *  Fetch necessary data which needs to be displayed initially
	 */
	@RequestMapping(value = "/admin/createnews/{enc}", method = RequestMethod.GET)
	public String createNews(ModelMap modelMap,HttpServletRequest request) {
		try {
			setNewsData(modelMap);        	 
			modelMap.addAttribute("mode", "create");
			if (((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserTypeId() == 1) {
				modelMap.addAttribute("isAdmin","yes");
			}

		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),createNewsLinkId, getCreateNews, 0,0);
		}
		return "common/admin/ManageContent";
	}

	/** Set news related values which needs to be displayed to user
	 */
	public void setNewsData(ModelMap modelMap){
		List<SelectItem> showForRadioList= new ArrayList<SelectItem>();
		showForRadioList.add(new SelectItem("Current Domain",1));
		showForRadioList.add(new SelectItem("Selected Domain",2));
		modelMap.addAttribute("showForRadioList", showForRadioList);
		modelMap.addAttribute(CONTENTYPE, 2);
	}

	@RequestMapping(value = "/admin/managenews/{enc}", method = RequestMethod.GET)
	public String listAndViewNews(ModelMap modelMap,HttpServletRequest request) {
		try {
			//int reportId = 10;
			modelMap.addAttribute("reportId", manageNewsReportId);
			reportGeneratorService.getReportConfigDetails(manageNewsReportId, modelMap);
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getViewNews, 0,0);
		}
		return "common/admin/ManageNews";
	}

	/** Called when administrator wants to edit news details
	 *  Fetch necessary data for specific client
	 */
	@RequestMapping(value = "/admin/editnews/{id}/{enc}", method = RequestMethod.GET)
	public String editNews(ModelMap modelMap,@PathVariable("id") int contentMangId,HttpServletRequest request) {
		try {
			setNewsData(modelMap);
			modelMap.addAttribute("mode", "edit");

			List<Object[]> newsList=manageContentService.getContentManagementById(contentMangId);
			Map<String,Object> newsMap= new HashMap<String, Object>();
			for (Object[] objects : newsList) {
				//marqueeMap.put(CONTENTYPE, objects[0]);

				newsMap.put("contentText", objects[4]);
				newsMap.put("startDate", objects[5]);
				newsMap.put("endDate", objects[6]);

			}
			if (((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserTypeId() == 1) {
				modelMap.addAttribute("isAdmin","yes");

				List<Object[]> selectedDomain=manageContentService.getSelectedSubDomain(contentMangId);
				int cnt=0;
				int clientId=0;
				for (Object[] objects : selectedDomain) {
					if(objects[2]!=null){
						clientId = (Integer)objects[0]; 
						cnt++;
					}
				}	
				boolean setList = false;
				if(cnt==1){
					//int clientId = (Integer)selectedDomain.get(0)[0];System.out.println("clientId------------------------"+clientId);
					ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
					if(clientBean.getClientId() == clientId){
						modelMap.addAttribute("currdomain", 1);	   				
					}else{
						setList = true;	
					}
				}
				else{
					setList = true;	
				}   		
				if(setList){
					modelMap.addAttribute("currdomain", 2);
					List<SelectItem> showCheckedList= new ArrayList<SelectItem>();
					showCheckedList=abcUtility.convertSelected(selectedDomain);

					modelMap.addAttribute("showCheckedDomains", showCheckedList);
				}
			}
			modelMap.addAttribute("contentMangId", contentMangId);
			modelMap.addAttribute("contentlist", newsMap);
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),editNewsLinkId, getEditNews, 0,contentMangId);
		}
		return "common/admin/ManageContent";
	}

	/** Called when administrator wants to edit marquee details
	 *  Fetch necessary data for specific client
	 */
	@RequestMapping(value = "/admin/editmarqueedetails/{id}/{enc}", method = RequestMethod.GET)
	public String editMarquee(@PathVariable("id") int contentMangId,ModelMap modelMap,HttpServletRequest request){
		try {
			setMarqueeData(modelMap);
			modelMap.addAttribute("mode", "edit");
			List<Object[]> marqueeList=manageContentService.getContentManagementById(contentMangId);
			Map<String,Object> marqueeMap= new HashMap<String, Object>();
			for (Object[] objects : marqueeList) {
				//marqueeMap.put(CONTENTYPE, objects[0]);
				marqueeMap.put("locationId", objects[1]);
				marqueeMap.put("contentText", HtmlUtils.htmlUnescape(objects[4].toString()));
				marqueeMap.put("startDate", objects[5]);
				marqueeMap.put("endDate", objects[6]);

			}

			modelMap.addAttribute("contentlist", marqueeMap);
			modelMap.addAttribute("contentMangId", contentMangId);
			if (((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserTypeId() == 1) {
				modelMap.addAttribute("isAdmin","yes");
				List<Object[]> selectedDomain=manageContentService.getSelectedSubDomain(contentMangId);
				int cnt=0;
				int clientId=0;
				for (Object[] objects : selectedDomain) {
					if(objects[2]!=null){
						clientId = (Integer)objects[0]; 
						cnt++;
					}
				}	
				boolean setList = false;
				if(cnt==1){
					//int clientId = (Integer)selectedDomain.get(0)[0];System.out.println("clientId------------------------"+clientId);
					ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
					if(clientBean.getClientId() == clientId){
						modelMap.addAttribute("currdomain", 1);
						modelMap.addAttribute("rdShowFor",1);
					}else{
						setList = true;	
					}
				}
				else{
					setList = true;	
				}   		
				if(setList){
					modelMap.addAttribute("currdomain", 2);
					modelMap.addAttribute("rdShowFor",2);

					List<SelectItem> showCheckedList= new ArrayList<SelectItem>();
					showCheckedList=abcUtility.convertSelected(selectedDomain);
					/*for (Object[] objects : selectedDomain) {
	   			showCheckedList.add(new SelectItem(objects[1], objects[0], objects[2]));
	   		//	System.out.println("---------------------"+objects[1] + objects[0] + objects[2]);
	   		}	*/
					modelMap.addAttribute("showCheckedDomains", showCheckedList);
				}
			}

		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}	finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),editMarqueeLinkId, getEditMarquee, 0,contentMangId);
		}

		return "common/admin/ManageContent";

	}

	/** Set marquee related values which needs to be displayed to user
	 */
	private void setMarqueeData(ModelMap modelMap){
		List<SelectItem> dispLocRadioList = new ArrayList<SelectItem>();
		dispLocRadioList.add(new SelectItem("Before Login", 1));
		dispLocRadioList.add(new SelectItem("After Login", 2));
		dispLocRadioList.add(new SelectItem("On registration page", 3));
		modelMap.addAttribute("dispLocRadioList", dispLocRadioList);

		List<SelectItem> showForRadioList= new ArrayList<SelectItem>();
		showForRadioList.add(new SelectItem("Current Domain",1));
		showForRadioList.add(new SelectItem("Selected Domain",2));
		modelMap.addAttribute("showForRadioList", showForRadioList);
		modelMap.addAttribute(CONTENTYPE, 1);
	}

	/** Called before administrator wants to create marquee
	 *  Fetch necessary data which needs to be displayed initially
	 */
	@RequestMapping(value = "/admin/createmarquee/{enc}", method = RequestMethod.GET)
	public String createMarquee(ModelMap modelMap,HttpServletRequest request) {
		try {     
			modelMap.addAttribute("mode", "create");
			setMarqueeData(modelMap);  


			if (((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserTypeId() == 1) {

				modelMap.addAttribute("isAdmin","yes");
			}

		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),marqueeLinkId, getCreateMarquee, 0,0);
		}
		return "common/admin/ManageContent";
	}


	@RequestMapping(value = "/admin/managemarquee/{enc}", method = RequestMethod.GET)
	public String listAndViewMarquee(ModelMap modelMap,HttpServletRequest request) {
		try {
			//int reportId = 9;
			modelMap.addAttribute("reportId", manageMarqueeReportId);
			reportGeneratorService.getReportConfigDetails(manageMarqueeReportId, modelMap);
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getViewMarquee, 0,0);
		}
		return "common/admin/ManageMarquee";
	}

	/** Called before administrator wants to update contactus
	 */
	@RequestMapping(value = "/admin/contactus/{enc}", method = RequestMethod.GET)
	public String contactUs(ModelMap modelMap,HttpServletRequest request) {
		try {
			List<Object[]> data=manageContentService.getContAbout(abcUtility.getSessionClientId(request),4);
			String contentText=data != null && !data.isEmpty() ? data.get(0)[0].toString() : "";
			if(StringUtils.hasLength(contentText)){
				modelMap.addAttribute("mode","edit");
				modelMap.addAttribute("contentMangId", data.get(0)[1]);
			}
			modelMap.addAttribute(CONTENTYPE, 4);
			modelMap.addAttribute("contactUs",contentText);
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageContactUs, getContactUs, 0,0);
		}
		return "common/admin/ManageContent";
	}
	/**
	 * To download excel file for static listing. 
	 * @param modelMap
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/admin/downloadlistingexcelfile/{enc}", method = RequestMethod.GET)
	public String downloadExcelFileForStaticListing(ModelMap modelMap,HttpServletRequest request, HttpServletResponse response) {
		try {
			List<Object[]> data=manageContentService.getContAbout(abcUtility.getSessionClientId(request),7);
			String contentText=data != null && !data.isEmpty() ? data.get(0)[0].toString() : "";
			if(StringUtils.hasLength(contentText)){
				modelMap.addAttribute("mode","edit");
				modelMap.addAttribute("contentMangId", data.get(0)[1]);
			}
			modelMap.addAttribute(CONTENTYPE, 7);
			modelMap.addAttribute("statistics",contentText);
			
			//start - File download 
			StringBuilder path = new StringBuilder();
            String fileName="CategoryListingFormat";
            String subDir="CategoryListing";
            path.append(drive).append(upload).append("\\").append(subDir).append("\\");
            File subFolder = new File(path.toString());
            if(!subFolder.isDirectory()) {
            	subFolder.mkdirs();
            }
			File file = new File(path.toString() + fileName + ".xlsx");
			/*if(!file.exists()) {
				file.createNewFile();
			}*/
			if(file.exists()) {
				InputStream fis = new FileInputStream(file);
	            byte[] buf = new byte[fis.available()];
	            int offset = 0;
	            int numRead = 0;
	            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
	                offset += numRead;
	            }
	            ServletOutputStream outputStream = response.getOutputStream();
	            response.setContentType("application/octet-stream");
	            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName+ ".xls\"");            
	            outputStream.write(buf);
	            outputStream.flush();
	            outputStream.close();
	            modelMap.addAttribute("isDownloadFileAvailable", true);
			}
			else {
				modelMap.addAttribute("isDownloadFileAvailable", false);
				modelMap.addAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_notification_template_not_set");
			}
			//end - File download            
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageStatisticsLinkId, getManageStatistics, 0,0);
		}
		return "common/admin/ManageContent";
	}
	/**
	 * To view supplier inquiry
	 * @param modelMap
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/viewinquiry/{enc}", method = RequestMethod.GET)
	public String viewInquiry(ModelMap modelMap,HttpServletRequest request) {
		String pageName="common/admin/ViewSupplierInquiry";
		try {
			modelMap.addAttribute("reportId", viewSupplierInquiryReportId);
			reportGeneratorService.getReportConfigDetails(viewSupplierInquiryReportId, modelMap);
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewSupplierLinkId, getViewInquiry,0,0);
		}
		return pageName;
	}
	/** Called before administrator wants to update statistics
	 */
	@RequestMapping(value = "/admin/statistics/{enc}", method = RequestMethod.GET)
	public String manageStatistics(ModelMap modelMap,HttpServletRequest request) {
		try {
			List<Object[]> data=manageContentService.getContAbout(abcUtility.getSessionClientId(request),7);
			String contentText=data != null && !data.isEmpty() ? data.get(0)[0].toString() : "";
			if(StringUtils.hasLength(contentText)){
				modelMap.addAttribute("mode","edit");
				modelMap.addAttribute("contentMangId", data.get(0)[1]);
			}
			StringBuilder path = new StringBuilder();
            String fileName="CategoryListingFormat";
            String subDir="CategoryListing";
            path.append(drive).append(upload).append("\\").append(subDir).append("\\");
			File file = new File(path.toString() + fileName + ".xlsx");
			if(file.exists()) {
				modelMap.addAttribute("isDownloadFileAvailable", true);
			}
			else{
				modelMap.addAttribute("isDownloadFileAvailable", false);
			}
			modelMap.addAttribute("waringMsg","msg_notification_create_statistics");
			modelMap.addAttribute(CONTENTYPE, 7);
			modelMap.addAttribute("statistics",contentText);
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageStatisticsLinkId, getManageStatistics, 0,0);
		}
		return "common/admin/ManageContent";
	}
	/**
     * To view inquiry
     * @param supplierInquiryId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/viewinquirycomment/{supplierInquiryId}/{enc}", method = RequestMethod.GET)
	public String viewInquiryComment(@PathVariable("supplierInquiryId") int supplierInquiryId, ModelMap modelMap,HttpServletRequest request) {
		String pageName="common/admin/ViewInquiryComment";
		TblSupplierInquiry tblSupplierInquiry = null; 
		int inquiryType = 0;
		String linkType = null;
    	try {
    		tblSupplierInquiry = commonService.getTblSupplierInquiry(supplierInquiryId);
    		if(tblSupplierInquiry!=null) {
    			modelMap.addAttribute("tblSupplierInquiry", tblSupplierInquiry);
    			inquiryType = tblSupplierInquiry.getInquiryType();
    			
    			linkType = inquiryType==1 ? messageSource.getMessage("manage_statistics_get_specs", null, LocaleContextHolder.getLocale()) :
							 inquiryType==2 ? messageSource.getMessage("manage_statistics_get_quote", null, LocaleContextHolder.getLocale()) :
								messageSource.getMessage("manage_statistics_get_suppliers", null, LocaleContextHolder.getLocale());
					
    			modelMap.addAttribute("inquiryType", linkType);
    		}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageStatisticsLinkId, getViewInquiryComments, 0,0);
		}
    	return pageName;
	}
	/** Called before administrator wants to update aboutus
	 */
	@RequestMapping(value = "/admin/aboutus/{enc}", method = RequestMethod.GET)
	public String aboutUs(ModelMap modelMap,HttpServletRequest request) {
		try {
			List<Object[]> data=	manageContentService.getContAbout(abcUtility.getSessionClientId(request),3);
			String contentText=data != null && !data.isEmpty() ? data.get(0)[0].toString() : "";
			if(StringUtils.hasLength(contentText)){
				modelMap.addAttribute("mode","edit");
				modelMap.addAttribute("contentMangId", data.get(0)[1]);
			}
			modelMap.addAttribute(CONTENTYPE, 3);
			modelMap.addAttribute("aboutUs",contentText);
		} catch (Exception ex) {
			return exceptionHandlerService.writeLog(ex);
		}
		finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageAboutUs, getAboutUs, 0,0);
		}
		return "common/admin/ManageContent";
	}
        
        @RequestMapping(value = "/admin/homepagecontent/{enc}", method = RequestMethod.GET)
        public String homePageContent(ModelMap modelMap, HttpServletRequest request) {
            try {
                List<Object[]> data = manageContentService.getContAbout(abcUtility.getSessionClientId(request), 9);
                modelMap.addAttribute("mode", "edit");
                String contentText = data != null && !data.isEmpty() ? data.get(0)[0].toString() : "";
                if (!data.isEmpty()) {
                modelMap.addAttribute("contentMangId",data.get(0)[1]);
                }
                modelMap.addAttribute(CONTENTYPE, 9);
                modelMap.addAttribute("homecontent", contentText);
            } catch (Exception ex) {
                return exceptionHandlerService.writeLog(ex);
            } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageHomeContent, getHomePageContent, 0, 0);
            }
            return "common/admin/ManageContent";
        }

	@RequestMapping(value = "/admin/managecontent/{contentId}/{enc}", method = RequestMethod.POST)
	public String manageContent(ModelMap modelMap,@PathVariable("contentId") int contentType){
		modelMap.addAttribute(CONTENTYPE, contentType);
		return "common/admin/ManageContent";
	}

	/** Called when administrator wants to save/update data related to marquee, news, contactUs, aboutUs , client Reg Terms and Condition
	 */
	@RequestMapping(value = "/admin/addcontent", method = RequestMethod.POST)
	public String addContent(ModelMap modelMap, HttpServletRequest request, RedirectAttributes rd){    
		boolean isAdded;
		String urlReturn=null;
		String sucessMsg=null;

		TblContentManagement tblContentManagement=new TblContentManagement();
                String isAdmin=request.getParameter("hdAdmin");
                
                int contentManagmentId = StringUtils.hasLength(request.getParameter("hdContentMangId"))?Integer.parseInt(request.getParameter("hdContentMangId")):0;
		
                if(contentManagmentId !=0 && StringUtils.hasLength(request.getParameter("hdMode")) && request.getParameter("hdMode").equals("edit")){

			tblContentManagement.setContentManagemenId(Integer.parseInt(request.getParameter("hdContentMangId")));
		}
		Integer contentId=Integer.parseInt(request.getParameter("hdContentType"));
		try {
			Date currentDate= commonService.getServerDateTime();
			int showForId=0;
			String contentText=null;
			switch(contentId){ 
			case 1:
				tblContentManagement.setContentType(1);
				contentText=request.getParameter("txtaMarquee");
				tblContentManagement.setContentText(contentText);
				int locationId=Integer.parseInt(request.getParameter("rdDispLoc"));
				tblContentManagement.setLocationId(locationId);
				sucessMsg="redirect_success_marquee";
				break;

			case 2:
				tblContentManagement.setContentType(2);
				contentText=request.getParameter("txtaNews");
				tblContentManagement.setContentText(contentText);
				tblContentManagement.setLocationId(0);
				sucessMsg="redirect_success_news";
				break;

			case 3:
				tblContentManagement.setContentType(3);
				contentText=request.getParameter("rtfAboutUs");
				tblContentManagement.setContentText(contentText);
				sucessMsg="msg_success_add_content";
				break;

			case 4:
				tblContentManagement.setContentType(4);
				contentText=request.getParameter("rtfContactUs");
				tblContentManagement.setContentText(contentText);
				sucessMsg="msg_success_add_content";
				break;
			case 7:
				tblContentManagement.setContentType(7);
				contentText = getStatisticsHtmlContentFromExcel(request);
				tblContentManagement.setContentText(contentText);
				sucessMsg="msg_success_add_statistics_content";
				break;
			case 8:
				int languageId=StringUtils.hasLength(request.getParameter("hdLanguageId"))?Integer.parseInt(request.getParameter("hdLanguageId")):0;
				tblContentManagement.setContentType(8);
				contentText=request.getParameter("rtfRegTerm");
				tblContentManagement.setContentText(contentText);
				tblContentManagement.setStartDate(currentDate);
				tblContentManagement.setEndDate(currentDate);
				tblContentManagement.setLocationId(0);
				tblContentManagement.setCreatedOn(currentDate);
				tblContentManagement.setIsDateRequired(0);
				tblContentManagement.setLinkType(0);
				tblContentManagement.setLocationId(0);
				tblContentManagement.setTblLanguage(new TblLanguage(languageId));
				sucessMsg="msg_success_add_reg_terms";
				break;
                            case 9:
                                    tblContentManagement.setContentType(9);
                                    contentText = request.getParameter("rtfHomePageContent");
                                    tblContentManagement.setContentText(contentText);
                                    sucessMsg = "msg_success_add_content";
                                break;
			default:
				break;
			}
			
			if(contentId==3 || contentId==4 || contentId==7 || contentId==9 ){
                            if (contentId == 9) {
                                tblContentManagement.setLocationId(1);
                            } else {
                                tblContentManagement.setLocationId(0);
                            }
				tblContentManagement.setEndDate(currentDate);
				tblContentManagement.setStartDate(currentDate);
				if(StringUtils.hasLength(request.getParameter("hdContentMangId"))){
					tblContentManagement.setContentManagemenId(Integer.parseInt(request.getParameter("hdContentMangId")));
				}

			}
			if(contentId==1 || contentId==2){
				String startDate=request.getParameter("txtStartDateTime");
				String endDate=request.getParameter("txtEndDateTime");
				if(isAdmin!=null && isAdmin.equals("yes")){
					showForId=Integer.parseInt(request.getParameter("rdShowFor"));
				}
				if(StringUtils.hasLength(request.getParameter("hdContentMangId"))){
					sucessMsg="msg_success_update_content";
				}
				tblContentManagement.setEndDate(conversionService.convert(endDate, Date.class));
				tblContentManagement.setStartDate(conversionService.convert(startDate, Date.class));
			}
                        tblContentManagement.setIsActive(1);

			
			
			
			List<TblClientContentMapping> clientContentMappings = new ArrayList<TblClientContentMapping>();

			if(contentId != 9 && StringUtils.hasLength(request.getParameter("hdMode")) && request.getParameter("hdMode").equals("edit")){
				manageContentService.updateClientContentMapping(tblContentManagement.getContentManagemenId());

			}
			TblClientContentMapping contentMapping=null;
			if(showForId==2 && isAdmin!=null && isAdmin.equals("yes") && request.getParameterValues("chkMultipleDomain")!=null){
				String[] clientIds= request.getParameterValues("chkMultipleDomain");
				for(int i=0;i<clientIds.length;++i){
					contentMapping = new TblClientContentMapping();
					contentMapping.setTblClient(new TblClient(Integer.parseInt(clientIds[i])));
					contentMapping.setTblContentManagement(tblContentManagement); 
					contentMapping.setIsActive(1);
					clientContentMappings.add(contentMapping);
				}		
			}
			else{
                                 contentMapping = new TblClientContentMapping();
				if(contentId == 8) {
					int clientId =  StringUtils.hasLength(request.getParameter("hdClientId"))?Integer.parseInt(request.getParameter("hdClientId")):0;
					contentMapping.setTblClient(new TblClient(clientId));
				} else {
					contentMapping.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
				}
				contentMapping.setTblContentManagement(tblContentManagement);
                                    contentMapping.setIsActive(1);
				clientContentMappings.add(contentMapping );
			}
			tblContentManagement.setCreatedBy(abcUtility.getSessionUserId(request));
			
			// Bug #51396 By Jitendra.
			tblContentManagement.setSmsRequire(0);
			tblContentManagement.setSenderId(0);
			if(contentId==1 || contentId==2){
				isAdded=	manageContentService.addContent(tblContentManagement, clientContentMappings);
			}else if (contentId == 8) {
				isAdded= manageContentService.addOrUpdateClientRegTermsCondition(tblContentManagement,contentMapping);
			}else if (contentId == 9) {
				isAdded= manageContentService.addHomePageContent(tblContentManagement,contentMapping,abcUtility.getSessionClientId(request));
			}else{
				isAdded= manageContentService.addContAboutUs(tblContentManagement,contentMapping);
			}
			if(isAdded){
				rd.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), sucessMsg);
			}else{
				rd.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
				if(contentId == 8 ) {
					urlReturn="redirect:/common/admin/manageclientregterms"+encryptDecryptUtils.generateRedirect("common/admin/manageclientregterms", request);
				} else {
					urlReturn="redirect:/common/admin/managecontent/"+contentId+encryptDecryptUtils.generateRedirect("common/admin/managecontent/"+contentId, request);	
				}
				
			}

		}catch(Exception e){


			return exceptionHandlerService.writeLog(e);    		    		
		}
		finally{
			int linkId=0;
			String comment=null;
			switch(contentId){
			case 1:
				linkId=marqueeLinkId;
				if(request.getParameter("hdMode").equals("edit")){

					comment=postEditMarquee;

				}
				else{

					comment=postCreateMarquee;
				}   
				break;
			case 2:
				linkId=createNewsLinkId;
				if(request.getParameter("hdMode").equals("edit")){
					comment=postEditNews;
				}else{
					comment=postCreateNews;
				}
				break;
			case 3:
				linkId=manageAboutUs;
				comment=postAboutUs;
				break;
			case 4:
				linkId=manageContactUs;
				comment=postContactUs;
				break;
			case 7:
				linkId=manageStatisticsLinkId;
				comment=postManageStatistics;
				break;
			case 8:
				if(StringUtils.hasLength(request.getParameter("hdMode")) && request.getParameter("hdMode").equals("edit")){
					linkId=editBidderTermsLinkId;
					comment=getUpdateBidderTermsCondition;
				} else {
					linkId=createBidderTermsLinkId;
					comment=getAddBidderTermsCondition;
				}
				
				break;
                            case 9:
                              linkId=manageHomePageLinkId;
                              comment=getHomePageContent;
                                break;
			default:
				break;
			}

			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, comment, 0,tblContentManagement.getContentManagemenId());
		}

		if(contentId==1){	
			urlReturn="redirect:/common/admin/managemarquee"+ encryptDecryptUtils.generateRedirect("common/admin/managemarquee", request);
		}else if(contentId==2){

			urlReturn="redirect:/common/admin/managenews/"+ encryptDecryptUtils.generateRedirect("common/admin/managenews/", request);
		}else if(contentId==3){

			urlReturn="redirect:/common/admin/aboutus/"+ encryptDecryptUtils.generateRedirect("common/admin/aboutus/", request);
		}else if(contentId==4){
			urlReturn="redirect:/common/admin/contactus"+encryptDecryptUtils.generateRedirect("common/admin/contactus", request);
		} else if(contentId == 8) {
			urlReturn="redirect:/common/admin/manageclientregterms"+encryptDecryptUtils.generateRedirect("common/admin/manageclientregterms", request);
		}else if(contentId == 9) {
			urlReturn="redirect:/common/admin/homepagecontent"+encryptDecryptUtils.generateRedirect("common/admin/homepagecontent", request);
		} else { // if(contentId==7){
			urlReturn="redirect:/common/admin/statistics"+encryptDecryptUtils.generateRedirect("common/admin/statistics", request);
		}
		return urlReturn;
	}
	/**
	 * Returned HTML content for static listing.
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private String getStatisticsHtmlContentFromExcel(HttpServletRequest request) throws Exception{
		StringBuilder htmlContent = new StringBuilder();
		StringBuilder htmlTr = new StringBuilder();
		String tempHtml = "";
		String filePath = StringUtils.hasLength(request.getParameter("hdFilePath")) ? request.getParameter("hdFilePath") : "";
		if(filePath!=null && !"".equalsIgnoreCase(filePath)) {
			htmlContent.append("<table class='border-top-none' width='100%'><tbody>");
			htmlTr.append("<tr>");
			htmlTr.append("<td colspan='2' class='a-right'><span><b> CATEGORY <b></b></b></span></td>");
			htmlTr.append("</tr>");
			htmlTr.append("<tr>");
			htmlTr.append("<td><b> INDEX </b></td>");
			htmlTr.append("<td> <div class='details-box'>");
			htmlTr.append("<p><b>No. of Events:</b> NO_OF_EVENTS | <b>Procurement Value:</b> PROC_VALUE | <b>% Savings:</b> SAVINGS </p>");
			htmlTr.append("<p><b>Unique Suppliers:</b> NO_SUPPLIERS | <b>Unique Buyers:</b> NO_BUYERS </p>");
			htmlTr.append("<p class='a-right'><a href=\"javascript:void(0);\" onClick=\"getStat('CATEGORY', '1')\">Get Specs</a> | ");
			htmlTr.append("<a href=\"javascript:void(0);\" onClick=\"getStat('CATEGORY', '2')\">Get Quote</a> | ");
			htmlTr.append("<a href=\"javascript:void(0);\" onClick=\"getStat('CATEGORY', '3')\">Get Suppliers</a></p>");
			htmlTr.append("</div> </td>");
			htmlTr.append("</tr>");
			tempHtml = getReplacedHtmlTr(htmlTr, filePath);
			htmlContent.append(tempHtml);
			htmlContent.append("</tbody></table>");
		}
		return htmlContent.toString();
	}
	/**
	 * To replace data in HTML of TR tag
	 * @param htmlTr
	 * @param filePath
	 * @return
	 * @throws Exception
	 */
	private String getReplacedHtmlTr(StringBuilder htmlTr, String filePath) throws Exception{
		StringBuilder allTrs = new StringBuilder();
		String strTrs = "";
		List<String> headerFromexsl=new ArrayList<String>();
		boolean isValidate=true;
		Map<String, String> captionMap = new HashMap<String, String>();
        captionMap.put("CATEGORY", "Category");
        captionMap.put("NO_OF_EVENTS", "No. of events");
        captionMap.put("PROC_VALUE", "Est. Value / Procurement Value");
        captionMap.put("SAVINGS", "Saving in %");
        captionMap.put("NO_SUPPLIERS", "No. of unique suppliers");
        captionMap.put("NO_BUYERS", "No. of unique buyers");
		File file = new File(filePath);
        if(file.exists()) {
            int j = filePath.lastIndexOf('.');
            String lst = filePath.substring(j + 1);
            boolean isXls = "xls".equalsIgnoreCase(lst);
            Iterator<Row> rows = null;
            if (isXls) {
                HSSFWorkbook workBook = new HSSFWorkbook(new POIFSFileSystem(new FileInputStream(file)));
                HSSFSheet sheet = workBook.getSheetAt(0);
                rows = sheet.rowIterator();
            }else {
                XSSFWorkbook workBook = new XSSFWorkbook(new FileInputStream(file));
                XSSFSheet sheet = workBook.getSheetAt(0);
                rows = sheet.rowIterator();
            }
            if(rows != null) {
                int rowcount = 0;
                if (rows.hasNext()) {
                    Row row = rows.next();
                    Iterator<Cell> cells = row.cellIterator();
                    while (cells.hasNext()) {
                        /*if (rowcount == 0) {
                        	rowcount++;
                        	Cell cell = cells.next();
                            continue;
                        }*/
                        Cell cell = cells.next();
                        if (cell.getCellType() == (isXls ? HSSFCell.CELL_TYPE_NUMERIC : XSSFCell.CELL_TYPE_NUMERIC)) {
                            headerFromexsl.add(cell.getNumericCellValue()+"");
                        } else if (cell.getCellType() == (isXls ? HSSFCell.CELL_TYPE_STRING : XSSFCell.CELL_TYPE_STRING)) {
                            headerFromexsl.add(cell.getRichStringCellValue().toString());
                        }  
                    }
                    rowcount++;
                }
                for (int i = 0; i < headerFromexsl.size(); i++) {
                	Object key = getKeyFromMapForExcel(captionMap, headerFromexsl.get(i));
                	if(key == null)
                	{
                		 allTrs.append(messageSource.getMessage("msg_invalidexcelfileformat", null, LocaleContextHolder.getLocale()));
                		 isValidate = false;
                		 break;
                	}	
				}
                int headerCount=0;
                rowcount=1;
                if(isValidate){
                	while(rows.hasNext()) {
                		strTrs = htmlTr.toString();
                		Row row = rows.next();
	                    int colcount=0;
	                    headerCount=0;
	                    for(int cn=0; cn<row.getLastCellNum(); cn++) {
                        	Cell cell = row.getCell(cn, Row.CREATE_NULL_AS_BLANK);
                            /*if (colcount == 0) {
                                colcount++;
                                continue;
                            }*/
                        	strTrs=strTrs.replace("INDEX", String.valueOf(rowcount));
                            if (cell.getCellType() == (isXls ? HSSFCell.CELL_TYPE_NUMERIC : XSSFCell.CELL_TYPE_NUMERIC)) {
                            	if (HSSFDateUtil.isCellDateFormatted(cell)) { //in case of the date
                            		SimpleDateFormat sdf = new SimpleDateFormat(CommonUtility.getClientDateFormat()+" HH:mm");
                            		String cellValue =  sdf.format(cell.getDateCellValue());
                            		strTrs=strTrs.replace(getKeyFromMapForExcel(captionMap, headerFromexsl.get(headerCount)).toString(), cellValue.trim());
                            	}else{
                            		strTrs=strTrs.replace(getKeyFromMapForExcel(captionMap, headerFromexsl.get(headerCount)).toString(), String.valueOf(cell.getNumericCellValue()).trim());
                            	}
                            	headerCount++;
                            } else if (cell.getCellType() == (isXls ? HSSFCell.CELL_TYPE_STRING : XSSFCell.CELL_TYPE_STRING)) {
                            	strTrs=strTrs.replace(getKeyFromMapForExcel(captionMap, headerFromexsl.get(headerCount)).toString(), cell.getRichStringCellValue().toString().trim());
                            	headerCount++;
                            }
                            else if (cell.getCellType() == (isXls ? HSSFCell.CELL_TYPE_BLANK : XSSFCell.CELL_TYPE_BLANK)) {
                            	strTrs=strTrs.replace(getKeyFromMapForExcel(captionMap, headerFromexsl.get(headerCount)).toString(), "".toString());
                            	headerCount++;
                            }
                            colcount++;
	                    }
	                    if(colcount!=0 && headerCount!=0) {
		                    allTrs.append(strTrs);
		                    strTrs="";
	                    }
                		rowcount++;
                	}
                }
            }
        }
		return allTrs.toString();
	}
	/**
	 * @param hm
	 * @param value
	 * @return
	 */
	private Object getKeyFromMapForExcel(Map hm, Object value) {
    	for (Object o : hm.keySet()) {
	          if (hm.get(o).equals(value)) {
	            return o;
	          }
	        }
	        return null;
    }
	/**
	 * To upload excel file for static listing.
	 * @param request
	 * @param response
	 * @param redirectAttributes
	 * @return
	 * @throws Exception
	 */
    @RequestMapping(value="/admin/uploadexcelforlisting", method=RequestMethod.POST)
	public String uploadExcelForListing(HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes) throws Exception{
		String retVal="redirect:/common/admin/statistics"+encryptDecryptUtils.generateRedirect("common/admin/statistics", request);
		String data = null;
		boolean isValidate = true;
		File file = null;
        File tmpDir = null;
        long fileSize = 0;
        String fileName = null;
        String lastDirName="StaticListing";
        long fileMaxSize = 1024 * 1024;//1 MB
        String fileExtensions = "xls,xlsx";
        int userId = 0;
        try {
        	userId = abcUtility.getSessionUserId(request);
        	if(userId!=0) {
		        DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
		        fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
		        ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
		        List items = uploadHandler.parseRequest(request);
		        Iterator itr = items.iterator();
		        while (itr.hasNext()) {
		            FileItem item = (FileItem) itr.next();
		            if (!item.isFormField()) {
		                fileSize = item.getSize();
		                if (item.getName().lastIndexOf("\\") != -1) {
		                    fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1, item.getName().length());
		                } else {
		                    fileName = item.getName();
		                    String ext = fileName.substring(fileName.indexOf('.'));
		                    fileName = fileName.substring(0,fileName.indexOf('.'));
		                    fileName = fileName+"_"+new SimpleDateFormat("yyyy-MM-dd").format(new Date())+"_"+abcUtility.getSessionUserId(request)+ext;
		                }
		                if (fileName != null && !fileName.equalsIgnoreCase("")) {
		                    if (fileSize == 0) {
		                        //data = messageSource.getMessage("msg_statistics_emptyfile", null, LocaleContextHolder.getLocale());
		                        isValidate = false;
		                        redirectAttributes.addFlashAttribute("errorMsg", "msg_statistics_emptyfile");
		                        break;
		                    }
		                    if (!checkFileSize(fileSize, fileMaxSize)) {
		                        //data = messageSource.getMessage("msg_statistics_maxfilesize", new Object[]{(fileMaxSize / 1024)}, LocaleContextHolder.getLocale());
		                        isValidate = false;
		                        redirectAttributes.addFlashAttribute("errorMsg", "msg_statistics_maxfilesize");
		                        break;
		                    }
		                    if (!checkFileExn(fileName, fileExtensions)) {
		                        //data = messageSource.getMessage("msg_statistics_invalidextension", null, LocaleContextHolder.getLocale());
		                        isValidate = false;
		                        redirectAttributes.addFlashAttribute("errorMsg", "msg_statistics_invalidextension");
		                        break;
		                    } else {
		                        /* if destination directory not exist then create it*/
		                        String tmpDirPath = docUpload + "\\" + abcUtility.getSessionClientId(request);
		                        tmpDir = new File(tmpDirPath);
		                        if (!tmpDir.isDirectory()) {
		                            tmpDir.mkdirs();
		                        }
		                        tmpDirPath = tmpDirPath +"\\"+ lastDirName;
		                        tmpDir = new File(tmpDirPath);
		                        if (!tmpDir.isDirectory()) {
		                            tmpDir.mkdirs();
		                        }
		                        // Start - rename file
		                        file = new File(tmpDir, fileName);
		                        int count=1;
		                        while(file.exists()) {
		                        	String ext = fileName.substring(fileName.indexOf('.'));
					                fileName = (count==1) ? fileName.substring(0,fileName.indexOf('.')) : fileName.substring(0,fileName.indexOf('('));
		                        	fileName +="("+count+")"+ext;
				                    file = new File(tmpDir, fileName);
				                    count++;
		                        }
		                     // end - rename file
		                        item.write(file);
		                        redirectAttributes.addFlashAttribute("filePath", tmpDirPath+"\\"+fileName);
		                        redirectAttributes.addFlashAttribute("uploadMsg", "msg_docuploadsuccessfully");
		                    }
		                }
		            }
		        }
        	}
        	else {
        		retVal="redirect:/sessionexpired";
        	}
        }
        catch(Exception e) {
        	retVal = exceptionHandlerService.writeLog(e);
        }
        finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageStatisticsLinkId, getManageStatistics, 0,0);
        }
		return retVal;
	}
	/** Called during fetching list of all domains
	 */ 
	@RequestMapping(value="/admin/domains",method=RequestMethod.POST)
	public String getDomains(ModelMap modelMap,HttpServletRequest request){


		try {
			List<Object[]>  list= commonService.getAllDomain();
			List<SelectItem> selectList=	abcUtility.convert(list);
			modelMap.addAttribute("compId", 2);

			abcUtility.setCheckBoxParams(selectList,"MultipleDomain", "", "", "", "", "", false, false, "", false, true, "", false,true , "3", modelMap,false);
		} catch (Exception e) {			
			return exceptionHandlerService.writeLog(e);		
		}	finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postGetDomains, 0,0);
		}

		return "AjaxComponent";
	}

	@RequestMapping(value="/ajaxcall/checkComboName", method=RequestMethod.POST)
	@ResponseBody
	public String checkComboName(@RequestParam("txtcomboName") String comboName, @RequestParam("hdComboId") String comboId,HttpServletRequest request){ //TODO : remove unused method params.
		String resultString="sessionexpired";
		try{
			if(abcUtility.getSessionUserId(request)!=0){
				boolean result;
				result=manageContentService.checkUniqueCombo(comboName,Integer.parseInt(comboId),abcUtility.getSessionClientId(request));
				resultString=result?"valid":"inValid";
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		}
		return resultString;
	}

		/** Called when administrator wants to delete data related to marquee, news
		 */
		@RequestMapping(value = "/admin/deletecontent/{id}/{contentId}/{enc}", method = RequestMethod.GET)
		public String deleteContent(@PathVariable("id") int contentMangId, @PathVariable("contentId") int contentId,HttpServletRequest request,RedirectAttributes rd){

			String urlReturn=null;
			try {
				boolean isDeleted=	manageContentService.deleteContent(contentMangId);
				if(isDeleted){
					if(contentId==1){
						urlReturn="redirect:/common/admin/managemarquee"+ encryptDecryptUtils.generateRedirect("common/admin/managemarquee", request);
						rd.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_success_delete_marquee");
					}else{
						urlReturn="redirect:/common/admin/managenews/"+ encryptDecryptUtils.generateRedirect("common/admin/managenews/", request);
						rd.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_success_delete_news");	
					}

				}else{
					rd.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());

				}
			} catch (Exception e) {
				return exceptionHandlerService.writeLog(e);
			}finally{
				if(contentId==1){
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), cancelMarqueeLinkId, getDeleteMarquee, 0,contentMangId);
				}
				else{
					auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),cancelNewsLinkId, getDeleteNews, 0,contentMangId);
				}
			}

			return urlReturn;
		}
         /**
         * To cancel Combo box
         * @param modelMap
         * @return 
         */
        @RequestMapping(value = "/admin/cancelcombobox/{comboId}/{enc}",  method= RequestMethod.GET)
	public String cancelField(@PathVariable("comboId") String comboId,HttpServletRequest request,RedirectAttributes redirectAttributes) {
            boolean success=false;
            try{
                    success = manageContentService.cancelComboBoxById(Integer.parseInt(comboId));
            }
            catch(Exception ex){
                    return exceptionHandlerService.writeLog(ex);
            }
            finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), cancelComboLinkId, getComboCancelled,0, Integer.parseInt(comboId),"");
            }
            redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_cancel_combobox" : CommonKeywords.ERROR_MSG_KEY.toString());
            return "redirect:/common/admin/managecombo"+ encryptDecryptUtils.generateRedirect("common/admin/managecombo", request);
        }
        
        /**
         * Called when admin wants to Edit any Help Page 
         */
        @RequestMapping(value = "/admin/helppage/{helpId}/{enc}",  method= RequestMethod.GET)
        public String createHelpPage(HttpServletRequest request,ModelMap modelMap,@PathVariable("helpId") int helpId) {

        	try {
        		modelMap.addAttribute("pageName", manageContentService.getPageName(helpId))	;
        		modelMap.addAttribute("helpDetails", manageContentService.getHelpContent(helpId));
        		modelMap.addAttribute("language", manageContentService.getLanguage(helpId));
        	} catch (Exception ex) {
        		exceptionHandlerService.writeLog(ex);
        	} finally {
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageHelpLinkId, getEditHelpPage,0,helpId);
        	}
        	return "common/admin/CreateHelpPage";
        }

        /**
         * Called when admin updates any Help Page 
         */
        @RequestMapping(value = "/admin/addhelpcontent",  method= RequestMethod.POST)
        public String addHelpPage(HttpServletRequest request,ModelMap modelMap,RedirectAttributes rd) {
        	boolean isUpdated=false;
        	String urlReturn="";

        	try{
        		if(StringUtils.hasLength(request.getParameter("hdHelpId")) && StringUtils.hasLength(request.getParameter("rtfHelpContent"))){
        			isUpdated=manageContentService.updateHelpContent(Integer.parseInt(request.getParameter("hdHelpId")), request.getParameter("rtfHelpContent"));
        		}
        		if(isUpdated){
        			rd.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_success_helpcontent");
        			urlReturn="redirect:/common/admin/managehelp"+ encryptDecryptUtils.generateRedirect("common/admin/managehelp", request);  
        		}
        		else{
        			urlReturn="redirect:/common/admin/helppage/"+Integer.parseInt(request.getParameter("hdHelpId"))+ encryptDecryptUtils.generateRedirect("common/admin/helppage/"+Integer.parseInt(request.getParameter("hdHelpId")), request);
        			rd.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
        		}

        	}catch(Exception ex){
        		exceptionHandlerService.writeLog(ex);
        	} finally {
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageHelpLinkId, postEditHelpPage,0,Integer.parseInt(request.getParameter("hdHelpId")));
        	}
        	return urlReturn;
        }
    	
        /**
         * Called when admin wants to view details of Help Page 
         */
        @RequestMapping(value = "/admin/viewhelppage/{helpId}/{enc}",  method= RequestMethod.GET)
        public String viewHelpPage(HttpServletRequest request,ModelMap modelMap,@PathVariable("helpId") int helpId) {

        	try {
        		modelMap.addAttribute("pageName", manageContentService.getPageName(helpId))	;
        		modelMap.addAttribute("helpDetails", manageContentService.getHelpContent(helpId));
        		modelMap.addAttribute("language", manageContentService.getLanguage(helpId));
        	} catch (Exception ex) {
        		exceptionHandlerService.writeLog(ex);
        	}finally {
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageHelpLinkId, getViewHelpPage,0,helpId);
        	}
        	return "common/admin/ViewHelpPage";
        }
        
        /**
         * to get view marquee page 
         * @param contentMangId
         * @param modelMap
         * @param request
         * @return String
         */
        @RequestMapping(value = "/admin/viewmarquee/{marqueeid}/{enc}", method = RequestMethod.GET)
    	public String viewMarquee(@PathVariable("marqueeid") int marqueeId,ModelMap modelMap,HttpServletRequest request){
    		try {
    			List<Object[]> marqueeList=manageContentService.getContentManagementById(marqueeId);
    			for (Object[] objects : marqueeList) {
    				//marqueeMap.put(CONTENTYPE, objects[0]);
    				modelMap.addAttribute("locationId", objects[1]);
    				modelMap.addAttribute("contentText", HtmlUtils.htmlUnescape(objects[4].toString()));
    				modelMap.addAttribute("startDate", objects[5]);
    				modelMap.addAttribute("endDate", objects[6]);
    			}
				modelMap.addAttribute("selectedDomain", manageContentService.getSelectedSubDomainForView(marqueeId));
    		} catch (Exception e) {
    			return exceptionHandlerService.writeLog(e);
    		}	finally{
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),viewMarqueeLinkId, getViewMarquee, 0,marqueeId);
    		}
    		return "common/admin/ViewMarquee";
    	}
        /**
         * To show create grade page
         * 
         * @author purvesh
         * @param modelMap
         * @param request
         * @return
         */
        @RequestMapping(value="/admin/creategrade/{enc}", method = RequestMethod.GET)
        public String createGrade(ModelMap modelMap,HttpServletRequest request){
        	String retVal="common/admin/CreateGrade";
        	try {
        		modelMap.addAttribute("operType","create");
        		modelMap.addAttribute("waringMsg","msg_notification_creategrade");
                List<SelectItem> selSortOrder = new ArrayList<SelectItem>();
                selSortOrder.add(new SelectItem("1", 1));
                selSortOrder.add(new SelectItem("2", 2));
                selSortOrder.add(new SelectItem("3", 3));
                selSortOrder.add(new SelectItem("4", 4));
                selSortOrder.add(new SelectItem("5", 5));
                selSortOrder.add(new SelectItem("6", 6));
                selSortOrder.add(new SelectItem("7", 7));
                selSortOrder.add(new SelectItem("8", 8));
                selSortOrder.add(new SelectItem("9", 9));
                selSortOrder.add(new SelectItem("10", 10));
                selSortOrder.add(new SelectItem("11", 11));
                selSortOrder.add(new SelectItem("12", 12));
                selSortOrder.add(new SelectItem("13", 13));
                selSortOrder.add(new SelectItem("14", 14));
                selSortOrder.add(new SelectItem("15", 15));
                modelMap.addAttribute("selSortOrder", selSortOrder);
                
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	finally{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, "Accessed create grade page", 0,0);
        	}
        	return retVal;
        }
        /**
         * To add grade
         * 
         * @author purvesh
         * @param request
         * @param response
         * @param modelMap
         * @param redirectAttributes
         * @return
         */
        @RequestMapping(value="admin/addgrade", method = RequestMethod.POST)
        public String addGrade(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap, RedirectAttributes redirectAttributes){
        	String retVal="redirect:/common/admin/creategrade"+ encryptDecryptUtils.generateRedirect("common/admin/creategrade", request);
        	int userId = 0;
        	int clientId = 0;
        	boolean success = true;
        	String failureMsg=CommonKeywords.ERROR_MSG.toString();
        	try {
				userId = abcUtility.getSessionUserId(request);
				clientId = abcUtility.getSessionClientId(request);
				if(userId!=0){
					String gradeName = StringUtils.hasLength(request.getParameter("txtGradeName")) ? request.getParameter("txtGradeName") : "";
					long minLimit = StringUtils.hasLength(request.getParameter("txtMinFinLimit")) ? Long.parseLong(request.getParameter("txtMinFinLimit")) : 0;
					long maxLimit = StringUtils.hasLength(request.getParameter("txtMaxFinLimit")) ? Long.parseLong(request.getParameter("txtMaxFinLimit")) : 0;
					int level = StringUtils.hasLength(request.getParameter("selLevel")) ? Integer.parseInt(request.getParameter("selLevel")) : 0;
					if(gradeName!=null && !"".equalsIgnoreCase(gradeName) && minLimit>=0 && maxLimit!=0 && level!=0){
						if(manageContentService.isDuplicateGradeLevel(level, clientId)){
							success = false;
							failureMsg = "msg_gradelevel_invalid";
						}
						if(success){
							TblGrade tblGrade = new TblGrade();
							tblGrade.setGradeName(gradeName);
							tblGrade.setMinLimit(minLimit);
							tblGrade.setMaxLimit(maxLimit);
							tblGrade.setGradelevel(level);
							tblGrade.setTblClient(new TblClient(clientId));
							success =  manageContentService.addGrade(tblGrade);
						}
						if(success){
							retVal="redirect:/common/admin/managegrade"+encryptDecryptUtils.generateRedirect("common/admin/managegrade", request);//"redirect:/common/admin/managegrade"+ encryptDecryptUtils.generateRedirect("common/admin/managegrade", request);
						}
					}
					redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),success ?  "redirect_success_gradeadded_successfully" : failureMsg);
				}
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	finally{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, "Add grade", 0,0);
        	}
        	return retVal;
        }
        
        @ResponseBody
        @RequestMapping(value="/admin/overlape", method=RequestMethod.POST)
        public String overlapeLimit(HttpServletRequest request,HttpServletResponse response){
        	boolean success=false;
        	StringBuilder retVal=new StringBuilder();
        	int userId = 0;
        	int gradeId = 0;
        	try {
				userId = abcUtility.getSessionUserId(request); 
				if(userId!=0){
					boolean isMinLimit = StringUtils.hasLength(request.getParameter("txtIsMinLimit")) ? Boolean.parseBoolean(request.getParameter("txtIsMinLimit")) : false;
					int limitValue = StringUtils.hasLength(request.getParameter("txtLimitVal")) ? Integer.parseInt(request.getParameter("txtLimitVal")) : 0;
					boolean isEdit = StringUtils.hasLength(request.getParameter("txtIsEdit")) ? Boolean.parseBoolean(request.getParameter("txtIsEdit")) : false;
					gradeId = StringUtils.hasLength(request.getParameter("txtGradeId")) ? Integer.parseInt(request.getParameter("txtGradeId")) : 0;
					success = manageContentService.isDuplicateFinLimit(isMinLimit, limitValue, isEdit, gradeId, abcUtility.getSessionClientId(request));
					if(success){
						retVal.append("true");
					}
					else{
						retVal.append("false");
					}
				}
				else{
					retVal.append("sessionexpired");
				}
			} catch (Exception e) {
				exceptionHandlerService.writeLog(e);
			}
        	return retVal.toString();
        }
        
        @ResponseBody
        @RequestMapping(value="/admin/gradename", method=RequestMethod.POST) 
        public String gradeNameCheck(HttpServletRequest request,HttpServletResponse response){
        	boolean success=false;
        	StringBuilder retVal=new StringBuilder();
        	int userId = 0;
        	try {
				userId = abcUtility.getSessionUserId(request);
				if(userId!=0){
					String gradeName = StringUtils.hasLength(request.getParameter("txtGradeName")) ? request.getParameter("txtGradeName") : "";
					success = manageContentService.isDuplicateGradeName(gradeName, abcUtility.getSessionClientId(request));
					if(success){
						retVal.append("true");
					}
					else{
						retVal.append("false");
					}
				}
				else{
					retVal.append("sessionexpired");
				}
			} catch (Exception e) {
				exceptionHandlerService.writeLog(e);
			}
        	return retVal.toString();
        }
        /**
         * To show edit grade page
         * 
         * @author purvesh
         * @param gradeId
         * @param clientId
         * @param modelMap
         * @param request
         * @return
         */
        @RequestMapping(value="/admin/showeditgrade/{gradeId}/{clientId}/{enc}", method=RequestMethod.GET)
        public String showEditGrade(@PathVariable("gradeId")int gradeId, @PathVariable("clientId")int clientId, ModelMap modelMap,HttpServletRequest request){
        	String retVal="common/admin/CreateGrade";
        	try {
        		modelMap.addAttribute("operType","edit");
        		modelMap.addAttribute("waringMsg","msg_notification_creategrade");
                List<SelectItem> selSortOrder = new ArrayList<SelectItem>();
                selSortOrder.add(new SelectItem("1", 1));
                selSortOrder.add(new SelectItem("2", 2));
                selSortOrder.add(new SelectItem("3", 3));
                selSortOrder.add(new SelectItem("4", 4));
                selSortOrder.add(new SelectItem("5", 5));
                selSortOrder.add(new SelectItem("6", 6));
                selSortOrder.add(new SelectItem("7", 7));
                selSortOrder.add(new SelectItem("8", 8));
                selSortOrder.add(new SelectItem("9", 9));
                selSortOrder.add(new SelectItem("10", 10));
                selSortOrder.add(new SelectItem("11", 11));
                selSortOrder.add(new SelectItem("12", 12));
                selSortOrder.add(new SelectItem("13", 13));
                selSortOrder.add(new SelectItem("14", 14));
                selSortOrder.add(new SelectItem("15", 15));
                modelMap.addAttribute("selSortOrder", selSortOrder);
                TblGrade tblGrade = manageContentService.getGrade(gradeId, clientId).get(0);
                modelMap.addAttribute("tblGrade", tblGrade);
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	finally{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, "Accessed edit grade page", 0,0);
        	}
        	return retVal;
        }
        /**
         * To update grade
         * 
         * @author purvesh
         * @param request
         * @param response
         * @param modelMap
         * @param redirectAttributes
         * @return
         */
        @RequestMapping(value="admin/updategrade", method = RequestMethod.POST)
        public String updateGrade(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap, RedirectAttributes redirectAttributes){
        	String retVal="";
        	int userId = 0;
        	int clientId = 0;
        	int gradeId = 0;
        	boolean success = false;
        	try {
				userId = abcUtility.getSessionUserId(request);
				clientId = abcUtility.getSessionClientId(request);
				if(userId!=0){
					gradeId = StringUtils.hasLength(request.getParameter("hdGradeId")) ? Integer.parseInt(request.getParameter("hdGradeId")) : 0;
					String gradeName = StringUtils.hasLength(request.getParameter("txtGradeName")) ? request.getParameter("txtGradeName") : "";
					long minLimit = StringUtils.hasLength(request.getParameter("txtMinFinLimit")) ? Long.parseLong(request.getParameter("txtMinFinLimit")) : 0;
					long maxLimit = StringUtils.hasLength(request.getParameter("txtMaxFinLimit")) ? Long.parseLong(request.getParameter("txtMaxFinLimit")) : 0;
					int level = StringUtils.hasLength(request.getParameter("hdLevel")) ? Integer.parseInt(request.getParameter("hdLevel")) : 0;
					retVal="redirect:/common/admin/showeditgrade/"+ gradeId+"/"+clientId+ encryptDecryptUtils.generateRedirect("common/admin/showeditgrade/"+ gradeId+"/"+clientId, request);
					if(gradeName!=null && !"".equalsIgnoreCase(gradeName) && minLimit>=0 && maxLimit!=0 && level!=0){
						success = manageContentService.updateGrade(clientId, gradeId, gradeName, minLimit, maxLimit, level);						
						if(success){
							retVal="redirect:/common/admin/managegrade"+encryptDecryptUtils.generateRedirect("common/admin/managegrade", request);//"redirect:/common/admin/managegrade"+ encryptDecryptUtils.generateRedirect("common/admin/managegrade", request);
						}
					}
					redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),success ?  "redirect_success_gradeupdated_successfully" : CommonKeywords.ERROR_MSG.toString());
				}
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	finally{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, "Update grade", gradeId,clientId);
        	}
        	return retVal;
        }
        /**
         * To view grade
         * 
         * @author purvesh
         * @param gradeId
         * @param clientId
         * @param modelMap
         * @param request
         * @return
         */
        @RequestMapping(value="/admin/viewgrade/{gradeId}/{clientId}/{enc}", method=RequestMethod.GET)
        public String viewGrade(@PathVariable("gradeId")int gradeId, @PathVariable("clientId")int clientId, ModelMap modelMap,HttpServletRequest request){
        	String retVal="common/admin/ViewGrade";
        	try {
        		modelMap.addAttribute("waringMsg","msg_notification_creategrade");
                TblGrade tblGrade = manageContentService.getGrade(gradeId, clientId).get(0);
                modelMap.addAttribute("tblGrade", tblGrade);
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	finally{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, "Accessed edit grade page", 0,0);
        	}
        	return retVal;
        }
        
        /**
    	 * To Show manage Grade
    	 * 
    	 * @author purvesh
    	 * @param request
    	 * @param response
    	 * @param modelMap
    	 * @return
    	 */
    	@RequestMapping(value="/admin/managegrade/{enc}", method=RequestMethod.GET)
    	public String manageGrade(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap){
    		String retVal="common/admin/ManageGrade";
    		try {
    			modelMap.addAttribute("reportId",gradeListingReportId);
    			reportGeneratorService.getReportConfigDetails(gradeListingReportId, modelMap);
    		} catch (Exception e) {
    			retVal = exceptionHandlerService.writeLog(e);
    		}
    		finally{
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "Manage grade list", 0,0);
    		}
    		return retVal;
    	}
    	/**
         * To show create Group
         * 
         * @author Keval
         * @param modelMap
         * @param request
         * @return
         */
        @RequestMapping(value="/admin/creategroup/{enc}", method = RequestMethod.GET)
        public String createGroup(ModelMap modelMap,HttpServletRequest request){
        	String retVal="common/admin/CreateGroup";
        	try {
        		int clientId = abcUtility.getSessionClientId(request);
        		modelMap.addAttribute("operType","create");
        		List<SelectItem> items = new ArrayList<SelectItem>();
        		List<Object[]> screenList = manageContentService.getScreenByClientId(clientId);
        		for(int i=0;i<screenList.size();i++){
        			items.add(new SelectItem(screenList.get(i)[1], screenList.get(i)[0]));
        		}
        		modelMap.put("screenList",items);
        		List<SelectItem> selMandatory = new ArrayList<SelectItem>();
        		selMandatory.add(new SelectItem("Mandatory", 1));
        		selMandatory.add(new SelectItem("Non–mandatory", 2));
        		selMandatory.add(new SelectItem("Partial", 3));
                modelMap.addAttribute("selMandatory", selMandatory);
                
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	finally{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0, "Accessed create grade page", 0,0);
        	}
        	return retVal;
        }
        /**
         * To add Group
         * 
         * @author Keval soni
         * @param request
         * @param response
         * @param modelMap
         * @param redirectAttributes
         * @return
         */
        @RequestMapping(value="admin/addgroup", method = RequestMethod.POST)
        public String addGroup(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap, RedirectAttributes redirectAttributes){
        	String retVal="redirect:/common/admin/creategroup"+ encryptDecryptUtils.generateRedirect("common/admin/creategroup", request);
        	int userId = 0;
        	int clientId = 0,isMandatory = 0;
        	boolean success = true;
        	String failureMsg=CommonKeywords.ERROR_MSG.toString();
        	try {
        		Date date = commonService.getServerDateTime();
        		TblDynFieldGroup dynFldGroup = new TblDynFieldGroup();
        		userId = abcUtility.getSessionUserId(request);
				clientId = abcUtility.getSessionClientId(request);
        		String groupName = StringUtils.hasLength(request.getParameter("txtGroupName")) ? request.getParameter("txtGroupName") : "";
        		isMandatory = StringUtils.hasLength(request.getParameter("selIsMandatory")) ? Integer.parseInt(request.getParameter("selIsMandatory")) : 0;
        		int screenId = StringUtils.hasLength(request.getParameter("selScreenId")) ? Integer.parseInt(request.getParameter("selScreenId")) : 0;
        		isMandatory = StringUtils.hasLength(request.getParameter("selIsMandatory")) ? Integer.parseInt(request.getParameter("selIsMandatory")) : 0;
        		dynFldGroup.setGroupName(groupName);
				dynFldGroup.setLinkId(screenId);
				dynFldGroup.setCstatus(1);
				dynFldGroup.setSortOrder(1);
				dynFldGroup.setTblClient(new TblClient(clientId));
				dynFldGroup.setCreatedBy(userId);
				dynFldGroup.setCreatedOn(date);
				dynFldGroup.setUpdatedBy(userId);
				dynFldGroup.setUpdatedOn(date);
				dynFldGroup.setIsMandatory(isMandatory);
				success = manageContentService.addDynFldGroup(dynFldGroup);
				if(success){
					retVal="redirect:/common/admin/showeditgroup/"+dynFldGroup.getGroupId()+"/"+clientId+encryptDecryptUtils.generateRedirect("common/admin/showeditgroup/"+dynFldGroup.getGroupId()+"/"+clientId, request);
				}
				redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),success ?  "msg_fields_group_added_successfully" : failureMsg);
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	return retVal;
        } /**
    	 * To Show manage Group
    	 * 
    	 * @author Keval Soni
    	 * @param request
    	 * @param response
    	 * @param modelMap
    	 * @return
    	 */
    	@RequestMapping(value="/admin/managegroup/{enc}", method=RequestMethod.GET)
    	public String manageGroup(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap){
    		String retVal="common/admin/ManageGroup";
    		try {
    			modelMap.addAttribute("reportId",groupListingReportId);
    			reportGeneratorService.getReportConfigDetails(groupListingReportId, modelMap);
    			int clientId = abcUtility.getSessionClientId(request);
    			List<SelectItem> items = new ArrayList<SelectItem>();
        		List<Object[]> screenList = manageContentService.getScreenByClientId(clientId);
        		for(int i=0;i<screenList.size();i++){
        			items.add(new SelectItem(screenList.get(i)[1], screenList.get(i)[0]));
        		}
        		modelMap.put("screenList",items);
        		List<SelectItem> selMandatory = new ArrayList<SelectItem>();
        		selMandatory.add(new SelectItem("Mandatory", 1));
        		selMandatory.add(new SelectItem("Non–mandatory", 2));
        		selMandatory.add(new SelectItem("Partial", 3));
                modelMap.addAttribute("selMandatory", selMandatory);
    		} catch (Exception e) {
    			retVal = exceptionHandlerService.writeLog(e);
    		}
    		return retVal;
    	}
    	 
        /**
         * To view Group
         * 
         * @author Keval Soni
         * @param groupId
         * @param clientId
         * @param modelMap
         * @param request
         * @return
         */
        @RequestMapping(value="/admin/viewgroup/{groupId}/{clientId}/{enc}", method=RequestMethod.GET)
        public String viewGroup(@PathVariable("groupId")int groupId, @PathVariable("clientId")int clientId, ModelMap modelMap,HttpServletRequest request){
        	String retVal="common/admin/CreateGroup";
        	try {
        		modelMap.addAttribute("operType","view");
                TblDynFieldGroup tblDynFieldGroup = manageContentService.getGroup(groupId, clientId).get(0);
                int screenId = tblDynFieldGroup.getLinkId();
        		List<Object[]> screenList = manageContentService.getScreenByClientId(clientId);
        		for(int i=0;i<screenList.size();i++){
        			if(tblDynFieldGroup.getLinkId()==Integer.parseInt(screenList.get(i)[0].toString()))
        					modelMap.put("ScreenName",screenList.get(i)[1]);	
        		}
                modelMap.addAttribute("tblDynFieldGroup", tblDynFieldGroup);
                
                List<Object[]> dynFieldByScreen = (List<Object[]>)manageContentService.getDynFieldByScreen(screenId,clientId,0); // 0 - for Selected Fields Only
    			List<Object[]> groupList = (List<Object[]>)manageContentService.getGroupListByScreenIdAndClientId(screenId,clientId,0);// 0 - for Selected Fields Only
    			List<SelectItem> selGroup = abcUtility.convert(groupList);
    			modelMap.addAttribute("selGroup", selGroup);
    			
				List<Object[]> dynFldGrpMapping = manageContentService.getGroupMappingDetailsByGroupId(Integer.valueOf(groupId));
				modelMap.addAttribute("MappedField", dynFldGrpMapping);
				List<SelectItem> selSort = new ArrayList<SelectItem>();
    			for(int i=0;i<dynFldGrpMapping.size();i++){
    				selSort.add(new SelectItem(i+1, i+1));
    			}
    			 modelMap.addAttribute("selSort", selSort);
    			modelMap.addAttribute("DynField", dynFieldByScreen);
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	return retVal;
        }
        @ResponseBody
        @RequestMapping(value="/admin/groupname", method=RequestMethod.POST) 
        public String groupNameCheck(HttpServletRequest request,HttpServletResponse response){
        	boolean success=false;
        	StringBuilder retVal=new StringBuilder();
        	int userId = 0;
        	try {
				userId = abcUtility.getSessionUserId(request);
				if(userId!=0){
					String groupName = StringUtils.hasLength(request.getParameter("txtGroupName")) ? request.getParameter("txtGroupName") : "";
					success = manageContentService.isDuplicateGroupName(groupName, abcUtility.getSessionClientId(request));
					if(success){
						retVal.append("true");
					}
					else{
						retVal.append("false");
					}
				}
				else{
					retVal.append("sessionexpired");
				}
			} catch (Exception e) {
				exceptionHandlerService.writeLog(e);
			}
        	return retVal.toString();
        }
        /**
         * To show edit Group page
         * 
         * @author Keval Soni
         * @param groupId
         * @param clientId
         * @param modelMap
         * @param request
         * @return
         */
        @RequestMapping(value="/admin/showeditgroup/{groupId}/{clientId}/{enc}", method=RequestMethod.GET)
        public String showEditGroup(@PathVariable("groupId")int groupId, @PathVariable("clientId")int clientId, ModelMap modelMap,HttpServletRequest request){
        	String retVal="common/admin/CreateGroup";
        	try {
        		modelMap.addAttribute("operType","edit");
                TblDynFieldGroup tblDynFieldGroup = manageContentService.getGroup(groupId, clientId).get(0);
                int screenId = tblDynFieldGroup.getLinkId();
        		List<Object[]> screenList = manageContentService.getScreenByClientId(clientId);
        		for(int i=0;i<screenList.size();i++){
        			if(tblDynFieldGroup.getLinkId()==Integer.parseInt(screenList.get(i)[0].toString()))
        					modelMap.put("ScreenName",screenList.get(i)[1]);	
        		}
                modelMap.addAttribute("tblDynFieldGroup", tblDynFieldGroup);
                
                List<Object[]> dynFieldByScreen = (List<Object[]>)manageContentService.getDynFieldByScreen(screenId,clientId,0); // 0 - for Selected Fields Only
    			List<Object[]> groupList = (List<Object[]>)manageContentService.getGroupListByScreenIdAndClientId(screenId,clientId,0);// 0 - for Selected Fields Only
    			List<SelectItem> selGroup = abcUtility.convert(groupList);
    			modelMap.addAttribute("selGroup", selGroup);
    			
				List<Object[]> dynFldGrpMapping = manageContentService.getGroupMappingDetailsByGroupId(Integer.valueOf(groupId));
				modelMap.addAttribute("MappedField", dynFldGrpMapping);
				List<SelectItem> selSort = new ArrayList<SelectItem>();
    			for(int i=0;i<dynFldGrpMapping.size();i++){
    				selSort.add(new SelectItem(i+1, i+1));
    			}
    			 modelMap.addAttribute("selSort", selSort);
    			modelMap.addAttribute("DynField", dynFieldByScreen);
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	return retVal;
        }
        /**
         * To update Group
         * 
         * @author Keval Soni
         * @param request
         * @param response
         * @param modelMap
         * @param redirectAttributes
         * @return
         */
        @RequestMapping(value="admin/updategroup", method = RequestMethod.POST)
        public String updateGroup(HttpServletRequest request,HttpServletResponse response, ModelMap modelMap, RedirectAttributes redirectAttributes){
        	String retVal="";
        	int userId = 0,isMandatory = 0;
        	int clientId = 0,isFieldSelected=0,dynFieldId=0,sortOrder=0;
        	int groupId = 0,screenId = 0,groupIdSelected = 0;
        	boolean success = true;
        	try {
				userId = abcUtility.getSessionUserId(request);
				clientId = abcUtility.getSessionClientId(request);
				Date date = commonService.getServerDateTime();
				groupId = StringUtils.hasLength(request.getParameter("hdGroupId")) ? Integer.parseInt(request.getParameter("hdGroupId")) : 0;
				screenId = StringUtils.hasLength(request.getParameter("hdScreenId")) ? Integer.parseInt(request.getParameter("hdScreenId")) : 0;
				isMandatory = StringUtils.hasLength(request.getParameter("hdIsMandatory")) ? Integer.parseInt(request.getParameter("hdIsMandatory")) : 0;
				List<Object[]> dynFldGrpMapping = manageContentService.getGroupMappingDetailsByGroupId(Integer.valueOf(groupId));
				List<TblDynFieldGroup> groupList = new ArrayList<TblDynFieldGroup>();
				List<TblDynFieldGroup> dynGroupList = (List<TblDynFieldGroup>)manageContentService.getGroupListByScreenIdAndClientId(screenId,clientId,1);// 1 - for Whole Group
				Map<Integer, TblDynFieldGroup> fieldGroupMap = new HashMap<Integer, TblDynFieldGroup>();
				for(int i=0;i<dynGroupList.size();i++){
					fieldGroupMap.put(dynGroupList.get(i).getGroupId(), dynGroupList.get(i));
				}
				TblDynFieldGroup dynFldGroup = new TblDynFieldGroup();
				TblDynFieldGroupMapping dynFldGroupMapp = new TblDynFieldGroupMapping();
				List<TblDynFieldGroupMapping> dynFldGroupMappingList = new ArrayList<TblDynFieldGroupMapping>();
				List<Integer> mappingTobeDeleted = new ArrayList<Integer>();
				List<Integer> groupIdsList = new ArrayList<Integer>();
				List<Integer> dynFldidLst = new ArrayList<Integer>();
				List<TblDynField> dynFldList = new ArrayList<TblDynField>();
				
				Integer[] fieldsIds = new Integer[dynFldGrpMapping.size()];
				for(int i=0;i<dynFldGrpMapping.size();i++){
					fieldsIds[i] = Integer.parseInt(dynFldGrpMapping.get(i)[0].toString());
					dynFldidLst.add(Integer.parseInt(dynFldGrpMapping.get(i)[0].toString()));
				}
				Map<Integer, TblDynField> fieldMap = new HashMap<Integer, TblDynField>();
				if(fieldsIds.length != 0){
					fieldMap = dynamicFieldService.getDynFieldListById(fieldsIds);
				}
				List<TblDynField> dynFieldByScreen = (List<TblDynField>)manageContentService.getDynFieldByScreen(screenId,clientId,1);
				TblDynField dynField = new TblDynField();
				for(int i=0;i<dynFldGrpMapping.size();i++){
					dynFieldId = Integer.parseInt(dynFldGrpMapping.get(i)[0].toString());
					isFieldSelected =  StringUtils.hasLength(request.getParameter("chkSelectedYesOrNo_"+dynFieldId)) ? Integer.parseInt(request.getParameter("chkSelectedYesOrNo_"+dynFieldId)) : 0;
					if(isFieldSelected == 1){
						groupIdSelected = StringUtils.hasLength(request.getParameter("selGroupId_"+dynFieldId)) ? Integer.parseInt(request.getParameter("selGroupId_"+dynFieldId)) : 0;
						if(groupId == groupIdSelected){
							sortOrder = StringUtils.hasLength(request.getParameter("selSort_"+dynFieldId)) ? Integer.parseInt(request.getParameter("selSort_"+dynFieldId)) : 0;
							if(!groupIdsList.contains(groupId)){
								dynFldGroup = new TblDynFieldGroup();
								BeanUtils.copyProperties(fieldGroupMap.get(groupIdSelected), dynFldGroup);
								dynFldGroup.setTblDynFieldGroupMapping(null);
								dynFldGroup.setUpdatedBy(userId);
								dynFldGroup.setUpdatedOn(date);
								groupList.add(dynFldGroup);
								groupIdsList.add(groupIdSelected);
							}
							dynField = new TblDynField();
							BeanUtils.copyProperties(fieldMap.get(dynFieldId), dynField);
							dynField.setTblClientField(null);
							dynField.setTblDynControlType(new TblDynControlType(dynFieldByScreen.get(i).getTblDynControlType().getControlTypeId()));
							if(isMandatory == 1){
								dynField.setIsMandatory(1);
							}else if(isMandatory == 2){
								dynField.setIsMandatory(0);
							}else{
								dynField.setIsMandatory(StringUtils.hasLength(request.getParameter("chkMandatoryYesOrNo_"+dynFieldId)) ? Integer.parseInt(request.getParameter("chkMandatoryYesOrNo_"+dynFieldId)) : 0);
							}
							
							dynFldGroupMapp = new TblDynFieldGroupMapping(Integer.parseInt(dynFldGrpMapping.get(i)[2].toString()));
							dynFldGroupMapp.setSortOrder(sortOrder);
							dynFldGroupMapp.setTblDynFieldGroup(new TblDynFieldGroup(groupId));
							dynFldGroupMapp.setTblDynField(dynField);
							dynFldGroupMappingList.add(dynFldGroupMapp);
							dynFldList.add(dynField);
						}else{
							mappingTobeDeleted.add(Integer.parseInt(dynFldGrpMapping.get(i)[2].toString()));
						}
					}else{
						mappingTobeDeleted.add(Integer.parseInt(dynFldGrpMapping.get(i)[2].toString()));
					}
				}
				List<Object[]> maxSortOrder = manageContentService.getMaxSortorderByClientId(clientId);
				Map<Integer, Integer> groupIdWithMaxSortOrder = new HashMap<Integer, Integer>();
				for(int i = 0;i<maxSortOrder.size();i++){
					groupIdWithMaxSortOrder.put(Integer.parseInt(maxSortOrder.get(i)[0].toString()), Integer.parseInt(maxSortOrder.get(i)[1].toString()));
				}
				List<Object[]> groupWithMandatory = manageContentService.getGroupMadatoryList(clientId);
				Map<Integer, Integer> groupMandatoryData = new HashMap<Integer, Integer>();
				for(int i=0;i<groupWithMandatory.size();i++){
					groupMandatoryData.put(Integer.parseInt(groupWithMandatory.get(i)[0].toString()), Integer.parseInt(groupWithMandatory.get(i)[1].toString()));
				}
				for(int i=0;i<dynFieldByScreen.size();i++){
					dynField = new TblDynField();
					BeanUtils.copyProperties(dynFieldByScreen.get(i), dynField);
					dynField.setTblClientField(null);
					dynField.setTblDynControlType(new TblDynControlType(dynFieldByScreen.get(i).getTblDynControlType().getControlTypeId()));
					dynFieldId = dynFieldByScreen.get(i).getFieldId();
					isFieldSelected =  StringUtils.hasLength(request.getParameter("chkSelectedYesOrNo_"+dynFieldId)) ? Integer.parseInt(request.getParameter("chkSelectedYesOrNo_"+dynFieldId)) : 0;
					groupIdSelected = StringUtils.hasLength(request.getParameter("selGroupId_"+dynFieldId)) ? Integer.parseInt(request.getParameter("selGroupId_"+dynFieldId)) : 0;
					if(isFieldSelected == 1 && (groupId != groupIdSelected || (groupId == groupIdSelected && !dynFldidLst.contains(dynFieldId)))){
						dynFldGroupMapp = new TblDynFieldGroupMapping();
						if(!groupIdsList.contains(groupIdSelected)){
							dynFldGroup = new TblDynFieldGroup();
							BeanUtils.copyProperties(fieldGroupMap.get(groupIdSelected), dynFldGroup);
							dynFldGroup.setTblDynFieldGroupMapping(null);
							dynFldGroup.setUpdatedBy(userId);
							dynFldGroup.setUpdatedOn(date);
							groupList.add(dynFldGroup);
							groupIdsList.add(groupIdSelected);
						}
						if(!groupIdWithMaxSortOrder.containsKey(groupIdSelected)){
							groupIdWithMaxSortOrder.put(groupIdSelected, 0);
						}
						dynFldGroupMapp.setSortOrder((groupIdWithMaxSortOrder.get(groupIdSelected)+1));
						groupIdWithMaxSortOrder.put(groupIdSelected, groupIdWithMaxSortOrder.get(groupIdSelected)+1);
						dynFldGroupMapp.setTblDynFieldGroup(new TblDynFieldGroup(groupIdSelected));
						if(groupMandatoryData.get(groupIdSelected) == 1){
							dynField.setIsMandatory(1);
						}else if(groupMandatoryData.get(groupIdSelected) == 2){
							dynField.setIsMandatory(0);
						}else{
							dynField.setIsMandatory(StringUtils.hasLength(request.getParameter("MandatoryYesOrNo_"+dynFieldId)) ? Integer.parseInt(request.getParameter("MandatoryYesOrNo_"+dynFieldId)) : 0);
						}
						dynFldGroupMapp.setTblDynField(dynField);
						dynFldGroupMappingList.add(dynFldGroupMapp);
						dynFldList.add(dynField);
					}
				}
				success = manageContentService.addGroupAndMappingData(groupList,dynFldList,dynFldGroupMappingList,mappingTobeDeleted);
				if(success){
					retVal="redirect:/common/admin/managegroup"+encryptDecryptUtils.generateRedirect("common/admin/managegroup", request);
				}
				redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),success ?  "redirect_success_groupupdated_successfully" : CommonKeywords.ERROR_MSG.toString());
				/*}*/
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	return retVal;
        }
    	  /**
         * By bharat
         * to dispaly create banner JSP Page
         */
    	  /**
    	 * To Show Create Banner
    	 * 
    	 * @author bharat
    	 * @param request
    	 * @param response
    	 * @param modelMap
    	 * @return
    	 */
    	  @RequestMapping(value = "/admin/createbanner/{enc}", method = RequestMethod.GET)
          public String createBanner(HttpServletRequest request,ModelMap map) {
              String retVal = "common/admin/CreateBanner";
              try {
            	int manageBannerBannerEventid = 125; /// Event id for banner.
              	map.addAttribute("accourdainList",manageContentService.getAccordionList());
              	map.addAttribute("isDateRequireList",manageContentService.getisDateRequireList());
              	map.addAttribute("imageLinkType",manageContentService.getImmageLinkType());
              	map.addAttribute("domainType",manageContentService.getDomainType());
              	map.addAttribute("clientId", abcUtility.getSessionClientId(request));
              	map.addAttribute("isSmsAppRequire", manageContentService.getisSmsAppRequire());
              	map.addAttribute("senderId", manageContentService.getsenderId());
              	map.put("domainList", getAllDomainList());
      			addDocumentDetail(map,abcUtility.getSessionClientId(request),manageBannerBannerEventid,manageBannerCreateBanner); 
  		        map.addAttribute("contentManagementList",manageContentService.getContentManagementListByCreatedBy(abcUtility.getSessionClientId(request),manageBannerCreateBanner));
              } catch (Exception ex) {
                  return exceptionHandlerService.writeLog(ex);
              } finally {
                  auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageBannerCreateBanner, createBanner, 0, 0);
              }
              return retVal;
          }

	private List<SelectItem> getAllDomainList() throws Exception {
		List<Object[]> allDomainList = commonService.getAllDomain();
		List<SelectItem> domainList = new ArrayList<SelectItem>();
		if (allDomainList != null && !allDomainList.isEmpty()) {
			for (Object[] objects : allDomainList) {
				domainList.add(new SelectItem(objects[1], objects[0]));
			}
		}
		return domainList;
	}

	private void addDocumentDetail(ModelMap map, int clientId,int eventId,int linkId) throws Exception {

		List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, clientId); // Event Id Need to change
		int allowedSize = 0;
		StringBuilder allowedExt = new StringBuilder();
		if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
			allowedSize = lstDocUploadConf.get(0).getMaxSize();
			allowedExt.append(lstDocUploadConf.get(0).getType());
			map.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
		}
		int index = allowedExt.toString().indexOf(",");
		allowedExt.insert(index + 1, "*.");
		while (index >= 0) {
			index = allowedExt.toString().indexOf(",", index + ",".length());
			allowedExt.insert(index + 1, "*.");
		}
		map.addAttribute("allowedExt", allowedExt);
		map.addAttribute("allowedSize", allowedSize / 1024);
		map.addAttribute("linkId", linkId); // / need to change Link id
		map.addAttribute("cStatusDoc", 1);

	}

	  /**
     * By bharat
     * to dispaly addbanner
     */
	  /**
	 * To shave Created Banner
	 * 
	 * @author bharatkumar
	 * @param request
	 * @param RedirectAttributes
	 * @param modelMap
	 * @return
	 */
    @RequestMapping(value = "/admin/addbanner", method = RequestMethod.POST)
    public String addBanner(HttpServletRequest request, RedirectAttributes rd,ModelMap map) {
    	String retVal = null;
        try {
        	String selAccordion = request.getParameter("selAccordion1");
        	String txBannerDesc = request.getParameter("txtBannerDesc"); 
        	String selSmsAppRequire=request.getParameter("selSmsAppRequire");
        	String selDisplayDateRequire = request.getParameter("selDisplayDateRequire");
        	String txStartDate = request.getParameter("txtStartDate");
        	String txEndDate = request.getParameter("txtEndDate"); 
        	String selImageLinkType = request.getParameter("selImageLinkType");
        	String txLink = request.getParameter("txtLink");
        	String txLinkMap = request.getParameter("rtfLinkMap"); 
        	String selDomainType = request.getParameter("selDomainType");
        	String txtHidDocIds = request.getParameter("txtHidDocIds");
        	String DownloadLink=request.getParameter("txtDownloadLink");
        	String selsenderId=request.getParameter("selsenderId");
        	String[] chkMultipleDomain = request.getParameterValues("chkMultipleDomain");
        	TblContentManagement tblContentManagement = new TblContentManagement();
        	tblContentManagement.setContentType(5); // Need to change making it to 5

    		if (selImageLinkType != null && selImageLinkType.equals("1")) {
    			tblContentManagement.setContentText(txLink);
    			tblContentManagement.setLinkType(1);
    		} else if (selImageLinkType != null && selImageLinkType.equals("2")) {
    			tblContentManagement.setContentText(txLinkMap);
    			tblContentManagement.setLinkType(2);
    		} else {
    			tblContentManagement.setContentText("");
    			tblContentManagement.setLinkType(0);
    		}
    		/*sms require*/
    		if (selSmsAppRequire != null && selSmsAppRequire.equals("1")) {
    			String ContentText=DownloadLink;
    			int senderId=Integer.parseInt(request.getParameter("selsenderId"));
    			tblContentManagement.setContentText(ContentText);
    			tblContentManagement.setSmsRequire(1);
    			tblContentManagement.setSenderId(senderId);
    		} else {
    			tblContentManagement.setSenderId(0);
    			tblContentManagement.setSmsRequire(0);
    		}
    		
    		if (selDisplayDateRequire != null && selDisplayDateRequire.equals("1")) {
    			Date startDate = conversionService.convert(txStartDate, Date.class);
            	Date endDate = conversionService.convert(txEndDate, Date.class);
    			tblContentManagement.setStartDate(startDate);
    			tblContentManagement.setEndDate(endDate);
    			tblContentManagement.setIsDateRequired(1);
    		} else {
    			Date date = commonService.getServerDateTime();
    			tblContentManagement.setStartDate(date);
    			tblContentManagement.setEndDate(date);
    			tblContentManagement.setIsDateRequired(0);
    			//selSmsAppRequire
    		}
    		tblContentManagement.setCreatedBy(abcUtility.getSessionClientId(request));
    		tblContentManagement.setLocationId(Integer.parseInt(selAccordion));
    		tblContentManagement.setIsActive(1);
    		List<TblClientContentMapping> clientContentMappings = new ArrayList<TblClientContentMapping>();
    		TblClientContentMapping contentMapping = null;
    		int maxCount = manageContentService.getMaxCountOfPriority(abcUtility.getSessionClientId(request),Integer.parseInt(selAccordion));
    		if (selDomainType != null && selDomainType.equals("1")) {
    			for (String clientID : chkMultipleDomain) {
    				contentMapping = new TblClientContentMapping();
    				contentMapping.setTblClient(new TblClient(Integer.parseInt(clientID)));
    				contentMapping.setTblContentManagement(tblContentManagement);
    				contentMapping.setIsActive(1);
    				contentMapping.setPriority(maxCount+1);
    				clientContentMappings.add(contentMapping);
    			}
    		} else {
    			contentMapping = new TblClientContentMapping();
    			contentMapping.setTblClient(new TblClient(abcUtility
    					.getSessionClientId(request)));
    			contentMapping.setTblContentManagement(tblContentManagement);
    			contentMapping.setIsActive(1);
    			contentMapping.setPriority(maxCount+1);
    			clientContentMappings.add(contentMapping);
    		}
    		
        	if(manageContentService.addBanner(tblContentManagement,clientContentMappings,txtHidDocIds))
        	{
        		rd.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_success_create_banner");
        	} else{
				rd.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
			}
        	List<List<Object>> contentManagementList = null;
	        contentManagementList = manageContentService.getContentManagementListByCreatedBy(abcUtility.getSessionClientId(request),manageBannerCreateBanner);
	        map.addAttribute("contentManagementList",contentManagementList);
        	retVal  ="redirect:/common/admin/createbanner"+encryptDecryptUtils.generateRedirect("common/admin/createbanner", request);
        	
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageBannerCreateBanner, saveBanner, 0, 0);
        }
        return retVal;
    }

    	
    	/**
    	 * To Manage the Banner get request
    	 * @author 	Mitesh
    	 */
    	@RequestMapping(value="/admin/managebanner/{enc}", method=RequestMethod.GET)
    	public String manageClientBanner(ModelMap modelMap, HttpServletRequest request){
    		String retVal="common/admin/ManageBanner";
    		int clientId=abcUtility.getSessionClientId(request);
    		//System.out.println("client id="+clientId);
    		boolean isfirstRequest=false;
    		try {
    		//	System.out.println("In manage banner controller");
    			//call the client banner constant service
    			List<Object[]> contentList=manageContentService.getClientBannersContent(clientId);
    			//get the clientContentId from the List
    			Object[] contentmanagetId =new Object[contentList.size()];
    			for (int i=0;i<contentList.size();i++) {
    	 				Object[] objects=contentList.get(i);
    					contentmanagetId[i]=objects[3];
    			}
    			//call the client banner
    			List<Object[]> contentListbanner=null;
    			if(contentmanagetId.length>0){
    				contentListbanner=manageContentService.getClientBanners(manageBannerCreateBanner,contentmanagetId);
    			}
    			//check the controller call the fisttime or not
    		
    			int priorityCount=manageContentService.getPriorityCount(clientId);
    			if(priorityCount==contentList.size()){
    				isfirstRequest=true;
    			}
    			
    			Map<String, Object> bannerMap;
    			List<Object> bannerheadlist = new ArrayList<Object>();
    			int leftCount=0;
    			int rightCount=0;
    			if(contentList.size()>0 && contentListbanner.size()>0 && contentList.size()==contentListbanner.size()){
	    			for (int i=0;i<contentList.size();i++) {
	    				Object[] objects=contentList.get(i);
	    				bannerMap = new HashMap<String, Object>();
	    				bannerMap.put("location",objects[0]);
	    				bannerMap.put("priority",objects[1]);
	    				bannerMap.put("clientContectId",objects[2]);
	    				bannerMap.put("contentManagemenId",objects[3]);
	    				bannerMap.put("isactive",objects[4]);
	    				if((Integer)objects[0]== 3){
	    					leftCount++;
	    				}
	    				if((Integer)objects[0]==4){
	    					rightCount++;
	    				}
	    				objects=contentListbanner.get(i);
	    				    				
	    				bannerMap.put("description",objects[0]);
	    				bannerMap.put("bannerpath",objects[1]);
	    				
	    				bannerheadlist.add(bannerMap);
	    			
	    			}
    			}	
    			modelMap.addAttribute("bannerList", bannerheadlist);
    			modelMap.addAttribute("leftcount", leftCount);
    			modelMap.addAttribute("rightcount", rightCount);
    			modelMap.addAttribute("isfirstrequest", isfirstRequest);
    			//prepare the drop down for the select
    			List<SelectItem> leftPrioritySelect = new ArrayList<SelectItem>();
    			List<SelectItem> rightPriorityList = new ArrayList<SelectItem>();
    			for(int i=1;i<=leftCount;i++){
    				leftPrioritySelect.add(new SelectItem(i,i));
    			}
    			modelMap.addAttribute("leftPrioritySelect", leftPrioritySelect);
    			for(int i=1;i<=rightCount;i++){
    				rightPriorityList.add(new SelectItem(i,i));
    			}
    			modelMap.addAttribute("rightPrioritySelect", rightPriorityList);
    		} catch (Exception e) {
    			retVal = exceptionHandlerService.writeLog(e);
    		}
    		finally{
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageBannerManageBanner, getManagebannerPage, clientId,0);
    		}
    		return retVal;
    	}
    
    	/**remove the client banner.
    	 * @author mitesh.patel
    	 * @param modelMap
    	 * @param response
    	 * @param request
    	 * @return
    	 */
    	@RequestMapping(value = "/admin/removebanner/{clientContectId}/{enc}", method = RequestMethod.GET)                       
    	public String removeclientBanner(RedirectAttributes redirectAttributes, HttpServletRequest request,@PathVariable("clientContectId") int clientContectId){
    		boolean success=false;
    		try{
    			success = manageContentService.deActiveClientBanner(clientContectId);
    		}
    		catch(Exception ex){
    			return exceptionHandlerService.writeLog(ex);
    		}
    		finally {
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageBannerRemoveBanner,getDeactivemanagerbannerPage, abcUtility.getSessionClientId(request),clientContectId);
    		}
    		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_remove_client_banner" : CommonKeywords.ERROR_MSG_KEY.toString());
    		return "redirect:/common/admin/managebanner"+ encryptDecryptUtils.generateRedirect("common/admin/managebanner", request);
    	}
    	 /**
         * update the banner priority post request
         * 
         * @author Mitesh Patel
         * @param request
         * @param response
         * @param modelMap
         * @param redirectAttributes
         * @return
         */
        @RequestMapping(value="admin/updatebannerpriority", method = RequestMethod.POST)
        public String updateClientBannerPriority(HttpServletRequest request,RedirectAttributes redirectAttributes){
        	String retVal="";
        	int userId = 0;
        	int clientId = 0;
        	int gradeId = 0;
        	boolean success = false;
        	try {
				clientId = abcUtility.getSessionClientId(request);
				//get the left side param value
				String clientContentId[] =request.getParameterValues("clientContentIdl");
				String priority[] =request.getParameterValues("selPriorityl");
				String contentManagemenId[] =request.getParameterValues("contentManagemenIdl");
				String isactive[] =request.getParameterValues("isactivel");
				//generate left side pojo
				TblClientContentMapping clienttMapObj;
				List<TblClientContentMapping> contMangList=new ArrayList<TblClientContentMapping>();
				if(clientContentId!=null){
					for(int i=0;i<clientContentId.length;i++){
						clienttMapObj=new TblClientContentMapping();
						clienttMapObj.setClientContentId(Integer.parseInt(clientContentId[i]));
						/*TblClient tblclient=new TblClient();
						tblclient.setClientId(clientId);
						clienttMapObj.setTblClient(tblclient);*/
						clienttMapObj.setTblClient(new TblClient(clientId));
						TblContentManagement contentManagement=new TblContentManagement();
						contentManagement.setContentManagemenId(Integer.parseInt(contentManagemenId[i]));
						clienttMapObj.setTblContentManagement(contentManagement);
						clienttMapObj.setPriority(Integer.parseInt(priority[i]));
						clienttMapObj.setIsActive(Integer.parseInt(isactive[i]));
						
						contMangList.add(clienttMapObj);
					}
				}
				//get the right side pojo
				clientContentId=request.getParameterValues("clientContentIdr");
				priority=request.getParameterValues("selPriorityr");
				contentManagemenId=request.getParameterValues("contentManagemenIdr");
				isactive=request.getParameterValues("isactiver");
				
				if(clientContentId!=null){
					for(int i=0;i<clientContentId.length;i++){
						clienttMapObj=new TblClientContentMapping();
						clienttMapObj.setClientContentId(Integer.parseInt(clientContentId[i]));
						/*TblClient tblclient=new TblClient();
						tblclient.setClientId(clientId);
						clienttMapObj.setTblClient(tblclient);*/
						clienttMapObj.setTblClient(new TblClient(clientId));
						TblContentManagement contentManagement=new TblContentManagement();
						contentManagement.setContentManagemenId(Integer.parseInt(contentManagemenId[i]));
						clienttMapObj.setTblContentManagement(contentManagement);
						clienttMapObj.setPriority(Integer.parseInt(priority[i]));
						clienttMapObj.setIsActive(Integer.parseInt(isactive[i]));
						
						contMangList.add(clienttMapObj);
					}
				}
				//service call for the update
				if(contMangList!=null && contMangList.size()>0)
				{
					success = manageContentService.updateBannerPriority(contMangList);
				}
			
				if(success){
					retVal="redirect:/common/admin/managebanner"+encryptDecryptUtils.generateRedirect("common/admin/managebanner", request);
				}
		
				redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(),success ?  "redirect_success_bannerupdate_successfully" : CommonKeywords.ERROR_MSG.toString());
				
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
        	finally{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageBannerManageBanner, postManagebanner, gradeId,clientId);
        	}
        	return retVal;
        }
        
        /**remove the master banner.
    	 * @author bharatkumar
    	 * @param modelMap
    	 * @param response
    	 * @param request
    	 * @return
    	 */
    	@RequestMapping(value = "/admin/removeBannerMaster/{clientContectId}/{officerDocMappingId}/{enc}", method = RequestMethod.GET)                       
    	public String removeMasterBanner(RedirectAttributes redirectAttributes, HttpServletRequest request,@PathVariable("clientContectId") int clientContectId,@PathVariable("officerDocMappingId") int officerDocMappingId){
    		boolean success=false;
    		try{
    		  //	success = manageContentService.removeMasterBanner(clientContectId,officerDocMappingId,abcUtility.getSessionClientId(request),docUploadPath);
    		}
    		catch(Exception ex){
    			return exceptionHandlerService.writeLog(ex);
    		}
    		finally {
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageBannerRemoveBanner,getDeactivemanagerbannerPage, 0,clientContectId);
    		}
    		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_remove_client_banner" : CommonKeywords.ERROR_MSG_KEY.toString());
    		return "redirect:/common/admin/managebanner"+ encryptDecryptUtils.generateRedirect("common/admin/managebanner", request);
    	}
    	
    	/**
    	 * To Show Create Link
    	 * 
    	 * @author dipika
    	 * @param request
    	 * @param modelMap
    	 * @return
    	 */
    	  @RequestMapping(value = "/admin/createLink/{enc}", method = RequestMethod.GET)
          public String createLink(HttpServletRequest request,ModelMap map) {
              String retVal = "common/admin/CreateLink";
              try {
            	int manageDownloadEventid = 142; 
            	setLinkDetails(request,map,manageDownloadEventid);
             	map.addAttribute("mode", "create"); 	
             	map.addAttribute(CONTENTYPE,1);
              } catch (Exception ex) {
                  return exceptionHandlerService.writeLog(ex);
              } finally {
                  auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageDownloadCreate, createBanner, 0, 0);
              }
              return retVal;
          }
    	  
    	  /**
      	 * To Show Edit Link
      	 * 
      	 * @author dipika
      	 * @param request
      	 * @param modelMap
      	 * @return
      	 */
      	@RequestMapping(value = "/admin/editLink/{documentLinkId}/{enc}", method = RequestMethod.GET)
        public String editLink(HttpServletRequest request,ModelMap map,@PathVariable("documentLinkId") int documentLinkId) {
            String retVal = "common/admin/CreateLink";
            try {
		          	int manageDownloadEventid = 142; 
		          	setLinkDetails(request,map,manageDownloadEventid);		          	
		          	
		          	if(documentLinkId!=0){
		          		
		          	 	map.addAttribute("mode", "edit");	
		          	 	map.addAttribute(CONTENTYPE,1);
		          	 	
		          		map.addAttribute("documentLinkId",documentLinkId);        
		          		TblDocumentLink tblDocumentLink=  manageContentService.getTbldocumentlink(documentLinkId);
		          		
		          		map.addAttribute("tblDocumentLink",tblDocumentLink);	          		

		          		
		          		if(tblDocumentLink.getLinkType()==1)
		          		{
		          			Object[] object=manageContentService.getOfficerDocument(documentLinkId,manageDownloadDocumentUpload).get(0);
		          			map.addAttribute("tblOfficerDocs",object);
		          			map.addAttribute("linkId",manageDownloadDocumentUpload);
		          			map.addAttribute("objectId",documentLinkId);		          		
		          			map.addAttribute("cStatusDoc",0);
		          			map.addAttribute("cStatusDocView",1);
		          			map.addAttribute("txtHidDocIds",object[2]);
		          		}
		          		
		          		if (((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserTypeId() == 1) {
	        				map.addAttribute("isAdmin","yes");

	        				List<Object[]> selectedDomain=manageContentService.getSelectedClientsForLinks(documentLinkId);
	        				int cnt=0;
	        				int clientId=0;
	        				for (Object[] objects : selectedDomain) {
	        					if(objects[2]!=null){
	        						
	        						if(objects[2]!=null){
	        						
		        						clientId = (Integer)objects[0];
		        						cnt++;
	        						}
	        						
	        					}
	        				}	
	        				boolean setList = false;
	        				if(cnt==1){
	        				
	        					ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	        					if(clientId!=0){
	        						map.addAttribute("currdomain", 1);	   				
	        					}else{
	        						setList = true;		        					
	        					}
	        				}
	        				else{
	        					setList = true;	
	        				}   		
	        				if(setList){
	        					map.addAttribute("currdomain", 2);
	        					List<SelectItem> showCheckedList= new ArrayList<SelectItem>();
	        					showCheckedList=abcUtility.convertSelected(selectedDomain);
	        					map.addAttribute("showCheckedDomains", showCheckedList);
	        				}
	        			}
		          		map.addAttribute("currentDisplayTo", tblDocumentLink.getDisplayTo() != 0 ? tblDocumentLink.getDisplayTo() : 4);
		          	}          	
            } catch (Exception ex) {
                return exceptionHandlerService.writeLog(ex);
            } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageDownloadEdit, createBanner, 0, 0);
            }
            return retVal;
        }
    	  
      	/**
      	 * To Show details for Link form
      	 * 
      	 * @author dipika
      	 * @param request
      	 * @param modelMap
      	 * @return
      	 */
    	public void setLinkDetails(HttpServletRequest request, ModelMap map,int eventId) {
  	    	
    		try{
			  	  	List<SelectItem> lstTypeOfLink = new ArrayList<SelectItem>();
			    	lstTypeOfLink.add(new SelectItem("Provide Link", 2));
			    	lstTypeOfLink.add(new SelectItem("Upload Document", 1));
			    	map.addAttribute("lstTypeOfLink", lstTypeOfLink);
			    	map.addAttribute("chTypeOfLink", 1);
			    	
			    	List<SelectItem> lstShowDoc = new ArrayList<SelectItem>();
			    	lstShowDoc.add(new SelectItem("Before Login", 1));
			    	lstShowDoc.add(new SelectItem("After Login", 2));			    	
			    	lstShowDoc.add(new SelectItem("Both", 3));
			    	map.addAttribute("lstShowDoc", lstShowDoc);
			    	map.addAttribute("chShowDoc", 2);
			    	
				   	map.addAttribute("clientId", abcUtility.getSessionClientId(request));	
				   	
				   	if (((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserTypeId() == 1) {
			
						map.addAttribute("isAdmin","yes");
					}
				   	
					List<SelectItem> showForRadioList= new ArrayList<SelectItem>();
					showForRadioList.add(new SelectItem("Current Domain",1));
					showForRadioList.add(new SelectItem("Selected Domain",2));
					map.addAttribute("showForRadioList", showForRadioList);
					
					List<SelectItem> displayToRadioList= new ArrayList<SelectItem>();
					displayToRadioList.add(new SelectItem("Bidder",2));
					displayToRadioList.add(new SelectItem("Officer",3));
					displayToRadioList.add(new SelectItem("Both",4));
					map.addAttribute("displayToRadioList", displayToRadioList);
					
					List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, abcUtility.getSessionClientId(request)); 
					int allowedSize = 0;
					StringBuilder allowedExt = new StringBuilder();
					if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
						allowedSize = lstDocUploadConf.get(0).getMaxSize();
						allowedExt.append(lstDocUploadConf.get(0).getType());
						map.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
					}
					int index = allowedExt.toString().indexOf(",");
					allowedExt.insert(index + 1, "*.");
					while (index >= 0) {
						index = allowedExt.toString().indexOf(",", index + ",".length());
						allowedExt.insert(index + 1, "*.");
					}
					map.addAttribute("allowedExt", allowedExt);
					map.addAttribute("allowedSize", allowedSize / 1024);
					map.addAttribute("objectId",manageContentService.getOfficerDocMappingId()[0]);
					//map.addAttribute("eventId", 142); 
					map.addAttribute("linkId", manageDownloadDocumentUpload); // / need to change Link id
					map.addAttribute("cStatusDoc", 0);
    		 } catch (Exception ex) {
                 exceptionHandlerService.writeLog(ex);
             } finally {
                 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageDownloadCreate, createBanner, 0, 0);
             }
  	    	
    }
    	  /**
	     * By dipika
	     * to submitLink/document
	     */    		 
	    @RequestMapping(value = "/admin/submitLink", method = RequestMethod.POST)
	    public String submitLink(HttpServletRequest request, RedirectAttributes rd,ModelMap map) {
	    	String retVal = null;
	    	boolean isSuccess=false;
	    	String frm=null;
	        try {
	        	String selLinkType = request.getParameter("selLinkType");
	        	String txtLinkName = request.getParameter("txtLinkName");     	         	
	        	String selShowDocs = request.getParameter("selShowDocs");    	       
	        	String rdShowFor =String.valueOf(request.getParameter("rdShowFor") != null ?Integer.parseInt(request.getParameter("rdShowFor")) : "0"); 
	        	int objectId=Integer.parseInt( request.getParameter("txtObjectId"));
	        	int documentLinkId=0;
	        	int rddisplayTo=(request.getParameter("rddisplayTo") != null ? Integer.parseInt(request.getParameter("rddisplayTo")) : 0);
	        	
	        	String txtHidDocIds="0";
	        	String[] chkMultipleDomain=null;
	        	int length=1;
	        	
	        	if(rdShowFor.equals("2")){
    	        	if(request.getParameterValues("chkMultipleDomain")!=null)
    	        	{
    	        		chkMultipleDomain = request.getParameterValues("chkMultipleDomain");
    	        		length=chkMultipleDomain.length;
    	        	}
	        	}
	        	TblDocumentLink tblDocumentLink=null;
	        	if(request.getParameter("hdDocumentLinkId")!=null){
	        		documentLinkId=Integer.parseInt(request.getParameter("hdDocumentLinkId"));
	        		tblDocumentLink=manageContentService.getTbldocumentlink(documentLinkId);	        			        		
	        		frm="edit";
	        	}else{
	        		tblDocumentLink=new TblDocumentLink();
	        		frm="create";
	        	}
	        	
	        	tblDocumentLink.setLinkName(txtLinkName);
	        	tblDocumentLink.setIsActive(1);
	        	tblDocumentLink.setLinkType(Integer.parseInt(selLinkType));
	        	
	        	if(selLinkType.equals("2"))
	        	{
	        		String txtLinkUrl = request.getParameter("txtLinkUrl");
	        		tblDocumentLink.setLinkUrl(txtLinkUrl);
	        	}
	        	else{
	        		tblDocumentLink.setLinkUrl("");
	        		txtHidDocIds = request.getParameter("txtHidDocIds");
	        	}
	        	tblDocumentLink.setDisplayLocation(Integer.parseInt(selShowDocs));
	        	tblDocumentLink.setCreatedBy(abcUtility.getSessionUserId(request));
	        	if(Integer.parseInt(selShowDocs)==2){//After login
	        		tblDocumentLink.setDisplayTo(rddisplayTo);
	        	}else if(Integer.parseInt(selShowDocs)==1){//Before login
	        		tblDocumentLink.setDisplayTo(0);
	        	}else{
	        		tblDocumentLink.setDisplayTo(4);// Both - 4
	        	}
	        	if(manageContentService.addTblDocumentLink(tblDocumentLink))
	        	{
	        		documentLinkId=tblDocumentLink.getDocumentLinkId();
	        		
	        		if(selLinkType.equals("2") && request.getParameter("txtHidDocIds")!=null && !request.getParameter("txtHidDocIds").equals("0")){

		        		Object[] object=manageContentService.getOfficerDocument(documentLinkId,manageDownloadDocumentUpload).get(0);
		        		txtHidDocIds=object[2].toString();
	        		}
	        		
	        		Integer[] builder=new Integer[length];
	        		 
	        		int i=0;
	        		if(rdShowFor.equals("2") && chkMultipleDomain!=null && chkMultipleDomain.length!=0){
		        		for(String domain:chkMultipleDomain)
		        		{		        			
		        			builder[i++]=Integer.parseInt(domain);		        			
		        		}
	        		}
	        		else{
	        			builder[i]=abcUtility.getSessionClientId(request);
	        		}
	        		List<Object[]> lstTblClientDocLink=null;
	        			        			
	        		lstTblClientDocLink=manageContentService.getTblClientDocLink(documentLinkId,builder," not ");    	        
	        	
	        		if(lstTblClientDocLink.size()!=0){
	        			i=0;
	        			Integer[] lstClientDocLinkId=new Integer[lstTblClientDocLink.size()];
		        		for(Object[] tblClientDocLink:lstTblClientDocLink){
		        					
		        			lstClientDocLinkId[i++]=(Integer)tblClientDocLink[1];
		        		}
		        		manageContentService.cancelTblClientDocLink(lstClientDocLinkId);
	        		}	    			
	        		
	        		lstTblClientDocLink=manageContentService.getTblClientDocLink(documentLinkId,builder," ");
	        		
	        		List<Integer> availDomain=new ArrayList<Integer>();
	        		
	        		if(lstTblClientDocLink.size()!=0){
		        		for(Object[] tblClientDocLink:lstTblClientDocLink){
		        			
		        			availDomain.add((Integer)tblClientDocLink[0]);
		        		}
	        		}
	        		
        			if(rdShowFor.equals("2") && chkMultipleDomain!=null && chkMultipleDomain.length!=0){
		        		for(String domain:chkMultipleDomain){
		        			
		        			if(!availDomain.contains(Integer.parseInt(domain))){
		        				
		        				TblClientDocLink tblClientDocLink=new TblClientDocLink();
		        				tblClientDocLink.setTblDocumentLink(tblDocumentLink);
		        				tblClientDocLink.setTblClient(new TblClient(Integer.parseInt(domain)));
		        				
		        				manageContentService.addTblClientDocLink(tblClientDocLink);
		        			}      			
		        		}
	        		}
	        		else{
	        			
	        			if(!availDomain.contains(abcUtility.getSessionClientId(request))){
	        				TblClientDocLink tblClientDocLink=new TblClientDocLink();
	        				tblClientDocLink.setTblDocumentLink(tblDocumentLink);
	        				tblClientDocLink.setTblClient(clientService.getClientById(abcUtility.getSessionClientId(request)));
	        				
	        				manageContentService.addTblClientDocLink(tblClientDocLink);
	        			}
	        		}
	        		
	        		if(selLinkType.equals("2") && !txtHidDocIds.equals("0")){
	        			fileUploadService.updateOfficerDocsObjectId(txtHidDocIds, tblDocumentLink.getDocumentLinkId(), 0);		
	        		}
	        		else if(!txtHidDocIds.equals("0")){
	        			fileUploadService.updateOfficerDocsObjectId(txtHidDocIds, tblDocumentLink.getDocumentLinkId(), 1);
	        		}
	        	    else{
	        			fileUploadService.getOfficerDocDetailsForRemove(objectId,manageDownloadDocumentUpload);  // Need to change linkid
	        		}	        		
	        	
	        		isSuccess=true;
	        		
	        	} else{
					rd.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
				}
	      
	        	if(isSuccess){
	        		retVal  ="redirect:/common/admin/managedownloadlink"+encryptDecryptUtils.generateRedirect("common/admin/managedownloadlink", request);
	        		if(frm.equals("create")){
	        			rd.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_success_create_Link");
	        		}
	        		else{
	        			rd.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_success_update_Link");
	        		}
	        	}else{
	        		retVal  ="redirect:/common/admin/createLink"+encryptDecryptUtils.generateRedirect("common/admin/createLink", request);
	        	}
	        	
	        } catch (Exception ex) {
	            return exceptionHandlerService.writeLog(ex);
	        } finally {
	            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageDownloadCreate, saveBanner, 0, 0);
	        }
	        return retVal;
	    }
	    /**
	     * By dipika
	     */    	
	    @RequestMapping(value = "/admin/managedownloadlink/{enc}", method = RequestMethod.GET)
	    public String manageDownloadLink(ModelMap modelMap, HttpServletRequest req) {
	    	 int manageDownloadReportId = 79;  // need to change
	        try {
	           
	            modelMap.addAttribute("reportId", manageDownloadReportId);
	            reportGeneratorService.getReportConfigDetails(manageDownloadReportId, modelMap);
	           
	        } catch (Exception ex) {
	            exceptionHandlerService.writeLog(ex);
	        } finally {
	            auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageDownloadView, null, 0, 0);
	        }
	        return "common/admin/ManageDownloadLink";
	    }
	    
	    /**
	     * By dipika
	     */  
	    @RequestMapping(value = "/admin/deleteLink/{documentLinkId}/{enc}", method = RequestMethod.GET)
	    public String removeDownloadLink(ModelMap modelMap, HttpServletRequest request,@PathVariable("documentLinkId") int documentLinkId,RedirectAttributes rd) {
	    
	    	String retVal="";
	        try {
	        	TblDocumentLink tblDocumentLink=null;
	        	if(documentLinkId!=0){
	        		manageContentService.cancelTblDocumentLink(documentLinkId);
	        		
	        		rd.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_success_delete_Link");
	        		
	        	} else{
					rd.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
				}
	      
	        	retVal  ="redirect:/common/admin/managedownloadlink"+encryptDecryptUtils.generateRedirect("common/admin/managedownloadlink", request);
	        	
	        	
	        } catch (Exception ex) {
	            exceptionHandlerService.writeLog(ex);
	        } finally {
	            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageDownloadDocumentDelete, null, 0, 0);
	        }
	        return retVal;
	    }
	    /**
		 * To manage client Reg terms and condition
		 * @author jaynam 
		 * @param modelMap
		 * @param request
		 */
		@RequestMapping(value = "/admin/manageclientregterms/{enc}", method = RequestMethod.GET)                       
		public String manageClientRegTerms(ModelMap modelMap, HttpServletRequest request){
			try{
				modelMap.addAttribute("reportId", 86);
				reportGeneratorService.getReportConfigDetails(86, modelMap);
			}
			catch(Exception ex){
				return exceptionHandlerService.writeLog(ex);
			}
			finally {
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),manageClientTermsConditionLinkId, getManageClientTermsCondition,0,0);
			}
			return "common/admin/ManageClientRegTerms";
		}
		
		/**
		 * To edit client Registrations  terms and condition
		 * @author jaynam
		 * @param modelMap
		 * @param request
		 */
		@RequestMapping(value = "/admin/editclientregterms/{clientId}/{clientRegTermId}/{languageId}/{mode}/{enc}", method = RequestMethod.GET)                       
		public String editClientRegTerms(@PathVariable("clientId") int clientId,@PathVariable("clientRegTermId") int clientRegTermId,@PathVariable("languageId") int languageId,@PathVariable("mode") int mode,ModelMap modelMap,HttpServletRequest request){
			String retVal=null;
			try{
				if(clientRegTermId!=0){
					List<Object[]> clientRegTermDataList= manageContentService.getClientRegTermDataByClientRegTermId(clientRegTermId);
					if(clientRegTermDataList!=null && !clientRegTermDataList.isEmpty()){
						modelMap.addAttribute("clientRegTermData",clientRegTermDataList.get(0));
					}
				}
				modelMap.put("languageId", languageId);
    			modelMap.put("languageName", clientService.getLanguageById(languageId).getLanguage());
    			modelMap.put("clientId", clientId);
				modelMap.put("displayMode", mode);
				modelMap.put("clientRegTermId", clientRegTermId);
				retVal="common/admin/UpdateClientRegTerms";
			}
			catch(Exception ex){
				retVal= exceptionHandlerService.writeLog(ex);
			}
			finally {
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),viewBidderTermsLinkId, getViewBidderTermsCondition,0,clientRegTermId);
			}
			return retVal;
		}
		

	    /**
	     * Search and listing Mobile No
	     *
	     * @param enc
	     * @return to view
	     */
	    @RequestMapping(value = "/admin/searchlistmobile/{enc}", method = RequestMethod.GET)
	    public String searchListMobile(ModelMap modelMap, HttpServletRequest request, HttpSession session) {
	    	String retVal="/common/admin/ManageMobileList";
			try {
				modelMap.addAttribute("reportId",mobileListingReportId);
				reportGeneratorService.getReportConfigDetails(mobileListingReportId, modelMap);
			} catch (Exception e) {
				retVal = exceptionHandlerService.writeLog(e);
			}
			finally{
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, "Manage to do list", 0,0);
			}
	        return retVal;
	    }
	    
}