package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblUserRoleDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblUserRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserRoleImpl extends AbcAbstractClass<TblUserRole> implements TblUserRoleDao {

    @Override
    public void addTblUserRole(TblUserRole tblUserRole){
        super.addEntity(tblUserRole);
    }

    @Override
    public void deleteTblUserRole(TblUserRole tblUserRole) {
        super.deleteEntity(tblUserRole);
    }

    @Override
    public void updateTblUserRole(TblUserRole tblUserRole) {
        super.updateEntity(tblUserRole);
    }

    @Override
    public List<TblUserRole> getAllTblUserRole() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserRole> findTblUserRole(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserRoleCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserRole> findByCountTblUserRole(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserRole(List<TblUserRole> tblUserRoles){
        super.updateAll(tblUserRoles);
    }
}
