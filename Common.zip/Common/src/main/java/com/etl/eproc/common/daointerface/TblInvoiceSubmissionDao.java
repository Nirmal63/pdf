package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblInvoiceSubmission;
import java.util.List;

public interface TblInvoiceSubmissionDao  {

    public void addTblInvoiceSubmission(TblInvoiceSubmission tblInvoiceSubmission);

    public void deleteTblInvoiceSubmission(TblInvoiceSubmission tblInvoiceSubmission);

    public void updateTblInvoiceSubmission(TblInvoiceSubmission tblInvoiceSubmission);

    public List<TblInvoiceSubmission> getAllTblInvoiceSubmission();

    public List<TblInvoiceSubmission> findTblInvoiceSubmission(Object... values) throws Exception;

    public List<TblInvoiceSubmission> findByCountTblInvoiceSubmission(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblInvoiceSubmissionCount();

    public void saveUpdateAllTblInvoiceSubmission(List<TblInvoiceSubmission> tblInvoiceSubmissions);

	public void saveOrUpdateTblInvoiceSubmission(TblInvoiceSubmission tblInvoiceSubmission);
}