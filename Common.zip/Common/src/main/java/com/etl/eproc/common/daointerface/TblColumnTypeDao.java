package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblColumnType;
import java.util.List;

public interface TblColumnTypeDao  {

    public void addTblColumnType(TblColumnType tblColumnType);

    public void deleteTblColumnType(TblColumnType tblColumnType);

    public void updateTblColumnType(TblColumnType tblColumnType);

    public List<TblColumnType> getAllTblColumnType();

    public List<TblColumnType> findTblColumnType(Object... values) throws Exception;

    public List<TblColumnType> findByCountTblColumnType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblColumnTypeCount();

    public void saveUpdateAllTblColumnType(List<TblColumnType> tblColumnTypes);
}