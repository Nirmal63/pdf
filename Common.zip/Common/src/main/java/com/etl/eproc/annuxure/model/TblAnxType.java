package com.etl.eproc.annuxure.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.core.style.ToStringCreator;

@Entity
@Table(name = "tbl_AnnexureType", schema = "appcommon")
public class TblAnxType {

	private int annexureTypeId;
	private TblAnnexure annexure;
	private TblClmAnnexureType typeOfAnnexure;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getAnnexureTypeId() {
		return this.annexureTypeId;
	}

	public void setAnnexureTypeId(int annexureTypeId) {
		this.annexureTypeId = annexureTypeId;
	}

	@ManyToOne
	@JoinColumn(name = "typeOfAnnexure")
	public TblClmAnnexureType getTypeOfAnnexure() {
		return typeOfAnnexure;
	}

	@ManyToOne
	@JoinColumn(name = "annexureId")
	public TblAnnexure getAnnexure() {
		return this.annexure;
	}

	public void setTypeOfAnnexure(TblClmAnnexureType typeOfAnnexure) {
		this.typeOfAnnexure = typeOfAnnexure;
	}

	public void setAnnexure(TblAnnexure annexure) {
		this.annexure = annexure;
	}

	@Override
	public String toString() {
		return new ToStringCreator(this)
				.append("annexureTypeId", this.getAnnexureTypeId()).toString();

	}
}
