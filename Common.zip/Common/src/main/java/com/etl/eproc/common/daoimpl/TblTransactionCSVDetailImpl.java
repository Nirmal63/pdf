package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblTransactionCSVDetail;
import com.etl.eproc.common.daointerface.TblTransactionCSVDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblTransactionCSVDetailImpl extends AbcAbstractClass<TblTransactionCSVDetail> implements TblTransactionCSVDetailDao {

    @Override
    public void addTblTransactionCSVDetail(TblTransactionCSVDetail tblTransactionCSVDetail){
        super.addEntity(tblTransactionCSVDetail);
    }

    @Override
    public void deleteTblTransactionCSVDetail(TblTransactionCSVDetail tblTransactionCSVDetail) {
        super.deleteEntity(tblTransactionCSVDetail);
    }

    @Override
    public void updateTblTransactionCSVDetail(TblTransactionCSVDetail tblTransactionCSVDetail) {
        super.updateEntity(tblTransactionCSVDetail);
    }

    @Override
    public List<TblTransactionCSVDetail> getAllTblTransactionCSVDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTransactionCSVDetail> findTblTransactionCSVDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTransactionCSVDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTransactionCSVDetail> findByCountTblTransactionCSVDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTransactionCSVDetail(List<TblTransactionCSVDetail> tblTransactionCSVDetails){
        super.updateAll(tblTransactionCSVDetails);
    }
}
