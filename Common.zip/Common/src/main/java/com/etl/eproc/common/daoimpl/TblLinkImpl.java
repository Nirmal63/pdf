package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblLinkDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblLink;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblLinkImpl extends AbcAbstractClass<TblLink> implements TblLinkDao {

    @Override
    public void addTblLink(TblLink tblLink){
        super.addEntity(tblLink);
    }

    @Override
    public void deleteTblLink(TblLink tblLink) {
        super.deleteEntity(tblLink);
    }

    @Override
    public void updateTblLink(TblLink tblLink) {
        super.updateEntity(tblLink);
    }

    @Override
    public List<TblLink> getAllTblLink() {
        return super.getAllEntity();
    }

    @Override
    public List<TblLink> findTblLink(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblLinkCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblLink> findByCountTblLink(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblLink(List<TblLink> tblLinks){
        super.updateAll(tblLinks);
    }
}
