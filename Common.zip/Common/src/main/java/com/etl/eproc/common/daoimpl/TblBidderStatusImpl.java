package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblBidderStatusDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblBidderStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBidderStatusImpl extends AbcAbstractClass<TblBidderStatus> implements TblBidderStatusDao {

    @Override
    public void addTblBidderStatus(TblBidderStatus tblBidderStatus){
        super.addEntity(tblBidderStatus);
    }

    @Override
    public void deleteTblBidderStatus(TblBidderStatus tblBidderStatus) {
        super.deleteEntity(tblBidderStatus);
    }

    @Override
    public void updateTblBidderStatus(TblBidderStatus tblBidderStatus) {
        super.updateEntity(tblBidderStatus);
    }

    @Override
    public List<TblBidderStatus> getAllTblBidderStatus() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBidderStatus> findTblBidderStatus(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBidderStatusCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBidderStatus> findByCountTblBidderStatus(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBidderStatus(List<TblBidderStatus> tblBidderStatuss){
        super.updateAll(tblBidderStatuss);
    }

	@Override
	public void saveOrUpdateTblBidderStatus(TblBidderStatus bidderStatus) {
		super.saveOrUpdateEntity(bidderStatus);
		
	}
}
