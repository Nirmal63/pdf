package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblOfflinePayment;
import com.etl.eproc.common.daointerface.TblOfflinePaymentDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblOfflinePaymentImpl extends AbcAbstractClass<TblOfflinePayment> implements TblOfflinePaymentDao {

    @Override
    public void addTblOfflinePayment(TblOfflinePayment tblOfflinePayment){
        super.addEntity(tblOfflinePayment);
    }

    @Override
    public void deleteTblOfflinePayment(TblOfflinePayment tblOfflinePayment) {
        super.deleteEntity(tblOfflinePayment);
    }

    @Override
    public void updateTblOfflinePayment(TblOfflinePayment tblOfflinePayment) {
        super.updateEntity(tblOfflinePayment);
    }

    @Override
    public List<TblOfflinePayment> getAllTblOfflinePayment() {
        return super.getAllEntity();
    }

    @Override
    public List<TblOfflinePayment> findTblOfflinePayment(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblOfflinePaymentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblOfflinePayment> findByCountTblOfflinePayment(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblOfflinePayment(List<TblOfflinePayment> tblOfflinePayments){
        super.updateAll(tblOfflinePayments);
    }

	@Override
	public void saveOrUpdateTblOfflinePayment(TblOfflinePayment tblOfflinePayment) {
		super.saveOrUpdateEntity(tblOfflinePayment);
	}
}
