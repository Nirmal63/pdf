package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblAdditionalEmailConf;

public interface TblAdditionalEmailConfDao {

    public void addTblAdditionalEmailConf(TblAdditionalEmailConf tblAdditionalEmailConf);

    public void deleteTblAdditionalEmailConf(TblAdditionalEmailConf tblAdditionalEmailConf);

    public void updateTblAdditionalEmailConf(TblAdditionalEmailConf tblAdditionalEmailConf);

    public List<TblAdditionalEmailConf> getAllTblAdditionalEmailConf();

    public List<TblAdditionalEmailConf> findTblAdditionalEmailConf(Object... values) throws Exception;

    public List<TblAdditionalEmailConf> findByCountTblAdditionalEmailConf(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAdditionalEmailConfCount();

    public void saveUpdateAllTblAdditionalEmailConf(List<TblAdditionalEmailConf> tblAdditionalEmailConfs);
}