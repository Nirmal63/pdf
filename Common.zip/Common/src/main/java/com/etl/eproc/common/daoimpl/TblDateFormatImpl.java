package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblDateFormatDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblDateFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDateFormatImpl extends AbcAbstractClass<TblDateFormat> implements TblDateFormatDao {

    @Override
    public void addTblDateFormat(TblDateFormat tblDateFormat){
        super.addEntity(tblDateFormat);
    }

    @Override
    public void deleteTblDateFormat(TblDateFormat tblDateFormat) {
        super.deleteEntity(tblDateFormat);
    }

    @Override
    public void updateTblDateFormat(TblDateFormat tblDateFormat) {
        super.updateEntity(tblDateFormat);
    }

    @Override
    public List<TblDateFormat> getAllTblDateFormat() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDateFormat> findTblDateFormat(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDateFormatCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDateFormat> findByCountTblDateFormat(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDateFormat(List<TblDateFormat> tblDateFormats){
        super.updateAll(tblDateFormats);
    }
}
