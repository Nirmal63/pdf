package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.eindent.model.TblClientBoqColumn;
import java.util.List;

public interface TblClientBoqColumnDao  {

    public void addTblClientBoqColumn(TblClientBoqColumn tblClientBoqColumn);

    public void deleteTblClientBoqColumn(TblClientBoqColumn tblClientBoqColumn);

    public void updateTblClientBoqColumn(TblClientBoqColumn tblClientBoqColumn);

    public List<TblClientBoqColumn> getAllTblClientBoqColumn();

    public List<TblClientBoqColumn> findTblClientBoqColumn(Object... values) throws Exception;

    public List<TblClientBoqColumn> findByCountTblClientBoqColumn(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientBoqColumnCount();

    public void saveUpdateAllTblClientBoqColumn(List<TblClientBoqColumn> tblClientBoqColumns);
}