package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblMetaTagDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblMetaTag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMetaTagImpl extends AbcAbstractClass<TblMetaTag> implements TblMetaTagDao {

    @Override
    public void addTblMetaTag(TblMetaTag tblMetaTag){
        super.addEntity(tblMetaTag);
    }

    @Override
    public void deleteTblMetaTag(TblMetaTag tblMetaTag) {
        super.deleteEntity(tblMetaTag);
    }

    @Override
    public void updateTblMetaTag(TblMetaTag tblMetaTag) {
        super.updateEntity(tblMetaTag);
    }

    @Override
    public List<TblMetaTag> getAllTblMetaTag() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMetaTag> findTblMetaTag(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMetaTagCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMetaTag> findByCountTblMetaTag(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMetaTag(List<TblMetaTag> tblMetaTags){
        super.updateAll(tblMetaTags);
    }
}
