/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;
import com.etl.eproc.common.model.TblLOIDetail;
import com.etl.eproc.common.daointerface.TblLOIDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;
/**
 *
 * @author urja
 */


@Repository @Transactional    /*StackUpdate*/
public class TblLOIDetailImpl extends AbcAbstractClass<TblLOIDetail> implements TblLOIDetailDao {

    @Override
    public void addTblLOIDetail(TblLOIDetail tblLOIDetail){
        super.addEntity(tblLOIDetail);
    }

    @Override
    public void deleteTblLOIDetail(TblLOIDetail tblLOIDetail) {
        super.deleteEntity(tblLOIDetail);
    }

    @Override
    public void updateTblLOIDetail(TblLOIDetail tblLOIDetail) {
        super.updateEntity(tblLOIDetail);
    }

    @Override
    public List<TblLOIDetail> getAllTblLOIDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblLOIDetail> findTblLOIDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblLOIDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblLOIDetail> findByCountTblLOIDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblLOIDetail(List<TblLOIDetail> tblLOIDetails){
        super.updateAll(tblLOIDetails);
    }
}
