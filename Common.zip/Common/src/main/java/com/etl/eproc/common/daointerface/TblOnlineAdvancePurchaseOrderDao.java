package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblOnlineAdvancePurchaseOrder;
import java.util.List;

public interface TblOnlineAdvancePurchaseOrderDao  {

    public void addTblOnlineAdvancePurchaseOrder(TblOnlineAdvancePurchaseOrder tblOnlineAdvancePurchaseOrder);

    public void deleteTblOnlineAdvancePurchaseOrder(TblOnlineAdvancePurchaseOrder tblOnlineAdvancePurchaseOrder);

    public void updateTblOnlineAdvancePurchaseOrder(TblOnlineAdvancePurchaseOrder tblOnlineAdvancePurchaseOrder);

    public List<TblOnlineAdvancePurchaseOrder> getAllTblOnlineAdvancePurchaseOrder();

    public List<TblOnlineAdvancePurchaseOrder> findTblOnlineAdvancePurchaseOrder(Object... values) throws Exception;

    public List<TblOnlineAdvancePurchaseOrder> findByCountTblOnlineAdvancePurchaseOrder(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblOnlineAdvancePurchaseOrderCount();

    public void saveUpdateAllTblOnlineAdvancePurchaseOrder(List<TblOnlineAdvancePurchaseOrder> tblOnlineAdvancePurchaseOrders);

	public void saveOrUpdateTblOnlineAdvancePurchaseOrder(TblOnlineAdvancePurchaseOrder onlineAPO);
}