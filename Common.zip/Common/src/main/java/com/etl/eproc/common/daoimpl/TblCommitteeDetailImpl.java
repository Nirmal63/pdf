package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblCommitteeDetail;
import com.etl.eproc.common.daointerface.TblCommitteeDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCommitteeDetailImpl extends AbcAbstractClass<TblCommitteeDetail> implements TblCommitteeDetailDao {

    @Override
    public void addTblCommitteeDetail(TblCommitteeDetail tblCommitteeDetail){
        super.addEntity(tblCommitteeDetail);
    }

    @Override
    public void deleteTblCommitteeDetail(TblCommitteeDetail tblCommitteeDetail) {
        super.deleteEntity(tblCommitteeDetail);
    }

    @Override
    public void updateTblCommitteeDetail(TblCommitteeDetail tblCommitteeDetail) {
        super.updateEntity(tblCommitteeDetail);
    }

    @Override
    public List<TblCommitteeDetail> getAllTblCommitteeDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCommitteeDetail> findTblCommitteeDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCommitteeDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCommitteeDetail> findByCountTblCommitteeDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCommitteeDetail(List<TblCommitteeDetail> tblCommitteeDetails){
        super.updateAll(tblCommitteeDetails);
    }
}
