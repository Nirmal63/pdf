package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblEmdTransactionDetailStatus;
import java.util.List;

public interface TblEmdTransactionDetailStatusDao  {

    public void addTblEmdTransactionDetailStatus(TblEmdTransactionDetailStatus tblEmdTransactionDetailStatus);

    public void deleteTblEmdTransactionDetailStatus(TblEmdTransactionDetailStatus tblEmdTransactionDetailStatus);

    public void updateTblEmdTransactionDetailStatus(TblEmdTransactionDetailStatus tblEmdTransactionDetailStatus);

    public List<TblEmdTransactionDetailStatus> getAllTblEmdTransactionDetailStatus();

    public List<TblEmdTransactionDetailStatus> findTblEmdTransactionDetailStatus(Object... values) throws Exception;

    public List<TblEmdTransactionDetailStatus> findByCountTblEmdTransactionDetailStatus(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEmdTransactionDetailStatusCount();

    public void saveUpdateAllTblEmdTransactionDetailStatus(List<TblEmdTransactionDetailStatus> tblEmdTransactionDetailStatus);

	public void saveOrUpdateTblEmdTransactionDetailStatus(TblEmdTransactionDetailStatus tblEmdTransactionDetailStatus);
}