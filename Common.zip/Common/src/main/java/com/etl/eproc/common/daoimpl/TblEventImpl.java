package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblEventDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblEventImpl extends AbcAbstractClass<TblEvent> implements TblEventDao {

    @Override
    public void addTblEvent(TblEvent tblEvent){
        super.addEntity(tblEvent);
    }

    @Override
    public void deleteTblEvent(TblEvent tblEvent) {
        super.deleteEntity(tblEvent);
    }

    @Override
    public void updateTblEvent(TblEvent tblEvent) {
        super.updateEntity(tblEvent);
    }

    @Override
    public List<TblEvent> getAllTblEvent() {
        return super.getAllEntity();
    }

    @Override
    public List<TblEvent> findTblEvent(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblEventCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblEvent> findByCountTblEvent(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblEvent(List<TblEvent> tblEvents){
        super.updateAll(tblEvents);
    }
}
