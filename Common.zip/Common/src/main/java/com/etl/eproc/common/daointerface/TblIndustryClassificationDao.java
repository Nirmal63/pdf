/**
 * 
 */
package com.etl.eproc.common.daointerface;

/**
 * @author janak
 *
 */

import com.etl.eproc.common.model.TblIndustryClassification;
import java.util.List;

public interface TblIndustryClassificationDao  {

    public void addTblIndustryClassification(TblIndustryClassification tblIndustryClassification);

    public void deleteTblIndustryClassification(TblIndustryClassification tblIndustryClassification);

    public void updateTblIndustryClassification(TblIndustryClassification tblIndustryClassification);

    public List<TblIndustryClassification> getAllTblIndustryClassification();

    public List<TblIndustryClassification> findTblIndustryClassification(Object... values) throws Exception;

    public List<TblIndustryClassification> findByCountTblIndustryClassification(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblIndustryClassificationCount();

    public void saveUpdateAllTblIndustryClassification(List<TblIndustryClassification> tblIndustryClassifications);
}