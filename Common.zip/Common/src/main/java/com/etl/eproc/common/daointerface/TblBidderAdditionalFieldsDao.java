package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBidderAdditionalFields;

public interface TblBidderAdditionalFieldsDao  {

    public void addTblBidderAdditionalFields(TblBidderAdditionalFields tblBidderAdditionalFields);

    public void deleteTblBidderAdditionalFields(TblBidderAdditionalFields tblBidderAdditionalFields);

    public void updateTblBidderAdditionalFields(TblBidderAdditionalFields tblBidderAdditionalFields);

    public List<TblBidderAdditionalFields> getAllTblBidderAdditionalFields();

    public List<TblBidderAdditionalFields> findTblBidderAdditionalFields(Object... values) throws Exception;

    public List<TblBidderAdditionalFields> findByCountTblBidderAdditionalFields(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidderAdditionalFieldsCount();

    public void saveUpdateAllTblBidderAdditionalFields(List<TblBidderAdditionalFields> tblBidderAdditionalFieldss);

	public void saveOrUpdateTblBidderAdditionalFields(TblBidderAdditionalFields tblBidderAdditionalFields);
}