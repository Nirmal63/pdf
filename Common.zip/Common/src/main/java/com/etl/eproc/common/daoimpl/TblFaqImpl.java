/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;
import com.etl.eproc.common.model.TblFaq;
import com.etl.eproc.common.daointerface.TblFaqDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;

import java.util.List;
import java.util.Map;

/**
 *
 * @author mahesh.patel
 */
@Repository @Transactional    /*StackUpdate*/
public class TblFaqImpl extends AbcAbstractClass<TblFaq> implements TblFaqDao {

    @Override
    public void addTblFaq(TblFaq tblFaq){
        super.addEntity(tblFaq);
    }

    @Override
    public void deleteTblFaq(TblFaq tblFaq) {
        super.deleteEntity(tblFaq);
    }

    @Override
    public void updateTblFaq(TblFaq tblFaq) {
        super.updateEntity(tblFaq);
    }

    @Override
    public List<TblFaq> getAllTblFaq() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFaq> findTblFaq(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFaqCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFaq> findByCountTblFaq(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFaq(List<TblFaq> tblFaqs){
        super.updateAll(tblFaqs);
    }

	@Override
	public int updateDeleteNewQuery(String query, Map<String, Object> var) {
		// TODO Auto-generated method stub
		return 0;
	}
}
