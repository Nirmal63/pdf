package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.common.model.TblCentralizedCommittee;

public interface TblCentralizedCommitteeDao  {

    public void addTblCentralizedCommittee(TblCentralizedCommittee tblCentralizedCommittee);

    public void deleteTblCentralizedCommittee(TblCentralizedCommittee tblCentralizedCommittee);

    public void updateTblCentralizedCommittee(TblCentralizedCommittee tblCentralizedCommittee);

    public List<TblCentralizedCommittee> getAllTblCentralizedCommittee();

    public List<TblCentralizedCommittee> findTblCentralizedCommittee(Object... values) throws Exception;

    public List<TblCentralizedCommittee> findByCountTblCentralizedCommittee(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCentralizedCommitteeCount();

    public void saveUpdateAllTblCentralizedCommittee(List<TblCentralizedCommittee> tblCentralizedCommittees);
}