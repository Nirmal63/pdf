package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblCertUnMapHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblCertUnMapHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCertUnMapHistoryImpl extends AbcAbstractClass<TblCertUnMapHistory> implements TblCertUnMapHistoryDao {

    @Override
    public void addTblCertUnMapHistory(TblCertUnMapHistory tblCertUnMapHistory){
        super.addEntity(tblCertUnMapHistory);
    }

    @Override
    public void deleteTblCertUnMapHistory(TblCertUnMapHistory tblCertUnMapHistory) {
        super.deleteEntity(tblCertUnMapHistory);
    }

    @Override
    public void updateTblCertUnMapHistory(TblCertUnMapHistory tblCertUnMapHistory) {
        super.updateEntity(tblCertUnMapHistory);
    }

    @Override
    public List<TblCertUnMapHistory> getAllTblCertUnMapHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCertUnMapHistory> findTblCertUnMapHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCertUnMapHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCertUnMapHistory> findByCountTblCertUnMapHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCertUnMapHistory(List<TblCertUnMapHistory> tblCertUnMapHistorys){
        super.updateAll(tblCertUnMapHistorys);
    }
}
