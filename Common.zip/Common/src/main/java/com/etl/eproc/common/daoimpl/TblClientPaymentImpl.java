package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblClientPaymentDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblClientPayment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientPaymentImpl extends AbcAbstractClass<TblClientPayment> implements TblClientPaymentDao {

    @Override
    public void addTblClientPayment(TblClientPayment tblClientPayment){
        super.addEntity(tblClientPayment);
    }

    @Override
    public void deleteTblClientPayment(TblClientPayment tblClientPayment) {
        super.deleteEntity(tblClientPayment);
    }

    @Override
    public void updateTblClientPayment(TblClientPayment tblClientPayment) {
        super.updateEntity(tblClientPayment);
    }

    @Override
    public List<TblClientPayment> getAllTblClientPayment() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientPayment> findTblClientPayment(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientPaymentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientPayment> findByCountTblClientPayment(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientPayment(List<TblClientPayment> tblClientPayments){
        super.updateAll(tblClientPayments);
    }
}
