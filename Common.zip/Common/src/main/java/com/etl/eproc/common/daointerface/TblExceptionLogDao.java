package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblExceptionLog;
import java.util.List;

public interface TblExceptionLogDao  {

    public void addTblExceptionLog(TblExceptionLog tblExceptionLog);

    public void deleteTblExceptionLog(TblExceptionLog tblExceptionLog);

    public void updateTblExceptionLog(TblExceptionLog tblExceptionLog);

    public List<TblExceptionLog> getAllTblExceptionLog();

    public List<TblExceptionLog> findTblExceptionLog(Object... values) throws Exception;

    public List<TblExceptionLog> findByCountTblExceptionLog(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblExceptionLogCount();

    public void saveUpdateAllTblExceptionLog(List<TblExceptionLog> tblExceptionLogs);
}