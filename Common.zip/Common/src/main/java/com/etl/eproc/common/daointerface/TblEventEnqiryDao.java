package com.etl.eproc.common.daointerface;

import java.util.List;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblEventEnquiry;

public interface TblEventEnqiryDao  {

    public boolean addTblEventEnqiry(TblEventEnquiry tblEventEnqiry);

    public void deleteTblEventEnqiry(TblEventEnquiry tblEventEnqiry);

  //  public void updateTblEventEnqiry(TblEventEnqiry tblEventEnqiry);

   // public List<TblEventEnqiry> getAllTblEventEnqiry();

    public List<TblEventEnquiry> findTblEventEnqiry(Object... values) throws Exception;

    public List<TblEventEnquiry> findByCountTblEventEnqiry(int firstResult,int maxResult,Object... values) throws Exception;

    //public long getTblEventEnqiryCount();

    public void saveUpdateAllTblEventEnqiry(List<TblEventEnquiry> tblEventEnqiry);
}