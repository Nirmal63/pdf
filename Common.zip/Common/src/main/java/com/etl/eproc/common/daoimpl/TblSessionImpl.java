package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblSessionDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblSessionImpl extends AbcAbstractClass<TblSession> implements TblSessionDao {

    @Override
    public void addTblSession(TblSession tblSession){
        super.addEntity(tblSession);
    }

    @Override
    public void deleteTblSession(TblSession tblSession) {
        super.deleteEntity(tblSession);
    }

    @Override
    public void updateTblSession(TblSession tblSession) {
        super.updateEntity(tblSession);
    }

    @Override
    public List<TblSession> getAllTblSession() {
        return super.getAllEntity();
    }

    @Override
    public List<TblSession> findTblSession(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblSessionCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblSession> findByCountTblSession(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblSession(List<TblSession> tblSessions){
        super.updateAll(tblSessions);
    }
}
