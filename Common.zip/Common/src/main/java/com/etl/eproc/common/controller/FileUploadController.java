/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.net.URL;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblBidderDocMapping;
import com.etl.eproc.common.model.TblBidderDocument;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblDocumentHash;
import com.etl.eproc.common.model.TblDownloadDocHistory;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblOfficerDocMapping;
import com.etl.eproc.common.model.TblOfficerDocument;
import com.etl.eproc.common.model.TblTrackLogin;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.SectorService;
import com.etl.eproc.common.services.TpslService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.DateUtils;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.FileEncryptDecryptUtil;
import com.etl.eproc.common.utility.SessionBean;

import net.coobird.thumbnailator.Thumbnails;


/**
 *
 * @author dipal.shah
 */
@Controller
public class FileUploadController {

    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private CommonService commonService;
    @Autowired
    private FileEncryptDecryptUtil fileEncryptDecryptUtil;
    @Autowired
	private AuditTrailService auditTrailService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private TpslService tpslService;
    @Autowired
    private DepartmentUserService departmentUserService;
    @Autowired
    private ManageBidderService manageBidderService;
     
    @Value("#{projectProperties['logo.server.path']}")
    private String logoserverpath;
    @Value("#{projectProperties['sector.image.server.context.path']}")
    private String sectorimagecontextpath;
    @Value("#{projectProperties['file.drive']}")
    private String fileDrive;
    @Value("#{projectProperties['file.upload']}")
    private String fileUpload;
    @Value("#{projectProperties['file.tenderwisereport']}")
    private String tenderwiseReport;
	@Value("#{projectProperties['doc_upload_path']}")
	private String docUploadPath;
    @Value("#{projectProperties['officer.docstatus.pending']?:0}")
	private int officerDocStatusPending;
    @Value("#{projectProperties['officer.docstatus.approve']?:1}")
	private int officerDocStatusApprove;
    @Value("#{projectProperties['officer.docstatus.reject']?:2}")
	private int officerDocStatusReject;
    @Value("#{projectProperties['officer.docstatus.cancel']?:3}")
	private int officerDocStatusCancel;
    @Value("#{projectProperties['bidder.docstatus.pending']?:0}")
	private int bidderDocStatusPending;
    @Value("#{projectProperties['bidder.docstatus.approve']?:1}")
	private int bidderDocStatusApprove;
    @Value("#{projectProperties['bidder.docstatus.reject']?:2}")
	private int bidderDocStatusReject;
    @Value("#{projectProperties['bidder.docstatus.cancel']?:3}")
	private int bidderDocStatusCancel;
    @Value("#{linkProperties['manage_client_upload_bidder_data']?:421}")
        private int uploadNEFTBidderLinkId;
    @Value("#{vendorlinkProperties['enlistment_configuration_document_upload']?:743}")
    private int enlistmentOfficerDocLinkId;
    @Value("#{projectProperties['contextName']}")
	 private String contextName;
    @Value("#{tenderlinkProperties['notice_and_document_brd_re_generate']}")
    private int brdLinkId;
    @Value("#{tenderlinkProperties['corrigendum_upload']}")
    private int corrigendum_uploadLinkId;
    
    @Value("#{auclinkProperties['manage_auction_attribute_selection_download_image']}")
    private int downloadLinkId;
    @Value("#{auctionAuditTrailProperties['getDownloadItemZip']}")
	private String getDownloadItemZip;
    @Value("#{auctionAuditTrailProperties['getDownloadAllItemZip']}")
	private String getDownloadAllItemZip;
	@Value("#{linkProperties['manage_bidder_blacklist']?:32}")
	private String bidderBlacklistLinkId;
	@Value("#{auclinkProperties['cpb_report_linkId']?:5519}")
    private String prominentReportLinkId;
    @Autowired
    private MessageSource messageSource;
    @Autowired
    private DateUtils dateUtils;
    @Autowired
	private SectorService sectorService;
	private static final int FILESIGNATURE_ZIP[] = new int[]{0x50, 0x4B, 0x03, 0x04};
	private static final int FILESIGNATURE_PDF[] = new int[]{0x25, 0x50, 0x44, 0x46};
	private static final int FILESIGNATURE_RAR[] = new int[]{0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x00};
	private static final int FILESIGNATURE_EXE[] = new int[]{0x4D, 0x5A};
	//private static final int FILESIGNATURE_BMP[] = new int[]{0x42, 0x4D};
	private static final int FILESIGNATURE_DOCX_XLSX[] =  new int[]{0x50, 0x4B, 0x03, 0x04, 0x14, 0x00, 0x06, 0x00};
	private static final int FILESIGNATURE_DOC_PPT_XLS_PPS[] = new int[]{0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1};
	private static final int FILESIGNATURE_DOC_PPT_XLS_PPS_TAT[] = new int[]{13, 10, 13, 10, 13, 10, 13, 10};
	//private static final int FILESIGNATURE_PNG[] = new int[]{0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A};
    //47 49 46 38 37 61               OR  47 49 46 38 39 61  FOR GIF
	/*private static final int FILESIGNATURE_GIF_1[] = new int[]{0x47, 0x49, 0x46, 0x38, 0x37, 0x61};
	private static final int FILESIGNATURE_GIF_2[] = new int[]{0x47, 0x49, 0x46, 0x38, 0x39, 0x61};
    //49 49 2A 00  OR 4D 4D 00 2A FOR TIFF , TIF
	private static final int FILESIGNATURE_TIF_1[] = new int[]{0x49, 0x49, 0x2A, 0x00};
	private static final int FILESIGNATURE_TIF_2[] = new int[]{0x4D, 0x4D, 0x00, 0x2A};
    //FF D8 FF E0 xx xx 4A 46 or 49 46 00               
	private static final int FILESIGNATURE_JPG[] = new int[]{0xFF, 0xD8, 0xFF, 0xE0, 0x4A, 0x46, 0x49, 0x46, 0x00};*/
	private static final String SESSION_OBJECT="sessionObject";
	//private static final String NULL="null";
	private static final String EVENT_ID="txtEventId";
	private static final String CSTATUS_DOC ="txtcStatusDoc";
	private static final String CSTATUS_DOCVIEW ="txtcStatusDocView";
	private static final String TXT_LINKID ="txtlinkId";
	private static final String TXT_OBJECTID ="txtobjectId";
	private static final String OBJECTID ="objectId";
	private static final String DOC_ID ="docId";
	private static final String TXT_DOCID ="txtdocIds";	
	private static final String HD_CHILDID="hdChildId";
	private static final String TXT_CHILDID="txtChildId";
	private static final String TXT_MAPPEDBY="txtMappedBy";
	private static final String THUMBNAIL_PREFIX="thumbnail_";
	private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
	@Value("#{adminAuditTrailProperties['postajaxdocumentupload']}")
    private String postAjaxDocumentUpload;
	@Value("#{adminAuditTrailProperties['postajaximageupload']}")
    private String postAjaxImageUpload;
	@Value("#{adminAuditTrailProperties['postajaxdocumentapprove']}")
    private String postAjaxDocumentApprove;
	@Value("#{adminAuditTrailProperties['postajaxdocumentcancel']}")
    private String postAjaxDocumentCancel;
	@Value("#{adminAuditTrailProperties['postajaxdocumentremove']}")
    private String postAjaxDocumentRemove;
	@Value("#{adminAuditTrailProperties['getdownloadauctiondoc']}")
    private String getDownloadAuctionDocuments;
	@Value("#{adminAuditTrailProperties['postDownloadRegDoc']}")
    private String getDownloadRegDoc;
	private @Value("#{projectProperties['internal_ip']}")
	String internalIp;
	@Value("#{tenderlinkProperties['lnk_docfee_payment']?:929}") 
	private int lnkTenderDocPayment; 
	@Value("#{tenderlinkProperties['lnk_emdfee_payment']?:930}") 
	private int lnkTenderEmdPayment;
	@Value("#{adminAuditTrailProperties['referenceDocumentsUploadedFor']}")
	private String referenceDocumentsUploadedFor;
	@Value("#{adminAuditTrailProperties['referenceDocumentsCancelledFor']}")
	private String referenceDocumentsCancelledFor;
	
	
    /**
     * to submit file upload through ajax
     * @param request
     * @param response
     * @param session
     * @throws IOException
     */
    @RequestMapping(value = "/ajax/submitfileupload",method = RequestMethod.POST)
    public void ajaxSubmitFileUpload(HttpServletRequest request, HttpServletResponse response,HttpSession session){
    	RedirectAttributes redirectAttributes = null;
    	String documentName = null;
    	 boolean isValidate = true;
         int clientId = 0;
         String result="";
         Integer objectId=0;
         int auditTrialObjectId=0;
         String donloadDocPath="";
         int linkId=0;
         ClientBean clientBean = null;
         boolean isSession = false;
         int corrigendumpublishId=0;
         try {
        	 PrintWriter out = response.getWriter();
        	 Object sessionBean=session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
        	 response.setContentType("text/html");
        	 int userTypeId=0;
        	 int userId = 0;
        	 if(sessionBean != null){
	        	  userId = ((SessionBean)sessionBean).getUserId();
	        	   userTypeId=((SessionBean)session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString())).getUserTypeId();
	        	 isSession = true;
        	 }else if(session.getAttribute(SESSION_OBJECT)!=null){
        		 sessionBean=session.getAttribute(SESSION_OBJECT);
	        	  userId = abcUtility.getSessionUserId(request);
	        	  userTypeId=((SessionBean)sessionBean).getUserTypeId();
	        	  isSession = true;
        	 }	
        	 if(isSession){
        		 clientBean = (ClientBean) session.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	             String fileDesc = null;
	             clientId = abcUtility.getSessionClientId(request);
	             int eventId=0;
	             String description=StringUtils.hasLength(request.getParameter("txtDocDesc")) ? request.getParameter("txtDocDesc") : null; 
	             objectId = StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0;
	             eventId = StringUtils.hasLength(request.getParameter(EVENT_ID)) ? Integer.parseInt(request.getParameter(EVENT_ID)) : 0;
	        	 linkId = StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? Integer.parseInt(request.getParameter(TXT_LINKID)) : 0;
	        	 int status=StringUtils.hasLength(request.getParameter("txtCstatus")) ? Integer.parseInt(request.getParameter("txtCstatus")) : 0;
	        	 int cStatusDocView=StringUtils.hasLength(request.getParameter(CSTATUS_DOCVIEW)) ? Integer.parseInt(request.getParameter(CSTATUS_DOCVIEW)) : -1;
	        	 String allowFileExist=StringUtils.hasLength(request.getParameter("txtallowFileExist")) ? request.getParameter("txtallowFileExist") : ""; 
	        	 String isUserIdwisePath=StringUtils.hasLength(request.getParameter("txtisUserIdwisePath")) ? request.getParameter("txtisUserIdwisePath") : "";
	        	 int childId= StringUtils.hasLength(request.getParameter(HD_CHILDID)) ? Integer.parseInt(request.getParameter(HD_CHILDID)) : 0;
	        	 String isSpecialClient=StringUtils.hasLength(request.getParameter("txtisSpecialClient")) ? request.getParameter("txtisSpecialClient") : "n";
	        	 String isThumbmnailRequired=StringUtils.hasLength(request.getParameter("txtisThumbmnailForFirstImgOnly")) ? request.getParameter("txtisThumbmnailForFirstImgOnly") : "n";
	        	 String isCopyOnApacheServerRequired=StringUtils.hasLength(request.getParameter("txtisCopyOnApacheServerRequired")) ? request.getParameter("txtisCopyOnApacheServerRequired") : "n";
	             String isUploadToClientDir=StringUtils.hasLength(request.getParameter("txtuploadToClientDir")) ? request.getParameter("txtuploadToClientDir") : "n";
	             if("Y".equalsIgnoreCase(isUploadToClientDir)){// in case of neft upload vendor data document should upload to selected client directory
	            	 clientId=objectId; 
	             }
	             String documentHashing=null;
	        	 List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, clientId);
	             TblDocUploadConf tblDocUploadConf=lstDocUploadConf.get(0);
	         	 List<Object[]> list=null;
	             boolean fileUploadedSuccess = false;
	             File file = null;
	             File tmpDir=null;
                     File tmpDir2;
	             String fileDir = "";
	             long fileSize = 0;
	             String fileName = "";
	             long fileMaxSize=0;
	             String fileExtensions=null;
	             int maxFileUploadLimit=0;
	             if(!lstDocUploadConf.isEmpty()){
	            	 fileMaxSize = lstDocUploadConf.get(0).getMaxSize() * 1024;
		             fileExtensions = lstDocUploadConf.get(0).getType();
		             maxFileUploadLimit=lstDocUploadConf.get(0).getMaxLimit(); 
	             }
	             DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
	             fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
	             ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
	             List items = uploadHandler.parseRequest(request);
	             Iterator itr = items.iterator();
	             while (itr.hasNext()) {
	            	 if(description == null){
	            		 isValidate = false;
	            		 result=messageSource.getMessage("msg_docbrief_empty", null, LocaleContextHolder.getLocale());
	                     break;
	            	 }
	                 FileItem item = (FileItem) itr.next();
	                 if (item.isFormField()) {
	                     if (item.getFieldName().equals("txtDocDesc")) {
	                         fileDesc = item.getString();
	                         if(fileDesc == null || "".equalsIgnoreCase(fileDesc.trim())){
	                             isValidate = false;
	                             break;
	                         }
	                     }
	                 } else {
	                     fileSize = item.getSize();
	                     if (item.getName().lastIndexOf("\\") != -1) {
	                         fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1, item.getName().length());
	                     } else {
	                         fileName = item.getName();
	                     }
	                     documentName = new String(fileName);
	                    if (StringUtils.hasLength(fileName)) {
	                         if(fileSize == 0){
	                        	 result=messageSource.getMessage("msg_validation_filewithzerokb", null, LocaleContextHolder.getLocale());
	                             isValidate = false;
	                             break;
	                         }
	                         if(maxFileUploadLimit != 0){
	                        	 List<Object[]> uploadedFile=null;
	                        	 if(userTypeId == 1 || userTypeId == 3){
	                        		 uploadedFile=fileUploadService.getOfficerDocs(objectId, clientId, linkId, -1);
	                        	 }else if(userTypeId == 2){
	                        		 uploadedFile=fileUploadService.getBidderDocs(objectId, clientId, linkId, -1,userId);
	                        	 }
	                        	 if(uploadedFile !=null && uploadedFile.size() >= maxFileUploadLimit){
	                        		 result=messageSource.getMessage("msg_maxfileuploadlimit", null, LocaleContextHolder.getLocale());
		                             isValidate = false;
		                             break;
	                        	 }
	                         }
	                         if (!checkFileSize(fileSize, fileMaxSize)) {
	                        	 result= messageSource.getMessage("msg_filesizeexceeds", new Object[]{fileMaxSize / (1024*1024)}, LocaleContextHolder.getLocale());
	                             isValidate = false;
	                             break;
	                         }
	                         if (!checkFileExn(fileName, fileExtensions)) {
	                        	 StringBuilder allowedExt = new StringBuilder();
	                        	 if(!lstDocUploadConf.isEmpty()){
	                        		 allowedExt.append(lstDocUploadConf.get(0).getType());
	                        	 }
	                             int index = allowedExt.toString().indexOf(",");
	                             allowedExt.insert(index + 1, "*.");
	                             while (index >= 0) {
	                                 index = allowedExt.toString().indexOf(",", index + ",".length());
	                                 allowedExt.insert(index + 1, "*.");
	                             }
	                             
	                        	 result=(clientBean.getIsDIYClient()!=1)  ? messageSource.getMessage("msg_acceptablefiletypes", new Object[]{allowedExt}, LocaleContextHolder.getLocale())
	                        			 		: messageSource.getMessage("instruction_fileUpload_2", new Object[]{fileMaxSize/ (1024*1024)}, LocaleContextHolder.getLocale()) +"<br/>"+
	                        			 			messageSource.getMessage("msg_acceptablefiletypes", new Object[]{allowedExt}, LocaleContextHolder.getLocale());
	                             isValidate = false;
	                             break;
	                         } else {
	                        	 /* if destination directory not exist then create it */
	                        	 isDirExists(docUploadPath.split(":")[0]+":\\\\", docUploadPath.substring(3, docUploadPath.length())+tblDocUploadConf.getPath());
	                        	 StringBuilder tmpDirPath=new StringBuilder();
	                        	 tmpDirPath.append(docUploadPath).append(tblDocUploadConf.getPath());
	                             if ((tblDocUploadConf.getIsDynamicPath() == 1 && objectId == 0) || objectId == 0) {
	                                 fileDir = userId + "_" + session.getId();
	                                 tmpDir = new File(tmpDirPath.append("\\").append(fileDir).toString());
	                                 donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                             } else if (objectId != 0 && tblDocUploadConf.getIsDynamicPath() ==1) {
	                            	 fileDir = objectId.toString()+(childId!=0 ? "\\"+childId : "");
	                                 if("Y".equalsIgnoreCase(isUserIdwisePath)){
	                                	 fileDir=fileDir+"\\"+userId;
	                                 }
	                                 tmpDir = new File(tmpDirPath.append("\\").append(fileDir).toString());
	                                 donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                             }else if (objectId != 0 && tblDocUploadConf.getIsDynamicPath() ==0) {
	                                 fileDir = objectId.toString()+(childId!=0 ? "\\"+childId : "");
	                                 tmpDir = new File(tmpDirPath.append("\\").append(fileDir).toString());
	                                 donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                             }
	                             else {
	                                 tmpDir = new File(tmpDirPath.toString());
	                                 donloadDocPath=tblDocUploadConf.getPath();
	                             }
	                             if (!tmpDir.isDirectory()) {
	                            	 tmpDir.mkdirs();
	                             }
	                             file = new File(tmpDir, fileName);
	                             if (abcUtility.ValidationForFileExist(file)) {
	                            	 result= messageSource.getMessage("msg_fileexists", null, LocaleContextHolder.getLocale());
                                     if(allowFileExist.equalsIgnoreCase("y")) {
                                         fileName = fileName.replace(".", "_"+commonService.getServerDateTime().toString().replace(":", "_").replace(".","_") +".");
                                         file = new File(tmpDir, fileName);
                                     } else {
                                        isValidate = false;
                                        fileUploadedSuccess = false;
                                        break;
                                     }
	                             }
	                             item.write(file);
	                             if (checkFileExn(fileName, "enc")){
	                            	 String[] res = new String[2];
	                            	 res = encryptDecryptUtils.decryptSignerCode(file,objectId,0);
                            		 if(res[0].contains("false")){
                            			 isValidate = false;
                            			 result= messageSource.getMessage(res[1], null, LocaleContextHolder.getLocale());
                            		 }
	                             }
	                             documentHashing=fileEncryptDecryptUtil.fileHashing(file);
	                             if (!isValidContentType(file)) {
	                                  file.delete();
	                                  result= messageSource.getMessage("msg_invalidfiletype", null, LocaleContextHolder.getLocale());
	                                  fileUploadedSuccess = false;
	                                  isValidate = false;
	                              } else {
	                            	  
		                            	 if(isValidate && isSpecialClient.equalsIgnoreCase("y")){
		                            		 postAjaxDocumentUpload=postAjaxImageUpload;
		                            		 list=fileUploadService.getOfficerDocs(objectId, childId,clientId, linkId, 1);
		         	                		 if(isThumbmnailRequired.equalsIgnoreCase("y") && list.size()==0){
		         	                			 Thumbnails.of(new File(tmpDir, fileName)).forceSize(100, 100)
		         	                				.toFile(new File(tmpDir,THUMBNAIL_PREFIX+fileName));
		         	                		 }        
		         	                	 }
		                            	 //copy on Apache Server
	         	                		 if(isCopyOnApacheServerRequired.equalsIgnoreCase("y")){
	         	                		 	String tempPath=tblDocUploadConf.getPath();
                                            tmpDir2 =  new File(logoserverpath+"\\"+request.getContextPath()+"\\"+sectorimagecontextpath+"\\"+tempPath+"\\"+fileDir);                        
                                            if (!tmpDir2.isDirectory()) {
                                                tmpDir2.mkdirs();
                                            }
                                            if(tmpDir2.isDirectory()){
                                                FileCopyUtils.copy(file,new File(tmpDir2.getPath()+"\\"+fileName));
                                                if(isValidate && isSpecialClient.equalsIgnoreCase("y")){
                                                	 if(isThumbmnailRequired.equalsIgnoreCase("y") && list.size()==0){
	       		         	                			 FileCopyUtils.copy(new File(tmpDir, THUMBNAIL_PREFIX+fileName),new File(tmpDir2.getPath()+"\\"+THUMBNAIL_PREFIX+fileName));
	       		         	                		 }
                                                }
                                                tmpDir2 = null;
                                            }
	         	                		 }
                                         if(tblDocUploadConf.getIsEncryptionReq() == 1){
                                            fileEncryptDecryptUtil.fileEncryptUtil(file, (int) fileSize);
                                         }
	                                 fileUploadedSuccess = true;
	                             }
	                         }
	                     }
	                 }
	             }
	             if (isValidate) {
	                 if (fileUploadedSuccess) {
	                	 if(userTypeId == 3 || userTypeId == 1){
	                         TblOfficerDocument tblOfficerDocument = new TblOfficerDocument();
	                         tblOfficerDocument.setDocName(fileName);
	                         documentName = new String(fileName);
	                         tblOfficerDocument.setTblClient(new TblClient(clientId));
	                         tblOfficerDocument.setOfficerFolderId(1);
	                         tblOfficerDocument.setPath(donloadDocPath);
	                         tblOfficerDocument.setDescription(description);
	                         tblOfficerDocument.setFileSize((int)fileSize);
	                         tblOfficerDocument.setCreatedBy(userId);
	                         tblOfficerDocument.setCstatus(1);
	                         tblOfficerDocument.setIsEncryptionReq(tblDocUploadConf.getIsEncryptionReq());
	                         TblOfficerDocMapping tblOfficerDocMapping = new TblOfficerDocMapping();
                             tblOfficerDocMapping.setObjectId(objectId);
                             tblOfficerDocMapping.setTblLink(new TblLink(linkId));
                             tblOfficerDocMapping.setMappedBy(userId);
                             tblOfficerDocMapping.setCstatus(cStatusDocView != -1 ? cStatusDocView : status > 3 ? 0 : status);
                             tblOfficerDocMapping.setMappedBy(userId);
                             tblOfficerDocMapping.setChildId(childId);
                             if (fileUploadService.addOfficerDocument(tblOfficerDocument,tblOfficerDocMapping)) {
                            	 TblDocumentHash tblDocumentHash =  new TblDocumentHash();
	                             tblDocumentHash.setHash(documentHashing);
	                             int officerDocId=0;
	                             officerDocId=tblOfficerDocument.getOfficerDocId();
	                             tblDocumentHash.setTblOfficerDocument(new TblOfficerDocument(tblOfficerDocument.getOfficerDocId()));
	                             fileUploadService.addDocumentHashing(tblDocumentHash);
	                        	 auditTrialObjectId=tblOfficerDocMapping.getOfficerDocMappingId();
	                             result= tblOfficerDocMapping.getOfficerDocMappingId() + "";
	                             String previousURL =  request.getHeader("referer");
	                             if(previousURL.contains("uploadtenderdocuments")){
		                             	Object[] tblCorrigendum=commonService.getCorrigendumByTenderId(objectId);
		                             	if(tblCorrigendum!=null){
		                             		corrigendumpublishId=(Integer) tblCorrigendum[0];
		                             		if(corrigendumpublishId!=0){
		                             			fileUploadService.addOfficerDocumentOnNoticeAfterCorrigendum(corrigendumpublishId,tblOfficerDocMapping,0,userId,1,fileName);
		                             		}
		                             	}
		                             }
	             		        }	                             
	                         
	                         if(isSpecialClient.equalsIgnoreCase("y") && isThumbmnailRequired.equalsIgnoreCase("y")){
	                        	list=fileUploadService.getOfficerDocs(objectId, childId,clientId, linkId, 1);
	                        	if(list!=null && list.size()==1){
//		                        	ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
		                        	sectorService.setImageToAuctionItemwise(tblOfficerDocument.getOfficerDocId(), clientBean.getSectorTableName(), childId);
	                        	}
	                         }
	                	 }else if(userTypeId == 2){
	                		 TblBidderDocument tblBidderDocument = new TblBidderDocument();
	                         tblBidderDocument.setDocName(fileName);
	                         tblBidderDocument.setTblClient(new TblClient(clientId));
	                         tblBidderDocument.setBidderFolderId(1);
	                         tblBidderDocument.setPath(donloadDocPath);
	                         tblBidderDocument.setDescription(description);
	                         tblBidderDocument.setFileSize(fileSize);
	                         tblBidderDocument.setCreatedBy(userId);
	                         tblBidderDocument.setCstatus(1);
	                         tblBidderDocument.setIsEncryptionReq(tblDocUploadConf.getIsEncryptionReq());
	                         TblBidderDocMapping tblBidderDocMapping = new TblBidderDocMapping();
                             tblBidderDocMapping.setObjectId(objectId);
                             tblBidderDocMapping.setTblLink(new TblLink(linkId));
                             tblBidderDocMapping.setChildId(childId);
                             tblBidderDocMapping.setMappedBy(userId);
                             tblBidderDocMapping.setCstatus(cStatusDocView != -1 ? cStatusDocView : status > 3 ? 0 : status);
                             tblBidderDocMapping.setDocumentId(0);
                             tblBidderDocMapping.setDocumentName("");
                             tblBidderDocMapping.setTblCompany(new TblCompany(Integer.parseInt(commonService.getCompanyIdByUserId(userId).toString())));
	                         if (fileUploadService.addBidderDocument(tblBidderDocument,tblBidderDocMapping)) {
	                        	 auditTrialObjectId=tblBidderDocMapping.getBidderDocMappingId();
	                             result= tblBidderDocMapping.getBidderDocMappingId() + "";
	                         }
	                	 }
	                	 out.print(result.trim());
	                 }else{
	                	 out.print("Error:" + result);
	                 }
	             }else{
	            	 out.print("Error:" + result);
	             }
        	 }else{
            	 out.print("Error:sessionexpired");
             }
         } catch (Exception e) {
             exceptionHandlerService.writeLog(e);
         } finally {
        	 String previousURL =  request.getHeader("referer");
        	 if(previousURL.contains("uploaddocfortechenv"))
        	 {
        		Object tenderId = fileUploadService.getTenderIdByTableId(objectId);
         		if(tenderId != null)
         		{
         			 objectId = (Integer) tenderId;	
         			 makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postAjaxDocumentUpload+" (Form/Table:"+documentName+")", objectId, auditTrialObjectId);
         		}
        	 }
        	 else if(previousURL.contains("uploadcorrigendumdoc"))
        	 {
        		Object tenderId = fileUploadService.getTenderIdByCorrigendumId(objectId);
         		if(tenderId != null)
         		{
         			objectId = (Integer) tenderId;
         			makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postAjaxDocumentUpload+" (Corrigendum:"+documentName+")", objectId, auditTrialObjectId);
         		}
        	 }else if(previousURL.contains("uploadreferencedocumentsbidderwise") || previousURL.contains("uploadAuctionDocumentbidderwise")){
        		 	int userId = StringUtils.hasLength(request.getParameter(HD_CHILDID)) ? Integer.parseInt(request.getParameter(HD_CHILDID)) : 0;
        		 	String companyName="";
        		 	String message="";
        		 	try {
        		 		companyName=commonService.getCompanyNameByCompanyId(Integer.parseInt(commonService.getCompanyIdByUserId(userId).toString()));
        		 		message=MessageFormat.format(referenceDocumentsUploadedFor, companyName);
					} catch (Exception e) {
						e.printStackTrace();
					}
					 makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId,message, objectId, auditTrialObjectId);
				
        	 }
        	 else
        	 {
        		 if(previousURL.contains("uploadtenderdocuments") && corrigendumpublishId!=0)
        			 makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postAjaxDocumentUpload+" (After Corrigendum Prepare :"+documentName+")", objectId, auditTrialObjectId);
        		 else
        			 makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postAjaxDocumentUpload+" ("+documentName+")", objectId, auditTrialObjectId);
        	 }
        	 
         }
         
    }
    
	/**
     * Project Task #28497
     * Handle multiple file to upload.
     * @param request
     * @param response
     * @param session
     * @author ashish.jani
     */
    @RequestMapping(value = "/ajax/submitmultiplefileupload",method = RequestMethod.POST)
    public void ajaxSubmitMultipleFileUpload(HttpServletRequest request, HttpServletResponse response,HttpSession session){
    	 boolean isValidate = true;
         int clientId = 0;
         String result="";
         Integer objectId=0;
         int auditTrialObjectId=0;
         String donloadDocPath="";
         int linkId=0;
         ClientBean clientBean = null;
         try {
        	 PrintWriter out = response.getWriter();
        	 Object sessionBean=session.getAttribute(SESSION_OBJECT);
        	 response.setContentType("text/html");
        	 if(sessionBean != null){
        		 clientBean = (ClientBean) session.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	        	 int userTypeId=((SessionBean)sessionBean).getUserTypeId();
	        	 int userId = abcUtility.getSessionUserId(request);
	             String fileDesc = null;
	             clientId = abcUtility.getSessionClientId(request);
	             int eventId=0;
	             //String description=StringUtils.hasLength(request.getParameter("txtDocDesc")) ? request.getParameter("txtDocDesc") : null; 
	             objectId = StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0;
	             eventId = StringUtils.hasLength(request.getParameter(EVENT_ID)) ? Integer.parseInt(request.getParameter(EVENT_ID)) : 0;
	        	 linkId = StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? Integer.parseInt(request.getParameter(TXT_LINKID)) : 0;
	        	 int status=StringUtils.hasLength(request.getParameter("txtCstatus")) ? Integer.parseInt(request.getParameter("txtCstatus")) : 0;
	        	 int cStatusDocView=StringUtils.hasLength(request.getParameter(CSTATUS_DOCVIEW)) ? Integer.parseInt(request.getParameter(CSTATUS_DOCVIEW)) : -1;
	        	 String allowFileExist=StringUtils.hasLength(request.getParameter("txtallowFileExist")) ? request.getParameter("txtallowFileExist") : ""; 
	        	 String isUserIdwisePath=StringUtils.hasLength(request.getParameter("txtisUserIdwisePath")) ? request.getParameter("txtisUserIdwisePath") : "";
	        	 int childId= StringUtils.hasLength(request.getParameter(HD_CHILDID)) ? Integer.parseInt(request.getParameter(HD_CHILDID)) : 0;
	        	 String isSpecialClient=StringUtils.hasLength(request.getParameter("txtisSpecialClient")) ? request.getParameter("txtisSpecialClient") : "n";
	        	 String isThumbmnailRequired=StringUtils.hasLength(request.getParameter("txtisThumbmnailForFirstImgOnly")) ? request.getParameter("txtisThumbmnailForFirstImgOnly") : "n";
	        	 String isCopyOnApacheServerRequired=StringUtils.hasLength(request.getParameter("txtisCopyOnApacheServerRequired")) ? request.getParameter("txtisCopyOnApacheServerRequired") : "n";
	             List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, clientId);
	             TblDocUploadConf tblDocUploadConf=lstDocUploadConf.get(0);
	         	 List<Object[]> list=null;
	             boolean fileUploadedSuccess = false;
	             File file = null;
	             File tmpDir=null;
                     File tmpDir2;
	             String fileDir = "";
	             long fileSize = 0;
	             String fileName = "";
	             long fileMaxSize=0;
	             String fileExtensions=null;
	             int maxFileUploadLimit=0;
	             if(!lstDocUploadConf.isEmpty()){
	            	 fileMaxSize = lstDocUploadConf.get(0).getMaxSize() * 1024;
		             fileExtensions = lstDocUploadConf.get(0).getType();
		             maxFileUploadLimit=lstDocUploadConf.get(0).getMaxLimit(); 
	             }
	             DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
	             fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
	             ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
	             List items = uploadHandler.parseRequest(request);
	             Iterator itr = items.iterator();
	             int idx = 0;
	             JSONArray jArrResponse = new JSONArray();
	             while (itr.hasNext()) {
	            	 FileItem item = (FileItem) itr.next();
	            	 JSONObject jobjFile = new JSONObject();
	            	 String description=StringUtils.hasLength(request.getParameter("txtDocDesc_"+idx)) ? request.getParameter("txtDocDesc_"+idx) : null;
	            	 idx++;
	            	 if(description == null){
	            		 jobjFile.put("status", "error");
	            		 jobjFile.put("file_name", item.getName());
	            		 result=messageSource.getMessage("msg_docbrief_empty", null, LocaleContextHolder.getLocale());
	            		 jobjFile.put("result", result);
	            		 jArrResponse.put(jobjFile);
	            		 isValidate = false;
	                     continue;
	            	 }
	                 
	                 if (item.isFormField()) {
	                     if (item.getFieldName().equals("txtDocDesc")) {
	                         fileDesc = item.getString();
	                         if(fileDesc == null || "".equalsIgnoreCase(fileDesc.trim())){
	                             isValidate = false;
	                             break;
	                         }
	                     }
	                 } else {
	                     fileSize = item.getSize();
	                     if (item.getName().lastIndexOf("\\") != -1) {
	                         fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1, item.getName().length());
	                     } else {
	                         fileName = item.getName();
	                     }
	                     if (StringUtils.hasLength(fileName)) {
	                         if(fileSize == 0){
	                        	 jobjFile.put("status", "error");
	                        	 jobjFile.put("file_name", item.getName());
	                        	 result=messageSource.getMessage("msg_validation_filewithzerokb", null, LocaleContextHolder.getLocale());
	                        	 jobjFile.put("result", result);
	    	            		 jArrResponse.put(jobjFile);
	    	            		 isValidate = false;
	                             continue;
	                         }
	                         if(maxFileUploadLimit != 0){
	                        	 List<Object[]> uploadedFile=null;
	                        	 if(userTypeId == 1 || userTypeId == 3){
	                        		 //uploadedFile=fileUploadService.getOfficerDocs(objectId, clientId, linkId, -1);
	                        		 uploadedFile=fileUploadService.getOfficerDocs(objectId, childId,clientId, linkId, 1);
	                        	 }/*else if(userTypeId == 2){
	                        		 uploadedFile=fileUploadService.getBidderDocs(objectId, clientId, linkId, -1,userId);
	                        	 }*/
	                        	 if(uploadedFile !=null && uploadedFile.size() >= maxFileUploadLimit){
	                        		 jobjFile.put("status", "error");
	                        		 jobjFile.put("file_name", item.getName());
	                        		 result=messageSource.getMessage("vehicle_file_limit_exceed", null, LocaleContextHolder.getLocale());
	                        		 jobjFile.put("result", result);
		    	            		 jArrResponse.put(jobjFile);
		    	            		 isValidate = false;
		                             continue;
	                        	 }
	                         }
	                         if (!checkFileSize(fileSize, fileMaxSize)) {
	                        	 jobjFile.put("status", "error");
	                        	 jobjFile.put("file_name", item.getName());
	                        	 result= messageSource.getMessage("vehicle_file_size_exceed", new Object[]{fileMaxSize / (1024*1024)}, LocaleContextHolder.getLocale());
	                        	 jobjFile.put("result", result);
	    	            		 jArrResponse.put(jobjFile);
	    	            		 isValidate = false;
	                             continue;
	                         }
	                         if (!checkFileExn(fileName, fileExtensions)) {
	                        	 StringBuilder allowedExt = new StringBuilder();
	                        	 if(!lstDocUploadConf.isEmpty()){
	                        		 allowedExt.append(lstDocUploadConf.get(0).getType());
	                        	 }
	                             int index = allowedExt.toString().indexOf(",");
	                             allowedExt.insert(index + 1, "*.");
	                             while (index >= 0) {
	                                 index = allowedExt.toString().indexOf(",", index + ",".length());
	                                 allowedExt.insert(index + 1, "*.");
	                             }
	                             jobjFile.put("status", "error");
	                             jobjFile.put("file_name", item.getName());
	                             result=(clientBean.getIsDIYClient()!=1)  ? messageSource.getMessage("msg_acceptablefiletypes", new Object[]{allowedExt}, LocaleContextHolder.getLocale())
	                        			 		: messageSource.getMessage("instruction_fileUpload_2", new Object[]{fileMaxSize/ (1024*1024)}, LocaleContextHolder.getLocale()) +"<br/>"+
	                        			 			messageSource.getMessage("msg_acceptablefiletypes", new Object[]{allowedExt}, LocaleContextHolder.getLocale());
	                             jobjFile.put("result", result);
	    	            		 jArrResponse.put(jobjFile);
	    	            		 isValidate = false;
	                             continue;
	                         } else {
	                        	 /* if destination directory not exist then create it */
	                        	 isDirExists(docUploadPath.split(":")[0]+":\\\\", docUploadPath.substring(3, docUploadPath.length())+tblDocUploadConf.getPath());
	                        	 StringBuilder tmpDirPath=new StringBuilder();
	                        	 tmpDirPath.append(docUploadPath).append(tblDocUploadConf.getPath());
	                             if ((tblDocUploadConf.getIsDynamicPath() == 1 && objectId == 0) || objectId == 0) {
	                                 fileDir = userId + "_" + session.getId();
	                                 tmpDir = new File(tmpDirPath.append("\\").append(fileDir).toString());
	                                 donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                             } else if (objectId != 0 && tblDocUploadConf.getIsDynamicPath() ==1) {
	                            	 fileDir = objectId.toString()+(childId!=0 ? "\\"+childId : "");
	                                 if("Y".equalsIgnoreCase(isUserIdwisePath)){
	                                	 fileDir=fileDir+"\\"+userId;
	                                 }
	                                 tmpDir = new File(tmpDirPath.append("\\").append(fileDir).toString());
	                                 donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                             }else if (objectId != 0 && tblDocUploadConf.getIsDynamicPath() ==0) {
	                                 fileDir = objectId.toString()+(childId!=0 ? "\\"+childId : "");
	                                 tmpDir = new File(tmpDirPath.append("\\").append(fileDir).toString());
	                                 donloadDocPath=tblDocUploadConf.getPath()+"\\"+fileDir;
	                             }
	                             else {
	                                 tmpDir = new File(tmpDirPath.toString());
	                                 donloadDocPath=tblDocUploadConf.getPath();
	                             }
	                             if (!tmpDir.isDirectory()) {
	                            	 tmpDir.mkdirs();
	                             }
	                             file = new File(tmpDir, fileName);
	                             if (abcUtility.ValidationForFileExist(file)) {
	                            	 result= messageSource.getMessage("msg_fileexists", null, LocaleContextHolder.getLocale());
                                     if(allowFileExist.equalsIgnoreCase("y")) {
                                         fileName = fileName.replace(".", "_"+commonService.getServerDateTime().toString().replace(":", "_").replace(".","_") +".");
                                         file = new File(tmpDir, fileName);
                                     } else {
                                    	jobjFile.put("status", "error");
                                    	jobjFile.put("file_name", item.getName()); 
                                        fileUploadedSuccess = false;
                                        jobjFile.put("result", result);
	       	    	            		jArrResponse.put(jobjFile);
	       	    	            		isValidate = false;
	       	                            continue;
                                     }
	                             }
	                             item.write(file);
	                             if (checkFileExn(fileName, "enc")){
	                            	 String[] res = new String[2];
	                            	 res = encryptDecryptUtils.decryptSignerCode(file,objectId,0);
                            		 if(res[0].contains("false")){
                            			 isValidate = false;
                            			 result= messageSource.getMessage(res[1], null, LocaleContextHolder.getLocale());
                            		 }
	                             }
	                             if (!isValidContentType(file)) {
	                                  file.delete();
	                                  jobjFile.put("status", "error");
	                                  jobjFile.put("file_name", item.getName());
	                                  result= messageSource.getMessage("msg_invalidfiletype", null, LocaleContextHolder.getLocale());
	                                  jobjFile.put("result", result);
	       	    	            	  jArrResponse.put(jobjFile);
	                                  fileUploadedSuccess = false;
	                                  isValidate = false;
	                              } else {
	                            	  
		                            	 if(isValidate && isSpecialClient.equalsIgnoreCase("y")){
		                            		 postAjaxDocumentUpload=postAjaxImageUpload;
		                            		 list=fileUploadService.getOfficerDocs(objectId, childId,clientId, linkId, 1);
		         	                		 if(isThumbmnailRequired.equalsIgnoreCase("y") && list.size()==0){
		         	                			 Thumbnails.of(new File(tmpDir, fileName)).forceSize(100, 100)
		         	                				.toFile(new File(tmpDir,THUMBNAIL_PREFIX+fileName));
		         	                		 }        
		         	                	 }
		                            	 //copy on Apache Server
	         	                		 if(isCopyOnApacheServerRequired.equalsIgnoreCase("y")){
	         	                		 	String tempPath=tblDocUploadConf.getPath();
                                            tmpDir2 =  new File(logoserverpath+"\\"+request.getContextPath()+"\\"+sectorimagecontextpath+"\\"+tempPath+"\\"+fileDir);                        
                                            if (!tmpDir2.isDirectory()) {
                                                tmpDir2.mkdirs();
                                            }
                                            
                                            if(tmpDir2.isDirectory()){
                                                FileCopyUtils.copy(file,new File(tmpDir2.getPath()+"\\"+fileName));
                                                if(isValidate && isSpecialClient.equalsIgnoreCase("y")){
                                                	 if(isThumbmnailRequired.equalsIgnoreCase("y") && list.size()==0){
	       		         	                			 FileCopyUtils.copy(new File(tmpDir, THUMBNAIL_PREFIX+fileName),new File(tmpDir2.getPath()+"\\"+THUMBNAIL_PREFIX+fileName));
	       		         	                		 }
                                                }
                                                tmpDir2 = null;
                                            }
	         	                		 }
                                         if(tblDocUploadConf.getIsEncryptionReq() == 1){
                                            fileEncryptDecryptUtil.fileEncryptUtil(file, (int) fileSize);
                                         }
	                                 fileUploadedSuccess = true;
	                                 isValidate = true;
	                             }
	                         }
	                     }
	                 }
	             
		             if (isValidate) {
		            	 if (fileUploadedSuccess) {
		                	 if(userTypeId == 3 || userTypeId == 1){
		                         TblOfficerDocument tblOfficerDocument = new TblOfficerDocument();
		                         tblOfficerDocument.setDocName(fileName);
		                         tblOfficerDocument.setTblClient(new TblClient(clientId));
		                         tblOfficerDocument.setOfficerFolderId(1);
		                         tblOfficerDocument.setPath(donloadDocPath);
		                         tblOfficerDocument.setDescription(description);
		                         tblOfficerDocument.setFileSize((int)fileSize);
		                         tblOfficerDocument.setCreatedBy(userId);
		                         tblOfficerDocument.setCstatus(1);
		                         tblOfficerDocument.setIsEncryptionReq(tblDocUploadConf.getIsEncryptionReq());
		                         TblOfficerDocMapping tblOfficerDocMapping = new TblOfficerDocMapping();
	                             tblOfficerDocMapping.setObjectId(objectId);
	                             tblOfficerDocMapping.setTblLink(new TblLink(linkId));
	                             tblOfficerDocMapping.setMappedBy(userId);
	                             tblOfficerDocMapping.setCstatus(cStatusDocView != -1 ? cStatusDocView : status > 3 ? 0 : status);
	                             tblOfficerDocMapping.setMappedBy(userId);
	                             tblOfficerDocMapping.setChildId(childId);
		                         if (fileUploadService.addOfficerDocument(tblOfficerDocument,tblOfficerDocMapping)) {
		                        	 auditTrialObjectId=tblOfficerDocMapping.getOfficerDocMappingId();
		                             result= tblOfficerDocMapping.getOfficerDocMappingId() + "";
		                             jobjFile.put("status", "success");
		                             jobjFile.put("file_name", item.getName());
		                             jobjFile.put("result", result);
	       	    	            	 jArrResponse.put(jobjFile);
		                         }
		                         if(isSpecialClient.equalsIgnoreCase("y") && isThumbmnailRequired.equalsIgnoreCase("y")){
		                        	list=fileUploadService.getOfficerDocs(objectId, childId,clientId, linkId, 1);
		                        	if(list!=null && list.size()==1){
	//		                        	ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
			                        	sectorService.setImageToAuctionItemwise(tblOfficerDocument.getOfficerDocId(), clientBean.getSectorTableName(), childId);
		                        	}
		                         }
		                	 }else if(userTypeId == 2){
		                		 TblBidderDocument tblBidderDocument = new TblBidderDocument();
		                         tblBidderDocument.setDocName(fileName);
		                         tblBidderDocument.setTblClient(new TblClient(clientId));
		                         tblBidderDocument.setBidderFolderId(1);
		                         tblBidderDocument.setPath(donloadDocPath);
		                         tblBidderDocument.setDescription(description);
		                         tblBidderDocument.setFileSize(fileSize);
		                         tblBidderDocument.setCreatedBy(userId);
		                         tblBidderDocument.setCstatus(1);
		                         tblBidderDocument.setIsEncryptionReq(tblDocUploadConf.getIsEncryptionReq());
		                         TblBidderDocMapping tblBidderDocMapping = new TblBidderDocMapping();
	                             tblBidderDocMapping.setObjectId(objectId);
	                             tblBidderDocMapping.setTblLink(new TblLink(linkId));
	                             tblBidderDocMapping.setChildId(0);
	                             tblBidderDocMapping.setMappedBy(userId);
	                             tblBidderDocMapping.setCstatus(cStatusDocView != -1 ? cStatusDocView : status > 3 ? 0 : status);
	                             tblBidderDocMapping.setDocumentId(0);
	                             tblBidderDocMapping.setDocumentName("");
	                             tblBidderDocMapping.setTblCompany(new TblCompany(Integer.parseInt(commonService.getCompanyIdByUserId(userId).toString())));
		                         if (fileUploadService.addBidderDocument(tblBidderDocument,tblBidderDocMapping)) {
		                        	 auditTrialObjectId=tblBidderDocMapping.getBidderDocMappingId();
		                             result= tblBidderDocMapping.getBidderDocMappingId() + "";
		                             jobjFile.put("status", "success");
		                             jobjFile.put("file_name", item.getName());
		                             jobjFile.put("result", result);
	       	    	            	 jArrResponse.put(jobjFile);
		                         }
		                	 }
		                	 //out.print(result.trim());
		                 }/*else{
		                	 out.print("Error:" + result);
		                 }*/
		             }
	             }
	             out.print(jArrResponse.toString());
        	 }else{
            	 out.print("Error:sessionexpired");
             }
         } catch (Exception e) {
             exceptionHandlerService.writeLog(e);
         } finally {
        	 makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, postAjaxDocumentUpload, objectId, auditTrialObjectId);
         }
         
    }
    
    /**
     * to change the status of the document and remove physical file (if status is rejected(delete))
     */
    @RequestMapping(value = "/ajax/deletefile",method = RequestMethod.POST)
    public void removeUploadedFile(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
        int docId = StringUtils.hasLength(request.getParameter("txtdocId")) ? Integer.parseInt(request.getParameter("txtdocId")) : 0;
        int linkId = 0;
    	String message=null;
    	int objectId=StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0;
        int cStatusDoc=StringUtils.hasLength(request.getParameter(CSTATUS_DOC)) ? Integer.parseInt(request.getParameter(CSTATUS_DOC)) : 0;
        String signText=StringUtils.hasLength(request.getParameter("skpSignText")) ? request.getParameter("skpSignText") : "";
        boolean delFlag = false;
        int corrigendumpublishId=0;
        try {
        	if(session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	        	int userTypeId=((SessionBean)session.getAttribute(SESSION_OBJECT)).getUserTypeId();
	        	int userId = ((SessionBean)session.getAttribute(SESSION_OBJECT)).getUserId();
	        	if(userTypeId == 1 || userTypeId == 3){
	        		List<Object[]> tblOfficerDocument= fileUploadService.getOfficerDocDetailsForRemove(docId);
	        		if(!tblOfficerDocument.isEmpty()){
		        		String filePath=docUploadPath+tblOfficerDocument.get(0)[3].toString();
		        		filePath=filePath.replace("\\", "\\\\");
		        		filePath += "\\"+tblOfficerDocument.get(0)[2].toString();
		        		String previousURL =  request.getHeader("referer");
                        if(previousURL.contains("etender")){
		        		Object[] tblCorrigendum=commonService.getCorrigendumByTenderId(objectId);
        		        boolean isDelete=false;
        		        if(tblCorrigendum!=null){
        		        corrigendumpublishId=(Integer) tblCorrigendum[0];
        		        java.util.Date corrigendumpublishon=(Date) tblCorrigendum[1];
                        if(corrigendumpublishId!=0){
                        	int docsId=Integer.parseInt(tblOfficerDocument.get(0)[1].toString());
                        	TblOfficerDocument tblOfficerDos= fileUploadService.getOfficerDocumentById(docsId);
                        	if(tblOfficerDos!=null){
                        	List<TblOfficerDocMapping> tblOfficerDocMapping = fileUploadService.getOfficerDocumentMappingByOfficerDoc(tblOfficerDos);
                        	if(tblOfficerDocMapping!=null && !tblOfficerDocMapping.isEmpty()){
                        		for(TblOfficerDocMapping tbldocs:tblOfficerDocMapping){
                        			if(objectId==tbldocs.getObjectId() && docId==tbldocs.getOfficerDocMappingId()){
                         				 if((cStatusDoc == officerDocStatusCancel || cStatusDoc == officerDocStatusApprove))
                         					 	delFlag=fileUploadService.addOfficerDocumentOnNoticeAfterCorrigendum(corrigendumpublishId,tbldocs,cStatusDoc,userId,2,tblOfficerDocument.get(0)[2].toString());
                         					if(cStatusDoc == officerDocStatusReject){
                         						delFlag = fileUploadService.updateOfficerDocDetailsForRemove(docId,cStatusDoc);
                         						delFlag=fileUploadService.addOfficerDocumentOnNoticeAfterCorrigendum(corrigendumpublishId,tbldocs,cStatusDoc,userId,3,tblOfficerDocument.get(0)[2].toString());
                         					}
                        					 if(cStatusDoc == officerDocStatusApprove){
                 		        				message=postAjaxDocumentApprove;
                 		        			}else if(cStatusDoc == officerDocStatusCancel){
                 		        				message=postAjaxDocumentCancel;
                 		        			}else if(cStatusDoc == officerDocStatusReject){
                 		        				message=postAjaxDocumentRemove;
                 		        			}
                        			}
                        		}
                        	}
                        }
                        }
                        }
	        		}
        		        if(corrigendumpublishId==0){
		        		if(cStatusDoc == officerDocStatusCancel || cStatusDoc == officerDocStatusApprove){
		        			delFlag = fileUploadService.updateOfficerDocDetailsForRemove(docId,cStatusDoc);
		        			if(cStatusDoc == officerDocStatusApprove){
		        				linkId=getLinkId((Integer)tblOfficerDocument.get(0)[5], officerDocStatusApprove,0);
		        				message=postAjaxDocumentApprove;
		        			}else{
		        				linkId=getLinkId((Integer)tblOfficerDocument.get(0)[5], officerDocStatusCancel,0);
		        				message=postAjaxDocumentCancel;
		        			}
		        		}else{
		        			File f = new File(filePath);
		        			f = abcUtility.CheckDirExist(f);
		    	            if(f.exists()){
		    	            	delFlag = deleteFile(f.getPath());
				        		if (delFlag) {
				                    delFlag = fileUploadService.updateOfficerDocDetailsForRemove(docId,cStatusDoc);
				                }
		    	            }
			        		linkId=getLinkId((Integer)tblOfficerDocument.get(0)[5], officerDocStatusReject,0);
		    				message=postAjaxDocumentRemove;
		        		}
        		       }
	        		}
	        	}else if(userTypeId == 2){
	        		List<Object[]> tblBidderDocument=fileUploadService.getBidderDocDetailsForRemove(docId);
	        		if(!tblBidderDocument.isEmpty()){
		        		String filePath=docUploadPath+tblBidderDocument.get(0)[3].toString();
		        		filePath=filePath.replace("\\", "\\\\");
		        		if(cStatusDoc == bidderDocStatusCancel || cStatusDoc == bidderDocStatusApprove){
		        			delFlag = fileUploadService.updateBidderDocDetailsForRemove(docId,cStatusDoc);
		        			if(cStatusDoc == bidderDocStatusApprove){
		        				linkId=getLinkId((Integer)tblBidderDocument.get(0)[5], bidderDocStatusApprove,0);
		        				message=postAjaxDocumentApprove;
		        			}else{
		        				linkId=getLinkId((Integer)tblBidderDocument.get(0)[5], bidderDocStatusCancel,0);
		        				message=postAjaxDocumentCancel;
		        			}
		        		}else{
		        			if((Integer)tblBidderDocument.get(0)[5]==lnkTenderDocPayment || (Integer)tblBidderDocument.get(0)[5]==lnkTenderEmdPayment)
		        			{
		        				File f = new File(filePath);
			        			if(f.exists()){
			        				delFlag = renameFile(filePath, tblBidderDocument.get(0)[2].toString());
					        		if (delFlag) {
					                    delFlag = fileUploadService.updateBidderDocDetailsForRemove(docId,cStatusDoc);
					                    delFlag = fileUploadService.updateBidderDocDocumentForRemove((Integer)tblBidderDocument.get(0)[1],cStatusDoc);
					                }
			    	            }
		        			}else
		        			{
		        				filePath += "\\"+tblBidderDocument.get(0)[2].toString();
		        				File f = new File(filePath);
			        			f = abcUtility.CheckDirExist(f);
			    	            if(f.exists()){
			        				delFlag = deleteFile(f.getPath());
					        		if (delFlag) {
					                    delFlag = fileUploadService.updateBidderDocDetailsForRemove(docId,cStatusDoc);
					                }
			    	            }
		        			}
			        		linkId=getLinkId((Integer)tblBidderDocument.get(0)[5], bidderDocStatusReject,0);
		    				message=postAjaxDocumentRemove;
		        		}
	        		}
	        	}
	        	response.getWriter().write(delFlag + "");
        	}else if(session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString())  != null ){

	        	int userTypeId=((SessionBean)session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString())).getUserTypeId();
	        	if(userTypeId == 1 || userTypeId == 3){
	        		List<Object[]> tblOfficerDocument= fileUploadService.getOfficerDocDetailsForRemove(docId);
	        		if(!tblOfficerDocument.isEmpty()){
		        		String filePath=docUploadPath+tblOfficerDocument.get(0)[3].toString();
		        		filePath=filePath.replace("\\", "\\\\");
		        		filePath += "\\"+tblOfficerDocument.get(0)[2].toString();
		        		if(cStatusDoc == officerDocStatusCancel || cStatusDoc == officerDocStatusApprove){
		        			delFlag = fileUploadService.updateOfficerDocDetailsForRemove(docId,cStatusDoc);
		        			if(cStatusDoc == officerDocStatusApprove){
		        				linkId=getLinkId((Integer)tblOfficerDocument.get(0)[5], officerDocStatusApprove,0);
		        				message=postAjaxDocumentApprove;
		        			}else{
		        				linkId=getLinkId((Integer)tblOfficerDocument.get(0)[5], officerDocStatusCancel,0);
		        				message=postAjaxDocumentCancel;
		        			}
		        		}else{
		        			File f = new File(filePath);
		        			f = abcUtility.CheckDirExist(f);
		    	            if(f.exists()){
				        		delFlag = deleteFile(f.getPath());
				        		if (delFlag) {
				                    delFlag = fileUploadService.updateOfficerDocDetailsForRemove(docId,cStatusDoc);
				                }
		    	            }
			        		linkId=getLinkId((Integer)tblOfficerDocument.get(0)[5], officerDocStatusReject,0);
		    				message=postAjaxDocumentRemove;
		        		}
	        		}
	        	}else if(userTypeId == 2){
	        		List<Object[]> tblBidderDocument=fileUploadService.getBidderDocDetailsForRemove(docId);
	        		if(!tblBidderDocument.isEmpty()){
		        		String filePath=docUploadPath+tblBidderDocument.get(0)[3].toString();
		        		filePath=filePath.replace("\\", "\\\\");
		        		filePath += "\\"+tblBidderDocument.get(0)[2].toString();
		        		if(cStatusDoc == bidderDocStatusCancel || cStatusDoc == bidderDocStatusApprove){
		        			delFlag = fileUploadService.updateBidderDocDetailsForRemove(docId,cStatusDoc);
		        			if(cStatusDoc == bidderDocStatusApprove){
		        				linkId=getLinkId((Integer)tblBidderDocument.get(0)[5], bidderDocStatusApprove,0);
		        				message=postAjaxDocumentApprove;
		        			}else{
		        				linkId=getLinkId((Integer)tblBidderDocument.get(0)[5], bidderDocStatusCancel,0);
		        				message=postAjaxDocumentCancel;
		        			}
		        		}else{
		        			File f = new File(filePath);
		        			f = abcUtility.CheckDirExist(f);
		    	            if(f.exists()){
				        		delFlag = deleteFile(f.getPath());
				        		if (delFlag) {
				                    delFlag = fileUploadService.updateBidderDocDetailsForRemove(docId,cStatusDoc);
				                }
		    	            }
			        		linkId=getLinkId((Integer)tblBidderDocument.get(0)[5], bidderDocStatusReject,0);
		    				message=postAjaxDocumentRemove;
		        		}
	        		}
	        	}
	        	response.getWriter().write(delFlag + "");
        	
        	}else{
        		response.getWriter().write("sessionexpired");
        	}
          
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }finally {
      		      		 
        	if(abcUtility.getSessionIsPkiEnabled(request) == 1 && request.getHeader("Referer").contains(request.getContextPath()+"/etender") && (cStatusDoc == 1 || cStatusDoc == 3)){
        		if(request.getHeader("Referer").contains("/etender") && corrigendumpublishId!=0)
         			 makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, message+" After Corrigendum Prepare", objectId,docId,message,signText);
        		else if(request.getHeader("Referer").contains("/uploadreferencedocumentsbidderwise") || request.getHeader("Referer").contains("/uploadAuctionDocumentbidderwise")){

        			int userId = StringUtils.hasLength(request.getParameter("txtChildId")) ? Integer.parseInt(request.getParameter("txtChildId")) : 0;
        		 	String companyName="";
        		 	String msg="";
        		 	try {
        		 		companyName=commonService.getCompanyNameByCompanyId(Integer.parseInt(commonService.getCompanyIdByUserId(userId).toString()));
        		 		msg=MessageFormat.format(referenceDocumentsCancelledFor, companyName);
					} catch (Exception e) {
						e.printStackTrace();
					}
        		 	makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, objectId,docId,msg,signText);
        		}
        		else
        			makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, message, objectId, docId,message,signText);
        	}else{
        		if(request.getHeader("Referer").contains("/etender") && corrigendumpublishId!=0)
        			 makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, message+" After Corrigendum Prepare", objectId,docId);
        		else if(request.getHeader("Referer").contains("/uploadreferencedocumentsbidderwise") || request.getHeader("Referer").contains("/uploadAuctionDocumentbidderwise")){

        			int userId = StringUtils.hasLength(request.getParameter("txtChildId")) ? Integer.parseInt(request.getParameter("txtChildId")) : 0;
        		 	String companyName="";
        		 	String msg="";
        		 	try {
        		 		companyName=commonService.getCompanyNameByCompanyId(Integer.parseInt(commonService.getCompanyIdByUserId(userId).toString()));
        		 		msg=MessageFormat.format(referenceDocumentsCancelledFor, companyName);
					} catch (Exception e) {
						e.printStackTrace();
					}
        		 	makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, objectId, docId);
        		}
        		else
        			 makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, message, objectId, docId);
        	}
        }
    }
    
    private boolean renameFile(String filePath,String oldFileName) {
        boolean flg = false;
        try {
            File f = new File(filePath+"\\"+oldFileName);
            File f2=new File(filePath+"\\"+oldFileName.replace(".", "_deleted"+commonService.getServerDateTime().toString().replace(".","_").replace(":","_")+"."));
            f = abcUtility.CheckDirExist(f);
            if(f.exists()){
            	flg=f.renameTo(f2);
            }
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
        return flg;
    }
   /**
    * This controller remove the image as well thumbnail with the object & row id from local and apache server
    * @author mitesh
    * @param request
    * @param response
    * @param session
    */
    @RequestMapping(value = "/ajax/deletefilewiththumbnail",method = RequestMethod.POST)
    public void removeUploadedFileWithThumbnail(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
        int docId = StringUtils.hasLength(request.getParameter("hdDocId")) ? Integer.parseInt(request.getParameter("hdDocId")) : 0;
        int linkId = 0;
    	String message=null;
    	int objectId=StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0;
        int cStatusDoc=StringUtils.hasLength(request.getParameter(CSTATUS_DOC)) ? Integer.parseInt(request.getParameter(CSTATUS_DOC)) : 0;
        String signText=StringUtils.hasLength(request.getParameter("skpSignText")) ? request.getParameter("skpSignText") : "";
        String isDeleteThumbFromLocal=StringUtils.hasLength(request.getParameter("txtIsDeleteFromLocal")) ? request.getParameter("txtIsDeleteFromLocal") : "n";
        String isDeleteFromServer=StringUtils.hasLength(request.getParameter("txtIsDeleteFromServer")) ? request.getParameter("txtIsDeleteFromServer") : "n";
        int childId= StringUtils.hasLength(request.getParameter(HD_CHILDID)) ? Integer.parseInt(request.getParameter(HD_CHILDID)) : 0;
        boolean delFlag = false;
        boolean localThumbdelFlag=false;
        boolean ServerThumbdelFlag=false;
        try {
        	if(session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
	        		List<Object[]> tblOfficerDocument= fileUploadService.getOfficerDocDetailsForRemove(docId);
	        		if(!tblOfficerDocument.isEmpty()){
		        		String filePath=docUploadPath+tblOfficerDocument.get(0)[3].toString();
		        		filePath=filePath.replace("\\", "\\\\");
		        		filePath += "\\"+tblOfficerDocument.get(0)[2].toString();
		        		if(cStatusDoc == officerDocStatusCancel || cStatusDoc == officerDocStatusApprove){
		        			delFlag = fileUploadService.updateOfficerDocDetailsForRemove(docId,cStatusDoc);
		        			if(cStatusDoc == officerDocStatusApprove){
		        				linkId=getLinkId((Integer)tblOfficerDocument.get(0)[5], officerDocStatusApprove,0);
		        				message=postAjaxDocumentApprove;
		        			}else{
		        				linkId=getLinkId((Integer)tblOfficerDocument.get(0)[5], officerDocStatusCancel,0);
		        				message=postAjaxDocumentCancel;
		        			}
		        		}else{
		        			File f = new File(filePath);
		        			f = abcUtility.CheckDirExist(f);
		        			if(f.exists()){
		        				delFlag = deleteFile(f.getPath());
		        			}
			        		if(isDeleteThumbFromLocal.equalsIgnoreCase("y")){//Thumb delete from local
			        			String localPath=docUploadPath+tblOfficerDocument.get(0)[3].toString();
			        			localPath=localPath.replace("\\", "\\\\");
			        			localPath += "\\"+THUMBNAIL_PREFIX+tblOfficerDocument.get(0)[2].toString();
			        			File file = new File(localPath);
			        			file = abcUtility.CheckDirExist(file);
			        			if(file.exists()){ 
			        				localThumbdelFlag=deleteFile(file.getPath());
			        			}
			        		}
			        		if(isDeleteFromServer.equalsIgnoreCase("y")){//original imag & Thumb delete from Apache Server
			        			String serverPath=logoserverpath+"\\"+request.getContextPath()+"\\"+sectorimagecontextpath+"\\"+tblOfficerDocument.get(0)[3].toString();//+"\\"+THUMBNAIL_PREFIX+tblOfficerDocument.get(0)[2].toString();
			        			serverPath=serverPath.replace("\\/", "\\");
			        			serverPath=serverPath.replace("\\", "\\");
			        			localThumbdelFlag=deleteFile(serverPath+"\\"+tblOfficerDocument.get(0)[2].toString());//original image from server
			        			localThumbdelFlag=deleteFile(serverPath+"\\"+THUMBNAIL_PREFIX+tblOfficerDocument.get(0)[2].toString());//Thumbnail image from server
			        		}
			                delFlag = fileUploadService.updateOfficerDocDetailsForRemove(docId,cStatusDoc);
			                
			        		linkId=getLinkId((Integer)tblOfficerDocument.get(0)[5], officerDocStatusReject,0);
		    				message=postAjaxDocumentRemove;
		        		}
	        		}
	        	response.getWriter().write(delFlag + "");
        	}else{
        		response.getWriter().write("sessionexpired");
        	}
          
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }finally {
        	if(abcUtility.getSessionIsPkiEnabled(request) == 1 && request.getHeader("Referer").contains(request.getContextPath()+"/etender") && (cStatusDoc == 1 || cStatusDoc == 3)){
        		makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, message, objectId, docId,message,signText);
        	}else{
        		makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, message, objectId, docId);
        	}
        }
    }

    /**
     * to download the file
     * @param docId
     * @param request
     * @param response
     * @param session
     */
    @RequestMapping(value = {"/ajax/downloadfile/{docId}/{objectId}/{enc}","/ajaxcall/downloadfile/{docId}/{objectId}"})
    public String downloadFile(@PathVariable(DOC_ID) int docId,@PathVariable(OBJECTID) int objectId,HttpServletRequest request,HttpServletResponse response,HttpSession session,RedirectAttributes redirectAttributes) {
    	ServletOutputStream outputStream = null;
    	String documentName = null;
        int userTypeId=0;
        InputStream fis=null;
        int linkId=0;
        int moduleId=0;
        int status=-1;
        String documentHashing = null;
        String hashComprareVal = "false";
        //ABC Flag to allow download file
        boolean allowDownload = false;
        int aLinkId = 0, aModuleId = 0;
        try {
        	String filePath=null;
        	String fileName=null;
        	Object sessionBean=session.getAttribute(SESSION_OBJECT);
        	userTypeId=sessionBean !=null ? ((SessionBean)session.getAttribute(SESSION_OBJECT)).getUserTypeId() : 0;
    		List<Object[]> tblOfficerDocument= fileUploadService.getOfficerDocDetailsForRemove(docId);
    		int isEncryptionReq=0;
    		if(!tblOfficerDocument.isEmpty()){
			aLinkId = (Integer)tblOfficerDocument.get(0)[5];
    			aModuleId = commonService.getModuleIdbyLinkId(aLinkId);
	    		linkId=getLinkId((Integer)tblOfficerDocument.get(0)[5], -1,0);
                        
	    		moduleId=commonService.getModuleIdbyLinkId(linkId);
	    		filePath=docUploadPath+tblOfficerDocument.get(0)[3].toString();
	    		filePath=filePath.replace("\\", "\\\\");
	    		filePath += "\\"+tblOfficerDocument.get(0)[2].toString();
	    		fileName=tblOfficerDocument.get(0)[2].toString();
	    		documentName = new String(fileName);
	    		status=Integer.parseInt(tblOfficerDocument.get(0)[4].toString());
	    		isEncryptionReq=(Integer)tblOfficerDocument.get(0)[6];
    		}
        		TblLink tblLink=commonService.getTblLink(linkId);
        		List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(tblLink.getTblEvent().getEventId(), abcUtility.getSessionClientId(request));
				TblDocUploadConf tblDocUploadConf=lstDocUploadConf.get(0);
			//ABC if usertypeId is zero that is no session
			if(userTypeId == 0) {
				allowDownload = fileUploadService.doAllowDownload(aLinkId, status, objectId, aModuleId);
			}else {
				allowDownload = true;
			}
		if(allowDownload) {
	            File file = null;
	            file = new File(filePath);
	            file = abcUtility.CheckDirExist(file);
	            if(file.exists()){
		            fis = new FileInputStream(file);
		            byte[] buf = new byte[(int) file.length()];
		            int offset = 0;
		            int numRead = 0;
		            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
		                offset += numRead;
		            }
	                    if(isEncryptionReq == 1){
	                    	buf = fileEncryptDecryptUtil.fileDecryptUtil(buf);
	                    }
	                    if(linkId == 255 || linkId == 378 || linkId == 376){
	                        documentHashing=fileEncryptDecryptUtil.bufferHashing(buf);
	        	            hashComprareVal = fileUploadService.compareHashValueByDocId(tblOfficerDocument.get(0)[1].toString(),documentHashing);
	                        }
	        	            //Hashvalue is verified then this case
	        	            if((linkId == 255 || linkId == 378 || linkId == 376) && hashComprareVal.equalsIgnoreCase("true")){
	        	            	response.setContentType("application/octet-stream");
	        		            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
	        		            outputStream = response.getOutputStream();
	        		            outputStream.write(buf);
	        		            outputStream.flush();
	        		            outputStream.close();
	        		            if (userTypeId == 2) {
	        		            	SessionBean sessionBean1=(SessionBean)sessionBean;
	        						TblDownloadDocHistory tblDownloadDocHistory=new TblDownloadDocHistory();
	        						tblDownloadDocHistory.setTblOfficerDocMapping(new TblOfficerDocMapping(docId));
	        						tblDownloadDocHistory.setTblTrackLogin(new TblTrackLogin(sessionBean1.getTrackLoginId()));
	        						fileUploadService.addDownloadDocHistory(tblDownloadDocHistory);
	        		            }
	        		            //General Case
	        	            }else if (linkId != 255 || linkId != 378 || linkId != 376){
					            response.setContentType("application/octet-stream");
					            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
					            outputStream = response.getOutputStream();
					            outputStream.write(buf);
					            outputStream.flush();
					            outputStream.close();
					            if (userTypeId == 2) {
					            	SessionBean sessionBean1=(SessionBean)sessionBean;
									TblDownloadDocHistory tblDownloadDocHistory=new TblDownloadDocHistory();
									tblDownloadDocHistory.setTblOfficerDocMapping(new TblOfficerDocMapping(docId));
									tblDownloadDocHistory.setTblTrackLogin(new TblTrackLogin(sessionBean1.getTrackLoginId()));
									fileUploadService.addDownloadDocHistory(tblDownloadDocHistory);
								}
				        	  }
	            			}
					}else {
				return "redirect:/pagenotfound";
			}
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }finally{
        	if(fis != null){
        		try {
					fis.close();
				} catch (IOException e) {
					//e.printStackTrace();
				}
        	}
        	if(allowDownload) {
        	String previousURL = request.getHeader("referer");
        	if(previousURL.contains("bidform") || previousURL.contains("uploaddocfortechenv"))
        	{	
        		Object tenderId = fileUploadService.getTenderIdByTableId(objectId);
        		if(tenderId != null)
        		{
        			objectId = (Integer) tenderId;	
        			makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getDownloadAuctionDocuments+" (Form/Table:"+documentName+")", objectId, docId);
        		}
        	}
        	else if(previousURL.contains("viewcorrigendum") || previousURL.contains("uploadcorrigendumdoc"))
        	{
        		Object tenderId = fileUploadService.getTenderIdByCorrigendumId(objectId);
        		if(tenderId != null)
        		{
        			objectId = (Integer) tenderId;
        			makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getDownloadAuctionDocuments+" (Corrigendum:"+documentName+")", objectId, docId);
        		}
        	}
        	else if((linkId == 255 || linkId == 378 || linkId == 376) && (hashComprareVal.equalsIgnoreCase("false")) && (previousURL.contains("bidder/downloadtenderdocuments") || previousURL.contains("bidder/documentsdownloadfortender"))){
        		redirectAttributes.addFlashAttribute("documentDownloadError", "msg_verification_failed");
        		redirectAttributes.addFlashAttribute("documentName", documentName);
        		return  "redirect:/etender/bidder/downloadtenderdocuments/" + objectId + encryptDecryptUtils.generateRedirect("etender/bidder/downloadtenderdocuments/" + objectId, request);
        	}
        	else
        	{
        		Object tenderId = fileUploadService.getTenderIdByCorrigendumId(objectId);
        		if(tenderId != null)
        		{
        			objectId = (Integer) tenderId;
        		}
        		makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getDownloadAuctionDocuments+" ("+documentName+")", objectId, docId);
        	}
        	}
        	//auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),userTypeId == 2 ? bidderDownloadDocument : documentDownload, getDownloadAuctionDocuments, objectId, docId);
        }
        return null;
    }
    
    /**
     * to download the bidder document
     * @param docId
     * @param request
     * @param response
     * @param session
     */
    @RequestMapping(value = {"/ajax/downloadbidderfile/{docId}/{objectId}/{enc}","/ajax/downloadbidderfile/{docId}/{objectId}"})
    public void downloadBidderFile(@PathVariable(DOC_ID) int docId,@PathVariable(OBJECTID) int objectId,HttpServletRequest request,HttpServletResponse response) {
        ServletOutputStream outputStream = null;
        InputStream fis=null;
        int linkId=0;
        int userTypeId=0;
        try {
        	String filePath=null;
        	String fileName=null;
    		List<Object[]> tblBidderDocument=fileUploadService.getBidderDocDetailsForRemove(docId);
    		 if(request.getSession().getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString())!=null){
    		  userTypeId=((SessionBean)request.getSession().getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString())).getUserTypeId();
    		 }else{
            	userTypeId=abcUtility.getSessionUserTypeId(request);
            	}
                int isEncryptionReq=0;
    		if(!tblBidderDocument.isEmpty()){
                        if(userTypeId == 2){
                            linkId=getLinkId((Integer)tblBidderDocument.get(0)[5],-1,userTypeId);
                        }else{
                            linkId=(Integer)tblBidderDocument.get(0)[5];
                        }
	    		filePath=docUploadPath+tblBidderDocument.get(0)[3].toString();
	    		filePath=filePath.replace("\\", "\\\\");
	    		filePath += "\\"+tblBidderDocument.get(0)[2].toString();
	    		fileName=tblBidderDocument.get(0)[2].toString();
	    		isEncryptionReq=(Integer)tblBidderDocument.get(0)[6];
    		}
    		TblLink tblLink=commonService.getTblLink(linkId);
    		List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(tblLink.getTblEvent().getEventId(), abcUtility.getSessionClientId(request));
    		TblDocUploadConf tblDocUploadConf=lstDocUploadConf.get(0);
            File file = null;
            file = new File(filePath);
            file = abcUtility.CheckDirExist(file);
            if(file.exists()){
	            fis = new FileInputStream(file);
	            byte[] buf = new byte[(int) file.length()];
	            int offset = 0;
	            int numRead = 0;
	            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
	                offset += numRead;
	            }
	            if(isEncryptionReq == 1){
	                buf = fileEncryptDecryptUtil.fileDecryptUtil(buf);
	            }
	            response.setContentType("application/octet-stream");
	            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
	            outputStream = response.getOutputStream();
	            outputStream.write(buf);
	            outputStream.flush();
	            outputStream.close();
	        }
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }finally{
        	if(fis != null){
        		try {
					fis.close();
				} catch (IOException e) {
				}
        	}
        	makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDownloadAuctionDocuments, objectId, docId);
        }
    }
 
    /**
     * to get uploaded document in the listing
     * @param request
     * @param response
     * @param session
     */
    @RequestMapping(value = {"/ajax/getuploadeddocs","/ajaxcall/getuploadeddocs"})
    public void getUploadedDocs(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
        
        /* String docIds = "";
        if (request.getParameter("docIds") != null) {
            docIds = request.getParameter("docIds");
        }*/
        List<Object[]> lstDocumentDetails = null;
        StringBuilder strDocList = new StringBuilder();
        int objectId=0;
        int linkId=0;
        int childId=0;
        int mappedBy=0;
        int userTypeId=0;
        int userId=0;
        boolean isSession=true;
        try {
        	Object sessionBean=session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
        	if(sessionBean != null){
        		  userTypeId=((SessionBean)sessionBean).getUserTypeId();
	        	  userId = ((SessionBean)sessionBean).getUserId();
	        	  isSession = true;
        	 }else if(session.getAttribute(SESSION_OBJECT)!=null){
        		 sessionBean=session.getAttribute(SESSION_OBJECT);
        	 	  userTypeId=sessionBean !=null ? ((SessionBean)session.getAttribute(SESSION_OBJECT)).getUserTypeId() : 0;
	        	  userId = abcUtility.getSessionUserId(request);
	        	  isSession = true;
        	 }
        	 if(isSession){
        	objectId=StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0; 
        	childId=StringUtils.hasLength(request.getParameter(HD_CHILDID)) ? Integer.parseInt(request.getParameter(HD_CHILDID)) : 0;
        	mappedBy=StringUtils.hasLength(request.getParameter(TXT_MAPPEDBY)) ? Integer.parseInt(request.getParameter(TXT_MAPPEDBY)) : 0;
        	linkId=StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? Integer.parseInt(request.getParameter(TXT_LINKID)) : 0;
        	String isUploadToClientDir=StringUtils.hasLength(request.getParameter("txtuploadToClientDir")) ? request.getParameter("txtuploadToClientDir") : "n";
        	if(objectId==0 && linkId==0){
        		objectId=StringUtils.hasLength(request.getParameter("hdObjectId")) ? Integer.parseInt(request.getParameter("hdObjectId")) : 0; 
            	linkId=StringUtils.hasLength(request.getParameter("hdLinkId")) ? Integer.parseInt(request.getParameter("hdLinkId")) : 0;
        	}
        	String docIds=StringUtils.hasLength(request.getParameter(TXT_DOCID)) ? request.getParameter(TXT_DOCID).replace("<PRE>", "").replace("</PRE>", "") : "0";
        	int clientId=abcUtility.getSessionClientId(request);
        	if("Y".equalsIgnoreCase(isUploadToClientDir)){// in case of neft upload vendor data document should download from selected client directory
           	 clientId=objectId; 
            }
        	int cStatusDoc=0;
        	int status=0;
        	String hashVal = "";
        	String isReadOnly=StringUtils.hasLength(request.getParameter("txtisReadOnly")) ? request.getParameter("txtisReadOnly"): null;
                String txtDisplayStatusColumn=StringUtils.hasLength(request.getParameter("txtDisplayStatusColumn")) ? request.getParameter("txtDisplayStatusColumn"): "";
        	String isAuctionDocDownload=StringUtils.hasLength(request.getParameter("txtisAuctionDocDownload")) ? request.getParameter("txtisAuctionDocDownload"): null;
        	String isBidderDocDownload=StringUtils.hasLength(request.getParameter("txtisBidderDocDownload")) ? request.getParameter("txtisBidderDocDownload"): "";
            cStatusDoc = StringUtils.hasLength(request.getParameter(CSTATUS_DOC)) ? Integer.parseInt(request.getParameter(CSTATUS_DOC)) : 0;
            int cStatusDocView=StringUtils.hasLength(request.getParameter(CSTATUS_DOCVIEW)) ? Integer.parseInt(request.getParameter(CSTATUS_DOCVIEW)) : -1;
            //Added By Lipi - Bug #19523 Start
            int downloadDocument = StringUtils.hasLength(request.getParameter("txtdownloadDocument")) ? Integer.parseInt(request.getParameter("txtdownloadDocument")) : 0;
            String startDate = StringUtils.hasLength(request.getParameter("txtstartDate")) ? request.getParameter("txtstartDate") : null;
            String endDate = StringUtils.hasLength(request.getParameter("txtendDate")) ? request.getParameter("txtendDate") : null;
            String clientName = clientService.getClientNameById(clientId);
            int companyId=commonService.getCompanyId(userId, clientId);
        	boolean isPaymentDone=fileUploadService.isPaymentDone(1, objectId, companyId);
        	int showCreatedBy=StringUtils.hasLength(request.getParameter("showCreatedBy")) ? Integer.parseInt(request.getParameter("showCreatedBy")) : 0;
        	boolean isBidDocs = false;
            //End
            if(cStatusDocView == -1){
	            if(cStatusDoc == bidderDocStatusApprove || cStatusDoc == officerDocStatusApprove || cStatusDoc == bidderDocStatusPending || cStatusDoc == officerDocStatusPending){
	            	status=officerDocStatusPending;
	            }else if(cStatusDoc == bidderDocStatusCancel || cStatusDoc == officerDocStatusCancel){
	            	status=officerDocStatusApprove;
	            }else if(cStatusDoc < 0){
	            	status=cStatusDoc;
	            }else{
                       status=cStatusDocView; 
                }
            }else{
            	status=cStatusDocView;
            }
        	if((userTypeId ==1 || userTypeId == 3 || "Y".equalsIgnoreCase(isAuctionDocDownload)) && !"Y".equalsIgnoreCase(isBidderDocDownload)){
        		if(objectId!=0){
        			if(childId!=0 && mappedBy!=0){
        				lstDocumentDetails =fileUploadService.getOfficerDocsDynamic(String.valueOf(objectId),String.valueOf(childId),String.valueOf(clientId),String.valueOf(linkId),String.valueOf(status),String.valueOf(mappedBy)); /*Changes Bug Id #28102*/
        			}else if(childId > 0){
        				lstDocumentDetails=fileUploadService.getOfficerDocs(objectId,childId,clientId, linkId,status);
        			}
        			else{
        				lstDocumentDetails=fileUploadService.getOfficerDocs(objectId, clientId, linkId,status);
        			}
        		}else{
        			lstDocumentDetails=fileUploadService.getOfficerDocs(objectId, clientId, linkId,status,docIds);
        		}
        		if((userTypeId ==1 || userTypeId == 3) && request.getHeader("referer").contains("etender")){
            		List<Object[]> corDocumentDetails = fileUploadService.getOfficerAllNoticeDocsAfterCorrigendum(objectId, clientId,request,lstDocumentDetails);
            		if(corDocumentDetails!=null && !corDocumentDetails.isEmpty() && corDocumentDetails.size()>0)
            			lstDocumentDetails=corDocumentDetails;
            	}
        	}else if(userTypeId == 2 || "Y".equalsIgnoreCase(isBidderDocDownload)){
        		isBidDocs = true;
                userId="Y".equalsIgnoreCase(isBidderDocDownload) ? 0 : userId;
        		if(objectId!=0){
        			lstDocumentDetails=fileUploadService.getBidderDocs(objectId, clientId, linkId,status,mappedBy!=0? mappedBy : userId);
        		}else if(childId > 0){
    				lstDocumentDetails=fileUploadService.getBidderDocsWithChildId(objectId, clientId, linkId,status,userId,docIds,childId);
    			}else if(childId == -1){
    				lstDocumentDetails=fileUploadService.getBidderDocsWithChildId(objectId, clientId, linkId,status,userId,docIds,childId);
    			}
        		else{
        			lstDocumentDetails=fileUploadService.getBidderDocs(objectId, clientId, linkId,status,userId,docIds);
        		}
        	}
            strDocList.append("     <tr class='gradi border-right'>");
            strDocList.append("         <th width='10%'>").append(messageSource.getMessage("column_srno", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='18%' class='a-center'>").append(messageSource.getMessage("fields_document", null, LocaleContextHolder.getLocale())).append("</th>");
	        if(!isBidDocs && linkId!=Integer.parseInt(prominentReportLinkId)){
	        	strDocList.append("         <th width='18%' class='a-left'>").append(messageSource.getMessage("field_hash", null, LocaleContextHolder.getLocale())).append("</th>");
	        }
            if(linkId!=Integer.parseInt(bidderBlacklistLinkId)){
            	strDocList.append("         <th width='20%' class='a-center'>").append(messageSource.getMessage("fields_docBrief", null, LocaleContextHolder.getLocale())).append("</th>");
            }	
            /*strDocList.append("         <th width='15%' class='a-left'>").append(messageSource.getMessage("col_size", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='16%' class='a-left'>").append(messageSource.getMessage("coloumn_datetime", null, LocaleContextHolder.getLocale())).append("</th>");
            */
            if(linkId!=Integer.parseInt(prominentReportLinkId)) {
            strDocList.append("         <th width='15%' class='a-left'>").append(messageSource.getMessage("col_size", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='16%' class='a-left'>").append(messageSource.getMessage("coloumn_datetime", null, LocaleContextHolder.getLocale())).append("</th>");
            }
            if(showCreatedBy == 1){
            	strDocList.append("         <th width='16%' class='a-left'>").append(messageSource.getMessage("coloumn_uploaded_by", null, LocaleContextHolder.getLocale())).append("</th>");
            }
            if(!txtDisplayStatusColumn.equalsIgnoreCase("N") && linkId!=enlistmentOfficerDocLinkId && linkId!=Integer.parseInt(bidderBlacklistLinkId) && linkId!=Integer.parseInt(prominentReportLinkId))
            {
            	strDocList.append("         <th width='10%' class='a-left'>").append(messageSource.getMessage("coloumn_status", null, LocaleContextHolder.getLocale())).append("</th>");
            }
            strDocList.append("         <th width='19%' class='a-centr'>").append(messageSource.getMessage("column_action", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("     </tr>");
                if (lstDocumentDetails != null && !lstDocumentDetails.isEmpty()) {
	                for (int i=0;i<lstDocumentDetails.size();i++) {
	                	if(lstDocumentDetails.get(i)!=null && lstDocumentDetails.get(i).length>=9 && lstDocumentDetails.get(i)[9].toString().contains("AuctionNoticeDetailsDocs"))
	                		continue;
	                    strDocList.append("     <tr id='fli_").append(lstDocumentDetails.get(i)[0]).append("'>");
	                    strDocList.append("         <td class='a-center'>");
	                    strDocList.append(i+1);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td class='word-break'>");
	                    strDocList.append(lstDocumentDetails.get(i)[1]);
	                    strDocList.append("</td>");
	                    if(!isBidDocs && linkId!=Integer.parseInt(prominentReportLinkId)){
	                    	hashVal = fileUploadService.getHashValueByDocId(lstDocumentDetails.get(i)[6].toString());
	                    	strDocList.append("         <td>");
	                    	if(hashVal!=null && !hashVal.equals("")){
	                    		strDocList.append("<div class='hash-div' id='idhashPopup_"+i+"'>SHA-256<img  class='has-div-img' src='/GAIL/resources/template/template1/images/hash-icon.png'/>  <div class='pophash' id='pophashId_"+i+"'> "+hashVal+" </div></div>");/* CSP BEFORE LOGIN */
	                    	}else{
	                    		strDocList.append("-");
	                    	}
	                    	strDocList.append("</td>");
	                    }
	                    if(linkId!=Integer.parseInt(bidderBlacklistLinkId))
	                    {
	                    	strDocList.append("         <td class='word-break line-height'>");
	                    	strDocList.append(breakString(lstDocumentDetails.get(i)[2].toString()));
	                    	strDocList.append("</td>");
	                    }
	                    if(linkId!=Integer.parseInt(prominentReportLinkId)){
	                    strDocList.append("         <td>");
	                    //strDocList.append(new BigDecimal(Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024)).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue());
	                    String fileSizeString=String.format("%.3f", Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024));
	                    strDocList.append("0.000".equals(fileSizeString) ? "0.001" : fileSizeString);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    strDocList.append(CommonUtility.convertTimezone(lstDocumentDetails.get(i)[4]));
	                    strDocList.append("</td>");
	                    if(showCreatedBy == 1){
	                    	strDocList.append("         <td>");
		                    //strDocList.append(lstDocumentDetails.get(i)[8].toString());departmentUserService
	                    	strDocList.append(departmentUserService.getUserName(Integer.parseInt(lstDocumentDetails.get(i)[8].toString())).get(0));
		                    strDocList.append("</td>");
		            	}
	                    }   
	                    if(!txtDisplayStatusColumn.equalsIgnoreCase("N") && linkId!=enlistmentOfficerDocLinkId && linkId!=Integer.parseInt(bidderBlacklistLinkId)&& linkId!=Integer.parseInt(prominentReportLinkId))
	                    {
	                    strDocList.append("         <td>");
                               if((Integer)lstDocumentDetails.get(i)[5] == 1){
                                    strDocList.append(messageSource.getMessage("label_approved", null, LocaleContextHolder.getLocale()));
                                }else if((Integer)lstDocumentDetails.get(i)[5] == 3){
                                    strDocList.append(messageSource.getMessage("label_cancelled", null, LocaleContextHolder.getLocale()));
                                }
                                else if((Integer)lstDocumentDetails.get(i)[5] == 0){
                                    strDocList.append(messageSource.getMessage("label_pending", null, LocaleContextHolder.getLocale()));
                                }
                            
	                    strDocList.append("</td>");
                            }
	                   // if(isActionColumnShow){
		                    if(isReadOnly == null){
//			                    strDocList.append("         <td width='9%' style=\"padding: 5px;\">");
		                    	strDocList.append(" <td id='td_").append(i).append("' class='a-center' style=\"padding: 5px;\">");
			                    strDocList.append(" <input type='hidden' id='txtSignDoc_"+lstDocumentDetails.get(i)[0]).append("' name='txtSignDoc_").append(lstDocumentDetails.get(i)[0]).append("' value='").append(lstDocumentDetails.get(i)[1]).append("").append(lstDocumentDetails.get(i)[2]).append("").append(lstDocumentDetails.get(i)[4]).append("' />");
			                    if(cStatusDoc == bidderDocStatusPending || cStatusDoc == officerDocStatusPending ||  cStatusDoc > 3){
				                    strDocList.append("<a href='javascript:void(0);' onclick=\"removeFile('");
				                    strDocList.append(lstDocumentDetails.get(i)[0]);
				                    strDocList.append("','").append((userTypeId == 1 || userTypeId ==3 ? officerDocStatusReject : bidderDocStatusReject)).append("');\">");
				                    strDocList.append(messageSource.getMessage("link_delete", null, LocaleContextHolder.getLocale())).append("</a>  | ");
				                    if(cStatusDoc == 4 && Integer.parseInt(lstDocumentDetails.get(i)[5].toString()) == 0){
				                    	strDocList.append("<a href='").append(request.getContextPath()).append("/common/admin/mapvendorcode/").append(objectId);
				                    	strDocList.append("/").append(lstDocumentDetails.get(i)[0]).append("/").append(encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[1].toString()));
				                    	strDocList.append(encryptDecryptUtils.generateRedirect("common/admin/mapvendorcode/"+objectId+"/"+lstDocumentDetails.get(i)[0]+"/"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[1].toString()), request));
				                    	strDocList.append("' >");
					                    strDocList.append(messageSource.getMessage("link_map", null, LocaleContextHolder.getLocale())).append("</a>  | ");
				                    }else if(cStatusDoc == 4 && Integer.parseInt(lstDocumentDetails.get(i)[5].toString()) == 1){
				                    	strDocList.append(messageSource.getMessage("lbl_mapped", null, LocaleContextHolder.getLocale()));
                                    }
			                    }else if((cStatusDoc == bidderDocStatusApprove || cStatusDoc == officerDocStatusApprove) && linkId!=427 && linkId!=Integer.parseInt(bidderBlacklistLinkId)){
			                    	strDocList.append("<a href='javascript:void(0);' onclick=\"removeFile('");
				                    strDocList.append(lstDocumentDetails.get(i)[0]);
				                    strDocList.append("','").append((userTypeId == 1 || userTypeId ==3 ? officerDocStatusApprove : bidderDocStatusApprove)).append("');\">");
				                    strDocList.append(messageSource.getMessage("link_approve", null, LocaleContextHolder.getLocale())).append("</a>  | ");
			                    }else if(cStatusDoc == bidderDocStatusCancel || cStatusDoc == officerDocStatusCancel){
			                    	strDocList.append("<a href='javascript:void(0);' onclick=\"removeFile('");
				                    strDocList.append(lstDocumentDetails.get(i)[0]);
				                    strDocList.append("','").append((userTypeId == 1 || userTypeId ==3 ? officerDocStatusCancel : bidderDocStatusCancel)).append("');\">");
				                    strDocList.append(messageSource.getMessage("link_cancel", null, LocaleContextHolder.getLocale())).append("</a>  | ");
			                    }
			                    if(sessionBean == null){
			                    	//Added By Lipi - Bug #19523 add downloadDocument and date Condition
			                    	if(downloadDocument ==2){
					                    strDocList.append(messageSource.getMessage("msg_document_download_afterlogin", new Object[]{clientName}, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else if(startDate !=null && dateUtils.convertStringtoDate(startDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) > 0){
					                    strDocList.append(messageSource.getMessage("msg_document_download_startdate", new Object[]{CommonUtility.convertTimezone(startDate)}, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else if(endDate !=null && dateUtils.convertStringtoDate(endDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) < 0){
					                    strDocList.append(messageSource.getMessage("msg_document_download_enddate", null, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
		                    			//Nikhil Cancel doc code
		                    			strDocList.append("-");
		                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                        //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                        //strDocList.append(">");
                                        //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                        strDocList.append("</td>");
		                    		}else{
		                    			strDocList.append(" <a href=").append(request.getContextPath()).append("/ajaxcall/downloadfile/");
		                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                        strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                        strDocList.append(" onclick=\"return checkDocStatus("+lstDocumentDetails.get(i)[0]+");\" >");
                                        strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                        strDocList.append("</td>");
		                    		}
			                    }else if(userTypeId ==1 || userTypeId == 3 || "Y".equalsIgnoreCase(isAuctionDocDownload)){
			                    	/* Bug #19715
			                    	 * if(downloadDocument ==2){
					                    strDocList.append(messageSource.getMessage("msg_document_download_afterlogin", new Object[]{clientName}, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else*/ if(startDate !=null && dateUtils.convertStringtoDate(startDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) > 0){
					                    strDocList.append(messageSource.getMessage("msg_document_download_startdate", new Object[]{CommonUtility.convertTimezone(startDate)}, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else if(endDate !=null && dateUtils.convertStringtoDate(endDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) < 0){
					                    strDocList.append(messageSource.getMessage("msg_document_download_enddate", null, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
		                    			//Nikhil Cancel doc code
		                    			strDocList.append("-");
		                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                        //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                        //strDocList.append(">");
                                        //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                        strDocList.append("</td>");
		                    		}else{        
		                    			strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadfile/");
		                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
		                    			strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
		                    			strDocList.append(" onclick=\"return checkDocStatus("+lstDocumentDetails.get(i)[0]+");\" >");
		                    			strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
		                    			strDocList.append("</td>");
		                    		}
			                    } else{
			                    	if(userTypeId ==2){
			                    		/*if(downloadDocument ==2){
						                    strDocList.append(messageSource.getMessage("msg_document_download_afterlogin", new Object[]{clientName}, LocaleContextHolder.getLocale()));
						                    strDocList.append("</td>");
			                    		}else*/ if(startDate !=null && dateUtils.convertStringtoDate(startDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) > 0){
						                    strDocList.append(messageSource.getMessage("msg_document_download_startdate", new Object[]{CommonUtility.convertTimezone(startDate)}, LocaleContextHolder.getLocale()));
						                    strDocList.append("</td>");
			                    		}else if(endDate !=null && dateUtils.convertStringtoDate(endDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) < 0){
						                    strDocList.append(messageSource.getMessage("msg_document_download_enddate", null, LocaleContextHolder.getLocale()));
						                    strDocList.append("</td>");
			                    		}else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
			                    			//Nikhil Cancel doc code
			                    			strDocList.append("-");
			                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
	                                        //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
	                                        //strDocList.append(">");
	                                        //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
	                                        strDocList.append("</td>");
			                    		}else{
			                    			strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadbidderfile/");
			                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
			                    			strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadbidderfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
			                    			strDocList.append(" onclick=\"return checkDocStatus("+lstDocumentDetails.get(i)[0]+");\" >");
			                    			strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
			                    			strDocList.append("</td>");
			                    		}
			                    	}
		                    }
	                    }else{                                     
	                    	if(sessionBean == null){
	                    		if(downloadDocument ==2){
	                    			strDocList.append(" <td id='td_").append(i).append("' > ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_afterlogin", new Object[]{clientName}, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if(startDate !=null && dateUtils.convertStringtoDate(startDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) > 0){
	                    			strDocList.append(" <td id='td_").append(i).append("' class='a-center'> ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_startdate", new Object[]{CommonUtility.convertTimezone(startDate)}, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if(endDate !=null && dateUtils.convertStringtoDate(endDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) < 0){
	                    			strDocList.append(" <td id='td_").append(i).append("' class='a-center'> ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_enddate", null, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if(downloadDocument == 3 && !isPaymentDone){
	                    			strDocList.append(" <td id='td_").append(i).append("' > ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_afterpayment", null, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
	                    			//Nikhil Cancel doc code
	                    			strDocList.append(" <td class='a-center' id='td_").append(i).append("' > ");
	                    			strDocList.append("-");
	                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                    //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                    //strDocList.append(">");
                                    //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                    strDocList.append("</td>");
	                    		}else{
	                    			strDocList.append(" <td class='a-center'> <a href=").append(request.getContextPath()).append("/ajaxcall/downloadfile/");
	                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
	                    			strDocList.append(" id=\"idcheckDocStatus_"+lstDocumentDetails.get(i)[0]+"\" class ='download-div'>");/* CSP BEFORE LOGIN */
	                    			strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
	                    			strDocList.append("</td>");
	                    		}
		                    }
	                    	else if((userTypeId ==1 || userTypeId == 3 || "Y".equalsIgnoreCase(isAuctionDocDownload)) && !"Y".equalsIgnoreCase(isBidderDocDownload)){
	                    		/*if(downloadDocument ==2){
	                    			strDocList.append(" <td id='td_").append(i).append("' class='a-center'> ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_afterlogin", new Object[]{clientName}, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else */if(downloadDocument ==3 && !isPaymentDone){
	                    			strDocList.append(" <td id='td_").append(i).append("' > ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_afterpayment", null, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if(startDate !=null && dateUtils.convertStringtoDate(startDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) > 0){
	                    			strDocList.append(" <td id='td_").append(i).append("' > ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_startdate", new Object[]{CommonUtility.convertTimezone(startDate)}, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if(endDate !=null && dateUtils.convertStringtoDate(endDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) < 0){
	                    			strDocList.append(" <td id='td_").append(i).append("' > ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_enddate", null, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
	                    			//Nikhil Cancel doc code
	                    			strDocList.append(" <td class='a-center' id='td_").append(i).append("' > ");
	                    			strDocList.append("-");
	                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                    //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                    //strDocList.append(">");
                                    //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                    strDocList.append("</td>");
	                    		}else{
	                    			strDocList.append("         <td width='9%' style=\"padding: 5px;\">");
	                    			// STQC Change
	                    			if((Integer)lstDocumentDetails.get(i)[5] == 0){
	                    				strDocList.append("<a href='javascript:void(0);' onclick=\"removeFile('");
					                    strDocList.append(lstDocumentDetails.get(i)[0]);
					                    strDocList.append("','").append((userTypeId == 1 || userTypeId ==3 ? officerDocStatusReject : bidderDocStatusReject)).append("');\">");
					                    strDocList.append(messageSource.getMessage("link_delete", null, LocaleContextHolder.getLocale())).append("</a>  | ");
	                    			}
	                    			strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadfile/");
	                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
	                    			strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
	                    			strDocList.append(" onclick=\"return checkDocStatus("+lstDocumentDetails.get(i)[0]+");\" >");
	                    			strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
	                    			strDocList.append("</td>");
	                    		}
	                    	}else{
	                    		if(userTypeId == 2 || "Y".equalsIgnoreCase(isBidderDocDownload)){
	                    			/*if(downloadDocument == 2){
		                    			strDocList.append(" <td id='td_").append(i).append("' class='a-center'> ");
					                    strDocList.append(messageSource.getMessage("msg_document_download_afterlogin", new Object[]{clientName}, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else*/ if(downloadDocument == 3 && !isPaymentDone){
		                    			strDocList.append(" <td id='td_").append(i).append("' > ");
					                    strDocList.append(messageSource.getMessage("msg_document_download_afterpayment", null, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else if(startDate != null && dateUtils.convertStringtoDate(startDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) > 0){
		                    			strDocList.append(" <td id='td_").append(i).append("' > ");
					                    strDocList.append(messageSource.getMessage("msg_document_download_startdate", new Object[]{CommonUtility.convertTimezone(startDate)}, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else if(endDate != null && dateUtils.convertStringtoDate(endDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) < 0){
		                    			strDocList.append(" <td id='td_").append(i).append("' > ");
					                    strDocList.append(messageSource.getMessage("msg_document_download_enddate", null, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
		                    			//Nikhil Cancel doc code
		                    			strDocList.append(" <td class='a-center' id='td_").append(i).append("' > ");
		                    			strDocList.append("-");
		                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                        //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                        //strDocList.append(">");
                                        //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                        strDocList.append("</td>");
		                    		}else{
		                    			strDocList.append("         <td width='9%' style=\"padding: 5px;\">");
		                    			strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadbidderfile/");
		                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
		                    			strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadbidderfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
		                    			strDocList.append(" onclick=\"return checkDocStatus("+lstDocumentDetails.get(i)[0]+");\" >");
		                    			strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
		                    			strDocList.append("</td>");
		                    		}
	                    		}
	                    	}
	                    }
                      // }
	                    strDocList.append("</tr>");
                }
            }else{
            	strDocList.append(" <tr> <td colspan='7' align='center'>").append(messageSource.getMessage("empty_records", null, LocaleContextHolder.getLocale())).append("</td></tr>");
            }
            response.getWriter().write(strDocList.toString());
        	 }else{
        		 response.getWriter().write("Error:sessionexpired".toString());
        	 }
        	 } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
//        finally{
//        	auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDocumentDetails, objectId, 0);
//        }
    }
    /**
     * to get uploaded document with child id.
     * @author purvesh
     * @param request
     * @param response
     * @param session
     */
    @RequestMapping(value = "/ajax/getofficeruploadeddocschildid")
    public void getOfficerUploadedDocsChildId(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
    	List<Object[]> lstDocumentDetails = null;
        StringBuilder strDocList = new StringBuilder();
        int objectId=0;
        int linkId=0;
        int colSpan=6;
        try {
        	objectId=StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0; 
        	linkId=StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? Integer.parseInt(request.getParameter(TXT_LINKID)) : 0;
        	int childId= StringUtils.hasLength(request.getParameter(HD_CHILDID)) ? Integer.parseInt(request.getParameter(HD_CHILDID)) : 0;
       
        	int clientId=abcUtility.getSessionClientId(request);
        	int cStatusDoc=0;
            String txtDisplayStatusColumn=StringUtils.hasLength(request.getParameter("txtDisplayStatusColumn")) ? request.getParameter("txtDisplayStatusColumn"): "";
            cStatusDoc = StringUtils.hasLength(request.getParameter(CSTATUS_DOC)) ? Integer.parseInt(request.getParameter(CSTATUS_DOC)) : 0;
            int cStatusDocView=StringUtils.hasLength(request.getParameter(CSTATUS_DOCVIEW)) ? Integer.parseInt(request.getParameter(CSTATUS_DOCVIEW)) : -1;
        	lstDocumentDetails=fileUploadService.getOfficerDocs(objectId, childId,clientId, linkId, 1);
        	strDocList.append("     <tr class='gradi border-right'>");
            strDocList.append("         <th width='5%'>").append(messageSource.getMessage("column_srno", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='18%' class='a-left'>").append(messageSource.getMessage("fields_document", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='20%' class='a-left'>").append(messageSource.getMessage("fields_docBrief", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='10%' class='a-left'>").append(messageSource.getMessage("col_size", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='16%' class='a-left'>").append(messageSource.getMessage("coloumn_datetime", null, LocaleContextHolder.getLocale())).append("</th>");
            if(!txtDisplayStatusColumn.equalsIgnoreCase("N") && linkId!=enlistmentOfficerDocLinkId)
            {
            	strDocList.append("         <th width='10%' class='a-left'>").append(messageSource.getMessage("coloumn_status", null, LocaleContextHolder.getLocale())).append("</th>");
            	colSpan=7;
            }
            strDocList.append("         <th width='19%' class='a-left'>").append(messageSource.getMessage("column_action", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("     </tr>");
            if(lstDocumentDetails!=null && !lstDocumentDetails.isEmpty()){
            	int srno = 1;
            	for(Object[] objDocs : lstDocumentDetails){
	            	strDocList.append("     <tr class='border-right'>");
	            	strDocList.append("        <td>").append(srno).append("</td>");
	            	strDocList.append("        <td>").append(objDocs[1]).append("</td>");
	            	strDocList.append("        <td>").append(objDocs[2]).append("</td>");
	            	String fileSizeString=String.format("%.3f", Double.parseDouble(objDocs[3].toString())/(1024*1024));
	            	strDocList.append("        <td>").append("0.000".equals(fileSizeString) ? "0.001" : fileSizeString).append("</td>");
	            	strDocList.append("        <td>").append(CommonUtility.convertTimezone(objDocs[4])).append("</td>");
	            	if(!txtDisplayStatusColumn.equalsIgnoreCase("N") && linkId!=enlistmentOfficerDocLinkId)
	                {
		            	strDocList.append("         <td>");
	                    if((Integer)objDocs[5] == 1){
	                    strDocList.append(messageSource.getMessage("label_approved", null, LocaleContextHolder.getLocale()));
	                    }else if((Integer)objDocs[5] == 3){
	                    strDocList.append(messageSource.getMessage("label_cancelled", null, LocaleContextHolder.getLocale()));
	                    }
	                    else if((Integer)objDocs[5] == 0){
	                    strDocList.append(messageSource.getMessage("label_pending", null, LocaleContextHolder.getLocale()));
	                    }
	                    strDocList.append("</td>");
	                }
	            	strDocList.append("        <td><a href=").append(request.getContextPath()).append("/ajax/downloadfile/");
        			strDocList.append(					objDocs[0]).append("/").append(objectId);
        			strDocList.append(					encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+objDocs[0]+"/"+objectId, request)).append(">");
        			strDocList.append(					messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a> ");
        			strDocList.append("				<br/><a href='javascript:void(0);' class='removeFile' onclick=\"removeFile('").append(objDocs[0]).append("');\">");
        			strDocList.append(					messageSource.getMessage("link_remove", null, LocaleContextHolder.getLocale())).append("</a> ");;
        			strDocList.append("			</td>"); 
	            	strDocList.append("     </tr>");
	            	srno++;
            	}
            }
            else{
            	strDocList.append(" <tr> <td colspan='").append(colSpan).append("'>").append(messageSource.getMessage("empty_records", null, LocaleContextHolder.getLocale())).append("</td></tr>");
            }
            response.getWriter().write(strDocList.toString());
    } catch (Exception ex) {
        exceptionHandlerService.writeLog(ex);
    }
//    finally{
//    	auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDocumentDetails, objectId, 0);
//    }
}
    /**
     * to get download document in the listing
     * @author dharmesh
     * @param request
     * @param response
     * @param session
     */
    @RequestMapping(value = "/ajax/getDownloadDocsWithChildId")
    public void getDownloadDocsWithChildId(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
      
        List<Object[]> lstDocumentDetails = null;
        StringBuilder strDocList = new StringBuilder();
        int objectId=0;
        int linkId=0;
        try {
        	objectId=StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0; 
        	linkId=StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? Integer.parseInt(request.getParameter(TXT_LINKID)) : 0;
        	int childId= StringUtils.hasLength(request.getParameter(HD_CHILDID)) ? Integer.parseInt(request.getParameter(HD_CHILDID)) : 0;
       
        	int clientId=abcUtility.getSessionClientId(request);
        	int cStatusDoc=0;
            String txtDisplayStatusColumn=StringUtils.hasLength(request.getParameter("txtDisplayStatusColumn")) ? request.getParameter("txtDisplayStatusColumn"): "";
            cStatusDoc = StringUtils.hasLength(request.getParameter(CSTATUS_DOC)) ? Integer.parseInt(request.getParameter(CSTATUS_DOC)) : 0;
            int cStatusDocView=StringUtils.hasLength(request.getParameter(CSTATUS_DOCVIEW)) ? Integer.parseInt(request.getParameter(CSTATUS_DOCVIEW)) : -1;
          
        	lstDocumentDetails=fileUploadService.getOfficerDocs(objectId, childId,clientId, linkId, 1);
        	ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            strDocList.append("     <tr class='gradi border-right'>");
            strDocList.append("         <th width='5%'>").append(messageSource.getMessage("column_srno", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='18%' class='a-left'>").append(messageSource.getMessage("fields_auc_docname", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='15%' class='a-left'>").append(messageSource.getMessage("fields_auc_docbrief", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='10%' class='a-left'>").append(messageSource.getMessage("col_size", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='16%' class='a-left'>").append(messageSource.getMessage("coloumn_datetime", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='19%' class='a-center'>").append(messageSource.getMessage("column_action", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("     </tr>");
                if (lstDocumentDetails != null && !lstDocumentDetails.isEmpty()) {
	                for (int i=0;i<lstDocumentDetails.size();i++) {
	
	                    strDocList.append("     <tr id='fli_").append(lstDocumentDetails.get(i)[0]).append("'>");
	                    strDocList.append("         <td class='a-center'>");
	                    strDocList.append(i+1);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    strDocList.append(lstDocumentDetails.get(i)[1]);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    strDocList.append(breakString(lstDocumentDetails.get(i)[2].toString()));
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    //strDocList.append(new BigDecimal(Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024)).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue());
	                    String fileSizeString=String.format("%.3f", Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024));
	                    strDocList.append("0.000".equals(fileSizeString) ? "0.001" : fileSizeString);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    strDocList.append(CommonUtility.convertTimezone(lstDocumentDetails.get(i)[4]));
	                    strDocList.append("</td>");
	                    strDocList.append("        <td class='a-center'><a href=").append(request.getContextPath()).append("/ajax/downloadfile/");
	        			strDocList.append(					lstDocumentDetails.get(i)[0]).append("/").append(objectId);
	        			strDocList.append(					encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request)).append(">");
	        			strDocList.append(					messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a> </td>");
	                    strDocList.append("</tr>");
	                
                }
            }else{
            	strDocList.append(" <tr> <td colspan='5'>").append(messageSource.getMessage("empty_records", null, LocaleContextHolder.getLocale())).append("</td></tr>");
            }
            response.getWriter().write(strDocList.toString());
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
//        finally{
//        	auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDocumentDetails, objectId, 0);
//        }
    }
    /**
     * to get uploaded document in the listing
     * @author mitesh
     * @param request
     * @param response
     * @param session
     */
    @RequestMapping(value = "/ajax/getuploadeddocsWithChildId")
    public void getUploadedDocsWithChildId(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
      
        List<Object[]> lstDocumentDetails = null;
        StringBuilder strDocList = new StringBuilder();
        int objectId=0;
        int linkId=0;
        try {
        	objectId=StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0; 
        	linkId=StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? Integer.parseInt(request.getParameter(TXT_LINKID)) : 0;
        	int childId= StringUtils.hasLength(request.getParameter(HD_CHILDID)) ? Integer.parseInt(request.getParameter(HD_CHILDID)) : 0;
       
        	int clientId=abcUtility.getSessionClientId(request);
        	int cStatusDoc=0;
            String txtDisplayStatusColumn=StringUtils.hasLength(request.getParameter("txtDisplayStatusColumn")) ? request.getParameter("txtDisplayStatusColumn"): "";
            cStatusDoc = StringUtils.hasLength(request.getParameter(CSTATUS_DOC)) ? Integer.parseInt(request.getParameter(CSTATUS_DOC)) : 0;
            int cStatusDocView=StringUtils.hasLength(request.getParameter(CSTATUS_DOCVIEW)) ? Integer.parseInt(request.getParameter(CSTATUS_DOCVIEW)) : -1;
          
        	lstDocumentDetails=fileUploadService.getOfficerDocs(objectId, childId,clientId, linkId, 1);
        	ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
 			Integer sectorOffcerDocId=sectorService.getOfficerDocIdfromSector(clientBean.getSectorTableName(), childId);
            strDocList.append("     <tr class='gradi border-right'>");
            strDocList.append("         <th width='5%'>").append(messageSource.getMessage("column_srno", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='18%' class='a-left'>").append(messageSource.getMessage("fields_image_name", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='15%' class='a-left'>").append(messageSource.getMessage("fields_imageBrief", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='10%' class='a-left'>").append(messageSource.getMessage("col_size", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='16%' class='a-left'>").append(messageSource.getMessage("coloumn_datetime", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='19%' class='a-center'>").append(messageSource.getMessage("column_action", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='16%' class='a-center'>").append(messageSource.getMessage("lbl_img_SetasThumbnail", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("     </tr>");
                if (lstDocumentDetails != null && !lstDocumentDetails.isEmpty()) {
	                for (int i=0;i<lstDocumentDetails.size();i++) {
	
	                    strDocList.append("     <tr id='fli_").append(lstDocumentDetails.get(i)[0]).append("'>");
	                    strDocList.append("         <td class='a-center'>");
	                    strDocList.append(i+1);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    strDocList.append(lstDocumentDetails.get(i)[1]);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    strDocList.append(breakString(lstDocumentDetails.get(i)[2].toString()));
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    //strDocList.append(new BigDecimal(Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024)).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue());
	                    String fileSizeString=String.format("%.3f", Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024));
	                    strDocList.append("0.000".equals(fileSizeString) ? "0.001" : fileSizeString);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    strDocList.append(CommonUtility.convertTimezone(lstDocumentDetails.get(i)[4]));
	                    strDocList.append("</td>");
	                    Integer officerIdint=(Integer)lstDocumentDetails.get(i)[6];
	                    String temp=officerIdint.equals(sectorOffcerDocId)?"true":"false";
	                    strDocList.append("         <td class='a-center'>");
	                    strDocList.append("<a href='javascript:void(0);' onclick=\"removeFile('"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[0].toString())+"','"+encryptDecryptUtils.encrypt(Integer.toString(childId))+"','"+temp+"');\">Remove</a>");                    
	                    strDocList.append("</td>");
	                    //Add the check box
	                    strDocList.append("         <td class='a-center'>");
	                    temp=officerIdint.equals(sectorOffcerDocId)?"checked":"";
	                    //strDocList.append("<abc:checkbox jsrequired='true' tagid='Thumbnail_"+i+"' item='"+lstDocumentDetails.get(i)[6].toString()+"'></abc:checkbox>"+lstDocumentDetails.get(i)[6].toString());                
	                    strDocList.append("<input type='checkbox' id='chkThumbnail_"+i+"' name='chkThumbnail' value='"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[6].toString())+"' "+temp+" onclick=\"chkThumbnailHandler(this,'"+encryptDecryptUtils.encrypt(Integer.toString(childId))+"');\"/>");
	                    strDocList.append("</td>");
	                    strDocList.append("</tr>");
	                
                }
            }else{
            	strDocList.append(" <tr> <td colspan='6'>").append(messageSource.getMessage("empty_records", null, LocaleContextHolder.getLocale())).append("</td></tr>");
            }
            response.getWriter().write(strDocList.toString());
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
//        finally{
//        	auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDocumentDetails, objectId, 0);
//        }
    }
    
    
    /**
     * to get uploaded document in the listing specially for the special client image display with the childId.
     * @author mitesh
     * @param request
     * @param response
     * @param session
     */
    @RequestMapping(value = {"/ajax/getoffieruploadeddocs","/ajaxcall/getoffieruploadeddocs"},method= RequestMethod.POST)
    public void getOfficerUploadedDocs(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
      
        List<Object[]> lstDocumentDetails = null;
        StringBuilder strDocList = new StringBuilder();
        int objectId=0;
        int linkId=0;
        int childId=0;
        String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
        try {
        	SessionBean sessionBean=(SessionBean)session.getAttribute(SESSION_OBJECT);
        	objectId=StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0; 
        	linkId=StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? Integer.parseInt(request.getParameter(TXT_LINKID)) : 0;
        	String docIds=StringUtils.hasLength(request.getParameter(TXT_DOCID)) ? request.getParameter(TXT_DOCID).replace("<PRE>", "").replace("</PRE>", "") : "0";
        	childId= StringUtils.hasLength(request.getParameter(TXT_CHILDID)) ? Integer.parseInt(request.getParameter(TXT_CHILDID)) : 0;
        	int eventId = StringUtils.hasLength(request.getParameter(EVENT_ID)) ? Integer.parseInt(request.getParameter(EVENT_ID)) : 0;
        	int clientId=abcUtility.getSessionClientId(request);
        	//code for get the doc config details
        	List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, clientId);
        	String tempPath="";
        	if(!lstDocUploadConf.isEmpty()){
        		TblDocUploadConf tblDocUploadConf=lstDocUploadConf.get(0);
        		tempPath=tblDocUploadConf.getPath();
        	}
        	//code for the retrive from the Apache server location. 
	    	URL url = new URL(request.getRequestURL().toString()); 
	        StringBuilder baseContexPath=new StringBuilder();
	        baseContexPath.append(request.getContextPath()).append("/").append(sectorimagecontextpath).append(tempPath).append("/").append(objectId).append("/").append(childId);
	        baseContexPath=new StringBuilder(baseContexPath.toString().replace("\\", "/"));
	        //End
        	lstDocumentDetails=fileUploadService.getOfficerDocs(objectId, childId,clientId, linkId, 1);
        	 if (lstDocumentDetails != null && !lstDocumentDetails.isEmpty()) {
        		 	strDocList.append("<ul class='slides'>");
	                for (int i=0;i<lstDocumentDetails.size();i++) {	
					   /* strDocList.append("<li data-thumb='"+request.getContextPath()+"/common/sector/buyer/getimage/"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[7].toString())+"/"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[1].toString())+"/"+ encryptDecryptUtils.encrypt("common/sector/buyer/getimage/"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[7].toString())+"/"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[1].toString())+sessionBean.getUserName())+"'>");
					    strDocList.append("<img src='"+request.getContextPath()+"/common/sector/buyer/getimage/"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[7].toString())+"/"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[1].toString())+"/"+ encryptDecryptUtils.encrypt("common/sector/buyer/getimage/"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[7].toString())+"/"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[1].toString())+sessionBean.getUserName())+"' />");
					    strDocList.append("</li>");*/
	                	strDocList.append("<li data-thumb='"+baseContexPath+"/"+lstDocumentDetails.get(i)[1]+"' >");
						strDocList.append("<img src='"+baseContexPath+"/"+lstDocumentDetails.get(i)[1]+"' title='"+lstDocumentDetails.get(i)[2]+"'/>");
						strDocList.append("</li>");
	                }
	                strDocList.append("</ul>");
        	 }
        	 else
        	 {
        		 strDocList.append("@@1");
        	 }
            response.getWriter().write(strDocList.toString());
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, "Accessed image gallery", ipAddress, objectId, childId);
        }
    }
        
    
    /**
     * to get tender uploaded document in the listing
     * @param request
     * @param response
     * @param session
     */
    @RequestMapping(value = {"/ajax/gettenderuploadeddocs","/ajaxcall/gettenderuploadeddocs"},method=RequestMethod.POST)
    public void getTenderUploadedDocs(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
        List<Object[]> lstDocumentDetails = null;
        StringBuilder strDocList = new StringBuilder();
        int objectId=0;
        int linkId=0;
        try {
        	Object sessionBean=session.getAttribute(SESSION_OBJECT);
        	objectId=StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0; 
        	int tenderId=StringUtils.hasLength(request.getParameter("txttenderId")) ? Integer.parseInt(request.getParameter("txttenderId")) : 0;
        	linkId=StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? Integer.parseInt(request.getParameter(TXT_LINKID)) : 0;
        	String docIds=StringUtils.hasLength(request.getParameter(TXT_DOCID)) ? request.getParameter(TXT_DOCID).replace("<PRE>", "").replace("</PRE>", "") : "0";
        	int clientId=abcUtility.getSessionClientId(request);
        	String clientName=clientService.getClientNameById(clientId);
        	int userTypeId=sessionBean !=null ? ((SessionBean)session.getAttribute(SESSION_OBJECT)).getUserTypeId() : 0;
        	int userId=abcUtility.getSessionUserId(request);
        	int companyId=commonService.getCompanyId(userId, clientId);
        	boolean isPaymentDone=fileUploadService.isPaymentDone(1, tenderId, companyId);
        	int cStatusDoc=0;
        	int status=0;
        	String isReadOnly=StringUtils.hasLength(request.getParameter("txtisReadOnly")) ? request.getParameter("txtisReadOnly"): null;
        	String isTenderDocDownload=StringUtils.hasLength(request.getParameter("txtisTenderDocDownload")) ? request.getParameter("txtisTenderDocDownload"): null;
            cStatusDoc = StringUtils.hasLength(request.getParameter(CSTATUS_DOC)) ? Integer.parseInt(request.getParameter(CSTATUS_DOC)) : 0;
            int cStatusDocView=StringUtils.hasLength(request.getParameter(CSTATUS_DOCVIEW)) ? Integer.parseInt(request.getParameter(CSTATUS_DOCVIEW)) : -1;
            int downloadDocument=StringUtils.hasLength(request.getParameter("txtdownloadDocument")) ? Integer.parseInt(request.getParameter("txtdownloadDocument")) : 0;
            String startDate=StringUtils.hasLength(request.getParameter("txtstartDate")) ? request.getParameter("txtstartDate") : null;
            String endDate=StringUtils.hasLength(request.getParameter("txtendDate")) ? request.getParameter("txtendDate") : null;
            boolean downloadaccess=false;
            String hashVal = "";
            boolean isBidDocs = false;
            if(cStatusDocView == -1){
	            if(cStatusDoc == bidderDocStatusApprove || cStatusDoc == officerDocStatusApprove || cStatusDoc == bidderDocStatusPending || cStatusDoc == officerDocStatusPending){
	            	status=officerDocStatusPending;
	            }else if(cStatusDoc == bidderDocStatusCancel || cStatusDoc == officerDocStatusCancel){
	            	status=officerDocStatusApprove;
	            }else{
                    status=cStatusDocView; 
                 }
            }else{
            	status=cStatusDocView;
            }
            if(((userTypeId ==1 || userTypeId == 3 || "Y".equalsIgnoreCase(isTenderDocDownload)) && userTypeId != 2) || (userTypeId == 2  && fileUploadService.isBidderMappedToTenderId(tenderId,userId))){    
            	if(objectId!=0){
        			lstDocumentDetails=fileUploadService.getOfficerDocs(objectId, clientId, linkId,status);    
        		}else{
        			lstDocumentDetails=fileUploadService.getOfficerDocs(objectId, clientId, linkId,status,docIds);
        		}
            	// comment this code against #72252 
//            	if((userTypeId ==1 || userTypeId == 3) && request.getHeader("referer").contains("etender")){
//            		List<Object[]> corDocumentDetails = fileUploadService.getOfficerAllNoticeDocsAfterCorrigendum(objectId, clientId,request,null);
//            		if(corDocumentDetails!=null && !corDocumentDetails.isEmpty() && corDocumentDetails.size()>0)
//            			lstDocumentDetails=corDocumentDetails;
//            	}
            }else if(userTypeId == 2){
            	downloadaccess=true;
            	isBidDocs = true;
            	if(objectId!=0){
        			lstDocumentDetails=fileUploadService.getBidderDocs(objectId, clientId, linkId,status,userId);
        		}else{
        			lstDocumentDetails=fileUploadService.getBidderDocs(objectId, clientId, linkId,status,userId,docIds);
        		}
        	}
        	strDocList.append("     <tr class='gradi border-right'>");
            strDocList.append("         <th width='5%'>").append(messageSource.getMessage("column_srno", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='20%' class='a-left'>").append(messageSource.getMessage("fields_document", null, LocaleContextHolder.getLocale())).append("</th>");
	        if(!isBidDocs){
	        	strDocList.append("         <th width='18%' class='a-left'>").append(messageSource.getMessage("field_hash", null, LocaleContextHolder.getLocale())).append("</th>");
	        }
            strDocList.append("         <th width='25%' class='a-left'>").append(messageSource.getMessage("fields_docBrief", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='10%' class='a-left'>").append(messageSource.getMessage("col_size", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='15%' class='a-left'>").append(messageSource.getMessage("coloumn_datetime", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='10%' class='a-left'>").append(messageSource.getMessage("coloumn_status", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("         <th width='15%' class='a-left'>").append(messageSource.getMessage("column_action", null, LocaleContextHolder.getLocale())).append("</th>");
            strDocList.append("     </tr>");
                if (lstDocumentDetails != null && !lstDocumentDetails.isEmpty()) {
	                for (int i=0;i<lstDocumentDetails.size();i++) {
	                    strDocList.append("     <tr id='fli_"+lstDocumentDetails.get(i)[0]+"'>");
	                    strDocList.append("         <td class='a-center'>");
	                    strDocList.append(i+1);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    strDocList.append(lstDocumentDetails.get(i)[1]);
	                    strDocList.append("</td>");
	                    if(!isBidDocs){
	                    	hashVal = fileUploadService.getHashValueByDocId(lstDocumentDetails.get(i)[6].toString());
	                    	strDocList.append("         <td>");
	                    	if(hashVal!=null && !hashVal.equals("")){
	                    		strDocList.append("<div class='hash-div' id='idhashPopup_"+i+"'>SHA-256<img  class='has-div-img' src='/GAIL/resources/template/template1/images/hash-icon.png'/>  <div class='pophash' id='pophashId_"+i+"'> "+hashVal+" </div></div>");/* CSP BEFORE LOGIN */
	                    	}else{
	                    		strDocList.append("-");
	                    	}
	                    	strDocList.append("</td>");
	                    	strDocList.append("         <td>");
	                    }
	                    strDocList.append(breakString(lstDocumentDetails.get(i)[2].toString()));
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                  //strDocList.append(new BigDecimal(Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024)).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue());
	                    String fileSizeString=String.format("%.3f", Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024));
	                    strDocList.append("0.000".equals(fileSizeString) ? "0.001" : fileSizeString);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    strDocList.append(CommonUtility.convertTimezone(lstDocumentDetails.get(i)[4]));
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    if((Integer)lstDocumentDetails.get(i)[5] == 1){
	                    	strDocList.append(messageSource.getMessage("label_approved", null, LocaleContextHolder.getLocale()));
	                    }else if((Integer)lstDocumentDetails.get(i)[5] == 3){
	                    	strDocList.append(messageSource.getMessage("label_cancelled", null, LocaleContextHolder.getLocale()));
	                    }
	                    else if((Integer)lstDocumentDetails.get(i)[5] == 0){
	                    	strDocList.append(messageSource.getMessage("label_pending", null, LocaleContextHolder.getLocale()));
	                    }
	                    strDocList.append("</td>");
//	                    if(isActionColumnShow){
	                    if(isReadOnly == null){
		                    strDocList.append("         <td width='9%' style=\"padding: 5px;\">");
		                    strDocList.append(" <input type='hidden' id='txtSignDoc_").append(lstDocumentDetails.get(i)[0]).append("' name='txtSignDoc_").append(lstDocumentDetails.get(i)[0]).append("' value='").append(lstDocumentDetails.get(i)[1]).append("").append(lstDocumentDetails.get(i)[2]).append("").append(lstDocumentDetails.get(i)[4]).append("' />");
		                    if(cStatusDoc == bidderDocStatusPending || cStatusDoc == officerDocStatusPending || cStatusDocView != -1){
			                    strDocList.append("<a href='javascript:void(0);' onclick=\"removeFile('");
			                    strDocList.append(lstDocumentDetails.get(i)[0]);
			                    strDocList.append("','"+(userTypeId == 1 || userTypeId ==3 ? officerDocStatusReject : bidderDocStatusReject)+"');\">");
			                    strDocList.append(messageSource.getMessage("link_delete", null, LocaleContextHolder.getLocale())).append("</a>  | ");
		                    }else if(cStatusDoc == bidderDocStatusApprove || cStatusDoc == officerDocStatusApprove){
		                    	strDocList.append("<a href='javascript:void(0);' onclick=\"removeFile('");
			                    strDocList.append(lstDocumentDetails.get(i)[0]);
			                    strDocList.append("','"+(userTypeId == 1 || userTypeId ==3 ? officerDocStatusApprove : bidderDocStatusApprove)+"');\">");
			                    strDocList.append(messageSource.getMessage("link_approve", null, LocaleContextHolder.getLocale())).append("</a>  | ");
		                    }else if(cStatusDoc == bidderDocStatusCancel || cStatusDoc == officerDocStatusCancel){
		                    	strDocList.append("<a href='javascript:void(0);' onclick=\"removeFile('");
			                    strDocList.append(lstDocumentDetails.get(i)[0]);
			                    strDocList.append("','"+(userTypeId == 1 || userTypeId ==3 ? officerDocStatusCancel : bidderDocStatusCancel)+"');\">");
			                    strDocList.append(messageSource.getMessage("link_cancel", null, LocaleContextHolder.getLocale())).append("</a>  | ");
		                    }
		                    else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
                    			//Nikhil Cancel doc code
                    			strDocList.append("-");
                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                //strDocList.append(">");
                                //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                strDocList.append("</td>");
                    		}
		                    if(sessionBean == null){
		                    	strDocList.append(" <a href=").append(request.getContextPath()).append("/ajaxcall/downloadfile/");
			                    strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
			                    strDocList.append(" id=\"idcheckDocStatus_"+lstDocumentDetails.get(i)[0]+"\" class ='download-div'>");/* CSP BEFORE LOGIN */
			                    strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
			                    strDocList.append("</td>");
		                    }
		                    else if(userTypeId ==1 || userTypeId == 3 || "Y".equalsIgnoreCase(isTenderDocDownload)){
				                    strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadfile/");
				                    strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
				                    strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
				                    strDocList.append(" onclick=\"return checkDocStatus("+lstDocumentDetails.get(i)[0]+");\" >");
				                    strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
				                    strDocList.append("</td>");
		                    }else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
                    			//Nikhil Cancel doc code
                    			strDocList.append("-");
                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                //strDocList.append(">");
                                //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                strDocList.append("</td>");
                    		}
		                    else{
		                    	if(userTypeId ==2){
			                    	strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadbidderfile/");
				                    strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
				                    strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadbidderfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
				                    strDocList.append(" onclick=\"return checkDocStatus("+lstDocumentDetails.get(i)[0]+");\" >");
				                    strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
				                    strDocList.append("</td>");
		                    	}
		                    }
	                    }else{
	                    	if(sessionBean == null){
	                    		if(downloadDocument ==2){
	                    			strDocList.append(" <td id='td_").append(i).append("' > ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_afterlogin", new Object[]{clientName}, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if(startDate !=null && dateUtils.convertStringtoDate(startDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) > 0){
	                    			strDocList.append(" <td id='td_").append(i).append("' class='a-center'> ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_startdate", new Object[]{CommonUtility.convertTimezone(startDate)}, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if(endDate !=null && dateUtils.convertStringtoDate(endDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) < 0){
	                    			strDocList.append(" <td id='td_").append(i).append("' class='a-center'> ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_enddate", null, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if(downloadDocument == 3 && !isPaymentDone){
	                    			strDocList.append(" <td id='td_").append(i).append("' > ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_afterpayment", null, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}
	                    		else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
	                    			//Nikhil Cancel doc code
	                    			strDocList.append("-");
	                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                    //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                    //strDocList.append(">");
                                    //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                    strDocList.append("</td>");
	                    		}else{
			                    	strDocList.append(" <td id='td_").append(i).append("' > <a href=").append(request.getContextPath()).append("/ajaxcall/downloadfile/");
				                    strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
				                    strDocList.append(" id=\"idcheckDocStatus_"+lstDocumentDetails.get(i)[0]+"\" class ='download-div'>");/* CSP BEFORE LOGIN */
				                    strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
				                    strDocList.append("</td>");
	                    		}
		                    }
	                    	else if(userTypeId ==1 || userTypeId == 3 || linkId == 170){ //linkId == 170 condition added to display cancelled tender documents all time to bidder even if document download time ends
		                    	if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
		                    		//Nikhil Cancel doc code
	                    			strDocList.append(" <td class='a-center' id='td_").append(i).append("' > ");
	                    			strDocList.append("-");
	                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                    //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                    //strDocList.append(">");
                                    //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                    strDocList.append("</td>");
		                    	}else{
		                    		strDocList.append("         <td id='td_").append(i).append("'  width='9%'  style=\"padding: 5px;\">");
			                    	strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadfile/");
			                        strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
			                        strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
			                        strDocList.append(" onclick=\"return checkDocStatus("+lstDocumentDetails.get(i)[0]+");\" >");
			                        strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
			    	                strDocList.append("</td>");
		                    	}
	                    	}else if("Y".equalsIgnoreCase(isTenderDocDownload)){
	                    		if(downloadDocument ==3 && !isPaymentDone){
	                    			strDocList.append(" <td id='td_").append(i).append("' > ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_afterpayment", null, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if(startDate !=null && dateUtils.convertStringtoDate(startDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) > 0){
	                    			strDocList.append(" <td id='td_").append(i).append("' > ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_startdate", new Object[]{CommonUtility.convertTimezone(startDate)}, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}else if(endDate !=null && dateUtils.convertStringtoDate(endDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) < 0){
	                    			strDocList.append(" <td id='td_").append(i).append("' > ");
				                    strDocList.append(messageSource.getMessage("msg_document_download_enddate", null, LocaleContextHolder.getLocale()));
				                    strDocList.append("</td>");
	                    		}
	                    		else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
	                    			//Nikhil Cancel doc code
	                    			strDocList.append(" <td class='a-center' id='td_").append(i).append("' > ");
	                    			strDocList.append("-");
	                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                    //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                    //strDocList.append(">");
                                    //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                    strDocList.append("</td>");
	                    		}else{
			                    	strDocList.append("         <td id='td_").append(i).append("'  width='9%'  style=\"padding: 5px;\">");
			                    	strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadfile/");
			                        strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
			                        strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
			                        strDocList.append(" onclick=\"return checkDocStatus("+lstDocumentDetails.get(i)[0]+");\" >");
			                        strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
			    	                strDocList.append("</td>");
	                    		}
	                    	}else{
	                    		if(userTypeId ==2){
	                    			/*if(downloadDocument ==2){
		                    			strDocList.append(" <td id='td_").append(i).append("' class='a-center'> ");
					                    strDocList.append(messageSource.getMessage("msg_document_download_afterlogin", new Object[]{clientName}, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else*/ if(downloadDocument ==3 && !isPaymentDone){
		                    			strDocList.append(" <td id='td_").append(i).append("' > ");
					                    strDocList.append(messageSource.getMessage("msg_document_download_afterpayment", null, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else if(startDate !=null && dateUtils.convertStringtoDate(startDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) > 0){
		                    			strDocList.append(" <td id='td_").append(i).append("' > ");
					                    strDocList.append(messageSource.getMessage("msg_document_download_startdate", new Object[]{CommonUtility.convertTimezone(startDate)}, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}else if(endDate !=null && dateUtils.convertStringtoDate(endDate, "yyyy-MM-dd HH:mm:ss").compareTo(commonService.getServerDateTime()) < 0){
		                    			strDocList.append(" <td id='td_").append(i).append("' > ");
					                    strDocList.append(messageSource.getMessage("msg_document_download_enddate", null, LocaleContextHolder.getLocale()));
					                    strDocList.append("</td>");
		                    		}
		                    		else if((Integer)lstDocumentDetails.get(i)[5] == bidderDocStatusCancel){
		                    			//Nikhil Cancel doc code
		                    			strDocList.append(" <td class='a-center' id='td_").append(i).append("' > ");
		                    			strDocList.append("-");
		                    			//strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                        //strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                        //strDocList.append(">");
                                        //strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                        strDocList.append("</td>");
		                    		}else{
		                    			strDocList.append("         <td id='td_").append(i).append("'  width='9%' style=\"padding: 5px;\">");
		    	                    	strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadbidderfile/");
		    	                        strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
		    	                        strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadbidderfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
		    	                        strDocList.append(" onclick=\"return checkDocStatus("+lstDocumentDetails.get(i)[0]+");\" >");
		    	                        strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
		    	    	                strDocList.append("</td>");
		                    		}
	                    		}
	                    	}
	                    }
//	                    }
	                    strDocList.append("</tr>");
                }
            }else{
            	strDocList.append(" <tr> <td colspan='7'>").append(messageSource.getMessage("empty_records", null, LocaleContextHolder.getLocale())).append("</td></tr>");
            }
            response.getWriter().write(strDocList.toString());
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
        finally{
        	//makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDocumentDetails, objectId, 0);
        	//auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDocumentDetails, objectId, 0);
        }
    }

    

    /*For check Extension and size
    public boolean checkFileExn(String fileName, String allowExtensions) {
        boolean chextn = false;
        int j = fileName.lastIndexOf('.');
        String lst = fileName.substring(j + 1);
        String str = allowExtensions;
        String[] str1 = str.split(",");
        for (int i = 0; i < str1.length; i++) {
            if (str1[i].trim().equalsIgnoreCase(lst)) {
                chextn = true;
            }
        }
        return chextn;
    }
    For doc size msg

    public boolean checkFileSize(long fielSize, long maxFileSize) {
        boolean chextn = false;
        float fsize = 0.0f;
        float dsize = 0.0f;
        // code for check file size
        fsize = fielSize / (1024 * 1024);
        dsize = maxFileSize;
        if (dsize > fsize) {
            chextn = true;
        } else {
            chextn = false;
        }
        return chextn;
    }
*/

    /**
     * to delete the file physically
     * @param filePath
     * @return
     */
    public boolean deleteFile(String filePath) {
        boolean flg = false;
        try {
            File f = new File(filePath);
            if (f.delete()) {
                flg = true;
            }

        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
        return flg;
    }
    
    /**
     * to check the file size   
     * @param fielSize
     * @param maxFileSize
     * @return
     */
    private boolean checkFileSize(long fielSize, long maxFileSize) {
        boolean chextn = false;
        if (maxFileSize > fielSize) {
            chextn = true;
        } else {
            chextn = false;
        }
        return chextn;
    }
    
    /**
     * to check file extention
     * @param fileName
     * @param allowExtensions
     * @return
     */
    private boolean checkFileExn(String fileName, String allowExtensions) {
        boolean chextn = false;
        int j = fileName.lastIndexOf('.');
        String lst = fileName.substring(j + 1);
        String str = allowExtensions;
        String[] str1 = str.split(",");
        for (int i = 0; i < str1.length; i++) {
            if (str1[i].trim().equalsIgnoreCase(lst)) {
                chextn = true;
            }
        }
        return chextn;
    }
    
    /**
     * to check the valid type 
     * @param file
     * @return boolean
     * @throws FileNotFoundException
     * @throws IOException
     */
    private boolean isValidContentType(File file) throws FileNotFoundException, IOException {
        boolean flag = false;
        int count = 0;
        FileInputStream fis = new FileInputStream(file);
        int j = file.getName().lastIndexOf('.');
        String fileExt = file.getName().substring(j + 1);
        //System.out.println("fileExt :: " + fileExt);
        if ("pdf".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_PDF.length; ++i) {
                if (fis.read() != FILESIGNATURE_PDF[i]) {
                    //System.out.println("not a valid pdf file");
                    count++;
                }
            }
        } else if ("zip".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_ZIP.length; ++i) {
                if (fis.read() != FILESIGNATURE_ZIP[i]) {
                    //System.out.println("not a valid zip file");
                    count++;
                }
            }
        } else if ("rar".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_RAR.length; ++i) {
                if (fis.read() != FILESIGNATURE_RAR[i]) {
                    count++;
                }
            }
        }else if ("exe".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_EXE.length; ++i) {
                if (fis.read() != FILESIGNATURE_EXE[i]) {
                    count++;
                }
            }
        }/*else if ("bmp".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_BMP.length; ++i) {
                if (fis.read() != FILESIGNATURE_BMP[i]) {
                    count++;
                }
            }
        }*/else if ("DOCX".equalsIgnoreCase(fileExt) || "XLSX".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_DOCX_XLSX.length; ++i) {
            	int temp=fis.read();
            	//System.out.println("temp :: "+temp);
            	//System.out.println("Standard :: "+FILESIGNATURE_DOCX_XLSX[i]);
                if (temp != FILESIGNATURE_DOCX_XLSX[i]) {
                    count++;
                }
            }
        }else if ("doc".equalsIgnoreCase(fileExt) || "ppt".equalsIgnoreCase(fileExt) || "xls".equalsIgnoreCase(fileExt) || "pps".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_DOC_PPT_XLS_PPS.length; ++i) {
            	int temp=fis.read();
                if (temp != FILESIGNATURE_DOC_PPT_XLS_PPS[i]) {
                	//if(temp != FILESIGNATURE_DOC_PPT_XLS_PPS_TAT[i]){
                		count++;
                	//}
                }
            }
        }/*else if ("PNG".equalsIgnoreCase(fileExt)) {
            for (int i = 0; i < FILESIGNATURE_PNG.length; ++i) {
                if (fis.read() != FILESIGNATURE_PNG[i]) {
                    count++;
                }
            }
        }*/
        if (count > 0) {
            flag = false;
        } else {
            flag = true;
        }
        fis.close();
        return flag;
    }
    
    /**
     * create directory if it does not exists
     * @param drive
     * @param rpath
     * @return boolean
        String[] tpath = rpath.split("\\\\");
     */
    private void isDirExists(String drive, String rpath) {
        String[] tpath = rpath.split("\\\\");
        StringBuilder path = new StringBuilder();
        path.append(drive);

        for (int i = 0; i < tpath.length; i++) {
            path.append("\\").append(tpath[i]);

            File f = new File(path.toString());

            if (!f.isDirectory()) {
                f.mkdirs();
            }
        }
    }
    
    /**
     * method is used to add entry in the audit trail based on module type like auction or tender or admin
     * @param request
     * @param audit
     * @param linkId
     * @param remarks
     * @param parentId
     * @param childId
     * @param remarkSign
     */
    private void makeModuleBasedAuditTrialEntries(HttpServletRequest request,Object audit, int linkId, String remarks, Integer parentId,Integer childId,String... remarkSign){
    	//String uri=request.getHeader("Referer");
    	//String contextPath=request.getContextPath();
    	int moduleId=0;
    	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    	try {
			moduleId=commonService.getModuleIdbyLinkId(linkId);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	switch (moduleId) {
    		case 2:
    			auditTrailService.makeIndentAuditTrail(audit,linkId,remarks,parentId,childId,remarkSign);
    			break;
			case 3:
				auditTrailService.makeTenderAuditTrail(audit,linkId,remarks,parentId,childId,remarkSign);	
				break;
				
			case 5 :
				auditTrailService.makeAuctionAuditTrail(audit,linkId,remarks,ipAddress,parentId,childId,remarkSign);	
				break;
				
			case 8 :
				auditTrailService.makeVendorAuditTrail(audit,linkId,remarks,parentId,childId,remarkSign);	
				break;
				
			default:
				auditTrailService.makeAuditTrail(audit,linkId,remarks,parentId,childId,remarkSign);
				break;
    	}
    	/*if(uri.contains(contextPath+"/eauction")){
    		auditTrailService.makeAuctionAuditTrail(audit,linkId,remarks,parentId,childId,remarkSign);
    	}else if(uri.contains(contextPath+"/etender")){
    		auditTrailService.makeTenderAuditTrail(audit,linkId,remarks,parentId,childId,remarkSign);
    	}else{
    		auditTrailService.makeAuditTrail(audit,linkId,remarks,parentId,childId,remarkSign);
    	}*/
    }
    
    /**
     * to get link id based on the event and module type 
     * @param linkId
     * @param status
     * @return int
     */
    private int getLinkId(int linkId,int status,int userTypeId){
    	int result=linkId;
    	switch (linkId) {
			case 123://For auction
						if(status==0){
							result=123;
						}else if(status==1){
							result=101;
						}
						else if(status==2){
							result=104;
						}
						else if(status==3){
							result=103;
						}
						else{
							result=102;
						}
						break;
			case 175://For tender
						if(status==0){
							result=175;
						}else if(status==1){
							result=249;
						}
						else if(status==2){
							result=373;
						}
						else if(status==3){
							result=250;
						}
						else{
							result=255;
						}
						break;
						
			case 216://pre bid meeting
						if(status==0){
							result=216;
						}else if(status==1){
							result=217;
						}
						else if(status==2){
							result=243;
						}
						else{
							result=376;
						}
						break;
						
			case 182://Corrigendum
						if(status==0){
							result=182;
						}else if(status==1){ 
							result=182;
						}
						else if(status==2){
							result=377;
						}
						else{
							result=378;
						}
						break;
	
			case 311://Bid evaluation upload
						if(status==0){
							result=311;
						}
						else if(status==2){
							result=374;
						}
						else{
							result=375;
						}
						break;
			case 293://Bid opening upload
						if(status==0){
							result=293;
						}
						else if(status==2){
							result=383;
						}
						else{
							result=382;
						}
						break;
            case 517:
                        result=519;
                        break;
            case 509:
                        result=511;
                        break;
            case 524://pcf upload rfx
            			if(userTypeId == 1 || userTypeId == 3){
            				result=521;
            			}else{
            				result=525;
            			}
		                break;
            case 522://pcf upload auction
		    			if(userTypeId == 1 || userTypeId == 3){
		    				result=513;
		    			}else{
		    				result=523;
		    			}
		                break;
		                
            case 518://brd upload rfx
            			if(status == 2){
            				result=520;
            			}else{
            				result=519;
            			}
            			break;
            			
            case 510://brd upload auction
		    			if(status == 2){
		    				result=512;
		    			}else{
		    				result=511;
		    			}
		    			break;
            case 756://Final summary sheet upload auction
		    			if(status == 2){
		    				result=758;
		    			}else{
		    				result=757;
		    			}
		    			break;
            case 753://Final summary sheet upload tender
		    			if(status == 2){
		    				result=755;
		    			}else{
		    				result=754;
		    			}
		    			break;

			default:
				break;
		}
    	
    	return result;
    }
    
    private  String breakString(String str) {
        StringBuilder string = new StringBuilder();
        if(str.length()<=70){
            string.append(str);
        }else{
            float i = str.length() % 70;
            if (i == 0) {
                float cnt = str.length() / 70;
                for (int k = 0; k < cnt; k++) {
                    string.append(str.substring((k*70), (k+1) * 70)).append("<br/>");
                }
            } else {
                float cnt = str.length() / 70;
                int length=0;
                for (int k = 0; k < cnt; k++) {
                    string.append(str.substring((k*70), (k+1) * 70));
                    length = ((k+1) * 70);
                    string.append("<br/>");
                }
                string.append(str.substring(length, str.length()));
            }
        }
        return string.toString();
    }
    
    @RequestMapping(value = {"/etender/buyer/tenderdocaszip/{tenderId}/{needfresh}/{enc}","/etender/bidder/tenderdocaszip/{tenderId}/{needfresh}/{enc}"}, method = RequestMethod.GET)
    public String downloadTenderDocAsZip(@PathVariable("tenderId")Integer tenderId,@PathVariable("needfresh")Integer needfresh,HttpServletRequest request ,HttpServletResponse response,RedirectAttributes redirectAttributes){
        try {
            response.setContentType("application/octet-stream");
            ServletOutputStream outputStream = null;
//            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(SESSION_OBJECT);
            String filePath=docUploadPath+"\\"+abcUtility.getSessionClientId(request)+"\\Tender\\";            
            File file = new File(filePath+"\\"+tenderId+".zip");
            boolean isZipAvail = true;
            int chkIsBrd = fileUploadService.isBRDAutoByTenderId(tenderId);
            List<Object[]> lstDocumentDetails = new ArrayList<Object[]>();
            List<Object> corrigendumIds = fileUploadService.getCorrigendumIdsByTenderId(tenderId);
            List<Integer> objectIds = new ArrayList<Integer>();
            objectIds.add(tenderId);
            if(corrigendumIds != null && !corrigendumIds.isEmpty()){
            	for(int k=0;k<corrigendumIds.size();k++){
            		objectIds.add(Integer.parseInt(corrigendumIds.get(k).toString()));
            	}
            }
            List<Integer> linkIds = new ArrayList<Integer>();
            linkIds.add(175);
            linkIds.add(corrigendum_uploadLinkId);
            if(chkIsBrd == 1){
            	linkIds.add(brdLinkId);
            }
            lstDocumentDetails = fileUploadService.getOfficerDocswithBrdDoc(objectIds, abcUtility.getSessionClientId(request), linkIds,-1);
            List<String[]> approvedDoc = new ArrayList<String[]>();
            for (Object[] objects : lstDocumentDetails) {
            	String[] apprvDocArr = new String[4]; 
                if((Integer)objects[5]==1){ 
                	apprvDocArr[0]=objects[1].toString();
                	apprvDocArr[1]=objects[7].toString();
                	apprvDocArr[2]=objects[3].toString();
                	apprvDocArr[3]=objects[9].toString();
                  	approvedDoc.add(apprvDocArr);
                }
            }            
            if(needfresh==1 || !file.exists()){
                File dir = new File(filePath+"\\"+tenderId);
                dir = abcUtility.CheckDirLength(dir);
                if(((chkIsBrd == 1) || (chkIsBrd != 1 && dir.exists())) && approvedDoc.size()!=0){
                	if(chkIsBrd == 1 &&  !dir.exists()){
                		dir = new File(filePath+"\\"+"BRD"+"\\"+tenderId);
                	}
                	if(dir.exists() && dir.list().length!=0){
                		abcUtility.zipDirectory(dir, file,approvedDoc);	
                	}
                }else{
                    isZipAvail = false;
                }
            }            
            if(isZipAvail){
            FileInputStream fis = new FileInputStream(file);
            byte[] buf = new byte[(int) file.length()];
            int offset = 0;
            int numRead = 0;
            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                offset += numRead;
            }
//            if(tblDocUploadConf.getIsEncryptionReq() == 1){
//                buf = fileEncryptDecryptUtil.fileDecryptUtil(buf);
//            }
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment;filename=\"" + tenderId + ".zip\"");
            outputStream = response.getOutputStream();
            outputStream.write(buf);
            outputStream.flush();
            outputStream.close();
            fis.close();
            /*if (sessionBean.getUserTypeId() == 2) {
                SessionBean sessionBean1=(SessionBean)sessionBean;
                TblDownloadDocHistory tblDownloadDocHistory=new TblDownloadDocHistory();
                tblDownloadDocHistory.setTblOfficerDocMapping(new TblOfficerDocMapping(docId));
                tblDownloadDocHistory.setTblTrackLogin(new TblTrackLogin(sessionBean1.getTrackLoginId()));
                fileUploadService.addDownloadDocHistory(tblDownloadDocHistory);
            }*/
            return null;
            }else{
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_tender_nodocforzip");
                String refererUrl = request.getHeader("referer");
                return "redirect:"+refererUrl.substring(refererUrl.indexOf(contextName)+5, refererUrl.length());
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
    }
    
  @RequestMapping(value = {"/etender/buyer/bidderformdocaszip/{tenderId}/{companyId}/{envelopeId}/{enc}", "/etender/bidder/bidderformdocaszip/{tenderId}/{companyId}/{envelopeId}/{enc}"}, method = RequestMethod.GET)
    public String downloadBidderFormDocAsZip(@PathVariable("tenderId") Integer tenderId, @PathVariable("companyId") Integer companyId,@PathVariable("envelopeId") Integer envelopeId ,HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes) {
        try {
        	 int needfresh=1;
             String companyName = abcUtility.correctFileName(commonService.getCompanyNameByCompanyId(companyId) + "_" + tenderId);
             String filePathFragment = fileDrive + fileUpload + tenderwiseReport + "\\" + tenderId + "\\"+ companyId + "\\" + envelopeId;
             String filePath = filePathFragment + "\\" + companyName;
             System.out.println("FilePathFragment Before--" + filePathFragment);
             
             File  zfile = new File(filePath+".zip");
             
             File theDir = zfile.getParentFile();
             if(!theDir.exists() && !theDir.mkdirs()){
                 throw new IllegalStateException("Couldn't create dir: " + theDir);
             }
             
             
             List<Object[]> bidderDocs = fileUploadService.getBidderFormDocs(companyId, envelopeId );
             List<String[]> approvedDoc = new ArrayList<String[]>();
        
            ServletOutputStream outputStream = null;
            boolean isZipAvail = true;
            for (Object[] docs : bidderDocs) {
                String[] approvedDocsArr = new String[4] ;
                approvedDocsArr[0]=docs[1].toString();
                approvedDocsArr[1]=docs[5].toString();
                approvedDocsArr[2]=docs[6].toString();
                approvedDocsArr[3]=docs[0].toString();
                approvedDoc.add(approvedDocsArr);
            }
            
            
             String souceFilePath="";
             if(needfresh==1 || !zfile.exists()){
                if(bidderDocs!=null && !bidderDocs.isEmpty()){
                    Object[] docs=bidderDocs.get(0);
                    souceFilePath=docUploadPath + docs[0];
                }
                File dir = new File(souceFilePath);
                if(approvedDoc.size()!=0){
                	if(!dir.exists()){
                		dir.mkdir();
                	}
                    abcUtility.zipDirectory(dir, zfile,approvedDoc);
                }else{
                    isZipAvail = false;
                }
                
            }     
            response.setContentType("application/octet-stream");
            if (isZipAvail) {
                FileInputStream fis = new FileInputStream(zfile);
                byte[] buf = new byte[(int) zfile.length()];
                int offset = 0;
                int numRead = 0;
                while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                    offset += numRead;
                }
                response.setContentType("application/octet-stream");
                response.setHeader("Content-Disposition", "attachment;filename=\"" + zfile.getName() + "\"");
                outputStream = response.getOutputStream();
                outputStream.write(buf);
                outputStream.flush();
                outputStream.close();
                fis.close();
                return null;
            } else {
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_tender_nodocforzip");
                String refererUrl = request.getHeader("referer");
                return "redirect:" + refererUrl.substring(refererUrl.indexOf("EPROC") + 5, refererUrl.length());
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
    }
  
  @RequestMapping(value = {"/etender/buyer/bidderformdocconsortiumaszip/{tenderId}/{companyId}/{envelopeId}/{consortiumId}/{enc}"}, method = RequestMethod.GET)
  public String downloadBidderConsortiumFormDocAsZip(@PathVariable("tenderId") Integer tenderId, @PathVariable("companyId") Integer companyId,@PathVariable("envelopeId") Integer envelopeId ,@PathVariable("consortiumId") Integer consortiumId ,HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes) {
      try {
      	 int needfresh=1;
           String companyName = abcUtility.correctFileName(commonService.getCompanyNameByCompanyId(companyId) + "_" + tenderId);
           String filePathFragment = fileDrive + fileUpload + tenderwiseReport + "\\" + tenderId + "\\"+ companyId + "\\" + envelopeId;
           String filePath = filePathFragment + "\\" + companyName;
           
           File  zfile = new File(filePath+".zip");
           
           File theDir = zfile.getParentFile();
           if(!theDir.exists() && !theDir.mkdirs()){
               throw new IllegalStateException("Couldn't create dir: " + theDir);
           }
           
           List<Object> companyIds = commonService.getCompanyDetailForConsortium(tenderId,consortiumId);
           List<Integer> comp = new ArrayList<Integer>();
           for(Object s: companyIds){
          	 comp.add(Integer.parseInt(s.toString()));
           }
         
           List<Object[]> bidderDocs = fileUploadService.getBidderFormDocsForConsortium(comp, envelopeId );
           List<String[]> approvedDoc = new ArrayList<String[]>();
      
          ServletOutputStream outputStream = null;
          boolean isZipAvail = true;
          for (Object[] docs : bidderDocs) {
              String[] approvedDocsArr = new String[5] ;
              approvedDocsArr[0]=docs[1].toString();
              approvedDocsArr[1]=docs[5].toString();
              approvedDocsArr[2]=docs[6].toString();
              approvedDocsArr[3]=docs[0].toString();
              approvedDocsArr[4]=docs[7].toString();
              approvedDoc.add(approvedDocsArr);
          }
          String souceFilePath="";
           if(needfresh==1 || !zfile.exists()){
              if(bidderDocs!=null && !bidderDocs.isEmpty()){
                  Object[] docs=bidderDocs.get(0);
                  souceFilePath=docUploadPath + docs[0];
              }
              File dir = new File(souceFilePath);
              if(approvedDoc.size()!=0){
              	if(!dir.exists()){
              		dir.mkdir();
              	}
                  abcUtility.zipDirectoryForConsortium(dir, zfile,approvedDoc);
              }else{
                  isZipAvail = false;
              }
          }     
          response.setContentType("application/octet-stream");
          if (isZipAvail) {
              FileInputStream fis = new FileInputStream(zfile);
              byte[] buf = new byte[(int) zfile.length()];
              int offset = 0;
              int numRead = 0;
              while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                  offset += numRead;
              }
              response.setContentType("application/octet-stream");
              response.setHeader("Content-Disposition", "attachment;filename=\"" + zfile.getName() + "\"");
              outputStream = response.getOutputStream();
              outputStream.write(buf);
              outputStream.flush();
              outputStream.close();
              fis.close();	
              return null;
          } else {
              redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_tender_nodocforzip");
              String refererUrl = request.getHeader("referer");
              return "redirect:" + refererUrl.substring(refererUrl.indexOf(contextName) + 5, refererUrl.length());
          }
      } catch (Exception ex) {
          return exceptionHandlerService.writeLog(ex);
      }
  }
  
  /**
   * to get uploaded document in the listing
   * @param request
   * @param response
   * @param session
   */
  @RequestMapping(value = {"/ajax/getuploadeddocsWithMultipleLink","/ajaxcall/getuploadeddocsWithMultipleLink"})
  public void getUploadedDocsWithMultipleLink(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
      
      /* String docIds = "";
      if (request.getParameter("docIds") != null) {
          docIds = request.getParameter("docIds");
      }*/
      List<Object[]> lstDocumentDetails = null;
      StringBuilder strDocList = new StringBuilder();
      int objectId=0;
      String linkId="0";
      int childId=0;
      int mappedBy=0;
      try {
      	Object sessionBean=session.getAttribute(SESSION_OBJECT);
      	objectId=StringUtils.hasLength(request.getParameter(TXT_OBJECTID)) ? Integer.parseInt(request.getParameter(TXT_OBJECTID)) : 0; 
      	linkId=StringUtils.hasLength(request.getParameter(TXT_LINKID)) ? request.getParameter(TXT_LINKID) : "";
      	childId=StringUtils.hasLength(request.getParameter(HD_CHILDID)) ? Integer.parseInt(request.getParameter(HD_CHILDID)) : 0;
      	int amenCount=StringUtils.hasLength(request.getParameter("txtAmenCount")) ? Integer.parseInt(request.getParameter("txtAmenCount")) : 0;
      	int latestAmendmentId=StringUtils.hasLength(request.getParameter("txtlatestAmendmentId")) ? Integer.parseInt(request.getParameter("txtlatestAmendmentId")) : 0;
      	if(objectId==0){
      		objectId=StringUtils.hasLength(request.getParameter("hdObjectId")) ? Integer.parseInt(request.getParameter("hdObjectId")) : 0; 
      	}
      	if(childId==0){
      		childId=StringUtils.hasLength(request.getParameter(TXT_CHILDID)) ? Integer.parseInt(request.getParameter(TXT_CHILDID)) : 0; 
      	}
      	mappedBy=StringUtils.hasLength(request.getParameter(TXT_MAPPEDBY)) ? Integer.parseInt(request.getParameter(TXT_MAPPEDBY)) : 0;
      	List<Integer> lstLink=new ArrayList<Integer>();
      	if(!"".equals(linkId) && linkId!=null && (!linkId.equals("0"))){
      		String[] strLink=linkId.split(",");
      		for (String string : strLink) {
      			lstLink.add(Integer.valueOf(string.trim()));
			}
      	
      	String docIds=StringUtils.hasLength(request.getParameter(TXT_DOCID)) ? request.getParameter(TXT_DOCID).replace("<PRE>", "").replace("</PRE>", "") : "0";
      	int clientId=abcUtility.getSessionClientId(request);
      	int userTypeId=sessionBean !=null ? ((SessionBean)session.getAttribute(SESSION_OBJECT)).getUserTypeId() : 0;
      	int userId=abcUtility.getSessionUserId(request);
      	int cStatusDoc=0;
      	int status=0;
      	String hashVal = "";
      	String isReadOnly=StringUtils.hasLength(request.getParameter("txtisReadOnly")) ? request.getParameter("txtisReadOnly"): null;
              String txtDisplayStatusColumn=StringUtils.hasLength(request.getParameter("txtDisplayStatusColumn")) ? request.getParameter("txtDisplayStatusColumn"): "";
      	String isAuctionDocDownload=StringUtils.hasLength(request.getParameter("txtisAuctionDocDownload")) ? request.getParameter("txtisAuctionDocDownload"): null;
      	String isBidderDocDownload=StringUtils.hasLength(request.getParameter("txtisBidderDocDownload")) ? request.getParameter("txtisBidderDocDownload"): "";
          cStatusDoc = StringUtils.hasLength(request.getParameter(CSTATUS_DOC)) ? Integer.parseInt(request.getParameter(CSTATUS_DOC)) : 0;
          int cStatusDocView=StringUtils.hasLength(request.getParameter(CSTATUS_DOCVIEW)) ? Integer.parseInt(request.getParameter(CSTATUS_DOCVIEW)) : -1;
          //Added By Lipi - Bug #19523 Start
          int downloadDocument = StringUtils.hasLength(request.getParameter("txtdownloadDocument")) ? Integer.parseInt(request.getParameter("txtdownloadDocument")) : 0;
          String startDate = StringUtils.hasLength(request.getParameter("txtstartDate")) ? request.getParameter("txtstartDate") : null;
          String endDate = StringUtils.hasLength(request.getParameter("txtendDate")) ? request.getParameter("txtendDate") : null;
          String clientName = clientService.getClientNameById(clientId);
          int companyId=commonService.getCompanyId(userId, clientId);
          boolean isBidDocs = false;
      	boolean isPaymentDone=fileUploadService.isPaymentDone(1, objectId, companyId);
		int showCreatedBy=StringUtils.hasLength(request.getParameter("showCreatedBy")) ? Integer.parseInt(request.getParameter("showCreatedBy")) : 0;
          //End
          if(cStatusDocView == -1){
	            if(cStatusDoc == bidderDocStatusApprove || cStatusDoc == officerDocStatusApprove || cStatusDoc == bidderDocStatusPending || cStatusDoc == officerDocStatusPending){
	            	status=officerDocStatusPending;
	            }else if(cStatusDoc == bidderDocStatusCancel || cStatusDoc == officerDocStatusCancel){
	            	status=officerDocStatusApprove;
	            }else if(cStatusDoc < 0){
	            	status=cStatusDoc;
	            }else{
                     status=cStatusDocView; 
              }
          }else{
          	status=cStatusDocView;
          }
      	if((userTypeId ==1 || userTypeId == 3 || "Y".equalsIgnoreCase(isAuctionDocDownload)) && !"Y".equalsIgnoreCase(isBidderDocDownload)){
      		if(objectId!=0){
      			if(childId!=0 && mappedBy > 0){
    				lstDocumentDetails =fileUploadService.getOfficerDocsDynamic(String.valueOf(objectId),String.valueOf(childId),String.valueOf(clientId),String.valueOf(linkId),"-2",String.valueOf(mappedBy));
    			}else{
    				lstDocumentDetails=fileUploadService.getOfficerDocsWithMultipleLink(objectId, clientId, childId,lstLink,status);
    			}
      		}else{
      			lstDocumentDetails=fileUploadService.getOfficerDocsWithMultipleLink(objectId, clientId, childId,lstLink,status,docIds);
      		}
      	}else if(userTypeId == 2 || "Y".equalsIgnoreCase(isBidderDocDownload)){
            userId="Y".equalsIgnoreCase(isBidderDocDownload) ? 0 : userId;
            isBidDocs = true;
			if(objectId!=0){
				lstDocumentDetails=fileUploadService.getBidderDocsWithMultipleLink(objectId, clientId, linkId,status,userId);
			}else{
				lstDocumentDetails=fileUploadService.getBidderDocsWithMultipleLink(objectId, clientId, linkId,status,userId,docIds);
			}
		}
          strDocList.append("     <tr class='gradi border-right'>");
          strDocList.append("         <th width='5%'>").append(messageSource.getMessage("column_srno", null, LocaleContextHolder.getLocale())).append("</th>");
          strDocList.append("         <th width='18%' class='a-left'>").append(messageSource.getMessage("fields_document", null, LocaleContextHolder.getLocale())).append("</th>");
	      if(!isBidDocs){
	    	  strDocList.append("         <th width='18%' class='a-left'>").append(messageSource.getMessage("field_hash", null, LocaleContextHolder.getLocale())).append("</th>");
	      }
          if(!linkId.equals(bidderBlacklistLinkId)){
          strDocList.append("         <th width='20%' class='a-left'>").append(messageSource.getMessage("fields_docBrief", null, LocaleContextHolder.getLocale())).append("</th>");
          }
          strDocList.append("         <th width='10%' class='a-left'>").append(messageSource.getMessage("col_size", null, LocaleContextHolder.getLocale())).append("</th>");
          strDocList.append("         <th width='16%' class='a-left'>").append(messageSource.getMessage("coloumn_datetime", null, LocaleContextHolder.getLocale())).append("</th>");
		  if(showCreatedBy == 1){
            	strDocList.append("         <th width='16%' class='a-left'>").append(messageSource.getMessage("coloumn_uploaded_by", null, LocaleContextHolder.getLocale())).append("</th>");
            }
          if(!txtDisplayStatusColumn.equalsIgnoreCase("N") && !linkId.equals(bidderBlacklistLinkId))
          {
          	strDocList.append("         <th width='10%' class='a-left'>").append(messageSource.getMessage("coloumn_status", null, LocaleContextHolder.getLocale())).append("</th>");
          }
          strDocList.append("         <th width='19%' class='a-left noprint'>").append(messageSource.getMessage("column_action", null, LocaleContextHolder.getLocale())).append("</th>");
          strDocList.append("     </tr>");
              if (lstDocumentDetails != null && !lstDocumentDetails.isEmpty()) {
	                for (int i=0;i<lstDocumentDetails.size();i++) {
	                    strDocList.append("     <tr id='fli_").append(lstDocumentDetails.get(i)[0]).append("'>");
	                    strDocList.append("         <td class='a-center'>");
	                    strDocList.append(i+1);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td class='word-break'>");
	                    strDocList.append(lstDocumentDetails.get(i)[1]);
	                    strDocList.append("</td>");
	                    if(!isBidDocs){
	                    	hashVal = fileUploadService.getHashValueByDocId(lstDocumentDetails.get(i)[6].toString());
	                    	strDocList.append("         <td>");
	                    	if(hashVal!=null && !hashVal.equals("")){
	                    		strDocList.append("<div class='hash-div' id='idhashPopup_"+i+"'>SHA-256<img  class='has-div-img' src='/GAIL/resources/template/template1/images/hash-icon.png'/>  <div class='pophash' id='pophashId_"+i+"'> "+hashVal+" </div></div>");/* CSP BEFORE LOGIN */
	                    	}else{
	                    		strDocList.append("-");
	                    	}
	                    	strDocList.append("</td>");
	                    }
	                    if(!linkId.equals(bidderBlacklistLinkId)){
	                    strDocList.append("         <td class='word-break'>");
	                    strDocList.append(breakString(lstDocumentDetails.get(i)[2].toString()));
	                    strDocList.append("</td>");
	                    }
	                    strDocList.append("         <td>");
	                    //strDocList.append(new BigDecimal(Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024)).setScale(3, BigDecimal.ROUND_HALF_UP).doubleValue());
	                    String fileSizeString=String.format("%.3f", Double.parseDouble(lstDocumentDetails.get(i)[3].toString())/(1024*1024));
	                    strDocList.append("0.000".equals(fileSizeString) ? "0.001" : fileSizeString);
	                    strDocList.append("</td>");
	                    strDocList.append("         <td>");
	                    strDocList.append(CommonUtility.convertTimezone(lstDocumentDetails.get(i)[4]));
	                    strDocList.append("</td>");
						if(showCreatedBy == 1){
	                    	strDocList.append("         <td>");
		                    //strDocList.append(lstDocumentDetails.get(i)[8].toString());
	                    	strDocList.append(departmentUserService.getUserName(Integer.parseInt(lstDocumentDetails.get(i)[9].toString())).get(0));
		                    strDocList.append("</td>");
		            	}
                          if(!txtDisplayStatusColumn.equalsIgnoreCase("N") && !linkId.equals(bidderBlacklistLinkId))
	                    {
	                    strDocList.append("         <td>");
                             if((Integer)lstDocumentDetails.get(i)[5] == 1){
                                  strDocList.append(messageSource.getMessage("label_approved", null, LocaleContextHolder.getLocale()));
                              }else if((Integer)lstDocumentDetails.get(i)[5] == 3){
                                  strDocList.append(messageSource.getMessage("label_cancelled", null, LocaleContextHolder.getLocale()));
                              }
                              else if((Integer)lstDocumentDetails.get(i)[5] == 0){
                                  strDocList.append(messageSource.getMessage("label_pending", null, LocaleContextHolder.getLocale()));
                              }
                          
	                    strDocList.append("</td>");
                          }
	                   // if(isActionColumnShow){
		                    if(isReadOnly == null){
//			                    strDocList.append("         <td width='9%' style=\"padding: 5px;\">");
		                    	strDocList.append(" <td class='noprint' id='td_").append(i).append("' style=\"padding: 5px;\">");
			                    strDocList.append(" <input type='hidden' id='txtSignDoc_"+lstDocumentDetails.get(i)[0]).append("' name='txtSignDoc_").append(lstDocumentDetails.get(i)[0]).append("' value='").append(lstDocumentDetails.get(i)[1]).append("").append(lstDocumentDetails.get(i)[2]).append("").append(lstDocumentDetails.get(i)[4]).append("' />");
			                    if(cStatusDoc == bidderDocStatusPending || cStatusDoc == officerDocStatusPending ||  cStatusDoc > 3){
				                    strDocList.append("<a href='#' onclick=\"removeFile('");
				                    strDocList.append(lstDocumentDetails.get(i)[0]);
				                    strDocList.append("','").append((userTypeId == 1 || userTypeId ==3 ? officerDocStatusReject : bidderDocStatusReject)).append("');\">");
				                    strDocList.append(messageSource.getMessage("link_delete", null, LocaleContextHolder.getLocale())).append("</a>  | ");
				                    if(cStatusDoc == 4 && Integer.parseInt(lstDocumentDetails.get(i)[5].toString()) == 0){
				                    	strDocList.append("<a href='").append(request.getContextPath()).append("/common/admin/mapvendorcode/").append(objectId);
				                    	strDocList.append("/").append(lstDocumentDetails.get(i)[0]).append("/").append(encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[1].toString()));
				                    	strDocList.append(encryptDecryptUtils.generateRedirect("common/admin/mapvendorcode/"+objectId+"/"+lstDocumentDetails.get(i)[0]+"/"+encryptDecryptUtils.encrypt(lstDocumentDetails.get(i)[1].toString()), request));
				                    	strDocList.append("' >");
					                    strDocList.append(messageSource.getMessage("link_map", null, LocaleContextHolder.getLocale())).append("</a>  | ");
				                    }else if(cStatusDoc == 4 && Integer.parseInt(lstDocumentDetails.get(i)[5].toString()) == 1){
				                    	strDocList.append(messageSource.getMessage("lbl_mapped", null, LocaleContextHolder.getLocale()));
                                  }
			                    }else if((cStatusDoc == bidderDocStatusApprove || cStatusDoc == officerDocStatusApprove) && !linkId.equals(bidderBlacklistLinkId)){
			                    	strDocList.append("<a href='#' onclick=\"removeFile('");
				                    strDocList.append(lstDocumentDetails.get(i)[0]);
				                    strDocList.append("','").append((userTypeId == 1 || userTypeId ==3 ? officerDocStatusApprove : bidderDocStatusApprove)).append("');\">");
				                    strDocList.append(messageSource.getMessage("link_approve", null, LocaleContextHolder.getLocale())).append("</a>  | ");
			                    }else if((cStatusDoc == bidderDocStatusCancel || cStatusDoc == officerDocStatusCancel) && (Integer)lstDocumentDetails.get(i)[5] == 1){
			                    	strDocList.append("<a href='#' onclick=\"removeFile('");
				                    strDocList.append(lstDocumentDetails.get(i)[0]);
				                    strDocList.append("','").append((userTypeId == 1 || userTypeId ==3 ? officerDocStatusCancel : bidderDocStatusCancel)).append("');\">");
				                    strDocList.append(messageSource.getMessage("link_cancel", null, LocaleContextHolder.getLocale())).append("</a>  | ");
			                    }
			                    if(sessionBean == null){
		                    		  strDocList.append(" <a href=").append(request.getContextPath()).append("/ajaxcall/downloadfile/");
		                    		  strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                                      strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
                                      strDocList.append(">");
                                      strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                                      if((Integer)lstDocumentDetails.get(i)[5] == 1 && amenCount!=0 && (Integer)lstDocumentDetails.get(i)[8]!=0  && latestAmendmentId==(Integer)lstDocumentDetails.get(i)[8]){strDocList.append("<span class='green'> (New)</span>");}
                                      strDocList.append("</td>");
			                    }else if(userTypeId ==1 || userTypeId == 3 || "Y".equalsIgnoreCase(isAuctionDocDownload)){
			                    	
	                    			strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadfile/");
	                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
	                    			strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
	                    			strDocList.append(">");
	                    			strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
	                    			if((Integer)lstDocumentDetails.get(i)[5] == 1 && amenCount!=0 && (Integer)lstDocumentDetails.get(i)[8]!=0  && latestAmendmentId==(Integer)lstDocumentDetails.get(i)[8]){strDocList.append("<span class='green'> (New)</span>");}
	                    			strDocList.append("</td>");
			                    }else if(userTypeId == 2 && "Y".equalsIgnoreCase(isBidderDocDownload)){
		                    			strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadbidderfile/");
		                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
		                    			strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadbidderfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
		                    			strDocList.append(">");
		                    			strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
		                    			strDocList.append("</td>");
		                    	}
	                    }else{                                     
	                    	if(sessionBean == null){
                    			strDocList.append(" <td class='a-center noprint'> <a href=").append(request.getContextPath()).append("/ajaxcall/downloadfile/");
                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
                    			strDocList.append(">");
                    			strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
                    			if((Integer)lstDocumentDetails.get(i)[5] == 1 && amenCount!=0 && (Integer)lstDocumentDetails.get(i)[8]!=0  && latestAmendmentId==(Integer)lstDocumentDetails.get(i)[8]){strDocList.append("<span class='green'> (New)</span>");}
                    			strDocList.append("</td>");
		                    }
	                    	else if((userTypeId ==1 || userTypeId == 3 || "Y".equalsIgnoreCase(isAuctionDocDownload)) && !"Y".equalsIgnoreCase(isBidderDocDownload)){
	                    		
	                    			strDocList.append("         <td class='noprint' width='9%' style=\"padding: 5px;\">");
	                    			strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadfile/");
	                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
	                    			strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
	                    			strDocList.append(">");
	                    			strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
	                    			if((Integer)lstDocumentDetails.get(i)[5] == 1 && amenCount!=0 && (Integer)lstDocumentDetails.get(i)[8]!=0 && latestAmendmentId==(Integer)lstDocumentDetails.get(i)[8]){strDocList.append("<span class='green'> (New)</span>");}
	                    			strDocList.append("</td>");
	                    	}else{
	                    		if(userTypeId == 2 || "Y".equalsIgnoreCase(isBidderDocDownload)){
	                    			strDocList.append("         <td class='noprint' width='9%' style=\"padding: 5px;\">");
	                    			strDocList.append(" <a href=").append(request.getContextPath()).append("/ajax/downloadbidderfile/");
	                    			strDocList.append(lstDocumentDetails.get(i)[0]).append("/").append(objectId);
	                    			strDocList.append(encryptDecryptUtils.generateRedirect("ajax/downloadbidderfile/"+lstDocumentDetails.get(i)[0]+"/"+objectId, request));
	                    			strDocList.append(">");
	                    			strDocList.append(messageSource.getMessage("link_download", null, LocaleContextHolder.getLocale())).append("</a>");
	                    			strDocList.append("</td>");
	                    		}
	                    	}
	                    }
                    // }
	                    strDocList.append("</tr>");
              }
          }else{
          	strDocList.append(" <tr id='trEmptyDocList'> <td colspan='7'>").append(messageSource.getMessage("empty_records", null, LocaleContextHolder.getLocale())).append("</td></tr>");
          }
          response.getWriter().write(strDocList.toString());
      	}else{
      		response.getWriter().write("sessionexpired");
      	}
      } catch (Exception ex) {
          exceptionHandlerService.writeLog(ex);
      }
//      finally{
//      	auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDocumentDetails, objectId, 0);
//      }
  }
  
  /**
   * This will download all images for tableId/objectId and create zip childId wise then master zip for objectId
   * @author ashish.jani
   * @param request
   * @param response
   * @param objectId 
   * @param linkId
   * @return 
   */
  @RequestMapping(value={"/common/sector/buyer/downloadallimages/{objectId}/{linkId}/{childId}/{enc}","/downloadallimages/{objectId}/{linkId}/{childId}"}, method=RequestMethod.GET)
	 public void downloadAllWithZip(HttpServletRequest request,HttpServletResponse response,@PathVariable("objectId")int objectId,@PathVariable("linkId")int linkId,@PathVariable("childId")int childId){
	  	ServletOutputStream outputStream = null;
	  	 int clientId = abcUtility.getSessionClientId(request);
	  	 ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	  	String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
		 if(childId == 0){
		  	 //get child ids
			 List<Object> lstChildids = null;
			try {
				lstChildids = fileUploadService.getChildIds(objectId, clientId, linkId);
			
				 List<String[]> strChildZips = new ArrayList<String[]>();
				 //download and create zip for childId_i
				 String filePath = docUploadPath+"\\"+clientId+"\\Auction\\Sector\\"+objectId;
				 String auctionId = sectorService.getItemNameFromChildId(objectId, 769, Integer.parseInt(lstChildids.get(0).toString()),clientBean.getSectorTableName()).get(0)[2].toString();
				 File masterZip = new File(filePath+"\\"+auctionId+".zip");
			
				 for(Object childId_i : lstChildids){
					 int intChildId = Integer.parseInt(childId_i.toString());
					 String itemName = null;
					try {
						itemName = sectorService.getItemNameFromChildId(objectId, 769, intChildId,clientBean.getSectorTableName()).get(0)[1].toString();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					 downloadDocumentAsZip(intChildId,objectId,linkId,clientId,itemName);
					 String[] strArr = new String[4];
					 strArr[0] = itemName+".zip";
					 strArr[1] = "0";
					 strArr[2] = "0";
					 strArr[3] = "\\"+clientId+"\\Auction\\Sector\\"+objectId;
					 strChildZips.add(strArr);
				 }
				 //create master zip on objectid
				File dir = new File(filePath);
				dir = abcUtility.CheckDirLength(dir);
		 		if(dir.exists() && dir.list().length!=0 && strChildZips.size()!=0){
		 			try {
						abcUtility.zipDirectory(dir, masterZip, strChildZips);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		 		}
		 		if(masterZip.exists()){
		 			FileInputStream fis = null ;
		 			try{
		 				outputStream = response.getOutputStream();
			 			fis = new FileInputStream(masterZip);
			            byte[] buf = new byte[(int) masterZip.length()];
			            int offset = 0;
			            int numRead = 0;
			            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
			                offset += numRead;
			            }
			//         
			            response.setContentType("application/octet-stream");
			            response.setHeader("Content-Disposition", "attachment;filename=\"" + auctionId + ".zip\"");
			            outputStream = response.getOutputStream();
			            outputStream.write(buf);
			            fis.close();
		 			}catch(Exception ex){
		 				ex.printStackTrace();
		 			}finally{
			            try {
							outputStream.flush();
							outputStream.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			            
			            auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),downloadLinkId,getDownloadAllItemZip,ipAddress,objectId,childId);
		 			}
		            
		 		}
	 		} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		 }else{
			 String itemName = null;
			try {
				itemName = sectorService.getItemNameFromChildId(objectId, 769, childId,clientBean.getSectorTableName()).get(0)[1].toString();
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			 downloadDocumentAsZip(childId,objectId,linkId,clientId,itemName);
			 String filePath=docUploadPath+"\\"+clientId+"\\Auction\\Sector\\"+objectId;            
			 File zip = new File(filePath+"\\"+itemName+".zip");
			 if(zip.exists()){
				 FileInputStream fis = null;
				 try{
		 				outputStream = response.getOutputStream();
			 			fis = new FileInputStream(zip);
			            byte[] buf = new byte[(int) zip.length()];
			            int offset = 0;
			            int numRead = 0;
			            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
			                offset += numRead;
			            }
			//         
			            response.setContentType("application/octet-stream");
			            response.setHeader("Content-Disposition", "attachment;filename=\"" + itemName + ".zip\"");
			            outputStream = response.getOutputStream();
			            outputStream.write(buf);
		 			}catch(Exception ex){
		 				ex.printStackTrace();
		 			}finally{
			            try {
							outputStream.flush();
							outputStream.close();
							fis.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
			            auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),downloadLinkId,getDownloadItemZip,ipAddress,objectId,childId);
		 			}
			 }
		 }
	 }

	private void downloadDocumentAsZip(int childId, int objectId, int linkId,int clientId,String itemName) {
		// TODO Auto-generated method stub
		try {
        	String filePath=docUploadPath+"\\"+clientId+"\\Auction\\Sector\\"+objectId;            
            File zip = new File(filePath+"\\"+itemName+".zip");
        	List<Object[]> lstDocuments = fileUploadService.getOfficerDocs(objectId, childId, clientId, linkId, 1);
    		int isEncryptionReq=0;
    		List<String[]> filesToZip = new ArrayList<String[]>();
    		if(!lstDocuments.isEmpty()){
    			for(Object[] obj : lstDocuments){
	    			String[] strArr = new String[4];
		    		strArr[0] = obj[1].toString();
		    		strArr[1] = "0";
		    		strArr[2] = obj[3].toString();
		    		strArr[3] = obj[7].toString();
		    		//isEncryptionReq=(Integer)lstDocuments.get(0)[6];
		    		filesToZip.add(strArr);
    			}
    		}
    		File dir = new File(filePath+"\\"+childId);
    		dir = abcUtility.CheckDirLength(dir);
    		if(dir.exists() && dir.list().length!=0 && filesToZip.size()!=0){
    			abcUtility.zipDirectory(dir, zip, filesToZip);
    		}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
     * Ajax call to upload the gsl bidder registration in documents 
     * @author Janak Dhanani
     * @param ModelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/uploadbidderregdoc", method = RequestMethod.POST)
    @ResponseBody
    public String uploadBidderRegdoc(ModelMap modelMap, HttpServletRequest request,@RequestParam("opType") int opType) {

        boolean isValidate = true;
        JSONObject jsonObject = null;
        String filePath = null;
        boolean fileUploadedSuccess = false;
        int isEncryptionReq = 0;
        int clientId = 0;
        String docId = null;
        try {
        	String tempUserId = null;
        	SessionBean sessionBean = request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
        	if(sessionBean != null){
        		tempUserId =sessionBean.getUserId()+"" ; // after login
        	}else{
        		tempUserId = request.getSession().getId().toString(); //before login
        	}
        	clientId = abcUtility.getSessionClientId(request);
        	
        	TblDocUploadConf lstDocUploadConf = commonService.getDocUploadConf(14, clientId).get(0);
            File file = null;
            String dataStatus=null;
            File tmpDir = null;
            jsonObject = new JSONObject();
            long fileSize = 0;
            String fileName = null;
            long fileMaxSize = lstDocUploadConf.getMaxSize() * 1024;
            String fileExtensions = lstDocUploadConf.getType();
            String path = lstDocUploadConf.getPath(); 
            isEncryptionReq=lstDocUploadConf.getIsEncryptionReq();
            String tmpDirPath = docUploadPath + path;
			isDirExists(tmpDirPath);
            DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
            fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
            ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
            List items = uploadHandler.parseRequest(request);
            Iterator itr = items.iterator();
            filePath = "null";
            while (itr.hasNext()) {
                FileItem item = (FileItem) itr.next();
                if (!item.isFormField()) {
                    fileSize = item.getSize();
                    if (item.getName().lastIndexOf("\\") != -1) {
                        fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1, item.getName().length());
                    } else {
                        fileName = item.getName();
                    }
                    if (fileName != null && !fileName.equalsIgnoreCase("")) {
                        if (fileSize == 0) {
                            dataStatus = messageSource.getMessage("size_zero_not_allowed", null, LocaleContextHolder.getLocale());
                            isValidate = false;
                            break;
                        }
                        if (!checkFileSize(fileSize, fileMaxSize)) {
                            dataStatus = messageSource.getMessage("max_file_size", new Object[]{(fileMaxSize / (1024*1024))}, LocaleContextHolder.getLocale());
                            isValidate = false;
                            break;
                        }
                        if (!checkFileExn(fileName, fileExtensions)) {
                            dataStatus = messageSource.getMessage("not_allowed_other_filetype", new Object[] { fileExtensions }, LocaleContextHolder.getLocale());
                            isValidate = false;
                            break;
                        } else {
                            /* if destination directory not exist then create it*/
                        	dataStatus = "null";
                        	docId = item.getFieldName().split("_")[1];
                        	tmpDirPath = tmpDirPath + "\\" + tempUserId + "\\" + (opType ==1 ? "RegisteredIn" :"IndustryClassification") + (opType ==1 ? "\\"+docId :""); 
                        			;
                        	tmpDir = new File(tmpDirPath);
                            if (!tmpDir.isDirectory()) {
                                tmpDir.mkdirs();
                            }
                            tmpDir = new File(tmpDirPath);
                            if (!tmpDir.isDirectory()) {
                                tmpDir.mkdir();
                            }
                            file = new File(tmpDir, fileName);
                            item.write(file);
                            if (isEncryptionReq == 1) {
                                fileSize = fileEncryptDecryptUtil.fileEncryptUtil(file, (int) fileSize);
                            }
                            fileUploadedSuccess = true;
                            filePath = file.getCanonicalPath();
                        }
                    }
                }
            }
            if (isValidate) {
				if (fileUploadedSuccess) {
					TblBidderDocument tblBidderDocument = new TblBidderDocument();
					tblBidderDocument.setDocName(fileName);
					tblBidderDocument.setTblClient(new TblClient(clientId));
					tblBidderDocument.setBidderFolderId(1);
					tblBidderDocument.setPath(path + "\\" + tempUserId + "\\" + (opType ==1 ? "RegisteredIn" :"IndustryClassification") + (opType ==1 ? "\\"+docId :"")); 
					tblBidderDocument.setDescription(opType ==1 ? "RegisteredIn" : "IndustryClassification");
					tblBidderDocument.setFileSize(fileSize);
					tblBidderDocument.setCstatus(1);
					tblBidderDocument.setIsEncryptionReq(lstDocUploadConf.getIsEncryptionReq());
					if(sessionBean == null){
						tblBidderDocument.setCreatedBy(0);
		        	}else{
		        		tblBidderDocument.setCreatedBy(sessionBean.getUserId());
		        	}
					manageBidderService.addBidderDocument(tblBidderDocument);
					jsonObject.put("docId", encryptDecryptUtils.encrypt(tblBidderDocument.getBidderDocId()+""));
				}
			}
            jsonObject.put("dataStatus", dataStatus);
            jsonObject.put("fileUploadedSuccess", fileUploadedSuccess);
            
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
        	//auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),1, 2, 0, 0);
        }
        return jsonObject.toString().trim();
     }
    
    private boolean isDirExists(String apath) {
		boolean flag = false;
		File f = new File(apath);
		if (!f.isDirectory()) {
			f.mkdirs();
		}

		return flag;
	}
    /**
     * to download the bidder document
     * @param docId
     * @param request
     * @param response
     * @param session
     */
    @RequestMapping(value = "/ajaxcall/downloadbidderfile/{docId}")
    public void downloadRegistrationBidderFile(@PathVariable(DOC_ID) String encDocId,HttpServletRequest request,HttpServletResponse response) {
        ServletOutputStream outputStream = null;
        InputStream fis=null;
        int linkId=24;
        int docId = Integer.parseInt(encryptDecryptUtils.decrypt(encDocId));
        try {
        	String filePath=null;
        	String fileName=null;
        	
    		TblBidderDocument tblBidderDocument=fileUploadService.getBidderDocumentById(docId);
            int isEncryptionReq=0;
    		if(tblBidderDocument != null ){
	    		filePath=docUploadPath+tblBidderDocument.getPath();
	    		filePath=filePath.replace("\\", "\\\\");
	    		filePath += "\\"+tblBidderDocument.getDocName();
	    		fileName=tblBidderDocument.getDocName();
	    		isEncryptionReq=tblBidderDocument.getIsEncryptionReq();
    		}
            File file = null;
            file = new File(filePath);
            file = abcUtility.CheckDirExist(file);
            if(file.exists()){
	            fis = new FileInputStream(file);
	            byte[] buf = new byte[(int) file.length()];
	            int offset = 0;
	            int numRead = 0;
	            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
	                offset += numRead;
	            }
	            if(isEncryptionReq == 1){
	                buf = fileEncryptDecryptUtil.fileDecryptUtil(buf);
	            }
	            response.setContentType("application/octet-stream");
	            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
	            outputStream = response.getOutputStream();
	            outputStream.write(buf);
	            outputStream.flush();
	            outputStream.close();
	        }
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }finally{
        	if(fis != null){
        		try {
					fis.close();
				} catch (IOException e) {
				}
        	}
        	makeModuleBasedAuditTrialEntries(request,request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getDownloadRegDoc, 0, docId);
        }
    }
    
    /**
     * to change the status of the document and remove physical file (if status is rejected(delete))
     */
    @RequestMapping(value = "/ajaxcall/deletebidderfile",method = RequestMethod.POST)
    public void removeUploadedBidderRegistrationFile(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
        String encDocId = StringUtils.hasLength(request.getParameter("txtdocId")) ? request.getParameter("txtdocId").toString() : "0";
        boolean delFlag = false;
        try {
        	int docId = Integer.parseInt(encryptDecryptUtils.decrypt(encDocId));
    		TblBidderDocument tblBidderDocument=fileUploadService.getBidderDocumentById(docId);
    		if(tblBidderDocument != null){
        		String filePath=docUploadPath+tblBidderDocument.getPath();
        		filePath=filePath.replace("\\", "\\\\");
        		filePath += "\\"+tblBidderDocument.getDocName();
        		File f = new File(filePath);
        		f = abcUtility.CheckDirExist(f);
        		if(f.exists()){
        			delFlag = deleteFile(f.getPath());
        		}
	        	if (delFlag) {
	        		delFlag = fileUploadService.updateBidderDocDocumentForRemove(docId,0);
	            }
    		}
        	response.getWriter().write(delFlag + "");
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
    }
    
    @RequestMapping(value = {"/etender/buyer/bidderItemWiseFormdocaszip/{tenderId}/{companyId}/{envelopeId}/{enc}", "/etender/bidder/bidderItemWiseFormdocaszip/{tenderId}/{companyId}/{envelopeId}/{enc}"}, method = RequestMethod.GET)
    public String downloadBidderItemWiseFormdocaszip(@PathVariable("tenderId") Integer tenderId, @PathVariable("companyId") Integer companyId,@PathVariable("envelopeId") Integer envelopeId ,HttpServletRequest request, HttpServletResponse response, RedirectAttributes redirectAttributes) {
        try {
        	 int needfresh=1;
             String companyName = abcUtility.correctFileName(commonService.getCompanyNameByCompanyId(companyId) + "_" + tenderId);
             String filePathFragment = fileDrive + fileUpload + tenderwiseReport + "\\" + tenderId + "\\"+ companyId + "\\" + envelopeId;
             String filePath = filePathFragment + "\\" + companyName;
             System.out.println("FilePathFragment Before--" + filePathFragment);
             
             File  zfile = new File(filePath+".zip");
             
             File theDir = zfile.getParentFile();
             if(!theDir.exists() && !theDir.mkdirs()){
                 throw new IllegalStateException("Couldn't create dir: " + theDir);
             }
             
             
             List<Object[]> bidderDocs = fileUploadService.getBidderItemWiseDocs(companyId, envelopeId );
             List<String[]> approvedDoc = new ArrayList<String[]>();
        
            ServletOutputStream outputStream = null;
            boolean isZipAvail = true;
            for (Object[] docs : bidderDocs) {
                String[] approvedDocsArr = new String[4] ;
                approvedDocsArr[0]=docs[1].toString();
                approvedDocsArr[1]=docs[5].toString();
                approvedDocsArr[2]=docs[6].toString();
                approvedDocsArr[3]=docs[0].toString();
                approvedDoc.add(approvedDocsArr);
            }
            
            
             String souceFilePath="";
             if(needfresh==1 || !zfile.exists()){
                if(bidderDocs!=null && !bidderDocs.isEmpty()){
                    Object[] docs=bidderDocs.get(0);
                    souceFilePath=docUploadPath + docs[0];
                }
                File dir = new File(souceFilePath);
                if(approvedDoc.size()!=0){
                	if(!dir.exists()){
                		dir.mkdir();
                	}
                    abcUtility.zipDirectory(dir, zfile,approvedDoc);
                }else{
                    isZipAvail = false;
                }
                
            }     
            response.setContentType("application/octet-stream");
            if (isZipAvail) {
                FileInputStream fis = new FileInputStream(zfile);
                byte[] buf = new byte[(int) zfile.length()];
                int offset = 0;
                int numRead = 0;
                while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                    offset += numRead;
                }
                response.setContentType("application/octet-stream");
                response.setHeader("Content-Disposition", "attachment;filename=\"" + zfile.getName() + "\"");
                outputStream = response.getOutputStream();
                outputStream.write(buf);
                outputStream.flush();
                outputStream.close();
                fis.close();
                return null;
            } else {
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_tender_nodocforzip");
                String refererUrl = request.getHeader("referer");
                return "redirect:" + refererUrl.substring(refererUrl.indexOf("EPROC") + 5, refererUrl.length());
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
    }
    
    
    private boolean renameDir(String dirPath,String newDirName) {
        boolean flg = false;
        try {
            File existF = new File(dirPath);
            File newF=new File(existF.getParent() + "/" + newDirName);
            if(existF.exists()){
            	flg=existF.renameTo(newF);
            }
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
        return flg;
    }
    @RequestMapping(value = "/ajaxcall/checkDocStatus", method = RequestMethod.POST)
    @ResponseBody
    public String checkDocStatus(@RequestParam(DOC_ID) int docId,HttpServletRequest request) {
    	String isCanceledDoc = "";
         try { 
        	 List<Object[]> tblOfficerDocument = fileUploadService.getOfficerDocDetailsForRemove(docId);
        	 if(!tblOfficerDocument.isEmpty() && Integer.parseInt(tblOfficerDocument.get(0)[4].toString()) == 3){
        		 isCanceledDoc = "true";
        	 }
         }
		 catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
         }
         finally{
             //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), LinkId,Remark, 0,0,"");
         }
       return isCanceledDoc;
    }

}
