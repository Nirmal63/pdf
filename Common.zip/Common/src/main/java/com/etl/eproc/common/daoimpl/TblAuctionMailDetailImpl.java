package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblAuctionMailDetail;
import com.etl.eproc.common.daointerface.TblAuctionMailDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author jitendra
 */
@Repository @Transactional    /*StackUpdate*/
public class TblAuctionMailDetailImpl extends AbcAbstractClass<TblAuctionMailDetail> implements TblAuctionMailDetailDao {

    @Override
    public void addTblAuctionMailDetail(TblAuctionMailDetail tblAuctionMailDetail){
        super.addEntity(tblAuctionMailDetail);
    }

    @Override
    public void deleteTblAuctionMailDetail(TblAuctionMailDetail tblAuctionMailDetail) {
        super.deleteEntity(tblAuctionMailDetail);
    }

    @Override
    public void updateTblAuctionMailDetail(TblAuctionMailDetail tblAuctionMailDetail) {
        super.updateEntity(tblAuctionMailDetail);
    }

    @Override
    public List<TblAuctionMailDetail> getAllTblAuctionMailDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAuctionMailDetail> findTblAuctionMailDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAuctionMailDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAuctionMailDetail> findByCountTblAuctionMailDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAuctionMailDetail(List<TblAuctionMailDetail> tblAuctionMailDetails){
        super.updateAll(tblAuctionMailDetails);
    }
}
