package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblFormBusinessType;
import com.etl.eproc.common.daointerface.TblFormBusinessTypeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblFormBusinessTypeImpl extends AbcAbstractClass<TblFormBusinessType> implements TblFormBusinessTypeDao {

    @Override
    public void addTblFormBusinessType(TblFormBusinessType tblFormBusinessType){
        super.addEntity(tblFormBusinessType);
    }

    @Override
    public void deleteTblFormBusinessType(TblFormBusinessType tblFormBusinessType) {
        super.deleteEntity(tblFormBusinessType);
    }

    @Override
    public void updateTblFormBusinessType(TblFormBusinessType tblFormBusinessType) {
        super.updateEntity(tblFormBusinessType);
    }

    @Override
    public List<TblFormBusinessType> getAllTblFormBusinessType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFormBusinessType> findTblFormBusinessType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFormBusinessTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFormBusinessType> findByCountTblFormBusinessType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFormBusinessType(List<TblFormBusinessType> tblFormBusinessTypes){
        super.updateAll(tblFormBusinessTypes);
    }
}
