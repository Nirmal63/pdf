package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblFormProduct;
import com.etl.eproc.common.daointerface.TblFormProductDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblFormProductImpl extends AbcAbstractClass<TblFormProduct> implements TblFormProductDao {

    @Override
    public void addTblFormProduct(TblFormProduct tblFormProduct){
        super.addEntity(tblFormProduct);
    }

    @Override
    public void deleteTblFormProduct(TblFormProduct tblFormProduct) {
        super.deleteEntity(tblFormProduct);
    }

    @Override
    public void updateTblFormProduct(TblFormProduct tblFormProduct) {
        super.updateEntity(tblFormProduct);
    }

    @Override
    public List<TblFormProduct> getAllTblFormProduct() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFormProduct> findTblFormProduct(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFormProductCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFormProduct> findByCountTblFormProduct(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFormProduct(List<TblFormProduct> tblFormProducts){
        super.updateAll(tblFormProducts);
    }
}
