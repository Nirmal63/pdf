/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

/**
 *
 * @author taher.tinwala
 */
import com.etl.eproc.common.model.TblFormRule;
import com.etl.eproc.common.daointerface.TblFormRuleDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblFormRuleImpl extends AbcAbstractClass<TblFormRule> implements TblFormRuleDao {

    @Override
    public void addTblFormRule(TblFormRule tblFormRule){
        super.addEntity(tblFormRule);
    }

    @Override
    public void deleteTblFormRule(TblFormRule tblFormRule) {
        super.deleteEntity(tblFormRule);
    }

    @Override
    public void updateTblFormRule(TblFormRule tblFormRule) {
        super.updateEntity(tblFormRule);
    }

    @Override
    public List<TblFormRule> getAllTblFormRule() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFormRule> findTblFormRule(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFormRuleCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFormRule> findByCountTblFormRule(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFormRule(List<TblFormRule> tblFormRules){
        super.updateAll(tblFormRules);
    }
}

