package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblMasterBid;
import com.etl.eproc.common.daointerface.TblMasterBidDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMasterBidImpl extends AbcAbstractClass<TblMasterBid> implements TblMasterBidDao {

    @Override
    public void addTblMasterBid(TblMasterBid tblMasterBid){
        super.addEntity(tblMasterBid);
    }

    @Override
    public void deleteTblMasterBid(TblMasterBid tblMasterBid) {
        super.deleteEntity(tblMasterBid);
    }

    @Override
    public void updateTblMasterBid(TblMasterBid tblMasterBid) {
        super.updateEntity(tblMasterBid);
    }

    @Override
    public List<TblMasterBid> getAllTblMasterBid() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMasterBid> findTblMasterBid(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMasterBidCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMasterBid> findByCountTblMasterBid(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMasterBid(List<TblMasterBid> tblMasterBids){
        super.updateAll(tblMasterBids);
    }
}
