package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMvpVertical;
import java.util.List;

public interface TblMvpVerticalDao  {

    public void addTblMvpVertical(TblMvpVertical tblMvpVertical);

    public void deleteTblMvpVertical(TblMvpVertical tblMvpVertical);

    public void updateTblMvpVertical(TblMvpVertical tblMvpVertical);

    public List<TblMvpVertical> getAllTblMvpVertical();

    public List<TblMvpVertical> findTblMvpVertical(Object... values) throws Exception;

    public List<TblMvpVertical> findByCountTblMvpVertical(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMvpVerticalCount();

    public void saveUpdateAllTblMvpVertical(List<TblMvpVertical> tblMvpVerticals);
}	