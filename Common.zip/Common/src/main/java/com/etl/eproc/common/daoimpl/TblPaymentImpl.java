package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblPayment;
import com.etl.eproc.common.daointerface.TblPaymentDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblPaymentImpl extends AbcAbstractClass<TblPayment> implements TblPaymentDao {

    @Override
    public void addTblPayment(TblPayment tblPayment){
        super.addEntity(tblPayment);
    }

    @Override
    public void deleteTblPayment(TblPayment tblPayment) {
        super.deleteEntity(tblPayment);
    }

    @Override
    public void updateTblPayment(TblPayment tblPayment) {
        super.updateEntity(tblPayment);
    }

    @Override
    public List<TblPayment> getAllTblPayment() {
        return super.getAllEntity();
    }

    @Override
    public List<TblPayment> findTblPayment(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblPaymentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblPayment> findByCountTblPayment(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblPayment(List<TblPayment> tblPayments){
        super.updateAll(tblPayments);
    }

	@Override
	public void saveOrUpdateTblPayment(TblPayment tblPayment) {
		super.saveOrUpdateEntity(tblPayment);
	}
}
