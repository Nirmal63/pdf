package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblLastTransactionDetail;
import java.util.List;

public interface TblLastTransactionDetailDao  {

    public void addTblLastTransactionDetail(TblLastTransactionDetail tblLastTransactionDetail);

    public void deleteTblLastTransactionDetail(TblLastTransactionDetail tblLastTransactionDetail);

    public void updateTblLastTransactionDetail(TblLastTransactionDetail tblLastTransactionDetail);

    public List<TblLastTransactionDetail> getAllTblLastTransactionDetail();

    public List<TblLastTransactionDetail> findTblLastTransactionDetail(Object... values) throws Exception;

    public List<TblLastTransactionDetail> findByCountTblLastTransactionDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblLastTransactionDetailCount();

    public void saveUpdateAllTblLastTransactionDetail(List<TblLastTransactionDetail> tblLastTransactionDetails);

	public void saveOrUpdateTblLastTransactionDetail(TblLastTransactionDetail tblLastTransactionDetail);
}