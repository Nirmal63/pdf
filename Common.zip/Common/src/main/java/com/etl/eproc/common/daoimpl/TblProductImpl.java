package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblProductDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblProduct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblProductImpl extends AbcAbstractClass<TblProduct> implements TblProductDao {

    @Override
    public void addTblProduct(TblProduct tblProduct){
        super.addEntity(tblProduct);
    }

    @Override
    public void deleteTblProduct(TblProduct tblProduct) {
        super.deleteEntity(tblProduct);
    }

    @Override
    public void updateTblProduct(TblProduct tblProduct) {
        super.updateEntity(tblProduct);
    }

    @Override
    public List<TblProduct> getAllTblProduct() {
        return super.getAllEntity();
    }

    @Override
    public List<TblProduct> findTblProduct(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblProductCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblProduct> findByCountTblProduct(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblProduct(List<TblProduct> tblProducts){
        super.updateAll(tblProducts);
    }
}
