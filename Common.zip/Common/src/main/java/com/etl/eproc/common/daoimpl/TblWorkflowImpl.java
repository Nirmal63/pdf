package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblWorkflow;
import com.etl.eproc.common.daointerface.TblWorkflowDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblWorkflowImpl extends AbcAbstractClass<TblWorkflow> implements TblWorkflowDao {

    @Override
    public void addTblWorkflow(TblWorkflow tblWorkflow){
        super.addEntity(tblWorkflow);
    }

    @Override
    public void deleteTblWorkflow(TblWorkflow tblWorkflow) {
        super.deleteEntity(tblWorkflow);
    }

    @Override
    public void updateTblWorkflow(TblWorkflow tblWorkflow) {
        super.updateEntity(tblWorkflow);
    }

    @Override
    public List<TblWorkflow> getAllTblWorkflow() {
        return super.getAllEntity();
    }

    @Override
    public List<TblWorkflow> findTblWorkflow(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblWorkflowCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblWorkflow> findByCountTblWorkflow(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblWorkflow(List<TblWorkflow> tblWorkflows){
        super.updateAll(tblWorkflows);
    }

	@Override
	public void deleteAllTblWorkflow(List<TblWorkflow> tblWorkflows) {
		super.deleteAll(tblWorkflows);
	}
}
