package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblPasswordHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblPasswordHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblPasswordHistoryImpl extends AbcAbstractClass<TblPasswordHistory> implements TblPasswordHistoryDao {

    @Override
    public void addTblPasswordHistory(TblPasswordHistory tblPasswordHistory){
        super.addEntity(tblPasswordHistory);
    }

    @Override
    public void deleteTblPasswordHistory(TblPasswordHistory tblPasswordHistory) {
        super.deleteEntity(tblPasswordHistory);
    }

    @Override
    public void updateTblPasswordHistory(TblPasswordHistory tblPasswordHistory) {
        super.updateEntity(tblPasswordHistory);
    }

    @Override
    public List<TblPasswordHistory> getAllTblPasswordHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblPasswordHistory> findTblPasswordHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblPasswordHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblPasswordHistory> findByCountTblPasswordHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblPasswordHistory(List<TblPasswordHistory> tblPasswordHistorys){
        super.updateAll(tblPasswordHistorys);
    }

	@Override
	public void saveOrUpdateTblPasswordHistory(TblPasswordHistory tblPasswordHistory) {
		super.saveOrUpdateEntity(tblPasswordHistory);
	}
}
