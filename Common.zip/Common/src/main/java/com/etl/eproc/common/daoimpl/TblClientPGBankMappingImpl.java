package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblClientPGBankMapping;
import com.etl.eproc.common.daointerface.TblClientPGBankMappingDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientPGBankMappingImpl extends AbcAbstractClass<TblClientPGBankMapping> implements TblClientPGBankMappingDao {

    @Override
    public void addTblClientPGBankMapping(TblClientPGBankMapping tblClientPGBankMapping){
        super.addEntity(tblClientPGBankMapping);
    }

    @Override
    public void deleteTblClientPGBankMapping(TblClientPGBankMapping tblClientPGBankMapping) {
        super.deleteEntity(tblClientPGBankMapping);
    }

    @Override
    public void updateTblClientPGBankMapping(TblClientPGBankMapping tblClientPGBankMapping) {
        super.updateEntity(tblClientPGBankMapping);
    }

    @Override
    public List<TblClientPGBankMapping> getAllTblClientPGBankMapping() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientPGBankMapping> findTblClientPGBankMapping(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientPGBankMappingCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientPGBankMapping> findByCountTblClientPGBankMapping(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientPGBankMapping(List<TblClientPGBankMapping> tblClientPGBankMappings){
        super.updateAll(tblClientPGBankMappings);
    }
}
