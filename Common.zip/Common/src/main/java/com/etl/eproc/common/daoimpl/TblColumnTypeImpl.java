package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblColumnType;
import com.etl.eproc.common.daointerface.TblColumnTypeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblColumnTypeImpl extends AbcAbstractClass<TblColumnType> implements TblColumnTypeDao {

    @Override
    public void addTblColumnType(TblColumnType tblColumnType){
        super.addEntity(tblColumnType);
    }

    @Override
    public void deleteTblColumnType(TblColumnType tblColumnType) {
        super.deleteEntity(tblColumnType);
    }

    @Override
    public void updateTblColumnType(TblColumnType tblColumnType) {
        super.updateEntity(tblColumnType);
    }

    @Override
    public List<TblColumnType> getAllTblColumnType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblColumnType> findTblColumnType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblColumnTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblColumnType> findByCountTblColumnType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblColumnType(List<TblColumnType> tblColumnTypes){
        super.updateAll(tblColumnTypes);
    }
}
