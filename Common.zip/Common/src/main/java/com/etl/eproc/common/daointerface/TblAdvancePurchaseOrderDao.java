package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblAdvancePurchaseOrder;

public interface TblAdvancePurchaseOrderDao {

    public void addTblAdvancePurchaseOrder(TblAdvancePurchaseOrder tblAdvancePurchaseOrder);

    public void deleteTblAdvancePurchaseOrder(TblAdvancePurchaseOrder tblAdvancePurchaseOrder);

    public void updateTblAdvancePurchaseOrder(TblAdvancePurchaseOrder tblAdvancePurchaseOrder);

    public List<TblAdvancePurchaseOrder> getAllTblAdvancePurchaseOrder();

    public List<TblAdvancePurchaseOrder> findTblAdvancePurchaseOrder(Object... values) throws Exception;

    public List<TblAdvancePurchaseOrder> findByCountTblAdvancePurchaseOrder(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAdvancePurchaseOrderCount();

    public void saveUpdateAllTblAdvancePurchaseOrder(List<TblAdvancePurchaseOrder> tblAdvancePurchaseOrders);

	public void saveOrUpdateTblAdvancePurchaseOrder(TblAdvancePurchaseOrder tblAdvancePurchaseOrder);
}