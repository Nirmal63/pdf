package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblLanguageDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblLanguage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblLanguageImpl extends AbcAbstractClass<TblLanguage> implements TblLanguageDao {

    @Override
    public void addTblLanguage(TblLanguage tblLanguage){
        super.addEntity(tblLanguage);
    }

    @Override
    public void deleteTblLanguage(TblLanguage tblLanguage) {
        super.deleteEntity(tblLanguage);
    }

    @Override
    public void updateTblLanguage(TblLanguage tblLanguage) {
        super.updateEntity(tblLanguage);
    }

    @Override
    public List<TblLanguage> getAllTblLanguage() {
        return super.getAllEntity();
    }

    @Override
    public List<TblLanguage> findTblLanguage(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblLanguageCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblLanguage> findByCountTblLanguage(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblLanguage(List<TblLanguage> tblLanguages){
        super.updateAll(tblLanguages);
    }
}
