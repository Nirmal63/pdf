package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblDynFieldGroupMapping;
import com.etl.eproc.common.daointerface.TblDynFieldGroupMappingDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDynFieldGroupMappingImpl extends AbcAbstractClass<TblDynFieldGroupMapping> implements TblDynFieldGroupMappingDao {

    @Override
    public void addTblDynFieldGroupMapping(TblDynFieldGroupMapping tblDynFieldGroupMapping){
        super.addEntity(tblDynFieldGroupMapping);
    }

    @Override
    public void deleteTblDynFieldGroupMapping(TblDynFieldGroupMapping tblDynFieldGroupMapping) {
        super.deleteEntity(tblDynFieldGroupMapping);
    }

    @Override
    public void updateTblDynFieldGroupMapping(TblDynFieldGroupMapping tblDynFieldGroupMapping) {
        super.updateEntity(tblDynFieldGroupMapping);
    }

    @Override
    public List<TblDynFieldGroupMapping> getAllTblDynFieldGroupMapping() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynFieldGroupMapping> findTblDynFieldGroupMapping(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynFieldGroupMappingCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynFieldGroupMapping> findByCountTblDynFieldGroupMapping(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDynFieldGroupMapping(List<TblDynFieldGroupMapping> tblDynFieldGroupMappings){
        super.updateAll(tblDynFieldGroupMappings);
    }
}
