package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblClientLanguageDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblClientLanguage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientLanguageImpl extends AbcAbstractClass<TblClientLanguage> implements TblClientLanguageDao {

    @Override
    public void addTblClientLanguage(TblClientLanguage tblClientLanguage){
        super.addEntity(tblClientLanguage);
    }

    @Override
    public void deleteTblClientLanguage(TblClientLanguage tblClientLanguage) {
        super.deleteEntity(tblClientLanguage);
    }

    @Override
    public void updateTblClientLanguage(TblClientLanguage tblClientLanguage) {
        super.updateEntity(tblClientLanguage);
    }

    @Override
    public List<TblClientLanguage> getAllTblClientLanguage() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientLanguage> findTblClientLanguage(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientLanguageCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientLanguage> findByCountTblClientLanguage(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientLanguage(List<TblClientLanguage> tblClientLanguages){
        super.updateAll(tblClientLanguages);
    }
}
