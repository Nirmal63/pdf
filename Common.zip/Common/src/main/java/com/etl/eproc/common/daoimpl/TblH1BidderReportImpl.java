package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblH1BidderReport;
import com.etl.eproc.common.daointerface.TblH1BidderReportDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblH1BidderReportImpl extends AbcAbstractClass<TblH1BidderReport> implements TblH1BidderReportDao {

    @Override
    public void addTblH1BidderReport(TblH1BidderReport tblH1BidderReport){
        super.addEntity(tblH1BidderReport);
    }

    @Override
    public void deleteTblH1BidderReport(TblH1BidderReport tblH1BidderReport) {
        super.deleteEntity(tblH1BidderReport);
    }

    @Override
    public void updateTblH1BidderReport(TblH1BidderReport tblH1BidderReport) {
        super.updateEntity(tblH1BidderReport);
    }

    @Override
    public List<TblH1BidderReport> getAllTblH1BidderReport() {
        return super.getAllEntity();
    }

    @Override
    public List<TblH1BidderReport> findTblH1BidderReport(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblH1BidderReportCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblH1BidderReport> findByCountTblH1BidderReport(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblH1BidderReport(List<TblH1BidderReport> tblH1BidderReports){
        super.updateAll(tblH1BidderReports);
    }
}
