package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCombo;
import java.util.List;

public interface TblComboDao  {

    public void addTblCombo(TblCombo tblCombo);

    public void deleteTblCombo(TblCombo tblCombo);

    public void updateTblCombo(TblCombo tblCombo);

    public List<TblCombo> getAllTblCombo();

    public List<TblCombo> findTblCombo(Object... values) throws Exception;

    public List<TblCombo> findByCountTblCombo(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblComboCount();

    public void saveUpdateAllTblCombo(List<TblCombo> tblCombos);
}