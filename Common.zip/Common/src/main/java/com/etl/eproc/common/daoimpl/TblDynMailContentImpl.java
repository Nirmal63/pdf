package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblDynMailContent;
import com.etl.eproc.common.daointerface.TblDynMailContentDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDynMailContentImpl extends AbcAbstractClass<TblDynMailContent> implements TblDynMailContentDao {

    @Override
    public void addTblDynMailContent(TblDynMailContent tblDynMailContent){
        super.addEntity(tblDynMailContent);
    }

    @Override
    public void deleteTblDynMailContent(TblDynMailContent tblDynMailContent) {
        super.deleteEntity(tblDynMailContent);
    }

    @Override
    public void updateTblDynMailContent(TblDynMailContent tblDynMailContent) {
        super.updateEntity(tblDynMailContent);
    }

    @Override
    public List<TblDynMailContent> getAllTblDynMailContent() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynMailContent> findTblDynMailContent(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynMailContentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynMailContent> findByCountTblDynMailContent(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDynMailContent(List<TblDynMailContent> tblDynMailContents){
        super.updateAll(tblDynMailContents);
    }
}
