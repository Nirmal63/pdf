package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblClientBoqColumnDao;
import com.etl.eproc.eindent.model.TblClientBoqColumn;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientBoqColumnImpl extends AbcAbstractClass<TblClientBoqColumn> implements TblClientBoqColumnDao {

    @Override
    public void addTblClientBoqColumn(TblClientBoqColumn tblClientBoqColumn) {
        super.addEntity(tblClientBoqColumn);
    }

    @Override
    public void deleteTblClientBoqColumn(TblClientBoqColumn tblClientBoqColumn) {
        super.deleteEntity(tblClientBoqColumn);
    }

    @Override
    public void updateTblClientBoqColumn(TblClientBoqColumn tblClientBoqColumn) {
        super.updateEntity(tblClientBoqColumn);
    }

    @Override
    public List<TblClientBoqColumn> getAllTblClientBoqColumn() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientBoqColumn> findTblClientBoqColumn(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientBoqColumnCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientBoqColumn> findByCountTblClientBoqColumn(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientBoqColumn(List<TblClientBoqColumn> tblClientBoqColumns) {
        super.updateAll(tblClientBoqColumns);
    }
}
