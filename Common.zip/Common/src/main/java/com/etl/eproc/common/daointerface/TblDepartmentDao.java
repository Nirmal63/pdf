package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDepartment;
import java.util.List;

public interface TblDepartmentDao  {

    public void addTblDepartment(TblDepartment tblDepartment);

    public void deleteTblDepartment(TblDepartment tblDepartment);

    public void updateTblDepartment(TblDepartment tblDepartment);

    public List<TblDepartment> getAllTblDepartment();

    public List<TblDepartment> findTblDepartment(Object... values) throws Exception;

    public List<TblDepartment> findByCountTblDepartment(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDepartmentCount();

    public void saveUpdateAllTblDepartment(List<TblDepartment> tblDepartments);

	public void saveOrUpdateTblDepartment(TblDepartment tblDepartment);
}