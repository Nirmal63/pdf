/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import com.etl.eproc.common.services.ExceptionHandlerService;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author dixit
 */
@Controller
public class HomeController {
    
 @Autowired
 private ExceptionHandlerService exceptionHandlerService;
// @Autowired
// private TblAuditMasterse exceptionHandlerService;
 
 
  @RequestMapping(value = "/downloads/{str}", method = RequestMethod.GET)
    public String downloadSigner(@PathVariable("str") String str,HttpSession session, HttpServletResponse response, HttpServletRequest request) {
        //SessionBean sessionBean = (SessionBean) session.getAttribute("sessionObject");
        try {
            String documentPath = "";
            String setHeaderParam = "";
            ServletOutputStream outputStream = null;
//                ServletContext sc = request.getServletContext();
            if("certificate".equalsIgnoreCase(str)){
                documentPath = HomeController.class.getResource("/").toString().replace("WEB-INF/classes", "/resources/zip/Certificate.zip").replace("file:/", "");
                setHeaderParam = "attachment;filename=\"Certificate.zip\"";
            }else if("signerV2".equalsIgnoreCase(str)){
                documentPath = HomeController.class.getResource("/").toString().replace("WEB-INF/classes", "/resources/zip/SignerV2.0.exe").replace("file:/", "");
                setHeaderParam = "attachment;filename=\"SignerV2.0.exe\"";
            }else if("signerCA".equalsIgnoreCase(str)){
                documentPath = HomeController.class.getResource("/").toString().replace("WEB-INF/classes", "/resources/zip/SignerCA.exe").replace("file:/", "");
                setHeaderParam = "attachment;filename=\"SignerCA.exe\"";
            }else if("patchWindowsXP".equalsIgnoreCase(str)){
                documentPath = HomeController.class.getResource("/").toString().replace("WEB-INF/classes", "/resources/zip/WindowsXP.zip").replace("file:/", "");
                setHeaderParam = "attachment;filename=\"WindowsXP.zip\"";
            }else if("patchWindowsServer2003".equalsIgnoreCase(str)){
                documentPath = HomeController.class.getResource("/").toString().replace("WEB-INF/classes", "/resources/zip/WindowsServer2003.zip").replace("file:/", "");
                setHeaderParam = "attachment;filename=\"WindowsServer2003.zip\"";
            }else if("beforeloginusermanual".equalsIgnoreCase(str)){
                documentPath = HomeController.class.getResource("/").toString().replace("WEB-INF/classes", "/resources/zip/UserManual.pdf").replace("file:/", "");
                setHeaderParam = "attachment;filename=\"UserManual.pdf\"";
            }else if("afterloginusermanual".equalsIgnoreCase(str)){
                documentPath = HomeController.class.getResource("/").toString().replace("WEB-INF/classes", "/resources/zip/BidderUserManual.pdf").replace("file:/", "");
                setHeaderParam = "attachment;filename=\"BidderUserManual.pdf\"";
            }
            else if("systemreq".equalsIgnoreCase(str)){
                documentPath = HomeController.class.getResource("/").toString().replace("WEB-INF/classes", "/resources/zip/SystemRequirement.pdf").replace("file:/", "");
                setHeaderParam = "attachment;filename=\"SystemRequirement.pdf\"";
            }
            File file = null;
            file = new File(documentPath);
            InputStream fis = new FileInputStream(file);
            byte[] buf = new byte[fis.available()];
            int offset = 0;
            int numRead = 0;
            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                offset += numRead;
            }
            fis.close();
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", setHeaderParam);
            outputStream = response.getOutputStream();
            outputStream.write(buf);
            outputStream.flush();
            outputStream.close();
        } catch (Exception ex) {
            //new AbcException(ex, exceptionHandlerService);
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //tblAuditMasterService.makeAuditTrail(request.getAttribute("auditBean"), "Download Signer", "");
        }
        return null;
    }  
}
