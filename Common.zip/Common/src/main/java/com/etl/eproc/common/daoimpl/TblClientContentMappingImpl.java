package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblClientContentMapping;
import com.etl.eproc.common.daointerface.TblClientContentMappingDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientContentMappingImpl extends AbcAbstractClass<TblClientContentMapping> implements TblClientContentMappingDao {

    @Override
    public void addTblClientContentMapping(TblClientContentMapping tblClientContentMapping){
        super.addEntity(tblClientContentMapping);
    }

    @Override
    public void deleteTblClientContentMapping(TblClientContentMapping tblClientContentMapping) {
        super.deleteEntity(tblClientContentMapping);
    }

    @Override
    public void updateTblClientContentMapping(TblClientContentMapping tblClientContentMapping) {
        super.updateEntity(tblClientContentMapping);
    }

    @Override
    public List<TblClientContentMapping> getAllTblClientContentMapping() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientContentMapping> findTblClientContentMapping(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientContentMappingCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientContentMapping> findByCountTblClientContentMapping(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientContentMapping(List<TblClientContentMapping> tblClientContentMappings){
        super.updateAll(tblClientContentMappings);
    }
}
