package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblDeptNeftRtgsConfDetails;
import com.etl.eproc.common.daointerface.TblDeptNeftRtgsConfDetailsDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDeptNeftRtgsConfDetailsImpl extends AbcAbstractClass<TblDeptNeftRtgsConfDetails> implements TblDeptNeftRtgsConfDetailsDao {

    @Override
    public void addTblDeptNeftRtgsConfDetails(TblDeptNeftRtgsConfDetails tblDeptNeftRtgsConfDetails){
        super.addEntity(tblDeptNeftRtgsConfDetails);
    }

    @Override
    public void deleteTblDeptNeftRtgsConfDetails(TblDeptNeftRtgsConfDetails tblDeptNeftRtgsConfDetails) {
        super.deleteEntity(tblDeptNeftRtgsConfDetails);
    }

    @Override
    public void updateTblDeptNeftRtgsConfDetails(TblDeptNeftRtgsConfDetails tblDeptNeftRtgsConfDetails) {
        super.updateEntity(tblDeptNeftRtgsConfDetails);
    }

    @Override
    public List<TblDeptNeftRtgsConfDetails> getAllTblDeptNeftRtgsConfDetails() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDeptNeftRtgsConfDetails> findTblDeptNeftRtgsConfDetails(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDeptNeftRtgsConfDetailsCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDeptNeftRtgsConfDetails> findByCountTblDeptNeftRtgsConfDetails(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDeptNeftRtgsConfDetails(List<TblDeptNeftRtgsConfDetails> tblDeptNeftRtgsConfDetailss){
        super.updateAll(tblDeptNeftRtgsConfDetailss);
    }
}
