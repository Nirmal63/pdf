package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblCentralizedCommittee;
import com.etl.eproc.common.daointerface.TblCentralizedCommitteeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCentralizedCommitteeImpl extends AbcAbstractClass<TblCentralizedCommittee> implements TblCentralizedCommitteeDao {

    @Override
    public void addTblCentralizedCommittee(TblCentralizedCommittee tblCentralizedCommittee){
        super.addEntity(tblCentralizedCommittee);
    }

    @Override
    public void deleteTblCentralizedCommittee(TblCentralizedCommittee tblCentralizedCommittee) {
        super.deleteEntity(tblCentralizedCommittee);
    }

    @Override
    public void updateTblCentralizedCommittee(TblCentralizedCommittee tblCentralizedCommittee) {
        super.updateEntity(tblCentralizedCommittee);
    }

    @Override
    public List<TblCentralizedCommittee> getAllTblCentralizedCommittee() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCentralizedCommittee> findTblCentralizedCommittee(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCentralizedCommitteeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCentralizedCommittee> findByCountTblCentralizedCommittee(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCentralizedCommittee(List<TblCentralizedCommittee> tblCentralizedCommittees){
        super.updateAll(tblCentralizedCommittees);
    }
}
