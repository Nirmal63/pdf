package com.etl.eproc.common.daointerface;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDynFieldGroup;
import java.util.List;

public interface TblDynFieldGroupDao  {

    public void addTblDynFieldGroup(TblDynFieldGroup tblDynFieldGroup);

    public void deleteTblDynFieldGroup(TblDynFieldGroup tblDynFieldGroup);

    public void updateTblDynFieldGroup(TblDynFieldGroup tblDynFieldGroup);

    public List<TblDynFieldGroup> getAllTblDynFieldGroup();

    public List<TblDynFieldGroup> findTblDynFieldGroup(Object... values) throws Exception;

    public List<TblDynFieldGroup> findByCountTblDynFieldGroup(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynFieldGroupCount();

    public void saveUpdateAllTblDynFieldGroup(List<TblDynFieldGroup> tblDynFieldGroups);
}
