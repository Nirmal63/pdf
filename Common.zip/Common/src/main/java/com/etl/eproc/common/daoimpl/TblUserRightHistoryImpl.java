package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblUserRightHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblUserRightHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserRightHistoryImpl extends AbcAbstractClass<TblUserRightHistory> implements TblUserRightHistoryDao {

    @Override
    public void addTblUserRightHistory(TblUserRightHistory tblUserRightHistory){
        super.addEntity(tblUserRightHistory);
    }

    @Override
    public void deleteTblUserRightHistory(TblUserRightHistory tblUserRightHistory) {
        super.deleteEntity(tblUserRightHistory);
    }

    @Override
    public void updateTblUserRightHistory(TblUserRightHistory tblUserRightHistory) {
        super.updateEntity(tblUserRightHistory);
    }

    @Override
    public List<TblUserRightHistory> getAllTblUserRightHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserRightHistory> findTblUserRightHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserRightHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserRightHistory> findByCountTblUserRightHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserRightHistory(List<TblUserRightHistory> tblUserRightHistorys){
        super.updateAll(tblUserRightHistorys);
    }
}
