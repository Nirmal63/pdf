package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblRuleLinkDao;
import com.etl.eproc.common.model.TblRuleLink;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblRuleLinkImpl extends AbcAbstractClass<TblRuleLink> implements TblRuleLinkDao {


    @Override
    public void addTblRuleLink(TblRuleLink tblRuleLink){
        super.addEntity(tblRuleLink);
    }

    @Override
    public void deleteTblRuleLink(TblRuleLink tblRuleLink) {
        super.deleteEntity(tblRuleLink);
    }

    @Override
    public void updateTblRuleLink(TblRuleLink tblRuleLink) {
        super.updateEntity(tblRuleLink);
    }

    @Override
    public List<TblRuleLink> getAllTblRuleLink() {
        return super.getAllEntity();
    }

    @Override
    public List<TblRuleLink> findTblRuleLink(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblRuleLinkCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblRuleLink> findByCountTblRuleLink(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblRuleLink(List<TblRuleLink> tblRuleLinks){
        super.updateAll(tblRuleLinks);
    }
}
