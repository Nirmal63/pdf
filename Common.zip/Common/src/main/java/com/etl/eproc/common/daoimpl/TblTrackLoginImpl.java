package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblTrackLoginDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblTrackLogin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblTrackLoginImpl extends AbcAbstractClass<TblTrackLogin> implements TblTrackLoginDao {

    @Override
    public void addTblTrackLogin(TblTrackLogin tblTrackLogin){
        super.addEntity(tblTrackLogin);
    }

    @Override
    public void deleteTblTrackLogin(TblTrackLogin tblTrackLogin) {
        super.deleteEntity(tblTrackLogin);
    }

    @Override
    public void updateTblTrackLogin(TblTrackLogin tblTrackLogin) {
        super.updateEntity(tblTrackLogin);
    }

    @Override
    public List<TblTrackLogin> getAllTblTrackLogin() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTrackLogin> findTblTrackLogin(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTrackLoginCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTrackLogin> findByCountTblTrackLogin(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTrackLogin(List<TblTrackLogin> tblTrackLogins){
        super.updateAll(tblTrackLogins);
    }
}
