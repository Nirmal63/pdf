package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblActivityMasterDao;
import com.etl.eproc.common.model.TblActivityMaster;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblActivityMasterDaoImpl extends AbcAbstractClass<TblActivityMaster> implements TblActivityMasterDao {
	
    @Override
    public void addTblActivityMaster(TblActivityMaster tblActivityMaster){
        super.addEntity(tblActivityMaster);
    }

    @Override
    public void deleteTblActivityMaster(TblActivityMaster tblActivityMaster) {
        super.deleteEntity(tblActivityMaster);
    }

    @Override
    public void updateTblActivityMaster(TblActivityMaster tblActivityMaster) {
        super.updateEntity(tblActivityMaster);
    }

    @Override
    public List<TblActivityMaster> getAllTblActivityMaster() {
        return super.getAllEntity();
    }

    @Override
    public List<TblActivityMaster> findTblActivityMaster(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblActivityMasterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblActivityMaster> findByCountTblActivityMaster(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }
}
