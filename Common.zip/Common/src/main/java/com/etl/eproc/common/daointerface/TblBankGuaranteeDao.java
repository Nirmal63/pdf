package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBankGuarantee;

public interface TblBankGuaranteeDao  {

    public void addTblBankGuarantee(TblBankGuarantee tblBankGuarantee);

    public void deleteTblBankGuarantee(TblBankGuarantee tblBankGuarantee);

    public void updateTblBankGuarantee(TblBankGuarantee tblBankGuarantee);

    public List<TblBankGuarantee> getAllTblBankGuarantee();

    public List<TblBankGuarantee> findTblBankGuarantee(Object... values) throws Exception;

    public List<TblBankGuarantee> findByCountTblBankGuarantee(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBankGuaranteeCount();

    public void saveUpdateAllTblBankGuarantee(List<TblBankGuarantee> tblBankGuarantees);
}

