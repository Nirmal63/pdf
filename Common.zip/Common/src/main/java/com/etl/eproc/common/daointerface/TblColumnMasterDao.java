package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblColumnMaster;
import java.util.List;

public interface TblColumnMasterDao  {

    public void addTblColumnMaster(TblColumnMaster tblColumnMaster);

    public void deleteTblColumnMaster(TblColumnMaster tblColumnMaster);

    public void updateTblColumnMaster(TblColumnMaster tblColumnMaster);

    public List<TblColumnMaster> getAllTblColumnMaster();

    public List<TblColumnMaster> findTblColumnMaster(Object... values) throws Exception;

    public List<TblColumnMaster> findByCountTblColumnMaster(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblColumnMasterCount();

    public void saveUpdateAllTblColumnMaster(List<TblColumnMaster> tblColumnMasters);
}