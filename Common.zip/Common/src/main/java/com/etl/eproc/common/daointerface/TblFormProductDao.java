package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblFormProduct;
import java.util.List;

public interface TblFormProductDao  {

    public void addTblFormProduct(TblFormProduct tblFormProduct);

    public void deleteTblFormProduct(TblFormProduct tblFormProduct);

    public void updateTblFormProduct(TblFormProduct tblFormProduct);

    public List<TblFormProduct> getAllTblFormProduct();

    public List<TblFormProduct> findTblFormProduct(Object... values) throws Exception;

    public List<TblFormProduct> findByCountTblFormProduct(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFormProductCount();

    public void saveUpdateAllTblFormProduct(List<TblFormProduct> tblFormProducts);
}