/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblWorkflowConfiguration;
import com.etl.eproc.common.daointerface.TblWorkflowConfigurationDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblWorkflowConfigurationImpl extends AbcAbstractClass<TblWorkflowConfiguration> implements TblWorkflowConfigurationDao {

    @Override
    public void addTblWorkflowConfiguration(TblWorkflowConfiguration tblWorkflowConfiguration){
        super.addEntity(tblWorkflowConfiguration);
    }

    @Override
    public void deleteTblWorkflowConfiguration(TblWorkflowConfiguration tblWorkflowConfiguration) {
        super.deleteEntity(tblWorkflowConfiguration);
    }

    @Override
    public void updateTblWorkflowConfiguration(TblWorkflowConfiguration tblWorkflowConfiguration) {
        super.updateEntity(tblWorkflowConfiguration);
    }

    @Override
    public List<TblWorkflowConfiguration> getAllTblWorkflowConfiguration() {
        return super.getAllEntity();
    }

    @Override
    public List<TblWorkflowConfiguration> findTblWorkflowConfiguration(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblWorkflowConfigurationCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblWorkflowConfiguration> findByCountTblWorkflowConfiguration(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblWorkflowConfiguration(List<TblWorkflowConfiguration> tblWorkflowConfigurations){
        super.updateAll(tblWorkflowConfigurations);
    }
}
