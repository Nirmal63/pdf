package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblSsoHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblSsoHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblSsoHistoryImpl extends AbcAbstractClass<TblSsoHistory> implements TblSsoHistoryDao {

    @Override
    public void addTblSsoHistory(TblSsoHistory tblSsoHistory){
        super.addEntity(tblSsoHistory);
    }

    @Override
    public void deleteTblSsoHistory(TblSsoHistory tblSsoHistory) {
        super.deleteEntity(tblSsoHistory);
    }

    @Override
    public void updateTblSsoHistory(TblSsoHistory tblSsoHistory) {
        super.updateEntity(tblSsoHistory);
    }

    @Override
    public List<TblSsoHistory> getAllTblSsoHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblSsoHistory> findTblSsoHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblSsoHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblSsoHistory> findByCountTblSsoHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblSsoHistory(List<TblSsoHistory> tblSsoHistorys){
        super.updateAll(tblSsoHistorys);
    }
}
