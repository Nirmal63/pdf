package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblProcurementEvent;
import com.etl.eproc.common.daointerface.TblProcurementEventDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

@Repository @Transactional    /*StackUpdate*/
public class TblProcurementEventImpl extends AbcAbstractClass<TblProcurementEvent> implements TblProcurementEventDao{

	@Override
	public void addTblProcurementEvent(TblProcurementEvent tblProcurementEvent) {
		super.addEntity(tblProcurementEvent);
	}

	@Override
	public void deleteTblProcurementEvent(TblProcurementEvent tblProcurementEvent) {
		super.deleteEntity(tblProcurementEvent);
	}

	@Override
	public void updateTblProcurementEvent(TblProcurementEvent tblProcurementEvent) {
		super.updateEntity(tblProcurementEvent);
	}

	@Override
	public List<TblProcurementEvent> getAllTblProcurementEvent() {
		return super.getAllEntity();
	}

	@Override
	public List<TblProcurementEvent> findTblProcurementEvent(Object... values) throws Exception {
		return super.findEntity(values);
	}

	@Override
	public long getTblProcurementEventCount() {
		return super.getEntityCount();
	}
	
	@Override
	public List<TblProcurementEvent> findByCountTblProcurementEvent(int firstResult, int maxResult, Object... values) throws Exception {
		return super.findByCountEntity(firstResult, maxResult, values);
	}

	@Override
	public void saveUpdateAllTblProcurementEvent(List<TblProcurementEvent> tblProcurementEvents) {
		super.updateAll(tblProcurementEvents);
	}
}
