package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblNeftRtgsBidderDetail;
import com.etl.eproc.common.daointerface.TblNeftRtgsBidderDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblNeftRtgsBidderDetailImpl extends AbcAbstractClass<TblNeftRtgsBidderDetail> implements TblNeftRtgsBidderDetailDao {

    @Override
    public void addTblNeftRtgsBidderDetail(TblNeftRtgsBidderDetail tblNeftRtgsBidderDetail){
        super.addEntity(tblNeftRtgsBidderDetail);
    }

    @Override
    public void deleteTblNeftRtgsBidderDetail(TblNeftRtgsBidderDetail tblNeftRtgsBidderDetail) {
        super.deleteEntity(tblNeftRtgsBidderDetail);
    }

    @Override
    public void updateTblNeftRtgsBidderDetail(TblNeftRtgsBidderDetail tblNeftRtgsBidderDetail) {
        super.updateEntity(tblNeftRtgsBidderDetail);
    }

    @Override
    public List<TblNeftRtgsBidderDetail> getAllTblNeftRtgsBidderDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNeftRtgsBidderDetail> findTblNeftRtgsBidderDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNeftRtgsBidderDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNeftRtgsBidderDetail> findByCountTblNeftRtgsBidderDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNeftRtgsBidderDetail(List<TblNeftRtgsBidderDetail> tblNeftRtgsBidderDetails){
        super.updateAll(tblNeftRtgsBidderDetails);
    }
}
