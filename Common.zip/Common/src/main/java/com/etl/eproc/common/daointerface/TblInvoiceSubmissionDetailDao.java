package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblInvoiceSubmissionDetail;
import java.util.List;

public interface TblInvoiceSubmissionDetailDao  {

    public void addTblInvoiceSubmissionDetail(TblInvoiceSubmissionDetail tblInvoiceSubmissionDetail);

    public void deleteTblInvoiceSubmissionDetail(TblInvoiceSubmissionDetail tblInvoiceSubmissionDetail);

    public void updateTblInvoiceSubmissionDetail(TblInvoiceSubmissionDetail tblInvoiceSubmissionDetail);

    public List<TblInvoiceSubmissionDetail> getAllTblInvoiceSubmissionDetail();

    public List<TblInvoiceSubmissionDetail> findTblInvoiceSubmissionDetail(Object... values) throws Exception;

    public List<TblInvoiceSubmissionDetail> findByCountTblInvoiceSubmissionDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblInvoiceSubmissionDetailCount();

    public void saveUpdateAllTblInvoiceSubmissionDetail(List<TblInvoiceSubmissionDetail> tblInvoiceSubmissionDetails);
}