/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;


import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daogeneric.Operation_enum;
import com.etl.eproc.common.daointerface.TblClientExemptionCertificateDao;
import com.etl.eproc.common.model.TblClientExemptionCertificate;
import com.etl.eproc.common.databean.ClientDtBean;
import com.etl.eproc.common.model.TblBankMaster;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientAlertConf;
import com.etl.eproc.common.model.TblClientBidTerm;
import com.etl.eproc.common.model.TblClientCPPPConfig;
import com.etl.eproc.common.model.TblClientColumnType;
import com.etl.eproc.common.model.TblClientCurrency;
import com.etl.eproc.common.model.TblClientEventType;
import com.etl.eproc.common.model.TblClientFeature;
import com.etl.eproc.common.model.TblClientLanguage;
import com.etl.eproc.common.model.TblClientLinkConfig;
import com.etl.eproc.common.model.TblClientModule;
import com.etl.eproc.common.model.TblClientPGBankMapping;
import com.etl.eproc.common.model.TblClientPayment;
import com.etl.eproc.common.model.TblClientRegDoc;
import com.etl.eproc.common.model.TblClientSector;
import com.etl.eproc.common.model.TblClientWorkflowType;
import com.etl.eproc.common.model.TblColumnType;
import com.etl.eproc.common.model.TblCountry;
import com.etl.eproc.common.model.TblCurrency;
import com.etl.eproc.common.model.TblCustomParameter;
import com.etl.eproc.common.model.TblDateFormat;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblEventType;
import com.etl.eproc.common.model.TblFeature;
import com.etl.eproc.common.model.TblField;
import com.etl.eproc.common.model.TblLanguage;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblModule;
import com.etl.eproc.common.model.TblMvpVertical;
import com.etl.eproc.common.model.TblNeftRtgsConf;
import com.etl.eproc.common.model.TblPaymentGatewayMaster;
import com.etl.eproc.common.model.TblPaymentType;
import com.etl.eproc.common.model.TblSector;
import com.etl.eproc.common.model.TblState;
import com.etl.eproc.common.model.TblTheme;
import com.etl.eproc.common.model.TblTimeZone;
import com.etl.eproc.common.model.TblTransactionTypeAccountMapping;
import com.etl.eproc.common.model.TblUserClientAccess;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.model.TblWorkflowType;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.ManageContentService;
import com.etl.eproc.common.services.NeftRtgsService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.services.TpslService;
import com.etl.eproc.common.services.WSCheckAvailService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.etender.model.TblDynReportColumn;
import com.etl.eproc.etender.model.TblDynReportFormMap;

/**
 *
 * @author shreyansh.shah
 */
@Controller
@RequestMapping("/common")
public class ClientController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
   	private TblClientExemptionCertificateDao tblClientExemptionCertificateDao ;
    @Value("#{projectProperties['future_release']}")
    private boolean isFutureRelease;
    @Value("#{projectProperties['logofile.allowedSize']}")
    private float allowedSize;
    @Value("#{projectProperties['logofile_allowedExt']}")
    private String allowedExt;
    @Value("#{projectProperties['file.drive']}")
    private String drive;
    @Value("#{projectProperties['logo.server.path']}")
    private String logoserverpath;
    @Value("#{projectProperties['logo.server.context.path']}")
    private String logoservercontextpath;
    @Value("#{projectProperties['logofile.upload']}")
    private String path;    
    @Value("#{projectProperties['Eproc.Main.Folder.path.upload']}")
    private String Mainpath;    
    @Value("#{linkProperties['manage_client_create_client']?:1}")
    private int createClientLinkId; 
    @Value("#{linkProperties['manage_client_edit_client']?:2}")
    private int editClientLinkId; 
    @Value("#{linkProperties['manage_client_view_client']?:3}")
    private int viewClientLinkId;
    /*@Value("#{linkProperties['manage_client_additional_configuration']?:4}")
    private int additionalConfiLinkId;
    @Value("#{linkProperties['manage_client_sealed_bid_additional_configuration']?:78}")
    private int sealedBidAdditionalConfiLinkId;
    @Value("#{linkProperties['manage_client_auction_additional_configuration']?:79}")
    private int auctionAdditionalConfiLinkId;*/
    
    @Value("#{linkProperties['manage_client_approve_client']?:5}")
    private int approveClientLinkId; 
    @Value("#{linkProperties['manage_client_selecttheme']?:69}")
    private int selecthemeLinkId;
    @Value("#{linkProperties['manage_client_default_configuration']?:70}")
    private int defaultConfLinkId; 
    @Value("#{linkProperties['manage_client_auction_configuration']?:71}")
    private int auctionConfgLinkId; 
    @Value("#{linkProperties['manage_client_registration_supp_docs']?:72}")
    private int regSuppDocLinkId;
    @Value("#{linkProperties['report_admin_manage_client']?:1}")
    private int manageClientReportId;
    @Value("#{linkProperties['manage_client_auction_additional_configuration']?:4}")
    private int linkManageClientAucAddConfig;
    @Value("#{linkProperties['manage_client_pq_additional_configuration']?:78}")
    private int linkManageClientPqAddConfig;
    @Value("#{linkProperties['manage_client_tender_additional_configuration']?:79}")
    private int linkManageClientTenAddConfig;
    @Value("#{linkProperties['manage_client_sealed_bid_additional_configuration']?:407}")
    private int linkManageClientSbidAddConfig;
    @Value("#{linkProperties['manage_client_rfp_additional_configuration']?:408}")
    private int linkManageClientRfpAddConfig;
    @Value("#{linkProperties['manage_client_rfi_additional_configuration']?:409}")
    private int linkManageClientRfiAddConfig;
    @Value("#{linkProperties['manage_client_reoi_additional_configuration']?:410}")
    private int linkManageClientReoiAddConfig;
    
    @Value("#{projectProperties['certificateClass']}")
    private String tempCertificateClass;
    @Value("#{adminAuditTrailProperties['getManageClient']}")
    private String auditManageClient;
    @Value("#{adminAuditTrailProperties['getCreateClient']}")
    private String auditCreateClient;
    @Value("#{adminAuditTrailProperties['approveClientSign']}")
    private String auditApproveClientWithSign;
    /*@Value("#{adminAuditTrailProperties['approveClientSignFailed']}")
    private String auditApproveClientWithSignFailed;
    @Value("#{adminAuditTrailProperties['approveClientWithoutSign']}")
    private String auditApproveClientWithoutSign;
    @Value("#{adminAuditTrailProperties['approveClientWithoutSignFailed']}")
    private String auditApproveClientWithoutSignFailed;*/
    @Value("#{adminAuditTrailProperties['postEditClient']}")
    private String auditClientEdited;
    /*@Value("#{adminAuditTrailProperties['postEditClientFailed']}")
    private String auditClientEditFailed;*/
    @Value("#{adminAuditTrailProperties['postCreateClient']}")
    private String auditClientCreated;
    /*@Value("#{adminAuditTrailProperties['postCreateClientFailed']}")
    private String auditClientCreatedFailed;*/
    /*@Value("#{adminAuditTrailProperties['getSealedBidParamConfig']}")
    private String auditConfigSealedBidParam;*/
    @Value("#{adminAuditTrailProperties['getAuctionParamConfig']}")
    private String auditConfigAuctionParam;
    @Value("#{adminAuditTrailProperties['getViewClient']}")
    private String auditViewClient;
    @Value("#{adminAuditTrailProperties['getEditClient']}")
    private String auditEditClient;
    @Value("#{adminAuditTrailProperties['getApproveClient']}")
    private String auditApproveClient;
    @Value("#{adminAuditTrailProperties['getClientThemeConfiguration']}")
    private String auditThemeConfig;
    @Value("#{adminAuditTrailProperties['postUploadLogo']}")
    private String auditLogoUpload;
    @Value("#{adminAuditTrailProperties['postUploadLogoFailed']}")
    private String auditLogoUploadFailed;
    @Value("#{adminAuditTrailProperties['postThemeUpdated']}")
    private String auditThemeUpdated;
    @Value("#{adminAuditTrailProperties['postThemeUpdateFailed']}")
    private String auditThemeUpdateFailed;
    @Value("#{adminAuditTrailProperties['getConfigRegDoc']}")
    private String auditConfigRegDocs;
    @Value("#{adminAuditTrailProperties['getAdditionalConfigForSealBid']}")
    private String getAdditionalConfigForSealBid;
    @Value("#{adminAuditTrailProperties['postAdditionalConfigForSealBid']}")
    private String postAdditionalConfigForSealBid;
    @Value("#{adminAuditTrailProperties['getAdditionalConfigForAuction']}")
    private String getAdditionalConfigForAuction;
    @Value("#{adminAuditTrailProperties['postAdditionalConfigForAuction']}")
    private String postAdditionalConfigForAuction;
//    @Value("#{adminAuditTrailProperties['postAdditionalConfigFailed']}")
//    private String auditAdditionalConfigurationFailed;
    @Value("#{adminAuditTrailProperties['postRegDocAdded']}")
    private String auditRegDocAdded;
    @Value("#{adminAuditTrailProperties['postRegDocFailed']}")
    private String auditRegDocFailed;
    @Value("#{adminAuditTrailProperties['postRegDocUpdated']}")
    private String auditRegDocUpdated;
    @Value("#{adminAuditTrailProperties['postRegDocUpdateFailed']}")
    private String auditRegDocUpdateFailed;
    @Value("#{adminAuditTrailProperties['postDefAuctionParamConfigured']}")
    private String auditDefAuctionParamConfigured;
    @Value("#{adminAuditTrailProperties['postDefAuctionParamConfigFailed']}")
    private String auditDefAuctionParamConfigFailed;
    @Value("#{adminAuditTrailProperties['postDefSealBidParamConfigured']}")
    private String auditDefSealBidParamConfigured;
    @Value("#{adminAuditTrailProperties['postDefSealBidParamConfigFailed']}")
    private String auditDefSealBidParamConfigFailed;
     @Value("#{linkProperties['manage_client_sealed_bid_additional_configuration']?:78}")
    private int addiSealBidConfLinkId; 
    @Value("#{linkProperties['manage_client_auction_additional_configuration']?:79}")
    private int addiAuctionConfgLinkId;
    

    @Value("#{adminAuditTrailProperties['postdefaultparameterpq']}")
    private String postDefaultParameterPQ;
    @Value("#{adminAuditTrailProperties['postdefaultparametertender']}")
    private String postDefaultParameterTender;
    @Value("#{adminAuditTrailProperties['postdefaultparameterrfq']}")
    private String postDefaultParameterRFQ;
    @Value("#{adminAuditTrailProperties['postdefaultparameterrfp']}")
    private String postDefaultParameterRFP;
    @Value("#{adminAuditTrailProperties['postdefaultparameterrfi']}")
    private String postDefaultParameterRFI;
    @Value("#{adminAuditTrailProperties['postdefaultparameterreoi']}")
    private String postDefaultParameterREOI;
    @Value("#{adminAuditTrailProperties['postClientSectorConfig']}")
    private String auditClientSectorConfigCreated;
   
    @Value("#{linkProperties['manage_client_configure_sector']?:398}")
    private int mapClientSectorLinkId; 
    @Value("#{linkProperties['manage_client_payment_configuration']?:428}")
	private int paymentConfigurationLinkId;
    @Value("#{adminAuditTrailProperties['get_manage_payment_conf']}")
	private String getManagePaymentConf;
    @Value("#{adminAuditTrailProperties['msg_defaultconfigration_success']}")
    private String defaultConfigrationSuccess;
    @Value("#{projectProperties['search_panel_horizontal']}")
    private String searchHorizontal;
    @Value("#{projectProperties['search_panel_vertical']}")
    private String searchVertical;
    @Value("#{projectProperties['label_yes']}")
    private String homePageYes;
    @Value("#{projectProperties['label_no']}")
    private String homePageNo;
    @Value("#{projectProperties['auc_display_homepage_property']}")
    private String aucProperty;
    @Value("#{projectProperties['search_panel_default']}")
    private String searchPanelDefault;
    @Value("#{projectProperties['mvp_envIds']}")
    private String mvpEnvIds;
    @Value("#{projectProperties['mvp_formId_tech']}")
    private String mvpTechFormIds; 
    @Value("#{projectProperties['mvp_formId_pricebid']}")
    private String mvpPriceBidFormIds; 
    @Value("#{linkProperties['hide_registration_link']?:3355}")
    private int hideRegistrationLinkId;
    @Value("#{adminAuditTrailProperties['getHideRegistrationLinkRemark']}")
    private String getHideRegistrationLinkRemark;
    @Value("#{adminAuditTrailProperties['submitHideRegistrationLinkRemark']}")
    private String submitHideRegistrationLinkRemark;
    @Value("#{linkProperties['reset_bidder_link']?:5532}")
    private int reset_bidder_link;
    @Value("#{adminAuditTrailProperties['submitResetBiddersLinkRemark']}")
    private String submitResetBiddersLinkRemark;
    @Value("#{adminAuditTrailProperties['getResetBiddersLinkRemark']}")
    private String getResetBiddersLinkRemark;
    @Value("#{projectProperties['default_config_clientId']?:76}")
    private int defaultConfigClientId;
    
    
    @Autowired
    private CommonService commonService;
    @Autowired
    private ClientService clientService;
    @Autowired    
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private ModelToSelectItem modelToSelectItem;
    @Autowired
    private CommonValidators commonValidators;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    DynamicFieldService dynamicFieldService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private MessageSource messageSource;
    @Autowired
    private WSCheckAvailService wSCheckAvailService;
    @Autowired
    private TpslService tpslService;
    @Autowired
    private NeftRtgsService neftService;
    @Autowired
    private ManageBidderService manageBidderService; 
    @Autowired
    private ConversionService conversionService;
    @Autowired
    private ManageContentService manageContentService;
    
    private static final String EVENT_SPECIFIC = "Event Specific";
    private static final String NOT_REQUIRED = "Not Required";
    private static final String YES = "Yes";
    private static final String COUNTRY = "selCountry";
    private static final String STATE = "selState";
    private static final String OPERTYPE_CREATE = "operType";
    private static final String SEARCHCLIENTLIST_URL = "common/admin/searchlistclient";
    private static final String CLIENT_ID = "clientId";    
    private static final String LIMITED = "Limited";
    private static final String REQUIRED_DOCSURL = "common/admin/addrequireddocs/";
    private static final int TAB_CLIENT = -1;
    private static final int TAB_THEME = 0;
    /*private static final int TAB_SEALEDBID_PARAMS = 3;
    private static final int TAB_AUCTION_PARAMS = 2;*/
    private static final int TAB_ADDI_SEALEDBID_PARAMS = -5;
    private static final int TAB_REGISTRATION_SUPP_DOC = -3;
    private static final int TAB_ADDI_AUCTION_PARAMS = -2;
    
    //private static final int TAB_SEALBID_CONFG = 1;
    private static final int TAB_AUCTION_CONFIG = 2;
    /*private static final int TAB_PQ_CONFIG = 3;
    private static final int TAB_TENDER_CONFIG = 4;
    private static final int TAB_RFQSEALBID_CONFIG = 5;
    private static final int TAB_RFP_CONFIG = 6;
    private static final int TAB_RFI_CONFIG = 7;
    private static final int TAB_REOI_CONFIG = 8;*/
    private static final int TAB_ONLINE_PAYMENT = 1;
    private static final int TAB_NEFTRTGS = 2;
    private static final int TAB_ACCOUNTMAPPING = 3;
    /**
     * Search and listing sub domain
     *
     * @param enc
     * @return to view
     */
    @RequestMapping(value = "/admin/searchlistclient/{enc}", method = RequestMethod.GET)
    public String searchListSubDomain(ModelMap modelMap, HttpServletRequest request, HttpSession session) {
        try {
            //int reportId = 1;
        	modelMap.put("lstClientMarquee", clientService.getClientMarqueeAfterLogin((int) abcUtility.getSessionClientId(request)));/* For After Loging Marque */
            modelMap.addAttribute("reportId", manageClientReportId);
            reportGeneratorService.getReportConfigDetails(manageClientReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
        finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, auditManageClient,0,0);
        }
        return "/common/admin/SearchListClient";
    }
    
    void setClientData(ModelMap modelMap) throws Exception{
    		String langId=WebUtils.getCookie(getServletRequest(), "locale").getValue();
            List<SelectItem> selDomainType = new ArrayList<SelectItem>();
            selDomainType.add(new SelectItem("PKI", 0));
            selDomainType.add(new SelectItem("Non PKI", 1));
            selDomainType.add(new SelectItem(EVENT_SPECIFIC, 2));
            modelMap.addAttribute("selDomainType", selDomainType);

            List<SelectItem> selWorkflow = new ArrayList<SelectItem>();
            selWorkflow.add(new SelectItem("Required", 1));
            selWorkflow.add(new SelectItem(NOT_REQUIRED, 0));
            selWorkflow.add(new SelectItem(EVENT_SPECIFIC, 2));
            modelMap.addAttribute("selWorkflow", selWorkflow);
            
            List<TblDateFormat> tblDateFormatList = commonService.getDateFormatList();
            List<SelectItem> selDateFormat = modelToSelectItem.convertListIntoSelectItemList(tblDateFormatList, "dateFormatId", "dateFormat");
            modelMap.addAttribute("selDateFormat", selDateFormat);

            List<SelectItem> selFiguresIntoWords = new ArrayList<SelectItem>();
            selFiguresIntoWords.add(new SelectItem("Lacs, Crore", 0));
            selFiguresIntoWords.add(new SelectItem("Million, Billion, Trillion", 1));
            modelMap.addAttribute("selFiguresIntoWords", selFiguresIntoWords);

            List<TblCurrency> tblCurrencyList = commonService.getCurrencyList();
            List<SelectItem> selDefaultCurrency = modelToSelectItem.convertListIntoSelectItemList(tblCurrencyList, "currencyId", "lang"+langId);
            modelMap.addAttribute("selDefaultCurrency", selDefaultCurrency);

            List<TblLanguage> tblLanguageList = commonService.getLanguageList();
            List<SelectItem> selDefaultLanguage = modelToSelectItem.convertListIntoSelectItemList(tblLanguageList, "languageId", "language");
            modelMap.addAttribute("selDefaultLanguage", selDefaultLanguage);

            List<TblTimeZone> tblTimeZoneList = commonService.getTimeZoneList();
            List<SelectItem> selTimeZone = modelToSelectItem.convertListIntoSelectItemList(tblTimeZoneList, "timeZoneId", "lang"+langId);
            modelMap.addAttribute("selTimeZone", selTimeZone);

            List<SelectItem> selBidderRegVeriBy = new ArrayList<SelectItem>();
            selBidderRegVeriBy.add(new SelectItem("Email ID", 1));
            selBidderRegVeriBy.add(new SelectItem("Email ID and Mobile Number", 2));
            selBidderRegVeriBy.add(new SelectItem("Mobile Number", 3));
            selBidderRegVeriBy.add(new SelectItem(NOT_REQUIRED, 0));
            modelMap.addAttribute("selBidderRegVeriBy", selBidderRegVeriBy);
            String [] tempListOfCertificateClass = tempCertificateClass.split("\\|");
            List <SelectItem> selectedCertificateClass = new ArrayList<SelectItem>();
            for (String tempkey : tempListOfCertificateClass) {      	
            	SelectItem item = new SelectItem();
            	item.setLabel(tempkey);
            	item.setValue(tempkey.charAt(tempkey.length()-1));
            	
            	if(tempkey.equalsIgnoreCase("CLASS-2") || tempkey.equalsIgnoreCase("CLASS-3"))
            	{
            		item.setSelectedVal(tempkey.charAt(tempkey.length()-1));
            	}
				selectedCertificateClass.add(item);
			}
            modelMap.addAttribute("selectedCertificateClass",selectedCertificateClass);
            List<SelectItem> signerTypes = new ArrayList<SelectItem>();
            signerTypes.add(new SelectItem(messageSource.getMessage("fields_signertype_capicom",null,"Capicom",LocaleContextHolder.getLocale()), 0));
            signerTypes.add(new SelectItem(messageSource.getMessage("fields_signertype_signer_service",null,"Signer Service",LocaleContextHolder.getLocale()), 1));
            modelMap.addAttribute("signerTypes", signerTypes);
            List<SelectItem> selDeptUserRegVeriBy = new ArrayList<SelectItem>();
            selDeptUserRegVeriBy.add(new SelectItem("Email ID", 1));
            selDeptUserRegVeriBy.add(new SelectItem("Email ID and Mobile Number", 2));
            selDeptUserRegVeriBy.add(new SelectItem(NOT_REQUIRED, 0));
            modelMap.addAttribute("selDeptUserRegVeriBy", selDeptUserRegVeriBy);

            List<SelectItem> selRegistrationBy = new ArrayList<SelectItem>();
            selRegistrationBy.add(new SelectItem("Bidder", 1));
            selRegistrationBy.add(new SelectItem("Authorized User", 0));
            modelMap.addAttribute("selRegistrationBy", selRegistrationBy);

            List<SelectItem> selRegCharges = new ArrayList<SelectItem>();
            selRegCharges.add(new SelectItem("Applicable", 1));
            selRegCharges.add(new SelectItem("Not Applicable", 0));
//            selRegCharges.add(new SelectItem(EVENT_SPECIFIC, 2));
            modelMap.addAttribute("selRegCharges", selRegCharges);

            List<SelectItem> lstRequiredList = new ArrayList<SelectItem>();
            lstRequiredList.add(new SelectItem("Required", 1));
            lstRequiredList.add(new SelectItem(NOT_REQUIRED, 0));
            modelMap.addAttribute("selRegSupportingDoc", lstRequiredList);

            List<TblModule> tblModuleList = commonService.getModuleList();
            List<SelectItem> selDefaultHomePgLst = modelToSelectItem.convertListIntoSelectItemList(tblModuleList, "moduleId", "lang"+langId);
            selDefaultHomePgLst.add(0, new SelectItem("Please Select", 0));
            modelMap.addAttribute("selDefaultHomePgLst", selDefaultHomePgLst);

            List<SelectItem> selDigitalCerti = new ArrayList<SelectItem>();
            selDigitalCerti.add(new SelectItem(YES, 1));
            selDigitalCerti.add(new SelectItem("No", 0));
            selDigitalCerti.add(new SelectItem(EVENT_SPECIFIC, 2));
            modelMap.addAttribute("selDigitalCerti", selDigitalCerti);

            List<SelectItem> selListingView = new ArrayList<SelectItem>();
            /* Change Request #34301 to add listing style block by Pranav Gandharva*/ 
           
            selListingView.add(new SelectItem("Tabular", 0));
            selListingView.add(new SelectItem("Normal", 1));
            selListingView.add(new SelectItem("Block",2));
            modelMap.addAttribute("selListingView", selListingView);

            List<SelectItem> selDigiCertiType = new ArrayList<SelectItem>();
            selDigiCertiType.add(new SelectItem("Single", 1));
            selDigiCertiType.add(new SelectItem("Dual", 2));
            modelMap.addAttribute("selDigiCertiType", selDigiCertiType);

            List<SelectItem> selConcurrentLoginSession = new ArrayList<SelectItem>();
        	selConcurrentLoginSession.add(new SelectItem("Multiple", 1));
            selConcurrentLoginSession.add(new SelectItem("Single", 0));
            modelMap.addAttribute("selConcurrentLoginSession", selConcurrentLoginSession);

            List<SelectItem> rYesNo = new ArrayList<SelectItem>();
            rYesNo.add(new SelectItem(YES, 1));
            rYesNo.add(new SelectItem("No", 0));
            modelMap.addAttribute("rYesNo", rYesNo);

            List<SelectItem> selIsShowDcBanner = new ArrayList<SelectItem>();
            selIsShowDcBanner.add(new SelectItem(YES, 1));
            selIsShowDcBanner.add(new SelectItem("No", 0));
            modelMap.addAttribute("selIsShowDcBanner", selIsShowDcBanner);
            
    		
            List<SelectItem> selIsloginLinkConfigured = new ArrayList<SelectItem>(); 
            SelectItem itemNo = new SelectItem("No",0);
            itemNo.setSelectedVal(0);
            selIsloginLinkConfigured.add(new SelectItem(YES, 1));
            selIsloginLinkConfigured.add(itemNo);
            modelMap.addAttribute("selIsloginLinkConfigured", selIsloginLinkConfigured);

          //Start : Modified for CR #26634 : Milan Kothari
            List<SelectItem> selIsCalendarConfigured = new ArrayList<SelectItem>(); 
            SelectItem tempObject = new SelectItem("No",0);
            itemNo.setSelectedVal(0);
            selIsCalendarConfigured.add(new SelectItem(YES, 1));
            selIsCalendarConfigured.add(itemNo);
            modelMap.addAttribute("selIsCalendarConfigured", selIsCalendarConfigured);
          //End : Modified for CR #26634 : Milan Kothari
            
            List<SelectItem> selIsTwoStepBidderApproval = new ArrayList<SelectItem>();
            selIsTwoStepBidderApproval.add(new SelectItem("No", 0));
            selIsTwoStepBidderApproval.add(new SelectItem(YES, 1));
            //selIsTwoStepBidderApproval.add(new SelectItem("Auto", 2));
            modelMap.addAttribute("selIsTwoStepBidderApproval", selIsTwoStepBidderApproval);

            List<SelectItem> selMapDcRequired = new ArrayList<SelectItem>();
            selMapDcRequired.add(new SelectItem("During Registration", 1));
            selMapDcRequired.add(new SelectItem("At the time of Login", 0));
            modelMap.addAttribute("selMapDcRequired", selMapDcRequired);

            List<SelectItem> selIsConcurrentLogin = new ArrayList<SelectItem>();
            selIsConcurrentLogin.add(new SelectItem(YES, 1));
            selIsConcurrentLogin.add(new SelectItem("No", 0));
            modelMap.addAttribute("selIsConcurrentLogin", selIsConcurrentLogin);
            List<SelectItem> isCapchaConfigured = new ArrayList<SelectItem>();
            isCapchaConfigured.add(new SelectItem("Captcha code", 1));
            isCapchaConfigured.add(new SelectItem("Manual unlock", 0));
            modelMap.addAttribute("CapchaConfigured", isCapchaConfigured);
            
            /** 0 for Not Set, 1 for CPV Category, 2 for Manual Category */
            List<SelectItem> categoryStdList = new ArrayList<SelectItem>();
            categoryStdList.add(new SelectItem(messageSource.getMessage("lbl_standard_cpv",null,"Standard (CPV)",LocaleContextHolder.getLocale()),1));
            categoryStdList.add(new SelectItem(messageSource.getMessage("label_manual",null,"Manual",LocaleContextHolder.getLocale()),2));
            modelMap.addAttribute("categoryStdList", categoryStdList);
            
            List<SelectItem> selRegistrationMode = new ArrayList<SelectItem>();
            selRegistrationMode.add(new SelectItem("Online", 1));
            selRegistrationMode.add(new SelectItem("Offline", 2));
            selRegistrationMode.add(new SelectItem("Both", 3));
            modelMap.addAttribute("selRegistrationMode", selRegistrationMode);
            List<SelectItem> selOfficerRegBy = new ArrayList<SelectItem>();
            selOfficerRegBy.add(new SelectItem("Registered Officer", 1));
            selOfficerRegBy.add(new SelectItem("Himself", 2));
            modelMap.addAttribute("selOfficerRegBy", selOfficerRegBy);
            
            List<SelectItem> selGSTDetailsRequired = commonService.getGSTDetailsRequired();
            modelMap.addAttribute("selGSTDetailsRequired", selGSTDetailsRequired);
            List<SelectItem> selBusinessTieUp = commonService.getBusinessTieUp();
            modelMap.addAttribute("selBusinessTieUp", selBusinessTieUp);
            
            List<SelectItem> selAutoInvoice = new ArrayList<SelectItem>();
            selAutoInvoice.add(new SelectItem("No", 0));
            selAutoInvoice.add(new SelectItem(YES, 1));
            modelMap.addAttribute("selAutoInvoice", selAutoInvoice);
    }
    /**
     * author Lipi Shah
     * configure CPPP Details Client wise 
     */
    @RequestMapping(value = "/admin/configureClientCPPP/{clientId}/{enc}", method = RequestMethod.GET)
    public String configureClientCPPP(@PathVariable(CLIENT_ID) int clientId, ModelMap modelMap, HttpServletRequest request, HttpSession session) {
        try {
        	modelMap.addAttribute("domainName", clientService.getClientNameById(clientId));
        	String clientName=clientService.getClientNameByClientId(clientId);
        	boolean isSuccess = clientService.checkCPPPConfigureOrNot(clientId);
        	List<TblClientCPPPConfig> list = clientService.getCPPPDetailsByClient(clientId);
    		if(list!=null && !list.isEmpty()){
    			modelMap.addAttribute("CPPPDtls",list.get(0));
    		}
        	if(isSuccess && !clientName.isEmpty()){
        		modelMap.addAttribute("opType", "View");
        		modelMap.addAttribute("isApproved", true);
        	}else{
        		modelMap.addAttribute("opType", "Create");
        		modelMap.addAttribute("isApproved", false);
        	}
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
        finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, auditManageClient,0,0);
        }
        return "/common/admin/ConfigureClientCPPP";
    }
    /**
     * author Lipi Shah
     * ADD CPPP Details Client wise 
     */
    @RequestMapping(value = "/admin/addClientCPPPDetails", method = RequestMethod.POST)
    public String addClientCPPPDetails(ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) { 
        boolean isSuccess = false;
        String retVal = SEARCHCLIENTLIST_URL;
        try{
        	String xml_userId = StringUtils.hasLength(request.getParameter("txtCPPPUserId")) ? request.getParameter("txtCPPPUserId") : "";
        	String userName = StringUtils.hasLength(request.getParameter("txtCPPPUserName")) ? request.getParameter("txtCPPPUserName") : "";
        	String password = StringUtils.hasLength(request.getParameter("txtCPPPPassword")) ? request.getParameter("txtCPPPPassword") : "";
        	String url = StringUtils.hasLength(request.getParameter("txtCPPPUrl")) ? request.getParameter("txtCPPPUrl") : "";
        	int clientId = StringUtils.hasLength(request.getParameter("hdClientId")) ? Integer.parseInt(request.getParameter("hdClientId")) : 0;
        	boolean isApproved = StringUtils.hasLength(request.getParameter("hdIsApproved")) ? Boolean.parseBoolean(request.getParameter("hdIsApproved")) : false;
        	
        	isSuccess = clientService.checkCPPPConfigureOrNot(clientId);
        	if(!isApproved){
	        	TblClientCPPPConfig tblClientCPPPConfig = new TblClientCPPPConfig();
	        	if(isSuccess){
	        		int cpppId = StringUtils.hasLength(request.getParameter("hdCpppId")) ? Integer.parseInt(request.getParameter("hdCpppId")) : 0;
	        		tblClientCPPPConfig.setCppp_Id(cpppId);
	        	}
	        	tblClientCPPPConfig.setXml_user_id(xml_userId);
	        	tblClientCPPPConfig.setTblClient(new TblClient(clientId));
	        	tblClientCPPPConfig.setPassword(password);
	        	tblClientCPPPConfig.setUrl(url);
	        	tblClientCPPPConfig.setUsername(userName);
	            isSuccess = clientService.addClientCPPPConfig(tblClientCPPPConfig);
	            redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "msg_success_client_CPPP_conf" : CommonKeywords.ERROR_MSG_KEY.toString());
        	}else{
        		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"msg_success_already_client_CPPP_conf");
        	}
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), isEdit?editClientLinkId:createClientLinkId,isEdit? auditClientEdited : auditClientCreated, 0, tblClient.getClientId());
        }
        
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    
    /**
     * author janak dhanani
     * validate CPPP Client Configure are available or not
     */
    
    @RequestMapping(value = "/admin/validateCPPPClientConfigure/", method = RequestMethod.POST)
    @ResponseBody
    public String validateCPPPClientConfigure(@RequestParam("xmlUserId") String xmlUserId,@RequestParam("xmlUserName") String xmlUserName,@RequestParam("xmlPassword") String xmlPassword, HttpServletRequest request) {
        String retVal = "sessionexpired";
        try {
        	boolean checkInTblClientCppp = false;
        	List<TblClientCPPPConfig> tblClientCPPPConfigsList = clientService.getAllTblClientCPPPConfig();
        	if(tblClientCPPPConfigsList !=null && !tblClientCPPPConfigsList.isEmpty())
        	{
	        	for (TblClientCPPPConfig tblClientCPPPConfig : tblClientCPPPConfigsList) {
					if(tblClientCPPPConfig.getXml_user_id().equals(xmlUserId) || tblClientCPPPConfig.getUsername().equals(xmlUserName) || (tblClientCPPPConfig.getXml_user_id().equals(xmlUserId) && tblClientCPPPConfig.getUsername().equals(xmlUserName)))
						checkInTblClientCppp = true;
				}
        	}
        	if(checkInTblClientCppp)
        	{
        		retVal = "alreadyExist";
        		return retVal;
        	}
        	retVal = clientService.validateCPPPClientConfigure(xmlUserId,xmlUserName,xmlPassword);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return retVal;
    }
    
    /**
     * To Display create sub domain page
     * @Author Shreyansh.shah 
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/createclient/{enc}", method = RequestMethod.GET)
    public String createSubDomain(ModelMap modelMap,HttpServletRequest request) {
        try {
            List<Object[]> lstModule = clientService.getClientModule(0);
            List<SelectItem> chkModule = abcUtility.convert(lstModule);
            modelMap.addAttribute("chkModule", chkModule);

            List<Object[]> lstWorkFlowType = clientService.getClientWorkflow(0);
            List<SelectItem> chkWorkflowType = abcUtility.convert(lstWorkFlowType);
            modelMap.addAttribute("chkWorkflowType", chkWorkflowType);

            List<Object[]> lstCurrency = clientService.getClientCurrency(0);
            List<SelectItem> selCurrency = abcUtility.convert(lstCurrency);
            modelMap.addAttribute("selCurrency", selCurrency);
            String [] tempListOfCertificateClass = tempCertificateClass.split("\\|");
            
            List <SelectItem> selectedCertificateClass = new ArrayList<SelectItem>();
            for (String tempkey : tempListOfCertificateClass) {
				selectedCertificateClass.add(new SelectItem(tempkey,tempkey.charAt(tempkey.length()-1)));
			}
            
            modelMap.addAttribute("selectedCertificateClass",selectedCertificateClass);
            List<Object[]> lstLanguage = clientService.getClientLanguage(0);
            List<SelectItem> selLanguage = abcUtility.convertSelected(lstLanguage);
            modelMap.addAttribute("selLanguage", selLanguage);
            
            String langId=WebUtils.getCookie(request, "locale").getValue();
            List<TblCountry> lstCountry = commonService.getCountryList(langId);
            List<SelectItem> selCountry = modelToSelectItem.convertListIntoSelectItemList(lstCountry,"countryId", "lang"+langId);
            modelMap.addAttribute(COUNTRY, selCountry);

            List<TblState> lstState = commonService.getStateBycountryId(105);
            List<SelectItem> selState = modelToSelectItem.convertListIntoSelectItemList(lstState, "stateId", "lang"+langId);
            modelMap.addAttribute(STATE, selState);

            modelMap.addAttribute("selPaymentRequires", clientService.getPaymentRequires());
            List<SelectItem> selPaymentConfigBy = new ArrayList<SelectItem>();
            selPaymentConfigBy.add(new SelectItem("Client", 1));
            selPaymentConfigBy.add(new SelectItem("Department", 2));
            modelMap.addAttribute("selPaymentConfigBy", selPaymentConfigBy);
            List<TblPaymentType> paymentType =  commonService.getPaymentTypeList();
            modelMap.addAttribute("paymentType",paymentType);
            List<Object[]> lstBank = clientService.getActiveBank(0);
            List<SelectItem> selBank = abcUtility.convert(lstBank);
            modelMap.addAttribute("selBank", selBank);
            modelMap.addAttribute("iscCapchaConfigured", 1);
            setClientData(modelMap);
                           
            /* Change Request #34301 to add Search panel and Select homepage by Pranav Gandharva */
            
            List<SelectItem> searchPanel= new ArrayList<SelectItem>();
            searchPanel.add(new SelectItem(searchPanelDefault, 0));
            searchPanel.add(new SelectItem(searchHorizontal,1));
            searchPanel.add(new SelectItem(searchVertical,2));
            modelMap.addAttribute("searchPanel",searchPanel);
            
            List<SelectItem> displayHomePage= new ArrayList<SelectItem>();
            displayHomePage.add(new SelectItem(homePageNo,0));
            displayHomePage.add(new SelectItem(homePageYes,1));
            modelMap.addAttribute("displayHomePage",displayHomePage);
            
            List<SelectItem> selectHomePage= new ArrayList<SelectItem>();
            selectHomePage.add(new SelectItem(aucProperty,1));
            modelMap.addAttribute("selectHomePage",selectHomePage);
                        
            List<SelectItem> eventStatusListing= new ArrayList<SelectItem>();
            eventStatusListing.add(new SelectItem("Live", 0));
            eventStatusListing.add(new SelectItem("Live and Future",1));
            modelMap.addAttribute("selIsEventStatusListing",eventStatusListing);
            /*Project Task #40511 : Start*/
            List<SelectItem> rfxSavingFormula = new ArrayList<SelectItem>();
            rfxSavingFormula.add(new SelectItem(messageSource.getMessage("ten_Estimated_Value_L1_Value", null, LocaleContextHolder.getLocale()), 1));
            modelMap.addAttribute("rfxSavingFormula", rfxSavingFormula);
            
            List<SelectItem> auctionSavingFormulaWithStartPrice = new ArrayList<SelectItem>();
            auctionSavingFormulaWithStartPrice.add(new SelectItem(messageSource.getMessage("search_panel_default", null, LocaleContextHolder.getLocale()), 0));
            auctionSavingFormulaWithStartPrice.add(new SelectItem(messageSource.getMessage("auc_start_price_auction_L1H1", null, LocaleContextHolder.getLocale()), 1));
            modelMap.addAttribute("auctionSavingFormulaWithStartPrice", auctionSavingFormulaWithStartPrice);
            
            List<SelectItem> auctionSavingFormulaWithoutStartPrice = new ArrayList<SelectItem>();
            auctionSavingFormulaWithoutStartPrice.add(new SelectItem(messageSource.getMessage("search_panel_default", null, LocaleContextHolder.getLocale()), 0));
            auctionSavingFormulaWithoutStartPrice.add(new SelectItem(messageSource.getMessage("auc_L1H1_offirst_quote_received_auction_L1H1", null, LocaleContextHolder.getLocale()), 1));
            auctionSavingFormulaWithoutStartPrice.add(new SelectItem(messageSource.getMessage("auc_first_bidreceived_auction_L1H1", null, LocaleContextHolder.getLocale()), 2));
            modelMap.addAttribute("auctionSavingFormulaWithoutStartPrice", auctionSavingFormulaWithoutStartPrice);
            
            /*CR #52114*/
            List<SelectItem> selGSTDetailsRequired = commonService.getGSTDetailsRequired();
            modelMap.addAttribute("selGSTDetailsRequired", selGSTDetailsRequired);
            
            /*Project Task #40511 : End*/
            modelMap.addAttribute(OPERTYPE_CREATE, "create");
            
            List<SelectItem> selAllowExternalUsersToViewReports = commonService.getAllowExternalUserToViewReport();
            modelMap.addAttribute("selAllowExternalUsersToViewReports",selAllowExternalUsersToViewReports);
            
        } catch (Exception e) {
             return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createClientLinkId, auditCreateClient,0,0);
        }
        return "/common/admin/CreateClient";
    }
    /**To Approve SubDomain Details, it will finally approve sub domain.
     * @Author Shreyansh.shah
     * @param modelMap
     * @param session
     * @param redirectAttributes
     * @param response
     * @param request
     * @return 
     */
    @RequestMapping(value="/admin/updateApprovedClient/", method = RequestMethod.POST)
    public String updateApprovedClient(RedirectAttributes redirectAttributes, HttpServletRequest request) { 
        String retVal = null;
        String remarks = request.getParameter("txtaRemarks");
        boolean isSuccess = false;
        int clientId = 0;
        int userId = 0;
        int createdBy=0;
        try {
            if (remarks != null && request.getParameter("hdclientId") != null) {
                clientId = Integer.parseInt(request.getParameter("hdclientId"));
                userId= abcUtility.getSessionUserId(request);
                clientService.updateClientApproval(clientId, userId);
               
                //#Project Task #50218 Admin User (ETL Executive) : Limited domain login rights
            	//author Hardik Gohil  
                List<TblUserClientAccess> userClientAccessesList = new ArrayList<TblUserClientAccess>();
                TblUserClientAccess forSuperAdminAccess = new TblUserClientAccess();
                forSuperAdminAccess.setTblUserLogin(new TblUserLogin(1));//For assigning client access right to superAdmin 
                forSuperAdminAccess.setTblClient(new TblClient(clientId));
                forSuperAdminAccess.setCreatedBy(userId);
                forSuperAdminAccess.setCStatus(1);
                userClientAccessesList.add(forSuperAdminAccess);
                
                createdBy =clientService.getCreatedByFromTblClientByClientId(clientId);
                if(createdBy!=0 && createdBy!=1) {
                	TblUserClientAccess forCreatedClientUserAccess = new TblUserClientAccess();
                	forCreatedClientUserAccess.setTblUserLogin(new TblUserLogin(createdBy));//For assigning client access right to whoever created the client 
                	forCreatedClientUserAccess.setTblClient(new TblClient(clientId));
                	forCreatedClientUserAccess.setCreatedBy(userId);
                	forCreatedClientUserAccess.setCStatus(1);
                	userClientAccessesList.add(forCreatedClientUserAccess);
                }
                
                clientService.addTblUserClientAccess(userClientAccessesList);
                isSuccess=true;
                retVal = SEARCHCLIENTLIST_URL;
            } else {
            	isSuccess=false;
            	retVal = "common/admin/approveclient/"+clientId;
            }
        } catch (Exception ex) { 
            return exceptionHandlerService.writeLog(ex);
        } finally {
            if(abcUtility.getSessionIsPkiEnabled(request) ==1){
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), approveClientLinkId,auditApproveClientWithSign, 0,clientId,remarks,request.getParameter("skpSignText"));
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), approveClientLinkId,auditApproveClientWithSign, 0,clientId,remarks);
        	}
        }
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? "redirect_success_approveclient" : CommonKeywords.ERROR_MSG_KEY.toString());
        return  "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }

    /**
     * To add and update client details
     * @Author Shreyansh.shah
     * @param clientDtBean
     * @param result
     * @param modelMap
     * @param session
     * @param redirectAttributes
     * @param response
     * @param request
     * @return 
     */
    @RequestMapping(value = "/admin/addclientdetails/", method = RequestMethod.POST)
    public String addClientDetails(@ModelAttribute ClientDtBean clientDtBean, BindingResult result, ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) { 
        boolean isSuccess = false;
        boolean isApprove = false;
        String retVal = null;
        String clientId = request.getParameter("hdclientId");
        String redirectLink = null;
        String successRedirectLink;
        String successMessage = null;
        int paymentMode = 0;
        boolean isEdit = false;
        int userId = abcUtility.getSessionUserId(request);
        TblClient tblClient = new TblClient();
        try {
            if (clientId == null || clientId.equals("0")) {
                redirectLink = "common/admin/createclient";
                successMessage = "redirect_success_addclient";
            } else {
                isEdit = true;
                redirectLink = "common/admin/editclient/" + clientId;
                successMessage = "redirect_success_updateclient";
            }
            //Start for PT#28958 and CR#27339 (Pki & Event Specific Domain By Default Set 2 for Dual Certificate)
	            if(Integer.parseInt(clientDtBean.getSelIsPkiEnabled()) != 0) {
	            	clientDtBean.setSelIsDualCerti("2");	//set for PT#28958 and CR#27339 (Pki & Event Specific Domain By Default Set 2 for Dual Certificate)
	            }
            //End for PT#28958 and CR#27339 (Pki & Event Specific Domain By Default Set 2 for Dual Certificate)
            clientDtBean.setCommonValidators(commonValidators);
            clientDtBean.validateBean(result);
            
            // set default dc verification to 1
            clientDtBean.setIsDcVerificationRequired(1);
            
            boolean validateDomain = commonService.checkUniqueDomainName(clientDtBean.getTxtDomainName(), Integer.parseInt(clientId));
            if (!validateDomain) {
                result.rejectValue("txtDomainName", "msg_domainname_exists", "Domain name Already Exist");
            }
            if (result.hasErrors()) {
                List<Object[]> lstModule = clientService.getClientModule(0);
                List<SelectItem> chkModule = abcUtility.convert(lstModule);
                modelMap.addAttribute("chkModule", chkModule);

                List<Object[]> lstWorkFlowType = clientService.getClientWorkflow(0);
                List<SelectItem> chkWorkflowType = abcUtility.convert(lstWorkFlowType);
                modelMap.addAttribute("chkWorkflowType", chkWorkflowType);

                List<Object[]> lstCurrency = clientService.getClientCurrency(0);
                List<SelectItem> selCurrency = abcUtility.convert(lstCurrency);
                modelMap.addAttribute("selCurrency", selCurrency);
                
                String tempselectedCertificateClass[]=tblClient.getCertificateClass().split("\\|");
                List <SelectItem> selectedCertificateClass = new ArrayList<SelectItem>();
                for (String tempkey : tempselectedCertificateClass) {
    				selectedCertificateClass.add(new SelectItem("Class_"+tempkey,tempkey));
    			}
                modelMap.addAttribute("selectedCertificateClass",selectedCertificateClass);

                List<Object[]> lstLanguage = clientService.getClientLanguage(0);
                List<SelectItem> selLanguage = abcUtility.convertSelected(lstLanguage);
                modelMap.addAttribute("selLanguage", selLanguage);
                
                String langId=WebUtils.getCookie(request, "locale").getValue();
                List<TblCountry> lstCountry = commonService.getCountryList(langId);
                List<SelectItem> selCountry = modelToSelectItem.convertListIntoSelectItemList(lstCountry, "countryId", "lang"+langId);
                modelMap.addAttribute(COUNTRY, selCountry);

                List<TblState> lstState = commonService.getStateBycountryId(105);
                List<SelectItem> selState = modelToSelectItem.convertListIntoSelectItemList(lstState, "stateId", "lang"+langId);
                modelMap.addAttribute(STATE, selState);

                List<Object[]> lstModeOfPayment = clientService.getClientPaymentType(0);
                List<SelectItem> selModeOfPayment = abcUtility.convert(lstModeOfPayment);
                modelMap.addAttribute("selModeOfPayment", selModeOfPayment);
                List<TblPaymentType> paymentType =  commonService.getPaymentTypeList();
                modelMap.addAttribute("paymentType",paymentType);
                List<SelectItem> selPaymentConfigBy = new ArrayList<SelectItem>();
                selPaymentConfigBy.add(new SelectItem("Client", 1));
                selPaymentConfigBy.add(new SelectItem("Department", 2));
                modelMap.addAttribute("selPaymentConfigBy", selPaymentConfigBy);
                
                List<Object[]> lstBank = clientService.getActiveBank(0);
                List<SelectItem> selBank = abcUtility.convert(lstBank);
                modelMap.addAttribute("selBank", selBank);
                
                if(isEdit) {
                    modelMap.addAttribute("EprocLogo", CommonUtility.checkValue(request.getParameter("hdEprocLogo")));
                    modelMap.addAttribute("ArchieveContext", CommonUtility.checkNull(request.getParameter("txtArchieveContext")));
                    modelMap.addAttribute("ClientId", clientId);
                    modelMap.addAttribute("ThemeId", CommonUtility.checkValue(request.getParameter("hdThemeId")));
                    modelMap.addAttribute("Logo",  request.getParameter("hdLogo"));
                    modelMap.addAttribute("DeptId",  CommonUtility.checkValue(request.getParameter("hddeptId")));
                }
                setClientData(modelMap);
                modelMap.addAttribute(OPERTYPE_CREATE, "error");
                retVal = "common/admin/CreateClient";
            } else {
                List<TblClientModule> tblClientModules = new ArrayList<TblClientModule>();
                List<TblClientWorkflowType> tblClientWorkflows = new ArrayList<TblClientWorkflowType>();
                List<TblClientLanguage> tblClientLanguages = new ArrayList<TblClientLanguage>();
                List<TblClientCurrency> tblClientCurrencies = new ArrayList<TblClientCurrency>();
                List<TblClientPayment> tblClientPayments = new ArrayList<TblClientPayment>();
                List<TblClientPGBankMapping> tblClientPGBankMappings = new ArrayList<TblClientPGBankMapping>();
                String chkModule[] = request.getParameterValues("chkModuleList");
                boolean auctionFlag=true,tenderFlag=true;
                for (String module : chkModule) {
                    if(module.equals("5")){
                    	auctionFlag=false;	
                    }else if(module.equals("3")){
                    	tenderFlag=false;
                    }
                }
                if(auctionFlag){
                	clientDtBean.setSelAuctionSavingFormulaWithStartPrice(0);
                	clientDtBean.setSelAuctionSavingFormulaWithoutStartPrice(0);
                }
                if(tenderFlag){
                	clientDtBean.setSelRfxSavingFormula(0);
                }
                tblClient = clientDtBean._toTblClient();
                int isGstApplicable = (Integer) clientService.getClientField(Integer.parseInt(clientId), "isGSTApplicable");
                if(clientDtBean.getSelIsGstRequired()==1 && isGstApplicable==0){
                	tblClient.setIsGSTApplicable(1);
                }else if(clientDtBean.getSelIsGstRequired()==0 && isGstApplicable==0){
                	tblClient.setIsGSTApplicable(0);
                }else if(isGstApplicable==1){
                	tblClient.setIsGSTApplicable(1);
                }
                tblClient.setCreatedBy(userId);
                tblClient.setUpdatedBy(userId);
                if (isEdit) {
                	tblClient.setIsShowCompanyLogo(clientDtBean.getHdIsShowCompanyLogo());
                }
                tblClient.setBusinessTieup(clientDtBean.getSelbusinessform());
                tblClient.setLogoLocation(1);
                tblClient.setIsCaptchaConfigured(Integer.parseInt(request.getParameter("rdIsCapchaConfigured"))); //CR : #25347 add captcha code Configuration by Keval
                int isActive = (Integer) clientService.getClientField(Integer.parseInt(clientId), "isActive");
                isApprove = isActive==1 ? true : false;
                if(Integer.parseInt(request.getParameter("hdThemeId")) ==1 ) {
                    tblClient.setLogo(request.getParameter("hdLogo"));
                    tblClient.setTblTheme(new TblTheme(1));
                } else {
                    tblClient.setLogo(request.getParameter("hdLogo"));
                    tblClient.setTblTheme(new TblTheme(Integer.parseInt(request.getParameter("hdThemeId"))));
                }
                        
                
                String chkLanguages[] = request.getParameterValues("chkLanguage");
                String chkCurrencies[] = request.getParameterValues("chkCurrency");
                String temp=null;
               
                String certificateClass="";
                
                if((tblClient.getIsPkiEnabled()==1 || tblClient.getIsPkiEnabled()==2)  && (request.getParameterValues("chkDigitalCertificateClass")!=null) )
                {
                	if(request.getParameterValues("chkDigitalCertificateClass").toString()!="")
                	{
                		String chkCertificateClass[] = request.getParameterValues("chkDigitalCertificateClass");
                    
                		for(int i=0;i<chkCertificateClass.length;i++)
                		{
                			temp = chkCertificateClass[i];
                			certificateClass +=temp.charAt(temp.length()-1);
                			if(i == (chkCertificateClass.length-1))
                			{
                		
                			}
                			else
                			{
                				certificateClass+="|";
                			}
                		}
                	}
                }
                else
                {
                	certificateClass = "N.A";
                }
                tblClient.setCertificateClass(certificateClass);
                // For Edit set client id to update data

                for (String module : chkModule) {
                    TblClientModule tblClientModule = new TblClientModule();
                    tblClientModule.setTblModule(new TblModule(Integer.parseInt(module)));
                    tblClientModule.setTblClient(tblClient);
                    if (tblClient.getTblModule().getModuleId() == Integer.parseInt(module)) {
                        tblClientModule.setIsDefault(1);
                    } else {
                        tblClientModule.setIsDefault(0);
                    }
                    tblClientModule.setIsActive(1);
                    tblClientModules.add(tblClientModule);
                }
                
                /*
                 * Start : Added By Nirav Modi : CR :11933
                 */
                List<TblClientEventType> tblClientEventTypes= new ArrayList<TblClientEventType>();
                for (String module : chkModule) {
                	String chkEventTypeList[] = request.getParameterValues("echkEventTypeList"+module);
                	if(chkEventTypeList!=null && chkEventTypeList.length>0){
                		for (String eventTypeId : chkEventTypeList) {
                			TblClientEventType tblClientEventType = new TblClientEventType();
                			tblClientEventType.setIsActive(1);
                			tblClientEventType.setTblClient(tblClient);
                			tblClientEventType.setTblEventType(new TblEventType(Integer.parseInt(eventTypeId)));
                			tblClientEventTypes.add(tblClientEventType);
                		}
                	}
                }
                /*
                 * End : Added By Nirav Modi : CR :11933
                 */
                
                /* * Start : Added By Nirav Modi : CR :14804 */
                String categoryType = request.getParameter("selCategoryType");
                if(categoryType!=null && !categoryType.isEmpty()){
                	tblClient.setCategoryType(Integer.parseInt(categoryType));
                }
                /* * End : Added By Nirav Modi : CR :14804 */
                
                String IsloginLinkConfigured = request.getParameter("selIsloginLinkConfigured");
                if(IsloginLinkConfigured!=null && !IsloginLinkConfigured.isEmpty()){
                	tblClient.setIsloginLinkConfigured(Integer.parseInt(IsloginLinkConfigured));
                }
                
                String IscalendarConfigured = request.getParameter("selIsCalendarConfigured");
                if(IscalendarConfigured!=null && !IscalendarConfigured.isEmpty()){
                	tblClient.setIsCalendarConfigured(Integer.parseInt(IscalendarConfigured));
                }

                
                if (tblClient.getIsWorkflowReq() == 1 || tblClient.getIsWorkflowReq() == 2) {
                    String chkWorkFlowType[] = request.getParameterValues("chkWorkflowType");
                    for (String workFlow : chkWorkFlowType) {
                        TblClientWorkflowType tblClientWorkflow = new TblClientWorkflowType();
                        tblClientWorkflow.setTblWorkflowType(new TblWorkflowType(Integer.parseInt(workFlow)));
                        tblClientWorkflow.setTblClient(tblClient);
                        tblClientWorkflow.setIsActive(1);
                        if (tblClientWorkflow.getTblWorkflowType().getWorkflowTypeId() == Integer.parseInt(workFlow)) {
                            tblClientWorkflow.setIsDefault(1);
                        } else {
                            tblClientWorkflow.setIsDefault(0);
                        }

                        tblClientWorkflows.add(tblClientWorkflow);
                    }
                }
                for (String language : chkLanguages) {
                    TblClientLanguage tblClientLanguage = new TblClientLanguage();
                    tblClientLanguage.setTblLanguage(new TblLanguage(Integer.parseInt(language)));
                    tblClientLanguage.setTblClient(tblClient);
                    tblClientLanguage.setIsActive(1);
                    if (tblClient.getTblLanguage().getLanguageId() == Integer.parseInt(language)) {
                        tblClientLanguage.setIsDefault(1);
                    } else {
                        tblClientLanguage.setIsDefault(0);
                    }
                    tblClientLanguages.add(tblClientLanguage);
                }
                for (String currency : chkCurrencies) {
                    TblClientCurrency tblClientCurrency = new TblClientCurrency();
                    tblClientCurrency.setTblCurrency(new TblCurrency(Integer.parseInt(currency)));
                    tblClientCurrency.setTblClient(tblClient);
                    tblClientCurrency.setIsActive(1);
                    if (tblClient.getTblCurrency().getCurrencyId() == Integer.parseInt(currency)) {
                        tblClientCurrency.setIsDefault(1);
                    } else {
                        tblClientCurrency.setIsDefault(0);
                    }
                    tblClientCurrencies.add(tblClientCurrency);
                }
                /**
                 * Start : @author dipika
                 * changes of payment
                 */
                /**
                 * @uodated dharmesh
                 * for Bug Id #27808 - Edit client PG Issue
                 */
                //int neft_approved_count=neftService.getApprovedNeftRtgsConfCountByClientId(Integer.parseInt(clientId)); /*Condition Added for Bug Id #25124 */
//                if(isEdit && neft_approved_count>0){
//                	tblClient.setPaymentConfigBy(StringUtils.hasLength(request.getParameter("hdPaymentConfigBy").trim())?Integer.parseInt(request.getParameter("hdPaymentConfigBy").trim()):0);
//                }
//                if (tblClient.getIsOnlinePayment() != 0 && ((neft_approved_count == 0 && isEdit)|| !isEdit) ) {
                	int bankId=0;
                	int pgId=0;
                	TblClientPGBankMapping tblClientPGBankMapping=null;
                	HashSet<String> paymentTypes = new HashSet<String>();
                	if(tblClient.getIsOnlinePayment() != 0 ){
                		String paymentType[] = request.getParameterValues("selModeOfPayment");
                		for (String pType : paymentType) {
                        	paymentTypes.add(pType);
                        	}
                		}
                    for (String paymentType : paymentTypes) {
                        TblClientPayment tblClientPayment = new TblClientPayment();
                        tblClientPayment.setTblPaymentType(new TblPaymentType(Integer.parseInt(paymentType)));
                        if(Integer.parseInt(paymentType)==6)
                        {
                            paymentMode = Integer.parseInt(paymentType);      
                        }
                        tblClientPayment.setTblClient(tblClient);
                        tblClientPayment.setIsActive(1);
                        tblClientPayment.setCreatedBy(userId);
                        tblClientPayments.add(tblClientPayment);
                        
                        if(paymentType.equals("1") || paymentType.equals("2")){
                        	bankId= StringUtils.hasLength(request.getParameter("selBank"))?Integer.parseInt(request.getParameter("selBank")):0;
                        	if(StringUtils.hasLength(request.getParameter("selPaymentGateway"))){
	                        	pgId= StringUtils.hasLength(request.getParameter("selPaymentGateway"))?Integer.parseInt(request.getParameter("selPaymentGateway")):0;
	                        	}else{
	                        	List<Object[]> list=commonService.getPaymentGatewayByBankId(bankId);
	                        	pgId=list!=null && !list.isEmpty() ? Integer.valueOf(list.get(0)[0].toString()):1;
	                        }
	                        tblClientPGBankMapping=new TblClientPGBankMapping();
	                        tblClientPGBankMapping.setIsActive(1);
	                        tblClientPGBankMapping.setTblPaymentType(new TblPaymentType(Integer.parseInt(paymentType)));
	                        tblClientPGBankMapping.setTblBankMaster(new TblBankMaster(bankId));
	                        tblClientPGBankMapping.setTblPaymentGatewayMaster(new TblPaymentGatewayMaster(pgId));
	                        tblClientPGBankMapping.setTblClient(tblClient);  
	                        tblClientPGBankMappings.add(tblClientPGBankMapping);
                        }
                    }
//                }                
                /**
                 * end changes of payment by dipika
                 */
                TblDepartment tblDepartment = clientDtBean._toTblDepartment();
                tblDepartment.setTblClient(tblClient);
                tblDepartment.setCreatedBy(userId);
                /*
                 * Modify by Nirav Modi : apply transaction management
                 */
                if (isEdit) {
                    tblDepartment.setDeptId(Integer.parseInt(request.getParameter("hddeptId")));
                    tblClient.setClientId(Integer.parseInt(clientId));
                    tblClient.setEprocLogo(CommonUtility.checkValue(request.getParameter("hdEprocLogo")));
                    tblClient.setArchieveContext(CommonUtility.checkNull(request.getParameter("txtArchieveContext")));
                    tblClient.setIsActive(CommonUtility.checkValue(request.getParameter("hdisActive")));
                    TblClient clientBeforeUpdate = clientService.getClientById(Integer.parseInt(clientId));
                    if(clientBeforeUpdate.getIsTwoStepBidderApproval() != tblClient.getIsTwoStepBidderApproval()){
                    	if(clientBeforeUpdate.getIsTwoStepBidderApproval() == 0 && tblClient.getIsTwoStepBidderApproval() == 1){
                    		manageBidderService.updateBidderStatusByClientIdAndWorkflowIdAndCstatus(Integer.parseInt(clientId),9,1);
                    	}
                    }
                }
                /*
                 * Start : Added By Nirav Modi : CR :11933 : new tblClientEventTypes parameter added
                 */
                isSuccess = clientService.addClient(tblClient, tblClientModules, tblClientWorkflows, tblClientLanguages, tblClientCurrencies, tblDepartment, tblClientPayments,tblClientEventTypes,isEdit,tblClientPGBankMappings);
                /**
                 * in case of update clientRegWorkFlow Status in case of approved client. 
                 */
                if(isSuccess && isEdit && isApprove){
                	isSuccess = clientService.updateClientRegWorkFlowStatus(Integer.parseInt(clientId), userId);
                }
                if (!isEdit) {
                    successRedirectLink = "common/admin/themeconfig/" + tblClient.getClientId();
                } else {
                    successRedirectLink = SEARCHCLIENTLIST_URL;
                }
                /* Priyanka Works starts here */ 
                int isCheck = 0;
                List<TblClientExemptionCertificate>  tblClientExemptionCertificateList = tblClientExemptionCertificateDao.findTblClientExemptionCertificate("tblClient.clientId",Operation_enum.EQ,tblClient.getClientId(),"isActive",Operation_enum.EQ,1);
                if(isSuccess)
                {
                	if(tblClientExemptionCertificateList.isEmpty() && paymentMode==6)
                	{
                		isCheck = clientService.addTblClientExemptionCertificate(tblClient.getClientId());
                	}
                	else if((!tblClientExemptionCertificateList.isEmpty() && paymentMode!=6))
                	{
                		  // Update isActive = 0 of TblClientExemptionCertificate for client 
                		isCheck = clientService.updateTblClientExemptionCertificate(tblClient.getClientId());
                	}
                }
                /* Priyanka Works ends here */ 
                if (isSuccess) {
                    if (!isEdit) {
                        wSCheckAvailService.registerDomain(tblClient.getDomainName(), 2, Integer.parseInt(clientId), userId);
                    }
                    retVal = successRedirectLink;
                } else {
                    retVal = redirectLink;
                }
             // STQC Change By Jitendra. Add default config, terms & condition and client reg doc entry 
                if(isSuccess && !isEdit){
                	isSuccess = addDefaultConfigAndTermsConditionEntry(tblClient.getClientId(), userId, defaultConfigClientId);
                	String[] docName = {messageSource.getMessage("reg_doc_pan", null, LocaleContextHolder.getLocale()), messageSource.getMessage("reg_doc_other_1", null, LocaleContextHolder.getLocale()), messageSource.getMessage("reg_doc_other_2", null, LocaleContextHolder.getLocale())};   
                	String[] mandatory = messageSource.getMessage("reg_doc_mandatory", null, LocaleContextHolder.getLocale()).trim().split(",");  
                	List<TblClientRegDoc> tblClientRegDocs=new ArrayList<TblClientRegDoc>();
                	TblClientRegDoc tblClientRegDoc = null;
                	for(int i=0;i<docName.length;i++){
    	        		tblClientRegDoc=new TblClientRegDoc();
    	        		tblClientRegDoc.setCreatedBy(userId);
    	        		tblClientRegDoc.setIsActive(1);
    	        		tblClientRegDoc.setTblClient(new TblClient(tblClient.getClientId()));
    	        		tblClientRegDoc.setDocName(docName[i]);
    	        		tblClientRegDoc.setIsMandatory(mandatory[i]!=null && !"".equals(mandatory[i])?Integer.parseInt(mandatory[i]):0);
    	        		tblClientRegDocs.add(tblClientRegDoc);
    	        	}
                	boolean status = clientService.addNewRequiredDocs(tblClientRegDocs);
                	if(isSuccess && status){
                		retVal = successRedirectLink;
                	}else{
                		retVal = redirectLink;
                	}
                }
                retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), isEdit?editClientLinkId:createClientLinkId,isEdit? auditClientEdited : auditClientCreated, 0, tblClient.getClientId());
        }
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? successMessage : CommonKeywords.ERROR_MSG_KEY.toString());
        return retVal;
    }

    /**
     * to view configure sealed bid jsp page (for create and edit both)
     *
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/configureSealedBid/{clientId}/{enc}", method = RequestMethod.GET)
    public String configureSealedBid(@PathVariable(CLIENT_ID) int clientId,ModelMap modelMap,HttpServletRequest request) {
        try {
        	int moduleId=4;
            List<SelectItem> rAccessType = new ArrayList<SelectItem>();
            rAccessType.add(new SelectItem("Open", "Open"));
            rAccessType.add(new SelectItem(LIMITED, "Limited"));
            modelMap.addAttribute("rAccessType", rAccessType);

            List<SelectItem> rVisibility = new ArrayList<SelectItem>();
            rVisibility.add(new SelectItem("Show", 1));
            rVisibility.add(new SelectItem("Hide", 0));
            modelMap.addAttribute("rVisibility", rVisibility);
            
            modelMap.addAttribute("rYesNo", commonService.getYesNo());

            List<SelectItem> rLimitedUnlimited = new ArrayList<SelectItem>();
            rLimitedUnlimited.add(new SelectItem(LIMITED, "Limited"));
            rLimitedUnlimited.add(new SelectItem("Unlimited", "Unlimited"));
            modelMap.addAttribute("rLimitedUnlimited", rLimitedUnlimited);
            
            List<SelectItem> rBiddingType = new ArrayList<SelectItem>();
            rBiddingType.add(new SelectItem("NCB/Domestic", "NCB/Domestic"));
            rBiddingType.add(new SelectItem("ICB/Global", "ICB/Global"));
            modelMap.addAttribute("rBiddingType", rBiddingType);

            List<SelectItem> rContractType = new ArrayList<SelectItem>();
            rContractType.add(new SelectItem("Goods", "Goods"));
            rContractType.add(new SelectItem("Service", "Service"));
            rContractType.add(new SelectItem("Works", "Works"));
            modelMap.addAttribute("rContractType", rContractType);

            List<SelectItem> rAuctionVariant = new ArrayList<SelectItem>();
            rAuctionVariant.add(new SelectItem("Forward", "Forward"));
            rAuctionVariant.add(new SelectItem("Reverse", "Reverse"));
            modelMap.addAttribute("rAuctionVariant", rAuctionVariant);

            List<SelectItem> rAuctionType = new ArrayList<SelectItem>();
            rAuctionType.add(new SelectItem("Standard", "Standard"));
            rAuctionType.add(new SelectItem("Rank", "Rank"));
            modelMap.addAttribute("rAuctionType", rAuctionType);

            List<SelectItem> selDelValUpto = new ArrayList<SelectItem>();
            selDelValUpto.add(new SelectItem("2", 2));
            selDelValUpto.add(new SelectItem("1", 1));
            selDelValUpto.add(new SelectItem("3", 3));
            selDelValUpto.add(new SelectItem("4", 4));
            selDelValUpto.add(new SelectItem("5", 5));
            modelMap.addAttribute("selDelValUpto", selDelValUpto);

            List<SelectItem> rDefaultStatus = new ArrayList<SelectItem>();
            rDefaultStatus.add(new SelectItem("Live", "Live"));
            rDefaultStatus.add(new SelectItem("Future", "Future"));
            rDefaultStatus.add(new SelectItem("Cancelled", "Cancelled"));
            rDefaultStatus.add(new SelectItem("Archive", "Archive"));
            modelMap.addAttribute("rDefaultStatus", rDefaultStatus);

            modelMap.addAttribute("configType", "sealedbid");
            modelMap.addAttribute("moduleId", moduleId);
            modelMap.addAttribute("eventList", clientService.getNotificationEvents(clientId,moduleId));
            modelMap.addAttribute("paramList", clientService.getCustomParameter(moduleId, clientId));
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sealBidConfLinkId, auditConfigSealedBidParam, 0,6);
        }
        return "/common/admin/ConfigureSealedBid";
    }

    /**
     *  to view configure auction JSP Page (for create and edit both)
     *
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/configureAuction/{clientId}/{enc}", method = RequestMethod.GET)
    public String configureAuction(@PathVariable(CLIENT_ID) int clientId,ModelMap modelMap,HttpServletRequest request) {
        try {
        	int moduleId=5;
            List<SelectItem> rAccessType = new ArrayList<SelectItem>();
            rAccessType.add(new SelectItem("Open", 1));
            rAccessType.add(new SelectItem(LIMITED, 2));
            modelMap.addAttribute("rAccessType", rAccessType);

            List<SelectItem> rVisibility = new ArrayList<SelectItem>();
            rVisibility.add(new SelectItem("Show", 1));
            rVisibility.add(new SelectItem("Hide", 0));
            modelMap.addAttribute("rVisibility", rVisibility);

            /*List<SelectItem> rYesNo = new ArrayList<SelectItem>();
            rYesNo.add(new SelectItem(YES, "Yes"));
            rYesNo.add(new SelectItem("No", "No"));*/
            modelMap.addAttribute("rYesNo", commonService.getYesNo());

            List<SelectItem> rLimitedUnlimited = new ArrayList<SelectItem>();
            rLimitedUnlimited.add(new SelectItem(LIMITED, "Limited"));
            rLimitedUnlimited.add(new SelectItem("Unlimited", "Unlimited"));
            modelMap.addAttribute("rLimitedUnlimited", rLimitedUnlimited);
            
            List<SelectItem> rBiddingType = new ArrayList<SelectItem>();
            rBiddingType.add(new SelectItem("NCB", 1));
            rBiddingType.add(new SelectItem("ICB", 2));
            modelMap.addAttribute("rBiddingType", rBiddingType);

            /*List<SelectItem> rContractType = new ArrayList<SelectItem>();
            rContractType.add(new SelectItem("Goods", "Goods"));
            rContractType.add(new SelectItem("Service", "Service"));
            rContractType.add(new SelectItem("Works", "Works"));*/
            modelMap.addAttribute("rContractType", abcUtility.convert(clientService.getProcurementNature()));

            /*List<SelectItem> rAuctionVariant = new ArrayList<SelectItem>();
            rAuctionVariant.add(new SelectItem("Forward", "Forward"));
            rAuctionVariant.add(new SelectItem("Reverse", "Reverse"));*/
            modelMap.addAttribute("rAuctionVariant", abcUtility.convert(clientService.getEventTypeIdForAuctionDefaultConfg(clientId)));

            List<SelectItem> rAuctionType = new ArrayList<SelectItem>();
            rAuctionType.add(new SelectItem("Standard", 1));
            rAuctionType.add(new SelectItem("Rank", 2));
            modelMap.addAttribute("rAuctionType", rAuctionType);

            List<SelectItem> rDecIncrType = new ArrayList<SelectItem>();
            rDecIncrType.add(new SelectItem("Figure", 1));
            rDecIncrType.add(new SelectItem("Percentage", 2));
            modelMap.addAttribute("rDecIncrType", rDecIncrType);

            List<SelectItem> selDelValUpto = new ArrayList<SelectItem>();
            selDelValUpto.add(new SelectItem("2", 2));
            selDelValUpto.add(new SelectItem("1", 1));
            selDelValUpto.add(new SelectItem("3", 3));
            selDelValUpto.add(new SelectItem("4", 4));
            selDelValUpto.add(new SelectItem("5", 5));
            modelMap.addAttribute("selDelValUpto", selDelValUpto);

            List<SelectItem> rDisplayWinningBidAmt = new ArrayList<SelectItem>();
            rDisplayWinningBidAmt.add(new SelectItem("After Bidder Bid", "Bidder Bid"));
            rDisplayWinningBidAmt.add(new SelectItem("Any time Bidder Bid", "Any time Bidder Bid"));
            modelMap.addAttribute("rDisplayWinningBidAmt", rDisplayWinningBidAmt);

            List<SelectItem> rAutoExtensionMode = new ArrayList<SelectItem>();
            rAutoExtensionMode.add(new SelectItem("Fix No Extension", 1));
            rAutoExtensionMode.add(new SelectItem("Unlimited Extension", 2));
            modelMap.addAttribute("rAutoExtensionMode", rAutoExtensionMode);

            List<SelectItem> rFirstBidAccptCondi = new ArrayList<SelectItem>();
            rFirstBidAccptCondi.add(new SelectItem("Accept Start Price", 1));
            rFirstBidAccptCondi.add(new SelectItem("Accept Start Price (-Decrement Value  / +Increment Value)",2));
            modelMap.addAttribute("rFirstBidAccptCondi", rFirstBidAccptCondi);

            List<SelectItem> rDefaultStatus = new ArrayList<SelectItem>();
            rDefaultStatus.add(new SelectItem("Live", "Live"));
            rDefaultStatus.add(new SelectItem("Future", "Future"));
            rDefaultStatus.add(new SelectItem("Cancelled", "Cancelled"));
            rDefaultStatus.add(new SelectItem("Archive", "Archive"));
            modelMap.addAttribute("rDefaultStatus", rDefaultStatus);

            List<SelectItem> rAuctionResult = new ArrayList<SelectItem>();
            rAuctionResult.add(new SelectItem("Grand Total", 1));
            rAuctionResult.add(new SelectItem("Item wise", 2));
            rAuctionResult.add(new SelectItem("Grand Total and Item wise", 3));
            modelMap.addAttribute("rAuctionResult", rAuctionResult);
            
            List<SelectItem> incDecRuleList = new ArrayList<SelectItem>();
            incDecRuleList.add(new SelectItem("All Items", 1));
            incDecRuleList.add(new SelectItem("Any Items", 2));
            modelMap.addAttribute("incDecRuleList", incDecRuleList);

            modelMap.addAttribute("configType", "auction");
            modelMap.addAttribute("moduleId", moduleId);
            modelMap.addAttribute("eventList", clientService.getNotificationEvents(clientId,moduleId));
            modelMap.addAttribute("paramList", clientService.getCustomParameter(moduleId, clientId));
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), auctionConfgLinkId, auditConfigAuctionParam, 0,4);
        }
        return "/common/admin/configureAuction";
    }
    
    /**
     * to get default configuration page 
     * @param clientId
     * @param eventTypeId
     * @param modelMap
     * @param request
     * @return String
     */
    @RequestMapping(value = "/admin/defaultconfiguration/{clientId}/{eventTypeId}/{enc}", method = RequestMethod.GET)
    public String defaultConfiguration(@PathVariable("clientId") int clientId,@PathVariable("eventTypeId") int eventTypeId, ModelMap modelMap, HttpServletRequest request) {
        try {
        	List<Object[]> data=clientService.getClientConfigureEvents(clientId);
        	modelMap.addAttribute("eventsList",data);
        	modelMap.addAttribute("clientName",clientService.getClientName(clientId));
        	modelMap.addAttribute("domainName",clientService.getClientNameById(clientId));
        	if(eventTypeId == 0){
        		modelMap.addAttribute("eventTypeId", (Integer)data.get(0)[0]/* == 1 || (Integer)data.get(0)[0] == 2 ? 2 : data.get(0)[0]*/);
        		modelMap.addAttribute("moduleId",data.get(0)[2]);
        	}else{
        		modelMap.addAttribute("eventTypeId", eventTypeId /*== 1 || eventTypeId == 2 ? 2 : eventTypeId*/);
        		modelMap.addAttribute("moduleId",commonService.getModuleIdbyEventTypeId(eventTypeId));
        	}
        	modelMap.addAttribute("clientList",clientService.getActiveClient(clientId));
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), defaultConfLinkId, "Accessed default configuration page", clientId, 0);
        }
        return "common/admin//DefaultConfiguration";
    }
    
    /**
     * to get event wise default configuration page
     * @param clientId
     * @param txtEventTypeId
     * @param txtModuleId
     * @param request
     * @param modelMap
     * @return String
     */
    @RequestMapping(value = "/admin/configurationcontent", method = RequestMethod.POST)
    public String configurationContent(@RequestParam("hdClientId") int clientId, @RequestParam("txtEventTypeId") int txtEventTypeId,@RequestParam("txtModuleId") int txtModuleId,HttpServletRequest request, ModelMap modelMap) {
    	String retVal="";
    	//int moduleId=0;
    	String eventName="";
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            	List<SelectItem> rVisibility = new ArrayList<SelectItem>();
                rVisibility.add(new SelectItem("Show", 1));
                rVisibility.add(new SelectItem("Hide", 0));
                modelMap.addAttribute("rVisibility", rVisibility);
                boolean isView = false;
                List<Object> eventNameList=commonService.getEventNameFromEventId(txtEventTypeId);
                eventName=eventNameList !=null && !eventNameList.isEmpty() ? eventNameList.get(0).toString() : "";
                switch(txtEventTypeId){
                
                	//case 1 :  // fall through
                        
//                    case TAB_AUCTION_CONFIG:
//                    	//moduleId=5;
//                        List<SelectItem> rAccessType = new ArrayList<SelectItem>();
//                        rAccessType.add(new SelectItem("Open", 1));
//                        rAccessType.add(new SelectItem(LIMITED, 2));
//                        modelMap.addAttribute("rAccessType", rAccessType);
//
//                        /*List<SelectItem> rYesNo = new ArrayList<SelectItem>();
//                        rYesNo.add(new SelectItem(YES, "Yes"));
//                        rYesNo.add(new SelectItem("No", "No"));*/
//                        modelMap.addAttribute("rYesNo", commonService.getYesNo());
//
//                        List<SelectItem> rLimitedUnlimited = new ArrayList<SelectItem>();
//                        rLimitedUnlimited.add(new SelectItem(LIMITED, "Limited"));
//                        rLimitedUnlimited.add(new SelectItem("Unlimited", "Unlimited"));
//                        modelMap.addAttribute("rLimitedUnlimited", rLimitedUnlimited);
//                        
//                        List<SelectItem> rBiddingType = new ArrayList<SelectItem>();
//                        rBiddingType.add(new SelectItem("NCB", 1));
//                        rBiddingType.add(new SelectItem("ICB", 2));
//                        modelMap.addAttribute("rBiddingType", rBiddingType);
//
//                        /*List<SelectItem> rContractType = new ArrayList<SelectItem>();
//                        rContractType.add(new SelectItem("Goods", "Goods"));
//                        rContractType.add(new SelectItem("Service", "Service"));
//                        rContractType.add(new SelectItem("Works", "Works"));*/
//                        modelMap.addAttribute("rContractType", abcUtility.convert(clientService.getProcurementNature()));
//
//                        /*List<SelectItem> rAuctionVariant = new ArrayList<SelectItem>();
//                        rAuctionVariant.add(new SelectItem("Forward", "Forward"));
//                        rAuctionVariant.add(new SelectItem("Reverse", "Reverse"));*/
//                        modelMap.addAttribute("rAuctionVariant", abcUtility.convert(clientService.getEventTypeIdForAuctionDefaultConfg(clientId)));
//
//                        List<SelectItem> rAuctionType = new ArrayList<SelectItem>();
//                        rAuctionType.add(new SelectItem("Standard", 1));
//                        rAuctionType.add(new SelectItem("Rank", 2));
//                        modelMap.addAttribute("rAuctionType", rAuctionType);
//
//                        List<SelectItem> rDecIncrType = new ArrayList<SelectItem>();
//                        rDecIncrType.add(new SelectItem("Figure", 1));
//                        rDecIncrType.add(new SelectItem("Percentage", 2));
//                        modelMap.addAttribute("rDecIncrType", rDecIncrType);
//
//                        List<SelectItem> selDelValUpto = new ArrayList<SelectItem>();
//                        selDelValUpto.add(new SelectItem("2", 2));
//                        selDelValUpto.add(new SelectItem("1", 1));
//                        selDelValUpto.add(new SelectItem("3", 3));
//                        selDelValUpto.add(new SelectItem("4", 4));
//                        selDelValUpto.add(new SelectItem("5", 5));
//                        modelMap.addAttribute("selDelValUpto", selDelValUpto);
//
//                        List<SelectItem> rDisplayWinningBidAmt = new ArrayList<SelectItem>();
//                        rDisplayWinningBidAmt.add(new SelectItem("After Bidder Bid", "Bidder Bid"));
//                        rDisplayWinningBidAmt.add(new SelectItem("Any time Bidder Bid", "Any time Bidder Bid"));
//                        modelMap.addAttribute("rDisplayWinningBidAmt", rDisplayWinningBidAmt);
//
//                        List<SelectItem> rAutoExtensionMode = new ArrayList<SelectItem>();
//                        rAutoExtensionMode.add(new SelectItem("Fix No Extension", 1));
//                        rAutoExtensionMode.add(new SelectItem("Unlimited Extension", 2));
//                        modelMap.addAttribute("rAutoExtensionMode", rAutoExtensionMode);
//
//                        List<SelectItem> rFirstBidAccptCondi = new ArrayList<SelectItem>();
//                        rFirstBidAccptCondi.add(new SelectItem("Accept Start Price", 1));
//                        rFirstBidAccptCondi.add(new SelectItem("Accept Start Price (-Decrement Value  / +Increment Value)",2));
//                        modelMap.addAttribute("rFirstBidAccptCondi", rFirstBidAccptCondi);
//
//                        List<SelectItem> rDefaultStatus = new ArrayList<SelectItem>();
//                        rDefaultStatus.add(new SelectItem("Live", "Live"));
//                        rDefaultStatus.add(new SelectItem("Future", "Future"));
//                        rDefaultStatus.add(new SelectItem("Cancelled", "Cancelled"));
//                        rDefaultStatus.add(new SelectItem("Archive", "Archive"));
//                        modelMap.addAttribute("rDefaultStatus", rDefaultStatus);
//
//                        List<SelectItem> rAuctionResult = new ArrayList<SelectItem>();
//                        rAuctionResult.add(new SelectItem("Grand Total", 1));
//                        rAuctionResult.add(new SelectItem("Item wise", 2));
//                        rAuctionResult.add(new SelectItem("Grand Total and Item wise", 3));
//                        modelMap.addAttribute("rAuctionResult", rAuctionResult);
//                        
//                        List<SelectItem> incDecRuleList = new ArrayList<SelectItem>();
//                        incDecRuleList.add(new SelectItem("All Items", 1));
//                        incDecRuleList.add(new SelectItem("Any Items", 2));
//                        modelMap.addAttribute("incDecRuleList", incDecRuleList);
//                        
//                        List<SelectItem> configureTimeForItemList = new ArrayList<SelectItem>();
//                        configureTimeForItemList.add(new SelectItem("Parallel", 1));
//                        configureTimeForItemList.add(new SelectItem("Serial", 2));
//                        modelMap.addAttribute("configureTimeForItemList", configureTimeForItemList);
//
//                        modelMap.addAttribute("configType", "auction");
//                        modelMap.addAttribute("moduleId", txtModuleId);
//                        modelMap.addAttribute("eventList", clientService.getNotificationEvents(clientId,txtModuleId));
//                        modelMap.addAttribute("paramList", clientService.getCustomParameter(txtModuleId, clientId));
//
//                    	retVal="/common/admin/configureAuction";
//                        break;
                                        
                    /*case TAB_PQ_CONFIG:
                    	moduleId=3;
                    	retVal="/common/admin/ConfigureDefaultParameters";
                    	generateComponentMap(modelMap,TAB_PQ_CONFIG,clientId,isView);
                    	modelMap.addAttribute("eventList", clientService.getNotificationEvents(clientId,moduleId));
                        //modelMap.addAttribute("paramList", clientService.getCustomParameter(moduleId, clientId));
                    	break;
                    	
                    case TAB_TENDER_CONFIG:
                    	moduleId=3;
                    	retVal="/common/admin/ConfigureDefaultParameters";
                    	generateComponentMap(modelMap,TAB_TENDER_CONFIG,clientId,isView);
                    	modelMap.addAttribute("eventList", clientService.getNotificationEvents(clientId,moduleId));
                        //modelMap.addAttribute("paramList", clientService.getCustomParameter(moduleId, clientId));
                    	break;
                    	
                    case TAB_RFQSEALBID_CONFIG:
                    	moduleId=3;
                    	retVal="/common/admin/ConfigureDefaultParameters";
                    	generateComponentMap(modelMap,TAB_RFQSEALBID_CONFIG,clientId,isView);
                    	modelMap.addAttribute("eventList", clientService.getNotificationEvents(clientId,moduleId));
                        //modelMap.addAttribute("paramList", clientService.getCustomParameter(moduleId, clientId));
                    	break;
                    	
                    case TAB_RFP_CONFIG:
                    	moduleId=3;
                    	retVal="/common/admin/ConfigureDefaultParameters";
                    	generateComponentMap(modelMap,TAB_RFP_CONFIG,clientId,isView);
                    	modelMap.addAttribute("eventList", clientService.getNotificationEvents(clientId,moduleId));
                        //modelMap.addAttribute("paramList", clientService.getCustomParameter(moduleId, clientId));
                    	break;
                    	
                    case TAB_RFI_CONFIG:
                    	moduleId=3;
                    	retVal="/common/admin/ConfigureDefaultParameters";
                    	generateComponentMap(modelMap,TAB_RFI_CONFIG,clientId,isView);
                    	modelMap.addAttribute("eventList", clientService.getNotificationEvents(clientId,moduleId));
                        //modelMap.addAttribute("paramList", clientService.getCustomParameter(moduleId, clientId));
                    	break;
                    
                    case TAB_REOI_CONFIG:
                    	moduleId=3;
                    	retVal="/common/admin/ConfigureDefaultParameters";
                    	generateComponentMap(modelMap,TAB_REOI_CONFIG,clientId,isView);
                    	modelMap.addAttribute("eventList", clientService.getNotificationEvents(clientId,moduleId));
                        //modelMap.addAttribute("paramList", clientService.getCustomParameter(moduleId, clientId));
                    	break;*/
                   default :
            	   			retVal="/common/admin/ConfigureDefaultParameters";
			               	generateComponentMap(modelMap,txtEventTypeId,clientId,isView,request);
			               	modelMap.addAttribute("eventList", clientService.getNotificationEvents(clientId,txtModuleId));
			                //modelMap.addAttribute("paramList", clientService.getCustomParameter(moduleId, clientId));
                    	
                }
                int isGstRequired = Integer.parseInt(commonService.getField("TblClient", "isGSTRequired", "clientId", clientId));
                modelMap.addAttribute("isGSTRequired", isGstRequired);
                modelMap.addAttribute("eventTypeId", txtEventTypeId);
                modelMap.addAttribute("clientId", clientId);
                modelMap.addAttribute("isOnline", clientService.getClientById(clientId).getIsOnlinePayment());
                modelMap.addAttribute("moduleId", txtModuleId);
            }else{
                modelMap.addAttribute("sessionexpired",true);
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), defaultConfLinkId, "Accessed "+eventName+" configuration page", clientId, 0);
        }
        return retVal;
    }
    
    /**
     * view sub domain
     * @Author Shreyansh.shah
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/viewclient/{clientId}/{enc}", method = RequestMethod.GET)
    public String viewClient(@PathVariable(CLIENT_ID) int clientId, ModelMap modelMap,HttpServletRequest request) {
        try {
            List<Object[]> clientDeptObj = clientService.getClientDetailsByClientId(clientId);
            modelMap.addAttribute("clientDetails", clientDeptObj);
            List<Object[]> lstModule = clientService.getClientModule(clientId);
            List<Object[]> lstWorkFlowType = clientService.getClientWorkflow(clientId);                       
            List<Object[]> lstModeOfPayment = clientService.getClientPaymentType(clientId);
            List<Object[]> lstLanguage = clientService.getClientLanguage(clientId);
            String commaValues = "";
            String defaultLang = "";
            for(Object[] obj : lstLanguage) {
                if(obj[2] != null) {
                commaValues = commaValues + obj[1] + ",";
                }
                if(obj[3] != null && obj[3].equals(1)) {
                    defaultLang = (String) obj[1];
                }
            }
            commaValues = "".equals(commaValues) ? commaValues : commaValues.substring(0, commaValues.length() - 1);
            List<Object[]> lstCurrency = clientService.getClientCurrency(clientId);
            String currencyList = "";
            String defaultCurrency = "";
            for(Object[] obj : lstCurrency) {
                if(obj[2] != null) {
                    currencyList = currencyList + obj[1] + ",";
                }
                if(obj[3] != null && obj[3].equals(1)) {
                    defaultCurrency = (String) obj[1];
                }
            }
            currencyList = "".equals(currencyList) ? currencyList : currencyList.substring(0, currencyList.length() - 1);
            modelMap.addAttribute("languageList",commaValues);
            modelMap.addAttribute("defaultLang",defaultLang);
            modelMap.addAttribute("currencyList",currencyList);
            modelMap.addAttribute("defaultCurrency",defaultCurrency);
            modelMap.addAttribute("moduleList",abcUtility.converObjectArrayToCommas(lstModule, 1,2));
            modelMap.addAttribute("workFlowList",abcUtility.converObjectArrayToCommas(lstWorkFlowType, 1,2));
            modelMap.addAttribute("modeOfPaymentList",abcUtility.converObjectArrayToCommas(lstModeOfPayment, 1,2));
            modelMap.addAttribute("eventTypeLst", clientService.getClientConfigureEvents(clientId));
            modelMap.addAttribute("defaultCurrency",defaultCurrency);
            modelMap.addAttribute(OPERTYPE_CREATE, "view");
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewClientLinkId, auditViewClient, 0,clientId);
        }
        return "/common/admin/ViewClient";
    }

    /**
     * edit sub domain
     * @Author Shreyansh.shah
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/editclient/{clientId}/{enc}", method = RequestMethod.GET)
    public String editClient(@PathVariable(CLIENT_ID) int clientId, ModelMap modelMap, HttpServletRequest request) {
        try {
            TblClient tblClient = clientService.getClientById(clientId);
            TblDepartment tblDepartment = clientService.getDepartmentById(tblClient.getDeptId());
            setClientData(modelMap);
            modelMap.addAttribute("tblDepartmentList",tblDepartment);
            modelMap.addAttribute("tblClientList",tblClient);
            modelMap.addAttribute(CLIENT_ID,clientId);
            modelMap.addAttribute("selIsTwoStepBidderApprEdit", tblClient.getIsTwoStepBidderApproval());

            List<Object[]> lstModule = clientService.getClientModule(clientId);
            List<SelectItem> chkModule = abcUtility.convertSelected(lstModule);
            modelMap.addAttribute("chkModule", chkModule);

            List<Object[]> lstWorkFlowType = clientService.getClientWorkflow(clientId);
            List<SelectItem> chkWorkflowType = abcUtility.convertSelected(lstWorkFlowType);
            modelMap.addAttribute("chkWorkflowType", chkWorkflowType);

            List<Object[]> lstCurrency = clientService.getClientCurrency(clientId);
            List<SelectItem> selCurrency = abcUtility.convertSelected(lstCurrency);
            modelMap.addAttribute("selCurrency", selCurrency);


            List<Object[]> lstLanguage = clientService.getClientLanguage(clientId);
            List<SelectItem> selLanguage = abcUtility.convertSelected(lstLanguage);
            modelMap.addAttribute("selLanguage", selLanguage);

            String langId=WebUtils.getCookie(request, "locale").getValue();
            List<TblCountry> lstCountry = commonService.getCountryList(langId);
            List<SelectItem> selCountry = modelToSelectItem.convertListIntoSelectItemList(lstCountry,"countryId", "lang"+langId);
            modelMap.addAttribute(COUNTRY, selCountry);

            List<TblState> lstState = commonService.getStateBycountryId(tblDepartment.getTblCountry().getCountryId());
            List<SelectItem> selState = modelToSelectItem.convertListIntoSelectItemList(lstState, "stateId", "lang"+langId);
            modelMap.addAttribute(STATE, selState);
            String [] tempListOfCertificateClass = tempCertificateClass.split("\\|");
            String []lstOfCertificateClass = tblClient.getCertificateClass().split("\\|");
            
            List <SelectItem> selectedCertificateClass = new ArrayList<SelectItem>();
            int i=0;
            for (String tempkey : tempListOfCertificateClass) 
            {
            	SelectItem item = new SelectItem();
            	item.setLabel(tempkey);
            	item.setValue(tempkey.charAt(tempkey.length()-1));
            	
            	if(i<lstOfCertificateClass.length)
            	{
            		String tempValue = lstOfCertificateClass[i];
            	
            		if(tempValue.equalsIgnoreCase(item.getValue().toString()))
            		{
            			item.setSelectedVal(tempkey.charAt(tempkey.length()-1));
            			i++;
            		}
            	}
            	
            	selectedCertificateClass.add(item);
			}
            modelMap.addAttribute("selectedCertificateClass",selectedCertificateClass);
            
            modelMap.addAttribute("selPaymentRequires", clientService.getPaymentRequires());
            modelMap.addAttribute("registrationCharges", tblClient.getRegistrationCharges());
            modelMap.addAttribute("regChargeMode", tblClient.getRegistrationChargeMode());
            List<TblPaymentType> paymentType =  commonService.getPaymentTypeList();
            modelMap.addAttribute("paymentType",paymentType);
            List<Object[]> payList = clientService.getClientIsOnlinePaymentType( clientId, 3);
   		 	List<SelectItem> PayTypeItems = (clientId==0)?abcUtility.convert(payList):abcUtility.convertSelected(payList);
   		 	modelMap.addAttribute("clientPayTypeItems",PayTypeItems);
   		 	List<Object[]> clientisPgConfig = tpslService.getClientWisePGConf(clientId);
   		 	modelMap.addAttribute("isPgConfig",(clientisPgConfig==null || clientisPgConfig.isEmpty()) ?0:1);
   		 	TblNeftRtgsConf blNeftRtgsConf = neftService.getTblNeftRtgsConfByClientId(clientId);
   		 	modelMap.addAttribute("isNeftRtgsConfig", blNeftRtgsConf!=null?blNeftRtgsConf.getCstatus():0);
            List<SelectItem> selPaymentConfigBy = new ArrayList<SelectItem>();
            selPaymentConfigBy.add(new SelectItem("Client", 1));
            selPaymentConfigBy.add(new SelectItem("Department", 2));
            modelMap.addAttribute("selPaymentConfigBy", selPaymentConfigBy);
            modelMap.addAttribute("cSelPaymentConfigBy", tblClient.getPaymentConfigBy());
            
            List<SelectItem> isCapchaConfigured = new ArrayList<SelectItem>();
            isCapchaConfigured.add(new SelectItem("Captcha code", 1));
            isCapchaConfigured.add(new SelectItem("Manual unlock", 0));
            modelMap.addAttribute("CapchaConfigured", isCapchaConfigured);
            modelMap.addAttribute("iscCapchaConfigured", tblClient.getIsCaptchaConfigured());
            
            List<Object[]> lstBank = clientService.getActiveBank(clientId);
            List<SelectItem> selBank = abcUtility.convertSelected(lstBank);
            modelMap.addAttribute("selBank", selBank);     
            int neft_approved_count=neftService.getApprovedNeftRtgsConfCountByClientId(clientId);
            modelMap.addAttribute("neft_approved_count", neft_approved_count); 
            
            List<SelectItem> selIsloginLinkConfigured = new ArrayList<SelectItem>();
            int isLoginLinkConfigured = tblClient.getIsloginLinkConfigured();
            if(isLoginLinkConfigured == 1)
            {
                SelectItem itemYes = new SelectItem(YES, 1);
                itemYes.setSelectedVal(1);
                selIsloginLinkConfigured.add(itemYes);
                selIsloginLinkConfigured.add(new SelectItem("No", 0));
            }
            else
            {
                SelectItem itemNo = new SelectItem("No", 0);
                itemNo.setSelectedVal(0);
                selIsloginLinkConfigured.add(new SelectItem(YES, 1));
                selIsloginLinkConfigured.add(itemNo);
            }
            modelMap.addAttribute("selIsloginLinkConfigured", selIsloginLinkConfigured);

            
            List<SelectItem> selIsCalendarConfigured = new ArrayList<SelectItem>();
            int isCalendarConfigured = tblClient.getIsCalendarConfigured();
            if(isCalendarConfigured == 1)
            {
                SelectItem itemYes = new SelectItem(YES, 1);
                itemYes.setSelectedVal(1);
                selIsCalendarConfigured.add(itemYes);
                selIsCalendarConfigured.add(new SelectItem("No", 0));
            }
            else
            {
                SelectItem itemNo = new SelectItem("No", 0);
                itemNo.setSelectedVal(0);
                selIsCalendarConfigured.add(new SelectItem(YES, 1));
                selIsCalendarConfigured.add(itemNo);
            }
            modelMap.addAttribute("selIsCalendarConfigured", selIsCalendarConfigured);
           
            List<SelectItem> searchPanel= new ArrayList<SelectItem>();
            if(tblClient.getSearchPanelType()==1){
            	searchPanel.add(new SelectItem(searchHorizontal,1));
            	searchPanel.add(new SelectItem(searchVertical,2));
                searchPanel.add(new SelectItem(searchPanelDefault, 0));

            	
            }else{
            	searchPanel.add(new SelectItem(searchVertical,2));
            	searchPanel.add(new SelectItem(searchHorizontal,1));
                searchPanel.add(new SelectItem(searchPanelDefault, 0));
            	
            }
            modelMap.addAttribute("searchPanel",searchPanel);
            
            List<SelectItem> displayHomePage= new ArrayList<SelectItem>();
           if(tblClient.getIsHomePageRequire()==0){
        	   displayHomePage.add(new SelectItem(homePageNo,0));
        	   displayHomePage.add(new SelectItem(homePageYes,1));
        	   
           }else{
        	   displayHomePage.add(new SelectItem(homePageYes,1));
        	   displayHomePage.add(new SelectItem(homePageNo,0));
        	   
           }
            
              modelMap.addAttribute("displayHomePage",displayHomePage);
            
              List<SelectItem> selectHomePage= new ArrayList<SelectItem>();
        	  selectHomePage.add(new SelectItem(aucProperty,1));
              modelMap.addAttribute("selectHomePage",selectHomePage);
              
              int isEventStatusListing = tblClient.getIsEventStatusListing();
              List<SelectItem> selIsEventStatusListing = new ArrayList<SelectItem>();
              if(isEventStatusListing == 0)
              {
            	  SelectItem eventStatus = new SelectItem("Live", 0);
            	  eventStatus.setSelectedVal(0);
            	  selIsEventStatusListing.add(eventStatus);
                  selIsEventStatusListing.add(new SelectItem("Live and Future", 1));
              }
              else
              {
                  SelectItem eventStatus = new SelectItem("Live and Future", 1);
                  eventStatus.setSelectedVal(1);
                  selIsEventStatusListing.add(eventStatus);
                  selIsEventStatusListing.add(new SelectItem("Live", 0));
              }
              
              modelMap.addAttribute("selIsEventStatusListing", selIsEventStatusListing);
              /*Project Task #40511 : Start*/
              List<SelectItem> rfxSavingFormula = new ArrayList<SelectItem>();
              rfxSavingFormula.add(new SelectItem(messageSource.getMessage("ten_Estimated_Value_L1_Value", null, LocaleContextHolder.getLocale()), 1));
              modelMap.addAttribute("rfxSavingFormula", rfxSavingFormula);
              modelMap.addAttribute("selectedRfxSavingFormula", tblClient.getRfxSavingFormula());
              
              
              List<SelectItem> auctionSavingFormulaWithStartPrice = new ArrayList<SelectItem>();
              auctionSavingFormulaWithStartPrice.add(new SelectItem(messageSource.getMessage("search_panel_default", null, LocaleContextHolder.getLocale()), 0));
              if(tblClient.getAuctionSavingFormulaWithStartPrice() == 1){
            	  auctionSavingFormulaWithStartPrice.add(new SelectItem(messageSource.getMessage("auc_start_price_auction_L1H1", null, LocaleContextHolder.getLocale()), 1));
              }else{
            	  auctionSavingFormulaWithStartPrice.add(new SelectItem(messageSource.getMessage("auc_start_price_auction_L1H1", null, LocaleContextHolder.getLocale()), 1));
              }
              modelMap.addAttribute("auctionSavingFormulaWithStartPrice", auctionSavingFormulaWithStartPrice);
              
              List<SelectItem> auctionSavingFormulaWithoutStartPrice = new ArrayList<SelectItem>();
              auctionSavingFormulaWithoutStartPrice.add(new SelectItem(messageSource.getMessage("search_panel_default", null, LocaleContextHolder.getLocale()), 0));
              if(tblClient.getAuctionSavingFormulaWithoutStartPrice() == 1){
            	  auctionSavingFormulaWithoutStartPrice.add(new SelectItem(messageSource.getMessage("auc_L1H1_offirst_quote_received_auction_L1H1", null, LocaleContextHolder.getLocale()), 1));
            	  auctionSavingFormulaWithoutStartPrice.add(new SelectItem(messageSource.getMessage("auc_first_bidreceived_auction_L1H1", null, LocaleContextHolder.getLocale()), 2));
              }else if(tblClient.getAuctionSavingFormulaWithoutStartPrice() == 2){
            	  auctionSavingFormulaWithoutStartPrice.add(new SelectItem(messageSource.getMessage("auc_first_bidreceived_auction_L1H1", null, LocaleContextHolder.getLocale()), 2));
            	  auctionSavingFormulaWithoutStartPrice.add(new SelectItem(messageSource.getMessage("auc_L1H1_offirst_quote_received_auction_L1H1", null, LocaleContextHolder.getLocale()), 1));
              }else{
            	  auctionSavingFormulaWithoutStartPrice.add(new SelectItem(messageSource.getMessage("auc_L1H1_offirst_quote_received_auction_L1H1", null, LocaleContextHolder.getLocale()), 1));
            	  auctionSavingFormulaWithoutStartPrice.add(new SelectItem(messageSource.getMessage("auc_first_bidreceived_auction_L1H1", null, LocaleContextHolder.getLocale()), 2));
              }
              modelMap.addAttribute("auctionSavingFormulaWithoutStartPrice", auctionSavingFormulaWithoutStartPrice);
              /*Project Task #40511 : End*/
            modelMap.addAttribute(OPERTYPE_CREATE, "edit");
            List<SelectItem> selAllowExternalUsersToViewReports = commonService.getAllowExternalUserToViewReport();
            modelMap.addAttribute("selAllowExternalUsersToViewReports",selAllowExternalUsersToViewReports);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editClientLinkId, auditEditClient, 0,clientId);
        }
        return "/common/admin/CreateClient";
    }

    /**
     * To Display Approve sub domain configuration Page
     * @Author Shreyansh.shah
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/approveclient/{clientId}/{enc}", method = RequestMethod.GET)
    public String approveClient(@PathVariable(CLIENT_ID) int clientId, ModelMap modelMap,HttpServletRequest request) {
        try {
           String publicKey = null;
            if(abcUtility.getSessionIsPkiEnabled(request) ==1){
                String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
                if(certIds!=null && certIds.length!=0){
                        publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
                }
            }
            modelMap.addAttribute("isRegSuppDocReq",clientService.getMandocRequired(clientId));
            modelMap.addAttribute("publicKey", publicKey); /*main jsp page*/
            modelMap.addAttribute(OPERTYPE_CREATE, "approve");/*main jsp page*/
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), approveClientLinkId, auditApproveClient, 0,clientId);
        }
        return "/common/admin/ViewClient";
    }

    /**
     * Theme configuration
     * Theme creation controller - which serves the select theme updation request 
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/themeconfig/{clientId}/{enc}", method = RequestMethod.GET)
    public String selectTheme(HttpServletRequest request,@PathVariable(CLIENT_ID) int clientId,ModelMap modelMap) {
        try {
            List<SelectItem> selTheme = new ArrayList<SelectItem>();
            List<TblTheme> list = commonService.getThemeList();
            if(list!=null && !list.isEmpty()){
                selTheme = modelToSelectItem.convertListIntoSelectItemList(list, "themeId", "lang"+WebUtils.getCookie(request, "locale").getValue());
            }
            List<Object[]> configureThemeList = clientService.getConfiguredThemeData(clientId);
            if(configureThemeList!=null && !configureThemeList.isEmpty()){
//                if(configureThemeList.get(0)[0]!=null){
//                    modelMap.addAttribute("selectedthemeId", configureThemeList.get(0)[0]);    
//                }
                if(configureThemeList.get(0)[1]!=null){
                    modelMap.addAttribute("logoName", configureThemeList.get(0)[1]);                        
                }
                if(configureThemeList.get(0)[2]!=null){
                    modelMap.addAttribute("companyLogoName", configureThemeList.get(0)[2]);                        
                }
            }
            modelMap.addAttribute("clientName", configureThemeList.get(0)[4]);
            modelMap.addAttribute("subDomainName", configureThemeList.get(0)[3]);
            modelMap.addAttribute("getCompanyLogo", clientService.getCompanyLogo());
//            modelMap.addAttribute("selTheme", selTheme);
            modelMap.addAttribute(CLIENT_ID, clientId);
            List<SelectItem> showCompanyLogo = new ArrayList<SelectItem>();
            showCompanyLogo.add(new SelectItem(messageSource.getMessage("label_show_company_logo", null, LocaleContextHolder.getLocale()), 1));
            showCompanyLogo.add(new SelectItem(messageSource.getMessage("label_hide_company_logo", null, LocaleContextHolder.getLocale()), 0));
            modelMap.addAttribute("showCompanyLogo", showCompanyLogo);
            modelMap.addAttribute("companyLogoValue", commonService.getField("TblClient", "isShowCompanyLogo", "clientId", clientId));
            
            List<SelectItem> logoLocationList = new ArrayList<SelectItem>();
            logoLocationList.add(new SelectItem(messageSource.getMessage("label_logo_left",  null, LocaleContextHolder.getLocale()), 1));
            logoLocationList.add(new SelectItem(messageSource.getMessage("label_logo_right", null, LocaleContextHolder.getLocale()), 0));
            modelMap.addAttribute("logoLocationList", logoLocationList);
            modelMap.addAttribute("isLogoLeftValue", commonService.getField("TblClient", "logoLocation", "clientId", clientId));
            
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), selecthemeLinkId, auditThemeConfig, 0, clientId);
        }
        return "/common/admin/ThemeConfig";
    }
    @RequestMapping(value = "/admin/uploadtheme", method = RequestMethod.POST)
    public String uploadTheme(HttpServletRequest request, RedirectAttributes redirectAttributes) {
        boolean flag = false;
        boolean companyLogoFlag=false;
        String returnStr = "redirect:/loginfailed";
        try {
        	int eProcLogo=StringUtils.hasLength(request.getParameter("selCompanyLogo")) ? Integer.parseInt(request.getParameter("selCompanyLogo")) : 1;
            flag = clientService.updateTheme(Integer.parseInt(request.getParameter("hdClientId")), 1/*Integer.parseInt(request.getParameter("selTheme"))*/, request.getParameter("hdlogoname"),eProcLogo);        
            int isShowCompanyLogo=request.getParameter("rdShowCompanyLogo")!=null?Integer.parseInt(request.getParameter("rdShowCompanyLogo")):1;
            int logoLocation=request.getParameter("rdlogoLocation")!=null?Integer.parseInt(request.getParameter("rdlogoLocation")):1;
            companyLogoFlag=clientService.updateCompanyLogo(Integer.parseInt(request.getParameter("hdClientId")), isShowCompanyLogo,logoLocation);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally{
             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), selecthemeLinkId, flag ? auditLogoUpload : auditLogoUploadFailed, 0, Integer.parseInt(request.getParameter("hdClientId")),"");
        }
        if(flag && companyLogoFlag){
            redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_logofile_success");
            if(isFutureRelease){
            	returnStr = "redirect:/common/admin/defaultconfiguration/"+Integer.parseInt(request.getParameter("hdClientId"))+"/0"+encryptDecryptUtils.generateRedirect("common/admin/defaultconfiguration/"+Integer.parseInt(request.getParameter("hdClientId"))+"/0", request);
            }else{
            	returnStr = "redirect:/common/admin/searchlistclient"+encryptDecryptUtils.generateRedirect("common/admin/searchlistclient", request);
            }
        }else{
            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
            returnStr = "redirect:/common/admin/themeconfig/"+Integer.parseInt(request.getParameter("hdClientId")) + encryptDecryptUtils.generateRedirect("common/admin/themeconfig/"+Integer.parseInt(request.getParameter("hdClientId")), request);
            
        }
        return returnStr;
    }
 /**
  * Theme and Logo uploadation controller -  which serves the change theme and Logo updation request 
  * @param request
  * @param redirectAttributes
  * @return 
  */   
 @RequestMapping(value = "/admin/uploadlogoandtheme", method = RequestMethod.POST)
    public String uploadLogoAndTheme(HttpServletRequest request, RedirectAttributes redirectAttributes) {
     boolean fileUploadedSuccess = false;
     boolean companyLogoFlag=false;
     boolean flag = false;
     boolean bool = false;
     boolean changeExist = false;
     int clientId =0;
     int isShowCompanyLogo=0;
     String hdlogoname = "";
     String returnStr = "redirect:/loginfailed";
        try {
        	int eProcLogo=1;
            File file = null;           
            int themeId =0;
            long fileSize = 0;
            String logo = null;
            boolean checkret = false;
            File tmpDir;
            File tmpDir1;
            File tmpDir2;
            File destinationDir;
            String destinationDirPath = null;
            //int eProcLogo=StringUtils.hasLength(request.getParameter("selCompanyLogo")) ? Integer.parseInt(request.getParameter("selCompanyLogo")) : 1;
            tmpDir = new File(ClientController.class.getResource("/").toString().replace("WEB-INF/classes/", "resources/static-images/Logo").replace("file:/", "").replace("target"+request.getContextPath(),"src/main/webapp").replace("%20", " "));
            int logoLocation=0;
            if (!tmpDir.isDirectory()){
                tmpDir.mkdir();
            }            
            tmpDir1 = new File(drive+path);
            if (!tmpDir1.isDirectory()){
                tmpDir1 = new File(drive+Mainpath);
                if (!tmpDir1.isDirectory()) {
                    tmpDir1.mkdir();
                    tmpDir1 = new File(drive+path);
                    if (!tmpDir1.isDirectory()) {
                        tmpDir1.mkdir();
                    }
                }else{
                    tmpDir1 = new File(drive+path);
                    if (!tmpDir1.isDirectory()) {
                        tmpDir1.mkdir();
                    }
                }
            }
            DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
            /*
             *Set the size threshold, above which content will be stored on disk.
             */
            fileItemFactory.setSizeThreshold(4 * 1024 * 1024); //1 MB
        /*
             * Set the temporary directory to store the uploaded files of size above threshold.
             */
            fileItemFactory.setRepository(tmpDir);

            ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
            /*
             * Parse the request
             */
            List items = uploadHandler.parseRequest(request);
            Iterator itr = items.iterator();
            //For Supporting Document
            while (itr.hasNext()) {
                FileItem item = (FileItem) itr.next();
                //For Supporting Document
            /*
                 * Handle Form Fields.
                 */
                //System.out.println("item.getName() ::::"+item.getName());
                if (item.isFormField()) {
                	themeId = 1;
                    if (item.getFieldName().equals("hdClientId")) {
                        clientId = Integer.parseInt(encryptDecryptUtils.decrypt(item.getString()));
                    }/* else if (item.getFieldName().equals("selTheme")) {
                        themeId = Integer.parseInt(item.getString());
                    }*/ else if(item.getFieldName().equals("selCompanyLogo")){
                    	eProcLogo=Integer.parseInt(item.getString());
                    }else if(item.getFieldName().equals("logoname")){
                    	hdlogoname=item.getString();
                    }else if (item.getFieldName().equals("rdShowCompanyLogo")) {
                    	isShowCompanyLogo=Integer.parseInt(encryptDecryptUtils.decrypt(item.getString()));
                    }else if (item.getFieldName().equals("rdlogoLocation")) {
                    	logoLocation=Integer.parseInt(encryptDecryptUtils.decrypt(item.getString()));
                    }
                    
                    destinationDirPath = tmpDir.getPath()+"\\"+clientId;                    
                    //destinationDirPath = drive+path+"\\"+clientId;
                } else {
                    //Handle Uploaded files.
                /*
                     * Write file to the ultimate location.
                     */
                    if (item.getName().lastIndexOf("\\") == -1) {
                        logo = item.getName();
                    } else {
                        logo = item.getName().substring(item.getName().lastIndexOf("\\") + 1, item.getName().length());
                    }
                    logo = logo.replaceAll(" ", "");
                    String realPath = destinationDirPath;
                    destinationDir = new File(realPath);
                    if (!destinationDir.isDirectory()) {
                        destinationDir.mkdir();
                    }
                    fileSize = item.getSize();
                    checkret = checkExnAndSize(logo, item.getSize());
                    if (!checkret) {                        
                        fileUploadedSuccess = false;
                        bool= true;
                        break;
                    } else {
                        file = new File(destinationDir, logo);
                        if (file.isFile()) {
                        	flag = true;
                            if(!hdlogoname.equalsIgnoreCase(logo)){
                                changeExist = true;
                                clientService.updateTheme(clientId, themeId, logo,eProcLogo);
                            }
                            fileUploadedSuccess = true;
                            break;
                        }
                        /*writing file to the actual source code*/                        
                        if(tmpDir.isDirectory()){
                            item.write(file);
                        }                        
                        /*copying file to the D:/ drive of the Hard Disc*/
                        tmpDir1 = new File(tmpDir1.getPath()+"\\"+clientId);                        
                        if (!tmpDir1.isDirectory()) {
                            tmpDir1.mkdir();
                        }                       
                        if(tmpDir1.isDirectory()){
                            FileCopyUtils.copy(file,new File(tmpDir1.getPath()+"/"+file.getName()));    
                        }
                        /*copying file to the Apache instance on the testing/production/Live environment*/
                        tmpDir2 =  new File(logoserverpath+"\\"+request.getContextPath()+"\\"+logoservercontextpath+"\\"+clientId);                        
                        if (!tmpDir2.isDirectory()) {
                            tmpDir2.mkdir();
                        }
                        if(tmpDir2.isDirectory()){
                            FileCopyUtils.copy(file,new File(tmpDir2.getPath()+"\\"+file.getName()));
                            tmpDir2 = null;
                        } 
                        
                        // Code commented because it is not require, it will overide generated image. and make it 0 kb.@Bharat 
                        /*copying file to the Local Tomcat instance on the localhost environment*/
                        /*tmpDir2 = new File(ClientController.class.getResource("/").toString().replace("WEB-INF/classes/", "resources/static-images/Logo").replace("file:/", "").replace("%20", " ")+"\\"+clientId);                        
                        if (!tmpDir2.isDirectory()) {
                            tmpDir2.mkdir();
                        }
                        if(tmpDir2.isDirectory()){
                            FileCopyUtils.copy(file,new File(tmpDir2.getPath()+"/"+file.getName()));
                        }   */                                                                     
                        clientService.updateTheme(clientId, themeId, logo,eProcLogo);
                        fileUploadedSuccess = true;
                    }
                }
            }
            //int isShowCompanyLogo=request.getParameter("rdShowCompanyLogo")!=null?Integer.parseInt(request.getParameter("rdShowCompanyLogo")):1;
            companyLogoFlag=clientService.updateCompanyLogo(clientId, isShowCompanyLogo,logoLocation);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), selecthemeLinkId, fileUploadedSuccess ? auditThemeUpdated : auditThemeUpdateFailed, 0, clientId);
        }
        if (fileUploadedSuccess && companyLogoFlag) {
            if(flag){
            	redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), changeExist?"redirect_logofile_success":"redirect_logofile_exist");
            }else{
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_logofile_success");
            }
            if(isFutureRelease){
            	returnStr = "redirect:/common/admin/defaultconfiguration/"+clientId+"/0"+encryptDecryptUtils.generateRedirect("common/admin/defaultconfiguration/"+clientId+"/0", request);
            }else{
            	returnStr = "redirect:/common/admin/searchlistclient"+encryptDecryptUtils.generateRedirect("common/admin/searchlistclient", request);
            }
        } else {
            if(bool){
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_logofile_error");
            }else{
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
            }
            returnStr = "redirect:/common/admin/themeconfig/"+clientId + encryptDecryptUtils.generateRedirect("common/admin/themeconfig/"+clientId, request);
        }
        return returnStr;
        
    }    
    private boolean checkExnAndSize(String extn, long size) {
        boolean chextn = false;
        float fsize = 0.0f;
        int j = extn.lastIndexOf('.');
        String lst = extn.substring(j + 1);
        String[] str1 = allowedExt.split(",");
        for (int i = 0; i < str1.length; i++) {
            if (str1[i].trim().equalsIgnoreCase(lst)) {
                chextn = true;
            }
        }
        if (chextn) {
            fsize = size / (1024 * 1024);
            if (allowedSize > fsize) {
                chextn = true;
            } else {
                chextn = false;
            }
        }
        return chextn;
    }
    /**
     *
     * @param enc
     * @return to view
     */
    @RequestMapping(value = "/admin/viewSealedBidParams/{operType}/{enc}", method = RequestMethod.GET)
    public String viewSealedBidParams(@PathVariable(OPERTYPE_CREATE) int operType, HttpServletRequest request, ModelMap modelMap) {
        try {
            modelMap.addAttribute(OPERTYPE_CREATE, operType);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }/* finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), selecthemeLinkId, fileUploadedSuccess ? auditThemeUpdated : auditThemeUpdateFailed, 0, clientId);
        }*/
        return "/common/admin/ViewSealedBidParams";
    }

    /**
     *
     * @param enc
     * @return to view
     */
    @RequestMapping(value = "/admin/viewAuctionParams/{operType}/{enc}", method = RequestMethod.GET)
    public String viewAuctionParams(@PathVariable(OPERTYPE_CREATE) int operType, ModelMap modelMap) {
        try {
            modelMap.addAttribute(OPERTYPE_CREATE, operType);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        return "/common/admin/ViewAuctionParams";
    }

    /**
    * to get registration support documents page
    */
    @RequestMapping(value = "/admin/addrequireddocs/{clientId}/{enc}", method = RequestMethod.GET)
    public String addRequiredDocs(@PathVariable(CLIENT_ID) int clientId,ModelMap modelMap,HttpServletRequest request) {
        try {
        	modelMap.addAttribute("clientRegDocs", clientService.getClientRegDocByclientId(clientId));
            modelMap.addAttribute("mandatoryList", commonService.getYesNo());
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), regSuppDocLinkId, auditConfigRegDocs, 0,clientId);
        }
        return "/common/admin/AddRequiredDocs";
    }

    @RequestMapping(value = "/admin/configureregistrationworkflow/{enc}", method = RequestMethod.GET)
    public String configureRegistrationWorkflow(ModelMap modelMap) {
        try {
            List<SelectItem> regiDetailList = new ArrayList<SelectItem>();
            regiDetailList.add(new SelectItem("1", 1));
            regiDetailList.add(new SelectItem("2", 2));
            regiDetailList.add(new SelectItem("3", 3));
            regiDetailList.add(new SelectItem("4", 4));
            modelMap.addAttribute("regiDetailList", regiDetailList);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        return "/common/admin/ConfigureRegistrationWorkflow";
    }

    /**
     * @author nirav.modi
     * @param clientId
     * @param modelMap
     * @param session
     * @return
     */
    @RequestMapping(value = "/admin/configureadditionalparameters/{clientId}/{eventTypeId}/{enc}", method = RequestMethod.GET) 
    public String configureAdditionalParameters(@PathVariable("clientId") int clientId, @PathVariable("eventTypeId")int eventTypeId, ModelMap modelMap,HttpServletRequest request) {
        int linkId = 0;
        try {
        	List<Object[]> data=clientService.getClientConfigureEvents(clientId);
        	modelMap.addAttribute("eventsList",data);
        	linkId = 78;
        	if(eventTypeId==0){
        		modelMap.addAttribute("eventTypeId", (Integer)data.get(0)[0]);
        	}
        	List<Object[]> tabData = new ArrayList<Object[]>();
        	Object[] cols = null;
        	for(int i=0; i<data.size(); i++){
        		cols = new Object[3];
        		cols[0] = data.get(i)[0];
        		cols[1] = data.get(i)[1];
        		cols[2] = getLinkIdByEventType((Integer)data.get(i)[0]);
        		if((Integer)cols[0]==eventTypeId){
            		modelMap.addAttribute("eventTypeId",cols[0]);
        		}
        		tabData.add(cols);
        	}
                modelMap.addAttribute("featuresList",commonService.getFeaturesList(clientId,eventTypeId));
        	modelMap.addAttribute("tabData", tabData);
        	int objectId=clientId;
        	modelMap.addAttribute("objectId", objectId);
                modelMap.addAttribute("domainNameValue", clientService.getClientNameById(clientId));
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId,linkId==78?getAdditionalConfigForSealBid:getAdditionalConfigForAuction , 0,clientId);
        }
        return "/common/admin/ConfigureAdditionalParameters";
    }

    private int getLinkIdByEventType(int eventTypeId){
    	int linkId = 0;
    	switch (eventTypeId) {
			case 1:
				linkId = linkManageClientAucAddConfig;
				break;
			case 2:
				linkId = linkManageClientAucAddConfig;
				break;
			case 3:
				linkId = linkManageClientPqAddConfig;
				break;
			case 4:
				linkId = linkManageClientTenAddConfig;
				break;
			case 5:
				linkId = linkManageClientSbidAddConfig;
				break;
			case 6:
				linkId = linkManageClientRfpAddConfig;
				break;
			case 7:
				linkId = linkManageClientRfiAddConfig;
				break;
			case 8:
				linkId = linkManageClientReoiAddConfig;
				break;
		}
    	return linkId;
    }
    @RequestMapping(value = "/admin/addconfigureadditionalparameters", method = RequestMethod.POST)
    public String addConfigureAdditionalParameters(HttpServletRequest request,RedirectAttributes redirectAttributes) { 
    	int clientId=0;
    	boolean success=false;
    	int linkId =0;
        try {
            clientId = request.getParameter("hdClientId")!=null && !"".equals(request.getParameter("hdClientId"))?Integer.parseInt(request.getParameter("hdClientId")):0;
            List<TblClientFeature> clientFeaturesList = new ArrayList<TblClientFeature>();
            String featureId[] = request.getParameterValues("chkFeaturesId");
            if(featureId != null && featureId.length > 0){
                 for(int i=0;i< featureId.length;i++){
                     TblClientFeature clientFeature = new TblClientFeature();
                     clientFeature.setTblClient(new TblClient(clientId));
                     clientFeature.setTblFeature(new TblFeature(Integer.parseInt(featureId[i])));
                     clientFeature.setCreatedBy(abcUtility.getSessionUserId(request));
                     clientFeature.setIsActive(1);
                     clientFeaturesList.add(clientFeature);
                 }
                 success = clientService.addTblClientFeatures(clientId, clientFeaturesList);
            } else {
                success = clientService.updateFeaturebyClientId(clientId);
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, linkId==78?postAdditionalConfigForSealBid:postAdditionalConfigForAuction, 0,clientId);
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_additional_confi" : CommonKeywords.ERROR_MSG_KEY.toString());
        return "redirect:/common/admin/searchlistclient"+encryptDecryptUtils.generateRedirect("common/admin/searchlistclient", request);
    }

    /**
     * to add registration support documents 
     */
    @RequestMapping(value = "/admin/addnewrequireddocs", method = RequestMethod.POST)
    public String addNewRequiredDocs(RedirectAttributes redirectAttributes, HttpServletRequest request) {
    	boolean success=false;
        String retVal = null;
        int clientId=0;
        boolean valid=true;
        try{
        	HttpSession session=request.getSession();
        	SessionBean sessionBean=session != null && session.getAttribute("sessionObject") != null ? (SessionBean)session.getAttribute("sessionObject") : null;
        	String rowCount = request.getParameter("txtRowCnt");
            String hdClientId = request.getParameter("hdClientId");
            TblClientRegDoc tblClientRegDoc=null;
            TblClient tblClient=null;
        	List<TblClientRegDoc> tblClientRegDocs=new ArrayList<TblClientRegDoc>();
        	int cnt=rowCount!=null && !"".equals(rowCount)?Integer.parseInt(rowCount):0;
        	clientId=hdClientId!=null && !"".equals(hdClientId)?Integer.parseInt(hdClientId):0;
        	String[] docName=request.getParameterValues("txtDocumentName");
        	String[] mandatory=request.getParameterValues("selMandatory");
        	for(int i=0;i<cnt;i++){
        		//docName[i]=request.getParameter("txtDocumentName"+(i+1));
        		//mandatory[i]=request.getParameter("selMandatory"+(i+1))!=null && !"".equals(request.getParameter("selMandatory"+(i+1)))?Integer.parseInt(request.getParameter("selMandatory"+(i+1))):0;
        		if(docName[i]==null || "".equals(docName[i])){
        			valid=false;
        			break;
        		}
        	}
        	if(!valid){
        		retVal="redirect:/"+REQUIRED_DOCSURL+clientId + encryptDecryptUtils.generateRedirect(REQUIRED_DOCSURL+clientId, request);
        	}else{
	        	for(int i=0;i<cnt;i++){
	        		tblClientRegDoc=new TblClientRegDoc();
	        		tblClient=new TblClient();
	        		tblClient.setClientId(clientId);
	        		tblClientRegDoc.setCreatedBy(sessionBean.getUserId());
	        		tblClientRegDoc.setIsActive(1);
	        		tblClientRegDoc.setTblClient(tblClient);
	        		tblClientRegDoc.setDocName(docName[i]);
	        		tblClientRegDoc.setIsMandatory(mandatory[i]!=null && !"".equals(mandatory[i])?Integer.parseInt(mandatory[i]):0);
	        		tblClientRegDocs.add(tblClientRegDoc);
	        	}
	        	success=clientService.addNewRequiredDocs(tblClientRegDocs);
	        	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_addnewrequireddocs" : CommonKeywords.ERROR_MSG_KEY.toString());
	            if(success){
	               // redirectAttributes.addFlashAttribute("succMsg", "Successfully");
	            	retVal="redirect:/"+SEARCHCLIENTLIST_URL + encryptDecryptUtils.generateRedirect(SEARCHCLIENTLIST_URL, request);
	            }else{
	               // redirectAttributes.addFlashAttribute("errorMsg", "Unsuccessfully");
	            	retVal="redirect:/"+REQUIRED_DOCSURL+clientId + encryptDecryptUtils.generateRedirect(REQUIRED_DOCSURL+clientId, request);
	            }
        	}
        }catch(Exception e){
        	return exceptionHandlerService.writeLog(e);
        }finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), regSuppDocLinkId, success ? auditRegDocAdded : auditRegDocFailed, 0,clientId);
        }
        return retVal;
    }
    
    /**
     * to update registration support documents 
     */
    @RequestMapping(value = "/admin/updaterequireddocs", method = RequestMethod.POST)                       
    public String updateRequiredDocs(RedirectAttributes redirectAttributes, HttpServletRequest request){
        boolean success = false;
        String retVal = null;
        int clientId=0;
        boolean valid=true;
        try{
        	HttpSession session=request.getSession();
        	SessionBean sessionBean=session != null && session.getAttribute("sessionObject") != null ? (SessionBean)session.getAttribute("sessionObject") : null;
        	String updateSec="";
        	List<TblClientRegDoc> tblClientRegDocs=new ArrayList<TblClientRegDoc>();
        	String rowCount = request.getParameter("txtRowCnt");
            String hdClientId = request.getParameter("hdClientId");
        	int cnt=rowCount!=null && !"".equals(rowCount)?Integer.parseInt(rowCount):0;
        	clientId=hdClientId!=null && !"".equals(hdClientId)?Integer.parseInt(hdClientId):0;
        	String deletedSec=request.getParameter("txtRowsDeleted");
        	int[] updateDocId=new int[cnt];
        	String[] docName=request.getParameterValues("txtDocumentName");
        	String[] mandatory=request.getParameterValues("selMandatory");
        	String updateDocData[] = request.getParameterValues("txtUpdateRegDocId");
        	for(int i=0;i<cnt;i++){
        		String docId = updateDocData[i];
                    if(StringUtils.hasLength(docId)){
                    	updateSec=updateSec+(docId!=null?docId:"")+",";
                    }
                    updateDocId[i]=updateDocData!=null && !"".equals(docId)?Integer.parseInt(docId):0;
            		if(docName[i]==null || "".equals(docName[i])){
            			valid=false;
            			break;
            		}
        		//docName[i]=request.getParameter("txtDocumentName"+(i+1));
        		//mandatory[i]=request.getParameter("selMandatory"+(i+1))!=null && !"".equals(request.getParameter("selMandatory"+(i+1)))?Integer.parseInt(request.getParameter("selMandatory"+(i+1))):0;
        	}
        	if(!valid){
        		retVal="redirect:/"+REQUIRED_DOCSURL+clientId + encryptDecryptUtils.generateRedirect(REQUIRED_DOCSURL+clientId, request);
        	}else{
	        	for(int i=0;i<cnt;i++){
	        		TblClientRegDoc tblClientRegDoc=new TblClientRegDoc();
	        		if(updateDocId[i]!=0){
	        			tblClientRegDoc.setClientRegDocId(updateDocId[i]);
	        		}
	        		tblClientRegDoc.setCreatedBy(sessionBean.getUserId());
	        		tblClientRegDoc.setIsActive(1);
	        		tblClientRegDoc.setTblClient(new TblClient(clientId));
	        		tblClientRegDoc.setDocName(docName[i]);
	        		tblClientRegDoc.setIsMandatory(mandatory[i]!=null && !"".equals(mandatory[i])?Integer.parseInt(mandatory[i]):0);
	        		tblClientRegDocs.add(tblClientRegDoc);
	        	}
	        	success=clientService.updateRequiredDocs(tblClientRegDocs,updateSec,deletedSec);
	        	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_addnewrequireddocs" : CommonKeywords.ERROR_MSG_KEY.toString());
	            if(success){
	               // redirectAttributes.addFlashAttribute("succMsg", "Successfully");
	            	retVal="redirect:/"+ SEARCHCLIENTLIST_URL + encryptDecryptUtils.generateRedirect(SEARCHCLIENTLIST_URL, request);
	            }else{
	               // redirectAttributes.addFlashAttribute("errorMsg", "Unsuccessfully");
	            	retVal="redirect:/"+REQUIRED_DOCSURL+clientId + encryptDecryptUtils.generateRedirect(REQUIRED_DOCSURL+clientId, request);
	            }
        	}
        }
        catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        }finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), regSuppDocLinkId, success ? auditRegDocUpdated : auditRegDocUpdateFailed, 0,clientId);
        }
        return retVal;
    }
    
    /**
     * to add and update default configuration 
     */
    @RequestMapping(value = "/admin/addsealedbidauctionconfig", method = RequestMethod.POST)
    public String addSealedBidConfig (RedirectAttributes redirectAttributes, HttpServletRequest request){
        boolean success = false;
        List<TblCustomParameter> tblCustomParameters=new ArrayList<TblCustomParameter>();
        List<TblClientAlertConf> tblClientAlertConfList=new ArrayList<TblClientAlertConf>();
        int moduleId=0;
        int clientId=0;
        String retVal = null;
        String configType=null;
        try{
        	HttpSession session=request.getSession();
        	SessionBean sessionBean=session != null && session.getAttribute("sessionObject") != null ? (SessionBean)session.getAttribute("sessionObject"):null;
        	int cnt=request.getParameter("hdCnt")!=null && !"".equals(request.getParameter("hdCnt"))?Integer.parseInt(request.getParameter("hdCnt")):0;
        	clientId =request.getParameter("hdClientId")!=null && !"".equals(request.getParameter("hdClientId"))?Integer.parseInt(request.getParameter("hdClientId")):0;
        	moduleId=request.getParameter("hdModuleId")!=null && !"".equals(request.getParameter("hdModuleId"))?Integer.parseInt(request.getParameter("hdModuleId")):0;
        	int eventLength=request.getParameter("hdEventLength")!=null && !"".equals(request.getParameter("hdEventLength"))?Integer.parseInt(request.getParameter("hdEventLength")):0;
        	configType=request.getParameter("hdConfigType")!=null && !"".equals(request.getParameter("hdConfigType"))?request.getParameter("hdConfigType"):null;
        	for(int i=1;i<=cnt;i++){
        		TblCustomParameter tblCustomParameter=new TblCustomParameter();
        		if(request.getParameter("hdCustomParamId_"+i)!=null && !"".equals(request.getParameter("hdCustomParamId_"+i))){
        			tblCustomParameter.setCustomParamId(Integer.parseInt(request.getParameter("hdCustomParamId_"+i)));
        		}
        		tblCustomParameter.setCreatedBy(sessionBean.getUserId());
        		tblCustomParameter.setTblClient(new TblClient(clientId));
        		tblCustomParameter.setTblModule(new TblModule(moduleId));
        		tblCustomParameter.setField(request.getParameter("hdFieldName_"+i)!=null?request.getParameter("hdFieldName_"+i):"");
        		tblCustomParameter.setTblField(new TblField(StringUtils.hasLength(request.getParameter("hdFieldId_"+i)) ? Integer.parseInt(request.getParameter("hdFieldId_"+i)) : 1));
        		tblCustomParameter.setTblEventType(new TblEventType(StringUtils.hasLength(request.getParameter("hdEventTypeId_"+i)) ? Integer.parseInt(request.getParameter("hdEventTypeId_"+i)) : 2));
        		tblCustomParameter.setFieldLabel(request.getParameter("txtFieldLabel_"+i)!=null?request.getParameter("txtFieldLabel_"+i):"");
        		if(configType != null && "auction".equalsIgnoreCase(configType) && (i==11 || i==12 || i==13 || i==36 || i==38)){
        			tblCustomParameter.setFieldValue(request.getParameter("txtFieldVal_"+i)!=null?request.getParameter("txtFieldVal_"+i):"");
        		}else{
        			tblCustomParameter.setFieldValue(request.getParameter("selFieldVal_"+i)!=null?request.getParameter("selFieldVal_"+i):"0");
        		}
        		tblCustomParameter.setIsShown(request.getParameter("rdIsShown_"+i)!=null && !"".equals(request.getParameter("rdIsShown_"+i))?Integer.parseInt(request.getParameter("rdIsShown_"+i)):0);
        		tblCustomParameters.add(tblCustomParameter);
        	}
        	for(int i=1;i<=eventLength;i++){
        		TblClientAlertConf tblClientAlertConf=new TblClientAlertConf();
        		if(request.getParameter("hdAlertId_"+i)!=null && !"".equals(request.getParameter("hdAlertId_"+i))){
        			tblClientAlertConf.setAlertId(Integer.parseInt(request.getParameter("hdAlertId_"+i)));
        		}
        		tblClientAlertConf.setCreatedBy(sessionBean.getUserId());
        		tblClientAlertConf.setTblClient(new TblClient(clientId));
        		tblClientAlertConf.setTblLink(new TblLink(request.getParameter("hdLinkId_"+i)!=null && !"".equals(request.getParameter("hdLinkId_"+i))?Integer.parseInt(request.getParameter("hdLinkId_"+i)):0));
        		tblClientAlertConf.setByEmail(request.getParameter("chkIsMail_"+i)!=null && !"".equals(request.getParameter("chkIsMail_"+i))?Integer.parseInt(request.getParameter("chkIsMail_"+i)):0);
        		tblClientAlertConf.setByMessageBox(request.getParameter("chkIsMsgBox_"+i)!=null && !"".equals(request.getParameter("chkIsMsgBox_"+i))?Integer.parseInt(request.getParameter("chkIsMsgBox_"+i)):0);
        		tblClientAlertConf.setBySms(request.getParameter("chkIsSMS_"+i)!=null && !"".equals(request.getParameter("chkIsSMS_"+i))?Integer.parseInt(request.getParameter("chkIsSMS_"+i)):0);
        		tblClientAlertConfList.add(tblClientAlertConf);
        	}
        	success=clientService.addCustomParam(tblCustomParameters, tblClientAlertConfList);
        	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_defaultconfiguration" : CommonKeywords.ERROR_MSG_KEY.toString());
        	if(success){
        		 
        		if(configType != null && "auction".equalsIgnoreCase(configType)){
        			if(clientService.getMandocRequired(clientId)){
        				retVal="redirect:/"+REQUIRED_DOCSURL+clientId + encryptDecryptUtils.generateRedirect(REQUIRED_DOCSURL+clientId, request);
        			}else{
        				retVal="redirect:/"+ SEARCHCLIENTLIST_URL + encryptDecryptUtils.generateRedirect(SEARCHCLIENTLIST_URL, request);
        			}
        		}else{
        			retVal="redirect:/common/admin/configureAuction/"+clientId+ encryptDecryptUtils.generateRedirect("common/admin/configureAuction/"+clientId, request);
        		}
            }else{
               // redirectAttributes.addFlashAttribute("errorMsg", "Unsuccessfully");
            	if(configType != null && "auction".equalsIgnoreCase(configType)){
            		retVal="redirect:/common/admin/configureAuction/"+clientId+ encryptDecryptUtils.generateRedirect("common/admin/configureAuction/"+clientId, request);
            	}else{
            		retVal="redirect:/common/admin/configureSealedBid/"+clientId + encryptDecryptUtils.generateRedirect("common/admin/configureSealedBid/"+clientId, request);
            	}
            }
        }catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        }finally {
        	int linkId=0;
        	String msg=null;
        	if(configType != null && "auction".equalsIgnoreCase(configType)){
        		linkId=defaultConfLinkId;
        		msg=success ? auditDefAuctionParamConfigured : auditDefAuctionParamConfigFailed;
        	}else{
        		linkId=defaultConfLinkId;
        		msg=success ? auditDefSealBidParamConfigured : auditDefSealBidParamConfigFailed;
        	}
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,clientId);
        }
        return retVal;
    }
    
    /**
     * @author VIPULP
     * @param tabId
     * @param clientId
     * @param request
     * @param modelMap
     * @return ajax content
     */
    @RequestMapping(value = "/admin/approveclientcontent", method = RequestMethod.POST)
    public String approveClientContent(@RequestParam("txtTabId") int tabId, @RequestParam("txtClientId") int clientId,
           @RequestParam("txtOperType") int operType,@RequestParam("txtModuleId") int moduleId,HttpServletRequest request, ModelMap modelMap) {
        try {
            if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                if(tabId <= 0){
                    switch(tabId){
                        case TAB_CLIENT:
                            getClientTabContent(modelMap,clientId);
                            break;
                        case TAB_THEME:
                            List<Object[]> configureThemeList = clientService.getConfiguredThemeDataForView(clientId);
                            if (configureThemeList != null && !configureThemeList.isEmpty()) {
                                if (configureThemeList.get(0)[0] != null) {
                                    modelMap.addAttribute("themeName", configureThemeList.get(0)[0]);
                                }
                                if (configureThemeList.get(0)[1] != null) {
                                    modelMap.addAttribute("logoName", configureThemeList.get(0)[1]);
                                }
                                if (configureThemeList.get(0)[2] != null) {
                                    modelMap.addAttribute("companyLogoName", configureThemeList.get(0)[2]);
                                }
                            }
                            break;
                        case TAB_ADDI_SEALEDBID_PARAMS:
                            modelMap.addAttribute("addiSealedBidParams",dynamicFieldService.getDynFieldNameValListByLinkIdForView(addiSealBidConfLinkId, clientId));
                            break;
                        case TAB_REGISTRATION_SUPP_DOC:
                            modelMap.addAttribute("ClientRegDocLst",clientService.getClientRegDocByclientId(clientId));
                            break;
                        case TAB_ADDI_AUCTION_PARAMS:
                            modelMap.addAttribute("addiAuctionParams",dynamicFieldService.getDynFieldNameValListByLinkIdForView(addiAuctionConfgLinkId, clientId));
                            break;
                    }
                }else{
                            generateComponentMap(modelMap,tabId,clientId,true,request);
                            modelMap.addAttribute("eventList", clientService.getNotificationEventsForView(clientId,moduleId));
                            modelMap.addAttribute("paramList", clientService.getCustomParameter(moduleId, clientId));
                            
                            modelMap.addAttribute("rContractType", abcUtility.convert(clientService.getProcurementNature()));
                            modelMap.addAttribute("rAuctionVariant", abcUtility.convert(clientService.getEventTypeIdForAuctionDefaultConfg(clientId)));
                }
                modelMap.addAttribute("tabId", tabId);
                modelMap.addAttribute("clientId", clientId);
            } else {
                modelMap.addAttribute("sessionExpired",true);
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 
                    operType == 1 ? approveClientLinkId : viewClientLinkId, operType == 1 ? auditApproveClient : auditViewClient, 0,clientId);
        }
        return "/common/admin/ApproveClientContent";
    }
    
    /**
     * GET client tab content
     *
     * @param modelMap
     */
    private void getClientTabContent(ModelMap modelMap, int clientId) throws Exception {
        List<Object[]> clientDeptObj = clientService.getClientDetailsByClientId(clientId);
        List<Object[]> lstModule = clientService.getClientModuleForView(clientId);
        List<Object[]> lstWorkFlowType = clientService.getClientWorkflowForView(clientId);;
        List<Object[]> lstModeOfPayment = clientService.getClientPaymentTypeForView(clientId);
        List<Object[]> lstLanguage = clientService.getClientLanguageForView(clientId);
        List<Object[]> lstHomeModule = clientService.getClientModuleForHomePage(clientId);
       
        
        /**
         * Start : UI Change #15912  (default HomePage module ) purvesh 
         */
        if(lstHomeModule!=null && !lstHomeModule.isEmpty()){
        	for(Object[] obj : lstHomeModule) {
        		//System.out.println( obj[1]+"***"+ obj[2]);
        		if((Integer)obj[2]==1){
        			modelMap.addAttribute("defaultHomePageListing", obj[1]);
        			break;
        		}
        	}
        }
        // end : UI Change #15912 purvesh 
        
        /*
         * Start: Added By Nirav Modi: CR : 11933
         */
        List<Object[]> eventTypeList = clientService.getEventTypeId(clientId);
        int moduleId=0;
        List<Map<String, Object>> eventTypeMapList=  new ArrayList<Map<String,Object>>();
        StringBuilder value= null;
        Map<String, Object> eventMap = null;
        int count=0;
        boolean flag=false;
        for(Object[] object: eventTypeList){
        	int tmpModuleId=(Integer) object[2];
        	if(tmpModuleId!=moduleId){
        		if(count!=0){
        			flag=true;
        		}
        		if(flag){
        			eventTypeMapList.add(eventMap);
        		}
        		value=new StringBuilder();
        		eventMap = new HashMap<String, Object>();
        		eventMap.put("label",object[3]);
        		value.append(object[1]);
        		eventMap.put("value", value);
        		moduleId=tmpModuleId;
        	}else{
        		value.append(", ").append(object[1]);
        		eventMap.put("value", value);
        	}
        	if(count==eventTypeList.size()-1){
        		eventTypeMapList.add(eventMap);
        	}
        	count++;
        }
        
        /*
         * End: Added By Nirav Modi: CR : 11933
         */
        // To get both selected languages and default languages
        StringBuilder commaValues = new StringBuilder();
        StringBuilder defaultLang = new StringBuilder();
        for (Object[] obj : lstLanguage) {
            if (obj[2] != null) {
                commaValues.append(obj[1]).append(",");
            }
            if (obj[3] != null && obj[3].equals(1)) {
                defaultLang.append(obj[1]);
            }
        }
        // To get both curencies and default currency
        commaValues = commaValues.deleteCharAt(commaValues.length() - 1);
        List<Object[]> lstCurrency = clientService.getClientCurrencyForView(clientId);
        StringBuilder currencyList = new StringBuilder();
        StringBuilder defaultCurrency = new StringBuilder();
        for (Object[] obj : lstCurrency) {
            if (obj[2] != null) {
                currencyList.append(obj[1]).append(",");
            }
            if (obj[3] != null && obj[3].equals(1)) {
                defaultCurrency.append(obj[1]);
            }
        }
        currencyList = currencyList.deleteCharAt(currencyList.length() - 1);
        modelMap.addAttribute("languageList", commaValues.toString());
        modelMap.addAttribute("defaultLang", defaultLang.toString());
        modelMap.addAttribute("currencyList", currencyList.toString());
        modelMap.addAttribute("defaultCurrency", defaultCurrency.toString());
        modelMap.addAttribute("moduleList", abcUtility.converObjectArrayToCommas(lstModule, 1, 2));
        modelMap.addAttribute("workFlowList", abcUtility.converObjectArrayToCommas(lstWorkFlowType, 1, 2));
        modelMap.addAttribute("modeOfPaymentList", abcUtility.converObjectArrayToCommas(lstModeOfPayment, 1, 2));
        modelMap.addAttribute("eventTypeMapList",eventTypeMapList);
        modelMap.addAttribute("clientDetails", clientDeptObj);
        modelMap.addAttribute("clientDetailsList",clientService.getClientById(clientId));
        TblClientPGBankMapping tblClientPGBankMapping=clientService.getTblClientPGBankMappingForClient(clientId);
        modelMap.addAttribute("paymentGateway",tblClientPGBankMapping != null?commonService.getTblPaymentGatewayMaster(tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId()):null);        
        modelMap.addAttribute("bank",tblClientPGBankMapping!=null?commonService.getTblBankMaster(tblClientPGBankMapping.getTblBankMaster().getBankId()):null);        
        
    }
    
    public HttpServletRequest getServletRequest() {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return attr.getRequest();
    }
    
    public List<SelectItem> generateList(String data){
    	String[] dataOne=data.split("~");
    	List<SelectItem> dataList = new ArrayList<SelectItem>();
    	//List<Object[]> dataList=new ArrayList<Object[]>();
    	for(String tempData : dataOne){
    		String[] dataTwo=tempData.split("::");
    		//System.out.println("data two :::"+messageSource.getMessage(dataTwo[0], null, LocaleContextHolder.getLocale()));
    		dataList.add(new SelectItem(messageSource.getMessage(dataTwo[0], null, LocaleContextHolder.getLocale()),dataTwo[1]));
    	}
    	return dataList;
    }
    
    private void generateComponentMap(ModelMap modelMap,int eventTypeId,int clientId,boolean isView,HttpServletRequest request) throws Exception{
    	modelMap.addAttribute("getYesNo", commonService.getYesNo());
    	List<Object[]> dataList=clientService.getClientConfigurationFields(clientId, eventTypeId);
    	List<HashMap<String,Object>> data=new ArrayList<HashMap<String,Object>>();
        //Added by Mitesh
        List<Object[]> dataListColumnConfig=clientService.getColumnTypeConfiguration(clientId,eventTypeId,request);
    	List<SelectItem> selColumn = abcUtility.convertSelected(dataListColumnConfig); //modelToSelectItem.convertListIntoSelectItemList(dataListColumnConfig,"columnTypeId", "lang"+1);
    	modelMap.addAttribute("selColumnType", selColumn);
        dataListColumnConfig=clientService.getColumnTypeConfigurationForMandatory(clientId,eventTypeId,request);
    	selColumn = abcUtility.convertSelected(dataListColumnConfig); 
    	modelMap.addAttribute("selMandatoryColumnType", selColumn);
    	
    	Map<String, Object> dataMap=null;
    	for(Object[] dataTemp : dataList){
    		boolean isEmptyQuery=false;
    		dataMap=new HashMap<String,Object>();
    		dataMap.put("fieldLabel", dataTemp[6]);
    		dataMap.put("fieldGroupId", dataTemp[2]);
    		if(dataTemp[9].equals(0) && dataTemp[14].equals(1)) // Change for set default value from tblField if not found in tblCustomeParameter table.
    		{	dataMap.put("fieldVal", dataTemp[8]);
    		}else{
    		    dataMap.put("fieldVal", dataTemp[4]);
    		}
    		dataMap.put("defaultVal", dataTemp[8]);
                
    		if(dataTemp[7] != null && !dataTemp[7].toString().equals("")){
                    if(isView && StringUtils.hasLength(dataTemp[4].toString())){
    			dataMap.put("controlValue", generateDataMap(dataTemp[7].toString()).get(Integer.parseInt(dataTemp[4].toString())));
                    }else{
    			dataMap.put("controlValue", generateList(dataTemp[7].toString()));
                    }
    		}else if(dataTemp[7].toString().isEmpty() && "2".equals(dataTemp[1].toString())){
                    if(isView && StringUtils.hasLength(dataTemp[4].toString())){
                        if(StringUtils.hasLength(dataTemp[5].toString())){
                            List<Object[]> lstLabelVal = commonService.getExecuteQuery(dataTemp[5].toString(),clientId);
                            //Map map = new HashMap();
                            if(!lstLabelVal.isEmpty()){
                                for (Object[] objects : lstLabelVal) {
                                    if(StringUtils.hasLength(objects[0].toString()) && Integer.parseInt(objects[0].toString()) == Integer.parseInt(dataTemp[4].toString())){
                                        dataMap.put("controlValue", objects[1]);
                                    }
                                }
                            }
                        }else{
                            dataMap.put("controlValue", generateDataMap(dataTemp[7].toString()).get(Integer.parseInt(dataTemp[4].toString())));
                        }
                    }else{
                    	List<SelectItem> tempList=abcUtility.convert(commonService.getExecuteQuery(dataTemp[5].toString(),clientId));
                        dataMap.put("controlValue", tempList);
                        if(tempList.isEmpty()){
                        	isEmptyQuery=true;
                        }
                    }
    		}else{
                    if(isView){
                         dataMap.put("controlValue",dataTemp[4]);
                    }
                }
    		dataMap.put("controlType", dataTemp[1]);
    		dataMap.put("isShown", dataTemp[0]);
    		dataMap.put("field", dataTemp[3]);
    		dataMap.put("customParamId", dataTemp[9]);
    		dataMap.put("eventTypeId", dataTemp[10]);
    		dataMap.put("fieldId", dataTemp[11]);
    		dataMap.put("forShowHide", dataTemp[12]);
    		dataMap.put("staticFieldLabel", dataTemp[13]);
    		dataMap.put("hasDefaultValue", dataTemp[14]);
    		dataMap.put("isEmptyRecord", isEmptyQuery);
    		dataMap.put("isReadOnly", (Integer)dataTemp[15] == 1 ? true : false);
    		dataMap.put("description",dataTemp[16]);
    		data.add((HashMap<String, Object>) dataMap);
    	}
    	modelMap.addAttribute("data", data);
    	
    }
    
    private Map<Integer, String> generateDataMap(String data) {
        String[] dataOne = data.split("~");
        Map<Integer, String> dataMap = new HashMap<Integer, String>();
        for (String tempData : dataOne) {
            String[] dataTwo = tempData.split("::");
            dataMap.put(Integer.parseInt(dataTwo[1]), messageSource.getMessage(dataTwo[0], null, LocaleContextHolder.getLocale()));
        }
        return dataMap;
    }
    
    /**
     * to add default configuration parameters
     * @param redirectAttributes
     * @param request
     * @return String
     */
    @RequestMapping(value = "/admin/adddefaultconfig", method = RequestMethod.POST)
    public String addDefaultConfig (RedirectAttributes redirectAttributes, HttpServletRequest request){
        boolean success = false;
        List<TblCustomParameter> tblCustomParameters=new ArrayList<TblCustomParameter>();
        List<TblClientAlertConf> tblClientAlertConfList=new ArrayList<TblClientAlertConf>();
        int moduleId=0;
        int clientId=0;
        String retVal = null;
        String columnTypes[];
        String mandatoryColumnTypes[];
        //String configType=null;
        int eventTypeId=0;
        try{
        	/*HttpSession session=request.getSession();
        	SessionBean sessionBean=session != null && session.getAttribute("sessionObject") != null ? (SessionBean)session.getAttribute("sessionObject"):null;*/
        	int userId=abcUtility.getSessionUserId(request);
        	int cnt=StringUtils.hasLength(request.getParameter("hdCnt")) ? Integer.parseInt(request.getParameter("hdCnt")) : 0;
        	clientId =StringUtils.hasLength(request.getParameter("hdClientId")) ? Integer.parseInt(request.getParameter("hdClientId")) : 0;
        	moduleId=StringUtils.hasLength(request.getParameter("hdModuleId")) ? Integer.parseInt(request.getParameter("hdModuleId")) : 0;
        	int eventLength=StringUtils.hasLength(request.getParameter("hdEventLength")) ? Integer.parseInt(request.getParameter("hdEventLength")) : 0;
        	eventTypeId=StringUtils.hasLength(request.getParameter("hdEventTypeId")) ? Integer.parseInt(request.getParameter("hdEventTypeId")) : 0;
        	//configType=request.getParameter("hdConfigType")!=null && !"".equals(request.getParameter("hdConfigType"))?request.getParameter("hdConfigType"):null;
                columnTypes=request.getParameterValues("chkColumnType");
                mandatoryColumnTypes=request.getParameterValues("chkMandatoryColumnType");
                
        	for(int i=0;i<cnt;i++){
        		TblCustomParameter tblCustomParameter=new TblCustomParameter();
        		if(request.getParameter("hdCustomParamId_"+i)!=null && !"".equals(request.getParameter("hdCustomParamId_"+i))){
        			tblCustomParameter.setCustomParamId(Integer.parseInt(request.getParameter("hdCustomParamId_"+i)));
        		}
        		int controlType=StringUtils.hasLength(request.getParameter("hdControlType_"+i)) ? Integer.parseInt(request.getParameter("hdControlType_"+i)) : 0;
        		tblCustomParameter.setCreatedBy(userId);
        		tblCustomParameter.setTblClient(new TblClient(clientId));
        		tblCustomParameter.setTblModule(new TblModule(moduleId));
        		tblCustomParameter.setField(request.getParameter("hdField_"+i)!=null?request.getParameter("hdField_"+i):"");
        		tblCustomParameter.setTblField(new TblField(StringUtils.hasLength(request.getParameter("hdFieldId_"+i)) ? Integer.parseInt(request.getParameter("hdFieldId_"+i)) : 0));
        		tblCustomParameter.setTblEventType(new TblEventType(eventTypeId));
        		tblCustomParameter.setFieldLabel(request.getParameter("txtFieldLabel_"+i)!=null?request.getParameter("txtFieldLabel_"+i):"");
        		if(controlType == 1 ){
        			tblCustomParameter.setFieldValue(request.getParameter("txtFieldVal_"+i)!=null?request.getParameter("txtFieldVal_"+i):"");
        		}else if(controlType == 2){
        			if(!StringUtils.hasLength(request.getParameter("selFieldVal_"+i)) && "workflowTypeId".equalsIgnoreCase(request.getParameter("hdField_"+i))){
        				tblCustomParameter.setFieldValue(request.getParameter("selFieldVal_"+i)!=null?request.getParameter("selFieldVal_"+i):"3");
        			}else{
        				tblCustomParameter.setFieldValue(request.getParameter("selFieldVal_"+i)!=null?request.getParameter("selFieldVal_"+i):"0");
        			}	
        		}else if(controlType == 0 || controlType > 2){
        			tblCustomParameter.setFieldValue("");
        		}
        		tblCustomParameter.setIsShown(StringUtils.hasLength(request.getParameter("rdIsShown_"+i)) ? Integer.parseInt(request.getParameter("rdIsShown_"+i)) : 1);
        		tblCustomParameters.add(tblCustomParameter);
        	}
        	for(int i=1;i<=eventLength;i++){
        		TblClientAlertConf tblClientAlertConf=new TblClientAlertConf();
        		if(request.getParameter("hdAlertId_"+i)!=null && !"".equals(request.getParameter("hdAlertId_"+i))){
        			tblClientAlertConf.setAlertId(Integer.parseInt(request.getParameter("hdAlertId_"+i)));
        		}
        		tblClientAlertConf.setCreatedBy(userId);
        		tblClientAlertConf.setTblClient(new TblClient(clientId));
        		tblClientAlertConf.setTblLink(new TblLink(request.getParameter("hdLinkId_"+i)!=null && !"".equals(request.getParameter("hdLinkId_"+i))?Integer.parseInt(request.getParameter("hdLinkId_"+i)):0));
        		tblClientAlertConf.setByEmail(request.getParameter("chkIsMail_"+i)!=null && !"".equals(request.getParameter("chkIsMail_"+i))?Integer.parseInt(request.getParameter("chkIsMail_"+i)):0);
        		tblClientAlertConf.setByMessageBox(request.getParameter("chkIsMsgBox_"+i)!=null && !"".equals(request.getParameter("chkIsMsgBox_"+i))?Integer.parseInt(request.getParameter("chkIsMsgBox_"+i)):0);
        		tblClientAlertConf.setBySms(request.getParameter("chkIsSMS_"+i)!=null && !"".equals(request.getParameter("chkIsSMS_"+i))?Integer.parseInt(request.getParameter("chkIsSMS_"+i)):0);
        		tblClientAlertConf.setMarkCCtoOfficer(request.getParameter("chkIsMarkCC_"+i)!=null && !"".equals(request.getParameter("chkIsMarkCC_"+i))?Integer.parseInt(request.getParameter("chkIsMarkCC_"+i)):0);
        		tblClientAlertConfList.add(tblClientAlertConf);
        	}
                //get columnType from the request.
                List<TblClientColumnType> clientColumnTypeList=new ArrayList<TblClientColumnType>();
                if(columnTypes!=null){
                    List<String> mandatoryColumnTypesList;
                    if(mandatoryColumnTypes!=null){
                        mandatoryColumnTypesList=Arrays.asList(mandatoryColumnTypes);
                    }
                    else{
                        mandatoryColumnTypesList=new ArrayList<String>();
                    }
                    for (String columnType : columnTypes) {
                        TblClientColumnType clientColumnType=new TblClientColumnType();
                        clientColumnType.setTblClient(new TblClient(clientId));
                        clientColumnType.setTblColumnType(new TblColumnType(Integer.parseInt(columnType)));
                        clientColumnType.setTblEventType(new TblEventType(eventTypeId));
                        clientColumnType.setIsMandatory((mandatoryColumnTypesList.contains(columnType)==true?1:0));
                        clientColumnType.setIsActive(1);
                        clientColumnTypeList.add(clientColumnType);
                    }
                }
        	success=clientService.addCustomParam(tblCustomParameters, tblClientAlertConfList);
            
        	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_defaultconfiguration" : CommonKeywords.ERROR_MSG_KEY.toString());
        	if(success){
                    clientService.deleteInsertClientColumnType(clientId, eventTypeId, clientColumnTypeList);
        		List<Object[]> data=clientService.getClientConfigureEvents(clientId);
        		if(eventTypeId == (Integer)data.get(data.size() - 1)[0]){
        			if(clientService.getMandocRequired(clientId)){
        				retVal="redirect:/"+REQUIRED_DOCSURL+clientId + encryptDecryptUtils.generateRedirect(REQUIRED_DOCSURL+clientId, request);
        			}else{
        				retVal="redirect:/"+ SEARCHCLIENTLIST_URL + encryptDecryptUtils.generateRedirect(SEARCHCLIENTLIST_URL, request);
        			}
        		}else{
        			for(int i=0;i<data.size();i++){
        				if(eventTypeId == (Integer)data.get(i)[0]){
        					eventTypeId=(Integer)data.get(i+1)[0];
        					break;
        				}
        			}
        			retVal="redirect:/common/admin/defaultconfiguration/"+clientId+"/"+eventTypeId+encryptDecryptUtils.generateRedirect("common/admin/defaultconfiguration/"+clientId+"/"+eventTypeId, request); 
        		}
    			
            }else{
               /*// redirectAttributes.addFlashAttribute("errorMsg", "Unsuccessfully");
            	if(configType != null && "auction".equalsIgnoreCase(configType)){
            		retVal="redirect:/common/admin/configureAuction/"+clientId+ encryptDecryptUtils.generateRedirect("common/admin/configureAuction/"+clientId, request);
            	}else{
            		retVal="redirect:/common/admin/configureSealedBid/"+clientId + encryptDecryptUtils.generateRedirect("common/admin/configureSealedBid/"+clientId, request);
            	}*/
            }
        }catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        }finally {
        	int linkId=0;
        	String msg="";
        		linkId=defaultConfLinkId;
        		switch(eventTypeId){
        		
	        		case 1: 
	        				msg=auditDefAuctionParamConfigured;
	        				break;
	        		case 2: 
	    				msg=auditDefAuctionParamConfigured;
	    				break;
	    				
	        		case 3: 
	    				msg=postDefaultParameterPQ;
	    				break;
	    				
	        		case 4: 
	    				msg=postDefaultParameterTender;
	    				break;
	    				
	        		case 5: 
	    				msg=postDefaultParameterRFQ;
	    				break;
	    				
	        		case 6: 
	    				msg=postDefaultParameterRFP;
	    				break;
	    				
	        		case 7: 
	    				msg=postDefaultParameterRFI;
	    				break;
	    				
	        		case 8: 
	    				msg=postDefaultParameterREOI;
	    				break;
        		}
        		
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,clientId);
        }
        return retVal;
    }
    
    /**
     * Mapping of Clinet-Sector
     * @Author Nirav Raval
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/mapclientsector/{clientId}/{enc}", method = RequestMethod.GET)
    public String mapClientSector(@PathVariable(CLIENT_ID) int clientId, ModelMap modelMap, HttpServletRequest request) {
        try {
            TblClient tblClient = clientService.getClientById(clientId);
            TblDepartment tblDepartment = clientService.getDepartmentById(tblClient.getDeptId());
            setClientData(modelMap);
            modelMap.addAttribute("tblClientList",tblClient);
            modelMap.addAttribute("tblDeptList",tblDepartment);
            modelMap.addAttribute(CLIENT_ID,clientId);
           
            List<Object[]> lstSector = clientService.getSector(clientId);
            List<SelectItem> selSector = abcUtility.convertSelected(lstSector);
            modelMap.addAttribute("selSector", selSector);
            
            List<Object> listSector = clientService.getClientSector(clientId);
            modelMap.addAttribute("selectedSector", listSector);
            
            modelMap.addAttribute(OPERTYPE_CREATE, "edit");
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), mapClientSectorLinkId, auditEditClient, 0,clientId);
        }
        return "/common/admin/ClientSectorMap";
    }
    
    /**
     * To add and update client-sector mapping details
     * @Author Nirav Raval
     * @param modelMap
     * @param redirectAttributes
     * @param request
     * @return 
     */
    @RequestMapping(value = "/admin/addclientsectormap/", method = RequestMethod.POST)
    public String addClientSectorMap(ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) { 
        boolean isSuccess = false;
        String retVal = null;
        String clientId = request.getParameter("hdclientId");
        String redirectLink = null;
        String successRedirectLink;
        String successMessage = null;
        int userId = abcUtility.getSessionUserId(request);
        TblClient tblClient = new TblClient();
        try {
            redirectLink = "/common/admin/ClientSectorMap" + clientId;
            successMessage = "redirect_success_updateclient";
            
            List<TblClientSector> tblClientSectors = new ArrayList<TblClientSector>();
            String chkSectors[] = null;
            boolean isInsertReq = false;

            if (request.getParameterValues("chkSector") != null) {
                chkSectors = request.getParameterValues("chkSector");
                isInsertReq = true;
            }

            if (chkSectors != null) {
                for (String sectors : chkSectors) {
                    TblClientSector tblclientsector = new TblClientSector();
                    tblclientsector.setTblClient(tblClient);
                    tblclientsector.setTblSector(new TblSector(Integer.parseInt(sectors)));
                    tblclientsector.getTblClient().setClientId(Integer.parseInt(clientId));

                    tblClientSectors.add(tblclientsector);
                }
            } else {
                TblClientSector tblclientsector = new TblClientSector();
                tblclientsector.setTblClient(tblClient);
                tblclientsector.getTblClient().setClientId(Integer.parseInt(clientId));

                tblClientSectors.add(tblclientsector);
            }
           
           int sectorId = Integer.parseInt(chkSectors[0]); 
           int clientSectorId = clientService.getClientSectorId(Integer.parseInt(clientId), 7);
        	if(clientSectorId > 0){
        		clientService.deleteMVPVertical(clientSectorId);
        	}
           
            
            isSuccess = clientService.addClientSector(tblClientSectors, Integer.parseInt(clientId), isInsertReq);
            
            if(isSuccess && sectorId == 7){
            	TblClientSector tblclientsector = tblClientSectors.get(0);
            	clientSectorId = tblclientsector.getClientSectorId();
            	String[] envIds = mvpEnvIds.split(",");
            	List<TblMvpVertical> tblMvpVerticals = new ArrayList<TblMvpVertical>();
            	for(String envId : envIds){
            		String[] formIds = (Integer.parseInt(envId) == 3) ? mvpTechFormIds.split(",") : mvpPriceBidFormIds.split(",");
            		for(String formId : formIds){
            			TblMvpVertical tblMvpVertical = new TblMvpVertical();
                		tblMvpVertical.setTblClientSector(new TblClientSector(clientSectorId)); 
                		tblMvpVertical.setModuleId(3);
                		tblMvpVertical.setEnvId(Integer.parseInt(envId));
                		tblMvpVertical.setFormId(Integer.parseInt(formId));
                		tblMvpVertical.setCreatedBy(userId);
                		tblMvpVertical.setIsActive(1);
                		tblMvpVerticals.add(tblMvpVertical);
            		}
            	}
            	isSuccess = clientService.addMVPVertical(tblMvpVerticals);
            }
            successRedirectLink = SEARCHCLIENTLIST_URL;
            if (isSuccess) {
                retVal = successRedirectLink;
            } else {
                retVal = redirectLink;
            }
            retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
            
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), isSuccess?mapClientSectorLinkId:editClientLinkId,isSuccess? auditClientSectorConfigCreated : auditClientEdited, 0, tblClient.getClientId());
        }
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? successMessage : CommonKeywords.ERROR_MSG_KEY.toString());
        return retVal;
    }
    
    /**
     * @author dharmesh
     * Used to manage payment configuration and active tab re-allocation
     * @param enc
     * @param modelMap
     * @return
     */
    @RequestMapping(value = "/admin/managepaymentconf/{clientId}/{tabId}/{enc}", method = RequestMethod.GET)
    public String managePaymentConfiguration(@PathVariable(CLIENT_ID) int clientId,@PathVariable("tabId") int tabId, ModelMap modelMap, HttpServletRequest request) {
        try {
    		
    	
            List<Object[]> lstTblClientPayment = clientService.getTblClientPayment(clientId);
            modelMap.put("lstTblClientPayment", lstTblClientPayment);
        	if(tabId==0){
            if (lstTblClientPayment != null && !lstTblClientPayment.isEmpty()) {
            	for (Object[] objects : lstTblClientPayment) {
                	if (Integer.parseInt(objects[0].toString()) == 1) {
                		tabId = TAB_ONLINE_PAYMENT;
    				} else if (Integer.parseInt(objects[0].toString()) == 2 && tabId == 0) {
    					tabId = TAB_NEFTRTGS;
    				}
    			}
			}
        	}
            modelMap.put("tabId", tabId);
            modelMap.addAttribute("domainName", clientService.getClientNameById(clientId));
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), paymentConfigurationLinkId, getManagePaymentConf, 0,clientId);
        }
        return "/common/admin/ManagePayment";
    }
    /**
     * @author manish
     * Used to get payment configuration content
     * @param clientId
     * @param txtTabId
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/paymentconfigurationcontent/{clientId}", method = RequestMethod.POST)
    public String getPaymentConfigurationContent(@PathVariable(CLIENT_ID) int clientId, @RequestParam("txtTabId") int txtTabId, ModelMap modelMap, HttpServletRequest request) {
    	String retVal="";
    	try {
    		if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
    			
    			Object[] obj=clientService.getClientFields(clientId,"domainName,paymentConfigBy,deptId");
    			modelMap.addAttribute("domainName", obj[0]);
    			modelMap.addAttribute(CLIENT_ID, clientId);
    			int paymentConfigBy=Integer.valueOf(obj[1].toString());
    			modelMap.addAttribute("paymentConfigBy",paymentConfigBy);
    			modelMap.addAttribute("parentDepartment", clientService.getDepartmentById(Integer.valueOf(obj[2].toString())));
    			switch (txtTabId) {
	    			case TAB_ONLINE_PAYMENT:
	    				boolean isDocFeesConf = false;
	    				boolean isEmdConf = false;
	    				boolean isRegChargesConfig = false;
	    				boolean isEventReg = false;
	    				boolean isRestAucMoney = false;
	    				boolean isRestSecFees = false;
	    				List<Object[]> list = tpslService.getClientWisePGConf(clientId);
	    				if (list != null && !list.isEmpty()) {
	    					int i = 0;
	    					for (Object[] object : list) {
	    						i = (Integer)object[1];
	    						if (i == 1) {
	    							isDocFeesConf = true;
	    							modelMap.put("pgConfIdForDocFees", (Integer)object[0]);
	    						} else if(i == 2) {
	    							isEmdConf = true;
	    							modelMap.put("pgConfIdForEmd", (Integer)object[0]);
	    						}else if(i == 3) {
	    							isRegChargesConfig = true;
	    							modelMap.put("pgConfIdForRegCharges", (Integer)object[0]);
	    						}else if(i == 8) {
	    							isEventReg = true;
	    							modelMap.put("pgConfIdForEventReg", (Integer)object[0]);
	    						}else if(i == 9) {
	    							isRestAucMoney = true;
	    							modelMap.put("pgConfIdForRestAucMoney", (Integer)object[0]);
	    						}else if(i == 11) {
	    							isRestSecFees = true;
	    							modelMap.put("pgConfIdForRestSecFees", (Integer)object[0]);
	    						}
	    					}
	    				}
	    				modelMap.put("isDocFeesConf", isDocFeesConf);
	    				modelMap.put("isEmdConf", isEmdConf);
	    				modelMap.put("isRegChargesConfig", isRegChargesConfig);
	    				modelMap.put("isEventReg", isEventReg);
	    				modelMap.put("isRestAucMoney", isRestAucMoney);
	    				modelMap.put("isRestSecFees", isRestSecFees);
	    				if(paymentConfigBy==2){
	    					modelMap.put("deptList",tpslService.getActivePGDeptListByClientId(clientId));
	    				}
	    				retVal = "/common/admin/ManagePGConfiguration";
	    				break;
	    			case TAB_NEFTRTGS:
	    				Object neftObj=neftService.getNeftRtgsConfigurationDetail(clientId);
	    				modelMap.addAttribute("neftConfList",neftObj);
                        modelMap.addAttribute("isVendorAvailable", neftService.isVendorAvailable(clientId));
                        if(paymentConfigBy==2 && neftObj!=null){
	    					modelMap.put("deptList",neftService.getActiveNeftDeptListByClientId(clientId));
	    				}
	    				retVal = "/common/admin/NEFTConfigurationList";
	    				break;
	    			case TAB_ACCOUNTMAPPING:	    				
	    				modelMap.addAttribute("lstAccountType",neftService.getAccountType());
	    				
	    				List<TblTransactionTypeAccountMapping> lst=neftService.getTransactionTypeAccountMapping(clientId);
	    				for (TblTransactionTypeAccountMapping tblTransactionTypeAccountMapping : lst) {
							switch (tblTransactionTypeAccountMapping.getTblTransactionType().getTransactionTypeId()) {
								case 1:
									modelMap.addAttribute("docFeeFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("docFeeTo",tblTransactionTypeAccountMapping.getCreditAccountType());
									break;
								case 2:
									modelMap.addAttribute("emdFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("emdTo",tblTransactionTypeAccountMapping.getCreditAccountType());
									break;
								case 3:
									modelMap.addAttribute("refundFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("refundTo",tblTransactionTypeAccountMapping.getCreditAccountType());
									break;
								case 4:
									modelMap.addAttribute("forfietFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("forfietTo",tblTransactionTypeAccountMapping.getCreditAccountType());
									break;
								case 5:
									modelMap.addAttribute("releaseFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("releaseTo",tblTransactionTypeAccountMapping.getCreditAccountType());
									break;
								case 6:
									modelMap.addAttribute("pgFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("pgTo",tblTransactionTypeAccountMapping.getCreditAccountType());
								case 8:
									modelMap.addAttribute("eventFeeFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("eventFeeTo",tblTransactionTypeAccountMapping.getCreditAccountType());
									break;
								case 9:
									modelMap.addAttribute("restAucMoneyFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("restAucMoneyTo",tblTransactionTypeAccountMapping.getCreditAccountType());
									break;
								case 11:
									modelMap.addAttribute("restSecfeesFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("restSecfeesTo",tblTransactionTypeAccountMapping.getCreditAccountType());
									break;
								case 12:
									modelMap.addAttribute("releaseRestSecfeesFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("releaseRestSecfeesTo",tblTransactionTypeAccountMapping.getCreditAccountType());
									break;
								case 13:
									modelMap.addAttribute("CommissionFrom",tblTransactionTypeAccountMapping.getDebitAccountType());
									modelMap.addAttribute("CommissionTo",tblTransactionTypeAccountMapping.getCreditAccountType());
									break;
								default:
									break;
							}
						}
	    				retVal = "/common/admin/AccountConfiguration";
	    				break;
	    			default:
	    				retVal = "redirect:/exception";
	    				break;
    			}
    		} else {
        		modelMap.put("sessionexpired",true);
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), paymentConfigurationLinkId, getManagePaymentConf, 0,clientId);
        }
        return retVal;
    }
    
    /**
     * to add default configuration parameters
     * @param redirectAttributes
     * @param request
     * @return selectedClientid
     * @return clientId
     * 
     */
    @RequestMapping(value = "/admin/setConfirationAsClient", method = RequestMethod.POST)
    public String setConfirationAsClient(RedirectAttributes redirectAttributes,HttpServletRequest request){
        boolean success = false;
        String retVal = null;
        int toClientId = 0;
    	int fromClientList = 0;
    	try {
        		toClientId = Integer.parseInt(request.getParameter("hdClientId"));
        		fromClientList = Integer.parseInt(request.getParameter("selClientList")); 
        		List<Object[]> commonEvent = clientService.getCommonEventId(toClientId,fromClientList);
        		if(commonEvent != null && !commonEvent.isEmpty()){
        			int userId = abcUtility.getSessionUserId(request);
        			success = clientService.setParameterForClient(commonEvent, toClientId, fromClientList, userId);
        		}else{
        			success = true;
        		}
        	
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), defaultConfLinkId, defaultConfigrationSuccess, 0,toClientId);
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_defaultconfiguration" : CommonKeywords.ERROR_MSG_KEY.toString());
        retVal="redirect:/"+ SEARCHCLIENTLIST_URL + encryptDecryptUtils.generateRedirect(SEARCHCLIENTLIST_URL, request);
        return retVal;
    }
    
    @RequestMapping(value = "/admin/hideRegistrationLink/{enc}", method = RequestMethod.GET)
    public String hideRegistrationLink(HttpServletRequest request, ModelMap modelMap){
    	int clientId = 0;
    	try {
            clientId = abcUtility.getSessionClientId(request);
            List<Object[]> hideRegistrationLinkDetails = clientService.getHideRegistrationLinkDetails(clientId, hideRegistrationLinkId, 1);
            modelMap.addAttribute("clientId", clientId);
            modelMap.addAttribute("hideRegistrationLinkDetails", hideRegistrationLinkDetails);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), hideRegistrationLinkId, getHideRegistrationLinkRemark, 0,clientId);
        }
        return "/common/admin/HideRegistrationLink";
    }
    
    @RequestMapping(value = "/admin/submitHideRegistrationLink", method = RequestMethod.POST)
    public String submitRegistrationLink(HttpServletRequest request, RedirectAttributes redirectAttributes){
    	String retVal = null;
    	String fromDate = null;
    	String toDate = null;
    	TblClientLinkConfig tblClientLinkConfig = null;
    	List<TblClientLinkConfig> tblClientLinkConfigs = new ArrayList<TblClientLinkConfig>();
    	boolean success = false;
    	int clientId = 0;
    	int userId = 0;
    	try {
    		clientId = abcUtility.getSessionClientId(request);
    		userId = abcUtility.getSessionUserDetailId(request);
    		fromDate = StringUtils.hasLength(request.getParameter("txtFromDate")) ? request.getParameter("txtFromDate") : null;
    		toDate = StringUtils.hasLength(request.getParameter("txtToDate")) ? request.getParameter("txtToDate") : null;
    		tblClientLinkConfig = new TblClientLinkConfig();
    		tblClientLinkConfig.setTblClient(new TblClient(clientId));
    		tblClientLinkConfig.setTblLink(new TblLink(hideRegistrationLinkId));
    		tblClientLinkConfig.setFromDate(conversionService.convert(fromDate, Date.class));
     		tblClientLinkConfig.setToDate(conversionService.convert(toDate, Date.class));
     		tblClientLinkConfig.setCreatedBy(userId);
    		tblClientLinkConfig.setIsActive(1);
    		tblClientLinkConfigs.add(tblClientLinkConfig);
    		success = clientService.addHideRegistrationLinkDetails(tblClientLinkConfigs, clientId, hideRegistrationLinkId);
    	} catch (Exception e) {
    		return exceptionHandlerService.writeLog(e);
		} finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), hideRegistrationLinkId, submitHideRegistrationLinkRemark, 0,clientId);
        }
    	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_hideRegistrationLink" : CommonKeywords.ERROR_MSG_KEY.toString());
    	retVal="redirect:/common/admin/hideRegistrationLink"+ encryptDecryptUtils.generateRedirect("common/admin/hideRegistrationLink", request);
    	return retVal;
    }
    
    @RequestMapping(value = "/admin/resetBidders/{clientId}/{enc}", method = RequestMethod.GET)
    public String resetBidders(@PathVariable(CLIENT_ID) int clientId,HttpServletRequest request, ModelMap modelMap){
    	try {
            Object[] obj=clientService.getClientFields(clientId,"domainName,deptId");
            String userId = String.valueOf(abcUtility.getSessionUserId(request));
            modelMap.addAttribute("domainName", obj[0]);
			modelMap.addAttribute(CLIENT_ID, clientId);
            Object[] bidderStatusCount = clientService.getBidderListForResetBidders(clientId);
            modelMap.addAttribute("lastActivityDate", clientService.getLastActivityDate(clientId));
            
            modelMap.addAttribute("clientId", clientId);
            modelMap.addAttribute("bidderStatusCount", bidderStatusCount);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), reset_bidder_link, getResetBiddersLinkRemark, 0,clientId);
        }
        return "/common/admin/ResetBidders";
    }
    
    @RequestMapping(value = "/admin/submitResetBidder", method = RequestMethod.POST)
    public String submitResetBidder(HttpServletRequest request, RedirectAttributes redirectAttributes){
    	boolean success = false;
    	int clientId = 0;
    	int userId = 0;
    	String retVal = "";
    	try {
    		clientId = Integer.parseInt(request.getParameter("hdClientId"));
    		userId = abcUtility.getSessionUserId(request);
    		clientService.ResetBidders(clientId, userId);
    	} catch (Exception e) {
    		return exceptionHandlerService.writeLog(e);
		} finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), reset_bidder_link, submitResetBiddersLinkRemark, 0,clientId);
        }
    	redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString() , "redirect_success_reset_bidder");
    	//retVal="redirect:/common/admin/resetBidders/"+clientId+ encryptDecryptUtils.generateRedirect("common/admin/resetBidders", request);
    	retVal="redirect:/"+ SEARCHCLIENTLIST_URL + encryptDecryptUtils.generateRedirect(SEARCHCLIENTLIST_URL, request);
    	return retVal;
    }
    /**
     * This method is used to add default config and manage terms & condition entry on client creation. For STQC
     * @author jitendra
     * @param clientId
     * @param userId
     * @param fromClientId
     * @return
     */
    private boolean addDefaultConfigAndTermsConditionEntry(int clientId, int userId, int fromClientId){
    	boolean success = false;
    	TblClientBidTerm tblClientBidTerm = null;
    	try {
    		List<Object[]> commonEvent = clientService.getCommonEventId(clientId,fromClientId);
    		if(commonEvent != null && !commonEvent.isEmpty()){
    			success = clientService.setParameterForClient(commonEvent, clientId, fromClientId, userId);
    		}
    		if(success){
    			List<Object[]> eventTypeList = manageContentService.getEventTypeByClientId(clientId);
            	List<Object[]> clientLanguageList = clientService.getClientLanguageToSelect(clientId);
        		int languageId = (clientLanguageList!=null && !clientLanguageList.isEmpty()) ? Integer.parseInt(clientLanguageList.get(0)[0].toString()) : 0;
        		if(eventTypeList != null && !eventTypeList.isEmpty() && languageId != 0){
            		List<TblClientBidTerm> tblClientBidTerms= new ArrayList<TblClientBidTerm>();
            		for(Object[] eventType : eventTypeList){
            			String bidTerm = messageSource.getMessage((Integer)eventType[0] == 1 ? "default_terms_and_conditions_auction" : "default_terms_and_conditions_other", null, LocaleContextHolder.getLocale());
            			tblClientBidTerm = new TblClientBidTerm();
            			tblClientBidTerm.setTblLanguage(new TblLanguage(languageId));
            			tblClientBidTerm.setBidTerm(bidTerm);
            			tblClientBidTerm.setTblEventType(new TblEventType((Integer)eventType[0]));
            			tblClientBidTerm.setCreatedBy(userId);
        				tblClientBidTerm.setIsActive(1);
        				tblClientBidTerm.setTblClient(new TblClient(clientId));
        				tblClientBidTerms.add(tblClientBidTerm);
            		}
            		success = manageContentService.addClientTermsCondition(tblClientBidTerms);
            	}
    		}
    	}catch (Exception e) {
    		exceptionHandlerService.writeLog(e);
    		success = false;
		}
		return success;
    }
}