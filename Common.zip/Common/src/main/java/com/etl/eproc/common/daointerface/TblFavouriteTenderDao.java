package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblFavouriteEvent;
import java.util.List;

public interface TblFavouriteTenderDao  {

    public void addTblFavouriteTender(TblFavouriteEvent tblFavouriteTender);

    public void deleteTblFavouriteTender(TblFavouriteEvent tblFavouriteTender);

    public void updateTblFavouriteTender(TblFavouriteEvent tblFavouriteTender);

    public List<TblFavouriteEvent> getAllTblFavouriteTender();

    public List<TblFavouriteEvent> findTblFavouriteTender(Object... values) throws Exception;

    public List<TblFavouriteEvent> findByCountTblFavouriteTender(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFavouriteTenderCount();

    public void saveUpdateAllTblFavouriteTender(List<TblFavouriteEvent> tblFavouriteTenders);
}