package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblContentMobile;
import com.etl.eproc.common.daointerface.TblContentMobileDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblContentMobileImpl extends AbcAbstractClass<TblContentMobile> implements TblContentMobileDao {

    @Override
    public void addTblContentMobile(TblContentMobile tblContentMobile){
        super.addEntity(tblContentMobile);
    }

    @Override
    public void deleteTblContentMobile(TblContentMobile tblContentMobile) {
        super.deleteEntity(tblContentMobile);
    }

    @Override
    public void updateTblContentMobile(TblContentMobile tblContentMobile) {
        super.updateEntity(tblContentMobile);
    }

    @Override
    public List<TblContentMobile> getAllTblContentMobile() {
        return super.getAllEntity();
    }

    @Override
    public List<TblContentMobile> findTblContentMobile(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblContentMobileCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblContentMobile> findByCountTblContentMobile(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblContentMobile(List<TblContentMobile> tblContentMobiles){
        super.updateAll(tblContentMobiles);
    }
}
