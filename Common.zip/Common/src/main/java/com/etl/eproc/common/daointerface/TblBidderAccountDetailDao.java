package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBidderAccountDetail;

public interface TblBidderAccountDetailDao  {

    public void addTblBidderAccountDetail(TblBidderAccountDetail tblBidderAccountDetail);

    public void deleteTblBidderAccountDetail(TblBidderAccountDetail tblBidderAccountDetail);

    public void updateTblBidderAccountDetail(TblBidderAccountDetail tblBidderAccountDetail);

    public List<TblBidderAccountDetail> getAllTblBidderAccountDetail();

    public List<TblBidderAccountDetail> findTblBidderAccountDetail(Object... values) throws Exception;

    public List<TblBidderAccountDetail> findByCountTblBidderAccountDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidderAccountDetailCount();

    public void saveUpdateAllTblBidderAccountDetail(List<TblBidderAccountDetail> tblBidderAccountDetails);
}