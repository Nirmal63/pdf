package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblNegotiationBidDetail;
import java.util.List;

public interface TblNegotiationBidDetailDao  {

    public void addTblNegotiationBidDetail(TblNegotiationBidDetail tblNegotiationBidDetail);

    public void deleteTblNegotiationBidDetail(TblNegotiationBidDetail tblNegotiationBidDetail);

    public void updateTblNegotiationBidDetail(TblNegotiationBidDetail tblNegotiationBidDetail);

    public List<TblNegotiationBidDetail> getAllTblNegotiationBidDetail();

    public List<TblNegotiationBidDetail> findTblNegotiationBidDetail(Object... values) throws Exception;

    public List<TblNegotiationBidDetail> findByCountTblNegotiationBidDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNegotiationBidDetailCount();

    public void saveUpdateAllTblNegotiationBidDetail(List<TblNegotiationBidDetail> tblNegotiationBidDetails);
}
