package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblPaymentITSDetail;
import com.etl.eproc.common.daointerface.TblPaymentITSDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblPaymentITSDetailImpl extends AbcAbstractClass<TblPaymentITSDetail> implements TblPaymentITSDetailDao {

    @Override
    public void addTblPaymentITSDetail(TblPaymentITSDetail tblPaymentITSDetail){
        super.addEntity(tblPaymentITSDetail);
    }

    @Override
    public void deleteTblPaymentITSDetail(TblPaymentITSDetail tblPaymentITSDetail) {
        super.deleteEntity(tblPaymentITSDetail);
    }

    @Override
    public void updateTblPaymentITSDetail(TblPaymentITSDetail tblPaymentITSDetail) {
        super.updateEntity(tblPaymentITSDetail);
    }

    @Override
    public List<TblPaymentITSDetail> getAllTblPaymentITSDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblPaymentITSDetail> findTblPaymentITSDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblPaymentITSDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblPaymentITSDetail> findByCountTblPaymentITSDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblPaymentITSDetail(List<TblPaymentITSDetail> tblPaymentITSDetails){
        super.updateAll(tblPaymentITSDetails);
    }
}
