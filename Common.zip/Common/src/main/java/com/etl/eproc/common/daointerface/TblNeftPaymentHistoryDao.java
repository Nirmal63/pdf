package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblNeftPaymentHistory;

/**
 *
 * @author hitesh.borsania
 */
 
public interface TblNeftPaymentHistoryDao {

    public void addTblNeftPaymentHistory(TblNeftPaymentHistory tblNeftPaymentHistory);

    public void deleteTblNeftPaymentHistory(TblNeftPaymentHistory tblNeftPaymentHistory);

    public void updateTblNeftPaymentHistory(TblNeftPaymentHistory tblNeftPaymentHistory);

    public List<TblNeftPaymentHistory> getAllTblNeftPaymentHistory();

    public List<TblNeftPaymentHistory> findTblNeftPaymentHistory(Object... values) throws Exception;

    public List<TblNeftPaymentHistory> findByCountTblNeftPaymentHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNeftPaymentHistoryCount();

    public void saveUpdateAllTblNeftPaymentHistory(List<TblNeftPaymentHistory> tblNeftPaymentHistorys);
    
    public void saveOrUpdateTblNeftPaymentHistory(TblNeftPaymentHistory tblNeftPaymentHistory);
}