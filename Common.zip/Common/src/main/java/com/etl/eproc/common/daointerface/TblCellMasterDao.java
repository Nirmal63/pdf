package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCellMaster;
import java.util.List;

public interface TblCellMasterDao  {

    public void addTblCellMaster(TblCellMaster tblCellMaster);

    public void deleteTblCellMaster(TblCellMaster tblCellMaster);

    public void updateTblCellMaster(TblCellMaster tblCellMaster);

    public List<TblCellMaster> getAllTblCellMaster();

    public List<TblCellMaster> findTblCellMaster(Object... values) throws Exception;

    public List<TblCellMaster> findByCountTblCellMaster(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCellMasterCount();

    public void saveUpdateAllTblCellMaster(List<TblCellMaster> tblCellMasters);
}