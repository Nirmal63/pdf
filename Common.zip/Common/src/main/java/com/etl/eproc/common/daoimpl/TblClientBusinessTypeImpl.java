package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblClientBusinessType;
import com.etl.eproc.common.daointerface.TblClientBusinessTypeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientBusinessTypeImpl extends AbcAbstractClass<TblClientBusinessType> implements TblClientBusinessTypeDao {

    @Override
    public void addTblClientBusinessType(TblClientBusinessType tblClientBusinessType){
        super.addEntity(tblClientBusinessType);
    }

    @Override
    public void deleteTblClientBusinessType(TblClientBusinessType tblClientBusinessType) {
        super.deleteEntity(tblClientBusinessType);
    }

    @Override
    public void updateTblClientBusinessType(TblClientBusinessType tblClientBusinessType) {
        super.updateEntity(tblClientBusinessType);
    }

    @Override
    public List<TblClientBusinessType> getAllTblClientBusinessType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientBusinessType> findTblClientBusinessType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientBusinessTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientBusinessType> findByCountTblClientBusinessType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientBusinessType(List<TblClientBusinessType> tblClientBusinessTypes){
        super.updateAll(tblClientBusinessTypes);
    }
}
