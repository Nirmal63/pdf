package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.etender.daointerface.TblEventCompletionDao;
import com.etl.eproc.etender.model.TblEventCompletion;


/**
*
* @author nitin
*/
@Repository @Transactional    /*StackUpdate*/
public class TblEventCompletionImpl extends AbcAbstractClass<TblEventCompletion> implements TblEventCompletionDao {

	    @Override
	    public void addTblEventCompletion(TblEventCompletion tblEventCompletion){
	        super.addEntity(tblEventCompletion);
	    }

	    @Override
	    public void deleteTblEventCompletion(TblEventCompletion tblEventCompletion) {
	        super.deleteEntity(tblEventCompletion);
	    }

	    @Override
	    public void updateTblEventCompletion(TblEventCompletion tblEventCompletion) {
	        super.updateEntity(tblEventCompletion);
	    }

	    @Override
	    public List<TblEventCompletion> getAllTblEventCompletion() {
	        return super.getAllEntity();
	    }

	    @Override
	    public List<TblEventCompletion> findTblEventCompletion(Object... values) throws Exception {
	        return super.findEntity(values);
	    }

	    @Override
	    public long getTblEventCompletionCount() {
	        return super.getEntityCount();
	    }

	    @Override
	    public List<TblEventCompletion> findByCountTblEventCompletion(int firstResult, int maxResult, Object... values) throws Exception {
	        return super.findByCountEntity(firstResult, maxResult, values);
	    }

	    @Override
	    public void saveUpdateAllTblEventCompletion(List<TblEventCompletion> tblEventCompletions){
	        super.updateAll(tblEventCompletions);
	    }
}
