package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblLanguage;
import java.util.List;

public interface TblLanguageDao  {

    public void addTblLanguage(TblLanguage tblLanguage);

    public void deleteTblLanguage(TblLanguage tblLanguage);

    public void updateTblLanguage(TblLanguage tblLanguage);

    public List<TblLanguage> getAllTblLanguage();

    public List<TblLanguage> findTblLanguage(Object... values) throws Exception;

    public List<TblLanguage> findByCountTblLanguage(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblLanguageCount();

    public void saveUpdateAllTblLanguage(List<TblLanguage> tblLanguages);
}