package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblClientRegDocDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblClientRegDoc;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientRegDocImpl extends AbcAbstractClass<TblClientRegDoc> implements TblClientRegDocDao {

    @Override
    public void addTblClientRegDoc(TblClientRegDoc tblClientRegDoc){
        super.addEntity(tblClientRegDoc);
    }

    @Override
    public void deleteTblClientRegDoc(TblClientRegDoc tblClientRegDoc) {
        super.deleteEntity(tblClientRegDoc);
    }

    @Override
    public void updateTblClientRegDoc(TblClientRegDoc tblClientRegDoc) {
        super.updateEntity(tblClientRegDoc);
    }

    @Override
    public List<TblClientRegDoc> getAllTblClientRegDoc() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientRegDoc> findTblClientRegDoc(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientRegDocCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientRegDoc> findByCountTblClientRegDoc(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientRegDoc(List<TblClientRegDoc> tblClientRegDocs){
        super.updateAll(tblClientRegDocs);
    }
}
