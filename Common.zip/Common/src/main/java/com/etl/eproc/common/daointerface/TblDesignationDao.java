package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDesignation;
import java.util.List;

public interface TblDesignationDao  {

    public void addTblDesignation(TblDesignation tblDesignation);

    public void deleteTblDesignation(TblDesignation tblDesignation);

    public void updateTblDesignation(TblDesignation tblDesignation);

    public List<TblDesignation> getAllTblDesignation();

    public List<TblDesignation> findTblDesignation(Object... values) throws Exception;

    public List<TblDesignation> findByCountTblDesignation(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDesignationCount();

    public void saveUpdateAllTblDesignation(List<TblDesignation> tblDesignations);
}