package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblKeyword;
import java.util.List;

public interface TblKeywordDao  {

    public void addTblKeyword(TblKeyword tblKeyword);

    public void deleteTblKeyword(TblKeyword tblKeyword);

    public void updateTblKeyword(TblKeyword tblKeyword);

    public List<TblKeyword> getAllTblKeyword();

    public List<TblKeyword> findTblKeyword(Object... values) throws Exception;

    public List<TblKeyword> findByCountTblKeyword(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblKeywordCount();

    public void saveUpdateAllTblKeyword(List<TblKeyword> tblKeywords);
}