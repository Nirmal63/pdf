package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblMaterialMaster;
import com.etl.eproc.common.daointerface.TblMaterialMasterDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMaterialMasterImpl extends AbcAbstractClass<TblMaterialMaster> implements TblMaterialMasterDao {

    @Override
    @Transactional(propagation=Propagation.REQUIRED,rollbackFor={Exception.class})
    public void addTblMaterialMaster(TblMaterialMaster tblMaterialMaster){
        super.addEntity(tblMaterialMaster);
    }

    @Override
    public void deleteTblMaterialMaster(TblMaterialMaster tblMaterialMaster) {
        super.deleteEntity(tblMaterialMaster);
    }

    @Override
    public void updateTblMaterialMaster(TblMaterialMaster tblMaterialMaster) {
        super.updateEntity(tblMaterialMaster);
    }

    @Override
    public List<TblMaterialMaster> getAllTblMaterialMaster() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMaterialMaster> findTblMaterialMaster(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMaterialMasterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMaterialMaster> findByCountTblMaterialMaster(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMaterialMaster(List<TblMaterialMaster> tblMaterialMasters){
        super.updateAll(tblMaterialMasters);
    }
}
