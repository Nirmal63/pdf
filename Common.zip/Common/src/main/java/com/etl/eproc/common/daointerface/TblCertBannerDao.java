package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCertBanner;
import java.util.List;

public interface TblCertBannerDao  {

    public void addTblCertBanner(TblCertBanner tblCertBanner);

    public void deleteTblCertBanner(TblCertBanner tblCertBanner);

    public void updateTblCertBanner(TblCertBanner tblCertBanner);

    public List<TblCertBanner> getAllTblCertBanner();

    public List<TblCertBanner> findTblCertBanner(Object... values) throws Exception;

    public List<TblCertBanner> findByCountTblCertBanner(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCertBannerCount();

    public void saveUpdateAllTblCertBanner(List<TblCertBanner> tblCertBanners);
}