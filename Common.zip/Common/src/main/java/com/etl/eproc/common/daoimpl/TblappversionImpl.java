package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.Tblappversion;
import com.etl.eproc.common.daointerface.TblappversionDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblappversionImpl extends AbcAbstractClass<Tblappversion> implements TblappversionDao {

    @Override
    public void addTblappversion(Tblappversion tblappversion){
        super.addEntity(tblappversion);
    }

    @Override
    public void deleteTblappversion(Tblappversion tblappversion) {
        super.deleteEntity(tblappversion);
    }

    @Override
    public void updateTblappversion(Tblappversion tblappversion) {
        super.updateEntity(tblappversion);
    }

    @Override
    public List<Tblappversion> getAllTblappversion() {
        return super.getAllEntity();
    }

    @Override
    public List<Tblappversion> findTblappversion(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblappversionCount() {
        return super.getEntityCount();
    }

    @Override
    public List<Tblappversion> findByCountTblappversion(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblappversion(List<Tblappversion> tblappversions){
        super.updateAll(tblappversions);
    }

	@Override
	public void saveOrUpdateTblappversion(Tblappversion tblappversion) {
		super.saveOrUpdateEntity(tblappversion);
		
	}
}
