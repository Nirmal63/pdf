package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblComboDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblComboDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblComboDetailImpl extends AbcAbstractClass<TblComboDetail> implements TblComboDetailDao {

    @Override
    public void addTblComboDetail(TblComboDetail tblComboDetail){
        super.addEntity(tblComboDetail);
    }

    @Override
    public void deleteTblComboDetail(TblComboDetail tblComboDetail) {
        super.deleteEntity(tblComboDetail);
    }

    @Override
    public void updateTblComboDetail(TblComboDetail tblComboDetail) {
        super.updateEntity(tblComboDetail);
    }

    @Override
    public List<TblComboDetail> getAllTblComboDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblComboDetail> findTblComboDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblComboDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblComboDetail> findByCountTblComboDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblComboDetail(List<TblComboDetail> tblComboDetails){
        super.updateAll(tblComboDetails);
    }
}
