package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblActivityMaster;

public interface TblActivityMasterDao {

    public void addTblActivityMaster(TblActivityMaster tblActivityMaster);

    public void deleteTblActivityMaster(TblActivityMaster tblActivityMaster);

    public void updateTblActivityMaster(TblActivityMaster tblActivityMaster);

    public List<TblActivityMaster> getAllTblActivityMaster();

    public List<TblActivityMaster> findTblActivityMaster(Object... values) throws Exception;

    public List<TblActivityMaster> findByCountTblActivityMaster(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblActivityMasterCount();
}