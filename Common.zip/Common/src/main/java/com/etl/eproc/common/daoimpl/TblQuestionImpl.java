/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

/**
 *
 * @author darshan
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblQuestionDao;
import com.etl.eproc.common.model.TblQuestion;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblQuestionImpl extends AbcAbstractClass<TblQuestion> implements TblQuestionDao {

    @Override
    public void addTblQuestion(TblQuestion tblQuestion) {
	super.addEntity(tblQuestion);
    }

    @Override
    public void deleteTblQuestion(TblQuestion tblQuestion) {
	super.deleteEntity(tblQuestion);
    }

    @Override
    public void updateTblQuestion(TblQuestion tblQuestion) {
	super.updateEntity(tblQuestion);
    }

    @Override
    public List<TblQuestion> getAllTblQuestion() {
	return super.getAllEntity();
    }

    @Override
    public List<TblQuestion> findTblQuestion(Object... values) throws Exception {
	return super.findEntity(values);
    }

    @Override
    public long getTblQuestionCount() {
	return super.getEntityCount();
    }

    @Override
    public List<TblQuestion> findByCountTblQuestion(int firstResult, int maxResult, Object... values) throws Exception {
	return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblQuestion(List<TblQuestion> tblQuestions) {
	super.updateAll(tblQuestions);
    }

	@Override
	public void saveOrUpdateTblQuestion(TblQuestion tblquestion) {
		super.saveOrUpdateEntity(tblquestion);
	}
}