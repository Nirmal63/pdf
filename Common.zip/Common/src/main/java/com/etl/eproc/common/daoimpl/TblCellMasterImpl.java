package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblCellMaster;
import com.etl.eproc.common.daointerface.TblCellMasterDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCellMasterImpl extends AbcAbstractClass<TblCellMaster> implements TblCellMasterDao {

    @Override
    public void addTblCellMaster(TblCellMaster tblCellMaster){
        super.addEntity(tblCellMaster);
    }

    @Override
    public void deleteTblCellMaster(TblCellMaster tblCellMaster) {
        super.deleteEntity(tblCellMaster);
    }

    @Override
    public void updateTblCellMaster(TblCellMaster tblCellMaster) {
        super.updateEntity(tblCellMaster);
    }

    @Override
    public List<TblCellMaster> getAllTblCellMaster() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCellMaster> findTblCellMaster(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCellMasterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCellMaster> findByCountTblCellMaster(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCellMaster(List<TblCellMaster> tblCellMasters){
        super.updateAll(tblCellMasters);
    }
}
