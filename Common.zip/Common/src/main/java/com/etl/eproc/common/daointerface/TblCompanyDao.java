package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCompany;
import java.util.List;

public interface TblCompanyDao  {

    public void addTblCompany(TblCompany tblCompany);

    public void deleteTblCompany(TblCompany tblCompany);

    public void updateTblCompany(TblCompany tblCompany);

    public List<TblCompany> getAllTblCompany();

    public List<TblCompany> findTblCompany(Object... values) throws Exception;

    public List<TblCompany> findByCountTblCompany(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCompanyCount();

    public void saveUpdateAllTblCompany(List<TblCompany> tblCompanys);

	public void saveOrUpdateTblCompany(TblCompany tblCompany);
}