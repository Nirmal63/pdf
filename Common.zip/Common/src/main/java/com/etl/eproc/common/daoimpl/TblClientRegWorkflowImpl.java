package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblClientRegWorkflowDao;
import com.etl.eproc.common.model.TblClientRegWorkflow;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientRegWorkflowImpl extends AbcAbstractClass<TblClientRegWorkflow> implements TblClientRegWorkflowDao {

    @Override
    public void addTblClientRegWorkflow(TblClientRegWorkflow tblClientRegWorkflow){
        super.addEntity(tblClientRegWorkflow);
    }

    @Override
    public void deleteTblClientRegWorkflow(TblClientRegWorkflow tblClientRegWorkflow) {
        super.deleteEntity(tblClientRegWorkflow);
    }

    @Override
    public void updateTblClientRegWorkflow(TblClientRegWorkflow tblClientRegWorkflow) {
        super.updateEntity(tblClientRegWorkflow);
    }

    @Override
    public List<TblClientRegWorkflow> getAllTblClientRegWorkflow() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientRegWorkflow> findTblClientRegWorkflow(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientRegWorkflowCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientRegWorkflow> findByCountTblClientRegWorkflow(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientRegWorkflow(List<TblClientRegWorkflow> tblClientRegWorkflows){
        super.updateAll(tblClientRegWorkflows);
    }
}