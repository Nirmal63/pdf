package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblBankMaster;
import com.etl.eproc.common.daointerface.TblBankMasterDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBankMasterImpl extends AbcAbstractClass<TblBankMaster> implements TblBankMasterDao {

    @Override
    public void addTblBankMaster(TblBankMaster tblBankMaster){
        super.addEntity(tblBankMaster);
    }

    @Override
    public void deleteTblBankMaster(TblBankMaster tblBankMaster) {
        super.deleteEntity(tblBankMaster);
    }

    @Override
    public void updateTblBankMaster(TblBankMaster tblBankMaster) {
        super.updateEntity(tblBankMaster);
    }

    @Override
    public List<TblBankMaster> getAllTblBankMaster() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBankMaster> findTblBankMaster(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBankMasterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBankMaster> findByCountTblBankMaster(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBankMaster(List<TblBankMaster> tblBankMasters){
        super.updateAll(tblBankMasters);
    }
}
