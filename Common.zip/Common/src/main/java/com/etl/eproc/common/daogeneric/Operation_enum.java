package com.etl.eproc.common.daogeneric;

/*
 * @author TaherT
 */
public enum Operation_enum {

   NE, EQ, LT, GT, LE, GE, LIKE, OR, IN, ORDERBY, ASC, DESC
}
