package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblHelp;
import java.util.List;

public interface TblHelpDao  {

    public void addTblHelp(TblHelp tblHelp);

    public void deleteTblHelp(TblHelp tblHelp);

    public void updateTblHelp(TblHelp tblHelp);

    public List<TblHelp> getAllTblHelp();

    public List<TblHelp> findTblHelp(Object... values) throws Exception;

    public List<TblHelp> findByCountTblHelp(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblHelpCount();

    public void saveUpdateAllTblHelp(List<TblHelp> tblHelps);
}