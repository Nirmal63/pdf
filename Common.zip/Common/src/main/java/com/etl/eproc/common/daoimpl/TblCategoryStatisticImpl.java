package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblCategoryStatistic;
import com.etl.eproc.common.daointerface.TblCategoryStatisticDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCategoryStatisticImpl extends AbcAbstractClass<TblCategoryStatistic> implements TblCategoryStatisticDao {

    @Override
    public void addTblCategoryStatistic(TblCategoryStatistic tblCategoryStatistic){
        super.addEntity(tblCategoryStatistic);
    }

    @Override
    public void deleteTblCategoryStatistic(TblCategoryStatistic tblCategoryStatistic) {
        super.deleteEntity(tblCategoryStatistic);
    }

    @Override
    public void updateTblCategoryStatistic(TblCategoryStatistic tblCategoryStatistic) {
        super.updateEntity(tblCategoryStatistic);
    }

    @Override
    public List<TblCategoryStatistic> getAllTblCategoryStatistic() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCategoryStatistic> findTblCategoryStatistic(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCategoryStatisticCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCategoryStatistic> findByCountTblCategoryStatistic(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCategoryStatistic(List<TblCategoryStatistic> tblCategoryStatistics){
        super.updateAll(tblCategoryStatistics);
    }
}
