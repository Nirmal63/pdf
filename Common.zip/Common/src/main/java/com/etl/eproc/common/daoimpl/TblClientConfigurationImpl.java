package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblClientConfiguration;
import com.etl.eproc.common.daointerface.TblClientConfigurationDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *

 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientConfigurationImpl extends AbcAbstractClass<TblClientConfiguration> implements TblClientConfigurationDao {

    @Override
    public void addTblClientConfiguration(TblClientConfiguration tblClientConfiguration){
        super.addEntity(tblClientConfiguration);
    }

    @Override
    public void deleteTblClientConfiguration(TblClientConfiguration tblClientConfiguration) {
        super.deleteEntity(tblClientConfiguration);
    }

    @Override
    public void updateTblClientConfiguration(TblClientConfiguration tblClientConfiguration) {
        super.updateEntity(tblClientConfiguration);
    }

    @Override
    public List<TblClientConfiguration> getAllTblClientConfiguration() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientConfiguration> findTblClientConfiguration(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientConfigurationCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientConfiguration> findByCountTblClientConfiguration(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientConfiguration(List<TblClientConfiguration> tblClientConfigurations){
        super.updateAll(tblClientConfigurations);
    }
}
