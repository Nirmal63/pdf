package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientRule;
import java.util.List;

public interface TblClientRuleDao  {

    public void addTblClientRule(TblClientRule tblClientRule);

    public void deleteTblClientRule(TblClientRule tblClientRule);

    public void updateTblClientRule(TblClientRule tblClientRule);

    public List<TblClientRule> getAllTblClientRule();

    public List<TblClientRule> findTblClientRule(Object... values) throws Exception;

    public List<TblClientRule> findByCountTblClientRule(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientRuleCount();

    public void saveUpdateAllTblClientRule(List<TblClientRule> tblClientRules);
}
