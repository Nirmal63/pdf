package com.etl.eproc.common.daoimpl;

import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.HibernateQueryDao;

/*
 * @author TaherT
 */
@Repository @Transactional    /*StackUpdate*/
public class HibernateQueryImpl extends AbcAbstractClass<Object> implements HibernateQueryDao {

	//GenericDao methods implementation
	@Override
	public List<Object[]> createQuery(String query,Map<String,Object> var){
		return super.createQuery(query, var);
	}
	
	@Override
	public List<Object[]> createSQLQuery(String query,Map<String,Object> var){
		return super.createSQLQuery(query, var);
	}
    
	@Override
    public List<Object[]> createSQLQuery(String query, Map<String, Object> var,int[] ncharsIndex,int colcount) {
    	return super.createSQLQuery(query, var, ncharsIndex, colcount);
    }

	/*
	 * @Override public List<Object[]> createByCountQuery(String query,
	 * Map<String,Object> var,int firstResult, int maxResult) { return
	 * super.createByCountQuery(query, var, firstResult, maxResult); }
	 */

    @Override
    public long countForQuery(String from,String countOn, String where,Map<String,Object> var) {
    	return super.countForQuery(from, countOn, where, var);
    }

    @Override
    public List<Object> singleColQuery(String query,Map<String,Object> var){
    	return super.singleColQuery(query, var);
    }

    @Override
    public int updateDeleteQuery(String query,Map<String,Object> var) {
    	return super.updateDeleteQuery(query, var);
    }

    @Override
    public int updateDeleteSQLQuery(String query,Map<String,Object> var) {
    	return super.updateDeleteSQLQuery(query, var);
    }
    
    @Override
    public List nativeQueryToBean(String query, Class classAlias, Map<String, Object> var) throws DataAccessResourceFailureException, HibernateException, IllegalStateException, ClassNotFoundException {
    	return super.nativeQueryToBean(query, classAlias, var);
    }
    
    @Override
    public List<Object[]> createQueryForGmr(String query, Map<String, Object> var) {
    	return super.createQueryForGmr(query, var);
    }
	
	//Existing methods implementation
	@Override
    public List<Object[]> createNewQuery(String query, Map<String, Object> var) {
        return super.createQuery(query, var);
    }

	/*
	 * @Override public List<Object[]> createByCountNewQuery(String query,
	 * Map<String,Object> var,int firstResult, int maxResult) { return
	 * super.createByCountQuery(query, var,firstResult, maxResult); }
	 */

    @Override
    public long countForNewQuery(String from,String countOn, String where,Map<String,Object> var) throws Exception {
        return super.countForQuery(from,countOn,where,var);
    }

    @Override
    public List<Object> getSingleColQuery(String query,Map<String,Object> var) {
        return super.singleColQuery(query,var);
    }

    @Override
    public int updateDeleteNewQuery(String query,Map<String,Object> var) {
        return super.updateDeleteQuery(query,var);
    }

    @Override
    public int updateDeleteSQLNewQuery(String query,Map<String,Object> var) {
        return super.updateDeleteSQLQuery(query,var);
    }
  
    @Override
    public List<Object[]> nativeSQLQuery(String query, Map<String, Object> var) {
        return super.createSQLQuery(query,var);
    }  
    
    @Override
    public List nativeNewQueryToBean(String query, Class classAlias, Map<String, Object> var) throws DataAccessResourceFailureException, HibernateException, IllegalStateException, ClassNotFoundException{
        return super.nativeQueryToBean(query, classAlias, var);
    }



}
