package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblRZPPaymentDao;
import com.etl.eproc.common.model.TblRZPPayment;

/**
 *
 * @author rinju
 */
@Repository @Transactional    /*StackUpdate*/
public class TblRZPPaymentImpl extends AbcAbstractClass<TblRZPPayment> implements TblRZPPaymentDao {

    @Override
    public void addTblRZPPayment(TblRZPPayment tblRZPPayment){
        super.addEntity(tblRZPPayment);
    }

    @Override
    public void deleteTblRZPPayment(TblRZPPayment tblRZPPayment) {
        super.deleteEntity(tblRZPPayment);
    }

    @Override
    public void updateTblRZPPayment(TblRZPPayment tblRZPPayment) {
        super.updateEntity(tblRZPPayment);
    }

    @Override
    public List<TblRZPPayment> getAllTblRZPPayment() {
        return super.getAllEntity();
    }

    @Override
    public List<TblRZPPayment> findTblRZPPayment(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblRZPPaymentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblRZPPayment> findByCountTblRZPPayment(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblRZPPayment(List<TblRZPPayment> tblRZPPayments){
        super.updateAll(tblRZPPayments);
    }
}
