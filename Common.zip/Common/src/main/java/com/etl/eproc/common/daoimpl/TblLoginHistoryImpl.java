package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblLoginHistory;
import com.etl.eproc.common.daointerface.TblLoginHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblLoginHistoryImpl extends AbcAbstractClass<TblLoginHistory> implements TblLoginHistoryDao {


    @Override
    public void addTblLoginHistory(TblLoginHistory tblLoginHistory){
        super.addEntity(tblLoginHistory);
    }

    @Override
    public void deleteTblLoginHistory(TblLoginHistory tblLoginHistory) {
        super.deleteEntity(tblLoginHistory);
    }

    @Override
    public void updateTblLoginHistory(TblLoginHistory tblLoginHistory) {
        super.updateEntity(tblLoginHistory);
    }

    @Override
    public List<TblLoginHistory> getAllTblLoginHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblLoginHistory> findTblLoginHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblLoginHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblLoginHistory> findByCountTblLoginHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblLoginHistory(List<TblLoginHistory> tblLoginHistorys){
        super.updateAll(tblLoginHistorys);
    }
}
