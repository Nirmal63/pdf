package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblAdditionalEmailConfDao;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblAdditionalEmailConf;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblAdditionalEmailConfImpl extends AbcAbstractClass<TblAdditionalEmailConf> implements TblAdditionalEmailConfDao {

    
    @Override
    public void addTblAdditionalEmailConf(TblAdditionalEmailConf tblAdditionalEmailConf){
        super.addEntity(tblAdditionalEmailConf);
    }

    @Override
    public void deleteTblAdditionalEmailConf(TblAdditionalEmailConf tblAdditionalEmailConf) {
        super.deleteEntity(tblAdditionalEmailConf);
    }

    @Override
    public void updateTblAdditionalEmailConf(TblAdditionalEmailConf tblAdditionalEmailConf) {
        super.updateEntity(tblAdditionalEmailConf);
    }

    @Override
    public List<TblAdditionalEmailConf> getAllTblAdditionalEmailConf() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAdditionalEmailConf> findTblAdditionalEmailConf(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAdditionalEmailConfCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAdditionalEmailConf> findByCountTblAdditionalEmailConf(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAdditionalEmailConf(List<TblAdditionalEmailConf> tblAdditionalEmailConfs){
        super.updateAll(tblAdditionalEmailConfs);
    }
}
