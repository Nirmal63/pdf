package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblExemptionCertConf;
import java.util.List;

public interface TblExemptionCertConfDao  {

    public void addTblExemptionCertConf(TblExemptionCertConf tblExemptionCertConf);

    public void deleteTblExemptionCertConf(TblExemptionCertConf tblExemptionCertConf);

    public void updateTblExemptionCertConf(TblExemptionCertConf tblExemptionCertConf);

    public List<TblExemptionCertConf> getAllTblExemptionCertConf();

    public List<TblExemptionCertConf> findTblExemptionCertConf(Object... values) throws Exception;

    public List<TblExemptionCertConf> findByCountTblExemptionCertConf(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblExemptionCertConfCount();

    public void saveUpdateAllTblExemptionCertConf(List<TblExemptionCertConf> tblExemptionCertConfs);
}