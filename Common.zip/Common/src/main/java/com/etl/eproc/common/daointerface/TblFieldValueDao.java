package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.common.model.TblFieldValue;

public interface TblFieldValueDao  {

    public void addTblFieldValue(TblFieldValue tblFieldValue);

    public void deleteTblFieldValue(TblFieldValue tblFieldValue);

    public void updateTblFieldValue(TblFieldValue tblFieldValue);

    public List<TblFieldValue> getAllTblFieldValue();

    public List<TblFieldValue> findTblFieldValue(Object... values) throws Exception;

    public List<TblFieldValue> findByCountTblFieldValue(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFieldValueCount();

    public void saveUpdateAllTblFieldValue(List<TblFieldValue> tblFieldValues);
}