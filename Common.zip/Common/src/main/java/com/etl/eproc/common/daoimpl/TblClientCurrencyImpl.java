package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblClientCurrencyDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblClientCurrency;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientCurrencyImpl extends AbcAbstractClass<TblClientCurrency> implements TblClientCurrencyDao {


    @Override
    public void addTblClientCurrency(TblClientCurrency tblClientCurrency){
        super.addEntity(tblClientCurrency);
    }

    @Override
    public void deleteTblClientCurrency(TblClientCurrency tblClientCurrency) {
        super.deleteEntity(tblClientCurrency);
    }

    @Override
    public void updateTblClientCurrency(TblClientCurrency tblClientCurrency) {
        super.updateEntity(tblClientCurrency);
    }

    @Override
    public List<TblClientCurrency> getAllTblClientCurrency() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientCurrency> findTblClientCurrency(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientCurrencyCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientCurrency> findByCountTblClientCurrency(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientCurrency(List<TblClientCurrency> tblClientCurrencys){
        super.updateAll(tblClientCurrencys);
    }
}
