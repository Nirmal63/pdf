package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblContentManagement;
import java.util.List;

public interface TblContentManagementDao  {

    public void addTblContentManagement(TblContentManagement tblContentManagement);

    public void deleteTblContentManagement(TblContentManagement tblContentManagement);

    public void updateTblContentManagement(TblContentManagement tblContentManagement);

    public List<TblContentManagement> getAllTblContentManagement();

    public List<TblContentManagement> findTblContentManagement(Object... values) throws Exception;

    public List<TblContentManagement> findByCountTblContentManagement(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblContentManagementCount();

    public void saveUpdateAllTblContentManagement(List<TblContentManagement> tblContentManagements);
}