package com.etl.eproc.common.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblProduct;
import com.etl.eproc.common.model.TblProductCategory;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ManageItemService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;

@Controller
@RequestMapping(value = "/common")
public class ItemCreationController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private ManageItemService manageItemService;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private AbcUtility abcUtility;
    @Value("#{linkProperties['manage_product_create_product']?:42}")
    private int createProductLinkId;
    @Value("#{linkProperties['manage_product_edit_product']?:43}")
    private int editProductLinkId;
    @Value("#{linkProperties['report_admin_manage_product']?:7}")
    private int manageProductReportId;
    private static final String ROWCNT = "txtRowCnt";
    private static final String CLIENTID = "hdClientId";
    private static final String CATEGORY = "txtCategory";
    @Value("#{adminAuditTrailProperties['getCreateProductPage']}")
    private String getCreateProductPage;
    @Value("#{adminAuditTrailProperties['getManageProductPage']}")
    private String getManageProductPage;
    @Value("#{adminAuditTrailProperties['postProductAdd']}")
    private String postProductAdd;
    @Value("#{adminAuditTrailProperties['getEditProductPage']}")
    private String getEditProductPage;
    @Value("#{adminAuditTrailProperties['postProductUpdated']}")
    private String postProductUpdated;

    /**
     * to display create product JSP Page
     *
     * @param response
     * @param request
     * @return String
     */
    @RequestMapping(value = "/admin/createitem/{enc}", method = RequestMethod.GET)
    public String createItem(HttpServletRequest request) {
        String retVal = null;
        try {
        	request.setAttribute("clientId", abcUtility.getSessionClientId(request));
            retVal = "common/admin/CreateItem";
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createProductLinkId, getCreateProductPage, 0, 0);
        }
        return retVal;
    }

    /**
     * to display manage product page
     *
     * @param modelMap
     * @param response
     * @param request
     * @return String
     */
    @RequestMapping(value = "/admin/manageitems/{enc}", method = RequestMethod.GET)
    public String manageItems(ModelMap modelMap, HttpServletRequest request) {
        String retVal = null;
        try {
            //int reportId = 7;
            modelMap.addAttribute("reportId", manageProductReportId);
            reportGeneratorService.getReportConfigDetails(manageProductReportId, modelMap);
            retVal = "common/admin/ManageItems";
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getManageProductPage, 0, 0);
        }
        return retVal;
    }

    /**
     * to add product
     *
     * @param map
     * @param redirectAttributes
     * @param request
     * @return String
     */
    @RequestMapping(value = "/admin/addproduct", method = RequestMethod.POST)
    public String addProduct(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        String retVal = null;
        int cnt = 0;
        int clientId = 0;
        int categoryId = 0;
        TblProduct tblProduct = null;
        boolean valid = true;
        boolean isDuplicate=false;
        try {
            List<TblProduct> tblProductList = new ArrayList<TblProduct>();
            cnt = StringUtils.hasLength(request.getParameter(ROWCNT)) ? Integer.parseInt(request.getParameter(ROWCNT)) : 0;
            clientId = StringUtils.hasLength(request.getParameter(CLIENTID)) ? Integer.parseInt(request.getParameter(CLIENTID)) : 0;
            categoryId = StringUtils.hasLength(request.getParameter(CATEGORY)) ? Integer.parseInt(request.getParameter(CATEGORY)) : 0;
            String[] productName = request.getParameterValues("txtaProductName");
            String[] productCode = request.getParameterValues("txtProductCode");
            String[] productDesc = request.getParameterValues("txtaProductDesc");
            StringBuilder tempProducts = new StringBuilder();
            for (int i = 0; i < cnt; i++) {
                tempProducts.append(productName[i]).append(",");
                if (productDesc[i] == null || "".equals(productDesc[i]) || productName[i] == null || "".equals(productName[i]) || productCode[i] == null || "".equals(productCode[i]) || categoryId == 0) {
                    valid = false;
                    break;
                }/*else{
                 isDuplicate=commonService.checkUniqueProductName(categoryId, productName[i],null);
                 if(isDuplicate){
                 break;
                 }
                 }*/
            }
            if (!valid) {
                retVal = "redirect:/common/admin/createitem" + encryptDecryptUtils.generateRedirect("common/admin/createitem", request);
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
            } else if (commonService.checkUniqueProductName(categoryId, tempProducts.substring(0, tempProducts.length() - 1), null)) {
                retVal = "redirect:/common/admin/createitem" + encryptDecryptUtils.generateRedirect("common/admin/createitem", request);
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_productlreadyexists");
            } else {
            	List<String> uniqueProductChk = new ArrayList<String>();
                for (int i = 0; i < cnt; i++) {
                	
                	if(uniqueProductChk.contains(productName[i]))
                	{
                		isDuplicate = true;
                		retVal = "redirect:/common/admin/createitem" + encryptDecryptUtils.generateRedirect("common/admin/createitem", request);
                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_productlreadyexists");
                        break;
					} else {
						isDuplicate=commonService.checkUniqueProductName(categoryId, productName[i],null);
						if(isDuplicate)
						{
							retVal = "redirect:/common/admin/createitem" + encryptDecryptUtils.generateRedirect("common/admin/createitem", request);
	                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_productlreadyexists");
	                        break;
						}	
                		uniqueProductChk.add(productName[i]);
                	}	
                    tblProduct = new TblProduct();
                    tblProduct.setCreatedBy(abcUtility.getSessionUserId(request));
                    tblProduct.setIsActive(1);
                    tblProduct.setTblClient(new TblClient(clientId));
                    tblProduct.setProductName(productName[i]);
                    tblProduct.setProductCode(productCode[i]);
                    tblProduct.setTblProductCategory(new TblProductCategory(categoryId));
                    tblProduct.setProductDescription(productDesc[i]);
                    tblProductList.add(tblProduct);
                }
                if(!isDuplicate)
                {
                	success = manageItemService.addProduct(tblProductList);
                	redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_addproduct" : CommonKeywords.ERROR_MSG_KEY.toString());
                    if (success) {
                        retVal = "redirect:/common/admin/manageitems" + encryptDecryptUtils.generateRedirect("common/admin/manageitems", request);
                    } else {
                        retVal = "redirect:/common/admin/createitem" + encryptDecryptUtils.generateRedirect("common/admin/createitem", request);
                    }
                }	
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createProductLinkId, postProductAdd, 0, clientId);
        }
        return retVal;
    }

    /**
     * to get edit product page
     *
     * @param categoryId
     * @param modelMap
     * @param response
     * @param request
     * @param session
     * @return String
     */
    @RequestMapping(value = "/admin/editproduct/{productId}/{enc}", method = RequestMethod.GET)
    public String getEditProduct(@PathVariable("productId") int productId, ModelMap modelMap, HttpServletRequest request) {
        try {
            request.setAttribute("clientId", abcUtility.getSessionClientId(request));
            TblProduct product = manageItemService.getProductById(productId);
            modelMap.addAttribute("product", product);
            modelMap.addAttribute("categoryId", product.getTblProductCategory().getCategoryId());
            modelMap.addAttribute("oprType", "edit");
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editProductLinkId, getEditProductPage, 0, productId);
        }
        return "common/admin/CreateProduct";
    }

    /**
     * to update Product
     *
     * @param map
     * @param redirectAttributes
     * @param request
     * @return String
     */
    @RequestMapping(value = "/admin/updateproductetails", method = RequestMethod.POST)
    public String updateProduct(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        String retVal = null;
        int clientId = 0;
        int categoryId = 0;
        TblProduct tblProduct = null;
        int productId = 0;
        try {
            clientId = StringUtils.hasLength(request.getParameter(CLIENTID)) ? Integer.parseInt(request.getParameter(CLIENTID)) : 0;
            categoryId = StringUtils.hasLength(request.getParameter(CATEGORY)) ? Integer.parseInt(request.getParameter(CATEGORY)) : 0;
            productId = StringUtils.hasLength(request.getParameter("hdProductId")) ? Integer.parseInt(request.getParameter("hdProductId")) : 0;
            String productName = request.getParameter("txtaProductName");
            String productCode = request.getParameter("txtProductCode");
            String productDesc = request.getParameter("txtaProductDesc");
            if (productDesc == null || "".equals(productDesc) || productName == null || "".equals(productName) || productCode == null || "".equals(productCode) || categoryId == 0) {
                //valid=false;
                retVal = "redirect:/common/admin/editproduct/" + categoryId + encryptDecryptUtils.generateRedirect("common/admin/editproduct/" + categoryId, request);
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
            } else if (commonService.checkUniqueProductName(categoryId, productName, String.valueOf(productId))) {
                //valid=false;
                retVal = "redirect:/common/admin/editproduct/" + categoryId + encryptDecryptUtils.generateRedirect("common/admin/editproduct/" + categoryId, request);
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_productlreadyexists");
            } else {
                tblProduct = new TblProduct();
                if (productId != 0) {
                    tblProduct.setProductId(productId);
                }
                tblProduct.setCreatedBy(abcUtility.getSessionUserId(request));
                tblProduct.setIsActive(1);
                tblProduct.setTblClient(new TblClient(clientId));
                tblProduct.setProductName(productName);
                tblProduct.setProductCode(productCode);
                tblProduct.setTblProductCategory(new TblProductCategory(categoryId));
                tblProduct.setProductDescription(productDesc);
                success = manageItemService.updateProduct(tblProduct);
                redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_updateproduct" : CommonKeywords.ERROR_MSG_KEY.toString());
                if (success) {
                    retVal = "redirect:/common/admin/manageitems" + encryptDecryptUtils.generateRedirect("common/admin/manageitems", request);
                } else {
                    retVal = "redirect:/common/admin/editproduct/" + productId + encryptDecryptUtils.generateRedirect("common/admin/editproduct/" + productId, request);
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editProductLinkId, postProductUpdated, 0, productId);
        }
        return retVal;
    }
}
