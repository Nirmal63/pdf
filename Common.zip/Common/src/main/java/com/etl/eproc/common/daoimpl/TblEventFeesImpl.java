package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblEventFeesDao;
import com.etl.eproc.etender.model.TblEventFees;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblEventFeesImpl extends AbcAbstractClass<TblEventFees> implements TblEventFeesDao {

    @Override
    public void addTblTenderFees(TblEventFees tblEventFees){
        super.addEntity(tblEventFees);
    }

    @Override
    public void deleteTblTenderFees(TblEventFees tblEventFees) {
        super.deleteEntity(tblEventFees);
    }

    @Override
    public void updateTblTenderFees(TblEventFees tblEventFees) {
        super.updateEntity(tblEventFees);
    }

    @Override
    public List<TblEventFees> getAllTblEventFees() {
        return super.getAllEntity();
    }

    @Override
    public List<TblEventFees> findTblEventFees(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblEventFeesCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblEventFees> findByCountTblEventFees(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }
    @Override
    public void saveOrUpdateTblEventFees(TblEventFees tblEventFees){
        super.saveOrUpdateEntity(tblEventFees);
    }
    @Override
    public void saveUpdateAllTblEventFees(List<TblEventFees> tblTenderFeess){
        super.updateAll(tblTenderFeess);
    }
}
