package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblPaymentRequestDao;
import com.etl.eproc.common.daointerface.TblRZPPaymentDao;
import com.etl.eproc.common.model.TblPaymentRequest;
import com.etl.eproc.common.model.TblRZPPayment;

/**
 *
 * @author rinju
 */
@Repository @Transactional    /*StackUpdate*/
public class TblPaymentRequestImpl extends AbcAbstractClass<TblPaymentRequest> implements TblPaymentRequestDao {

    @Override
    public void addTblPaymentRequest(TblPaymentRequest tblPaymentRequest){
        super.addEntity(tblPaymentRequest);
    }

    @Override
    public void deleteTblPaymentRequest(TblPaymentRequest tblPaymentRequest) {
        super.deleteEntity(tblPaymentRequest);
    }

    @Override
    public void updateTblPaymentRequest(TblPaymentRequest tblPaymentRequest) {
        super.updateEntity(tblPaymentRequest);
    }

    @Override
    public List<TblPaymentRequest> getAllTblPaymentRequest() {
        return super.getAllEntity();
    }

    @Override
    public List<TblPaymentRequest> findTblPaymentRequest(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblPaymentRequestCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblPaymentRequest> findByCountTblPaymentRequest(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblPaymentRequest(List<TblPaymentRequest> tblPaymentRequest){
        super.updateAll(tblPaymentRequest);
    }
}
