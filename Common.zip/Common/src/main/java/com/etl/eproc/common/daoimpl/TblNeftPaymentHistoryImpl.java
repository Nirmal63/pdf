package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblNeftPaymentHistory;
import com.etl.eproc.common.daointerface.TblNeftPaymentHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author hitesh.borsania
 */
@Repository @Transactional     /*StackUpdate*/
public class TblNeftPaymentHistoryImpl extends AbcAbstractClass<TblNeftPaymentHistory> implements TblNeftPaymentHistoryDao {

    @Override
    public void addTblNeftPaymentHistory(TblNeftPaymentHistory tblNeftPaymentHistory){
        super.addEntity(tblNeftPaymentHistory);
    }

    @Override
    public void deleteTblNeftPaymentHistory(TblNeftPaymentHistory tblNeftPaymentHistory) {
        super.deleteEntity(tblNeftPaymentHistory);
    }

    @Override
    public void updateTblNeftPaymentHistory(TblNeftPaymentHistory tblNeftPaymentHistory) {
        super.updateEntity(tblNeftPaymentHistory);
    }

    @Override
    public List<TblNeftPaymentHistory> getAllTblNeftPaymentHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNeftPaymentHistory> findTblNeftPaymentHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNeftPaymentHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNeftPaymentHistory> findByCountTblNeftPaymentHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNeftPaymentHistory(List<TblNeftPaymentHistory> tblNeftPaymentHistorys){
        super.updateAll(tblNeftPaymentHistorys);
    }
    
    @Override
    public void saveOrUpdateTblNeftPaymentHistory(TblNeftPaymentHistory tblNeftPaymentHistory){
        super.saveOrUpdateEntity(tblNeftPaymentHistory);
    }

}
