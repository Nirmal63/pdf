/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

/**
 *
 * @author darshan
 */
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblClientSectorDao;
import com.etl.eproc.common.model.TblClientSector;

@Repository @Transactional    /*StackUpdate*/
public class TblClientSectorDaoImpl extends AbcAbstractClass<TblClientSector> implements TblClientSectorDao {

    @Override
    public void addTblClientSector(TblClientSector TblClientSector) {
	super.addEntity(TblClientSector);
    }

    @Override
    public void deleteTblClientSector(TblClientSector TblClientSector) {
	super.deleteEntity(TblClientSector);
    }

    @Override
    public void updateTblClientSector(TblClientSector TblClientSector) {
	super.updateEntity(TblClientSector);
    }

    @Override
    public List<TblClientSector> getAllTblClientSector() {
	return super.getAllEntity();
    }

    @Override
    public List<TblClientSector> findTblClientSector(Object... values) throws Exception {
	return super.findEntity(values);
    }

    @Override
    public long getTblClientSectorCount() {
	return super.getEntityCount();
    }

    @Override
    public List<TblClientSector> findByCountTblClientSector(int firstResult, int maxResult, Object... values) throws Exception {
	return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveOrUpdateTblClientSector(TblClientSector TblClientSectors) {
	super.saveOrUpdateEntity(TblClientSectors);
    }

}