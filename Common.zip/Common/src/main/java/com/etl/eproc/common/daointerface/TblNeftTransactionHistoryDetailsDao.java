package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblNeftTransactionHistoryDetails;
import java.util.List;

public interface TblNeftTransactionHistoryDetailsDao  {

	    public void addTblNeftTransactionHistoryDetails(TblNeftTransactionHistoryDetails tblNeftTransactionHistoryDetails);

	    public void deleteTblNeftTransactionHistoryDetails(TblNeftTransactionHistoryDetails tblNeftTransactionHistoryDetails);

	    public void updateTblNeftTransactionHistoryDetails(TblNeftTransactionHistoryDetails tblNeftTransactionHistoryDetails);

	    public List<TblNeftTransactionHistoryDetails> getAllTblNeftTransactionHistoryDetails();

	    public List<TblNeftTransactionHistoryDetails> findTblNeftTransactionHistoryDetails(Object... values) throws Exception;

	    public List<TblNeftTransactionHistoryDetails> findByCountTblNeftTransactionHistoryDetails(int firstResult,int maxResult,Object... values) throws Exception;

	    public long getTblNeftTransactionHistoryDetailsCount();

	    public void saveUpdateAllTblNeftTransactionHistoryDetails(List<TblNeftTransactionHistoryDetails> tblNeftTransactionHistoryDetails);

		public void saveOrUpdateTblNeftTransactionHistoryDetails(
				TblNeftTransactionHistoryDetails tblNeftTransactionHistoryDetails);
}