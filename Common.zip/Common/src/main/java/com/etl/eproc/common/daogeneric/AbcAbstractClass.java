package com.etl.eproc.common.daogeneric;

import java.lang.reflect.ParameterizedType;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessResourceFailureException;

/*
 * @author TaherT
 */
public abstract class AbcAbstractClass<EntityType>{

	@Autowired
    @Qualifier("sessionFactory")
	private SessionFactory sessionFactory;
	
	protected Session getCurrentSession() {
        return this.sessionFactory.getCurrentSession();
    }
	
	private Class<EntityType> persistentClass;

    public Class<EntityType> getPersistentClass() {
        return persistentClass;
    }

    public void setPersistentClass(Class<EntityType> persistentClass) {
        this.persistentClass = persistentClass;
    }

    @SuppressWarnings("unchecked")
	public AbcAbstractClass() {
        super();
        this.persistentClass = (Class<EntityType>) ((ParameterizedType) getClass()
                .getGenericSuperclass()).getActualTypeArguments()[0];
    }

    public void addEntity(EntityType entity) {
    	getCurrentSession().save(entity);
    }

    public void deleteEntity(EntityType entity) {
    	getCurrentSession().delete(entity);
    }

    //@SuppressWarnings("rawtypes")
	public void deleteAll(Collection entities) {
    	for(Object entity: entities) {
    		getCurrentSession().delete(entity);	
    	}
    }

    public void updateEntity(EntityType entity) {
    	getCurrentSession().update(entity);
    }
    
    public void saveOrUpdateEntity(EntityType entity) {
    	getCurrentSession().saveOrUpdate(entity);
    }

    public void updateAll(Collection<EntityType> collection) {
    	for(Object entity:collection) {
    		getCurrentSession().saveOrUpdate(entity);	
    	}
    }

    //@SuppressWarnings("unchecked")
    public List<EntityType> getAllEntity() {
        List<EntityType> lst = null;
        lst = getCurrentSession().createCriteria(getPersistentClass()).list();
        return lst;
    }

    //@SuppressWarnings("unchecked")
	public List<EntityType> findEntity(Object... values) throws Exception {

    	Criteria criteria = getCurrentSession().createCriteria(persistentClass);
        List<EntityType> lst = new ArrayList<EntityType>();

        int len = values.length % 3;

        if (len != 0) {
            throw new Exception(
                    "Arguments Must be triplet of [field, expression(e.g. eq,lt,gt...), value]");
        }

        len = values.length / 3;

        for (int i = 0, j = 0; i < len; i++, j += 3) {

            Operation_enum operation = (Operation_enum) values[j + 1];

            switch (operation) {
                case EQ:
                	criteria.add(Restrictions.eq(values[j].toString(),
                            values[j + 2]));
                    // System.out.println("restrictions==="+values[j].toString()+"---"+
                    // values[j + 2]);
                    break;
                case GE:
                	criteria.add(Restrictions.ge(values[j].toString(),
                            values[j + 2]));
                    break;
                case GT:
                	criteria.add(Restrictions.gt(values[j].toString(),
                            values[j + 2]));
                    break;
                case LE:
                	criteria.add(Restrictions.le(values[j].toString(),
                            values[j + 2]));
                    break;
                case LT:
                	criteria.add(Restrictions.lt(values[j].toString(),
                            values[j + 2]));
                    break;
                case NE:
                	criteria.add(Restrictions.ne(values[j].toString(),
                            values[j + 2]));
                    break;
                case LIKE:
                	criteria.add(Restrictions.ilike(values[j].toString(),
                            values[j + 2]));
                    break;
                case OR:
                	criteria
                            .add(Restrictions.or(Restrictions.ilike(
                            values[j].toString(), values[j + 2]),
                            Restrictions.ilike(values[j + 3].toString(),
                            values[j + 5])));
                    j = j + 3;
                    i++;
                    break;
                case IN:
                	criteria.add(Restrictions.in(values[j].toString(),
                            (Object[]) values[j + 2]));
                    break;
                case ORDERBY:
                    //ordered = true;
                    Operation_enum order = (Operation_enum) values[j + 2];
                    if (order == Operation_enum.ASC) {
                    	criteria.addOrder(Order.asc(values[j].toString()));
                    } else if (order == Operation_enum.DESC) {
                    	criteria.addOrder(Order.desc(values[j].toString()));
                    } else {
                        throw new Exception(
                                "Order by can be ASC or DESC only. use Enum for to specify this.");
                    }
                    break;
                default:

            }
        }
        lst = (List<EntityType>) criteria.list();
        return lst;
    }

    //@SuppressWarnings({ "incomplete-switch", "unchecked" })
	public List<EntityType> findByCountEntity(int firstResult, int maxResult,
            Object... values) throws Exception {

    	Criteria criteria = getCurrentSession().createCriteria(persistentClass);
        List<EntityType> lst = new ArrayList<EntityType>();
        int len = values.length % 3;
        boolean ordered = false;

        if (len != 0) {
            throw new Exception(
                    "Arguments Must be triplet of [field, expression(e.g. eq,lt,gt...), value]");
        }

        len = values.length / 3;

        for (int i = 0, j = 0; i < len; i++, j += 3) {

            Operation_enum operation = (Operation_enum) values[j + 1];

            switch (operation) {
                case EQ:
                	criteria.add(Restrictions.eq(values[j].toString(),
                            values[j + 2]));
                    break;
                case GE:
                	criteria.add(Restrictions.ge(values[j].toString(),
                            values[j + 2]));
                    break;
                case GT:
                	criteria.add(Restrictions.gt(values[j].toString(),
                            values[j + 2]));
                    break;
                case LE:
                	criteria.add(Restrictions.le(values[j].toString(),
                            values[j + 2]));
                    break;
                case LT:
                	criteria.add(Restrictions.lt(values[j].toString(),
                            values[j + 2]));
                    break;
                case NE:
                	criteria.add(Restrictions.ne(values[j].toString(),
                            values[j + 2]));
                    break;
                case LIKE:
                	criteria.add(Restrictions.ilike(values[j].toString(),
                            values[j + 2]));
                    break;
                case OR:
                	criteria
                            .add(Restrictions.or(Restrictions.ilike(
                            values[j].toString(), values[j + 2]),
                            Restrictions.ilike(values[j + 3].toString(),
                            values[j + 5])));
                    j = j + 3;
                    i++;
                    break;
                case IN:
                	criteria.add(Restrictions.in(values[j].toString(),
                            (Object[]) values[j + 2]));
                    break;
                case ORDERBY:
                    ordered = true;
                    Operation_enum order = (Operation_enum) values[j + 2];
                    if (order == Operation_enum.ASC) {
                    	criteria.addOrder(Order.asc(values[j].toString()));
                    } else if (order == Operation_enum.DESC) {
                    	criteria.addOrder(Order.desc(values[j].toString()));
                    } else {
                        throw new Exception(
                                "Order by can be ASC or DESC only. use Enum for to specify this.");
                    }

                    break;
            }
        }

        if (!ordered && !persistentClass.getSimpleName().startsWith("Vw")) {
            String firstFieldNameFull = persistentClass.getDeclaredFields()[0]
                    .toString();
            int intlastdot = firstFieldNameFull.lastIndexOf('.');
            String firstFieldName = firstFieldNameFull
                    .substring(intlastdot + 1);

            criteria.addOrder(Order.asc(firstFieldName));
        }
        criteria.setFirstResult(firstResult);
		criteria.setMaxResults(maxResult);
        lst = (List<EntityType>) criteria.list();
        return lst;
    }

    /*
     * Below is to create Projection Ex. count, rowcount, max, min etc See
     * Projection.Ctrl+Space
     */
    public long getEntityCount() {
        long count = 0;
        Criteria c = getCurrentSession().createCriteria(persistentClass).setProjection(Projections.rowCount());
        count = (Long) c.list().get(0);
        return count;
    }

    //@SuppressWarnings("unchecked")
	public List<Object[]> createQuery(String query, Map<String, Object> var) {
        Query q = getCurrentSession().createQuery(query);
        setQueryMap(q, var);
        return q == null ? null : q.list();
    }
	
	public List<Object[]> createQueryForGmr(String query, Map<String, Object> var) {
		Query q = null;
        q = getCurrentSession().createQuery(query);
        q.setMaxResults(5);
        setQueryMap(q, var);
        return q == null ? null : q.list();
		
	}

	@SuppressWarnings("unchecked")
	public List<Object[]> createSQLQuery(String query, Map<String, Object> var) {
        Query q = getCurrentSession().createSQLQuery(query);        
        setQueryMap(q, var);
        return q == null ? null : q.list();
    }
    
    /**
     * Creating SQL query containing nvarchar columns
     * @param query Query to be executed where each column should be (c0,c1...)
     * @param var parameters containing values
     * @param ncharsIndex index(s) of columns which are nvarchar
     * @param colcount total columns count in query
     * @return 
     */

	//@SuppressWarnings("unchecked")
	public List<Object[]> createSQLQuery(String query, Map<String, Object> var,int[] ncharsIndex,int colcount) {
        SQLQuery q = getCurrentSession().createSQLQuery(query);
        for (int i=0;i<colcount;i++){
            boolean isNchar = false;
            for (int j : ncharsIndex) {
                if(i==j){
                    isNchar = true;
                    break;
                }
            }
            if(isNchar){
                q.addScalar("c"+i,StringType.INSTANCE);
            }else{
                q.addScalar("c"+i);
            }
        }        
        setQueryMap(q, var);
        return q == null ? null : q.list();
    } 

	/*
	 * //@SuppressWarnings("unchecked") public List<Object[]>
	 * createByCountQuery(String query, Map<String, Object> var, int firstResult,
	 * int maxResult) { Query q = getCurrentSession().createQuery(query);
	 * setQueryMap(q, var); q.setFirstResult(firstResult);
	 * q.setMaxResults(maxResult); return q == null ? null : q.list(); }
	 */

    public long countForQuery(String from, String countOn, String where, Map<String, Object> var) {
        StringBuilder query = new StringBuilder();
        query.append("select count(").append(countOn).append(") as count from ").append(from).append(" where ").append(where);
        Query q = getCurrentSession().createQuery(query.toString());
        setQueryMap(q, var);
        return q == null ? 0 : (Long) q.list().get(0);
    }

    //@SuppressWarnings("unchecked")
	public List<Object> singleColQuery(String query, Map<String, Object> var) {
        Query q = getCurrentSession().createQuery(query);
        setQueryMap(q, var);
        return q == null ? null : q.list();
    }

    public int updateDeleteQuery(String query, Map<String, Object> var) {
        Query q = getCurrentSession().createQuery(query);
        setQueryMap(q, var);
        return q == null ? 0 : q.executeUpdate();
    }

    public int updateDeleteSQLQuery(String query, Map<String, Object> var) {
        Query q = getCurrentSession().createSQLQuery(query);
        setQueryMap(q, var);
        return q == null ? 0 : q.executeUpdate();
    }

    //@SuppressWarnings("rawtypes")
	public List nativeQueryToBean(String query, Class classAlias, Map<String, Object> var) throws DataAccessResourceFailureException, HibernateException, IllegalStateException, ClassNotFoundException {
        Query q = getCurrentSession().createSQLQuery(query).setResultTransformer(Transformers.aliasToBean(classAlias));
        setQueryMap(q, var);
        return q.list();
    }
    
    //@SuppressWarnings("rawtypes")
	private void setQueryMap(Query q,Map<String, Object> var){
        if(var!=null){
            Set<String> varnames = var.keySet();
            for (String key : varnames) {
                Object val = var.get(key);
                if (val instanceof String) {
                    q.setString(key, val.toString());
                } else if (val instanceof Integer) {
                    q.setInteger(key, (Integer) val);
                } else if (val instanceof Date) {
                    q.setDate(key, (Date) val);
                }else if (val instanceof Long) {
                    q.setLong(key, (Long) val);
                }else if (val instanceof Object[]) {
                    q.setParameterList(key,(Object[]) val);
                }else if (val instanceof Collection) {
                    q.setParameterList(key,(Collection) val);
                }else if (val instanceof Double) {
                    q.setDouble(key, (Double) val);
                }else if (val instanceof BigDecimal) {
                    q.setBigDecimal(key, (BigDecimal) val);
                }
            }
        }
    }
}