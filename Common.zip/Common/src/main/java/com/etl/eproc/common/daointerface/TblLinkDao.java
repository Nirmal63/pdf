package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblLink;
import java.util.List;

public interface TblLinkDao  {

    public void addTblLink(TblLink tblLink);

    public void deleteTblLink(TblLink tblLink);

    public void updateTblLink(TblLink tblLink);

    public List<TblLink> getAllTblLink();

    public List<TblLink> findTblLink(Object... values) throws Exception;

    public List<TblLink> findByCountTblLink(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblLinkCount();

    public void saveUpdateAllTblLink(List<TblLink> tblLinks);
}