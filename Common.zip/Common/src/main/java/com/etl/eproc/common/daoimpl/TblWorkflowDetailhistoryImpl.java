package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblWorkflowDetailhistory;
import com.etl.eproc.common.daointerface.TblWorkflowDetailhistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblWorkflowDetailhistoryImpl extends AbcAbstractClass<TblWorkflowDetailhistory> implements TblWorkflowDetailhistoryDao {

    @Override
    public void addTblWorkflowDetailhistory(TblWorkflowDetailhistory tblWorkflowDetailhistory){
        super.addEntity(tblWorkflowDetailhistory);
    }

    @Override
    public void deleteTblWorkflowDetailhistory(TblWorkflowDetailhistory tblWorkflowDetailhistory) {
        super.deleteEntity(tblWorkflowDetailhistory);
    }

    @Override
    public void updateTblWorkflowDetailhistory(TblWorkflowDetailhistory tblWorkflowDetailhistory) {
        super.updateEntity(tblWorkflowDetailhistory);
    }

    @Override
    public List<TblWorkflowDetailhistory> getAllTblWorkflowDetailhistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblWorkflowDetailhistory> findTblWorkflowDetailhistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblWorkflowDetailhistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblWorkflowDetailhistory> findByCountTblWorkflowDetailhistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblWorkflowDetailhistory(List<TblWorkflowDetailhistory> tblWorkflowDetailhistorys){
        super.updateAll(tblWorkflowDetailhistorys);
    }
}
