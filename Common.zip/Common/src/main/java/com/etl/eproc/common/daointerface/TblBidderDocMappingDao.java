package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBidderDocMapping;

public interface TblBidderDocMappingDao  {

    public void addTblBidderDocMapping(TblBidderDocMapping tblBidderDocMapping);

    public void deleteTblBidderDocMapping(TblBidderDocMapping tblBidderDocMapping);

    public void updateTblBidderDocMapping(TblBidderDocMapping tblBidderDocMapping);

    public List<TblBidderDocMapping> getAllTblBidderDocMapping();

    public List<TblBidderDocMapping> findTblBidderDocMapping(Object... values) throws Exception;

    public List<TblBidderDocMapping> findByCountTblBidderDocMapping(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidderDocMappingCount();

    public void saveUpdateAllTblBidderDocMapping(List<TblBidderDocMapping> tblBidderDocMappings);

	public void saveOrUpdateTblBidderDocMapping(TblBidderDocMapping tblBidderDocMapping);
}