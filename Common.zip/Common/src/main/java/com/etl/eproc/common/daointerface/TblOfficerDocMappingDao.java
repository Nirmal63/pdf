package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblOfficerDocMapping;
import java.util.List;

public interface TblOfficerDocMappingDao  {

    public void addTblOfficerDocMapping(TblOfficerDocMapping tblOfficerDocMapping);

    public void deleteTblOfficerDocMapping(TblOfficerDocMapping tblOfficerDocMapping);

    public void updateTblOfficerDocMapping(TblOfficerDocMapping tblOfficerDocMapping);

    public List<TblOfficerDocMapping> getAllTblOfficerDocMapping();

    public List<TblOfficerDocMapping> findTblOfficerDocMapping(Object... values) throws Exception;

    public List<TblOfficerDocMapping> findByCountTblOfficerDocMapping(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblOfficerDocMappingCount();

    public void saveUpdateAllTblOfficerDocMapping(List<TblOfficerDocMapping> tblOfficerDocMappings);

	public void saveOrUpdateTblOfficerDocMapping(TblOfficerDocMapping tblOfficerDocMapping);
}