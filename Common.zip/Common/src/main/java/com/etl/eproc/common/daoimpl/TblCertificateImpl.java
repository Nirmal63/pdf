package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblCertificateDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblCertificate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCertificateImpl extends AbcAbstractClass<TblCertificate> implements TblCertificateDao {

    @Override
    public void addTblCertificate(TblCertificate tblCertificate){
        super.addEntity(tblCertificate);
    }

    @Override
    public void deleteTblCertificate(TblCertificate tblCertificate) {
        super.deleteEntity(tblCertificate);
    }

    @Override
    public void updateTblCertificate(TblCertificate tblCertificate) {
        super.updateEntity(tblCertificate);
    }

    @Override
    public List<TblCertificate> getAllTblCertificate() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCertificate> findTblCertificate(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCertificateCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCertificate> findByCountTblCertificate(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCertificate(List<TblCertificate> tblCertificates){
        super.updateAll(tblCertificates);
    }
}
