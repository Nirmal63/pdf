package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDateFormat;
import java.util.List;

public interface TblDateFormatDao  {

    public void addTblDateFormat(TblDateFormat tblDateFormat);

    public void deleteTblDateFormat(TblDateFormat tblDateFormat);

    public void updateTblDateFormat(TblDateFormat tblDateFormat);

    public List<TblDateFormat> getAllTblDateFormat();

    public List<TblDateFormat> findTblDateFormat(Object... values) throws Exception;

    public List<TblDateFormat> findByCountTblDateFormat(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDateFormatCount();

    public void saveUpdateAllTblDateFormat(List<TblDateFormat> tblDateFormats);
}