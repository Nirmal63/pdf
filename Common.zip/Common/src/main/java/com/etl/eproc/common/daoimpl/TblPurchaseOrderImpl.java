package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblPurchaseOrderDao;
import com.etl.eproc.common.model.TblPurchaseOrder;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblPurchaseOrderImpl extends AbcAbstractClass<TblPurchaseOrder> implements TblPurchaseOrderDao {

    @Override
    public void addTblPurchaseOrder(TblPurchaseOrder tblPurchaseOrder){
        super.addEntity(tblPurchaseOrder);
    }

    @Override
    public void deleteTblPurchaseOrder(TblPurchaseOrder tblPurchaseOrder) {
        super.deleteEntity(tblPurchaseOrder);
    }

    @Override
    public void updateTblPurchaseOrder(TblPurchaseOrder tblPurchaseOrder) {
        super.updateEntity(tblPurchaseOrder);
    }

    @Override
    public List<TblPurchaseOrder> getAllTblPurchaseOrder() {
        return super.getAllEntity();
    }

    @Override
    public List<TblPurchaseOrder> findTblPurchaseOrder(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblPurchaseOrderCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblPurchaseOrder> findByCountTblPurchaseOrder(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblPurchaseOrder(List<TblPurchaseOrder> tblPurchaseOrders){
        super.updateAll(tblPurchaseOrders);
    }
}
