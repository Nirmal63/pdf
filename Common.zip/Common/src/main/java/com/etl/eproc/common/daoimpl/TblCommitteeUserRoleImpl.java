package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblCommitteeUserRole;
import com.etl.eproc.common.daointerface.TblCommitteeUserRoleDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCommitteeUserRoleImpl extends AbcAbstractClass<TblCommitteeUserRole> implements TblCommitteeUserRoleDao {

    @Override
    public void addTblCommitteeUserRole(TblCommitteeUserRole tblCommitteeUserRole){
        super.addEntity(tblCommitteeUserRole);
    }

    @Override
    public void deleteTblCommitteeUserRole(TblCommitteeUserRole tblCommitteeUserRole) {
        super.deleteEntity(tblCommitteeUserRole);
    }

    @Override
    public void updateTblCommitteeUserRole(TblCommitteeUserRole tblCommitteeUserRole) {
        super.updateEntity(tblCommitteeUserRole);
    }

    @Override
    public List<TblCommitteeUserRole> getAllTblCommitteeUserRole() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCommitteeUserRole> findTblCommitteeUserRole(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCommitteeUserRoleCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCommitteeUserRole> findByCountTblCommitteeUserRole(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCommitteeUserRole(List<TblCommitteeUserRole> tblCommitteeUserRoles){
        super.updateAll(tblCommitteeUserRoles);
    }
}
