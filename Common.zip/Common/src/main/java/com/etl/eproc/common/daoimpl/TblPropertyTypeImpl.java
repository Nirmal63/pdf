package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblPropertyType;
import com.etl.eproc.common.daointerface.TblPropertyTypeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblPropertyTypeImpl extends AbcAbstractClass<TblPropertyType> implements TblPropertyTypeDao {

    @Override
    public void addTblPropertyType(TblPropertyType tblPropertyType){
        super.addEntity(tblPropertyType);
    }

    @Override
    public void deleteTblPropertyType(TblPropertyType tblPropertyType) {
        super.deleteEntity(tblPropertyType);
    }

    @Override
    public void updateTblPropertyType(TblPropertyType tblPropertyType) {
        super.updateEntity(tblPropertyType);
    }

    @Override
    public List<TblPropertyType> getAllTblPropertyType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblPropertyType> findTblPropertyType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblPropertyTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblPropertyType> findByCountTblPropertyType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblPropertyType(List<TblPropertyType> tblPropertyTypes){
        super.updateAll(tblPropertyTypes);
    }
}
