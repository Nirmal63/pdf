package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblBidderDocFolderDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblBidderDocFolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBidderDocFolderImpl extends AbcAbstractClass<TblBidderDocFolder> implements TblBidderDocFolderDao {

    @Override
    public void addTblBidderDocFolder(TblBidderDocFolder tblBidderDocFolder){
        super.addEntity(tblBidderDocFolder);
    }

    @Override
    public void deleteTblBidderDocFolder(TblBidderDocFolder tblBidderDocFolder) {
        super.deleteEntity(tblBidderDocFolder);
    }

    @Override
    public void updateTblBidderDocFolder(TblBidderDocFolder tblBidderDocFolder) {
        super.updateEntity(tblBidderDocFolder);
    }

    @Override
    public List<TblBidderDocFolder> getAllTblBidderDocFolder() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBidderDocFolder> findTblBidderDocFolder(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBidderDocFolderCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBidderDocFolder> findByCountTblBidderDocFolder(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBidderDocFolder(List<TblBidderDocFolder> tblBidderDocFolders){
        super.updateAll(tblBidderDocFolders);
    }

	@Override
	public void saveOrUpdateTblBidderDocFolder(TblBidderDocFolder tblBidderDocFolder) {
		super.saveOrUpdateEntity(tblBidderDocFolder);
	}
}
