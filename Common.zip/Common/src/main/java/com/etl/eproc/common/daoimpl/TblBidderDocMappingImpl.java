package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblBidderDocMappingDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblBidderDocMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBidderDocMappingImpl extends AbcAbstractClass<TblBidderDocMapping> implements TblBidderDocMappingDao {

    @Override
    public void addTblBidderDocMapping(TblBidderDocMapping tblBidderDocMapping){
        super.addEntity(tblBidderDocMapping);
    }

    @Override
    public void deleteTblBidderDocMapping(TblBidderDocMapping tblBidderDocMapping) {
        super.deleteEntity(tblBidderDocMapping);
    }

    @Override
    public void updateTblBidderDocMapping(TblBidderDocMapping tblBidderDocMapping) {
        super.updateEntity(tblBidderDocMapping);
    }

    @Override
    public List<TblBidderDocMapping> getAllTblBidderDocMapping() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBidderDocMapping> findTblBidderDocMapping(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBidderDocMappingCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBidderDocMapping> findByCountTblBidderDocMapping(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBidderDocMapping(List<TblBidderDocMapping> tblBidderDocMappings){
        super.updateAll(tblBidderDocMappings);
    }

	@Override
	public void saveOrUpdateTblBidderDocMapping(TblBidderDocMapping tblBidderDocMapping) {
		super.saveOrUpdateEntity(tblBidderDocMapping);
	}
}
