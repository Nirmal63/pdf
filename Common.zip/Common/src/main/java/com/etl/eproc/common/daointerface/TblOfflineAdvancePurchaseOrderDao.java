package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.common.model.TblOfflineAdvancePurchaseOrder;

public interface TblOfflineAdvancePurchaseOrderDao  {

    public void addTblOfflineAdvancePurchaseOrde(TblOfflineAdvancePurchaseOrder tblOfflineAdvancePurchaseOrde);

    public void deleteTblOfflineAdvancePurchaseOrde(TblOfflineAdvancePurchaseOrder tblOfflineAdvancePurchaseOrde);

    public void updateTblOfflineAdvancePurchaseOrde(TblOfflineAdvancePurchaseOrder tblOfflineAdvancePurchaseOrde);

    public List<TblOfflineAdvancePurchaseOrder> getAllTblOfflineAdvancePurchaseOrde();

    public List<TblOfflineAdvancePurchaseOrder> findTblOfflineAdvancePurchaseOrde(Object... values) throws Exception;

    public List<TblOfflineAdvancePurchaseOrder> findByCountTblOfflineAdvancePurchaseOrde(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblOfflineAdvancePurchaseOrdeCount();

    public void saveUpdateAllTblOfflineAdvancePurchaseOrde(List<TblOfflineAdvancePurchaseOrder> tblOfflineAdvancePurchaseOrdes);

	public void saveOrUpdateTblOfflineAdvancePurchaseOrder(TblOfflineAdvancePurchaseOrder offlineAPO);
}