package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblCountryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblCountry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCountryImpl extends AbcAbstractClass<TblCountry> implements TblCountryDao {

    @Override
    public void addTblCountry(TblCountry tblCountry){
        super.addEntity(tblCountry);
    }

    @Override
    public void deleteTblCountry(TblCountry tblCountry) {
        super.deleteEntity(tblCountry);
    }

    @Override
    public void updateTblCountry(TblCountry tblCountry) {
        super.updateEntity(tblCountry);
    }

    @Override
    public List<TblCountry> getAllTblCountry() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCountry> findTblCountry(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCountryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCountry> findByCountTblCountry(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCountry(List<TblCountry> tblCountrys){
        super.updateAll(tblCountrys);
    }
}
