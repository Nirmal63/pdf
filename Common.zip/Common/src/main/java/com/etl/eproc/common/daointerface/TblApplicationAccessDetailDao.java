package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblApplicationAccessDetail;

public interface TblApplicationAccessDetailDao  {

    public void addTblApplicationAccessDetail(TblApplicationAccessDetail tblApplicationAccessDetail);

    public void deleteTblApplicationAccessDetail(TblApplicationAccessDetail tblApplicationAccessDetail);

    public void updateTblApplicationAccessDetail(TblApplicationAccessDetail tblApplicationAccessDetail);

    public List<TblApplicationAccessDetail> getAllTblApplicationAccessDetail();

    public List<TblApplicationAccessDetail> findTblApplicationAccessDetail(Object... values) throws Exception;

    public List<TblApplicationAccessDetail> findByCountTblApplicationAccessDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblApplicationAccessDetailCount();

    public void saveUpdateAllTblApplicationAccessDetail(List<TblApplicationAccessDetail> tblApplicationAccessDetails);

	public void saveOrUpdateTblApplicationAccessDetail(TblApplicationAccessDetail tblApplicationAccessDetail);
}