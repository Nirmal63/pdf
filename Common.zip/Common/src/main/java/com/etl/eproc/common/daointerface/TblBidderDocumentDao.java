package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBidderDocument;

public interface TblBidderDocumentDao  {

    public void addTblBidderDocument(TblBidderDocument tblBidderDocument);

    public void deleteTblBidderDocument(TblBidderDocument tblBidderDocument);

    public void updateTblBidderDocument(TblBidderDocument tblBidderDocument);

    public List<TblBidderDocument> getAllTblBidderDocument();

    public List<TblBidderDocument> findTblBidderDocument(Object... values) throws Exception;

    public List<TblBidderDocument> findByCountTblBidderDocument(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidderDocumentCount();

    public void saveUpdateAllTblBidderDocument(List<TblBidderDocument> tblBidderDocuments);

	public void saveOrUpdateTblBidderDocument(TblBidderDocument tblBidderDocument);
}