package com.etl.eproc.common.daoimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblCouponHistoryDao;
import com.etl.eproc.common.model.TblCouponHistory;

/*
 * @author TaherT
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCouponHistoryDaoImpl extends AbcAbstractClass<TblCouponHistory> implements TblCouponHistoryDao {
	
	@Override
    public List<TblCouponHistory> findTblCouponHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

	@Override
	public void saveOrUpdateTblCouponHistory(TblCouponHistory tblCouponHistory) {
		super.saveOrUpdateEntity(tblCouponHistory);
		
	}


}
