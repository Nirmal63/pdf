package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblFeatureDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblFeature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblFeatureImpl extends AbcAbstractClass<TblFeature> implements TblFeatureDao {

    @Override
    public void addTblFeature(TblFeature tblFeature){
        super.addEntity(tblFeature);
    }

    @Override
    public void deleteTblFeature(TblFeature tblFeature) {
        super.deleteEntity(tblFeature);
    }

    @Override
    public void updateTblFeature(TblFeature tblFeature) {
        super.updateEntity(tblFeature);
    }

    @Override
    public List<TblFeature> getAllTblFeature() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFeature> findTblFeature(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFeatureCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFeature> findByCountTblFeature(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFeature(List<TblFeature> tblFeatures){
        super.updateAll(tblFeatures);
    }
}
