package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblNegotiation;
import java.util.List;

public interface TblNegotiationDao  {

    public void addTblNegotiation(TblNegotiation tblNegotiation);

    public void deleteTblNegotiation(TblNegotiation tblNegotiation);

    public void updateTblNegotiation(TblNegotiation tblNegotiation);

    public List<TblNegotiation> getAllTblNegotiation();

    public List<TblNegotiation> findTblNegotiation(Object... values) throws Exception;

    public List<TblNegotiation> findByCountTblNegotiation(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNegotiationCount();

    public void saveUpdateAllTblNegotiation(List<TblNegotiation> tblNegotiations);
}
