package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblEmdTransactionDetailStatusDao;
import com.etl.eproc.common.model.TblEmdTransactionDetailStatus;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblEmdTransactionDetailStatusImpl extends AbcAbstractClass<TblEmdTransactionDetailStatus> implements TblEmdTransactionDetailStatusDao {

    @Override
    public void addTblEmdTransactionDetailStatus(TblEmdTransactionDetailStatus tblEmdTransactionDetailStatus){
        super.addEntity(tblEmdTransactionDetailStatus);
    }

    @Override
    public void deleteTblEmdTransactionDetailStatus(TblEmdTransactionDetailStatus tblEmdTransactionDetailStatus) {
        super.deleteEntity(tblEmdTransactionDetailStatus);
    }

    @Override
    public void updateTblEmdTransactionDetailStatus(TblEmdTransactionDetailStatus tblEmdTransactionDetailStatus) {
        super.updateEntity(tblEmdTransactionDetailStatus);
    }

    @Override
    public List<TblEmdTransactionDetailStatus> getAllTblEmdTransactionDetailStatus() {
        return super.getAllEntity();
    }

    @Override
    public List<TblEmdTransactionDetailStatus> findTblEmdTransactionDetailStatus(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblEmdTransactionDetailStatusCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblEmdTransactionDetailStatus> findByCountTblEmdTransactionDetailStatus(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblEmdTransactionDetailStatus(List<TblEmdTransactionDetailStatus> tblEmdTransactionDetailStatus){
        super.updateAll(tblEmdTransactionDetailStatus);
    }

	@Override
	public void saveOrUpdateTblEmdTransactionDetailStatus(TblEmdTransactionDetailStatus tblEmdTransactionDetailStatus) {
		super.saveOrUpdateEntity(tblEmdTransactionDetailStatus);
	}
}
