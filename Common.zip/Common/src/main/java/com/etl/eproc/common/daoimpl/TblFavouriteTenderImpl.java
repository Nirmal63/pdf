package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblFavouriteEvent;
import com.etl.eproc.common.daointerface.TblFavouriteTenderDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblFavouriteTenderImpl extends AbcAbstractClass<TblFavouriteEvent> implements TblFavouriteTenderDao {

    @Override
    public void addTblFavouriteTender(TblFavouriteEvent tblFavouriteTender){
        super.addEntity(tblFavouriteTender);
    }

    @Override
    public void deleteTblFavouriteTender(TblFavouriteEvent tblFavouriteTender) {
        super.deleteEntity(tblFavouriteTender);
    }

    @Override
    public void updateTblFavouriteTender(TblFavouriteEvent tblFavouriteTender) {
        super.updateEntity(tblFavouriteTender);
    }

    @Override
    public List<TblFavouriteEvent> getAllTblFavouriteTender() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFavouriteEvent> findTblFavouriteTender(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFavouriteTenderCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFavouriteEvent> findByCountTblFavouriteTender(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFavouriteTender(List<TblFavouriteEvent> tblFavouriteTenders){
        super.updateAll(tblFavouriteTenders);
    }
}
