package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblMessageDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMessageImpl extends AbcAbstractClass<TblMessage> implements TblMessageDao {

    @Override
    public void addTblMessage(TblMessage tblMessage){
        super.addEntity(tblMessage);
    }

    @Override
    public void deleteTblMessage(TblMessage tblMessage) {
        super.deleteEntity(tblMessage);
    }

    @Override
    public void updateTblMessage(TblMessage tblMessage) {
        super.updateEntity(tblMessage);
    }

    @Override
    public List<TblMessage> getAllTblMessage() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMessage> findTblMessage(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMessageCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMessage> findByCountTblMessage(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMessage(List<TblMessage> tblMessages){
        super.updateAll(tblMessages);
    }

	@Override
	public void saveOrUpdateTblMessage(TblMessage tblMessage) {
		super.saveOrUpdateEntity(tblMessage);
	}
}
