package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblMapCategory;
import com.etl.eproc.common.daointerface.TblMapCategoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMapCategoryImpl extends AbcAbstractClass<TblMapCategory> implements TblMapCategoryDao {

    @Override
    public void addTblMapCategory(TblMapCategory tblMapCategory){
        super.addEntity(tblMapCategory);
    }

    @Override
    public void deleteTblMapCategory(TblMapCategory tblMapCategory) {
        super.deleteEntity(tblMapCategory);
    }

    @Override
    public void updateTblMapCategory(TblMapCategory tblMapCategory) {
        super.updateEntity(tblMapCategory);
    }

    @Override
    public List<TblMapCategory> getAllTblMapCategory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMapCategory> findTblMapCategory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMapCategoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMapCategory> findByCountTblMapCategory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMapCategory(List<TblMapCategory> tblMapCategorys){
        super.updateAll(tblMapCategorys);
    }
}

