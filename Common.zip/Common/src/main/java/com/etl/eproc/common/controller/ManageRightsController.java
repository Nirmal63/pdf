/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.databean.AssignRightsDataBean;
import com.etl.eproc.common.model.TblDesignation;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblModule;
import com.etl.eproc.common.model.TblSubModule;
import com.etl.eproc.common.model.TblUserRight;
import com.etl.eproc.common.model.TblUserRightHistory;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.DesignationService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ManageContentService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;

/**
 * 
 * @author vipul
 */
@Controller
@RequestMapping("/common")
public class ManageRightsController {

	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
	@Autowired
	private ManageContentService manageContentService;
	@Autowired
	private DesignationService designationService;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	ModelToSelectItem modelToSelectItem;
	@Value("#{projectProperties['userrighthistory.actiontype.assign']}")
	private String actionTypeAssign;
	@Value("#{projectProperties['userrighthistory.actiontype.remove']}")
	private String actionTypeRemove;
	@Autowired
	private AuditTrailService auditTrailService;
	@Value("#{linkProperties['manage_designation_assign_rights']?:12}")
	private String assignRighstLinkId;
	@Value("#{adminAuditTrailProperties['getmanagerights']}")
	private String getManageRightsAuditMsg;
	@Value("#{adminAuditTrailProperties['posteditrights']}")
	private String postEditRightsAuditMsg;
	@Value("#{adminAuditTrailProperties['postassignrights']}")
	private String postAssignRightsAuditMsg;
	// @Value("#{adminAuditTrailProperties['ajaxgetaccesscontrolmatrix']}")
	// private String ajaxGetAccessControlMatrixAuditMsg;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private ClientService clientService;

	@RequestMapping(value = {"/admin/managemenurights/{designationId}/{enc}","/admin/viewmanagemenurights/{designationId}/{enc}"}, method = RequestMethod.GET)
    public String manageMenuRights(@PathVariable("designationId") int designationId, ModelMap modelMap, HttpServletRequest request) {
        try {
            List<Object[]> lstModules = clientService.getClientModuleForView(abcUtility.getSessionClientId(request));
            List<Object[]> lstDesignationDtls = manageContentService.getDesignationDtsl(designationId);
            List<Object[]> tbldesiglst = manageContentService.getDesignationList(abcUtility.getSessionClientId(request),designationId);
            List<SelectItem> selList = new ArrayList<SelectItem>();
            
            for (int i = 0; i < tbldesiglst.size(); i++) {
            	Object[] object=tbldesiglst.get(i);
            selList.add(new SelectItem(object[1], object[0]));
            	
			}
            
            int readOnly = 0;
             boolean flag = false;
            Cookie[] cookies = request.getCookies();
            String moduleId = null;
            if (cookies != null) {
                for (Cookie cookie : cookies) {
                    if ("moduleId".equals(cookie.getName())) {
                        moduleId = cookie.getValue();
                        break;
                    }
                }
            }
            if(request.getServletPath().contains("viewmanagemenurights")){
                flag = true;
                readOnly = 1;
            }
            modelMap.put("viewOnly", flag);
            modelMap.put("readOnly", readOnly);
            modelMap.put("designationDtls", lstDesignationDtls);
            modelMap.put("moduleId",moduleId);
            modelMap.put("lstModules", lstModules);
            modelMap.put("designationId", designationId);
            modelMap.put("designationList", selList);

        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(assignRighstLinkId), getManageRightsAuditMsg, 0, 0);
        }
        return "/common/admin/ManageMenuRights";
    }

	/**
	 * regards Change Request #17243
	 * 
	 * @author SULABH
	 * @param designationId
	 * @param moduleId
	 * @param modelMap
	 * @param request
	 * @param redirectAttributes
	 * @return
	 */
	@RequestMapping(value = "/admin/managerights/{designationId}/{moduleId}/{enc}", method = RequestMethod.GET)
	public String manageRights(
			@PathVariable("designationId") int designationId,
			@PathVariable("moduleId") int moduleId, ModelMap modelMap,
			HttpServletRequest request, RedirectAttributes redirectAttributes) {
		try {
			List<Object[]> lstModules = clientService
					.getClientModuleForView(abcUtility
							.getSessionClientId(request));
			List<Object[]> lstDesignationDtls = manageContentService
					.getDesignationDtsl(designationId);
			List<Object[]> tbldesiglst = manageContentService.getDesignationList(abcUtility.getSessionClientId(request),designationId);
			
			
			 List<SelectItem> selList = new ArrayList<SelectItem>();
	            
	            for (int i = 0; i < tbldesiglst.size(); i++) {
	            	Object[] object=tbldesiglst.get(i);
	            selList.add(new SelectItem(object[1], object[0]));
	            	
				}
	            
			modelMap.put("viewOnly", false);
			modelMap.put("readOnly", 0);
			modelMap.put("designationDtls", lstDesignationDtls);
			modelMap.put("moduleId", moduleId);
			modelMap.put("lstModules", lstModules);
			modelMap.put("designationId", designationId);
			 modelMap.put("designationList", selList);

		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(
					request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					Integer.parseInt(assignRighstLinkId),
					getManageRightsAuditMsg, 0, 0);
		}
		return "/common/admin/ManageMenuRights";
	}

	@RequestMapping(value = "/admin/addrights", method = RequestMethod.POST)
	public String addRights(HttpServletRequest request,
			HttpSession httpSession, RedirectAttributes redirectAttributes,
			ModelMap modelMap) {
		boolean isUpdate = false;
		int designationId = 0;
		int moduleId = 0;
		int designationIdOfAprrove=0;
		try {
			int userId = abcUtility.getSessionUserId(request);

			List<TblUserRightHistory> lstUserRightHistory = new ArrayList<TblUserRightHistory>();

			designationId = request.getParameter("hdDesigationIdForSave") != null ? Integer
					.parseInt(request.getParameter("hdDesigationIdForSave")) : 0;
					
			designationIdOfAprrove = request.getParameter("hdDesigationId") != null ? Integer
							.parseInt(request.getParameter("hdDesigationId")) : 0;
							
					
					
			moduleId = request.getParameter("hdModuleId") != null ? Integer
					.parseInt(request.getParameter("hdModuleId")) : 0;

			List<Object> lstApprovedLinks = designationService.getApprovedLinks(moduleId,designationIdOfAprrove);
			
			
			isUpdate = lstApprovedLinks.size() > 0 ? true : false;
			String successMsg = isUpdate ? "msg_rights_updated_success"
					: "msg_rights_assigned_success";

			if (lstApprovedLinks != null && !lstApprovedLinks.isEmpty()) {
				for (Object object : lstApprovedLinks) {
					TblUserRightHistory tblUserRightHistory = new TblUserRightHistory();
					tblUserRightHistory.setTblDesignation(new TblDesignation(
							designationId));
					tblUserRightHistory.setTblLink(new TblLink(Integer
							.parseInt(object.toString())));
					tblUserRightHistory.setActionType(Integer
							.parseInt(actionTypeRemove));
					tblUserRightHistory.setCreatedBy(userId);

					lstUserRightHistory.add(tblUserRightHistory);
				}

				designationService.addUserRightsHistory(lstUserRightHistory);
			}
			

			List<TblUserRight> lstTblUserRights = new ArrayList<TblUserRight>();
			if(designationId != designationIdOfAprrove)
			{
			
				designationService.deleteApprovedLinksAll(designationId);
				
			for (int i = 0; i < lstApprovedLinks.size(); i++) {
				
				Object object = lstApprovedLinks.get(i);
				
				TblUserRight userRight = new TblUserRight();
				TblDesignation designation  = new TblDesignation();
				TblLink link = new TblLink();
				link.setLinkId(Integer.parseInt(object.toString()));
				designation.setDesignationId(designationId);
				userRight.setTblDesignation(designation);
				userRight.setTblLink(link);
				lstTblUserRights.add(userRight);
			}
			}
			else
			{
				
				designationService.deleteApprovedLinks(designationId, moduleId);
				String[] rightsLink = request.getParameterValues("chkRightsLink");
				if (rightsLink != null) {
					for (int i = 0; i < rightsLink.length; i++) {
						
							TblUserRight tblUserRight = new TblUserRight();
							tblUserRight.setTblDesignation(new TblDesignation(designationId));
							tblUserRight.setTblLink(new TblLink(Integer.parseInt(rightsLink[i].split("_")[0])));
							lstTblUserRights.add(tblUserRight);	
					}
				}

			}	

		
			
			
			boolean status = designationService.addRights(lstTblUserRights);
			
			if (lstTblUserRights != null && !lstTblUserRights.isEmpty()) {
				if (status) {
					lstUserRightHistory = new ArrayList<TblUserRightHistory>();
					lstApprovedLinks = designationService.getApprovedLinks(moduleId,designationId);

					if (lstApprovedLinks != null && !lstApprovedLinks.isEmpty()) {
						for (Object object : lstApprovedLinks) {
							TblUserRightHistory tblUserRightHistory = new TblUserRightHistory();
							tblUserRightHistory
									.setTblDesignation(new TblDesignation(
											designationId));
							tblUserRightHistory.setTblLink(new TblLink(Integer
									.parseInt(object.toString())));
							tblUserRightHistory.setActionType(Integer
									.parseInt(actionTypeAssign));
							tblUserRightHistory.setCreatedBy(userId);

							lstUserRightHistory.add(tblUserRightHistory);
						}

						designationService
								.addUserRightsHistory(lstUserRightHistory);
					}
				}
			}
			modelMap.addAttribute("successMsg", successMsg);
			redirectAttributes.addFlashAttribute(
					CommonKeywords.SUCCESS_MSG.toString(), successMsg);
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute(
					CommonKeywords.ERROR_MSG.toString(),
					CommonKeywords.ERROR_MSG_KEY.toString());
			exceptionHandlerService.writeLog(e);
		} finally {
			if (isUpdate) {
				auditTrailService.makeAuditTrail(request
						.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
						Integer.parseInt(assignRighstLinkId),
						postEditRightsAuditMsg, 0, 0);
			} else {
				auditTrailService.makeAuditTrail(request
						.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
						Integer.parseInt(assignRighstLinkId),
						postAssignRightsAuditMsg, 0, 0);
			}
		}
		return "redirect:/common/admin/managerights/"
				+ designationId
				+ "/"
				+ moduleId
				+ encryptDecryptUtils.generateRedirect(
						"common/admin/managerights/" + designationId + "/"
								+ moduleId, request);
	}

	@RequestMapping(value = "/admin/getaccesscontrolmatrix", method = RequestMethod.POST)
	public String retriveAccessControlMatrix(
			@RequestParam("txtModuleId") String moduleId,
			@RequestParam("txtDesignationId") String designationId,
			@RequestParam("txtDesigationIdForSave") String desigationIdForSave,
			@RequestParam("flag") String flag
			, ModelMap modelMap,
			HttpServletRequest req, HttpSession session) {
		try {
			
			
			desigationIdForSave = (req.getParameter("txtDesigationIdForSave") != null ? req.getParameter("txtDesigationIdForSave") : "0");
			
			int sessionDesignationId = 0;
			if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
				SessionBean sessionBean = (SessionBean) session
						.getAttribute(CommonKeywords.SESSION_OBJ.toString());
				sessionDesignationId = sessionBean.getDesignationId();

				List<AssignRightsDataBean> dataBeanList = new ArrayList<AssignRightsDataBean>();

				List<TblModule> lstModules = manageContentService
						.getModuleListByModuleId(Integer.parseInt(moduleId));
				List<TblSubModule> lstSubModules = manageContentService
						.getSubModuleListByModuleId(Integer.parseInt(moduleId));
				List<Object[]> lstEvent = manageContentService
						.getEventListByModuleId(Integer.parseInt(moduleId));
				List<Object[]> lstLinks = designationService.getApprovalLink(
						Integer.parseInt(designationId),
						Integer.parseInt(moduleId), sessionDesignationId);

				for (TblModule tblModule : lstModules) {
					for (TblSubModule tblSubModule : lstSubModules) {
						if (tblModule.getModuleId().equals(
								tblSubModule.getTblModule().getModuleId())) {
							AssignRightsDataBean assignRightsDataBean = new AssignRightsDataBean();
							assignRightsDataBean.setModuleId(tblModule
									.getModuleId());
							assignRightsDataBean.setSubmoduleId(tblSubModule
									.getSubModuleId());
							assignRightsDataBean
									.setModuleName(modelToSelectItem
											.getLangVal(tblSubModule, WebUtils
													.getCookie(req, "locale")
													.getValue()));
							List<SelectItem> eventList = new ArrayList<SelectItem>();
							List<List<SelectItem>> linkList = new ArrayList<List<SelectItem>>();
							for (Object[] tblEvent : lstEvent) {
								String submoduleId = String
										.valueOf(tblSubModule.getSubModuleId());
								String submoduleIdFK = String
										.valueOf(tblEvent[3]);
								// System.out.println(submoduleId+"::"+submoduleIdFK);
								if (submoduleId.equals(submoduleIdFK)) {
									eventList.add(new SelectItem(tblEvent[1],
											tblEvent[0]
													+ "_"
													+ tblSubModule
															.getSubModuleId()));
									List<SelectItem> linksList = new ArrayList<SelectItem>();
									for (Object[] tblLink : lstLinks) {
										String eventId = String
												.valueOf(tblEvent[0]);
										String eventIdFK = String
												.valueOf(tblLink[1]);
										if (eventId.equals(eventIdFK)) {
											linksList.add(new SelectItem(
													tblLink[3],
													tblLink[0] + "_"
															+ tblEvent[0],
													tblLink[2]));
										}
									}
									linkList.add(linksList);
								}
							}
							assignRightsDataBean.setRowSpan(eventList.size());
							assignRightsDataBean.setEventList(eventList);
							assignRightsDataBean.setActionLinksList(linkList);
							dataBeanList.add(assignRightsDataBean);
						}
					}
				}
				/*
				 * for (AssignRightsDataBean rightsDataBean : dataBeanList) {
				 * System.out.println("ModuleName " +
				 * rightsDataBean.getModuleName());
				 * System.out.println("Rowspan " + rightsDataBean.getRowSpan());
				 * for (SelectItem event : rightsDataBean.getEventList()) {
				 * System.out.println("Event : " + event.getLabel() + " " +
				 * event.getValue()); } for (List<SelectItem> selectItems :
				 * rightsDataBean.getActionLinksList()) {
				 * System.out.println("^^^^^^^^^^^^^^^^^^^^^"); for (SelectItem
				 * selectItem : selectItems) { System.out.println("Link : " +
				 * selectItem.getLabel() + " " + selectItem.getValue()); } } }
				 */
				boolean f = Boolean.parseBoolean(flag);
				modelMap.put("viewOnly", f);
				modelMap.put("dataBeanList", dataBeanList);
				modelMap.put("lstModules", lstModules);
				modelMap.put("designationId", designationId);
				modelMap.put("designationIdForSave", desigationIdForSave);
				modelMap.put("activeTabId", moduleId);
			} else {
				modelMap.addAttribute("sessionExpired", true);
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		// finally {
		// auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
		// Integer.parseInt(assignRighstLinkId),
		// ajaxGetAccessControlMatrixAuditMsg, 0, 0);
		// }
		return "/common/admin/AccessControlMatrix";
	}
	
	
	/**
	 * @author nirav.prajapati
	 * 
	 * @param request
	 * @param httpSession
	 * @param redirectAttributes
	 * @param modelMap
	 * @param pendingDesignationId
	 * @param aprroveDesignationId
	 * @param moduleId
	 * @return
	 */
	
	
	@RequestMapping(value = "/admin/addrightsfromapproveddesignation/{pendingDesignationId}/{aprroveDesignationId}/{moduleId}", method = RequestMethod.POST)
	public String addRightsOfapprovedDesignation(HttpServletRequest request,
			HttpSession httpSession, RedirectAttributes redirectAttributes,
			ModelMap modelMap,
			@PathVariable("pendingDesignationId") int pendingDesignationId,
			@PathVariable("aprroveDesignationId") int aprroveDesignationId,
			@PathVariable("moduleId") int moduleId
			) {
		
		
		boolean isUpdate = false;
		try {
			int userId = abcUtility.getSessionUserId(request);

			List<TblUserRightHistory> lstUserRightHistory = new ArrayList<TblUserRightHistory>();

			List<Object> lstApprovedLinks = designationService.getApprovedLinks(moduleId,aprroveDesignationId);
			
			isUpdate = lstApprovedLinks.size() > 0 ? true : false;
			String successMsg = isUpdate ? "msg_rights_updated_success"
					: "msg_rights_assigned_success";

			if (lstApprovedLinks != null && !lstApprovedLinks.isEmpty()) {
				for (Object object : lstApprovedLinks) {
					TblUserRightHistory tblUserRightHistory = new TblUserRightHistory();
					tblUserRightHistory.setTblDesignation(new TblDesignation(
							pendingDesignationId));
					tblUserRightHistory.setTblLink(new TblLink(Integer
							.parseInt(object.toString())));
					tblUserRightHistory.setActionType(Integer
							.parseInt(actionTypeRemove));
					tblUserRightHistory.setCreatedBy(userId);

					lstUserRightHistory.add(tblUserRightHistory);
				}

				designationService.addUserRightsHistory(lstUserRightHistory);
			}
			

			List<TblUserRight> lstTblUserRights = new ArrayList<TblUserRight>();
			if(pendingDesignationId != aprroveDesignationId)
			{
			
				designationService.deleteApprovedLinksAll(pendingDesignationId);
				
				for (int i = 0; i < lstApprovedLinks.size(); i++) {
				
					Object object = lstApprovedLinks.get(i);
					
					TblUserRight userRight = new TblUserRight();
					TblDesignation designation  = new TblDesignation();
					TblLink link = new TblLink();
					link.setLinkId(Integer.parseInt(object.toString()));
					designation.setDesignationId(pendingDesignationId);
					userRight.setTblDesignation(designation);
					userRight.setTblLink(link);
					lstTblUserRights.add(userRight);
				}
			}
			boolean status = designationService.addRights(lstTblUserRights);
			
			if (lstTblUserRights != null && !lstTblUserRights.isEmpty()) {
				if (status) {
					lstUserRightHistory = new ArrayList<TblUserRightHistory>();
					lstApprovedLinks = designationService.getApprovedLinks(moduleId,pendingDesignationId);

					if (lstApprovedLinks != null && !lstApprovedLinks.isEmpty()) {
						for (Object object : lstApprovedLinks) {
							TblUserRightHistory tblUserRightHistory = new TblUserRightHistory();
							tblUserRightHistory
									.setTblDesignation(new TblDesignation(
											pendingDesignationId));
							tblUserRightHistory.setTblLink(new TblLink(Integer
									.parseInt(object.toString())));
							tblUserRightHistory.setActionType(Integer
									.parseInt(actionTypeAssign));
							tblUserRightHistory.setCreatedBy(userId);

							lstUserRightHistory.add(tblUserRightHistory);
						}

						designationService
								.addUserRightsHistory(lstUserRightHistory);
					}
				}
			}
			modelMap.addAttribute("successMsg", successMsg);
			redirectAttributes.addFlashAttribute(
					CommonKeywords.SUCCESS_MSG.toString(), successMsg);
		} catch (Exception e) {
			redirectAttributes.addFlashAttribute(
					CommonKeywords.ERROR_MSG.toString(),
					CommonKeywords.ERROR_MSG_KEY.toString());
			exceptionHandlerService.writeLog(e);
		} finally {
			if (isUpdate) {
				auditTrailService.makeAuditTrail(request
						.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
						Integer.parseInt(assignRighstLinkId),
						postEditRightsAuditMsg, 0, 0);
			} else {
				auditTrailService.makeAuditTrail(request
						.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
						Integer.parseInt(assignRighstLinkId),
						postAssignRightsAuditMsg, 0, 0);
			}
		}
		return "redirect:/common/admin/managerights/"
				+ pendingDesignationId
				+ "/"
				+ moduleId
				+ encryptDecryptUtils.generateRedirect(
						"common/admin/managerights/" + pendingDesignationId + "/"
								+ moduleId, request);
	}

	
	
}
