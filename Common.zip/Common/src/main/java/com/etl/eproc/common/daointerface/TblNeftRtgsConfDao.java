package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblNeftRtgsConf;
import java.util.List;

public interface TblNeftRtgsConfDao  {

    public void addTblNeftRtgsConf(TblNeftRtgsConf tblNeftRtgsConf);

    public void deleteTblNeftRtgsConf(TblNeftRtgsConf tblNeftRtgsConf);

    public void updateTblNeftRtgsConf(TblNeftRtgsConf tblNeftRtgsConf);

    public List<TblNeftRtgsConf> getAllTblNeftRtgsConf();

    public List<TblNeftRtgsConf> findTblNeftRtgsConf(Object... values) throws Exception;

    public List<TblNeftRtgsConf> findByCountTblNeftRtgsConf(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNeftRtgsConfCount();

    public void saveUpdateAllTblNeftRtgsConf(List<TblNeftRtgsConf> tblNeftRtgsConfs);

	public void saveOrUpdateTblNeftRtgsConf(TblNeftRtgsConf tblNeftRtgsConf);
}