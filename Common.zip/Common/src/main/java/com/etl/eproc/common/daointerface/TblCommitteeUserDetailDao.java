package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCommitteeUserDetail;
import java.util.List;

public interface TblCommitteeUserDetailDao  {

    public void addTblCommitteeUserDetail(TblCommitteeUserDetail tblCommitteeUserDetail);

    public void deleteTblCommitteeUserDetail(TblCommitteeUserDetail tblCommitteeUserDetail);

    public void updateTblCommitteeUserDetail(TblCommitteeUserDetail tblCommitteeUserDetail);

    public List<TblCommitteeUserDetail> getAllTblCommitteeUserDetail();

    public List<TblCommitteeUserDetail> findTblCommitteeUserDetail(Object... values) throws Exception;

    public List<TblCommitteeUserDetail> findByCountTblCommitteeUserDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCommitteeUserDetailCount();

    public void saveUpdateAllTblCommitteeUserDetail(List<TblCommitteeUserDetail> tblCommitteeUserDetails);
}