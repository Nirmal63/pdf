/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;

/**
 *
 * @author mahesh.patel
 */

import com.etl.eproc.common.model.TblFaq;

import java.util.List;
import java.util.Map;

public interface TblFaqDao  {
	
	
	public void saveOrUpdateEntity(TblFaq tblFaq);
	
	public void addTblFaq(TblFaq tblFaq);

    public void deleteTblFaq(TblFaq tblFaq);

    public void updateTblFaq(TblFaq tblFaq);

    public List<TblFaq> getAllTblFaq();

    public List<TblFaq> findTblFaq(Object... values) throws Exception;

    public List<TblFaq> findByCountTblFaq(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFaqCount();

    public void saveUpdateAllTblFaq(List<TblFaq> tblFaqs);
    
    int updateDeleteNewQuery(String query,Map<String,Object> var);
}