package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCurrency;
import java.util.List;

public interface TblCurrencyDao  {

    public void addTblCurrency(TblCurrency tblCurrency);

    public void deleteTblCurrency(TblCurrency tblCurrency);

    public void updateTblCurrency(TblCurrency tblCurrency);

    public List<TblCurrency> getAllTblCurrency();

    public List<TblCurrency> findTblCurrency(Object... values) throws Exception;

    public List<TblCurrency> findByCountTblCurrency(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCurrencyCount();

    public void saveUpdateAllTblCurrency(List<TblCurrency> tblCurrencys);
}