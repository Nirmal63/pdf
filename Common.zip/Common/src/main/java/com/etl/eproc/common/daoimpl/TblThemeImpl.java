package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblThemeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblTheme;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblThemeImpl extends AbcAbstractClass<TblTheme> implements TblThemeDao {

    @Override
    public void addTblTheme(TblTheme tblTheme){
        super.addEntity(tblTheme);
    }

    @Override
    public void deleteTblTheme(TblTheme tblTheme) {
        super.deleteEntity(tblTheme);
    }

    @Override
    public void updateTblTheme(TblTheme tblTheme) {
        super.updateEntity(tblTheme);
    }

    @Override
    public List<TblTheme> getAllTblTheme() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTheme> findTblTheme(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblThemeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTheme> findByCountTblTheme(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTheme(List<TblTheme> tblThemes){
        super.updateAll(tblThemes);
    }
}
