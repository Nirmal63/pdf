package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblClientRuleDao;
import com.etl.eproc.common.model.TblClientRule;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientRuleImpl extends AbcAbstractClass<TblClientRule> implements TblClientRuleDao {

    @Override
    public void addTblClientRule(TblClientRule tblClientRule){
        super.addEntity(tblClientRule);
    }

    @Override
    public void deleteTblClientRule(TblClientRule tblClientRule) {
        super.deleteEntity(tblClientRule);
    }

    @Override
    public void updateTblClientRule(TblClientRule tblClientRule) {
        super.updateEntity(tblClientRule);
    }

    @Override
    public List<TblClientRule> getAllTblClientRule() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientRule> findTblClientRule(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientRuleCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientRule> findByCountTblClientRule(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientRule(List<TblClientRule> tblClientRules){
        super.updateAll(tblClientRules);
    }
}

