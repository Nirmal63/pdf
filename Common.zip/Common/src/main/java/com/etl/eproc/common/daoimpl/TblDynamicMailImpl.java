/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblDynamicMailDao;
import com.etl.eproc.common.model.TblDynamicMailContent;

/**
 *
 * @author shreyansh.shah
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDynamicMailImpl extends AbcAbstractClass<TblDynamicMailContent> implements TblDynamicMailDao {

    @Override
    public List<TblDynamicMailContent> getAllTblDynamicMailContent() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynamicMailContent> findTblDynamicMailContent(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynamicMailContentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynamicMailContent> findByCountTblDynamicMailContent(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void addTblDynamicMailContent(TblDynamicMailContent tblusermaster) {
        super.addEntity(tblusermaster);
    }

    @Override
    public void deleteTblDynamicMailContent(TblDynamicMailContent tblusermaster) {
        super.deleteEntity(tblusermaster);
    }

    @Override
    public void updateTblDynamicMailContent(TblDynamicMailContent tblusermaster) {
        super.updateEntity(tblusermaster);
    }
}
