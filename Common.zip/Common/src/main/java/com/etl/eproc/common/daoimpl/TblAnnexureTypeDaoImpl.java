package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblAnnexureTypeDao;
import com.etl.eproc.common.model.TblAnnexureType;

/**
 *
 * @author Hema
 */
@Repository @Transactional    /*StackUpdate*/
public class TblAnnexureTypeDaoImpl extends AbcAbstractClass<TblAnnexureType> implements TblAnnexureTypeDao {
	
    @Override
    public void addTblAnnexureType(TblAnnexureType TblAnnexureType){
        super.addEntity(TblAnnexureType);
    }

    @Override
    public void deleteTblAnnexureType(TblAnnexureType TblAnnexureType) {
        super.deleteEntity(TblAnnexureType);
    }

    @Override
    public void updateTblAnnexureType(TblAnnexureType TblAnnexureType) {
        super.updateEntity(TblAnnexureType);
    }

    @Override
    public List<TblAnnexureType> getAllTblAnnexureType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAnnexureType> findTblAnnexureType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAnnexureTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAnnexureType> findByCountTblAnnexureType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }
}
