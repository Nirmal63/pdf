package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblHintQuestion;
import java.util.List;

public interface TblHintQuestionDao  {

    public void addTblHintQuestion(TblHintQuestion tblHintQuestion);

    public void deleteTblHintQuestion(TblHintQuestion tblHintQuestion);

    public void updateTblHintQuestion(TblHintQuestion tblHintQuestion);

    public List<TblHintQuestion> getAllTblHintQuestion();

    public List<TblHintQuestion> findTblHintQuestion(Object... values) throws Exception;

    public List<TblHintQuestion> findByCountTblHintQuestion(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblHintQuestionCount();

    public void saveUpdateAllTblHintQuestion(List<TblHintQuestion> tblHintQuestions);
}