package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientField;
import java.util.List;

public interface TblClientFieldDao  {

    public void addTblClientField(TblClientField tblClientField);

    public void deleteTblClientField(TblClientField tblClientField);

    public void updateTblClientField(TblClientField tblClientField);

    public List<TblClientField> getAllTblClientField();

    public List<TblClientField> findTblClientField(Object... values) throws Exception;

    public List<TblClientField> findByCountTblClientField(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientFieldCount();

    public void saveUpdateAllTblClientField(List<TblClientField> tblClientFields);

	public void saveOrUpdateTblClientField(TblClientField tblClientField);
}