package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblDynControlTypeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblDynControlType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDynControlTypeImpl extends AbcAbstractClass<TblDynControlType> implements TblDynControlTypeDao {

    @Override
    public void addTblDynControlType(TblDynControlType tblDynControlType){
        super.addEntity(tblDynControlType);
    }

    @Override
    public void deleteTblDynControlType(TblDynControlType tblDynControlType) {
        super.deleteEntity(tblDynControlType);
    }

    @Override
    public void updateTblDynControlType(TblDynControlType tblDynControlType) {
        super.updateEntity(tblDynControlType);
    }

    @Override
    public List<TblDynControlType> getAllTblDynControlType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDynControlType> findTblDynControlType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDynControlTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDynControlType> findByCountTblDynControlType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDynControlType(List<TblDynControlType> tblDynControlTypes){
        super.updateAll(tblDynControlTypes);
    }
}
