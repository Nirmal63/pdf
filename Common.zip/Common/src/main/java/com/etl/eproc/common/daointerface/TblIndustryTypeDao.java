/**
 * 
 */
package com.etl.eproc.common.daointerface;

/**
 * @author janak
 *
 */

import com.etl.eproc.common.model.TblIndustryType;
import java.util.List;

public interface TblIndustryTypeDao  {

    public void addTblIndustryType(TblIndustryType tblIndustryType);

    public void deleteTblIndustryType(TblIndustryType tblIndustryType);

    public void updateTblIndustryType(TblIndustryType tblIndustryType);

    public List<TblIndustryType> getAllTblIndustryType();

    public List<TblIndustryType> findTblIndustryType(Object... values) throws Exception;

    public List<TblIndustryType> findByCountTblIndustryType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblIndustryTypeCount();

    public void saveUpdateAllTblIndustryType(List<TblIndustryType> tblIndustryTypes);
}