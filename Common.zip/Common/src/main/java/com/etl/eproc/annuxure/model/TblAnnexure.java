package com.etl.eproc.annuxure.model;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.core.style.ToStringCreator;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClmClause;
import com.etl.eproc.etender.model.TblTenderTermsheetMapping;
@Entity
@Table(name="tbl_Annexure",schema ="appcommon")
public class TblAnnexure implements java.io.Serializable {
	private int annexureId;
	private String annexureName;
	private int cStatus;
	private TblClient tblClient;
	private int createdBy;
	private Date createdOn;
	private int acceptedBy;
	private Date acceptedOn;
	private String acceptedRemarks;
	private int updatedBy;
	private Date updatedOn;
	private int cancelledBy;
	private Date cancelledOn;
	private String cancelledRemarks; 
	
	private Set<TblAnxType> tblAnnexureType = new HashSet<TblAnxType>();
	@OneToMany(cascade = CascadeType.ALL,  mappedBy = "annexure")
	public Set<TblAnxType> getTblAnnexureType() {
		return this.tblAnnexureType;
	}
	public void setTblAnnexureType(Set<TblAnxType> tblAnnexureType) {
		this.tblAnnexureType = tblAnnexureType;
	}
	
	private Set<TblAnxClause> tblAnxClause = new HashSet<TblAnxClause>();
	@OneToMany(cascade = CascadeType.ALL , mappedBy = "tblAnnexure")
	public Set<TblAnxClause> getTblAnxClause() {
		return tblAnxClause;
	}
	
	public void setTblAnxClause(Set<TblAnxClause> tblAnxClause) {
		this.tblAnxClause = tblAnxClause;
	}
	
	
	 private Set<TblTenderTermsheetMapping> tblTenderTermsheetMappings;
	 
	 @OneToMany(mappedBy = "tblAnnexure")
	
		public Set<TblTenderTermsheetMapping> getTblTenderTermsheetMappings() {
			return tblTenderTermsheetMappings;
		}
		public void setTblTenderTermsheetMappings(Set<TblTenderTermsheetMapping> tblTenderTermsheetMappings) {
			this.tblTenderTermsheetMappings = tblTenderTermsheetMappings;
		}
	


	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "annexureId", unique = true, nullable = false)
	public int getAnnexureId() {
		return annexureId;
	}
	public void setAnnexureId(int annexureId) {
		this.annexureId = annexureId;
	}
	public String getAnnexureName() {
		return annexureName;
	}
	public void setAnnexureName(String annexureName) {
		this.annexureName = annexureName;
	}
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "clientid")
	public TblClient getTblClient() {
		return tblClient;
	}
	public void setTblClient(TblClient tblClient) {
		this.tblClient = tblClient;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "createdOn", nullable = false, updatable = false, insertable = false)
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	
	@Column(name = "acceptBy")
	public int getAcceptedBy() {
		return acceptedBy;
	}
	@Column(name = "acceptBy")
	public void setAcceptedBy(int acceptedBy) {
		this.acceptedBy = acceptedBy;
	}
	@Column(name = "acceptOn")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getAcceptedOn() {
		return acceptedOn;
	}
	@Column(name = "acceptOn")
	public void setAcceptedOn(Date acceptedOn) {
		this.acceptedOn = acceptedOn;
	}
	public int getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Temporal(TemporalType.TIMESTAMP)
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	@Column(name = "cancelBy")
	public int getCancelledBy() {
		return cancelledBy;
	}
	@Column(name = "cancelBy")
	public void setCancelledBy(int cancelledBy) {
		this.cancelledBy = cancelledBy;
	}
	@Column(name = "cancelOn")
	@Temporal(TemporalType.TIMESTAMP)
	public Date getCancelledOn() {
		return cancelledOn;
	}
	@Column(name = "cancelOn")
	public void setCancelledOn(Date cancelledOn) {
		this.cancelledOn = cancelledOn;
	}
	public int getcStatus() {
		return cStatus;
	}
	public void setcStatus(int cStatus) {
		this.cStatus = cStatus;
	}
	public String getAcceptedRemarks() {
		return acceptedRemarks;
	}
	public void setAcceptedRemarks(String acceptedRemarks) {
		this.acceptedRemarks = acceptedRemarks;
	}
	public String getCancelledRemarks() {
		return cancelledRemarks;
	}
	public void setCancelledRemarks(String cancelledRemarks) {
		this.cancelledRemarks = cancelledRemarks;
	}
	
	
	@Override
	public String toString() {
		return new ToStringCreator(this).append("acceptedBy", this.getAcceptedBy())
				.append("acceptedOn", this.getAcceptedOn())
				.append("acceptedRemarks", this.getAcceptedRemarks())
				.append("cancelledBy", this.getCancelledBy())
				.append("cancelledOn", this.getCancelledOn())
				.append("cancelledRemarks", this.getCancelledRemarks())
				.append("annexureId", this.getAnnexureId())
				.append("createdBy", this.getCreatedBy())
				.append("createdOn", this.getCreatedOn())
				.append("cStatus", this.getcStatus())
				.append("annexureName", this.getAnnexureName())
				.append("updatedBy", this.getUpdatedBy())
				.append("updatedOn", this.getUpdatedOn())
				.toString();
	}
	public TblAnnexure() {
	}
	public TblAnnexure(int annexureId) {
		this.annexureId = annexureId;
	}
	
	
	
}