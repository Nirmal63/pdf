package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblNegotiationSummary;
import java.util.List;

public interface TblNegotiationSummaryDao  {

    public void addTblNegotiationSummary(TblNegotiationSummary tblNegotiationSummary);

    public void deleteTblNegotiationSummary(TblNegotiationSummary tblNegotiationSummary);

    public void updateTblNegotiationSummary(TblNegotiationSummary tblNegotiationSummary);

    public List<TblNegotiationSummary> getAllTblNegotiationSummary();

    public List<TblNegotiationSummary> findTblNegotiationSummary(Object... values) throws Exception;

    public List<TblNegotiationSummary> findByCountTblNegotiationSummary(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNegotiationSummaryCount();

    public void saveUpdateAllTblNegotiationSummary(List<TblNegotiationSummary> tblNegotiationSummarys);

	public void saveOrUpdateTblNegotiationSummary(TblNegotiationSummary tblnegotiationsummary);
}