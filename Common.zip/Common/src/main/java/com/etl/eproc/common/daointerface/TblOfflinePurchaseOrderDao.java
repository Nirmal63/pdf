package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblOfflinePurchaseOrder;
import java.util.List;

public interface TblOfflinePurchaseOrderDao  {

    public void addTblOfflinePurchaseOrder(TblOfflinePurchaseOrder tblOfflinePurchaseOrder);

    public void deleteTblOfflinePurchaseOrder(TblOfflinePurchaseOrder tblOfflinePurchaseOrder);

    public void updateTblOfflinePurchaseOrder(TblOfflinePurchaseOrder tblOfflinePurchaseOrder);

    public List<TblOfflinePurchaseOrder> getAllTblOfflinePurchaseOrder();

    public List<TblOfflinePurchaseOrder> findTblOfflinePurchaseOrder(Object... values) throws Exception;

    public List<TblOfflinePurchaseOrder> findByCountTblOfflinePurchaseOrder(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblOfflinePurchaseOrderCount();

    public void saveUpdateAllTblOfflinePurchaseOrder(List<TblOfflinePurchaseOrder> tblOfflinePurchaseOrders);
}