package com.etl.eproc.common.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblCountry;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblDrtClientDepartment;
import com.etl.eproc.common.model.TblState;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentService;
import com.etl.eproc.common.services.DrtService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SelectItem;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/common")
public class DepartmentController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private CommonService commonService;
    @Autowired
    private DrtService drtService;
    @Autowired
    private DepartmentService departmentService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private ModelToSelectItem modelToSelectItem;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private ClientService clientService;
    @Value("#{linkProperties['manage_department_create_department']?:6}")
    private int createDeptLinkId;
    @Value("#{linkProperties['manage_department_edit_department']?:7}")
    private int editDeptLinkId;
    @Value("#{linkProperties['manage_department_view_department']?:8}")
    private int viewDeptLinkId;
    @Value("#{linkProperties['report_admin_manage_department']?:2}")
    private int manageDepartmentReportId;
    @Value("#{linkProperties['manage_department_activate']?:156}")
    private int activeDepartmentLinkId;
    @Value("#{linkProperties['manage_department_deactivate']?:157}")
    private int deActiveDepartmentLinkId;
    @Value("#{adminAuditTrailProperties['getManageDeptRemark']}")
    private String getManageDeptRemark;
    @Value("#{adminAuditTrailProperties['getDeptCreateRemark']}")
    private String getDeptCreateRemark;
    @Value("#{adminAuditTrailProperties['postDeptAddRemark']}")
    private String postDeptAddRemark;
    @Value("#{adminAuditTrailProperties['getDeptEditRemark']}")
    private String getDeptEditRemark;
    @Value("#{adminAuditTrailProperties['postDeptEditRemark']}")
    private String postDeptEditRemark;
    @Value("#{adminAuditTrailProperties['getViewDept']}")
    private String getViewDept;
    @Value("#{adminAuditTrailProperties['postActiveDeptRemark']}")
    private String postActiveDeptRemark;
    @Value("#{adminAuditTrailProperties['postInActiveDeptRemark']}")
    private String postInActiveDeptRemark;
    

    @RequestMapping(value = "/admin/managedepartment/{enc}", method = RequestMethod.GET)
    public String manageDepartment(ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("reportId", manageDepartmentReportId);
            reportGeneratorService.getReportConfigDetails(manageDepartmentReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getManageDeptRemark, 0, 0);
        }
        return "common/admin/ManageDepartment";
    }
    
    @RequestMapping(value = "/admin/activeinactivedepartment/{deptId}/{status}/{enc}", method = RequestMethod.GET)
    public String activeInActiveDepartment(ModelMap modelMap,@PathVariable("deptId") int deptId,@PathVariable("status") int status, HttpServletRequest request , RedirectAttributes redirectAttributes) {
    	boolean success= false;
    	String retVal=null;
        try {
            success=departmentService.activeInActiveDepartment(deptId,status,abcUtility.getSessionUserId(request));
            retVal = "common/admin/managedepartment";
            retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
        } catch (Exception ex) {
            retVal=exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),status==1?activeDepartmentLinkId:deActiveDepartmentLinkId,status==1?postActiveDeptRemark:postInActiveDeptRemark, 0, deptId);
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? status==1?"redirect_success_active":"redirect_success_deactive" : CommonKeywords.ERROR_MSG_KEY.toString());
        return retVal;
    }
    /**
     * Use for create department
     *
     * @author nirav.modi
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/createdeparment/{enc}", method = RequestMethod.GET)
    public String createDeparment(ModelMap modelMap, HttpServletRequest request, HttpSession session) {
        try {
        	int clientId=abcUtility.getSessionClientId(request);
        	String langId=WebUtils.getCookie(request, "locale").getValue();
            modelMap.put("countryList",modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId));
            modelMap.put("clientId",clientId);
            List<SelectItem> bankList = abcUtility.convert(drtService.getBankSectorClient(3));  // Here 3 for Bank Sector              
            modelMap.addAttribute("bankList", bankList);
            List<Object[]> dataList=departmentService.getStateIdByClientId(clientId);
            if(dataList!=null && !dataList.isEmpty()){
            	Object[] obj=dataList.get(0);
            	modelMap.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId((Integer)obj[1]), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
            	modelMap.put("stateId",obj[0]);
            	modelMap.put("countryId",obj[1]);
            }
            ClientBean clientBean = (ClientBean) session.getAttribute(CommonKeywords.CLIENT_OBJ.toString());            
            List<Object> lstSector = clientService.getClientSector(clientBean.getClientId());            
            boolean showBank = false;
            // Select Bank will only display If Client is map with DRT(Sector Id 1) Or Sarfaesi(Sector Id 2) Or  Or Bank(Sector Id 3)
            for(Object obj:lstSector){
                if((Integer)obj == 1 || (Integer)obj == 2 || (Integer)obj == 3){
                        showBank = true;
                        break;
                }
            }
            modelMap.put("showBank", showBank);
            Object obj[]=clientService.getClientFields(clientId,"isGSTRequired,gstNo");
            modelMap.addAttribute("isGSTRequired", obj[0]);
            modelMap.addAttribute("ClientGstNo", obj[1]);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createDeptLinkId,getDeptCreateRemark, 0, 0);
        }
        return "common/admin/CreateDeparment";
    }

    /**
     * Use to submit details of new Department
     *
     * @author nirav.modi
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/adddeparment", method = RequestMethod.POST)
    public String addDepartment(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        String retVal = null;
        TblDepartment tblDepartment = null;
        boolean isDeptAlreadyExist = false;
        try {
            int userId = abcUtility.getSessionUserId(request);
            tblDepartment = new TblDepartment();
            TblCountry tblCountry = new TblCountry();
            TblState tblState = new TblState();
            TblClient tblClient = new TblClient();
            TblDrtClientDepartment tblDrtClientDepartment = new TblDrtClientDepartment();

            String clientId = request.getParameter("hdClientId");
            String departmentName = request.getParameter("txtDepartmentName");
            String address = request.getParameter("txtaAddress");
            String countryId = request.getParameter("selCountry");
            String city = request.getParameter("txtCity");
            String stateId = request.getParameter("selState");
            String phoneNo = request.getParameter("txtMobileNumber");
            String parentDeptId = request.getParameter("txtParentDepartment");
            String deptGstNo = request.getParameter("txtGstNo");
            if (clientId != null && departmentName != null && countryId != null && city != null && stateId != null && phoneNo != null && parentDeptId != null && !parentDeptId.equals("")) {
                if (commonService.checkUniqueDepartmentName(Integer.parseInt(clientId), departmentName, 0, Integer.parseInt(parentDeptId))) {
                    isDeptAlreadyExist = true;
                    retVal = "common/admin/createdeparment";
                    redirectAttributes.addFlashAttribute("isDeptAlreadyExist", "true");
                }
                if (!isDeptAlreadyExist) {
                    tblClient.setClientId(Integer.parseInt(clientId));
                    tblState.setStateId(Integer.parseInt(stateId));
                    tblCountry.setCountryId(Integer.parseInt(countryId));

                    tblDepartment.setTblClient(tblClient);                    
                    tblDepartment.setTblCountry(tblCountry);
                    tblDepartment.setTblState(tblState);

                    tblDepartment.setDeptName(departmentName);
                    tblDepartment.setAddress(address);
                    tblDepartment.setPhoneNo(phoneNo);
                    tblDepartment.setParentDeptId(Integer.parseInt(parentDeptId));
                    tblDepartment.setCity(city);
                    tblDepartment.setCreatedBy(userId);
                    tblDepartment.setCstatus(1);
                    tblDepartment.setGstNo(deptGstNo);
                    success = departmentService.addDepartment(tblDepartment);
                   
                    if(request.getParameter("selBank") != null){
                        int bankId = Integer.valueOf(request.getParameter("selBank"));
                        
                        tblClient.setClientId(bankId);
                        tblDrtClientDepartment.setTblClient(tblClient);
                        tblDrtClientDepartment.setTblDepartment(tblDepartment);
                        tblDrtClientDepartment.setCreatedBy(userId);
                        tblDrtClientDepartment.setIsActive(1);
                        
                        success = departmentService.addDRTClietDept(tblDrtClientDepartment);
                    }
                   
                    
                    retVal = success?"common/admin/managedepartment" : "common/admin/createdeparment";
                }
            } else {
                retVal = "common/admin/createdeparment";
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createDeptLinkId, postDeptAddRemark, 0, tblDepartment != null ? tblDepartment.getDeptId() : 0);
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_create_dept" : CommonKeywords.ERROR_MSG_KEY.toString());
        return "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    }

    /**
     * Use to get edit details of department for edit page
     *
     * @author nirav.modi
     * @param modelMap
     * @param deptId
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/editdepartment/{deptId}/{enc}", method = RequestMethod.GET)
    public String getEditDepartmentDetails(ModelMap modelMap, @PathVariable("deptId") int deptId, HttpServletRequest request, HttpSession session) {
        try {
            TblDepartment tblDepartment = departmentService.getDepartmentById(deptId);
            int countryId = tblDepartment.getTblCountry().getCountryId();
            String langId=WebUtils.getCookie(request, "locale").getValue();
            modelMap.put("countryList", modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId));
            modelMap.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId(countryId), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
            modelMap.put("clientId", abcUtility.getSessionClientId(request));
            modelMap.put("tblDepartment", tblDepartment);
            List<Object[]> bankListdata = null;
            boolean isUpdate = false;
            String oldBankid = "0";
            
            ClientBean clientBean = (ClientBean) session.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            List<Object> lstSector = clientService.getClientSector(clientBean.getClientId());            
            boolean showBank = false;
            // Select Bank will only display If Client is map with DRT(Sector Id 1) Or Sarfaesi(Sector Id 2) Or  Or Bank(Sector Id 3)
            for(Object obj:lstSector){
                if((Integer)obj == 1 || (Integer)obj == 2 || (Integer)obj == 3){
                        showBank = true;
                        bankListdata = drtService.getBankSectorClientForUpdate(deptId);
                        if (bankListdata != null) {
                        for (Object[] objects : bankListdata) {
                            if (objects.length >= 3) {
                                if(objects[2] != null){
                                    oldBankid = objects[0].toString();                                   
                                    break;
                                }
                            }                
                        }
                    }
                    break;
                }
            }
            modelMap.put("showBank", showBank);
            
            modelMap.addAttribute("oldBankid", oldBankid);
            List<SelectItem> bankList = abcUtility.convertSelected(bankListdata);                   
            modelMap.addAttribute("bankList", bankList);            
            Object obj[]=clientService.getClientFields(abcUtility.getSessionClientId(request),"isGSTRequired,gstNo");
            modelMap.addAttribute("isGSTRequired", obj[0]);
            modelMap.addAttribute("ClientGstNo", obj[1]);
            modelMap.put("opType", "update");
        } catch (Exception ex) {            
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editDeptLinkId, getDeptEditRemark, 0, deptId);
        }
        return "common/admin/CreateDeparment";
    }

    /**
     * Use to update department
     *
     * @author nirav.modi
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/updatedeparment", method = RequestMethod.POST)
    public String updateDepartment(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        String retVal = null;
        String deptId = null;         
        try {
            deptId = request.getParameter("hdDeptId");
            String clientId = request.getParameter("hdClientId");
            String departmentName = request.getParameter("txtDepartmentName");
            String address = request.getParameter("txtaAddress");
            String countryId = request.getParameter("selCountry");
            String city = request.getParameter("txtCity");
            String stateId = request.getParameter("selState");
            String phoneNo = request.getParameter("txtMobileNumber");
            String parentDeptId = request.getParameter("txtParentDepartment");
            String bankId = request.getParameter("selBank") != null ? request.getParameter("selBank") : "0";
            String deptGstNo = request.getParameter("txtGstNo");        
            String oldBankId = request.getParameter("hdOldBankid")!= null ? request.getParameter("hdOldBankid") : "0";
            
            if (deptId != null && clientId != null && departmentName != null && countryId != null && city != null && stateId != null && phoneNo != null && parentDeptId != null) {
                TblDepartment tblDepartment = new TblDepartment();
                TblCountry tblCountry = new TblCountry();
                TblState tblState = new TblState();
                TblClient tblClient = new TblClient();
                
                tblClient.setClientId(Integer.parseInt(clientId));
                tblState.setStateId(Integer.parseInt(stateId));
                tblCountry.setCountryId(Integer.parseInt(countryId));
                tblDepartment.setTblClient(tblClient);
                tblDepartment.setTblCountry(tblCountry);
                tblDepartment.setTblState(tblState);
                tblDepartment.setCstatus(1);
                tblDepartment.setCreatedBy(abcUtility.getSessionUserId(request));
                tblDepartment.setDeptId(Integer.parseInt(deptId));
                tblDepartment.setDeptName(departmentName);
                tblDepartment.setAddress(address);
                tblDepartment.setPhoneNo(phoneNo);
                tblDepartment.setParentDeptId(Integer.parseInt(parentDeptId));
                tblDepartment.setCity(city);
                tblDepartment.setGstNo(deptGstNo);
                success = departmentService.updateDepartment(tblDepartment);
                if(!oldBankId.equalsIgnoreCase(bankId)){
                    int isSuccess = departmentService.updateDRTClietDept(deptId);
                    
                    if((isSuccess != 0 && Integer.valueOf(bankId) != 0) || (oldBankId.equals("0") && Integer.valueOf(bankId) != 0)){
                        TblDrtClientDepartment tblDrtClientDepartment = new TblDrtClientDepartment();
                        int userId = abcUtility.getSessionUserId(request);
                        tblClient.setClientId(Integer.valueOf(bankId));
                        tblDrtClientDepartment.setTblClient(tblClient);
                        tblDrtClientDepartment.setTblDepartment(tblDepartment);
                        tblDrtClientDepartment.setCreatedBy(userId);
                        tblDrtClientDepartment.setIsActive(1);
                        
                        success = departmentService.addDRTClietDept(tblDrtClientDepartment);
                    }
                }
                retVal = success? "common/admin/managedepartment" : "common/admin/editdepartment/" + deptId;
            } else {
                retVal = "common/admin/editdepartment/" + deptId;
            }
        } catch (Exception ex) {
             return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editDeptLinkId, postDeptEditRemark, 0, deptId != null ? Integer.parseInt(deptId) : 0);
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_update_dept" : CommonKeywords.ERROR_MSG_KEY.toString());
        return "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
    }

    /**
     * Use to view department details
     *
     * @author nirav.modi
     * @param modelMap
     * @param deptId
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/viewdepartment/{deptId}/{enc}", method = RequestMethod.GET)
    public String viewDepartment(ModelMap modelMap, @PathVariable("deptId") int deptId, HttpServletRequest request) {
        try {
            Map<String, Object> departmentDetailMap = null;
            List<Object[]> departmentDetails = departmentService.viewDepartment(deptId);
            if (departmentDetails != null && !departmentDetails.isEmpty()) {
                Object[] objs = departmentDetails.get(0);
                departmentDetailMap = new HashMap<String, Object>();
                departmentDetailMap.put("countryName", objs[0]);
                departmentDetailMap.put("state", objs[1]);
                departmentDetailMap.put("deptName", objs[2]);
                departmentDetailMap.put("address", objs[3]);
                departmentDetailMap.put("city", objs[4]);
                departmentDetailMap.put("phoneNo", objs[5]);
                departmentDetailMap.put("parentDeptName", objs[6]);
                departmentDetailMap.put("deptGstNo", objs[7]);
                int isGstRequired = (Integer)clientService.getClientField((Integer)objs[8], "isGSTRequired");
                departmentDetailMap.put("isGSTRequired", isGstRequired);
            }
            modelMap.put("departmentDetailMap", departmentDetailMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), viewDeptLinkId, getViewDept, 0, deptId);
        }
        return "common/admin/ViewDepartment";
    }
}
