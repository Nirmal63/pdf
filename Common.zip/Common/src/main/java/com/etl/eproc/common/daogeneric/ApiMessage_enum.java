package com.etl.eproc.common.daogeneric;

public enum ApiMessage_enum {

	BAD_REQUEST						("Bad Request"),
	INTERNAL_SERVER_ERROR			("Internal Server Error"),
	UNAUTHORIZED					("Unauthorized"),
	DUPLICATE						("Duplicate"),
	PASS							("pass"),
	REJECT							("reject"),
	CREDITED						("ok"),
	RETURNED						("ok"),
	RETRY							("retry");
	
	
	private final String message;
	
	private ApiMessage_enum(String msgFor) {
		this.message=msgFor;
	}
	
	
	public String toString(){
		return message;
	}
}
