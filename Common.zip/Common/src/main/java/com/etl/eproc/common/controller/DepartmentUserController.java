/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;


import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.daointerface.TblUserEnableDisableDataDao;
import com.etl.eproc.common.databean.CertiDataBean;
import com.etl.eproc.common.databean.OfficerRegistrationDatabean;
import com.etl.eproc.common.model.TblBidderApproval;
import com.etl.eproc.common.model.TblCertUnMapHistory;
import com.etl.eproc.common.model.TblCertificate;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblDCDetachHistory;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblDrtOfficerDepartment;
import com.etl.eproc.common.model.TblOfficer;
import com.etl.eproc.common.model.TblPasswordHistory;
import com.etl.eproc.common.model.TblQueAnsOfficer;
import com.etl.eproc.common.model.TblTimeZone;
import com.etl.eproc.common.model.TblUserCertificate;
import com.etl.eproc.common.model.TblUserClientAccess;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserEnableDisableData;
import com.etl.eproc.common.model.TblUserHistory;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.DrtService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.QuickDepartmentUserService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.services.WSCheckAvailService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SHA1HashEncryption;
import com.etl.eproc.common.utility.SHA256HashEncryption;
import com.etl.eproc.common.utility.SMSContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.common.utility.WSCheckAvail;
import com.etl.eproc.common.webservice.DataObject;

/**
 *
 * @author vipul
 */
@Controller
@RequestMapping("/common")
public class DepartmentUserController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private DepartmentUserService departmentUserService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private SHA256HashEncryption sha256HashEncryption;
    @Autowired
    private SHA1HashEncryption sha1HashEncryption;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private LoginService loginService;
    @Autowired
    private ModelToSelectItem modelToSelectItem;
    @Autowired
    private CommonValidators commonValidators;
    @Autowired
    private ClientService clientService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private WSCheckAvailService wSCheckAvailService;
    @Autowired
    private QuickDepartmentUserService quickDepartmentUserService;
    @Autowired
    private DynamicFieldService dynamicFieldService;
    @Value("#{projectProperties['userhistory.actiontype.enabled']}")
    private int actionTypeenabled;
    @Value("#{projectProperties['userhistory.actiontype.disabled']}")
    private int actionTypeDisabled;
    @Value("#{projectProperties['reset.passwordupdatedfrom']}")
    private int passwordUpdatedFrom;
    @Value("#{projectProperties['auction_Admin_userId']}")
    private String auctionAdminuserId;
    @Value("#{projectProperties['eproc_clientId']}")
    private String eprocClientId;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    private static final String DEPT_USER_GRID_URL = "common/admin/managedeptuser";
    @Autowired
    private AbcUtility abcUtility; 
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private SMSContentUtillity smsContentUtillity;
    @Autowired
    private DrtService drtService;
    @Autowired
	private ManageBidderService manageBidderService;
    @Value("#{linkProperties['manage_user_field_value']?:786}")
	private int manageUserFieldValueId;
    @Value("#{linkProperties['manage_department_user_approve']?:17}")
    private int deptUserApproveLinkId;
    @Value("#{linkProperties['manage_department_user_enable']?:18}")
    private int deptUserEnableLinkId;
    @Value("#{linkProperties['manage_department_user_disable']?:19}")
    private int deptUserDisableLinkId;
    @Value("#{linkProperties['manage_department_user_unmap_dc']?:21}")
    private int unmapDCLinkId;
    @Value("#{linkProperties['manage_department_user_approval_rights']?:22}")
    private int approvalRightsLinkId;
    @Value("#{linkProperties['manage_department_user_reset_password']?:23}")
    private int resetPasswordLinkId;
    @Value("#{linkProperties['manage_bidder_reset_password']?:38}")
    private int bidderResetPasswordLinkId;
    @Value("#{projectProperties['officer.status.pending']?:0}")
    private int cstatusPending;
    @Value("#{projectProperties['officer.status.approved']?:1}")
    private int officerStatusApproved;
    @Value("#{projectProperties['officer.status.disabled']?:2}")
    private int officerStatusDisabled;
    @Value("#{projectProperties['userhistory.actiontype.unlock']?:8}")
    private int actionTypeUnlock;
    @Value("#{linkProperties['manage_department_user_create_department_user']?:13}")
    private int createDeptUserLinkId;
    @Value("#{linkProperties['manage_department_user_edit_department_user']?:14}")
    private int editDeptUserLinkId;
    @Value("#{linkProperties['manage_department_user_view_department_user']?:16}")
    private int viewDeptUserLinkId;
    @Value("#{linkProperties['manage_department_user_unlock']?:20}")
    private int deptUserUnlockLinkId;
    @Value("#{linkProperties['manage_bidder_unlock']?:36}")
    private int bidderUnlockLinkId;
    @Value("#{linkProperties['report_admin_manage_deptuser']?:4}")
    private int manageDeptUserReportId;
    @Value("#{projectProperties['userhistory.actiontype.create']?:1}")
    private int actiontypecreate;
    @Value("#{projectProperties['userhistory.actiontype.edit']?:2}")
    private int actiontypeedit;
    @Value("#{linkProperties['other_map_certificate_on_login']?:151}")
    private int certiMapLink;
    @Value("#{linkProperties['manage_department_user_resend_registration_email']?:15}")
    private int sendRegDetailsOfficerLinkId;
    @Value("#{linkProperties['manage_bidder_resend_registration_email']?:26}")
    private int sendRegDetailsBidderLinkId;
    @Value("#{linkProperties['manage_department_user_department_mapping']?:399}")
    private int deptOfficerMapLink;
    @Value("#{linkProperties['map_officer_question_answer']?:818}")
    private int mapOfficerQuestionAnswerLinkId;
    @Value("#{linkProperties['replace_officer_question_answer']?:819}")
    private int replaceOfficerQuestionAnswerLinkId;
    @Value("#{adminAuditTrailProperties['getManageDeptUserRemark']}")
    private String getManageDeptUserRemark;
    @Value("#{adminAuditTrailProperties['getDeptUserCreateRemark']}")
    private String getDeptUserCreateRemark;
    @Value("#{adminAuditTrailProperties['getDeptUserEditRemark']}")
    private String getDeptUserEditRemark;
    @Value("#{adminAuditTrailProperties['getDeptUserViewRemark']}")
    private String getDeptUserViewRemark;
    @Value("#{adminAuditTrailProperties['postDeptUserProfileEditRemark']}")
    private String postDeptUserProfileEditRemark;
    @Value("#{adminAuditTrailProperties['postDeptUserCreateRemark']}")
    private String postDeptUserCreateRemark;
    @Value("#{adminAuditTrailProperties['getEnableUserRemark']}")
    private String getEnableUserRemark;
    @Value("#{adminAuditTrailProperties['getDisableUserRemark']}")
    private String getDisableUserRemark;
    @Value("#{adminAuditTrailProperties['getApproveUserRemark']}")
    private String getApproveUserRemark;    
    @Value("#{adminAuditTrailProperties['postDeptUserApproved']}")
    private String postDeptUserApproved;
    @Value("#{adminAuditTrailProperties['postDeptUserEnabled']}")
    private String postDeptUserEnabled;
    @Value("#{adminAuditTrailProperties['postDeptUserDisabled']}")
    private String postDeptUserDisabled;
    
    @Value("#{adminAuditTrailProperties['getUnMapDCUserRemark']}")
    private String getUnMapDCUserRemark;
//    @Value("#{adminAuditTrailProperties['postUnMapDCUserSignRemark']}")
//    private String postUnMapDCUserSignRemark;
    @Value("#{adminAuditTrailProperties['postUnMapDCUserRemark']}")
    private String postUnMapDCUserRemark;
    @Value("#{adminAuditTrailProperties['getApprovalRightRemark']}")
    private String getApprovalRightRemark;    
    @Value("#{adminAuditTrailProperties['postApprovalRightRemark']}")
    private String postApprovalRightRemark;
    @Value("#{adminAuditTrailProperties['postResetPasswordRemark']}")
    private String postResetPasswordRemark;
    @Value("#{adminAuditTrailProperties['getResetPasswordRemark']}")
    private String getResetPasswordRemark;
//    @Value("#{adminAuditTrailProperties['postResetPasswordSignRemark']}")
//    private String postResetPasswordSignRemark;
    @Value("#{adminAuditTrailProperties['postUserUnlockRemark']}")
    private String postUserUnlockRemark;
    @Value("#{adminAuditTrailProperties['postBidderUnlockRemark']}")
    private String postBidderUnlockRemark;
    @Value("#{adminAuditTrailProperties['showCertiBuyer']}")
    private String showCertiAudit;
    @Value("#{adminAuditTrailProperties['showDeptOfficerMap']}")
    private String editDeptOfficerMap;
    @Value("#{adminAuditTrailProperties['successDeptOfficerMap']}")
    private String successDeptOfficerMap;
    @Value("#{adminAuditTrailProperties['failDeptOfficerMap']}")
    private String failDeptOfficerMap;
    private static final String USER_ID = "userId";
    @Value("#{adminAuditTrailProperties['sendRegDetailsOfficer']}")
    private String sendRegDetailsOfficerAudit;
    @Value("#{adminAuditTrailProperties['sendRegDetailsBidder']}")
    private String sendRegDetailsBidderAudit;
    @Value("#{projectProperties['userhistory.actiontype.resetpassword']?:11}")
    private int actionTypeResetPassword;
    @Value("#{projectProperties['userhistory.actiontype.sendregresetpassword']?:12}")
    private int actionTypeSendRegResetPassword;
    @Value("#{adminAuditTrailProperties['mapQAOfficerRemark']}")
    private String mapQAOfficerRemark;
    @Value("#{adminAuditTrailProperties['replaceQAOfficerRemark']}")
    private String replaceQAOfficerRemark;
    @Value("#{adminAuditTrailProperties['ssoServNotAvail']}")
    private String ssoServNotAvail;
    @Value("#{linkProperties['user_client_access_linkId']?:4448}")
    private int userClientAccesslinkId;
    @Value("#{adminAuditTrailProperties['getUserClientAccess']}")
    private String msgGetUserClientAccess;
    @Value("#{adminAuditTrailProperties['postUserClientAccess']}")
    private String msgPostUserClientAccess;
    @Value("#{adminAuditTrailProperties['postUnmapUserClientAccess']}")
    private String msgPostUnmapUserClientAccess;
    
    @Value("#{smsProperties['msg_one_time_reset_otp']}")
	private String msgResetPass;
	@Value("#{projectProperties['default_contry_id']}")
    private int countryId;
    
    @Value("#{linkProperties['manage_bidder_detach_dc']?:5538}")
	private int detachDCLinkId;
    private final static String XFORWARDEDFOR = "X-FORWARDED-FOR";
    
    /**
     * Search and listing department user
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/managedeptuser/{enc}", method = RequestMethod.GET)
    public String manageDeptUser(ModelMap modelMap,HttpServletRequest request) {
        try {
        	//int reportId=4;
        	modelMap.addAttribute("reportId",manageDeptUserReportId);
        	//Change Request #22284 - START
        	String officerEmailId= "";
        	String personName = "";
        	List<TblQueAnsOfficer> queAnsOfficers =  departmentUserService.getTblQueAnsOfficer(abcUtility.getSessionClientId(request));
        	for(TblQueAnsOfficer tblQueAnsOfficer : queAnsOfficers){
        		if(tblQueAnsOfficer.getIsActive()==1){
        			int userId = tblQueAnsOfficer.getTblUserLogin().getUserId();
        			officerEmailId = commonService.getEmailByUserId(userId);
        			personName = commonService.getUserName(userId);
        		}
        	}
        	modelMap.put("officerEmailId", officerEmailId);
        	modelMap.put("personName", personName);
        	//END
            reportGeneratorService.getReportConfigDetails(manageDeptUserReportId, modelMap);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0,getManageDeptUserRemark, 0,0);
        }
        return "/common/admin/ManageDeptUser";
    }
    /**
     * setting the common modal map for create and edit case of department user creation
     * create/edit dept user set common model map
     * @param modelMap
     * @param session
     * @return void
     */
    private void setDeptUserModelmap(ModelMap modelMap,HttpServletRequest request,String operType,int DeptUserId,OfficerRegistrationDatabean officerRegistrationDatabean) throws Exception{   	
        List<SelectItem> timezonelist = new ArrayList<SelectItem>();
        List<SelectItem> userRoleRadio = new ArrayList<SelectItem>();
        List<TblTimeZone> tblTimeZonelist = commonService.getTimeZoneList();
        if(tblTimeZonelist!=null && !tblTimeZonelist.isEmpty()){
            timezonelist = modelToSelectItem.convertListIntoSelectItemList(tblTimeZonelist, "timeZoneId", "lang"+WebUtils.getCookie(request, "locale").getValue());
        }        
        int userId = abcUtility.getSessionUserId(request); 
        boolean isAbcUser = commonService.checkAbcUser(Integer.toString(DeptUserId))>0?true:false;
        int clientId = abcUtility.getSessionClientId(request); 
        if(userId!=0){
            if(userId == Integer.parseInt(auctionAdminuserId) && clientId==Integer.parseInt(eprocClientId)){
                userRoleRadio.add(new SelectItem("Admin User", 1));
                userRoleRadio.add(new SelectItem("Department User", 0));
                modelMap.addAttribute("userRoles", userRoleRadio);
            }
        }        
        if("create".equalsIgnoreCase((operType))){
        	modelMap.addAttribute("objectId", 0);
            List<Object[]> timezoneIdlist = commonService.getClientCountryStateTimezone(clientId);
            if(timezoneIdlist.get(0)[0]!=null){
                officerRegistrationDatabean.setselTimeZone(timezoneIdlist.get(0)[0].toString());          
            }            
        }else{            // edit and view
            DataObject dataObject = null;
            List<Object[]> list = departmentUserService.viewDeptUser(DeptUserId,clientId,isAbcUser);
            modelMap.addAttribute("objectId", DeptUserId);
            for (Object[] objects : list) {          
                if("view".equalsIgnoreCase(operType) || "edit".equalsIgnoreCase(operType)){
                    dataObject = WSCheckAvail.getSSOLoginMastreDetailasObject(objects[1].toString());
                }
                officerRegistrationDatabean.setTxtFullName((String)objects[0]);
                officerRegistrationDatabean.setTxtEmailId((String)objects[1]);
                officerRegistrationDatabean.setTxtMobileNo((dataObject!=null && dataObject.getData12()!=null && !"".equalsIgnoreCase(dataObject.getData12().toString()))?dataObject.getData12().toString():(String)objects[2]);
                officerRegistrationDatabean.settxtDept(objects[3].toString());
                officerRegistrationDatabean.setTxtParentDesig(objects[4].toString());
                officerRegistrationDatabean.setselTimeZone((dataObject!=null && dataObject.getData26()!=null && !"".equalsIgnoreCase(dataObject.getData26().toString()))?commonService.getTimezoneIdByTimeZone(dataObject.getData26().toString()).getTimeZoneId().toString():objects[5].toString());
                officerRegistrationDatabean.setTxtPhoneNo((dataObject!=null && dataObject.getData10()!=null && !"".equalsIgnoreCase(dataObject.getData10().toString()))?dataObject.getData10().toString():(String)objects[6]);                
                officerRegistrationDatabean.setHduserId(objects[7].toString());
                officerRegistrationDatabean.setTimezonenamelabel((dataObject!=null && dataObject.getData26()!=null && !"".equalsIgnoreCase(dataObject.getData26().toString()))?dataObject.getData26().toString():objects[8].toString());
                officerRegistrationDatabean.setDeptnamelabel(objects[9].toString());
                officerRegistrationDatabean.setDesignamelabel(objects[10].toString());
                officerRegistrationDatabean.setRduserrole(objects[11].toString());
                officerRegistrationDatabean.setHddbEmailVerified(objects[12].toString());
                modelMap.addAttribute("updatedUserDeptId", objects[3].toString());
            }
        }
        modelMap.addAttribute("timezonelist", timezonelist);
        modelMap.addAttribute("operType", operType);
        modelMap.addAttribute("officerRegistrationDatabean", officerRegistrationDatabean);
        modelMap.addAttribute("clientId", clientId);
        modelMap.addAttribute("linkId", manageUserFieldValueId);
        modelMap.put("lstClientMarquee", clientService.getClientMarqueeBylocation((int) abcUtility.getSessionClientId(request),3));/* For After Loging Marque */
        
    }
    /**
     * Department user creation handler - which serves the dept. user creation request for page display purpose
     * create dept user
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/createdeptuser/{enc}", method = RequestMethod.GET)
    public String createDeptUser(ModelMap modelMap,HttpServletRequest request,OfficerRegistrationDatabean officerRegistrationDatabean) {
        try {
             setDeptUserModelmap(modelMap, request,"create",0,officerRegistrationDatabean); 
             modelMap.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(manageUserFieldValueId, abcUtility.getSessionClientId(request), 0));
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createDeptUserLinkId,getDeptUserCreateRemark, 0,0,"");
        }
        return "/common/admin/CreateDeptUser";
    }

    @ResponseBody
    @RequestMapping(value="/admin/getgradefnlimit", method=RequestMethod.POST)
    public String getGradeFnlimit(HttpServletRequest request,HttpServletResponse response){
    	StringBuilder retVal=new StringBuilder();
    	List<Object[]> result = null;
    	int userId = 0;
    	try {
			userId = abcUtility.getSessionUserId(request);
			if(userId!=0){
				int designationId = StringUtils.hasLength(request.getParameter("txtDesigId")) ? Integer.parseInt(request.getParameter("txtDesigId")): 0;
				result = departmentUserService.getGradeLimitByDesigId(designationId); 
				if(result!=null && !result.isEmpty()){
					retVal.append(result.get(0)[0]+","+result.get(0)[1]+","+result.get(0)[2]);
				}
			}
			else{
				retVal.append("sessionexpired");
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
    	return retVal.toString();
    }
    /**
     * Department user edition handler - which serves the dept. user edition request for page display purpose
     * Edit Department User
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/editdeptuser/{operType}/{from}/{userId}/{enc}", method = RequestMethod.GET)
    public String getEditDeptUser(@PathVariable("operType") String operType,@PathVariable("from") String from,@PathVariable("userId") int userId, ModelMap modelMap,HttpServletRequest request,OfficerRegistrationDatabean officerRegistrationDatabean) {
        String strReturn = null;
        String Remarks = null;
        int LinkId = 0;
        int clientId = 0;
        int sessionUserId = 0;
        try { 
        	  clientId = abcUtility.getSessionClientId(request);
        	  sessionUserId = abcUtility.getSessionUserId(request);
        	  modelMap.addAttribute("from",from);
              setDeptUserModelmap(modelMap,request,operType,userId,officerRegistrationDatabean);
              modelMap.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(manageUserFieldValueId, clientId, userId));
              if("edit".equalsIgnoreCase(operType)){
                  LinkId = editDeptUserLinkId;
                  Remarks = getDeptUserEditRemark;
                  if(sessionUserId != Integer.parseInt(auctionAdminuserId)){
                	  modelMap.put("isLowerLevelUpdatedUser", departmentUserService.cheIsLowerLevelUpdatedUser(sessionUserId,Integer.parseInt((String)modelMap.get("updatedUserDeptId")),clientId));
                  }else{
                	  modelMap.put("isLowerLevelUpdatedUser", true);
                  }
              }else{
                  LinkId = viewDeptUserLinkId;
                  Remarks = getDeptUserViewRemark;
              }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }finally{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), LinkId, Remarks, 0, userId,"");
        }
        if("profile".equalsIgnoreCase(from)){
            if("view".equalsIgnoreCase(operType)){
                strReturn = "/common/admin/ViewDepartmentUser";
            }else{
                strReturn = "/common/admin/CreateDeptUserProfile";
            }
        }else{
            if("view".equalsIgnoreCase(operType)){
                strReturn = "/common/admin/ViewDepartmentUser";
            }else{
                strReturn = "/common/admin/CreateDeptUser";
            }
        }
        return strReturn;
    }
    
    /**
     * Department user data Post handler - which serves the dept. user creation and edition request for database submission purpose
     * @param officerRegistrationDatabean
     * @param result
     * @param session
     * @param request
     * @param redirectAttributes
     * @return to view
     */
    @RequestMapping(value = "/admin/addDeptUser", method = RequestMethod.POST)
        public String addDeptUser(@ModelAttribute OfficerRegistrationDatabean officerRegistrationDatabean, BindingResult result, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes,ModelMap modelMap) {
            boolean success = false;
            boolean isEdit = false;
            boolean isProfile = false;
            String auditstr = null;
            String returnStr = "redirect:/loginfailed";
            int officerverificationby = 0;            
            int parentId = 0;
            int actionType = 0;
            int officerId = 0;
            int bidderId = 0;
            int LinkId = 0;
            TblUserLogin tblUserLogin =null;
            TblOfficer  tblOfficer = null;
            ClientBean clientBean = null;
            boolean isSSOEnabled = false;
            try{
            	clientBean = (ClientBean) (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString())!=null ? request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) : null);
            	isSSOEnabled = clientBean.isIsSsoEnabled();
                officerRegistrationDatabean.setCommonValidators(commonValidators);
                officerRegistrationDatabean.validate(result);
                int clientId = abcUtility.getSessionClientId(request);    
                if(officerRegistrationDatabean.getHdoperType()!=null && !"".equals(officerRegistrationDatabean.getHdoperType()) && "edit".equalsIgnoreCase(officerRegistrationDatabean.getHdoperType())){
                    isEdit = true;
                }
                if(officerRegistrationDatabean.getHdfrom()!=null && !"".equals(officerRegistrationDatabean.getHdfrom()) && "profile".equalsIgnoreCase(officerRegistrationDatabean.getHdfrom())){
                    isProfile = true;
                }
                if(isEdit){
                    if(officerRegistrationDatabean.getHddbEmailId()!=null && !"".equalsIgnoreCase(officerRegistrationDatabean.getHddbEmailId())){
                        if(!officerRegistrationDatabean.getHddbEmailId().equalsIgnoreCase(officerRegistrationDatabean.getTxtEmailId())){
                            boolean isEmailExists=commonService.checkUniqueLoginId(officerRegistrationDatabean.getTxtEmailId());
                            if(!isEmailExists){
                                result.rejectValue("txtEmailId", "email", "Email already exists.");
                            }
                        }
                    }                    
                }else{
                    List<LinkedHashMap<String, Object>> list = commonService.checkValidUserInClient(clientId, officerRegistrationDatabean.getTxtEmailId(), 3);                    
                    if(list != null && !list.isEmpty()) {
                    	Map<String, Object> map  = list.get(0);
                        if(map.get("actionType") != null) {
                            actionType = Integer.parseInt(map.get("actionType").toString());
                            officerId = Integer.parseInt(map.get("officerId").toString());
                            bidderId = Integer.parseInt(map.get("bidderId").toString());
                            if(actionType==2 && officerId>0) {
                                result.rejectValue("txtEmailId", "msg_js_registration_officerexists", "Email ID already registered as department user on this domain.");
                            }else if(actionType==2 && bidderId>0) {
                                result.rejectValue("txtEmailId", "msg_js_registration_bidderexists", "Email ID already registered as bidder on this domain.");
                            }
                        }
                    }
                }
                boolean isservAvail = false;
                if(result.hasErrors()) {                        
                    if(isEdit){
                        if(isProfile){
                            returnStr = "/common/admin/CreateDeptUserProfile"; //"redirect:/common/admin/editdeptuser/edit/profile/"+officerRegistrationDatabean.getHduserId() + encryptDecryptUtils.generateRedirect("common/admin/editdeptuser/edit/profile/"+officerRegistrationDatabean.getHduserId(), request);
                        }else{
                            returnStr = "/common/admin/CreateDeptUser"; //"redirect:/common/admin/editdeptuser/edit/grid/"+officerRegistrationDatabean.getHduserId() + encryptDecryptUtils.generateRedirect("common/admin/editdeptuser/edit/grid/"+officerRegistrationDatabean.getHduserId(), request);
                        }
                        auditstr = postDeptUserProfileEditRemark;
                        setDeptUserModelmap(modelMap,request,officerRegistrationDatabean.getHdoperType(),Integer.parseInt(officerRegistrationDatabean.getHduserId()),officerRegistrationDatabean);
                    }else{
                        returnStr = "/common/admin/CreateDeptUser"; //"redirect:/common/admin/createdeptuser" + encryptDecryptUtils.generateRedirect("common/admin/createdeptuser", request);
                        auditstr = postDeptUserCreateRemark;
                        setDeptUserModelmap(modelMap,request,officerRegistrationDatabean.getHdoperType(),0,officerRegistrationDatabean);
                    }
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
                }else{
                    int userId = abcUtility.getSessionUserId(request);                    
                    Date serverdateime= commonService.getServerDateTime();
                    officerverificationby =  clientService.getOfficerRegistrationVerifiedBy(clientId);
                    if(isEdit){
                        boolean bool = false;
                        if(isSSOEnabled){
                        	 bool = wSCheckAvailService.updateSSOUser(null, officerRegistrationDatabean, userId, officerRegistrationDatabean.getHddbEmailId(),3, clientId);
                             if(bool){
                             	isservAvail = true;
                             }else{
                             	if (WSCheckAvail.isSsoAvailable()) {
                         			//First dump user in sso from Local and then reset the pass
                             		bool = wSCheckAvailService.dumpUserWithChngPwd(Integer.parseInt(officerRegistrationDatabean.getHduserId()),clientBean.getClientId(),3,false);
                             		if(bool){
                             			bool = wSCheckAvailService.updateSSOUser(null, officerRegistrationDatabean, Integer.parseInt(officerRegistrationDatabean.getHduserId()), officerRegistrationDatabean.getHddbEmailId(),3, clientId);
                             		}
                         		}else{
                         			isservAvail = false;//For redirect msg
                         		}
                             }
                        }
                        if(bool && departmentUserService.updateDeptUser(officerRegistrationDatabean,serverdateime, clientId) || !isSSOEnabled && departmentUserService.updateDeptUser(officerRegistrationDatabean,serverdateime, clientId)){
                            TblUserDetail  tblUserDetail = null;
                            if(!officerRegistrationDatabean.getHddbFullName().equalsIgnoreCase(officerRegistrationDatabean.getTxtFullName()) ||
                               !officerRegistrationDatabean.getTxtdbDeptname().equalsIgnoreCase(officerRegistrationDatabean.getTxtDeptname()) ||
                               !officerRegistrationDatabean.getTxtdbDesigname().equalsIgnoreCase(officerRegistrationDatabean.getTxtDesigname()) ||
                               !officerRegistrationDatabean.getHddbEmailId().equalsIgnoreCase(officerRegistrationDatabean.getTxtEmailId())){
                                tblUserDetail = officerRegistrationDatabean._toTblUserDetail(clientId,userId,null);
                                tblUserDetail.setTblUserLogin(new TblUserLogin(Integer.parseInt(officerRegistrationDatabean.getHduserId())));
                                bool = true;
                            }else{
                            	 bool = false;
                            }
                            TblUserHistory  tblUserHistory = officerRegistrationDatabean._toTblUserHistory(clientId,userId,actiontypeedit);
                            tblUserHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(officerRegistrationDatabean.getHduserId())));
                            dynamicFieldService.addDynamicFieldValueProcess(dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request),clientId,manageUserFieldValueId, Integer.parseInt(officerRegistrationDatabean.getHduserId()) ,userId);
                            if(departmentUserService.addDeptUserdetails(tblUserDetail, tblUserHistory, bool)){
                                //wSCheckAvailService.updateSSOUser(null,officerRegistrationDatabean,userId,officerRegistrationDatabean.getHddbEmailId(),3,clientId);
                                if(isProfile){
                                	if(clientBean.getIsDIYClient() == 1)
                                	{
                                		departmentUserService.updateDesignationByIdForDiy(officerRegistrationDatabean.getTxtParentDesig(), officerRegistrationDatabean.getTxtDesigname());	
                                	}	
                                    //returnStr = "redirect:/common/admin/searchlistclient/" + encryptDecryptUtils.generateRedirect("common/admin/searchlistclient/", request);
                                    returnStr = "redirect:/common/admin/editdeptuser/view/profile/"+userId+encryptDecryptUtils.generateRedirect("common/admin/editdeptuser/view/profile/"+userId, request);
                                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_bidder_edit_profile");
                                }else{
                                    returnStr = "redirect:/"+DEPT_USER_GRID_URL + encryptDecryptUtils.generateRedirect(DEPT_USER_GRID_URL, request);
                                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_edit_deptuserprofile");
                                }
                                auditstr = postDeptUserProfileEditRemark;
                                parentId = Integer.parseInt(officerRegistrationDatabean.getHduserId());
                                success = true;
                                LinkId = editDeptUserLinkId;
                            }
                        }else{
                        	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
                        	returnStr = "redirect:/common/admin/editdeptuser/edit/grid/"+Integer.parseInt(officerRegistrationDatabean.getHduserId())+encryptDecryptUtils.generateRedirect("common/admin/editdeptuser/edit/grid/"+Integer.parseInt(officerRegistrationDatabean.getHduserId()), request);
                        	auditstr = ssoServNotAvail;
                        }
                    }else{
                    	/*Department User / Officer Registration Verification By(officerverificationby). 0 for Not Required, 1 for Email, 2 for Email and Mobile No*/
                        int cStatus = 0;
                        int isFistLogin = 0;
                        int isEmailVerified = 0;
                        if(officerverificationby == 0){
                            cStatus = officerStatusApproved;
                            isFistLogin=1;
                            isEmailVerified=1;
                        } else if(actionType==3 && officerId>0) {
                        	List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(officerId);
                        	if(tblUserLogins != null && !tblUserLogins.isEmpty()) {
                        		if(tblUserLogins.get(0).getIsEmailVerified()==1) {
                        			cStatus = officerStatusApproved;
                        			isEmailVerified=1;
                        		}
                        	}
                        } else {
                            cStatus = cstatusPending;
                            //Start Bug Id:#24843
                            if(officerverificationby == 1){
                            	isFistLogin=1;
                            }
                            //End Bug Id:#24843
                        }
                        
                        boolean flag = true;
                        TblUserDetail  tblUserDetail = null;                        
                        TblUserHistory  tblUserHistory = null;
                        TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
                         if(officerRegistrationDatabean.getTxtactionType().equalsIgnoreCase("6")){                   ////////dumping from sso
                            DataObject dataObject =  WSCheckAvail.getSSOLoginMastreDetailasObject(officerRegistrationDatabean.getTxtEmailId());
                            tblUserLogin = officerRegistrationDatabean._toTblUserLogin(serverdateime,userId,clientId,"0",commonService,dataObject);
                            tblUserLogin.setIsFirstLogin(isFistLogin);
                            tblUserLogin.setIsEmailVerified(1);
                            tblUserDetail = officerRegistrationDatabean._toTblUserDetail(clientId,userId,dataObject);
                            tblUserDetail.setTblUserLogin(tblUserLogin);
                            tblOfficer = officerRegistrationDatabean._toTblOfficer(serverdateime,userId,clientId,cStatus,dataObject);
                            tblOfficer.setTblUserLogin(tblUserLogin);
                            tblUserHistory = officerRegistrationDatabean._toTblUserHistory(clientId,userId,actiontypecreate);
                            tblUserHistory.setTblUserLogin(tblUserLogin);                            
                        }else if(actionType == 3){
                            tblUserDetail = officerRegistrationDatabean._toTblUserDetail(clientId,userId,null);
                            tblUserDetail.setTblUserLogin(new TblUserLogin(officerId));
                            List<Object[]> list = departmentUserService.getUserNamePhoneNo(officerId);
                            tblUserDetail.setUserName(list.get(0)[1]!=null?list.get(0)[1].toString():"");
                            tblOfficer = officerRegistrationDatabean._toTblOfficer(serverdateime,userId,clientId,cStatus,null);
                            tblOfficer.setTblUserLogin(new TblUserLogin(officerId));
                            tblOfficer.setPhoneNo(list.get(0)[0]!=null?list.get(0)[0].toString():"");
                            tblUserHistory = officerRegistrationDatabean._toTblUserHistory(clientId,userId,actiontypecreate);
                            tblUserHistory.setTblUserLogin(new TblUserLogin(officerId));
                            parentId = officerId;
                            flag = false;
                        }else if(actionType == 4){
                            tblUserDetail = officerRegistrationDatabean._toTblUserDetail(clientId,userId,null);
                            tblUserDetail.setTblUserLogin(new TblUserLogin(bidderId));
                            List<Object> list = departmentUserService.getUserName(bidderId);
                            tblUserDetail.setUserName(list.get(0)!=null?list.get(0).toString():"");
                            tblOfficer = officerRegistrationDatabean._toTblOfficer(serverdateime,userId,clientId,cStatus,null);
                            tblOfficer.setTblUserLogin(new TblUserLogin(bidderId));
                            tblUserHistory = officerRegistrationDatabean._toTblUserHistory(clientId,userId,actiontypecreate);
                            tblUserHistory.setTblUserLogin(new TblUserLogin(bidderId));
                            parentId = bidderId;
                            flag = false;
                        }else if(actionType ==1){
                            String verificationCode = "0";
                            if(officerverificationby == 1){
                                verificationCode = UUID.randomUUID().toString().replaceAll("-", "").substring(0,10);
                            }
                            tblUserLogin = officerRegistrationDatabean._toTblUserLogin(serverdateime,userId,clientId,verificationCode,commonService,null);
                            tblUserLogin.setPassword(sha256HashEncryption.encodeStringSHA256(officerRegistrationDatabean.getTxtPassword()));
                            tblUserLogin.setIsFirstLogin(isFistLogin);
                            tblUserLogin.setIsEmailVerified(isEmailVerified);
                            tblUserDetail = officerRegistrationDatabean._toTblUserDetail(clientId,userId,null);
                            tblUserDetail.setTblUserLogin(tblUserLogin);
                            tblOfficer = officerRegistrationDatabean._toTblOfficer(serverdateime,userId,clientId,cStatus,null);
                            tblOfficer.setTblUserLogin(tblUserLogin);
                            tblUserHistory = officerRegistrationDatabean._toTblUserHistory(clientId,userId,actiontypecreate);
                            tblUserHistory.setTblUserLogin(tblUserLogin);   
                        }
                        //Bug:18917 @jaynam
                        if(flag){
                            tblPasswordHistory.setCreatedBy(abcUtility.getSessionUserId(request));
                            tblPasswordHistory.setCreatedOn(commonService.getServerDateTime());
                            tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
                            tblPasswordHistory.setPasswordUpdatedFrom(5);
                        }
                        success = departmentUserService.addDeptUser(tblUserLogin, tblUserDetail, tblOfficer, tblUserHistory,tblPasswordHistory,flag);
                        if(success) {
                        	success = dynamicFieldService.addDynamicFieldValueProcess(dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request),clientId,manageUserFieldValueId, tblUserDetail.getTblUserLogin().getUserId(),userId);
                        }
                        returnStr = "redirect:/"+DEPT_USER_GRID_URL + encryptDecryptUtils.generateRedirect(DEPT_USER_GRID_URL, request);
                        redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_create_deptuserprofile");
                        auditstr =postDeptUserCreateRemark;
                        LinkId = createDeptUserLinkId;
                        if(actionType ==1 || actionType==6){
                            parentId = tblUserLogin.getUserId();
                        }
                    }
                    if(success){
                       URL url = new URL(request.getRequestURL().toString());
                       StringBuilder verifyUrlPrefix = new StringBuilder();
                       verifyUrlPrefix.append(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "https").append("://").append(url.getHost());
                       if ((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) {
                            verifyUrlPrefix.append(":").append(url.getPort());
                       }
                       verifyUrlPrefix.append(url.getPath().substring(url.getPath().indexOf("/"), url.getPath().lastIndexOf("/"))); 
                       //verifyUrlPrefix.append(request.getContextPath());
                       Map<String, Object> paramMap =  new HashMap<String, Object>();
                       if(isEdit){
                           paramMap.put("SubDomainName", url.getHost());
                           paramMap.put("to", officerRegistrationDatabean.getTxtEmailId());
                           paramMap.put("ServerDateTime", CommonUtility.convertTimezone(serverdateime) + " " + TimeZone.getTimeZone("GMT"+CommonUtility.getTimeZone()).getDisplayName());
                           /**
                            * 	Bug #19566 :: According to #19566 "8" mailTemplateId is used. Any field is updated only one mail is sent. 
                            * Before this separate mail for email or mobile no and department or designation.
                            * -- start     
                            */
                           mailContentUtillity.dynamicMailGeneration("8", String.valueOf(userId), String.valueOf(clientId),paramMap);
                           /**
                            * -- End 
                            */
                           /*
                            *
                            *  Before Bug #19566
                            *  
	                           paramMap.put("subdomainname", url.getHost());
	                           paramMap.put("to", officerRegistrationDatabean.getTxtEmailId());
	                           paramMap.put("loginId", officerRegistrationDatabean.getTxtEmailId());
	                           paramMap.put("serverdatetime", CommonUtility.convertTimezone(serverdateime) + " " + TimeZone.getTimeZone("GMT"+CommonUtility.getTimeZone()).getDisplayName());
	                           if(isProfile){ // Before Bug #19566
	                                mailContentUtillity.dynamicMailGeneration("11", String.valueOf(userId), String.valueOf(clientId),paramMap);
	                           }else{
	                                mailContentUtillity.dynamicMailGeneration("1".equalsIgnoreCase(officerRegistrationDatabean.getHddbEmailVerified())?"28":"11", String.valueOf(userId), String.valueOf(clientId),paramMap);
                           }*/
                       }else{
                           if(officerRegistrationDatabean.getTxtactionType().equalsIgnoreCase("1")){
                                boolean isRegister = wSCheckAvailService.registerSSA(null,officerRegistrationDatabean, tblUserLogin.getUserId(), 3, clientId,true);
                                if(isRegister){
            						loginService.updateLoginSSOStatus(userId);//Is bidder register in SSO,change SSO-status 0 to 1 in TblUserLogin
            					}
                           }
                           paramMap.put("subdomainname", url.getHost());
                           paramMap.put("to", officerRegistrationDatabean.getTxtEmailId());
                           paramMap.put("loginId", officerRegistrationDatabean.getTxtEmailId());                           
                           switch(actionType){
                               case 6:
                                       paramMap.put("password", officerRegistrationDatabean.getTxtPassword()); 
                                       mailContentUtillity.dynamicMailGeneration("13", String.valueOf(userId), String.valueOf(clientId),paramMap);
                                       break; 
                               case 3:
                                       mailContentUtillity.dynamicMailGeneration("25", String.valueOf(userId), String.valueOf(clientId),paramMap);
                                       break; 
                               case 4:
                                       mailContentUtillity.dynamicMailGeneration("25", String.valueOf(userId), String.valueOf(clientId),paramMap);
                                       break;
                               case 1:
                                       paramMap.put("password", officerRegistrationDatabean.getTxtPassword());
                                       switch (officerverificationby) {
                                            case 2:
                                                    paramMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(officerRegistrationDatabean.getTxtEmailId()+"@@"+3+"_"+tblOfficer.getOfficerId())+"\">Email Verification Link</a>");
                                                    mailContentUtillity.dynamicMailGeneration("6", String.valueOf(userId), String.valueOf(clientId),paramMap);
                                                    break;
                                            case 1:
                                                    paramMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(officerRegistrationDatabean.getTxtEmailId()+"@@"+3+"_"+tblOfficer.getOfficerId())+"/"+encryptDecryptUtils.encrypt(tblUserLogin.getVerificationCode())+"\">Email Verification Link</a>");
                                                    mailContentUtillity.dynamicMailGeneration("12", String.valueOf(userId), String.valueOf(clientId),paramMap);
                                                    break;
                                            case 0:
                                                    mailContentUtillity.dynamicMailGeneration("13", String.valueOf(userId), String.valueOf(clientId),paramMap);
                                                    break;
                                            default:
                                                    break;
                                       }
                               default:
                                      break;    
                           }
                       }
                    }
                    else{
                    	if(isservAvail){
                    		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_edit_bidderprofile" : CommonKeywords.ERROR_MSG_KEY.toString());
                    	}
                    }
                    SessionBean sessionBean = (SessionBean)session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
                    if(sessionBean.getUserTypeId()!=1){
                        List<Object[]> timeZone = loginService.getUserTimeZone(sessionBean.getUserId());
                        if (timeZone != null && !timeZone.isEmpty()) {
                            sessionBean.setTimeZoneOffset(timeZone.get(0)[0].toString());
                            sessionBean.setTimeZoneAbbr(timeZone.get(0)[1].toString());
                        }
                        session.removeAttribute(CommonKeywords.SESSION_OBJ.toString());
                        session.setAttribute(CommonKeywords.SESSION_OBJ.toString(), sessionBean);
                    }
                }
            }
            catch(Exception ex){                
                return exceptionHandlerService.writeLog(ex);
            }finally{
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), LinkId, auditstr, 0, parentId,"");
            }
            return returnStr;
        }
   
    /**
     * @author nirav.modi
     * Block Department User
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/blockdeptuser/{officerId}/{cStatus}/{enc}", method = RequestMethod.GET)
    public String blockDeptUser(@PathVariable("cStatus") int cStatus,@PathVariable("officerId") int officerId,ModelMap modelMap,HttpServletRequest request) {
    	int linkId=0;
    	String page=null;
        try {
        	List<Object[]> userDetails = departmentUserService.getUserNameEmailIDByOfficerId(officerId);
        	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	String publicKey=null;
        	if(userDetails!=null && !userDetails.isEmpty()){
        		if(clientBean.getIsPkiEnabled()==1){
            		String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
            		if(certIds!=null && certIds.length!=0){
            			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
            		}
        		}
        		Object[]objects=userDetails.get(0);
    			modelMap.addAttribute("userName", objects[0]);
    			modelMap.addAttribute("loginId", objects[1]);
    			modelMap.addAttribute("userId", objects[2]);
    			modelMap.addAttribute("designationName", objects[3]);
    			modelMap.addAttribute("departmentName", objects[4]);
    			modelMap.addAttribute("publicKey", publicKey);
        	}
        	if(cStatus==0){
        		linkId=deptUserApproveLinkId;
        		page=getApproveUserRemark;
        	}else if(cStatus==1){
        		linkId=deptUserDisableLinkId;
        		page=getDisableUserRemark;
        	}else if(cStatus==2){
        		linkId=deptUserEnableLinkId;
        		page=getEnableUserRemark;
        	}
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, page, 0, officerId);
        }
        return "/common/admin/BlockDeptUser";
    }
    
    /**
     * @author nirav.modi
     * @param redirectAttributes
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/enabledisabledeptuser", method = RequestMethod.POST)                       
    public String enableDisableDeptUser(RedirectAttributes redirectAttributes, HttpServletRequest request){ 
        int updated=0;
        String successMessage = null;
        String msg=null;
        String remarks = null;
        String officerId = null;
        ClientBean clientBean = null;
        int cStatus = 0;
        int linkId=0;
        
        try{
        	remarks = request.getParameter("txtaRemarks");
            officerId = request.getParameter("hdOfficerId");
        	clientBean=(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	String currentStatus = request.getParameter("hdCStatus");
        	if(currentStatus.equals("1")){//1 for enable
    			cStatus=officerStatusDisabled;// do disable user
    		}else if(currentStatus.equals("2") || currentStatus.equals("0") || currentStatus.equals("3")){//2 for disable 
    			cStatus=officerStatusApproved;//do enable user
    		}
        	String userId = request.getParameter("hdUserId");
        	int createdBy = abcUtility.getSessionUserId(request);
        	int clientId = abcUtility.getSessionClientId(request);
        	if(StringUtils.hasLength(remarks) && cStatus!=0 && StringUtils.hasLength(officerId)){ 
        		TblUserHistory tblUserHistory = new TblUserHistory();
        		tblUserHistory.setTblClient(new TblClient(clientBean.getClientId()));
        		tblUserHistory.setCreatedBy(createdBy);
        		tblUserHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(userId)));
        		if(cStatus==officerStatusDisabled){
        			tblUserHistory.setActionType(actionTypeDisabled);
        		}else if(cStatus==officerStatusApproved){
        			tblUserHistory.setActionType(actionTypeenabled);
        		}
        		updated =departmentUserService.enableDisableDeptUser(Integer.parseInt(officerId),clientId,cStatus,tblUserHistory);
        		if(updated!=0){
        			TblUserEnableDisableData userEnableDisable =new TblUserEnableDisableData();
        			userEnableDisable.setUserId(Integer.parseInt(userId));
        			userEnableDisable.setRemarks(remarks);
        			userEnableDisable.setCreatedBy(createdBy);
        			userEnableDisable.setCreatedOn(commonService.getServerDateTime());
        			userEnableDisable.setcStatus(cStatus);
        			departmentUserService.addTblUserEnableDisableData(userEnableDisable);
        			String mailTemplateId=null;
        			URL url = new URL(request.getRequestURL().toString());
    				StringBuffer verifyUrlPrefix = new StringBuffer();
    				verifyUrlPrefix.append(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "https").append("://").append(url.getHost());
    				if ((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) {
    					verifyUrlPrefix.append(":").append(url.getPort());
    				}
    				Map<String, Object> paramMap = new HashMap<String, Object>();
        			paramMap.put("subdomainname",url.getHost());
        			paramMap.put("Remarks", remarks);
        			paramMap.put("LoginID", request.getParameter("hdLoginId"));
        			paramMap.put("to",request.getParameter("hdLoginId"));
        			if("0".equals(currentStatus) && cStatus==1){
        				linkId=deptUserApproveLinkId;
        				mailTemplateId="30";//for Approve user
        				msg=postDeptUserApproved;
        				successMessage="redirect_success_approve_user" ;
        			}else if(cStatus==1){
        				msg=postDeptUserEnabled;
        				mailTemplateId="14";//for enable user
        				successMessage="redirect_success_enable_user" ;
        				linkId=deptUserEnableLinkId;
        			}else if(cStatus==2){
        				msg=postDeptUserDisabled;
        				mailTemplateId="15";//for disable user
        				successMessage="redirect_success_disable_user" ;
        				linkId=deptUserDisableLinkId;
        			}
        			mailContentUtillity.dynamicMailGeneration(mailTemplateId, userId, String.valueOf(clientBean.getClientId()), paramMap, "");
        		}
        	}
        }
        catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	if(clientBean.getIsPkiEnabled()==1){
        		String signText=request.getParameter("skpSignText");
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,officerId!=null && !officerId.equals("")? Integer.parseInt(officerId):0, remarks,signText);
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, msg, 0,officerId!=null && !officerId.equals("")? Integer.parseInt(officerId):0, remarks);
        	}
        }
        redirectAttributes.addFlashAttribute(updated!=0 ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), updated!=0 ? successMessage : CommonKeywords.ERROR_MSG_KEY.toString());
        return "redirect:/"+DEPT_USER_GRID_URL+encryptDecryptUtils.generateRedirect(DEPT_USER_GRID_URL, request);
    }
    
    /**
     * @author nirav.modi
     * @param modelMap
     * @param userId
     * @param clientId
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/unmapdigitalcerti/{userId}/{enc}", method = RequestMethod.GET)
    public String unMapDigitalCerti(ModelMap modelMap,@PathVariable("userId") int userId,HttpServletRequest request) {
        try {
        	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	//for sign generation code
        	if(clientBean.getIsPkiEnabled()==1){
        		String publicKey=null;
        		String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
        		if(certIds!=null && certIds.length!=0){
        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
        		}
        		modelMap.addAttribute("publicKeyForSign", publicKey);
    		}
        	
        	List<Object[]> unmapCertDetails= departmentUserService.getUnMapCertDetails(userId, clientBean.getClientId());
        	if(unmapCertDetails!=null && !unmapCertDetails.isEmpty() && unmapCertDetails.size() != 3){
        		for (int i = 0; i < unmapCertDetails.size(); i++) {
        			Map<String,Object> certDetail= new HashMap<String, Object>();
            		Object[] object = unmapCertDetails.get(i);
            		certDetail.put("fullName", object[0]);
            		certDetail.put("deptName", object[1]);
            		certDetail.put("desiName", object[2]);
            		certDetail.put("loginId", object[3]);
            		certDetail.put("keyUsage", object[14]);
            		certDetail.put("subject", object[5]);
            		certDetail.put("issuer", object[6]);
            		certDetail.put("publicKey", object[7]);
            		certDetail.put("serialNumber", object[8]);
            		certDetail.put("validFrom", object[9]);
            		certDetail.put("validTo", object[10]);
            		certDetail.put("certId",object[11]);
            		certDetail.put("userCertId",object[12]);
            		certDetail.put("isDual",object[13]);
            		if((Integer)object[14] == 1){
            			modelMap.addAttribute("SigningCerti", certDetail);
            		}else if((Integer)object[14] == 2){
            			modelMap.addAttribute("EncryptionCerti", certDetail);
            		}
    			}
        	}else if(!unmapCertDetails.isEmpty() && unmapCertDetails.size() == 3){
        		List<HashMap<String,Object>> data=new ArrayList<HashMap<String,Object>>();
        		for (int i = 0; i < unmapCertDetails.size(); i++) {
        			Map<String,Object> certDetail= new HashMap<String, Object>();
        			Object[] object = unmapCertDetails.get(i);
        			certDetail.put("fullName", object[0]);
            		certDetail.put("deptName", object[1]);
            		certDetail.put("desiName", object[2]);
            		certDetail.put("loginId", object[3]);
            		certDetail.put("keyUsage", object[14]);
            		certDetail.put("subject", object[5]);
            		certDetail.put("issuer", object[6]);
            		certDetail.put("publicKey", object[7]);
            		certDetail.put("serialNumber", object[8]);
            		certDetail.put("validFrom", object[9]);
            		certDetail.put("validTo", object[10]);
            		certDetail.put("certId",object[11]);
            		certDetail.put("userCertId",object[12]);
            		certDetail.put("isDual",object[13]);
            		data.add((HashMap<String, Object>) certDetail);
            		
            		modelMap.addAttribute("SigningCerti", certDetail);
            		
        		}
        		modelMap.addAttribute("data", data);
        	}
        	modelMap.addAttribute("clientId", clientBean.getClientId());
        	modelMap.addAttribute("rowSize", unmapCertDetails.size());// for count how many rows return
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),unmapDCLinkId, getUnMapDCUserRemark, 0,userId);
        }
        return "/common/admin/UnMapDigitalCerti";
    }
    
    /**
     * @author nirav.modi
     * @param redirectAttributes
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/unmapdigicert", method = RequestMethod.POST)                       
    public String unMapDigiCerti(RedirectAttributes redirectAttributes, HttpServletRequest request){
        boolean success = false;
        String retVal = null;
        String userId = null;
        ClientBean clientBean=null;
        String remark = null;
        try{
        	clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	String encryCertId = request.getParameter("hdEncryCertId");
        	String encryUserCertId = request.getParameter("hdEncryUserCertId");
        	String encryKeyUsage = request.getParameter("hdEncryKeyUsage");
        	String encryIsDual = request.getParameter("hdEncryIsDual");
        	
        	String userCertIds[] = null;
        	String signingCertId = request.getParameter("hdSigningCertId");
        	String signingUserCertId = request.getParameter("hdSigningUserCertId");
        	String signingKeyUsage = request.getParameter("hdSigningKeyUsage");
        	String signingIsDual = request.getParameter("hdSigningIsDual");
        	userId = request.getParameter("hdUserId");
        	String clientId = request.getParameter("hdClientId");
        	remark = request.getParameter("txtaRemarks");
        	String rowSize = request.getParameter("hdRowSize");
        	String loginId = request.getParameter("hdLoginId");
                String encCertiId = request.getParameter("certIsSelect_enc");
        	String signCertiId = request.getParameter("certIsSelect_sign");
        	
        	int createdBy = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserId();
                List<TblUserCertificate> tblUserCertificates = null;
        	if(StringUtils.hasLength(loginId) /*&& StringUtils.hasLength(signingUserCertId)*/  && StringUtils.hasLength(remark) && StringUtils.hasLength(userId) /*&& StringUtils.hasLength(signingCertId)*/){
        		List<TblCertUnMapHistory> tblCertUnMapHistorys = new ArrayList<TblCertUnMapHistory>();
        		tblUserCertificates = new ArrayList<TblUserCertificate>();
        	      if ( signCertiId != null  &&  !signCertiId.isEmpty()) {
                          
                          TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
                          tblCertUnMapHistory.setRemark(remark);
                          tblCertUnMapHistory.setCreatedBy(createdBy);
                          tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(userId)));
                          tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
                          tblCertUnMapHistory.setIsMapped(0);
                          TblUserCertificate tblUserCertificate = new TblUserCertificate();
                          tblCertUnMapHistory.setTblCertificate(new TblCertificate(Integer.parseInt(signingCertId)));
                          tblCertUnMapHistory.setKeyUsage(Integer.parseInt(signingKeyUsage));
                          tblCertUnMapHistory.setIsDualCert(Integer.parseInt(signingIsDual));
                          tblUserCertificate.setUserCertId(Integer.parseInt(signingUserCertId));
                          tblUserCertificates.add(tblUserCertificate);
                          tblCertUnMapHistorys.add(tblCertUnMapHistory);
                         }
                          if ( encCertiId != null  &&  !encCertiId.isEmpty()) {
                              TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
                              tblCertUnMapHistory.setRemark(remark);
                              tblCertUnMapHistory.setCreatedBy(createdBy);
                              tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(userId)));
                              tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
                              tblCertUnMapHistory.setIsMapped(0);
                              TblUserCertificate tblUserCertificate = new TblUserCertificate();
                              tblCertUnMapHistory.setTblCertificate(new TblCertificate(Integer.parseInt(encryCertId)));
                              tblCertUnMapHistory.setKeyUsage(Integer.parseInt(encryKeyUsage));
                              tblCertUnMapHistory.setIsDualCert(Integer.parseInt(encryIsDual));
                              tblUserCertificate.setUserCertId(Integer.parseInt(encryUserCertId));
                              tblUserCertificates.add(tblUserCertificate);
                              tblCertUnMapHistorys.add(tblCertUnMapHistory);
                          }
                      
                      
            	success = departmentUserService.addCertUnMapHistory(tblCertUnMapHistorys,tblUserCertificates);
        	}
        	if(success){
                        //wSCheckAvailService.updateCertificateStatus(commonService.getSerialNo(certIds.substring(0, certIds.length()-1).toString()));
        		Map<String,Object> mailParams=new HashMap<String, Object>();
        		mailParams.put("SubDomainName", clientService.getClientNameById(clientBean.getClientId()));
        		List<Object> data=loginService.getLoginIdByUserId(Integer.parseInt(userId));
        		mailParams.put("to", !data.isEmpty() ? data.get(0) : "");
        		mailParams.put("EmailID", !data.isEmpty() ? data.get(0) : "");
        		mailParams.put("ClientName", clientService.getClientNameByClientId(clientBean.getClientId()));
        		mailContentUtillity.dynamicMailGeneration("250", userId, clientId, mailParams, "");
        		retVal = DEPT_USER_GRID_URL;
        	}else{
        		retVal = "common/admin/unmapdigitalcerti/"+userId;
        	}
        }
        catch(Exception ex){
        	retVal = "common/admin/unmapdigitalcerti/"+userId;
        	exceptionHandlerService.writeLog(ex);
        }
        finally{
        	if(clientBean.getIsPkiEnabled()==1){
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), unmapDCLinkId, postUnMapDCUserRemark, 0,userId!=null && !userId.equals("")? Integer.parseInt(userId):0,remark,request.getParameter("skpSignText"));
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), unmapDCLinkId, postUnMapDCUserRemark, 0,userId!=null && !userId.equals("")? Integer.parseInt(userId):0,remark);
        	}
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "reiderct_success_unmap_certificate" : CommonKeywords.ERROR_MSG_KEY.toString());
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    /**
     * @author nirav.modi
     * Approval rights for User
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/approvalrightstouser/{officerId}/{enc}", method = RequestMethod.GET)
    public String approvalRightsTouser(@PathVariable("officerId") int officerId,ModelMap modelMap,HttpServletRequest request) {
        try {
        	List<Object[]> allDomainList=  commonService.getAllDomain();
        	List<SelectItem> domainList = new ArrayList<SelectItem>();
        	if(allDomainList!=null && !allDomainList.isEmpty()){
        		for (Object[] objects : allDomainList) {
            		domainList.add(new SelectItem(objects[1], objects[0]));
    			}
        	}
        	
        	List<Object[]> list =departmentUserService.getUserNameEmailIDByOfficerId(officerId);
        	Object[] obj= list.get(0);//userName
        	modelMap.addAttribute("clientName",obj[0]);
        	modelMap.addAttribute("userId",obj[2]);
        	
        	List<Object> activeDomainList= departmentUserService.getActiveDomainById((Integer)obj[2]);
        	modelMap.addAttribute("activeDomainList",activeDomainList);
        	modelMap.addAttribute("isModifyCase",activeDomainList.size()!=0);// Using this, redirect msg will be come by approval rights modified successfully. and approval rights assigned successfully.     
        	modelMap.addAttribute("domainList",domainList);
        	
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), approvalRightsLinkId, getApprovalRightRemark, 0,officerId);
        }
        return "/common/admin/ApprovalRightsToUser";
    }
    
    /**
     * @author nirav.modi
     * @param redirectAttributes
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/assignrightstouser", method = RequestMethod.POST)                       
    public String assignRightsTouser(RedirectAttributes redirectAttributes, HttpServletRequest request){ 
        boolean success = false;
        boolean isPOJOSet=false;
        String retVal = null;
        String msg=null;
        String [] domainArray=null;
        String userId =null;
        String officerId =null;
        String isModifyCase=null; //TODO : instead of using as String convert to boolean if not null and then modify if-else accordingly.
        List<TblBidderApproval> tblBidderApprovalList = null;
        try{
        	int createdBy = abcUtility.getSessionUserId(request);
        	userId = request.getParameter("hdUserId");
        	officerId = request.getParameter("hdOfficerId");
        	isModifyCase=request.getParameter("hdIsModifyCase");
        	domainArray=request.getParameterValues("chkMultipleDomain");
        	if(domainArray != null && domainArray.length!= 0 && StringUtils.hasLength(userId)){ //TODO : instead of else-if this can be convert into simple if-else
        		tblBidderApprovalList = new ArrayList<TblBidderApproval>();
        		for (int i = 0; i < domainArray.length; i++) {
        			TblBidderApproval tblBidderApproval = new TblBidderApproval();
                	tblBidderApproval.setCreatedBy(createdBy);
                	tblBidderApproval.setTblClient(new TblClient(Integer.parseInt(domainArray[i])));
                	tblBidderApproval.setTblUserLogin(new TblUserLogin(Integer.parseInt(userId)));
                	tblBidderApproval.setIsActive(1);
                	tblBidderApprovalList.add(tblBidderApproval);
    			}
        		isPOJOSet=true;
        	}else if((domainArray == null || domainArray.length== 0) && StringUtils.hasLength(userId)){ // TODO : Use StringUtils.hasLength to check string not null and not empty.
        		tblBidderApprovalList = new ArrayList<TblBidderApproval>();
                TblBidderApproval tblBidderApproval = new TblBidderApproval();
            	tblBidderApproval.setCreatedBy(createdBy);
            	tblBidderApproval.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
            	tblBidderApproval.setTblUserLogin(new TblUserLogin(Integer.parseInt(userId)));
            	tblBidderApproval.setIsActive(1);
            	tblBidderApprovalList.add(tblBidderApproval);
            	isPOJOSet=true;
        	}
        	if(isPOJOSet){
        		success = departmentUserService.giveApprovalRightsToUser(Integer.parseInt(userId),tblBidderApprovalList);
        	}
        	if(success){
        		if(isModifyCase!=null && "true".equals(isModifyCase)){//For Modify status.  
        			msg = "redirect_modified_rights";
        		}else if(isModifyCase!=null && "false".equals(isModifyCase)){//For assigned status.
        			msg = "redirect_assigned_rights";
        		}
        		retVal=DEPT_USER_GRID_URL;
        	}else{
        		retVal="common/admin/approvalrightstouser/"+officerId;
        	}
        }
        catch(Exception ex){
        	return exceptionHandlerService.writeLog(ex);
        }
        finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), approvalRightsLinkId, postApprovalRightRemark, 0,officerId!=null && !officerId.equals("") ? Integer.parseInt(officerId):0);
        }
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? msg : CommonKeywords.ERROR_MSG_KEY.toString());
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    /**
     * Send Reg details.
     * 
     * @author purvesh
     * @param modelMap
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/sendregdetails/{userId}/{userTypeId}/{enc}", method = RequestMethod.GET)                       
    public String sendRegistarionDetails(@PathVariable("userId") int userId,@PathVariable("userTypeId") int userTypeId, ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes){
    	boolean success=false;
    	boolean isSSOEnabled = false;
    	String retVal="redirect:/common/admin/managebidder"+encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
    	try {
        	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        	isSSOEnabled = clientBean.isIsSsoEnabled();
        	String publicKey=null;
    		if(clientBean.getIsPkiEnabled()==1){
        		String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
        		if(certIds!=null && certIds.length!=0){
        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
        		}
        		modelMap.addAttribute("publicKey", publicKey);
        		retVal="/common/admin/SendRegDetails";
    		}else{
    			TblUserLogin tblUserLogin= loginService.getUserLoginById(userId);
            	String pass =UUID.randomUUID().toString().substring(0, 4)+"@"+UUID.randomUUID().toString().substring(0, 4);
            	String encryptedPassword = sha256HashEncryption.encodeStringSHA256(pass);
            	String sha1encryptedPassword = sha1HashEncryption.encodeStringSHA1(pass);
            	int createdBy = abcUtility.getSessionUserId(request);
        		TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
        		tblPasswordHistory.setTblUserLogin(new TblUserLogin(userId));
        		tblPasswordHistory.setCreatedBy(createdBy);
        		tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
        		tblPasswordHistory.setPasswordUpdatedFrom(passwordUpdatedFrom);//3
            	
        		TblUserHistory tblUserHistory = new TblUserHistory();
        		tblUserHistory.setActionType(actionTypeSendRegResetPassword);
        		tblUserHistory.setCreatedBy(createdBy);
        		tblUserHistory.setTblUserLogin(tblUserLogin);
        		tblUserHistory.setTblClient(new TblClient(clientBean.getClientId()));
        		if(isSSOEnabled){
        			success= wSCheckAvailService.changePassword(tblUserLogin.getLoginId(), encryptedPassword+"~~"+sha1encryptedPassword,tblUserLogin.getUserId(),clientBean.getClientId());
            		if (WSCheckAvail.isSsoAvailable() && !success) {
            			//First dump user in sso from Local and then reset the pass
            			success = wSCheckAvailService.dumpUserWithChngPwd(tblUserLogin.getUserId(),clientBean.getClientId(),userTypeId,true,encryptedPassword,sha1encryptedPassword);
            		}
        		}else{
        			success = true;
        		}
        		if(success){
        			success= departmentUserService.resetPassword(userId,encryptedPassword,tblPasswordHistory,tblUserHistory);
        			if(success){
        				redirectAttributes.addFlashAttribute("resetPassword", pass);
        				redirectAttributes.addFlashAttribute("loginId", tblUserLogin.getLoginId());
        				redirectAttributes.addFlashAttribute("success",success);
                        redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_sent_regdetails");
        			}else{
        				redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
        			}
        		}else if (WSCheckAvail.isSsoAvailable() && !success) {
        			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
        		}else{
        			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
        		}
            	if(success){
    				Map<String, Object> paramMap = new HashMap<String, Object>();
    				paramMap.put("loginId", tblUserLogin.getLoginId());
    				paramMap.put("password", pass);
    				mailContentUtillity.dynamicMailGeneration("34",String.valueOf(userId), String.valueOf(clientBean.getClientId()), paramMap, "");
            	}
                if(userTypeId==3){ // for Manage user grid
                	retVal ="redirect:/"+DEPT_USER_GRID_URL+encryptDecryptUtils.generateRedirect(DEPT_USER_GRID_URL, request);
                }else{// for bidder grid
                	retVal="redirect:/common/admin/managebidder"+encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
                }
    		}
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally{
        	if(abcUtility.getSessionIsPkiEnabled(request)!=1){
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), userTypeId==3 ? sendRegDetailsOfficerLinkId  : sendRegDetailsBidderLinkId, 
        				                            userTypeId==3 ? sendRegDetailsOfficerAudit  : sendRegDetailsBidderAudit, 0,userId);
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), userTypeId == 3 ? sendRegDetailsOfficerLinkId : sendRegDetailsBidderLinkId, 
        											userTypeId==3 ? sendRegDetailsOfficerAudit  : sendRegDetailsBidderAudit, 0, userId);	
        	}
        }
    	return retVal;
    }
    /**
     *  Send Reg details with sign.
     *  
     * @author purvesh
     * @param modelMap
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/sendregdetailswithsign", method = RequestMethod.POST)                       
    public String sendRegistarionDetailsWithSign(RedirectAttributes redirectAttributes,HttpServletRequest request){ 
    	boolean success = false;
    	String userId =null;
    	String userTypeId=null; //TODO : convert userTypeId to int
    	ClientBean clientBean= null;
    	String retVal=null;
    	boolean isSSOEnabled = false;
    	try{
    		clientBean=(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    		isSSOEnabled = clientBean.isIsSsoEnabled();
    		userId= request.getParameter("hdUserId");
    		userTypeId= request.getParameter("hdUserTypeId");
    		if(StringUtils.hasLength(userId) && StringUtils.hasLength(userTypeId)){ 
    			TblUserLogin tblUserLogin= loginService.getUserLoginById(Integer.parseInt(userId));
            	String pass =UUID.randomUUID().toString().substring(0, 4)+"@"+UUID.randomUUID().toString().substring(0, 4);
            	String encryptedPassword = sha256HashEncryption.encodeStringSHA256(pass);
            	String sha1encryptedPassword = sha1HashEncryption.encodeStringSHA1(pass);
            	int createdBy = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserId();
        		TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
        		tblPasswordHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(userId)));
        		tblPasswordHistory.setCreatedBy(createdBy);
        		tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
        		tblPasswordHistory.setPasswordUpdatedFrom(passwordUpdatedFrom);//3
            	
        		TblUserHistory tblUserHistory = new TblUserHistory();
        		tblUserHistory.setActionType(actionTypeSendRegResetPassword);
        		tblUserHistory.setCreatedBy(createdBy);
        		tblUserHistory.setTblUserLogin(tblUserLogin);
        		tblUserHistory.setTblClient(new TblClient(clientBean.getClientId()));
        		if(isSSOEnabled){
        			success= wSCheckAvailService.changePassword(tblUserLogin.getLoginId(), encryptedPassword+"~~"+sha1encryptedPassword,tblUserLogin.getUserId(),clientBean.getClientId());
            		if (WSCheckAvail.isSsoAvailable() && !success) {
            			//First dump user in sso from Local and then reset the pass
            			success = wSCheckAvailService.dumpUserWithChngPwd(tblUserLogin.getUserId(),clientBean.getClientId(),Integer.parseInt(userTypeId),true,encryptedPassword,sha1encryptedPassword);
            		}
        		}else{
        			success = true;
        		}
        		if(success){
        			success= departmentUserService.resetPassword(Integer.parseInt(userId),encryptedPassword,tblPasswordHistory,tblUserHistory);
        			if(success){
        				redirectAttributes.addFlashAttribute("resetPassword", pass);
        				redirectAttributes.addFlashAttribute("loginId", tblUserLogin.getLoginId());
        				redirectAttributes.addFlashAttribute("success",success);
                        redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_sent_regdetails");
        			}else{
        				redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
        			}
        		}else if (WSCheckAvail.isSsoAvailable() && !success) {
        			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
        		}else{
        			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
        		}
            	if(success){
    				Map<String, Object> paramMap = new HashMap<String, Object>();
    				paramMap.put("loginId", tblUserLogin.getLoginId());
    				paramMap.put("password", pass);
    				
    				mailContentUtillity.dynamicMailGeneration("34", userId, String.valueOf(clientBean.getClientId()), paramMap, "");
            	}
    		}
        }
        catch(Exception e){
        	return exceptionHandlerService.writeLog(e);
        }
    	finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), userTypeId.equals("3") ? sendRegDetailsOfficerLinkId : sendRegDetailsBidderLinkId, 
										userTypeId.equals("3") ? sendRegDetailsOfficerAudit  : sendRegDetailsBidderAudit, 0,StringUtils.hasLength(userId) ? Integer.parseInt(userId):0,"",request.getParameter("skpSignText"));
        }
        if(userTypeId.equals("3")){ // for Manage user grid
        	retVal = DEPT_USER_GRID_URL;
        }else{// for bidder grid
        	retVal="common/admin/managebidder";
        }
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    /**
     * @author nirav.modi
     * @param modelMap
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/resetpassword/{userId}/{userTypeId}/{byEmail}/{enc}", method = RequestMethod.GET)
	public String resetPassword(@PathVariable("userId") int userId, @PathVariable("userTypeId") int userTypeId,
			@PathVariable("byEmail") int byEmail, ModelMap modelMap, HttpServletRequest request,
			RedirectAttributes redirectAttributes) {
		boolean success = false;
		String retVal = null;
		boolean isSSOEnabled = false;
		try {
			ClientBean clientBean = (ClientBean) request.getSession()
					.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
			isSSOEnabled = clientBean.isIsSsoEnabled();
			String publicKey = null;
			if (clientBean.getIsPkiEnabled() == 1) {
				String certIds[] = ((SessionBean) request.getSession()
						.getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
				if (certIds != null && certIds.length != 0) {
					publicKey = commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
				}
				if (byEmail==2) {
					modelMap.addAttribute("success","2");
				} else if (byEmail==1) {
					modelMap.addAttribute("success", "1");
				}
				modelMap.addAttribute("publicKey", publicKey);
				retVal = "/common/admin/ResetPassword";
			} else {
				TblUserLogin tblUserLogin = loginService.getUserLoginById(userId);
				String pass = UUID.randomUUID().toString().substring(0, 4) + "@"
						+ UUID.randomUUID().toString().substring(0, 4);
				String encryptedPassword = sha256HashEncryption.encodeStringSHA256(pass);
				String sha1encryptedPassword = sha1HashEncryption.encodeStringSHA1(pass);
				int createdBy = abcUtility.getSessionUserId(request);
				TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
				tblPasswordHistory.setTblUserLogin(new TblUserLogin(userId));
				tblPasswordHistory.setCreatedBy(createdBy);
				tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
				tblPasswordHistory.setPasswordUpdatedFrom(passwordUpdatedFrom);// 3

				TblUserHistory tblUserHistory = new TblUserHistory();
				tblUserHistory.setActionType(actionTypeResetPassword);
				tblUserHistory.setCreatedBy(createdBy);
				tblUserHistory.setTblUserLogin(tblUserLogin);
				tblUserHistory.setTblClient(new TblClient(clientBean.getClientId()));
				if (isSSOEnabled) {
					success = wSCheckAvailService.changePassword(tblUserLogin.getLoginId(),
							encryptedPassword + "~~" + sha1encryptedPassword, tblUserLogin.getUserId(),
							clientBean.getClientId());
					if (WSCheckAvail.isSsoAvailable() && !success) {
						// First dump user in sso from Local and then reset the
						// pass
						success = wSCheckAvailService.dumpUserWithChngPwd(userId, clientBean.getClientId(), userTypeId,
								true, encryptedPassword, sha1encryptedPassword);
					}
				} else {
					success = true;
				}
				if (success) {
					success = departmentUserService.resetPassword(userId, encryptedPassword, tblPasswordHistory,
							tblUserHistory);
					if (success) {
						redirectAttributes.addFlashAttribute("resetPassword", pass);
						redirectAttributes.addFlashAttribute("loginId", tblUserLogin.getLoginId());
						if (byEmail==2) {
							redirectAttributes.addFlashAttribute("success", success);
						} else if (byEmail==1) {
							redirectAttributes.addFlashAttribute("success", "byEmail");
						}
						redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),
								"redirect_success_reset_password");
					} else {
						redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
								CommonKeywords.ERROR_MSG_KEY.toString());
					}
				} else if (WSCheckAvail.isSsoAvailable()) {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),
							CommonKeywords.ERROR_MSG_KEY.toString());
				} else {
					redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_reg_serv_not_avail");
				}
				if (success) {
					Map<String, Object> paramMap = new HashMap<String, Object>();
					paramMap.put("password", pass);
					paramMap.put("emailId", tblUserLogin.getLoginId());
					mailContentUtillity.dynamicMailGeneration("7", String.valueOf(userId),
							String.valueOf(clientBean.getClientId()), paramMap, "");

					int bidderRegVerifiedBy = clientService.getBidderRegistrationVerifiedBy(clientBean.getClientId());
					if (userTypeId == 2 && bidderRegVerifiedBy == 3 || bidderRegVerifiedBy == 2) {
						Map<String, Object> map = new HashMap<String, Object>();
						map.put("otp", pass);
						boolean isIndian = commonService.getCountryIdByCompanyId(Integer
								.parseInt(String.valueOf(commonService.getCompanyIdByUserId(userId)))) == countryId;
						smsContentUtillity.dynamicSMSGeneration(
								userTypeId == 3 ? resetPasswordLinkId : bidderResetPasswordLinkId,
								tblUserLogin.getMobileNo(), msgResetPass, commonService.getSMSSenderIdFromLogo(request),
								map, isIndian); // 1. parameter link Id 2.
												// mobile no 3. template string
												// 4. sender Id as per client 5.
												// dynamic parameters
					}
				}
				if (userTypeId == 3) { // for Manage user grid
					retVal = "redirect:/" + DEPT_USER_GRID_URL
							+ encryptDecryptUtils.generateRedirect(DEPT_USER_GRID_URL, request);
				} else {// for bidder grid
					retVal = "redirect:/common/admin/managebidder"
							+ encryptDecryptUtils.generateRedirect("common/admin/managebidder", request);
				}

			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			if (abcUtility.getSessionIsPkiEnabled(request) != 1) {
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
						userTypeId == 3 ? resetPasswordLinkId : bidderResetPasswordLinkId, postResetPasswordRemark, 0,
						userId);
			} else {
				auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
						userTypeId == 3 ? resetPasswordLinkId : bidderResetPasswordLinkId, getResetPasswordRemark, 0,
						userId);
			}
		}
		return retVal;
	}
    
    /**
     * @author nirav.modi
     * @param modelMap
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/resetpasswordwithsign/{success}", method = RequestMethod.POST)                       
    public String resetPasswordWithSign(@PathVariable("success") int byEmail,RedirectAttributes redirectAttributes,HttpServletRequest request){ 
    	boolean success = false;
    	String userId =null;
    	String userTypeId=null; //TODO : convert userTypeId to int
    	ClientBean clientBean= null;
    	String retVal=null;
    	boolean isSSOEnabled = false;
    	try{
    		clientBean=(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    		isSSOEnabled = clientBean.isIsSsoEnabled();
    		userId= request.getParameter("hdUserId");
    		userTypeId= request.getParameter("hdUserTypeId");
    		if(StringUtils.hasLength(userId) && StringUtils.hasLength(userTypeId)){ 
    			TblUserLogin tblUserLogin= loginService.getUserLoginById(Integer.parseInt(userId));
            	String pass =UUID.randomUUID().toString().substring(0, 4)+"@"+UUID.randomUUID().toString().substring(0, 4);
            	String encryptedPassword = sha256HashEncryption.encodeStringSHA256(pass);
            	String sha1encryptedPassword = sha1HashEncryption.encodeStringSHA1(pass);
            	int createdBy = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getUserId();
        		TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
        		tblPasswordHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(userId)));
        		tblPasswordHistory.setCreatedBy(createdBy);
        		tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
        		tblPasswordHistory.setPasswordUpdatedFrom(passwordUpdatedFrom);//3
            	
        		TblUserHistory tblUserHistory = new TblUserHistory();
        		tblUserHistory.setActionType(actionTypeResetPassword);
        		tblUserHistory.setCreatedBy(createdBy);
        		tblUserHistory.setTblUserLogin(tblUserLogin);
        		tblUserHistory.setTblClient(new TblClient(clientBean.getClientId()));
        		if(isSSOEnabled){
        			success= wSCheckAvailService.changePassword(tblUserLogin.getLoginId(), encryptedPassword+"~~"+sha1encryptedPassword,tblUserLogin.getUserId(),clientBean.getClientId());
            		if (WSCheckAvail.isSsoAvailable() && !success) {
            			//First dump user in sso from Local and then reset the pass
            			success = wSCheckAvailService.dumpUserWithChngPwd(tblUserLogin.getUserId(),clientBean.getClientId(),Integer.parseInt(userTypeId),true,encryptedPassword,sha1encryptedPassword);
            		}
        		}else{
        			success = true;
        		}
        		if(success){
        			success= departmentUserService.resetPassword(Integer.parseInt(userId),encryptedPassword,tblPasswordHistory,tblUserHistory);
        			if(success){
        				redirectAttributes.addFlashAttribute("resetPassword", pass);
        				redirectAttributes.addFlashAttribute("loginId", tblUserLogin.getLoginId());
        				redirectAttributes.addFlashAttribute("success",success);
        				if (byEmail==2) {
							redirectAttributes.addFlashAttribute("success", success);
						} else if (byEmail==1) {
							redirectAttributes.addFlashAttribute("success", "byEmail");
						}
                        redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_reset_password");
        			}else{
        				redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
        			}
        		}else{
        			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
        		}
            	if(success){
    				Map<String, Object> paramMap = new HashMap<String, Object>();
    				paramMap.put("password", pass);
    				paramMap.put("emailId", tblUserLogin.getLoginId());
    				
    				mailContentUtillity.dynamicMailGeneration("7", userId, String.valueOf(clientBean.getClientId()), paramMap, "");
    				
    				int bidderRegVerifiedBy=clientService.getBidderRegistrationVerifiedBy(clientBean.getClientId());
    				if(userTypeId.equals("2") && bidderRegVerifiedBy == 3 || bidderRegVerifiedBy == 2){
    					Map<String, Object> map = new HashMap<String, Object>();
    					map.put("otp", pass);
    					boolean isIndian=commonService.getCountryIdByCompanyId(Integer.parseInt(String.valueOf(commonService.getCompanyIdByUserId(Integer.parseInt(userId)))))==countryId;
    					smsContentUtillity.dynamicSMSGeneration(userTypeId.equals("3")?resetPasswordLinkId:bidderResetPasswordLinkId, tblUserLogin.getMobileNo(), msgResetPass,commonService.getSMSSenderIdFromLogo(request), map,isIndian);   // 1. parameter link Id 2. mobile no 3. template string 4. sender Id as per client 5. dynamic parameters
    				}
    			}
    		}
        }
        catch(Exception e){
        	return exceptionHandlerService.writeLog(e);
        }
    	finally{
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), userTypeId.equals("3")?resetPasswordLinkId:bidderResetPasswordLinkId,postResetPasswordRemark, 0,StringUtils.hasLength(userId) ? Integer.parseInt(userId):0,"",request.getParameter("skpSignText"));
        }
        if(userTypeId.equals("3")){ // for Manage user grid
        	retVal = DEPT_USER_GRID_URL;
        }else{// for bidder grid
        	retVal="common/admin/managebidder";
        }
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    /** to unlock user from manage bidder and manage user grid
     * @author nihar.dave
     * @param modelMap
     * @param response
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/unlockuser/{userId}/{userTypeId}/{enc}", method = RequestMethod.GET)                       
    public String unLockUser(RedirectAttributes redirectAttributes,@PathVariable("userId") int userId,@PathVariable("userTypeId") int userTypeId,HttpServletRequest request){ 
    	String retVal=null;
    	String emailId=null;
    	try {
    		boolean success=false;
        	int clientId=abcUtility.getSessionClientId(request);
        	int createdBy = abcUtility.getSessionUserId(request);
        	TblUserHistory tblUserHistory=new TblUserHistory();
        	tblUserHistory.setActionType(actionTypeUnlock);
        	tblUserHistory.setTblUserLogin(new TblUserLogin(userId));
        	tblUserHistory.setCreatedBy(createdBy);
        	tblUserHistory.setTblClient(new TblClient(clientId));
        	success=departmentUserService.unLockUser(userId, tblUserHistory,null);
        	if(success && userTypeId == 3){ // for Manage user grid
            	retVal = DEPT_USER_GRID_URL;
            	redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_unlockuser");
            }else if(success){// for bidder grid
            	URL url = new URL(request.getRequestURL().toString());
        		List<Object> data=loginService.getLoginIdByUserId(userId);
        		if(data != null && !data.isEmpty()){
        			emailId= (String)data.get(0);
        		}
        		Map<String,Object> dataMap=new HashMap<String, Object>();
        		dataMap.put("ClientName", clientService.getClientNameByClientId(clientId));
        		dataMap.put("subdomainname", url.getHost());
        		dataMap.put("to", emailId);
        		dataMap.put("emailId", emailId);        		
        		retVal="common/admin/managebidder";
        		mailContentUtillity.dynamicMailGeneration("24", String.valueOf(userId), String.valueOf(clientId),dataMap ,"");
            	redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_unlockuser");
            }else{
            	if(userTypeId == 3){
            		retVal = DEPT_USER_GRID_URL;
            		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
            	}else{
            		retVal="common/admin/managebidder";
            		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
            	}
            }
        } catch (Exception e) {
           return  exceptionHandlerService.writeLog(e);
        }finally{
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), userTypeId == 3 ? deptUserUnlockLinkId : bidderUnlockLinkId, userTypeId == 3 ? postUserUnlockRemark : postBidderUnlockRemark, 0, userId);
        }
    	return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    @RequestMapping(value = "/buyer/attacheventspeccerti/{redirectLink}/{enc}", method = RequestMethod.GET)
    public String showCerti(@PathVariable("redirectLink") String redirectLink,@ModelAttribute CertiDataBean certiDataBean, ModelMap model, HttpServletRequest req) {
        String pageName = "redirect:/loginfailed";
        if (req.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            SessionBean sessionBean = (SessionBean) req.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            ClientBean clientBean = (ClientBean) req.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            boolean flag = false;
            try {            	
            	model.addAttribute("attachCerti", true);
            	model.addAttribute("redirectLink", redirectLink);
            	model.addAttribute("isDcVerificationRequired",clientBean.getIsDcVerificationRequired());
            	flag=loginService.setCertiDetails(sessionBean, clientBean, model);
		TblClient tempClient=clientService.getClientById(clientBean.getClientId());
            	model.addAttribute("certificateClass",tempClient.getCertificateClass());
            } catch (Exception e) {
                return exceptionHandlerService.writeLog(e);
            } finally {
                auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), certiMapLink, showCertiAudit, 0, sessionBean.getUserId());
            }
            if (flag) {
                pageName = "CertiMap";
            }
        }
        return pageName;
    }
    
    /**
     * Mapping of Department-Officer
     * @Author Nirav Raval
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/mapDeptOfficer/{userId}/{enc}", method = RequestMethod.GET)
    public String mapDeptOfficer(@PathVariable(USER_ID) int userId, ModelMap modelMap, HttpServletRequest request) {
        String retVal = "/common/admin/DeptOfficerMap";
        SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());  
        try {              
              String officerName = commonService.getUserName(userId);  
              modelMap.addAttribute("officerName",officerName);
              List<Object[]> lstMappingData = clientService.getTblDrtOfficerDepartment(userId);
              List<Object> deptLst = commonService.getDepartmentNameByUserId(userId,abcUtility.getSessionClientId(request));
              int deptId = !(deptLst.isEmpty())?Integer.parseInt(deptLst.get(0).toString()):0;
              modelMap.addAttribute("deptId",deptId);
              modelMap.addAttribute(USER_ID,userId);
              modelMap.addAttribute("lstMappingData",lstMappingData);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deptOfficerMapLink, editDeptOfficerMap, 0,sessionBean.getUserId());
        }
        return retVal;
    }
    
    /**
     * To add department-user mapping details
     * @Author Nirav Raval
     * @param modelMap
     * @param redirectAttributes
     * @param request
     * @return 
     */
    @RequestMapping(value = "/admin/addmapDeptofficer/", method = RequestMethod.POST)
    public String addMapDeptOfficer(ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) { 
        boolean isSuccess = false;
        String redirectLink = null;
        String successRedirectLink;
        String successMessage = "redirect_success_officer_dept_map";

        String retVal = null;
        String deptIds = request.getParameter("deptIds");
        int officerId = Integer.valueOf(request.getParameter("hduserId"));
        String deptIdsData[];
        deptIdsData = StringUtils.commaDelimitedListToStringArray(deptIds);
        int createdBy = abcUtility.getSessionUserId(request);
        SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()); 
        List<TblDrtOfficerDepartment> listDrtOfficerDepartment = new ArrayList<TblDrtOfficerDepartment>();
        try{
            for(int i =0; i<deptIdsData.length; i++){
                TblDrtOfficerDepartment tblDrtOfficerDepartment = new TblDrtOfficerDepartment();  
                tblDrtOfficerDepartment.setCreatedBy(createdBy);
                TblUserLogin tblUserLogin = new TblUserLogin(officerId);
                tblDrtOfficerDepartment.setTblUserLogin(tblUserLogin);
                tblDrtOfficerDepartment.setIsActive(1);
                TblDepartment tblDepartment = clientService.getTblDepartmentByDeptId(Integer.valueOf(deptIdsData[i]));
                tblDrtOfficerDepartment.setTblDepartment(tblDepartment);
                
                TblClient  tblClient = new TblClient(tblDepartment.getTblClient().getClientId());
                tblDrtOfficerDepartment.setTblClient(tblClient);
                
                listDrtOfficerDepartment.add(tblDrtOfficerDepartment);
            }
        
            isSuccess = clientService.addDeptOfficerMap(listDrtOfficerDepartment);
            successRedirectLink = DEPT_USER_GRID_URL;
           
            if (isSuccess) {
                retVal = successRedirectLink;
            } else {
                retVal = redirectLink;
            }
            retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);

        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deptOfficerMapLink, isSuccess ? successDeptOfficerMap:failDeptOfficerMap, 0,sessionBean.getUserId());
        }
        redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? successMessage : CommonKeywords.ERROR_MSG_KEY.toString());
        return retVal;
    }
    
    /**
     * UnMap Department-Officer
     * @Author Nirav Raval
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/admin/unmapDeptOfficer/{officerId}/{deptId}/{enc}", method = RequestMethod.GET)
    public String unmapDeptOfficer(@PathVariable("officerId") int officerId, @PathVariable("deptId") int deptId,ModelMap modelMap, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean isSuccess = false;
        String retVal = "common/admin/mapDeptOfficer/"+officerId;
        String successMessage = "redirect_success_officer_dept_unmap";
        SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());   
        try {
              isSuccess = clientService.unMapDrtOfficerDepartment(officerId,deptId);
              List<Object[]> lstMappingData = clientService.getTblDrtOfficerDepartment(officerId);
              modelMap.addAttribute(USER_ID,officerId);
              modelMap.addAttribute("lstMappingData",lstMappingData);
              String officerName = commonService.getUserName(officerId);  
              modelMap.addAttribute("officerName",officerName);
              if(isSuccess){
                  redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_unmapdept");
              }else{
                  redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
              }

        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deptOfficerMapLink, editDeptOfficerMap, 0,sessionBean.getUserId());
        }          
          retVal = "redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
          return retVal;
    }
    
    @RequestMapping(value = "/admin/popuptreeDeptOfficerMap/{officerId}", method = RequestMethod.GET)
    public String popuptreeDeptOfficerMap(@PathVariable("officerId") int officerId, ModelMap modelMap, HttpServletRequest request, HttpServletResponse response) {
        String retVal;
        modelMap.addAttribute(USER_ID,officerId);
        retVal = "/common/admin/PopuptreeDeptOfficerMap";
        return retVal;
    }
    
    
    @RequestMapping(value = {"admin/getdrttree/{userId}"}, method = RequestMethod.GET)
    @ResponseBody
    public String getDepartmentList(@PathVariable("userId") int userId,HttpServletResponse response, HttpSession httpSession, HttpServletRequest request) throws IOException {
        String deptTree = null;
        try {
            
            List<Map<String, Object>> lst = drtService.getDRTFullTree();
 
            StringBuilder jsonString = new StringBuilder();
            if (lst != null && !lst.isEmpty()) {
                Iterator<Map<String, Object>> itr = lst.iterator();
                jsonString.append("[{");
                int prevLevel = 0;
                int level = 0;
                int deptLevel = 0;
                int deptId = 0;
                boolean isFirstLevel = true;
                
                while (itr.hasNext()) {
                    deptLevel = 0;
                    deptId = 0;
                    String deptName = null;

                    Map<String, Object> map = (Map<String, Object>) itr.next();
                    deptId = Integer.parseInt(map.get("deptId").toString());
                    
                    deptLevel = Integer.parseInt(map.get("deptLevel").toString());
                    deptName = map.get("deptName").toString();
                    
                    if(isFirstLevel)
                    {
                       prevLevel  = deptLevel;
                       level = deptLevel;
                    }
                    if (deptLevel == prevLevel) {
                        if (!isFirstLevel) {
                            jsonString.append("}, {");
                        } else {
                            isFirstLevel = false;
                        }
                        jsonString.append("\"id\":").append(deptId).append(",")
                                .append("\"text\":").append("\"").append(deptName).append("\"").append(",")
                                .append("\"state\":").append("\"").append("closed").append("\"").append(",")
                                .append("\"children\":[{");
                    } else if (deptLevel > prevLevel) {
                        jsonString.append("\"id\":").append(deptId).append(",")
                                .append("\"text\":").append("\"").append(deptName).append("\"").append(",")
                                .append("\"state\":").append("\"").append("closed").append("\"").append(",")
                                .append("\"children\":[{");
                    } else if (deptLevel < prevLevel) {
                        int diff = prevLevel - deptLevel;
                        for (int i = level; i < level + diff; i++) {
                            jsonString.append("}]");
                        }
                        jsonString.append("}, {\"id\":").append(deptId).append(",")
                                .append("\"text\":").append("\"").append(deptName).append("\"").append(",")
                                .append("\"state\":").append("\"").append("closed").append("\"").append(",")
                                .append("\"children\":[{");
                    }

                    prevLevel = deptLevel;
                }
                for (int i = level; i <= deptLevel; i++) {
                    jsonString.append("}]");
                }
            }
            deptTree = jsonString.toString().replace(",\"state\":\"closed\",\"children\":[{}", "}");
           
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deptTreeLinkId, ajaxGetDeptTreeAuditMsg, 0, hdDeptId);
        }
        return deptTree;
    }
    
    /**
     * used for map officer for QA module Change Request #22284
     * @author Lipi Shah
     */
    @RequestMapping(value = "/admin/mapofficerqueans/{userId}/{enc}", method = RequestMethod.GET)
    public String mapOfficerQueAns(@PathVariable("userId") int userId,ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	boolean isSuccess = false;
    	int counter = 0;
    	String retVal="redirect:/common/admin/managedeptuser"+encryptDecryptUtils.generateRedirect("common/admin/managedeptuser", request);
    	SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
        try {
        	List<TblQueAnsOfficer> queAnsOfficers =  departmentUserService.getTblQueAnsOfficer(abcUtility.getSessionClientId(request));
        	for(TblQueAnsOfficer officers:queAnsOfficers){//officer is already mapped or not
        		if(officers.getIsActive() == 1){
        			counter++;
        		}
        	}
        	if(counter == 0){
        		TblOfficer tblOfficer = quickDepartmentUserService.getTblOfficerByUserId(userId);
            	int deptId = 0;
            	if(tblOfficer!=null){
            		deptId = tblOfficer.getTblDepartment().getDeptId();
            	}
	        	TblQueAnsOfficer tblQueAnsOfficer = new TblQueAnsOfficer();
	        	tblQueAnsOfficer.setCreatedBy(abcUtility.getSessionUserId(request));
	        	tblQueAnsOfficer.setIsActive(1);
	        	tblQueAnsOfficer.setTblDepartment(new TblDepartment(deptId));
	        	tblQueAnsOfficer.setTblUserLogin(new TblUserLogin(userId));
	        	tblQueAnsOfficer.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
	        	isSuccess = departmentUserService.addTblQueAnsOfficer(tblQueAnsOfficer);
	        	if(isSuccess){
	        		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_map_officer_success");
	        	}
        	}else{
        		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_already_map_officer");
        	}
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),mapOfficerQuestionAnswerLinkId , mapQAOfficerRemark, 0, sessionBean.getUserId());
        }
        return retVal;
    }
    
    /**
     * used for replace officer for QA module Change Request #22284
     * @author Lipi Shah
     */
    @RequestMapping(value = "/admin/unmapofficerqueans/{userId}/{enc}", method = RequestMethod.GET)
    public String replaceOfficerQueAns(@PathVariable("userId") int officerId,ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	boolean isSuccess = false;
    	String retVal="redirect:/common/admin/managedeptuser"+encryptDecryptUtils.generateRedirect("common/admin/managedeptuser", request);
    	SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
        try {
        		int clientId = abcUtility.getSessionClientId(request);
        		isSuccess = departmentUserService.updateTblQueAnsOfficer(clientId);//unmap current officer
        		if(isSuccess){
        			//map with new user
        			int deptId = 0;
        			TblOfficer tblOfficer = quickDepartmentUserService.getTblOfficerByUserId(officerId);
                	if(tblOfficer!=null){
                		deptId = tblOfficer.getTblDepartment().getDeptId();
                	}
        			TblQueAnsOfficer tblQueAnsOfficer = new TblQueAnsOfficer();
    	        	tblQueAnsOfficer.setCreatedBy(abcUtility.getSessionUserId(request));
    	        	tblQueAnsOfficer.setIsActive(1);
    	        	tblQueAnsOfficer.setTblDepartment(new TblDepartment(deptId));
    	        	tblQueAnsOfficer.setTblUserLogin(new TblUserLogin(officerId));
    	        	tblQueAnsOfficer.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
    	        	isSuccess = departmentUserService.addTblQueAnsOfficer(tblQueAnsOfficer);
        		}
        		if(isSuccess){
	        		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_map_officer_success");
	        	}
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), replaceOfficerQuestionAnswerLinkId, replaceQAOfficerRemark, 0, sessionBean.getUserId());
        }
        return retVal;
    }
    /**
	 * @author Lipi
	 * @used for get user name for QA officer confirm msg Change Request #22284
	 * and check user is already mapped or not
	 */
	@RequestMapping(value = "/ajax/getuserame", method = RequestMethod.POST)
    @ResponseBody
    public String getUserName(@RequestParam("hdUserId") int userId, HttpServletRequest request) {
		String retVal = ""; 
        try {
        	int counter = 0;
        	List<TblQueAnsOfficer> queAnsOfficers =  departmentUserService.getTblQueAnsOfficer(abcUtility.getSessionClientId(request));
        	for(TblQueAnsOfficer officers:queAnsOfficers){//officer is already mapped or not
        		if(officers.getTblUserLogin().getUserId()==userId && officers.getIsActive() == 1){
        			counter++;
        		}
        	}
        	if(counter == 0){
        		retVal = commonService.getUserName(userId);
        	}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return retVal;
    }
	
	 /**
     * @author Hardik Gohil
     * @used for to get User Information and his/her client access list  
     * Project Task #50218
     */
	 @RequestMapping(value = "/admin/manageuserclientaccess/{userId}/{enc}", method = RequestMethod.GET)
	    public String manageUserClientAccess(@PathVariable("userId") int userId,ModelMap modelMap, HttpServletRequest request,OfficerRegistrationDatabean officerRegistrationDatabean) {
	    	String retVal="/common/admin/AssignClientAccess";
	        try {
	        	setDeptUserModelmap(modelMap,request,"",userId,officerRegistrationDatabean);
	        	List<Object[]> activeDomainWithAccessList=  departmentUserService.getClientActiveForAbcUserAccessList(userId);
	         	modelMap.addAttribute("domainList",activeDomainWithAccessList);
	        } 
	        catch (Exception ex) {
	            return exceptionHandlerService.writeLog(ex);
	        }
	        finally{
	        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), userClientAccesslinkId, msgGetUserClientAccess, userId,0);
	        }
	        return retVal;
	    }
	    
	 	/**
	     * @author Hardik Gohil
	     * @used for Add Or Update User Client access   
	     * Project Task #50218
	     */
	    @RequestMapping(value = "/admin/manageuserclientaccess", method = RequestMethod.POST)                       
	    public String manageUserClientAccess(RedirectAttributes redirectAttributes, HttpServletRequest request){ 
	        boolean success = false;
	        String retVal = null;
	        String [] domainArray=null;
	        int userId =0;
	        
	        try{
	        	int sessionUserId = abcUtility.getSessionUserId(request);
	        	userId = StringUtils.hasLength(request.getParameter("hdUserId"))?Integer.parseInt(request.getParameter("hdUserId")):0;
	        	domainArray = request.getParameterValues("chkMultipleDomain");
	        	if(userId != 0){
	        		List<TblUserClientAccess> tblUserClientAccessList = null;
	        		if(domainArray != null && domainArray.length > 0) {
	        			tblUserClientAccessList = new ArrayList<TblUserClientAccess>();
	        			for (String domainId : domainArray) {
	            			TblUserClientAccess tblUserClientAccess = new TblUserClientAccess();
	            			tblUserClientAccess.setCreatedBy(sessionUserId);
	            			tblUserClientAccess.setTblClient(new TblClient(Integer.parseInt(domainId)));
	            			tblUserClientAccess.setTblUserLogin(new TblUserLogin(userId));
	            			tblUserClientAccess.setCStatus(1);
	            			tblUserClientAccessList.add(tblUserClientAccess);
	        			}	
	        		}
	        		success = departmentUserService.assignClientAccessRightsToUser(userId, sessionUserId, tblUserClientAccessList);
	        	}
	        	retVal= success ? DEPT_USER_GRID_URL : "common/admin/manageuserclientaccess/"+userId;
	        }
	        catch(Exception ex){
	        	return exceptionHandlerService.writeLog(ex);
	        }
	        finally{
	        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), userClientAccesslinkId,(domainArray != null && domainArray.length > 0) ? msgPostUserClientAccess : msgPostUnmapUserClientAccess,userId,0);
	        }
	        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? (domainArray != null && domainArray.length > 0) ? "redirect_modified_user_client_access" : "redirect_modified_unmap_user_client_access" : CommonKeywords.ERROR_MSG_KEY.toString());
	        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
	    }
	    
	    /**
	     * @author nitin.w
	     * @param modelMap
	     * @param userId
	     * @param request
	     * @return
	     */
	    @RequestMapping(value = "/admin/detachdcofficer/{userId}/{enc}", method = RequestMethod.GET)
	    public String detachDcOfficer(ModelMap modelMap,@PathVariable("userId") int userId,HttpServletRequest request) {
	    	try {
	        	ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	        	//for sign generation code
	        	if(clientBean.getIsPkiEnabled()==1){
	        		String publicKey=null;
	        		String certIds[] = ((SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString())).getCertId().split(",");
	        		if(certIds!=null && certIds.length!=0){
	        			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
	        		}
	        		modelMap.addAttribute("publicKeyForSign", publicKey);
	    		}
	        	
	        	List<Object[]> unmapCertDetails= departmentUserService.getDetachCertDetails(userId, clientBean.getClientId());
	        	if(unmapCertDetails!=null)
	        	{
	        		/*&& unmapCertDetails.size() != 3*/
	        		if(!unmapCertDetails.isEmpty()){
	        		for (int i = 0; i < unmapCertDetails.size(); i++) {
	        			Map<String,Object> certDetail= new HashMap<String, Object>();
	            		Object[] object = unmapCertDetails.get(i);
	            		certDetail.put("fullName", object[0]);
	            		certDetail.put("deptName", object[1]);
	            		certDetail.put("desiName", object[2]);
	            		certDetail.put("loginId", object[3]);
	            		certDetail.put("keyUsage", object[14]);
	            		certDetail.put("subject", object[5]);
	            		certDetail.put("issuer", object[6]);
	            		certDetail.put("publicKey", object[7]);
	            		certDetail.put("serialNumber", object[8]);
	            		certDetail.put("validFrom", object[9]);
	            		certDetail.put("validTo", object[10]);
	            		certDetail.put("certId",object[11]);
	            		certDetail.put("userCertId",object[12]);
	            		certDetail.put("isDual",object[13]);
	            		if((Integer)object[14] == 1){
	            			modelMap.addAttribute("SigningCerti", certDetail);
	            		}else if((Integer)object[14] == 2){
	            			modelMap.addAttribute("EncryptionCerti", certDetail);
	            		}
	    			}
	        	}/*else if(!unmapCertDetails.isEmpty() && unmapCertDetails.size() == 3){
	        		List<HashMap<String,Object>> data=new ArrayList<HashMap<String,Object>>();
	        		for (int i = 0; i < unmapCertDetails.size(); i++) {
	        			Map<String,Object> certDetail= new HashMap<String, Object>();
	        			Object[] object = unmapCertDetails.get(i);
	        			certDetail.put("fullName", object[0]);
	            		certDetail.put("deptName", object[1]);
	            		certDetail.put("desiName", object[2]);
	            		certDetail.put("loginId", object[3]);
	            		certDetail.put("keyUsage", object[14]);
	            		certDetail.put("subject", object[5]);
	            		certDetail.put("issuer", object[6]);
	            		certDetail.put("publicKey", object[7]);
	            		certDetail.put("serialNumber", object[8]);
	            		certDetail.put("validFrom", object[9]);
	            		certDetail.put("validTo", object[10]);
	            		certDetail.put("certId",object[11]);
	            		certDetail.put("userCertId",object[12]);
	            		certDetail.put("isDual",object[13]);
	            		data.add((HashMap<String, Object>) certDetail);
	            		
	            		modelMap.addAttribute("SigningCerti", certDetail);
	            		
	        		}
	        		modelMap.addAttribute("data", data);
	        	}*/
	        		
	        	}
	        	modelMap.addAttribute("clientId", clientBean.getClientId());
	        	if(unmapCertDetails != null){
	        		modelMap.addAttribute("rowSize", unmapCertDetails.size());// for count how many rows return	
	        	}
	        	modelMap.addAttribute("clientName", clientService.getClientNameByClientId(clientBean.getClientId()));
	        	modelMap.put("EmailId",commonService.getEmailByUserId(userId));
	        } catch (Exception e) {
	            return exceptionHandlerService.writeLog(e);
	        }
	        finally{
	        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),detachDCLinkId, getUnMapDCUserRemark, 0,userId);
	        }
	        return "/common/admin/DetachDCOfficer";
	    }
	    
	    
	    /**
	     * @author nitin.w
	     * @param redirectAttributes
	     * @param response
	     * @param request
	     * @return
	     */
	    @RequestMapping(value = "/admin/adddetachdcofficer", method = RequestMethod.POST)                       
	    public String addDetachDC(RedirectAttributes redirectAttributes, HttpServletResponse response, HttpServletRequest request){
	    	
	    	   boolean success = false;
	           String retVal = null;
	           String userId = null;
	           ClientBean clientBean=null;
	           String remark = null;
	           String msg = null;
	        try{
	        	
	        	clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	        	String encryCertId = request.getParameter("hdEncryCertId");
	        	String encryUserCertId = request.getParameter("hdEncryUserCertId");
	        	String encryKeyUsage = request.getParameter("hdEncryKeyUsage");
	        	String encryIsDual = request.getParameter("hdEncryIsDual");
	        	
	        	String userCertIds[] = null;
	        	String signingCertId = request.getParameter("hdSigningCertId");
	        	String signingUserCertId = request.getParameter("hdSigningUserCertId");
	        	String signingKeyUsage = request.getParameter("hdSigningKeyUsage");
	        	String signingIsDual = request.getParameter("hdSigningIsDual");
	        	userId = request.getParameter("hdUserId");
	        	remark = "Detach DC Remerk";
	        	String rowSize = request.getParameter("hdRowSize");
	        	String loginId = request.getParameter("hdLoginId");
	                String encCertiId = request.getParameter("certIsSelect_enc");
	        	String signCertiId = request.getParameter("certIsSelect_sign");
	        	
	        	int createdBy = abcUtility.getSessionUserId(request);
	        	
	        	List<TblUserCertificate> tblUserCertificates = null;
	        	if(StringUtils.hasLength(loginId) /*&& StringUtils.hasLength(signingUserCertId)*/  && StringUtils.hasLength(remark) && StringUtils.hasLength(userId) /*&& StringUtils.hasLength(signingCertId)*/){
	        		//List<TblCertUnMapHistory> tblCertUnMapHistorys = new ArrayList<TblCertUnMapHistory>();
	        		List<TblDCDetachHistory> tblDetachCertHistorys = new ArrayList<TblDCDetachHistory>();
	        		tblUserCertificates = new ArrayList<TblUserCertificate>();
	        		if ( signCertiId != null  &&  !signCertiId.isEmpty()) {
	        				TblDCDetachHistory tblDetachCertHistory = new TblDCDetachHistory();
	        				tblDetachCertHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(userId)));
	        				tblDetachCertHistory.setTblCertificate(new TblCertificate(Integer.parseInt(signingCertId)));
	        				tblDetachCertHistory.setTblClient(new TblClient(clientBean.getClientId()));
	        				
	        				int clientId = abcUtility.getSessionClientId(request);
	        				int userTypeId = commonService.getUserTypeIdFromUserId(Integer.parseInt(userId), clientId);
	        				int companyId=Integer.parseInt(commonService.getCompanyIdByUserId(Integer.parseInt(userId)).toString());
	        				String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();
	        				
	        				tblDetachCertHistory.setCompanyId(userTypeId==2?companyId:0);
	        				tblDetachCertHistory.setIsDualCert(Integer.parseInt(signingIsDual));
	        				tblDetachCertHistory.setKeyUsage(Integer.parseInt(signingKeyUsage));
	        				tblDetachCertHistory.setIpAddress(ipAddress);
	        				tblDetachCertHistory.setCreatedOn(commonService.getServerDateTime());
	        				tblDetachCertHistory.setCreatedBy(createdBy);
	                        
	                        TblUserCertificate tblUserCertificate = new TblUserCertificate();
	                        tblUserCertificate.setUserCertId(Integer.parseInt(signingUserCertId));
	                        tblUserCertificates.add(tblUserCertificate);
	                        tblDetachCertHistorys.add(tblDetachCertHistory);
	                        
	                      }
	   	                if (encCertiId != null && !encCertiId.isEmpty()) {
	   	                	TblDCDetachHistory tblDetachCertHistory = new TblDCDetachHistory();
	   	     				tblDetachCertHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(userId)));
	   	     				tblDetachCertHistory.setTblCertificate(new TblCertificate(Integer.parseInt(encryCertId)));
	   	     				tblDetachCertHistory.setTblClient(new TblClient(clientBean.getClientId()));
	   	     				
	   	     				int clientId = abcUtility.getSessionClientId(request);
	   	     				int userTypeId = commonService.getUserTypeIdFromUserId(Integer.parseInt(userId), clientId);
	   	     				int companyId=Integer.parseInt(commonService.getCompanyIdByUserId(Integer.parseInt(userId)).toString());
	   	     				String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();
	   	     				
	   	     				tblDetachCertHistory.setCompanyId(userTypeId==2?companyId:0);
	   	     				tblDetachCertHistory.setIsDualCert(Integer.parseInt(encryIsDual));
	   	     				tblDetachCertHistory.setKeyUsage(Integer.parseInt(encryKeyUsage));
	   	     				tblDetachCertHistory.setIpAddress(ipAddress);
	   	     				tblDetachCertHistory.setCreatedOn(commonService.getServerDateTime());
	   	     				tblDetachCertHistory.setCreatedBy(createdBy);
	   	                     
	   	                     TblUserCertificate tblUserCertificate = new TblUserCertificate();
	   	                     tblUserCertificate.setUserCertId(Integer.parseInt(encryUserCertId));
	   	                     tblUserCertificates.add(tblUserCertificate);
	   	                     tblDetachCertHistorys.add(tblDetachCertHistory);
	                    }
	   	                success = manageBidderService.addDetachCertHistory(tblDetachCertHistorys,tblUserCertificates);
	   	     	}
	   	     	if(success){
	   	     		retVal = DEPT_USER_GRID_URL;
	   	     	}
	   	     	else{
	   	     		retVal = "common/admin/detachdcofficer/"+userId;
	   	     	}
	   	     	if(signCertiId != null  &&  !signCertiId.isEmpty() && encCertiId != null && !encCertiId.isEmpty()){
	   	     		msg = "reiderct_success_sinenc_detached_certificate";
	   	     	}
	   	     	else if (signCertiId != null  &&  !signCertiId.isEmpty()){
	   	     		msg = "reiderct_success_sin_detached_certificate";
	   	     	}
	   	     	else if (encCertiId != null && !encCertiId.isEmpty()){
	   	     		msg = "reiderct_success_encr_detached_certificate";
	   	     	}
	        	
	        }
	        catch(Exception ex){
	        	retVal = "common/admin/detachdcofficer/"+userId;
	        	exceptionHandlerService.writeLog(ex);
	        }
	        finally{
	        	if(clientBean != null)
	        	{
	   	        	if(clientBean.getIsPkiEnabled()==1){
	   	        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), detachDCLinkId, postUnMapDCUserRemark, 0,userId!=null && !userId.equals("")? Integer.parseInt(userId):0,remark,request.getParameter("skpSignText"));
	   	        	}else{
	   	        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), detachDCLinkId, postUnMapDCUserRemark, 0,userId!=null && !userId.equals("")? Integer.parseInt(userId):0,remark);
	   	        	}
	        	}
	        }
	        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? msg : CommonKeywords.ERROR_MSG_KEY.toString());
	        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
	    }
	    
	    @RequestMapping(value = "/ajax/getremarks", method = RequestMethod.POST)
	    @ResponseBody
	    public String getUserEnableDisableRemarks(@RequestParam("hdUserId") String userId, HttpServletRequest request) {
			String remarks = ""; 
	        try {
	        	remarks =  departmentUserService.getEnableDisableRemarks(Integer.parseInt(userId));
	        } catch (Exception e) {
	            exceptionHandlerService.writeLog(e);
	        }
	        return remarks;
	    }
	    	   
}
