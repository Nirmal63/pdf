package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblOverRuledReportDao;
import com.etl.eproc.etender.model.TblOverRuledReport;

/**
 *
 * @author taher
 */

@Repository @Transactional    /*StackUpdate*/
public class TblOverRuledReportImpl extends AbcAbstractClass<TblOverRuledReport> implements TblOverRuledReportDao {

    @Override
    public void addTblOverRuledReport(TblOverRuledReport tblOverRuledReport){
        super.addEntity(tblOverRuledReport);
    }

    @Override
    public void deleteTblOverRuledReport(TblOverRuledReport tblOverRuledReport) {
        super.deleteEntity(tblOverRuledReport);
    }

    @Override
    public void updateTblOverRuledReport(TblOverRuledReport tblOverRuledReport) {
        super.updateEntity(tblOverRuledReport);
    }

    @Override
    public List<TblOverRuledReport> getAllTblOverRuledReport() {
        return super.getAllEntity();
    }

    @Override
    public List<TblOverRuledReport> findTblOverRuledReport(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblOverRuledReportCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblOverRuledReport> findByCountTblOverRuledReport(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblOverRuledReport(List<TblOverRuledReport> tblOverRuledReports){
        super.updateAll(tblOverRuledReports);
    }

	@Override
	public void saveOrUpdateTblOverRuledReport(TblOverRuledReport overRuledReport) {
		super.saveOrUpdateEntity(overRuledReport);
	}
}
