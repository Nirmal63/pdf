/**
 *
 * @author hiral
 */
package com.etl.eproc.advertise.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.core.style.ToStringCreator;

@Entity
@Table(name="Tbl_AdvertiseDetail",schema="appadvertise")
public class TblAdvertiseDetail  implements java.io.Serializable {

        private   Date advertiseDate;
        private   int advertiseDetailId;
        private   String advertiseNo;
        private   int createdBy;
        private   Date createdOn;
        private   String paperName;
        private   TblAdvertise tblAdvertise;


        @Temporal(TemporalType.DATE)
        @Column(name="advertiseDate",nullable=false)
        public Date getAdvertiseDate() {
            return this.advertiseDate;
        }

        public void setAdvertiseDate(Date advertiseDate) {
            this.advertiseDate = advertiseDate;
        }
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name="advertiseDetailId",unique=true,nullable=false)
        public int getAdvertiseDetailId() {
            return this.advertiseDetailId;
        }

        public void setAdvertiseDetailId(int advertiseDetailId) {
            this.advertiseDetailId = advertiseDetailId;
        }
        public TblAdvertiseDetail(int advertiseDetailId){
            this.advertiseDetailId = advertiseDetailId;
        }
        @Column(name="advertiseNo",nullable=false, length=200)
        public String getAdvertiseNo() {
            return this.advertiseNo;
        }

        public void setAdvertiseNo(String advertiseNo) {
            this.advertiseNo = advertiseNo;
        }
        @Column(name="createdBy",nullable=false)
        public int getCreatedBy() {
            return this.createdBy;
        }

        public void setCreatedBy(int createdBy) {
            this.createdBy = createdBy;
        }
        @Temporal(TemporalType.TIMESTAMP)
        @Column(name="createdOn",nullable=false,updatable=false,insertable=false)
        public Date getCreatedOn() {
            return this.createdOn;
        }

        public void setCreatedOn(Date createdOn) {
            this.createdOn = createdOn;
        }
        @Column(name="paperName",nullable=false, length=200)
        public String getPaperName() {
            return this.paperName;
        }

        public void setPaperName(String paperName) {
            this.paperName = paperName;
        }
        @ManyToOne(fetch=FetchType.LAZY)
        @JoinColumn(name="advertiseid")
        public TblAdvertise getTblAdvertise() {
            return this.tblAdvertise;
        }

        public void setTblAdvertise(TblAdvertise tblAdvertise) {
            this.tblAdvertise = tblAdvertise;
        }
        public TblAdvertiseDetail(){
        }
        @Override
	public String toString() {
		return new ToStringCreator(this)
.append("advertiseDate", this.getAdvertiseDate())
.append("advertiseDetailId", this.getAdvertiseDetailId())
.append("advertiseNo", this.getAdvertiseNo())
.append("createdBy", this.getCreatedBy())
.append("createdOn", this.getCreatedOn())
.append("paperName", this.getPaperName())

		.toString();

	}
}
