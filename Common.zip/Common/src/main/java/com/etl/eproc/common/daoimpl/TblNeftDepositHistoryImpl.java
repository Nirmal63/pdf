package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblNeftDepositHistoryDao;
import com.etl.eproc.common.model.TblNeftDepositHistory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblNeftDepositHistoryImpl extends AbcAbstractClass<TblNeftDepositHistory> implements TblNeftDepositHistoryDao {

    @Override
    public void addTblNeftDepositHistory(TblNeftDepositHistory tblNeftDepositHistory){
        super.addEntity(tblNeftDepositHistory);
    }

    @Override
    public void deleteTblNeftDepositHistory(TblNeftDepositHistory tblNeftDepositHistory) {
        super.deleteEntity(tblNeftDepositHistory);
    }

    @Override
    public void updateTblNeftDepositHistory(TblNeftDepositHistory tblNeftDepositHistory) {
        super.updateEntity(tblNeftDepositHistory);
    }

    @Override
    public List<TblNeftDepositHistory> getAllTblNeftDepositHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNeftDepositHistory> findTblNeftDepositHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNeftDepositHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNeftDepositHistory> findByCountTblNeftDepositHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNeftDepositHistory(List<TblNeftDepositHistory> tblNeftDepositHistorys){
        super.updateAll(tblNeftDepositHistorys);
    }
}

