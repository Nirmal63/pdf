package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClient;
import java.util.List;

public interface TblClientDao  {

    public void addTblClient(TblClient tblClient);

    public void deleteTblClient(TblClient tblClient);

    public void updateTblClient(TblClient tblClient);

    public List<TblClient> getAllTblClient();

    public List<TblClient> findTblClient(Object... values) throws Exception;

    public List<TblClient> findByCountTblClient(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientCount();

    public void saveUpdateAllTblClient(List<TblClient> tblClients);

	public void saveOrUpdateTblClient(TblClient tblClient);
}