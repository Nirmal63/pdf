package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblIssuer;
import java.util.List;

public interface TblIssuerDao  {

    public void addTblIssuer(TblIssuer tblIssuer);

    public void deleteTblIssuer(TblIssuer tblIssuer);

    public void updateTblIssuer(TblIssuer tblIssuer);

    public List<TblIssuer> getAllTblIssuer();

    public List<TblIssuer> findTblIssuer(Object... values) throws Exception;

    public List<TblIssuer> findByCountTblIssuer(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblIssuerCount();

    public void saveUpdateAllTblIssuer(List<TblIssuer> tblIssuers);
}