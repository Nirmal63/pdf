package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDCDetachHistory;
import java.util.List;

public interface TblDCDetachHistoryDao  {

    public void addTblDCDetachHistory(TblDCDetachHistory tblDCDetachHistory);

    public void deleteTblDCDetachHistory(TblDCDetachHistory tblDCDetachHistory);

    public void updateTblDCDetachHistory(TblDCDetachHistory tblDCDetachHistory);

    public List<TblDCDetachHistory> getAllTblDCDetachHistory();

    public List<TblDCDetachHistory> findTblDCDetachHistory(Object... values) throws Exception;

    public List<TblDCDetachHistory> findByCountTblDCDetachHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDCDetachHistoryCount();

    public void saveUpdateAllTblDCDetachHistory(List<TblDCDetachHistory> tblDCDetachHistorys);
}