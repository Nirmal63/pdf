package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblMapAuthUser;
import com.etl.eproc.common.daointerface.TblMapAuthUserDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;


@Repository @Transactional    /*StackUpdate*/
public class TblMapAuthUserImpl extends AbcAbstractClass<TblMapAuthUser> implements TblMapAuthUserDao {

    @Override
    public void addTblMapAuthUser(TblMapAuthUser tblMapAuthUser){
        super.addEntity(tblMapAuthUser);
    }

    @Override
    public void deleteTblMapAuthUser(TblMapAuthUser tblMapAuthUser) {
        super.deleteEntity(tblMapAuthUser);
    }

    @Override
    public void updateTblMapAuthUser(TblMapAuthUser tblMapAuthUser) {
        super.updateEntity(tblMapAuthUser);
    }

    @Override
    public List<TblMapAuthUser> getAllTblMapAuthUser() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMapAuthUser> findTblMapAuthUser(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMapAuthUserCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMapAuthUser> findByCountTblMapAuthUser(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMapAuthUser(List<TblMapAuthUser> tblMapAuthUsers){
        super.updateAll(tblMapAuthUsers);
    }
}
