package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblEventPayment;
import java.util.List;

public interface TblEventPaymentDao  {

    public void addTblEventPayment(TblEventPayment tblEventPayment);

    public void deleteTblEventPayment(TblEventPayment tblEventPayment);

    public void updateTblEventPayment(TblEventPayment tblEventPayment);

    public List<TblEventPayment> getAllTblEventPayment();

    public List<TblEventPayment> findTblEventPayment(Object... values) throws Exception;

    public List<TblEventPayment> findByCountTblEventPayment(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEventPaymentCount();

    public void saveUpdateAllTblEventPayment(List<TblEventPayment> tblEventPayments);
}