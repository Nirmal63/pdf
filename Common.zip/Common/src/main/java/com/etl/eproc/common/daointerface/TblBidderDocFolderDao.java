package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBidderDocFolder;

public interface TblBidderDocFolderDao  {

    public void addTblBidderDocFolder(TblBidderDocFolder tblBidderDocFolder);

    public void deleteTblBidderDocFolder(TblBidderDocFolder tblBidderDocFolder);

    public void updateTblBidderDocFolder(TblBidderDocFolder tblBidderDocFolder);

    public List<TblBidderDocFolder> getAllTblBidderDocFolder();

    public List<TblBidderDocFolder> findTblBidderDocFolder(Object... values) throws Exception;

    public List<TblBidderDocFolder> findByCountTblBidderDocFolder(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidderDocFolderCount();

    public void saveUpdateAllTblBidderDocFolder(List<TblBidderDocFolder> tblBidderDocFolders);

	public void saveOrUpdateTblBidderDocFolder(TblBidderDocFolder tblBidderDocFolder);
}