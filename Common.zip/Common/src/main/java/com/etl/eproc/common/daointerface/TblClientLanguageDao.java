package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientLanguage;
import java.util.List;

public interface TblClientLanguageDao  {

    public void addTblClientLanguage(TblClientLanguage tblClientLanguage);

    public void deleteTblClientLanguage(TblClientLanguage tblClientLanguage);

    public void updateTblClientLanguage(TblClientLanguage tblClientLanguage);

    public List<TblClientLanguage> getAllTblClientLanguage();

    public List<TblClientLanguage> findTblClientLanguage(Object... values) throws Exception;

    public List<TblClientLanguage> findByCountTblClientLanguage(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientLanguageCount();

    public void saveUpdateAllTblClientLanguage(List<TblClientLanguage> tblClientLanguages);
}