package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblBidderDocumentDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblBidderDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBidderDocumentImpl extends AbcAbstractClass<TblBidderDocument> implements TblBidderDocumentDao {

    @Override
    public void addTblBidderDocument(TblBidderDocument tblBidderDocument){
        super.addEntity(tblBidderDocument);
    }

    @Override
    public void deleteTblBidderDocument(TblBidderDocument tblBidderDocument) {
        super.deleteEntity(tblBidderDocument);
    }

    @Override
    public void updateTblBidderDocument(TblBidderDocument tblBidderDocument) {
        super.updateEntity(tblBidderDocument);
    }

    @Override
    public List<TblBidderDocument> getAllTblBidderDocument() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBidderDocument> findTblBidderDocument(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBidderDocumentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBidderDocument> findByCountTblBidderDocument(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBidderDocument(List<TblBidderDocument> tblBidderDocuments){
        super.updateAll(tblBidderDocuments);
    }

	@Override
	public void saveOrUpdateTblBidderDocument(TblBidderDocument tblBidderDocument) {
		super.saveOrUpdateEntity(tblBidderDocument);
	}
}
