package com.etl.eproc.common.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.CheckSumRequestBean;
import com.CheckSumResponseBean;
import com.etl.eproc.common.daointerface.TblPaymentRequestDao;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientPGBankMapping;
import com.etl.eproc.common.model.TblClientPGConf;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblOnlinePayment;
import com.etl.eproc.common.model.TblPayment;
import com.etl.eproc.common.model.TblPaymentRequest;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.TpslService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.eauction.model.TblEmdBalance;
import com.tp.pg.util.TransactionRequestBean;
import com.tp.pg.util.TransactionResponseBean;

/**
 * @author manish 
 * Sep 7, 2013
 */
@Controller
@RequestMapping("/common")
public class TpslController {
	private static final int TAB_DOC_FEES = 3;
	private static final int TAB_EMD = 4;
	private static final int TAB_ONLINE_PAYMENT = 1;
	 private static final int TAB_RESTEVENTMONEY = 18;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
	@Autowired
	private AuditTrailService auditTrailService;
	@Autowired
	private TpslService tpslService;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private ManageBidderService manageBidderService;
	@Autowired
	private CommonService commonService;
	@Autowired
	private ClientService clientService;
	@Autowired
	private LoginService loginService;
	@Autowired
	private MailContentUtillity mailContentUtillity;
	@Autowired
	private TblPaymentRequestDao tblPaymentRequestDao;
	
	@Value("#{linkProperties['bidder_registration_charges_online_payment_pg']?:932}")
	private int lnkRegiChargesThroughPG;
	@Value("#{tenderlinkProperties['docfees_payment_through_pg']?:414}")
	private int lnkDocfeePaymentPG;
	@Value("#{tenderlinkProperties['emd_payment_through_pg']?:417}")
	private int lnkEmdPaymentThroughPG;
    @Value("#{tenderlinkProperties['restOfEventMoney']?:3321}") 
    private int lnkTenderRestOfEventMoney;
	@Value("#{auclinkProperties['emd_payment_through_pg']?:925}")
	private int lnkAuctionEmdPaymentPG;
	@Value("#{paymentConfigProperties['payment_doc_path']}")
	private String filePath;
	@Value("#{adminAuditTrailProperties['get_manage_tpsl_conf']}")
	private String getManageTpslConf;
	@Value("#{adminAuditTrailProperties['get_create_tpsl_conf']}")
	private String getCreateTpslConf;
	@Value("#{adminAuditTrailProperties['get_save_tpsl_conf']}")
	private String getSaveTpslConf;
	@Value("#{adminAuditTrailProperties['get_edit_tpsl_conf']}")
	private String getEditTpslConf;
	@Value("#{etenderAuditTrailProperties['getPaymentDataDashboard']}")
	private String getPaymentDataDashboard;
	@Value("#{etenderAuditTrailProperties['postTpslPaymentDetail']}")
	private String postTpslPaymentDetail;
	@Value("#{paymentConfigProperties['payment_tpsl_url']}")
	private String tpslUrl;
	@Value("#{linkProperties['manage_client_payment_configuration']?:428}")
	private int paymentConfigurationLinkId;
	@Value("#{linkProperties['manage_client_configure_docfees']?:429}")
	private int configureDocFeesLinkId;
	@Value("#{linkProperties['manage_client_configure_emd']?:430}")
	private int configureEmdLinkId;
	@Value("#{auclinkProperties['security_payment_through_pg']?:4433}")
    private int lnkAuctionSecurityPaymentPG;
	@Value("#{linkProperties['manage_client_edit_docfees_configuration']?:431}")
	private int editDocFeesConfLinkId;
	@Value("#{linkProperties['manage_client_edit_emd_configuration']?:432}")
	private int editEmdConfLinkId;
	@Value("#{linkProperties['manage_client_configure_registration_charges']?:688}")
	private int configureRegChargesLinkId;
	@Value("#{linkProperties['manage_client_edit_registration_charges']?:689}")
	private int editRegChargesLinkId;
    @Value("#{projectProperties['is_cgvvn_client']?:2}")   
    private boolean isCgvvnClient;
	@Value("#{linkProperties['manage_client_configure_eventwiseReg']?:918}")
	private int configureEventRegLinkId;
	@Value("#{linkProperties['edit_client_configure_eventwiseReg']?:919}")
	private int editEventRegLinkId;
    @Value("#{auclinkProperties['eventReg_payment_through_pg']?:940}")
    private int lnkAuctionEventRegPaymentPG;
    @Value("#{tenderlinkProperties['eventReg_payment_through_pg']?:937}")
    private int lnkTenderEventPaymentPG;
	@Value("#{linkProperties['manage_client_configure_restaucmoney']?:2296}")
	private int configureRestAucMoneyLinkId;
	@Value("#{linkProperties['edit_client_configure_restaucmoney']?:2297}")
	private int editRestAucMoneyLinkId;
	@Value("#{linkProperties['manage_client_configure_restSecFees']?:4389}")
	private int configureRestSecFeesPaymentPG;
	@Value("#{linkProperties['edit_client_configure_restSecFees']?:4390}")
	private int editRestSecFeesPaymentPG;
	@Value("#{paymentConfigProperties['LOCATORURL']}")
	private String locatorURL;
    @Value("#{paymentConfigProperties['ENCRYPTIONKEY']}")
    private String encKey;
    @Value("#{paymentConfigProperties['ENCRYPTIONIV']}")
    private String encValue;
    @Value("#{paymentConfigProperties['transaction_date']}")
    private String transaction_date;
	
	
	private static final String CLIENT_ID = "clientId";
	private static final String DEPT_ID = "deptId";
	private static final String PAYMENT_FOR = "paymentFor";
	private static final int TAB_REG_PAYMENT = 14;
	  private static final int TAB_PARTICIPATION_FEES = 17;
	  private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";

	/**
	 * @author manish Used to redirect on add pg screen
	 * @param clientId
	 * @param paymentFor
	 * @param modelMap
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/pgconfig/{clientId}/{deptId}/{paymentFor}/{enc}", method = RequestMethod.GET)
	public String tpslConfiguration(@PathVariable(CLIENT_ID) int clientId,@PathVariable(DEPT_ID) int deptId,@PathVariable(PAYMENT_FOR) int paymentFor, ModelMap modelMap,
			HttpServletRequest request) {
		int linkId = 0;
		try {
			String url=request.getRequestURL().toString();
			modelMap.put("deptName",clientService.getDepartmentById(deptId).getDeptName());
			String domainPort=url.split("/")[2];
			URL requestUrl=new URL(url);
			if((requestUrl.getPort() != 80) && (requestUrl.getPort() != 443) && (requestUrl.getPort() != -1)){
				url="http://"+clientService.getClientField(clientId,"domainName")+":"+domainPort.split(":")[1]+request.getContextPath()+"/";
			}else{
				url="https://"+clientService.getClientField(clientId,"domainName")+request.getContextPath()+"/";
			}
			TblClientPGBankMapping tblClientPGBankMapping=clientService.getTblClientPGBankMapping(clientId,1);
			int pgId=tblClientPGBankMapping!=null?tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId():0;
			modelMap.put("pgId",pgId);
			if(pgId==1 || pgId==12){
				if (paymentFor == 3) {
					modelMap.put("pRequestUrl",url+"common/submitRegistrationPaymentDetail");
					modelMap.put("pResponseUrl",url+"common/successRegistrationPayment");	
				}else{
					modelMap.put("pRequestUrl",url+"common/bidder/makePayment");
					modelMap.put("pResponseUrl",url+"common/successPayment");	
				}
			}else if(pgId==2){
				if (paymentFor == 3) {
					modelMap.put("pRequestUrl",url+"common/bidderonlinepayment");
					modelMap.put("pResponseUrl",url+"common/successRegCCAvenuePayment");
				}else{
					modelMap.put("pRequestUrl",url+"common/bidder/makePayment");
					modelMap.put("pResponseUrl",url+"common/successCCAvenuePayment/"+deptId+"/"+paymentFor);
				}
			}else if(pgId==3){
				if (paymentFor == 3) {
					modelMap.put("pRequestUrl",url+"common/bidderonlinepayment");
					modelMap.put("pResponseUrl",url+"common/successRegAxisPayment");
				}else{
					modelMap.put("pRequestUrl",url+"common/bidder/makePayment");
					modelMap.put("pResponseUrl",url+"common/successAxisPayment/"+deptId+"/"+paymentFor);
				}
			}else if(pgId==5){
				if (paymentFor == 3) {
					modelMap.put("pRequestUrl",url+"common/bidderonlinepayment");
					modelMap.put("pResponseUrl",url+"common/successRegSbiPayment");
				}else{
					modelMap.put("pRequestUrl",url+"common/bidder/makePayment");
					modelMap.put("pResponseUrl",url+"common/successSbiPayment/"+deptId+"/"+paymentFor);
				}
			}else if(pgId==6){
				if (paymentFor == 3) {
					modelMap.put("pRequestUrl",url+"common/bidderonlinepayment");
					modelMap.put("pResponseUrl",url+"common/successRegISGPayGatway");
				}else{
					modelMap.put("pRequestUrl",url+"common/bidder/makePayment");
					modelMap.put("pResponseUrl",url+"common/successISGPayGatway/"+deptId+"/"+paymentFor);
				}
			}else if(pgId==11){
				if (paymentFor == 3) {
					modelMap.put("pRequestUrl","https://api.razorpay.com/v1/checkout/embedded");
					modelMap.put("pResponseUrl",url+"common/successRZPPayment");
				}else{
					modelMap.put("pRequestUrl","https://api.razorpay.com/v1/checkout/embedded");
					modelMap.put("pResponseUrl",url+"common/successRZPPayment/"+deptId+"/"+paymentFor);
				}
			}else if(pgId==13){
					modelMap.put("pRequestUrl","https://uat.billdesk.com/pgidsk/PGIMerchantPayment");
					modelMap.put("pResponseUrl",url+"common/successBillDeskPayment/");
			}
			if(paymentFor==1){
				linkId=configureDocFeesLinkId;					
			}else if (paymentFor == 2) {
				linkId = configureEmdLinkId;
			}else if (paymentFor == 4) {
				linkId = configureRegChargesLinkId;
			}else if (paymentFor == 8) {
				linkId = configureEventRegLinkId;
			}else if (paymentFor == 9) {
				linkId = configureRestAucMoneyLinkId;
			}
			modelMap.put(CLIENT_ID, clientId);
			modelMap.put(PAYMENT_FOR, paymentFor);
			Object[] obj=clientService.getClientFields(clientId,"paymentConfigBy,deptId");
			int paymentConfigBy=Integer.valueOf(obj[0].toString());
			if(paymentConfigBy==2 ){
				modelMap.put("paymentConfigBy",paymentConfigBy);
				modelMap.put("isParentDept", obj[1].toString().equals(deptId));
				if(!obj[1].toString().equals(deptId)){				
					List<Object[]> list=tpslService.getPGDeptListByClientId(clientId,paymentFor);
					modelMap.put("pgDeptList",list!=null && !list.isEmpty() ? abcUtility.convert(list) : null);
				}
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getCreateTpslConf, 0, clientId);
		}
		return "/common/admin/AddEditPGConfiguration";
	}

	/**
	 * @author manish Used to add or edit pg configuration
	 * @param request
	 * @param redirectAttributes
	 * @param clientId
	 * @param paymentFor
	 * @param requestUrl
	 * @param responseUrl
	 * @param merchantId
	 * @param checkSumKey
	 * @param userName
	 * @param password
	 * @return
	 */
	@RequestMapping(value = "/admin/addpgconfig/{clientId}/{deptId}/{paymentFor}", method = RequestMethod.POST)
	public String addPGConfiguration(HttpServletRequest request,
			RedirectAttributes redirectAttributes,
			@PathVariable(CLIENT_ID) int clientId,
			@PathVariable(DEPT_ID) int deptId,
			@PathVariable(PAYMENT_FOR) int paymentFor,
			@RequestParam("txtrqUrl") String requestUrl,
			@RequestParam("txtrsUrl") String responseUrl,
			@RequestParam("txtmerchantId") String merchantId,
			@RequestParam("txtuserName") String userName,
			@RequestParam("txtpassword") String password) {
		String retStr = "common/admin/managepaymentconf/" + clientId+ "/"+TAB_ONLINE_PAYMENT;
		String key = CommonKeywords.SUCCESS_MSG.toString();
		String msg = "redirect_success_create_tpsl_document_fees";
		String fileName = "D_" + clientId + "_"+deptId+".properties";
		boolean isEdit = false;
		int linkId = configureDocFeesLinkId;
		String creditAccNo="";
		String creditAccName="";
		String creditAccIfscCode="";
		try {
			String accessCode=StringUtils.hasLength(request.getParameter("txtaccessCode"))?request.getParameter("txtaccessCode"):"";
			String checkSumKey=StringUtils.hasLength(request.getParameter("txtcheckSumKey"))?request.getParameter("txtcheckSumKey"):"";
			String accountNumber =StringUtils.hasLength(request.getParameter("txtaccountNumber"))?request.getParameter("txtaccountNumber"):"";
			int pgId =Integer.parseInt(StringUtils.hasLength(request.getParameter("hdpgId"))?request.getParameter("hdpgId").toString():"0");
			if(pgId==5){
				creditAccNo =StringUtils.hasLength(request.getParameter("txtCreditAccNo"))?request.getParameter("txtCreditAccNo"):"";
				creditAccName =StringUtils.hasLength(request.getParameter("txtCreditAccName"))?request.getParameter("txtCreditAccName"):"";
				creditAccIfscCode =StringUtils.hasLength(request.getParameter("txtCreditAccIfscCode"))?request.getParameter("txtCreditAccIfscCode"):"";
			}
			String terminalId=StringUtils.hasLength(request.getParameter("txtterminalId"))?request.getParameter("txtterminalId"):"";
			String merchantCategoryCode=StringUtils.hasLength(request.getParameter("txtmerchantCategoryCode"))?request.getParameter("txtmerchantCategoryCode"):"";
			String encryptionKey=StringUtils.hasLength(request.getParameter("txtencryptionKey"))?request.getParameter("txtencryptionKey"):"";
			String secureSecret=StringUtils.hasLength(request.getParameter("txtsecureSecret"))?request.getParameter("txtsecureSecret"):"";
			
			if (StringUtils.hasLength(request.getParameter("hdpgConfId"))) {
				isEdit = true;
			}
			if (paymentFor == 2) {
				linkId = configureEmdLinkId;
				msg = "redirect_success_create_tpsl_emd";
				if (isEdit) {
					linkId = editEmdConfLinkId;
					msg = "redirect_success_update_tpsl_emd";
				}
				fileName = "E_" + clientId + "_"+deptId + ".properties";
			} else if (paymentFor == 3) {
				linkId = configureRegChargesLinkId;
				msg = "redirect_success_create_tpsl_reg_charges";
				if (isEdit) {
					linkId = editRegChargesLinkId;
					msg = "redirect_success_update_tpsl_reg_charges";
				}
				fileName = "R_" + clientId + "_"+deptId+ ".properties";
			} else if (paymentFor == 8) {
				linkId = configureEventRegLinkId;
				msg = "redirect_success_create_eventreg_charges";
				if (isEdit) {
					linkId = editEventRegLinkId;
					msg = "redirect_success_update_eventreg_charges";
				}
				fileName = "ER_" + clientId + "_"+deptId+ ".properties";
			}else if (paymentFor == 9) {
				linkId = configureRestAucMoneyLinkId;
				msg = "redirect_success_create_tpsl_restauc_money";
				if (isEdit) {
					linkId = editRestAucMoneyLinkId;
					msg = "redirect_success_update_tpsl_restauc_money";
				}
				fileName = "ER_" + clientId + "_"+deptId+ ".properties";
			}else if (paymentFor == 11) {
				linkId = configureRestSecFeesPaymentPG;
				msg = "redirect_success_create_tpsl_restsec_fess";
				if (isEdit) {
					linkId = editRestSecFeesPaymentPG;
					msg = "redirect_success_update_tpsl_restsec_fees";
				}
				fileName = "ER_" + clientId + "_"+deptId+ ".properties";
			}else if (isEdit) {
				linkId = editDocFeesConfLinkId;
				msg = "redirect_success_update_tpsl_document_fees";
			}
			if(pgId == 1 || pgId == 12){// If payment gateway is TPSL then File is created. 
				File file = new File(filePath);
				if (!file.exists()) {
					file.mkdirs();
				}
	
				File file2 = new File(filePath + fileName);
				if (file2.exists()) {
					file2.delete();
				}
	
				Properties prop = new Properties();
				prop.setProperty("BillerId", merchantId);
				prop.setProperty("ResponseUrl", responseUrl);
				prop.setProperty("CRN", "INR");
				prop.setProperty("CheckSumKey", checkSumKey);
				prop.store(new FileOutputStream(filePath + fileName), null);
			}
			TblClientPGConf tblClientPGConf = new TblClientPGConf();
			tblClientPGConf.setPaymentFor(paymentFor);
			tblClientPGConf.setRequestUrl(requestUrl);
			tblClientPGConf.setResponseUrl(responseUrl);
			tblClientPGConf.setMerchantId(merchantId);
			tblClientPGConf.setUserName(userName);
			tblClientPGConf.setPassword(password);
			tblClientPGConf.setIsActive(1);
			tblClientPGConf.setFileName(pgId==1 || pgId==12?fileName:"");// If payment gateway is TPSL then File name is store. 
			tblClientPGConf.setTblClient(new TblClient(clientId));
			tblClientPGConf.setTblDepartment(new TblDepartment(deptId));
			if(pgId==5){
				tblClientPGConf.setCreditAccNo(creditAccNo);
				tblClientPGConf.setCreditAccName(creditAccName);
				tblClientPGConf.setCreditAccIfscCode(creditAccIfscCode);
			}else if(pgId==6){
				tblClientPGConf.setTerminalId(terminalId);
				tblClientPGConf.setMerchantCategoryCode(merchantCategoryCode);
				tblClientPGConf.setEncryptionKey(encryptionKey);
				tblClientPGConf.setSecureSecret(secureSecret);
				tblClientPGConf.setAccessCode(accessCode);
			}else if(pgId==11){
				tblClientPGConf.setEncryptionKey(encryptionKey);
				tblClientPGConf.setSecureSecret(secureSecret);
				tblClientPGConf.setCheckSumKey(checkSumKey);
				tblClientPGConf.setAccessCode(accessCode);
				tblClientPGConf.setOtherField(accountNumber);
			}else if(pgId==12){ 
				  tblClientPGConf.setEncryptionKey(encryptionKey);
				  tblClientPGConf.setSecureSecret(secureSecret);
				  tblClientPGConf.setCheckSumKey(checkSumKey);
				  tblClientPGConf.setOtherField(accountNumber);
				  tblClientPGConf.setAccessCode(accessCode); 
			}else{
				tblClientPGConf.setCheckSumKey(checkSumKey);
				tblClientPGConf.setAccessCode(accessCode);
				tblClientPGConf.setOtherField(accountNumber);
			}
			if (isEdit) {
				linkId = editDocFeesConfLinkId;
				tblClientPGConf.setPgConfId(Integer.parseInt(request
						.getParameter("hdpgConfId")));
			}
			
			if (isEdit) {
				/*Hitesh Code For Bug #62486 */
				
				Object[] obj=clientService.getClientFields(clientId,"paymentConfigBy,deptId");
				int paymentConfigBy=Integer.valueOf(obj[0].toString());
				boolean success = false;
				/* paymentConfigBy 1 for Client/Domain wise  */
				if(paymentConfigBy == 1){
					int getTenderClientWiseCount = clientService.getClientWiseTenderCountForPaymentGateway(clientId);
					int getAuctionClientWiseCount = clientService.getClientWiseAuctionCountForPaymentGateway(clientId);
					if(getTenderClientWiseCount > 0 || getAuctionClientWiseCount > 0){
						success = true;
					}
				}
				
				/* paymentConfigBy 2 for Department wise  */
				if(paymentConfigBy == 2){
					int getTenderDepartmentWiseCount = clientService.getDeptWiseTenderCountForPaymentGateway(deptId);
					int getAuctionDepartmentWiseCount = clientService.getDeptWiseAuctionCountForPaymentGateway(deptId);
					if(getTenderDepartmentWiseCount > 0 || getAuctionDepartmentWiseCount > 0){
						success = true;
					}
				}
				
				if(!success){
					tpslService.addTblClientPGConf(tblClientPGConf);
				}else{
					key = CommonKeywords.ERROR_MSG.toString();
					msg = CommonKeywords.ERROR_MSG_KEY.toString();
				}
				
				
			}else{
				tpslService.addTblClientPGConf(tblClientPGConf);
			}
		} catch (Exception e) {
			key = CommonKeywords.ERROR_MSG.toString();
			msg = CommonKeywords.ERROR_MSG_KEY.toString();
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getSaveTpslConf, 0, clientId);
			redirectAttributes.addFlashAttribute(key, msg);
		}
		return "redirect:/" + retStr
				+ encryptDecryptUtils.generateRedirect(retStr, request);
	}

	/**
	 * @author manish Used to get pg data for edit screen
	 * @param clientId
	 * @param paymentFor
	 * @param pgConfId
	 * @param request
	 * @param modelMap
	 * @return
	 */
	/**
	 * @author hitesh.borsania
	 * CR #61848
	 */
	@RequestMapping(value = "/admin/editpgconfig/{clientId}/{deptId}/{paymentFor}/{pgConfId}/{enc}", method = RequestMethod.GET)
	public String editPGConfiguration(@PathVariable(CLIENT_ID) int clientId,@PathVariable(DEPT_ID) int deptId,
			@PathVariable(PAYMENT_FOR) int paymentFor,
			@PathVariable("pgConfId") int pgConfId,
			HttpServletRequest request, ModelMap modelMap) {
		int linkId = editDocFeesConfLinkId;
		try {
			modelMap.put("deptName",clientService.getDepartmentById(deptId).getDeptName());
			if (paymentFor == 2) {
				linkId = editEmdConfLinkId;
			} else if (paymentFor == 3) {
				linkId = editRegChargesLinkId;
			}else if (paymentFor == 8) {
				linkId = editEventRegLinkId;
			}else if (paymentFor == 9) {
				linkId = editRestAucMoneyLinkId; 
			}else if (paymentFor == 11) {
				linkId = editRestSecFeesPaymentPG; 
			}
			modelMap.put(CLIENT_ID, clientId);
			modelMap.put(PAYMENT_FOR, paymentFor);
			modelMap.put("opType", "edit");
			Object[] obj=clientService.getClientFields(clientId,"paymentConfigBy,deptId");
			int paymentConfigBy=Integer.valueOf(obj[0].toString());
			if(paymentConfigBy==2 ){
				modelMap.put("paymentConfigBy",paymentConfigBy);
				modelMap.put("isParentDept", obj[1].toString().equals(deptId));
				List<Object[]> list=tpslService.getPGDeptListByClientId(clientId,paymentFor);
				modelMap.put("pgDeptList",list!=null && !list.isEmpty() ? abcUtility.convert(list) : null);				
			}
			modelMap.put("TblClientPGConf", tpslService.getClientPGConf(pgConfId).get(0));
			TblClientPGBankMapping tblClientPGBankMapping=clientService.getTblClientPGBankMapping(clientId,1);
			modelMap.put("pgId",tblClientPGBankMapping!=null?tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId():0);
			
			/*Hitesh Code For CR #61848 */
			/* paymentConfigBy 1 for Client/Domain wise  */
			boolean paymentGatwayClientwiseAfterEventPublished = false;
			if(paymentConfigBy == 1){
				int getTenderClientWiseCount = clientService.getClientWiseTenderCountForPaymentGateway(clientId);
				int getAuctionClientWiseCount = clientService.getClientWiseAuctionCountForPaymentGateway(clientId);
				if(getTenderClientWiseCount > 0 || getAuctionClientWiseCount > 0){
					paymentGatwayClientwiseAfterEventPublished = true;
				}
			}
			modelMap.put("paymentGatwayClientwiseAfterEventPublished", paymentGatwayClientwiseAfterEventPublished);
			
			/* paymentConfigBy 2 for Department wise  */
			boolean paymentGatwayDepartmentwiseAfterEventPublished = false;
			if(paymentConfigBy == 2){
				int getTenderDepartmentWiseCount = clientService.getDeptWiseTenderCountForPaymentGateway(deptId);
				int getAuctionDepartmentWiseCount = clientService.getDeptWiseAuctionCountForPaymentGateway(deptId);
				if(getTenderDepartmentWiseCount > 0 || getAuctionDepartmentWiseCount > 0){
					paymentGatwayDepartmentwiseAfterEventPublished = true;
				}
			}
			modelMap.put("paymentGatwayDepartmentwiseAfterEventPublished", paymentGatwayDepartmentwiseAfterEventPublished);
			
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(
					request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),
					linkId, getEditTpslConf, 0, 0);
		}
		return "/common/admin/AddEditPGConfiguration";
	}

	/**
	 * @author sharmila
	 * @param paymentId
	 * @param amount
	 * @param httpSession
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/submitPaymentDetail", method = RequestMethod.POST)
	public String submitPaymentDetail(@RequestParam("hdPaymentId") int paymentId, @RequestParam("hdAmount") BigDecimal amount, @RequestParam("hdPayFor") int payFor, HttpSession httpSession, HttpServletRequest request,RedirectAttributes redirectAttributes) {
		String page = tpslUrl;// "https://www.tpsl-india.in/PaymentGateway/TransactionRequest.jsp?msg="; read from property file
		int moduleId=0;
		String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
		int clientId = abcUtility.getSessionClientId(request);
		try {
			String url=request.getRequestURL().toString();
			String domainPort=url.split("/")[2];
			URL requestUrl=new URL(url);
			if((requestUrl.getPort() != 80) && (requestUrl.getPort() != 443) && (requestUrl.getPort() != -1)){
				url="http://"+clientService.getClientField(clientId,"domainName")+":"+domainPort.split(":")[1]+request.getContextPath()+"/";
			}else{
				url="https://"+clientService.getClientField(clientId,"domainName")+request.getContextPath()+"/";
			}
			Date serverDate = commonService.getServerDateTime();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(transaction_date);
			if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
				TblClientPGBankMapping tblClientPGBankMapping=clientService.getTblClientPGBankMapping(clientId,1);
				int pgId=tblClientPGBankMapping!=null?tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId():0;
				TblPayment tblPayment = tpslService.getTblPayment(paymentId);
				TblClientPGConf tblClientPGConf = tpslService.getPGConfiguration(abcUtility.getSessionClientId(request), payFor,tblPayment.getTblDepartment().getDeptId());
				String strMsg = null;
				String resrString = null;
				String reqParams = null;
				if(tblClientPGConf!=null){
					if(pgId == 1){
						CheckSumRequestBean objTranDetails = new CheckSumRequestBean();
						objTranDetails.setStrMerchantTranId(String.valueOf(paymentId));
						objTranDetails.setStrMarketCode(tblClientPGConf.getMerchantId());
						objTranDetails.setStrAccountNo("1");
						objTranDetails.setStrAmt(amount.toString());
						objTranDetails.setStrBankCode("NA");
						objTranDetails.setStrPropertyPath(filePath + tblClientPGConf.getFileName()); // read from property file
						com.TPSLUtil util = new com.TPSLUtil();
						strMsg = util.transactionRequestMessage(objTranDetails);
						reqParams = objTranDetails.toString()+" |Token:"+strMsg;
						page= commonService.getTblPaymentGatewayMaster(tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId()).getUrl();
						page += strMsg;
					}else if(pgId == 12){
						TransactionRequestBean objTransactionRequestBean=new TransactionRequestBean();
		    	    	objTransactionRequestBean.setStrRequestType("T");
		    	    	objTransactionRequestBean.setStrMerchantCode(tblClientPGConf.getMerchantId().trim());
		    	    	objTransactionRequestBean.setMerchantTxnRefNumber(String.valueOf(tblPayment.getPaymentId()));
		    	    	objTransactionRequestBean.setStrAmount(String.valueOf(tblPayment.getAmount().setScale(2, BigDecimal.ROUND_HALF_EVEN)));
			    	    objTransactionRequestBean.setStrCurrencyCode("INR");
			    	    objTransactionRequestBean.setStrReturnURL(tblClientPGConf.getResponseUrl());
		    	    	objTransactionRequestBean.setTxnDate(simpleDateFormat.format(serverDate));
		    	    	objTransactionRequestBean.setWebServiceLocator(locatorURL.toString().trim());
					    objTransactionRequestBean.setKey(tblClientPGConf.getEncryptionKey().trim().getBytes());
					    objTransactionRequestBean.setIv(tblClientPGConf.getSecureSecret().trim().getBytes());
		    	    	objTransactionRequestBean.setStrShoppingCartDetails("FIRST_"+String.valueOf(tblPayment.getAmount().setScale(2, BigDecimal.ROUND_HALF_EVEN))+"_0.0");
		    	    	resrString = objTransactionRequestBean.getTransactionToken();
		    	    	reqParams = objTransactionRequestBean.toString()+" |Token:"+resrString;
		    	    	page = resrString;
					}
            		TblPaymentRequest tblPaymnetReqest = new TblPaymentRequest();
    			   	tblPaymnetReqest.setTblPayment(tblPayment);
    			   	tblPaymnetReqest.setObjectId(tblPayment.getObjectId());
    			   	tblPaymnetReqest.setModuleId(moduleId);
    			   	tblPaymnetReqest.setTblUserLogin(tblPayment.getTblUserLogin());
    			   	tblPaymnetReqest.setReqParam(reqParams);
    			   	tblPaymnetReqest.setCreatedOn(commonService.getServerDateTime());
    			   	tblPaymentRequestDao.addTblPaymentRequest(tblPaymnetReqest);
					moduleId=tblPayment.getTblModule().getModuleId();
					page="redirect:" + page;
				}else{
					redirectAttributes.addFlashAttribute("errorMsg","msg_paymentconf_pg_pending");
					page="common/bidder/payment/"+tblPayment.getObjectId()+"/"+tblPayment.getTblModule().getModuleId()+"/"+tblPayment.getPaymentFor();
					page="redirect:/" + page+ encryptDecryptUtils.generateRedirect(page,request);
				}
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			if(moduleId==3){
				auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),payFor == 1 ? lnkDocfeePaymentPG : payFor==2?lnkEmdPaymentThroughPG:lnkTenderEventPaymentPG,postTpslPaymentDetail, 0, paymentId);
			}else if(moduleId==5){
				auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),payFor == 1 ? lnkDocfeePaymentPG :  payFor==2?lnkAuctionEmdPaymentPG:lnkAuctionEventRegPaymentPG,postTpslPaymentDetail, ipAddress, 0, paymentId);
			}
		}
		return page;
	}
	
	/**
	 * @author dipika
	 * @param paymentId
	 * @param amount
	 * @param httpSession
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/submitRegistrationPaymentDetail", method = RequestMethod.POST)
	public String submitRegistrationPaymentDetail(@RequestParam("hdPaymentId") int paymentId, @RequestParam("hdAmount") BigDecimal amount, @RequestParam("hdPayFor") int payFor, HttpSession httpSession, HttpServletRequest request, RedirectAttributes rea) {
		String page = tpslUrl;// "https://www.tpsl-india.in/PaymentGateway/TransactionRequest.jsp?msg="; read from property file
		int clientId = abcUtility.getSessionClientId(request);
		String resrString = null;
		int moduleId=0;
		try {
			if (httpSession.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
				Date serverDate = commonService.getServerDateTime();
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(transaction_date);
				TblPayment tblPayment = tpslService.getTblPayment(paymentId);
				TblClientPGConf tblClientPGConf = tpslService.getPGConfiguration(
				abcUtility.getSessionClientId(request), payFor,tblPayment.getTblDepartment().getDeptId());
				TblClientPGBankMapping tblClientPGBankMapping=clientService.getTblClientPGBankMapping(clientId,1);
				int pgId=tblClientPGBankMapping!=null?tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId():0;
				String reqParams = null; 
				if (!tpslService.isOnlinePaymentDone(paymentId)) {
					if(pgId == 1){
						CheckSumRequestBean objTranDetails = new CheckSumRequestBean();
						objTranDetails.setStrMerchantTranId(String.valueOf(paymentId));
						objTranDetails.setStrMarketCode(tblClientPGConf.getMerchantId());
						objTranDetails.setStrAccountNo("1");
						objTranDetails.setStrAmt(amount.toString());
						objTranDetails.setStrBankCode("NA");
						objTranDetails.setStrPropertyPath(filePath+ tblClientPGConf.getFileName()); // read from property
						com.TPSLUtil util = new com.TPSLUtil();
						String strMsg = util.transactionRequestMessage(objTranDetails);
						page= commonService.getTblPaymentGatewayMaster(tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId()).getUrl();
						page += strMsg;
						reqParams = objTranDetails.toString()+" |Token:"+strMsg;
					}else if(pgId == 12){
						TransactionRequestBean objTransactionRequestBean=new TransactionRequestBean();
		    	    	objTransactionRequestBean.setStrRequestType("T");
		    	    	objTransactionRequestBean.setStrMerchantCode(tblClientPGConf.getMerchantId().trim());
		    	    	objTransactionRequestBean.setMerchantTxnRefNumber(String.valueOf(tblPayment.getPaymentId()));
		    	    	objTransactionRequestBean.setStrAmount(String.valueOf(tblPayment.getAmount().setScale(2, BigDecimal.ROUND_HALF_EVEN)));
			    	    objTransactionRequestBean.setStrCurrencyCode("INR");
			    	    objTransactionRequestBean.setStrReturnURL(tblClientPGConf.getResponseUrl());
		    	    	objTransactionRequestBean.setTxnDate(simpleDateFormat.format(serverDate));
		    	    	objTransactionRequestBean.setWebServiceLocator(locatorURL.toString().trim());
		    	    	objTransactionRequestBean.setStrShoppingCartDetails("FIRST_"+String.valueOf(tblPayment.getAmount().setScale(2, BigDecimal.ROUND_HALF_EVEN))+"_0.0");
						objTransactionRequestBean.setKey(tblClientPGConf.getEncryptionKey().trim().getBytes());
						objTransactionRequestBean.setIv(tblClientPGConf.getSecureSecret().trim().getBytes());
		    	    	resrString = objTransactionRequestBean.getTransactionToken();
		    	    	reqParams = objTransactionRequestBean.toString()+" |Token:"+resrString;
		    	    	page = resrString;
					}
					TblPaymentRequest tblPaymnetReqest = new TblPaymentRequest();
					tblPaymnetReqest.setTblPayment(tblPayment);
					tblPaymnetReqest.setObjectId(tblPayment.getObjectId());
					tblPaymnetReqest.setModuleId(moduleId);
					tblPaymnetReqest.setTblUserLogin(tblPayment.getTblUserLogin());
					tblPaymnetReqest.setReqParam(reqParams);
					tblPaymnetReqest.setCreatedOn(commonService.getServerDateTime());
					tblPaymentRequestDao.addTblPaymentRequest(tblPaymnetReqest);
					moduleId=tblPayment.getTblModule().getModuleId();
				} else {
					page = "/bidderregcharges";
					rea.addFlashAttribute("errorMsg","redirect_error_payment_done");
				}
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			 auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),lnkRegiChargesThroughPG, "", 0, paymentId);
		}
		return "redirect:" + page;
	}

	/**
	 * @author dipika
	 * @param httpSession
	 * @param request
	 * @param rea
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/successRegistrationPayment", method = RequestMethod.POST)
	public String successRegistrationPayment(HttpSession httpSession,HttpServletRequest request, RedirectAttributes rea) throws IOException {
		String page = "bidderregcharges";
		int paymentId = 0;
		int objectId = 0;
		boolean isPaymentDone = false;
		try {
			if (httpSession.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
				SessionBean sessionBean = (SessionBean) httpSession.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
				if(sessionBean == null){
					sessionBean = (SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
				}
				TblClientPGBankMapping tblClientPGBankMapping=clientService.getTblClientPGBankMapping(abcUtility.getSessionClientId(request),1);
				int pgId=tblClientPGBankMapping!=null?tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId():0;
				int userId = sessionBean.getUserId();
				String msg = "";
				if (StringUtils.hasLength(request.getParameter("msg"))) {
					msg = request.getParameter("msg");
				}
				TblClientPGConf tblClientPGConf = tpslService.getPGConfigurationFromMerchantId(abcUtility.getSessionClientId(request),(String)request.getParameter("tpsl_mrct_cd"));
				TransactionResponseBean transactionResponseBean = new TransactionResponseBean();
				String strCheckSumValue = "";
				int strLength = 0;
				String returnCheckSum = "";
				String tpslRefId = "";
				String paymentDoneResCode = "";
				boolean ispaymentVarificationTpsl = false;
				if(pgId ==1){
					String[] oldStrArr = msg.split("\\|");
					strLength = oldStrArr.length;
					returnCheckSum = oldStrArr[strLength - 1];
					paymentId = StringUtils.hasLength(oldStrArr[1]) ? Integer.parseInt(oldStrArr[1]) : 0;
					tpslRefId = oldStrArr[2]; 
					paymentDoneResCode = oldStrArr[14];
				}else if(pgId == 12){
				transactionResponseBean.setKey(tblClientPGConf.getEncryptionKey().trim().getBytes());// WILL PROVIDED BY TPSL
				transactionResponseBean.setIv(tblClientPGConf.getSecureSecret().trim().getBytes());  // WILL PROVIDED BY TPSL
				transactionResponseBean.setResponsePayload(msg);
				String transactionResponse = transactionResponseBean.getResponsePayload();
				String[] newStrArr = transactionResponse.split("\\|");
				String txn_status = newStrArr[0].split("=")[1];	 
				String clnt_txn_ref = newStrArr[3].split("=")[1];
				String tpsl_txn_id = newStrArr[5].split("=")[1];

					System.out.println(" resrString ResponsePayload : "+(String)request.getParameter("msg"));
					System.out.println(" resrString clnt_txn_ref : "+(String)request.getParameter("clnt_txn_ref"));
					System.out.println(" resrString tpsl_mrct_cd : "+(String)request.getParameter("tpsl_mrct_cd"));
					String tranId=(String)request.getSession().getAttribute("mer_tran_id");
					if(request.getSession().getAttribute("KEY")!=null){
						System.out.println(" resrString ResponsePayload.jsp key: "+(String)request.getSession().getAttribute("KEY")+" tranId :"+tranId);
						System.out.println(" resrString ResponsePayload.jsp iv:"+(String)request.getSession().getAttribute("IV")+" tranId :"+tranId);
					}
					strLength = newStrArr.length;
					returnCheckSum = newStrArr[strLength - 1];
					paymentId = Integer.parseInt(clnt_txn_ref);
					tpslRefId = tpsl_txn_id;
					paymentDoneResCode = txn_status;
				}
				TblPayment tblPayment = tpslService.getTblPayment(paymentId);
				tblClientPGConf = tpslService.getPGConfiguration(abcUtility.getSessionClientId(request),tblPayment.getPaymentFor(),tblPayment.getTblDepartment().getDeptId());
				if(pgId == 12){
					ispaymentVarificationTpsl=tpslService.paymentVarificationTpsl(tblPayment.getPaymentFor(), tblPayment.getPaymentId(), abcUtility.getSessionClientId(request), String.valueOf(tblPayment.getCreatedOn()), tblPayment.getTblDepartment().getDeptId());
				}
				String resCode = null;
				if (strLength > 0) {
					if (tpslService.isOnlinePaymentDone(paymentId)) {
						resCode = "400";							
					}else {
						resCode = paymentDoneResCode;
						if ("0300".equals(resCode)) {
							isPaymentDone = true;
						}
						objectId = tblPayment.getObjectId();
						tblPayment.setCstatus(isPaymentDone ? 1 : 2);
						TblOnlinePayment tblOnlinePayment = new TblOnlinePayment();
						tblOnlinePayment.setMerchantId(tblClientPGConf.getMerchantId());
						tblOnlinePayment.setResponseCode(resCode);
						tblOnlinePayment.setResponseMessage(msg);
						tblOnlinePayment.setTblPayment(tblPayment);
						tblOnlinePayment.setTpslReferenceId(tpslRefId);
						tpslService.addOnlinePaymentDetail(tblOnlinePayment);
						CheckSumResponseBean objResTranDetails = new CheckSumResponseBean();
						objResTranDetails.setStrMSG(msg);
						objResTranDetails.setStrPropertyPath(filePath + "/"+ tblClientPGConf.getFileName());
						com.TPSLUtil util = new com.TPSLUtil();
						strCheckSumValue = util.transactionResponseMessage(objResTranDetails);
					}
				}
				if (StringUtils.hasLength(resCode) && isPaymentDone && (strCheckSumValue.equals(returnCheckSum) || ispaymentVarificationTpsl)) {
					rea.addFlashAttribute("successMsg", "msg_payment_success");
					int isGstRequired = (Integer)clientService.getClientField(abcUtility.getSessionClientId(request), "isGSTRequired");
					if(isGstRequired==1){
						manageBidderService.updateRegistrationWorkflowInBidderStatus(abcUtility.getSessionClientId(request),userId, 7);
					}else{
						manageBidderService.updateRegistrationWorkflowInBidderStatus(abcUtility.getSessionClientId(request),userId, 8);
					}
					Map<String, Object> mailParams = new HashMap<String, Object>();
					mailParams.put("domainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
					mailParams.put("eventType", commonService.getEventTypeModuleId(tblPayment.getTblModule().getModuleId()).get(0)[2]);
					mailParams.put("eventId", objectId);
					mailParams.put("amount", tblPayment.getAmount());
					mailParams.put("paymentType", commonService.getPaymentTypeDetail(tblPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
					mailParams.put("paymentMode", "Online");
					mailParams.put("date", CommonUtility.convertTimezone(commonService.getServerDateTime()));
					if(tblPayment.getPaymentFor() == 1){
						mailContentUtillity.dynamicMailGeneration("387", "0", null, mailParams, String.valueOf(tblPayment.getTblCompany().getCompanyId()), String.valueOf(abcUtility.getSessionClientId(request)));
					}else if(tblPayment.getPaymentFor() == 2){
						mailContentUtillity.dynamicMailGeneration("388", "0", null, mailParams, String.valueOf(tblPayment.getTblCompany().getCompanyId()), String.valueOf(abcUtility.getSessionClientId(request)));
					}else if(tblPayment.getPaymentFor() == 8){
						mailContentUtillity.dynamicMailGeneration("389", "0", null, mailParams, String.valueOf(tblPayment.getTblCompany().getCompanyId()), String.valueOf(abcUtility.getSessionClientId(request)));
					}
				} else if (resCode.equals("400")) {
					rea.addFlashAttribute("errorMsg","redirect_error_payment_done");
				} else {
					rea.addFlashAttribute("errorMsg", "msg_payment_fail");
				}
			}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),lnkRegiChargesThroughPG, getPaymentDataDashboard, objectId, paymentId);
		}
			return "redirect:/" + page;
	}

	/**
	 * @author sharmila
	 * @param httpSession
	 * @param request
	 * @param rea
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value = "/successPayment", method = RequestMethod.POST)
	public String submitOnlinePaymentDetail(HttpSession httpSession,
			HttpServletRequest request, RedirectAttributes rea)
			throws IOException {
		String page = "";
		int paymentId = 0;
		int objectId = 0;
		int linkId = 0;
		boolean isPaymentDone = false;
		int moduleId=0;
		String ipAddress = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
		try {
			if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
				String msg = "";
				SessionBean sBean =(SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
				if (StringUtils.hasLength(request.getParameter("msg"))) {
					msg = request.getParameter("msg");
				}
				TblClientPGBankMapping tblClientPGBankMapping=clientService.getTblClientPGBankMapping(abcUtility.getSessionClientId(request),1);
				int pgId=tblClientPGBankMapping!=null?tblClientPGBankMapping.getTblPaymentGatewayMaster().getPgId():0;
				TblClientPGConf tblClientPGConf = tpslService.getPGConfigurationFromMerchantId(abcUtility.getSessionClientId(request),(String)request.getParameter("tpsl_mrct_cd"));
				TransactionResponseBean transactionResponseBean = new TransactionResponseBean();
				String strCheckSumValue = "";
				String returnCheckSum = null;
				String tpslRefId = null;
				String paymentDoneResCode = null;
				boolean ispaymentVarificationTpsl = false;
				String resCode = null;
				int strLength = 0;

				if(pgId ==1){
					System.out.println(" successPayment 5.1");
					String[] oldStrArr = msg.split("\\|");
					strLength = oldStrArr.length;					
					strLength = oldStrArr.length;
					returnCheckSum = oldStrArr[strLength - 1];
					paymentId = StringUtils.hasLength(oldStrArr[1]) ? Integer.parseInt(oldStrArr[1]) : 0;
					tpslRefId = oldStrArr[2]; 
					paymentDoneResCode = oldStrArr[14];
				}else if(pgId == 12){
					transactionResponseBean.setKey(tblClientPGConf.getEncryptionKey().trim().getBytes());
					transactionResponseBean.setIv(tblClientPGConf.getSecureSecret().trim().getBytes());  				
					transactionResponseBean.setResponsePayload(msg);
					String transactionResponse = transactionResponseBean.getResponsePayload();

					System.out.println(" resrString ResponsePayload : "+(String)request.getParameter("msg"));
					System.out.println(" resrString clnt_txn_ref : "+(String)request.getParameter("clnt_txn_ref"));
					System.out.println(" resrString tpsl_mrct_cd : "+(String)request.getParameter("tpsl_mrct_cd"));
					System.out.println(" resrString clnt_rqst_meta : "+(String)request.getParameter("clnt_rqst_meta"));
					String tranId=(String)request.getSession().getAttribute("mer_tran_id");
					System.out.println(" resrString mer_tran_id : "+tranId);
					if(request.getSession().getAttribute("KEY")!=null){
						System.out.println(" resrString ResponsePayload.jsp key: "+(String)request.getSession().getAttribute("KEY")+" tranId :"+tranId);
						System.out.println(" resrString ResponsePayload.jsp iv:"+(String)request.getSession().getAttribute("IV")+" tranId :"+tranId);
					}	
					String[] newStrArr = transactionResponse.split("\\|");
					String txn_status = newStrArr[0].split("=")[1];	 
					String clnt_txn_ref = newStrArr[3].split("=")[1];
					String tpsl_txn_id = newStrArr[5].split("=")[1];

					strLength = newStrArr.length;
					returnCheckSum = newStrArr[strLength - 1];
					paymentId = Integer.parseInt(clnt_txn_ref);
					tpslRefId = tpsl_txn_id;
					paymentDoneResCode = txn_status;
				}
				TblPayment tblPayment = tpslService.getTblPayment(paymentId);
				tblClientPGConf = tpslService.getPGConfiguration(abcUtility.getSessionClientId(request),tblPayment.getPaymentFor(),tblPayment.getTblDepartment().getDeptId());
				if(pgId == 12){
					ispaymentVarificationTpsl=tpslService.paymentVarificationTpsl(tblPayment.getPaymentFor(), tblPayment.getPaymentId(), abcUtility.getSessionClientId(request), String.valueOf(tblPayment.getCreatedOn()), tblPayment.getTblDepartment().getDeptId());
				}
				if (strLength > 0) {
					if (tpslService.isOnlinePaymentDone(paymentId)) {
						resCode = "1300";
						isPaymentDone = true;
					} else {
						resCode = paymentDoneResCode;
						if ("0300".equals(resCode)) {
							isPaymentDone = true;
						}
					}
					objectId = tblPayment.getObjectId();
					tblPayment.setCstatus(isPaymentDone ? 1 : 2);
					TblOnlinePayment tblOnlinePayment = new TblOnlinePayment();
					tblOnlinePayment.setMerchantId(tblClientPGConf.getMerchantId());
					tblOnlinePayment.setResponseCode(resCode);
					tblOnlinePayment.setResponseMessage(msg);
					tblOnlinePayment.setTblPayment(tblPayment);
					tblOnlinePayment.setTpslReferenceId(tpslRefId);
					tpslService.addOnlinePaymentDetail(tblOnlinePayment);
					int isItemwiseWinner = 0;
					int itemwisePayment =0;
					if(tblPayment.getTblModule().getModuleId()==3){	
						 isItemwiseWinner = Integer.parseInt(commonService.getField("TblTender", "isItemwiseWinner","tenderId",tblPayment.getObjectId()).toString());
						 itemwisePayment = Integer.parseInt(commonService.getField("TblTender",tblPayment.getPaymentFor()==1?"isDocfeesApplicable":tblPayment.getPaymentFor()==2  || tblPayment.getPaymentFor()==9?"isEMDApplicable":"isRegistrationCharges","tenderId",objectId).toString());
					}else if(tblPayment.getTblModule().getModuleId()==5){
                		itemwisePayment = Integer.parseInt(commonService.getField("TblAuction",tblPayment.getPaymentFor()==2?"isEmdReq":"isRegistrationCharges","auctionId",tblPayment.getObjectId()).toString());
                	}
					if(itemwisePayment==2 || isItemwiseWinner == 1 || tblPayment.getPaymentFor()==11){//isItemwiseWinner is 1 if Event is Itemwise
						int companyId = tpslService.getCompanyIdByPaymentId(tblPayment.getPaymentId());
						tpslService.tenderFeesUpdateAndInsertOnFailure(companyId ,tblPayment.getObjectId() ,tblPayment.getUniqueId(),isPaymentDone,isPaymentDone?1:2);
					}
					moduleId=tblPayment.getTblModule().getModuleId();
					if(moduleId==3){
						page = "etender/bidder/biddingtenderdashboard/";
					}else if(moduleId==5 && tblPayment.getPaymentFor()!=8){
						BigDecimal amount=tblPayment.getAmount();
						TblEmdBalance tblEmdBalance=commonService.checkTblEmdBalance(tblPayment.getTblCompany().getCompanyId(), objectId, tblPayment.getTblClient().getClientId());
						if(tblEmdBalance!=null){
							tblEmdBalance.setEmdAmount(amount.add(tblEmdBalance.getEmdAmount()));
							tblEmdBalance.setEmdBalance(amount.add(tblEmdBalance.getEmdBalance()));
							tblEmdBalance.setUpdatedOn(commonService.getServerDateTime());
							tblEmdBalance.setUpdatedBy(abcUtility.getSessionUserId(request));
						}else{
							tblEmdBalance=new TblEmdBalance();
							tblEmdBalance.setAuctionId(objectId);
							tblEmdBalance.setBidderId(abcUtility.getSessionUserId(request));
							tblEmdBalance.setClientId(tblPayment.getTblClient().getClientId());
							tblEmdBalance.setTblCompany(tblPayment.getTblCompany());
							tblEmdBalance.setEmdAmount(amount);
							tblEmdBalance.setEmdBalance(amount);
//							tblEmdBalance.setCreatedOn(commonService.getServerDateTime());							
							tblEmdBalance.setCreatedBy(abcUtility.getSessionUserId(request));
							tblEmdBalance.setUpdatedOn(commonService.getServerDateTime());
							tblEmdBalance.setUpdatedBy(abcUtility.getSessionUserId(request));
						}						
						commonService.addTblEmdBalance(tblEmdBalance);
						page = "common/bidder/payment/";
					}
					CheckSumResponseBean objResTranDetails = new CheckSumResponseBean();
					objResTranDetails.setStrMSG(msg);
					objResTranDetails.setStrPropertyPath(filePath + "/"+ tblClientPGConf.getFileName());
					com.TPSLUtil util = new com.TPSLUtil();
					strCheckSumValue = util.transactionResponseMessage(objResTranDetails);
					page += objectId + "/";
					if(moduleId==3){
						if (tblPayment.getPaymentFor() == 1) {
							linkId = lnkDocfeePaymentPG;
							page += TAB_DOC_FEES;
						}else if (tblPayment.getPaymentFor() == 2) {
							linkId = lnkEmdPaymentThroughPG;
							page += TAB_EMD;
						}else if (tblPayment.getPaymentFor() == 9) {
							linkId = lnkTenderRestOfEventMoney;
							page += TAB_RESTEVENTMONEY;
						}else{
							linkId = lnkTenderEventPaymentPG;
							page += itemwisePayment ==2 ? TAB_PARTICIPATION_FEES : TAB_REG_PAYMENT;
						}
					}else  if(moduleId==5 && tblPayment.getPaymentFor()==9){
						page = "restOfAuction/bidder/getRestOfAucPaymentDetail/"+moduleId + "/"+objectId+"/"+tblPayment.getPaymentFor()+"/"+paymentId;
					}else  if(moduleId==5 && tblPayment.getPaymentFor()==11){
						page="common/bidder/payment/"+objectId+"/"+moduleId+"/11";
						linkId = lnkAuctionSecurityPaymentPG;
					}else if(moduleId==5 && tblPayment.getPaymentFor()!=8){
						page+=moduleId;
						if (tblPayment.getPaymentFor() == 2) {
							linkId = lnkAuctionEmdPaymentPG;
						}
						page+="/"+tblPayment.getPaymentFor();
					}else  if(moduleId==5 && tblPayment.getPaymentFor()==8){
						page="eauction/bidder/auctionlisting";
					}
					if (StringUtils.hasLength(resCode) && isPaymentDone && (strCheckSumValue.equals(returnCheckSum)) || ispaymentVarificationTpsl) {
						rea.addFlashAttribute("successMsg", tblPayment.getPaymentFor() == 1 ? "msg_doc_payment_success" : tblPayment.getPaymentFor() ==2 ?"msg_emd_payment_success":tblPayment.getPaymentFor()==8?"msg_eventReg_payment_success":(tblPayment.getPaymentFor()==9 && moduleId==3)? "msg_restEventMoney_payment_success" : (tblPayment.getPaymentFor()==9 && moduleId==5)? "msg_restAucMoney_payment_success": (tblPayment.getPaymentFor()==11 && moduleId==5)? "msg_payment_submit_success":"msg_payment_success");
						Map<String, Object> mailParams = new HashMap<String, Object>();
						URL url = new URL(request.getRequestURL().toString().split(request.getRequestURI().toString())[0]);
						mailParams.put("domainName", clientService.getClientNameById(abcUtility.getSessionClientId(request)));
						mailParams.put("domainURL",  url + request.getContextPath().toString());
						mailParams.put("amount", tblPayment.getAmount());
						mailParams.put("paymentType", commonService.getPaymentTypeDetail(tblPayment.getTblPaymentType().getPaymentTypeId()).getLang1());
						mailParams.put("paymentMode", "Online");
						mailParams.put("date", CommonUtility.convertTimezone(commonService.getServerDateTime()));
						mailParams.put("to", loginService.getLoginIdByUserId(sBean.getUserId()).get(0).toString());
						mailContentUtillity.dynamicMailGeneration("390", String.valueOf(abcUtility.getSessionUserId(request)), String.valueOf(abcUtility.getSessionClientId(request)), mailParams, "");
					} else {
						rea.addFlashAttribute("errorMsg", "msg_payment_fail");
					}
				}else {
					rea.addFlashAttribute("errorMsg", "msg_payment_fail");
				}
			}
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			if(moduleId==3){
				auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getPaymentDataDashboard, objectId, paymentId);
			}else if(moduleId==5){
				auditTrailService.makeAuctionAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),linkId, getPaymentDataDashboard,ipAddress, objectId, paymentId);
			}
		}
		return "redirect:/" + page + encryptDecryptUtils.generateRedirect(page, request);
	}

	 /**
     * @author dipika
     * get pg configuration for selected deptId
     * @param deptId
     * @param paymentFor
     * @return
     * @throws Exception
     */
	@RequestMapping(value = "/ajaxcall/getDeptPGConf", method = RequestMethod.POST)
	@ResponseBody
    public String getDeptPGConf(@RequestParam("hdDeptId") int deptId, @RequestParam("txtPaymentFor") int  paymentFor, HttpSession session, HttpServletRequest request) {
        String resultString = null;
        try {
           TblClientPGConf tblClientPGConf=tpslService.getClientPGConfDeptWise(deptId, paymentFor);
           resultString = tblClientPGConf.getMerchantId()+"@@"+tblClientPGConf.getCheckSumKey()+"@@"+tblClientPGConf.getUserName()+"@@"+tblClientPGConf.getPassword()+"@@"+tblClientPGConf.getAccessCode();
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return resultString;
    }
}

