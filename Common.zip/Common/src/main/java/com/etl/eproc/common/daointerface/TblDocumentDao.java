package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDocument;
import java.util.List;

public interface TblDocumentDao  {

    public void addTblDocument(TblDocument tblDocument);

    public void deleteTblDocument(TblDocument tblDocument);

    public void updateTblDocument(TblDocument tblDocument);

    public List<TblDocument> getAllTblDocument();

    public List<TblDocument> findTblDocument(Object... values) throws Exception;

    public List<TblDocument> findByCountTblDocument(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDocumentCount();

    public void saveUpdateAllTblDocument(List<TblDocument> tblDocuments);
}