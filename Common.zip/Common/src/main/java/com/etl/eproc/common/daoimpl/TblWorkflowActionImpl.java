package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblWorkflowActionDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblWorkflowAction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblWorkflowActionImpl extends AbcAbstractClass<TblWorkflowAction> implements TblWorkflowActionDao {

    @Override
    public void addTblWorkflowAction(TblWorkflowAction tblWorkflowAction){
        super.addEntity(tblWorkflowAction);
    }

    @Override
    public void deleteTblWorkflowAction(TblWorkflowAction tblWorkflowAction) {
        super.deleteEntity(tblWorkflowAction);
    }

    @Override
    public void updateTblWorkflowAction(TblWorkflowAction tblWorkflowAction) {
        super.updateEntity(tblWorkflowAction);
    }

    @Override
    public List<TblWorkflowAction> getAllTblWorkflowAction() {
        return super.getAllEntity();
    }

    @Override
    public List<TblWorkflowAction> findTblWorkflowAction(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblWorkflowActionCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblWorkflowAction> findByCountTblWorkflowAction(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblWorkflowAction(List<TblWorkflowAction> tblWorkflowActions){
        super.updateAll(tblWorkflowActions);
    }
}
