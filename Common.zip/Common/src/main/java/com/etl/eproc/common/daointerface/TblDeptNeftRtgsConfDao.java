package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDeptNeftRtgsConf;
import java.util.List;

public interface TblDeptNeftRtgsConfDao  {

    public void addTblDeptNeftRtgsConf(TblDeptNeftRtgsConf tblDeptNeftRtgsConf);

    public void deleteTblDeptNeftRtgsConf(TblDeptNeftRtgsConf tblDeptNeftRtgsConf);

    public void updateTblDeptNeftRtgsConf(TblDeptNeftRtgsConf tblDeptNeftRtgsConf);

    public List<TblDeptNeftRtgsConf> getAllTblDeptNeftRtgsConf();

    public List<TblDeptNeftRtgsConf> findTblDeptNeftRtgsConf(Object... values) throws Exception;

    public List<TblDeptNeftRtgsConf> findByCountTblDeptNeftRtgsConf(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDeptNeftRtgsConfCount();

    public void saveUpdateAllTblDeptNeftRtgsConf(List<TblDeptNeftRtgsConf> tblDeptNeftRtgsConfs);

	public void saveOrUpdateTblDeptNeftRtgsConf(TblDeptNeftRtgsConf tblDeptNeftRtgsConf);
}