/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

import com.etl.eproc.common.model.TblFaqDetail;
import com.etl.eproc.common.daointerface.TblFaqDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author mahesh.patel
 */
@Repository @Transactional    /*StackUpdate*/
public class TblFaqDetailImpl extends AbcAbstractClass<TblFaqDetail> implements TblFaqDetailDao {

    @Override
    public void addTblFaqDetail(TblFaqDetail tblFaqDetail) {
        super.addEntity(tblFaqDetail);
    }

    @Override
    public void deleteTblFaqDetail(TblFaqDetail tblFaqDetail) {
        super.deleteEntity(tblFaqDetail);
    }

    @Override
    public void updateTblFaqDetail(TblFaqDetail tblFaqDetail) {
        super.updateEntity(tblFaqDetail);
    }

    @Override
    public List<TblFaqDetail> getAllTblFaqDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFaqDetail> findTblFaqDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFaqDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFaqDetail> findByCountTblFaqDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFaqDetail(List<TblFaqDetail> tblFaqDetails) {
        super.updateAll(tblFaqDetails);
    }
}
