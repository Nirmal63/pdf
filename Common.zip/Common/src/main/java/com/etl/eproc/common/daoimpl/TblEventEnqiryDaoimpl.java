package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblEventEnqiryDao;
import com.etl.eproc.common.daointerface.TblUserLoginDao;
import com.etl.eproc.common.model.TblEventEnquiry;
import com.etl.eproc.common.model.TblUserLogin;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblEventEnqiryDaoimpl extends AbcAbstractClass<TblEventEnquiry> implements TblEventEnqiryDao {


    @Override
    public boolean addTblEventEnqiry(TblEventEnquiry tblEventEnqiry){
        super.saveOrUpdateEntity(tblEventEnqiry);
		return true;
    }

    @Override
    public void deleteTblEventEnqiry(TblEventEnquiry tblEventEnqiry) {
        super.deleteEntity(tblEventEnqiry);
    }

	/*
	 * @Override public void updateTblUserLogin(TblEventEnqiry tblEventEnqiry) {
	 * super.updateEntity(tblEventEnqiry); }
	 */

	/*
	 * @Override public List<TblEventEnqiry> getAlltblEventEnqiry() { return
	 * super.getAllEntity(); }
	 */

    @Override
    public List<TblEventEnquiry> findTblEventEnqiry(Object... values) throws Exception {
        return super.findEntity(values);
    }

	/*
	 * @Override public long gettblEventEnqiryCount() { return
	 * super.getEntityCount(); }
	 */

    @Override
    public List<TblEventEnquiry> findByCountTblEventEnqiry(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblEventEnqiry(List<TblEventEnquiry> tblEventEnqirys){
        super.updateAll(tblEventEnqirys);
    }

}
