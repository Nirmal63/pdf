package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientColumnType;
import java.util.List;

public interface TblClientColumnTypeDao  {

    public void addTblClientColumnType(TblClientColumnType tblClientColumnType);

    public void deleteTblClientColumnType(TblClientColumnType tblClientColumnType);

    public void updateTblClientColumnType(TblClientColumnType tblClientColumnType);

    public List<TblClientColumnType> getAllTblClientColumnType();

    public List<TblClientColumnType> findTblClientColumnType(Object... values) throws Exception;

    public List<TblClientColumnType> findByCountTblClientColumnType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientColumnTypeCount();

    public void saveUpdateAllTblClientColumnType(List<TblClientColumnType> tblClientColumnTypes);
}