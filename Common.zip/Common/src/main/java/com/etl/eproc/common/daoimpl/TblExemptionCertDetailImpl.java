package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblExemptionCertDetail;
import com.etl.eproc.common.daointerface.TblExemptionCertDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblExemptionCertDetailImpl extends AbcAbstractClass<TblExemptionCertDetail> implements TblExemptionCertDetailDao {

    @Override
    public void addTblExemptionCertDetail(TblExemptionCertDetail tblExemptionCertDetail){
        super.addEntity(tblExemptionCertDetail);
    }

    @Override
    public void deleteTblExemptionCertDetail(TblExemptionCertDetail tblExemptionCertDetail) {
        super.deleteEntity(tblExemptionCertDetail);
    }

    @Override
    public void updateTblExemptionCertDetail(TblExemptionCertDetail tblExemptionCertDetail) {
        super.updateEntity(tblExemptionCertDetail);
    }

    @Override
    public List<TblExemptionCertDetail> getAllTblExemptionCertDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblExemptionCertDetail> findTblExemptionCertDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblExemptionCertDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblExemptionCertDetail> findByCountTblExemptionCertDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblExemptionCertDetail(List<TblExemptionCertDetail> tblExemptionCertDetails){
        super.updateAll(tblExemptionCertDetails);
    }

	@Override
	public void saveOrUpdateTblExemptionCertDetail(TblExemptionCertDetail tblExemptionCertDetail) {
		super.saveOrUpdateEntity(tblExemptionCertDetail);
	}
}
