package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientContentMapping;
import java.util.List;

public interface TblClientContentMappingDao  {

    public void addTblClientContentMapping(TblClientContentMapping tblClientContentMapping);

    public void deleteTblClientContentMapping(TblClientContentMapping tblClientContentMapping);

    public void updateTblClientContentMapping(TblClientContentMapping tblClientContentMapping);

    public List<TblClientContentMapping> getAllTblClientContentMapping();

    public List<TblClientContentMapping> findTblClientContentMapping(Object... values) throws Exception;

    public List<TblClientContentMapping> findByCountTblClientContentMapping(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientContentMappingCount();

    public void saveUpdateAllTblClientContentMapping(List<TblClientContentMapping> tblClientContentMappings);
}