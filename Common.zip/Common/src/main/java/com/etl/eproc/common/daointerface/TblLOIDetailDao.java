/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;

import com.etl.eproc.common.model.TblLOIDetail;
import java.util.List;
/**
 *
 * @author urja
 */

public interface TblLOIDetailDao  {

    public void addTblLOIDetail(TblLOIDetail tblLOIDetail);

    public void deleteTblLOIDetail(TblLOIDetail tblLOIDetail);

    public void updateTblLOIDetail(TblLOIDetail tblLOIDetail);

    public List<TblLOIDetail> getAllTblLOIDetail();

    public List<TblLOIDetail> findTblLOIDetail(Object... values) throws Exception;

    public List<TblLOIDetail> findByCountTblLOIDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblLOIDetailCount();

    public void saveUpdateAllTblLOIDetail(List<TblLOIDetail> tblLOIDetails);
}
