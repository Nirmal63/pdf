package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblTypeDao;
import com.etl.eproc.common.model.TblType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblTypeImpl extends AbcAbstractClass<TblType> implements TblTypeDao {

    @Override
    public void addTblType(TblType tblType) {
        super.addEntity(tblType);
    }

    @Override
    public void deleteTblType(TblType tblType) {
        super.deleteEntity(tblType);
    }

    @Override
    public void updateTblType(TblType tblType) {
        super.updateEntity(tblType);
    }

    @Override
    public List<TblType> getAllTblType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblType> findTblType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblType> findByCountTblType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblType(List<TblType> tblTypes) {
        super.updateAll(tblTypes);
    }
}
