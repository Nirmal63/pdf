package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientEventType;
import java.util.List;

public interface TblClientEventTypeDao  {

    public void addTblClientEventType(TblClientEventType tblClientEventType);

    public void deleteTblClientEventType(TblClientEventType tblClientEventType);

    public void updateTblClientEventType(TblClientEventType tblClientEventType);

    public List<TblClientEventType> getAllTblClientEventType();

    public List<TblClientEventType> findTblClientEventType(Object... values) throws Exception;

    public List<TblClientEventType> findByCountTblClientEventType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientEventTypeCount();

    public void saveUpdateAllTblClientEventType(List<TblClientEventType> tblClientEventTypes);
}