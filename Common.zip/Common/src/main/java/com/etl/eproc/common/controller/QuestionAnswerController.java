package com.etl.eproc.common.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.databean.MessageConfigDatabean;
import com.etl.eproc.common.model.TblAnswer;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblOfficerDocMapping;
import com.etl.eproc.common.model.TblQueAnsOfficer;
import com.etl.eproc.common.model.TblQuestion;
import com.etl.eproc.common.model.TblSubModule;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.MessageQueueService;
import com.etl.eproc.common.services.QuestionAnswerService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.DateUtils;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.SelectItem;

/**
 * 
 * @author Jaynam
 */
@Controller
@RequestMapping("/common")
public class QuestionAnswerController {
	@Autowired
	private ExceptionHandlerService exceptionHandlerService;

	@Autowired
	private AbcUtility abcUtility;

	@Autowired
	private QuestionAnswerService answerService;

	@Autowired
	private CommonService commonService;
	
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	
	@Autowired
	private DepartmentUserService departmentUserService;
	
	@Autowired
	private LoginService loginService; 
    @Autowired
    private MessageQueueService messageQueueService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private DateUtils dateUtils;
    @Autowired
    private AuditTrailService auditTrailService;
	
	@Value("#{projectProperties['prebidmeeting_id']?:31}")
	private int prebidMeetingId;
	@Value("#{projectProperties['bidopening_id']?:32}")
	private int bidOpeningId;
	@Value("#{projectProperties['bidevaluation_id']?:33}")
	private int bidEvaluationId;
	@Value("#{tenderlinkProperties['upload_clarification']?:1182}")
	private int upload_clarificationLinkId;
    @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
    private String queueName;
    @Value("#{tenderlinkProperties['viewAllQuestionAnswerLinkId']?:215}")
	private int viewAllQuestionAnswerLinkId;
    @Value("#{etenderAuditTrailProperties['getQusAnsTab']}")
    private String getQusAnsTab;
    @Value("#{etenderAuditTrailProperties['getUnAnsweredTab']}")
    private String getUnAnsweredTab;
    @Value("#{etenderAuditTrailProperties['getAnsweredTab']}")
    private String getAnsweredTab;
    @Value("#{etenderAuditTrailProperties['getAllTab']}")
    private String getAllTab;
    @Value("#{etenderAuditTrailProperties['getClarificationDocumentQusAns']}")
    private String getClarificationDocumentQusAns;
    @Value("#{etenderAuditTrailProperties['getPostQuestionPage']}")
    private String getPostQuestionPage;
    @Value("#{etenderAuditTrailProperties['postQuestionByBidderPage']}")
    private String postQuestionByBidderPage;
    @Value("#{tenderlinkProperties['postQuestionLinkId']?:369}")
	private int postQuestionLinkId;
    @Value("#{tenderlinkProperties['submitQuestionLinkId']?:370}")
	private int submitQuestionLinkId;
    @Value("#{tenderlinkProperties['postAnswerLinkId']?:3294}")
	private int postAnswerLinkId;
    @Value("#{etenderAuditTrailProperties['getPostAnswerPage']}")
    private String getPostAnswerPage;
    @Value("#{etenderAuditTrailProperties['postAnswerByOfficerPage']}")
    private String postAnswerByOfficerPage;	
    @Value("#{etenderAuditTrailProperties['getConversationHistoryPage']}")
    private String getConversationHistoryPage;
    
	private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
	private static final int maxResult = 10 ;

	/**
	 * Method to get query Form
	 * 
	 * @Author Jaynam Doshi
	 * @param moduleType
	 * @param eventId
	 * @param type
	 * @param mode
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/question/getQuestionBox/{moduleType}/{eventId}/{type}/{mode}/{enc}", method = RequestMethod.GET)
	public String getQuestionBox(@PathVariable("moduleType") int moduleType,@PathVariable("eventId") int eventId, @PathVariable("type") int type,@PathVariable("mode") int mode, ModelMap modelMap,HttpServletRequest request) throws Exception {
		try{
			int clientId=abcUtility.getSessionClientId(request);
			List<SelectItem> selSubModule = getSubModulSelectItem(clientId,moduleType,0);
			modelMap.addAttribute("selSubModule", selSubModule);
			modelMap.addAttribute("questionType", type);
			modelMap.addAttribute("ModuleType", moduleType);
			modelMap.addAttribute("eventId", eventId);
			modelMap.addAttribute("mode",mode);
		}catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			String message = "";
			if(mode == 1){
				message = getPostQuestionPage;
			}else if(mode == 2){
				message = getConversationHistoryPage;
			}
			auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),postQuestionLinkId, message, eventId,0);
		}
		return "common/questionanswer/postQuestion";
	}

	/**
	 * Method to get response Form
	 * 
	 * @Author Jaynam Doshi
	 * @param moduleType
	 * @param eventId
	 * @param type
	 * @param mode
	 * @param modelMap
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value = "/answer/getAnswerBox", method = RequestMethod.POST)
	public String getAnswerBox(@RequestParam("txtQuestionId") int questionId , ModelMap modelMap,HttpServletRequest request) throws Exception {
	try{
		modelMap.addAttribute("eventId", Integer.parseInt(request.getParameter("hdEventId").toString()));
		modelMap.addAttribute("moduleType",Integer.parseInt(request.getParameter("hdModuleType").toString()));
		modelMap.addAttribute("createdBy",Integer.parseInt(request.getParameter("hdCreatedBy").toString()));
		modelMap.addAttribute("quesanslist", answerService.getQuestionAnswerByQid(questionId));
	}catch (Exception e) {
		return exceptionHandlerService.writeLog(e);
	} finally {
		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), postAnswerLinkId, getPostAnswerPage, Integer.parseInt(request.getParameter("hdEventId").toString()),0);
	}
		return "common/questionanswer/postAnswer";
	}


	/**
	 * Method to post query Form
	 * 
	 * @Author Jaynam Doshi
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/question/postQuestion", method = RequestMethod.POST)
	public String postQuestion(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes)
			throws Exception {
		String retval= REDIRECT_SESSION_EXPIRED;
		try{
				boolean isSuccess = false;
				int mode = 1;
				int eventId = Integer.parseInt(request.getParameter("hdEventId").toString());
				int moduleId = Integer.parseInt(request.getParameter("selSubModule").toString());
				int type = Integer.parseInt(request.getParameter("hdType").toString());
				int moduleType = Integer.parseInt(request.getParameter("hdModuleType").toString());
				String redirectMsg = "lbl_question_post";
				String strQuery = (request.getParameter("rtfQuestion") != null ? request
						.getParameter("rtfQuestion").toString() : "");
				int isValidTime = answerService.isQuestionAnswerValidTime(moduleType,eventId);
				if (!strQuery.trim().equals("") && isValidTime == 0) {
					TblQuestion tblQuestion = new TblQuestion();
					tblQuestion.setModuleType(moduleType);
					tblQuestion.setParentQuestionId(0);
					tblQuestion.setTblSubModule(new TblSubModule(moduleId));
					tblQuestion.setCstatus(0);
					tblQuestion.setQuestionText(strQuery);
					tblQuestion.setObjectId(eventId);
					tblQuestion.setTblUserLogin(new TblUserLogin(abcUtility.getSessionUserId(request)));
					tblQuestion.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
					tblQuestion.setUserTypeId(abcUtility.getSessionUserTypeId(request));
		
					isSuccess = answerService.addTblQuestion(tblQuestion);
		
				} else {
					if(isValidTime == 1) {
						redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "question_hours_not_yet_started");
					} else if(isValidTime == 2){
						redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "question_hours_fininshed");
					}
				}
				if(isSuccess){
					redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectMsg : CommonKeywords.ERROR_MSG_KEY.toString());
				}
				String ret="common/question/getQuestionBox/"+moduleType+"/"+eventId+"/"+type+"/"+mode;
				retval="redirect:/"+ret+encryptDecryptUtils.generateRedirect(ret,request);
			}catch (Exception e) {
				return exceptionHandlerService.writeLog(e);
			} finally {
				auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), submitQuestionLinkId, postQuestionByBidderPage, Integer.parseInt(request.getParameter("hdEventId").toString()),0);
			}
		return retval;
	}

	
	/**
	 * Method to save Answer
	 * 
	 * @Author Jaynam Doshi
	 * @param modelMap
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/answer", method = RequestMethod.POST)
	public String saveAnswer(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes)
			throws Exception {
		String retval= REDIRECT_SESSION_EXPIRED;
		try
		{
			boolean isSuccess = false;
			int questionID = Integer.parseInt(request.getParameter("hdQuestionId").toString());
			int eventId = Integer.parseInt(request.getParameter("hdEventId").toString());
			String redirectMsg = "lbl_answer_post";
			int moduleType = Integer.parseInt(request.getParameter("hdModuleType").toString());
			int createdBy = Integer.parseInt(request.getParameter("hdCreatedBy").toString());
			String strQuery = (request.getParameter("rtfAnswer") != null ? request.getParameter("rtfAnswer").toString() : "");
			if (!strQuery.trim().equals("")) {
				TblAnswer tblAnswerDetail = new TblAnswer();
				tblAnswerDetail.setAnswerText(strQuery);
				tblAnswerDetail.setCstatus(1);
				tblAnswerDetail.setTblQuestion(new TblQuestion(questionID));
				tblAnswerDetail.setTblUserLogin(new TblUserLogin(abcUtility.getSessionUserId(request)));
				tblAnswerDetail.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
				tblAnswerDetail.setUserTypeId(abcUtility.getSessionUserTypeId(request));
				isSuccess = answerService.addTblAnswer(tblAnswerDetail);
				if(isSuccess){
					redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectMsg : CommonKeywords.ERROR_MSG_KEY.toString());
				}
			}
			retval = "redirect:/common/questionanswer/view/"+eventId+"/"+moduleType+"/"+createdBy+encryptDecryptUtils.generateRedirect("common/questionanswer/view/"+eventId+"/"+moduleType+"/"+createdBy,request);
		}catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), postAnswerLinkId, postAnswerByOfficerPage, Integer.parseInt(request.getParameter("hdEventId").toString()),0);
		}
		return retval;
	}

	/**
	 * 
	 * @param eventId
	 * @param viewType
	 * @param modelMap
	 * @param request
	 * @return ajaxView
	 */
	@RequestMapping(value = "/query/viewAjaxQueries", method = RequestMethod.POST)
	public String viewAjaxQuestion(@RequestParam("txteventId") int eventId, 
								   @RequestParam("txtModuleType") int moduleType,
								   @RequestParam("txtModuleId") int moduleId,
								   @RequestParam("txtCstatus") int cStatus,
								   @RequestParam("txtMode") int mode,
								ModelMap modelMap,HttpServletRequest request, HttpSession session) {
		String	retVal;
		try {
			int clientId= abcUtility.getSessionClientId(request);
			int userId = abcUtility.getSessionUserId(request);
			int userType = abcUtility.getSessionUserTypeId(request);
			 modelMap.addAttribute("currentDate",commonService.getServerDateTime());
			 modelMap.addAttribute("viewType",moduleType);
			 modelMap.addAttribute("mode",mode);
			 modelMap.addAttribute("eventId",eventId);
			 modelMap.addAttribute("QusAnsList",answerService.viewAllQuestionAnswer(eventId,userId, moduleType,userType,moduleId,cStatus,clientId));	
			 retVal = "common/questionanswer/ViewQuesAns";
			 
		} catch (Exception e) {
			retVal = exceptionHandlerService.writeLog(e);
		}
		return retVal;
	}

	/**
	 * Method to display all question,answer and my question answer viewType 1 -
	 * @author jaynam
	 * @param eventId
	 * @param moduleType
	 * @param modelMap
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/questionanswer/view/{eventId}/{moduleType}/{createdBy}/{enc}", method = RequestMethod.GET)
	public String viewQuestionAnswer(@PathVariable("eventId") int eventId,@PathVariable("moduleType") int moduleType,@PathVariable("createdBy") int createdBy, ModelMap modelMap,HttpServletRequest request) {
		String pageName="common/questionanswer/OfficerQAView";
		try {
			int clientId=abcUtility.getSessionClientId(request);
			int userType = 0;
			if(moduleType == 3) {
				userType = answerService.getUserTypeForTender(abcUtility.getSessionUserDetailId(request),createdBy,eventId,abcUtility.getSessionUserId(request));
			}
			modelMap.addAttribute("userType", userType);
			//Change Request #22284 Start
			boolean notAuthorize = false;
			if(abcUtility.getSessionUserTypeId(request) == 3){
				boolean isQuestionAnswer = false;
				boolean isQAOfficerAllowed = false;
				commonService.commontenderSummary(eventId,modelMap,clientId);
				List<String> field = new ArrayList<String>();
				field.add("isQuestionAnswer");
				field.add("isQueAnsOfficer");
//				System.out.println(modelMap.get("eventTypeId"));
				List<Object[]> lstClientConfigFields = commonService.getClientConfigurationFields(abcUtility.getSessionClientId(request),Integer.parseInt(modelMap.get("eventTypeId").toString()),field);
	            if (lstClientConfigFields != null) {
	                for (int i = 0; i < lstClientConfigFields.size(); i++) {
	                	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isQuestionAnswer") && Integer.parseInt(lstClientConfigFields.get(i)[4].toString()) == 1){
	                		isQuestionAnswer=true;
	                    }
	                	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isQueAnsOfficer") && Integer.parseInt(lstClientConfigFields.get(i)[4].toString()) == 1){
	                		isQAOfficerAllowed=true;
	                    }
	                }
	            }
	            if(isQuestionAnswer && isQAOfficerAllowed){
	            	List<TblQueAnsOfficer> officers =  departmentUserService.getTblQueAnsOfficer(clientId);
	            	for(TblQueAnsOfficer tblQueAnsOfficer : officers){
	            		if(tblQueAnsOfficer.getIsActive()==1){
	            			int userId = tblQueAnsOfficer.getTblUserLogin().getUserId();
	            			modelMap.addAttribute("officerEmailId",commonService.getEmailByUserId(userId));
	            			modelMap.addAttribute("personName",commonService.getUserName(userId));
	            		}
	            		if(tblQueAnsOfficer.getTblUserLogin().getUserId() == abcUtility.getSessionUserId(request)){
	            			if(tblQueAnsOfficer.getIsActive()==0){
	            				notAuthorize = true;
	            			}else{
	            				notAuthorize = false;
	            			}
	            		}
	            	}
	            }
			}
			modelMap.addAttribute("notAuthorize", notAuthorize);
			//End
			modelMap.addAttribute("moduleType", moduleType);
			List<SelectItem> selSubModule = getSubModulSelectItem(clientId,moduleType,userType);
			List<SelectItem> selCompare = new ArrayList<SelectItem>(); // Status field 
    		selCompare.add(new SelectItem("Equal", 1));
    		selCompare.add(new SelectItem("Not Equal", 2));
    		selCompare.add(new SelectItem("Less than", 3));
    		selCompare.add(new SelectItem("Less than or equal", 4));
    		selCompare.add(new SelectItem("Greater than", 5));
    		selCompare.add(new SelectItem("Greater than or equal", 6));
    		selCompare.add(new SelectItem("Between", 7));
    		modelMap.addAttribute("selCompare", selCompare);
			modelMap.addAttribute("selSubModule", selSubModule);
			modelMap.addAttribute("currentDate",commonService.getServerDateTime());
			modelMap.addAttribute("eventId", eventId);
			modelMap.addAttribute("createdBy", createdBy);
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			//auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),(viewType == 1 ? viewAllQuestionAnswerLinkId :viewMyQuestionAnswerLinkId), (viewType == 1 ?messageSource.getMessage(MSG_VIEW_ALL_ANSWER, null,LocaleContextHolder.getLocale()):messageSource.getMessage("view_my_answer", null,LocaleContextHolder.getLocale())) + allPrebidQusAns, tenderId,0);
			auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),viewAllQuestionAnswerLinkId,getQusAnsTab, eventId,0);
		}
		return pageName; 
	}
	
	@RequestMapping(value="/questionanswerdata", method=RequestMethod.POST)
	public String questionAnswerData(@RequestParam("txtStatus")String status, 
				@RequestParam("txtPageNo") String pageNo,
				@RequestParam("hdObjectId") String objectId,
				@RequestParam("hdUserType") String userType,
				@RequestParam("hdNotAuthorize") boolean notAuthorize,
	    		HttpServletRequest request,ModelMap modelMap) throws NumberFormatException, Exception{
			String resultPage="",message="";
			//Change Request #22284 Start BugId:30903
			boolean notAuthorize1 = false;
			try{
				if(abcUtility.getSessionUserTypeId(request) == 3){
					boolean isQuestionAnswer = false;
					boolean isQAOfficerAllowed = false;
					List<String> field = new ArrayList<String>();
					field.add("isQuestionAnswer");
					field.add("isQueAnsOfficer");
					commonService.commontenderSummary(Integer.parseInt(objectId),modelMap,abcUtility.getSessionClientId(request));
					List<Object[]> lstClientConfigFields = commonService.getClientConfigurationFields(abcUtility.getSessionClientId(request),Integer.parseInt(modelMap.get("eventTypeId").toString()),field);
		            if (lstClientConfigFields != null) {
		                for (int i = 0; i < lstClientConfigFields.size(); i++) {
		                	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isQuestionAnswer") && Integer.parseInt(lstClientConfigFields.get(i)[4].toString()) == 1){
		                		isQuestionAnswer=true;
		                    }
		                	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isQueAnsOfficer") && Integer.parseInt(lstClientConfigFields.get(i)[4].toString()) == 1){
		                		isQAOfficerAllowed=true;
		                    }
		                }
		            }
		            if(isQuestionAnswer && isQAOfficerAllowed){
		            	List<TblQueAnsOfficer> officers =  departmentUserService.getTblQueAnsOfficer(abcUtility.getSessionClientId(request));
		            	for(TblQueAnsOfficer tblQueAnsOfficer : officers){
		            		if(tblQueAnsOfficer.getIsActive()==1){
		            			int userId = tblQueAnsOfficer.getTblUserLogin().getUserId();
		            			modelMap.addAttribute("officerEmailId",commonService.getEmailByUserId(userId));
		            			modelMap.addAttribute("personName",commonService.getUserName(userId));
		            		}
		            		if(tblQueAnsOfficer.getTblUserLogin().getUserId() == abcUtility.getSessionUserId(request)){
		            			if(tblQueAnsOfficer.getIsActive()==0){
		            				notAuthorize1 = true;
		            			}else{
		            				notAuthorize1 = false;
		            			}
		            		}
		            	}
		            }
				}
				//End
				if(status.equals("4")){
					resultPage="common/questionanswer/UploadClarificationListing";
					if(modelMap.get("submissionEndDate")!=null){
						Date d=dateUtils.convertStringtoDate(modelMap.get("submissionEndDate").toString(), CommonUtility.getClientDateFormat()+" HH:mm:ss");
						String result = dateUtils.convertStringtoDate(d,"MMMMM dd, yyyy hh:mm:ss a");
						modelMap.addAttribute("subEndDate",result);
					}else{
						modelMap.addAttribute("subEndDate","");
					}
					 int eventId = 0;
			            List<Object[]> eventIdlist = commonService.getEventIdFromLinkId(upload_clarificationLinkId);
			            if (eventIdlist != null && !eventIdlist.isEmpty()) {
			                eventId = (Integer) eventIdlist.get(0)[1];
			            }
					 List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, abcUtility.getSessionClientId(request));
					 int allowedSize = 0;
					 StringBuilder allowedExt = new StringBuilder();
					 if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
					 allowedSize = lstDocUploadConf.get(0).getMaxSize();
					 allowedExt.append(lstDocUploadConf.get(0).getType());
					 modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
					 }
					 int index = allowedExt.toString().indexOf(",");
					 allowedExt.insert(index + 1, "*.");
					 while (index >= 0) {
					 index = allowedExt.toString().indexOf(",", index + ",".length());
					 allowedExt.insert(index + 1, "*.");
					 }

					 
					 
					 modelMap.addAttribute("allowedExt", allowedExt);
					 modelMap.addAttribute("allowedSize", allowedSize / 1024);	
					
					 modelMap.addAttribute("objectIdNew", objectId);
					 modelMap.addAttribute("linkId", upload_clarificationLinkId);
					 List<Object[]> list=answerService.getTenderQAFields(Integer.parseInt(objectId));
					 Date submissionEndDate=(Date)list.get(0)[2];
					 Date serverdate=commonService.getServerDateTime();
					 if((submissionEndDate==null) || !(submissionEndDate.before(serverdate))){
						 modelMap.addAttribute("hideUploadLink",false);
						 modelMap.addAttribute("cStatusDoc", 5);
						 modelMap.addAttribute("cStatusDocView", 1);
						 if(notAuthorize){
							 modelMap.addAttribute("isReadOnly","Y");
							 modelMap.addAttribute("hideUploadLink",true);
							 modelMap.addAttribute("isTenderDocDownload", "Y");
							 modelMap.addAttribute("cStatusDoc",-1);
							 modelMap.addAttribute("cStatusDocView", -1);
						 }
					 }else if(submissionEndDate.before(serverdate)){
						 modelMap.addAttribute("isReadOnly","Y");
						 modelMap.addAttribute("hideUploadLink",true);
						 modelMap.addAttribute("isTenderDocDownload", "Y");
						 modelMap.addAttribute("cStatusDoc",-1);
						 modelMap.addAttribute("cStatusDocView", -1);
					 }
					 modelMap.addAttribute("submissionEndDate",submissionEndDate);
					 modelMap.put("moduleId", 3);
					 int sessionUserId = abcUtility.getSessionUserId(request); 
					 modelMap.addAttribute("mappedBy", sessionUserId);
					 modelMap.addAttribute("notAuthorize", notAuthorize1);
				}else{
					resultPage="common/questionanswer/OfficerQAListing";
					Long totalRecords =answerService.getCountQuestionAnswerByStatus(Integer.parseInt(status),Integer.parseInt(objectId),Integer.parseInt(userType));
			    	modelMap.addAttribute("quesAnsList", answerService.getQuestionAnswerByStatus(Integer.parseInt(status),pageNo,Integer.parseInt(objectId),Integer.parseInt(userType)));
			    	modelMap.addAttribute("totalRecords",totalRecords);
			    	int totalPages = (int) Math.ceil(totalRecords/(double)maxResult);
			    	modelMap.addAttribute("totalPages", totalPages);
			    	modelMap.addAttribute("notAuthorize", notAuthorize1);
				}
			}catch(Exception e){
				return exceptionHandlerService.writeLog(e);
			}finally{
				if("1".equals(status)){
					message = getUnAnsweredTab;
				}else if("2".equals(status)){
					message = getAnsweredTab;
				}else if("3".equals(status)){
					message = getAllTab;
				}else if("4".equals(status)){
					message = getClarificationDocumentQusAns;
				}
				auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),0,message, Integer.parseInt(objectId),0);
			}
			return resultPage;
	 }
	
	@RequestMapping(value="/questionanswersearchdata", method=RequestMethod.POST)
	public String questionAnswerSearchData(
				@RequestParam("hdObjectId") String objectId,
				@RequestParam("hdUserType") String userType,
				@RequestParam("txtUser") String userName,
				@RequestParam("txtKeywords") String keywords,
				@RequestParam("txtModule") String module,
				@RequestParam("txtPageNo") String pageNo,
				@RequestParam("txtStartDate") String startDate,
				@RequestParam("txtEndDate") String endDate,
				@RequestParam("hdStCmpId") String stCmpId,
	    		HttpServletRequest request,ModelMap modelMap) throws NumberFormatException, Exception{
		
	    	String resultPage="common/questionanswer/OfficerQAListing";
	    	String dateFrom = "";
	    	String dateTo="";
    		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    		if(startDate!=null && startDate!=""){
    			dateFrom = formatter.format(CommonUtility.getDateObj(startDate));
    		}
    		else{
    			stCmpId="0";
    		}
    		if(endDate!=null && endDate!=""){
    			dateTo = formatter.format(CommonUtility.getDateObj(endDate));
    		}
    		if("".equalsIgnoreCase(stCmpId)){
    			stCmpId="0";
			}
	    	Long totalRecords =answerService.getCountQuestionAnswerBySearch(Integer.parseInt(objectId),Integer.parseInt(userType),userName,keywords,module,Integer.parseInt(pageNo),dateFrom,dateTo,stCmpId);
	    	modelMap.addAttribute("quesAnsList", answerService.getQuestionAnswerBySearch(Integer.parseInt(objectId),Integer.parseInt(userType),userName,keywords,module,Integer.parseInt(pageNo),dateFrom,dateTo,stCmpId));
			//Change Request #22284 Start BugId:30903
	    	boolean notAuthorize = false;
			if(abcUtility.getSessionUserTypeId(request) == 3){
				boolean isQuestionAnswer = false;
				boolean isQAOfficerAllowed = false;
				List<String> field = new ArrayList<String>();
				field.add("isQuestionAnswer");
				field.add("isQueAnsOfficer");
				commonService.commontenderSummary(Integer.parseInt(objectId), modelMap, abcUtility.getSessionClientId(request));	
				List<Object[]> lstClientConfigFields = commonService.getClientConfigurationFields(abcUtility.getSessionClientId(request),Integer.parseInt(modelMap.get("eventTypeId").toString()),field);
	            if (lstClientConfigFields != null) {
	                for (int i = 0; i < lstClientConfigFields.size(); i++) {
	                	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isQuestionAnswer") && Integer.parseInt(lstClientConfigFields.get(i)[4].toString()) == 1){
	                		isQuestionAnswer=true;
	                    }
	                	if(lstClientConfigFields.get(i)[3].toString().equalsIgnoreCase("isQueAnsOfficer") && Integer.parseInt(lstClientConfigFields.get(i)[4].toString()) == 1){
	                		isQAOfficerAllowed=true;
	                    }
	                }
	            }
	            if(isQuestionAnswer && isQAOfficerAllowed){
	            	List<TblQueAnsOfficer> officers =  departmentUserService.getTblQueAnsOfficer(abcUtility.getSessionClientId(request));
	            	for(TblQueAnsOfficer tblQueAnsOfficer : officers){
	            		if(tblQueAnsOfficer.getIsActive()==1){
	            			int userId = tblQueAnsOfficer.getTblUserLogin().getUserId();
	            			modelMap.addAttribute("officerEmailId",commonService.getEmailByUserId(userId));
	            			modelMap.addAttribute("personName",commonService.getUserName(userId));
	            		}
	            		if(tblQueAnsOfficer.getTblUserLogin().getUserId() == abcUtility.getSessionUserId(request)){
	            			if(tblQueAnsOfficer.getIsActive()==0){
	            				notAuthorize = true;
	            			}else{
	            				notAuthorize = false;
	            			}
	            		}
	            	}
	            }
			}
	    	modelMap.addAttribute("notAuthorize",notAuthorize);
	    	//End
	    	modelMap.addAttribute("fromSearch",true);
	    	modelMap.addAttribute("totalRecords",totalRecords);
	    	int totalPages = (int) Math.ceil(totalRecords/(double)maxResult);
	    	modelMap.addAttribute("totalPages", totalPages);
	    	
	    	return resultPage;
	 
	 }
	private List<SelectItem> getBidderSelectItem(int eventId,int tenderMode) throws Exception{
		List<SelectItem> selBidder = new ArrayList<SelectItem>(); 
		if(tenderMode == 1){
			List<Object[]> TblTenderBidConfirmationByTenderId = answerService.getTblTenderBidConfirmationByTenderId(eventId);
			for (Object[] objects : TblTenderBidConfirmationByTenderId) {
				selBidder.add(new SelectItem(objects[1],objects[0]));	
			}
		}else {
			List<Object[]> TblTenderBidConfirmationByTenderId = answerService.getTblTenderBidderMapByTenderId(eventId);
			for (Object[] objects : TblTenderBidConfirmationByTenderId) {
				selBidder.add(new SelectItem(objects[1],objects[0]));	
			}
		}
		return selBidder;
	}

	private List<SelectItem> getSubModulSelectItem(int clientId, int moduleType,int userType) throws Exception {
		List<SelectItem> selSubModule = new ArrayList<SelectItem>(); // SubmoduleType
		List<Object[]> subModuleListData = answerService.getSubModule(clientId,moduleType);
     	for (Object[] objects : subModuleListData) {
     		if(userType == 0 || userType == 1 ) {
     			if(Integer.parseInt(objects[0].toString()) != prebidMeetingId) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     	} else if(userType == 2) {
	     		if(Integer.parseInt(objects[0].toString()) == bidOpeningId) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     		if(Integer.parseInt(objects[0].toString()) == bidEvaluationId) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     	} else if(userType == 3) {
	     		if(Integer.parseInt(objects[0].toString()) == bidOpeningId) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     	} else if(userType == 4) {
	     		if(Integer.parseInt(objects[0].toString()) == bidEvaluationId) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     	}
		}
		return selSubModule;
	}
	
	private List<SelectItem> getSubModulSelectItemForCommunication(int clientId, List<Integer> moduleType,int userType) throws Exception {
		List<SelectItem> selSubModule = new ArrayList<SelectItem>(); // SubmoduleType
		List<Object[]> subModuleListData = answerService.getSubModule(clientId,moduleType);
     	for (Object[] objects : subModuleListData) {
     		/*if(userType == 2) {
     			if(Integer.parseInt(objects[0].toString()) != prebidMeetingId) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
     			if(Integer.parseInt(objects[0].toString()) != 60) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     		if(Integer.parseInt(objects[0].toString()) != 61) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     	} else {
	     		if(Integer.parseInt(objects[0].toString()) != prebidMeetingIdgetSubModulSelectItemForCommunication) {
    				selSubModule.add(new SelectItem(objects[1],objects[0]));	
       		    }
	     	}*/
     		if(Integer.parseInt(objects[0].toString()) != 31) {
     			selSubModule.add(new SelectItem(objects[1],objects[0]));
     		}
     			
		}
		return selSubModule;
	}
	
	@RequestMapping(value = "/communication/view/{eventId}/{moduleType}/{createdBy}/{enc}", method = RequestMethod.GET)
	public String viewCommunication(@PathVariable("eventId") int eventId,@PathVariable("moduleType") int moduleType,@PathVariable("createdBy") int createdBy, ModelMap modelMap,HttpServletRequest request) {
		String pageName="common/questionanswer/CommunicationView";
		try {
			List<Integer> list = new ArrayList<Integer>();
			list.add(3);
			list.add(6);
			List<SelectItem> selSubModule = getSubModulSelectItemForCommunication(abcUtility.getSessionClientId(request),list,abcUtility.getSessionUserId(request));
			modelMap.addAttribute("selSubModule", selSubModule);
			modelMap.addAttribute("eventId", eventId);
			modelMap.addAttribute("createdBy", abcUtility.getSessionUserId(request));
			modelMap.addAttribute("moduleType", 4);
			commonService.commontenderSummary(eventId, modelMap, abcUtility.getSessionClientId(request));
			List<SelectItem> selBidder =  getBidderSelectItem(eventId,(Integer)modelMap.get("tenderMode"));
			modelMap.addAttribute("selBidder", selBidder);
			modelMap.addAttribute("userType", abcUtility.getSessionUserTypeId(request));
			if(abcUtility.getSessionUserTypeId(request) != 2){
				modelMap.addAttribute("questions",answerService.getQuestionsForOfficer(eventId));
			}else{
				modelMap.addAttribute("questions", answerService.getQuestionsForBidder(eventId,abcUtility.getSessionUserId(request)));
			}
			
			
			int linkid = 1182;
			int clientId = abcUtility.getSessionClientId(request);
			List<Object[]> eventIdlist = commonService.getEventIdFromLinkId(linkid);
            int eventIdNew = 0;
			if(eventIdlist!=null && !eventIdlist.isEmpty()){
				eventIdNew = Integer.parseInt(eventIdlist.get(0)[1].toString());
            }
            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventIdNew, clientId);
            int allowedSize = 0;
            StringBuilder allowedExt = new StringBuilder();
            if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
                allowedSize = lstDocUploadConf.get(0).getMaxSize();
                allowedExt.append(lstDocUploadConf.get(0).getType());
                modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
            }
            int index = allowedExt.toString().indexOf(",");
            allowedExt.insert(index + 1, "*.");
            while (index >= 0) {
                index = allowedExt.toString().indexOf(",", index + ",".length());
                allowedExt.insert(index + 1, "*.");
            }
            modelMap.addAttribute("linkId", linkid);
            modelMap.addAttribute("allowedExt", allowedExt);
            modelMap.addAttribute("allowedSize", allowedSize/1024);
            modelMap.addAttribute("cStatusDoc", 0);
            modelMap.addAttribute("cStatusDocView", 0); 
            modelMap.addAttribute("showCreatedBy", 0); 
         //   modelMap.addAttribute("isReadonly",1);
            modelMap.addAttribute("objectIdNew",0);
            
            
            modelMap.addAttribute("cStatusDoc", 5);
            modelMap.addAttribute("cStatusDocView", 1);
            modelMap.addAttribute("allowFileExist","Y");
            
            
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			// auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),(viewType == 1 ? viewAllQuestionAnswerLinkId :viewMyQuestionAnswerLinkId), (viewType == 1 ?messageSource.getMessage(MSG_VIEW_ALL_ANSWER, null,LocaleContextHolder.getLocale()):messageSource.getMessage("view_my_answer", null,LocaleContextHolder.getLocale())) + allPrebidQusAns, tenderId,0);
		}
		return pageName; 
	}
	@RequestMapping(value = "/communication/conversationhistory/{eventId}/{enc}", method = RequestMethod.GET)
	public String ConversationHistory(@PathVariable("eventId") int tenderId, ModelMap modelMap,HttpServletRequest request) {
		String pageName="common/questionanswer/ConversationHistory";
		try {
			if(abcUtility.getSessionUserTypeId(request) != 2){
				modelMap.addAttribute("questions",answerService.getQuestionsForOfficer(tenderId));
			}else{
				modelMap.addAttribute("questions", answerService.getQuestionsForBidder(tenderId,abcUtility.getSessionUserId(request)));
			}
			
			modelMap.addAttribute("officerDocsQue", answerService.getOfficerDocs(tenderId));
			modelMap.addAttribute("bidderDocsQue", answerService.getBidderDocs(tenderId));
			
			modelMap.addAttribute("eventId", tenderId);
			modelMap.addAttribute("moduleType", 4);
			modelMap.addAttribute("userType", abcUtility.getSessionUserTypeId(request));
			
			int linkid = 1182;
			int clientId = abcUtility.getSessionClientId(request);
			List<Object[]> eventIdlist = commonService.getEventIdFromLinkId(linkid);
            int eventId = 0;
			if(eventIdlist!=null && !eventIdlist.isEmpty()){
                eventId = Integer.parseInt(eventIdlist.get(0)[1].toString());
            }
            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, clientId);
            int allowedSize = 0;
            StringBuilder allowedExt = new StringBuilder();
            if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
                allowedSize = lstDocUploadConf.get(0).getMaxSize();
                allowedExt.append(lstDocUploadConf.get(0).getType());
                modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
            }
            int index = allowedExt.toString().indexOf(",");
            allowedExt.insert(index + 1, "*.");
            while (index >= 0) {
                index = allowedExt.toString().indexOf(",", index + ",".length());
                allowedExt.insert(index + 1, "*.");
            }
            modelMap.addAttribute("linkId", linkid);
            modelMap.addAttribute("allowedExt", allowedExt);
            modelMap.addAttribute("allowedSize", allowedSize/1024);
            modelMap.addAttribute("cStatusDoc", 0);
            modelMap.addAttribute("cStatusDocView", 0); 
            modelMap.addAttribute("showCreatedBy", 0); 
         //   modelMap.addAttribute("isReadonly",1);
            modelMap.addAttribute("objectIdNew",0);
            
            
            modelMap.addAttribute("cStatusDoc", 5);
            modelMap.addAttribute("cStatusDocView", 1);
            modelMap.addAttribute("allowFileExist","Y");
            
		} catch (Exception e) {
			return exceptionHandlerService.writeLog(e);
		} finally {
			// auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),(viewType == 1 ? viewAllQuestionAnswerLinkId :viewMyQuestionAnswerLinkId), (viewType == 1 ?messageSource.getMessage(MSG_VIEW_ALL_ANSWER, null,LocaleContextHolder.getLocale()):messageSource.getMessage("view_my_answer", null,LocaleContextHolder.getLocale())) + allPrebidQusAns, tenderId,0);
		}
		return pageName; 
	}
	@RequestMapping(value = "/question/postQuestionForCommunication", method = RequestMethod.POST)
	public String postQuestionForCommunication(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes)
			throws Exception {
		boolean isSuccess = false;
		int eventId = Integer.parseInt(request.getParameter("hdEventId").toString());
		int moduleId = Integer.parseInt(request.getParameter("selSubModule").toString());
		int moduleType = Integer.parseInt(request.getParameter("hdModuleType").toString());
		int userType = Integer.parseInt(request.getParameter("hdUserType").toString());
		String[] arrayBidders = request.getParameterValues("selBidder");
		List<String> bidders = null;
		if(userType != 2){
			bidders =  Arrays.asList(arrayBidders);
		}else {
			bidders =  new ArrayList<String>();
		}
		String redirectMsg = "lbl_question_post";
		String strQuery = (request.getParameter("txtaQuestion") != null ? request
				.getParameter("txtaQuestion").toString() : "");
		String txtHidDocIds = (request.getParameter("txtHidDocIds") != null ? request
				.getParameter("txtHidDocIds").toString() : "");
		if (!strQuery.trim().equals("")) {
			if(bidders.size() > 0){
				for (String bidder : bidders) {
					int bidderId = Integer.parseInt(bidder);
					
					TblQuestion tblQuestion = new TblQuestion();
					tblQuestion.setModuleType(moduleType);
					tblQuestion.setParentQuestionId(0);
					tblQuestion.setTblSubModule(new TblSubModule(moduleId));
					tblQuestion.setCstatus(0);
					tblQuestion.setQuestionText(strQuery);
					tblQuestion.setObjectId(eventId);
					tblQuestion.setTblUserLogin(new TblUserLogin(abcUtility.getSessionUserId(request)));
					tblQuestion.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
					tblQuestion.setUserTypeId(abcUtility.getSessionUserTypeId(request));
					if(abcUtility.getSessionUserTypeId(request) != 2){
						tblQuestion.setParentId(loginService.getBidderUserDetailId(bidderId));
					}
					
					isSuccess = answerService.addTblQuestion(tblQuestion);
					if(isSuccess){
						if (!"".equalsIgnoreCase(txtHidDocIds)) {
							if(abcUtility.getSessionUserTypeId(request) != 2){
								List<Integer> docIds = new ArrayList<Integer>(); 
						        for (int i = 0; i < txtHidDocIds.split(",").length; i++) {
									docIds.add(Integer.parseInt(txtHidDocIds.split(",")[i]));
								}
						        for (Integer integer : docIds) {
						        	TblOfficerDocMapping docMapping = fileUploadService.getTblOfficerDocMappingById(integer);
									docMapping.setOfficerDocMappingId(0);
									docMapping.setObjectId(tblQuestion.getQuestionId());
									docMapping.setChildId(eventId);
									fileUploadService.addOfficerDocMapping(docMapping);
								}
								//fileUploadService.updateOfficerDocsObjectIdAndChildId(txtHidDocIds, tblQuestion.getQuestionId(),eventId);
							}else{
								
								fileUploadService.updateBidderDocsObjectIdAndChildId(txtHidDocIds, tblQuestion.getQuestionId(),eventId);
							}
				            
				        }
					}
					
					
					TblAnswer tblAnswerDetail = new TblAnswer();
					tblAnswerDetail.setAnswerText("");
					tblAnswerDetail.setCstatus(0);
					tblAnswerDetail.setTblQuestion(new TblQuestion(tblQuestion.getQuestionId()));
					tblAnswerDetail.setTblUserLogin(new TblUserLogin(bidderId));
					tblAnswerDetail.setTblUserDetail(new TblUserDetail(loginService.getBidderUserDetailId(bidderId)));
					tblAnswerDetail.setUserTypeId(commonService.getUserTypeId(bidderId));
					
					isSuccess = answerService.addTblAnswer(tblAnswerDetail);
				}
			}else{
				TblQuestion tblQuestion = new TblQuestion();
				tblQuestion.setModuleType(moduleType);
				tblQuestion.setParentQuestionId(0);
				tblQuestion.setTblSubModule(new TblSubModule(moduleId));
				tblQuestion.setCstatus(0);
				tblQuestion.setQuestionText(strQuery);
				tblQuestion.setObjectId(eventId);
				tblQuestion.setTblUserLogin(new TblUserLogin(abcUtility.getSessionUserId(request)));
				tblQuestion.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
				tblQuestion.setUserTypeId(abcUtility.getSessionUserTypeId(request));
				isSuccess = answerService.addTblQuestion(tblQuestion);
				if(isSuccess){
					if (!"".equalsIgnoreCase(txtHidDocIds)) {
						if(abcUtility.getSessionUserTypeId(request) != 2){
							fileUploadService.updateOfficerDocsObjectIdAndChildId(txtHidDocIds, tblQuestion.getQuestionId(),eventId);
						}else{
							fileUploadService.updateBidderDocsObjectIdAndChildId(txtHidDocIds, tblQuestion.getQuestionId(),eventId);
						}
			            
			        }
				}
			}
			
			
		} 
		if(isSuccess){
			redirectAttributes.addFlashAttribute(isSuccess ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isSuccess ? redirectMsg : CommonKeywords.ERROR_MSG_KEY.toString());
			Set<Integer> integers = new HashSet<Integer>();
			List<TblSubModule> listForQue = commonService.getSubModuleBySubModuleIdId(moduleId);
			String eventName = "";
			if(listForQue != null && listForQue.size() > 0){
				eventName = listForQue.get(0).getLang1();
			}
			if(userType == 2){
				Map<String, Object> mapForTender = new HashMap<String, Object>();
				commonService.commontenderSummary(eventId, mapForTender, abcUtility.getSessionClientId(request));
				integers.add((Integer)mapForTender.get("assignUserId"));
				integers.add((Integer)mapForTender.get("officerId"));
				sendMessage(eventId,userType,request,new ArrayList<Integer>(integers),246,eventName);
			}else{
				if(bidders.size() > 0){
					for (String bidder : bidders) {
						int bidderId = Integer.parseInt(bidder);
						integers.add(bidderId);
					}
					sendMessage(eventId,userType,request,new ArrayList<Integer>(integers),246,eventName);
				}
			}
		}
		//String ret="common/communication/view/"+eventId+"/"+moduleType+"/"+abcUtility.getSessionUserDetailId(request);
		String ret="etender/buyer/tenderdashboard/"+eventId+"/16";
		if(userType == 2){
			ret="etender/bidder/biddingtenderdashboard/"+eventId+"/16";
		}
		String retval="redirect:/"+ret+encryptDecryptUtils.generateRedirect(ret,request);
		return retval;
	}
	
	private void sendMessage(int eventId,int userType,HttpServletRequest request,List<Integer> toUsers,int templateId,String EventType) throws Exception{
		String encryptUrlStr = "";
		encryptUrlStr = encryptDecryptUtils.encrypt("common/communication/conversationhistory/"+eventId);
        String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>";
        Map<String, Object> mailParams = new HashMap<String, Object>();
        MessageConfigDatabean messageConfigDatabean = new MessageConfigDatabean();
        messageConfigDatabean.setQueueName(queueName);
        messageConfigDatabean.setTemplateId(templateId);
        messageConfigDatabean.setUserId(abcUtility.getSessionUserId(request));
        messageConfigDatabean.setClientId(abcUtility.getSessionClientId(request));
        messageConfigDatabean.setObjectId(eventId);
        messageConfigDatabean.setUrlStr(request.getRequestURL().toString());
        messageConfigDatabean.setContextPath(request.getContextPath());
        //String CCEmailIds = "manoj.gadhavi@localmail.com";
        //messageConfigDatabean.setCc(CCEmailIds);
        mailParams.put("eventId", eventId);
        mailParams.put("eventType", EventType);
        String userName = "";
        Object[] lstUserDetail = null;
        if(abcUtility.getSessionUserTypeId(request) != 2){
        	lstUserDetail = loginService.getUserDetailIdByUserIdAndClientId(abcUtility.getSessionUserId(request),abcUtility.getSessionClientId(request));
        }else{
        	lstUserDetail = loginService.getUserDetailId(abcUtility.getSessionUserId(request));
        }
        if(lstUserDetail != null){
        	userName = lstUserDetail[4].toString();
        }
        mailParams.put("userId", userName);
        mailParams.put("link", hrefStr);
        int clientId = abcUtility.getSessionClientId(request);
        String DomainName="<a href=\"#\" onClick=\"viewMailLinkDetails(' " + clientService.getClientNameById (clientId) + " ');\">"+clientService.getClientNameById (clientId)+"</a>";
        mailParams.put("URL", DomainName);
        mailParams.put("SubDomainName", DomainName);
        for (Integer loginId : toUsers) {
            mailParams.put("to", commonService.getUserLoginById(loginId).get(0).getLoginId());
            messageConfigDatabean.setParamMap(mailParams);
            messageQueueService.sendMessage(messageConfigDatabean);
        }
	}
	@RequestMapping(value = "/answer/getConversation", method = RequestMethod.POST)
	public String getConversation(@RequestParam("txtQuestionId") int questionId , ModelMap modelMap,HttpServletRequest request) throws Exception {
		
		modelMap.addAttribute("answerlist", answerService.getConversation(questionId));
		List<Object[]> objects = answerService.getQuestionAnswerByQid(questionId);
		int objectId = 0;
		if(objects != null && objects.size() > 0){
			objectId = (Integer)objects.get(0)[5];
		}
		modelMap.addAttribute("officerDocs", answerService.getOfficerDocs(objectId));
		modelMap.addAttribute("bidderDocs", answerService.getBidderDocs(objectId));
		modelMap.addAttribute("userType", abcUtility.getSessionUserTypeId(request));
		return "common/questionanswer/getAnswers";
	}
	
	@RequestMapping(value = "/answer/postConversation", method = RequestMethod.POST)
	public String postConversation(@RequestParam("txtQuestionId") int questionId ,@RequestParam("txtAnswer") String txtAnswer,@RequestParam("txtHidDocIds") String txtHidDocIds , ModelMap modelMap,HttpServletRequest request) throws Exception {
		TblAnswer tblAnswerDetail = new TblAnswer();
			
		List<TblAnswer> tblAnswers = answerService.getTblAnswerByquestionIdAndtblUserLoginAndCstatus(questionId, abcUtility.getSessionUserId(request), 0);
		if(tblAnswers != null && tblAnswers.size() > 0){
			tblAnswerDetail = tblAnswers.get(0);
			tblAnswerDetail.setAnswerText(txtAnswer);
			tblAnswerDetail.setCstatus(1);
		}else{
			tblAnswerDetail.setAnswerText(txtAnswer);
			tblAnswerDetail.setCstatus(1);
			tblAnswerDetail.setTblQuestion(new TblQuestion(questionId));
			tblAnswerDetail.setTblUserLogin(new TblUserLogin(abcUtility.getSessionUserId(request)));
			tblAnswerDetail.setTblUserDetail(new TblUserDetail(abcUtility.getSessionUserDetailId(request)));
			tblAnswerDetail.setUserTypeId(abcUtility.getSessionUserTypeId(request));
		}
		boolean success = answerService.saveOrUpdateTblAnswer(tblAnswerDetail);
		List<Object[]> listForQue = answerService.getQuestionAnswerByQid(questionId);
		int eventId = 0;
		String eventName = "";
		if(listForQue != null && listForQue.size() > 0){
			eventId = (Integer)listForQue.get(0)[5];
			eventName = listForQue.get(0)[4].toString();
		}
		if(success){
			Set<Integer> integers = new HashSet<Integer>();
			if(abcUtility.getSessionUserTypeId(request) == 2){
				Map<String, Object> mapForTender = new HashMap<String, Object>();
				commonService.commontenderSummary(eventId, mapForTender, abcUtility.getSessionClientId(request));
				integers.add((Integer)mapForTender.get("assignUserId"));
				integers.add((Integer)mapForTender.get("officerId"));
				sendMessage(eventId,abcUtility.getSessionUserTypeId(request),request,new ArrayList<Integer>(integers),247,eventName);
			}else {
				TblQuestion tblQuestion = answerService.getTblQuestionById(questionId);
				if(tblQuestion != null){
					if(tblQuestion.getUserTypeId() == 2){
						integers.add(tblQuestion.getTblUserLogin().getUserId());
					}else{
						//integers.add(tblQuestion.getParentId());
						List<Object[]> list = answerService.getAnswerByQuestionIdAndUserType(questionId, 2) ;
						for (Object[] objects : list) {
							integers.add((Integer)objects[0]);
						}
					}
				}
				if(integers != null && integers.size() > 0){
					sendMessage(eventId,abcUtility.getSessionUserTypeId(request),request,new ArrayList<Integer>(integers),247,eventName);
				}
			}
			
		}
		modelMap.addAttribute("answerlist", answerService.getConversation(questionId));
		
		List<Object[]> objects = answerService.getQuestionAnswerByQid(questionId);
		int objectId = 0;
		if(objects != null && objects.size() > 0){
			objectId = (Integer)objects.get(0)[5];
		}
		if (!"".equalsIgnoreCase(txtHidDocIds)) {
			if(abcUtility.getSessionUserTypeId(request) != 2){
				fileUploadService.updateOfficerDocsObjectIdAndChildId(txtHidDocIds, tblAnswerDetail.getAnswerId(),objectId);
			}else{
				fileUploadService.updateBidderDocsObjectIdAndChildId(txtHidDocIds, tblAnswerDetail.getAnswerId(),objectId);
			}
            
        }
	
		modelMap.addAttribute("officerDocs", answerService.getOfficerDocs(eventId));
		modelMap.addAttribute("bidderDocs", answerService.getBidderDocs(eventId));
		
		return "common/questionanswer/getAnswers";
	}

}
