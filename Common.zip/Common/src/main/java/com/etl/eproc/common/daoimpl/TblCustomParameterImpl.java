package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblCustomParameterDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblCustomParameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCustomParameterImpl extends AbcAbstractClass<TblCustomParameter> implements TblCustomParameterDao {

    @Override
    public void addTblCustomParameter(TblCustomParameter tblCustomParameter){
        super.addEntity(tblCustomParameter);
    }

    @Override
    public void deleteTblCustomParameter(TblCustomParameter tblCustomParameter) {
        super.deleteEntity(tblCustomParameter);
    }

    @Override
    public void updateTblCustomParameter(TblCustomParameter tblCustomParameter) {
        super.updateEntity(tblCustomParameter);
    }

    @Override
    public List<TblCustomParameter> getAllTblCustomParameter() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCustomParameter> findTblCustomParameter(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCustomParameterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCustomParameter> findByCountTblCustomParameter(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCustomParameter(List<TblCustomParameter> tblCustomParameters){
        super.updateAll(tblCustomParameters);
    }
}
