package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblExceptionLogDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblExceptionLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblExceptionLogImpl extends AbcAbstractClass<TblExceptionLog> implements TblExceptionLogDao {

    @Override
    public void addTblExceptionLog(TblExceptionLog tblExceptionLog){
        super.addEntity(tblExceptionLog);
    }

    @Override
    public void deleteTblExceptionLog(TblExceptionLog tblExceptionLog) {
        super.deleteEntity(tblExceptionLog);
    }

    @Override
    public void updateTblExceptionLog(TblExceptionLog tblExceptionLog) {
        super.updateEntity(tblExceptionLog);
    }

    @Override
    public List<TblExceptionLog> getAllTblExceptionLog() {
        return super.getAllEntity();
    }

    @Override
    public List<TblExceptionLog> findTblExceptionLog(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblExceptionLogCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblExceptionLog> findByCountTblExceptionLog(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblExceptionLog(List<TblExceptionLog> tblExceptionLogs){
        super.updateAll(tblExceptionLogs);
    }
}
