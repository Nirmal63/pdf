package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblBankGuarantee;
import com.etl.eproc.common.daointerface.TblBankGuaranteeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBankGuaranteeImpl extends AbcAbstractClass<TblBankGuarantee> implements TblBankGuaranteeDao {

    @Override
    public void addTblBankGuarantee(TblBankGuarantee tblBankGuarantee){
        super.addEntity(tblBankGuarantee);
    }

    @Override
    public void deleteTblBankGuarantee(TblBankGuarantee tblBankGuarantee) {
        super.deleteEntity(tblBankGuarantee);
    }

    @Override
    public void updateTblBankGuarantee(TblBankGuarantee tblBankGuarantee) {
        super.updateEntity(tblBankGuarantee);
    }

    @Override
    public List<TblBankGuarantee> getAllTblBankGuarantee() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBankGuarantee> findTblBankGuarantee(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBankGuaranteeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBankGuarantee> findByCountTblBankGuarantee(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBankGuarantee(List<TblBankGuarantee> tblBankGuarantees){
        super.updateAll(tblBankGuarantees);
    }
}
