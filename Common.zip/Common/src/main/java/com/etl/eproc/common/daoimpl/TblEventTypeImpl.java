package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblEventTypeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblEventType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblEventTypeImpl extends AbcAbstractClass<TblEventType> implements TblEventTypeDao {

    @Override
    public void addTblEventType(TblEventType tblEventType){
        super.addEntity(tblEventType);
    }

    @Override
    public void deleteTblEventType(TblEventType tblEventType) {
        super.deleteEntity(tblEventType);
    }

    @Override
    public void updateTblEventType(TblEventType tblEventType) {
        super.updateEntity(tblEventType);
    }

    @Override
    public List<TblEventType> getAllTblEventType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblEventType> findTblEventType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblEventTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblEventType> findByCountTblEventType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblEventType(List<TblEventType> tblEventTypes){
        super.updateAll(tblEventTypes);
    }
}
