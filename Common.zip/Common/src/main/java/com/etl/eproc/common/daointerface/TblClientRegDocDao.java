package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientRegDoc;
import java.util.List;

public interface TblClientRegDocDao  {

    public void addTblClientRegDoc(TblClientRegDoc tblClientRegDoc);

    public void deleteTblClientRegDoc(TblClientRegDoc tblClientRegDoc);

    public void updateTblClientRegDoc(TblClientRegDoc tblClientRegDoc);

    public List<TblClientRegDoc> getAllTblClientRegDoc();

    public List<TblClientRegDoc> findTblClientRegDoc(Object... values) throws Exception;

    public List<TblClientRegDoc> findByCountTblClientRegDoc(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientRegDocCount();

    public void saveUpdateAllTblClientRegDoc(List<TblClientRegDoc> tblClientRegDocs);
}