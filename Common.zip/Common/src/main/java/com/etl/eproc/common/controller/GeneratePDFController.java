/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.awt.Rectangle;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.fusesource.hawtbuf.ByteArrayInputStream;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;
import org.xhtmlrenderer.pdf.ITextRenderer;
import org.zefer.pd4ml.PD4Constants;
import org.zefer.pd4ml.PD4ML;
import org.zefer.pd4ml.PD4PageMark;

import com.etl.eproc.common.model.TblAuditTrail;
import com.etl.eproc.common.model.TblClientServiceStatus;
import com.etl.eproc.common.model.TblClientServiceUrl;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.utility.AbcHttpUtil;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.FileEncryptDecryptUtil;
import com.etl.eproc.common.utility.SendMessageUtil;
import com.etl.eproc.vendor.services.VendorEnlistmentService;
import com.itextpdf.text.Image;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfGState;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfSignatureAppearance;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.security.BouncyCastleDigest;
import com.itextpdf.text.pdf.security.CertificateInfo;
import com.itextpdf.text.pdf.security.DigestAlgorithms;
import com.itextpdf.text.pdf.security.ExternalDigest;
import com.itextpdf.text.pdf.security.ExternalSignature;
import com.itextpdf.text.pdf.security.MakeSignature;
import com.itextpdf.text.pdf.security.MakeSignature.CryptoStandard;
import com.itextpdf.text.pdf.security.PrivateKeySignature;
import com.itextpdf.text.pdf.security.CertificateInfo.X500Name;
import com.lowagie.text.DocumentException;
import com.lowagie.text.pdf.BaseFont;

/*
 * @author TaherT
 */
@Controller
public class GeneratePDFController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private FileEncryptDecryptUtil fileEncryptDecryptUtil;
    @Autowired
    private AbcHttpUtil abcHttpUtil;
    @Autowired    
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private VendorEnlistmentService vendorEnlistmentService;
    
    /*@Autowired
    private AuctionService auctionService;*/
    @Autowired
    private CommonService commonService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Value("#{projectProperties['queue_mail']?:'mailQueue'}")
    private String queueName;
    private @Value("#{projectProperties['file.drive']}")
    String strDriveLetter;
    private @Value("#{projectProperties['pdf.upload']}")
    String path;
    private @Value("#{projectProperties['tport']?:8081}")
    int tPort;
    private @Value("#{projectProperties['internal_ip']}")
    String internalIp;
    @Value("#{projectProperties['logo.server.path']}")
    private String logoserverpath;
    @Value("#{projectProperties['logo.server.context.path']}")
    private String logoservercontextpath;
    @Value("#{projectProperties['file.drive']}")
    private String fileDrive;
    @Value("#{projectProperties['file.winningletter']}")
    private String winningLetter;
    private boolean isPathForApacheServer = true; // true for apache, false for tomcat
    @Value("#{projectProperties['doc_upload_path']}")
    private String docUploadPath;
    @Value("#{clientProperties['multiLanguageSupportRequiredInPDF']}")
    private String multiLanguageSupportRequiredInPDF;
    @Value("#{linkProperties['PDF_linkId']}")
    private int PdfLinkId;
    @Value("#{linkProperties['Excel_linkId']}")
    private int ExcelLinkId;
    @Value("#{linkProperties['Print_linkId']}")
    private int PrintLinkId;
    @Value("#{linkProperties['Html_linkId']}")
    private int HtmlLinkId;
    @Value("#{linkProperties['Word_linkId']}")
    private int WordLinkId;
    @Value("#{projectProperties['pdf_signature_certificate_alias']}")
    private String pdfSignatureCertificateAlias;
    @Value("#{projectProperties['pdf_signature_required']}")
    private boolean pdfSignatureRequired;
    @Value("#{projectProperties['notification.mailto']}")
    private String notificationMailTo;
    @Autowired
	private MessageSource messageSource;
	@Autowired
	ServletContext servletContext;
    @Autowired
    private SendMessageUtil sendMessageUtil;
	private static final String X_FORWARDED_FOR = "X-FORWARDED-FOR";
    boolean multiLanguageSupportRequired=false;
    
    /**
     * Generate pdf
     * @author bharat
     * @param request
     * @param response
     */
    
    @RequestMapping(value = "/generatepdf", method = RequestMethod.POST)
    public void generatePDF(HttpServletRequest request, HttpServletResponse response) {
        	int linkId=0;
        	TblAuditTrail auditMaster=null;
        	String remarks="";
            String ipAdd = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
        try {
        	int generateType =  StringUtils.hasLength(request.getParameter("txtGenerateType")) ? Integer.parseInt(request.getParameter("txtGenerateType")) : 0;
        	String pdfBuffer = setFileDefaultData(request);
            String fileName = request.getParameter("hdfileName");
            String id = request.getParameter("hdid");
            String url= request.getParameter("forwardUrl");
            remarks = generateType == 0 || generateType == 1 ? messageSource.getMessage("pdf_remark",null,LocaleContextHolder.getLocale()) : generateType == 4 ? messageSource.getMessage("excel_remark",null,LocaleContextHolder.getLocale()) : generateType == 2 ? messageSource.getMessage("html_remark",null,LocaleContextHolder.getLocale()) : generateType == 3 ? messageSource.getMessage("word_remark",null,LocaleContextHolder.getLocale()) : messageSource.getMessage("print_remark",null,LocaleContextHolder.getLocale());
            linkId = generateType == 0 || generateType == 1 ? PdfLinkId : generateType == 4 ? ExcelLinkId : generateType == 2 ? HtmlLinkId : generateType == 3 ? WordLinkId : PrintLinkId;
                       
            auditMaster = (TblAuditTrail) request.getAttribute(CommonKeywords.AUDIT_BEAN.toString());
            auditMaster.setPageUrl(url);
                        
           /* 
            * ValidationResponse validationpdfBufferForHtml = new ValidatorBuilder().html().validate(pdfBuffer);
           */
            if (StringUtils.hasLength(pdfBuffer) && StringUtils.hasLength(fileName) && StringUtils.hasLength(id)) {
                reportGeneration(pdfBuffer, fileName, (strDriveLetter + path), id,generateType, response, request);
            } else {
                response.sendRedirect(request.getHeader("referer"));
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally{
        	auditTrailService.makeAuditTrail(auditMaster, linkId, remarks, ipAdd, 0, 0);
        }
    }
    
    /**
     * Generate pdf for print
     * @author bharat
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/generatePDFForPrint", method = RequestMethod.POST)
    @ResponseBody
    public String generatePDFForPrint(HttpServletRequest request, HttpServletResponse response) {
    	String absolutePath="";
        TblAuditTrail auditMaster= null;
        String remarks="";
        String ipAdd = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
    	try {
        	int generateType =  StringUtils.hasLength(request.getParameter("txtGenerateType")) ? Integer.parseInt(request.getParameter("txtGenerateType")) : 0;
        	String pdfBuffer = setFileDefaultData(request);
            String fileName = request.getParameter("hdfileName");
            String id = request.getParameter("hdid");
            String url= request.getParameter("forwardUrl");
            absolutePath  = request.getServletContext().getRealPath(File.separator);
            remarks= generateType == 0 ? messageSource.getMessage("pdf_remark",null,LocaleContextHolder.getLocale()) : generateType == 4 ? messageSource.getMessage("excel_remark",null,LocaleContextHolder.getLocale()) : messageSource.getMessage("print_remark",null,LocaleContextHolder.getLocale()); 
            if(isPathForApacheServer){            // for working with Apache Start
	            if(logoservercontextpath.indexOf("\\") != -1){ // this will execute only once, after that global variable value will be change. 
	            	logoservercontextpath = logoservercontextpath.substring(0,logoservercontextpath.indexOf("\\"));
	            }
	            absolutePath    = logoserverpath+"\\"+request.getContextPath().replace("/", "")+"\\"+logoservercontextpath+"\\tempfile";
            }else{             // for working with tomcat  
            	absolutePath   += "\\resources\\tempfile";
            }
            
            auditMaster = (TblAuditTrail) request.getAttribute(CommonKeywords.AUDIT_BEAN.toString());
            auditMaster.setPageUrl(url);
            
            File tempfileObj = new File(absolutePath);
            if (tempfileObj.exists() == false) {
            	tempfileObj.mkdirs();
            }
            File file = new File(absolutePath +"\\"+ fileName + ".pdf");
            deleteIfExist(file);
            if (StringUtils.hasLength(pdfBuffer) && StringUtils.hasLength(fileName) && StringUtils.hasLength(id)) {
            	absolutePath = pdfGenerationForPrint(pdfBuffer,fileName, file , id,generateType, response, request);
            } else {
                response.sendRedirect(request.getHeader("referer"));
            }
            
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }finally{
        	auditTrailService.makeAuditTrail(auditMaster, PrintLinkId, remarks, ipAdd, 0, 0);
        }
        return absolutePath;
    }
    /**
     * Generate PDF of H1Bidder
     * @author keval.soni
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/generatePDFForMail", method = RequestMethod.POST)
    @ResponseBody
    public String generatePDFForMail(HttpServletRequest request, HttpServletResponse response) {
    	String absolutePath="",filePath="";
    	TblAuditTrail auditMaster =null;
    	String ipAdd = request.getHeader(X_FORWARDED_FOR) != null ? request.getHeader(X_FORWARDED_FOR) : request.getRemoteAddr();
        try {
        	int generateType =  StringUtils.hasLength(request.getParameter("txtGenerateType")) ? Integer.parseInt(request.getParameter("txtGenerateType")) : 0;
        	String pdfBuffer = setFileDefaultDataForWinningLetterPDF(request);
            String fileName = request.getParameter("fileName");
            String url = request.getParameter("forwardUrl");
            String[] actId = fileName.split("_");
            int auctionId = Integer.parseInt(actId[0]);
            String id = request.getParameter("hdid");
            absolutePath = fileDrive +"\\"+ winningLetter +"\\"+ auctionId;
            auditMaster = (TblAuditTrail) request.getAttribute(CommonKeywords.AUDIT_BEAN.toString());
            auditMaster.setPageUrl(url);
            File tempfileObj = new File(absolutePath);
            if (tempfileObj.exists() == false) {
            	tempfileObj.mkdirs();
            }
	    	  File file = new File(absolutePath +"\\"+ actId[1] + ".pdf");
	    	  filePath = winningLetter +"\\"+ auctionId +"\\"+ actId[1] + ".pdf";
	          deleteIfExist(file);
	          if (StringUtils.hasLength(pdfBuffer) && StringUtils.hasLength(actId[1]) && StringUtils.hasLength(id)) {
	        	  absolutePath = pdfGenerationForMail(pdfBuffer,actId[1], file , id,generateType, response, request);
	          } else {
	              response.sendRedirect(request.getHeader("referer"));
	          }
	          absolutePath = file.getAbsolutePath();
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }finally {
        	auditTrailService.makeAuditTrail(auditMaster, PdfLinkId, messageSource.getMessage("PDF_ForMail_remark",null,LocaleContextHolder.getLocale()), ipAdd, 0, 0);
        }
        return filePath;
    }
    @RequestMapping(value = "/ajaxcall/deleteFile", method = RequestMethod.POST)
    @ResponseBody
    public String DeleteFile(@RequestParam("filePath") String filePath) {
    	File file = new File(filePath);
        deleteIfExist(file);
    	return filePath;
    }
    /**
   * 
   * @author bharat
   * @param request
   * @return
   * @throws MalformedURLException
   */
	private String setFileDefaultData(HttpServletRequest request) throws MalformedURLException {
    	  String parentDeptName = "";
          String domainName = "";
          ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
          int generateType =  StringUtils.hasLength(request.getParameter("txtGenerateType")) ? Integer.parseInt(request.getParameter("txtGenerateType")) : 0;
          if(clientBean.getClientInfo() != null ){
              parentDeptName = (String) clientBean.getClientInfo().split(":")[0];
              domainName = (String) clientBean.getClientInfo().split(":")[1];
          }
          String clientName ="";
          URL url = new URL(request.getRequestURL().toString());
          
          StringBuilder verifyUrlPrefix=new StringBuilder();
          if(generateType == 0 || generateType == 1 || generateType == 5) {
              verifyUrlPrefix.append(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "http").append("://").append(internalIp);
          } else if (generateType == 2) {
	          verifyUrlPrefix.append(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "https").append("://").append(url.getHost());
	          if ((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) {
	              verifyUrlPrefix.append(":").append(url.getPort());
	          }else{
	        	  
	          }
          }
          
          verifyUrlPrefix.append(request.getContextPath()).append("/resources/static-images/Logo/").append(abcUtility.getSessionClientId(request));
          verifyUrlPrefix.append("/").append(WebUtils.getCookie(request, "logo").getValue());
          String clientTheme = abcUtility.getCookieValueByCookieName(request, "theme");
          if(clientTheme.equalsIgnoreCase("theme-2"))
          {	  
        	  String themeLogo = "";
	          if (request.getParameter("hdisCustomLandScap") != null && !request.getParameter("hdisCustomLandScap").equals("")) {
	        	  if(generateType==0 || generateType==1 || generateType==2 || generateType == 5){
	        		  themeLogo="<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td class=\"v-a-middle a-center\"><div class=\"a-center\">"+"<img width=\"100%\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</div></td></tr></table>";
	                } 
	        	  	clientName+="<div class=\"print-pdf main_container o-hidden\" id=\"temp\"><div class=\"container_25 o-hidden border-right\">" +
	                 		"<div class=\"content_section\"><section class=\"inner-right-bar pull-left grid_26 border-left\" id=\"print_area\">"+ themeLogo +"<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td width=\"10%\" class=\"black\">Domain :</td><td width=\"35%\">" +
	                  domainName + "</td>";
	                 clientName+="</tr><tr><td class=\"black\">Parent department:</td><td width=\"75%\">"+parentDeptName+"</td></tr></table></section>";
	
	          } else if (request.getParameter("dynPageSize") != null && !request.getParameter("dynPageSize").equals("")) {
	        	  	if(generateType==0 || generateType==1 || generateType==2 || generateType == 5){
	        		  themeLogo="<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td class=\"v-a-middle a-center\"><div class=\"a-center\">"+"<img width=\"100%\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</div></td></tr></table>";
	                } 
	        	    clientName+="<div class=\"print-pdf main_container o-hidden\" id=\"temp\"><div class=\"container_25 o-hidden border-right\">" +
	                 		"<div class=\"content_section\"><section class=\"inner-right-bar pull-left grid_26 border-left\" id=\"print_area\" >" + themeLogo + "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td width=\"10%\" class=\"black\">Domain :</td><td width=\"35%\">" +
	                  domainName + "</td>";
	                 clientName+="</tr><tr><td class=\"black\">Parent department:</td><td width=\"35%\">"+parentDeptName+"</td></tr></table></section>";
	          }else{
	        	    if(generateType==0 || generateType==1 || generateType==2 || generateType == 5){
	        		  themeLogo="<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td class=\"v-a-middle a-center\"><div class=\"a-center\">"+"<img width=\"100%\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</div></td></tr></table>";
	                } 
        	  	  	clientName+="<div class=\"main_container o-hidden\" id=\"temp\"><div class=\"container_25 o-hidden border-right\"><div class=\"content_section\"><section class=\"inner-right-bar grid_26 border-left\" id=\"print_area\">"+ themeLogo +"<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td class=\"black\" width=\"10%\">Domain :</td><td width=\"40%\">" +
                    domainName + "</td>";
                    clientName+="</tr><tr><td class=\"black\">Parent department:</td><td>"+parentDeptName+"</td></tr></table></section>";
	          }
          }else{
	          if (request.getParameter("hdisCustomLandScap") != null && !request.getParameter("hdisCustomLandScap").equals("")) {
	                 clientName+="<div class=\"print-pdf main_container o-hidden\" id=\"temp\"><div class=\"container_25 o-hidden border-right\">" +
	                 		"<div class=\"content_section\"><section class=\"inner-right-bar pull-left grid_26 border-left\" id=\"print_area\"><table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td width=\"25%\" class=\"black\">Domain :</td><td width=\"35%\">" +
	                  domainName + "</td>";
	                 if(generateType==0 || generateType==1 || generateType==2 || generateType == 5){
	              	   clientName+="<td rowspan=\"2\" width=\"40%\" class=\"border-left border-right\"><div class=\"client-logo pull-right\">"+"<img width=\"240\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</div></td>";
	                 }
	                 clientName+="</tr><tr><td width=\"25%\" class=\"black\">Parent department:</td><td width=\"75%\">"+parentDeptName+"</td></tr></table></section>";
	
	          } else if (request.getParameter("dynPageSize") != null && !request.getParameter("dynPageSize").equals("")) {
	        	  multiLanguageSupportRequired = CommonUtility.isClientConditionExistInProperty(multiLanguageSupportRequiredInPDF, abcUtility.getSessionClientId(request));
	        	  String themeLogo = "";
	        	  themeLogo="<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td class=\"v-a-middle a-center\"><div class=\"a-center\">"+"<img width=\"100%\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</div></td></tr></table>";
	              clientName+="<div class=\"main_container o-hidden\" id=\"temp\"><div class=\"container_25 o-hidden border-right\"><div class=\"content_section\"><section class=\"inner-right-bar grid_26 border-left\" id=\"print_area\"><table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td class=\"black\" width=\"20%\">Domain :</td><td width=\"40%\">" +
	                  domainName + "</td>";
	                  if(generateType==0 || generateType==1 || generateType==2 || generateType == 5){
	                	  if(multiLanguageSupportRequired)
	                		  clientName+="<td rowspan=\"2\" width=\"40%\" class=\"border-left border-right v-a-middle a-center\"><div class=\"client-logo a-center\">"+themeLogo+"</div></td>";
	                  	else
	                  		clientName+="<td rowspan=\"2\" width=\"40%\" class=\"border-left border-right v-a-middle a-center\"><div class=\"client-logo a-center\">"+"<img width=\"240\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</div></td>";
	                  }
	                  clientName+="</tr><tr><td class=\"black\">Parent department:</td><td>"+parentDeptName+"</td></tr></table></section>";
	          }else{
	        	  multiLanguageSupportRequired = CommonUtility.isClientConditionExistInProperty(multiLanguageSupportRequiredInPDF, abcUtility.getSessionClientId(request));
	        	  String themeLogo = "";
	        	  themeLogo="<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td class=\"v-a-middle a-center\"><div class=\"a-center\">"+"<img width=\"100%\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</div></td></tr></table>";
	              clientName+="<div class=\"main_container o-hidden\" id=\"temp\"><div class=\"container_25 o-hidden border-right\"><div class=\"content_section\"><section class=\"inner-right-bar grid_26 border-left\" id=\"print_area\"><table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" class=\"formField1\"><tr><td class=\"black\" width=\"20%\">Domain :</td><td width=\"40%\">" +
	                  domainName + "</td>";
	                  if(generateType==0 || generateType==1 || generateType==2 || generateType == 5){
	                	  if(multiLanguageSupportRequired)
	                		  clientName+="<td rowspan=\"2\" width=\"40%\" class=\"border-left border-right v-a-middle a-center\"><div class=\"client-logo a-center\">"+themeLogo+"</div></td>";
	                  	else
	                  		clientName+="<td rowspan=\"2\" width=\"40%\" class=\"border-left border-right v-a-middle a-center\"><div class=\"client-logo a-center\">"+"<img width=\"240\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</div></td>";
	                  }
	                  clientName+="</tr><tr><td class=\"black\">Parent department:</td><td>"+parentDeptName+"</td></tr></table></section>";
	          }
        	  
          }
          return clientName + request.getParameter("pdfBuffer");
      }
	
	/**
	 * @author keval.soni
	 * @param request
	 * @return
	 * @throws MalformedURLException
	 */
	private String setFileDefaultDataForWinningLetterPDF(HttpServletRequest request) throws MalformedURLException {
        int generateType =  StringUtils.hasLength(request.getParameter("txtGenerateType")) ? Integer.parseInt(request.getParameter("txtGenerateType")) : 0;
        String clientName ="";
        URL url = new URL(request.getRequestURL().toString());
        StringBuilder verifyUrlPrefix=new StringBuilder();
        if(generateType == 0 || generateType == 1 || generateType == 5 || generateType == 6) {
            verifyUrlPrefix.append(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "http").append("://").append(internalIp);
        } else if (generateType == 2) {
        verifyUrlPrefix.append(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "https").append("://").append(url.getHost());
        if ((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) {
            verifyUrlPrefix.append(":").append(url.getPort());
        } else{
//            if(tPort!=0) {
//                verifyUrlPrefix.append(":"+tPort);
//            }
        	}
        }
        verifyUrlPrefix.append(request.getContextPath()).append("/resources/static-images/Logo/");
        verifyUrlPrefix.append("logoForWinningLetter.jpg");
        //clientName="<div class=\"main_container\">  <div class=\"container_25\"><header><div class=\"client-logo pull-right\">"+"<img src=\""+verifyUrlPrefix.toString()+"\" />"+"</div></header></div></div>";
        if (request.getParameter("hdisCustomLandScap") != null && !request.getParameter("hdisCustomLandScap").equals("")) {
               clientName+="<div class=\"print-pdf main_container o-hidden\" id=\"temp\"><div class=\"container_25 o-hidden border-right\">" +
               		"<div class=\"content_section\"><section class=\"inner-right-bar pull-left grid_26 border-left\" id=\"print_area\"><table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">";
               if(generateType==6){
            	   clientName+="<tr><td width=\"40%\">"+"<img width=\"140\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</td>";
               }
               clientName+="</tr></table></section>";

        } else if (request.getParameter("dynPageSize") != null && !request.getParameter("dynPageSize").equals("")) {
                //int width = Integer.parseInt(request.getParameter("dynPageSize")) - 50;
                /*style=\"width:"+width+"px;\" */
               clientName+="<div class=\"print-pdf main_container o-hidden\" id=\"temp\"><div class=\"container_25 o-hidden border-right\">" +
               		"<div class=\"content_section\"><section class=\"inner-right-bar pull-left grid_26 border-left\" id=\"print_area\" ><table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">";
               if(generateType==6){
                   //System.out.println("verifyUrlPrefix = " + verifyUrlPrefix);
            	   clientName+="<tr><td width=\"40%\">"+"<img width=\"140\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</td>";
               }
               clientName+="</tr></table></section>";
        }else{
            clientName+="<div class=\"main_container o-hidden\" id=\"temp\"><div class=\"container_25 o-hidden border-right\"><div class=\"content_section\"><section class=\"inner-right-bar grid_26 border-left\" id=\"print_area\"><table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\">";
                if(generateType==6){
                	clientName+="<tr><td width=\"40%\" class=\"v-a-middle a-center\">"+"<img width=\"140\" src=\""+verifyUrlPrefix.toString()+"\" />"+"</td>";
                }
                clientName+="</tr></table></section>";
        }
        return clientName + request.getParameter("pdfBuffer");
	}
	/**
	 * 
	 * @author Manoj Gadhavi
	 * @modify Janak.Dhanani - 14/05/2015
	 * @param string 
	 * This method can remove all words start and end with &lt; and &gt;
	 */
	 public static String removeSpecialChars(String str) {
	     //return str.replaceAll("(?s)&#38;lt;.*?&#38;gt;", " ");
		 return str.replaceAll("(?s)&amp;lt;.*?&amp;gt;", " ");
	}

/**
 * 
 * @author bharat
 * @param pdfBuffer
 * @param fileName
 * @param path
 * @param id
 * @param generateType
 * @param response
 * @param request
 * @throws IOException
 * @throws DocumentException
 * @throws ServletException
 * @throws com.itextpdf.text.DocumentException 
 */
	private void reportGeneration(String pdfBuffer, String fileName, String path, String id,int generateType, HttpServletResponse response, HttpServletRequest request) throws IOException, DocumentException, ServletException, com.itextpdf.text.DocumentException {
		 pdfBuffer = pdfBuffer.replace("<br>", "<br/>").replace("&nbsp;", " ").replace(" & ", "&amp;").replace("colSpan", "colspan").replace("=\"\"","").replace("&lt;BR&gt;", "<br/>");

        File destFolder = new File(path + "\\" + id);
        if (destFolder.exists() == false) {
            destFolder.mkdirs();
        }
        //System.out.println(request.getServletContext().getRealPath(File.separator));
        File file = new File(path + "\\" + id + "\\" + fileName + ".pdf");
        ServletOutputStream outputStream = response.getOutputStream();
        FileOutputStream fos = new FileOutputStream(file);
        ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        int clientId = 0;
        if(clientBean!=null)
        {
        	clientId = clientBean.getClientId();
        }
        
        multiLanguageSupportRequired = CommonUtility.isClientConditionExistInProperty(multiLanguageSupportRequiredInPDF, clientId);
        		
        StringBuilder htmls = generateFinalData(request,generateType,pdfBuffer);
        Document htmlParseTagCompleteString = Jsoup.parse(htmls.toString());     // @ janak dhanani Jsop for incomplete tags and parser Bug #22267
        String finalData=null;
        if(multiLanguageSupportRequired){
        	finalData = AbcUtility.reverseReplaceSpecialChars(AbcUtility.htmlReverseReplaceQuotes(htmlParseTagCompleteString.toString())); //Changes For Bug Id:#32295
        }else{
        	finalData= AbcUtility.reverseReplaceSpecialChars(htmlParseTagCompleteString.toString());
        }
        finalData=finalData.replace("&", "&amp;");
        
        if(generateType == 0 || generateType == 1) {
        	final String waterMarkURLStr = getClass().getClassLoader().getResource("").getPath().split("/WEB-INF/classes/")[0].concat("/resources/static-images/Logo/eptl-watermark.png");
            final Image img = Image.getInstance(waterMarkURLStr);
	        final int w = Math.round(img.getScaledWidth());
	        final int h = Math.round(img.getScaledHeight());
	        boolean addSignature= StringUtils.hasLength(request.getParameter("addSignature")) ? Boolean.valueOf(request.getParameter("addSignature")) : false;
        	if(multiLanguageSupportRequired)
        	{
        		response.setContentType("application/pdf");
                response.setContentType("application/octet-stream");
                response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".pdf\"");
		            PD4ML pd4mlRender = new PD4ML();
		            pd4mlRender.enableDebugInfo();
		            pd4mlRender.setPermissions("empty", 0xffffffff ^ PD4Constants.AllowAnnotate ^ PD4Constants.AllowAssembly ^ PD4Constants.AllowContentExtraction ^ PD4Constants.AllowCopy ^ PD4Constants.AllowDegradedPrint ^ PD4Constants.AllowFillingForms ^ PD4Constants.AllowModify ^ PD4Constants.AllowPrint , true);
		            //pd4mlRender.adjustHtmlWidth();
		            pd4mlRender.setHtmlWidth(1100);
                    //Footer
                    PD4PageMark footer = new PD4PageMark();
                    StringBuilder htmlFooterData = new StringBuilder();
                    if (request.getParameter("isFooterRequire") != null && !request.getParameter("isFooterRequire").equals("")) {
                        String setFooterData[] = request.getParameter("isFooterRequire").split("@@");
                        if (setFooterData.length != 0) {
                            if (setFooterData.length == 2) {
                                htmlFooterData.append("<div style='float: left;' id='pdfPrintFooterHtml'>").append(setFooterData[1].toString()).append("</div>");
                            }
                             if (setFooterData[0].equals("YES") && setFooterData[0] != null) {
                                 htmlFooterData.append("<div  style='clear:both; text-align:right; width:100%;' id='pageno'>page $[page] of $[total]</div>");
                            }
                        }
                    }
                    footer.setHtmlTemplate(htmlFooterData.toString());
                    footer.setAreaHeight(-1);
                    footer.setWatermark(waterMarkURLStr/*waterMarkURL.toExternalForm()*/,new Rectangle(130, 300, 300, 200),80);
                    pd4mlRender.setPageFooter(footer);
		            String fontPath = request.getServletContext().getRealPath("/WEB-INF/i18n/fonts");
		            finalData = finalData.replaceAll("word-break", "word-wrap");
		            InputStream stream = new ByteArrayInputStream(finalData.getBytes(Charset.forName("UTF-8")));
		            InputStreamReader isr = new InputStreamReader(stream, "UTF-8");
		            pd4mlRender.useTTF(fontPath, true );
		            ByteArrayOutputStream baos = new ByteArrayOutputStream();
		            pd4mlRender.render(isr,baos);
		            if(pdfSignatureRequired || addSignature){
		            	baos = signPDF(baos);
		            }
		            baos.writeTo(outputStream);
		            baos.writeTo(fos);
		            baos.flush();
		            baos.close();
        	}
        	else
        	{
                response.setContentType("application/octet-stream");
                response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".pdf\"");
        		final ITextRenderer renderer = new ITextRenderer();
                renderer.getFontResolver().addFont("C:\\Windows\\Fonts\\Calibri.ttf",BaseFont.IDENTITY_H,BaseFont.NOT_EMBEDDED); // @ Bug #21690
                renderer.setDocumentFromString(finalData);
                renderer.layout();
    			ServletOutputStream os = response.getOutputStream();
    			ByteArrayOutputStream baos = new ByteArrayOutputStream();
    			renderer.createPDF(baos);
    			PdfReader reader = new PdfReader(baos.toByteArray());
    			PdfStamper stamper = new PdfStamper(reader, baos);
    			int n = reader.getNumberOfPages();
//    			stamper.setEncryption("".getBytes(), "".getBytes(),
//    					0xffffffff ^ PdfWriter.ALLOW_PRINTING ^ PdfWriter.ALLOW_ASSEMBLY ^ PdfWriter.ALLOW_COPY ^ PdfWriter.ALLOW_DEGRADED_PRINTING
//    							^ PdfWriter.ALLOW_FILL_IN ^ PdfWriter.ALLOW_MODIFY_CONTENTS ^ PdfWriter.ALLOW_MODIFY_ANNOTATIONS ^ PdfWriter.ALLOW_SCREENREADERS  ,true);
    	        PdfGState gs1 = new PdfGState();
    	        gs1.setFillOpacity(0.5f);
    	        PdfContentByte over;
    	        com.itextpdf.text.Rectangle pagesize;
    	        float x, y;
    	        for (int i = 1; i <= n; i++) {
    	            pagesize = reader.getPageSizeWithRotation(i);
    	            x = (pagesize.getLeft() + pagesize.getRight()) / 2;
    	            y = (pagesize.getTop() + pagesize.getBottom()) / 2;
    	            over = stamper.getOverContent(i);
    	            over.saveState();
    	            over.setGState(gs1);
    				over.addImage(img, w, 0, 0, h, x - (w / 2), y - (h / 2));
    	            over.restoreState();
    	        }
    			
    			stamper.close();
    			if(pdfSignatureRequired  || addSignature){
    				baos = signPDF(baos);
    			}
    			baos.writeTo(os);
    			baos.writeTo(fos);
    			baos.flush();
    			baos.close();
    			reader.close();
        		
        	}
        } else if(generateType == 2) {
            response.setContentType("text/html;charset=UTF-8");
            response.setCharacterEncoding("UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".html\"");
            outputStream.write(htmls.toString().getBytes("UTF-8"));
        } else if(generateType == 3) {
            response.setContentType("application/vnd.ms-word");
            response.setCharacterEncoding("UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".doc\"");
            outputStream.write(finalData.getBytes("UTF-8"));
        } else if(generateType == 4) {
            response.setContentType("application/vnd.ms-excel");
            response.setCharacterEncoding("UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".xls\"");
            finalData = removeSpecialChars(finalData); // To remove junk character when creating excel, BUG # 23305 By Mnaoj Gadhavi
            outputStream.write(finalData.replaceAll("<a.*?</a>", "").getBytes("UTF-8"));// Bug #24751 : Remove hyperlink in Excel Report
        } else if(generateType == 5) {
//            Date now = new Date();
//            String currDate = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(now);
//            fileName = "DynamicL1H1Report_" + currDate;
//            HSSFWorkbook wb = new HSSFWorkbook();
//            HSSFSheet sheet = wb.createSheet();
//
//            //Set Header Font
//            HSSFFont headerFont = wb.createFont();
//            headerFont.setBoldweight(headerFont.BOLDWEIGHT_BOLD);
//            headerFont.setFontHeightInPoints((short) 12);
//
//            //Set Header Style
//            CellStyle headerStyle = wb.createCellStyle();
//            headerStyle.setFillBackgroundColor(IndexedColors.BLACK.getIndex());
//            headerStyle.setAlignment(headerStyle.ALIGN_CENTER);
//            headerStyle.setFont(headerFont);
//            headerStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
//            headerStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
//            int rowCount = 0;
//            Row header;
//
//
//            Document doc = Jsoup.parse(htmls.toString());
//
//            // Display list of headers return by stored procedure
//            Cell cell;
//            for (Element table : doc.select("table[class=tableView]")) {
//                rowCount++;
//                int rowSpanCol = 0;
//                for (Element row : table.select("tr")) {
//                    header = sheet.createRow(rowCount);
//                        Elements ths = row.select("th");
//                        int count = 0;
//                        for (Element element : ths) {
//                            cell = header.createCell(count);
//                            cell.setCellValue(element.text());
//                            cell.setCellStyle(headerStyle);
//                            count++;
//                        }
//                        rowCount++;
//                        header = sheet.createRow(rowCount);
//                        Elements tds = row.select("td");
//                        count = 0;
//
//                        for (Element element : tds) {
//                            cell = header.createCell(rowSpanCol == count ? count++ : count);
//                            cell.setCellValue(element.text());
//                            if (!element.attr("rowspan").isEmpty()) {
//                                rowSpanCol = count;
//                                sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount + Integer.parseInt(element.attr("rowspan")), count, count));
//                            }
//                            count++;
//                        }
//                    rowCount++;
//
//                }
//
//            }
//            sheet = wb.getSheetAt(0);
//            for (int j = 0; j < 8; j++) {
//                sheet.autoSizeColumn(j);
//            }
//            ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
//            wb.write(outByteStream);
//            byte[] outArray = outByteStream.toByteArray();
//            response.setContentType("application/ms-excel");
//            response.setContentLength(outArray.length);
//            response.setHeader("Expires:", "0"); // eliminates browser caching
//            response.setHeader("Content-Disposition", "attachment; filename=" + fileName + ".xls");
//            OutputStream outStream = response.getOutputStream();
//            outStream.write(outArray);
//            outStream.flush();
//            outStream.close();
//            fos.flush();
//            fos.close();
//            outputStream.flush();
        }
    }
//	private void reportGeneration(String pdfBuffer, String fileName, String path, String id,int generateType, HttpServletResponse response, HttpServletRequest request) throws IOException, DocumentException, ServletException {
//        pdfBuffer = pdfBuffer.replaceAll("<br>", "<br/>").replaceAll("&nbsp;", " ").replaceAll(" & ", "&amp;").replaceAll("colSpan", "colspan").replace("=\"\"","");
//
//        File destFolder = new File(path + "\\" + id);
//        if (destFolder.exists() == false) {
//            destFolder.mkdirs();
//        }
//        //System.out.println(request.getServletContext().getRealPath(File.separator));
//        File file = new File(path + "\\" + id + "\\" + fileName + ".pdf");
//        ServletOutputStream outputStream = response.getOutputStream();
//        FileOutputStream fos = new FileOutputStream(file);
//        StringBuilder htmls = generateFinalData(request,generateType,pdfBuffer);
//        Document htmlParseTagCompleteString = Jsoup.parse(htmls.toString());     // @ janak dhanani Jsop for incomplete tags and parser Bug #22267
//        String finalData= AbcUtility.reverseReplaceSpecialChars(AbcUtility.htmlReverseReplaceQuotes(htmlParseTagCompleteString.toString())).replace("&", "&amp;");
//       
//            if (generateType == 0 || generateType == 1) {
//                response.setContentType("application/pdf");
//                response.setContentType("application/octet-stream");
//                response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".pdf\"");
//
//	            ITextRenderer renderer = new ITextRenderer();
//	            renderer.getFontResolver().addFont("C:\\Windows\\Fonts\\Calibri.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED); // @ Bug #21690
//	            renderer.setDocumentFromString(finalData);
//	            renderer.layout();
//	            renderer.createPDF(outputStream);
//	            renderer.createPDF(fos);
//        } else if(generateType == 2) {
//            response.setContentType("text/html;charset=UTF-8");
//            response.setCharacterEncoding("UTF-8");
//            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".html\"");
//            outputStream.write(htmls.toString().getBytes());
//        } else if(generateType == 3) {
//            response.setContentType("application/vnd.ms-word");
//            response.setCharacterEncoding("UTF-8");
//            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".doc\"");
//            outputStream.write(finalData.getBytes());
//        } else if(generateType == 4) {
//            response.setContentType("application/vnd.ms-excel");
//            response.setCharacterEncoding("UTF-8");
//            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".xls\"");
//            outputStream.write(finalData.replace("<br />", "\n").replace("<br/>", "\n").replace("<br>", "\n").getBytes());
//        } else if(generateType == 5) {
////            Date now = new Date();
////            String currDate = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(now);
////            fileName = "DynamicL1H1Report_" + currDate;
////            HSSFWorkbook wb = new HSSFWorkbook();
////            HSSFSheet sheet = wb.createSheet();
////
////            //Set Header Font
////            HSSFFont headerFont = wb.createFont();
////            headerFont.setBoldweight(headerFont.BOLDWEIGHT_BOLD);
////            headerFont.setFontHeightInPoints((short) 12);
////
////            //Set Header Style
////            CellStyle headerStyle = wb.createCellStyle();
////            headerStyle.setFillBackgroundColor(IndexedColors.BLACK.getIndex());
////            headerStyle.setAlignment(headerStyle.ALIGN_CENTER);
////            headerStyle.setFont(headerFont);
////            headerStyle.setBorderTop(HSSFCellStyle.BORDER_MEDIUM);
////            headerStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);
////            int rowCount = 0;
////            Row header;
////
////
////            Document doc = Jsoup.parse(htmls.toString());
////
////            // Display list of headers return by stored procedure
////            Cell cell;
////            for (Element table : doc.select("table[class=tableView]")) {
////                rowCount++;
////                int rowSpanCol = 0;
////                for (Element row : table.select("tr")) {
////                    header = sheet.createRow(rowCount);
////                        Elements ths = row.select("th");
////                        int count = 0;
////                        for (Element element : ths) {
////                            cell = header.createCell(count);
////                            cell.setCellValue(element.text());
////                            cell.setCellStyle(headerStyle);
////                            count++;
////                        }
////                        rowCount++;
////                        header = sheet.createRow(rowCount);
////                        Elements tds = row.select("td");
////                        count = 0;
////
////                        for (Element element : tds) {
////                            cell = header.createCell(rowSpanCol == count ? count++ : count);
////                            cell.setCellValue(element.text());
////                            if (!element.attr("rowspan").isEmpty()) {
////                                rowSpanCol = count;
////                                sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount + Integer.parseInt(element.attr("rowspan")), count, count));
////                            }
////                            count++;
////                        }
////                    rowCount++;
////
////                }
////
////            }
////            sheet = wb.getSheetAt(0);
////            for (int j = 0; j < 8; j++) {
////                sheet.autoSizeColumn(j);
////            }
////            ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
////            wb.write(outByteStream);
////            byte[] outArray = outByteStream.toByteArray();
////            response.setContentType("application/ms-excel");
////            response.setContentLength(outArray.length);
////            response.setHeader("Expires:", "0"); // eliminates browser caching
////            response.setHeader("Content-Disposition", "attachment; filename=" + fileName + ".xls");
////            OutputStream outStream = response.getOutputStream();
////            outStream.write(outArray);
////            outStream.flush();
////            outStream.close();
////            fos.flush();
////            fos.close();
////            outputStream.flush();
//        }
//    }
	/**
	 * 
	 * @author bharat
	 * @param request
	 * @param generateType
	 * @param pdfBuffer
	 * @return
	 */
	public StringBuilder  generateFinalData(HttpServletRequest request, int generateType,String pdfBuffer)
	{
        ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        int clientId = 0;
        if(clientBean!=null)
        {
        	clientId = clientBean.getClientId();
        }
        
        multiLanguageSupportRequired = CommonUtility.isClientConditionExistInProperty(multiLanguageSupportRequiredInPDF, clientId);
        
		String imagePath = request.getRealPath("grad.jpg").substring(0, request.getRealPath("grad.jpg").lastIndexOf("\\"))+"\\resources\\template\\template1\\images\\";
		StringBuilder htmls = new StringBuilder();
//		StringBuilder cssPath = new StringBuilder();
         URL url = null;
		try {
			url = new URL(request.getRequestURL().toString());
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int dynPageSize = StringUtils.hasLength(request.getParameter("dynPageSize")) ? Integer.parseInt(request.getParameter("dynPageSize")) : 0;
		/*cssPath.append("http").append("://").append("127.0.0.1"); // Bug #39250 By Jitendra
		cssPath.append(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "https").append("://").append(url.getHost());
        if ((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) {
        	cssPath.append(":").append(url.getPort());
        }*/
		//cssPath.append(request.getContextPath()).append("/resources/template/template1/css/pdfstyle.css");	 
		 if(generateType == 3) {
//	            htmls.append("<%@page contentType=\"text/html\" pageEncoding=\"UTF-8\"%>");  bug # 23147 for ms-word
	            htmls.append("<!DOCTYPE>");  
	            htmls.append("<html><head>");
	            if(multiLanguageSupportRequired)
	            {
	            	//htmls.append("<link rel='stylesheet' href='"+cssPath+"' />");	Bug #43132 By Jitendra.
	            	htmls.append("<style type=\"text/css\">");
	            	htmls.append("a,ins{text-decoration:none}table tr td,table tr th{border-bottom:1px solid #e8e8e8;border-top:1px solid #e8e8e8}article,aside,details,figcaption,figure,footer,header,hgroup,hr,menu,nav,section{display:block}a,hr{padding:0}hr,input[type=checkbox]:focus,input[type=radio]:focus{border:0}a,button{color:#069}.header-link li,li,nav ul{list-style:none}abbr,address,article,aside,audio,b,blockquote,body,canvas,caption,cite,code,dd,del,details,dfn,div,dl,dt,em,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,ins,kbd,label,legend,li,mark,menu,nav,object,ol,p,pre,q,samp,section,small,span,strong,sub,summary,sup,table,tbody,td,tfoot,th,thead,time,tr,ul,var,video{margin:0;padding:0;border:0;outline:0;font-size:100%;vertical-align:baseline;background:0 0}img,input,select,table tr th{vertical-align:middle}ins,mark{background-color:#ff9;color:#000}body{line-height:1;font-size:13px;color:#5d5e68}blockquote,q{quotes:none}blockquote:after,blockquote:before,q:after,q:before{content:'';content:none}a{margin:0;font-size:100%;vertical-align:baseline;background:0 0}a:hover{text-decoration:underline}mark{font-style:italic;font-weight:700}del{text-decoration:line-through}abbr[title],dfn[title]{border-bottom:1px dotted;cursor:help}table{border-collapse:collapse;border-spacing:0}table tr th{padding:9px 10px 7px;text-align:left;color:#222;font-weight:400}table tr td{border-left:0;padding:10px}hr{height:1px;border-top:1px solid #ccc;margin:1em 0}input[type=checkbox],input[type=radio]{width:13px;height:13px;border:none;padding:0\\9}.pull-left{float:left!important}.pull-right{float:right!important}li{display:inline}img{max-width:100%}.display{display:block}.o-hidden{overflow:hidden}.o-auto{overflow:auto}.clearfix{clear:both}p{line-height:20px;padding-top:20px;text-align:justify}h1,h2,h3,h4,h5,h6{color:#222;font-weight:400}h1{font-size:23px}h2{font-size:20px}label{margin:4px}.alpha{padding-left:0!important}.omega{padding-right:0!important}.alpha1{margin-left:0!important}.omega1{margin-right:0!important}button{background:#fafafa;padding:4px 10px;cursor:pointer;border:1px solid #E8E8E8;line-height:15px;margin:4px;transition:.5s;box-shadow:none}button:hover{background:#f2f2f2;transition:.5s}button[type=submit]:disabled{background:#666;color:#BEBEBE;border:1px solid #606060}.blue-button-big,.blue-button-small{background:#279CE7;text-align:center;border:1px solid #2096e1;color:#FFF;transition:.5s;box-shadow:none;cursor:pointer}.blue-button-big{padding:3px 10px;height:31px;font-size:20px;line-height:21px}.test section.inner-right-bar{width:100%!important}.blue-button-small{line-height:23px;padding:0 10px!important;font-size:16px}.blue-button-big:hover,.blue-button-small:hover{color:#FFF;border:1px solid #000;background:#000;transition:.5s}.dropdown-btn{border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;border:1px solid #e3e3e3;padding-right:20px}.active{color:#222}.black{color:#222!important}.no-padding{padding:0!important}.border-left-none,.border-left-none tr td,.border-left-none tr th,table.border-left-none tr td,table.border-left-none tr th{border-left:0!important}.border-right-none,.border-right-none tr td,.border-right-none tr th,table.border-right-none tr td,table.border-right-none tr th{border-right:0!important}.border-top-none td,.border-top-none th,table.border-top-none td,table.border-top-none th{border-top:0!important}.border-bottom-none,.border-bottom-none td,.border-bottom-none th,table.border-bottom-none td,table.border-bottom-none th{border-bottom:0!important}.border-right{border-right:1px solid #E8E8E8}.border-top{border-top:1px solid #E8E8E8}.border-top-none,table.no-border tr td{border-top:0!important}.border-bottom{border-bottom:1px solid #E8E8E8}table.no-border tr td{border-bottom:0!important}.go-back{line-height:25px;margin-top:8px;margin-bottom:8px;padding-left:12px;margin-right:12px}.red{color:red;font-weight:400}.a-center{text-align:center!important}.a-left{text-align:left!important}.a-right{text-align:right!important}.v-a-top{vertical-align:top!important}.v-a-middle{vertical-align:middle!important}.v-a-bottom{vertical-align:bottom!important}.m-top0{margin-top:0!important}.m-top1{margin-top:5px!important}.m-top2{margin-top:10px!important}.m-top3{margin-top:15px!important}.m-top4{margin-top:20px!important}.m-bottom-none{margin-bottom:0!important}.p-top-none{padding-top:0!important}.display-inline{display:inline!important}.display-line-block label{display:inline-block!important}.input-width{width:115px!important}.m-left_14{margin-left:14px}.mini-formfield textarea.cont-texarea{width:79%}.container_25{max-width:"+(dynPageSize!=0?dynPageSize:1024)+"px;margin:0 auto;padding:0}.container_25 .grid_1{width:2%}.container_25 .grid_2{width:6%}.container_25 .grid_3{width:10%}.container_25 .grid_4{width:14%}.container_25 .grid_5{width:18%}.container_25 .grid_6{width:22%}.container_25 .grid_7{width:26%}.container_25 .grid_8{width:30%}.container_25 .grid_9{width:34%}.container_25 .grid_10{width:38%}.container_25 .grid_11{width:42%}.container_25 .grid_12{width:46%}.container_25 .grid_13{width:50%}.container_25 .grid_14{width:54%}.container_25 .grid_15{width:58%}.container_25 .grid_16{width:62%}.container_25 .grid_17{width:66%}.container_25 .grid_18{width:70%}.container_25 .grid_19{width:74%}.container_25 .grid_20{width:78%}.container_25 .grid_21{width:82%}.container_25 .grid_22{width:86%}.container_25 .grid_23{width:90%}.container_25 .grid_24{width:94%}.container_25 .grid_25{width:98%}.container_25 .grid_26{width:100%}.container_25 .prefix1_10{margin-right:5px}.container_25 .prefix1_20{margin-right:10px}.container_25 .prefix1_30{margin-right:15px}.container_25 .prefix1_1{margin-left:5px}.container_25 .prefix1_2{margin-left:10px}.container_25 .prefix_1{padding-left:1.6%}.container_25 .prefix_2{padding-left:4%}.container_25 .prefix_2-px{padding-left:20px}.container_25 .prefix_3{padding-left:6%}.container_25 .prefix_4{padding-left:8%}.container_25 .prefix_5{padding-left:10%}.container_25 .prefix_6{padding-left:12%}.container_25 .prefix_7{padding-left:14%}.container_25 .prefix_8{padding-left:16%}.container_25 .prefix_9{padding-left:36%}.container_25 .prefix_10{padding-left:40%}.container_25 .prefix_11{padding-left:44%}.container_25 .prefix_12{padding-left:48%}.container_25 .prefix_13{padding-left:52%}.container_25 .prefix_14{padding-left:56%}.container_25 .prefix_15{padding-left:60%}.container_25 .prefix_16{padding-left:64%}.container_25 .prefix_17{padding-left:68%}.container_25 .prefix_18{padding-left:72%}.container_25 .prefix_19{padding-left:76%}.container_25 .prefix_20{padding-left:80%}.container_25 .prefix_21{padding-left:84%}.container_25 .prefix_22{padding-left:88%}.container_25 .prefix_23{padding-left:92%}.container_25 .prefix_24{padding-left:96%}.container_25 .suffix_1{padding-right:1.6%}.container_25 .suffix_2{padding-right:8%}.container_25 .suffix_3{padding-right:12%}.container_25 .suffix_4{padding-right:16%}.container_25 .suffix_5{padding-right:20%}.container_25 .suffix_6{padding-right:24%}.container_25 .suffix_7{padding-right:28%}.container_25 .suffix_8{padding-right:32%}.container_25 .suffix_9{padding-right:36%}.container_25 .suffix_10{padding-right:40%}.container_25 .suffix_11{padding-right:44%}.container_25 .suffix_12{padding-right:48%}.container_25 .suffix_13{padding-right:52%}.container_25 .suffix_14{padding-right:56%}.container_25 .suffix_15{padding-right:60%}.container_25 .suffix_16{padding-right:64%}.container_25 .suffix_17{padding-right:68%}.container_25 .suffix_18{padding-right:72%}.container_25 .suffix_19{padding-right:76%}.container_25 .suffix_20{padding-right:80%}.container_25 .suffix_21{padding-right:84%}.container_25 .suffix_22{padding-right:88%}.container_25 .suffix_23{padding-right:92%}.container_25 .suffix_24{padding-right:96%}.main_container{border-left:1px solid #d6d6d6;border-right:1px solid #d6d6d6;background:#FFF;max-width:"+(dynPageSize!=0?dynPageSize:1060)+"px;margin:0 auto;-moz-box-sizing:border-box;-webkit-box-sizing:border-box}header{position:relative}a.logo{display:block;height:145px;text-indent:-99999px}nav{text-align:right}nav li{color:#333}.top-nav li a{padding:0 10px;border-right:1px solid #ffc362;color:#333}nav li a:hover{color:#FFF;text-decoration:none}nav ul.top-nav{margin-bottom:0;margin-top:61px;margin-right:15px}nav ul.top-nav li img{padding-left:8px;margin-top:-4px;position:relative;top:1px}nav ul.bottom-nav{margin-bottom:0;margin-top:12px}nav ul.bottom-nav li{color:#333;padding-left:10px}nav ul.bottom-nav li a{border-left:1px solid #ffc362;padding:0 10px;color:#333}nav ul.bottom-nav li a.border,nav ul.top-nav li:last-child a,ul.tab li a.border{border-right:0}.navbar-fixed-bottom,.navbar-fixed-top{float:right;width:auto}.header-link{margin-top:10px}.header-link li a{border:0!important;font-size:15px!important;padding:0 5px!important}.header-link fieldset{background:#f2f2f2;border:1px solid #e7e7e7;position:absolute;padding:5px;width:22%;margin-top:5px}.header-link fieldset label{display:block}.header-link fieldset input{width:92%}.header-link fieldset a{font-size:13px!important;margin-top:12px}.carat-arrow{position:relative;top:-13px;left:10px}.help-setting,.login-setting,.settings_menu{position:absolute;right:156px;top:100px;text-align:left;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;border:1px solid #FFC362;background:#fba823;z-index:9}.help-setting li,.login-setting li,.settings_menu li{display:block;line-height:28px;padding-left:0!important}.help-setting li a,.login-setting li a,.settings_menu li a{border-right:0;border-bottom:1px solid #FFC362;display:block;border-left:0!important}.settings_menu li:last-child a{border:0}.help-setting{position:absolute;right:0;top:76px}.marquee{margin:15px 1% 0}.content_section{position:relative}.collapse,.expand{height:22px;position:absolute;top:30px;display:block;text-indent:-99999px}.left-bar{border:1px solid #efefef}.collapse{background:url(../images/expand-colllapse.png) no-repeat;width:20px;left:175px}.expand{width:17px;z-index:999}.accordion .inner,.infoMsg,.page-title,.search-bar{position:relative}.list{margin-top:10px}.list li{margin:0 0 0 10px;padding-left:10px;line-height:23px;display:block}span.title{font-size:19px;color:#222;display:block;border-top:1px solid #e8e8e8;background-color:#f5f5f5;border-bottom:1px solid #e8e8e8;padding:10px 0 10px 40px;margin:10px 0 0}.category li a{color:#7c7d89;line-height:30px;display:block;padding-left:10px}.category li a:hover{background:#f2f2f2;color:#222;padding-left:6px;border-left:4px solid #ee9200;text-decoration:none}.ad-icon{background:url(../images/advertise-icon.png) 10px 9px no-repeat}.ad-banner_div{padding:10px}.ad-banner_div img{margin-bottom:5px}.middle-bar{margin-left:8px}.search-bar{border:3px solid #279ce7;height:39px}.search-bar input[type=text]{width:64%}.advance-bar{background:#fcfcfc;border:1px solid #f1f1f1;font-size:11px;color:#222;padding:8px}.details-box{background:url(../images/divider.png) bottom no-repeat;padding-bottom:20px}.details-box span{display:block;color:#222}.details-box b{color:#222;font-weight:400}.bottom-btn{border:1px solid #EFEFEF;margin-top:10px;overflow:hidden;padding:2px}.bottom-btn button{margin-top:7px}.bottom-btn span{margin:2px 0 0 10px;color:#222}.bottom-btn select{border:1px solid #EFEFEF;padding:5px;box-shadow:none}button.show-btn{font-size:12px;padding:0 10px;line-height:29px}.right-bar{border:1px solid #efefef}.copy,footer{border-top:1px solid #e7e7e7}.ex-icon{background:url(../images/exhibitions-icon.png) 10px 8px no-repeat}.tender-icon{background:url(../images/tender-icon.png) 10px 9px no-repeat}footer{background:#fbfbfb;max-width:1058px;max-width:"+(dynPageSize!=0?dynPageSize:1060)+"px;margin-left:auto;margin-right:auto;margin-top:25px}.footer-links span{font-size:20px;color:#222;padding-bottom:15px;display:block}.footer-links li,.footer-links li a{line-height:25px;color:#6c6d79;font-size:12px;display:block}.footer-links li a:hover{text-decoration:underline}#side a.active,.submenu li a:hover,a.accordion-title:hover{text-decoration:none}.footer-links li b{color:#222;font-weight:400}.fb,.l-in,.tw{color:#3a589b}.social-icons{line-height:60px;display:block;padding-left:56px;font-size:22px}.social-icons:hover{opacity:.8}.fb{background:url(../images/f-icon.png) left no-repeat}.tw{background:url(../images/t-icon.png) left no-repeat}.l-in{background:url(../images/in-icon.png) left no-repeat}.copy{margin-top:10px;font-size:11px;padding:0 0 30px}.inner-right-bar{border-left:5px solid #ececec;width:81.21%;border-top:1px solid #E8E8E8;border-right:1px solid #E8E8E8;border-bottom:1px solid #E8E8E8}.border-left{border-left:1px solid #E8E8E8!important}.js #main .accordion{visibility:hidden}.js #side .accordion{display:none}#errorDivNor,a.important,a.trigger{display:block}.accordion li{list-style-type:none}#side ul.accordion ul{margin:0;padding:0 0 0 20px}.accordion .outer{border:1px solid #dadada;border-width:0 1px 1px;background:#fff}.accordion .inner{margin-bottom:0;padding:.5em 20px 1em;overflow:hidden}.accordion .inner .inner{padding-bottom:0}a.accordion-title{background-color:#f5f5f5;padding:12px 12px 12px 37px;border-bottom:1px solid #e8e8e8;color:#222;font-size:15px}.inbox-icon{background:url(../images/inbox-icon.png) 15px no-repeat}.admini-icon{background:url(../images/administrator-icon.png) 14px no-repeat}.auction-icon{background:url(../images/auction-icon.png) 9px no-repeat}.report-icon{background:url(../images/report-icon.png) 13px no-repeat}.submenu{background:#fafafa}.submenu li a{border-bottom:1px solid #eee;padding:10px 0 10px 35px;color:#5c5d67}.submenu li a.active,.submenu li a:hover{text-decoration:none;background:#FFF;color:#f59700;padding-left:31px;border-left:4px solid #f59700}.submenu-sub{background:#fdfdfd}.last-child a.trigger{background-image:none;font-weight:400}.submenu-sub li.last-child a{padding-left:41px}.submenu-sub li.last-child a:hover{padding-left:37px}#main a.trigger{background-color:#f0f0f0}#main a.trigger.open{border-color:#dadada;background-color:#e7e7e7}#main a:active.trigger.open,#main a:focus.trigger.open,#main a:hover.trigger.open{border-color:#bcd}#side a.active{font-weight:700;color:#f72}a.important{background:url(../images/star.png) no-repeat;text-indent:-99999px;height:16px;width:17px}a.important:hover{background:url(../images/star.png) center -16px no-repeat}.breadcrumb{background:#F6F6F6}.breadcrumb li a{color:#222;padding:0 10px 0 2px;background:url(../images/arrow.png) right no-repeat;line-height:25px}.breadcrumb li a.active,.breadcrumb li a:hover{color:#069;text-decoration:none}.breadcrumb li:last-child a{background:0 0!important}.page-title{line-height:40px;border-bottom:1px solid #e8e8e8;background:#FBFBFB}.inbox-searchbar{margin-top:3px}#errorDivNor{margin:-10px 0 0 5px;float:left}.inbox-searchbar input{padding:5px;margin-top:4px}.pagination div button,.pagination input{margin:3px 0 0 5px}.adv-srch{line-height:35px}.div-header-link div{padding:3px 2px 2px;float:left}.div-header-link div.creat-client{padding:12px 10px 10px 0}.div-header-link div.creat-client a{border:0;background:0 0;float:none;padding:0 2px 0 5px;display:inline}.div-header-link a{padding:14px 25px 13px;float:left;border-right:1px solid #d3d3d3;display:block}.div-header-link a.active,.div-header-link a:hover{background:#FFF;text-decoration:none;color:#222;border-bottom:2px solid #757575;padding:14px 15px 11px}.gradi{background:#FBFBFB}.pagination{padding:5px 10px!important;line-height:29px}.pagination div li a{padding:0 10px;line-height:28px;color:#222}.pagination input{padding:4px;width:30px!important}.content-div{padding:10px 13px 10px 10px}.listing-div{border:1px solid #ECECEC;padding:0 10px}.listing-tab{margin:10px 0 0;overflow:hidden;border:1px solid #ECECEC;border-bottom:0;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.listing-tab li a{padding:10px 20px;display:block;float:left;color:#7C7D89;font-size:18px;border-right:1px solid #ECECEC}.listing-tab li a.active,.listing-tab li a:hover{text-decoration:none;color:#ee9200;background:url(../images/orange-arrow.png) center 33px no-repeat;border-bottom:2px solid #ee9200}.bidding-row-highlight{background-color:#cae5ff}.bidDetailHighlight{background-color:#FAF2DC;color:#000;font:700}.view-event table tr td{border:0;width:25%;border-bottom:1px solid #ECECEC;padding:3px 5px 3px 15px}.view-info{margin-top:10px}.view-info table tr td{border:0;padding:5px 5px 5px 15px}.view-info label{display:block}.view-event table tr td label span{color:red}.view-event label{margin:2px 0;line-height:18px;display:block;color:#404040}.defcomp,.defcomptext{margin-top:10px!important;margin-bottom:10px!important;margin-right:10px!important}.view-event h2{padding:3px 0}.table-border table tr th{text-align:center}.mandatory1{padding:3px 0 0 20px}.cursor{cursor:pointer}.row-highlight{background-color:#d8f4d2}.view-event p{padding:0}.view-event li{list-style:inherit;display:list-item}.item-price-75{width:75%;display:block}.item-price-94{width:94%;display:block}.defcomp{width:50%!important}.defcomptext{width:46.5%!important}.mini-formfield{margin-top:20px;border-bottom:1px solid #E8E8E8;padding-bottom:15px}.mini-formfield li{line-height:18px}.mini-formfield table tr td{border:0;padding-top:5px;padding-bottom:5px}.mini-formfield table tr td label{margin-top:12px}.display-block table tr td label{display:block}.mini-formfield table tr td span{color:red}.mini-formfield input,.mini-formfield textarea{margin:0;width:90%}.mini-formfield select{margin:0;width:96%}.mini-formfield input[type=checkbox],.mini-formfield input[type=radio]{margin:5px;width:auto}.mini-formfield input.dateBox{width:79%!important}.table-border table tr td,.table-border table tr th{border-left:1px solid #E8E8E8}.table-border table tr td input[type=text],.table-border table tr td select{width:200px}.table-border table tr td textarea{width:92%;min-height:50px}.table-border p{padding-top:0;padding-bottom:10px;text-align:left}.label-span{color:#5D5E68!important}.white{background-color:#fff}.matrix-table button{margin:4px;padding:4px 5px}.matrix-table input[type=file]{margin:0 4px}.matrix-table input,.matrix-table textArea{width:150px}.matrix-table select{width:162px}.matrix-table .nmbr-select{width:60px}.row-table table tr td{border:0;padding:5px}.row-table table input{width:90%}.row-table table select{width:97%}.add-confi-icn,.approve-icn,.approve-rights-icn,.assign-rights-icn,.auction-icn,.deptree-icn,.dft-setting-icn,.disable-icn,.document-icn,.edit-icn,.enabel-icn,.industry-icn,.mail-icn,.plus-icn,.reject-icn,.rend-mail-icn,.reset-password-icn,.setting-icn,.terms-icn,.theme-icn,.unalock-icn,.unamap-icn,.user-remail-icn,.user-renew-icn{background:url(../images/sprite.png) -13px -90px no-repeat;display:block;float:left;height:20px;margin:0 1px;text-indent:-9999px;width:26px}.errorMsg,.successMsg{margin-bottom:5px;padding:10px 10px 10px 50px}.theme-icn{background-position:-40px -90px}.dft-setting-icn{background-position:-67px -90px}a.approve-icn{background-position:-95px -90px}.setting-icn{background-position:-120px -90px}.deptree-icn{background-position:-146px -90px}.mail-icn{background-position:-173px -90px}.plus-icn{background-position:-200px -90px}.reject-icn{background-position:-226px -90px}.auction-icn{background-position:-256px -90px}.enabel-icn{background-position:-284px -90px}.industry-icn{background-position:-310px -90px}.rend-mail-icn{background-position:-337px -90px}.unalock-icn{background-position:-363px -88px}.user-remail-icn{background-position:-392px -88px}.user-renew-icn{background-position:-423px -88px}.add-confi-icn{background-position:-454px -88px}.unamap-icn{background-position:-19px -120px}.document-icn{background-position:-50px -119px}.assign-rights-icn{background-position:-82px -120px}.disable-icn{background-position:-110px -120px}.reset-password-icn{background-position:-139px -122px}.approve-rights-icn{background-position:-165px -122px}.terms-icn{background-position:-192px -122px}.errorMsg,.noticeMsg,.successMsg,infoMsg{border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.successMsg{background:url(../images/successIcn.png) 10px center no-repeat #E9F9E5;border:1px solid #B4E8AA;color:#1C8400}.errorMsg{background:url(../images/errorIcn.png) 10px center no-repeat #F9E5E6;border:1px solid #E8AAAD;color:#B50007}.noticeMsg{background:url(../images/noticeIcn.png) 10px center no-repeat #F9F9E5;border:1px solid #E8E3AA;color:#828400;padding:10px 10px 10px 50px}.noticeMsg li{line-height:20px;list-style:decimal!important;margin-left:18px;display:list-item}.infoMsg{background:url(../images/infoIcn.png) 5px 3px no-repeat #fbf8e9;border:1px solid #fec600;color:#87836d;width:230px;padding:5px 5px 5px 28px}.infoMsg span{position:absolute;display:block;top:-11px;left:22px}.validationMsg{color:red;padding:5px 0 0 2px}.helpMsg{color:#03a200}.doc-table tr th .doc-table tr td{padding:7px;line-height:18px;text-align:left;width:auto!important}.doc-table tr th{text-align:center}span.arrow{border-left:5px solid transparent;border-right:5px solid transparent;border-top:7px solid #000;display:block;height:1px;left:40px;position:relative;top:3px;width:1px}.popupbox select{width:93.5%!important}.popup-title h3{font-size:20px;color:#222;background:#e3e3e3;padding:10px}.login-pop{width:400px}.user-pop{width:500px}/*! fancyBox v2.1.5 fancyapps.com | fancyapps.com/fancybox/#license */.fancybox-image,.fancybox-inner,.fancybox-nav,.fancybox-nav span,.fancybox-outer,.fancybox-skin,.fancybox-tmp,.fancybox-wrap,.fancybox-wrap iframe,.fancybox-wrap object{padding:0;margin:0;border:0;outline:0;vertical-align:top}.fancybox-wrap{position:absolute;top:0;left:0;z-index:8020;width:auto!important}.fancybox-inner,.fancybox-outer,.fancybox-skin{position:relative}.fancybox-skin{background:#f9f9f9;color:#444;text-shadow:none;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;border:5px solid #e3e3e3;padding:0!important;border-top:0}.fancybox-opened{z-index:8030}.fancybox-opened .fancybox-skin{-webkit-box-shadow:0 10px 25px rgba(0,0,0,.5);-moz-box-shadow:0 10px 25px rgba(0,0,0,.5);box-shadow:0 10px 25px rgba(0,0,0,.5)}.fancybox-inner{overflow:hidden;width:100%!important}.fancybox-type-iframe .fancybox-inner{-webkit-overflow-scrolling:touch}.fancybox-iframe,.fancybox-image{display:block;width:100%;height:100%}.fancybox-image{width:100%;height:100%;max-width:100%;max-height:100%}#fancybox-loading,.fancybox-close,.fancybox-next span,.fancybox-prev span{background-image:url(../images/fancybox_sprite.png)}#fancybox-loading{position:fixed;top:50%;left:50%;margin-top:-22px;margin-left:-22px;background-position:0 -108px;opacity:.8;cursor:pointer;z-index:8060}.fancybox-close,.fancybox-nav,.fancybox-nav span{cursor:pointer;z-index:8040;position:absolute}#fancybox-loading div{width:44px;height:44px;background:url(../images/fancybox_loading.gif) center center no-repeat}.fancybox-close{top:-20px;right:-22px;width:36px;height:36px}.fancybox-nav{top:0;width:40%;height:100%;text-decoration:none;background:url(../images/blank.gif);-webkit-tap-highlight-color:transparent}.fancybox-prev{left:0}.fancybox-next{right:0}.fancybox-nav span{top:50%;width:36px;height:34px;margin-top:-18px;visibility:hidden}.fancybox-prev span{left:10px;background-position:0 -36px}.fancybox-next span{right:10px;background-position:0 -72px}.fancybox-nav:hover span{visibility:visible}.fancybox-tmp{position:absolute;top:-99999px;left:-99999px;visibility:hidden;max-width:99999px;max-height:99999px;overflow:visible!important}.fancybox-lock,.fancybox-lock body{overflow:hidden!important}.fancybox-lock{width:auto}.fancybox-lock-test{overflow-y:hidden!important}.fancybox-overlay{position:absolute;top:0;left:0;overflow:hidden;display:none;z-index:8010;background:url(../images/fancybox_overlay.png)}.fancybox-overlay-fixed{position:fixed;bottom:0;right:0}.fancybox-lock .fancybox-overlay{overflow:auto;overflow-y:scroll}.fancybox-title{visibility:hidden;font:400 13px/20px \"Helvetica Neue\",Helvetica,Arial,sans-serif;position:relative;text-shadow:none;z-index:8050}.fancybox-opened .fancybox-title{visibility:visible}");
	            	htmls.append("</style>");
	            }
	            
	            htmls.append("<style type=\"text/css\">");
	            if(!multiLanguageSupportRequired)
	            {
	            	htmls.append("abbr,address,article,aside,audio,b,blockquote,body,canvas,caption,cite,code,dd,del,details,dfn,div,dl,dt,em,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,ins,kbd,label,legend,li,mark,menu,nav,object,ol,p,pre,q,samp,section,small,span,strong,sub,summary,sup,table,tbody,td,tfoot,th,thead,time,tr,ul,var,video{margin:0;padding:0;border:0;outline:0;font-size:100%;vertical-align:baseline;background:0 0}body{line-height:1;font-family:Calibri;font-size:13px;color:#5d5e68;}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}nav ul{list-style:none}blockquote,q{quotes:none}blockquote:after,blockquote:before,q:after,q:before{content:'';content:none}a{margin:0;padding:0;font-size:100%;vertical-align:baseline;background:0 0;color:#069;text-decoration:none}a:hover{text-decoration:underline}ins{background-color:#ff9;color:#000;text-decoration:none}mark{background-color:#ff9;color:#000;font-style:italic;font-weight:700}del{text-decoration:line-through}abbr[title],dfn[title]{border-bottom:1px dotted;cursor:help}table{border-collapse:collapse;border-spacing:0}table tr th{border-top:1px solid #e8e8e8;border-bottom:1px solid #e8e8e8;padding:9px 10px 7px;text-align:left;color:#222;font-weight:400;vertical-align:middle}table tr td{border-bottom:1px solid #e8e8e8;border-top:1px solid #e8e8e8;border-left:0;padding:10px}hr{display:block;height:1px;border:0;border-top:1px solid #ccc;margin:1em 0;padding:0}input,select{vertical-align:middle}input[type=checkbox],input[type=radio]{width:13px;height:13px;border:0\\9;padding:0\\9}input[type=checkbox]:focus,input[type=radio]:focus{border:0}.pull-left{float:left!important}.pull-right{float:right!important}li{display:inline;list-style:none}img{vertical-align:middle;max-width:100%}.display{display:block}.o-hidden{overflow:hidden}.o-auto{overflow:auto}.clearfix{clear:both}p{line-height:20px;padding-top:20px;text-align:justify}h1,h2,h3,h4,h5,h6{color:#222;font-family:Calibri;font-weight:400}h1{font-size:23px}h2{font-size:20px}label{margin:4px}.alpha{padding-left:0!important}.omega{padding-right:0!important}.alpha1{margin-left:0!important}.omega1{margin-right:0!important}button{background:url(/resources/template/template1/images/grad.jpg) repeat-x;background:#fafafa;color:#069;padding:4px 10px;*padding:5px 3px 3px;cursor:pointer;border:1px solid #E8E8E8;line-height:15px;*line-height:13px;margin:4px;*margin:3px;transition:.5s;box-shadow:none}button:hover{background:#f2f2f2;transition:.5s}button[type=submit]:disabled{background:#666;color:#BEBEBE;border:1px solid #606060}.blue-button-big{padding:3px 10px;*padding:3px 0;height:31px\\9;*height:33px;background:#279CE7;color:#FFF;font-family:Calibri;font-size:20px;cursor:pointer;text-align:center;line-height:21px;border:1px solid #2096e1;transition:.5s;box-shadow:none}.test section.inner-right-bar{width:100%!important}.blue-button-small{line-height:23px;*line-height:21px;padding:0 10px!important;*padding:0 5px;font-size:16px;background:#279CE7;color:#FFF;font-family:Calibri;cursor:pointer;text-align:center;border:1px solid #2096e1;transition:.5s;box-shadow:none}.blue-button-big:hover,.blue-button-small:hover{color:#FFF;border:1px solid #000;background:#000;transition:.5s}.dropdown-btn{border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;border:1px solid #e3e3e3;padding-right:20px;background:url("+imagePath+"grad.jpg) repeat-x}.active{color:#222}.black{color:#222!important}.no-padding{padding:0!important}.border-left-none,.border-left-none tr td,.border-left-none tr th,table.border-left-none tr td,table.border-left-none tr th{border-left:0!important}.border-right-none,.border-right-none tr td,.border-right-none tr th,table.border-right-none tr td,table.border-right-none tr th{border-right:0!important}.border-top-none td,.border-top-none th,table.border-top-none td,table.border-top-none th{border-top:0!important}.border-bottom-none,.border-bottom-none td,.border-bottom-none th,table.border-bottom-none td,table.border-bottom-none th{border-bottom:0!important}.border-right{border-right:1px solid #E8E8E8}.border-top{border-top:1px solid #E8E8E8}.border-bottom{border-bottom:1px solid #E8E8E8}table.no-border tr td{border-top:0!important;border-bottom:0!important}.border-top-none{border-top:0!important}.go-back{line-height:25px;margin-top:8px;margin-bottom:8px;background:url("+imagePath+"\\resources\\template\\template1\\images\\go-back-button.png) no-repeat left;padding-left:12px;margin-right:12px}.red{color:red;font-weight:400}.a-center{text-align:center!important}.a-left{text-align:left!important}.a-right{text-align:right!important}.v-a-top{vertical-align:top!important}.v-a-middle{vertical-align:middle!important}.v-a-bottom{vertical-align:bottom!important}.m-top0{margin-top:0!important}.m-top1{margin-top:5px!important}.m-top2{margin-top:10px!important}.m-top3{margin-top:15px!important}.m-top4{margin-top:20px!important}.m-bottom-none{margin-bottom:0!important}.p-top-none{padding-top:0!important}.display-inline{display:inline!important}.display-line-block label{display:inline-block!important}.input-width{width:115px!important}.m-left_14{margin-left:14px}.mini-formfield textarea.cont-texarea{width:79%}.container_25{max-width:"+(dynPageSize!=0?dynPageSize:1024)+"px;margin:0 auto;padding:0 0 0}.container_25 .grid_1{width:2%}.container_25 .grid_2{width:6%}.container_25 .grid_3{width:10%}.container_25 .grid_4{width:14%}.container_25 .grid_5{width:18%}.container_25 .grid_6{width:22%}.container_25 .grid_7{width:26%}.container_25 .grid_8{width:30%}.container_25 .grid_9{width:34%}.container_25 .grid_10{width:38%}.container_25 .grid_11{width:42%}.container_25 .grid_12{width:46%}.container_25 .grid_13{width:50%}.container_25 .grid_14{width:54%}.container_25 .grid_15{width:58%}.container_25 .grid_16{width:62%}.container_25 .grid_17{width:66%}.container_25 .grid_18{width:70%}.container_25 .grid_19{width:74%}.container_25 .grid_20{width:78%}.container_25 .grid_21{width:82%}.container_25 .grid_22{width:86%}.container_25 .grid_23{width:90%}.container_25 .grid_24{width:94%}.container_25 .grid_25{width:98%}.container_25 .grid_26{width:100%}.container_25 .prefix1_10{margin-right:5px}.container_25 .prefix1_20{margin-right:10px}.container_25 .prefix1_30{margin-right:15px}.container_25 .prefix1_1{margin-left:5px}.container_25 .prefix1_2{margin-left:10px}.container_25 .prefix_1{padding-left:1.6%}.container_25 .prefix_2{padding-left:4%}.container_25 .prefix_2-px{padding-left:20px}.container_25 .prefix_3{padding-left:6%}.container_25 .prefix_4{padding-left:8%}.container_25 .prefix_5{padding-left:10%}.container_25 .prefix_6{padding-left:12%}.container_25 .prefix_7{padding-left:14%}.container_25 .prefix_8{padding-left:16%}.container_25 .prefix_9{padding-left:36%}.container_25 .prefix_10{padding-left:40%}.container_25 .prefix_11{padding-left:44%}.container_25 .prefix_12{padding-left:48%}.container_25 .prefix_13{padding-left:52%}.container_25 .prefix_14{padding-left:56%}.container_25 .prefix_15{padding-left:60%}.container_25 .prefix_16{padding-left:64%}.container_25 .prefix_17{padding-left:68%}.container_25 .prefix_18{padding-left:72%}.container_25 .prefix_19{padding-left:76%}.container_25 .prefix_20{padding-left:80%}.container_25 .prefix_21{padding-left:84%}.container_25 .prefix_22{padding-left:88%}.container_25 .prefix_23{padding-left:92%}.container_25 .prefix_24{padding-left:96%}.container_25 .suffix_1{padding-right:1.6%}.container_25 .suffix_2{padding-right:8%}.container_25 .suffix_3{padding-right:12%}.container_25 .suffix_4{padding-right:16%}.container_25 .suffix_5{padding-right:20%}.container_25 .suffix_6{padding-right:24%}.container_25 .suffix_7{padding-right:28%}.container_25 .suffix_8{padding-right:32%}.container_25 .suffix_9{padding-right:36%}.container_25 .suffix_10{padding-right:40%}.container_25 .suffix_11{padding-right:44%}.container_25 .suffix_12{padding-right:48%}.container_25 .suffix_13{padding-right:52%}.container_25 .suffix_14{padding-right:56%}.container_25 .suffix_15{padding-right:60%}.container_25 .suffix_16{padding-right:64%}.container_25 .suffix_17{padding-right:68%}.container_25 .suffix_18{padding-right:72%}.container_25 .suffix_19{padding-right:76%}.container_25 .suffix_20{padding-right:80%}.container_25 .suffix_21{padding-right:84%}.container_25 .suffix_22{padding-right:88%}.container_25 .suffix_23{padding-right:92%}.container_25 .suffix_24{padding-right:96%}.main_container{border-left:1px solid #d6d6d6;border-right:1px solid #d6d6d6;background:#FFF;max-width:"+(dynPageSize!=0?dynPageSize:1060)+"px;margin:0 auto;-moz-box-sizing:border-box;-webkit-box-sizing:border-box}header{background:url("+imagePath+"\\resources\\template\\template1\\images\\grad.jpg\\logo.png) no-repeat;position:relative}a.logo{display:block;height:145px;text-indent:-99999px}nav{text-align:right}nav li{color:#333}.top-nav li a{padding:0 10px;border-right:1px solid #ffc362;color:#333}nav li a:hover{color:#FFF;text-decoration:none}nav ul.top-nav{margin-bottom:0;margin-top:61px;margin-right:15px}nav ul.top-nav li img{padding-left:8px;margin-top:-4px;position:relative;top:1px}nav ul.bottom-nav{margin-bottom:0;margin-top:12px}nav ul.bottom-nav li{font-family:arial;color:#333;padding-left:10px}nav ul.bottom-nav li a{border-left:1px solid #ffc362;padding:0 10px;color:#333}nav ul.bottom-nav li a.border,nav ul.top-nav li:last-child a,ul.tab li a.border{border-right:0}.navbar-fixed-bottom,.navbar-fixed-top{float:right;width:auto}.header-link{margin-top:10px}.header-link li{list-style:none}.header-link li a{border:0!important;font-size:15px!important;padding:0 5px!important}.header-link fieldset{background:#f2f2f2;border:1px solid #e7e7e7;position:absolute;padding:5px;width:22%;margin-top:5px}.header-link fieldset label{display:block}.header-link fieldset input{width:92%}.header-link fieldset a{font-size:13px!important;margin-top:12px}.carat-arrow{position:relative;top:-13px;left:10px}.help-setting,.login-setting,.settings_menu{position:absolute;right:156px;top:100px;text-align:left;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;border:1px solid #FFC362;background:#fba823;z-index:9}.help-setting li,.login-setting li,.settings_menu li{display:block;line-height:28px;padding-left:0!important}.help-setting li a,.login-setting li a,.settings_menu li a{border-right:0;border-bottom:1px solid #FFC362;display:block;border-left:0!important}.settings_menu li:last-child a{border:0}.help-setting{position:absolute;right:0;top:76px}.marquee{margin:15px 1% 0}.content_section{position:relative}.left-bar{border:1px solid #efefef}.collapse{background:url(../images/expand-colllapse.png) no-repeat 0 0;display:block;width:20px;height:22px;text-indent:-99999px;position:absolute;left:175px;top:30px}.expand{background:url("+imagePath+"\\resources\\template\\template1\\images\\expand-colllapse.png) no-repeat -23px 0;display:block;width:17px;height:22px;text-indent:-99999px;position:absolute;top:30px;z-index:999}.list{margin-top:10px}.list li{background:url("+imagePath+"\\resources\\template\\template1\\images\\arrow.png) no-repeat left 7px;margin:0 0 0 10px;padding-left:10px;line-height:23px;font-family:arial;display:block}span.title{font-size:19px;font-family:arial;color:#222;display:block;border-top:1px solid #e8e8e8;background-color:#f5f5f5;border-bottom:1px solid #e8e8e8;padding:10px 0 10px 40px;margin:10px 0 0}.cat-icon{background:url("+imagePath+"\\resources\\template\\template1\\images\\category_icon.png) no-repeat 10px 9px}.category li a{color:#7c7d89;line-height:30px;display:block;padding-left:10px}.category li a:hover{background:#f2f2f2;color:#222;padding-left:6px;border-left:4px solid #ee9200;text-decoration:none}.ad-icon{background:url(../images/advertise-icon.png) no-repeat 10px 9px}.ad-banner_div{padding:10px}.ad-banner_div img{margin-bottom:5px}.middle-bar{margin-left:8px}.search-bar{border:3px solid #279ce7;height:39px;position:relative}.search-bar input[type=text]{width:64%}.advance-bar{background:#fcfcfc;border:1px solid #f1f1f1;font-size:11px;color:#222;padding:8px}.details-box{background:url(../images/divider.png) no-repeat bottom;padding-bottom:20px}.details-box span{display:block;color:#222}.details-box b{color:#222;font-weight:400}.bottom-btn{border:1px solid #EFEFEF;margin-top:10px;overflow:hidden;padding:2px}.bottom-btn button{margin-top:7px;*margin-top:4px}.bottom-btn span{margin:2px 0 0 10px;*margin:4px 0 0 10px;color:#222}.bottom-btn select{border:1px solid #EFEFEF;padding:5px\\9;box-shadow:none}button.show-btn{font-size:12px;font-family:arial;padding:0 10px;line-height:29px}.right-bar{border:1px solid #efefef}.ex-icon{background:url(../images/exhibitions-icon.png) no-repeat 10px 8px}.tender-icon{background:url(../images/tender-icon.png) no-repeat 10px 9px}footer{background:#fbfbfb;border-top:1px solid #e7e7e7;max-width:1058px;max-width:"+(dynPageSize!=0?dynPageSize:1060)+"px\\9;margin-left:auto;margin-right:auto;margin-top:25px}.footer-links span{font-size:20px;color:#222;padding-bottom:15px;display:block;font-family:arial}.footer-links li,.footer-links li a{line-height:25px;color:#6c6d79;font-family:arial;font-size:12px;display:block}.footer-links li a:hover{text-decoration:underline}.footer-links li b{color:#222;font-weight:400}.social-icons{line-height:60px;display:block;padding-left:56px;font-size:22px;font-family:arial}.social-icons:hover{opacity:.8}.fb{background:url(../images/f-icon.png) no-repeat left;color:#3a589b}.tw{background:url(../images/t-icon.png) no-repeat left;color:#3a589b}.l-in{background:url(../images/in-icon.png) no-repeat left;color:#3a589b}.copy{border-top:1px solid #e7e7e7;margin-top:10px;font-size:11px;padding:0 0 30px}.inner-right-bar{border-left:5px solid #ececec;width:81.21%;border-top:1px solid #E8E8E8;border-right:1px solid #E8E8E8;border-bottom:1px solid #E8E8E8}.border-left{border-left:1px solid #E8E8E8!important}.js #main .accordion{visibility:hidden}.js #side .accordion{display:none}.accordion li{list-style-type:none}#side ul.accordion ul{margin:0;padding:0 0 0 20px}.accordion .outer{border:1px solid #dadada;border-width:0 1px 1px;background:#fff}.accordion .inner{margin-bottom:0;padding:.5em 20px 1em;position:relative;overflow:hidden}.accordion .inner .inner{padding-bottom:0}a.accordion-title{background-color:#f5f5f5;padding:12px 12px 12px 37px;border-bottom:1px solid #e8e8e8;color:#222;font-size:15px}.submenu li a:hover,a.accordion-title:hover{text-decoration:none}.inbox-icon{background:url(../images/inbox-icon.png) no-repeat 15px}.admini-icon{background:url(../images/administrator-icon.png) no-repeat 14px}.auction-icon{background:url(../images/auction-icon.png) no-repeat 9px}.report-icon{background:url(../images/report-icon.png) no-repeat 13px}a.trigger{display:block}.submenu{background:#fafafa}.submenu li a{border-bottom:1px solid #eee;padding:10px 0 10px 35px;color:#5c5d67}.submenu li a.active,.submenu li a:hover{text-decoration:none;background:#FFF;color:#f59700;padding-left:31px;border-left:4px solid #f59700}.submenu-sub{background:#fdfdfd}.last-child a.trigger{background-image:none;font-weight:400}.submenu-sub li.last-child a{padding-left:41px}.submenu-sub li.last-child a:hover{padding-left:37px}#main a.trigger{background-color:#f0f0f0}#main a.trigger.open{border-color:#dadada;background-color:#e7e7e7}#main a:active.trigger.open,#main a:focus.trigger.open,#main a:hover.trigger.open{border-color:#bcd}#side a.active{font-weight:700;color:#f72;text-decoration:none}a.important{background:url(../images/star.png) no-repeat;text-indent:-99999px;display:block;height:16px;width:17px}a.important:hover{background:url(../images/star.png) no-repeat center -16px}.breadcrumb{background:#F6F6F6}.breadcrumb li a{color:#222;padding:0 10px 0 2px;background:url(../images/arrow.png) right no-repeat;line-height:25px}.breadcrumb li a:hover{text-decoration:none;color:#069}.breadcrumb li:last-child a{background:none!important}.breadcrumb li a.active{color:#069;text-decoration:none}.page-title{position:relative;line-height:40px;border-bottom:1px solid #e8e8e8;background:#FBFBFB}.inbox-searchbar{margin-top:3px}#errorDivNor{display:block;margin:-10px 0 0 5px;float:left}.inbox-searchbar input{padding:5px;margin-top:4px\\9;*margin-top:4px}.adv-srch{line-height:35px}.div-header-link div{padding:3px 2px 2px;float:left}.div-header-link div.creat-client{padding:12px 10px 10px 0}.div-header-link div.creat-client a{border:0;background:0 0;float:none;padding:0 2px 0 5px;display:inline}.div-header-link a{background:url("+imagePath+"grad.jpg) repeat-x!important;padding:14px 25px 13px;float:left;border-right:1px solid #d3d3d3;display:block}.div-header-link a.active,.div-header-link a:hover{background:#FFF;text-decoration:none;color:#222;border-bottom:2px solid #757575;padding:14px 15px 11px}.gradi{background:none repeat scroll 0 0 #FBFBFB}.pagination{padding:5px 10px!important;line-height:29px}.pagination div button{margin:2px 0 0 5px;margin:3px 0 0 5px}.pagination div li a{padding:0 10px;line-height:28px;color:#222}.pagination input{margin:3px 0 0 5px;padding:4px;width:30px!important}.content-div{padding:10px 13px 10px 10px}.listing-div{border:1px solid #ECECEC;padding:0 10px}.listing-tab{margin:10px 0 0;overflow:hidden;border:1px solid #ECECEC;border-bottom:0;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.listing-tab li a{padding:10px 20px;display:block;float:left;color:#7C7D89;font-size:18px;border-right:1px solid #ECECEC;font-family:arial}.listing-tab li a.active,.listing-tab li a:hover{text-decoration:none;color:#ee9200;background:url(../images/orange-arrow.png) no-repeat center 33px;border-bottom:2px solid #ee9200}.bidding-row-highlight{background-color:#cae5ff}.bidDetailHighlight{background-color:#FAF2DC;color:#000;font:700}.view-event table tr td{border:0;width:25%;border-bottom:1px solid #ECECEC;padding:3px 5px 3px 15px}.view-info{margin-top:10px}.view-info table tr td{border:0;padding:5px 5px 5px 15px}.view-info label{display:block}.view-event table tr td label span{color:red}.view-event label{margin:2px 0;line-height:18px;display:block;color:#404040}.view-event h2{padding:3px 0}.table-border table tr th{text-align:center}.mandatory1{padding:3px 0 0 20px}.cursor{cursor:pointer}.row-highlight{background-color:#d8f4d2}.view-event p{padding:0}.view-event li{list-style:inherit;display:list-item}.item-price-75{width:75%;display:block}.item-price-94{width:94%;display:block}.defcomp{width:50%!important;margin-top:10px!important;margin-bottom:10px!important;margin-right:10px!important}.defcomptext{width:46.5%!important;margin-top:10px!important;margin-bottom:10px!important;margin-right:10px!important}.mini-formfield{margin-top:20px;border-bottom:1px solid #E8E8E8;padding-bottom:15px}.mini-formfield li{line-height:18px}.mini-formfield table tr td{border:0;padding-top:5px;padding-bottom:5px}.mini-formfield table tr td label{margin-top:12px}.display-block table tr td label{display:block}.mini-formfield table tr td span{color:red}.mini-formfield input,.mini-formfield textarea{margin:0;width:90%}.mini-formfield select{margin:0;width:96%}.mini-formfield input[type=checkbox],.mini-formfield input[type=radio]{margin:5px;width:auto}.mini-formfield input.dateBox{width:79%!important}.table-border table tr td,.table-border table tr th{border-left:1px solid #E8E8E8}.table-border table tr td input[type=text],.table-border table tr td select{width:200px}.table-border table tr td textarea{width:92%;min-height:50px}.table-border p{padding-top:0;padding-bottom:10px;text-align:left}.label-span{color:#5D5E68!important}.white{background-color:#fff}.matrix-table button{margin:4px;padding:4px 5px}.matrix-table input[type=file]{margin:0 4px}.matrix-table input,.matrix-table textArea{width:150px}.matrix-table select{width:162px}.matrix-table .nmbr-select{width:60px}.row-table table tr td{border:0;padding:5px}.row-table table input{width:90%}.row-table table select{width:97%}.add-confi-icn,.approve-icn,.approve-rights-icn,.assign-rights-icn,.auction-icn,.deptree-icn,.dft-setting-icn,.disable-icn,.document-icn,.edit-icn,.enabel-icn,.industry-icn,.mail-icn,.plus-icn,.reject-icn,.rend-mail-icn,.reset-password-icn,.setting-icn,.terms-icn,.theme-icn,.unalock-icn,.unamap-icn,.user-remail-icn,.user-renew-icn{background:url(../images/sprite.png) no-repeat -13px -90px;display:block;float:left;height:20px;margin:0 1px;text-indent:-9999px;width:26px}.theme-icn{background-position:-40px -90px}.dft-setting-icn{background-position:-67px -90px}a.approve-icn{background-position:-95px -90px}.setting-icn{background-position:-120px -90px}.deptree-icn{background-position:-146px -90px}.mail-icn{background-position:-173px -90px}.plus-icn{background-position:-200px -90px}.reject-icn{background-position:-226px -90px}.auction-icn{background-position:-256px -90px}.enabel-icn{background-position:-284px -90px}.industry-icn{background-position:-310px -90px}.rend-mail-icn{background-position:-337px -90px}.unalock-icn{background-position:-363px -88px}.user-remail-icn{background-position:-392px -88px}.user-renew-icn{background-position:-423px -88px}.add-confi-icn{background-position:-454px -88px}.unamap-icn{background-position:-19px -120px}.document-icn{background-position:-50px -119px}.assign-rights-icn{background-position:-82px -120px}.disable-icn{background-position:-110px -120px}.reset-password-icn{background-position:-139px -122px}.approve-rights-icn{background-position:-165px -122px}.terms-icn{background-position:-192px -122px}.errorMsg,.noticeMsg,.successMsg,infoMsg{border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.successMsg{background:url(../images/successIcn.png) no-repeat scroll 10px center #E9F9E5;border:1px solid #B4E8AA;color:#1C8400;margin-bottom:5px;padding:10px 10px 10px 50px}.errorMsg{background:url(../images/errorIcn.png) no-repeat scroll 10px center #F9E5E6;border:1px solid #E8AAAD;color:#B50007;margin-bottom:5px;padding:10px 10px 10px 50px}.noticeMsg{background:url(../images/noticeIcn.png) no-repeat scroll 10px center #F9F9E5;border:1px solid #E8E3AA;color:#828400;padding:10px 10px 10px 50px}.noticeMsg li{line-height:20px;list-style:decimal outside none!important;margin-left:18px;display:list-item}.infoMsg{background:url(../images/infoIcn.png) no-repeat scroll 5px 3px #fbf8e9;border:1px solid #fec600;color:#87836d;width:230px;position:relative;padding:5px 5px 5px 28px}.infoMsg span{position:absolute;display:block;top:-11px;left:22px}.validationMsg{color:red;padding:5px 0 0 2px}.helpMsg{color:#03a200}.doc-table tr th .doc-table tr td{padding:7px;line-height:18px;text-align:left;width:auto!important}.doc-table tr th{text-align:center}span.arrow{border-left:5px solid transparent;border-right:5px solid transparent;border-top:7px solid #000;display:block;height:1px;left:40px;position:relative;top:3px;width:1px}.popupbox select{width:93.5%!important}.popup-title h3{font-size:20px;color:#222;background:#e3e3e3;padding:10px}.login-pop{width:400px}.user-pop{width:500px}/*! fancyBox v2.1.5 fancyapps.com | fancyapps.com/fancybox/#license */.fancybox-image,.fancybox-inner,.fancybox-nav,.fancybox-nav span,.fancybox-outer,.fancybox-skin,.fancybox-tmp,.fancybox-wrap,.fancybox-wrap iframe,.fancybox-wrap object{padding:0;margin:0;border:0;outline:0;vertical-align:top}.fancybox-wrap{position:absolute;top:0;left:0;z-index:8020;width:auto!important}.fancybox-skin{position:relative;background:#f9f9f9;color:#444;text-shadow:none;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;border:5px solid #e3e3e3;padding:0!important;border-top:0}.fancybox-opened{z-index:8030}.fancybox-opened .fancybox-skin{-webkit-box-shadow:0 10px 25px rgba(0,0,0,.5);-moz-box-shadow:0 10px 25px rgba(0,0,0,.5);box-shadow:0 10px 25px rgba(0,0,0,.5)}.fancybox-inner,.fancybox-outer{position:relative}.fancybox-inner{overflow:hidden;width:100%!important}.fancybox-type-iframe .fancybox-inner{-webkit-overflow-scrolling:touch}.fancybox-iframe,.fancybox-image{display:block;width:100%;height:100%}.fancybox-image{width:100%;height:100%;max-width:100%;max-height:100%}#fancybox-loading,.fancybox-close,.fancybox-next span,.fancybox-prev span{background-image:url(../images/fancybox_sprite.png)}#fancybox-loading{position:fixed;top:50%;left:50%;margin-top:-22px;margin-left:-22px;background-position:0 -108px;opacity:.8;cursor:pointer;z-index:8060}#fancybox-loading div{width:44px;height:44px;background:url(../images/fancybox_loading.gif) center center no-repeat}.fancybox-close{position:absolute;top:-20px;right:-22px;width:36px;height:36px;cursor:pointer;z-index:8040}.fancybox-nav{position:absolute;top:0;width:40%;height:100%;cursor:pointer;text-decoration:none;background:transparent url(../images/blank.gif);-webkit-tap-highlight-color:rgba(0,0,0,0);z-index:8040}.fancybox-prev{left:0}.fancybox-next{right:0}.fancybox-nav span{position:absolute;top:50%;width:36px;height:34px;margin-top:-18px;cursor:pointer;z-index:8040;visibility:hidden}.fancybox-prev span{left:10px;background-position:0 -36px}.fancybox-next span{right:10px;background-position:0 -72px}.fancybox-nav:hover span{visibility:visible}.fancybox-tmp{position:absolute;top:-99999px;left:-99999px;visibility:hidden;max-width:99999px;max-height:99999px;overflow:visible!important}.fancybox-lock{overflow:hidden!important;width:auto}.fancybox-lock body{overflow:hidden!important}.fancybox-lock-test{overflow-y:hidden!important}.fancybox-overlay{position:absolute;top:0;left:0;overflow:hidden;display:none;z-index:8010;background:url(../images/fancybox_overlay.png)}.fancybox-overlay-fixed{position:fixed;bottom:0;right:0}.fancybox-lock .fancybox-overlay{overflow:auto;overflow-y:scroll}.fancybox-title{visibility:hidden;font:400 13px/20px \"Helvetica Neue\",Helvetica,Arial,sans-serif;position:relative;text-shadow:none;z-index:8050}.fancybox-opened .fancybox-title{visibility:visible}.fancybox-title-float-wrap{position:absolute;bottom:0;right:50%;margin-bottom:-35px;z-index:8050;text-align:center}.fancybox-title-float-wrap .child{display:inline-block;margin-right:-100%;padding:2px 20px;background:0 0;background:rgba(0,0,0,.8);-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px;text-shadow:0 1px 2px #222;color:#FFF;font-weight:700;line-height:24px;white-space:nowrap}.fancybox-title-outside-wrap{position:relative;margin-top:10px;color:#fff}.fancybox-title-inside-wrap{padding-top:10px}.fancybox-title-over-wrap{position:absolute;bottom:0;left:0;color:#fff;padding:10px;background:#000;background:rgba(0,0,0,.8)}.fancybox-custom .fancybox-skin{box-shadow:0 0 50px #222}element.style{display:block}@media only screen and (-webkit-min-device-pixel-ratio:1.5),only screen and (min--moz-device-pixel-ratio:1.5),only screen and (min-device-pixel-ratio:1.5){#fancybox-loading,.fancybox-close,.fancybox-next span,.fancybox-prev span{background-image:url(../images/fancybox_sprite@2x.png);background-size:44px 152px}#fancybox-loading div{background-image:url(../images/fancybox_loading@2x.gif);background-size:24px 24px}}.timer{border-top:1px solid #dbedff;border-bottom:1px solid #dbedff;border-radius:2px;background:#eef8ff}.rmn-time{margin:10px 20px 10px 10px}.rmn-time img{margin-right:10px}.se-time{margin-top:10px;margin-left:10px}.timer p{margin:0;padding:0}.points{margin-top:15px}.points li{display:block;line-height:24px;background:url(../images/li-arrow.png) no-repeat left;padding-left:20px}.faq-div h3{padding:10px;color:#069;border:1px solid #E8E8E8;background:url("+imagePath+"\\resources\\template\\template1\\images\\grad.jpg) repeat-x;font-family:arial;cursor:pointer;margin-bottom:2px;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.faq-div div{border:1px solid #E8E8E8;border-top:0;display:none;padding:10px;padding-bottom:0;margin-bottom:5px;margin-top:-5px;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.faq-div div p{margin-bottom:20px;padding-top:0}.multy-section section.inner-right-bar{width:100%!important}@media screen and (-webkit-min-device-pixel-ratio:0){.div-header-link div{padding:4px 0 2px 2px}.search-bar{height:37px}.bottom-btn span{margin:1px 0 0 10px}.search-input{padding:10px}.assign-checkbox label input{height:16px;width:16px}}@media screen and (max-width:1023px){.container_25{max-width:768px}.rel-width-left{width:22.7%!important}.rel-width-mid{width:76%!important}.container_25 .grid_7{width:100%}nav{display:none}}.timer-div tr td p {padding:0 !important;margin:0;}.timer-div tr td{vertical-align:middle;}.timer-div{background:#E8F8FF;}.timer-sticky{border-top:1px solid #dbedff;border-bottom:1px solid #dbedff;border-radius:2px;background:#e8f8ff;position:relative;padding:0 10px;}.nav-sticky {padding: 25px 0;background-color: white;position: -webkit-sticky;}.form-hd-ft-clr{background:#fdfdfd;}.view-event-3 p{padding:0;}.no-border{border:0 !important;}");
	            }
	            htmls.append(".noprint{ display: none; }");
	            htmls.append(".question-box{ border-bottom: 1px solid #E8E8E8; padding:10px;}.question-div span{font-size:14px;color:#222222;float: left;}.question-div p{ font-size:14px; color:#222222; position:relative; top:-3px; left: 5px; padding-bottom: 5px;}.rephrase-div p { color: #222222; font-size: 13px; left: 5px; position: relative; top: -3px;}.rephrase-div span{color: #222222; font-size: 13px; float:left;}.asked-ansed-div{ overflow: hidden;}.rephrase-div,.ans-div,.asked-ansed-div{padding-left:15px;}");
	            htmls.append(".width-212{width: 212px;}.width-546{width: 540px;}.width-685{width: 683px;}.width-267{width: 267px;}.event-dtl table tr td{border-top:1px solid #E8E8E8 !important;border-bottom:1px solid #E8E8E8 !important;}.event-dtl p{padding: 0;	border-bottom:none !important; text-align:justify;}.width-555WithAuto{width:555px;overflow:auto;}.width-695WithAuto{width:695px;overflow:auto;}.width-785WithAuto{width:785px;overflow:auto;}.width-695WithAuto{width:695px;overflow:auto;}.width-555WithAuto table tr td:first-child,.width-695WithAuto table tr td:first-child,.width-630WithAuto table tr td:first-child,.width-785WithAuto table tr td:first-child{border-left:0 !important;}.width-555WithAuto table tr td:last-child,.width-695WithAuto table tr td:last-child,.width-630WithAuto table tr td:first-childm,.width-785WithAuto table tr td:first-child{border-right:0 !important;}.para-word-break p{word-break:break-word;}.word-break{word-break:break-word;}");
	            htmls.append(".listing-style li {list-style: decimal;margin-left: 20px;display: list-item;line-height: 20px;}");
	            htmls.append(".border-none{ border:none !important; } .light-yellow{ background:#ffffed;} .kpi-datatable-caption {font-size: 24px; padding-bottom: 5px; padding-left: 5px; padding-top: 10px; text-align: left;}");
	            htmls.append(".table-row-highlightedColor {background-color: #FFFF99;}");
				htmls.append(".table-column-highlightedColor{color: red;}");
				htmls.append(".chat-faq{padding:10px;clear:both}.chat-faq .cd-faq-trigger{padding:0}.chat-faq > ul > li{padding:7px 10px 12px}.chat-faq .cd-faq-content{padding:0}.chat-main{display:table;width:100%}.chat-main li{display:table-cell;vertical-align:middle;padding:10px}.chat-main li:first-child{padding-right:0}.faq-chat-box{border-radius:4px;padding:15px;box-shadow:0 0 5px 0 rgba(0,0,0,0.1);border:1px solid #ededed}.chat-block{border-radius:100%;text-align:center;text-transform:uppercase;padding:10px;font-size:20px;width:25px;height:25px;display:table;color:#222;border:1px solid transparent}.chat-block span{display:table-cell;vertical-align:middle}.chat-o{border-color:#6ecacc;color:#6ecacc}.chat-b{border-color:#f29c89;color:#f29c89}.chat-info-qus{font-size:10px;color:#adadad;font-family:'lucida_granderegular';padding-top:10px}.chat-info-qus span{border:1px solid transparent;padding:3px 5px 2px;border-radius:10px}.chat-info-qus span.officer{border-color:#68c6c8;color:#68c6c8}.chat-info-qus span.bidder{border-color:#f29c89;color:#f29c89}.chat-info{font-size:12px;color:#adadad}.chat-info .small-clock-icon{opacity:0.6}.module-nm{border:1px solid #edeef3;background:#f2f4f8;color:#adadad;font-size:12px;border-radius:10px;padding:2px 5px;margin-left:5px}.post-div{background:#f8f8f8;border-top:1px solid #ededed;margin:10px 0 -12px -10px;padding:5px 10px;width:100%;display:table;width:100%}.post-div li{display:table-cell;vertical-align:middle}.post-div li:first-child{width:95%;padding-right:10px}.post-div textarea{box-shadow:none;width:100%;box-sizing:border-box;margin:0;height:50px;max-height:50px;padding-right:50px}.post-div button{margin:8px 0}.view-doc{position:relative}.view-doc div{padding-top:20px;position:absolute;right:0;top:8px}.view-doc a:hover{text-decoration:none}.doc-dropdown{display:none;border-radius:3px;background:#fff;box-shadow:0 0 5px 0 rgba(0, 0, 0, 0.2);border:1px solid #dbdbdb;padding:7px 13px 7px 30px;width:200px}.doc-dropdown li{display:list-item;text-align:left;padding:5px 0;line-height:16px;list-style-type:decimal}.doc-dropdown li a{padding:5px 0;font-size:11px}.doc-dropdown li a:hover{color:#222}.view-doc:hover .doc-dropdown{display:block}");
	            htmls.append("</style>");
	            if(multiLanguageSupportRequired)
	            {
	            	htmls.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">");
	            }
	            htmls.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"></head>");
	        } else { 
	        // htmls.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");      // bug #22842, #23064
	        htmls.append("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">");
	        htmls.append("<html xmlns=\"http://www.w3.org/1999/xhtml\">");
	        /*htmls.append("<head><style type=\"text/css\">");
	         htmls.append("body{text-decoration: none; font-family: Arial, Verdana,Helvetica,sans-serif; font-size:12px;}");
	         htmls.append("</style></head>");*/
	        htmls.append("<head>");
	        if(multiLanguageSupportRequired)
	        {
//		        htmls.append("<link rel='stylesheet' href='http://etender-uat.abcprocure.com:9090/EPROC/resources/template/template1/css/pdfstyle.css' />");	        	
//	        	htmls.append("<link rel='stylesheet' href='"+cssPath+"' />");	Bug #43132 By Jitendra.
	        	htmls.append("<style type=\"text/css\">");
            	htmls.append("a,ins{text-decoration:none}table tr td,table tr th{border-bottom:1px solid #e8e8e8;border-top:1px solid #e8e8e8}article,aside,details,figcaption,figure,footer,header,hgroup,hr,menu,nav,section{display:block}a,hr{padding:0}hr,input[type=checkbox]:focus,input[type=radio]:focus{border:0}a,button{color:#069}.header-link li,li,nav ul{list-style:none}abbr,address,article,aside,audio,b,blockquote,body,canvas,caption,cite,code,dd,del,details,dfn,div,dl,dt,em,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,ins,kbd,label,legend,li,mark,menu,nav,object,ol,p,pre,q,samp,section,small,span,strong,sub,summary,sup,table,tbody,td,tfoot,th,thead,time,tr,ul,var,video{margin:0;padding:0;border:0;outline:0;font-size:100%;vertical-align:baseline;background:0 0}img,input,select,table tr th{vertical-align:middle}ins,mark{background-color:#ff9;color:#000}body{line-height:1;font-size:13px;color:#5d5e68}blockquote,q{quotes:none}blockquote:after,blockquote:before,q:after,q:before{content:'';content:none}a{margin:0;font-size:100%;vertical-align:baseline;background:0 0}a:hover{text-decoration:underline}mark{font-style:italic;font-weight:700}del{text-decoration:line-through}abbr[title],dfn[title]{border-bottom:1px dotted;cursor:help}table{border-collapse:collapse;border-spacing:0}table tr th{padding:9px 10px 7px;text-align:left;color:#222;font-weight:400}table tr td{border-left:0;padding:10px}hr{height:1px;border-top:1px solid #ccc;margin:1em 0}input[type=checkbox],input[type=radio]{width:13px;height:13px;border:none;padding:0\\9}.pull-left{float:left!important}.pull-right{float:right!important}li{display:inline}img{max-width:100%}.display{display:block}.o-hidden{overflow:hidden}.o-auto{overflow:auto}.clearfix{clear:both}p{line-height:20px;padding-top:20px;text-align:justify}h1,h2,h3,h4,h5,h6{color:#222;font-weight:400}h1{font-size:23px}h2{font-size:20px}label{margin:4px}.alpha{padding-left:0!important}.omega{padding-right:0!important}.alpha1{margin-left:0!important}.omega1{margin-right:0!important}button{background:#fafafa;padding:4px 10px;cursor:pointer;border:1px solid #E8E8E8;line-height:15px;margin:4px;transition:.5s;box-shadow:none}button:hover{background:#f2f2f2;transition:.5s}button[type=submit]:disabled{background:#666;color:#BEBEBE;border:1px solid #606060}.blue-button-big,.blue-button-small{background:#279CE7;text-align:center;border:1px solid #2096e1;color:#FFF;transition:.5s;box-shadow:none;cursor:pointer}.blue-button-big{padding:3px 10px;height:31px;font-size:20px;line-height:21px}.test section.inner-right-bar{width:100%!important}.blue-button-small{line-height:23px;padding:0 10px!important;font-size:16px}.blue-button-big:hover,.blue-button-small:hover{color:#FFF;border:1px solid #000;background:#000;transition:.5s}.dropdown-btn{border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;border:1px solid #e3e3e3;padding-right:20px}.active{color:#222}.black{color:#222!important}.no-padding{padding:0!important}.border-left-none,.border-left-none tr td,.border-left-none tr th,table.border-left-none tr td,table.border-left-none tr th{border-left:0!important}.border-right-none,.border-right-none tr td,.border-right-none tr th,table.border-right-none tr td,table.border-right-none tr th{border-right:0!important}.border-top-none td,.border-top-none th,table.border-top-none td,table.border-top-none th{border-top:0!important}.border-bottom-none,.border-bottom-none td,.border-bottom-none th,table.border-bottom-none td,table.border-bottom-none th{border-bottom:0!important}.border-right{border-right:1px solid #E8E8E8}.border-top{border-top:1px solid #E8E8E8}.border-top-none,table.no-border tr td{border-top:0!important}.border-bottom{border-bottom:1px solid #E8E8E8}table.no-border tr td{border-bottom:0!important}.go-back{line-height:25px;margin-top:8px;margin-bottom:8px;padding-left:12px;margin-right:12px}.red{color:red;font-weight:400}.a-center{text-align:center!important}.a-left{text-align:left!important}.a-right{text-align:right!important}.v-a-top{vertical-align:top!important}.v-a-middle{vertical-align:middle!important}.v-a-bottom{vertical-align:bottom!important}.m-top0{margin-top:0!important}.m-top1{margin-top:5px!important}.m-top2{margin-top:10px!important}.m-top3{margin-top:15px!important}.m-top4{margin-top:20px!important}.m-bottom-none{margin-bottom:0!important}.p-top-none{padding-top:0!important}.display-inline{display:inline!important}.display-line-block label{display:inline-block!important}.input-width{width:115px!important}.m-left_14{margin-left:14px}.mini-formfield textarea.cont-texarea{width:79%}.container_25{max-width:"+(dynPageSize!=0?dynPageSize:1024)+"px;margin:0 auto;padding:0}.container_25 .grid_1{width:2%}.container_25 .grid_2{width:6%}.container_25 .grid_3{width:10%}.container_25 .grid_4{width:14%}.container_25 .grid_5{width:18%}.container_25 .grid_6{width:22%}.container_25 .grid_7{width:26%}.container_25 .grid_8{width:30%}.container_25 .grid_9{width:34%}.container_25 .grid_10{width:38%}.container_25 .grid_11{width:42%}.container_25 .grid_12{width:46%}.container_25 .grid_13{width:50%}.container_25 .grid_14{width:54%}.container_25 .grid_15{width:58%}.container_25 .grid_16{width:62%}.container_25 .grid_17{width:66%}.container_25 .grid_18{width:70%}.container_25 .grid_19{width:74%}.container_25 .grid_20{width:78%}.container_25 .grid_21{width:82%}.container_25 .grid_22{width:86%}.container_25 .grid_23{width:90%}.container_25 .grid_24{width:94%}.container_25 .grid_25{width:98%}.container_25 .grid_26{width:100%}.container_25 .prefix1_10{margin-right:5px}.container_25 .prefix1_20{margin-right:10px}.container_25 .prefix1_30{margin-right:15px}.container_25 .prefix1_1{margin-left:5px}.container_25 .prefix1_2{margin-left:10px}.container_25 .prefix_1{padding-left:1.6%}.container_25 .prefix_2{padding-left:4%}.container_25 .prefix_2-px{padding-left:20px}.container_25 .prefix_3{padding-left:6%}.container_25 .prefix_4{padding-left:8%}.container_25 .prefix_5{padding-left:10%}.container_25 .prefix_6{padding-left:12%}.container_25 .prefix_7{padding-left:14%}.container_25 .prefix_8{padding-left:16%}.container_25 .prefix_9{padding-left:36%}.container_25 .prefix_10{padding-left:40%}.container_25 .prefix_11{padding-left:44%}.container_25 .prefix_12{padding-left:48%}.container_25 .prefix_13{padding-left:52%}.container_25 .prefix_14{padding-left:56%}.container_25 .prefix_15{padding-left:60%}.container_25 .prefix_16{padding-left:64%}.container_25 .prefix_17{padding-left:68%}.container_25 .prefix_18{padding-left:72%}.container_25 .prefix_19{padding-left:76%}.container_25 .prefix_20{padding-left:80%}.container_25 .prefix_21{padding-left:84%}.container_25 .prefix_22{padding-left:88%}.container_25 .prefix_23{padding-left:92%}.container_25 .prefix_24{padding-left:96%}.container_25 .suffix_1{padding-right:1.6%}.container_25 .suffix_2{padding-right:8%}.container_25 .suffix_3{padding-right:12%}.container_25 .suffix_4{padding-right:16%}.container_25 .suffix_5{padding-right:20%}.container_25 .suffix_6{padding-right:24%}.container_25 .suffix_7{padding-right:28%}.container_25 .suffix_8{padding-right:32%}.container_25 .suffix_9{padding-right:36%}.container_25 .suffix_10{padding-right:40%}.container_25 .suffix_11{padding-right:44%}.container_25 .suffix_12{padding-right:48%}.container_25 .suffix_13{padding-right:52%}.container_25 .suffix_14{padding-right:56%}.container_25 .suffix_15{padding-right:60%}.container_25 .suffix_16{padding-right:64%}.container_25 .suffix_17{padding-right:68%}.container_25 .suffix_18{padding-right:72%}.container_25 .suffix_19{padding-right:76%}.container_25 .suffix_20{padding-right:80%}.container_25 .suffix_21{padding-right:84%}.container_25 .suffix_22{padding-right:88%}.container_25 .suffix_23{padding-right:92%}.container_25 .suffix_24{padding-right:96%}.main_container{border-left:1px solid #d6d6d6;border-right:1px solid #d6d6d6;background:#FFF;max-width:"+(dynPageSize!=0?dynPageSize:1060)+"px;margin:0 auto;-moz-box-sizing:border-box;-webkit-box-sizing:border-box}header{position:relative}a.logo{display:block;height:145px;text-indent:-99999px}nav{text-align:right}nav li{color:#333}.top-nav li a{padding:0 10px;border-right:1px solid #ffc362;color:#333}nav li a:hover{color:#FFF;text-decoration:none}nav ul.top-nav{margin-bottom:0;margin-top:61px;margin-right:15px}nav ul.top-nav li img{padding-left:8px;margin-top:-4px;position:relative;top:1px}nav ul.bottom-nav{margin-bottom:0;margin-top:12px}nav ul.bottom-nav li{color:#333;padding-left:10px}nav ul.bottom-nav li a{border-left:1px solid #ffc362;padding:0 10px;color:#333}nav ul.bottom-nav li a.border,nav ul.top-nav li:last-child a,ul.tab li a.border{border-right:0}.navbar-fixed-bottom,.navbar-fixed-top{float:right;width:auto}.header-link{margin-top:10px}.header-link li a{border:0!important;font-size:15px!important;padding:0 5px!important}.header-link fieldset{background:#f2f2f2;border:1px solid #e7e7e7;position:absolute;padding:5px;width:22%;margin-top:5px}.header-link fieldset label{display:block}.header-link fieldset input{width:92%}.header-link fieldset a{font-size:13px!important;margin-top:12px}.carat-arrow{position:relative;top:-13px;left:10px}.help-setting,.login-setting,.settings_menu{position:absolute;right:156px;top:100px;text-align:left;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;border:1px solid #FFC362;background:#fba823;z-index:9}.help-setting li,.login-setting li,.settings_menu li{display:block;line-height:28px;padding-left:0!important}.help-setting li a,.login-setting li a,.settings_menu li a{border-right:0;border-bottom:1px solid #FFC362;display:block;border-left:0!important}.settings_menu li:last-child a{border:0}.help-setting{position:absolute;right:0;top:76px}.marquee{margin:15px 1% 0}.content_section{position:relative}.collapse,.expand{height:22px;position:absolute;top:30px;display:block;text-indent:-99999px}.left-bar{border:1px solid #efefef}.collapse{background:url(../images/expand-colllapse.png) no-repeat;width:20px;left:175px}.expand{width:17px;z-index:999}.accordion .inner,.infoMsg,.page-title,.search-bar{position:relative}.list{margin-top:10px}.list li{margin:0 0 0 10px;padding-left:10px;line-height:23px;display:block}span.title{font-size:19px;color:#222;display:block;border-top:1px solid #e8e8e8;background-color:#f5f5f5;border-bottom:1px solid #e8e8e8;padding:10px 0 10px 40px;margin:10px 0 0}.category li a{color:#7c7d89;line-height:30px;display:block;padding-left:10px}.category li a:hover{background:#f2f2f2;color:#222;padding-left:6px;border-left:4px solid #ee9200;text-decoration:none}.ad-icon{background:url(../images/advertise-icon.png) 10px 9px no-repeat}.ad-banner_div{padding:10px}.ad-banner_div img{margin-bottom:5px}.middle-bar{margin-left:8px}.search-bar{border:3px solid #279ce7;height:39px}.search-bar input[type=text]{width:64%}.advance-bar{background:#fcfcfc;border:1px solid #f1f1f1;font-size:11px;color:#222;padding:8px}.details-box{background:url(../images/divider.png) bottom no-repeat;padding-bottom:20px}.details-box span{display:block;color:#222}.details-box b{color:#222;font-weight:400}.bottom-btn{border:1px solid #EFEFEF;margin-top:10px;overflow:hidden;padding:2px}.bottom-btn button{margin-top:7px}.bottom-btn span{margin:2px 0 0 10px;color:#222}.bottom-btn select{border:1px solid #EFEFEF;padding:5px;box-shadow:none}button.show-btn{font-size:12px;padding:0 10px;line-height:29px}.right-bar{border:1px solid #efefef}.copy,footer{border-top:1px solid #e7e7e7}.ex-icon{background:url(../images/exhibitions-icon.png) 10px 8px no-repeat}.tender-icon{background:url(../images/tender-icon.png) 10px 9px no-repeat}footer{background:#fbfbfb;max-width:1058px;max-width:"+(dynPageSize!=0?dynPageSize:1060)+"px;margin-left:auto;margin-right:auto;margin-top:25px}.footer-links span{font-size:20px;color:#222;padding-bottom:15px;display:block}.footer-links li,.footer-links li a{line-height:25px;color:#6c6d79;font-size:12px;display:block}.footer-links li a:hover{text-decoration:underline}#side a.active,.submenu li a:hover,a.accordion-title:hover{text-decoration:none}.footer-links li b{color:#222;font-weight:400}.fb,.l-in,.tw{color:#3a589b}.social-icons{line-height:60px;display:block;padding-left:56px;font-size:22px}.social-icons:hover{opacity:.8}.fb{background:url(../images/f-icon.png) left no-repeat}.tw{background:url(../images/t-icon.png) left no-repeat}.l-in{background:url(../images/in-icon.png) left no-repeat}.copy{margin-top:10px;font-size:11px;padding:0 0 30px}.inner-right-bar{border-left:5px solid #ececec;width:81.21%;border-top:1px solid #E8E8E8;border-right:1px solid #E8E8E8;border-bottom:1px solid #E8E8E8}.border-left{border-left:1px solid #E8E8E8!important}.js #main .accordion{visibility:hidden}.js #side .accordion{display:none}#errorDivNor,a.important,a.trigger{display:block}.accordion li{list-style-type:none}#side ul.accordion ul{margin:0;padding:0 0 0 20px}.accordion .outer{border:1px solid #dadada;border-width:0 1px 1px;background:#fff}.accordion .inner{margin-bottom:0;padding:.5em 20px 1em;overflow:hidden}.accordion .inner .inner{padding-bottom:0}a.accordion-title{background-color:#f5f5f5;padding:12px 12px 12px 37px;border-bottom:1px solid #e8e8e8;color:#222;font-size:15px}.inbox-icon{background:url(../images/inbox-icon.png) 15px no-repeat}.admini-icon{background:url(../images/administrator-icon.png) 14px no-repeat}.auction-icon{background:url(../images/auction-icon.png) 9px no-repeat}.report-icon{background:url(../images/report-icon.png) 13px no-repeat}.submenu{background:#fafafa}.submenu li a{border-bottom:1px solid #eee;padding:10px 0 10px 35px;color:#5c5d67}.submenu li a.active,.submenu li a:hover{text-decoration:none;background:#FFF;color:#f59700;padding-left:31px;border-left:4px solid #f59700}.submenu-sub{background:#fdfdfd}.last-child a.trigger{background-image:none;font-weight:400}.submenu-sub li.last-child a{padding-left:41px}.submenu-sub li.last-child a:hover{padding-left:37px}#main a.trigger{background-color:#f0f0f0}#main a.trigger.open{border-color:#dadada;background-color:#e7e7e7}#main a:active.trigger.open,#main a:focus.trigger.open,#main a:hover.trigger.open{border-color:#bcd}#side a.active{font-weight:700;color:#f72}a.important{background:url(../images/star.png) no-repeat;text-indent:-99999px;height:16px;width:17px}a.important:hover{background:url(../images/star.png) center -16px no-repeat}.breadcrumb{background:#F6F6F6}.breadcrumb li a{color:#222;padding:0 10px 0 2px;background:url(../images/arrow.png) right no-repeat;line-height:25px}.breadcrumb li a.active,.breadcrumb li a:hover{color:#069;text-decoration:none}.breadcrumb li:last-child a{background:0 0!important}.page-title{line-height:40px;border-bottom:1px solid #e8e8e8;background:#FBFBFB}.inbox-searchbar{margin-top:3px}#errorDivNor{margin:-10px 0 0 5px;float:left}.inbox-searchbar input{padding:5px;margin-top:4px}.pagination div button,.pagination input{margin:3px 0 0 5px}.adv-srch{line-height:35px}.div-header-link div{padding:3px 2px 2px;float:left}.div-header-link div.creat-client{padding:12px 10px 10px 0}.div-header-link div.creat-client a{border:0;background:0 0;float:none;padding:0 2px 0 5px;display:inline}.div-header-link a{padding:14px 25px 13px;float:left;border-right:1px solid #d3d3d3;display:block}.div-header-link a.active,.div-header-link a:hover{background:#FFF;text-decoration:none;color:#222;border-bottom:2px solid #757575;padding:14px 15px 11px}.gradi{background:#FBFBFB}.pagination{padding:5px 10px!important;line-height:29px}.pagination div li a{padding:0 10px;line-height:28px;color:#222}.pagination input{padding:4px;width:30px!important}.content-div{padding:10px 13px 10px 10px}.listing-div{border:1px solid #ECECEC;padding:0 10px}.listing-tab{margin:10px 0 0;overflow:hidden;border:1px solid #ECECEC;border-bottom:0;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.listing-tab li a{padding:10px 20px;display:block;float:left;color:#7C7D89;font-size:18px;border-right:1px solid #ECECEC}.listing-tab li a.active,.listing-tab li a:hover{text-decoration:none;color:#ee9200;background:url(../images/orange-arrow.png) center 33px no-repeat;border-bottom:2px solid #ee9200}.bidding-row-highlight{background-color:#cae5ff}.bidDetailHighlight{background-color:#FAF2DC;color:#000;font:700}.view-event table tr td{border:0;width:25%;border-bottom:1px solid #ECECEC;padding:3px 5px 3px 15px}.view-info{margin-top:10px}.view-info table tr td{border:0;padding:5px 5px 5px 15px}.view-info label{display:block}.view-event table tr td label span{color:red}.view-event label{margin:2px 0;line-height:18px;display:block;color:#404040}.defcomp,.defcomptext{margin-top:10px!important;margin-bottom:10px!important;margin-right:10px!important}.view-event h2{padding:3px 0}.table-border table tr th{text-align:center}.mandatory1{padding:3px 0 0 20px}.cursor{cursor:pointer}.row-highlight{background-color:#d8f4d2}.view-event p{padding:0}.view-event li{list-style:inherit;display:list-item}.item-price-75{width:75%;display:block}.item-price-94{width:94%;display:block}.defcomp{width:50%!important}.defcomptext{width:46.5%!important}.mini-formfield{margin-top:20px;border-bottom:1px solid #E8E8E8;padding-bottom:15px}.mini-formfield li{line-height:18px}.mini-formfield table tr td{border:0;padding-top:5px;padding-bottom:5px}.mini-formfield table tr td label{margin-top:12px}.display-block table tr td label{display:block}.mini-formfield table tr td span{color:red}.mini-formfield input,.mini-formfield textarea{margin:0;width:90%}.mini-formfield select{margin:0;width:96%}.mini-formfield input[type=checkbox],.mini-formfield input[type=radio]{margin:5px;width:auto}.mini-formfield input.dateBox{width:79%!important}.table-border table tr td,.table-border table tr th{border-left:1px solid #E8E8E8}.table-border table tr td input[type=text],.table-border table tr td select{width:200px}.table-border table tr td textarea{width:92%;min-height:50px}.table-border p{padding-top:0;padding-bottom:10px;text-align:left}.label-span{color:#5D5E68!important}.white{background-color:#fff}.matrix-table button{margin:4px;padding:4px 5px}.matrix-table input[type=file]{margin:0 4px}.matrix-table input,.matrix-table textArea{width:150px}.matrix-table select{width:162px}.matrix-table .nmbr-select{width:60px}.row-table table tr td{border:0;padding:5px}.row-table table input{width:90%}.row-table table select{width:97%}.add-confi-icn,.approve-icn,.approve-rights-icn,.assign-rights-icn,.auction-icn,.deptree-icn,.dft-setting-icn,.disable-icn,.document-icn,.edit-icn,.enabel-icn,.industry-icn,.mail-icn,.plus-icn,.reject-icn,.rend-mail-icn,.reset-password-icn,.setting-icn,.terms-icn,.theme-icn,.unalock-icn,.unamap-icn,.user-remail-icn,.user-renew-icn{background:url(../images/sprite.png) -13px -90px no-repeat;display:block;float:left;height:20px;margin:0 1px;text-indent:-9999px;width:26px}.errorMsg,.successMsg{margin-bottom:5px;padding:10px 10px 10px 50px}.theme-icn{background-position:-40px -90px}.dft-setting-icn{background-position:-67px -90px}a.approve-icn{background-position:-95px -90px}.setting-icn{background-position:-120px -90px}.deptree-icn{background-position:-146px -90px}.mail-icn{background-position:-173px -90px}.plus-icn{background-position:-200px -90px}.reject-icn{background-position:-226px -90px}.auction-icn{background-position:-256px -90px}.enabel-icn{background-position:-284px -90px}.industry-icn{background-position:-310px -90px}.rend-mail-icn{background-position:-337px -90px}.unalock-icn{background-position:-363px -88px}.user-remail-icn{background-position:-392px -88px}.user-renew-icn{background-position:-423px -88px}.add-confi-icn{background-position:-454px -88px}.unamap-icn{background-position:-19px -120px}.document-icn{background-position:-50px -119px}.assign-rights-icn{background-position:-82px -120px}.disable-icn{background-position:-110px -120px}.reset-password-icn{background-position:-139px -122px}.approve-rights-icn{background-position:-165px -122px}.terms-icn{background-position:-192px -122px}.errorMsg,.noticeMsg,.successMsg,infoMsg{border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.successMsg{background:url(../images/successIcn.png) 10px center no-repeat #E9F9E5;border:1px solid #B4E8AA;color:#1C8400}.errorMsg{background:url(../images/errorIcn.png) 10px center no-repeat #F9E5E6;border:1px solid #E8AAAD;color:#B50007}.noticeMsg{background:url(../images/noticeIcn.png) 10px center no-repeat #F9F9E5;border:1px solid #E8E3AA;color:#828400;padding:10px 10px 10px 50px}.noticeMsg li{line-height:20px;list-style:decimal!important;margin-left:18px;display:list-item}.infoMsg{background:url(../images/infoIcn.png) 5px 3px no-repeat #fbf8e9;border:1px solid #fec600;color:#87836d;width:230px;padding:5px 5px 5px 28px}.infoMsg span{position:absolute;display:block;top:-11px;left:22px}.validationMsg{color:red;padding:5px 0 0 2px}.helpMsg{color:#03a200}.doc-table tr th .doc-table tr td{padding:7px;line-height:18px;text-align:left;width:auto!important}.doc-table tr th{text-align:center}span.arrow{border-left:5px solid transparent;border-right:5px solid transparent;border-top:7px solid #000;display:block;height:1px;left:40px;position:relative;top:3px;width:1px}.popupbox select{width:93.5%!important}.popup-title h3{font-size:20px;color:#222;background:#e3e3e3;padding:10px}.login-pop{width:400px}.user-pop{width:500px}/*! fancyBox v2.1.5 fancyapps.com | fancyapps.com/fancybox/#license */.fancybox-image,.fancybox-inner,.fancybox-nav,.fancybox-nav span,.fancybox-outer,.fancybox-skin,.fancybox-tmp,.fancybox-wrap,.fancybox-wrap iframe,.fancybox-wrap object{padding:0;margin:0;border:0;outline:0;vertical-align:top}.fancybox-wrap{position:absolute;top:0;left:0;z-index:8020;width:auto!important}.fancybox-inner,.fancybox-outer,.fancybox-skin{position:relative}.fancybox-skin{background:#f9f9f9;color:#444;text-shadow:none;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;border:5px solid #e3e3e3;padding:0!important;border-top:0}.fancybox-opened{z-index:8030}.fancybox-opened .fancybox-skin{-webkit-box-shadow:0 10px 25px rgba(0,0,0,.5);-moz-box-shadow:0 10px 25px rgba(0,0,0,.5);box-shadow:0 10px 25px rgba(0,0,0,.5)}.fancybox-inner{overflow:hidden;width:100%!important}.fancybox-type-iframe .fancybox-inner{-webkit-overflow-scrolling:touch}.fancybox-iframe,.fancybox-image{display:block;width:100%;height:100%}.fancybox-image{width:100%;height:100%;max-width:100%;max-height:100%}#fancybox-loading,.fancybox-close,.fancybox-next span,.fancybox-prev span{background-image:url(../images/fancybox_sprite.png)}#fancybox-loading{position:fixed;top:50%;left:50%;margin-top:-22px;margin-left:-22px;background-position:0 -108px;opacity:.8;cursor:pointer;z-index:8060}.fancybox-close,.fancybox-nav,.fancybox-nav span{cursor:pointer;z-index:8040;position:absolute}#fancybox-loading div{width:44px;height:44px;background:url(../images/fancybox_loading.gif) center center no-repeat}.fancybox-close{top:-20px;right:-22px;width:36px;height:36px}.fancybox-nav{top:0;width:40%;height:100%;text-decoration:none;background:url(../images/blank.gif);-webkit-tap-highlight-color:transparent}.fancybox-prev{left:0}.fancybox-next{right:0}.fancybox-nav span{top:50%;width:36px;height:34px;margin-top:-18px;visibility:hidden}.fancybox-prev span{left:10px;background-position:0 -36px}.fancybox-next span{right:10px;background-position:0 -72px}.fancybox-nav:hover span{visibility:visible}.fancybox-tmp{position:absolute;top:-99999px;left:-99999px;visibility:hidden;max-width:99999px;max-height:99999px;overflow:visible!important}.fancybox-lock,.fancybox-lock body{overflow:hidden!important}.fancybox-lock{width:auto}.fancybox-lock-test{overflow-y:hidden!important}.fancybox-overlay{position:absolute;top:0;left:0;overflow:hidden;display:none;z-index:8010;background:url(../images/fancybox_overlay.png)}.fancybox-overlay-fixed{position:fixed;bottom:0;right:0}.fancybox-lock .fancybox-overlay{overflow:auto;overflow-y:scroll}.fancybox-title{visibility:hidden;font:400 13px/20px \"Helvetica Neue\",Helvetica,Arial,sans-serif;position:relative;text-shadow:none;z-index:8050}.fancybox-opened .fancybox-title{visibility:visible}");
            	htmls.append("</style>");
	        }
	        htmls.append("<style type=\"text/css\">");
	        if(!multiLanguageSupportRequired)
	        {
	        	htmls.append("abbr,address,article,aside,audio,b,blockquote,body,canvas,caption,cite,code,dd,del,details,dfn,div,dl,dt,em,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,ins,kbd,label,legend,li,mark,menu,nav,object,ol,p,pre,q,samp,section,small,span,strong,sub,summary,sup,table,tbody,td,tfoot,th,thead,time,tr,ul,var,video{margin:0;padding:0;border:0;outline:0;font-size:100%;vertical-align:baseline;background:0 0}body{line-height:1;font-family:Calibri;font-size:13px;color:#5d5e68;}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}nav ul{list-style:none}blockquote,q{quotes:none}blockquote:after,blockquote:before,q:after,q:before{content:'';content:none}a{margin:0;padding:0;font-size:100%;vertical-align:baseline;background:0 0;color:#069;text-decoration:none}a:hover{text-decoration:underline}ins{background-color:#ff9;color:#000;text-decoration:none}mark{background-color:#ff9;color:#000;font-style:italic;font-weight:700}del{text-decoration:line-through}abbr[title],dfn[title]{border-bottom:1px dotted;cursor:help}table{border-collapse:collapse;border-spacing:0}table tr th{border-top:1px solid #e8e8e8;border-bottom:1px solid #e8e8e8;padding:9px 10px 7px;text-align:left;color:#222;font-weight:400;vertical-align:middle}table tr td{border-bottom:1px solid #e8e8e8;border-top:1px solid #e8e8e8;border-left:0;padding:10px}hr{display:block;height:1px;border:0;border-top:1px solid #ccc;margin:1em 0;padding:0}input,select{vertical-align:middle}input[type=checkbox],input[type=radio]{width:13px;height:13px;border:0\\9;padding:0\\9}input[type=checkbox]:focus,input[type=radio]:focus{border:0}.pull-left{float:left!important}.pull-right{float:right!important}li{display:inline;list-style:none}img{vertical-align:middle;max-width:100%}.display{display:block}.o-hidden{overflow:hidden}.o-auto{overflow:auto}.clearfix{clear:both}p{line-height:20px;padding-top:20px;}h1,h2,h3,h4,h5,h6{color:#222;font-family:Calibri;font-weight:400}h1{font-size:23px}h2{font-size:20px}label{margin:4px}.alpha{padding-left:0!important}.omega{padding-right:0!important}.alpha1{margin-left:0!important}.omega1{margin-right:0!important}button{background:url(/resources/template/template1/images/grad.jpg) repeat-x;background:#fafafa;color:#069;padding:4px 10px;*padding:5px 3px 3px;cursor:pointer;border:1px solid #E8E8E8;line-height:15px;*line-height:13px;margin:4px;*margin:3px;transition:.5s;box-shadow:none}button:hover{background:#f2f2f2;transition:.5s}button[type=submit]:disabled{background:#666;color:#BEBEBE;border:1px solid #606060}.blue-button-big{padding:3px 10px;*padding:3px 0;height:31px\\9;*height:33px;background:#279CE7;color:#FFF;font-family:Calibri;font-size:20px;cursor:pointer;text-align:center;line-height:21px;border:1px solid #2096e1;transition:.5s;box-shadow:none}.test section.inner-right-bar{width:100%!important}.blue-button-small{line-height:23px;*line-height:21px;padding:0 10px!important;*padding:0 5px;font-size:16px;background:#279CE7;color:#FFF;font-family:Calibri;cursor:pointer;text-align:center;border:1px solid #2096e1;transition:.5s;box-shadow:none}.blue-button-big:hover,.blue-button-small:hover{color:#FFF;border:1px solid #000;background:#000;transition:.5s}.dropdown-btn{border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;border:1px solid #e3e3e3;padding-right:20px;background:url("+imagePath+"grad.jpg) repeat-x}.active{color:#222}.black{color:#222!important}.no-padding{padding:0!important}.border-left-none,.border-left-none tr td,.border-left-none tr th,table.border-left-none tr td,table.border-left-none tr th{border-left:0!important}.border-right-none,.border-right-none tr td,.border-right-none tr th,table.border-right-none tr td,table.border-right-none tr th{border-right:0!important}.border-top-none td,.border-top-none th,table.border-top-none td,table.border-top-none th{border-top:0!important}.border-bottom-none,.border-bottom-none td,.border-bottom-none th,table.border-bottom-none td,table.border-bottom-none th{border-bottom:0!important}.border-right{border-right:1px solid #E8E8E8}.border-top{border-top:1px solid #E8E8E8}.border-bottom{border-bottom:1px solid #E8E8E8}table.no-border tr td{border-top:0!important;border-bottom:0!important}.border-top-none{border-top:0!important}.go-back{line-height:25px;margin-top:8px;margin-bottom:8px;background:url("+imagePath+"\\resources\\template\\template1\\images\\go-back-button.png) no-repeat left;padding-left:12px;margin-right:12px}.red{color:red;font-weight:400}.a-center{text-align:center!important}.a-left{text-align:left!important}.a-right{text-align:right!important}.v-a-top{vertical-align:top!important}.v-a-middle{vertical-align:middle!important}.v-a-bottom{vertical-align:bottom!important}.m-top0{margin-top:0!important}.m-top1{margin-top:5px!important}.m-top2{margin-top:10px!important}.m-top3{margin-top:15px!important}.m-top4{margin-top:20px!important}.m-bottom-none{margin-bottom:0!important}.p-top-none{padding-top:0!important}.display-inline{display:inline!important}.display-line-block label{display:inline-block!important}.input-width{width:115px!important}.m-left_14{margin-left:14px}.mini-formfield textarea.cont-texarea{width:79%}.container_25{max-width:"+(dynPageSize!=0?dynPageSize:1024)+"px;margin:0 auto;padding:0 0 0}.container_25 .grid_1{width:2%}.container_25 .grid_2{width:6%}.container_25 .grid_3{width:10%}.container_25 .grid_4{width:14%}.container_25 .grid_5{width:18%}.container_25 .grid_6{width:22%}.container_25 .grid_7{width:26%}.container_25 .grid_8{width:30%}.container_25 .grid_9{width:34%}.container_25 .grid_10{width:38%}.container_25 .grid_11{width:42%}.container_25 .grid_12{width:46%}.container_25 .grid_13{width:50%}.container_25 .grid_14{width:54%}.container_25 .grid_15{width:58%}.container_25 .grid_16{width:62%}.container_25 .grid_17{width:66%}.container_25 .grid_18{width:70%}.container_25 .grid_19{width:74%}.container_25 .grid_20{width:78%}.container_25 .grid_21{width:82%}.container_25 .grid_22{width:86%}.container_25 .grid_23{width:90%}.container_25 .grid_24{width:94%}.container_25 .grid_25{width:98%}.container_25 .grid_26{width:100%}.container_25 .prefix1_10{margin-right:5px}.container_25 .prefix1_20{margin-right:10px}.container_25 .prefix1_30{margin-right:15px}.container_25 .prefix1_1{margin-left:5px}.container_25 .prefix1_2{margin-left:10px}.container_25 .prefix_1{padding-left:1.6%}.container_25 .prefix_2{padding-left:4%}.container_25 .prefix_2-px{padding-left:20px}.container_25 .prefix_3{padding-left:6%}.container_25 .prefix_4{padding-left:8%}.container_25 .prefix_5{padding-left:10%}.container_25 .prefix_6{padding-left:12%}.container_25 .prefix_7{padding-left:14%}.container_25 .prefix_8{padding-left:16%}.container_25 .prefix_9{padding-left:36%}.container_25 .prefix_10{padding-left:40%}.container_25 .prefix_11{padding-left:44%}.container_25 .prefix_12{padding-left:48%}.container_25 .prefix_13{padding-left:52%}.container_25 .prefix_14{padding-left:56%}.container_25 .prefix_15{padding-left:60%}.container_25 .prefix_16{padding-left:64%}.container_25 .prefix_17{padding-left:68%}.container_25 .prefix_18{padding-left:72%}.container_25 .prefix_19{padding-left:76%}.container_25 .prefix_20{padding-left:80%}.container_25 .prefix_21{padding-left:84%}.container_25 .prefix_22{padding-left:88%}.container_25 .prefix_23{padding-left:92%}.container_25 .prefix_24{padding-left:96%}.container_25 .suffix_1{padding-right:1.6%}.container_25 .suffix_2{padding-right:8%}.container_25 .suffix_3{padding-right:12%}.container_25 .suffix_4{padding-right:16%}.container_25 .suffix_5{padding-right:20%}.container_25 .suffix_6{padding-right:24%}.container_25 .suffix_7{padding-right:28%}.container_25 .suffix_8{padding-right:32%}.container_25 .suffix_9{padding-right:36%}.container_25 .suffix_10{padding-right:40%}.container_25 .suffix_11{padding-right:44%}.container_25 .suffix_12{padding-right:48%}.container_25 .suffix_13{padding-right:52%}.container_25 .suffix_14{padding-right:56%}.container_25 .suffix_15{padding-right:60%}.container_25 .suffix_16{padding-right:64%}.container_25 .suffix_17{padding-right:68%}.container_25 .suffix_18{padding-right:72%}.container_25 .suffix_19{padding-right:76%}.container_25 .suffix_20{padding-right:80%}.container_25 .suffix_21{padding-right:84%}.container_25 .suffix_22{padding-right:88%}.container_25 .suffix_23{padding-right:92%}.container_25 .suffix_24{padding-right:96%}.main_container{border-left:1px solid #d6d6d6;border-right:1px solid #d6d6d6;background:#FFF;max-width:"+(dynPageSize!=0?dynPageSize:1060)+"px;margin:0 auto;-moz-box-sizing:border-box;-webkit-box-sizing:border-box}header{position:relative}a.logo{display:block;height:145px;text-indent:-99999px}nav{text-align:right}nav li{color:#333}.top-nav li a{padding:0 10px;border-right:1px solid #ffc362;color:#333}nav li a:hover{color:#FFF;text-decoration:none}nav ul.top-nav{margin-bottom:0;margin-top:61px;margin-right:15px}nav ul.top-nav li img{padding-left:8px;margin-top:-4px;position:relative;top:1px}nav ul.bottom-nav{margin-bottom:0;margin-top:12px}nav ul.bottom-nav li{font-family:arial;color:#333;padding-left:10px}nav ul.bottom-nav li a{border-left:1px solid #ffc362;padding:0 10px;color:#333}nav ul.bottom-nav li a.border,nav ul.top-nav li:last-child a,ul.tab li a.border{border-right:0}.navbar-fixed-bottom,.navbar-fixed-top{float:right;width:auto}.header-link{margin-top:10px}.header-link li{list-style:none}.header-link li a{border:0!important;font-size:15px!important;padding:0 5px!important}.header-link fieldset{background:#f2f2f2;border:1px solid #e7e7e7;position:absolute;padding:5px;width:22%;margin-top:5px}.header-link fieldset label{display:block}.header-link fieldset input{width:92%}.header-link fieldset a{font-size:13px!important;margin-top:12px}.carat-arrow{position:relative;top:-13px;left:10px}.help-setting,.login-setting,.settings_menu{position:absolute;right:156px;top:100px;text-align:left;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;border:1px solid #FFC362;background:#fba823;z-index:9}.help-setting li,.login-setting li,.settings_menu li{display:block;line-height:28px;padding-left:0!important}.help-setting li a,.login-setting li a,.settings_menu li a{border-right:0;border-bottom:1px solid #FFC362;display:block;border-left:0!important}.settings_menu li:last-child a{border:0}.help-setting{position:absolute;right:0;top:76px}.marquee{margin:15px 1% 0}.content_section{position:relative}.left-bar{border:1px solid #efefef}.collapse{background:url(../images/expand-colllapse.png) no-repeat 0 0;display:block;width:20px;height:22px;text-indent:-99999px;position:absolute;left:175px;top:30px}.expand{background:url("+imagePath+"\\resources\\template\\template1\\images\\expand-colllapse.png) no-repeat -23px 0;display:block;width:17px;height:22px;text-indent:-99999px;position:absolute;top:30px;z-index:999}.list{margin-top:10px}.list li{background:url("+imagePath+"\\resources\\template\\template1\\images\\arrow.png) no-repeat left 7px;margin:0 0 0 10px;padding-left:10px;line-height:23px;font-family:arial;display:block}span.title{font-size:19px;font-family:arial;color:#222;display:block;border-top:1px solid #e8e8e8;background-color:#f5f5f5;border-bottom:1px solid #e8e8e8;padding:10px 0 10px 40px;margin:10px 0 0}.cat-icon{background:url("+imagePath+"\\resources\\template\\template1\\images\\category_icon.png) no-repeat 10px 9px}.category li a{color:#7c7d89;line-height:30px;display:block;padding-left:10px}.category li a:hover{background:#f2f2f2;color:#222;padding-left:6px;border-left:4px solid #ee9200;text-decoration:none}.ad-icon{background:url(../images/advertise-icon.png) no-repeat 10px 9px}.ad-banner_div{padding:10px}.ad-banner_div img{margin-bottom:5px}.middle-bar{margin-left:8px}.search-bar{border:3px solid #279ce7;height:39px;position:relative}.search-bar input[type=text]{width:64%}.advance-bar{background:#fcfcfc;border:1px solid #f1f1f1;font-size:11px;color:#222;padding:8px}.details-box{background:url(../images/divider.png) no-repeat bottom;padding-bottom:20px}.details-box span{display:block;color:#222}.details-box b{color:#222;font-weight:400}.bottom-btn{border:1px solid #EFEFEF;margin-top:10px;overflow:hidden;padding:2px}.bottom-btn button{margin-top:7px;*margin-top:4px}.bottom-btn span{margin:2px 0 0 10px;*margin:4px 0 0 10px;color:#222}.bottom-btn select{border:1px solid #EFEFEF;padding:5px\\9;box-shadow:none}button.show-btn{font-size:12px;font-family:arial;padding:0 10px;line-height:29px}.right-bar{border:1px solid #efefef}.ex-icon{background:url(../images/exhibitions-icon.png) no-repeat 10px 8px}.tender-icon{background:url(../images/tender-icon.png) no-repeat 10px 9px}footer{background:#fbfbfb;border-top:1px solid #e7e7e7;max-width:1058px;max-width:"+(dynPageSize!=0?dynPageSize:1060)+"px\\9;margin-left:auto;margin-right:auto;margin-top:25px}.footer-links span{font-size:20px;color:#222;padding-bottom:15px;display:block;font-family:arial}.footer-links li,.footer-links li a{line-height:25px;color:#6c6d79;font-family:arial;font-size:12px;display:block}.footer-links li a:hover{text-decoration:underline}.footer-links li b{color:#222;font-weight:400}.social-icons{line-height:60px;display:block;padding-left:56px;font-size:22px;font-family:arial}.social-icons:hover{opacity:.8}.fb{background:url(../images/f-icon.png) no-repeat left;color:#3a589b}.tw{background:url(../images/t-icon.png) no-repeat left;color:#3a589b}.l-in{background:url(../images/in-icon.png) no-repeat left;color:#3a589b}.copy{border-top:1px solid #e7e7e7;margin-top:10px;font-size:11px;padding:0 0 30px}.inner-right-bar{border-left:5px solid #ececec;width:81.21%;border-top:1px solid #E8E8E8;border-right:1px solid #E8E8E8;border-bottom:1px solid #E8E8E8}.border-left{border-left:1px solid #E8E8E8!important}.js #main .accordion{visibility:hidden}.js #side .accordion{display:none}.accordion li{list-style-type:none}#side ul.accordion ul{margin:0;padding:0 0 0 20px}.accordion .outer{border:1px solid #dadada;border-width:0 1px 1px;background:#fff}.accordion .inner{margin-bottom:0;padding:.5em 20px 1em;position:relative;overflow:hidden}.accordion .inner .inner{padding-bottom:0}a.accordion-title{background-color:#f5f5f5;padding:12px 12px 12px 37px;border-bottom:1px solid #e8e8e8;color:#222;font-size:15px}.submenu li a:hover,a.accordion-title:hover{text-decoration:none}.inbox-icon{background:url(../images/inbox-icon.png) no-repeat 15px}.admini-icon{background:url(../images/administrator-icon.png) no-repeat 14px}.auction-icon{background:url(../images/auction-icon.png) no-repeat 9px}.report-icon{background:url(../images/report-icon.png) no-repeat 13px}a.trigger{display:block}.submenu{background:#fafafa}.submenu li a{border-bottom:1px solid #eee;padding:10px 0 10px 35px;color:#5c5d67}.submenu li a.active,.submenu li a:hover{text-decoration:none;background:#FFF;color:#f59700;padding-left:31px;border-left:4px solid #f59700}.submenu-sub{background:#fdfdfd}.last-child a.trigger{background-image:none;font-weight:400}.submenu-sub li.last-child a{padding-left:41px}.submenu-sub li.last-child a:hover{padding-left:37px}#main a.trigger{background-color:#f0f0f0}#main a.trigger.open{border-color:#dadada;background-color:#e7e7e7}#main a:active.trigger.open,#main a:focus.trigger.open,#main a:hover.trigger.open{border-color:#bcd}#side a.active{font-weight:700;color:#f72;text-decoration:none}a.important{background:url(../images/star.png) no-repeat;text-indent:-99999px;display:block;height:16px;width:17px}a.important:hover{background:url(../images/star.png) no-repeat center -16px}.breadcrumb{background:#F6F6F6}.breadcrumb li a{color:#222;padding:0 10px 0 2px;background:url(../images/arrow.png) right no-repeat;line-height:25px}.breadcrumb li a:hover{text-decoration:none;color:#069}.breadcrumb li:last-child a{background:none!important}.breadcrumb li a.active{color:#069;text-decoration:none}.page-title{position:relative;line-height:40px;border-bottom:1px solid #e8e8e8;background:#FBFBFB}.inbox-searchbar{margin-top:3px}#errorDivNor{display:block;margin:-10px 0 0 5px;float:left}.inbox-searchbar input{padding:5px;margin-top:4px\\9;*margin-top:4px}.adv-srch{line-height:35px}.div-header-link div{padding:3px 2px 2px;float:left}.div-header-link div.creat-client{padding:12px 10px 10px 0}.div-header-link div.creat-client a{border:0;background:0 0;float:none;padding:0 2px 0 5px;display:inline}.div-header-link a{background:url("+imagePath+"grad.jpg) repeat-x!important;padding:14px 25px 13px;float:left;border-right:1px solid #d3d3d3;display:block}.div-header-link a.active,.div-header-link a:hover{background:#FFF;text-decoration:none;color:#222;border-bottom:2px solid #757575;padding:14px 15px 11px}.gradi{background:none repeat scroll 0 0 #FBFBFB}.pagination{padding:5px 10px!important;line-height:29px}.pagination div button{margin:2px 0 0 5px;margin:3px 0 0 5px}.pagination div li a{padding:0 10px;line-height:28px;color:#222}.pagination input{margin:3px 0 0 5px;padding:4px;width:30px!important}.content-div{padding:10px 13px 10px 10px}.listing-div{border:1px solid #ECECEC;padding:0 10px}.listing-tab{margin:10px 0 0;overflow:hidden;border:1px solid #ECECEC;border-bottom:0;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.listing-tab li a{padding:10px 20px;display:block;float:left;color:#7C7D89;font-size:18px;border-right:1px solid #ECECEC;font-family:arial}.listing-tab li a.active,.listing-tab li a:hover{text-decoration:none;color:#ee9200;background:url(../images/orange-arrow.png) no-repeat center 33px;border-bottom:2px solid #ee9200}.bidding-row-highlight{background-color:#cae5ff}.bidDetailHighlight{background-color:#FAF2DC;color:#000;font:700}.view-event table tr td{border:0;width:25%;border-bottom:1px solid #ECECEC;padding:3px 5px 3px 15px}.view-info{margin-top:10px}.view-info table tr td{border:0;padding:5px 5px 5px 15px}.view-info label{display:block}.view-event table tr td label span{color:red}.view-event label{margin:2px 0;line-height:18px;display:block;color:#404040}.view-event h2{padding:3px 0}.table-border table tr th{text-align:center}.mandatory1{padding:3px 0 0 20px}.cursor{cursor:pointer}.row-highlight{background-color:#d8f4d2}.view-event p{padding:0}.view-event li{list-style:inherit;display:list-item}.item-price-75{width:75%;display:block}.item-price-94{width:94%;display:block}.defcomp{width:50%!important;margin-top:10px!important;margin-bottom:10px!important;margin-right:10px!important}.defcomptext{width:46.5%!important;margin-top:10px!important;margin-bottom:10px!important;margin-right:10px!important}.mini-formfield{margin-top:20px;border-bottom:1px solid #E8E8E8;padding-bottom:15px}.mini-formfield li{line-height:18px}.mini-formfield table tr td{border:0;padding-top:5px;padding-bottom:5px}.mini-formfield table tr td label{margin-top:12px}.display-block table tr td label{display:block}.mini-formfield table tr td span{color:red}.mini-formfield input,.mini-formfield textarea{margin:0;width:90%}.mini-formfield select{margin:0;width:96%}.mini-formfield input[type=checkbox],.mini-formfield input[type=radio]{margin:5px;width:auto}.mini-formfield input.dateBox{width:79%!important}.table-border table tr td,.table-border table tr th{border-left:1px solid #E8E8E8}.table-border table tr td input[type=text],.table-border table tr td select{width:200px}.table-border table tr td textarea{width:92%;min-height:50px}.table-border p{padding-top:0;padding-bottom:10px;text-align:left}.label-span{color:#5D5E68!important}.white{background-color:#fff}.matrix-table button{margin:4px;padding:4px 5px}.matrix-table input[type=file]{margin:0 4px}.matrix-table input,.matrix-table textArea{width:150px}.matrix-table select{width:162px}.matrix-table .nmbr-select{width:60px}.row-table table tr td{border:0;padding:5px}.row-table table input{width:90%}.row-table table select{width:97%}.add-confi-icn,.approve-icn,.approve-rights-icn,.assign-rights-icn,.auction-icn,.deptree-icn,.dft-setting-icn,.disable-icn,.document-icn,.edit-icn,.enabel-icn,.industry-icn,.mail-icn,.plus-icn,.reject-icn,.rend-mail-icn,.reset-password-icn,.setting-icn,.terms-icn,.theme-icn,.unalock-icn,.unamap-icn,.user-remail-icn,.user-renew-icn{background:url(../images/sprite.png) no-repeat -13px -90px;display:block;float:left;height:20px;margin:0 1px;text-indent:-9999px;width:26px}.theme-icn{background-position:-40px -90px}.dft-setting-icn{background-position:-67px -90px}a.approve-icn{background-position:-95px -90px}.setting-icn{background-position:-120px -90px}.deptree-icn{background-position:-146px -90px}.mail-icn{background-position:-173px -90px}.plus-icn{background-position:-200px -90px}.reject-icn{background-position:-226px -90px}.auction-icn{background-position:-256px -90px}.enabel-icn{background-position:-284px -90px}.industry-icn{background-position:-310px -90px}.rend-mail-icn{background-position:-337px -90px}.unalock-icn{background-position:-363px -88px}.user-remail-icn{background-position:-392px -88px}.user-renew-icn{background-position:-423px -88px}.add-confi-icn{background-position:-454px -88px}.unamap-icn{background-position:-19px -120px}.document-icn{background-position:-50px -119px}.assign-rights-icn{background-position:-82px -120px}.disable-icn{background-position:-110px -120px}.reset-password-icn{background-position:-139px -122px}.approve-rights-icn{background-position:-165px -122px}.terms-icn{background-position:-192px -122px}.errorMsg,.noticeMsg,.successMsg,infoMsg{border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.successMsg{background:url(../images/successIcn.png) no-repeat scroll 10px center #E9F9E5;border:1px solid #B4E8AA;color:#1C8400;margin-bottom:5px;padding:10px 10px 10px 50px}.errorMsg{background:url(../images/errorIcn.png) no-repeat scroll 10px center #F9E5E6;border:1px solid #E8AAAD;color:#B50007;margin-bottom:5px;padding:10px 10px 10px 50px}.noticeMsg{background:url(../images/noticeIcn.png) no-repeat scroll 10px center #F9F9E5;border:1px solid #E8E3AA;color:#828400;padding:10px 10px 10px 50px}.noticeMsg li{line-height:20px;list-style:decimal outside none!important;margin-left:18px;display:list-item}.infoMsg{background:url(../images/infoIcn.png) no-repeat scroll 5px 3px #fbf8e9;border:1px solid #fec600;color:#87836d;width:230px;position:relative;padding:5px 5px 5px 28px}.infoMsg span{position:absolute;display:block;top:-11px;left:22px}.validationMsg{color:red;padding:5px 0 0 2px}.helpMsg{color:#03a200}.doc-table tr th .doc-table tr td{padding:7px;line-height:18px;text-align:left;width:auto!important}.doc-table tr th{text-align:center}span.arrow{border-left:5px solid transparent;border-right:5px solid transparent;border-top:7px solid #000;display:block;height:1px;left:40px;position:relative;top:3px;width:1px}.popupbox select{width:93.5%!important}.popup-title h3{font-size:20px;color:#222;background:#e3e3e3;padding:10px}.login-pop{width:400px}.user-pop{width:500px}/*! fancyBox v2.1.5 fancyapps.com | fancyapps.com/fancybox/#license */.fancybox-image,.fancybox-inner,.fancybox-nav,.fancybox-nav span,.fancybox-outer,.fancybox-skin,.fancybox-tmp,.fancybox-wrap,.fancybox-wrap iframe,.fancybox-wrap object{padding:0;margin:0;border:0;outline:0;vertical-align:top}.fancybox-wrap{position:absolute;top:0;left:0;z-index:8020;width:auto!important}.fancybox-skin{position:relative;background:#f9f9f9;color:#444;text-shadow:none;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;border:5px solid #e3e3e3;padding:0!important;border-top:0}.fancybox-opened{z-index:8030}.fancybox-opened .fancybox-skin{-webkit-box-shadow:0 10px 25px rgba(0,0,0,.5);-moz-box-shadow:0 10px 25px rgba(0,0,0,.5);box-shadow:0 10px 25px rgba(0,0,0,.5)}.fancybox-inner,.fancybox-outer{position:relative}.fancybox-inner{overflow:hidden;width:100%!important}.fancybox-type-iframe .fancybox-inner{-webkit-overflow-scrolling:touch}.fancybox-iframe,.fancybox-image{display:block;width:100%;height:100%}.fancybox-image{width:100%;height:100%;max-width:100%;max-height:100%}#fancybox-loading,.fancybox-close,.fancybox-next span,.fancybox-prev span{background-image:url(../images/fancybox_sprite.png)}#fancybox-loading{position:fixed;top:50%;left:50%;margin-top:-22px;margin-left:-22px;background-position:0 -108px;opacity:.8;cursor:pointer;z-index:8060}#fancybox-loading div{width:44px;height:44px;background:url(../images/fancybox_loading.gif) center center no-repeat}.fancybox-close{position:absolute;top:-20px;right:-22px;width:36px;height:36px;cursor:pointer;z-index:8040}.fancybox-nav{position:absolute;top:0;width:40%;height:100%;cursor:pointer;text-decoration:none;background:transparent url(../images/blank.gif);-webkit-tap-highlight-color:rgba(0,0,0,0);z-index:8040}.fancybox-prev{left:0}.fancybox-next{right:0}.fancybox-nav span{position:absolute;top:50%;width:36px;height:34px;margin-top:-18px;cursor:pointer;z-index:8040;visibility:hidden}.fancybox-prev span{left:10px;background-position:0 -36px}.fancybox-next span{right:10px;background-position:0 -72px}.fancybox-nav:hover span{visibility:visible}.fancybox-tmp{position:absolute;top:-99999px;left:-99999px;visibility:hidden;max-width:99999px;max-height:99999px;overflow:visible!important}.fancybox-lock{overflow:hidden!important;width:auto}.fancybox-lock body{overflow:hidden!important}.fancybox-lock-test{overflow-y:hidden!important}.fancybox-overlay{position:absolute;top:0;left:0;overflow:hidden;display:none;z-index:8010;background:url(../images/fancybox_overlay.png)}.fancybox-overlay-fixed{position:fixed;bottom:0;right:0}.fancybox-lock .fancybox-overlay{overflow:auto;overflow-y:scroll}.fancybox-title{visibility:hidden;font:400 13px/20px \"Helvetica Neue\",Helvetica,Arial,sans-serif;position:relative;text-shadow:none;z-index:8050}.fancybox-opened .fancybox-title{visibility:visible}.fancybox-title-float-wrap{position:absolute;bottom:0;right:50%;margin-bottom:-35px;z-index:8050;text-align:center}.fancybox-title-float-wrap .child{display:inline-block;margin-right:-100%;padding:2px 20px;background:0 0;background:rgba(0,0,0,.8);-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px;text-shadow:0 1px 2px #222;color:#FFF;font-weight:700;line-height:24px;white-space:nowrap}.fancybox-title-outside-wrap{position:relative;margin-top:10px;color:#fff}.fancybox-title-inside-wrap{padding-top:10px}.fancybox-title-over-wrap{position:absolute;bottom:0;left:0;color:#fff;padding:10px;background:#000;background:rgba(0,0,0,.8)}.fancybox-custom .fancybox-skin{box-shadow:0 0 50px #222}element.style{display:block}@media only screen and (-webkit-min-device-pixel-ratio:1.5),only screen and (min--moz-device-pixel-ratio:1.5),only screen and (min-device-pixel-ratio:1.5){#fancybox-loading,.fancybox-close,.fancybox-next span,.fancybox-prev span{background-image:url(../images/fancybox_sprite@2x.png);background-size:44px 152px}#fancybox-loading div{background-image:url(../images/fancybox_loading@2x.gif);background-size:24px 24px}}.timer{border-top:1px solid #dbedff;border-bottom:1px solid #dbedff;border-radius:2px;background:#eef8ff}.rmn-time{margin:10px 20px 10px 10px}.rmn-time img{margin-right:10px}.se-time{margin-top:10px;margin-left:10px}.timer p{margin:0;padding:0}.points{margin-top:15px}.points li{display:block;line-height:24px;background:url(../images/li-arrow.png) no-repeat left;padding-left:20px}.faq-div h3{padding:10px;color:#069;border:1px solid #E8E8E8;background:url("+imagePath+"\\resources\\template\\template1\\images\\grad.jpg) repeat-x;font-family:arial;cursor:pointer;margin-bottom:2px;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.faq-div div{border:1px solid #E8E8E8;border-top:0;display:none;padding:10px;padding-bottom:0;margin-bottom:5px;margin-top:-5px;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.faq-div div p{margin-bottom:20px;padding-top:0}.multy-section section.inner-right-bar{width:100%!important}@media screen and (-webkit-min-device-pixel-ratio:0){.div-header-link div{padding:4px 0 2px 2px}.search-bar{height:37px}.bottom-btn span{margin:1px 0 0 10px}.search-input{padding:10px}.assign-checkbox label input{height:16px;width:16px}}@media screen and (max-width:1023px){.container_25{max-width:768px}.rel-width-left{width:22.7%!important}.rel-width-mid{width:76%!important}.container_25 .grid_7{width:100%}nav{display:none}}.print-pdf.main_container, .print-pdf .container_25{max-width:100%;} .green{color:green!important;font-weight:normal;}");	
	        }
			htmls.append(".client-logo img {height:50px;}.client-logo{height:50px;width:100%;text-align:right;}header{background-size:150% !important;}");
			htmls.append(".question-box{ border-bottom: 1px solid #E8E8E8; padding:10px;}.question-div span{font-size:14px;color:#222222;float: left;}.question-div p{ font-size:14px; color:#222222; position:relative; top:-3px; left: 5px; padding-bottom: 5px;}.rephrase-div p { color: #222222; font-size: 13px; left: 5px; position: relative; top: -3px;}.rephrase-div span{color: #222222; font-size: 13px; float:left;}.asked-ansed-div{ overflow: hidden;}.rephrase-div,.ans-div,.asked-ansed-div{padding-left:15px;}");
			htmls.append(".noprint{ display: none; } .kpi-datatable-caption {font-size: 24px; padding-bottom: 5px; padding-left: 5px; padding-top: 10px; text-align: left;}");
			htmls.append(".table-row-highlightedColor {background-color: #FFFF99;}");
			htmls.append(".table-column-highlightedColor{color: red;}");
			htmls.append(".chat-faq{padding:10px;clear:both}.chat-faq .cd-faq-trigger{padding:0}.chat-faq > ul > li{padding:7px 10px 12px}.chat-faq .cd-faq-content{padding:0}.chat-main{display:table;width:100%}.chat-main li{display:table-cell;vertical-align:middle;padding:10px}.chat-main li:first-child{padding-right:0}.faq-chat-box{border-radius:4px;padding:15px;box-shadow:0 0 5px 0 rgba(0,0,0,0.1);border:1px solid #ededed}.chat-block{border-radius:100%;text-align:center;text-transform:uppercase;padding:10px;font-size:20px;width:25px;height:25px;display:table;color:#222;border:1px solid transparent}.chat-block span{display:table-cell;vertical-align:middle}.chat-o{border-color:#6ecacc;color:#6ecacc}.chat-b{border-color:#f29c89;color:#f29c89}.chat-info-qus{font-size:10px;color:#adadad;font-family:'lucida_granderegular';padding-top:10px}.chat-info-qus span{border:1px solid transparent;padding:3px 5px 2px;border-radius:10px}.chat-info-qus span.officer{border-color:#68c6c8;color:#68c6c8}.chat-info-qus span.bidder{border-color:#f29c89;color:#f29c89}.chat-info{font-size:12px;color:#adadad}.chat-info .small-clock-icon{opacity:0.6}.module-nm{border:1px solid #edeef3;background:#f2f4f8;color:#adadad;font-size:12px;border-radius:10px;padding:2px 5px;margin-left:5px}.post-div{background:#f8f8f8;border-top:1px solid #ededed;margin:10px 0 -12px -10px;padding:5px 10px;width:100%;display:table;width:100%}.post-div li{display:table-cell;vertical-align:middle}.post-div li:first-child{width:95%;padding-right:10px}.post-div textarea{box-shadow:none;width:100%;box-sizing:border-box;margin:0;height:50px;max-height:50px;padding-right:50px}.post-div button{margin:8px 0}.view-doc{position:relative}.view-doc div{padding-top:20px;position:absolute;right:0;top:8px}.view-doc a:hover{text-decoration:none}.doc-dropdown{display:none;border-radius:3px;background:#fff;box-shadow:0 0 5px 0 rgba(0, 0, 0, 0.2);border:1px solid #dbdbdb;padding:7px 13px 7px 30px;width:200px}.doc-dropdown li{display:list-item;text-align:left;padding:5px 0;line-height:16px;list-style-type:decimal}.doc-dropdown li a{padding:5px 0;font-size:11px}.doc-dropdown li a:hover{color:#222}.view-doc:hover .doc-dropdown{display:block}");
	        if(generateType == 4) {
	            htmls.append("body{color: #5D5E68;font-family: Calibri;font-size: 13px;line-height: 1;} table{border:1px solid #A8A8A8;} tr th{background:#FBFBFB;}tr th,tr td {border:1px solid #e8e8e8;padding:5px;}tr td.black {	color:black;} table tr td table{border:0;} .green{color:green}");
	        } else {
	        	if(!multiLanguageSupportRequired)
	        	{
	        		htmls.append("abbr,address,article,aside,audio,b,blockquote,body,canvas,caption,cite,code,dd,del,details,dfn,div,dl,dt,em,fieldset,figcaption,figure,footer,form,h1,h2,h3,h4,h5,h6,header,hgroup,html,i,iframe,img,ins,kbd,label,legend,li,mark,menu,nav,object,ol,p,pre,q,samp,section,small,span,strong,sub,summary,sup,table,tbody,td,tfoot,th,thead,time,tr,ul,var,video{margin:0;padding:0;border:0;outline:0;font-size:100%;vertical-align:baseline;background:0 0}body{line-height:1;font-family:Calibri;font-size:13px;color:#5d5e68;}article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block}nav ul{list-style:none}blockquote,q{quotes:none}blockquote:after,blockquote:before,q:after,q:before{content:'';content:none}a{margin:0;padding:0;font-size:100%;vertical-align:baseline;background:0 0;color:#069;text-decoration:none}a:hover{text-decoration:underline}ins{background-color:#ff9;color:#000;text-decoration:none}mark{background-color:#ff9;color:#000;font-style:italic;font-weight:700}del{text-decoration:line-through}abbr[title],dfn[title]{border-bottom:1px dotted;cursor:help}table{border-collapse:collapse;border-spacing:0}table tr th{border-top:1px solid #e8e8e8;border-bottom:1px solid #e8e8e8;padding:9px 10px 7px;text-align:left;color:#222;font-weight:400;vertical-align:middle}table tr td{border-bottom:1px solid #e8e8e8;border-top:1px solid #e8e8e8;border-left:0;padding:10px}hr{display:block;height:1px;border:0;border-top:1px solid #ccc;margin:1em 0;padding:0}input,select{vertical-align:middle}input[type=checkbox],input[type=radio]{width:13px;height:13px;border:0\\9;padding:0\\9}input[type=checkbox]:focus,input[type=radio]:focus{border:0}.pull-left{float:left!important}.pull-right{float:right!important}li{display:inline;list-style:none}img{vertical-align:middle;max-width:100%}.display{display:block}.o-hidden{overflow:hidden}.o-auto{overflow:auto}.clearfix{clear:both}p{line-height:20px;padding-top:20px;text-align:justify}h1,h2,h3,h4,h5,h6{color:#222;font-family:Calibri;font-weight:400}h1{font-size:23px}h2{font-size:20px}label{margin:4px}.alpha{padding-left:0!important}.omega{padding-right:0!important}.alpha1{margin-left:0!important}.omega1{margin-right:0!important}button{background:url(/resources/template/template1/images/grad.jpg) repeat-x;background:#fafafa;color:#069;padding:4px 10px;*padding:5px 3px 3px;cursor:pointer;border:1px solid #E8E8E8;line-height:15px;*line-height:13px;margin:4px;*margin:3px;transition:.5s;box-shadow:none}button:hover{background:#f2f2f2;transition:.5s}button[type=submit]:disabled{background:#666;color:#BEBEBE;border:1px solid #606060}.blue-button-big{padding:3px 10px;*padding:3px 0;height:31px\\9;*height:33px;background:#279CE7;color:#FFF;font-family:Calibri;font-size:20px;cursor:pointer;text-align:center;line-height:21px;border:1px solid #2096e1;transition:.5s;box-shadow:none}.test section.inner-right-bar{width:100%!important}.blue-button-small{line-height:23px;*line-height:21px;padding:0 10px!important;*padding:0 5px;font-size:16px;background:#279CE7;color:#FFF;font-family:Calibri;cursor:pointer;text-align:center;border:1px solid #2096e1;transition:.5s;box-shadow:none}.blue-button-big:hover,.blue-button-small:hover{color:#FFF;border:1px solid #000;background:#000;transition:.5s}.dropdown-btn{border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;border:1px solid #e3e3e3;padding-right:20px;background:url("+imagePath+"grad.jpg) repeat-x}.active{color:#222}.black{color:#222!important}.no-padding{padding:0!important}.border-left-none,.border-left-none tr td,.border-left-none tr th,table.border-left-none tr td,table.border-left-none tr th{border-left:0!important}.border-right-none,.border-right-none tr td,.border-right-none tr th,table.border-right-none tr td,table.border-right-none tr th{border-right:0!important}.border-top-none td,.border-top-none th,table.border-top-none td,table.border-top-none th{border-top:0!important}.border-bottom-none,.border-bottom-none td,.border-bottom-none th,table.border-bottom-none td,table.border-bottom-none th{border-bottom:0!important}.border-right{border-right:1px solid #E8E8E8}.border-top{border-top:1px solid #E8E8E8}.border-bottom{border-bottom:1px solid #E8E8E8}table.no-border tr td{border-top:0!important;border-bottom:0!important}.border-top-none{border-top:0!important}.go-back{line-height:25px;margin-top:8px;margin-bottom:8px;background:url("+imagePath+"\\resources\\template\\template1\\images\\go-back-button.png) no-repeat left;padding-left:12px;margin-right:12px}.red{color:red;font-weight:400}.a-center{text-align:center!important}.a-left{text-align:left!important}.a-right{text-align:right!important}.v-a-top{vertical-align:top!important}.v-a-middle{vertical-align:middle!important}.v-a-bottom{vertical-align:bottom!important}.m-top0{margin-top:0!important}.m-top1{margin-top:5px!important}.m-top2{margin-top:10px!important}.m-top3{margin-top:15px!important}.m-top4{margin-top:20px!important}.m-bottom-none{margin-bottom:0!important}.p-top-none{padding-top:0!important}.display-inline{display:inline!important}.display-line-block label{display:inline-block!important}.input-width{width:115px!important}.m-left_14{margin-left:14px}.mini-formfield textarea.cont-texarea{width:79%}.container_25{max-width:"+(dynPageSize!=0?dynPageSize:1024)+"px;margin:0 auto;padding:0 0 0}.container_25 .grid_1{width:2%}.container_25 .grid_2{width:6%}.container_25 .grid_3{width:10%}.container_25 .grid_4{width:14%}.container_25 .grid_5{width:18%}.container_25 .grid_6{width:22%}.container_25 .grid_7{width:26%}.container_25 .grid_8{width:30%}.container_25 .grid_9{width:34%}.container_25 .grid_10{width:38%}.container_25 .grid_11{width:42%}.container_25 .grid_12{width:46%}.container_25 .grid_13{width:50%}.container_25 .grid_14{width:54%}.container_25 .grid_15{width:58%}.container_25 .grid_16{width:62%}.container_25 .grid_17{width:66%}.container_25 .grid_18{width:70%}.container_25 .grid_19{width:74%}.container_25 .grid_20{width:78%}.container_25 .grid_21{width:82%}.container_25 .grid_22{width:86%}.container_25 .grid_23{width:90%}.container_25 .grid_24{width:94%}.container_25 .grid_25{width:98%}.container_25 .grid_26{width:100%}.container_25 .prefix1_10{margin-right:5px}.container_25 .prefix1_20{margin-right:10px}.container_25 .prefix1_30{margin-right:15px}.container_25 .prefix1_1{margin-left:5px}.container_25 .prefix1_2{margin-left:10px}.container_25 .prefix_1{padding-left:1.6%}.container_25 .prefix_2{padding-left:4%}.container_25 .prefix_2-px{padding-left:20px}.container_25 .prefix_3{padding-left:6%}.container_25 .prefix_4{padding-left:8%}.container_25 .prefix_5{padding-left:10%}.container_25 .prefix_6{padding-left:12%}.container_25 .prefix_7{padding-left:14%}.container_25 .prefix_8{padding-left:16%}.container_25 .prefix_9{padding-left:36%}.container_25 .prefix_10{padding-left:40%}.container_25 .prefix_11{padding-left:44%}.container_25 .prefix_12{padding-left:48%}.container_25 .prefix_13{padding-left:52%}.container_25 .prefix_14{padding-left:56%}.container_25 .prefix_15{padding-left:60%}.container_25 .prefix_16{padding-left:64%}.container_25 .prefix_17{padding-left:68%}.container_25 .prefix_18{padding-left:72%}.container_25 .prefix_19{padding-left:76%}.container_25 .prefix_20{padding-left:80%}.container_25 .prefix_21{padding-left:84%}.container_25 .prefix_22{padding-left:88%}.container_25 .prefix_23{padding-left:92%}.container_25 .prefix_24{padding-left:96%}.container_25 .suffix_1{padding-right:1.6%}.container_25 .suffix_2{padding-right:8%}.container_25 .suffix_3{padding-right:12%}.container_25 .suffix_4{padding-right:16%}.container_25 .suffix_5{padding-right:20%}.container_25 .suffix_6{padding-right:24%}.container_25 .suffix_7{padding-right:28%}.container_25 .suffix_8{padding-right:32%}.container_25 .suffix_9{padding-right:36%}.container_25 .suffix_10{padding-right:40%}.container_25 .suffix_11{padding-right:44%}.container_25 .suffix_12{padding-right:48%}.container_25 .suffix_13{padding-right:52%}.container_25 .suffix_14{padding-right:56%}.container_25 .suffix_15{padding-right:60%}.container_25 .suffix_16{padding-right:64%}.container_25 .suffix_17{padding-right:68%}.container_25 .suffix_18{padding-right:72%}.container_25 .suffix_19{padding-right:76%}.container_25 .suffix_20{padding-right:80%}.container_25 .suffix_21{padding-right:84%}.container_25 .suffix_22{padding-right:88%}.container_25 .suffix_23{padding-right:92%}.container_25 .suffix_24{padding-right:96%}.main_container{border-left:1px solid #d6d6d6;border-right:1px solid #d6d6d6;background:#FFF;max-width:"+(dynPageSize!=0?dynPageSize:1060)+"px;margin:0 auto;-moz-box-sizing:border-box;-webkit-box-sizing:border-box}header{background:url("+imagePath+"\\resources\\template\\template1\\images\\grad.jpg\\logo.png) no-repeat;position:relative}a.logo{display:block;height:145px;text-indent:-99999px}nav{text-align:right}nav li{color:#333}.top-nav li a{padding:0 10px;border-right:1px solid #ffc362;color:#333}nav li a:hover{color:#FFF;text-decoration:none}nav ul.top-nav{margin-bottom:0;margin-top:61px;margin-right:15px}nav ul.top-nav li img{padding-left:8px;margin-top:-4px;position:relative;top:1px}nav ul.bottom-nav{margin-bottom:0;margin-top:12px}nav ul.bottom-nav li{font-family:arial;color:#333;padding-left:10px}nav ul.bottom-nav li a{border-left:1px solid #ffc362;padding:0 10px;color:#333}nav ul.bottom-nav li a.border,nav ul.top-nav li:last-child a,ul.tab li a.border{border-right:0}.navbar-fixed-bottom,.navbar-fixed-top{float:right;width:auto}.header-link{margin-top:10px}.header-link li{list-style:none}.header-link li a{border:0!important;font-size:15px!important;padding:0 5px!important}.header-link fieldset{background:#f2f2f2;border:1px solid #e7e7e7;position:absolute;padding:5px;width:22%;margin-top:5px}.header-link fieldset label{display:block}.header-link fieldset input{width:92%}.header-link fieldset a{font-size:13px!important;margin-top:12px}.carat-arrow{position:relative;top:-13px;left:10px}.help-setting,.login-setting,.settings_menu{position:absolute;right:156px;top:100px;text-align:left;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px;border:1px solid #FFC362;background:#fba823;z-index:9}.help-setting li,.login-setting li,.settings_menu li{display:block;line-height:28px;padding-left:0!important}.help-setting li a,.login-setting li a,.settings_menu li a{border-right:0;border-bottom:1px solid #FFC362;display:block;border-left:0!important}.settings_menu li:last-child a{border:0}.help-setting{position:absolute;right:0;top:76px}.marquee{margin:15px 1% 0}.content_section{position:relative}.left-bar{border:1px solid #efefef}.collapse{background:url(../images/expand-colllapse.png) no-repeat 0 0;display:block;width:20px;height:22px;text-indent:-99999px;position:absolute;left:175px;top:30px}.expand{background:url("+imagePath+"\\resources\\template\\template1\\images\\expand-colllapse.png) no-repeat -23px 0;display:block;width:17px;height:22px;text-indent:-99999px;position:absolute;top:30px;z-index:999}.list{margin-top:10px}.list li{background:url("+imagePath+"\\resources\\template\\template1\\images\\arrow.png) no-repeat left 7px;margin:0 0 0 10px;padding-left:10px;line-height:23px;font-family:arial;display:block}span.title{font-size:19px;font-family:arial;color:#222;display:block;border-top:1px solid #e8e8e8;background-color:#f5f5f5;border-bottom:1px solid #e8e8e8;padding:10px 0 10px 40px;margin:10px 0 0}.cat-icon{background:url("+imagePath+"\\resources\\template\\template1\\images\\category_icon.png) no-repeat 10px 9px}.category li a{color:#7c7d89;line-height:30px;display:block;padding-left:10px}.category li a:hover{background:#f2f2f2;color:#222;padding-left:6px;border-left:4px solid #ee9200;text-decoration:none}.ad-icon{background:url(../images/advertise-icon.png) no-repeat 10px 9px}.ad-banner_div{padding:10px}.ad-banner_div img{margin-bottom:5px}.middle-bar{margin-left:8px}.search-bar{border:3px solid #279ce7;height:39px;position:relative}.search-bar input[type=text]{width:64%}.advance-bar{background:#fcfcfc;border:1px solid #f1f1f1;font-size:11px;color:#222;padding:8px}.details-box{background:url(../images/divider.png) no-repeat bottom;padding-bottom:20px}.details-box span{display:block;color:#222}.details-box b{color:#222;font-weight:400}.bottom-btn{border:1px solid #EFEFEF;margin-top:10px;overflow:hidden;padding:2px}.bottom-btn button{margin-top:7px;*margin-top:4px}.bottom-btn span{margin:2px 0 0 10px;*margin:4px 0 0 10px;color:#222}.bottom-btn select{border:1px solid #EFEFEF;padding:5px\\9;box-shadow:none}button.show-btn{font-size:12px;font-family:arial;padding:0 10px;line-height:29px}.right-bar{border:1px solid #efefef}.ex-icon{background:url(../images/exhibitions-icon.png) no-repeat 10px 8px}.tender-icon{background:url(../images/tender-icon.png) no-repeat 10px 9px}footer{background:#fbfbfb;border-top:1px solid #e7e7e7;max-width:1058px;max-width:"+(dynPageSize!=0?dynPageSize:1060)+"px\\9;margin-left:auto;margin-right:auto;margin-top:25px}.footer-links span{font-size:20px;color:#222;padding-bottom:15px;display:block;font-family:arial}.footer-links li,.footer-links li a{line-height:25px;color:#6c6d79;font-family:arial;font-size:12px;display:block}.footer-links li a:hover{text-decoration:underline}.footer-links li b{color:#222;font-weight:400}.social-icons{line-height:60px;display:block;padding-left:56px;font-size:22px;font-family:arial}.social-icons:hover{opacity:.8}.fb{background:url(../images/f-icon.png) no-repeat left;color:#3a589b}.tw{background:url(../images/t-icon.png) no-repeat left;color:#3a589b}.l-in{background:url(../images/in-icon.png) no-repeat left;color:#3a589b}.copy{border-top:1px solid #e7e7e7;margin-top:10px;font-size:11px;padding:0 0 30px}.inner-right-bar{border-left:5px solid #ececec;width:81.21%;border-top:1px solid #E8E8E8;border-right:1px solid #E8E8E8;border-bottom:1px solid #E8E8E8}.border-left{border-left:1px solid #E8E8E8!important}.js #main .accordion{visibility:hidden}.js #side .accordion{display:none}.accordion li{list-style-type:none}#side ul.accordion ul{margin:0;padding:0 0 0 20px}.accordion .outer{border:1px solid #dadada;border-width:0 1px 1px;background:#fff}.accordion .inner{margin-bottom:0;padding:.5em 20px 1em;position:relative;overflow:hidden}.accordion .inner .inner{padding-bottom:0}a.accordion-title{background-color:#f5f5f5;padding:12px 12px 12px 37px;border-bottom:1px solid #e8e8e8;color:#222;font-size:15px}.submenu li a:hover,a.accordion-title:hover{text-decoration:none}.inbox-icon{background:url(../images/inbox-icon.png) no-repeat 15px}.admini-icon{background:url(../images/administrator-icon.png) no-repeat 14px}.auction-icon{background:url(../images/auction-icon.png) no-repeat 9px}.report-icon{background:url(../images/report-icon.png) no-repeat 13px}a.trigger{display:block}.submenu{background:#fafafa}.submenu li a{border-bottom:1px solid #eee;padding:10px 0 10px 35px;color:#5c5d67}.submenu li a.active,.submenu li a:hover{text-decoration:none;background:#FFF;color:#f59700;padding-left:31px;border-left:4px solid #f59700}.submenu-sub{background:#fdfdfd}.last-child a.trigger{background-image:none;font-weight:400}.submenu-sub li.last-child a{padding-left:41px}.submenu-sub li.last-child a:hover{padding-left:37px}#main a.trigger{background-color:#f0f0f0}#main a.trigger.open{border-color:#dadada;background-color:#e7e7e7}#main a:active.trigger.open,#main a:focus.trigger.open,#main a:hover.trigger.open{border-color:#bcd}#side a.active{font-weight:700;color:#f72;text-decoration:none}a.important{background:url(../images/star.png) no-repeat;text-indent:-99999px;display:block;height:16px;width:17px}a.important:hover{background:url(../images/star.png) no-repeat center -16px}.breadcrumb{background:#F6F6F6}.breadcrumb li a{color:#222;padding:0 10px 0 2px;background:url(../images/arrow.png) right no-repeat;line-height:25px}.breadcrumb li a:hover{text-decoration:none;color:#069}.breadcrumb li:last-child a{background:none!important}.breadcrumb li a.active{color:#069;text-decoration:none}.page-title{position:relative;line-height:40px;border-bottom:1px solid #e8e8e8;background:#FBFBFB}.inbox-searchbar{margin-top:3px}#errorDivNor{display:block;margin:-10px 0 0 5px;float:left}.inbox-searchbar input{padding:5px;margin-top:4px\\9;*margin-top:4px}.adv-srch{line-height:35px}.div-header-link div{padding:3px 2px 2px;float:left}.div-header-link div.creat-client{padding:12px 10px 10px 0}.div-header-link div.creat-client a{border:0;background:0 0;float:none;padding:0 2px 0 5px;display:inline}.div-header-link a{background:url("+imagePath+"grad.jpg) repeat-x!important;padding:14px 25px 13px;float:left;border-right:1px solid #d3d3d3;display:block}.div-header-link a.active,.div-header-link a:hover{background:#FFF;text-decoration:none;color:#222;border-bottom:2px solid #757575;padding:14px 15px 11px}.gradi{background:none repeat scroll 0 0 #FBFBFB}.pagination{padding:5px 10px!important;line-height:29px}.pagination div button{margin:2px 0 0 5px;margin:3px 0 0 5px}.pagination div li a{padding:0 10px;line-height:28px;color:#222}.pagination input{margin:3px 0 0 5px;padding:4px;width:30px!important}.content-div{padding:10px 13px 10px 10px}.listing-div{border:1px solid #ECECEC;padding:0 10px}.listing-tab{margin:10px 0 0;overflow:hidden;border:1px solid #ECECEC;border-bottom:0;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.listing-tab li a{padding:10px 20px;display:block;float:left;color:#7C7D89;font-size:18px;border-right:1px solid #ECECEC;font-family:arial}.listing-tab li a.active,.listing-tab li a:hover{text-decoration:none;color:#ee9200;background:url(../images/orange-arrow.png) no-repeat center 33px;border-bottom:2px solid #ee9200}.bidding-row-highlight{background-color:#cae5ff}.bidDetailHighlight{background-color:#FAF2DC;color:#000;font:700}.view-event table tr td{border:0;width:25%;border-bottom:1px solid #ECECEC;padding:3px 5px 3px 15px}.view-info{margin-top:10px}.view-info table tr td{border:0;padding:5px 5px 5px 15px}.view-info label{display:block}.view-event table tr td label span{color:red}.view-event label{margin:2px 0;line-height:18px;display:block;color:#404040}.view-event h2{padding:3px 0}.table-border table tr th{text-align:center}.mandatory1{padding:3px 0 0 20px}.cursor{cursor:pointer}.row-highlight{background-color:#d8f4d2}.view-event p{padding:0}.view-event li{list-style:inherit;display:list-item}.item-price-75{width:75%;display:block}.item-price-94{width:94%;display:block}.defcomp{width:50%!important;margin-top:10px!important;margin-bottom:10px!important;margin-right:10px!important}.defcomptext{width:46.5%!important;margin-top:10px!important;margin-bottom:10px!important;margin-right:10px!important}.mini-formfield{margin-top:20px;border-bottom:1px solid #E8E8E8;padding-bottom:15px}.mini-formfield li{line-height:18px}.mini-formfield table tr td{border:0;padding-top:5px;padding-bottom:5px}.mini-formfield table tr td label{margin-top:12px}.display-block table tr td label{display:block}.mini-formfield table tr td span{color:red}.mini-formfield input,.mini-formfield textarea{margin:0;width:90%}.mini-formfield select{margin:0;width:96%}.mini-formfield input[type=checkbox],.mini-formfield input[type=radio]{margin:5px;width:auto}.mini-formfield input.dateBox{width:79%!important}.table-border table tr td,.table-border table tr th{border-left:1px solid #E8E8E8}.table-border table tr td input[type=text],.table-border table tr td select{width:200px}.table-border table tr td textarea{width:92%;min-height:50px}.table-border p{padding-top:0;padding-bottom:10px;text-align:left}.label-span{color:#5D5E68!important}.white{background-color:#fff}.matrix-table button{margin:4px;padding:4px 5px}.matrix-table input[type=file]{margin:0 4px}.matrix-table input,.matrix-table textArea{width:150px}.matrix-table select{width:162px}.matrix-table .nmbr-select{width:60px}.row-table table tr td{border:0;padding:5px}.row-table table input{width:90%}.row-table table select{width:97%}.add-confi-icn,.approve-icn,.approve-rights-icn,.assign-rights-icn,.auction-icn,.deptree-icn,.dft-setting-icn,.disable-icn,.document-icn,.edit-icn,.enabel-icn,.industry-icn,.mail-icn,.plus-icn,.reject-icn,.rend-mail-icn,.reset-password-icn,.setting-icn,.terms-icn,.theme-icn,.unalock-icn,.unamap-icn,.user-remail-icn,.user-renew-icn{background:url(../images/sprite.png) no-repeat -13px -90px;display:block;float:left;height:20px;margin:0 1px;text-indent:-9999px;width:26px}.theme-icn{background-position:-40px -90px}.dft-setting-icn{background-position:-67px -90px}a.approve-icn{background-position:-95px -90px}.setting-icn{background-position:-120px -90px}.deptree-icn{background-position:-146px -90px}.mail-icn{background-position:-173px -90px}.plus-icn{background-position:-200px -90px}.reject-icn{background-position:-226px -90px}.auction-icn{background-position:-256px -90px}.enabel-icn{background-position:-284px -90px}.industry-icn{background-position:-310px -90px}.rend-mail-icn{background-position:-337px -90px}.unalock-icn{background-position:-363px -88px}.user-remail-icn{background-position:-392px -88px}.user-renew-icn{background-position:-423px -88px}.add-confi-icn{background-position:-454px -88px}.unamap-icn{background-position:-19px -120px}.document-icn{background-position:-50px -119px}.assign-rights-icn{background-position:-82px -120px}.disable-icn{background-position:-110px -120px}.reset-password-icn{background-position:-139px -122px}.approve-rights-icn{background-position:-165px -122px}.terms-icn{background-position:-192px -122px}.errorMsg,.noticeMsg,.successMsg,infoMsg{border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.successMsg{background:url(../images/successIcn.png) no-repeat scroll 10px center #E9F9E5;border:1px solid #B4E8AA;color:#1C8400;margin-bottom:5px;padding:10px 10px 10px 50px}.errorMsg{background:url(../images/errorIcn.png) no-repeat scroll 10px center #F9E5E6;border:1px solid #E8AAAD;color:#B50007;margin-bottom:5px;padding:10px 10px 10px 50px}.noticeMsg{background:url(../images/noticeIcn.png) no-repeat scroll 10px center #F9F9E5;border:1px solid #E8E3AA;color:#828400;padding:10px 10px 10px 50px}.noticeMsg li{line-height:20px;list-style:decimal outside none!important;margin-left:18px;display:list-item}.infoMsg{background:url(../images/infoIcn.png) no-repeat scroll 5px 3px #fbf8e9;border:1px solid #fec600;color:#87836d;width:230px;position:relative;padding:5px 5px 5px 28px}.infoMsg span{position:absolute;display:block;top:-11px;left:22px}.validationMsg{color:red;padding:5px 0 0 2px}.helpMsg{color:#03a200}.doc-table tr th .doc-table tr td{padding:7px;line-height:18px;text-align:left;width:auto!important}.doc-table tr th{text-align:center}span.arrow{border-left:5px solid transparent;border-right:5px solid transparent;border-top:7px solid #000;display:block;height:1px;left:40px;position:relative;top:3px;width:1px}.popupbox select{width:93.5%!important}.popup-title h3{font-size:20px;color:#222;background:#e3e3e3;padding:10px}.login-pop{width:400px}.user-pop{width:500px}/*! fancyBox v2.1.5 fancyapps.com | fancyapps.com/fancybox/#license */.fancybox-image,.fancybox-inner,.fancybox-nav,.fancybox-nav span,.fancybox-outer,.fancybox-skin,.fancybox-tmp,.fancybox-wrap,.fancybox-wrap iframe,.fancybox-wrap object{padding:0;margin:0;border:0;outline:0;vertical-align:top}.fancybox-wrap{position:absolute;top:0;left:0;z-index:8020;width:auto!important}.fancybox-skin{position:relative;background:#f9f9f9;color:#444;text-shadow:none;-webkit-border-radius:4px;-moz-border-radius:4px;border-radius:4px;border:5px solid #e3e3e3;padding:0!important;border-top:0}.fancybox-opened{z-index:8030}.fancybox-opened .fancybox-skin{-webkit-box-shadow:0 10px 25px rgba(0,0,0,.5);-moz-box-shadow:0 10px 25px rgba(0,0,0,.5);box-shadow:0 10px 25px rgba(0,0,0,.5)}.fancybox-inner,.fancybox-outer{position:relative}.fancybox-inner{overflow:hidden;width:100%!important}.fancybox-type-iframe .fancybox-inner{-webkit-overflow-scrolling:touch}.fancybox-iframe,.fancybox-image{display:block;width:100%;height:100%}.fancybox-image{width:100%;height:100%;max-width:100%;max-height:100%}#fancybox-loading,.fancybox-close,.fancybox-next span,.fancybox-prev span{background-image:url(../images/fancybox_sprite.png)}#fancybox-loading{position:fixed;top:50%;left:50%;margin-top:-22px;margin-left:-22px;background-position:0 -108px;opacity:.8;cursor:pointer;z-index:8060}#fancybox-loading div{width:44px;height:44px;background:url(../images/fancybox_loading.gif) center center no-repeat}.fancybox-close{position:absolute;top:-20px;right:-22px;width:36px;height:36px;cursor:pointer;z-index:8040}.fancybox-nav{position:absolute;top:0;width:40%;height:100%;cursor:pointer;text-decoration:none;background:transparent url(../images/blank.gif);-webkit-tap-highlight-color:rgba(0,0,0,0);z-index:8040}.fancybox-prev{left:0}.fancybox-next{right:0}.fancybox-nav span{position:absolute;top:50%;width:36px;height:34px;margin-top:-18px;cursor:pointer;z-index:8040;visibility:hidden}.fancybox-prev span{left:10px;background-position:0 -36px}.fancybox-next span{right:10px;background-position:0 -72px}.fancybox-nav:hover span{visibility:visible}.fancybox-tmp{position:absolute;top:-99999px;left:-99999px;visibility:hidden;max-width:99999px;max-height:99999px;overflow:visible!important}.fancybox-lock{overflow:hidden!important;width:auto}.fancybox-lock body{overflow:hidden!important}.fancybox-lock-test{overflow-y:hidden!important}.fancybox-overlay{position:absolute;top:0;left:0;overflow:hidden;display:none;z-index:8010;background:url(../images/fancybox_overlay.png)}.fancybox-overlay-fixed{position:fixed;bottom:0;right:0}.fancybox-lock .fancybox-overlay{overflow:auto;overflow-y:scroll}.fancybox-title{visibility:hidden;font:400 13px/20px \"Helvetica Neue\",Helvetica,Arial,sans-serif;position:relative;text-shadow:none;z-index:8050}.fancybox-opened .fancybox-title{visibility:visible}.fancybox-title-float-wrap{position:absolute;bottom:0;right:50%;margin-bottom:-35px;z-index:8050;text-align:center}.fancybox-title-float-wrap .child{display:inline-block;margin-right:-100%;padding:2px 20px;background:0 0;background:rgba(0,0,0,.8);-webkit-border-radius:15px;-moz-border-radius:15px;border-radius:15px;text-shadow:0 1px 2px #222;color:#FFF;font-weight:700;line-height:24px;white-space:nowrap}.fancybox-title-outside-wrap{position:relative;margin-top:10px;color:#fff}.fancybox-title-inside-wrap{padding-top:10px}.fancybox-title-over-wrap{position:absolute;bottom:0;left:0;color:#fff;padding:10px;background:#000;background:rgba(0,0,0,.8)}.fancybox-custom .fancybox-skin{box-shadow:0 0 50px #222}element.style{display:block}@media only screen and (-webkit-min-device-pixel-ratio:1.5),only screen and (min--moz-device-pixel-ratio:1.5),only screen and (min-device-pixel-ratio:1.5){#fancybox-loading,.fancybox-close,.fancybox-next span,.fancybox-prev span{background-image:url(../images/fancybox_sprite@2x.png);background-size:44px 152px}#fancybox-loading div{background-image:url(../images/fancybox_loading@2x.gif);background-size:24px 24px}}.timer{border-top:1px solid #dbedff;border-bottom:1px solid #dbedff;border-radius:2px;background:#eef8ff}.rmn-time{margin:10px 20px 10px 10px}.rmn-time img{margin-right:10px}.se-time{margin-top:10px;margin-left:10px}.timer p{margin:0;padding:0}.points{margin-top:15px}.points li{display:block;line-height:24px;background:url(../images/li-arrow.png) no-repeat left;padding-left:20px}.faq-div h3{padding:10px;color:#069;border:1px solid #E8E8E8;background:url("+imagePath+"\\resources\\template\\template1\\images\\grad.jpg) repeat-x;font-family:arial;cursor:pointer;margin-bottom:2px;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.faq-div div{border:1px solid #E8E8E8;border-top:0;display:none;padding:10px;padding-bottom:0;margin-bottom:5px;margin-top:-5px;border-radius:2px;-moz-border-radius:2px;-webkit-border-radius:2px}.faq-div div p{margin-bottom:20px;padding-top:0}.multy-section section.inner-right-bar{width:100%!important}@media screen and (-webkit-min-device-pixel-ratio:0){.div-header-link div{padding:4px 0 2px 2px}.search-bar{height:37px}.bottom-btn span{margin:1px 0 0 10px}.search-input{padding:10px}.assign-checkbox label input{height:16px;width:16px}}@media screen and (max-width:1023px){.container_25{max-width:768px}.rel-width-left{width:22.7%!important}.rel-width-mid{width:76%!important}.container_25 .grid_7{width:100%}nav{display:none}}.print-pdf.main_container, .print-pdf .container_25{max-width:100%;}.timer-div tr td p {padding:0 !important;margin:0;}.timer-div tr td{vertical-align:middle;}.timer-div{background:#E8F8FF;}.timer-sticky{border-top:1px solid #dbedff;border-bottom:1px solid #dbedff;border-radius:2px;background:#e8f8ff;position:relative;padding:0 10px;}.nav-sticky {padding: 25px 0;background-color: white;position: -webkit-sticky;}.form-hd-ft-clr{background:#fdfdfd;}.view-event-3 p{padding:0;}.no-border{border:0 !important;}table.borderForH1Bidder,tr.borderForH1Bidder,td.borderForH1Bidder,th.borderForH1Bidder{border:1px solid #E8E8E8; !important;}");	
	        	}
	            htmls.append(".noprint{ display: none; }");
	        }
	        
	        if (request.getParameter("hdisCustomLandScap") != null && !request.getParameter("hdisCustomLandScap").equals("")) {
	            htmls.append("@page{ size: "+request.getParameter("hdisCustomLandScap")+"px;}");
	        }
	        else  if (request.getParameter("dynPageSize") != null && !request.getParameter("dynPageSize").equals("")) {
	        	if((request.getParameter("isLandScap") != null && request.getParameter("isLandScap").equals("YES")) || (dynPageSize > 3508)) {
	        	    htmls.append("@page{ size: "+ Math.floor(Integer.parseInt(request.getParameter("dynPageSize")) * 0.264583) +"mm 210mm;}");
	        	} else {
	        		htmls.append("@page{ size: "+request.getParameter("dynPageSize")+"px;}");
	        	}
	        }
	        if (request.getParameter("isHeaderRequire") != null && !request.getParameter("isHeaderRequire").equals("")) {
				String setHeaderData[]= request.getParameter("isHeaderRequire").split("@@");
				if(setHeaderData.length != 0 ){
		        	if(setHeaderData[0].equals("YES") && setHeaderData[0] != null && setHeaderData.length==2)
		        	{
	        	     	String htmlHeaderData =setHeaderData[1].equals("[pageNo]") ? "<div id='pdfPrintHeaderHtml'></div>" : "<div id='pdfPrintHeaderHtml'>"+ setHeaderData[1]+"</div>";
	        	     	pdfBuffer = htmlHeaderData + pdfBuffer;
		        		/*htmls.append("@page { padding-top:0.1in; margin-top: 1in; @top-left  { content: element(pdfPageHeading); } } #pdfPrintHeaderHtml { position: running(pdfPageHeading); } ");*/
	        	     	if(setHeaderData[1].equals("[pageNo]")){
	        	     		htmls.append("@page { padding-top:0.1in; margin-top: 1in;  @top-right  {content:"+"\" Page  \""+ " counter(page) "+"\" of \""+ "counter(pages);} } #pdfPrintHeaderHtml { position: running(pdfPageHeading);color:gray; } ");
	        	     	}else{
	        	     		htmls.append("@page { padding-top:0.1in; margin-top: 1in; @top-right  { content: element(pdfPageHeading); } } #pdfPrintHeaderHtml { position: running(pdfPageHeading); } ");
	        	     	}
		        	}
		        }
			}
	        if (request.getParameter("isFooterRequire") != null && !request.getParameter("isFooterRequire").equals("")) {
				String setFooterData[]= request.getParameter("isFooterRequire").split("@@");
		        if(setFooterData.length != 0 ){
		        	if(setFooterData[0].equals("YES") && setFooterData[0] != null && setFooterData.length==2){
		        		String htmlFooterData =setFooterData[1].equals("[pageNo]") ? "<div id='pdfPrintFooterHtml'></div>" : "<div id='pdfPrintFooterHtml'>"+ setFooterData[1]+"</div>";
		        		pdfBuffer = htmlFooterData + pdfBuffer ;
		        		if(setFooterData[1].equals("[pageNo]")){
	        	     		htmls.append("@page { padding-top:0.1in; margin-top: 1in;  @bottom-right  {content:"+"\" Page  \""+ " counter(page) "+"\" of \""+ "counter(pages);} } #pdfPrintFooterHtml { position: running(pdfPageFooter);color:gray; } ");
	        	     	}else{
	        	     		htmls.append("@page { padding-top:0.1in; margin-top: 1in; @bottom-right  { content: element(pdfPageFooter); } } #pdfPrintFooterHtml { position: running(pdfPageFooter);color:gray; } ");
	        	     	}
		        	}
		        }
			}
            htmls.append(".width-212{width: 212px;}.width-546{width: 540px;}.width-685{width: 683px;}.width-267{width: 267px;}.event-dtl table tr td{border-top:1px solid #E8E8E8 !important;border-bottom:1px solid #E8E8E8 !important;}.event-dtl p{padding: 0;	border-bottom:none !important; text-align:justify;}.width-555WithAuto{width:555px;overflow:auto;}.width-695WithAuto{width:695px;overflow:auto;}.width-785WithAuto{width:785px;overflow:auto;}.width-695WithAuto{width:695px;overflow:auto;}.width-555WithAuto table tr td:first-child,.width-695WithAuto table tr td:first-child,.width-630WithAuto table tr td:first-child,.width-785WithAuto table tr td:first-child{border-left:0 !important;}.width-555WithAuto table tr td:last-child,.width-695WithAuto table tr td:last-child,.width-630WithAuto table tr td:first-childm,.width-785WithAuto table tr td:first-child{border-right:0 !important;}.para-word-break p{word-break:break-word;}.word-break{word-break:break-word;}");
	        htmls.append(".listing-style li {list-style: decimal;margin-left: 20px;display: list-item;line-height: 20px;}"); 
	        htmls.append("</style>");
	        if(multiLanguageSupportRequired)
	        {
	        	htmls.append("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">");	
	        }
            htmls.append("</head>");
	        }
	        //Add image in header part into the PDF report.
	       /* StringBuffer domainName = request.getRequestURL();
	        String contextPath = request.getRequestURI();
	        String actualDomainValue = domainName.toString(); 
	        if(contextPath != null && !contextPath.equals("")){
	        	actualDomainValue = actualDomainValue.substring(0,domainName.indexOf(contextPath));
	        }
	        Cookie[] cookies = request.getCookies();
	        String logoname=null;
	        for (Cookie cookie : cookies) {
	        	 if ("logo".equals(cookie.getName())) {
	        		 logoname=cookie.getValue();
	             }
			}
	        int clientId=abcUtility.getSessionClientId(request);
	        htmls.append("<div style=\"text-align:center\">");
	        htmls.append("<img align=\"center\" src=\""+actualDomainValue+request.getContextPath()+"/resources/static-images/"+clientId+"/"+logoname+" \" width=\"650\" height=\"50\" />");
	        //End by header code.
	        htmls.append("</div>");*/
//	        pdfBuffer = "<TABLE width=\"100%\" class=\"formField1\" style=\"BORDER-RIGHT: #ccc 1px solid; BORDER-LEFT: #ccc 1px solid\" cellSpacing=\"0\" cellpadding=\"0\"> <TBODY> <TR> <TH width=\"15%\" class=\"f-bold\">Department</TH> <TD width=\"25%\">PKI</TD> <TH width=\"15%\" class=\"f-bold\">Department officer</TH> <TD width=\"25%\">Sachin Patel</TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Event Id</TH> <TD width=\"25%\">504</TD> <TH width=\"15%\" class=\"f-bold\">Reference No.</TH> <TD width=\"25%\">vipu/test/15-11-2013/01</TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Brief scope of work</TH> <TD colSpan=\"3\">test01</TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Details</TH> <TD colSpan=\"3\"> <P>test 01</P></TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Product / service / work keywords</TH> <TD width=\"25%\" colSpan=\"3\">Test Apparatus</TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Stage </TH> <TD width=\"25%\">Single </TD> <TH width=\"15%\" class=\"f-bold\">Envelope</TH> <TD>Price bid </TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Bid validity period (in days)</TH> <TD width=\"25%\">10 </TD> <TH width=\"15%\" class=\"f-bold\">Type of contract</TH> <TD width=\"25%\">Goods</TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Project duration / delivery or completion period (in days)</TH> <TD width=\"25%\">21500 </TD> <TH width=\"15%\" class=\"f-bold\">Download tender document</TH> <TD width=\"25%\">Before login </TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Tender value / Estimated cost</TH> <TD width=\"25%\">15235740.0 </TD> <TH width=\"15%\" class=\"f-bold\">Accept decimal value up to</TH> <TD width=\"25%\">1 </TD></TR></TBODY></TABLE> <DIV class=\"formHeader1 m-top no_border-radius\">Bid submission configuration </DIV> <TABLE width=\"100%\" class=\"formField1\" style=\"BORDER-RIGHT: #ccc 1px solid; BORDER-LEFT: #ccc 1px solid\" cellSpacing=\"0\" cellpadding=\"0\"> <TBODY> <TR> <TH width=\"15%\" class=\"f-bold\">Distribution of PO</TH> <TD width=\"25%\">Not allowed </TD> <TH width=\"15%\" class=\"f-bold\">Item wise L1/H1</TH> <TD width=\"25%\">Don't allow </TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Mode of tender submission</TH> <TD width=\"25%\">Online </TD> <TH width=\"15%\" class=\"f-bold\">Bidding access</TH> <TD width=\"25%\">Limited </TD></TR> <TR> <TH width=\"15%\" class=\"f-bold v-a-top\">Type of contract</TH> <TD width=\"25%\">Goods </TD> <TH width=\"15%\" class=\"f-bold\">Base currency</TH> <TD width=\"25%\">INR </TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Bidding type</TH> <TD width=\"25%\">Indigenous </TD> <TH width=\"15%\" class=\"f-bold\">Consortium</TH> <TD width=\"25%\">Not allowed </TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Bid withdrawal</TH> <TD width=\"25%\">Allowed </TD> <TD width=\"15%\" class=\"f-bold\">&nbsp;</TD> <TD width=\"25%\">&nbsp;</TD></TR></TBODY></TABLE> <DIV class=\"formHeader1 m-top no_border-radius\" id=\"divKeyConfDtl\">Key configuration </DIV> <TABLE width=\"100%\" class=\"formField1\" id=\"tldKeyConfDtl\" style=\"BORDER-RIGHT: #ccc 1px solid; BORDER-LEFT: #ccc 1px solid\" cellSpacing=\"0\" cellpadding=\"0\"> <TBODY> <TR> <TH width=\"15%\" class=\"f-bold\">Bidding variant</TH> <TD width=\"25%\">Buy </TD> <TH width=\"15%\" class=\"f-bold\">Pre-bid meeting</TH> <TD width=\"25%\">Don't allow </TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Workflow requires</TH> <TD width=\"25%\">No </TD> <TH width=\"15%\" class=\"f-bold\">Question / Answer requires</TH> <TD width=\"25%\">No </TD></TR></TBODY></TABLE> <DIV class=\"formHeader1 m-top no_border-radius\">Dates configuration </DIV> <TABLE width=\"100%\" class=\"formField1\" style=\"BORDER-RIGHT: #ccc 1px solid; BORDER-LEFT: #ccc 1px solid\" cellSpacing=\"0\" cellpadding=\"0\"> <TBODY> <TR> <TH width=\"15%\" class=\"f-bold\">Document downloading start date and time</TH> <TD width=\"25%\">16/11/2013 15:23:00 </TD> <TH width=\"15%\" class=\"f-bold\">Document Downloading end date and time</TH> <TD width=\"25%\">17/11/2013 14:23:00 </TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Bid submission start date and time</TH> <TD width=\"25%\">15/11/2013 14:30:05 </TD> <TH width=\"15%\" class=\"f-bold\">Bid submission end date and time</TH> <TD width=\"25%\">20/11/2013 14:23:00 </TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">Bid opening date and time</TH> <TD width=\"25%\">22/11/2013 14:23:00 </TD> <TD width=\"15%\" class=\"f-bold\">&nbsp;</TD> <TD width=\"25%\">&nbsp;</TD></TR></TBODY></TABLE> <DIV class=\"formHeader1 m-top no_border-radius\" id=\"divFeesDtl\">Document / EMD / Security fee detail </DIV> <TABLE width=\"100%\" class=\"formField1\" id=\"tldFeesDtl\" style=\"BORDER-RIGHT: #ccc 1px solid; BORDER-LEFT: #ccc 1px solid\" cellSpacing=\"0\" cellpadding=\"0\"> <TBODY> <TR> <TH width=\"15%\" class=\"f-bold\">Document fees</TH> <TD width=\"25%\">Not allowed </TD> <TH width=\"15%\" class=\"f-bold\">Tender security fees</TH> <TD width=\"25%\">Not allowed </TD></TR> <TR> <TH width=\"15%\" class=\"f-bold\">EMD</TH> <TD width=\"25%\">Not allowed </TD> <TD width=\"15%\" class=\"f-bold\">&nbsp;</TD> <TD width=\"25%\">&nbsp;</TD></TR></TBODY></TABLE>".replaceAll("<br>", "<br/>").replaceAll("&nbsp;", "&#160;").replaceAll(" & ", " &#38; ").replaceAll("colSpan", "colspan").replaceAll("cellSpacing", "cellspacing").replaceAll("cellPadding", "cellpadding");
	        htmls.append("<body>").append(pdfBuffer).append(" </body></html>");
	        return htmls; 
	}
	/**
	 * 
	 * @author bharat
	 * @param pdfBuffer
	 * @param fileName
	 * @param file
	 * @param id
	 * @param generateType
	 * @param response
	 * @param request
	 * @return
	 * @throws IOException
	 * @throws DocumentException
	 * @throws ServletException
	 */
	private String pdfGenerationForPrint(String pdfBuffer, String fileName, File file, String id,int generateType, HttpServletResponse response, HttpServletRequest request) throws IOException, DocumentException, ServletException {
        pdfBuffer = pdfBuffer.replaceAll("<br>", "<br/>").replaceAll("­ ","-").replaceAll("&shy; "," ").replaceAll("Â"," ").replaceAll("&nbsp;"," ").replaceAll("&", "&amp;").replaceAll("colSpan", "colspan").replace("=\"\"","");
        FileOutputStream fos = new FileOutputStream(file);
        ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        int clientId = 0;
        if(clientBean!=null)
        {
        	clientId = clientBean.getClientId();
        }
        
        multiLanguageSupportRequired = CommonUtility.isClientConditionExistInProperty(multiLanguageSupportRequiredInPDF, clientId);        
        StringBuilder htmls = generateFinalData(request,generateType,pdfBuffer);
        Document htmlParseTagCompleteString = Jsoup.parse(htmls.toString());		 // @ janak dhanani Jsop for incomplete tags and parser Bug #21746
        String finalData= AbcUtility.reverseReplaceSpecialChars(htmlParseTagCompleteString.toString());
        //renderer.getFontResolver().addFont("C:\\Windows\\Fonts\\Calibri.ttf","UTF-8",BaseFont.NOT_EMBEDDED);
    	if(multiLanguageSupportRequired)
    	{
            PD4ML pd4mlRender = new PD4ML();
            pd4mlRender.enableDebugInfo();
            pd4mlRender.adjustHtmlWidth();                
            String fontPath = request.getServletContext().getRealPath("/WEB-INF/i18n/fonts");
            pd4mlRender.useTTF(fontPath, true );
            pd4mlRender.setDefaultTTFs("Calibri","Times New Roman", "Arial");  
            finalData = finalData.replaceAll("word-break", "word-wrap");
            StringReader stringDate = new StringReader(finalData);
            pd4mlRender.render(stringDate,fos);
    	}
    	else
    	{
	        ITextRenderer renderer = new ITextRenderer();
	        renderer.getFontResolver().addFont("C:\\Windows\\Fonts\\Calibri.ttf",BaseFont.IDENTITY_H,BaseFont.NOT_EMBEDDED); // @ Bug #21690
	        renderer.setDocumentFromString(finalData);
	        renderer.layout();
	        renderer.createPDF(fos);
    	}
        return file.getAbsolutePath();  
	}
	
	/**Generate H1Bidder Winning letter
	 * @author keval.soni
	 * @param pdfBuffer
	 * @param fileName
	 * @param file
	 * @param id
	 * @param generateType
	 * @param response
	 * @param request
	 * @return
	 * @throws Exception
	 */
	private String pdfGenerationForMail(String pdfBuffer, String fileName, File file, String id,int generateType, HttpServletResponse response, HttpServletRequest request) throws Exception {
		FileOutputStream fos = new FileOutputStream(file);
       try {
	    pdfBuffer = pdfBuffer.replaceAll("<br>", "<br/>").replaceAll("­ ","-").replaceAll("&shy; "," ").replaceAll("Â"," ").replaceAll("&nbsp;"," ").replaceAll("&", "&amp;").replaceAll("colSpan", "colspan").replace("=\"\"","");
        ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        StringBuilder htmls = generateFinalData(request,generateType,pdfBuffer);
        Document htmlParseTagCompleteString = Jsoup.parse(htmls.toString());		 // @ janak dhanani Jsop for incomplete tags and parser Bug #21746
        String finalData= AbcUtility.reverseReplaceSpecialChars(htmlParseTagCompleteString.toString());
        int clientId = 0;
        if(clientBean!=null)
        {
        	clientId = clientBean.getClientId();
        }
        
        multiLanguageSupportRequired = CommonUtility.isClientConditionExistInProperty(multiLanguageSupportRequiredInPDF, clientId); 
    	if(multiLanguageSupportRequired)
    	{
            PD4ML pd4mlRender = new PD4ML();
            pd4mlRender.enableDebugInfo();
            pd4mlRender.adjustHtmlWidth();                
            String fontPath = request.getServletContext().getRealPath("/WEB-INF/i18n/fonts");
            pd4mlRender.useTTF(fontPath, true );
            pd4mlRender.setDefaultTTFs("Calibri","Times New Roman", "Arial");  
            finalData = finalData.replaceAll("word-break", "word-wrap");
            byte[] byteArray = finalData.getBytes("UTF-8");
            StringReader stringDate = new StringReader(new String(byteArray,Charset.forName("UTF-8")));
            pd4mlRender.render(stringDate,fos);
    	}
    	else
    	{
	        ITextRenderer renderer = new ITextRenderer();
	        renderer.getFontResolver().addFont("C:\\Windows\\Fonts\\Calibri.ttf",BaseFont.IDENTITY_H,BaseFont.NOT_EMBEDDED); // @ Bug #21690
	        renderer.setDocumentFromString(finalData);
	        renderer.layout();
	        renderer.createPDF(fos);
    	}
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}finally {
			fos.close();
		}
    	return file.getAbsolutePath();
	}
	/**
	 *  
	 * @author bharat
	 * @param file
	 */
	private void deleteIfExist(File file) {
	    	try{
	    	 if (file.exists()){
	    		 file.delete();
	          }
	    	}catch(Exception e)
	    	{
	    		 exceptionHandlerService.writeLog(e);
	    	}
	}
        
	@RequestMapping(value = "/vendordownloadzip", method = RequestMethod.POST)
    public void vendoeDocumentDownloadAllAsZip(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
        try {
        	vendorDocumentDownloadAllProcess(request,response,session,false);
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
    }
	
	@RequestMapping(value = "/vendorautodownloadzip", method = RequestMethod.POST)
    public String vendorDocumentAllAsZipToDarshak(HttpServletRequest request, HttpServletResponse response,HttpSession session,RedirectAttributes redirectAttributes) {
    	String retVal = "";
    	try {
			int companyEnlistment = Integer.parseInt(request.getParameter("txtcompanyEnlistment"));
			int reviseFormId = Integer.parseInt(request.getParameter("txtReviseFormId"));
			String zipFile = vendorDocumentDownloadAllProcess(request, response, session,true);
			
			List<Object[]> lstClientServiceUrl = commonService.getClientServiceUrlData(abcUtility.getSessionClientId(request),8);
			Integer clientServiceUrlId = (Integer)lstClientServiceUrl.get(0)[0]; 
			String url = lstClientServiceUrl.get(0)[2].toString();
			
			String RequestFor = "Vendor company enlistmented zip document file";
			TblClientServiceStatus tblClientServiceStatus = new TblClientServiceStatus();
			tblClientServiceStatus.setTblClientServiceUrl(new TblClientServiceUrl(clientServiceUrlId));
			tblClientServiceStatus.setEventId(companyEnlistment);
			tblClientServiceStatus.setRequestData(RequestFor);
			tblClientServiceStatus.setResponseData("");
			tblClientServiceStatus.setStatus(0);
			tblClientServiceStatus.setCreatedBy(abcUtility.getSessionUserId(request));
			tblClientServiceStatus.setCreatedOn(commonService.getServerDateTime());
			commonService.addClientServiceUrlStatus(tblClientServiceStatus);
			tblClientServiceStatus = null;
			String fileNo = vendorEnlistmentService.getCompanyEnlistmentFields(companyEnlistment,"tblcompanyenlistment.fileNo,tblcompanyenlistment.cstatus").get(0)[0].toString();
        	String responseData = abcHttpUtil.sendVendorZipByWebservice(url, "POST", fileNo ,zipFile);
    		JSONObject jResponse = new JSONObject(responseData);
    		
			tblClientServiceStatus = commonService.getClientServiceUrlStatus(clientServiceUrlId).get(0);
			tblClientServiceStatus.setTblClientServiceUrl(new TblClientServiceUrl(clientServiceUrlId));
			tblClientServiceStatus.setEventId(companyEnlistment);
			tblClientServiceStatus.setRequestData(RequestFor);    			
			tblClientServiceStatus.setResponseData(jResponse.getString("response"));
			tblClientServiceStatus.setStatus((Integer)jResponse.get("status"));
			tblClientServiceStatus.setCreatedBy(abcUtility.getSessionUserId(request));
			tblClientServiceStatus.setCreatedOn(commonService.getServerDateTime());
			commonService.addClientServiceUrlStatus(tblClientServiceStatus);
			
    		StringBuilder retUrl = new StringBuilder();
    		retVal=retUrl.append("enlistment/bidder/getvendorenlistformdetails/"+companyEnlistment+"/"+reviseFormId).toString();
    		retVal="redirect:/" + retVal + encryptDecryptUtils.generateRedirect(retVal, request);
            if(reviseFormId == 0){
            	redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_final_submission");   
            }else{
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_revise");   
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
        return retVal.toString();
    }
	
    public String vendorDocumentDownloadAllProcess(HttpServletRequest request, HttpServletResponse response,HttpSession session,boolean isAutoDownload) throws Exception{
    	int companyEnlistment = Integer.parseInt(request.getParameter("txtcompanyEnlistment"));
        String pdfBuffer = setFileDefaultData(request);
        String fileName = request.getParameter("hdfileName");
        String id = request.getParameter("hdid");
        
        String filePath = docUploadPath + "\\"+abcUtility.getSessionClientId(request)+"\\" + companyEnlistment+"\\gslzipdocs";
        File path = new File(filePath);
        if (path.exists()) {
           FileUtils.forceDelete(path);
           path.mkdirs();
        }else{
            path.mkdirs();
        }
        File zipFile = new File(filePath + ".zip");
       
        if (StringUtils.hasLength(pdfBuffer) && StringUtils.hasLength(id)) {
            pdfBuffer = pdfBuffer.replace("<br>", "<br/>").replace("&nbsp;", " ").replace(" & ", "&amp;").replace("colSpan", "colspan").replace("=\"\"", "").replace("BR", "br/");

            File pdfFile = new File(filePath + "\\" + "Company Enlistment Report" + ".pdf");
            FileOutputStream fos = new FileOutputStream(pdfFile);
            StringBuilder htmls = generateFinalData(request, 0, pdfBuffer);
            Document htmlParseTagCompleteString = Jsoup.parse(htmls.toString());     // @ janak dhanani Jsop for incomplete tags and parser Bug #22267
            String finalData = AbcUtility.reverseReplaceSpecialChars(htmlParseTagCompleteString.toString());
            finalData = finalData.replace("&", "&amp;");
            ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            int clientId = 0;
            if(clientBean!=null)
            {
            	clientId = clientBean.getClientId();
            }
            
            multiLanguageSupportRequired = CommonUtility.isClientConditionExistInProperty(multiLanguageSupportRequiredInPDF, clientId); 
        	if(multiLanguageSupportRequired)
        	{
                PD4ML pd4mlRender = new PD4ML();
                pd4mlRender.enableDebugInfo();
                pd4mlRender.adjustHtmlWidth();                
                String fontPath = request.getServletContext().getRealPath("/WEB-INF/i18n/fonts");
                pd4mlRender.useTTF(fontPath, true );
                pd4mlRender.setDefaultTTFs("Calibri","Times New Roman", "Arial");  
                finalData = finalData.replaceAll("word-break", "word-wrap");
                StringReader stringDate = new StringReader(finalData);
                pd4mlRender.render(stringDate,fos);
        	}
        	else
        	{
	            ITextRenderer renderer = new ITextRenderer();
	            renderer.getFontResolver().addFont("C:\\Windows\\Fonts\\Calibri.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED); // @ Bug #21690
	            renderer.setDocumentFromString(finalData);
	            renderer.layout();
	            renderer.createPDF(fos);
	            renderer.finishPDF();
	            fileEncryptDecryptUtil.fileEncryptUtil(pdfFile, (int) pdfFile.length());
	            fos.flush();
        	}
        }
        //Generate Zip 
        List<Object[]> getBidIdList = fileUploadService.getVendorBiddingList(companyEnlistment);

        if (getBidIdList != null && !getBidIdList.isEmpty()) {
            List<String> list = new ArrayList<String>();
            for (Object[] objects : getBidIdList) {
                list.add(objects[0].toString());
            }
             List<Object[]> lstDocumentDetails  = fileUploadService.getVendorBidderDocs(StringUtils.collectionToCommaDelimitedString(list), abcUtility.getSessionClientId(request), 565, 1);
            if (lstDocumentDetails != null && !lstDocumentDetails.isEmpty()) {
                for (Object[] docs : lstDocumentDetails) {
                    File dir = new File(filePath + "\\" + docs[3]);
                    if (!dir.exists()) {
                        dir.mkdirs();
                    }
//                      FileCopyUtils.copy(dir,new File(docUploadPath + docs[0]+"\\"+docs[1]));
                    File file = new File(docUploadPath + docs[0] + "\\" + docs[1]);
                    file = abcUtility.CheckDirExist(file);
                    if(file.exists()){
                    	FileUtils.copyFileToDirectory(file, dir);
                    }
                }
            }
        }
        
        abcUtility.zipDir(zipFile.toString(), filePath, filePath);
        if(isAutoDownload == false){
	        FileInputStream fis = new FileInputStream(zipFile);
	        byte[] buf = new byte[(int) zipFile.length()];
	        int offset = 0;
	        int numRead = 0;
	        while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
	            offset += numRead;
	        }
	        
	        ServletOutputStream outputStream = null;
	        response.setContentType("application/octet-stream");
	        response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + ".zip\"");
	        outputStream = response.getOutputStream();
	        outputStream.write(buf);
	        outputStream.flush();
	        outputStream.close();
        }
        return zipFile.toString();
    }
    
    private ByteArrayOutputStream signPDF(ByteArrayOutputStream baos){
    	ByteArrayOutputStream newBaos = new ByteArrayOutputStream();
    	boolean isSigned = false;
        try {
            KeyStore ks = KeyStore.getInstance("Windows-MY", "SunMSCAPI");
            ks.load(null, null);
            java.security.cert.Certificate[] chain = ks.getCertificateChain(pdfSignatureCertificateAlias);
            PrivateKey key = (PrivateKey) ks.getKey(pdfSignatureCertificateAlias, "".toCharArray());
            
            if(chain != null && key != null) {
            	boolean allowToAddSignature = true;
            	Date lastPdfCertExpiryAlert = (Date) servletContext.getAttribute("lastPdfCertExpiryAlert");
            	SimpleDateFormat utcDt = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy");
                X509Certificate certificate = (X509Certificate) ks.getCertificate(pdfSignatureCertificateAlias);
                Date certificateValidTo = certificate.getNotAfter();
                long daysDiff = Math.round((double) (utcDt.parse(certificateValidTo.toString()).getTime() - utcDt.parse(new Date().toString()).getTime()) / (24 * 60 * 60 * 1000));

                if(daysDiff <= 30) {
                	long hoursDiffFromLastAlert = (utcDt.parse(new Date().toString()).getTime() - utcDt.parse(lastPdfCertExpiryAlert.toString()).getTime()) / (60 * 60 * 1000);
                	if(daysDiff <= 1) {
                		allowToAddSignature = false;
                	}
                	if(hoursDiffFromLastAlert >= 24) {
						try {
							if(daysDiff > 0) {
								 sendMessageUtil.setEmailMessage("Dear user <br/> Pdf signature certificate : "+ pdfSignatureCertificateAlias + " is about to expire on " + utcDt.parse(certificateValidTo.toString()) +" ("+daysDiff+" days). <br/> kindly change certificate.");
								 sendMessageUtil.setEmailSub("Pdf signature certificate : "+ pdfSignatureCertificateAlias + " is about to expire in " + daysDiff + "days");
							} else {
								 sendMessageUtil.setEmailMessage("Dear user <br/> Pdf signature certificate : "+ pdfSignatureCertificateAlias + " has been expired on " + utcDt.parse(certificateValidTo.toString()) +". <br/> kindly change certificate.");
								 sendMessageUtil.setEmailSub("Pdf signature certificate : "+ pdfSignatureCertificateAlias + " has been expired");
							}
							sendMessageUtil.setEmailTo(notificationMailTo.split(","));
							sendMessageUtil.sendEmail();
							servletContext.setAttribute("lastPdfCertExpiryAlert", new Date());
						} catch(Exception e) {
							exceptionHandlerService.writeLog(e);
						}
                	}
                }
            	if(allowToAddSignature) {
	                PdfReader reader = new PdfReader(baos.toByteArray());
	                PdfReader.unethicalreading = true;
	                int signOnPage = reader.getNumberOfPages();
	                
	                float width = 200, height = 60;
	                com.itextpdf.text.Rectangle cropBox = reader.getCropBox(1);
	                com.itextpdf.text.Rectangle rectangle = new com.itextpdf.text.Rectangle(cropBox.getRight(width)-45, cropBox.getBottom()+20, cropBox.getRight()-20, cropBox.getBottom(height));
	               
	                PdfStamper stamper = PdfStamper.createSignature(reader, newBaos, '\0');
	                PdfSignatureAppearance appearance = stamper.getSignatureAppearance();
	                appearance.setVisibleSignature(rectangle, signOnPage, "SIGN");
	                appearance.setCertificate(chain[0]);
	                String name = null;
	                X500Name x500name = CertificateInfo.getSubjectFields((X509Certificate)appearance.getCertificate());
	                if (x500name != null) {
	                	name = x500name.getField("CN");
	                	if (name == null) {
	                		name = x500name.getField("E");
	                	}
	                }
	                if (name == null) {
	                    name = "";
	                }
	                SimpleDateFormat sd = new SimpleDateFormat("yyyy.MM.dd HH:mm:ss z");
	                sd.setTimeZone(TimeZone.getTimeZone("IST"));
	                appearance.setLayer2Text("Digitally signed by "+ name +"\nDate: "+sd.format(appearance.getSignDate().getTime()));
	                ExternalDigest digest = new BouncyCastleDigest();
	                ExternalSignature signature = new PrivateKeySignature(key, DigestAlgorithms.SHA1, ks.getProvider().getName());
	                MakeSignature.signDetached(appearance, digest, signature, chain, null, null, null, 0, CryptoStandard.CMS);
	                stamper.close();
	                reader.close();
	                isSigned = true;
                }
            }
        } catch(Exception e) {
        	exceptionHandlerService.writeLog(e);
        }
        return isSigned ? newBaos : baos;
    }    
}
