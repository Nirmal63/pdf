package com.etl.eproc.common.daointerface;

import java.util.List;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblEmarketUserRight;

public interface TblEmarketUserRightDao  {

    public void addTblEmarketUserRight(TblEmarketUserRight tblEmarketUserRight);

    public void deleteTblEmarketUserRight(TblEmarketUserRight tblEmarketUserRight);

    public void updateTblEmarketUserRight(TblEmarketUserRight tblEmarketUserRight);

    public List<TblEmarketUserRight> getAllTblEmarketUserRight();

    public List<TblEmarketUserRight> findTblEmarketUserRight(Object... values) throws Exception;

    public List<TblEmarketUserRight> findByCountTblEmarketUserRight(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEmarketUserRightCount();

    public void saveUpdateAllTblEmarketUserRight(List<TblEmarketUserRight> tblEmarketUserRights);
}