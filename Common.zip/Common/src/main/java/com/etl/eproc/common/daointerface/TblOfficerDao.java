package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblOfficer;
import java.util.List;

public interface TblOfficerDao  {

    public void addTblOfficer(TblOfficer tblOfficer);

    public void deleteTblOfficer(TblOfficer tblOfficer);

    public void updateTblOfficer(TblOfficer tblOfficer);

    public List<TblOfficer> getAllTblOfficer();

    public List<TblOfficer> findTblOfficer(Object... values) throws Exception;

    public List<TblOfficer> findByCountTblOfficer(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblOfficerCount();

    public void saveUpdateAllTblOfficer(List<TblOfficer> tblOfficers);
}