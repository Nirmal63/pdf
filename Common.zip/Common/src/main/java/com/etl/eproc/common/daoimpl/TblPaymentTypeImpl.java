package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblPaymentTypeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblPaymentType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblPaymentTypeImpl extends AbcAbstractClass<TblPaymentType> implements TblPaymentTypeDao {

    @Override
    public void addTblPaymentType(TblPaymentType tblPaymentType){
        super.addEntity(tblPaymentType);
    }

    @Override
    public void deleteTblPaymentType(TblPaymentType tblPaymentType) {
        super.deleteEntity(tblPaymentType);
    }

    @Override
    public void updateTblPaymentType(TblPaymentType tblPaymentType) {
        super.updateEntity(tblPaymentType);
    }

    @Override
    public List<TblPaymentType> getAllTblPaymentType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblPaymentType> findTblPaymentType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblPaymentTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblPaymentType> findByCountTblPaymentType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblPaymentType(List<TblPaymentType> tblPaymentTypes){
        super.updateAll(tblPaymentTypes);
    }
}
