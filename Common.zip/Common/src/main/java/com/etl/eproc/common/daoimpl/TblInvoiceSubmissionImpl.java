package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblInvoiceSubmission;
import com.etl.eproc.common.daointerface.TblInvoiceSubmissionDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblInvoiceSubmissionImpl extends AbcAbstractClass<TblInvoiceSubmission> implements TblInvoiceSubmissionDao {

    @Override
    public void addTblInvoiceSubmission(TblInvoiceSubmission tblInvoiceSubmission){
        super.addEntity(tblInvoiceSubmission);
    }

    @Override
    public void deleteTblInvoiceSubmission(TblInvoiceSubmission tblInvoiceSubmission) {
        super.deleteEntity(tblInvoiceSubmission);
    }

    @Override
    public void updateTblInvoiceSubmission(TblInvoiceSubmission tblInvoiceSubmission) {
        super.updateEntity(tblInvoiceSubmission);
    }

    @Override
    public List<TblInvoiceSubmission> getAllTblInvoiceSubmission() {
        return super.getAllEntity();
    }

    @Override
    public List<TblInvoiceSubmission> findTblInvoiceSubmission(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblInvoiceSubmissionCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblInvoiceSubmission> findByCountTblInvoiceSubmission(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblInvoiceSubmission(List<TblInvoiceSubmission> tblInvoiceSubmissions){
        super.updateAll(tblInvoiceSubmissions);
    }

	@Override
	public void saveOrUpdateTblInvoiceSubmission(TblInvoiceSubmission tblInvoiceSubmission) {
		super.saveOrUpdateEntity(tblInvoiceSubmission);
	}
}
