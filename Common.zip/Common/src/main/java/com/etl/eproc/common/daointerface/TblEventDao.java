package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblEvent;
import java.util.List;

public interface TblEventDao  {

    public void addTblEvent(TblEvent tblEvent);

    public void deleteTblEvent(TblEvent tblEvent);

    public void updateTblEvent(TblEvent tblEvent);

    public List<TblEvent> getAllTblEvent();

    public List<TblEvent> findTblEvent(Object... values) throws Exception;

    public List<TblEvent> findByCountTblEvent(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEventCount();

    public void saveUpdateAllTblEvent(List<TblEvent> tblEvents);
}