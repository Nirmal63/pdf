package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblExemptionCertDetail;
import java.util.List;

public interface TblExemptionCertDetailDao  {

    public void addTblExemptionCertDetail(TblExemptionCertDetail tblExemptionCertDetail);

    public void deleteTblExemptionCertDetail(TblExemptionCertDetail tblExemptionCertDetail);

    public void updateTblExemptionCertDetail(TblExemptionCertDetail tblExemptionCertDetail);

    public List<TblExemptionCertDetail> getAllTblExemptionCertDetail();

    public List<TblExemptionCertDetail> findTblExemptionCertDetail(Object... values) throws Exception;

    public List<TblExemptionCertDetail> findByCountTblExemptionCertDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblExemptionCertDetailCount();

    public void saveUpdateAllTblExemptionCertDetail(List<TblExemptionCertDetail> tblExemptionCertDetails);

	public void saveOrUpdateTblExemptionCertDetail(TblExemptionCertDetail tblExemptionCertDetail);
}