package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblUserFeedBack;
import com.etl.eproc.common.daointerface.TblUserFeedBackDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserFeedBackImpl extends AbcAbstractClass<TblUserFeedBack> implements TblUserFeedBackDao {

    @Override
    public void addTblUserFeedBack(TblUserFeedBack tblUserFeedBack){
        super.addEntity(tblUserFeedBack);
    }

    @Override
    public void deleteTblUserFeedBack(TblUserFeedBack tblUserFeedBack) {
        super.deleteEntity(tblUserFeedBack);
    }

    @Override
    public void updateTblUserFeedBack(TblUserFeedBack tblUserFeedBack) {
        super.updateEntity(tblUserFeedBack);
    }

    @Override
    public List<TblUserFeedBack> getAllTblUserFeedBack() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserFeedBack> findTblUserFeedBack(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserFeedBackCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserFeedBack> findByCountTblUserFeedBack(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserFeedBack(List<TblUserFeedBack> tblUserFeedBacks){
        super.updateAll(tblUserFeedBacks);
    }
}
