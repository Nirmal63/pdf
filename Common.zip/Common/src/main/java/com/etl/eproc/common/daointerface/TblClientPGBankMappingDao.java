package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientPGBankMapping;
import java.util.List;

public interface TblClientPGBankMappingDao  {

    public void addTblClientPGBankMapping(TblClientPGBankMapping tblClientPGBankMapping);

    public void deleteTblClientPGBankMapping(TblClientPGBankMapping tblClientPGBankMapping);

    public void updateTblClientPGBankMapping(TblClientPGBankMapping tblClientPGBankMapping);

    public List<TblClientPGBankMapping> getAllTblClientPGBankMapping();

    public List<TblClientPGBankMapping> findTblClientPGBankMapping(Object... values) throws Exception;

    public List<TblClientPGBankMapping> findByCountTblClientPGBankMapping(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientPGBankMappingCount();

    public void saveUpdateAllTblClientPGBankMapping(List<TblClientPGBankMapping> tblClientPGBankMappings);
}