/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;

/**
 *
 * @author rajnikant
 */

import com.etl.eproc.eauction.model.TblClientMailTemplate;
import java.util.List;

public interface TblClientMailTemplateDao  {

    public void addTblClientMailTemplate(TblClientMailTemplate tblClientMailTemplate);

    public void deleteTblClientMailTemplate(TblClientMailTemplate tblClientMailTemplate);

    public void updateTblClientMailTemplate(TblClientMailTemplate tblClientMailTemplate);

    public List<TblClientMailTemplate> getAllTblClientMailTemplate();

    public List<TblClientMailTemplate> findTblClientMailTemplate(Object... values) throws Exception;

    public List<TblClientMailTemplate> findByCountTblClientMailTemplate(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientMailTemplateCount();

    public void saveUpdateAllTblClientMailTemplate(List<TblClientMailTemplate> tblClientMailTemplates);
}