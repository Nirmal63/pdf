package com.etl.eproc.annuxure.model;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="tbl_ClmAnnexureType",schema ="appclient")
public class TblClmAnnexureType implements java.io.Serializable {
	
	private int clmAnnexureTypeId;
	private String annexureName;
	private int isActive;
	
	
	
	private Set<TblAnxType> tblAnnexureType = new HashSet<TblAnxType>();

	@OneToMany(cascade = CascadeType.ALL,  mappedBy = "typeOfAnnexure")
	public Set<TblAnxType> getTblAnnexureType() {
		return tblAnnexureType;
	}
	public void setTblAnnexureType(Set<TblAnxType> tblAnnexureType) {
		this.tblAnnexureType = tblAnnexureType;
	}
	
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getClmAnnexureTypeId() {
		return clmAnnexureTypeId;
	}
	
	public void setClmAnnexureTypeId(int clmAnnexureTypeId) {
		this.clmAnnexureTypeId = clmAnnexureTypeId;
	}
	
	
	public void setAnnexureName(String annexureName) {
		this.annexureName = annexureName;
	}
	public int getIsActive() {
		return isActive;
	}
	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}
	
	public String getAnnexureName() {
		return annexureName;
	}
	public TblClmAnnexureType() {
	
	}
	public TblClmAnnexureType(int annexureTypeId) {
		this.clmAnnexureTypeId = annexureTypeId;
	}
	
	
	
	
	
	

}
