package com.etl.eproc.common.daointerface;

import java.util.List;


import com.etl.eproc.common.model.TblMobileUserLogin;

/**
 * 
 * @author urja.r
 *
 */
public interface TblMobileUserLoginDao  {

    public void addTblMobileUserLogin(TblMobileUserLogin tblMobileUserLogin);

    public void deleteTblMobileUserLogin(TblMobileUserLogin tblMobileUserLogin);

    public void updateTblMobileUserLogin(TblMobileUserLogin tblMobileUserLogin);

    public List<TblMobileUserLogin> getAllTblMobileUserLogin();

    public List<TblMobileUserLogin> findTblMobileUserLogin(Object... values) throws Exception;

    public List<TblMobileUserLogin> findByCountTblMobileUserLogin(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMobileUserLoginCount();

    public void saveUpdateAllTblMobileUserLogin(List<TblMobileUserLogin> tblMobileUserLogins);
}