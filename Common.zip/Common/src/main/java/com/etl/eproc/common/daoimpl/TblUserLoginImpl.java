package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblUserLoginDao;
import com.etl.eproc.common.model.TblUserLogin;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserLoginImpl extends AbcAbstractClass<TblUserLogin> implements TblUserLoginDao {


    @Override
    public void addTblUserLogin(TblUserLogin tblUserLogin){
        super.addEntity(tblUserLogin);
    }

    @Override
    public void deleteTblUserLogin(TblUserLogin tblUserLogin) {
        super.deleteEntity(tblUserLogin);
    }

    @Override
    public void updateTblUserLogin(TblUserLogin tblUserLogin) {
        super.updateEntity(tblUserLogin);
    }

    @Override
    public List<TblUserLogin> getAllTblUserLogin() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserLogin> findTblUserLogin(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserLoginCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserLogin> findByCountTblUserLogin(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserLogin(List<TblUserLogin> tblUserLogins){
        super.updateAll(tblUserLogins);
    }

	@Override
	public void saveOrUpdateTblUserLogin(TblUserLogin tblUserLogin) {
		super.saveOrUpdateEntity(tblUserLogin);
		
	}
}
