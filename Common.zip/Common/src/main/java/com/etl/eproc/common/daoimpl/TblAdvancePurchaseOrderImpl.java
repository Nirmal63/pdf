package com.etl.eproc.common.daoimpl;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblAdvancePurchaseOrderDao;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblAdvancePurchaseOrder;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblAdvancePurchaseOrderImpl extends AbcAbstractClass<TblAdvancePurchaseOrder> implements TblAdvancePurchaseOrderDao {

    @Override
    public void addTblAdvancePurchaseOrder(TblAdvancePurchaseOrder tblAdvancePurchaseOrder){
        super.addEntity(tblAdvancePurchaseOrder);
    }

    @Override
    public void deleteTblAdvancePurchaseOrder(TblAdvancePurchaseOrder tblAdvancePurchaseOrder) {
        super.deleteEntity(tblAdvancePurchaseOrder);
    }

    @Override
    public void updateTblAdvancePurchaseOrder(TblAdvancePurchaseOrder tblAdvancePurchaseOrder) {
        super.updateEntity(tblAdvancePurchaseOrder);
    }

    @Override
    public List<TblAdvancePurchaseOrder> getAllTblAdvancePurchaseOrder() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAdvancePurchaseOrder> findTblAdvancePurchaseOrder(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAdvancePurchaseOrderCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAdvancePurchaseOrder> findByCountTblAdvancePurchaseOrder(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAdvancePurchaseOrder(List<TblAdvancePurchaseOrder> tblAdvancePurchaseOrders){
        super.updateAll(tblAdvancePurchaseOrders);
    }

	@Override
	public void saveOrUpdateTblAdvancePurchaseOrder(TblAdvancePurchaseOrder tblAdvancePurchaseOrder) {
		super.saveOrUpdateEntity(tblAdvancePurchaseOrder);
	}
}
