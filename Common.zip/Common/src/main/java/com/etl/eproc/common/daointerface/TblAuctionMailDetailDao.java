package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblAuctionMailDetail;

public interface TblAuctionMailDetailDao  {

    public void addTblAuctionMailDetail(TblAuctionMailDetail tblAuctionMailDetail);

    public void deleteTblAuctionMailDetail(TblAuctionMailDetail tblAuctionMailDetail);

    public void updateTblAuctionMailDetail(TblAuctionMailDetail tblAuctionMailDetail);

    public List<TblAuctionMailDetail> getAllTblAuctionMailDetail();

    public List<TblAuctionMailDetail> findTblAuctionMailDetail(Object... values) throws Exception;

    public List<TblAuctionMailDetail> findByCountTblAuctionMailDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAuctionMailDetailCount();

    public void saveUpdateAllTblAuctionMailDetail(List<TblAuctionMailDetail> tblAuctionMailDetails);
}