package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblRegistrationWorkflowDao;
import com.etl.eproc.common.model.TblRegistrationWorkflow;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblRegistrationWorkflowImpl extends AbcAbstractClass<TblRegistrationWorkflow> implements TblRegistrationWorkflowDao {

    @Override
    public void addTblRegistrationWorkflow(TblRegistrationWorkflow tblRegistrationWorkflow){
        super.addEntity(tblRegistrationWorkflow);
    }

    @Override
    public void deleteTblRegistrationWorkflow(TblRegistrationWorkflow tblRegistrationWorkflow) {
        super.deleteEntity(tblRegistrationWorkflow);
    }

    @Override
    public void updateTblRegistrationWorkflow(TblRegistrationWorkflow tblRegistrationWorkflow) {
        super.updateEntity(tblRegistrationWorkflow);
    }

    @Override
    public List<TblRegistrationWorkflow> getAllTblRegistrationWorkflow() {
        return super.getAllEntity();
    }

    @Override
    public List<TblRegistrationWorkflow> findTblRegistrationWorkflow(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblRegistrationWorkflowCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblRegistrationWorkflow> findByCountTblRegistrationWorkflow(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblRegistrationWorkflow(List<TblRegistrationWorkflow> tblRegistrationWorkflows){
        super.updateAll(tblRegistrationWorkflows);
    }
}