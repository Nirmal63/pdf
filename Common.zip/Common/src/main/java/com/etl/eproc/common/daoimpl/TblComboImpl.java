package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblComboDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblCombo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblComboImpl extends AbcAbstractClass<TblCombo> implements TblComboDao {

    @Override
    public void addTblCombo(TblCombo tblCombo){
        super.addEntity(tblCombo);
    }

    @Override
    public void deleteTblCombo(TblCombo tblCombo) {
        super.deleteEntity(tblCombo);
    }

    @Override
    public void updateTblCombo(TblCombo tblCombo) {
        super.updateEntity(tblCombo);
    }

    @Override
    public List<TblCombo> getAllTblCombo() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCombo> findTblCombo(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblComboCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCombo> findByCountTblCombo(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCombo(List<TblCombo> tblCombos){
        super.updateAll(tblCombos);
    }
}
