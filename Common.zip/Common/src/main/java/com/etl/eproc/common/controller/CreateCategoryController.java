package com.etl.eproc.common.controller;

import java.math.BigDecimal;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.model.TblCategoryStatistic;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblProductCategory;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ManageCategoryService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.SessionBean;

@Controller
@RequestMapping(value = "/common")
public class CreateCategoryController {

    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private ManageCategoryService manageCategoryService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private AbcUtility abcUtility;
    /*@Value("#{projectProperties['errormsg.operation.fail']}")
     private String errorMsg;*/
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Value("#{linkProperties['manage_catagory_create_categoty']?:39}")
    private int createCategoryLinkId;
    @Value("#{linkProperties['manage_catagory_edit_category']?:40}")
    private int editCategoryLinkId;
    @Value("#{linkProperties['report_admin_manage_category']?:6}")
    private int manageCategoryReportId;
    @Value("#{adminAuditTrailProperties['getCreateCatPage']}")
    private String getCreateCatPage;
    @Value("#{adminAuditTrailProperties['getManageCategoryPage']}")
    private String getManageCategoryPage;
    @Value("#{adminAuditTrailProperties['postAddCategory']}")
    private String postAddCategory;
    @Value("#{adminAuditTrailProperties['postAddCategoryFailed']}")
    private String postAddCategoryFailed;
    @Value("#{adminAuditTrailProperties['getEditCategory']}")
    private String getEditCategory;
    @Value("#{adminAuditTrailProperties['postUpdateCategory']}")
    private String postUpdateCategory;
    @Value("#{adminAuditTrailProperties['postUpdateCategoryFailed']}")
    private String postUpdateCategoryFailed;
    
    /**
     * to dispaly create category JSP Page
     */
    @RequestMapping(value = "/admin/createcategory/{enc}", method = RequestMethod.GET)
    public String createCategory(HttpServletRequest request) {
        String retVal = null;
        try {
            request.setAttribute("clientId", abcUtility.getSessionClientId(request));
            retVal = "common/admin/CreateCategory";
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createCategoryLinkId, getCreateCatPage, 0, 0);
        }
        return retVal;
    }

    /**
     * to dispaly manage category JSP Page
     */
    @RequestMapping(value = "/admin/managecategory/{enc}", method = RequestMethod.GET)
    public String manageCategory(ModelMap modelMap, HttpServletRequest request) {
        try {
            //int reportId = 6;
            modelMap.addAttribute("reportId", manageCategoryReportId);
            reportGeneratorService.getReportConfigDetails(manageCategoryReportId, modelMap);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, getManageCategoryPage, 0, 0);
        }
        return "common/admin/ManageCategory";
    }

    /**
     * to add category
     */
    @RequestMapping(value = "/admin/addcategory", method = RequestMethod.POST)
    public String addCategory(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        int clientId = 0;
        String categoryName = null;
        int parentCatId = 0;
        String retVal = null;
        TblProductCategory tblProductCategory = null;
        try {
            //HttpSession session = request.getSession();
            //SessionBean sessionBean = (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
            clientId = StringUtils.hasLength(request.getParameter("hdClientId")) ? Integer.parseInt(request.getParameter("hdClientId")) : 0;
            parentCatId = StringUtils.hasLength(request.getParameter("txtCategory")) ? Integer.parseInt(request.getParameter("txtCategory")) : 0;
            categoryName = StringUtils.hasLength(request.getParameter("txtaCategoryName")) ? request.getParameter("txtaCategoryName") : null;
            if (categoryName == null) {
                success = false;
                retVal = "redirect:/common/admin/createcategory" + encryptDecryptUtils.generateRedirect("common/admin/createcategory", request);
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
            } else {
                if (commonService.checkUniqueCategoryName(clientId, categoryName, 0)) {
                    success = false;
                    retVal = "redirect:/common/admin/createcategory" + encryptDecryptUtils.generateRedirect("common/admin/createcategory", request);
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_catalreadyexists");
                } else {
                    tblProductCategory = new TblProductCategory();
                    tblProductCategory.setCategoryName(categoryName);
                    tblProductCategory.setParentCategoryId(parentCatId);
                    tblProductCategory.setCreatedBy(abcUtility.getSessionUserId(request));
                    tblProductCategory.setIsActive(1);
                    tblProductCategory.setTblClient(new TblClient(clientId));
                    success = manageCategoryService.addCategory(tblProductCategory);
                    if (success) {
                        retVal = "redirect:/common/admin/managecategory" + encryptDecryptUtils.generateRedirect("common/admin/managecategory", request);
                        redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_createcat");
                    } else {
                        retVal = "redirect:/common/admin/createcategory" + encryptDecryptUtils.generateRedirect("common/admin/createcategory", request);
                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                    }
                }
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createCategoryLinkId, success ? postAddCategory : postAddCategoryFailed, 0, tblProductCategory != null ? tblProductCategory.getCategoryId() : 0);
        }
        return retVal;
    }

    /**
     * to dispaly create category JSP Page at edit time
     */
    @RequestMapping(value = "/admin/editcategory/{categoryId}/{enc}", method = RequestMethod.GET)
    public String getEditCategory(@PathVariable("categoryId") int categoryId, ModelMap modelMap, HttpServletRequest request) {
        try {
            modelMap.addAttribute("clientId", abcUtility.getSessionClientId(request));
            modelMap.addAttribute("tblProductCategory", manageCategoryService.getProductCategoryById(categoryId));
            modelMap.addAttribute("oprType", "edit");
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editCategoryLinkId, getEditCategory, 0, categoryId);
        }
        return "common/admin/CreateCategory";
    }

    /**
     * to update category
     */
    @RequestMapping(value = "/admin/updatecategory", method = RequestMethod.POST)
    public String updateCategory(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        int clientId = 0;
        String categoryName = null;
        int parentCatId = 0;
        int categoryId = 0;
        String retVal = null;
        TblProductCategory tblProductCategory = null;
        try {
            //HttpSession session = request.getSession();
            //SessionBean sessionBean = (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
            clientId = StringUtils.hasLength(request.getParameter("hdClientId"))  ? Integer.parseInt(request.getParameter("hdClientId")) : 0;
            parentCatId = StringUtils.hasLength(request.getParameter("txtCategory")) ? Integer.parseInt(request.getParameter("txtCategory")) : 0;
            categoryId = StringUtils.hasLength(request.getParameter("hdCategoryId")) ? Integer.parseInt(request.getParameter("hdCategoryId")) : 0;
            categoryName = StringUtils.hasLength(request.getParameter("txtaCategoryName")) ? request.getParameter("txtaCategoryName") : null;
            if (categoryName == null) {
                success = false;
                retVal = "redirect:/common/admin/editcategory/" + clientId + "/" + categoryId + encryptDecryptUtils.generateRedirect("common/admin/editcategory/" + clientId + "/" + categoryId, request);
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
            } else {
                if (commonService.checkUniqueCategoryName(clientId, categoryName, categoryId)) {
                    success = false;
                    retVal = "redirect:/common/admin/editcategory/" + clientId + "/" + categoryId + encryptDecryptUtils.generateRedirect("common/admin/editcategory/" + clientId + "/" + categoryId, request);
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_catalreadyexists");
                } else {
                    tblProductCategory = new TblProductCategory();
                    tblProductCategory.setCategoryId(categoryId);
                    tblProductCategory.setParentCategoryId(parentCatId);
                    tblProductCategory.setCategoryName(categoryName);
                    tblProductCategory.setCreatedBy(abcUtility.getSessionUserId(request));
                    tblProductCategory.setIsActive(1);
                    tblProductCategory.setTblClient(new TblClient(clientId));
                    success = manageCategoryService.updateCategory(tblProductCategory);
                    if (success) {
                        retVal = "redirect:/common/admin/managecategory" + encryptDecryptUtils.generateRedirect("common/admin/managecategory", request);
                        redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_updatecat");
                    } else {
                        retVal = "redirect:/common/admin/editcategory/" + clientId + "/" + categoryId + encryptDecryptUtils.generateRedirect("common/admin/editcategory/" + clientId + "/" + categoryId, request);
                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                    }
                }
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), editCategoryLinkId, success ? postUpdateCategory :postUpdateCategoryFailed, 0, categoryId);
        }
        return retVal;
    }
    
    
    
    /**
     * to dispaly create category JSP Page
     */
    @RequestMapping(value = "/admin/createcategoryattributes/{categoryId}/{enc}", method = RequestMethod.GET)
    public String createCategoryAttributes(HttpServletRequest request,@PathVariable("categoryId")int categoryId,ModelMap modelmap) {
        String retVal = null;
        TblCategoryStatistic tblCategoryStatistic = null;
        try {
        	tblCategoryStatistic = manageCategoryService.getCategoryStatistic(categoryId);
            if(tblCategoryStatistic !=null)
            {
            	modelmap.put("optType", "edit");
            	modelmap.put("tblCategoryStatistic", tblCategoryStatistic);
            }	
            retVal = "common/admin/AddCategoryAttributes";
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createCategoryLinkId, getCreateCatPage, 0, 0);
        }
        return retVal;
    }
    
    
    /**
     * add/edit category statistics
     * @param redirectAttributes
     * @param request
     * @return
     */
    @RequestMapping(value = "/admin/addcategoryattribute", method = RequestMethod.POST)
    public String addCategoryAttribute(RedirectAttributes redirectAttributes, HttpServletRequest request) {
        boolean success = false;
        String successMsg = "";
        int categoryId = 0;
        String retVal = null;
        TblProductCategory tblProductCategory = null;
        int noOfevents = 0 ;
        String procurementValue;
        String saving;
        int buyerCount = 0;
        int optType = 0;
        try {
        	
        	Date currentTime = commonService.getServerDateTime();
            HttpSession session = request.getSession();
            SessionBean sessionBean = (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
            categoryId = StringUtils.hasLength(request.getParameter("hdCategoryId")) ? Integer.parseInt(request.getParameter("hdCategoryId")) : 0;
            noOfevents = StringUtils.hasLength(request.getParameter("txtEventCount")) ? Integer.parseInt(request.getParameter("txtEventCount")) : 0;
            procurementValue = StringUtils.hasLength(request.getParameter("txtProcurementValue")) ? request.getParameter("txtProcurementValue") : "";
            saving = StringUtils.hasLength(request.getParameter("txtSaving")) ? request.getParameter("txtSaving"): "";
            buyerCount = StringUtils.hasLength(request.getParameter("txtBuyerCount")) ? Integer.parseInt(request.getParameter("txtBuyerCount")) : 0;
            optType = StringUtils.hasLength(request.getParameter("hdOptType")) ? Integer.parseInt(request.getParameter("hdOptType")) : 0;
            
            TblCategoryStatistic tblCategoryStatistic = new TblCategoryStatistic();
            tblCategoryStatistic.setBuyerCount(buyerCount);
            tblCategoryStatistic.setCategoryId(categoryId);
            tblCategoryStatistic.setProcurementValue(new BigDecimal(procurementValue));
            tblCategoryStatistic.setEventCount(noOfevents);
            tblCategoryStatistic.setSaving(new BigDecimal(saving));
            tblCategoryStatistic.setCreatedBy(sessionBean.getUserDetailId());
            tblCategoryStatistic.setCreatedOn(currentTime);
            tblCategoryStatistic.setUpdatedBy(sessionBean.getUserDetailId());
            tblCategoryStatistic.setUpdateOn(currentTime);
            
			if (optType == 1) {
            	success = manageCategoryService.addCategoryStatistic(tblCategoryStatistic);
            	successMsg = "redirect_success_createcatattr";
            }else if (optType==2) {
            	success = manageCategoryService.updateCategoryStatistic(tblCategoryStatistic);
            	successMsg = "redirect_success_editcatattr";
			}
			
            if (success) {
                retVal = "redirect:/common/admin/managecategory" + encryptDecryptUtils.generateRedirect("common/admin/managecategory", request);
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), successMsg);
            } else {
                retVal = "redirect:/common/admin/managecategory" + encryptDecryptUtils.generateRedirect("common/admin/managecategory", request);
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createCategoryLinkId, success ? postAddCategory : postAddCategoryFailed, 0, tblProductCategory != null ? tblProductCategory.getCategoryId() : 0);
        }
        return retVal;
    }

    
    
    
    
}
