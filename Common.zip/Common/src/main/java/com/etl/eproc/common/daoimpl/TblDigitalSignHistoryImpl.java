package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblDigitalSignHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblDigitalSignHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDigitalSignHistoryImpl extends AbcAbstractClass<TblDigitalSignHistory> implements TblDigitalSignHistoryDao {

    @Override
    public void addTblDigitalSignHistory(TblDigitalSignHistory tblDigitalSignHistory){
        super.addEntity(tblDigitalSignHistory);
    }

    @Override
    public void deleteTblDigitalSignHistory(TblDigitalSignHistory tblDigitalSignHistory) {
        super.deleteEntity(tblDigitalSignHistory);
    }

    @Override
    public void updateTblDigitalSignHistory(TblDigitalSignHistory tblDigitalSignHistory) {
        super.updateEntity(tblDigitalSignHistory);
    }

    @Override
    public List<TblDigitalSignHistory> getAllTblDigitalSignHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDigitalSignHistory> findTblDigitalSignHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDigitalSignHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDigitalSignHistory> findByCountTblDigitalSignHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDigitalSignHistory(List<TblDigitalSignHistory> tblDigitalSignHistorys){
        super.updateAll(tblDigitalSignHistorys);
    }
}
