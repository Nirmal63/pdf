/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblFormRuleDetailDao;
import com.etl.eproc.common.model.TblFormRuleDetail;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author taher.tinwala
 */
@Repository @Transactional    /*StackUpdate*/
public class TblFormRuleDetailImpl extends AbcAbstractClass<TblFormRuleDetail> implements TblFormRuleDetailDao {

    @Override
    public void addTblFormRuleDetail(TblFormRuleDetail tblFormRuleDetail){
        super.addEntity(tblFormRuleDetail);
    }

    @Override
    public void deleteTblFormRuleDetail(TblFormRuleDetail tblFormRuleDetail) {
        super.deleteEntity(tblFormRuleDetail);
    }

    @Override
    public void updateTblFormRuleDetail(TblFormRuleDetail tblFormRuleDetail) {
        super.updateEntity(tblFormRuleDetail);
    }

    @Override
    public List<TblFormRuleDetail> getAllTblFormRuleDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFormRuleDetail> findTblFormRuleDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFormRuleDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFormRuleDetail> findByCountTblFormRuleDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFormRuleDetail(List<TblFormRuleDetail> tblFormRuleDetails){
        super.updateAll(tblFormRuleDetails);
    }
}
