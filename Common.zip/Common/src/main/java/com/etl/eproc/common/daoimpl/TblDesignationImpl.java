package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblDesignationDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblDesignation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDesignationImpl extends AbcAbstractClass<TblDesignation> implements TblDesignationDao {

    @Override
    public void addTblDesignation(TblDesignation tblDesignation){
        super.addEntity(tblDesignation);
    }

    @Override
    public void deleteTblDesignation(TblDesignation tblDesignation) {
        super.deleteEntity(tblDesignation);
    }

    @Override
    public void updateTblDesignation(TblDesignation tblDesignation) {
        super.updateEntity(tblDesignation);
    }

    @Override
    public List<TblDesignation> getAllTblDesignation() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDesignation> findTblDesignation(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDesignationCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDesignation> findByCountTblDesignation(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDesignation(List<TblDesignation> tblDesignations){
        super.updateAll(tblDesignations);
    }
}
