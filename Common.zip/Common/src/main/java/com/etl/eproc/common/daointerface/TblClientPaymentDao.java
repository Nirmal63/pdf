package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientPayment;
import java.util.List;

public interface TblClientPaymentDao  {

    public void addTblClientPayment(TblClientPayment tblClientPayment);

    public void deleteTblClientPayment(TblClientPayment tblClientPayment);

    public void updateTblClientPayment(TblClientPayment tblClientPayment);

    public List<TblClientPayment> getAllTblClientPayment();

    public List<TblClientPayment> findTblClientPayment(Object... values) throws Exception;

    public List<TblClientPayment> findByCountTblClientPayment(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientPaymentCount();

    public void saveUpdateAllTblClientPayment(List<TblClientPayment> tblClientPayments);
}