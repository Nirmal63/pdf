package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMasterBid;
import java.util.List;

public interface TblMasterBidDao  {

    public void addTblMasterBid(TblMasterBid tblMasterBid);

    public void deleteTblMasterBid(TblMasterBid tblMasterBid);

    public void updateTblMasterBid(TblMasterBid tblMasterBid);

    public List<TblMasterBid> getAllTblMasterBid();

    public List<TblMasterBid> findTblMasterBid(Object... values) throws Exception;

    public List<TblMasterBid> findByCountTblMasterBid(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMasterBidCount();

    public void saveUpdateAllTblMasterBid(List<TblMasterBid> tblMasterBids);
}