/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

/**
 *
 * @author darshan
 */
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblAnswerDao;
import com.etl.eproc.common.model.TblAnswer;

@Repository @Transactional    /*StackUpdate*/
public class TblAnswerImpl extends AbcAbstractClass<TblAnswer> implements TblAnswerDao {

    @Override
    public void addTblAnswer(TblAnswer tblAnswer) {
	super.addEntity(tblAnswer);
    }

    @Override
    public void deleteTblAnswer(TblAnswer tblAnswer) {
	super.deleteEntity(tblAnswer);
    }

    @Override
    public void updateTblAnswer(TblAnswer tblAnswer) {
	super.updateEntity(tblAnswer);
    }

    @Override
    public List<TblAnswer> getAllTblAnswer() {
	return super.getAllEntity();
    }

    @Override
    public List<TblAnswer> findTblAnswer(Object... values) throws Exception {
	return super.findEntity(values);
    }

    @Override
    public long getTblAnswerCount() {
	return super.getEntityCount();
    }

    @Override
    public List<TblAnswer> findByCountTblAnswer(int firstResult, int maxResult, Object... values) throws Exception {
	return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAnswer(List<TblAnswer> tblAnswers) {
	super.updateAll(tblAnswers);
    }

	@Override
	public void saveOrUpdateTblAnswer(TblAnswer tblanswer) {
		super.saveOrUpdateEntity(tblanswer);
	}
}