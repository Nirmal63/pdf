package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblOnlineAdvancePurchaseOrder;
import com.etl.eproc.common.daointerface.TblOnlineAdvancePurchaseOrderDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblOnlineAdvancePurchaseOrderImpl extends AbcAbstractClass<TblOnlineAdvancePurchaseOrder> implements TblOnlineAdvancePurchaseOrderDao {

    @Override
    public void addTblOnlineAdvancePurchaseOrder(TblOnlineAdvancePurchaseOrder tblOnlineAdvancePurchaseOrder){
        super.addEntity(tblOnlineAdvancePurchaseOrder);
    }

    @Override
    public void deleteTblOnlineAdvancePurchaseOrder(TblOnlineAdvancePurchaseOrder tblOnlineAdvancePurchaseOrder) {
        super.deleteEntity(tblOnlineAdvancePurchaseOrder);
    }

    @Override
    public void updateTblOnlineAdvancePurchaseOrder(TblOnlineAdvancePurchaseOrder tblOnlineAdvancePurchaseOrder) {
        super.updateEntity(tblOnlineAdvancePurchaseOrder);
    }

    @Override
    public List<TblOnlineAdvancePurchaseOrder> getAllTblOnlineAdvancePurchaseOrder() {
        return super.getAllEntity();
    }

    @Override
    public List<TblOnlineAdvancePurchaseOrder> findTblOnlineAdvancePurchaseOrder(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblOnlineAdvancePurchaseOrderCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblOnlineAdvancePurchaseOrder> findByCountTblOnlineAdvancePurchaseOrder(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblOnlineAdvancePurchaseOrder(List<TblOnlineAdvancePurchaseOrder> tblOnlineAdvancePurchaseOrders){
        super.updateAll(tblOnlineAdvancePurchaseOrders);
    }

	@Override
	public void saveOrUpdateTblOnlineAdvancePurchaseOrder(TblOnlineAdvancePurchaseOrder onlineAPO) {
		super.saveOrUpdateEntity(onlineAPO);
	}
}
