/**
 * 
 */
package com.etl.eproc.common.daoimpl;

/**
 * @author janak
 *
 */
import com.etl.eproc.common.model.TblRegisteredIn;
import com.etl.eproc.common.daointerface.TblRegisteredInDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblRegisteredInImpl extends AbcAbstractClass<TblRegisteredIn> implements TblRegisteredInDao {

    @Override
    public void addTblRegisteredIn(TblRegisteredIn tblRegisteredIn){
        super.addEntity(tblRegisteredIn);
    }

    @Override
    public void deleteTblRegisteredIn(TblRegisteredIn tblRegisteredIn) {
        super.deleteEntity(tblRegisteredIn);
    }

    @Override
    public void updateTblRegisteredIn(TblRegisteredIn tblRegisteredIn) {
        super.updateEntity(tblRegisteredIn);
    }

    @Override
    public List<TblRegisteredIn> getAllTblRegisteredIn() {
        return super.getAllEntity();
    }

    @Override
    public List<TblRegisteredIn> findTblRegisteredIn(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblRegisteredInCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblRegisteredIn> findByCountTblRegisteredIn(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblRegisteredIn(List<TblRegisteredIn> tblRegisteredIns){
        super.updateAll(tblRegisteredIns);
    }
}
