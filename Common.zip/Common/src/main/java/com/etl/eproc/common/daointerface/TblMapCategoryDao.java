package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMapCategory;
import java.util.List;

public interface TblMapCategoryDao  {

    public void addTblMapCategory(TblMapCategory tblMapCategory);

    public void deleteTblMapCategory(TblMapCategory tblMapCategory);

    public void updateTblMapCategory(TblMapCategory tblMapCategory);

    public List<TblMapCategory> getAllTblMapCategory();

    public List<TblMapCategory> findTblMapCategory(Object... values) throws Exception;

    public List<TblMapCategory> findByCountTblMapCategory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMapCategoryCount();

    public void saveUpdateAllTblMapCategory(List<TblMapCategory> tblMapCategorys);
}
