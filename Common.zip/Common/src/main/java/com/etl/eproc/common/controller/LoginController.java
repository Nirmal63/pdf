/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.net.URI;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.aspectj.weaver.patterns.ISignaturePattern;
import org.bouncycastle.asn1.ocsp.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.databean.CertiDataBean;
import com.etl.eproc.common.databean.ChangePassDataBean;
import com.etl.eproc.common.databean.ForgotPassDataBean;
import com.etl.eproc.common.model.TblAuditTrail;
import com.etl.eproc.common.model.TblCertUnMapHistory;
import com.etl.eproc.common.model.TblCertificate;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblContentManagement;
import com.etl.eproc.common.model.TblContentMobile;
import com.etl.eproc.common.model.TblLoginHistory;
import com.etl.eproc.common.model.TblPasswordHistory;
import com.etl.eproc.common.model.TblReportSearchColumnDetail;
import com.etl.eproc.common.model.TblSession;
import com.etl.eproc.common.model.TblTrackLogin;
import com.etl.eproc.common.model.TblUserCertificate;
import com.etl.eproc.common.model.TblUserHistory;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.DrtService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.MailBoxService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.ManageContentService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.services.WSCheckAvailService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CertificateException;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SHA1HashEncryption;
import com.etl.eproc.common.utility.SHA256HashEncryption;
import com.etl.eproc.common.utility.SMSContentUtillity;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.common.utility.SignerVerify;
import com.etl.eproc.common.utility.WSCheckAvail;
import com.etl.eproc.common.webservice.DataObject;
import com.etl.eproc.vendor.services.VendorEnlistmentService;
import com.etl.eproc.common.utility.SMSContentUtillity;
import com.etl.eproc.factory.AbcCaptchaFactory;
/**
 *
 * @author taher.tinwala
 */
@Controller
public class LoginController {

    @Autowired
    private CommonService commonService;
    @Autowired
    private LoginService loginService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private WSCheckAvailService wSCheckAvailService;
    /*@Autowired
    private AbcEncryptionUtil abcEncryptionUtil;*/
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private SignerVerify signerVerify;
    @Autowired
    private ModelToSelectItem modelToSelectItem;
    @Autowired
    private CommonValidators commonValidators;
    @Autowired
    private ClientService clientService;
    @Autowired
    private FileUploadService fileUploadService;
    @Autowired
    private DrtService drtService;
    @Autowired
    private ManageBidderService manageBidderService;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private ManageContentService manageContentService;
    @Autowired
    private VendorEnlistmentService vendorEnlistmentService;
    @Autowired
    private SHA256HashEncryption sha256HashEncryption;
    @Autowired
    private MailBoxService mailBoxService; 
    @Autowired
    private SHA1HashEncryption sha1HashEncryption;
    @Autowired
    private SMSContentUtillity smsContentUtillity;

    @Value("#{projectProperties['password.validity']?:30}")
    private int passValidity;
    @Value("#{projectProperties['login.failedattempt']?:3}")
    private int failedAttempt;
    @Value("#{projectProperties['password.maxrepeat']?:5}")
    private int passMaxRepeat;
    private static final String SESSIONOBJECT = "sessionObject";
    private static final String TEMPSESSIONOBJECT = "tempSessionObject";
    @Autowired
    private DepartmentUserService departmentUserService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private MessageSource messageSource;
    @Value("#{projectProperties['userhistory.actiontype.unlock']?:8}")
    private int actionTypeUnlock;
//    @Value("#{projectProperties['auction_Admin_userId']}")
//    private int superAdmin;
    private static final String FORGOTPWDURL = "redirect:/forgotpassword";
    @Value("#{linkProperties['manage_department_user_change_password']?:73}")
    private int deptUserChnPwdLinkId;
    @Value("#{linkProperties['manage_bidder_change_password']?:75}")
    private int bidderChnPwdLinkId;
    @Value("#{linkProperties['manage_bidder_forgot_password']?:76}")
    private int bidderFrgtPwdLinkId;
    @Value("#{linkProperties['manage_bidder_unlock_mail']?:77}")
    private int bidderUnlockMailLinkId;
    @Value("#{linkProperties['report_home_auction_listing']?:17}")
    private int homeAuctionListingReportId;
    @Value("#{linkProperties['report_home_sector_auction_listing']?:82}")
    private int homeSectorAuctionListingReportId;
    
    @Value("#{linkProperties['report_home_property_auction_listing']?:113}")
    private int propertySectorHomeAuctionListingReportId;
    
    @Value("#{linkProperties['report_advertise_listing']?:114}")
    private int advertiseReportId;
    
    @Value("#{linkProperties['report_home_tender_listing']?:33}")
    private int homeTenderListingReportId;
    @Value("#{linkProperties['other_login']?:150}")
    private int loginLink;
    @Value("#{linkProperties['other_map_certificate_on_login']?:151}")
    private int certiMapLink;
    @Value("#{linkProperties['other_logout']?:152}")
    private int logoutLink;
    @Value("#{linkProperties['manage_banner_create_banner']?:591}")
    private int createBannerLink;
    @Value("#{projectProperties['pki_required_abcuser']}")
    private boolean pkiReqForAbcUser;
    @Value("#{adminAuditTrailProperties['submitLogin']}")
    private String submitLoginAudit;
//    @Value("#{adminAuditTrailProperties['submitLoginFail']}")
//    private String submitLoginFailAudit;
    @Value("#{adminAuditTrailProperties['showCerti']}")
    private String showCertiAudit;
    @Value("#{adminAuditTrailProperties['certiLogin']}")
    private String certiLoginAudit;
    @Value("#{adminAuditTrailProperties['certiLoginFail']}")
    private String certiLoginFailAudit;
    @Value("#{adminAuditTrailProperties['logout']}")
    private String logoutAudit;
    @Value("#{adminAuditTrailProperties['logoutFail']}")
    private String logoutFailAudit;
    @Value("#{adminAuditTrailProperties['forgotPassword']}")
    private String forgotPasswordAudit;
    @Value("#{adminAuditTrailProperties['submitForgotPassword']}")
    private String submitForgotPasswordAudit;
    //CR: 20457	
    @Value("#{adminAuditTrailProperties['sendResetPasswordLinkAudit']}")
    private String sendResetPasswordLinkAudit;
    @Value("#{adminAuditTrailProperties['callChangepasswordBeforeLogin']}")
    private String callChangepasswordBeforeLogin;
    @Value("#{adminAuditTrailProperties['callSubmitChangepasswordBeforeLogin']}")
    private String callSubmitChangepasswordBeforeLogin;
    @Value("#{adminAuditTrailProperties['changePasswordOnLogin']}")
    private String changePasswordOnLoginAudit;
    @Value("#{adminAuditTrailProperties['changePassword']}")
    private String changePasswordAudit;
    @Value("#{adminAuditTrailProperties['submitChangePassword']}")
    private String submitChangePasswordAudit;
    @Value("#{adminAuditTrailProperties['submitChangePasswordOnLogin']}")
    private String submitChangePasswordOnLoginAudit;
    @Value("#{adminAuditTrailProperties['unLockUserFromMail']}")
    private String unLockUserFromMailAudit;
    @Value("#{adminAuditTrailProperties['changePasswordExpired']}")
    private String changePasswordExpiredAudit;
    @Value("#{adminAuditTrailProperties['submitChangePasswordExpired']}")
    private String submitChangePasswordExpiredAudit;
    @Value("#{linkProperties['report_home_DRT_auction_listing']?:43}")
    private int homeDRTAuctionListingReportId;
    @Value("#{linkProperties['report_home_DRT_rfq_listing']?:80}")
    private int homeDRTRfqListingReportId;
    @Value("#{adminAuditTrailProperties['failedpasswordchange']}")
    private String failedPasswordChange;
    @Value("#{adminAuditTrailProperties['ssoServNotAvail']}")
    private String ssoServNotAvail;    
    @Value("#{linkProperties['manage_download_document_upload']?:737}")
	private int manageDownloadDocumentUpload; 
    @Value("#{auclinkProperties['manage_auction_attribute_selection_add']?:766}")
    private int aucAttrSelLinkId;
    @Value("#{linkProperties['mail_reset_password_link']?:180}")
    private int mailResetPasswordLink;
    @Value("#{linkProperties['link_statics_report_home_page']?:88}")
    private int linkStaticsReportHomePage;
//    @Value("#{adminAuditTrailProperties['certiLoginBidder']}")
//    private String certiLoginBidderAudit;
//    @Value("#{adminAuditTrailProperties['certiLoginBuyer']}")
//    private String certiLoginBuyerAudit;
    //CR: 25825
    @Value("#{projectProperties['rci_client_ids']}")
    private String rciClientIds;
    @Value("#{projectProperties['gsl_client']}")
    private String gslClientIds;
    @Value("#{projectProperties['property_sector']}")
    private int propertySectorId;
    @Value("#{projectProperties['drt_sector']}")
    private int drtSectorId;
    @Value("#{projectProperties['bank_sector']}")
    private int bankSectorId;
    @Value("#{projectProperties['GMRTemplateId']}")
    private String GMRTemplateId;
    Integer isLoginLinkConfigured=0;
    @Value("#{linkProperties['hide_registration_link']?:3355}")
    private int hideRegistrationLinkId;
    @Value("#{linkProperties['marketplace_linkId']?:3361}")
    private int marketPlaceLinkId;
    @Value("#{projectProperties['spacematrix_clientId']}")
    private int SMclientId;
    @Value("#{projectProperties['default_contry_id']}")
    private int countryId;
    @Value("#{projectProperties['AgNextTemplateId']}")
   	private String agNextTemplateId;
//    @Value("#{projectProperties['is_sub_user_dc_auto_approved']}")
//   	private int isSubUserDCAutoApproved;
    @Value("#{clientProperties['is_sub_user_dc_auto_approved']}")
   	private int isSubUserDCAutoApproved;
    /**
     * This will trigger Locale Resolver of Spring and redirects to the same url
     * with changed locale.
     *
     * @author japan
     * @param request
     * @return
     */
    @RequestMapping(value = "/changelanguage", params = {"language"}, method = RequestMethod.GET)
    public String changeLanguage(HttpServletRequest request) {
//    	System.out.println("language :::"+request.getParameter("language") );
        return "redirect:" + request.getHeader("Referer");
    }

    /**
     * This will trigger Theme Resolver of Spring and redirects to the same url
     * with changed theme.
     *
     * @author japan
     * @param request
     * @return
     */
    @RequestMapping(value = "/changetheme", params = {"theme"}, method = RequestMethod.GET)
    public String changeTheme(HttpServletRequest request) {
//    	System.out.println("theme :::"+request.getParameter("theme") );        
        return "redirect:" + request.getHeader("Referer");
    }

    /**
     * This method gets the information to show on home page and returns the
     * same.
     *
     * @param req
     * @param session
     * @param map
     * @return String containing the jsp name
     */
    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String showLogin(HttpServletRequest req, HttpSession session, ModelMap map, HttpServletResponse response) {
    	String pageName;
    	pageName = getHomePageData(req,session,map,response,0,0,false);
    	int ShowAccessDetail=abcUtility.getAccessDetail(req);
		/* CSP BEFORE LOGIN */
    	ClientBean clientBean = (ClientBean) req.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    	String userAgent = req.getHeader("user-agent");
    	if(clientBean.getIsSigner() == 1 && userAgent.contains("Trident")) {
    		clientBean.setIsSigner(0);
    	}
				
		if(ShowAccessDetail==1){
    	int visitorCount=commonService.getVisitorDetail(req);
    		map.addAttribute("visitorCount",visitorCount);
		}
		
		if(pageName.equals("SetCookie")) {
			return pageName;
		}
		
		//For template-9
		if(agNextTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1])){
			pageName = "AgNextHome";
		}
    	return pageName;
    }
    
    @RequestMapping(value = "/ajaxSearchAgNext", method = RequestMethod.GET)
    public String getSearchListingPage(HttpServletRequest req, HttpSession session, ModelMap map, HttpServletResponse response,Model model){
    	String pageName = getHomePageData(req,session,map,response,0,0,false);
    	int ShowAccessDetail=abcUtility.getAccessDetail(req);
		if(ShowAccessDetail==1){
    	int visitorCount=commonService.getVisitorDetail(req);
    		map.addAttribute("visitorCount",visitorCount);
		}
		String txtReportId = (String) model.asMap().get("txtReportId");
		String txtModuleId = (String) model.asMap().get("txtKeywordSearch");
		if(txtReportId != null && txtModuleId != null){
			map.addAttribute("reportId",txtReportId);
			map.addAttribute("moduleId",txtModuleId);
			try {
				String txtKeywordSearch = (String) model.asMap().get("txtKeywordSearch");
				if(txtKeywordSearch != null){
					map.addAttribute("keywordSearch", txtKeywordSearch.replace("\\", "%5C"));
				}
			}catch (Exception e){
				return exceptionHandlerService.writeLog(e);
			}
		}
		if(agNextTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1])){
			pageName = "home"; //use this page
		}
    	return pageName;
    }

    /**
     * This method is redirect to Eproc Homepage.
     * @param req
     * @param session
     * @param map
     * @param response
     * @return
     */
    @RequestMapping(value = "/searchTender", method = RequestMethod.GET)
    public String searchTender(HttpServletRequest req, HttpSession session, ModelMap map, HttpServletResponse response) {
    	String pageName;
    	pageName = getHomePageData(req,session,map,response,0,0,false);
    	int ShowAccessDetail=abcUtility.getAccessDetail(req);
		if(ShowAccessDetail==1){
    	int visitorCount=commonService.getVisitorDetail(req);
    		map.addAttribute("visitorCount",visitorCount);
		}
		map.addAttribute("isSearchTender",true);
		map.addAttribute("isSearchAuction",false);
    	return pageName;
    }
    /**
     * This method is redirect to Auction Tiger Homepage.
     * @param req
     * @param session
     * @param map
     * @param response
     * @return
     */
    @RequestMapping(value = "/searchAuction", method = RequestMethod.GET)
    public String searchAuction(HttpServletRequest req, HttpSession session, ModelMap map, HttpServletResponse response) {
    	String pageName;
    	pageName = getHomePageData(req,session,map,response,0,0,false);
    	int ShowAccessDetail=abcUtility.getAccessDetail(req);
		if(ShowAccessDetail==1){
    	int visitorCount=commonService.getVisitorDetail(req);
    		map.addAttribute("visitorCount",visitorCount);
		}
		map.addAttribute("isSearchTender",false);
		map.addAttribute("isSearchAuction",true);
    	return pageName;
    }
    /**
     * @author pradip.jinjala
     * @param req
     * @param session
     * @param map
     * @param response
     * @return
     */
    @RequestMapping(value = "/searchData", method = RequestMethod.GET)
    public String PropertyListingView(HttpServletRequest req, HttpSession session, ModelMap map, HttpServletResponse response) {
    	String pageName = null;
    	map.addAttribute("isAuctionTiger",true);
    	map.addAttribute("isStateProperty", "satevalid");
    	pageName = getHomePageData(req,session,map,response,0,0,true);
    	int ShowAccessDetail=abcUtility.getAccessDetail(req);
		if(ShowAccessDetail==1){
    	int visitorCount=commonService.getVisitorDetail(req);
    		map.addAttribute("visitorCount",visitorCount);
		}
		String selectedState = null;
		String typeOfPropertys = null;
		
		boolean flag = true;
		map.addAttribute("txtKeywordSearch", req.getParameter("txtKeywordSearch"));
		try {
			if (req.getParameter("state") != null && !req.getParameter("state").isEmpty()) {
				String[] stateArr = req.getParameter("state").split(",");
				if (stateArr.length > 0 && !stateArr[0].equals("")) {
					for (String state : stateArr) {
						if (flag) {
							selectedState = "$" + state.trim() + "$";
							flag = false;
						} else {
							selectedState += ",$" + state.trim() + "$";
						}
					}
					map.addAttribute("state", selectedState);
				}
			}
			flag = true;
		} catch (Exception e) {
			flag = true;
		}
		
		if(req.getParameterValues("typeOfProperty") != null){
			String[] typeOfPropertyArr = req.getParameterValues("typeOfProperty");
			for (String typeOfProperty : typeOfPropertyArr) {
				if(flag){
					typeOfPropertys = "$"+typeOfProperty+"$";
					flag = false;
				}else{
					typeOfPropertys += ",$"+typeOfProperty+"$";		
				}
			}
			map.addAttribute("typeOfProperty", typeOfPropertys.replaceAll("[\\t\\n\\r]",""));
		}
		map.addAttribute("budget", req.getParameter("budget"));
		
    	return pageName;
    }
    
    @RequestMapping(value = "/searchGMR", method = RequestMethod.GET)
    public String getGMRListingPage(HttpServletRequest req, HttpSession session, ModelMap map, HttpServletResponse response){
    	String pageName = null;
    	int ShowAccessDetail=abcUtility.getAccessDetail(req);
		if(ShowAccessDetail==1){
    	int visitorCount=commonService.getVisitorDetail(req);
    		map.addAttribute("visitorCount",visitorCount);
		}
		String selectedModule = req.getParameter("txtSelectedModule");
		if(selectedModule != null){
			map.addAttribute("reportId",selectedModule.split(",")[1]);
			map.addAttribute("moduleId",selectedModule.split(",")[0]);
			String keywordSearch = req.getParameter("txtKeywordSearch");
			map.addAttribute("keywordSearch", keywordSearch.replace("\\", "%5C"));
		}
		pageName = getHomePageData(req,session,map,response,0,0,false);
		pageName = "GmrHomeListingReport";
    	return pageName;
    }
    
    @RequestMapping(value = "/bank/{bankId}/{moduleId}/{scrollPosition}", method = RequestMethod.GET)
    public String activeInActiveDepartment(ModelMap map, HttpSession session, @PathVariable("bankId") int bankId,  @PathVariable("moduleId") int selectedModuleId, @PathVariable("scrollPosition") int scrollPosition, HttpServletRequest request , HttpServletResponse response) throws Exception {
    	String pageName;
    	boolean isPropertyListing = false;
    	ClientBean clientBean =(ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    	List<Object> lstClientSector = clientService.getClientSector(clientBean.getClientId()); 
        int sectorId = lstClientSector.size() > 0 ? (Integer)lstClientSector.get(0) : 0;
    	if((((sectorId == drtSectorId || sectorId == bankSectorId) && selectedModuleId == 5 && clientBean.getIsHomePageRequire() == 1))){
    		isPropertyListing = true;
    	}
    	map.addAttribute("selBankScrollPos", scrollPosition);
    	pageName = getHomePageData(request,session,map,response,bankId,selectedModuleId,isPropertyListing);
    	return pageName;
     }
    /*
     * Author : Yagnesh
     * Purpose : To set cookie when user comes from email verification
     */
    @RequestMapping(value = "/setcookie", method = RequestMethod.GET)
    public String setCookieFirstTime(HttpServletRequest request , HttpServletResponse response, RedirectAttributes redirectAttributes) {
    	return "SetCookieAuth";
    }
    /*
     * Author : Vijay 
     * Purpose : To set cookie when user comes from npaBank verification
     */
    @RequestMapping(value = "/setcookiebank/{isBankProperties}/{bankId}/{selectedModuleId}", method = RequestMethod.GET)
    public String setCookieForBank(@PathVariable("isBankProperties") int isBankProperties,@PathVariable("bankId") int bankId,@PathVariable("selectedModuleId") int selectedModuleId,HttpServletRequest request , HttpServletResponse response, ModelMap map ) {
	    try
	    {
	    	
	    		map.addAttribute("isBankNpaProperties",true);
		    	map.addAttribute("bankId",bankId);
		    	map.addAttribute("selectedModuleId",selectedModuleId);
		    	map.addAttribute("isPropertyListing",0);
	    	
	    }
	    catch(Exception e)
	    {
	    	exceptionHandlerService.writeLog(e);
	    }
    	return "SetCookieAuth";
    }
    
    
    @RequestMapping(value = "/setcookiestateproperty/{searchData}", method = RequestMethod.GET)
    public String setcookieStateProperty(@PathVariable("searchData") String searchData,HttpServletRequest request , HttpServletResponse response, ModelMap map ) {
	    try
	    {
	    		String decData=encryptDecryptUtils.decrypt(searchData);
	    		map.addAttribute("searchData","searchData?"+decData);
	    	
	    }
	    catch(Exception e)
	    {
	    	exceptionHandlerService.writeLog(e);
	    }
    	return "SetCookieAuth";
    }
    
    /*
     * Author : Yagnesh
     * Purpose : To show successful message on email verification
     */
    @RequestMapping(value = "/authcomplete", method = RequestMethod.GET)
    public String authComplte(HttpServletRequest request , HttpServletResponse response, RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_email_verify_Only");
    	return "redirect:/";
    }
    
    private void getDownloadLinks(HttpSession session,int clientId,int displayLocation, int displayTo){
    	
    	List<Object[]> lstDownloadLinks;
		try {			
		
			lstDownloadLinks = manageContentService.getDownloadLinks(clientId, displayLocation, 2,displayTo);
		
			session.setAttribute("downloadLinks",lstDownloadLinks);
			
			List<Object[]> lstDownloadDocs=manageContentService.getDownloadLinks(clientId, displayLocation, 1,displayTo);
			List<Object[]> lstDownloadDocsFinal=new ArrayList<Object[]>();
			int docId=0;
			
			for(Object[] objLinks:lstDownloadDocs)
			{					
				 List<Object[]> lstDocumentDetails=manageContentService.getOfficerDocs(Integer.parseInt(objLinks[2].toString()), manageDownloadDocumentUpload,1); //6
				 for(Object[] objDocs:lstDocumentDetails)
				 {
					 docId=Integer.parseInt(objDocs[0].toString());
					 String[] link=new String[2];
					 link[0]="ajaxcall/downloadfile/"+docId+"/"+Integer.parseInt(objLinks[2].toString());
					 link[1]=objLinks[1].toString();
					 lstDownloadDocsFinal.add(link);
				 }
			}
			session.setAttribute("downloadDocs",lstDownloadDocsFinal);
			
			if(lstDownloadLinks.size()!=0 || lstDownloadDocsFinal.size()!=0){
				session.setAttribute("isDownloads",1);
			}else{
				session.setAttribute("isDownloads",0);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    private String getHomePageData(HttpServletRequest req, HttpSession session, ModelMap map, HttpServletResponse response, int bankId, int selectedModuleId, boolean isPropertyListing){
        String pageName = "";
        String gmrTheme = "";
      //  map.put("captchaHtml",AbcCaptchaFactory.newAbcCaptcha(0)); this was commented because of it was causing cross site scripting issues when it redirect on home page 
        try {
    		int counter = 0;
    		Cookie[] cookies = req.getCookies();
    		if (cookies != null) {
    			for (Cookie cookie : cookies) {
    				if ("locale".equals(cookie.getName())) {
    					counter++;
    				}
    				if("theme".equals(cookie.getName())){
    					gmrTheme = cookie.getValue();
    				}
    			}
    		}
    		if (counter == 0) {
    			 if(map.get("isStateProperty")!=null){
    					boolean flag = true;
        				StringBuilder selectedState = new StringBuilder();
        				String[] stateArr = req.getParameter("state").split(",");
        				StringBuilder typeofPropertyquery = new StringBuilder();
        				if(stateArr.length > 0 && !stateArr[0].equals("")){
        					for (String state : stateArr) {
        						if(flag){
        							selectedState.append("state="+state.replace(" ", "+")+"&");
        							flag = false;
        						}else{
        							selectedState.append("state="+state.replace(" ", "+")+"&");		
        						}
        					}
        					if(req.getParameterValues("typeOfProperty") == null)
        					{
        					selectedState.append("budget=0+-+0");
        					pageName = "redirect:/setcookiestateproperty/"+encryptDecryptUtils.encrypt(selectedState.toString());
        					}
        				}
        				flag = true;
        				if(req.getParameterValues("typeOfProperty") != null){
        					String[] typeOfPropertyArr = req.getParameterValues("typeOfProperty");
        					
        					for (String typeOfProperty : typeOfPropertyArr) {
        						if(flag){
        							typeofPropertyquery.append("typeOfProperty=").append(typeOfProperty.replace(" ", "+").replace("/", "%2F")).append("&");
        							flag = false;
        						}else{
        							typeofPropertyquery.append("typeOfProperty=").append(typeOfProperty.replace(" ", "+").replace("/", "%2F")).append("&");		
        						}
        					}
        					if(stateArr.length < 0 && stateArr[0].equals(""))
        					{
        					typeofPropertyquery.append("budget=0+-+0");
        					pageName = "redirect:/setcookiestateproperty/"+encryptDecryptUtils.encrypt(typeofPropertyquery.toString());
        					}
        				}
        				
        				if(req.getParameterValues("typeOfProperty") != null && stateArr.length > 0 && !stateArr[0].equals("")){
        				 selectedState.append(typeofPropertyquery.append("budget=0+-+0"));
        				 pageName = "redirect:/setcookiestateproperty/"+encryptDecryptUtils.encrypt(selectedState.toString());
        				}
        				
        				

    			 }else{
    				 if(bankId !=0)
    	    			{
    	    			 pageName = "redirect:/setcookiebank/"+1+"/"+bankId+"/"+selectedModuleId;
    	    			}else
    	    			{
    	    				pageName = "SetCookie"; // If cookie is not found, then redirect to home url from this JSP  
    	    			}
    			 }
    		} else {
				int registrationBy = 1;
				ClientBean clientBean = (ClientBean) session.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
				int clientId= clientBean.getClientId();
				TblClient tblClient = null;
								
				isLoginLinkConfigured=clientBean.getIsLoginLinkConfigured();
				map.put("isLoginLinkConfigured", isLoginLinkConfigured);
				registrationBy = clientService.getBidderRegistrationBy(clientBean.getClientId());

				if (req.getSession().getAttribute(SESSIONOBJECT) != null) {
					SessionBean sessionBean = (SessionBean) req.getSession().getAttribute(SESSIONOBJECT);
					
					int clientRegWorkflowIdbidder = 0;
					int bidderCstatus = 0;
					if(sessionBean.getUserTypeId() == 2 )
                    {
						clientRegWorkflowIdbidder = manageBidderService.getBidderWorkflowId(clientBean.getClientId(), sessionBean.getUserId());
						bidderCstatus=manageBidderService.getBidderCstatus(clientBean.getClientId(), sessionBean.getUserId());
					}
					if(bidderCstatus == 6 && clientRegWorkflowIdbidder == 9)
					{
						pageName = "redirect:/eauction/bidder/editbidder/"+sessionBean.getUserId()+encryptDecryptUtils.generateRedirect("eauction/bidder/editbidder/"+sessionBean.getUserId(), req);
					} else {
						pageName = getRedirectPage(req);
					}	
				} else if (req.getSession().getAttribute(TEMPSESSIONOBJECT) != null) {
					SessionBean sessionBean = (SessionBean) req.getSession().getAttribute(TEMPSESSIONOBJECT);
					int userId = sessionBean.getUserId();
					List<TblUserLogin> userLogins = commonService.getUserLoginById(userId);
					TblUserLogin userLogin = userLogins != null && userLogins.isEmpty() ? null : userLogins.get(0);
					if (userLogin != null) {
						boolean isFirstLogin = (userLogin.getIsFirstLogin() == 1);
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(userLogin.getPasswordUpdatedOn());
						calendar.add(Calendar.DAY_OF_MONTH, passValidity);
						if (calendar.getTime().before(commonService.getServerDateTime())) {
							pageName = "redirect:/chngpassword";
						} else if (isFirstLogin) {
							pageName = "redirect:/changepasswordonlogin";
						}else if (!sessionBean.getUserName().matches(("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9\\-\\_]+(\\.[A-Za-z0-9\\-\\_]+)*(\\.[A-Za-z0-9\\-\\_]{2,})$"))) {
							pageName = "redirect:/updateloginid";
						}  else {
							int clientRegWorkflowId = 0;
							if (sessionBean.getUserTypeId() == 2) {
								clientRegWorkflowId = manageBidderService.getBidderWorkflowId(clientBean.getClientId(), userId);
							}
							if (clientRegWorkflowId != 0 && clientRegWorkflowId != 9) {
								switch (clientRegWorkflowId) {
								case 4: //Certificate Mapping
									pageName = "redirect:/certimap";
									break;
								case 5: //Registation Documents
									pageName = "redirect:/uploaddocument";
									break;
								case 6: //Registration Charges
									pageName = "redirect:/bidderregcharges";//pending
									break;
								case 7: //GST Details
									pageName = "redirect:/gstDetails/0";//pending
									break;
								case 8: //Finish Registration
									pageName = "redirect:/finishregistration";//pending
									break;
								}
								
							}
							 else {
								pageName = "redirect:/certimap";
							}
						}
					} else {
						getHomePageDetails(registrationBy, clientBean, req, map,bankId,selectedModuleId);
						if(clientBean.getIsDIYClient() == 1) //PT:21042
						{
							pageName = "DIYHomepage";
						}else{
							pageName = "home";	
						}
						
					}
				} else {
					getHomePageDetails(registrationBy, clientBean, req, map,bankId, selectedModuleId);					
					getDownloadLinks(session,clientBean.getClientId(),1,0);					
					getHomePageDetails(registrationBy, clientBean, req, map,bankId, selectedModuleId);
					session.setAttribute("header_languageSelectList", abcUtility.convert(clientService.getClientLanguageToSelect(clientBean.getClientId())));
					session.setAttribute("header_themeSelectList", modelToSelectItem.convertListIntoSelectItemList(commonService.getThemeList(), "themeId", "lang"+WebUtils.getCookie(req, "locale").getValue()));
                                        List sectorList = clientService.getClientSector(clientBean.getClientId());
                                        boolean isDRT = false;
                                        boolean isBank = false;
                                        boolean isSarfaesi = false;
                                        for(Object obj : sectorList){
                                            if(obj.equals(1)){
                                                isDRT = true;
                                            }else if(obj.equals(2)){
                                                isSarfaesi = true;
                                            }else if(obj.equals(3)){
                                                isBank = true;
                                            }
                                        }
                                        session.setAttribute("sectorList",sectorList);
                                        session.setAttribute("isDRT", isDRT);
                                        session.setAttribute("isBank", isBank);
                                        session.setAttribute("isSarfaesi", isSarfaesi);
                                        
                                        if(isDRT){
                                            req.setAttribute("BankList", drtService.getBankSectorClient(3));
                                        }
                                       // req.setAttribute("isDRT", isDRT);
					req.setAttribute("clientDefTheme", clientService.getClientDefTheme(clientBean.getClientId()));
					if(clientBean.getIsDIYClient() == 1)//PT:21042
					{
						pageName = "DIYHomepage";
					}else{
						//Auction Tiger Home page
						if(isPropertyListing){
							pageName = "PropertyHomeAuctionListing";
						}else{	
							pageName = "home";
						}
					}
				}
			}
    	} catch (Exception ex) {
    		pageName = exceptionHandlerService.writeLog(ex);
    	}
        
        return pageName;
    }
    
    private void getHomePageDetails(int registrationBy, ClientBean clientBean, HttpServletRequest request, ModelMap map, int bankId, int selectedModuleId) throws Exception {
    	// PT: 20745 :: Statistics
    	int isStatisticsReportAllow = 0;
    	String clientModule = clientBean.getClientModules();
    	if(clientModule != null && !clientModule.equals("") && clientModule.contains(","+9+","))
    	{
    		isStatisticsReportAllow=commonService.isCategoryStaticsAllow(clientBean.getClientId());
    	}
    	if(isStatisticsReportAllow == 1) {
    		 map.addAttribute("isStatisticsAdded", true);
    		 map.put("reportId", linkStaticsReportHomePage);
    	}
    	else {
    		map.addAttribute("isStatisticsAdded", false);
    	}
        map.put("lstClientMarquee", clientService.getClientMarquee(clientBean.getClientId()));
        map.put("clientHomePage", clientService.getClientHomepage(clientBean.getClientId()));
        if(bankId != 0){
        	if(selectedModuleId == 5){
        		map.put("reportId", homeDRTAuctionListingReportId);
        	}else if(selectedModuleId == 3){
        		map.put("reportId", homeDRTRfqListingReportId);
        	}
            map.put("bankName", clientService.getClientNameByClientId(bankId));
            map.put("bankId", bankId);
        }
        else{
            map.put("bankId", 0);            
        }
        List<Object[]> lst = clientService.getClientModuleForHomePage(clientBean.getClientId());
        List<Object[]> cltModules = new ArrayList<Object[]>();
        Object[] objs = null;
        for(int i=0; i<lst.size();i++){
        	objs = new Object[4];
        	for(int j=0; j<lst.get(i).length; j++){
        		objs[j] = lst.get(i)[j];
        	}
        	/*
        	 * As New Module Develop, else if condition is added and compare with its moduleId. (For Tender remove comment)
        	 */
        	 
        	 if("3".equalsIgnoreCase(lst.get(i)[0].toString())){
        		objs[3] = homeTenderListingReportId;
        	}
        	else if("5".equalsIgnoreCase(lst.get(i)[0].toString())){
        		if(clientBean.getSectorTableName()!=null && !"".equalsIgnoreCase(clientBean.getSectorTableName())) {
        			List<Object> lstClientSector = clientService.getClientSector(clientBean.getClientId());
        			int sectorId = lstClientSector.size() > 0 ? (Integer)lstClientSector.get(0) : 0;
        			if(sectorId == propertySectorId){
        				objs[3] = propertySectorHomeAuctionListingReportId;
        			}else{
        				objs[3] = homeSectorAuctionListingReportId;
        			}
        			map.addAttribute("isSectorTableFound", true);
        			reportGeneratorService.getSectorSearchFieldsConfig(abcUtility.getSessionClientId(request), aucAttrSelLinkId, map);
        			map.put("isSectorTableFound", true);
        			map.addAttribute("sectorId", sectorId);
        		}
        		else {
        			objs[3] = homeAuctionListingReportId;
        		}
        	}	else if("10".equalsIgnoreCase(lst.get(i)[0].toString())){
        		objs[3] = advertiseReportId;
        	}
        	cltModules.add(objs);
        }
//        Bug #36239
        map.put("setDefaultModule", request.getRequestURI().toString());
        if(map.get("reportId")==null)
        {
        	map.put("reportId", getDefaultModuleReportId(lst, clientBean, map));
        }
        if(map.get("moduleId") != null)
        {
             map.put("moduleId", map.get("moduleId").toString());
        }
        else if(selectedModuleId != 0 && bankId != 0){
        	map.put("moduleId", selectedModuleId);
        }
        else
        {
            String moduleId=null;
            for(int i=0; i<lst.size();i++){
                    if((Integer)lst.get(i)[2]==1){
                            moduleId = lst.get(i)[0].toString();
                            String data = map.get("setDefaultModule").toString();
                     		List<Object> lstClientSector = clientService.getClientSector(clientBean.getClientId());
                			int sectorId = lstClientSector.size() > 0 ? (Integer)lstClientSector.get(0) : 0;
                			if((((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1 && data.contains("searchTender"))) && moduleId.equals("5")){
                				moduleId = "3";
                			}else if((((sectorId == drtSectorId || sectorId == bankSectorId) && data.contains("searchData") && clientBean.getIsHomePageRequire() == 1 && clientBean.getHomePageTypeId() == 1))){
                	    		moduleId = "5";
                	    	}
                            break;
                    }
            }
             map.put("moduleId", moduleId);
        }
        
        reportGeneratorService.getReportConfigDetails(Integer.parseInt(map.get("reportId").toString()), map);
        if(clientBean.getSectorTableName()!=null && !"".equalsIgnoreCase(clientBean.getSectorTableName())) {
        	List<SelectItem> lstSortColumns = new ArrayList<SelectItem>();
        	lstSortColumns.add(new SelectItem("Order by",""));
			List<TblReportSearchColumnDetail> lstTblReportSortDetails = reportGeneratorService.getReportSearchColumnDetail(Integer.parseInt(map.get("reportId").toString()));
			if(lstTblReportSortDetails!=null && !lstTblReportSortDetails.isEmpty()) {
				for(TblReportSearchColumnDetail tblReportSearchColumnDetail : lstTblReportSortDetails) {
					if(tblReportSearchColumnDetail.getSortColHeadingId()!=0) {
						lstSortColumns.add(new SelectItem(tblReportSearchColumnDetail.getColumnName() , tblReportSearchColumnDetail.getSortColHeadingId()));
					}
				}
			}
			map.put("lstSortColumns", lstSortColumns);
        }
        List<Object[]> bannerList= new ArrayList<Object[]>();
        List<Integer> contentMgtId=new ArrayList<Integer>();
        
        if(!GMRTemplateId.equals(WebUtils.getCookie(request, "theme").getValue().toString().split("-")[1])){
        	
        	bannerList=manageContentService.getClientBannersContentForHomepage(clientBean.getClientId());
             	for(Object[] banner : bannerList){
        		contentMgtId.add(Integer.parseInt(banner[0].toString()));
        	}
        }else{
            bannerList=manageContentService.getGmrClientBannerForHomepage(clientBean.getClientId(),request);
        	for(Object[] banner : bannerList){
        		contentMgtId.add(Integer.parseInt(banner[0].toString()));
        	}
        }
        if(!bannerList.isEmpty()){
	        List<Object[]> tempFileList=manageContentService.getClientBannersFile(contentMgtId,clientBean.getClientId(),createBannerLink); // Link id need to be changed
	        List<Object[]> bannerDocList=new ArrayList<Object[]>();
	        for(Object[] banner : bannerList){
	        	for(Object[] bannerDoc : tempFileList){
	        		if(Integer.parseInt(banner[0].toString()) == Integer.parseInt(bannerDoc[3].toString())){
	        			bannerDocList.add(bannerDoc);
	        			break;
	        		}
	        	}
	        }
	        map.put("bannerDocList", bannerDocList);
        }
        map.put("bannerList", bannerList);
        map.put("certContactDetails", clientService.getClientCertContactDetail(clientBean.getClientId()));
        map.put("isRegistrationByBidder", registrationBy == 1);
        map.put("isRegisterByHimSelf", clientService.getClientOfficerRegisterBy(clientBean.getClientId()));
        
        List<Object[]> data=clientService.getClientHomepageStyle(clientBean.getClientId());
        map.put("homePageStyle", !data.isEmpty() ? data.get(0)[0] : 1);
        map.put("isShowDcBanner", !data.isEmpty() ? data.get(0)[1] : 0);
        /*int counter = 0;
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if ("conversionValue".equals(cookie.getName())) {
                    counter++;
                }
                if ("listingStyle".equals(cookie.getName())) {
                    counter++;
                }
                if ("eprocLogoName".equals(cookie.getName())) {
                    counter++;
                }
            }
        }
        if (counter == 0) {
            List<Object[]> clientDetails = clientService.getClientConversionValueAndListingStyle(clientBean.getClientId());
            if (clientDetails != null && !clientDetails.isEmpty()) {
                map.put("conversionValue", clientDetails.get(0)[0]);
                map.put("listingStyle", clientDetails.get(0)[1]);
                map.put("eprocLogoName", clientDetails.get(0)[2]);
            }
        }*/
        /*map.put("clientModules", clientService.getClientModuleForHomePage(clientBean.getClientId()));*/
        map.put("clientModules", cltModules);
        
        // PT : #38537 by Jitendra. Hide Registration Link status
        map.put("isRegistrationLinkHidden", clientService.isRegistrationLinkHidden(clientBean.getClientId(), hideRegistrationLinkId, 1));
        
    }
    
    private int getDefaultModuleReportId(List<Object[]> lstModules, ClientBean clientBean, ModelMap map) throws Exception{
    	int reportId=0;
    	String moduleId="";
    	for(int i=0; i<lstModules.size();i++){
         	if((Integer)lstModules.get(i)[2]==1){
         		String checkUrl = map.get("setDefaultModule").toString();
         		moduleId = lstModules.get(i)[0].toString();
         		List<Object> lstClientSector = clientService.getClientSector(clientBean.getClientId());
    			int sectorId = lstClientSector.size() > 0 ? (Integer)lstClientSector.get(0) : 0;
    			if((((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1 && clientBean.getHomePageTypeId() == 1 && checkUrl.contains("searchTender"))) && moduleId.equals("5")){
    				moduleId = "3";
    	    	}else if((((sectorId == drtSectorId || sectorId == bankSectorId) && checkUrl.contains("searchData") && clientBean.getIsHomePageRequire() == 1 && clientBean.getHomePageTypeId() == 1))){
    	    		moduleId = "5";
    	    	}
         		break;
         	}
        }
    	/*
    	 *  As New Module Develop, else if condition is added and compare with its moduleId (For Tender remove comment)
    	 *  
    	 */
    	 
    	 if("3".equals(moduleId)){
    		reportId = homeTenderListingReportId;
    	}
    	else if("5".equals(moduleId)){
    		if(clientBean.getSectorTableName()!=null && !"".equalsIgnoreCase(clientBean.getSectorTableName())) {
    			int sectorId = (Integer) clientService.getClientSector(clientBean.getClientId()).get(0);
    			if(sectorId == propertySectorId){
    				reportId = propertySectorHomeAuctionListingReportId;
    			}else{
    				reportId = homeSectorAuctionListingReportId;
    			}    			
    			reportGeneratorService.getSectorSearchFieldsConfig(clientBean.getClientId(), aucAttrSelLinkId, map);
    			map.put("isSectorTableFound", true);
    			map.put("sectorId", sectorId);
    		}
    		else {
    			reportId = homeAuctionListingReportId;
    		}
    		
    	}
    	else if("10".equals(moduleId))
    	{
    		reportId = advertiseReportId;
    	}
    	return reportId;
    }

    @RequestMapping(value = "/submitLogin", method = RequestMethod.GET)
    public String submitLogin(HttpServletRequest request, RedirectAttributes redirectAttributes,HttpServletResponse response) throws Exception {
        TblUserLogin tblUserLogin = null;
        boolean loginSuccess = false;
        boolean isFirstLogin = false;
        boolean isChngPass = false;
        SessionBean bean = null;
        int clientId = 0;
        boolean pkiRequired = false;
        boolean isEventSpecific = false;
        int clientRegWorkflowId = 0;
        Date serverDate = null;
        ClientBean clientBean = null;
        String userName = "";
        int isCaptchaConfigured = 0;
        int bidderCstatus=0;
        int userTypeId=0;
        boolean isGstEntered = true;
        if (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) {
            clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            clientId = clientBean.getClientId();
            pkiRequired = (clientBean.getIsPkiEnabled() == 1);
            isEventSpecific = (clientBean.getIsPkiEnabled() == 2);
        }
        try {
            if (SecurityContextHolder.getContext().getAuthentication().isAuthenticated()
                    && !SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString().equalsIgnoreCase("anonymousUser")) {

                String ipAddress = request.getHeader("X-FORWARDED-FOR") != null ? request.getHeader("X-FORWARDED-FOR") : request.getRemoteAddr();
                TblTrackLogin trackLogin = new TblTrackLogin();
                userName = SecurityContextHolder.getContext().getAuthentication().getPrincipal().toString();
                tblUserLogin = loginService.getUserLoginByLoginId(userName);
                trackLogin.setBrowserType(request.getHeader("User-Agent"));
                trackLogin.setIpAddress(ipAddress);
                trackLogin.setOperatingSystem(request.getHeader("User-Agent"));
                trackLogin.setTblClient(new TblClient(clientId));
                trackLogin.setUserId(tblUserLogin.getUserId());
                trackLogin.setLoginId(tblUserLogin.getLoginId());

                loginSuccess = tblUserLogin.getFailedLoginAttempt() < failedAttempt;
                isCaptchaConfigured = (Integer) request.getSession().getAttribute("isCaptchaConfigured");
                if (loginSuccess) {
                	
                	if(isCaptchaConfigured == 1 && Integer.parseInt(request.getSession().getAttribute("isCaptchaValid").toString()) == 1){
                		redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_unlockaccount");
                	}
                	
                    SessionBean sessionBean = new SessionBean();
                    sessionBean.setUserName(tblUserLogin.getLoginId());
                    sessionBean.setUserId(tblUserLogin.getUserId());
                    Iterator<GrantedAuthority> authIterator = SecurityContextHolder.getContext().getAuthentication().getAuthorities().iterator();
                    while (authIterator.hasNext()) {
                        String authority = authIterator.next().getAuthority();
                        sessionBean.setUserTypeId(authority.equals("ROLE_BIDDER") ? 2 : authority.equals("ROLE_OFFICER") ? 3 : authority.equals("ROLE_ABCUSER") ? 1 : 0);
                        trackLogin.setUserTypeId(sessionBean.getUserTypeId());
                        userTypeId=sessionBean.getUserTypeId();
                    }
                    List<Object> list = loginService.getClientOfficerUserName(tblUserLogin.getUserId() ,clientId);
                    if(!list.isEmpty() && list != null && (userTypeId == 3 || userTypeId == 1)){
                    	sessionBean.setFullName(String.valueOf(list.get(0)));
                    }else{
                    	sessionBean.setFullName(tblUserLogin.getUserName());
                    }
                    getDownloadLinks(request.getSession(),clientBean.getClientId(),2,sessionBean.getUserTypeId());
                    if (sessionBean.getUserTypeId() == 1) {
                        if (!pkiReqForAbcUser) {
                            clientBean.setIsPkiEnabled(0);
                            request.getSession().removeAttribute(CommonKeywords.CLIENT_OBJ.toString());
                            request.getSession().setAttribute(CommonKeywords.CLIENT_OBJ.toString(), clientBean);
                        }
                    }
                   /* if(isEventSpecific){
                        String certIds = null;                        
                        List<Object[]> certificates = loginService.getUserPublicKey(sessionBean.getUserId(),clientBean.getIsDualCerti());
                        for (Object[] certs : certificates) {
                            if((Integer)certs[2] == 0){
                                sessionBean.setCertId(certs[1].toString()+","+certs[1].toString());
                            }else if((Integer)certs[2] == 1){
                                certIds = certs[1].toString();
                            }else if(clientBean.getIsDualCerti()==2 && (Integer)certs[2] == 2){
                                certIds = certIds + ","+certs[1].toString();
                            }
                        }
                        if(sessionBean.getCertId()==null && certIds!=null){
                            sessionBean.setCertId(certIds);
                        }
                    }*/
                    sessionBean.setIsAbcUser(sessionBean.getUserTypeId() == 1);
                    sessionBean.setUserDetailId(loginService.getUserDetailId(sessionBean.getUserId(), sessionBean.getUserTypeId() == 3 ? clientId : sessionBean.getUserTypeId() == 2 ? 0 : -1));
                    List<Object[]> lstObj = loginService.getLstLoginDtIpAddrById(sessionBean.getUserId(), clientId);
                    if (lstObj != null & !lstObj.isEmpty()) {
                        for (int i = 0; i < lstObj.size(); i++) {
                            Object[] object = lstObj.get(i);
                            sessionBean.setLastLoginDateTime((Date) object[0]);
                            sessionBean.setIpAddress(String.valueOf(object[1]));
                        }
                    }
                    List<Object[]> timeZone = loginService.getUserTimeZone(sessionBean.getUserId());
                    if (timeZone != null && !timeZone.isEmpty()) {
                        if(sessionBean.getUserTypeId()==1){
                            sessionBean.setTimeZoneOffset(clientBean.getTimeZone());
                            sessionBean.setTimeZoneAbbr(clientBean.getTimeZoneAbbr());                                                                                    
                        }else{
                            sessionBean.setTimeZoneOffset(timeZone.get(0)[0].toString());
                            sessionBean.setTimeZoneAbbr(timeZone.get(0)[1].toString());
                        }
                    }
                    if (sessionBean.getUserTypeId() != 2) {
                        if (sessionBean.isIsAbcUser()) {
                            clientId = 0;
                        }
                        List<Object[]> depDesigList = loginService.getDeptNDesigId(sessionBean.getUserId(), clientId);
                        if (!depDesigList.isEmpty()) {
                            sessionBean.setDeptId((Integer) depDesigList.get(0)[0]);
                            sessionBean.setDesignationId((Integer) depDesigList.get(0)[1]);
                            if (sessionBean.getUserTypeId() != 2) {
                            	request.getSession().setAttribute("isCreateBidderAllowed", clientService.getBidderRegistrationBy(abcUtility.getSessionClientId(request)) == 0);
                                StringBuilder right = new StringBuilder();
                                List<Object> rights = loginService.getUserRights(sessionBean.getDesignationId());
                                for (Object link : rights) {
                                    right.append(",").append(link);
                                }
                                boolean hasAccessEmarketPlace = loginService.hasAccessOfEmarketPlaceDashboard(abcUtility.getSessionClientId(request), sessionBean.getUserId());
                                if(hasAccessEmarketPlace){//do change
                                	right.append("," +marketPlaceLinkId);
                                }
                                
                            	List<Object> lstClientSector = clientService.getClientSector(clientBean.getClientId()); 
                                int sectorId = lstClientSector.size() > 0 ? (Integer)lstClientSector.get(0) : 0;
                            	if(sectorId == 1 || sectorId == 2 || sectorId == 3){
                            		right.append("," +4507);
                            	}
                            	
                                right.append(",");
                                sessionBean.setRights(right.toString());
                            }
                        }
                    }
                    sessionBean.setTrackLoginId(-1);
                    //Set the mail unread count
        			if(sessionBean.getUserId()!=0){
        				List<Object[]> inboxCountDetails=mailBoxService.getInboxCount(sessionBean.getUserId(),clientBean.getClientId(),sessionBean.getUserTypeId());
        				if(inboxCountDetails!=null && !inboxCountDetails.isEmpty()){
        					for(Object[] data: inboxCountDetails){
        						if(data[1].toString().equalsIgnoreCase("inbox")){
        							   sessionBean.setUnReadCount((Long)data[2]);
        							   break;
        						}
        					}
        				}
        			}
                    //Ended
        			
        			 if(clientBean.getIsDIYClient() == 1){
                     	int isEmailVeriReq = sessionBean.getUserTypeId() == 2 ? clientService.getBidderRegistrationVerifiedBy(abcUtility.getSessionClientId(request)):sessionBean.getUserTypeId() == 3 ? clientService.getOfficerRegistrationVerifiedBy(abcUtility.getSessionClientId(request)):0; 	
                     	if(tblUserLogin.getIsEmailVerified() == 0 && isEmailVeriReq == 1)
                     	{
                     		response.addCookie(new Cookie("IsEmailVerifiedForDIY", "1"));
                     	}
                     }
        			
                    if (sessionBean.getUserTypeId() == 2) {
                        clientRegWorkflowId = manageBidderService.getBidderWorkflowId(clientId, sessionBean.getUserId());
                        bidderCstatus=manageBidderService.getBidderCstatus(clientBean.getClientId(), sessionBean.getUserId());
                        sessionBean.setCompanyId(loginService.getCompanyId(sessionBean.getUserId(), clientBean.getClientId()));
                    }
                    if(bidderCstatus==1){
                    	int isGstRequired = (Integer)clientService.getClientField(clientId, "isGSTRequired");
                    	if(isGstRequired==1){
                    		Object[] obj = manageBidderService.getGstFields("TblBidderGstDetails", sessionBean.getUserId(),clientId ,"gstDetailId,panNo");
                    		if(obj==null  && commonService.getCountryIdByCompanyId(sessionBean.getCompanyId())==countryId){
                    			isGstEntered = false;
                    		}
                    	}
                    }
                    sessionBean.setCountryId(commonService.getCountryIdByCompanyId(sessionBean.getCompanyId()));
                    if ((clientRegWorkflowId != 0 && clientRegWorkflowId != 9) || pkiRequired) {
                        request.getSession().setAttribute(TEMPSESSIONOBJECT, sessionBean);
                    } else {
                        request.getSession().setAttribute(SESSIONOBJECT, sessionBean);
                    }
                    bean = sessionBean;
                    if (tblUserLogin.getIsFirstLogin() == 1) {
                        isFirstLogin = true;
                    } else {
                        loginSuccess = true;
                    }
                    loginService.updateLoginStatus(0, false, tblUserLogin.getUserId());
                    trackLogin.setRemark("Login Success");
                    trackLogin.setCstatus(1);
                    trackLogin.setUserDetailId(sessionBean.getUserDetailId());
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTime(tblUserLogin.getPasswordUpdatedOn());
                    calendar.add(Calendar.DAY_OF_MONTH, passValidity);
                    serverDate = commonService.getServerDateTime();
                    isChngPass = calendar.getTime().before(serverDate);
                    
                    // Start - Task list reminder : purvesh
                    setTaskListData(tblUserLogin.getUserId(),clientBean.getClientId(),request);
                    // End - Task list reminder : purvesh
                    
                    //Start - Lipi 
                    //Dump user in SSO from Local - not changed the pass
                    if(CommonUtility.isSSOEnabled(request)){
                    	wSCheckAvailService.dumpUserWithChngPwd(tblUserLogin.getUserId(),clientBean.getClientId(),sessionBean.getUserTypeId(),false);
                    }
                    //End - Lipi
                    if(request.getSession().getAttribute("isDRT") == null){
                        List sectorList = clientService.getClientSector(clientBean.getClientId());
                        boolean isDRT = false;
                        boolean isBank = false;
                        boolean isSarfaesi = false;
                        for(Object obj : sectorList){
                            if(obj.equals(1)){
                                isDRT = true;
                            }else if(obj.equals(2)){
                                isSarfaesi = true;
                            }else if(obj.equals(3)){
                                isBank = true;
                            }
                        }
                        request.getSession().setAttribute("sectorList",sectorList);
                        request.getSession().setAttribute("isDRT", isDRT);
                        request.getSession().setAttribute("isBank", isBank);
                        request.getSession().setAttribute("isSarfaesi", isSarfaesi);
                    }
                    
                } else {
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "Your login Account has been locked because of " + failedAttempt + " consecutive failed Login attempts , please click on Forgot Password Link");
                    trackLogin.setRemark("Failed Login Attempt Exceeded");
                    trackLogin.setCstatus(0);
                }

                loginService.addTrackLogin(trackLogin);
                if (bean != null && bean.getTrackLoginId() == -1) {
                    bean.setTrackLoginId(trackLogin.getTrackLoginId());
                    if ((bean.getUserTypeId()==2 && clientRegWorkflowId != 9) || pkiRequired) {
                        request.getSession().removeAttribute(TEMPSESSIONOBJECT);
                        request.getSession().setAttribute(TEMPSESSIONOBJECT, bean);
                    } else {
                        TblSession tblSession = new TblSession();
                        tblSession.setCertId("0");
                        tblSession.setLoginDate(serverDate != null ? serverDate : commonService.getServerDateTime());
                        tblSession.setLogoutDate(serverDate != null ? serverDate : commonService.getServerDateTime());
                        tblSession.setJSessionId(request.getSession().getId());
                        tblSession.setTblTrackLogin(trackLogin);
                        loginService.addSession(tblSession);
                        request.getSession().removeAttribute(SESSIONOBJECT);
                        request.getSession().setAttribute(SESSIONOBJECT, bean);
                    }
                }
                /*if(!pkiRequired){
                 SyncSessionRegistry();
                 }*/
               
            }
        } catch (Exception ex) {
            tblUserLogin = null;
            loginSuccess = false;
            request.getSession().removeAttribute(TEMPSESSIONOBJECT);
            return exceptionHandlerService.writeLog(ex);
        } finally {
            if (bean != null) {
                auditTrailService.makeAuditTrail(new TblAuditTrail(request.getRequestURL().toString(), bean.getTrackLoginId()), loginLink,submitLoginAudit, 0, tblUserLogin != null ? tblUserLogin.getUserId() : 0);
            }
        }
        //TODO : Use string variable to assign page name instead of multiple returns.
        String pageName = "redirect:/loginfailed";
        if (loginSuccess){
        if (!userName.matches("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9\\-\\_]+(\\.[A-Za-z0-9\\-\\_]+)*(\\.[A-Za-z0-9\\-\\_]{2,})$")){
                if (request.getSession().getAttribute(SESSIONOBJECT)!= null) {
                    request.getSession().setAttribute(TEMPSESSIONOBJECT, request.getSession().getAttribute(SESSIONOBJECT));
                    request.getSession().removeAttribute(SESSIONOBJECT);
                }                
                pageName = "redirect:/updateloginid";
        }else if(tblUserLogin.getIsMigrated()==1){
        	if (request.getSession().getAttribute(SESSIONOBJECT)!= null) {
                request.getSession().setAttribute(TEMPSESSIONOBJECT, request.getSession().getAttribute(SESSIONOBJECT));
                request.getSession().removeAttribute(SESSIONOBJECT);
            } 
        	pageName = "redirect:/updatepassworddtls";
        }else{
        	if(clientBean.getClientId() == SMclientId){
        		if (isFirstLogin && (userTypeId == 2 && clientRegWorkflowId==1)) {
        			 if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
                         request.getSession().setAttribute(TEMPSESSIONOBJECT, request.getSession().getAttribute(SESSIONOBJECT));
                         request.getSession().removeAttribute(SESSIONOBJECT);
                     }
                     pageName = "redirect:/changepasswordonlogin";
        		}else if(isFirstLogin && (userTypeId == 2 && clientRegWorkflowId==9)){
        			redirectAttributes.addAttribute("clientId", clientBean.getClientId());
                	redirectAttributes.addAttribute("userId", tblUserLogin.getUserId());
                	pageName = "redirect:/bidderregistrationforsm";
        		}
        	}else{
        		
        		if (isFirstLogin && ((userTypeId == 2 && clientRegWorkflowId==9)||(clientRegWorkflowId==0))) { //Changes BugId:#31487 and Related BugId:#29618
        			if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
        				request.getSession().setAttribute(TEMPSESSIONOBJECT, request.getSession().getAttribute(SESSIONOBJECT));
        				request.getSession().removeAttribute(SESSIONOBJECT);
        			}
        			pageName = "redirect:/changepasswordonlogin";
        		} else {
        			if (isChngPass) {
        				if (request.getSession().getAttribute(SESSIONOBJECT) != null) {
        					request.getSession().setAttribute(TEMPSESSIONOBJECT, request.getSession().getAttribute(SESSIONOBJECT));
        					request.getSession().removeAttribute(SESSIONOBJECT);
        				}
        				redirectAttributes.addFlashAttribute("notMsg", "Your Password validity has expired");
        				pageName = "redirect:/chngpassword";
        			} else {
        				int bidderRegVerifiedBy=clientService.getBidderRegistrationVerifiedBy(clientId);
        				if(userTypeId == 2 && clientRegWorkflowId == 3 && (bidderRegVerifiedBy == 3 || bidderRegVerifiedBy == 2)&& tblUserLogin.getIsMobileNoVerified() == 0){
            				//Bidder verification By  Mobile Number
        					redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_msg_otp_sent_registered_mobileno");
        					pageName = "redirect:/registrationOTPGenerate/0/"+encryptDecryptUtils.encrypt(String.valueOf(tblUserLogin.getUserId()));
        				}
        				else if (clientRegWorkflowId != 0 && clientRegWorkflowId != 9) {
        					switch (clientRegWorkflowId) {
        					case 4: //Certificate Mapping
        						pageName = "redirect:/certimap";
        						break;
        					case 5: //Registation Documents
        						pageName = "redirect:/uploaddocument";
        						break;
        					case 6: //Registration Charges
        						pageName = "redirect:/bidderregcharges";//pending
        						break;
                            case 7: //GST details
								pageName = "redirect:/gstDetails/0";//pending
								break;	
                            case 8: //Finish Registration
                            	pageName = "redirect:/finishregistration";
                            	break;
                        }
                    }
                    else if(bidderCstatus == 6 && clientRegWorkflowId == 9)
                    {
                        pageName = "redirect:/eauction/bidder/editbidder/"+tblUserLogin.getUserId()+encryptDecryptUtils.generateRedirect("eauction/bidder/editbidder/"+tblUserLogin.getUserId(), request);
                    }
                    else {
                        if (pkiRequired) {
                            pageName = "redirect:/certimap";
                        }else if(!isGstEntered){
                        	pageName = "redirect:/gstDetails/0";
                        }else {
                            pageName = getRedirectPage(request);
                        }
                    }
                }
            }
            TblLoginHistory tblLoginHistory=new TblLoginHistory();
            tblLoginHistory.setTblTrackLogin(new TblTrackLogin(bean.getTrackLoginId()));
            tblLoginHistory.setRemark("");
            tblLoginHistory.setCstatus(1);
            try {
				loginService.addLoginHistory(tblLoginHistory);
			} catch (Exception e) {
				return exceptionHandlerService.writeLog(e);
			}
        }}
        } else {
            return pageName;
        }
        return pageName;
    }

    /**
     * To set task list data
     * 
     * @author purvesh
     * @param request
     * @throws Exception
     */
    private void setTaskListData(int userId, int clientId, HttpServletRequest request) throws Exception {
    	String taskLists = new String();
        String currentTask = "";
        List<Object[]> taskListData = mailBoxService.getTaskListData(userId, clientId);
        request.getSession().removeAttribute("taskLists");
        request.getSession().removeAttribute("isFirstTime");
        if(taskListData!=null && !taskListData.isEmpty()) {
        	for(Object[] task : taskListData) {
        		currentTask="";
        		currentTask= task[0] +"|~|"+ task[1] +"|~|"+ task[2] +"|~|"+ CommonUtility.convertTimezoneToClientTimezone(task[3]) +"|~|"+ task[4]+"|~|"+ task[5]+"|~|"+ task[6]+ "|~|"+ CommonUtility.convertTimezoneToClientTimezone(task[7])+"|#|";
        		taskLists+=currentTask; 	
          	}       	        			 
        	request.getSession().setAttribute("taskLists", taskLists);        	 	  
        	request.getSession().setAttribute("isFirstTime", true);
        	
        }
    }
    @RequestMapping(value = "/certimap", method = RequestMethod.GET)
    public String showCerti(@ModelAttribute CertiDataBean certiDataBean, ModelMap model, HttpServletRequest req) {
        String pageName = "redirect:/loginfailed";
        if (req.getSession().getAttribute(TEMPSESSIONOBJECT) != null) {
            SessionBean sessionBean = (SessionBean) req.getSession().getAttribute(TEMPSESSIONOBJECT);
            ClientBean clientBean = (ClientBean) req.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            boolean flag = false;
            try {            	
            	model.addAttribute("attachCerti", false);
            	flag=loginService.setCertiDetails(sessionBean, clientBean, model);//all data are set in this method
            	TblClient tempClient=clientService.getClientById(clientBean.getClientId());
            	model.addAttribute("certificateClass",tempClient.getCertificateClass());
            	model.addAttribute("isDcVerificationRequired",clientBean.getIsDcVerificationRequired());
            	model.addAttribute("isRegistrationLinkHidden", clientService.isRegistrationLinkHidden(clientBean.getClientId(), hideRegistrationLinkId, 1));
            	int clientRegWorkflowIdbidder = 0;
                if(sessionBean.getUserTypeId() == 2 )
                {
                	model.addAttribute("clientRegWorkflowId",manageBidderService.getBidderWorkflowId(clientBean.getClientId(), sessionBean.getUserId()));
    			}
                
            	/* CSP BEFORE LOGIN */
                String userAgent = req.getHeader("user-agent");
            	if(clientBean.getIsSigner() == 1 && userAgent.contains("Trident")) {
            		clientBean.setIsSigner(0);
            	}
            } catch (Exception e) {
                return exceptionHandlerService.writeLog(e);
            } finally {
                auditTrailService.makeAuditTrail(req.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), certiMapLink, showCertiAudit, 0, sessionBean.getUserId());
            }
            if (flag) {
                pageName = "CertiMap";
            }
        }
        return pageName;
    }
    //CR : 25825 Keval soni For RCI Specific
    private int getRegWorkflowIdForInternationBidder(int clientId,int userId,int curRegistrationWorkflowId){
    	int registrationWorkflowId = curRegistrationWorkflowId;
    	if(rciClientIds != null && !"".equals(rciClientIds)){
			String[] rciIds = rciClientIds.split(",");
			if(rciIds.length != 0){
				for(int i = 0;i<rciIds.length;i++){
					if(!"".equals(rciIds[i])){
						if(clientId == Integer.parseInt(rciIds[i])){
							int clientCountryId=clientService.getCountryIdByClientId(clientId);
							int bidderCountryId=clientService.getBidderCountryIdByUserId(userId);
							if(clientCountryId != bidderCountryId && registrationWorkflowId == 5){
								registrationWorkflowId=8;
								break;
							}
						}
					}
				}
			}
		}
    	return registrationWorkflowId;
    }
    @RequestMapping(value = "/certiLogin", method = RequestMethod.POST)
    public String certiLogin(@ModelAttribute CertiDataBean certiDataBean, ModelMap model, RedirectAttributes redirectAttributes, HttpServletRequest request) throws Exception {
        boolean loginSuccess = false;
        boolean isSignOk = false;
        boolean isEncrOk = false;
        boolean iscertprob = false;
        boolean isDualCerti = false;
        boolean isEncryptionVerified = false;
        boolean isSigningVerified = false;
        SessionBean bean = null;
        ClientBean clientBean = null;
        int certIdSign = 0;
        int certIdEncr = 0;
        int registrationWorkflowId = 0;
        final String certError = "certError";
        int loginHisStatus=0;
        String attach = null;
        if (request.getSession().getAttribute(TEMPSESSIONOBJECT) != null || (certiDataBean.getHdAttachCerti().equalsIgnoreCase("true") && request.getSession().getAttribute(SESSIONOBJECT) != null)) {        	
            bean = (SessionBean) (request.getSession().getAttribute(TEMPSESSIONOBJECT)==null ? request.getSession().getAttribute(SESSIONOBJECT) : request.getSession().getAttribute(TEMPSESSIONOBJECT));
            if (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) {
                clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
                isDualCerti = (clientBean.getIsDualCerti() == 2);
            }
            String key = certiDataBean.getSignedData();
            attach = certiDataBean.getHdattach();
            Object[] data = null;
            if (bean.getCertId() == null || bean.getCertId().isEmpty()) {
                if (StringUtils.hasLength(certiDataBean.getSkpPublicKey_encrypt())) {
                    isDualCerti = true;//if Encryption certifcate data are post from page than dual
                } else {
                    isDualCerti = false;
                }
            }
            int clientRegWorkflowIdbidder = 0;
            if(bean.getUserTypeId() == 2 )
            {
				clientRegWorkflowIdbidder = manageBidderService.getBidderWorkflowId(clientBean.getClientId(), bean.getUserId());
			}
            
            if (isDualCerti) {
                if (certiDataBean.getSkpPublicKey_sign().contains("'") || certiDataBean.getSkpPublicKey_sign().contains("\"")
                        || certiDataBean.getSkpSerial_sign().contains("'") || certiDataBean.getSkpSerial_sign().contains("\"")
                        || certiDataBean.getSkpPublicKey_encrypt().contains("'") || certiDataBean.getSkpPublicKey_encrypt().contains("\"")
                        || certiDataBean.getSkpSerial_encrypt().contains("'") || certiDataBean.getSkpSerial_encrypt().contains("\"")) {
                    iscertprob = true;
                    redirectAttributes.addFlashAttribute(certError, "redirect_error_certproper");
                    loginHisStatus=7;
                } else {
                    try {
                        Date serverDate = commonService.getServerDateTime();
                        if (key != null) {
                            data = signerVerify.verify(key);//Verify Data to get Key
                            if (data[1] == null || !(Boolean) data[1] || data[2] == null || !data[2].toString().equals(request.getSession().getAttribute("CERTI_RANDOMNO")) || data[0] == null) {
                                iscertprob = true;
                                redirectAttributes.addFlashAttribute(certError, "redirect_error_certproper");
                                loginHisStatus=7;
                            }
                        }else{
                            if (attach != null && attach.equals("yes")) {
                                iscertprob = false;
                            }     
                        }
                        if(!iscertprob){
                                isSignOk = !commonService.checkCertificateRevoked(certiDataBean.getSkpSerial_sign(),certiDataBean.getSkpIssuer_sign());//Check if Sign Certificate is revoked
                                isEncrOk = !commonService.checkCertificateRevoked(certiDataBean.getSkpSerial_encrypt(),certiDataBean.getSkpIssuer_encrypt());//Check if Encr Certificate is revoked
                                if (isSignOk && isEncrOk) {
                                    isSignOk = commonService.checkValidIssuer(certiDataBean.getSkpIssuer_sign());//Check if Sign Certificate is from Valid Issuer
                                    isEncrOk = commonService.checkValidIssuer(certiDataBean.getSkpIssuer_encrypt());//Check if Encr Certificate is from Valid Issuer
                                    if (isSignOk && isEncrOk) {
                                        if (!commonService.checkAttachedCertExpired(bean.getUserId())) {//Check if user certificate are expired or not
                                            List<Object[]> list = loginService.getUserPublicKey(bean.getUserId(),clientBean.getIsDualCerti());
                                            if (list.size() == 2) {//Both certificate already available in DB
                                                isSignOk = list.get(0)[0].toString().equals(certiDataBean.getSkpPublicKey_sign());//Check if Sign public Key match with DB
                                                isEncrOk = list.get(1)[0].toString().equals(certiDataBean.getSkpPublicKey_encrypt());//Check if Encr public Key match with DB
                                                if (isSignOk && isEncrOk) {
                                                	
                                                	// Fetch certificate Verified or not from the database
                                                	
                                                	if(list.get(0)[4].toString().equals("1"))
                                                	{
                                                		isSigningVerified = true;	
                                                	}
                                                	if(list.get(1)[4].toString().equals("1"))
                                                	{
                                                		isEncryptionVerified = true;	
                                                	}
                                                	
                                                	// Check if Digital Certificate is Verified or Not
                                                    if(bean.getUserTypeId() == 2 && clientBean.getIsDcVerificationRequired() ==1 && !isSigningVerified && clientRegWorkflowIdbidder==9)
                                                    {
                                                        redirectAttributes.addFlashAttribute(certError, "cert_notverified_certificate");
                                                        iscertprob = true;
                                                        loginHisStatus = 10;
                                                        List<Object[]> tempList = loginService.getUserPublicKey(bean.getUserId(),clientBean.getIsDualCerti());
                                                        
                                                        // Maintain Record in Login History
                                            	        TblLoginHistory tblLoginHistory=new TblLoginHistory();
                                            	        tblLoginHistory.setTblTrackLogin(new TblTrackLogin(bean.getTrackLoginId()));
                                            	        String remarks="Signing digital certificate is not verified";
                                            	        tblLoginHistory.setRemark(remarks);
                                            	        tblLoginHistory.setCstatus(loginHisStatus);
                                            	        try 
                                            	        {
                                            	        	loginService.addLoginHistory(tblLoginHistory);
                                            			} 
                                            	        catch (Exception e)
                                            	        {
                                            				return exceptionHandlerService.writeLog(e);
                                            			}
                                                        
                                                        //Audit Trail Report
                                                        if (tempList.size() == 2) 
                                                        {//Both certificate already available in DB
                                                            certIdSign = (Integer) tempList.get(0)[1];
                                                            certIdEncr = (Integer) tempList.get(1)[1];
                                                        }
//                                                        auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), certiMapLink, iscertprob ? certiLoginFailAudit :  certiLoginAudit, 0, certIdSign);
//                                                    	return "redirect:/certimap";
                                                    }
                                                	else
                                                	{
                                                    	if (certiDataBean.getHdAttachCerti().equalsIgnoreCase("true")) {
                                                            certIdSign = (Integer) list.get(0)[1];
                                                            certIdEncr = (Integer) list.get(1)[1];
                                                            bean.setCertId(certIdSign + "," + certIdEncr);
                                                        }
                                                    	else if(certiDataBean.getHdAttachCerti().equalsIgnoreCase("false")){
                                                                boolean allowLogin = true;
                                                                if(bean.getUserTypeId()==2 && manageBidderService.getBidderWorkflowId(clientBean.getClientId(), bean.getUserId())!=9){
                                                                    registrationWorkflowId = manageBidderService.getClientRegWorkflowId(clientBean.getClientId(), 4);
                                                                    if(registrationWorkflowId!=9){
                                                                    	//For CR #25825 - Keval Soni
                                                                    	registrationWorkflowId = getRegWorkflowIdForInternationBidder(clientBean.getClientId(),bean.getUserId(),registrationWorkflowId);
                                                                    	int companyId = Integer.valueOf((commonService.getCompanyIdByUserId(bean.getUserId()).toString()));
                                                                    	if(registrationWorkflowId==7 && commonService.getCountryIdByCompanyId(companyId)!=countryId){
                                                                    		registrationWorkflowId = 8;
                                                                		}
                                                                        manageBidderService.updateRegistrationWorkflowInBidderStatus(clientBean.getClientId(), bean.getUserId(), registrationWorkflowId==8 ? 9 : registrationWorkflowId);
                                                                        allowLogin = false;
                                                                    }
                                                                }                                                            
                                                                if(allowLogin){
                                                                    certIdSign = (Integer) list.get(0)[1];
                                                                    certIdEncr = (Integer) list.get(1)[1];
                                                                    bean.setCertId(certIdSign + "," + certIdEncr);
                                                                    request.getSession().removeAttribute(TEMPSESSIONOBJECT);
                                                                    request.getSession().setAttribute(SESSIONOBJECT, bean);

                                                                    TblSession tblSession = new TblSession();
                                                                    tblSession.setCertId(bean.getCertId());
                                                                    tblSession.setLoginDate(serverDate);
                                                                    tblSession.setLogoutDate(serverDate);
                                                                    tblSession.setJSessionId(request.getSession().getId());
                                                                    tblSession.setTblTrackLogin(new TblTrackLogin(bean.getTrackLoginId()));
                                                                    loginService.addSession(tblSession);
                                                                }
    	                                                    loginSuccess = true;
                                                    	}
                                                	}
                                                } else {
                                                    iscertprob = true;
                                                    if (!isEncrOk && !isSignOk) {
                                                        redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
                                                        loginHisStatus=8;
                                                    } else {
                                                        if (!isSignOk) {
                                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertalreadymap");
                                                            loginHisStatus=8;
                                                        }
                                                        if (!isEncrOk) {
                                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_enccertalreadymap");
                                                            loginHisStatus=8;
                                                        }
                                                    }
                                                }
                                            }else if(list.isEmpty()){//None certificate available in DB.Both Certificate entry is done      
                                                List<TblCertificate> certificates = new ArrayList<TblCertificate>();
                                                List<TblUserCertificate> userCertificates = new ArrayList<TblUserCertificate>();
                                                List<TblCertUnMapHistory> certUnMapHistorys = new ArrayList<TblCertUnMapHistory>();
                                                SimpleDateFormat format = new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");
                                                String datesplitSign[] = certiDataBean.getSkpValidTo_sign().split(" ");
                                                String dateSign = datesplitSign[2] + "/" + datesplitSign[1] + "/" + datesplitSign[5] + " " + datesplitSign[3];
                                                Date signToSign = format.parse(dateSign);
                                                datesplitSign = certiDataBean.getSkpValidFrom_sign().split(" ");
                                                dateSign = datesplitSign[2] + "/" + datesplitSign[1] + "/" + datesplitSign[5] + " " + datesplitSign[3];
                                                Date signFrom = format.parse(dateSign);
                                                if (signToSign.after(serverDate)) {
                                                    List<Object> signList = loginService.getCertiByPublicKey(certiDataBean.getSkpPublicKey_sign());
                                                    if (signList.isEmpty()) {
                                                        TblCertificate certificate = new TblCertificate();
                                                        certificate.setAlias(certiDataBean.getSkpAlias_sign());
                                                        certificate.setEndDate(signToSign);
                                                        certificate.setIssuer(certiDataBean.getSkpIssuer_sign());
                                                        certificate.setPublicKey(certiDataBean.getSkpPublicKey_sign());
                                                        certificate.setSerialNumber(certiDataBean.getSkpSerial_sign());
                                                        certificate.setStartDate(signFrom);
                                                        certificate.setSubject(certiDataBean.getSkpSubject_sign());
                                                        certificate.setKeyUsage(certiDataBean.getSkpPublicKey_sign().equals(certiDataBean.getSkpPublicKey_encrypt()) ? 0 : 1);
                                                        
                                                        
                                                        TblUserCertificate userCertificate = new TblUserCertificate();
                                                        userCertificate.setTblCertificate(certificate);
                                                        userCertificate.setTblClient(new TblClient(clientBean.getClientId()));
                                                        userCertificate.setTblUserLogin(new TblUserLogin(bean.getUserId()));
                                                        userCertificate.setCreatedBy(bean.getUserId());
                                                        userCertificate.setIsDualCert(2);
                                                        userCertificate.setKeyUsage(1);
                                                        
                                                        TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
                                                        tblCertUnMapHistory.setCreatedBy(bean.getUserId());
                                                        tblCertUnMapHistory.setIsMapped(1);
                                                        tblCertUnMapHistory.setTblCertificate(certificate);
                                                        tblCertUnMapHistory.setKeyUsage(1);
                                                        tblCertUnMapHistory.setIsDualCert(2);
                                                        tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
                                                        tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(bean.getUserId()));
                                                        tblCertUnMapHistory.setRemark("");
                                                        certificates.add(certificate);
                                                        userCertificates.add(userCertificate);
                                                        certUnMapHistorys.add(tblCertUnMapHistory);

                                                    }else{
                                                        certIdSign = (Integer)signList.get(0);
                                                        if(loginService.isCertMappedToUser(certIdSign))
                                                        {
                                                        	redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
                                                            loginHisStatus=8;
                                                            iscertprob = true;
                                                        }
                                                        else
                                                        {
	                                                        TblUserCertificate userCertificate = new TblUserCertificate();
	                                                        userCertificate.setTblCertificate(new TblCertificate(certIdSign));
	                                                        userCertificate.setTblClient(new TblClient(clientBean.getClientId()));
	                                                        userCertificate.setTblUserLogin(new TblUserLogin(bean.getUserId()));
	                                                        userCertificate.setCreatedBy(bean.getUserId());
	                                                        userCertificate.setIsDualCert(2);
	                                                        userCertificate.setKeyUsage(1);
	                                                        
	                                                        
	                                                        TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
	                                                        tblCertUnMapHistory.setCreatedBy(bean.getUserId());
	                                                        tblCertUnMapHistory.setIsMapped(1);
	                                                        tblCertUnMapHistory.setKeyUsage(1);
	                                                        tblCertUnMapHistory.setIsDualCert(2);
	                                                        tblCertUnMapHistory.setTblCertificate(new TblCertificate(certIdSign));
	                                                        tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
	                                                        tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(bean.getUserId()));
	                                                        tblCertUnMapHistory.setRemark("");
	                                                        certificates.add(null);
	                                                        userCertificates.add(userCertificate);
	                                                        certUnMapHistorys.add(tblCertUnMapHistory);
                                                        }
                                                    }
                                                } else {
                                                    redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertexpired");
                                                    loginHisStatus = 5;
                                                    iscertprob = true;
                                                    loginHisStatus=8;
                                                }
                                                String datesplit[] = certiDataBean.getSkpValidTo_encrypt().split(" ");
                                                String date = datesplit[2] + "/" + datesplit[1] + "/" + datesplit[5] + " " + datesplit[3];
                                                Date encrTo = format.parse(date);
                                                datesplit = certiDataBean.getSkpValidFrom_encrypt().split(" ");
                                                date = datesplit[2] + "/" + datesplit[1] + "/" + datesplit[5] + " " + datesplit[3];
                                                Date encrFrom = format.parse(date);
                                                if (encrTo.after(serverDate)) {
                                                    List<Object> encList = loginService.getCertiByPublicKey(certiDataBean.getSkpPublicKey_encrypt());
                                                    if (encList.isEmpty() && !certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign())) {
                                                        TblCertificate certificate = new TblCertificate();
                                                        certificate.setAlias(certiDataBean.getSkpAlias_encrypt());
                                                        certificate.setEndDate(encrTo);
                                                        certificate.setIssuer(certiDataBean.getSkpIssuer_encrypt());
                                                        certificate.setPublicKey(certiDataBean.getSkpPublicKey_encrypt());
                                                        certificate.setSerialNumber(certiDataBean.getSkpSerial_encrypt());
                                                        certificate.setStartDate(encrFrom);
                                                        certificate.setSubject(certiDataBean.getSkpSubject_encrypt());
                                                        certificate.setKeyUsage(2);
                                                        
                                                        TblUserCertificate userCertificate = new TblUserCertificate();
                                                        userCertificate.setTblCertificate(certificate);
                                                        userCertificate.setTblClient(new TblClient(clientBean.getClientId()));
                                                        userCertificate.setTblUserLogin(new TblUserLogin(bean.getUserId()));
                                                        userCertificate.setCreatedBy(bean.getUserId());
                                                        userCertificate.setIsDualCert(2);
                                                        userCertificate.setKeyUsage(2);
                                                        
                                                        TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
                                                        tblCertUnMapHistory.setCreatedBy(bean.getUserId());
                                                        tblCertUnMapHistory.setIsMapped(1);
                                                        tblCertUnMapHistory.setKeyUsage(2);
                                                        tblCertUnMapHistory.setIsDualCert(2);
                                                        tblCertUnMapHistory.setTblCertificate(certificate);
                                                        tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
                                                        tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(bean.getUserId()));
                                                        tblCertUnMapHistory.setRemark("");
                                                        certificates.add(certificate);
                                                        userCertificates.add(userCertificate);
                                                        certUnMapHistorys.add(tblCertUnMapHistory);

                                                    }else{                                                        
                                                        certIdEncr = encList.isEmpty() && certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign()) ? certIdSign : (Integer)encList.get(0);
                                                        if(loginService.isCertMappedToUser(certIdEncr))
                                                        {
                                                        	redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
                                                            loginHisStatus=8;
                                                            iscertprob = true;
                                                        }
                                                        else
                                                        {
	                                                        TblUserCertificate userCertificate = new TblUserCertificate();
	                                                        userCertificate.setTblCertificate(encList.isEmpty() && certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign()) ? certificates.get(0) : new TblCertificate(certIdEncr));
	                                                        userCertificate.setTblClient(new TblClient(clientBean.getClientId()));
	                                                        userCertificate.setTblUserLogin(new TblUserLogin(bean.getUserId()));
	                                                        userCertificate.setCreatedBy(bean.getUserId());
	                                                        userCertificate.setIsDualCert(2);
	                                                        userCertificate.setKeyUsage(2);
	                                                        
	                                                        
	                                                        TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
	                                                        tblCertUnMapHistory.setCreatedBy(bean.getUserId());
	                                                        tblCertUnMapHistory.setIsMapped(1);
	                                                        tblCertUnMapHistory.setKeyUsage(2);
	                                                        tblCertUnMapHistory.setIsDualCert(2);
	                                                        tblCertUnMapHistory.setTblCertificate(encList.isEmpty() && certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign()) ? certificates.get(0) : new TblCertificate(certIdEncr));
	                                                        tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
	                                                        tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(bean.getUserId()));
	                                                        tblCertUnMapHistory.setRemark("");
	                                                        certificates.add(null);
	                                                        userCertificates.add(userCertificate);
	                                                        certUnMapHistorys.add(tblCertUnMapHistory);
                                                        }
                                                    }
                                                } else {
                                                    redirectAttributes.addFlashAttribute(certError, "redirect_error_enccertexpired");
                                                    loginHisStatus = 5;
                                                    loginHisStatus=8;
                                                    iscertprob = true;
                                                }                                                
                                                try{
                                                	 if(!iscertprob){
                                                		 iscertprob = !loginService.addUserCertificate(certificates, userCertificates, certUnMapHistorys);
                                                	 }
                                                }catch(CertificateException e){
                                                    iscertprob = true;
                                                }
                                                if(!iscertprob)
                                                {
                                                	if(certificates.size()==2){
                                                        if(certificates.get(0)!=null){                                                            
                                                            wSCheckAvailService.RegisterCertificate(certificates.get(0),bean.getUserName(),certificates.get(0).getKeyUsage()==0?1:0,certificates.get(0).getKeyUsage()==0?1:1,"Map",bean.getUserId(),clientBean.getClientId());
                                                        }
                                                        if(certificates.get(1)!=null){
                                                            wSCheckAvailService.RegisterCertificate(certificates.get(1),bean.getUserName(),1,0,"Map",bean.getUserId(),clientBean.getClientId());                                                            
                                                        }
                                                    }
                                                    sendAttachDcMail(bean, clientBean.getClientId(), request, certificates);
                                                }
                                                if(bean.getUserTypeId() == 2 && clientBean.getIsDcVerificationRequired() ==1 && !iscertprob && clientRegWorkflowIdbidder==9)
                                                {
                                                	redirectAttributes.addFlashAttribute(certError, "cert_notverified_certificate");
                                                    iscertprob = true;
                                                    loginHisStatus = 10;
                                                }
                                                else if (iscertprob) {
                                                    redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
                                                    loginHisStatus = 8;
                                                    iscertprob = true;
                                                }
                                                if (!iscertprob) {
                                                    certIdSign = certificates.size()==2 && certificates.get(0)!=null ? certificates.get(0).getCertId() : certIdSign;
                                                    certIdEncr = certificates.size()==2 && certificates.get(1)!=null ? certificates.get(1).getCertId() : (certIdEncr==0 ? certIdSign : certIdEncr);
// Sending Mail on Attach Code                                                    
                                                    if (certiDataBean.getHdAttachCerti().equalsIgnoreCase("false")) {
                                                        if (bean.getUserTypeId() != 2) {
                                                            bean.setCertId(certIdSign + "," + certIdEncr);
                                                            request.getSession().removeAttribute(TEMPSESSIONOBJECT);
                                                            request.getSession().setAttribute(SESSIONOBJECT, bean);

                                                            TblSession tblSession = new TblSession();
                                                            tblSession.setCertId(bean.getCertId());
                                                            tblSession.setLoginDate(serverDate);
                                                            tblSession.setLogoutDate(serverDate);
                                                            tblSession.setJSessionId(request.getSession().getId());
                                                            tblSession.setTblTrackLogin(new TblTrackLogin(bean.getTrackLoginId()));
                                                            loginService.addSession(tblSession);
                                                        } else {
                                                            int bidderRegWorkflowId = manageBidderService.getBidderWorkflowId(clientBean.getClientId(), bean.getUserId());
                                                            if(bidderRegWorkflowId!=9){
                                                                registrationWorkflowId = manageBidderService.getClientRegWorkflowId(clientBean.getClientId(), 4);
                                                                //For CR #25825 - Keval Soni
                                                            	registrationWorkflowId = getRegWorkflowIdForInternationBidder(clientBean.getClientId(),bean.getUserId(),registrationWorkflowId);
                                                            	int companyId = Integer.valueOf((commonService.getCompanyIdByUserId(bean.getUserId()).toString()));
                                                            	if(registrationWorkflowId==7 && commonService.getCountryIdByCompanyId(companyId)!=countryId){
                                                            		registrationWorkflowId = 8;
                                                        		}
                                                                manageBidderService.updateRegistrationWorkflowInBidderStatus(clientBean.getClientId(), bean.getUserId(), registrationWorkflowId==8 ? 9 : registrationWorkflowId);
                                                                if(commonService.getSubUser(bean.getUserId()) && isSubUserDCAutoApproved==1) {
                                                                	int mainBidderCreatedBy=commonService.getMainBidderCreatedBySubBidderId(bean.getUserId(),clientBean.getClientId());
                                                                	int mainBidderVerifiedBy = commonService.getParentBidderVerifiedBy(bean.getUserId());
                                                                	if(commonService.isParentBidderApproved(bean.getUserId(),clientBean.getClientId())){
	                                                                	loginService.verifyDC(bean.getUserId(),1,mainBidderVerifiedBy);
	                                                                	loginService.verifyDC(bean.getUserId(),2,mainBidderVerifiedBy);
	                                                                	URL url = new URL(request.getRequestURL().toString());
	                                                                	List<Object> data1=loginService.getLoginIdByUserId(bean.getUserId());
	                                                                	String emailId="";
	                                                	        		if(data1 != null && !data1.isEmpty()){
	                                                	        			emailId= (String)data1.get(0);
	                                                	        		}
	                                                	        		Map<String,Object> dataMap=new HashMap<String, Object>();
	//                                                	        		dataMap.put("subdomainname", url.getHost());
	                                                	        		dataMap.put("to", emailId);
	                                                	        		dataMap.put("emailId", emailId);
	                                                	        		dataMap.put("ClientName", clientService.getClientNameByClientId(clientBean.getClientId()));
	                                            	        			dataMap.put("SubDomainName", clientService.getClientNameById(clientBean.getClientId()));
	                                            	        			dataMap.put(emailId, emailId);
	                                            	        			String encryptUrlStr = encryptDecryptUtils.encrypt("etender/bidder/tenderlisting/0/");
	                                            	                	String herfStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
	                                            	                	dataMap.put("link", herfStr);
	                                            	                	mailContentUtillity.dynamicMailGeneration("22", String.valueOf(bean.getUserId()), String.valueOf(clientBean.getClientId()),dataMap ,"");
                                                                }
                                                                }
                                                                
                                                            }else{
                                                                bean.setCertId(String.valueOf(certIdSign));
                                                                request.getSession().removeAttribute(TEMPSESSIONOBJECT);
                                                                request.getSession().setAttribute(SESSIONOBJECT, bean);
                                                                TblSession tblSession = new TblSession();
                                                                tblSession.setCertId(bean.getCertId());
                                                                tblSession.setLoginDate(serverDate);
                                                                tblSession.setLogoutDate(serverDate);
                                                                tblSession.setJSessionId(request.getSession().getId());
                                                                tblSession.setTblTrackLogin(new TblTrackLogin(bean.getTrackLoginId()));
                                                                loginService.addSession(tblSession);
                                                                registrationWorkflowId=9;
                                                            }
                                                        }
                                                        loginSuccess = true;
                                                    }else{
                                                            bean.setCertId(certIdSign + "," + certIdEncr);
                                                            request.getSession().removeAttribute(SESSIONOBJECT);
                                                            request.getSession().setAttribute(SESSIONOBJECT, bean);
                                                    }                                                    
                                                }
                                            }else{
                                            	
                                            	if(list.get(0)[3].toString().equals("1"))
                                            	{
                                            		isSignOk = list.get(0)[0].toString().equals(certiDataBean.getSkpPublicKey_sign());//Check if Sign public Key match with DB
                                                    //Sign certificate is available in DB, while Encr certificate is not. Encr certificate entry is done
                                                	if(isSignOk)
                                                	{
                                                		if(list.get(0)[4].toString().equals("1"))
                                                    	{
                                                    		isSigningVerified = true;	
                                                    	}
                                                        TblCertificate certificate = null;
                                                        TblUserCertificate userCertificate = new TblUserCertificate();
                                                        TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
                                                        SimpleDateFormat format = new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");
                                                        String datesplit[] = certiDataBean.getSkpValidTo_encrypt().split(" ");
                                                        String date = datesplit[2] + "/" + datesplit[1] + "/" + datesplit[5] + " " + datesplit[3];
                                                        Date encrTo = format.parse(date);
                                                        datesplit = certiDataBean.getSkpValidFrom_encrypt().split(" ");
                                                        date = datesplit[2] + "/" + datesplit[1] + "/" + datesplit[5] + " " + datesplit[3];
                                                        Date encrFrom = format.parse(date);
                                                        if (encrTo.after(serverDate)) {
                                                            List<Object> encList = loginService.getCertiByPublicKey(certiDataBean.getSkpPublicKey_encrypt());
                                                            if (encList.isEmpty() && !certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign())) {
                                                                certificate = new TblCertificate();
                                                                certificate.setAlias(certiDataBean.getSkpAlias_encrypt());
                                                                certificate.setEndDate(encrTo);
                                                                certificate.setIssuer(certiDataBean.getSkpIssuer_encrypt());
                                                                certificate.setPublicKey(certiDataBean.getSkpPublicKey_encrypt());
                                                                certificate.setSerialNumber(certiDataBean.getSkpSerial_encrypt());
                                                                certificate.setStartDate(encrFrom);
                                                                certificate.setSubject(certiDataBean.getSkpSubject_encrypt());
                                                                certificate.setKeyUsage(2);
                                                                
                                                                userCertificate.setTblCertificate(certificate);
                                                                userCertificate.setTblClient(new TblClient(clientBean.getClientId()));
                                                                userCertificate.setTblUserLogin(new TblUserLogin(bean.getUserId()));
                                                                userCertificate.setCreatedBy(bean.getUserId());
                                                                userCertificate.setIsDualCert(2);
                                                                userCertificate.setKeyUsage(2);
                                                                
                                                                tblCertUnMapHistory.setCreatedBy(bean.getUserId());
                                                                tblCertUnMapHistory.setIsMapped(1);
                                                                tblCertUnMapHistory.setKeyUsage(2);
                                                                tblCertUnMapHistory.setIsDualCert(2);
                                                                tblCertUnMapHistory.setTblCertificate(certificate);
                                                                tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
                                                                tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(bean.getUserId()));
                                                                tblCertUnMapHistory.setRemark("");

                                                            }else{                                                        
                                                                certIdEncr = encList.isEmpty() && certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign()) ? certIdSign : (Integer)encList.get(0);
                                                                if(loginService.isCertMappedToUser(certIdEncr))
                                                                {
                                                                	redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
                                                                    loginHisStatus=8;
                                                                    iscertprob = true;
                                                                }
                                                                else
                                                                {
	                                                                userCertificate.setTblCertificate(encList.isEmpty() && certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign()) ? certificate : new TblCertificate(certIdEncr));
	                                                                userCertificate.setTblClient(new TblClient(clientBean.getClientId()));
	                                                                userCertificate.setTblUserLogin(new TblUserLogin(bean.getUserId()));
	                                                                userCertificate.setCreatedBy(bean.getUserId());
	                                                                userCertificate.setIsDualCert(2);
	                                                                userCertificate.setKeyUsage(2);
	                                                                
	                                                                
	                                                                tblCertUnMapHistory.setCreatedBy(bean.getUserId());
	                                                                tblCertUnMapHistory.setIsMapped(1);
	                                                                tblCertUnMapHistory.setKeyUsage(2);
	                                                                tblCertUnMapHistory.setIsDualCert(2);
	                                                                tblCertUnMapHistory.setTblCertificate(encList.isEmpty() && certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign()) ? certificate : new TblCertificate(certIdEncr));
	                                                                tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
	                                                                tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(bean.getUserId()));
	                                                                tblCertUnMapHistory.setRemark("");
                                                                }
                                                            }
                                                        } else {
                                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_enccertexpired");
                                                            loginHisStatus = 5;
                                                            loginHisStatus=8;
                                                            iscertprob = true;
                                                        }
                                                        if(!iscertprob)
                                                        {
                                                        	iscertprob=!loginService.addUserCertificate(certificate, userCertificate, tblCertUnMapHistory);
                                                        }
                                                        
                                                        if(!iscertprob)
                                                        {
                                                        	if(certificate!=null)
                                                            {
                                                                certIdEncr = certificate.getCertId();
                                                                List<TblCertificate> certificates = new ArrayList<TblCertificate>();
                                                                certificates.add(certificate);
    //Sending Mail on Attach Code
                                                                if(certificates.get(0)!=null){
                                                                    wSCheckAvailService.RegisterCertificate(certificates.get(0),bean.getUserName(),1,0,"Map",bean.getUserId(),clientBean.getClientId());                                                            
                                                                }
                                                                sendAttachDcMail(bean, clientBean.getClientId(), request, certificates);
                                                            }
                                                            
                                                            bean.setCertId(list.get(0)[1] + "," + certIdEncr);
                                                            request.getSession().removeAttribute(SESSIONOBJECT);
                                                            request.getSession().setAttribute(SESSIONOBJECT, bean);
                                                        }
                                                    	if(bean.getUserTypeId() == 2 && clientBean.getIsDcVerificationRequired() == 1 && !isSigningVerified && clientRegWorkflowIdbidder==9 && !iscertprob)
                                                        {
                                                    			redirectAttributes.addFlashAttribute(certError, "cert_notverified_certificate");
                                                                iscertprob = true;
                                                                loginHisStatus = 10;	
                                                        }
        	                                                
                                                        else if(iscertprob) {
                                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
                                                            loginHisStatus = 8;
                                                            iscertprob = true;
                                                        }
                                                        if (!iscertprob) {
                                                            if(certificate!=null){
                                                                certIdEncr = certificate.getCertId();
                                                                List<TblCertificate> certificates = new ArrayList<TblCertificate>();
                                                                certificates.add(certificate);
                                                            }
                                                            
                                                            bean.setCertId(list.get(0)[1] + "," + certIdEncr);
                                                            request.getSession().removeAttribute(SESSIONOBJECT);
                                                            request.getSession().setAttribute(SESSIONOBJECT, bean);
                                                        }
                                                	}
                                                	else
                                                	{
                                                		 iscertprob = true;
                                                         redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertalreadymap");
                                                         loginHisStatus=8;
                                                	}
                                            	}
                                            	else
                                            	{
                                            		isEncrOk = list.get(0)[0].toString().equals(certiDataBean.getSkpPublicKey_encrypt());//Check if Encr public Key match with DB
                                            		if(isEncrOk)
                                            		{
                                                        //Encr certificate is available in DB, while Signing certificate is not. Signing certificate entry is done
                                                        TblCertificate certificate = null;
                                                        TblUserCertificate userCertificate = new TblUserCertificate();
                                                        TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
                                                        SimpleDateFormat format = new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");
                                                        String datesplit[] = certiDataBean.getSkpValidTo_sign().split(" ");
                                                        String date = datesplit[2] + "/" + datesplit[1] + "/" + datesplit[5] + " " + datesplit[3];
                                                        Date signTo = format.parse(date);
                                                        datesplit = certiDataBean.getSkpValidFrom_sign().split(" ");
                                                        date = datesplit[2] + "/" + datesplit[1] + "/" + datesplit[5] + " " + datesplit[3];
                                                        Date signFrom = format.parse(date);
                                                        if (signTo.after(serverDate)) {
                                                            List<Object> signList = loginService.getCertiByPublicKey(certiDataBean.getSkpPublicKey_sign());
                                                            if (signList.isEmpty() && !certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign())) {
                                                                certificate = new TblCertificate();
                                                                certificate.setAlias(certiDataBean.getSkpAlias_sign());
                                                                certificate.setEndDate(signTo);
                                                                certificate.setIssuer(certiDataBean.getSkpIssuer_sign());
                                                                certificate.setPublicKey(certiDataBean.getSkpPublicKey_sign());
                                                                certificate.setSerialNumber(certiDataBean.getSkpSerial_sign());
                                                                certificate.setStartDate(signFrom);
                                                                certificate.setSubject(certiDataBean.getSkpSubject_sign());
                                                                certificate.setKeyUsage(2);
                                                                
                                                                userCertificate.setTblCertificate(certificate);
                                                                userCertificate.setTblClient(new TblClient(clientBean.getClientId()));
                                                                userCertificate.setTblUserLogin(new TblUserLogin(bean.getUserId()));
                                                                userCertificate.setCreatedBy(bean.getUserId());
                                                                userCertificate.setIsDualCert(2);
                                                                userCertificate.setKeyUsage(1);
                                                                
                                                                tblCertUnMapHistory.setCreatedBy(bean.getUserId());
                                                                tblCertUnMapHistory.setIsMapped(1);
                                                                tblCertUnMapHistory.setKeyUsage(1);
                                                                tblCertUnMapHistory.setIsDualCert(2);
                                                                tblCertUnMapHistory.setTblCertificate(certificate);
                                                                tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
                                                                tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(bean.getUserId()));
                                                                tblCertUnMapHistory.setRemark("");

                                                            }else{    
                                                            	
                                                                certIdSign = signList.isEmpty() && certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign()) ? certIdSign : (Integer)signList.get(0);
                                                                if(loginService.isCertMappedToUser(certIdEncr))
                                                                {
                                                                	redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
                                                                    loginHisStatus=8;
                                                                    iscertprob = true;
                                                                }
                                                                else
                                                                {
	                                                                userCertificate.setTblCertificate(signList.isEmpty() && certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign()) ? certificate : new TblCertificate(certIdSign));
	                                                                userCertificate.setTblClient(new TblClient(clientBean.getClientId()));
	                                                                userCertificate.setTblUserLogin(new TblUserLogin(bean.getUserId()));
	                                                                userCertificate.setCreatedBy(bean.getUserId());
	                                                                userCertificate.setIsDualCert(2);
	                                                                userCertificate.setKeyUsage(1);
	                                                                
	                                                                
	                                                                tblCertUnMapHistory.setCreatedBy(bean.getUserId());
	                                                                tblCertUnMapHistory.setIsMapped(1);
	                                                                tblCertUnMapHistory.setKeyUsage(2);
	                                                                tblCertUnMapHistory.setIsDualCert(2);
	                                                                tblCertUnMapHistory.setTblCertificate(signList.isEmpty() && certiDataBean.getSkpPublicKey_encrypt().equals(certiDataBean.getSkpPublicKey_sign()) ? certificate : new TblCertificate(certIdSign));
	                                                                tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
	                                                                tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(bean.getUserId()));
	                                                                tblCertUnMapHistory.setRemark("");
                                                                }
                                                            }
                                                        } else {
                                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertexpired");
                                                            loginHisStatus = 5;
                                                            loginHisStatus=8;
                                                            iscertprob = true;
                                                        }
                                                        if(!iscertprob)
                                                        {
                                                        	iscertprob=!loginService.addUserCertificate(certificate, userCertificate, tblCertUnMapHistory);
                                                        }
                                                        if(!iscertprob)
                                                        {
                                                        	if(certificate!=null)
                                                            {
                                                                certIdSign = certificate.getCertId();
                                                                List<TblCertificate> certificates = new ArrayList<TblCertificate>();
                                                                certificates.add(certificate);
    //Sending Mail on Attach Code
                                                                if(certificates.get(0)!=null){
                                                                    wSCheckAvailService.RegisterCertificate(certificates.get(0),bean.getUserName(),1,0,"Map",bean.getUserId(),clientBean.getClientId());                                                            
                                                                }
                                                                sendAttachDcMail(bean, clientBean.getClientId(), request, certificates);
                                                            }
                                                            
                                                            bean.setCertId(certIdSign + "," + list.get(0)[1]);
                                                            request.getSession().removeAttribute(SESSIONOBJECT);
                                                            request.getSession().setAttribute(SESSIONOBJECT, bean);
                                                        }
                                                        if(bean.getUserTypeId() == 2 && clientBean.getIsDcVerificationRequired() == 1 && clientRegWorkflowIdbidder==9 && !iscertprob)
                                                        {
                                                    			redirectAttributes.addFlashAttribute(certError, "cert_notverified_certificate");
                                                                iscertprob = true;
                                                                loginHisStatus = 10;	
                                                        }	
                                                        else if(iscertprob) {
                                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
                                                            loginHisStatus = 8;
                                                            iscertprob = true;
                                                        }
                                                        if (!iscertprob) {
                                                            if(certificate!=null){
                                                                certIdEncr = certificate.getCertId();
                                                                List<TblCertificate> certificates = new ArrayList<TblCertificate>();
                                                                certificates.add(certificate);
                                                            }
                                                            
                                                            bean.setCertId(certIdSign + "," + list.get(0)[1]);
                                                            request.getSession().removeAttribute(SESSIONOBJECT);
                                                            request.getSession().setAttribute(SESSIONOBJECT, bean);
                                                        }
                                            		}
                                                	else
                                                	{
                                                		 iscertprob = true;
                                                         redirectAttributes.addFlashAttribute(certError, "redirect_error_enccertalreadymap");
                                                         loginHisStatus=8;
                                                	}
                                            	}
                                            }
                                        } else {
                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_certexpired");
                                            loginHisStatus = 5;
                                            loginHisStatus=5;
                                            iscertprob = true;
                                        }
                                    } else {
                                        iscertprob = true;
                                        if (!isEncrOk && !isSignOk) {
                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_certnotvalidissuer");
                                            loginHisStatus = 9;
                                        } else {
                                            if (!isSignOk) {
                                                redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertnotvalidissuer");
                                                loginHisStatus = 9;
                                            }
                                            if (!isEncrOk) {
                                                redirectAttributes.addFlashAttribute(certError, "redirect_error_enccertnotvalidissuer");
                                                loginHisStatus = 9;
                                            }
                                        }
                                    }

                                } else {
                                    iscertprob = true;
                                    if (!isEncrOk && !isSignOk) {
                                        redirectAttributes.addFlashAttribute(certError, "redirect_error_certrevoked");
                                        loginHisStatus=6;
                                    } else {
                                        if (!isSignOk) {
                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertrevoked");
                                            loginHisStatus=6;
                                        }
                                        if (!isEncrOk) {
                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_enccertrevoked");
                                            loginHisStatus=6;
                                        }
                                    }
                                }
                            }
                    } catch (Exception ex) {
                        loginSuccess = false;
                        request.getSession().removeAttribute(SESSIONOBJECT);
                        return exceptionHandlerService.writeLog(ex);
                    } finally {
                        auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), certiMapLink, iscertprob ? certiLoginFailAudit :  certiLoginAudit, 0, certIdSign);
                        request.getSession().removeAttribute("CERTI_RANDOMNO");
                    }
                }
            } else {//Single Certificate during login
                if (certiDataBean.getSkpPublicKey_sign().contains("'") || certiDataBean.getSkpPublicKey_sign().contains("\"")
                        || certiDataBean.getSkpSerial_sign().contains("'") || certiDataBean.getSkpSerial_sign().contains("\"")) {
                    iscertprob = true;
                    redirectAttributes.addFlashAttribute(certError, "redirect_error_certproper");
                    loginHisStatus=7;
                } else {
                    try {
                        Date serverDate = commonService.getServerDateTime();
                        if (key != null) {
                            data = signerVerify.verify(key);
                            if (data[1] == null || !(Boolean) data[1] || data[2] == null || !data[2].toString().equals(request.getSession().getAttribute("CERTI_RANDOMNO")) || data[0] == null) {
                                iscertprob = true;
                                redirectAttributes.addFlashAttribute(certError, "redirect_error_certproper");
                                loginHisStatus=7;
                            }                            
                        }else{
                            if (attach != null && attach.equals("yes")) {
                                iscertprob = false;
                            }     
                        }
                        if(!iscertprob){
                                isSignOk = !commonService.checkCertificateRevoked(certiDataBean.getSkpSerial_sign(),certiDataBean.getSkpIssuer_sign());
                                if (isSignOk) {
                                    isSignOk = commonService.checkValidIssuer(certiDataBean.getSkpIssuer_sign());
                                    if (isSignOk) {
                                        if (!commonService.checkAttachedCertExpired(bean.getUserId())) {
//                                            List<Object[]> list = loginService.getUserPublicKey(bean.getUserId(), bean.getCertId()==null ? 1 :2);
                                             List<Object[]> list = loginService.getUserPublicKey(bean.getUserId(),clientBean.getIsDualCerti());                                             
                                            for (Iterator<Object[]> it = list.iterator(); it.hasNext();) {
                                                Object[] cert = it.next();                
                                                if ((Integer) cert[3] == 2) {
                                                    it.remove();
                                                }
                                                	if(cert[4].toString().equals("1") && cert[3].toString().equals("1"))
                                                	{
                                                		isSigningVerified = true; 	
                                                	}
                                            }                                            
                                            if(!list.isEmpty()){//Single Certificate is available in DB, than only certificate properness is checked
                                                for (Object[] objects : list) {
                                                    if((Integer)objects[3]==1){
                                                        isSignOk = list.get(0)[0].toString().equals(certiDataBean.getSkpPublicKey_sign());
                                                    }
                                                }
                                                if (isSignOk) {
                                                    //if(certiDataBean.getHdAttachCerti().equalsIgnoreCase("false") || (clientBean.getIsPkiEnabled() ==2 && (bean.getCertId()==null || bean.getCertId().isEmpty()))){
                                                    // Check if Digital Certificate is Verified or Not
                                                	 
                                                    if(bean.getUserTypeId() == 2 && clientBean.getIsDcVerificationRequired() ==1 && !isSigningVerified && clientRegWorkflowIdbidder==9)
                                                    {
                                                        redirectAttributes.addFlashAttribute(certError, "cert_notverified_certificate");
                                                        iscertprob = true;
                                                        loginHisStatus = 10;
                                                        List<Object[]> tempList = loginService.getUserPublicKey(bean.getUserId(),clientBean.getIsDualCerti());
                                                        
                                                        // Maintain Record in Login History
                                            	        TblLoginHistory tblLoginHistory=new TblLoginHistory();
                                            	        tblLoginHistory.setTblTrackLogin(new TblTrackLogin(bean.getTrackLoginId()));
                                            	        String remarks="Signing digital certificate is not verified";
                                            	        tblLoginHistory.setRemark(remarks);
                                            	        tblLoginHistory.setCstatus(loginHisStatus);
                                            	        try 
                                            	        {
                                            	        	loginService.addLoginHistory(tblLoginHistory);
                                            			} 
                                            	        catch (Exception e)
                                            	        {
                                            				return exceptionHandlerService.writeLog(e);
                                            			}
                                                        
                                                        //Audit Trail Report
                                                        if (tempList.size() == 2) 
                                                        {//Both certificate already available in DB
                                                            certIdSign = (Integer) tempList.get(0)[1];
                                                            certIdEncr = (Integer) tempList.get(1)[1];
                                                        }
                                                        iscertprob = true;
                                                        loginHisStatus=10;
//                                                        auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), certiMapLink, iscertprob ? certiLoginFailAudit :  certiLoginAudit, 0, certIdSign);
//                                                    	return "redirect:/certimap";
                                                    }
                                                        else
                                                        {
                                                        	if(certiDataBean.getHdAttachCerti().equalsIgnoreCase("false")){
                                                                boolean allowLogin = true;
                                                                if(bean.getUserTypeId()==2 && manageBidderService.getBidderWorkflowId(clientBean.getClientId(), bean.getUserId())!=9){
                                                                    registrationWorkflowId = manageBidderService.getClientRegWorkflowId(clientBean.getClientId(), 4);
                                                                    if(registrationWorkflowId!=9){
                                                                    	//For CR #25825 - Keval Soni
                                                                    	registrationWorkflowId = getRegWorkflowIdForInternationBidder(clientBean.getClientId(),bean.getUserId(),registrationWorkflowId);
                                                                    	int companyId = Integer.valueOf((commonService.getCompanyIdByUserId(bean.getUserId()).toString()));
                                                                    	if(registrationWorkflowId==7 && commonService.getCountryIdByCompanyId(companyId)!=countryId){
                                                                    		registrationWorkflowId = 8;
                                                                		}
                                                                        manageBidderService.updateRegistrationWorkflowInBidderStatus(clientBean.getClientId(), bean.getUserId(), registrationWorkflowId==8 ? 9 : registrationWorkflowId);
                                                                        allowLogin = false;
                                                                    }
                                                                }
                                                                if(allowLogin){
                                                                    certIdSign = (Integer) list.get(0)[1];
                                                                    bean.setCertId(String.valueOf(certIdSign));
                                                                    request.getSession().removeAttribute(TEMPSESSIONOBJECT);
                                                                    request.getSession().setAttribute(SESSIONOBJECT, bean);

                                                                    TblSession tblSession = new TblSession();
                                                                    tblSession.setCertId(bean.getCertId());
                                                                    tblSession.setLoginDate(serverDate);
                                                                    tblSession.setLogoutDate(serverDate);
                                                                    tblSession.setJSessionId(request.getSession().getId());
                                                                    tblSession.setTblTrackLogin(new TblTrackLogin(bean.getTrackLoginId()));
                                                                    loginService.addSession(tblSession);
                                                                }    
                                                                loginSuccess = true;
                                                        }else{
                                                                  certIdSign = (Integer) list.get(0)[1];
                                                                    bean.setCertId(String.valueOf(certIdSign));
                                                                    request.getSession().removeAttribute(TEMPSESSIONOBJECT);
                                                                    request.getSession().setAttribute(SESSIONOBJECT, bean);
                                                       }
                                                        }
                                                } else {
                                                    if (!isSignOk) {
                                                        redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertalreadymap");
                                                        loginHisStatus=8;
                                                        iscertprob = true;
                                                    }
                                                }
                                            }else{//Single Certificate login but certificate is not available in DB, Sign Certificate is saved in DB
                                                SimpleDateFormat format = new SimpleDateFormat("dd/MMM/yyyy HH:mm:ss");
                                                String datesplit[] = certiDataBean.getSkpValidTo_sign().split(" ");
                                                String date = datesplit[2] + "/" + datesplit[1] + "/" + datesplit[5] + " " + datesplit[3];
                                                Date signTo = format.parse(date);
                                                datesplit = certiDataBean.getSkpValidFrom_sign().split(" ");
                                                date = datesplit[2] + "/" + datesplit[1] + "/" + datesplit[5] + " " + datesplit[3];
                                                Date signFrom = format.parse(date);
                                                if (signTo.after(serverDate)) {
                                                        List<Object> signList = loginService.getCertiByPublicKey(certiDataBean.getSkpPublicKey_sign());
                                                        if (signList.isEmpty()) {
                                                                //0 - both,1-sign,2-encrypt
                                                                TblCertificate certificate = new TblCertificate();
                                                                certificate.setAlias(certiDataBean.getSkpAlias_sign());
                                                                certificate.setEndDate(signTo);
                                                                certificate.setIssuer(certiDataBean.getSkpIssuer_sign());
                                                                certificate.setPublicKey(certiDataBean.getSkpPublicKey_sign());
                                                                certificate.setSerialNumber(certiDataBean.getSkpSerial_sign());
                                                                certificate.setStartDate(signFrom);
                                                                certificate.setSubject(certiDataBean.getSkpSubject_sign());
                                                                if (certiDataBean.getSkpPurpose_sign().equals("2")) {
                                                                        certificate.setKeyUsage(0);
                                                                } else {
                                                                        certificate.setKeyUsage(1);
                                                                }

                                                                TblUserCertificate userCertificate = new TblUserCertificate();
                                                                userCertificate.setTblCertificate(certificate);
                                                                userCertificate.setTblClient(new TblClient(clientBean.getClientId()));
                                                                userCertificate.setTblUserLogin(new TblUserLogin(bean.getUserId()));
                                                                userCertificate.setCreatedBy(bean.getUserId());
                                                                userCertificate.setIsDualCert(clientBean.getIsDualCerti());
                                                                userCertificate.setKeyUsage(1);

                                                                TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
                                                                tblCertUnMapHistory.setCreatedBy(bean.getUserId());
                                                                tblCertUnMapHistory.setIsMapped(1);
                                                                tblCertUnMapHistory.setTblCertificate(certificate);
                                                                tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
                                                                tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(bean.getUserId()));
                                                                tblCertUnMapHistory.setRemark("");
                                                                iscertprob = !loginService.addUserCertificate(certificate, userCertificate, tblCertUnMapHistory);
                                                                
                                                                if(!iscertprob && (attach != null && attach.equals("yes")))
                                                                {
                                                                    List<TblCertificate> certificates = new ArrayList<TblCertificate>();
                                                                    certificates.add(certificate);
                                                                    //Sending DC Attach Mail                                                                        
                                                                    sendAttachDcMail(bean, clientBean.getClientId(), request, certificates);
                                                                    wSCheckAvailService.RegisterCertificate(certificate,bean.getUserName(),certificate.getKeyUsage()==0?1:0,certificate.getKeyUsage()==0?1:1,"Map",bean.getUserId(),clientBean.getClientId());
                                                                }
                                                                
                                                            	if(bean.getUserTypeId() == 2 && clientBean.getIsDcVerificationRequired() ==1 && (attach != null && attach.equals("yes")) && userCertificate.getKeyUsage() != 2 && clientRegWorkflowIdbidder==9)
                                                            	{
                                                            		redirectAttributes.addFlashAttribute(certError, "cert_notverified_certificate");
                                                                    iscertprob = true;
                                                                    loginHisStatus = 10;        
                                                             	}
                                                            	else if(iscertprob)
                                                            	{
                                                                    redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
                                                                    loginHisStatus=8;
                                                                    iscertprob = true;
                                                            	}
                                                                
                                                                certIdSign = certificate.getCertId();
                                                        }else{                                                            
                                                            certIdSign = (Integer)signList.get(0);
                                                            if(loginService.isCertMappedToUser(certIdSign))
                                                            {
                                                            	redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
                                                                loginHisStatus=8;
                                                                iscertprob = true;
                                                            }
                                                            else
                                                            {
		                                                            TblUserCertificate userCertificate = new TblUserCertificate();
		                                                            userCertificate.setTblCertificate(new TblCertificate(certIdSign));
		                                                            userCertificate.setTblClient(new TblClient(clientBean.getClientId()));
		                                                            userCertificate.setTblUserLogin(new TblUserLogin(bean.getUserId()));
		                                                            userCertificate.setCreatedBy(bean.getUserId());
		                                                            userCertificate.setIsDualCert(clientBean.getIsDualCerti());
		                                                            userCertificate.setKeyUsage(1);
		
		
		                                                            TblCertUnMapHistory tblCertUnMapHistory = new TblCertUnMapHistory();
		                                                            tblCertUnMapHistory.setCreatedBy(bean.getUserId());
		                                                            tblCertUnMapHistory.setIsMapped(1);
		                                                            tblCertUnMapHistory.setTblCertificate(new TblCertificate(certIdSign));
		                                                            tblCertUnMapHistory.setTblClient(new TblClient(clientBean.getClientId()));
		                                                            tblCertUnMapHistory.setTblUserLogin(new TblUserLogin(bean.getUserId()));
		                                                            tblCertUnMapHistory.setRemark("");
		                                                            iscertprob = !loginService.addUserCertificate(null, userCertificate, tblCertUnMapHistory);
	                                                              
		                                                            if(iscertprob){
		                                                            	redirectAttributes.addFlashAttribute(certError, "redirect_error_certalreadymap");
		                                                                loginHisStatus = 8;
		                                                                iscertprob = true;
		                                                            }else if(bean.getUserTypeId() == 2 && clientBean.getIsDcVerificationRequired() ==1 && (attach != null && attach.equals("yes")) && userCertificate.getKeyUsage() != 2 && clientRegWorkflowIdbidder==9)
		                                                            {
		                                                            	redirectAttributes.addFlashAttribute(certError, "cert_notverified_certificate");
		                                                                iscertprob = true;
		                                                                loginHisStatus = 10;                                                                	
		                                                            }
                                                            } 
                                                        }
                                                        if (!iscertprob) {
                                                                if(certiDataBean.getHdAttachCerti().equalsIgnoreCase("false")){
                                                                        if (bean.getUserTypeId() != 2) {
                                                                                bean.setCertId(String.valueOf(certIdSign));
                                                                                request.getSession().removeAttribute(TEMPSESSIONOBJECT);
                                                                                request.getSession().setAttribute(SESSIONOBJECT, bean);

                                                                                TblSession tblSession = new TblSession();
                                                                                tblSession.setCertId(bean.getCertId());
                                                                                tblSession.setLoginDate(serverDate);
                                                                                tblSession.setLogoutDate(serverDate);
                                                                                tblSession.setJSessionId(request.getSession().getId());
                                                                                tblSession.setTblTrackLogin(new TblTrackLogin(bean.getTrackLoginId()));
                                                                                loginService.addSession(tblSession);
                                                                        } else {
                                                                                int bidderRegWorkflowId = manageBidderService.getBidderWorkflowId(clientBean.getClientId(), bean.getUserId());
                                                                                if(bidderRegWorkflowId!=9){
                                                                                    registrationWorkflowId = manageBidderService.getClientRegWorkflowId(clientBean.getClientId(), 4);
                                                                                    //For CR #25825 - Keval Soni
                                                                                	registrationWorkflowId = getRegWorkflowIdForInternationBidder(clientBean.getClientId(),bean.getUserId(),registrationWorkflowId);
                                                                                	int companyId = Integer.valueOf((commonService.getCompanyIdByUserId(bean.getUserId()).toString()));
                                                                                	if(registrationWorkflowId==7 && commonService.getCountryIdByCompanyId(companyId)!=countryId){
                                                                                		registrationWorkflowId = 8;
                                                                            		}
                                                                                    manageBidderService.updateRegistrationWorkflowInBidderStatus(clientBean.getClientId(), bean.getUserId(), registrationWorkflowId==8 ? 9 : registrationWorkflowId);
                                                                                }else{
                                                                                    bean.setCertId(String.valueOf(certIdSign));
                                                                                    request.getSession().removeAttribute(TEMPSESSIONOBJECT);
                                                                                    request.getSession().setAttribute(SESSIONOBJECT, bean);
                                                                                    TblSession tblSession = new TblSession();
                                                                                    tblSession.setCertId(bean.getCertId());
                                                                                    tblSession.setLoginDate(serverDate);
                                                                                    tblSession.setLogoutDate(serverDate);
                                                                                    tblSession.setJSessionId(request.getSession().getId());
                                                                                    tblSession.setTblTrackLogin(new TblTrackLogin(bean.getTrackLoginId()));
                                                                                    loginService.addSession(tblSession);
                                                                                    registrationWorkflowId = 9;
                                                                                }
                                                                        }
                                                                        loginSuccess = true;
                                                                }else{
                                                                          bean.setCertId(String.valueOf(certIdSign));
                                                                          request.getSession().removeAttribute(SESSIONOBJECT);
                                                                          request.getSession().setAttribute(SESSIONOBJECT, bean);
                                                                }
                                                        }
                                                } else {
                                                        redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertexpired");
                                                        loginHisStatus=5;
                                                        iscertprob = true;
                                                }
                                            }
                                        } else {
                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertexpired");
                                            loginHisStatus=5;
                                            iscertprob = true;
                                        }
                                    } else {
                                        if (!isSignOk) {
                                            redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertnotvalidissuer");
                                            loginHisStatus=9;
                                            iscertprob = true;
                                        }
                                    }
                                } else {
                                    if (!isSignOk) {
                                        redirectAttributes.addFlashAttribute(certError, "redirect_error_signcertrevoked");
                                        loginHisStatus=6;
                                        iscertprob = true;
                                    }
                                }
                            }
                    } catch (Exception ex) {
                        loginSuccess = false;
                        request.getSession().removeAttribute(SESSIONOBJECT);
                        return exceptionHandlerService.writeLog(ex);
                    } finally {
                        auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), certiMapLink, iscertprob ? certiLoginFailAudit :  certiLoginAudit, 0, certIdSign);
                        request.getSession().removeAttribute("CERTI_RANDOMNO");
                    }
                }
            }
        } else {
            return "redirect:/loginfailed";
        }
        String pageName = "redirect:/loginfailed";
        if (loginSuccess) {
            if (attach != null && attach.equals("yes")) {
                redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_certmapped");
            }
            boolean isGstEntered = true;
            int bidderCstatus=manageBidderService.getBidderCstatus(clientBean.getClientId(), bean.getUserId());
            if(bidderCstatus==1){
            	int isGstRequired = (Integer)clientService.getClientField(clientBean.getClientId(), "isGSTRequired");
            	if(isGstRequired==1){
            		Object[] obj = manageBidderService.getGstFields("TblBidderGstDetails", bean.getUserId(),clientBean.getClientId(), "gstDetailId,panNo");
            		if(obj==null  && commonService.getCountryIdByCompanyId(bean.getCompanyId())==countryId){
            			isGstEntered = false;
            		}
            	}
            }
            loginHisStatus=4;
            if (bean.getUserTypeId() == 1) {
                pageName = getRedirectPage(request);
            } else if (bean.getUserTypeId() == 2) {
                if (registrationWorkflowId != 0 && registrationWorkflowId != 9) {
                	
	
                	if(commonService.getSubUser(bean.getUserId())) {
                		registrationWorkflowId=8;
                	}
                    switch (registrationWorkflowId) {
                        case 6: //Registration Charges
                            pageName = "redirect:/bidderregcharges";//pending
                            break;
                        case 7: //Complete registration - final step
                            pageName = "redirect:/gstDetails/0";
                            break;
                        case 8: //Complete registration - final step
                            pageName = "redirect:/finishregistration";
                            break;
                    }
                } else if(!isGstEntered){
                	pageName = "redirect:/gstDetails/0";
                }else {
                    pageName = getRedirectPage(request);
                }
            } else if (bean.getUserTypeId() == 3) {
                pageName = getRedirectPage(request);
            }
        } else {        	
	            if (iscertprob) {
	            	if(certiDataBean.getHdAttachCerti().equalsIgnoreCase("true")){
	            		if(request.getHeader("referer").toString().contains("bidder/attacheventspeccerti")){
	            			pageName = "redirect:/common/bidder/attacheventspeccerti/"+certiDataBean.getHdRedirectLink()+ encryptDecryptUtils.generateRedirect("common/bidder/attacheventspeccerti/"+certiDataBean.getHdRedirectLink(), request);
	            		}else{
	            			pageName = "redirect:/common/buyer/attacheventspeccerti/"+certiDataBean.getHdRedirectLink()+ encryptDecryptUtils.generateRedirect("common/buyer/attacheventspeccerti/"+certiDataBean.getHdRedirectLink(), request);
	            		}
	            		
	            	}else{
	            		pageName = "redirect:/certimap";
	            	}
	            }else{
	            	if(certiDataBean.getHdAttachCerti().equalsIgnoreCase("true")){        		
	            		String url = certiDataBean.getHdRedirectLink().replace(",", "/");
                                if(url.equals("default")){
                                    pageName = "redirect:/";
                                }else{
                                    pageName = "redirect:/"+url + encryptDecryptUtils.generateRedirect(url, request);
                                }
	            		if(bean!=null){
	            			bean.setEventSpecVerify(true);
	            			request.getSession().removeAttribute(SESSIONOBJECT);
	            			request.getSession().setAttribute(SESSIONOBJECT, bean);
	            		}
	            		
	            	}
	            }        	
        }
        if(bean != null && bean.getTrackLoginId() > 0){
	        TblLoginHistory tblLoginHistory=new TblLoginHistory();
	        tblLoginHistory.setTblTrackLogin(new TblTrackLogin(bean.getTrackLoginId()));
	        String remarks=redirectAttributes.getFlashAttributes().containsKey(certError) ? messageSource.getMessage((String)redirectAttributes.getFlashAttributes().get(certError), null, LocaleContextHolder.getLocale()) /*(String)redirectAttributes.getFlashAttributes().get(certError)*/ : "";
	        tblLoginHistory.setRemark(remarks);
	        tblLoginHistory.setCstatus(loginHisStatus);
	        try {
	        	loginService.addLoginHistory(tblLoginHistory);
			} catch (Exception e) {
				return exceptionHandlerService.writeLog(e);
			}
        }
        return pageName;
    }
    
    private void sendAttachDcMail(SessionBean sessionBean, int clientId, HttpServletRequest request, List<TblCertificate> tblCertificates) throws Exception {
    	Map<String, Object> paramMap = new HashMap<String, Object>();
    	List<Object[]> userDetails = null;
    	List<Object[]> certificateContactDetails = clientService.getClientCertContactDetail(clientId);
    	if(certificateContactDetails!=null && !certificateContactDetails.isEmpty()) {
    		paramMap.put("to", certificateContactDetails.get(0)[1]);
    		TblUserLogin tblUserLogin = loginService.getUserLoginById(sessionBean.getUserId());
    		if(sessionBean.getUserTypeId() == 2) { // Bidder details
    			userDetails = commonService.getCompanyDetailsByUserId(sessionBean.getUserId(), clientId);
	    		if(userDetails != null && !userDetails.isEmpty()) {
	    			paramMap.put("userName", tblUserLogin.getUserName());
	    			if(sessionBean.getUserTypeId() == 2) {
	    				paramMap.put("companyName", " "+userDetails.get(0)[0]); 
	    			}
	    			paramMap.put("landline", userDetails.get(0)[1]);
	    			paramMap.put("UserType", "Bidder");
	    		}
    		}
    		else { // Officer details
    			userDetails = commonService.getOfficerContactDetails(sessionBean.getUserId(), clientId);
    			if(userDetails != null && !userDetails.isEmpty()) {
    				paramMap.put("userName", tblUserLogin.getUserName());
    				if(sessionBean.getUserTypeId() != 2) {
	    				paramMap.put("companyName", " "); 
	    			}
	    			paramMap.put("landline", userDetails.get(0)[3]);
	    			paramMap.put("UserType", "Officer");
    			}
    		}
    		paramMap.put("bidderMailId", tblUserLogin.getLoginId());
    		paramMap.put("mobile", tblUserLogin.getMobileNo());
    		paramMap.put("domainname", new URL(request.getRequestURL().toString()).getHost());

    		if(tblCertificates != null && tblCertificates.size()>0 && tblCertificates.get(0)!=null) {
    			String certificateSubjcet = tblCertificates.get(0).getSubject();
    			for (String subjectDetail : certificateSubjcet.split(",")) {
    				if(subjectDetail.contains("O=")) {
    					paramMap.put("organisation", subjectDetail.substring(subjectDetail.indexOf('=')+1));
    				} else if(subjectDetail.contains("CN=")) {
    					paramMap.put("companyName1", subjectDetail.substring(subjectDetail.indexOf('=')+1));
    				}
    			}
    			paramMap.put("subject", tblCertificates.get(0).getSubject());
    			paramMap.put("issuer",tblCertificates.get(0).getIssuer());
    			paramMap.put("serial", tblCertificates.get(0).getSerialNumber());
    			paramMap.put("startDate", tblCertificates.get(0).getStartDate());
    			paramMap.put("endDate", tblCertificates.get(0).getEndDate());

    			if(tblCertificates.size()==2 && tblCertificates.get(1)!=null) {
    				paramMap.put("subject1", tblCertificates.get(1).getSubject());
    				paramMap.put("issuer1",tblCertificates.get(1).getIssuer());
    				paramMap.put("serial1", tblCertificates.get(1).getSerialNumber());
    				paramMap.put("startDate1", tblCertificates.get(1).getStartDate());
    				paramMap.put("endDate1", tblCertificates.get(1).getEndDate());
    				mailContentUtillity.dynamicMailGeneration("32", String.valueOf(sessionBean.getUserId()), String.valueOf(clientId),paramMap);
    			} else {
    				mailContentUtillity.dynamicMailGeneration("31", String.valueOf(sessionBean.getUserId()), String.valueOf(clientId),paramMap);
    			}
    		}
    		if(sessionBean.getUserTypeId() == 2) {
    			mailContentUtillity.dynamicMailGeneration("235", String.valueOf(sessionBean.getUserId()), String.valueOf(clientId),paramMap);
    		}
    	}
    }

    @RequestMapping(value = "/logout")
    public String logout(HttpServletRequest req,ModelMap modelMap,RedirectAttributes redirectAttributes) {
        HttpSession session = req.getSession();          
        SessionBean sessionBean = null;
        boolean flag = false;
        modelMap.addAttribute(CommonKeywords.SUCCESS_MSG.toString(), session.getAttribute(CommonKeywords.SUCCESS_MSG.toString()));
        modelMap.addAttribute(CommonKeywords.ERROR_MSG_KEY.toString(), session.getAttribute(CommonKeywords.ERROR_MSG.toString()));
        for (Cookie cookie : req.getCookies()) {
            if("expandcollapse".equals(cookie.getName())){
                cookie.setValue(null);
                cookie.setMaxAge(-1);
                cookie.setPath(req.getContextPath()+"/");
            }
        }
        try {
            if (session.getAttribute(SESSIONOBJECT) != null) {
                sessionBean = (SessionBean) session.getAttribute(SESSIONOBJECT);
            }
            if (session.getAttribute(TEMPSESSIONOBJECT) != null) {
                sessionBean = (SessionBean) session.getAttribute(TEMPSESSIONOBJECT);
            }
            modelMap.addAttribute("clientId",abcUtility.getSessionClientId(req));
            session.invalidate();
//            long trackLoginId = 0;
//            if (sessionBean != null) {
//                trackLoginId = sessionBean.getTrackLoginId();
//            }
            if(sessionBean!=null && sessionBean.getTrackLoginId()!=0){
	            TblLoginHistory tblLoginHistory=new TblLoginHistory();
	            tblLoginHistory.setTblTrackLogin(new TblTrackLogin(sessionBean.getTrackLoginId()));
	            tblLoginHistory.setRemark("");
	            tblLoginHistory.setCstatus(3);
		    loginService.addLoginHistory(tblLoginHistory);
                    flag = true;
                    redirectAttributes.addFlashAttribute("isFromLogout", "Y");
            }            
            redirectAttributes.addFlashAttribute(modelMap.get(CommonKeywords.SUCCESS_MSG.toString())!=null ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG_KEY.toString(), modelMap.get(CommonKeywords.SUCCESS_MSG.toString())!=null ? modelMap.get(CommonKeywords.SUCCESS_MSG.toString()) : modelMap.get(CommonKeywords.ERROR_MSG.toString()));
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            if (sessionBean != null) {
                auditTrailService.makeAuditTrail(new TblAuditTrail(req.getRequestURL().toString(), sessionBean.getTrackLoginId()), logoutLink, flag ? logoutAudit : logoutFailAudit, 0, sessionBean.getUserId());
            }
        }
        return "redirect:/";
    }

    /**
     * Method used to serve loginFailed event.
     *
     * @param model
     * @return Login Page
     */
    @RequestMapping(value = "/loginfailed", method = RequestMethod.GET)
    public String loginerror(HttpServletRequest request,RedirectAttributes redirectAttributes) {
        
    	if(isLoginLinkConfigured == 0)
    	{
    		redirectAttributes.addFlashAttribute("emailId", request.getParameter("emailId"));
    		return "redirect:/";
    	}
    	else
    	{
    		String emailId = request.getParameter("emailId");
    		String retVal = "redirect:/";
    		String getUrl = null;
    		try 
    		{
    	    	if(request.getSession().getAttribute("getUrl")!=null){
    				getUrl = request.getSession().getAttribute("getUrl").toString();
    				request.getSession().removeAttribute("getUrl");
    	    		if(getUrl.equalsIgnoreCase("buyerlogin")){
    					retVal = "redirect:/buyerlogin";
    				}
    				else if(getUrl.equalsIgnoreCase("bidderlogin")){
    					retVal = "redirect:/bidderlogin";
    				}
    	    	}
    		} catch (Exception e) {
    			return exceptionHandlerService.writeLog(e);
    			}
    		redirectAttributes.addFlashAttribute("emailId", emailId);
    		return retVal;
    	}
    }

    /**
     * to get forgot password page
     *
     * @param response
     * @param request
     * @return String
     */
    @RequestMapping(value = "/forgotpassword", method = RequestMethod.GET)
    public String forgotPassword(HttpServletRequest request,ModelMap map) {
    	String pageName ="ForgotPassword";
    	String sessionLoginUrl = null;
    	
    	if(request.getSession().getAttribute("sessionLoginurl")!=null)
    	{
    		sessionLoginUrl = request.getSession().getAttribute("sessionLoginurl").toString();
    	}
    	ClientBean clientBean = null;
        try {
        	clientBean = (ClientBean) (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString())!=null ? request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) : null);
        	
        	/* CSP BEFORE LOGIN */
        	String userAgent = request.getHeader("user-agent");
        	if(clientBean.getIsSigner() == 1 && userAgent.contains("Trident")) {
        		clientBean.setIsSigner(0);
        	}
        	if(clientBean.getIsDIYClient() == 1)
        	{
        		pageName ="ForgotPasswordDIY";
        	}
            if (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) {
                request.setAttribute("isPkiEnabled", abcUtility.getSessionIsPkiEnabled(request));
            }
            

            int ShowAccessDetail=abcUtility.getAccessDetail(request);
    		if(ShowAccessDetail==1){
	        	int visitorCount=commonService.getVisitorDetail(request);
	        	map.addAttribute("visitorCount",visitorCount);
	        	
	        	map.addAttribute("isLoginLinkConfigured",clientBean.getIsLoginLinkConfigured());
	        	map.addAttribute("sessionLoginUrl",sessionLoginUrl);
    		}
    		TblClient tempClient=clientService.getClientById(clientBean.getClientId());
    		map.addAttribute("certificateClass",tempClient.getCertificateClass());
    		
    		int bidderRegVerifiedBy=clientService.getBidderRegistrationVerifiedBy(clientBean.getClientId());
    		List<SelectItem> selForgotPassword = new ArrayList<SelectItem>();
    		selForgotPassword.add(new SelectItem("Reset password using Hint answer", 1));
    		selForgotPassword.add(new SelectItem("Reset password through OTP on registered mobile number", 2));
    		map.addAttribute("selForgotPassword", selForgotPassword);
    		map.addAttribute("bidderRegVerifiedBy", bidderRegVerifiedBy);
    		map.addAttribute("linkId", bidderFrgtPwdLinkId);
    		
            //request.setAttribute("hintQueList", modelToSelectItem.convertListIntoSelectItemList(commonService.getHintQuestionList(),"hintQuestionId","lang"+WebUtils.getCookie(request, "locale").getValue()));
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidderFrgtPwdLinkId, forgotPasswordAudit, 0, 0);
        }
        return pageName;
    }

    /**
     * to submit forgot password post method
     *
     * @param forgotPassDataBean
     * @param result
     * @param map
     * @param redirectAttributes
     * @param request
     * @return
     */
    
	@SuppressWarnings("unused")
	@RequestMapping(value = "/submitforgotpassword", method = RequestMethod.POST)
    public String submitForgotPassword(@ModelAttribute ForgotPassDataBean forgotPassDataBean, BindingResult result, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/";
        ClientBean clientBean = null;
        int userId = 0;
        //int cuserId = 0;
        boolean flag = true;
        boolean status = false;
        boolean isSSOEnabled = false;
        TblUserLogin tblUserLogin = null;
        try {
            forgotPassDataBean.setCommonValidators(commonValidators);
            forgotPassDataBean.validateBean(result);
            
            int forgotPasswordBy = StringUtils.hasLength(request.getParameter("rdforgotPassword"))?Integer.parseInt(request.getParameter("rdforgotPassword")):0;
            String OTPVerified = StringUtils.hasLength(request.getParameter("isOTPVerify")) ? request.getParameter("isOTPVerify") : "";
            
            if (result.hasErrors()) {
                //request.setAttribute("hintQueList", modelToSelectItem.convertListIntoSelectItemList(commonService.getHintQuestionList(),"hintQuestionId","lang"+WebUtils.getCookie(request, "locale").getValue()));
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                retVal = FORGOTPWDURL;
            } else {
                if (request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null) {
                    clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
                    isSSOEnabled = clientBean.isIsSsoEnabled();
                    if (clientBean.getIsPkiEnabled() == 1) {
                        Object[] data = signerVerify.verify(forgotPassDataBean.getSignedData());
                        if (data != null) {
                            if (data[1] != null && (Boolean) data[1] && data[2] != null && data[2].toString().equals("ForgotPassword") && data[0] != null) {
                                int[] ids = loginService.checkForgotPass(forgotPassDataBean.getTxtEmailId(), forgotPassDataBean.getSkpPublicKey_sign(), forgotPassDataBean.getTxtHintAns(), clientBean.getIsDualCerti(), forgotPasswordBy, OTPVerified);
                                userId = ids[0];
                                // cuserId = ids[1];
                                if (userId > 0) {
                                    if (data[0].toString().equals(forgotPassDataBean.getSkpPublicKey_sign())) {
                                        boolean dataIn = loginService.isPassValid(userId, forgotPassDataBean.getTxtNewPassword());
                                        if (dataIn) {
                                        	if(ids[2]!=0){ // check
                                        		status = wSCheckAvailService.changePassword(forgotPassDataBean.getTxtEmailId(), forgotPassDataBean.getTxtNewPassword()+"~~"+forgotPassDataBean.getTxtsha1pass(),userId,clientBean.getClientId());
                                            }
                                        	if (isSSOEnabled && !status) {
                                    			//First dump user in sso from Local and then change the pass
                                        		int userTypeId = commonService.getUserTypeId(userId);
                                        		status = wSCheckAvailService.dumpUserWithChngPwd(userId,clientBean.getClientId(),userTypeId,true,forgotPassDataBean.getTxtNewPassword(),forgotPassDataBean.getTxthash());
                                    		}
                                        	if(!isSSOEnabled){
                                        		status = true;
                                        	}
                                        	if(status){
	                                            status = loginService.updateForgotPass(userId, forgotPassDataBean.getTxtNewPassword(), forgotPassDataBean.getTxthash());
	                                            TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
	                                            tblPasswordHistory.setTblUserLogin(new TblUserLogin(userId));
	                                            tblPasswordHistory.setOldPassword(forgotPassDataBean.getTxtNewPassword());
	                                            tblPasswordHistory.setPasswordUpdatedFrom(2);
	                                            tblPasswordHistory.setCreatedBy(userId);
	                                            status = status ? loginService.insertPwdHistory(tblPasswordHistory) : false;
	                                            if(!status){
	                                            	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
	                                            	retVal = FORGOTPWDURL;
	                                            }
                                        	}else if (WSCheckAvail.isSsoAvailable() && !status) {
                                        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                                            	retVal = FORGOTPWDURL;
                                        	}else{
                                        		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
                                        		retVal = FORGOTPWDURL;
                                        	}
                                        } else {
                                            redirectAttributes.addFlashAttribute("errorMsgPwdRepeat", "redirect_failure_pwdnotrepeat");
                                            redirectAttributes.addFlashAttribute("msgArgmnt", passMaxRepeat);
                                            retVal = FORGOTPWDURL;
                                        }
                                    } else {
                                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_forgotpassword_pk");
                                        retVal = FORGOTPWDURL;
                                    }
                                } else if (userId == -2 || userId == -5) {
                                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_forgotpassword_wha");
                                    retVal = FORGOTPWDURL;
                                } else if (userId == -3 || userId == -4) {
                                	boolean isSignOk = !commonService.checkCertificateRevoked(forgotPassDataBean.getSkpSerial_sign(),forgotPassDataBean.getSkpIssuer_sign());
                                    if (isSignOk) {
                                        isSignOk = commonService.checkValidIssuer(forgotPassDataBean.getSkpIssuer_sign());
                                        if (isSignOk) {
                                            if (!commonService.checkAttachedCertExpired(userId)) {
                                            	if(userId == -4){
                                            		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_forgotpassword_validcert");
                                            	}else{
                                            		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_frgtpwd_cert_mapped");
                                            	}
                                            }else{
                                            	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_frgtpwd_cert_expired");
                                            }
                                        }else{
                                        	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_error_signcertnotvalidissuer");
                                        }
                                    }else{
                                    	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_frgtpwd_cert_revoked");
                                    }
                                    
                                    retVal = FORGOTPWDURL;
                                }else if(userId == -6){
                                    status = wSCheckAvailService.changePassword(forgotPassDataBean.getTxtEmailId(), forgotPassDataBean.getTxtNewPassword()+"~~"+forgotPassDataBean.getTxtsha1pass(),userId,clientBean.getClientId());
                                }
                            } else {
                                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_forgotpassword_validcert");
                                retVal = FORGOTPWDURL;
                            }
                        }
                        if (status) {
                            redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_forgotpassword");
                            retVal = request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ?"redirect:/logout" : "redirect:/";
                        }/*else{
                         redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                         return FORGOTPWDURL;
                         }*/
                    } else {
                    	tblUserLogin = loginService.getUserLoginByLoginId(forgotPassDataBean.getTxtEmailId());
                    	if(isSSOEnabled){

                             DataObject dataObject = WSCheckAvail.gethintQuestDetail(forgotPassDataBean.getTxtEmailId());
                         	if ((WSCheckAvail.isSsoAvailable() && dataObject==null)) {
                     			//First dump user in sso from Local
                         		status = wSCheckAvailService.dumpUserWithChngPwd(tblUserLogin.getUserId(),clientBean.getClientId(),commonService.getUserTypeId(tblUserLogin.getUserId()),false);
                         		if(status){
                         			dataObject = WSCheckAvail.gethintQuestDetail(forgotPassDataBean.getTxtEmailId());
                         		}else {
                                 	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                                 	flag = false;
                                 	return FORGOTPWDURL;
                                 }
                     		}
                         	if(dataObject!=null && dataObject.getData3().toString()!=null){
                                if((dataObject.getData3().toString().equalsIgnoreCase(forgotPassDataBean.getTxtHintAns())) || (forgotPasswordBy == 2 && OTPVerified.equals("OTPVerified"))){
                                    if(tblUserLogin!=null && tblUserLogin.getUserId()!=0){
                                    	boolean dataIn = loginService.isPassValid(tblUserLogin.getUserId(), forgotPassDataBean.getTxtNewPassword());
                                    	if(dataIn){
                                    		status = wSCheckAvailService.changePassword(forgotPassDataBean.getTxtEmailId(), forgotPassDataBean.getTxtNewPassword()+"~~"+forgotPassDataBean.getTxtsha1pass(),tblUserLogin.getUserId()!=0?tblUserLogin.getUserId():0,clientBean.getClientId());
                                        	if(status){
                                        		status = loginService.updateForgotPass(tblUserLogin.getUserId(), forgotPassDataBean.getTxtNewPassword(), forgotPassDataBean.getTxthash());
                                                TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
                                                tblPasswordHistory.setTblUserLogin(new TblUserLogin(tblUserLogin.getUserId()));
                                                tblPasswordHistory.setOldPassword(forgotPassDataBean.getTxtNewPassword());
                                                tblPasswordHistory.setPasswordUpdatedFrom(2);
                                                tblPasswordHistory.setCreatedBy(tblUserLogin.getUserId());
                                                status = status ? loginService.insertPwdHistory(tblPasswordHistory) : false;
                                                if (status) {
                                                	redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_forgotpassword");
                                                	retVal = request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ?"redirect:/logout" : "redirect:/";
                                                	flag = false;
                                                } else {
                                                	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                                                	retVal = FORGOTPWDURL;
                                                	flag = false;
                                                }
                                        	}else{
                                    			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
                                    			retVal = FORGOTPWDURL;
                                    			flag = false;
                                        	}
                                    	}else{
                                    		redirectAttributes.addFlashAttribute("errorMsgPwdRepeat", "redirect_failure_pwdnotrepeat");
                                            redirectAttributes.addFlashAttribute("msgArgmnt", passMaxRepeat);
                                            retVal = FORGOTPWDURL;
                                            flag = false;
                                    	}
                                    }else{
                                    	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                                        retVal = FORGOTPWDURL;
                                        flag = false;
                                    }
                                }else{
                                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_forgotpassword_wha");
                                    retVal = FORGOTPWDURL;
                                    flag = false;
                                }
                            }
                    	}else {
                    		List<Object[]> localHintQuestList = commonService.gethintQuestDetailLocal(forgotPassDataBean.getTxtEmailId());
                    		boolean isSuccess = false; 
                            if((localHintQuestList != null && localHintQuestList.size() > 0) && (localHintQuestList.get(0)[2].toString().equalsIgnoreCase(forgotPassDataBean.getTxtHintAns()) || (forgotPasswordBy == 2 && OTPVerified.equals("OTPVerified")))){
                                if(tblUserLogin!=null && tblUserLogin.getUserId()!=0){
                            		boolean dataIn = loginService.isPassValid(tblUserLogin.getUserId(), forgotPassDataBean.getTxtNewPassword());
                            		if(dataIn){
                            			isSuccess = loginService.updateForgotPass(tblUserLogin.getUserId(), forgotPassDataBean.getTxtNewPassword(), forgotPassDataBean.getTxthash());
                                        TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
                                        tblPasswordHistory.setTblUserLogin(new TblUserLogin(tblUserLogin.getUserId()));
                                        tblPasswordHistory.setOldPassword(forgotPassDataBean.getTxtNewPassword());
                                        tblPasswordHistory.setPasswordUpdatedFrom(2);
                                        tblPasswordHistory.setCreatedBy(tblUserLogin.getUserId());
                                        isSuccess = isSuccess ? loginService.insertPwdHistory(tblPasswordHistory) : false;
                                        if (isSuccess) {
                                        	redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_forgotpassword");
                                        	retVal = request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ?"redirect:/logout" : "redirect:/";
                                        	flag = false;
                                        } else {
                                        	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                                        	retVal = FORGOTPWDURL;
                                        	flag = false;
                                        }
                            		}else {
                                        redirectAttributes.addFlashAttribute("errorMsgPwdRepeat", "redirect_failure_pwdnotrepeat");
                                        redirectAttributes.addFlashAttribute("msgArgmnt", passMaxRepeat);
                                        retVal = FORGOTPWDURL;
                                        flag = false;
                                    }
                                }else{
                                	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                                    retVal = FORGOTPWDURL;
                                    flag = false;
                                }
                            }else{
                                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_forgotpassword_wha");
                                retVal = FORGOTPWDURL;
                                flag = false;
                            }
                    	}
                        if(flag){
                            boolean dataIn = loginService.isPassValid(tblUserLogin.getUserId(), forgotPassDataBean.getTxtNewPassword());
                            if (!dataIn) {
                                redirectAttributes.addFlashAttribute("errorMsgPwdRepeat", "redirect_failure_pwdnotrepeat");
                                redirectAttributes.addFlashAttribute("msgArgmnt", passMaxRepeat);
                                retVal = FORGOTPWDURL;
                            } else if (!loginService.checkHintAnswer(forgotPassDataBean.getTxtEmailId(), forgotPassDataBean.getTxtHintAns())) {
                                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_forgotpassword_wha");
                                retVal = FORGOTPWDURL;
                            } else {                            
                                status = loginService.updateForgotPass(tblUserLogin.getUserId(), forgotPassDataBean.getTxtNewPassword(), forgotPassDataBean.getTxthash());
                                TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
                                tblPasswordHistory.setTblUserLogin(new TblUserLogin(tblUserLogin.getUserId()));
                                tblPasswordHistory.setOldPassword(forgotPassDataBean.getTxtNewPassword());
                                tblPasswordHistory.setPasswordUpdatedFrom(2);
                                tblPasswordHistory.setCreatedBy(tblUserLogin.getUserId());
                                status = status ? loginService.insertPwdHistory(tblPasswordHistory) : false;
                                if (status) {
                                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_forgotpassword");
                                    retVal = request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ?"redirect:/logout" : "redirect:/";
                                } else {
                                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                                    retVal = FORGOTPWDURL;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidderFrgtPwdLinkId, submitForgotPasswordAudit, 0, userId);
        }
        return retVal;
    }

    /**
     * to get changepassword on login page
     *
     * @param response
     * @param request
     * @param session
     * @return String
     */
    @RequestMapping(value = "/changepasswordonlogin", method = RequestMethod.GET)
    public String changePasswordOnLogin(HttpServletRequest request, HttpSession session) {
        SessionBean sessionBean = null;
        try {
            //ClientBean clientBean = request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null ? (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) : null;
            if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
                sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
            }
            if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null/*(clientBean.getIsPkiEnabled() == 1 && session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null) || (clientBean.getIsPkiEnabled() == 0 && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null)*/) { //(clientBean.getIsPkiEnabled() == 1 && session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null) || (clientBean.getIsPkiEnabled() == 0 && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null)
                return "redirect:/";
            }
            session.setAttribute("SECURITY_CHNGPASS", UUID.randomUUID().toString());
            request.setAttribute("hintQueList", modelToSelectItem.convertListIntoSelectItemList(commonService.getHintQuestionList(), "hintQuestionId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
            request.setAttribute("userType", sessionBean.getUserTypeId());
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sessionBean.getUserTypeId() == 2 ? bidderChnPwdLinkId : deptUserChnPwdLinkId, changePasswordOnLoginAudit, 0, 0);
        }
        return "ChangePasswordOnLogin";
    }
    /**
     * to get UpdateLoginId on login page
     *
     * @param response
     * @param request
     * @param session
     * @return String
     */
    @RequestMapping(value = "/updateloginid", method = RequestMethod.GET)
    public String updateLoginId(HttpServletRequest request, HttpSession session) {
        SessionBean sessionBean = null;
        try {            
            if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
                sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
            }
            if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null/*(clientBean.getIsPkiEnabled() == 1 && session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null) || (clientBean.getIsPkiEnabled() == 0 && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null)*/) { //(clientBean.getIsPkiEnabled() == 1 && session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null) || (clientBean.getIsPkiEnabled() == 0 && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null)
                return "redirect:/loginfailed";
            }            
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sessionBean.getUserTypeId() == 2 ? bidderChnPwdLinkId : deptUserChnPwdLinkId, changePasswordOnLoginAudit, 0, 0);
        }
        return "UpdateLoginId";
    }
    /**
     * to get updatepassworddtls on login page
     * author Lipi Shah
     */
    @RequestMapping(value = "/updatepassworddtls", method = RequestMethod.GET)
    public String updatePassword(HttpServletRequest request, HttpSession session,ModelMap modelMap) {
        SessionBean sessionBean = null;
        try {            
            if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
                sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
            }
            if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null/*(clientBean.getIsPkiEnabled() == 1 && session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null) || (clientBean.getIsPkiEnabled() == 0 && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null)*/) { //(clientBean.getIsPkiEnabled() == 1 && session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null) || (clientBean.getIsPkiEnabled() == 0 && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null)
            	return "redirect:/loginfailed";
            }            
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sessionBean.getUserTypeId() == 2 ? bidderChnPwdLinkId : deptUserChnPwdLinkId, changePasswordOnLoginAudit, 0, 0);
        }
        return "updatePassword";
    }

    /**
     * to get UpdateLoginId on login page
     *
     * @param response
     * @param request
     * @param session
     * @return String
     */
    @RequestMapping(value = "/submitupdatedloginid", method = RequestMethod.POST)
    public String submitupdatedloginid(HttpServletRequest request, HttpSession session,RedirectAttributes redirectAttributes) {
        SessionBean sessionBean = null;
        String pageName= "redirect:/logout";
        try {            
            ClientBean clientBean = request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null ? (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString()) : null;
            if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
                sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
            }
            if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null/*(clientBean.getIsPkiEnabled() == 1 && session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null) || (clientBean.getIsPkiEnabled() == 0 && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null)*/) { //(clientBean.getIsPkiEnabled() == 1 && session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null) || (clientBean.getIsPkiEnabled() == 0 && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null)
                return "redirect:/loginfailed";
            }
            String txtEmailId = StringUtils.hasLength(request.getParameter("txtEmailId")) ? request.getParameter("txtEmailId") : "";
            String txtPassword = StringUtils.hasLength(request.getParameter("txtPassword")) ? request.getParameter("txtPassword") : "";
//            String txtConfirmPassword = StringUtils.hasLength(request.getParameter("txtConfirmPassword")) ? request.getParameter("txtConfirmPassword") : "";
            
            boolean isMigrated = StringUtils.hasLength(request.getParameter("hdIsMigrated")) ? Boolean.parseBoolean(request.getParameter("hdIsMigrated")) : false;
            boolean cstatus = wSCheckAvailService.updateSSOLoginCredentils(sessionBean.getUserName(), isMigrated ? sessionBean.getUserName() : txtEmailId, sha256HashEncryption.encodeStringSHA256(txtPassword)+"~~"+sha1HashEncryption.encodeStringSHA1(txtPassword), sessionBean.getUserId(), clientBean.getClientId());
            if(cstatus){
            	if(loginService.updateLoginCredentials(sessionBean.getUserName(),isMigrated ? sessionBean.getUserName() : txtEmailId, sha256HashEncryption.encodeStringSHA256(txtPassword))){
            		loginService.updateMigrateStatus(isMigrated ? sessionBean.getUserName() : txtEmailId);
                    request.getSession().setAttribute(CommonKeywords.SUCCESS_MSG.toString(),isMigrated ? "redirect_success_forgotpassword" : "emailId_password_updated_success");
                }else{
                    request.getSession().setAttribute(CommonKeywords.ERROR_MSG_KEY.toString(),CommonKeywords.ERROR_MSG.toString());
                    return "UpdateLoginId";
                }
            }else if (WSCheckAvail.isSsoAvailable() && !cstatus) {
    			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
    		}else{
    			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
    		}
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            //auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sessionBean.getUserTypeId() == 2 ? bidderChnPwdLinkId : deptUserChnPwdLinkId, changePasswordOnLoginAudit, 0, 0);
        }
        return pageName;
    }

    /**
     * to get change password page
     *
     * @param response
     * @param request
     * @return String
     */
    @RequestMapping(value = "/changepassword/{enc}", method = RequestMethod.GET)
    public String changePassword(HttpServletRequest request) {
        SessionBean sessionBean = null;
        try {
            HttpSession session = request.getSession();
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                sessionBean = (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
            }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sessionBean.getUserTypeId() == 2 ? bidderChnPwdLinkId : deptUserChnPwdLinkId, changePasswordAudit, 0, 0);
        }
        return "ChangePassword";
    }

    /**
     * to submit change password
     *
     * @param changePassDataBean
     * @param result
     * @param map
     * @param redirectAttributes
     * @param request
     * @return String
     */
    @RequestMapping(value = "/submitchangepassword", method = RequestMethod.POST)
    public String submitChangePassword(@ModelAttribute ChangePassDataBean changePassDataBean, BindingResult result, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/";
        SessionBean sessionBean = null;
        String auditTrailMessage="";
        boolean status = false;
        boolean isSSOEnabled = false;
        try {
            HttpSession session = request.getSession();
            sessionBean = (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            isSSOEnabled = clientBean.isIsSsoEnabled();
            changePassDataBean.setCommonValidators(commonValidators);
            changePassDataBean.validateBean(result);
            if (result.hasErrors()) {
                //request.setAttribute("hintQueList", modelToSelectItem.convertListIntoSelectItemList(commonService.getHintQuestionList(),"hintQuestionId","lang"+WebUtils.getCookie(request, "locale").getValue()));
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                retVal = "ChangePassword";
                auditTrailMessage=failedPasswordChange;
            } else {
                boolean dataIn = loginService.isPassValid(sessionBean.getUserId(), changePassDataBean.getTxtNewPass());
                if (loginService.checkChangePassword(sessionBean.getUserId(), changePassDataBean.getTxtOldPass()+"~~"+changePassDataBean.getTxtsha1oldpass())) {
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_changepassword_oldpwd");
                    retVal = "redirect:/changepassword" + encryptDecryptUtils.generateRedirect("changepassword", request);
                    auditTrailMessage=failedPasswordChange;
                } else if (!dataIn) {
                    redirectAttributes.addFlashAttribute("errorMsgPwdRepeat", "redirect_failure_pwdnotrepeat");
                    redirectAttributes.addFlashAttribute("msgArgmnt", passMaxRepeat);
                    retVal = "redirect:/changepassword" + encryptDecryptUtils.generateRedirect("changepassword", request);
                    auditTrailMessage=failedPasswordChange;
                } else {
                	if(isSSOEnabled){
	                	status = wSCheckAvailService.changePassword(sessionBean.getUserName(), changePassDataBean.getTxtNewPass()+"~~"+changePassDataBean.getTxtsha1pass(),sessionBean.getUserId(),clientBean.getClientId());
	                	if (WSCheckAvail.isSsoAvailable() && !status) {
	            			//First dump user in sso from Local and then reset the pass
	                		status = wSCheckAvailService.dumpUserWithChngPwd(sessionBean.getUserId(),clientBean.getClientId(),sessionBean.getUserTypeId(),true,changePassDataBean.getTxtNewPass(),changePassDataBean.getTxtsha1pass());
	            		}
                	}else{
                		status = true;
                	}
                	if(status){
	                	status = loginService.updateForgotPass(sessionBean.getUserId(), changePassDataBean.getTxtNewPass(), null);
	                    TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
	                    tblPasswordHistory.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
	                    tblPasswordHistory.setOldPassword(changePassDataBean.getTxtNewPass());
	                    tblPasswordHistory.setCreatedBy(sessionBean.getUserId());
	                    tblPasswordHistory.setPasswordUpdatedFrom(2);
	                    status = status ? loginService.insertPwdHistory(tblPasswordHistory) : false;
	                    if (status) {
	                      redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_forgotpassword");
	                        int moduleId = Integer.parseInt(WebUtils.getCookie(request, "moduleId").getValue());
                        	if(moduleId==3){
                        		if(sessionBean.getUserTypeId()==2){
                        			int clientId = clientBean.getClientId();
                        	    	if(rciClientIds != null && !"".equals(rciClientIds))
                        	    	{
                        	    		if(CommonUtility.isClientConditionExistInProperty(rciClientIds,clientId))
                        	    		{
                        	    			boolean isRciBidderEnlisted = request.getSession().getAttribute("isRciBidderEnlisted") == null ? false : (Boolean) request.getSession().getAttribute("isRciBidderEnlisted");
                                    		if(!isRciBidderEnlisted)
                                    		{ // if company is not enlisted or approved
                                    			isRciBidderEnlisted = vendorEnlistmentService.isCompanyEnlistedAndApproved(clientId,commonService.getCompanyId(sessionBean.getUserId(), clientId));
                                    			request.getSession().setAttribute("isRciBidderEnlisted",isRciBidderEnlisted);
                                    			if(!isRciBidderEnlisted)
                                    			{
                                    				retVal = "redirect:/enlistment/bidder/pqpreferencelisting" + encryptDecryptUtils.generateRedirect("enlistment/bidder/pqpreferencelisting", request);
                                    			}
                                    			else
                                    			{
                                    				retVal = "redirect:/etender/bidder/tenderlisting/0"+encryptDecryptUtils.generateRedirect("etender/bidder/tenderlisting/0", request);
                                    			}
                                    		}
                                    		else
                                    		{
                                    			retVal = "redirect:/etender/bidder/tenderlisting/0"+encryptDecryptUtils.generateRedirect("etender/bidder/tenderlisting/0", request);
                                    		}
                        	    		}
                        	    		else
                        	    		{
                        	    			retVal = "redirect:/etender/bidder/tenderlisting/0"+encryptDecryptUtils.generateRedirect("etender/bidder/tenderlisting/0", request);	
                        	    		}
                        			}
                        			else
                        			{
                        				retVal = "redirect:/etender/bidder/tenderlisting/0"+encryptDecryptUtils.generateRedirect("etender/bidder/tenderlisting/0", request);
                        			}
                        			
                        		}else{
                        			//retVal = "redirect:/etender/buyer/tenderlisting"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderlisting", request);
                        			retVal = redirectAttributes.addFlashAttribute(CommonKeywords.SESSION_OBJ.toString()) != null ?"redirect:/logout" : "redirect:/";
                        		}
                        	}else if(moduleId==5){
                        		if(sessionBean.getUserTypeId()==2){
                        			retVal = "redirect:/eauction/bidder/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/bidder/auctionlisting", request);
                        		}else{
                        		retVal = "redirect:/eauction/auctioneer/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/auctionlisting", request);
                        		}
                        	}else if(moduleId==8){
                            	retVal = "redirect:/enlistment/admin/tasklist/0" + encryptDecryptUtils.generateRedirect("enlistment/admin/tasklist/0", request);
                            }else{
                            	retVal =  "redirect:/";
                            }
	                        auditTrailMessage=submitChangePasswordAudit;
	                    } else {
	                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
	                        retVal = "redirect:/changepassword" + encryptDecryptUtils.generateRedirect("changepassword", request);
	                        auditTrailMessage=failedPasswordChange;
	                    }
                	}else if (WSCheckAvail.isSsoAvailable() && !status) {
                		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                        retVal = "redirect:/changepassword" + encryptDecryptUtils.generateRedirect("changepassword", request);
                        auditTrailMessage=failedPasswordChange;
                	}else{
                		retVal = "redirect:/changepassword" + encryptDecryptUtils.generateRedirect("changepassword", request);
                		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
                		auditTrailMessage=ssoServNotAvail;
                	}
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sessionBean.getUserTypeId() == 2 ? bidderChnPwdLinkId : deptUserChnPwdLinkId, auditTrailMessage, 0, sessionBean.getUserId());
        }
        return retVal;
    }

    /**
     * to submit change password on login
     *
     * @param changePassDataBean
     * @param result
     * @param map
     * @param redirectAttributes
     * @param request
     * @return String
     */
    @RequestMapping(value = "/submitchangepasswordonlogin", method = RequestMethod.POST)
    public String submitChangePasswordOnLogin(@ModelAttribute ChangePassDataBean changePassDataBean, BindingResult result, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = null;
        SessionBean sessionBean = null;
        String auditTrailMessage="";
        boolean isSSOEnabled = false;
        boolean status = false;
        try {
            HttpSession session = request.getSession();
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                sessionBean = (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
            } else if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
                sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
            }
            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            changePassDataBean.setCommonValidators(commonValidators);
            changePassDataBean.validateBean(result);
            isSSOEnabled = clientBean.isIsSsoEnabled();
            if (result.hasErrors()) {
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                retVal = "redirect:/changepasswordonlogin";
                auditTrailMessage=failedPasswordChange;
            } else {
                String availCheck = request.getParameter("hdSecurityCheck");
                if (availCheck != null && availCheck.equals(session.getAttribute("SECURITY_CHNGPASS"))) {
                        boolean dataIn = loginService.isPassValid(sessionBean.getUserId(), changePassDataBean.getTxtNewPass());
                        if (loginService.checkChangePassword(sessionBean.getUserId(), changePassDataBean.getTxtOldPass()+"~~"+changePassDataBean.getTxtsha1oldpass())) {
                            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_changepassword_oldpwd");
                            retVal = "redirect:/changepasswordonlogin";
                            auditTrailMessage=failedPasswordChange;
                        } else if (!dataIn) {
                            redirectAttributes.addFlashAttribute("errorMsgPwdRepeat", "redirect_failure_pwdnotrepeat");
                            redirectAttributes.addFlashAttribute("msgArgmnt", passMaxRepeat);
                            retVal = "redirect:/changepasswordonlogin";
                            auditTrailMessage=failedPasswordChange;
                        } else {
                        	if(isSSOEnabled){
                        		status = wSCheckAvailService.changePassword(sessionBean.getUserName(), changePassDataBean.getTxtNewPass()+"~~"+changePassDataBean.getTxtsha1pass(),sessionBean.getUserId(),clientBean.getClientId());
                            	if (WSCheckAvail.isSsoAvailable() && !status) {
                        			//First dump user in sso from Local and then reset the pass
                            		status = wSCheckAvailService.dumpUserWithChngPwd(sessionBean.getUserId(),clientBean.getClientId(),sessionBean.getUserTypeId(),true,changePassDataBean.getTxtNewPass(),changePassDataBean.getTxtsha1pass());
                        		}
                        	}else{
                        		status = true;
                        	}
                            if(status){
                            	if(isSSOEnabled){
                            		wSCheckAvailService.updateHintQueAnswer(sessionBean.getUserName(),commonService.getHintQuestionById(changePassDataBean.getSelHintQuestion()!=null ? Integer.parseInt(changePassDataBean.getSelHintQuestion()):1).getLang1(),changePassDataBean.getTxtHintAns() != null ? changePassDataBean.getTxtHintAns() : "",sessionBean.getUserId(),clientBean.getClientId());
                            	}
                            	status = loginService.updateChangePassword(sessionBean.getUserId(), changePassDataBean.getTxtNewPass(), changePassDataBean.getSelHintQuestion()!=null?changePassDataBean.getSelHintQuestion():"1", changePassDataBean.getTxtHintAns()!=null?changePassDataBean.getTxtHintAns():"");
                                TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
                                tblPasswordHistory.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
                                tblPasswordHistory.setOldPassword(changePassDataBean.getTxtNewPass());
                                tblPasswordHistory.setCreatedBy(sessionBean.getUserId());
                                tblPasswordHistory.setPasswordUpdatedFrom(2);
                                status = status ? loginService.insertPwdHistory(tblPasswordHistory) : false;
                                if (status) {
                                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_forgotpassword");
                                    int userTypeId=sessionBean.getUserTypeId();
                                    int cStatus=0;
                                    int registrationWorkFlowId = 0;
                                    if(userTypeId ==2){
                                    	cStatus=manageBidderService.getBidderCstatus(clientBean.getClientId(), sessionBean.getUserId());
                                    	registrationWorkFlowId =manageBidderService.getBidderWorkflowId(clientBean.getClientId(), sessionBean.getUserId());
                                    }
                                    if(clientBean.getClientId() == SMclientId){
                                    	redirectAttributes.addAttribute("clientId", clientBean.getClientId());
                                    	redirectAttributes.addAttribute("userId", sessionBean.getUserId());
                                    	retVal = "redirect:/bidderregistrationforsm";
                                    }else{
                                    	
                                    	if(abcUtility.getSessionIsPkiEnabled(request)==1){
                                    		retVal = "redirect:/certimap";
                                    	}
                                    	else if(userTypeId == 2 && cStatus == 6 && registrationWorkFlowId == 9)
                                    	{
                                    		int userId = sessionBean.getUserId();
                                    		session.removeAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
                                    		session.setAttribute(CommonKeywords.SESSION_OBJ.toString(),sessionBean);
                                    		retVal = "redirect:/eauction/bidder/editbidder/"+userId+encryptDecryptUtils.generateRedirect("eauction/bidder/editbidder/"+userId, request);
                                    	}	
                                    	else{
                                    		if(!(userTypeId == 2 && (cStatus ==5 || cStatus==6))){
                                    			session.removeAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
                                    			session.setAttribute(CommonKeywords.SESSION_OBJ.toString(),sessionBean);
                                    		}
                                    		int moduleId = Integer.parseInt(WebUtils.getCookie(request, "moduleId").getValue());
                                    		if(userTypeId == 2 && cStatus == 5 && registrationWorkFlowId == 6 )
                                    		{	
                                    			redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_submitChangePassword");
                                    			retVal = "redirect:/bidderregcharges";
                                    		}else if(moduleId==3){
                                    			if(sessionBean.getUserTypeId()==2){
                                    				retVal = "redirect:/etender/bidder/tenderlisting/0"+encryptDecryptUtils.generateRedirect("etender/bidder/tenderlisting/0", request);
                                    			}else{
                                    				retVal = "redirect:/etender/buyer/tenderlisting"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderlisting", request);
                                    			}
                                    		}else if(moduleId==5){
                                    			if(sessionBean.getUserTypeId()==2){
                                    				retVal = "redirect:/eauction/bidder/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/bidder/auctionlisting", request);
                                    			}else{
                                    				retVal = "redirect:/eauction/auctioneer/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/auctionlisting", request);
                                    			}
                                    		}else if(moduleId==8){
                                    			retVal = "redirect:/enlistment/admin/tasklist/0" + encryptDecryptUtils.generateRedirect("enlistment/admin/tasklist/0", request);
                                    		}else{
                                    			retVal =  "redirect:/";
                                    		}
                                    	}
                                    }
                                                                    
                                    //retVal = abcUtility.getSessionIsPkiEnabled(request) == 1 ? "redirect:/certimap" : "redirect:/";
                                    auditTrailMessage=submitChangePasswordOnLoginAudit;
                                } else {
                                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                                    retVal = "redirect:/changepasswordonlogin";
                                    auditTrailMessage=failedPasswordChange;
                                }
                            }else if (WSCheckAvail.isSsoAvailable() && !status) {
                            	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                                retVal = "redirect:/changepasswordonlogin";
                                auditTrailMessage=failedPasswordChange;
                            }
                            else{
                            	redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
                            	retVal = "redirect:/changepasswordonlogin";
                                auditTrailMessage=ssoServNotAvail;
                            }
                        }
                } else {
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                    retVal = "redirect:/changepasswordonlogin";
                    auditTrailMessage=failedPasswordChange;
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sessionBean.getUserTypeId() == 2 ? bidderChnPwdLinkId : deptUserChnPwdLinkId, auditTrailMessage, 0, sessionBean.getUserId());
        }
        return retVal;
    }

    @RequestMapping(value = "/unlockuserfrommail/{userId}/{randomCode}", method = RequestMethod.GET)
    public String unLockUserFromMail(@PathVariable("userId") String userId, @PathVariable("randomCode") String randomCode, HttpServletRequest request, RedirectAttributes redirectAttributes) {
        String uId = null;
        try {
            String rdCode = encryptDecryptUtils.decrypt(randomCode);
            uId = encryptDecryptUtils.decrypt(userId);
            boolean result = loginService.checkUserIdRandomCode(uId, rdCode);
            if (result) {
                int clientId = abcUtility.getSessionClientId(request);
                int createdBy = abcUtility.getSessionUserId(request);
                TblUserHistory tblUserHistory = new TblUserHistory();
                tblUserHistory.setActionType(actionTypeUnlock);
                tblUserHistory.setTblUserLogin(new TblUserLogin(Integer.parseInt(uId)));
                tblUserHistory.setCreatedBy(createdBy);
                tblUserHistory.setTblClient(new TblClient(clientId));
                result = departmentUserService.unLockUser(Integer.parseInt(uId), tblUserHistory, "M");
                if (result) {
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_unlockuser");
                } else {
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                }
            } else {
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidderUnlockMailLinkId, unLockUserFromMailAudit, 0, 0);
        }
        return "redirect:/";
    }

    /**
     * to get change password page when password get expired
     *
     * @param response
     * @param request
     * @return String
     */
    @RequestMapping(value = "/chngpassword", method = RequestMethod.GET)
    public String changePasswordExpired(HttpServletRequest request) {
        SessionBean sessionBean = null;
        try {
            HttpSession session = request.getSession();
            if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
                sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
                //System.out.println("In If condition : "+sessionBean.getUserTypeId());
            }
            if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null/*(clientBean.getIsPkiEnabled() == 1 && session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null) || (clientBean.getIsPkiEnabled() == 0 && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null)*/) { //(clientBean.getIsPkiEnabled() == 1 && session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) == null) || (clientBean.getIsPkiEnabled() == 0 && session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null)
                return "ChangePassword";
            }
            request.setAttribute("isFromPwdExp", "Y");
            session.setAttribute("SECURITY_CHNGPASS", UUID.randomUUID().toString());
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sessionBean.getUserTypeId() == 2 ? bidderChnPwdLinkId : deptUserChnPwdLinkId, changePasswordExpiredAudit, 0, 0);
        }
        return "ChangePassword";
    }

    /**
     * to submit change password
     *
     * @param changePassDataBean
     * @param result
     * @param map
     * @param redirectAttributes
     * @param request
     * @return String
     */
    @RequestMapping(value = "/submitchngpassword", method = RequestMethod.POST)
    public String submitChangePasswordExpired(@ModelAttribute ChangePassDataBean changePassDataBean, BindingResult result, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = "redirect:/";
        SessionBean sessionBean = null;
        String auditTrailMessage="";
        boolean isSSOEnabled = false;
        boolean status = false;
        try {
                HttpSession session = request.getSession();
            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            isSSOEnabled = clientBean.isIsSsoEnabled();
            if (session.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                sessionBean = (SessionBean) session.getAttribute(CommonKeywords.SESSION_OBJ.toString());
                //System.out.println("In if ::"+sessionBean.getUserTypeId());
            } else if (session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString()) != null) {
                sessionBean = (SessionBean) session.getAttribute(CommonKeywords.TEMP_SESSIONOBJ.toString());
                //System.out.println("In else ::"+sessionBean.getUserTypeId());
            }
            changePassDataBean.setCommonValidators(commonValidators);
            changePassDataBean.validateBean(result);
            if (result.hasErrors()) {
                //request.setAttribute("hintQueList", modelToSelectItem.convertListIntoSelectItemList(commonService.getHintQuestionList(),"hintQuestionId","lang"+WebUtils.getCookie(request, "locale").getValue()));
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                retVal = "redirect:/chngpassword";
                auditTrailMessage=failedPasswordChange;
            } else {
                String availCheck = request.getParameter("hdSecurityCheck");
                if (availCheck != null && availCheck.equals(session.getAttribute("SECURITY_CHNGPASS"))) {
                    boolean dataIn = loginService.isPassValid(sessionBean.getUserId(), changePassDataBean.getTxtNewPass());
                    if (loginService.checkChangePassword(sessionBean.getUserId(), changePassDataBean.getTxtOldPass())) {
                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_failure_changepassword_oldpwd");
                        retVal = "redirect:/chngpassword";
                        auditTrailMessage=failedPasswordChange;
                    } else if (!dataIn) {
                        redirectAttributes.addFlashAttribute("errorMsgPwdRepeat", "redirect_failure_pwdnotrepeat");
                        redirectAttributes.addFlashAttribute("msgArgmnt", passMaxRepeat);
                        retVal = "redirect:/chngpassword";
                        auditTrailMessage=failedPasswordChange;
                    } else {
                    	if(isSSOEnabled){
                    		status = wSCheckAvailService.changePassword(sessionBean.getUserName(), changePassDataBean.getTxtNewPass()+"~~"+changePassDataBean.getTxtsha1pass(),sessionBean.getUserId(),clientBean.getClientId());
                        	if (WSCheckAvail.isSsoAvailable() && !status) {
                    			//First dump user in sso from Local and then reset the pass
                        		status = wSCheckAvailService.dumpUserWithChngPwd(sessionBean.getUserId(),clientBean.getClientId(),sessionBean.getUserTypeId(),true,changePassDataBean.getTxtNewPass(),changePassDataBean.getTxtsha1pass());
                    		}
                    	}
                    	if((status && isSSOEnabled) || (!status && !isSSOEnabled)){
	                        status = loginService.updateForgotPass(sessionBean.getUserId(), changePassDataBean.getTxtNewPass(), null);
	                        TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
	                        tblPasswordHistory.setTblUserLogin(new TblUserLogin(sessionBean.getUserId()));
	                        tblPasswordHistory.setOldPassword(changePassDataBean.getTxtNewPass());
	                        tblPasswordHistory.setCreatedBy(sessionBean.getUserId());
	                        tblPasswordHistory.setPasswordUpdatedFrom(2);
	                        status = status ? loginService.insertPwdHistory(tblPasswordHistory) : false;
	                        //boolean status=true;
	                        if (status) {
	                            redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_forgotpassword");
	                            retVal = "redirect:/chngpassword";
	                            auditTrailMessage=submitChangePasswordExpiredAudit;
	                        } else {
	                            redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
	                            retVal = "redirect:/chngpassword";
	                            auditTrailMessage=failedPasswordChange;
	                        }
                    	}else if (WSCheckAvail.isSsoAvailable() && !status) {
                    		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                            retVal = "redirect:/chngpassword";
                            auditTrailMessage=failedPasswordChange;
                    	}else{
                			redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
                			retVal = "redirect:/chngpassword";
                            auditTrailMessage=ssoServNotAvail;
                    	}
                    }
                } else {
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                    retVal = "redirect:/chngpassword";
                    auditTrailMessage=failedPasswordChange;
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sessionBean.getUserTypeId() == 2 ? bidderChnPwdLinkId : deptUserChnPwdLinkId, auditTrailMessage, 0, sessionBean.getUserId());
        }
        return retVal;
    }

    private String getRedirectPage(HttpServletRequest request) throws Exception{
        int userTypeId = abcUtility.getSessionUserTypeId(request);
        String pageName = "redirect:/loginfailed";
        String moduleId = WebUtils.getCookie(request, "moduleId").getValue();
        int isCategoryAllow = 0;
        if(abcUtility.isModuleAssignToClient(request,9) ){  // Module Assign Spend Analysis 
        	isCategoryAllow = commonService.isCategoryStaticsAllow(abcUtility.getSessionClientId(request));
        }
        ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        int clientId = abcUtility.getSessionClientId(request);
        int userId = abcUtility.getSessionUserId(request); 
        
        switch(userTypeId){
            case 1 : 
//                pageName = "redirect:/common/admin/searchlistclient" + encryptDecryptUtils.generateRedirect("common/admin/searchlistclient", request);
//                break;
            	if(isCategoryAllow == 1){
            		pageName = "redirect:/common/CategoryWiseListingReport"+encryptDecryptUtils.generateRedirect("common/CategoryWiseListingReport", request);		
            	}else if("3".equals(moduleId)){
                    pageName = "redirect:/etender/buyer/tenderlisting"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderlisting", request);
                }else if("5".equals(moduleId)){
                		pageName = "redirect:/eauction/auctioneer/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/auctionlisting", request);	
                }else if("8".equals(moduleId)){
                    pageName = "redirect:/enlistment/admin/tasklist/0" + encryptDecryptUtils.generateRedirect("enlistment/admin/tasklist/0", request);
                }else{
                	pageName = "redirect:/welcome" + encryptDecryptUtils.generateRedirect("welcome", request);
                }
                break;
            case 2 :
            	if(isCategoryAllow == 1){
            		pageName = "redirect:/common/CategoryWiseListingReport"+encryptDecryptUtils.generateRedirect("common/CategoryWiseListingReport", request);		
            	}else if("3".equals(moduleId)){
                    pageName = "redirect:/etender/bidder/tenderlisting/0"+encryptDecryptUtils.generateRedirect("etender/bidder/tenderlisting/0", request);
                }else if("5".equals(moduleId)){
                	if(clientBean!=null && clientBean.getIsDIYClient()==1) {
                		pageName = "redirect:/eauction/bidder/quickauctionlisting" + encryptDecryptUtils.generateRedirect("eauction/bidder/quickauctionlisting", request);
                	}
                	else {
                		pageName = "redirect:/eauction/bidder/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/bidder/auctionlisting", request);
                	}
                }else if("8".equals(moduleId)){
                    pageName = "redirect:/enlistment/bidder/pqpreferencelisting" + encryptDecryptUtils.generateRedirect("enlistment/bidder/pqpreferencelisting", request);
                }else{
                	pageName = "redirect:/welcome" + encryptDecryptUtils.generateRedirect("welcome", request);
                }
            	if(CommonUtility.isClientConditionExistInProperty(rciClientIds, clientId)){
            		boolean isRciBidderEnlisted = request.getSession().getAttribute("isRciBidderEnlisted") == null ? false : (Boolean) request.getSession().getAttribute("isRciBidderEnlisted");
            		if(!isRciBidderEnlisted){ // if company is not enlisted or approved
            			isRciBidderEnlisted = vendorEnlistmentService.isCompanyEnlistedAndApproved(clientId,commonService.getCompanyId(userId, clientId));
            			request.getSession().setAttribute("isRciBidderEnlisted",isRciBidderEnlisted);
            			if(!isRciBidderEnlisted){
            				pageName = "redirect:/enlistment/bidder/pqpreferencelisting" + encryptDecryptUtils.generateRedirect("enlistment/bidder/pqpreferencelisting", request);
            			}
            		}
            	}
            	if(CommonUtility.isClientConditionExistInProperty(gslClientIds, clientId)){
            		boolean isGslBidderRegDone = request.getSession().getAttribute("isGslBidderRegDone") == null ? false : (Boolean) request.getSession().getAttribute("isGslBidderRegDone");
            		if(!isGslBidderRegDone){ // if bidder reg for industry type and classification - gsl only
            			isGslBidderRegDone = manageBidderService.isBidderRegInBidderIndustry(clientId, userId);
            			request.getSession().setAttribute("isGslBidderRegDone",isGslBidderRegDone);
            			if(!isGslBidderRegDone){
            				pageName = "redirect:/eauction/bidder/editbidder/"+ userId +encryptDecryptUtils.generateRedirect("eauction/bidder/editbidder/"+ userId , request);
            			}
            		}
            	}
                break;
            case 3 :
            	if(isCategoryAllow == 1){
            		pageName = "redirect:/common/CategoryWiseListingReport"+encryptDecryptUtils.generateRedirect("common/CategoryWiseListingReport", request);		
            	}else if("3".equals(moduleId)){
                    pageName = "redirect:/etender/buyer/tenderlisting"+encryptDecryptUtils.generateRedirect("etender/buyer/tenderlisting", request);
                }else if("5".equals(moduleId)){
                	if(clientBean!=null && clientBean.getIsDIYClient()==1) {
                		pageName = "redirect:/eauction/auctioneer/quickauctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/quickauctionlisting", request);
                	}
                	else {
                		pageName = "redirect:/eauction/auctioneer/auctionlisting" + encryptDecryptUtils.generateRedirect("eauction/auctioneer/auctionlisting", request);
                	}
                }else if("8".equals(moduleId)){
                    pageName = "redirect:/enlistment/admin/tasklist/0" + encryptDecryptUtils.generateRedirect("enlistment/admin/tasklist/0", request);
                }else{
                	pageName = "redirect:/welcome" + encryptDecryptUtils.generateRedirect("welcome", request);
                }
                break;
        }
        return pageName;
    }
    
    @RequestMapping(value = "/showReortList", method = RequestMethod.POST)
    public String showReportLogin(HttpServletRequest req, ModelMap map,RedirectAttributes redirectAttributes) throws Exception {
        if(StringUtils.hasLength(req.getParameter("txtReportId")))
        {
            redirectAttributes.addFlashAttribute("reportId",req.getParameter("txtReportId"));
        }
        if(StringUtils.hasLength(req.getParameter("txtModuleId")))
        {
            redirectAttributes.addFlashAttribute("moduleId",req.getParameter("txtModuleId"));
        }
        ClientBean clientBean = (ClientBean) req.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
        List<Object> lstClientSector = clientService.getClientSector(clientBean.getClientId()); 
        int sectorId = lstClientSector.size() > 0 ? (Integer)lstClientSector.get(0) : 0;
    	if((((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1))){
    		return "redirect:/searchTender";
    	}else if(GMRTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1])){
    		
    		return "redirect:/searchGMR";
    	}else if(agNextTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1])){
    		redirectAttributes.addFlashAttribute("txtKeywordSearch",req.getParameter("txtKeywordSearch"));
    		return "redirect:/ajaxSearchAgNext";
    	}else{
    		return "redirect:/";	
    	}
    }

    /**
     * to get change password before login CR: 20457
     * @author bharat
     * @param response
     * @param request
     * @param session
     * @return String
     */
    @RequestMapping(value = "/changepasswordbeforelogin/{userId}", method = RequestMethod.GET)
    public String changePasswordBeforeLogin(HttpServletRequest request, HttpSession session,@PathVariable("userId") String encryptedUserId,RedirectAttributes redirectAttributes) {
    	String decryptedUserId = "";
    	int userId = 0;
    	String retVal = "ResetPasswordBeforeLogin";
        try {
        	decryptedUserId = encryptDecryptUtils.decrypt(encryptedUserId);
        	if(decryptedUserId != null && !decryptedUserId.isEmpty()){
        		userId = Integer.parseInt(decryptedUserId);
	        	TblUserLogin tblUserLogin = loginService.getUserLoginById(userId);
	        	if(tblUserLogin != null){
		      	    String emailId = tblUserLogin.getLoginId();
		      	    if(emailId == null || commonValidators.rangeLengthValidation(emailId, 6, 50) == false || commonValidators.isValidEmailId(emailId) == false){
		     	        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_regenerate_reset_password_url");
		     	        retVal = "redirect:/";
		            }else{
			        	//request.setAttribute("SECURITY_CHNGPASS", UUID.randomUUID().toString());
			            request.setAttribute("hintQueList", modelToSelectItem.convertListIntoSelectItemList(commonService.getHintQuestionList(), "hintQuestionId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
			            request.setAttribute("encryptedUserId", encryptedUserId);
			            request.setAttribute("decryptedUserId", decryptedUserId);
			            
			            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
			            request.setAttribute("isPkiEnabled",clientBean.getIsPkiEnabled()); 
			            retVal = "ResetPasswordBeforeLogin";
		            }
	        	}else{
	        	   redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_regenerate_reset_password_url");
	        	   retVal = "redirect:/";
	        	}
        	}else{
        		   redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "msg_regenerate_reset_password_url");
        		   retVal = "redirect:/";
        	}
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deptUserChnPwdLinkId, callChangepasswordBeforeLogin, 0, userId);
        }
        return retVal;
    }
    
    /**
     * send password reset link to users registered mailid.CR: 20457	
     * @author bharat
     * @param request
     * @param session
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/resetpasswordsendmail", method = RequestMethod.POST)
    public String resetPasswordSendmail(HttpServletRequest request, HttpSession session,RedirectAttributes redirectAttributes) {
       
        String retVal="";
        int userId = 0;
        boolean success=false;
        try {
        		String emailId = request.getParameter("emailId");
        	   if(emailId == null || commonValidators.rangeLengthValidation(emailId, 6, 50) == false || commonValidators.isValidEmailId(emailId) == false){
        	       redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "validation_email_valid");
               }else{
            	   TblUserLogin tblUserLogin = loginService.getUserLoginByLoginId(emailId);
            	   if(tblUserLogin == null || tblUserLogin.getUserId() == 0)
            	   {
            		   redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "validation_email_valid");
            	   }else{
                	   userId = tblUserLogin.getUserId();
                	   Map<String, Object> paramMap = new HashMap<String, Object>();
	           		   paramMap.put("to", emailId);
	           		   paramMap.put("Resetlink", "<a href=\"/changepasswordbeforelogin/"+encryptDecryptUtils.encrypt(userId+"")+"\">Reset Password</a>");
                	   mailContentUtillity.dynamicMailGeneration(mailResetPasswordLink+"", String.valueOf(userId), String.valueOf(abcUtility.getSessionClientId(request)), paramMap, null);
                	   success=true;
                	   redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "msg_reset_password_link_sent_success" : CommonKeywords.ERROR_MSG_KEY.toString());
	            	   //redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "msg_reset_password_link_sent_success");
            	   }
               }
    		   retVal = FORGOTPWDURL;
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
        	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidderChnPwdLinkId, sendResetPasswordLinkAudit, 0, userId);
        }
        return retVal;
    }
    
    /**
     * to change password before login CR: 20457	
     * @author bharat
     * @param changePassDataBean
     * @param result
     * @param map
     * @param redirectAttributes
     * @param request
     * @return String
     */
    @RequestMapping(value = "/submitchangepasswordbeforelogin", method = RequestMethod.POST)
    public String submitChangePasswordBeforeLogin(@ModelAttribute ChangePassDataBean changePassDataBean, BindingResult result, RedirectAttributes redirectAttributes, HttpServletRequest request) {
        String retVal = null;
        String auditTrailMessage="";
        String encryptedUserId = "";
        int decryptedUserId = 0;
        try {
        	encryptedUserId = request.getParameter("hdEncryptedUserId") == null ? "0" : request.getParameter("hdEncryptedUserId");
        	decryptedUserId = request.getParameter("hdDecryptedUserId") == null ? 0 : Integer.parseInt(request.getParameter("hdDecryptedUserId"));
        	
            ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            changePassDataBean.setCommonValidators(commonValidators);
            changePassDataBean.validateBeanWithoutOldPassword(result);
            if (result.hasErrors()) {
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                retVal = "redirect:/changepasswordbeforelogin/"+encryptedUserId;
                auditTrailMessage=failedPasswordChange;
            } else {
            	// un-comment it, if you want to validate password with previously inserted password.
                //boolean dataIn = loginService.isPassValid(decryptedUserId, changePassDataBean.getTxtNewPass());
            	boolean dataIn = true;
                if (!dataIn) {
                    redirectAttributes.addFlashAttribute("errorMsgPwdRepeat", "redirect_failure_pwdnotrepeat");
                    redirectAttributes.addFlashAttribute("msgArgmnt", passMaxRepeat);
                    retVal = "redirect:/changepasswordbeforelogin/"+encryptedUserId;
                    auditTrailMessage=failedPasswordChange;
                } else {
                	List<TblUserLogin> userLogins = commonService.getUserLoginById(decryptedUserId);
                	TblUserLogin userLogin = userLogins != null && userLogins.isEmpty() ? null : userLogins.get(0);
                	boolean status = wSCheckAvailService.changePassword(userLogin.getLoginId(), changePassDataBean.getTxtNewPass()+"~~"+changePassDataBean.getTxtsha1pass(),decryptedUserId,clientBean.getClientId());
                	if (WSCheckAvail.isSsoAvailable() && !status) {
            			//First dump user in sso from Local and then reset the pass
                		status = wSCheckAvailService.dumpUserWithChngPwd(userLogin.getUserId(),clientBean.getClientId(),commonService.getUserTypeId(userLogin.getUserId()),true,changePassDataBean.getTxtNewPass(),changePassDataBean.getTxtsha1pass());
            		}
                	if (status) {
	                    wSCheckAvailService.updateHintQueAnswer(userLogin.getLoginId(),commonService.getHintQuestionById(changePassDataBean.getSelHintQuestion()!=null?Integer.parseInt(changePassDataBean.getSelHintQuestion()):1).getLang1(),changePassDataBean.getTxtHintAns()!=null?changePassDataBean.getTxtHintAns():"",decryptedUserId,clientBean.getClientId());
	                    status = loginService.updateChangePassword(decryptedUserId, changePassDataBean.getTxtNewPass(), changePassDataBean.getSelHintQuestion()!=null?changePassDataBean.getSelHintQuestion():"1", changePassDataBean.getTxtHintAns()!=null ? changePassDataBean.getTxtHintAns() :"");
	                    TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
	                    tblPasswordHistory.setTblUserLogin(new TblUserLogin(decryptedUserId));
	                    tblPasswordHistory.setOldPassword(changePassDataBean.getTxtNewPass());
	                    tblPasswordHistory.setCreatedBy(decryptedUserId);
	                    tblPasswordHistory.setPasswordUpdatedFrom(2);
	                    status = status ? loginService.insertPwdHistory(tblPasswordHistory) : false;
	                    //boolean status=true;
	                    if (status) {
	                        redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(), "redirect_success_reset_password");
                            retVal =  "redirect:/";
	                        auditTrailMessage=callSubmitChangepasswordBeforeLogin;
	                    } else {
	                        redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
	                        retVal = "redirect:/changepasswordbeforelogin/"+encryptedUserId;
	                        auditTrailMessage=failedPasswordChange;
	                    }
                	}else if (WSCheckAvail.isSsoAvailable() && !status) {
                		//Error in dumpUserWithChngPwd
                		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), CommonKeywords.ERROR_MSG_KEY.toString());
                        retVal = "redirect:/changepasswordbeforelogin/"+encryptedUserId;
                        auditTrailMessage=failedPasswordChange;
                	}else{
                		redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_reg_serv_not_avail");
                		retVal = "redirect:/changepasswordbeforelogin/"+encryptedUserId;
                        auditTrailMessage=ssoServNotAvail;
                	}
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), deptUserChnPwdLinkId, auditTrailMessage, 0, decryptedUserId);
        }
        return retVal;
    }
    /**
     * To manage home page content for DIY.
     * @param modelMap
     * @param flag
     * @param request
     * @return
     */
    @RequestMapping(value = "/gethomepagecontent/{flag}", method = RequestMethod.GET)
    public String getHomePageContent(ModelMap modelMap,@PathVariable("flag")String flag,HttpServletRequest request){
    	int subBizModelId = 0;
    	if(flag.contains("subBizModel")) {
    		subBizModelId = Integer.parseInt(flag.split("_")[1]);
    		modelMap.addAttribute("flag", "subBizModel");
    		modelMap.addAttribute("subBizModelId", subBizModelId);
    	}
    	return "/HomePageContent";
    }
    
    /**
     * author Lipi
     * check login id is for bidder or buyer
     */
    @RequestMapping(value = "ajaxcall/isBidderOrBuyer", method = RequestMethod.POST)
	@ResponseBody
	public String isBidderOrBuyer(@RequestParam("txtLoginId") String loginId,@RequestParam("txtLoginUrl") String loginurl ,HttpServletRequest request) {
		String retVal = ""; 
	    try {
	    	
	    		int tempretVal = commonService.getUserTypeId(commonService.getUserIdByLoginId(loginId));
	    		ClientBean clientBean = (ClientBean) request.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
	    		
	    		request.getSession().setAttribute("sessionUserType",tempretVal);
	    		request.getSession().setAttribute("sessionIsLoginLinkConfigured",clientBean.getIsLoginLinkConfigured());
	    		request.getSession().setAttribute("sessionLoginurl",loginurl);
	    		
	    		retVal = String.valueOf(tempretVal);
	    } catch (Exception e) {
	        exceptionHandlerService.writeLog(e);
	    }
	    return retVal;
	}
    

   /**
     * author Lipi
     * to get login info
     */
	@RequestMapping(value = {"/buyerlogin","/bidderlogin"}, method = RequestMethod.GET)
	public String bidderRegistration(HttpServletRequest request,HttpSession session, ModelMap map, HttpServletResponse response) {
		String pageName;
		String sessionLoginurl;
	    pageName = getHomePageData(request,session,map,response,0,0,false);
	    int ShowAccessDetail=abcUtility.getAccessDetail(request);
	    String mapping = request.getServletPath();
	    
	    if(mapping.contains("bidderlogin"))
	    {
	    	sessionLoginurl="bidderlogin";
	    }
	    else
	    {
	    	sessionLoginurl="buyerlogin";
	    }

	    request.getSession().setAttribute("sessionLoginurl",sessionLoginurl);
	    
	    if(ShowAccessDetail==1){
			int visitorCount=commonService.getVisitorDetail(request);
	    	map.addAttribute("visitorCount",visitorCount);
		}
	    return pageName;
	}
    /**
     * author Lipi
     * to set URL as per Buyer or Bidder login 
     */
    @RequestMapping(value = "/setLoginWindowUrl", method = RequestMethod.POST)
    public String setLoginWindowURL(HttpServletRequest request, RedirectAttributes redirectAttributes) {
    	String pageName = "";
    	String sessionLoginurl = null;
    	int userType = StringUtils.hasLength(request.getParameter("hdUserType"))?Integer.parseInt(request.getParameter("hdUserType")):0;
    	
    		if(userType==1){
    			pageName = "redirect:/buyerlogin";
    			sessionLoginurl = "buyerlogin";
    		}else if(userType==2){
    			pageName = "redirect:/bidderlogin";
    			sessionLoginurl = "bidderlogin";
    		}
    	request.getSession().setAttribute("sessionLoginurl",sessionLoginurl);
    	return pageName;
    }
    @RequestMapping(value = "/drtauction", method = RequestMethod.GET)
	public String viewDrtAuction() {
		return "drtAuction";
	}
    @RequestMapping(value = "/primeauction", method = RequestMethod.GET)
	public String viewPrimeAuction() {
		return "viewPrimeAuction";
	}
    @RequestMapping(value = "/goldauction", method = RequestMethod.GET)
	public String viewGoldAuction() {
		return "viewGoldAuction";
	}
    @RequestMapping(value = "/valuationandpublication", method = RequestMethod.GET)
	public String valuationandpublication() {
		return "valuationAndPublication";
	}
    
	/* CSP BEFORE LOGIN */
    @RequestMapping(value = "/common/rcsp", method = RequestMethod.POST)
    public @ResponseBody void rcsp(HttpServletRequest request) throws Exception {
    }
    
    @RequestMapping(value = "/sendapplicationlink", method = RequestMethod.POST)
	public String sendApplicationLink(HttpServletRequest request, RedirectAttributes redirectAttributes) {
    	//String hdsmsvalue = "Thank you for choosing us to fulfill your business needs. Download our App:";
    	String downloadLink=null;
    	String smsValue=null;
    	int senderId = 0;
    	int isChecked=0;
    	String senderIdValue=null;
    	try
    	{
    	Map<String, Object> paramMap = new HashMap<String, Object>();
    	int contentId=Integer.parseInt(request.getParameter("txtsmsvalue"));
    	 List<Object[]> bannerList= new ArrayList<Object[]>();
    	 
          	bannerList=manageContentService.getContentManagementById(contentId);
    	
          	 if(!bannerList.isEmpty()){
          		 for(Object[] banner : bannerList){
          			downloadLink=banner[4].toString();
          			senderId=Integer.parseInt(banner[7].toString());
     	        	System.out.println(banner[3].toString() +""+ banner[4].toString());
     	        	}
          	 }
	   	
          	 if(senderId==1)
          	 {
          		senderIdValue ="ABCAPP";
          	 }
          	 else if(senderId==2)
          	 {
          		senderIdValue="AUCTGR";
          	 }
          	 else if(senderId==3)
          	 {
          		senderIdValue="PRCTGR";
          	 }
          	 
    	String txtmobilevalue=request.getParameter("txtmobileNo");
    	isChecked=Integer.parseInt(request.getParameter("smsRequire"));
    	smsValue=downloadLink;
    	paramMap.put("message", smsValue);
 		paramMap.put("mobileNumber",txtmobilevalue);
 		paramMap.put("senderIdValue", senderIdValue);
 	    smsContentUtillity.smsApplicationLink(paramMap);
 	    TblContentMobile tblContentMobile=new TblContentMobile();
 	   
	    tblContentMobile.setTblContentManagement(new TblContentManagement(contentId));
	    tblContentMobile.setMobileNo(txtmobilevalue);
	    tblContentMobile.setCreatedOn(commonService.getServerDateTime());
	    tblContentMobile.setIsAgree(isChecked);
	    boolean bSuccess=manageContentService.addMobileData(tblContentMobile);
    	}
    	catch(Exception e)
    	{
    		exceptionHandlerService.writeLog(e);
    	}
    	
    	return null;
	}
    
}
