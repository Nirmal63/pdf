package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblModule;
import java.util.List;

public interface TblModuleDao  {

    public void addTblModule(TblModule tblModule);

    public void deleteTblModule(TblModule tblModule);

    public void updateTblModule(TblModule tblModule);

    public List<TblModule> getAllTblModule();

    public List<TblModule> findTblModule(Object... values) throws Exception;

    public List<TblModule> findByCountTblModule(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblModuleCount();

    public void saveUpdateAllTblModule(List<TblModule> tblModules);
}