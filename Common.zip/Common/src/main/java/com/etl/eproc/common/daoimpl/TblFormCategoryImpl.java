package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblFormCategory;
import com.etl.eproc.common.daointerface.TblFormCategoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblFormCategoryImpl extends AbcAbstractClass<TblFormCategory> implements TblFormCategoryDao {

    @Override
    public void addTblFormCategory(TblFormCategory tblFormCategory){
        super.addEntity(tblFormCategory);
    }

    @Override
    public void deleteTblFormCategory(TblFormCategory tblFormCategory) {
        super.deleteEntity(tblFormCategory);
    }

    @Override
    public void updateTblFormCategory(TblFormCategory tblFormCategory) {
        super.updateEntity(tblFormCategory);
    }

    @Override
    public List<TblFormCategory> getAllTblFormCategory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFormCategory> findTblFormCategory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFormCategoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFormCategory> findByCountTblFormCategory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFormCategory(List<TblFormCategory> tblFormCategorys){
        super.updateAll(tblFormCategorys);
    }
}
