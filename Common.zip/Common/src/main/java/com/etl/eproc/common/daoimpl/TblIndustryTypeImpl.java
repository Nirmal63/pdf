/**
 * 
 */
package com.etl.eproc.common.daoimpl;

/**
 * @author janak
 *
 */
import com.etl.eproc.common.model.TblIndustryType;
import com.etl.eproc.common.daointerface.TblIndustryTypeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblIndustryTypeImpl extends AbcAbstractClass<TblIndustryType> implements TblIndustryTypeDao {

    @Override
    public void addTblIndustryType(TblIndustryType tblIndustryType){
        super.addEntity(tblIndustryType);
    }

    @Override
    public void deleteTblIndustryType(TblIndustryType tblIndustryType) {
        super.deleteEntity(tblIndustryType);
    }

    @Override
    public void updateTblIndustryType(TblIndustryType tblIndustryType) {
        super.updateEntity(tblIndustryType);
    }

    @Override
    public List<TblIndustryType> getAllTblIndustryType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblIndustryType> findTblIndustryType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblIndustryTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblIndustryType> findByCountTblIndustryType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblIndustryType(List<TblIndustryType> tblIndustryTypes){
        super.updateAll(tblIndustryTypes);
    }
}
