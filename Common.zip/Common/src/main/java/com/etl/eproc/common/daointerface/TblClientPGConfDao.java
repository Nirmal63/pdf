package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientPGConf;
import java.util.List;

public interface TblClientPGConfDao  {

    public void addTblClientPGConf(TblClientPGConf tblClientPGConf);

    public void deleteTblClientPGConf(TblClientPGConf tblClientPGConf);

    public void updateTblClientPGConf(TblClientPGConf tblClientPGConf);

    public List<TblClientPGConf> getAllTblClientPGConf();

    public List<TblClientPGConf> findTblClientPGConf(Object... values) throws Exception;

    public List<TblClientPGConf> findByCountTblClientPGConf(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientPGConfCount();

    public void saveUpdateAllTblClientPGConf(List<TblClientPGConf> tblClientPGConfs);

	public void saveOrUpdateTblClientPGConf(TblClientPGConf tblClientPGConf);
}