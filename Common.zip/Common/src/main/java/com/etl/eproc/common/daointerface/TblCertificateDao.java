package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCertificate;
import java.util.List;

public interface TblCertificateDao  {

    public void addTblCertificate(TblCertificate tblCertificate);

    public void deleteTblCertificate(TblCertificate tblCertificate);

    public void updateTblCertificate(TblCertificate tblCertificate);

    public List<TblCertificate> getAllTblCertificate();

    public List<TblCertificate> findTblCertificate(Object... values) throws Exception;

    public List<TblCertificate> findByCountTblCertificate(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCertificateCount();

    public void saveUpdateAllTblCertificate(List<TblCertificate> tblCertificates);
}