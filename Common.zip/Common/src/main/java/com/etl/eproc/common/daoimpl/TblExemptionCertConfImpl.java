package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblExemptionCertConf;
import com.etl.eproc.common.daointerface.TblExemptionCertConfDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblExemptionCertConfImpl extends AbcAbstractClass<TblExemptionCertConf> implements TblExemptionCertConfDao {

    @Override
    public void addTblExemptionCertConf(TblExemptionCertConf tblExemptionCertConf){
        super.addEntity(tblExemptionCertConf);
    }

    @Override
    public void deleteTblExemptionCertConf(TblExemptionCertConf tblExemptionCertConf) {
        super.deleteEntity(tblExemptionCertConf);
    }

    @Override
    public void updateTblExemptionCertConf(TblExemptionCertConf tblExemptionCertConf) {
        super.updateEntity(tblExemptionCertConf);
    }

    @Override
    public List<TblExemptionCertConf> getAllTblExemptionCertConf() {
        return super.getAllEntity();
    }

    @Override
    public List<TblExemptionCertConf> findTblExemptionCertConf(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblExemptionCertConfCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblExemptionCertConf> findByCountTblExemptionCertConf(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblExemptionCertConf(List<TblExemptionCertConf> tblExemptionCertConfs){
        super.updateAll(tblExemptionCertConfs);
    }
}
