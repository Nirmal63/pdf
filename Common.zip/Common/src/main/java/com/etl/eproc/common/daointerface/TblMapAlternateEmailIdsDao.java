package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMapAlternateEmailIds;
import java.util.List;

public interface TblMapAlternateEmailIdsDao  {

    public void addTblMapAlternateEmailIds(TblMapAlternateEmailIds tblMapAlternateEmailIds);

    public void deleteTblMapAlternateEmailIds(TblMapAlternateEmailIds tblMapAlternateEmailIds);

    public void updateTblMapAlternateEmailIds(TblMapAlternateEmailIds tblMapAlternateEmailIds);

    public List<TblMapAlternateEmailIds> getAllTblMapAlternateEmailIds();

    public List<TblMapAlternateEmailIds> findTblMapAlternateEmailIds(Object... values) throws Exception;

    public List<TblMapAlternateEmailIds> findByCountTblMapAlternateEmailIds(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMapAlternateEmailIdsCount();

    public void saveUpdateAllTblMapAlternateEmailIds(List<TblMapAlternateEmailIds> tblMapAlternateEmailIdss);
}