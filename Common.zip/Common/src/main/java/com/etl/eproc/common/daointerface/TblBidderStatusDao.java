package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBidderStatus;

public interface TblBidderStatusDao  {

    public void addTblBidderStatus(TblBidderStatus tblBidderStatus);

    public void deleteTblBidderStatus(TblBidderStatus tblBidderStatus);

    public void updateTblBidderStatus(TblBidderStatus tblBidderStatus);

    public List<TblBidderStatus> getAllTblBidderStatus();

    public List<TblBidderStatus> findTblBidderStatus(Object... values) throws Exception;

    public List<TblBidderStatus> findByCountTblBidderStatus(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBidderStatusCount();

    public void saveUpdateAllTblBidderStatus(List<TblBidderStatus> tblBidderStatuss);

	public void saveOrUpdateTblBidderStatus(TblBidderStatus bidderStatus);
}