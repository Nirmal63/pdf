package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblChat;
import java.util.List;

public interface TblChatDao  {

    public void addTblChat(TblChat tblChat);

    public void deleteTblChat(TblChat tblChat);

    public void updateTblChat(TblChat tblChat);

    public List<TblChat> getAllTblChat();

    public List<TblChat> findTblChat(Object... values) throws Exception;

    public List<TblChat> findByCountTblChat(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblChatCount();

    public void saveUpdateAllTblChat(List<TblChat> tblChats);
}
