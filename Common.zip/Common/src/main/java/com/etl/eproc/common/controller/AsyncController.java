/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.async.DeferredResult;

import com.etl.eproc.common.databean.AsyncDataBean;
import com.etl.eproc.common.repository.AsyncRepository;

/**
 * 
 * @author japan
 */
@Controller
public class AsyncController/* extends UrlMappingAbstraction */{

	@Autowired
	private AsyncRepository asyncRepository;
	
	Map<Integer, List<DeferredResult<String>>> buyerWatchers = new ConcurrentHashMap<Integer, List<DeferredResult<String>>>();
	
	/*@RequestMapping(value="/"+MESSAGE+"/{id}/{enc}", method=RequestMethod.GET)
	public String sendReceiveMessage(@PathVariable("id") String id, @PathVariable("enc") String enc) {
		return "appconfig/asyncMessageDemo";
	}*/
	
	@RequestMapping(value="/message/{id}/{enc}", method=RequestMethod.GET)
	public String sendReceiveMessage(@PathVariable("id") String id, @PathVariable("enc") String enc) {
		return "appconfig/asyncMessageDemo";
	}
	
	@RequestMapping(value="/asyncRequest/getMessages/{id}", method=RequestMethod.GET)
	public @ResponseBody DeferredResult<String> getMessages(final @PathVariable Integer id){
		final DeferredResult<String> deferredResult = new DeferredResult<String>();
		
		if(buyerWatchers.containsKey(id)) {
			buyerWatchers.get(id).add(deferredResult);
		} else {
			buyerWatchers.put(id, new ArrayList<DeferredResult<String>>());
			buyerWatchers.get(id).add(deferredResult);
		}
		
		deferredResult.onCompletion(new Runnable() {
			
			@Override
			public void run() {
				buyerWatchers.get(id).remove(deferredResult);
			}
		});
		
		return deferredResult;
	}
	
	@RequestMapping(value="/asyncRequest/setMessages", method=RequestMethod.POST)
	public @ResponseBody String setMessage(@RequestParam("id") Integer id, @RequestParam("message") String message) {
		asyncRepository.setMessage(id, message);
		processQueues();
		return "";
	}
	
	public void processQueues() {
		for (Map.Entry<Integer, Queue<AsyncDataBean>> entry : asyncRepository.getAsyncBeans().entrySet()) {
			while(entry != null && entry.getValue() != null && !entry.getValue().isEmpty()) {
				AsyncDataBean asyncDataBean = entry.getValue().poll();
				for (DeferredResult<String> deferredResult : buyerWatchers.get(asyncDataBean.getId())) {
					deferredResult.setResult(asyncDataBean.getMessage());
				}
			}
		}
	}
}
