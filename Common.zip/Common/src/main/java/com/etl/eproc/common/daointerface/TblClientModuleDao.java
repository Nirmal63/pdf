package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientModule;
import java.util.List;

public interface TblClientModuleDao  {

    public void addTblClientModule(TblClientModule tblClientModule);

    public void deleteTblClientModule(TblClientModule tblClientModule);

    public void updateTblClientModule(TblClientModule tblClientModule);

    public List<TblClientModule> getAllTblClientModule();

    public List<TblClientModule> findTblClientModule(Object... values) throws Exception;

    public List<TblClientModule> findByCountTblClientModule(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientModuleCount();

    public void saveUpdateAllTblClientModule(List<TblClientModule> tblClientModules);
}