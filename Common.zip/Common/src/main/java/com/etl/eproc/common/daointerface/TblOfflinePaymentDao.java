package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblOfflinePayment;
import java.util.List;

public interface TblOfflinePaymentDao  {

    public void addTblOfflinePayment(TblOfflinePayment tblOfflinePayment);

    public void deleteTblOfflinePayment(TblOfflinePayment tblOfflinePayment);

    public void updateTblOfflinePayment(TblOfflinePayment tblOfflinePayment);

    public List<TblOfflinePayment> getAllTblOfflinePayment();

    public List<TblOfflinePayment> findTblOfflinePayment(Object... values) throws Exception;

    public List<TblOfflinePayment> findByCountTblOfflinePayment(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblOfflinePaymentCount();

    public void saveUpdateAllTblOfflinePayment(List<TblOfflinePayment> tblOfflinePayments);

	public void saveOrUpdateTblOfflinePayment(TblOfflinePayment tblOfflinePayment);
}