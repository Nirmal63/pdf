package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblAgreementType;

public interface TblAgreementTypeDao {

    public void addTblAgreementType(TblAgreementType tblAgreementType);

    public void deleteTblAgreementType(TblAgreementType tblAgreementType);

    public void updateTblAgreementType(TblAgreementType tblAgreementType);

    public List<TblAgreementType> getAllTblAgreementType();

    public List<TblAgreementType> findTblAgreementType(Object... values) throws Exception;

    public List<TblAgreementType> findByCountTblAgreementType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAgreementTypeCount();
}