package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblBankIFSCDetail;
import com.etl.eproc.common.daointerface.TblBankIFSCDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBankIFSCDetailImpl extends AbcAbstractClass<TblBankIFSCDetail> implements TblBankIFSCDetailDao {

    @Override
    public void addTblBankIFSCDetail(TblBankIFSCDetail tblBankIFSCDetail){
        super.addEntity(tblBankIFSCDetail);
    }

    @Override
    public void deleteTblBankIFSCDetail(TblBankIFSCDetail tblBankIFSCDetail) {
        super.deleteEntity(tblBankIFSCDetail);
    }

    @Override
    public void updateTblBankIFSCDetail(TblBankIFSCDetail tblBankIFSCDetail) {
        super.updateEntity(tblBankIFSCDetail);
    }

    @Override
    public List<TblBankIFSCDetail> getAllTblBankIFSCDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBankIFSCDetail> findTblBankIFSCDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBankIFSCDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBankIFSCDetail> findByCountTblBankIFSCDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBankIFSCDetail(List<TblBankIFSCDetail> tblBankIFSCDetails){
        super.updateAll(tblBankIFSCDetails);
    }
}
