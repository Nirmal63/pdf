package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientCertBannerMapping;
import java.util.List;

public interface TblClientCertBannerMappingDao  {

    public void addTblClientCertBannerMapping(TblClientCertBannerMapping tblClientCertBannerMapping);

    public void deleteTblClientCertBannerMapping(TblClientCertBannerMapping tblClientCertBannerMapping);

    public void updateTblClientCertBannerMapping(TblClientCertBannerMapping tblClientCertBannerMapping);

    public List<TblClientCertBannerMapping> getAllTblClientCertBannerMapping();

    public List<TblClientCertBannerMapping> findTblClientCertBannerMapping(Object... values) throws Exception;

    public List<TblClientCertBannerMapping> findByCountTblClientCertBannerMapping(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientCertBannerMappingCount();

    public void saveUpdateAllTblClientCertBannerMapping(List<TblClientCertBannerMapping> tblClientCertBannerMappings);
}