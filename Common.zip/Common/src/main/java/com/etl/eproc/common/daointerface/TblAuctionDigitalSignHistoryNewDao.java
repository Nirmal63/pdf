package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.eauction.model.TblAuctionDigitalSignHistoryNew;

public interface TblAuctionDigitalSignHistoryNewDao  {

    public void addTblAuctionDigitalSignHistoryNew(TblAuctionDigitalSignHistoryNew TblAuctionDigitalSignHistoryNew);

    public void deleteTblAuctionDigitalSignHistoryNew(TblAuctionDigitalSignHistoryNew TblAuctionDigitalSignHistoryNew);

    public void updateTblAuctionDigitalSignHistoryNew(TblAuctionDigitalSignHistoryNew TblAuctionDigitalSignHistoryNew);

    public List<TblAuctionDigitalSignHistoryNew> getAllTblAuctionDigitalSignHistoryNew();

    public List<TblAuctionDigitalSignHistoryNew> findTblAuctionDigitalSignHistoryNew(Object... values) throws Exception;

    public List<TblAuctionDigitalSignHistoryNew> findByCountTblAuctionDigitalSignHistoryNew(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAuctionDigitalSignHistoryNewCount();

    public void saveUpdateAllTblAuctionDigitalSignHistoryNew(List<TblAuctionDigitalSignHistoryNew> TblAuctionDigitalSignHistoryNews);
}