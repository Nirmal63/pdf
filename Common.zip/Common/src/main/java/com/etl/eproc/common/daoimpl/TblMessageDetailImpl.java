package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblMessageDetail;
import com.etl.eproc.common.daointerface.TblMessageDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMessageDetailImpl extends AbcAbstractClass<TblMessageDetail> implements TblMessageDetailDao {

    @Override
    public void addTblMessageDetail(TblMessageDetail tblMessageDetail){
        super.addEntity(tblMessageDetail);
    }

    @Override
    public void deleteTblMessageDetail(TblMessageDetail tblMessageDetail) {
        super.deleteEntity(tblMessageDetail);
    }

    @Override
    public void updateTblMessageDetail(TblMessageDetail tblMessageDetail) {
        super.updateEntity(tblMessageDetail);
    }

    @Override
    public List<TblMessageDetail> getAllTblMessageDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMessageDetail> findTblMessageDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMessageDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMessageDetail> findByCountTblMessageDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMessageDetail(List<TblMessageDetail> tblMessageDetails){
        super.updateAll(tblMessageDetails);
    }
}
