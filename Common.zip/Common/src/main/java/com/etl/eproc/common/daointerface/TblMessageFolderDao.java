package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMessageFolder;
import java.util.List;

public interface TblMessageFolderDao  {

    public void addTblMessageFolder(TblMessageFolder tblMessageFolder);

    public void deleteTblMessageFolder(TblMessageFolder tblMessageFolder);

    public void updateTblMessageFolder(TblMessageFolder tblMessageFolder);

    public List<TblMessageFolder> getAllTblMessageFolder();

    public List<TblMessageFolder> findTblMessageFolder(Object... values) throws Exception;

    public List<TblMessageFolder> findByCountTblMessageFolder(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMessageFolderCount();

    public void saveUpdateAllTblMessageFolder(List<TblMessageFolder> tblMessageFolders);

	public void saveOrUpdateTblMessageFolder(TblMessageFolder tblMessageFolder);
}