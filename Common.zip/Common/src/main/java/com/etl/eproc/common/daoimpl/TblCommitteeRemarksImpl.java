package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblCommitteeRemarks;
import com.etl.eproc.common.daointerface.TblCommitteeRemarksDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCommitteeRemarksImpl extends AbcAbstractClass<TblCommitteeRemarks> implements TblCommitteeRemarksDao {

    @Override
    public void addTblCommitteeRemarks(TblCommitteeRemarks tblCommitteeRemarks){
        super.addEntity(tblCommitteeRemarks);
    }

    @Override
    public void deleteTblCommitteeRemarks(TblCommitteeRemarks tblCommitteeRemarks) {
        super.deleteEntity(tblCommitteeRemarks);
    }

    @Override
    public void updateTblCommitteeRemarks(TblCommitteeRemarks tblCommitteeRemarks) {
        super.updateEntity(tblCommitteeRemarks);
    }

    @Override
    public List<TblCommitteeRemarks> getAllTblCommitteeRemarks() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCommitteeRemarks> findTblCommitteeRemarks(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCommitteeRemarksCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCommitteeRemarks> findByCountTblCommitteeRemarks(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCommitteeRemarks(List<TblCommitteeRemarks> tblCommitteeRemarkss){
        super.updateAll(tblCommitteeRemarkss);
    }

	@Override
	public void saveOrUpdateTblCommitteeRemarks(TblCommitteeRemarks committeeremarks) {
	super.saveOrUpdateEntity(committeeremarks);
	}
}
