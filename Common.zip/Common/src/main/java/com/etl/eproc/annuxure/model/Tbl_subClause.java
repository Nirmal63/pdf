package com.etl.eproc.annuxure.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tbl_subClause",schema="appcommon")
public class Tbl_subClause  implements java.io.Serializable {
	
	private int subClauseId;
	private TblAnxClause tblClause;
	private String SrNo;
	private int createdBy;
	private Date createdOn;
	private int updatedBy;
	private Date updatedOn;
	private int isNegotiable;
	private String subClauseName;
	private String subClauseDescription;
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public int getSubClauseId() {
		return subClauseId;
	}
	public void setSubClauseId(int subClauseId) {
		this.subClauseId = subClauseId;
	}
	
	
	public String getSrNo() {
		return SrNo;
	}
	public void setSrNo(String srNo) {
		SrNo = srNo;
	}
	public int getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}
	public int getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}
	public Date getUpdatedOn() {
		return updatedOn;
	}
	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}
	public int getIsNegotiable() {
		return isNegotiable;
	}
	public void setIsNegotiable(int isNegotiable) {
		this.isNegotiable = isNegotiable;
	}
	
	@ManyToOne()
	@JoinColumn(name = "clauseId")
	public TblAnxClause getTblClause() {
		return tblClause;
	}
	public void setTblClause(TblAnxClause tblClause) {
		this.tblClause = tblClause;
	}
	public String getSubClauseName() {
		return subClauseName;
	}
	public void setSubClauseName(String subClauseName) {
		this.subClauseName = subClauseName;
	}
	
	@Column(name = "subClueDescription")
	public String getSubClauseDescription() {
		return subClauseDescription;
	}
	public void setSubClauseDescription(String subClauseDescription) {
		this.subClauseDescription = subClauseDescription;
	}
	
	
	

}
