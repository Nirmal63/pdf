package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCountry;
import java.util.List;

public interface TblCountryDao  {

    public void addTblCountry(TblCountry tblCountry);

    public void deleteTblCountry(TblCountry tblCountry);

    public void updateTblCountry(TblCountry tblCountry);

    public List<TblCountry> getAllTblCountry();

    public List<TblCountry> findTblCountry(Object... values) throws Exception;

    public List<TblCountry> findByCountTblCountry(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCountryCount();

    public void saveUpdateAllTblCountry(List<TblCountry> tblCountrys);
}