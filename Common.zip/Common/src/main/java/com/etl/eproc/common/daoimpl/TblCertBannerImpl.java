package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblCertBannerDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblCertBanner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCertBannerImpl extends AbcAbstractClass<TblCertBanner> implements TblCertBannerDao {

    @Override
    public void addTblCertBanner(TblCertBanner tblCertBanner){
        super.addEntity(tblCertBanner);
    }

    @Override
    public void deleteTblCertBanner(TblCertBanner tblCertBanner) {
        super.deleteEntity(tblCertBanner);
    }

    @Override
    public void updateTblCertBanner(TblCertBanner tblCertBanner) {
        super.updateEntity(tblCertBanner);
    }

    @Override
    public List<TblCertBanner> getAllTblCertBanner() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCertBanner> findTblCertBanner(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCertBannerCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCertBanner> findByCountTblCertBanner(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCertBanner(List<TblCertBanner> tblCertBanners){
        super.updateAll(tblCertBanners);
    }
}
