package com.etl.eproc.common.daointerface;



import com.etl.eproc.common.model.TblDocUploadConfig;
import java.util.List;


	public interface TblDocUploadConfigDao  {

	public void addTblDocUploadConfig(TblDocUploadConfig tblObj);

	public void deleteTblDocUploadConfig(TblDocUploadConfig tblObj);

	public void updateTblDocUploadConfig(TblDocUploadConfig tblObj);

	public List<TblDocUploadConfig> getAllTblDocUploadConfig();

	public List<TblDocUploadConfig> findTblDocUploadConfig(Object... values) throws Exception;

	public List<TblDocUploadConfig> findByCountTblDocUploadConfig(int firstResult,int maxResult,Object... values) throws Exception;

	public long getTblDocUploadConfigCount();

	public void updateOrSaveTblDocUploadConfig(List<TblDocUploadConfig> tblObj);
}