package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblSupplierInquiry;
import com.etl.eproc.common.daointerface.TblSupplierInquiryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblSupplierInquiryImpl extends AbcAbstractClass<TblSupplierInquiry> implements TblSupplierInquiryDao {

    @Override
    public void addTblSupplierInquiry(TblSupplierInquiry tblSupplierInquiry){
        super.addEntity(tblSupplierInquiry);
    }

    @Override
    public void deleteTblSupplierInquiry(TblSupplierInquiry tblSupplierInquiry) {
        super.deleteEntity(tblSupplierInquiry);
    }

    @Override
    public void updateTblSupplierInquiry(TblSupplierInquiry tblSupplierInquiry) {
        super.updateEntity(tblSupplierInquiry);
    }

    @Override
    public List<TblSupplierInquiry> getAllTblSupplierInquiry() {
        return super.getAllEntity();
    }

    @Override
    public List<TblSupplierInquiry> findTblSupplierInquiry(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblSupplierInquiryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblSupplierInquiry> findByCountTblSupplierInquiry(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblSupplierInquiry(List<TblSupplierInquiry> tblSupplierInquirys){
        super.updateAll(tblSupplierInquirys);
    }
}
