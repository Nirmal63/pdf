package com.etl.eproc.common.daointerface;

import java.util.List;


import com.etl.eproc.common.model.TblDocumentLink;

/**
*
* @author dipika
*/
public interface TblDocumentLinkDao  {

    public void addTblDocumentLink(TblDocumentLink tblDocumentLink);

    public void deleteTblDocumentLink(TblDocumentLink tblDocumentLink);

    public void updateTblDocumentLink(TblDocumentLink tblDocumentLink);

    public List<TblDocumentLink> getAllTblDocumentLink();

    public List<TblDocumentLink> findTblDocumentLink(Object... values) throws Exception;

    public List<TblDocumentLink> findByCountTblDocumentLink(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDocumentLinkCount();

    public void saveUpdateAllTblDocumentLink(List<TblDocumentLink> tblDocumentLinks);

	public void saveOrUpdateTblDocumentLink(TblDocumentLink tblDocumentLink);
}
