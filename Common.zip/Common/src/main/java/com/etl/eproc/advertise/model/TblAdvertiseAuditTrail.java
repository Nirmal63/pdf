package com.etl.eproc.advertise.model;

import com.etl.eproc.common.model.TblTrackLogin;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.core.style.ToStringCreator;

@Entity
@Table(name="Tbl_AdvertiseAuditTrail",schema="appreport")
public class TblAdvertiseAuditTrail  implements java.io.Serializable {

        private   long advertiseAuditTrailId;
        private   int advertiseId;
        private   Date createdOn;
        private   int linkId;
        private   long objectId;
        private   String pageUrl;
        private   String remark;
        private   TblTrackLogin tblTrackLogin;

        private Set<TblAdvertiseDigitalSignHistory> tblAdvertiseDigitalSignHistory = new HashSet<TblAdvertiseDigitalSignHistory>();

        @OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="tblAdvertiseAuditTrail")
        public Set<TblAdvertiseDigitalSignHistory> getTblAdvertiseDigitalSignHistory()
        {
            return tblAdvertiseDigitalSignHistory;
        }
        public void setTblAdvertiseDigitalSignHistory(Set<TblAdvertiseDigitalSignHistory> tblAdvertiseDigitalSignHistory)
        {
            this.tblAdvertiseDigitalSignHistory = tblAdvertiseDigitalSignHistory;
        }

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name="advertiseAuditTrailId",unique=true,nullable=false)
        public long getAdvertiseAuditTrailId() {
            return this.advertiseAuditTrailId;
        }

        public void setAdvertiseAuditTrailId(long advertiseAuditTrailId) {
            this.advertiseAuditTrailId = advertiseAuditTrailId;
        }
        public TblAdvertiseAuditTrail(long advertiseAuditTrailId){
            this.advertiseAuditTrailId = advertiseAuditTrailId;
        }
        @Column(name="advertiseId",nullable=false)
        public int getAdvertiseId() {
            return this.advertiseId;
        }

        public void setAdvertiseId(int advertiseId) {
            this.advertiseId = advertiseId;
        }
        @Temporal(TemporalType.TIMESTAMP)
        @Column(name="createdOn",nullable=false,updatable=false,insertable=false)
        public Date getCreatedOn() {
            return this.createdOn;
        }

        public void setCreatedOn(Date createdOn) {
            this.createdOn = createdOn;
        }
        @Column(name="linkId",nullable=false)
        public int getLinkId() {
            return this.linkId;
        }

        public void setLinkId(int linkId) {
            this.linkId = linkId;
        }
        @Column(name="objectId",nullable=false)
        public long getObjectId() {
            return this.objectId;
        }

        public void setObjectId(long objectId) {
            this.objectId = objectId;
        }
        @Column(name="pageUrl",nullable=false, length= 1000)
        public String getPageUrl() {
            return this.pageUrl;
        }

        public void setPageUrl(String pageUrl) {
            this.pageUrl = pageUrl;
        }
        @Column(name="remark",nullable=false, length= 100)
        public String getRemark() {
            return this.remark;
        }

        public void setRemark(String remark) {
            this.remark = remark;
        }
        @ManyToOne(fetch=FetchType.LAZY)
        @JoinColumn(name="trackloginid")
        public TblTrackLogin getTblTrackLogin() {
            return this.tblTrackLogin;
        }

        public void setTblTrackLogin(TblTrackLogin tblTrackLogin) {
            this.tblTrackLogin = tblTrackLogin;
        }
        public TblAdvertiseAuditTrail(){
        }
        @Override
	public String toString() {
		return new ToStringCreator(this)
.append("advertiseAuditTrailId", this.getAdvertiseAuditTrailId())
.append("advertiseId", this.getAdvertiseId())
.append("createdOn", this.getCreatedOn())
.append("linkId", this.getLinkId())
.append("objectId", this.getObjectId())
.append("pageUrl", this.getPageUrl())
.append("remark", this.getRemark())

		.toString();

	}
}
