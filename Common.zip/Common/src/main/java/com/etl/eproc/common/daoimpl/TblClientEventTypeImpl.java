package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblClientEventType;
import com.etl.eproc.common.daointerface.TblClientEventTypeDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientEventTypeImpl extends AbcAbstractClass<TblClientEventType> implements TblClientEventTypeDao {


    @Override
    public void addTblClientEventType(TblClientEventType tblClientEventType){
        super.addEntity(tblClientEventType);
    }

    @Override
    public void deleteTblClientEventType(TblClientEventType tblClientEventType) {
        super.deleteEntity(tblClientEventType);
    }

    @Override
    public void updateTblClientEventType(TblClientEventType tblClientEventType) {
        super.updateEntity(tblClientEventType);
    }

    @Override
    public List<TblClientEventType> getAllTblClientEventType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientEventType> findTblClientEventType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientEventTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientEventType> findByCountTblClientEventType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientEventType(List<TblClientEventType> tblClientEventTypes){
        super.updateAll(tblClientEventTypes);
    }
}
