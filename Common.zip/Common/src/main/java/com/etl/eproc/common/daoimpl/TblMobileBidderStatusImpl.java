package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblMobileBidderStatus;
import com.etl.eproc.common.daointerface.TblMobileBidderStatusDao;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;

import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMobileBidderStatusImpl extends AbcAbstractClass<TblMobileBidderStatus> implements TblMobileBidderStatusDao {

    @Override
    public void addTblmobilebidderstatus(TblMobileBidderStatus tblmobilebidderstatus){
        super.addEntity(tblmobilebidderstatus);
    }

    @Override
    public void deleteTblmobilebidderstatus(TblMobileBidderStatus tblmobilebidderstatus) {
        super.deleteEntity(tblmobilebidderstatus);
    }

    @Override
    public void updateTblmobilebidderstatus(TblMobileBidderStatus tblmobilebidderstatus) {
        super.updateEntity(tblmobilebidderstatus);
    }

    @Override
    public List<TblMobileBidderStatus> getAllTblmobilebidderstatus() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMobileBidderStatus> findTblmobilebidderstatus(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblmobilebidderstatusCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMobileBidderStatus> findByCountTblmobilebidderstatus(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblmobilebidderstatus(List<TblMobileBidderStatus> tblmobilebidderstatuss){
        super.updateAll(tblmobilebidderstatuss);
    }

	@Override
	public void saveOrUpdateTblMobileBidderStatus(TblMobileBidderStatus tblmobilebidderstatus) {
		super.saveOrUpdateEntity(tblmobilebidderstatus);
	}
}
