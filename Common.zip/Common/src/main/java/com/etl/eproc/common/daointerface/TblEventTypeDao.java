package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblEventType;
import java.util.List;

public interface TblEventTypeDao  {

    public void addTblEventType(TblEventType tblEventType);

    public void deleteTblEventType(TblEventType tblEventType);

    public void updateTblEventType(TblEventType tblEventType);

    public List<TblEventType> getAllTblEventType();

    public List<TblEventType> findTblEventType(Object... values) throws Exception;

    public List<TblEventType> findByCountTblEventType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEventTypeCount();

    public void saveUpdateAllTblEventType(List<TblEventType> tblEventTypes);
}