package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblMessageFolderDao;
import com.etl.eproc.common.model.TblMessageFolder;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMessageFolderImpl extends AbcAbstractClass<TblMessageFolder> implements TblMessageFolderDao {

    @Override
    public void addTblMessageFolder(TblMessageFolder tblMessageFolder){
        super.addEntity(tblMessageFolder);
    }

    @Override
    public void deleteTblMessageFolder(TblMessageFolder tblMessageFolder) {
        super.deleteEntity(tblMessageFolder);
    }

    @Override
    public void updateTblMessageFolder(TblMessageFolder tblMessageFolder) {
        super.updateEntity(tblMessageFolder);
    }

    @Override
    public List<TblMessageFolder> getAllTblMessageFolder() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMessageFolder> findTblMessageFolder(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMessageFolderCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMessageFolder> findByCountTblMessageFolder(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMessageFolder(List<TblMessageFolder> tblMessageFolders){
        super.updateAll(tblMessageFolders);
    }

	@Override
	public void saveOrUpdateTblMessageFolder(TblMessageFolder tblMessageFolder) {
		super.saveOrUpdateEntity(tblMessageFolder);
	}
}
