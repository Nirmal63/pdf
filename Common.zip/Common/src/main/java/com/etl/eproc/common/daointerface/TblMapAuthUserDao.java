package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMapAuthUser;
import java.util.List;

public interface TblMapAuthUserDao  {

    public void addTblMapAuthUser(TblMapAuthUser tblMapAuthUser);

    public void deleteTblMapAuthUser(TblMapAuthUser tblMapAuthUser);

    public void updateTblMapAuthUser(TblMapAuthUser tblMapAuthUser);

    public List<TblMapAuthUser> getAllTblMapAuthUser();

    public List<TblMapAuthUser> findTblMapAuthUser(Object... values) throws Exception;

    public List<TblMapAuthUser> findByCountTblMapAuthUser(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMapAuthUserCount();

    public void saveUpdateAllTblMapAuthUser(List<TblMapAuthUser> tblMapAuthUsers);
}