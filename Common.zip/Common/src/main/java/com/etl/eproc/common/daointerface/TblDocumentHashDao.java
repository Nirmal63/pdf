package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDocumentHash;
import java.util.List;

public interface TblDocumentHashDao  {

    public void addTblDocumentHash(TblDocumentHash tblDocumentHash);

    public void deleteTblDocumentHash(TblDocumentHash tblDocumentHash);

    public void updateTblDocumentHash(TblDocumentHash tblDocumentHash);

    public List<TblDocumentHash> getAllTblDocumentHash();

    public List<TblDocumentHash> findTblDocumentHash(Object... values) throws Exception;

    public List<TblDocumentHash> findByCountTblDocumentHash(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDocumentHashCount();

    public void saveUpdateAllTblDocumentHash(List<TblDocumentHash> tblDocumentHashs);

	public void saveOrUpdateTblDocumentHash(TblDocumentHash tblDocumentHash);
}