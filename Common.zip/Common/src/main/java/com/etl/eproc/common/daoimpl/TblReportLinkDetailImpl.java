package com.etl.eproc.common.daoimpl;




import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblReportLinkDetailDao;
import com.etl.eproc.common.model.TblReportLinkDetail;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository @Transactional    /*StackUpdate*/
public class TblReportLinkDetailImpl extends AbcAbstractClass<TblReportLinkDetail> implements TblReportLinkDetailDao {

	@Override 
	public void addTblReportLinkDetail(TblReportLinkDetail master){
		super.addEntity(master);
	}
	@Override 
	public void deleteTblReportLinkDetail(TblReportLinkDetail master) {
		super.deleteEntity(master);
	}
	@Override 
	public void updateTblReportLinkDetail(TblReportLinkDetail master) {
		super.updateEntity(master);
	}
	@Override 
	public List<TblReportLinkDetail> getAllTblReportLinkDetail() {
		return super.getAllEntity();
	}
	@Override 
	public List<TblReportLinkDetail> findTblReportLinkDetail(Object... values) throws Exception {
		return super.findEntity(values);
	}
	@Override 
	public long getTblReportLinkDetailCount() {
		return super.getEntityCount();
	}
	@Override 
	public List<TblReportLinkDetail> findByCountTblReportLinkDetail(int firstResult, int maxResult, Object... values) throws Exception {
		return super.findByCountEntity(firstResult, maxResult, values);
	}
	@Override 
	public void updateOrSaveTblReportLinkDetail(List<TblReportLinkDetail> tblObj) {
		super.updateAll(tblObj);
	}
}