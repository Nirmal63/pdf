package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.List;


import com.etl.eproc.common.model.TblNeftDepositHistory;

public interface TblNeftDepositHistoryDao  {

    public void addTblNeftDepositHistory(TblNeftDepositHistory tblNeftDepositHistory);

    public void deleteTblNeftDepositHistory(TblNeftDepositHistory tblNeftDepositHistory);

    public void updateTblNeftDepositHistory(TblNeftDepositHistory tblNeftDepositHistory);

    public List<TblNeftDepositHistory> getAllTblNeftDepositHistory();

    public List<TblNeftDepositHistory> findTblNeftDepositHistory(Object... values) throws Exception;

    public List<TblNeftDepositHistory> findByCountTblNeftDepositHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNeftDepositHistoryCount();

    public void saveUpdateAllTblNeftDepositHistory(List<TblNeftDepositHistory> tblNeftDepositHistorys);
}