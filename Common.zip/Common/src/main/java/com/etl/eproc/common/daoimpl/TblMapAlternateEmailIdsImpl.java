package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblMapAlternateEmailIds;
import com.etl.eproc.common.daointerface.TblMapAlternateEmailIdsDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMapAlternateEmailIdsImpl extends AbcAbstractClass<TblMapAlternateEmailIds> implements TblMapAlternateEmailIdsDao {

    @Override
    public void addTblMapAlternateEmailIds(TblMapAlternateEmailIds tblMapAlternateEmailIds){
        super.addEntity(tblMapAlternateEmailIds);
    }

    @Override
    public void deleteTblMapAlternateEmailIds(TblMapAlternateEmailIds tblMapAlternateEmailIds) {
        super.deleteEntity(tblMapAlternateEmailIds);
    }

    @Override
    public void updateTblMapAlternateEmailIds(TblMapAlternateEmailIds tblMapAlternateEmailIds) {
        super.updateEntity(tblMapAlternateEmailIds);
    }

    @Override
    public List<TblMapAlternateEmailIds> getAllTblMapAlternateEmailIds() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMapAlternateEmailIds> findTblMapAlternateEmailIds(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMapAlternateEmailIdsCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMapAlternateEmailIds> findByCountTblMapAlternateEmailIds(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMapAlternateEmailIds(List<TblMapAlternateEmailIds> tblMapAlternateEmailIdss){
        super.updateAll(tblMapAlternateEmailIdss);
    }
}
