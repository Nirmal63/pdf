/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;

/**
 *
 * @author darshan
 */
import java.util.List;

import com.etl.eproc.common.model.TblAnswer;

public interface TblAnswerDao {

    public void addTblAnswer(TblAnswer tblAnswer);

    public void deleteTblAnswer(TblAnswer tblAnswer);

    public void updateTblAnswer(TblAnswer tblAnswer);

    public List<TblAnswer> getAllTblAnswer();

    public List<TblAnswer> findTblAnswer(Object... values) throws Exception;

    public List<TblAnswer> findByCountTblAnswer(int firstResult, int maxResult, Object... values) throws Exception;

    public long getTblAnswerCount();

    public void saveUpdateAllTblAnswer(List<TblAnswer> tblAnswers);

	public void saveOrUpdateTblAnswer(TblAnswer tblanswer);
}