package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDynControlType;
import java.util.List;

public interface TblDynControlTypeDao  {

    public void addTblDynControlType(TblDynControlType tblDynControlType);

    public void deleteTblDynControlType(TblDynControlType tblDynControlType);

    public void updateTblDynControlType(TblDynControlType tblDynControlType);

    public List<TblDynControlType> getAllTblDynControlType();

    public List<TblDynControlType> findTblDynControlType(Object... values) throws Exception;

    public List<TblDynControlType> findByCountTblDynControlType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynControlTypeCount();

    public void saveUpdateAllTblDynControlType(List<TblDynControlType> tblDynControlTypes);
}