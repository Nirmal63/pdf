package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDeptNeftRtgsConfDetails;
import java.util.List;

public interface TblDeptNeftRtgsConfDetailsDao  {

    public void addTblDeptNeftRtgsConfDetails(TblDeptNeftRtgsConfDetails tblDeptNeftRtgsConfDetails);

    public void deleteTblDeptNeftRtgsConfDetails(TblDeptNeftRtgsConfDetails tblDeptNeftRtgsConfDetails);

    public void updateTblDeptNeftRtgsConfDetails(TblDeptNeftRtgsConfDetails tblDeptNeftRtgsConfDetails);

    public List<TblDeptNeftRtgsConfDetails> getAllTblDeptNeftRtgsConfDetails();

    public List<TblDeptNeftRtgsConfDetails> findTblDeptNeftRtgsConfDetails(Object... values) throws Exception;

    public List<TblDeptNeftRtgsConfDetails> findByCountTblDeptNeftRtgsConfDetails(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDeptNeftRtgsConfDetailsCount();

    public void saveUpdateAllTblDeptNeftRtgsConfDetails(List<TblDeptNeftRtgsConfDetails> tblDeptNeftRtgsConfDetailss);
}