package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblTransactionTypeAccountMapping;
import com.etl.eproc.common.daointerface.TblTransactionTypeAccountMappDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblTransactionTypeAccountMappImpl extends AbcAbstractClass<TblTransactionTypeAccountMapping> implements TblTransactionTypeAccountMappDao {

    @Override
    public void addTblTransactionTypeAccountMapp(TblTransactionTypeAccountMapping tblTransactionTypeAccountMapp){
        super.addEntity(tblTransactionTypeAccountMapp);
    }

    @Override
    public void deleteTblTransactionTypeAccountMapp(TblTransactionTypeAccountMapping tblTransactionTypeAccountMapp) {
        super.deleteEntity(tblTransactionTypeAccountMapp);
    }

    @Override
    public void updateTblTransactionTypeAccountMapp(TblTransactionTypeAccountMapping tblTransactionTypeAccountMapp) {
        super.updateEntity(tblTransactionTypeAccountMapp);
    }

    @Override
    public List<TblTransactionTypeAccountMapping> getAllTblTransactionTypeAccountMapp() {
        return super.getAllEntity();
    }

    @Override
    public List<TblTransactionTypeAccountMapping> findTblTransactionTypeAccountMapp(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblTransactionTypeAccountMappCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblTransactionTypeAccountMapping> findByCountTblTransactionTypeAccountMapp(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblTransactionTypeAccountMapp(List<TblTransactionTypeAccountMapping> tblTransactionTypeAccountMapps){
        super.updateAll(tblTransactionTypeAccountMapps);
    }
}
