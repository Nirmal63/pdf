package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblVendorMaster;
import com.etl.eproc.common.daointerface.TblVendorMasterDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblVendorMasterImpl extends AbcAbstractClass<TblVendorMaster> implements TblVendorMasterDao {

    @Override
    public void addTblVendorMaster(TblVendorMaster tblVendorMaster){
        super.addEntity(tblVendorMaster);
    }

    @Override
    public void deleteTblVendorMaster(TblVendorMaster tblVendorMaster) {
        super.deleteEntity(tblVendorMaster);
    }

    @Override
    public void updateTblVendorMaster(TblVendorMaster tblVendorMaster) {
        super.updateEntity(tblVendorMaster);
    }

    @Override
    public List<TblVendorMaster> getAllTblVendorMaster() {
        return super.getAllEntity();
    }

    @Override
    public List<TblVendorMaster> findTblVendorMaster(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblVendorMasterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblVendorMaster> findByCountTblVendorMaster(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblVendorMaster(List<TblVendorMaster> tblVendorMasters){
        super.updateAll(tblVendorMasters);
    }
}
