package com.etl.eproc.common.controller;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.etl.eproc.common.databean.NeftRtgsDataBean;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblClientPGBankMapping;
import com.etl.eproc.common.model.TblCompany;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblDeptNeftRtgsConf;
import com.etl.eproc.common.model.TblDeptNeftRtgsConfDetails;
import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblLastTransactionDetail;
import com.etl.eproc.common.model.TblNeftRtgsBidderDetail;
import com.etl.eproc.common.model.TblNeftRtgsConf;
import com.etl.eproc.common.model.TblNeftTransactionHistory;
import com.etl.eproc.common.model.TblTransactionCSVDetail;
import com.etl.eproc.common.model.TblTransactionType;
import com.etl.eproc.common.model.TblTransactionTypeAccountMapping;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.NeftRtgsService;
import com.etl.eproc.common.services.TpslService;
import com.etl.eproc.common.services.YesBankService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.DateUtils;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.SHA1HashEncryption;
import com.etl.eproc.common.utility.SessionBean;
//import javax.crypto.Cipher;

/**Comments**/

@Controller
@RequestMapping("/common")
public class NeftRtgsController {

	@Autowired
	private ExceptionHandlerService exceptionHandlerService;
	@Autowired
	private AbcUtility abcUtility;
	@Autowired
	private NeftRtgsService neftService;
	@Autowired
	private MailContentUtillity mailContentUtillity;
	@Autowired
	private EncryptDecryptUtils encryptDecryptUtils;
	@Autowired
	private CommonService commonService;
	@Autowired
	private FileUploadService fileUploadService;
	@Autowired
	private AuditTrailService auditTrailService;
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private ClientService clientService;
	@Autowired
	private DepartmentService departmentService;
	@Autowired
    private TpslService tpslService;
	@Autowired
	private SHA1HashEncryption sHA1HashEncryption;
	@Autowired
	private YesBankService yesBankService;
        @Autowired
        private DateUtils dateUtils;
        @Value("#{projectProperties['file.drive']}")
        private String drive;
        @Value("#{projectProperties['file.upload']}")
        private String upload;

	@Value("#{tenderlinkProperties['bidder_dashboard']?:279}")
    private int biddingEventDashboardLinkId;
	@Value("#{adminAuditTrailProperties['getNeftRtgs']}")
	private String getNeftRtgs;
	@Value("#{adminAuditTrailProperties['createNeftRtgs']}")
	private String createNeftRtgs;
	@Value("#{adminAuditTrailProperties['postrefundrequest']}")
	private String postRefundRequest;
	@Value("#{adminAuditTrailProperties['refund_Req_sign_remark']}")
	private String refundReqSignRemark;
        @Value("#{adminAuditTrailProperties['getNeftList']}")
	private String getNeftList;
        @Value("#{adminAuditTrailProperties['getNeftApprove']}")
	private String getNeftApprove;
        @Value("#{projectProperties['pki_enable']?:1}")
        private int pkiEnable;
	@Value("#{adminAuditTrailProperties['getUploadNeftDoc']}")
	private String getUploadNeftDoc;
	@Value("#{adminAuditTrailProperties['getNeftVendorSearch']}")
	private String getNeftVendorSearch;
	@Value("#{adminAuditTrailProperties['getNeftDateWiseSearch']}")
	private String getNeftDateWiseSearch;
	@Value("#{adminAuditTrailProperties['getNeftBidderMail']}")
	private String getNeftBidderMail;
	@Value("#{adminAuditTrailProperties['getMappedBidderCode']}")
	private String getMappedBidderCode;
	@Value("#{adminAuditTrailProperties['getDownloadBidder']}")
	private String getDownloadBidder;
	@Value("#{adminAuditTrailProperties['postNeftBidderDetail']}")
	private String postNeftBidderDetail;
	@Value("#{adminAuditTrailProperties['postDownloadVendorDate']}")
	private String postDownloadVendorDate;
	@Value("#{projectProperties['doc_upload_path']}")
	private String docUploadPath;
	@Value("#{linkProperties['manage_client_upload_bidder_data']?:421}")
        private int uploadNEFTBidderLinkId;
        @Value("#{linkProperties['manage_client_search_bidder']?:422}")
        private int searchNEFTBidderLinkId;
        @Value("#{linkProperties['manage_client_download_bidder_data']?:423}")
        private int downloadBidderLinkId;
        @Value("#{linkProperties['manage_client_send_mail']?:424}")
        private int sendMailLinkId;
        @Value("#{linkProperties['manage_client_map_bidder']?:425}")
        private int mapNEFTBidderCodeLinkId;
        @Value("#{projectProperties['upload.neft.doc.eventId']?:87}")
        private int neftUploadDocEventId;
	@Value("#{linkProperties['manage_neft_configuration']?:450}")
        private int manageNEFTLinkId;
	@Value("#{linkProperties['approve_neft_configuration']?:451}")
        private int approveNEFTLinkId;
	@Value("#{linkProperties['download_neft_balance_report']?:452}")
        private int balanceReportLinkId;
	@Value("#{linkProperties['manage_client_neft_create']?:411}")
	private int manage_client_neft_create;
	@Value("#{linkProperties['manage_client_neft_edit']?:412}")
	private int manage_client_neft_edit;
	@Value("#{linkProperties['manage_client_neft_view']?:413}")
	private int manage_client_neft_view;
	@Value("#{projectProperties['neft_linkId']?:175}")
        private int neftLinkId;
	@Value("#{linkProperties['manage_tranType_accountmapp']?:917}")
    private int manageTranTypeAccMappLinkId;
	@Value("#{adminAuditTrailProperties['get_save_accmapp']}")
	private String getSaveAccmapp;
	
	private static final String CLIENT_ID = "clientId";
	private static final String CLIENT_NAME = "clientName";
	private static final String PREFIX = "prefix";
	private static final String FROM_WHERE = "fromWhere";
	private static final int TAB_DOC_FEES = 3;
    private static final int TAB_EMD = 4;
    private static final String TAB_ID = "tabId";
    private static final String TENDER_ID = "tenderId";
    private static final String HIDDEN_TENDER_ID = "hdTenderId";
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    private static final String DEPT_ID = "deptId";
    private static final int TAB_ONLINE_PAYMENT = 1;
    private static final int TAB_NEFTRTGS = 2;
	
	
     /**
        * @author heeral.soni
        * used to get neft/rtgs configuration
        */ 
       @RequestMapping(value = "/admin/getneftconfiguration/{clientId}/{enc}", method = RequestMethod.GET)
       public String getNEFTConfiguration(@PathVariable(CLIENT_ID) int clientId,ModelMap modelMap, HttpServletRequest request) {
           try {
               modelMap.addAttribute("neftConfList", neftService.getNeftRtgsConfigurationDetail(clientId));
               modelMap.addAttribute(CLIENT_ID, clientId);
               modelMap.addAttribute("clientName", clientService.getClientName(clientId));
           } catch (Exception ex) {
               return exceptionHandlerService.writeLog(ex);
           }
           finally {
               auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageNEFTLinkId, getNeftList,0,clientId);
           }
           return "common/admin/NEFTConfigurationList";
       }
    
       /**
        * @author heeral.soni
        * used to approve neft/rtgs configuration
        */ 
       @RequestMapping(value = "/admin/approveneftconfiguratiuon", method = RequestMethod.POST)
       public String approveNEFTConfiguratiuon(ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes) {
           String retVal = null;
           int clientId = StringUtils.hasLength(request.getParameter("hdClientId")) ? Integer.parseInt(request.getParameter("hdClientId")) : 0;
           int deptId = StringUtils.hasLength(request.getParameter("hdDeptId")) ? Integer.parseInt(request.getParameter("hdDeptId")) : 0;
           int paymentConfigBy = StringUtils.hasLength(request.getParameter("hdPaymentConfigBy")) ? Integer.parseInt(request.getParameter("hdPaymentConfigBy")) : 0;
           int parentDeptId = StringUtils.hasLength(request.getParameter("hdParentDeptId")) ? Integer.parseInt(request.getParameter("hdParentDeptId")) : 0;
           int bankId = StringUtils.hasLength(request.getParameter("hdBankId")) ? Integer.parseInt(request.getParameter("hdBankId")) : 0;
           String password = StringUtils.hasLength(request.getParameter("hdPassword")) ? request.getParameter("hdPassword") : "";
           try {
        	   boolean isApproved=false;
        	   if(paymentConfigBy==2 && parentDeptId!=deptId){
        		   isApproved = neftService.updateDeptNEFTConfStatus(deptId);
        	   }else{
        		   if(bankId == 6){
        			   isApproved = neftService.updateNEFTConfStatus(clientId, sHA1HashEncryption.encodeStringSHA1(password));
        		   }else{
        			   isApproved = neftService.updateNEFTConfStatus(clientId, password);
        		   }
        		   isApproved = neftService.updateDeptNEFTConfStatus(deptId);
        	   }
               redirectAttributes.addFlashAttribute(isApproved ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isApproved ? "redirect_success_approve_neft" : CommonKeywords.ERROR_MSG_KEY.toString());
               retVal = "common/admin/managepaymentconf/"+clientId+ "/"+TAB_NEFTRTGS;
           } catch (Exception ex) {
               return exceptionHandlerService.writeLog(ex);
           }
           finally {
               auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), approveNEFTLinkId, getNeftApprove,0,clientId);
           }
           return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
       }
       
    /**
     * @author heeral.soni
     * used to get uploaded doc for neft/rtgs
     */ 
    @RequestMapping(value = "/admin/uploadvendordata/{objectId}/{enc}", method = RequestMethod.GET)
    public String uploadVendorData(@PathVariable("objectId") int objectId,ModelMap modelMap, HttpServletRequest request, HttpSession session) {
        try {
	    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(neftUploadDocEventId, abcUtility.getSessionClientId(request));
	    int allowedSize = 0;
	    StringBuilder allowedExt = new StringBuilder();
	    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
                allowedSize = lstDocUploadConf.get(0).getMaxSize();
                allowedExt.append(lstDocUploadConf.get(0).getType());
                modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
	    }
	    int index = allowedExt.toString().indexOf(",");
	    allowedExt.insert(index + 1, "*.");
	    while (index >= 0) {
                index = allowedExt.toString().indexOf(",", index + ",".length());
                allowedExt.insert(index + 1, "*.");
	    }

	    modelMap.addAttribute("allowedExt", allowedExt);
	    modelMap.addAttribute("allowedSize", allowedSize/1024);
            modelMap.addAttribute("linkId", uploadNEFTBidderLinkId);
	    modelMap.addAttribute("objectId", objectId);
	    modelMap.addAttribute("cStatusDoc", 4);
            modelMap.addAttribute("cStatusDocView", -1);
       modelMap.addAttribute("uploadToClientDir", "Y");    
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
        finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), uploadNEFTBidderLinkId, getUploadNeftDoc,objectId,0);
        }
        return "common/admin/UploadNeftVendorDetail";
    }
     
    /**
     * @author heeral.soni
     * access search neft vendor page
     */ 
    @RequestMapping(value = "/admin/searchvendor/{clientId}/{enc}", method = RequestMethod.GET)
    public String searchVendor(@PathVariable(CLIENT_ID) int clientId,ModelMap modelMap, HttpServletRequest request, HttpSession session) {
        try {
                modelMap.addAttribute(CLIENT_ID, clientId);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
        finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), searchNEFTBidderLinkId, getNeftVendorSearch,0,clientId);
        }
        return "common/admin/NEFTVendorSearch";
    }
	
    /**
     * @author heeral.soni
     * access download bidder detail date wise
     */ 
    @RequestMapping(value = "/admin/downloadvendordatewise/{clientId}/{prefix}/{fromWhere}/{enc}", method = RequestMethod.GET)
    public String downloadVendorDateWise(@PathVariable(CLIENT_ID) int clientId,@PathVariable(PREFIX) String prefix,@PathVariable(FROM_WHERE) String fromWhere,ModelMap modelMap, HttpServletRequest request, HttpSession session) {
        try {
                modelMap.addAttribute(CLIENT_ID, clientId);
                modelMap.addAttribute(CLIENT_NAME, clientService.getClientName(clientId));
                modelMap.addAttribute(PREFIX, prefix);
                modelMap.addAttribute(FROM_WHERE, fromWhere);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
        finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), downloadBidderLinkId, getNeftDateWiseSearch,0,clientId);
        }
        return "common/admin/DownloadVendorDateWise";
    }
    
    /**
     * @author heeral.soni
     * search vendor detail date wise
     */ 
    @RequestMapping(value = "/admin/downloadbidderdate", method = RequestMethod.POST)
    public String downloadVendorDate(HttpServletRequest request, HttpSession session) {
        int clientId = StringUtils.hasLength(request.getParameter("hdClientId")) ? Integer.parseInt(request.getParameter("hdClientId")) : 0;
        String retVal = null;
        try {        
                String prefix = StringUtils.hasLength(request.getParameter("hdPrefix")) ? request.getParameter("hdPrefix") : null;
                String fromWhere = StringUtils.hasLength(request.getParameter("hdFromWhere")) ? request.getParameter("hdFromWhere") : null;
                String date = StringUtils.hasLength(request.getParameter("txtDate")) ? request.getParameter("txtDate") : null;   
                retVal = "common/admin/downloadbidderdetail/" +clientId + "/" +prefix + "/" +fromWhere+ "/" +encryptDecryptUtils.encrypt(date);
        } catch (Exception ex) {
                return exceptionHandlerService.writeLog(ex);
        }
        finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), downloadBidderLinkId, postDownloadVendorDate,0,clientId);
        }
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    	
    /**
     * @author heeral.soni
     * ajax call for search and get neft vendor detail
     */ 
   @RequestMapping(value = "/admin/ajax/getvendordetail", method = RequestMethod.POST)
    public String getVendorDetail(ModelMap modelMap, HttpServletRequest request) {              
       int clientId = StringUtils.hasLength(request.getParameter("hdClientId")) ? Integer.parseInt(request.getParameter("hdClientId")) : 0;
       try {
                String emailId = StringUtils.hasLength(request.getParameter("txtEmailId")) ? request.getParameter("txtEmailId") : null;
                String bidderCode = StringUtils.hasLength(request.getParameter("txtBidderCode")) ? request.getParameter("txtBidderCode") : null;
                if (request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                    modelMap.addAttribute("bidderList", neftService.getBiderDetail(emailId,bidderCode,clientId));
                    modelMap.addAttribute(CLIENT_ID, clientId);
                }else {
                    modelMap.addAttribute("sessionExpired", true);
                }
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        }
        finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), searchNEFTBidderLinkId, postNeftBidderDetail,0,clientId);
            
        }
        return "common/admin/NEFTVendorSearchAjax";
    }
   
   /**
     * @author heeral.soni
     * used to send mail to neft vendor (individual bidder/all approve bidder)
     */ 
    @RequestMapping(value = "/admin/sendmailtobidder/{clientId}/{bidderId}/{compId}/{enc}", method = RequestMethod.GET)                       
    public String sendMailToBidder(@PathVariable(CLIENT_ID) int clientId,@PathVariable("bidderId") int bidderId,@PathVariable("compId") int compId, HttpServletRequest request,RedirectAttributes redirectAttributes){        
        String retVal = null;
        try{
                Map<String, Object> mailParams = new HashMap<String, Object>();
                List<Object[]> lst = neftService.getBiderDetailForSendMail(clientId,bidderId);
                List<Object[]> lstCmp = neftService.getCompanyDetailForSendMail(clientId,bidderId,compId);
                Object[] obj = null; 
                if(lst!=null && !lst.isEmpty()){
                    obj = lst.get(0);
                    //mailParams.put("paymentFor", "1".equals(obj[0].toString()) ? messageSource.getMessage("label_doc_fees", null, LocaleContextHolder.getLocale()) : messageSource.getMessage("label_emd", null, LocaleContextHolder.getLocale()));// 1 for docfees , 2 for emd
                    mailParams.put("paymentFor", obj[0].toString());// 1 for docfees , 2 for emd , 3 for docfees/emd
                    mailParams.put("tenderFor", obj[1].toString());
                    mailParams.put("benfAccName", obj[2].toString());
                    mailParams.put("benfBankBranch", obj[3].toString());
                    mailParams.put("benfIfscCode", obj[4].toString());
                    mailParams.put("deptName", obj[5].toString());
					mailParams.put("domainName", clientService.getClientNameById(clientId));
                }
                if(lst!=null && !lst.isEmpty() && lstCmp!=null && !lstCmp.isEmpty()){
                     for(int i =0;i<(lstCmp.size());i++){
                        Object [] objectCmp = lstCmp.get(i);
                        String companyId = objectCmp[0].toString();
                        String companyName = objectCmp[1].toString();
                        Object[] clientBnkDetail = neftService.getClientPGBank(clientId);
                        int bankId = Integer.parseInt(clientBnkDetail[0].toString());
                        if(bankId == 4)
                        {
                        	String bidderCode = objectCmp[0].toString();
                            while(bidderCode.length()<=11){
                            	bidderCode = "0" + bidderCode;
                            }
                            String  vendorCode = neftService.generateVendorCode(bankId, obj[6].toString(), obj[7].toString()) + bidderCode;
                          mailParams.put("clientCode", vendorCode);
                          mailParams.put("bidderCode", vendorCode);
                        }else{
                            mailParams.put("clientCode", obj[6].toString()+obj[7].toString()+companyId);
                            mailParams.put("bidderCode", obj[7].toString()+companyId);
                        }

                        mailParams.put("compName", companyName);
                        if(bidderId == 0){
                            mailContentUtillity.dynamicMailGeneration("50", "0" , null, mailParams,companyId,String.valueOf(clientId));                            
                        }else{
                            mailContentUtillity.dynamicMailGeneration("50", "1" , null, mailParams,String.valueOf(bidderId),String.valueOf(clientId));
                        }
                        // update status after mail sent
                        neftService.updateApprovedVendorStatus(Integer.parseInt(objectCmp[2].toString()), abcUtility.getSessionUserDetailId(request));
                     }
                     redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString() ,"msg_mail_success");
                 }else{
                	 redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString() ,"msg_no_vendor_available");
                 }
                if(bidderId == 0){
                    retVal = "common/admin/managepaymentconf/"+clientId+ "/"+ TAB_NEFTRTGS;
                }else{
                    retVal = "common/admin/searchvendor/"+clientId;
                }
        }
        catch(Exception ex){
            return exceptionHandlerService.writeLog(ex);
        }
         finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), sendMailLinkId, getNeftBidderMail,0,clientId);
        }
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
   
    /**
     * @author heeral.soni
     * used to map neft vendor code
     */ 
    @RequestMapping(value = "/admin/mapvendorcode/{clientId}/{docId}/{docName}/{enc}", method = RequestMethod.GET)
    public String mapVendorCode(@PathVariable(CLIENT_ID) int clientId,@PathVariable("docId") int docId,@PathVariable("docName") String docName,ModelMap modelMap, HttpServletRequest request,RedirectAttributes redirectAttributes){
        String retVal = null;
        boolean isXls = false;
        try{
            docName = encryptDecryptUtils.decrypt(docName);
            List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(neftUploadDocEventId, clientId);
	    TblDocUploadConf tblDocUploadConf=lstDocUploadConf.get(0);
            String xlsPath = docUploadPath+tblDocUploadConf.getPath()+File.separator+clientId+File.separator+docName;
            
            File file = new File(xlsPath);
            file = abcUtility.CheckDirExist(file);
            if("xls".equalsIgnoreCase(docName.substring(docName.lastIndexOf('.')+1).trim())){
                  isXls = true;
            }
            if(!file.exists()){
                redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString() ,"msg_file_notfound");
            }else{
                boolean isVendorCodeColumnAvailable = false;
                List<String> vendorCodeList =  new ArrayList<String>();
                Iterator<Row> rows = null;
                if (isXls) {
                     HSSFWorkbook workBook = new HSSFWorkbook(new POIFSFileSystem(new FileInputStream(xlsPath)));
                     HSSFSheet sheet = workBook.getSheetAt(0);
                     rows = sheet.rowIterator();
                 } else {
                     XSSFWorkbook workBook = new XSSFWorkbook(new FileInputStream(xlsPath));
                     XSSFSheet sheet = workBook.getSheetAt(0);
                     rows = sheet.rowIterator();
                }
               int rowcount=0;
                while (rows != null && rows.hasNext ()){
                    Row row = rows.next ();
                    int rowno = row.getRowNum();
                    rowcount++;
                    if(rowno == 0){
                        Iterator<Cell> cellIterator = row.cellIterator();
                        while (cellIterator.hasNext()) {
                            Cell cell = (Cell) cellIterator.next();
                            String cellValue = cell.toString().trim();
                            if(cellValue.equalsIgnoreCase(messageSource.getMessage("lbl_ven_code", null, LocaleContextHolder.getLocale()))){
                                isVendorCodeColumnAvailable = true;
                            }
                        }
                    }
                    if(isVendorCodeColumnAvailable){
                        Iterator<Cell> cellIterator = row.cellIterator();
                        //System.out.println("cellIterator = " + cellIterator.next().toString());
                        while (cellIterator.hasNext()) {
                            Cell cell = (Cell) cellIterator.next();
                            String cellValue = cell.toString().trim();
                            vendorCodeList.add(cellValue);
                        }
                    }
                }//end of while loop
                if(isVendorCodeColumnAvailable){
                    String vendorCodeString = null;
                    if(vendorCodeList != null){
                            Iterator<String> vendorCodeIterator = vendorCodeList.iterator();
                            while (vendorCodeIterator != null && vendorCodeIterator.hasNext()) {
                                    String vendorCode = vendorCodeIterator.next().toString();
                                    vendorCodeString += "'"+vendorCode+"',";  
                            }//end of while
                    }//end of if
                    boolean isMapped = false;
                    if(vendorCodeString != null && rowcount>=2){
                        isMapped = neftService.mapVendorCode(clientId,vendorCodeString.substring(4,vendorCodeString.length()-1),docId);
                    }
                    redirectAttributes.addFlashAttribute(isMapped? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isMapped? "msg_mapvendorcode" : "msg_no_vendor_available");
                }else{
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString() ,"msg_vendorcodenotexsist");
                }
            }
            retVal = "common/admin/uploadvendordata/"+clientId;
        }catch(Exception ex){
            return exceptionHandlerService.writeLog(ex);
        }
         finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), mapNEFTBidderCodeLinkId, getMappedBidderCode,0,clientId);
        }
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    
    /**
     * @author heeral.soni
     * export neft vendor detail into excel file
     */ 
    @RequestMapping(value = "/admin/downloadbidderdetail/{clientId}/{prefix}/{fromWhere}/{date}/{enc}", method = RequestMethod.GET)
    public void downloadBidderDetail(@PathVariable(CLIENT_ID) int clientId,@PathVariable(PREFIX) String prefix,@PathVariable(FROM_WHERE) String fromWhere,@PathVariable("date") String date,ModelMap modelMap, HttpServletRequest request,HttpServletResponse  response) {
        List<TblNeftRtgsBidderDetail> tblNeftRtgsBidderDetails = new ArrayList<TblNeftRtgsBidderDetail>();
        List<Object[]> list = null;
        String fileName = null;
        try {               
                Date now = new Date(); 
                String currDate = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(now);
                
                HSSFWorkbook wb = new HSSFWorkbook();
                HSSFSheet sheet = wb.createSheet();

                //Set Header Font
                HSSFFont headerFont = wb.createFont();
                headerFont.setBoldweight(headerFont.BOLDWEIGHT_BOLD);
                headerFont.setFontHeightInPoints((short) 12);

                //Set Header Style
                HSSFCellStyle headerStyle = wb.createCellStyle();
                headerStyle.setFillBackgroundColor(IndexedColors.BLACK.getIndex());
                headerStyle.setAlignment(headerStyle.ALIGN_LEFT);
                headerStyle.setFont(headerFont);
                headerStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);

                HSSFRow header = sheet.createRow(0);//its for header 
                header.setRowStyle(headerStyle);

                //Create Header Cell
                HSSFCell headerCell0  = header.createCell(0);
                HSSFCell headerCell1  = header.createCell(1);
                HSSFCell headerCell2  = header.createCell(2);
                HSSFCell headerCell3  = header.createCell(3);
                
                //set Column width
                sheet.setColumnWidth(0, 5000);
                sheet.setColumnWidth(1, 5000);
                sheet.setColumnWidth(2, 10000);
                sheet.setColumnWidth(3, 20000);

                if("pendingbidder".equalsIgnoreCase(fromWhere)){
                    list = neftService.getPendingBidderDetail(clientId);
                    fileName = "RTGSPendigBidderData_"+currDate;
                }else if("allbidder".equalsIgnoreCase(fromWhere)){
                    list = neftService.getAllBidderDetail(clientId);
                    fileName = "RTGSAllBidderData_"+currDate;
                }else if("bidderdate".equalsIgnoreCase(fromWhere)){
                    SimpleDateFormat sd2 = new SimpleDateFormat("dd/MM/yyyy");
                    SimpleDateFormat sd3 = new SimpleDateFormat("yyyy-MM-dd");
                    //System.out.println("sd3 ============ " +sd3.format(sd2.parse(encryptDecryptUtils.decrypt(date))));
                    list = neftService.getBidderDetailDateWise(clientId, sd3.format(sd2.parse(encryptDecryptUtils.decrypt(date))));
                    fileName = "RTGSBidderDateData_"+currDate;
                }
                
                //This Loop Will set all row wise cell value
                if(list != null && !list.isEmpty()){
                    //Set Header CellValue
                    headerCell0.setCellValue(messageSource.getMessage("lbl_rec_id", null, LocaleContextHolder.getLocale()));
                    headerCell1.setCellValue(messageSource.getMessage("lbl_ven_code", null, LocaleContextHolder.getLocale()));
                    headerCell2.setCellValue(messageSource.getMessage("lbl_vendorname", null, LocaleContextHolder.getLocale()));
                    headerCell3.setCellValue(messageSource.getMessage("lbl_bene_add", null, LocaleContextHolder.getLocale()));//header cell value set
                    if("allbidder".equalsIgnoreCase(fromWhere)){
                        HSSFCell headerCell4  = header.createCell(4);
                        HSSFCell headerCell5  = header.createCell(5);
                        headerCell4.setCellValue(messageSource.getMessage("lbl_sts", null, LocaleContextHolder.getLocale()));//header cell value set
                        headerCell5.setCellValue(messageSource.getMessage("lbl_sts_register", null, LocaleContextHolder.getLocale()));//header cell value set
                        sheet.setColumnWidth(4, 10000);
                        sheet.setColumnWidth(5, 10000);
                        headerCell4.setCellStyle(headerStyle);
                        headerCell5.setCellStyle(headerStyle);
                    }else if("bidderdate".equalsIgnoreCase(fromWhere)){
                        HSSFCell headerCell4  = header.createCell(4);
                        headerCell4.setCellValue(messageSource.getMessage("lbl_sts_register", null, LocaleContextHolder.getLocale()));//header cell value set
                        sheet.setColumnWidth(4, 10000);
                        headerCell4.setCellStyle(headerStyle);
                    }
                    
                    //Set Header Cell style
                    headerCell0.setCellStyle(headerStyle);
                    headerCell1.setCellStyle(headerStyle);
                    headerCell2.setCellStyle(headerStyle);
                    headerCell3.setCellStyle(headerStyle);
                    String clientCode = "";
                    Object[] clientBnkDetail = neftService.getClientPGBank(clientId);
                    int bankId = Integer.parseInt(clientBnkDetail[0].toString());
                    String vendorCode = null;
                    for(int i =0;i<(list.size());i++){
                        HSSFRow row = sheet.createRow(i+1);
                        Object [] objects = list.get(i);
                      if(bankId == 4)
                      {
                    	 clientCode = neftService.getClientCode(clientId);
                    	String bidderCode = objects[1].toString();
                        while(bidderCode.length()<=11){//Make 12-Digit Biddercode
                        	bidderCode = "0" + bidderCode;
                        }
                       // vendorCode = "Z" + clientCode + "AB" +  bidderCode;
                        vendorCode = neftService.generateVendorCode(bankId, clientCode, prefix) + bidderCode;
                      }else{
                    	  vendorCode = neftService.generateVendorCode(bankId, clientCode, prefix) + objects[1].toString();
                      }
                        //this loop will set all cell value in row
                        row.createCell(0).setCellValue(objects[0].toString());
                        row.createCell(1).setCellValue(vendorCode);
                        row.createCell(2).setCellValue(AbcUtility.reverseReplaceSpecialChars(objects[2].toString()));
                        row.createCell(3).setCellValue(clientService.getClientName(clientId));
                        if("allbidder".equalsIgnoreCase(fromWhere)){
                            row.createCell(4).setCellValue(objects[3].toString());
                            row.createCell(5).setCellValue(objects[4].toString());
                        }else if("bidderdate".equalsIgnoreCase(fromWhere)){
                            row.createCell(4).setCellValue(objects[3].toString());
                        }
                        if("pendingbidder".equalsIgnoreCase(fromWhere)){
                            TblNeftRtgsBidderDetail tblNeftRtgsBidderDetail = new TblNeftRtgsBidderDetail();
                            tblNeftRtgsBidderDetail.setTblClient(new TblClient(clientId));//set clientId 
                            tblNeftRtgsBidderDetail.setTblCompany(new TblCompany(Integer.parseInt(objects[1].toString())));//set companyId
                            tblNeftRtgsBidderDetail.setCompanyCode(vendorCode);
                            tblNeftRtgsBidderDetail.setCreatedBy(abcUtility.getSessionUserDetailId(request));
                            tblNeftRtgsBidderDetail.setCstatus(1);
                            tblNeftRtgsBidderDetail.setTblDepartment(new TblDepartment(Integer.parseInt(clientService.getClientField(clientId, "deptId").toString())));
                            tblNeftRtgsBidderDetails.add(tblNeftRtgsBidderDetail);
                        }
                    } // end of for loop
                }else{
                    headerCell0.setCellValue(messageSource.getMessage("empty_records", null, LocaleContextHolder.getLocale()));
                    headerCell0.setCellStyle(headerStyle);
                }
                if("pendingbidder".equalsIgnoreCase(fromWhere)){
                   neftService.addTblNeftRtgsBidderDetail(tblNeftRtgsBidderDetails);
                }
                
                ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
                wb.write(outByteStream);
                byte [] outArray = outByteStream.toByteArray();
                //wb.write(outByteStream);            
                //byte [] outArray = wb.getBytes();
                response.setContentType("application/ms-excel");
                response.setContentLength(outArray.length);
                response.setHeader("Expires:", "0"); // eliminates browser caching
                response.setHeader("Content-Disposition", "attachment; filename="+fileName+".xls");
                OutputStream outStream = response.getOutputStream();
                outStream.write(outArray);
                outStream.flush();
                outStream.close();
           } catch (Exception ex) {
           exceptionHandlerService.writeLog(ex);
        }
        finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), downloadBidderLinkId,getDownloadBidder,0,clientId);
        }
    }

    /**
     * @author heeral.soni
     * export neft vendor detail into excel file
     */ 
    @RequestMapping(value = "/admin/downloadbalancehistoryreport/{clientId}/{enc}", method = RequestMethod.GET)
    public void downloadBalanceHistoryReport(@PathVariable(CLIENT_ID) int clientId,ModelMap modelMap, HttpServletRequest request,HttpServletResponse  response) {
        List<Object[]> list = null;
        try {               
                Date now = new Date(); 
                String currentDate = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(now);
                
                HSSFWorkbook wb = new HSSFWorkbook();
                HSSFSheet sheet = wb.createSheet();

                //Set Header Font
                HSSFFont headerFont = wb.createFont();
                headerFont.setBoldweight(headerFont.BOLDWEIGHT_BOLD);
                headerFont.setFontHeightInPoints((short) 12);

                //Set Header Style
                HSSFCellStyle headerStyle = wb.createCellStyle();
                headerStyle.setFillBackgroundColor(IndexedColors.BLACK.getIndex());
                headerStyle.setAlignment(headerStyle.ALIGN_LEFT);
                headerStyle.setFont(headerFont);
                headerStyle.setBorderBottom(HSSFCellStyle.BORDER_MEDIUM);

                HSSFRow header = sheet.createRow(0);//its for header 
                header.setRowStyle(headerStyle);

                //Create Header Cell
                HSSFCell headerCell0  = header.createCell(0);
                HSSFCell headerCell1  = header.createCell(1);
                HSSFCell headerCell2  = header.createCell(2);
                HSSFCell headerCell3  = header.createCell(3);
                HSSFCell headerCell4  = header.createCell(4);
                HSSFCell headerCell5  = header.createCell(5);
                HSSFCell headerCell6  = header.createCell(6);
                HSSFCell headerCell7  = header.createCell(7);
                HSSFCell headerCell8  = header.createCell(8);
                
                //set Column width
                sheet.setColumnWidth(0, 10000);
                sheet.setColumnWidth(1, 10000);
                sheet.setColumnWidth(2, 10000);
                sheet.setColumnWidth(3, 10000);
                sheet.setColumnWidth(4, 10000);
                sheet.setColumnWidth(5, 10000);
                sheet.setColumnWidth(6, 10000);
                sheet.setColumnWidth(7, 10000);
                sheet.setColumnWidth(8, 10000);

                list = neftService.getNEFTBalanceHistory(clientId);
                String fileName = "Balance_History_Report_"+currentDate;
                //This Loop Will set all row wise cell value
                if(list != null && !list.isEmpty()){
                    //Set Header CellValue
                    headerCell0.setCellValue(messageSource.getMessage("lbl_bidder_reg_code", null, LocaleContextHolder.getLocale()));
                    headerCell1.setCellValue(messageSource.getMessage("fields_companyName", null, LocaleContextHolder.getLocale()));
                    headerCell2.setCellValue(messageSource.getMessage("lbl_phno1", null, LocaleContextHolder.getLocale()));//header cell value set
                    headerCell3.setCellValue(messageSource.getMessage("lbl_mobile_no", null, LocaleContextHolder.getLocale()));
                    headerCell4.setCellValue(messageSource.getMessage("column_mail", null, LocaleContextHolder.getLocale()));
                    headerCell5.setCellValue(messageSource.getMessage("field_secDepositAccNo", null, LocaleContextHolder.getLocale()));//header cell value set
                    headerCell6.setCellValue(messageSource.getMessage("lbl_total_amt", null, LocaleContextHolder.getLocale()));
                    headerCell7.setCellValue(messageSource.getMessage("lbl_bal_amt", null, LocaleContextHolder.getLocale()));
                    headerCell8.setCellValue(messageSource.getMessage("coloumn_datetime", null, LocaleContextHolder.getLocale()));
                                        
                    //Set Header Cell style
                    headerCell0.setCellStyle(headerStyle);
                    headerCell1.setCellStyle(headerStyle);
                    headerCell2.setCellStyle(headerStyle);
                    headerCell3.setCellStyle(headerStyle);
                    headerCell4.setCellStyle(headerStyle);
                    headerCell5.setCellStyle(headerStyle);
                    headerCell6.setCellStyle(headerStyle);
                    headerCell7.setCellStyle(headerStyle);
                    headerCell8.setCellStyle(headerStyle);
                    
                    for(int i =0;i<(list.size());i++){
                        HSSFRow row = sheet.createRow(i+1);
                        Object [] objects = list.get(i);
                        //this loop will set all cell value in row
                        row.createCell(0).setCellValue(objects[0].toString()!=null && !objects[0].toString().isEmpty() ? objects[0].toString() : "");
                        row.createCell(1).setCellValue(AbcUtility.reverseReplaceSpecialChars(objects[1].toString()!=null && !objects[1].toString().isEmpty() ? objects[1].toString() : ""));
                        row.createCell(2).setCellValue(objects[2].toString()!=null && !objects[2].toString().isEmpty() ? objects[2].toString() : "");
                        row.createCell(3).setCellValue(objects[3].toString()!=null && !objects[3].toString().isEmpty() ? objects[3].toString() : "");
                        row.createCell(4).setCellValue(objects[4].toString()!=null && !objects[4].toString().isEmpty() ? objects[4].toString() : "");
                        row.createCell(5).setCellValue(objects[5].toString()!=null && !objects[5].toString().isEmpty() ? objects[5].toString() : "");
                        row.createCell(6).setCellValue(objects[6].toString()!=null && !objects[6].toString().isEmpty() ? objects[6].toString() : "");
                        row.createCell(7).setCellValue(objects[7].toString()!=null && !objects[7].toString().isEmpty() ? objects[7].toString() : "");
                        row.createCell(8).setCellValue(objects[8].toString()!=null && !objects[8].toString().isEmpty() ? CommonUtility.convertTimezone(objects[8]) : "");
                        //System.out.println("date last------>"+CommonUtility.convertTimezone(objects[8]));
                    } // end of for loop
                }else{
                    headerCell0.setCellValue(messageSource.getMessage("empty_records", null, LocaleContextHolder.getLocale()));
                    headerCell0.setCellStyle(headerStyle);
                }
                                
                ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
                wb.write(outByteStream);
                byte [] outArray = outByteStream.toByteArray();
                response.setContentType("application/ms-excel");
                response.setContentLength(outArray.length);
                response.setHeader("Expires:", "0"); // eliminates browser caching
                response.setHeader("Content-Disposition", "attachment; filename="+fileName+".xls");
                OutputStream outStream = response.getOutputStream();
                outStream.write(outArray);
                outStream.flush();
                outStream.close();
                
           } catch (Exception ex) {
           exceptionHandlerService.writeLog(ex);
        }
        finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), balanceReportLinkId,getDownloadBidder,0,clientId);
        }
    }

    /**
     * @author heeral
     * used to save refund request data
     */
    @RequestMapping(value = "/bidder/submitRefundMoney", method = RequestMethod.POST)
    public String submitRefundMoney(HttpServletRequest request, RedirectAttributes redirectAttributes) {
    	String retVal = REDIRECT_SESSION_EXPIRED;
       SessionBean sessionBean = request.getSession() != null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
       boolean isRefund = false;
       BigDecimal amount = null;
       BigDecimal availableBalance = null;
       String flashMsg = "msg_validate_confirm_amount";
        try {
            if (sessionBean != null) {
            	TblClientPGBankMapping tblClientPGBankMapping=clientService.getTblClientPGBankMapping(abcUtility.getSessionClientId(request),2);
        		int bankId=tblClientPGBankMapping!=null?tblClientPGBankMapping.getTblBankMaster().getBankId():0;
        		
                int companyId = sessionBean.getCompanyId();
                int clientId = abcUtility.getSessionClientId(request);
                amount = new BigDecimal(StringUtils.hasLength(request.getParameter("txtAmtTobeRefund")) ? request.getParameter("txtAmtTobeRefund") : "0.00");
                availableBalance = neftService.getAvailableSecurityDeposit(sessionBean.getCompanyId(), abcUtility.getSessionClientId(request));                
                String creditAccNo = StringUtils.hasLength(request.getParameter("txtAccountNumber")) ? request.getParameter("txtAccountNumber") : null;
                String confirmCreditAccNo = StringUtils.hasLength(request.getParameter("txtConfirmAccountNumber")) ? request.getParameter("txtConfirmAccountNumber") : null;
                String creditIFSCCode = StringUtils.hasLength(request.getParameter("txtIfscCode")) ? request.getParameter("txtIfscCode") : null;
                String creditAccontName = StringUtils.hasLength(request.getParameter("txtAccountName")) ? request.getParameter("txtAccountName") : null;
                String clientName = StringUtils.hasLength(request.getParameter("hdClientName")) ? request.getParameter("hdClientName") : null;
                String debitAccNo = StringUtils.hasLength(request.getParameter("hdDebitAccNo")) ? request.getParameter("hdDebitAccNo") : null;
                if(availableBalance.compareTo(new BigDecimal(amount.toString())) < 0){
                    //refunded amount should not be greater than available balance
                    flashMsg = "msg_validate_refund_amount";
                    redirectAttributes.addFlashAttribute("errorMsg", flashMsg);
                }else if(amount.compareTo(new BigDecimal("0"))==0){
                    //refunded amount != 0
                    flashMsg = "zero_value_isnot_allow";
                    redirectAttributes.addFlashAttribute("errorMsg", flashMsg);
                }else if(confirmCreditAccNo.equals(creditAccNo)){
                        //insert into transaction csvdetail
                        TblTransactionCSVDetail tblTransactionCSVDetail = new TblTransactionCSVDetail();
                        tblTransactionCSVDetail.setObjectId(0);
                        tblTransactionCSVDetail.setCompanyId(sessionBean.getCompanyId());
                        tblTransactionCSVDetail.setTblTransactionType(new TblTransactionType(3));
                        tblTransactionCSVDetail.setPaymentId(0);
                        tblTransactionCSVDetail.setEmdTransactionId(0);
                        tblTransactionCSVDetail.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
                        tblTransactionCSVDetail.setRemark("NA");
                        tblTransactionCSVDetail.setCreditAccNo(creditAccNo);
                        tblTransactionCSVDetail.setClientName(clientName);
                        tblTransactionCSVDetail.setCreditAccISFC(creditIFSCCode);
                        tblTransactionCSVDetail.setCreditAccName(creditAccontName);
                        tblTransactionCSVDetail.setCmsRefNo("NA");
                        tblTransactionCSVDetail.setRbiRefNo("NA");
                        tblTransactionCSVDetail.setIBankDate(new Date(0));
                        tblTransactionCSVDetail.setLiqTransStatus(0);
                        tblTransactionCSVDetail.setAmount(amount);
                        tblTransactionCSVDetail.setDebitAccNo(debitAccNo);
                        
                        TblNeftTransactionHistory tblNeftTransactionHistory= new TblNeftTransactionHistory();
						tblNeftTransactionHistory.setTblClient(new TblClient(abcUtility.getSessionClientId(request)));
		                tblNeftTransactionHistory.setTblCompany(new TblCompany(sessionBean.getCompanyId()));
		                tblNeftTransactionHistory.setObjectId(0);
		                tblNeftTransactionHistory.setCreatedBy(sessionBean.getUserDetailId());
		                tblNeftTransactionHistory.setCreditAccountNo(creditAccNo);
	                	tblNeftTransactionHistory.setDebitAccountNo(debitAccNo);			
	                	tblNeftTransactionHistory.setTblTransactionType(new TblTransactionType(3));
	                	tblNeftTransactionHistory.setTblTransactionCSVDetail(tblTransactionCSVDetail);
	                	
                        isRefund = neftService.updateBidderAcountBalance(clientId, companyId,amount,tblTransactionCSVDetail,tblNeftTransactionHistory);
                        if(bankId == 6 && isRefund){
                        	yesBankService.yesBankNeftFundTransferAPICall(tblTransactionCSVDetail);
                        }
                        redirectAttributes.addFlashAttribute(isRefund ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), isRefund ? "msg_success_refund" : "msg_fail_refund");
                }else{
                    //msg for not match for account no and confirm account no
                    redirectAttributes.addFlashAttribute("errorMsg", flashMsg);
                }
                retVal = "redirect:/common/bidder/getRefundMoney"+encryptDecryptUtils.generateRedirect("common/bidder/getRefundMoney", request);
            }
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
                if(abcUtility.getSessionIsPkiEnabled(request)==pkiEnable){
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postRefundRequest,0, 0,refundReqSignRemark,StringUtils.hasLength(request.getParameter("skpSignText"))?request.getParameter("skpSignText"):"");
    		}else{
    			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), 0, postRefundRequest,0, 0);
    		}
        }
        return retVal;
    }
	/**
	 * @author sharmila
	 * handle GET request to create NEFT RTGS
	 */
	@RequestMapping(value = "/admin/createNeftRtgs/{clientId}/{deptId}/{enc}", method = RequestMethod.GET)
	public String createNeftRtgs(@PathVariable("clientId") int clientId,@PathVariable(DEPT_ID) int deptId, ModelMap modelMap, HttpServletRequest request) {
		String pageName="common/admin/createNeftRtgs";
		boolean isParentDept=true;
		TblDepartment parentDepartment=null;
		try {
			String url=request.getRequestURL().toString();
			modelMap.put("deptName",clientService.getDepartmentById(deptId).getDeptName());
			modelMap.put("lstPayFor", neftService.getPaymentFor());
			modelMap.put("opType", "insert");			
			Object[] obj=clientService.getClientFields(clientId,"domainName,paymentConfigBy,deptId");
			modelMap.addAttribute("domainName", obj[0]);
			int paymentConfigBy=Integer.valueOf(obj[1].toString());
			modelMap.addAttribute("paymentConfigBy",paymentConfigBy);
			parentDepartment=clientService.getDepartmentById(Integer.valueOf(obj[2].toString()));
			modelMap.addAttribute("parentDepartment", parentDepartment);
			Object[] clientBnkDetail = neftService.getClientPGBank(clientId);
            int bankId = Integer.parseInt(clientBnkDetail[0].toString());
            modelMap.addAttribute("bankId", bankId);
			if(bankId == 6){
				String domainPort=url.split("/")[2];
				URL requestUrl=new URL(url);
				if((requestUrl.getPort() != 80) && (requestUrl.getPort() != 443) && (requestUrl.getPort() != -1)){
					url="http://"+clientService.getClientField(clientId,"domainName")+":"+domainPort.split(":")[1]+request.getContextPath()+"/";
				}else{
					url="https://"+clientService.getClientField(clientId,"domainName")+request.getContextPath()+"/";
				}
				
				modelMap.put("appCode", "ECSTDJ01");
				modelMap.put("validateUrl",url+"commonwebservice/validateBidderWallet");
				modelMap.put("notifyUrl",url+"commonwebservice/notifyBidderWallet");	
			}
			
			if(paymentConfigBy==2 ){
				modelMap.put("paymentConfigBy",paymentConfigBy);
				isParentDept=obj[1].toString().equals(deptId);
				modelMap.put("isParentDept", isParentDept);
				int neftRtgsId=0;
				if(!obj[2].equals(deptId)){	
					neftRtgsId=neftService.getTblNeftRtgsConfByClientId(clientId).getNeftRtgsId();
					modelMap.put("neftRtgsId",neftRtgsId);
					List<Object[]> list=neftService.getNeftDeptListByClientId(clientId);
					modelMap.put("neftDeptList",list!=null && !list.isEmpty() ? abcUtility.convert(list) : null);
					List<Object[]> neftDetailList = neftService.getNeftRtgsDetail(neftRtgsId,parentDepartment.getDeptId());
					if(neftDetailList != null && !neftDetailList.isEmpty()){
						
						modelMap.put("tblDeptNeftRtgsConf", (TblDeptNeftRtgsConf) neftDetailList.get(0)[1]);
						modelMap.put("tblNeftRtgsConf", (TblNeftRtgsConf) neftDetailList.get(0)[0]);
					}
					if(bankId == 6){
						int deptNeftRtgsId=((TblDeptNeftRtgsConf) neftDetailList.get(0)[1]).getDeptNeftRtgsId();
			            TblDeptNeftRtgsConfDetails secDepositeAccountDetails=neftService.getDeptNeftRtgsConfDetails(deptNeftRtgsId, clientId, 1);
			            modelMap.addAttribute("secDepositeAccountDetails", secDepositeAccountDetails);
					}
					pageName="common/admin/CreateDeptNeftRtgs";
				}
				
			}
		} catch (Exception ex) {
			//ex.printStackTrace();
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manage_client_neft_create, createNeftRtgs, 0, clientId);
		}
		return pageName;
	}

	/**
	 * @author sharmila
	 * handle GET request to edit and view NEFT RTGS
	 */
	@RequestMapping(value = "/admin/getNeftRtgs/{neftRtgsId}/{deptId}/{isEdit}/{enc}", method = RequestMethod.GET)
	public String getNeftRtgs(ModelMap modelMap,@PathVariable("neftRtgsId") int neftRtgsId,@PathVariable(DEPT_ID) int deptId,@PathVariable("isEdit") int isEdit,HttpServletRequest request) {
		String retVal = "";
		int linkId = 0;
		int paymentConfigBy=0;
		TblDepartment parentDepartment=null;
		Object[] obj=null;
		try {
			modelMap.put("lstPayFor", neftService.getPaymentFor());
			modelMap.put("opType", "update");
			modelMap.put("deptName",clientService.getDepartmentById(deptId).getDeptName());			
			List<Object[]> neftDetailList = null;
			neftDetailList =neftService.getNeftRtgsDetail(neftRtgsId,deptId);
			if(neftDetailList != null && !neftDetailList.isEmpty()){
				
				modelMap.put("tblDeptNeftRtgsConf", (TblDeptNeftRtgsConf) neftDetailList.get(0)[1]);
				modelMap.put("tblNeftRtgsConf", (TblNeftRtgsConf) neftDetailList.get(0)[0]);
//				modelMap.put("tblDepartment", (TblDepartment) neftDetailList.get(0)[2]);
//				modelMap.put("tblClient", (TblClient) neftDetailList.get(0)[3]);
				int clientId=((TblNeftRtgsConf) neftDetailList.get(0)[0]).getTblClient().getClientId();
				obj=clientService.getClientFields(clientId,"domainName,paymentConfigBy,deptId");
				modelMap.addAttribute("clientId", clientId);
				modelMap.addAttribute("domainName", obj[0]);
				paymentConfigBy=Integer.valueOf(obj[1].toString());
				modelMap.addAttribute("paymentConfigBy",paymentConfigBy);
				parentDepartment=clientService.getDepartmentById(Integer.valueOf(obj[2].toString()));
				modelMap.addAttribute("parentDepartment", parentDepartment);
				
				if(isEdit==1 && paymentConfigBy==2 && !obj[2].equals(deptId)){	
					neftRtgsId=neftService.getTblNeftRtgsConfByClientId(clientId).getNeftRtgsId();
					modelMap.put("neftRtgsId",neftRtgsId);
					List<Object[]> list=neftService.getNeftDeptListByClientId(clientId);
					modelMap.put("neftDeptList",list!=null && !list.isEmpty() ? abcUtility.convert(list) : null);
				}
				Object[] clientBnkDetail = neftService.getClientPGBank(clientId);
	            int bankId = Integer.parseInt(clientBnkDetail[0].toString());
	            modelMap.addAttribute("bankId", bankId);
	            if(bankId == 6){
		            modelMap.addAttribute("appCode", "ECSTDJ01");
		            
		            int deptNeftRtgsId=((TblDeptNeftRtgsConf) neftDetailList.get(0)[1]).getDeptNeftRtgsId();
		            TblDeptNeftRtgsConfDetails secDepositeAccountDetails=neftService.getDeptNeftRtgsConfDetails(deptNeftRtgsId, clientId, 1);
		            modelMap.addAttribute("secDepositeAccountDetails", secDepositeAccountDetails);
		            
		            TblDeptNeftRtgsConfDetails escrowAccountDetails=neftService.getDeptNeftRtgsConfDetails(deptNeftRtgsId, clientId, 2);
		            modelMap.addAttribute("escrowAccountDetails", escrowAccountDetails);
		            
		            TblDeptNeftRtgsConfDetails currentAccountDetails=neftService.getDeptNeftRtgsConfDetails(deptNeftRtgsId, clientId, 3);
		            modelMap.addAttribute("currentAccountDetails", currentAccountDetails);
	            }
			}
			if(isEdit == 1){				
				if(paymentConfigBy==2 && !obj[2].equals(deptId)){ 
					retVal="common/admin/CreateDeptNeftRtgs";
				}else{
					retVal = "common/admin/createNeftRtgs";
				}
				linkId = manage_client_neft_edit;
			}else{
				retVal = "common/admin/viewNeftRtgs";
				linkId = manage_client_neft_view;
			}
		} catch (Exception ex) {
			//ex.printStackTrace();
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getNeftRtgs, 0, neftRtgsId);
		}
		return retVal;
	}

	/**
	 * @author sharmila
	 * handle POST request to create and edit NEFT RTGS
	 */ 
	@RequestMapping(value = "/admin/addNeftRtgs", method = RequestMethod.POST)
	public String addUpdateNeftRtgsDetail(@ModelAttribute("NeftRtgsDataBean") NeftRtgsDataBean neftRtgsDataBean, RedirectAttributes redirectAttributes, HttpServletRequest request) {
		boolean success = false;
		String retVal = "redirect:/sessionexpired";
		List<TblDeptNeftRtgsConfDetails> deptNeftRtgsConfDetails = new ArrayList<TblDeptNeftRtgsConfDetails>();
		TblDeptNeftRtgsConfDetails deptNeftRtgsConfDetail = null;
		try {
			//int clientId = abcUtility.getSessionClientId(request);
			int userDetailId = abcUtility.getSessionUserDetailId(request);
			int bankId = StringUtils.hasLength(request.getParameter("hdBankId")) ? Integer.parseInt(request.getParameter("hdBankId")) : 0;  
			TblClient tblClient = new TblClient(neftRtgsDataBean.getHdClientId());
			TblNeftRtgsConf tblNeftRtgsConf = new TblNeftRtgsConf();
			tblNeftRtgsConf.setCreatedBy(userDetailId);
			tblNeftRtgsConf.setTblClient(tblClient);
			tblNeftRtgsConf.setBidderCodePrefix(neftRtgsDataBean.getTxtPrefix());
			
			tblNeftRtgsConf.setValidateURL(neftRtgsDataBean.getTxtvalidateURL() != null && !"".equals(neftRtgsDataBean.getTxtvalidateURL()) ? neftRtgsDataBean.getTxtvalidateURL() : "");
			tblNeftRtgsConf.setNotifyURL(neftRtgsDataBean.getTxtnotifyURL() != null && !"".equals(neftRtgsDataBean.getTxtnotifyURL()) ? neftRtgsDataBean.getTxtnotifyURL() : "");
			tblNeftRtgsConf.setUsername(neftRtgsDataBean.getTxtuserName() != null && !"".equals(neftRtgsDataBean.getTxtuserName()) ? neftRtgsDataBean.getTxtuserName() : "");
			tblNeftRtgsConf.setPassword(neftRtgsDataBean.getTxtpassword() != null && !"".equals(neftRtgsDataBean.getTxtpassword()) ? neftRtgsDataBean.getTxtpassword() : "");
			
			tblNeftRtgsConf.setFundTransferFile(neftRtgsDataBean.getTxtFundTransferFile() !=null && !"".equals(neftRtgsDataBean.getTxtFundTransferFile()) ? neftRtgsDataBean.getTxtFundTransferFile()+"_%s.csv":"");
			tblNeftRtgsConf.setFundTransferReversalFile(neftRtgsDataBean.getTxtFundTransferReversalFile() != null && !"".equals(neftRtgsDataBean.getTxtFundTransferReversalFile()) ? neftRtgsDataBean.getTxtFundTransferReversalFile()+"_" : "");
			tblNeftRtgsConf.setRefundRequestFile(neftRtgsDataBean.getTxtRefundRequestFile() != null && !"".equals(neftRtgsDataBean.getTxtRefundRequestFile()) ? neftRtgsDataBean.getTxtRefundRequestFile()+"_%s.csv":"");
			tblNeftRtgsConf.setRefundRequestReversalFile(neftRtgsDataBean.getTxtRefundRequestReversalFile() != null && !"".equals(neftRtgsDataBean.getTxtRefundRequestReversalFile()) ? neftRtgsDataBean.getTxtRefundRequestReversalFile()+"_":"");
			tblNeftRtgsConf.setEmdReleaseFile(neftRtgsDataBean.getTxtEMDReleaseFile() != null && !"".equals(neftRtgsDataBean.getTxtEMDReleaseFile()) ? neftRtgsDataBean.getTxtEMDReleaseFile()+"_%s.csv":"");
			tblNeftRtgsConf.setEmdReleaseReversalFile(neftRtgsDataBean.getTxtEMDReleaseReversalFile() != null && !"".equals(neftRtgsDataBean.getTxtEMDReleaseReversalFile()) ? neftRtgsDataBean.getTxtEMDReleaseReversalFile()+"_":"");
			tblNeftRtgsConf.setECollectionFileName(neftRtgsDataBean.getTxtEMDReleaseReversalFile() != null && !"".equals(neftRtgsDataBean.getTxtEMDReleaseReversalFile()) ? neftRtgsDataBean.getTxtECollectionFileName()+"_":"");
			
			tblNeftRtgsConf.setClientName(neftRtgsDataBean.getTxtClientName());
//			tblNeftRtgsConf.setEscrowAccNo(neftRtgsDataBean.getTxtPayEscrowAccNo());
			tblNeftRtgsConf.setPgReleaseAccNo(neftRtgsDataBean.getTxtPgReleaseAccNo());
			tblNeftRtgsConf.setPgReleaseAccName(neftRtgsDataBean.getTxtPgReleaseAccName());
			tblNeftRtgsConf.setPgReleaseIfsc(neftRtgsDataBean.getTxtPgReleaseIfsc());
			tblNeftRtgsConf.setMailSubject(neftRtgsDataBean.getTxtTenderFor());//tender for
			tblNeftRtgsConf.setClientCode(neftRtgsDataBean.getTxtClientCode());
			tblNeftRtgsConf.setPaymentFor(neftRtgsDataBean.getSelPaymentFor());
//			tblNeftRtgsConf.setPaymentMode(neftRtgsDataBean.getRdPaymentMode());
			tblNeftRtgsConf.setBenfAccName(neftRtgsDataBean.getTxtBenfAccName());
			tblNeftRtgsConf.setBenfBranchName(neftRtgsDataBean.getTxtBenfBankBranch());
			tblNeftRtgsConf.setBenfIfsc(neftRtgsDataBean.getTxtBenfIFSCCode());
			tblNeftRtgsConf.setCstatus(0);
			tblNeftRtgsConf.setBidderCodeRequestFile(neftRtgsDataBean.getTxtBidderCodeRequestFile() != null && !"".equals(neftRtgsDataBean.getTxtBidderCodeRequestFile()) ? neftRtgsDataBean.getTxtBidderCodeRequestFile()+"_%s.csv" : "");
			tblNeftRtgsConf.setBidderCodeResponseFile(neftRtgsDataBean.getTxtBidderCodeResponseFile() != null && !"".equals(neftRtgsDataBean.getTxtBidderCodeResponseFile()) ? neftRtgsDataBean.getTxtBidderCodeResponseFile()+"_" : "");
			if(bankId==1){
				tblNeftRtgsConf.setCancellationFile(tblNeftRtgsConf.getClientCode()+"_"+tblNeftRtgsConf.getClientCode()+"CANC_");
				tblNeftRtgsConf.setUploadRejectFile(tblNeftRtgsConf.getClientCode()+"_"+tblNeftRtgsConf.getClientCode()+"UPLDREJ_");
			}
			TblLastTransactionDetail tblLastTransactionDetail = null;
			if(neftRtgsDataBean.getHdNeftRtgsId() != 0){
				tblNeftRtgsConf.setNeftRtgsId(neftRtgsDataBean.getHdNeftRtgsId());
			}else{
				tblLastTransactionDetail = new TblLastTransactionDetail();
				tblLastTransactionDetail.setTblClient(tblClient);
				tblLastTransactionDetail.setLastEmdReleaseId(0);
				tblLastTransactionDetail.setLastSecurityfeesReleaseId(0);
				tblLastTransactionDetail.setLastFundTransferId(0);
				tblLastTransactionDetail.setLastRefundRequestId(0);
			}

			TblDeptNeftRtgsConf tblDeptNeftRtgsConf = new TblDeptNeftRtgsConf();
			tblDeptNeftRtgsConf.setSecDepositAccNo(neftRtgsDataBean.getTxtSecDepositAccNo());
			tblDeptNeftRtgsConf.setSecDepositAccName(neftRtgsDataBean.getTxtSecDepositAccName());
			tblDeptNeftRtgsConf.setSecDepositAccIfsc(neftRtgsDataBean.getTxtSecDepositAccIfsc());
			tblDeptNeftRtgsConf.setEscrowAccIfsc(neftRtgsDataBean.getTxtEscrowAccIfsc());
			tblDeptNeftRtgsConf.setEscrowAccName(neftRtgsDataBean.getTxtEscrowAccName());
			tblDeptNeftRtgsConf.setEscrowAccNo(neftRtgsDataBean.getTxtEscrowAccNo());
			tblDeptNeftRtgsConf.setCurrentAccIfsc(neftRtgsDataBean.getTxtCurrentAccIfsc());
			tblDeptNeftRtgsConf.setCurrentAccName(neftRtgsDataBean.getTxtCurrentAccName());
			tblDeptNeftRtgsConf.setCurrentAccNo(neftRtgsDataBean.getTxtCurrentAccNo());
			tblDeptNeftRtgsConf.setForthAccIfsc(neftRtgsDataBean.getTxtForthAccIfsc());
			tblDeptNeftRtgsConf.setForthAccName(neftRtgsDataBean.getTxtForthAccName());
			tblDeptNeftRtgsConf.setForthAccNo(neftRtgsDataBean.getTxtForthAccNo());
			tblDeptNeftRtgsConf.setCommissionAccIfsc(neftRtgsDataBean.getTxtCommissionAccIfsc());
			tblDeptNeftRtgsConf.setCommissionAccName(neftRtgsDataBean.getTxtCommissionAccName());
			tblDeptNeftRtgsConf.setCommissionAccNo(neftRtgsDataBean.getTxtCommissionAccNo());

			tblDeptNeftRtgsConf.setTblDepartment(new TblDepartment(neftRtgsDataBean.getHdDeptId()));
			if(neftRtgsDataBean.getHdDeptNeftRtgsId() != 0){
				tblDeptNeftRtgsConf.setDeptNeftRtgsId(neftRtgsDataBean.getHdDeptNeftRtgsId());
			}
			//tblDeptNeftRtgsConf.setTblDepartment(clientService.getDepartmentById(deptId));
			tblDeptNeftRtgsConf.setTblNeftRtgsConf(tblNeftRtgsConf);
			if(bankId == 6){
				//Security Deposit Account
				deptNeftRtgsConfDetail= neftService.getDeptNeftRtgsConfDetails(tblDeptNeftRtgsConf.getDeptNeftRtgsId(),tblClient.getClientId(),1);
				if(deptNeftRtgsConfDetail == null){
					deptNeftRtgsConfDetail = new TblDeptNeftRtgsConfDetails();
				}
				deptNeftRtgsConfDetail.setTblDeptNeftRtgsConf(tblDeptNeftRtgsConf);
				deptNeftRtgsConfDetail.setTblClient(tblClient);
				deptNeftRtgsConfDetail.setAccountType(1);
				deptNeftRtgsConfDetail.setCustId(neftRtgsDataBean.getTxtSecDepositAccCustId());
				deptNeftRtgsConfDetail.setUserId(neftRtgsDataBean.getTxtSecDepositAccUserID());
				deptNeftRtgsConfDetail.setPassword(encryptDecryptUtils.encrypt(neftRtgsDataBean.getTxtSecDepositAccPassword()));
				deptNeftRtgsConfDetail.setBankClientId(neftRtgsDataBean.getTxtSecDepositAccBankClientId());
				deptNeftRtgsConfDetail.setBankClientSecret(neftRtgsDataBean.getTxtSecDepositAccBankClientSecret());
				deptNeftRtgsConfDetails.add(deptNeftRtgsConfDetail);
				
				//Escrow Account
				deptNeftRtgsConfDetail= neftService.getDeptNeftRtgsConfDetails(tblDeptNeftRtgsConf.getDeptNeftRtgsId(),tblClient.getClientId(),2);
				if(deptNeftRtgsConfDetail == null){
					deptNeftRtgsConfDetail = new TblDeptNeftRtgsConfDetails();
				}
				deptNeftRtgsConfDetail.setTblDeptNeftRtgsConf(tblDeptNeftRtgsConf);
				deptNeftRtgsConfDetail.setTblClient(tblClient);
				deptNeftRtgsConfDetail.setAccountType(2);
				deptNeftRtgsConfDetail.setCustId(neftRtgsDataBean.getTxtEscrowAccCustId());
				deptNeftRtgsConfDetail.setUserId(neftRtgsDataBean.getTxtEscrowAccUserID());
				deptNeftRtgsConfDetail.setPassword(encryptDecryptUtils.encrypt(neftRtgsDataBean.getTxtEscrowAccPassword()));
				deptNeftRtgsConfDetail.setBankClientId(neftRtgsDataBean.getTxtEscrowAccBankClientId());
				deptNeftRtgsConfDetail.setBankClientSecret(neftRtgsDataBean.getTxtEscrowAccBankClientSecret());
				deptNeftRtgsConfDetails.add(deptNeftRtgsConfDetail);
				
				//Current Account
				deptNeftRtgsConfDetail= neftService.getDeptNeftRtgsConfDetails(tblDeptNeftRtgsConf.getDeptNeftRtgsId(),tblClient.getClientId(),3);
				if(deptNeftRtgsConfDetail == null){
					deptNeftRtgsConfDetail = new TblDeptNeftRtgsConfDetails();
				}
				deptNeftRtgsConfDetail.setTblDeptNeftRtgsConf(tblDeptNeftRtgsConf);
				deptNeftRtgsConfDetail.setTblClient(tblClient);
				deptNeftRtgsConfDetail.setAccountType(3);
				deptNeftRtgsConfDetail.setCustId(neftRtgsDataBean.getTxtCurrentAccCustId());
				deptNeftRtgsConfDetail.setUserId(neftRtgsDataBean.getTxtCurrentAccUserID());
				deptNeftRtgsConfDetail.setPassword(encryptDecryptUtils.encrypt(neftRtgsDataBean.getTxtCurrentAccPassword()));
				deptNeftRtgsConfDetail.setBankClientId(neftRtgsDataBean.getTxtCurrentAccBankClientId());
				deptNeftRtgsConfDetail.setBankClientSecret(neftRtgsDataBean.getTxtCurrentAccBankClientSecret());
				deptNeftRtgsConfDetails.add(deptNeftRtgsConfDetail);
			}
			success = neftService.addUpdateNeftRtgsPaymentDetail(tblDeptNeftRtgsConf,tblLastTransactionDetail,deptNeftRtgsConfDetails);
			
			success=setTransactionTypeAccountMapping(tblClient.getClientId(), Integer.parseInt(clientService.getClientField(tblClient.getClientId(), "deptId").toString()), 1, 3, 1, 2, 1, 4, 2, 3, 2, 1, 2, 3,1,5,1,3,1,3,3,1,3,6);
			retVal = "common/admin/managepaymentconf/"+neftRtgsDataBean.getHdClientId()+ "/"+TAB_NEFTRTGS;
		} catch (Exception ex) {
			//ex.printStackTrace();
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manage_client_neft_create, getNeftRtgs, neftRtgsDataBean.getHdClientId(), neftRtgsDataBean.getHdNeftRtgsId());
		}
		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? neftRtgsDataBean.getHdNeftRtgsId() == 0 ? "redirect_success_create_neft" : "redirect_success_edit_neft" : CommonKeywords.ERROR_MSG_KEY.toString());
		return "redirect:/" +retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	}

    /**
     * @author sharmila
     * @param payAmount
     * @param response
     * @param request
     * @param httpSession
     */
    @RequestMapping(value = "/ajax/getAvailableSecurityDeposit", method = RequestMethod.POST)
    public void getAvailableSecurityDeposit(@RequestParam("payAmount") BigDecimal payAmount, HttpServletResponse response, HttpServletRequest request, HttpSession httpSession) {
        StringBuilder str = new StringBuilder("sessionexpired");
        try {
        	if (httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
            	SessionBean sBean =(SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
        		str.setLength(0);
        		BigDecimal balanceAmount = neftService.getAvailableSecurityDeposit(sBean.getCompanyId(), abcUtility.getSessionClientId(request));
        		str.append("<td>").append("Security Deposit Account").append("</td><td>Available balance:").append(balanceAmount).append("<input type='hidden' name='balanceAmount' value='").append(balanceAmount).append("'/>");
       			str.append("<input type='hidden' id='balAvailable' value='").append(payAmount.compareTo(balanceAmount)).append("'>"); //it should be -1 or 0
        		str.append("</td>");
        	}
        	response.getWriter().write(str.toString());
        } catch (Exception ex) {
        	//ex.printStackTrace();
            exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), biddingEventDashboardLinkId, "get Available Security Deposit", 0, 0);
        }
    }
    /**
	 * @author dipika patel
	 * handle GET request to refund money in NEFT RTGS
	 */
	@RequestMapping(value = "/bidder/getRefundMoney/{enc}", method = RequestMethod.GET)
	public String getNeftRtgs(ModelMap modelMap,HttpServletRequest request,HttpSession httpSession) {
		String retVal = "common/bidder/RefundReq";
		int companyId = 0;
		int linkId=0;
		int clientId=0;
		try {
			SessionBean sBean =(SessionBean) httpSession.getAttribute(CommonKeywords.SESSION_OBJ.toString());
			companyId=sBean.getCompanyId();
			clientId=abcUtility.getSessionClientId(request);
			modelMap.put("balanceAmount", neftService.getAvailableSecurityDeposit(companyId,clientId));
			modelMap.put("lstTranscationDetail", neftService.getPrevRefundReq(companyId, clientId, 0));
			modelMap.put("lstPreviousPaidTran",abcUtility.convert(neftService.getPrevPaidTranscationDetail(companyId, clientId)));
			modelMap.put("neftDetail",neftService.getNeftConfDetailForRefund(clientId));
			modelMap.put("companyId",companyId);
			String publicKey=null;
	    	if(abcUtility.getSessionIsPkiEnabled(request)==1){
	    		String certIds[] = ((SessionBean) request.getSession().getAttribute("sessionObject")).getCertId().split(",");
	    		if(certIds!=null && certIds.length!=0){
	    			publicKey= commonService.getPublicKeyById(Integer.parseInt(certIds[0]));
	    		}
	    		modelMap.addAttribute("publicKey", publicKey);
			}
			linkId = manage_client_neft_view;
		} catch (Exception ex) {
			//ex.printStackTrace();
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getNeftRtgs, 0, companyId);
		}
		return retVal;
	}
	
	/**
	 * @author dipika patel
	 * handle Ajax request to get TranscationCVSDetail
	 */
	@RequestMapping(value = "/ajax/bidder/getTranscationCVSDetail", method = RequestMethod.POST)
    @ResponseBody
    public String getTranscationCVSDetail(@RequestParam("hdTransactionId") int transactionId,HttpSession session, ModelMap map,HttpServletRequest request) throws JSONException {
    	SessionBean sessionBean = (SessionBean) session.getAttribute("sessionObject");
    	JSONObject objExtraDetail = new JSONObject();
    	if (sessionBean != null){
			try {
				TblTransactionCSVDetail tblTransactionCSVDetail =neftService.getTblTransactionCSVDetailByTransactionId(transactionId);
				if(tblTransactionCSVDetail != null){
					objExtraDetail.put("accountNumber",tblTransactionCSVDetail.getCreditAccNo());
			    	objExtraDetail.put("ifscCode",tblTransactionCSVDetail.getCreditAccISFC() );
			    	objExtraDetail.put("accountName", tblTransactionCSVDetail.getCreditAccName());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
    	}
	    return objExtraDetail.toString();
    }
	
	/**
	 * @author dipika patel
	 * handle Ajax request to check For ValidIfscCode
	 */
	@RequestMapping(value = "/ajax/bidder/checkForValidIfscCode", method = RequestMethod.POST)
    @ResponseBody
    public String checkForValidIfscCode(@RequestParam("txtIfscCode") String ifscCode,HttpSession session, ModelMap map,HttpServletRequest request) throws JSONException {
    	SessionBean sessionBean = (SessionBean) session.getAttribute("sessionObject");
    	StringBuffer tbl = new StringBuffer();
    	if (sessionBean != null){
			try {
				List<Object[]> bankDetail = neftService.getBankDetailFromIfsc(ifscCode);
				if(!bankDetail.isEmpty()){
					for (Object[] obj : bankDetail){
						tbl.append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" class=\"no-border\">");
						tbl.append("<tr><td width=\"25%\"><b>Bank Name : </b></td><td colspan=\"3\">"+obj[0].toString().trim()+"</td></tr>");
						tbl.append("<tr><td width=\"25%\"><b>Branch : </b></td><td colspan=\"3\">"+obj[3].toString().trim()+"</td></tr>");
						tbl.append("<tr><td width=\"25%\"><b>Address : </b></td><td colspan=\"3\">"+obj[4].toString().trim()+"</td></tr>");
						tbl.append("<tr><td width=\"25%\"><b>IFSC Code : </b></td><td>"+obj[1].toString().trim()+"</td><td width=\"25%\"><b>MICR Code : </b></td><td>"+obj[2].toString().trim()+"</td></tr>");
						tbl.append("<tr><td width=\"25%\"><b>City : </b></td><td>"+obj[5].toString().trim()+"</td><td width=\"25%\"><b>State : </b></td><td>"+obj[6].toString().trim()+"</td></tr>");
						tbl.append("</table>");
					}
				}
				else {
					tbl.append("<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" border=\"0\" class=\"no-border\"><tr><td>No record found for this IFSC Code. You can use this IFSC code but please verify the same from your bank, For further detail please contact your bank.</td></tr></table>");
				}			
			} catch (Exception e) {
				e.printStackTrace();
			}
    	}
	    return tbl.toString();
    }
	/**
	 * @author Lipi Shah
	 * download excel for import functionality in neft client configuration.
	 */
	@RequestMapping(value = {"/getneftrtgsexcel/{enc}"}, method = RequestMethod.GET)
    public void downloadNeftRtgsExcel(HttpServletResponse response,HttpServletRequest request) {
        try {
            StringBuilder path = new StringBuilder();
            int userId = abcUtility.getSessionUserId(request);
            int clientId = abcUtility.getSessionClientId(request);
            path.append(drive).append(upload).append("\\NEFT\\").append(clientId).append("\\");
            File folder = new File(path.toString());
            if(!folder.exists()){
                folder.mkdirs();
            }
            File file = new File(path.toString() + "NEFT_RTGS_CONF"+"_"+clientId+"_"+userId + ".xls");
//            if (!file.exists()) {
                Workbook wb = new HSSFWorkbook(); // Create New WorkBook
                Sheet sheet = wb.createSheet("NEFT_RTGS_CONF_DETAILS");// Create WorkSheet
                sheet.protectSheet("password"); //Protect WorkSheet                

                Font font = wb.createFont();  // Apply Font
                font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
                
                CellStyle editableCell = wb.createCellStyle();
                CellStyle nonEditableCell = wb.createCellStyle();
                CellStyle contentStyle = wb.createCellStyle();
                CellStyle headingStyle = wb.createCellStyle();
                int cellCnt = 0;
                Map<Integer,String> map = generateMap(clientId);
                
                final Set<Entry<Integer, String>> mapValues = map.entrySet();
                final int maplength = mapValues.size();
                final Entry<Integer,String>[] test = new Entry[maplength];
                mapValues.toArray(test);
                int totalLength = test[maplength-1].getKey();
                for(int i=0 ; i<=totalLength ;i++){
                    Row rowContent = sheet.createRow(i);     
                    sheet.setColumnWidth(cellCnt, 9000);
                    while(cellCnt!=2){
                    	Cell cellContentData = rowContent.createCell(cellCnt);
                        if(cellCnt == 0){
                        	if(map.get(i)!=null){
                        		contentStyle.setAlignment(CellStyle.ALIGN_LEFT);
                            	contentStyle.setLocked(true);
                            	contentStyle.setFont(font);
                            	cellContentData.setCellStyle(contentStyle);
                        		cellContentData.setCellValue(map.get(i));
                        	}else{
                        		if(i==0 || i==15 || i==20){
                        			headingStyle.setAlignment(CellStyle.ALIGN_LEFT);
                            		headingStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
                            		headingStyle.setLocked(true);
                            		headingStyle.setFont(font);
                                	cellContentData.setCellStyle(headingStyle);
                        		}
                        		switch(i){
	                        		case 0 :
	                        			cellContentData.setCellValue("File Naming Convention :");
	                        			break;
		                        	case 15 :
		                    			cellContentData.setCellValue("Mail Content :");
		                    			break;
		                        	case 20 :
		                    			cellContentData.setCellValue("Account Details :");
		                    			break;
                        		}
                        	}
                        }else if(cellCnt == 1){
                        	if(i==0 || i==10 || i==14 || i==15 || i==19 || i==20 || i==24 || i==28){
                        		nonEditableCell.setLocked(true); 
                        		cellContentData.setCellStyle(nonEditableCell);
                        	}else{
                        		editableCell.setLocked(false);
                        		cellContentData.setCellStyle(editableCell);
                        	}
                        }
                        cellCnt++;
                    }
                    cellCnt = 0 ;
                }
                FileOutputStream fout = new FileOutputStream(file);// Write File
                wb.write(fout);
                fout.flush();
                fout.close();
                
            InputStream fis = new FileInputStream(file);
            byte[] buf = new byte[fis.available()];
            int offset = 0;
            int numRead = 0;
            while ((offset < buf.length) && ((numRead = fis.read(buf, offset, buf.length - offset)) >= 0)) {
                offset += numRead;
            }
            ServletOutputStream outputStream = response.getOutputStream();
            response.setContentType("application/octet-stream");
            response.setHeader("Content-Disposition", "attachment;filename=\"" + "NEFT_RTGS_CONF"+"_"+clientId+"_"+userId + ".xls\"");            
            outputStream.write(buf);
            outputStream.flush();
            outputStream.close();
//            }
        } catch (Exception ex) {
            exceptionHandlerService.writeLog(ex);
        }
    }	
	/**
	 * @author Lipi Shah
	 * upload excel for import functionality in neft client configuration.
	 */
	@RequestMapping(value ={"/ajax/uploadneftrtgsdtls"}, method = RequestMethod.POST)
    public String uploadNeftRtgsDtls(HttpServletRequest request,ModelMap modelMap) {
        String data = "";
        String pageName = "/common/admin/createNeftRtgsDetails";
        try {
            int userId = abcUtility.getSessionUserId(request);
            if(userId!=0){
	            File file = null;
	            File tmpDir = null;
	            long fileSize = 0;
	            String fileName = null;
	            long fileMaxSize = 1024 * 1024;//1 MB
	            String fileExtensions = "xls";
	            DiskFileItemFactory fileItemFactory = new DiskFileItemFactory();
	            fileItemFactory.setSizeThreshold(1 * 1024 * 1024);
	            ServletFileUpload uploadHandler = new ServletFileUpload(fileItemFactory);
	            List items = uploadHandler.parseRequest(request);
	            Iterator itr = items.iterator();
	            int clientId = abcUtility.getSessionClientId(request);
	            while (itr.hasNext()) {
	                FileItem item = (FileItem) itr.next();
	                if (!item.isFormField()) {
	                    fileSize = item.getSize();
	                    if (item.getName().lastIndexOf("\\") != -1) {
	                        fileName = item.getName().substring(item.getName().lastIndexOf("\\") + 1, item.getName().length());
	                    } else {
	                        fileName = item.getName();
	                    }
	                    if (fileName != null && !fileName.equalsIgnoreCase("")) {
	                    	if(!fileName.equals("NEFT_RTGS_CONF"+"_"+clientId+"_"+userId+"."+fileExtensions)){
	                    		data = "Invalid File" + "@@ERROR@@";
	                    	}else if (fileSize == 0) {
	                            data = messageSource.getMessage("msg_tender_emptyfile", null, LocaleContextHolder.getLocale()) + "@@ERROR@@";
	                        }else if (!checkFileSize(fileSize, fileMaxSize)) {
	                            data = messageSource.getMessage("msg_tender_maxfilesize", new Object[]{(fileMaxSize / 1024)}, LocaleContextHolder.getLocale()) + "@@ERROR@@";
	                        }else if (!checkFileExn(fileName, fileExtensions)) {
	                            data = messageSource.getMessage("msg_tender_fileformatnotsupp", null, LocaleContextHolder.getLocale()) + "@@ERROR@@";
	                        } else {
	                            /* if destination directory not exist then create it*/
	                            String tmpDirPath = drive + upload + "\\NEFT\\"+clientId+"\\";
	                            tmpDir = new File(tmpDirPath);
	                            if (!tmpDir.isDirectory()) {
	                                tmpDir.mkdir();
	                            }
	                            tmpDir = new File(tmpDirPath);
	                            if (!tmpDir.isDirectory()) {
	                                tmpDir.mkdirs();
	                            }
	                            file = new File(tmpDir, fileName);
	                            item.write(file);
	                        }
	                    }
	                }
	            }
	            if (data.isEmpty() && file.exists()) {
	                FileInputStream fis = new FileInputStream(file);
	                HSSFWorkbook workbook = new HSSFWorkbook(fis);
	                //Get first sheet from the workbook
	                HSSFSheet sheet = workbook.getSheetAt(0);
	                //Iterate through each rows from first sheet
	                Iterator<Row> rowIterator = sheet.iterator();
	                int rowcount = 0;
	                String key = "";
	                String keyVal = "";
	                Map<Integer,String> map = generateMap(clientId);
	                Map<String,String> mapVal = new LinkedHashMap<String, String>();
	                while (rowIterator.hasNext()) {
	                    Row row = rowIterator.next();
	                    //For each row, iterate through each columns
	                    Iterator<Cell> cellIterator = row.cellIterator();
	                    while (cellIterator.hasNext()) {
	                        Cell cell = cellIterator.next();
	                        if(cell.getCellType() == Cell.CELL_TYPE_NUMERIC || cell.getCellType() == Cell.CELL_TYPE_STRING){
	                        	if(map.get(rowcount)!=null && !map.get(rowcount).isEmpty()){
                        			if(map.get(rowcount).toString().trim().equalsIgnoreCase(cell.getStringCellValue().trim())){
                                		key = cell.getStringCellValue().trim();
                                		cell = cellIterator.next();
                                		if(cell.getCellType() == Cell.CELL_TYPE_STRING){
                                			keyVal = cell.getStringCellValue().trim();
                                		}else if(cell.getCellType() == Cell.CELL_TYPE_NUMERIC){
                                			keyVal = new DataFormatter().formatCellValue(cell);
                                		}
                                		mapVal.put(key, keyVal);
	                        		}
	                        	}
	                        }
	                    }
	                    rowcount++;
	                }
	                modelMap.put("lstPayFor", neftService.getPaymentFor());
	                modelMap.put("map",mapVal);
	                Object[] clientBnkDetail = neftService.getClientPGBank(clientId);
	                int bankId = Integer.parseInt(clientBnkDetail[0].toString());
	                modelMap.put("bankId",bankId);
	                fis.close();
	            }
            }else{
            	data = "Invalid User" + "@@ERROR@@";
            }
            modelMap.put("dataError", data);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } finally {
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), bidFormExcelMatrix, addXlsMatrixAudit, Integer.parseInt(hdTenderId), Integer.parseInt(hdTableId));
        }
        return pageName;
    }
	private Map<Integer,String> generateMap(int clientId) throws Exception{
		Object[] clientBnkDetail = neftService.getClientPGBank(clientId);
        int bankId = Integer.parseInt(clientBnkDetail[0].toString());
		Map<Integer,String> val = new LinkedHashMap<Integer, String>();
		
		if(bankId == 6){
			val.put(1, messageSource.getMessage("field_appCode",null,LocaleContextHolder.getLocale()));
			val.put(2, messageSource.getMessage("field_validate_URL",null,LocaleContextHolder.getLocale()));
			val.put(3, messageSource.getMessage("field_notify_URL",null,LocaleContextHolder.getLocale()));
			val.put(4, messageSource.getMessage("field_userName",null,LocaleContextHolder.getLocale()));
			val.put(5, messageSource.getMessage("field_Password",null,LocaleContextHolder.getLocale()));
		}else{
			val.put(1, messageSource.getMessage("field_fundTransferFile",null,LocaleContextHolder.getLocale()));
			val.put(2, messageSource.getMessage("field_fundTransferReversalFile",null,LocaleContextHolder.getLocale()));
			val.put(3, messageSource.getMessage("field_refundRequestFile",null,LocaleContextHolder.getLocale()));
			val.put(4, messageSource.getMessage("field_refundRequestReversalFile",null,LocaleContextHolder.getLocale()));
			val.put(5, messageSource.getMessage("field_emdReleaseFile",null,LocaleContextHolder.getLocale()));
			val.put(6, messageSource.getMessage("field_emdReleaseReversalFile",null,LocaleContextHolder.getLocale()));
			val.put(7, messageSource.getMessage("field_eCollectionFileName",null,LocaleContextHolder.getLocale()));
		}
		val.put(8, messageSource.getMessage("field_clientName",null,LocaleContextHolder.getLocale()));
		val.put(9, messageSource.getMessage("field_clientCode",null,LocaleContextHolder.getLocale()));
		
		val.put(11, messageSource.getMessage("field_tpslAccNo",null,LocaleContextHolder.getLocale()));
		val.put(12, messageSource.getMessage("field_tpslAccName",null,LocaleContextHolder.getLocale()));
		val.put(13, messageSource.getMessage("field_tpslIfsc",null,LocaleContextHolder.getLocale()));
		
		val.put(16, messageSource.getMessage("field_benfAccName",null,LocaleContextHolder.getLocale()));
		val.put(17, messageSource.getMessage("field_benfBranchName",null,LocaleContextHolder.getLocale()));
		val.put(18, messageSource.getMessage("field_benfIfsc",null,LocaleContextHolder.getLocale()));
		
		if(bankId == 6){
			val.put(21, messageSource.getMessage("field_secDepositAccNo",null,LocaleContextHolder.getLocale()));
			val.put(22, messageSource.getMessage("field_secDepositAccName",null,LocaleContextHolder.getLocale()));
			val.put(23, messageSource.getMessage("field_secDepositAccIfsc",null,LocaleContextHolder.getLocale()));
			val.put(24, messageSource.getMessage("field_secDepositAcc_CustId",null,LocaleContextHolder.getLocale()));
			val.put(25, messageSource.getMessage("field_secDepositAcc_UserId",null,LocaleContextHolder.getLocale()));
			val.put(26, messageSource.getMessage("field_secDepositAcc_Password",null,LocaleContextHolder.getLocale()));
			val.put(27, messageSource.getMessage("field_secDepositAcc_BankClientId",null,LocaleContextHolder.getLocale()));
			val.put(28, messageSource.getMessage("field_secDepositAcc_BankClientSecret",null,LocaleContextHolder.getLocale()));
			
			val.put(30, messageSource.getMessage("field_escrowAccNo",null,LocaleContextHolder.getLocale()));
			val.put(31, messageSource.getMessage("field_escrowAccName",null,LocaleContextHolder.getLocale()));
			val.put(32, messageSource.getMessage("field_escrowAccIfsc",null,LocaleContextHolder.getLocale()));
			val.put(33, messageSource.getMessage("field_escrowAcc_CustId",null,LocaleContextHolder.getLocale()));
			val.put(34, messageSource.getMessage("field_escrowAcc_UserId",null,LocaleContextHolder.getLocale()));
			val.put(35, messageSource.getMessage("field_escrowAcc_Password",null,LocaleContextHolder.getLocale()));
			val.put(36, messageSource.getMessage("field_escrowAcc_BankClientId",null,LocaleContextHolder.getLocale()));
			val.put(37, messageSource.getMessage("field_escrowAcc_BankClientSecret",null,LocaleContextHolder.getLocale()));
			
			val.put(39, messageSource.getMessage("field_currentAccNo",null,LocaleContextHolder.getLocale()));
			val.put(40, messageSource.getMessage("field_currentAccName",null,LocaleContextHolder.getLocale()));
			val.put(41, messageSource.getMessage("field_currentAccIfsc",null,LocaleContextHolder.getLocale()));		
			val.put(42, messageSource.getMessage("field_currentAcc_CustId",null,LocaleContextHolder.getLocale()));
			val.put(43, messageSource.getMessage("field_currentAcc_UserId",null,LocaleContextHolder.getLocale()));
			val.put(44, messageSource.getMessage("field_currentAcc_Password",null,LocaleContextHolder.getLocale()));
			val.put(45, messageSource.getMessage("field_currentAcc_BankClientId",null,LocaleContextHolder.getLocale()));
			val.put(46, messageSource.getMessage("field_currentAcc_BankClientSecret",null,LocaleContextHolder.getLocale()));
			
			val.put(48, messageSource.getMessage("field_forthAccNo",null,LocaleContextHolder.getLocale()));
			val.put(49, messageSource.getMessage("field_forthAccName",null,LocaleContextHolder.getLocale()));
			val.put(50, messageSource.getMessage("field_forthAccIfsc",null,LocaleContextHolder.getLocale()));
			
		}else{
			val.put(21, messageSource.getMessage("field_secDepositAccNo",null,LocaleContextHolder.getLocale()));
			val.put(22, messageSource.getMessage("field_secDepositAccName",null,LocaleContextHolder.getLocale()));
			val.put(23, messageSource.getMessage("field_secDepositAccIfsc",null,LocaleContextHolder.getLocale()));
			
			val.put(25, messageSource.getMessage("field_escrowAccNo",null,LocaleContextHolder.getLocale()));
			val.put(26, messageSource.getMessage("field_escrowAccName",null,LocaleContextHolder.getLocale()));
			val.put(27, messageSource.getMessage("field_escrowAccIfsc",null,LocaleContextHolder.getLocale()));
			
			val.put(29, messageSource.getMessage("field_currentAccNo",null,LocaleContextHolder.getLocale()));
			val.put(30, messageSource.getMessage("field_currentAccName",null,LocaleContextHolder.getLocale()));
			val.put(31, messageSource.getMessage("field_currentAccIfsc",null,LocaleContextHolder.getLocale()));		
			
			val.put(33, messageSource.getMessage("field_forthAccNo",null,LocaleContextHolder.getLocale()));
			val.put(34, messageSource.getMessage("field_forthAccName",null,LocaleContextHolder.getLocale()));
			val.put(35, messageSource.getMessage("field_forthAccIfsc",null,LocaleContextHolder.getLocale()));
			
			val.put(37, messageSource.getMessage("field_bidderCodeRequest_fileName",null,LocaleContextHolder.getLocale()));
			val.put(38, messageSource.getMessage("field_bidderCodeReverse_fileName",null,LocaleContextHolder.getLocale()));
		}
		if(bankId == 1){
			val.put(39, messageSource.getMessage("field_cancellationFile",null,LocaleContextHolder.getLocale()));
			val.put(40, messageSource.getMessage("field_uploadRejectFile",null,LocaleContextHolder.getLocale()));
		}
		return val;
	}
	/**
	 * author Lipi
     * to check file size
     * @param fileName
     * @param allowExtensions
     * @return
     */
	private boolean checkFileSize(long fielSize, long maxFileSize) {
        boolean chextn = false;
        if (maxFileSize > fielSize) {
            chextn = true;
        } else {
            chextn = false;
        }
        return chextn;
    }
	/**
	 * author Lipi
     * to check file extention
     * @param fileName
     * @param allowExtensions
     * @return
     */
    private boolean checkFileExn(String fileName, String allowExtensions) {
        boolean chextn = false;
        int j = fileName.lastIndexOf('.');
        String lst = fileName.substring(j + 1);
        String str = allowExtensions;
        String[] str1 = str.split(",");
        for (int i = 0; i < str1.length; i++) {
            if (str1[i].trim().equalsIgnoreCase(lst)) {
                chextn = true;
            }
        }
        return chextn;
    }
    /**
     * @author dipika
     * get neft configuration for selected deptId
     * @param deptId
     * @return
     * @throws Exception
     */
	@RequestMapping(value = "/ajaxcall/getDeptNeftConf", method = RequestMethod.POST)
	@ResponseBody
    public String getDeptNeftConf(@RequestParam("hdDeptId") int deptId,ModelMap modelMap, HttpServletRequest request) {
        String resultString = null;
        try {
        	modelMap.put("deptId", deptId);
        	List<Object[]> neftDetailList = neftService.getNeftRtgsDetail(0,deptId);
			if(neftDetailList != null && !neftDetailList.isEmpty()){
				modelMap.put("lstPayFor", neftService.getPaymentFor());
				TblDeptNeftRtgsConf tblDeptNeftRtgsConf=(TblDeptNeftRtgsConf) neftDetailList.get(0)[1];
				resultString=tblDeptNeftRtgsConf.getEscrowAccNo()+"@@"+tblDeptNeftRtgsConf.getEscrowAccName()+"@@"+tblDeptNeftRtgsConf.getEscrowAccIfsc()
						+"@@"+tblDeptNeftRtgsConf.getCurrentAccNo()+"@@"+tblDeptNeftRtgsConf.getCurrentAccName()+"@@"+tblDeptNeftRtgsConf.getCurrentAccIfsc()
						+"@@"+tblDeptNeftRtgsConf.getSecDepositAccNo()+"@@"+tblDeptNeftRtgsConf.getSecDepositAccName()+"@@"+tblDeptNeftRtgsConf.getSecDepositAccIfsc()
						+"@@"+tblDeptNeftRtgsConf.getCommissionAccNo()+"@@"+tblDeptNeftRtgsConf.getCommissionAccName()+"@@"+tblDeptNeftRtgsConf.getCommissionAccIfsc();
			}
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } 
        return resultString;
    }
	
	/**
	 * @author dipika
	 * handle POST request to create and edit NEFT RTGS
	 */ 
	@RequestMapping(value = "/admin/addNeftRtgsDeptWise", method = RequestMethod.POST)
	public String addUpdateNeftRtgsDetailDeptWise(RedirectAttributes redirectAttributes, HttpServletRequest request) {
		boolean success = false;
		String retVal = "redirect:/sessionexpired";
		int clientId =0;
		int neftRtgsId = 0;
		int deptNeftRtgsId = 0;
		
		try {
			//int clientId = abcUtility.getSessionClientId(request);
			int userDetailId = abcUtility.getSessionUserDetailId(request);
			neftRtgsId = StringUtils.hasLength(request.getParameter("hdNeftRtgsId")) ? Integer.parseInt(request.getParameter("hdNeftRtgsId")) : 0;
			deptNeftRtgsId = StringUtils.hasLength(request.getParameter("hdDeptNeftRtgsId")) ? Integer.parseInt(request.getParameter("hdDeptNeftRtgsId")) : 0;
			clientId = StringUtils.hasLength(request.getParameter("hdClientId")) ? Integer.parseInt(request.getParameter("hdClientId")) : 0;
			int deptId = StringUtils.hasLength(request.getParameter("hdDeptId")) ? Integer.parseInt(request.getParameter("hdDeptId")) : 0;
			int bankId =  StringUtils.hasLength(request.getParameter("hdBankId")) ? Integer.parseInt(request.getParameter("hdBankId")) : 0;
			String txtSecDepositAccNo = StringUtils.hasLength(request.getParameter("txtSecDepositAccNo")) ? request.getParameter("txtSecDepositAccNo") : "";
			String txtSecDepositAccName = StringUtils.hasLength(request.getParameter("txtSecDepositAccName")) ? request.getParameter("txtSecDepositAccName") : "";
			String txtSecDepositAccIfsc = StringUtils.hasLength(request.getParameter("txtSecDepositAccIfsc")) ? request.getParameter("txtSecDepositAccIfsc") : "";
			String txtEscrowAccName = StringUtils.hasLength(request.getParameter("txtEscrowAccName")) ? request.getParameter("txtEscrowAccName") : "";
			String txtEscrowAccNo = StringUtils.hasLength(request.getParameter("txtEscrowAccNo")) ? request.getParameter("txtEscrowAccNo") : "";
			String txtEscrowAccIfsc = StringUtils.hasLength(request.getParameter("txtEscrowAccIfsc")) ? request.getParameter("txtEscrowAccIfsc") : "";
			String txtCurrentAccIfsc = StringUtils.hasLength(request.getParameter("txtCurrentAccIfsc")) ? request.getParameter("txtCurrentAccIfsc") : "";
			String txtCurrentAccName = StringUtils.hasLength(request.getParameter("txtCurrentAccName")) ? request.getParameter("txtCurrentAccName") : "";
			String txtCurrentAccNo = StringUtils.hasLength(request.getParameter("txtCurrentAccNo")) ? request.getParameter("txtCurrentAccNo") : "";
			String txtForthAccIfsc = StringUtils.hasLength(request.getParameter("txtForthAccIfsc")) ? request.getParameter("txtForthAccIfsc") : "";
			String txtForthAccName = StringUtils.hasLength(request.getParameter("txtForthAccName")) ? request.getParameter("txtForthAccName") : "";
			String txtForthAccNo = StringUtils.hasLength(request.getParameter("txtForthAccNo")) ? request.getParameter("txtForthAccNo") : "";
			
			String txtCommissionAccIfsc = StringUtils.hasLength(request.getParameter("txtCommissionAccIfsc")) ? request.getParameter("txtCommissionAccIfsc") : "";
			String txtCommissionAccName = StringUtils.hasLength(request.getParameter("txtCommissionAccName")) ? request.getParameter("txtCommissionAccName") : "";
			String txtCommissionAccNo = StringUtils.hasLength(request.getParameter("txtCommissionAccNo")) ? request.getParameter("txtCommissionAccNo") : "";
			
			TblDeptNeftRtgsConf tblDeptNeftRtgsConf = new TblDeptNeftRtgsConf();
			tblDeptNeftRtgsConf.setSecDepositAccNo(txtSecDepositAccNo);
			tblDeptNeftRtgsConf.setSecDepositAccName(txtSecDepositAccName);
			tblDeptNeftRtgsConf.setSecDepositAccIfsc(txtSecDepositAccIfsc);
			tblDeptNeftRtgsConf.setEscrowAccIfsc(txtEscrowAccIfsc);
			tblDeptNeftRtgsConf.setEscrowAccName(txtEscrowAccName);
			tblDeptNeftRtgsConf.setEscrowAccNo(txtEscrowAccNo);
			tblDeptNeftRtgsConf.setCurrentAccIfsc(txtCurrentAccIfsc);
			tblDeptNeftRtgsConf.setCurrentAccName(txtCurrentAccName);
			tblDeptNeftRtgsConf.setCurrentAccNo(txtCurrentAccNo);
			tblDeptNeftRtgsConf.setForthAccIfsc(txtForthAccIfsc);
			tblDeptNeftRtgsConf.setForthAccName(txtForthAccName);
			tblDeptNeftRtgsConf.setForthAccNo(txtForthAccNo);
			tblDeptNeftRtgsConf.setCstatus(0);
			tblDeptNeftRtgsConf.setCommissionAccIfsc(txtCommissionAccIfsc);
			tblDeptNeftRtgsConf.setCommissionAccName(txtCommissionAccName);
			tblDeptNeftRtgsConf.setCommissionAccNo(txtCommissionAccNo);
			tblDeptNeftRtgsConf.setTblDepartment(new TblDepartment(deptId));
			tblDeptNeftRtgsConf.setTblNeftRtgsConf(new TblNeftRtgsConf(neftRtgsId));
			
			if(deptNeftRtgsId!=0){
				tblDeptNeftRtgsConf.setDeptNeftRtgsId(deptNeftRtgsId);
			}
			List<TblDeptNeftRtgsConfDetails> deptNeftRtgsConfDetails = null;
			if(bankId == 6){
				deptNeftRtgsConfDetails = new ArrayList<TblDeptNeftRtgsConfDetails>();
				TblDeptNeftRtgsConfDetails deptNeftRtgsConfDetail = null;
				
				deptNeftRtgsConfDetail= neftService.getDeptNeftRtgsConfDetails(tblDeptNeftRtgsConf.getDeptNeftRtgsId(), clientId, 1);
				if(deptNeftRtgsConfDetail == null){
					deptNeftRtgsConfDetail = new TblDeptNeftRtgsConfDetails();
				}
				deptNeftRtgsConfDetail.setTblDeptNeftRtgsConf(tblDeptNeftRtgsConf);
				deptNeftRtgsConfDetail.setTblClient(new TblClient(clientId));
				deptNeftRtgsConfDetail.setAccountType(1);
				deptNeftRtgsConfDetail.setCustId(StringUtils.hasLength(request.getParameter("txtSecDepositAccCustId")) ? request.getParameter("txtSecDepositAccCustId") : "");
				deptNeftRtgsConfDetail.setUserId(StringUtils.hasLength(request.getParameter("txtSecDepositAccUserID")) ? request.getParameter("txtSecDepositAccUserID") : "");
				deptNeftRtgsConfDetail.setPassword(StringUtils.hasLength(request.getParameter("txtSecDepositAccPassword")) ? encryptDecryptUtils.encrypt(request.getParameter("txtSecDepositAccPassword")) : "");
				deptNeftRtgsConfDetail.setBankClientId(StringUtils.hasLength(request.getParameter("txtSecDepositAccBankClientId")) ? request.getParameter("txtSecDepositAccBankClientId") : "");
				deptNeftRtgsConfDetail.setBankClientSecret(StringUtils.hasLength(request.getParameter("txtSecDepositAccBankClientSecret")) ? request.getParameter("txtSecDepositAccBankClientSecret") : "");
				deptNeftRtgsConfDetails.add(deptNeftRtgsConfDetail);
				
				//Escrow Account
				deptNeftRtgsConfDetail= neftService.getDeptNeftRtgsConfDetails(tblDeptNeftRtgsConf.getDeptNeftRtgsId(), clientId,2);
				if(deptNeftRtgsConfDetail == null){
					deptNeftRtgsConfDetail = new TblDeptNeftRtgsConfDetails();
				}
				deptNeftRtgsConfDetail.setTblDeptNeftRtgsConf(tblDeptNeftRtgsConf);
				deptNeftRtgsConfDetail.setTblClient(new TblClient(clientId));
				deptNeftRtgsConfDetail.setAccountType(2);
				deptNeftRtgsConfDetail.setCustId(StringUtils.hasLength(request.getParameter("txtEscrowAccCustId")) ? request.getParameter("txtEscrowAccCustId") : "");
				deptNeftRtgsConfDetail.setUserId(StringUtils.hasLength(request.getParameter("txtEscrowAccUserID")) ? request.getParameter("txtEscrowAccUserID") : "");
				deptNeftRtgsConfDetail.setPassword(StringUtils.hasLength(request.getParameter("txtEscrowAccPassword")) ? encryptDecryptUtils.encrypt(request.getParameter("txtEscrowAccPassword")) : "");
				deptNeftRtgsConfDetail.setBankClientId(StringUtils.hasLength(request.getParameter("txtEscrowAccBankClientId")) ? request.getParameter("txtEscrowAccBankClientId") : "");
				deptNeftRtgsConfDetail.setBankClientSecret(StringUtils.hasLength(request.getParameter("txtEscrowAccBankClientSecret")) ? request.getParameter("txtEscrowAccBankClientSecret") : "");
				deptNeftRtgsConfDetails.add(deptNeftRtgsConfDetail);
				
				//Current Account
				deptNeftRtgsConfDetail= neftService.getDeptNeftRtgsConfDetails(tblDeptNeftRtgsConf.getDeptNeftRtgsId(), clientId ,3);
				if(deptNeftRtgsConfDetail == null){
					deptNeftRtgsConfDetail = new TblDeptNeftRtgsConfDetails();
				}
				deptNeftRtgsConfDetail.setTblDeptNeftRtgsConf(tblDeptNeftRtgsConf);
				deptNeftRtgsConfDetail.setTblClient(new TblClient(clientId));
				deptNeftRtgsConfDetail.setAccountType(3);
				deptNeftRtgsConfDetail.setCustId(StringUtils.hasLength(request.getParameter("txtCurrentAccCustId")) ? request.getParameter("txtCurrentAccCustId") : "");
				deptNeftRtgsConfDetail.setUserId(StringUtils.hasLength(request.getParameter("txtCurrentAccUserID")) ? request.getParameter("txtCurrentAccUserID") : "");
				deptNeftRtgsConfDetail.setPassword(StringUtils.hasLength(request.getParameter("txtCurrentAccPassword")) ? encryptDecryptUtils.encrypt(request.getParameter("txtCurrentAccPassword")) : "");
				deptNeftRtgsConfDetail.setBankClientId(StringUtils.hasLength(request.getParameter("txtCurrentAccBankClientId")) ? request.getParameter("txtCurrentAccBankClientId") : "");
				deptNeftRtgsConfDetail.setBankClientSecret(StringUtils.hasLength(request.getParameter("txtCurrentAccBankClientSecret")) ? request.getParameter("txtCurrentAccBankClientSecret") : "");
				deptNeftRtgsConfDetails.add(deptNeftRtgsConfDetail);
			}
			
			success = neftService.addUpdateDeptNeftRtgsPaymentDetail(tblDeptNeftRtgsConf, deptNeftRtgsConfDetails);
			retVal = "common/admin/managepaymentconf/"+clientId+ "/"+TAB_ONLINE_PAYMENT;
		} catch (Exception ex) {
			//ex.printStackTrace();
			exceptionHandlerService.writeLog(ex);
		} finally {
			auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manage_client_neft_create, getNeftRtgs, clientId, neftRtgsId);
		}
		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? neftRtgsId == 0 ? "redirect_success_create_neft" : "redirect_success_edit_neft" : CommonKeywords.ERROR_MSG_KEY.toString());
		return "redirect:/" +retVal + encryptDecryptUtils.generateRedirect(retVal, request);
	}
	
	/**
	 * @author dipika
     * to edit accounttype configuration 
     * @param redirectAttributes
     * @param request
     */
    @RequestMapping(value = "/admin/editAccountTypeMapping", method = RequestMethod.POST)
    public String editAccountTypeMapping(RedirectAttributes redirectAttributes,HttpServletRequest request){
        boolean success = false;
        String retVal = null;
        int clientId=0;
        
    	try {
    			clientId = StringUtils.hasLength(request.getParameter("hdClientId")) ? Integer.parseInt(request.getParameter("hdClientId")) : 0;
    			int deptId = StringUtils.hasLength(request.getParameter("hdDeptId")) ? Integer.parseInt(request.getParameter("hdDeptId")) : 0;
    			int docFeeAccTypeFrom = StringUtils.hasLength(request.getParameter("selDocFeeAccTypeFrom")) ? Integer.parseInt(request.getParameter("selDocFeeAccTypeFrom")) :1;
    			int docFeeAccTypeTo = StringUtils.hasLength(request.getParameter("selDocFeeAccTypeTo")) ? Integer.parseInt(request.getParameter("selDocFeeAccTypeTo")) : 3;
    			int emdFeeAccTypeFrom = StringUtils.hasLength(request.getParameter("selEmdFeeAccTypeFrom")) ? Integer.parseInt(request.getParameter("selEmdFeeAccTypeFrom")) : 1;
    			int emdFeeAccTypeTo = StringUtils.hasLength(request.getParameter("selEmdFeeAccTypeTo")) ?Integer.parseInt( request.getParameter("selEmdFeeAccTypeTo")) : 2;
    			int refundAccTypeFrom = StringUtils.hasLength(request.getParameter("selRefundAccTypeFrom")) ? Integer.parseInt(request.getParameter("selRefundAccTypeFrom")) : 1;
    			int refundAccTypeTo = StringUtils.hasLength(request.getParameter("selRefundAccTypeTo")) ? Integer.parseInt(request.getParameter("selRefundAccTypeTo")) : 4;
    			int forfeitAccTypeFrom = StringUtils.hasLength(request.getParameter("selForfeitAccTypeFrom")) ? Integer.parseInt(request.getParameter("selForfeitAccTypeFrom")) : 2;
    			int forfeitAccTypeTo = StringUtils.hasLength(request.getParameter("selForfeitAccTypeTo")) ? Integer.parseInt(request.getParameter("selForfeitAccTypeTo")) : 3;
    			int releaseAccTypeFrom = StringUtils.hasLength(request.getParameter("selReleaseAccTypeFrom")) ? Integer.parseInt(request.getParameter("selReleaseAccTypeFrom")) : 2;
    			int releaseAccTypeTo = StringUtils.hasLength(request.getParameter("selReleaseAccTypeTo")) ? Integer.parseInt(request.getParameter("selReleaseAccTypeTo")) : 1;
    			int pgAccTypeFrom = StringUtils.hasLength(request.getParameter("selPGAccTypeFrom")) ? Integer.parseInt(request.getParameter("selPGAccTypeFrom")) : 2;
    			int pgAccTypeTo = StringUtils.hasLength(request.getParameter("selPGAccTypeTo")) ? Integer.parseInt(request.getParameter("selPGAccTypeTo")) : 3;
    			int eventRegFeeAccTypeFrom = StringUtils.hasLength(request.getParameter("selEventRegFeeAccTypeFrom")) ? Integer.parseInt(request.getParameter("selEventRegFeeAccTypeFrom")) :1;
    			int eventRegFeeAccTypeTo = StringUtils.hasLength(request.getParameter("selEventRegFeeAccTypeTo")) ? Integer.parseInt(request.getParameter("selEventRegFeeAccTypeTo")) : 5;
    			int restAucMoneyAccTypeFrom = StringUtils.hasLength(request.getParameter("selRestAucMoneyAccTypeFrom")) ? Integer.parseInt(request.getParameter("selRestAucMoneyAccTypeFrom")) :1;
    			int restAucMoneyAccTypeTo = StringUtils.hasLength(request.getParameter("selRestAucMoneyAccTypeTo")) ? Integer.parseInt(request.getParameter("selRestAucMoneyAccTypeTo")) : 3;
    			int restSecfeesAccTypeFrom = StringUtils.hasLength(request.getParameter("selRestSecfeesAccTypeFrom")) ? Integer.parseInt(request.getParameter("selRestSecfeesAccTypeFrom")) :1;
    			int restSecfeesAccTypeTo = StringUtils.hasLength(request.getParameter("selRestSecfeesAccTypeTo")) ? Integer.parseInt(request.getParameter("selRestSecfeesAccTypeTo")) : 3;
    			int releaseSecfeesAccTypeFrom = StringUtils.hasLength(request.getParameter("selReleaseSecfeesAccTypeFrom")) ? Integer.parseInt(request.getParameter("selReleaseSecfeesAccTypeFrom")) :3;
    			int releaseSecfeesAccTypeTo = StringUtils.hasLength(request.getParameter("selReleaseSecfeesAccTypeTo")) ? Integer.parseInt(request.getParameter("selReleaseSecfeesAccTypeTo")) : 1;
    			int commissionAccTypeFrom = StringUtils.hasLength(request.getParameter("selCommissionAccTypeFrom")) ? Integer.parseInt(request.getParameter("selCommissionAccTypeFrom")) :3;
    			int commissionAccTypeTo = StringUtils.hasLength(request.getParameter("selCommissionAccTypeTo")) ? Integer.parseInt(request.getParameter("selCommissionAccTypeTo")) : 6;
    			success=setTransactionTypeAccountMapping(clientId, deptId, docFeeAccTypeFrom, docFeeAccTypeTo, emdFeeAccTypeFrom, emdFeeAccTypeTo, refundAccTypeFrom, refundAccTypeTo, forfeitAccTypeFrom, forfeitAccTypeTo, releaseAccTypeFrom, releaseAccTypeTo, pgAccTypeFrom, pgAccTypeTo,eventRegFeeAccTypeFrom,eventRegFeeAccTypeTo,restAucMoneyAccTypeFrom,restAucMoneyAccTypeTo,restSecfeesAccTypeFrom,restSecfeesAccTypeTo,releaseSecfeesAccTypeFrom,releaseSecfeesAccTypeTo,commissionAccTypeFrom,commissionAccTypeTo);
    			
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), manageTranTypeAccMappLinkId, getSaveAccmapp, 0,clientId);
        }
    	 retVal = "common/admin/managepaymentconf/"+clientId+ "/"+TAB_ONLINE_PAYMENT;
        redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_defaultconfiguration" : CommonKeywords.ERROR_MSG_KEY.toString());
        
        return "redirect:/"+retVal+encryptDecryptUtils.generateRedirect(retVal, request);
    }
    /**
	 * @author dipika
     * to edit accounttype configuration 
     */
    public boolean setTransactionTypeAccountMapping(int clientId,int deptId,int docFeeAccTypeFrom,int docFeeAccTypeTo,int emdFeeAccTypeFrom,int emdFeeAccTypeTo,int refundAccTypeFrom,int refundAccTypeTo
    		,int forfeitAccTypeFrom,int forfeitAccTypeTo,int releaseAccTypeFrom,int releaseAccTypeTo,int pgAccTypeFrom,int pgAccTypeTo,int eventRegFeeAccTypeFrom,int eventRegFeeAccTypeTo,int restAucMoneyAccTypeFrom,int restAucMoneyAccTypeTo,int restSecfeesAccTypeFrom,int restSecfeesAccTypeTo,int releaseSecfeesAccTypeFrom, int releaseSecfeesAccTypeTo, int commissionAccTypeFrom, int commissionAccTypeTo) throws Exception{
    	boolean retMsg=false;
		
			List<TblTransactionTypeAccountMapping> lstTransactionTypeAccountMapp=new ArrayList<TblTransactionTypeAccountMapping>();
			TblTransactionTypeAccountMapping tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(docFeeAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(docFeeAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(1));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);
			
			tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(emdFeeAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(emdFeeAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(2));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);
			
			tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(refundAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(refundAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(3));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);
			
			tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(forfeitAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(forfeitAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(4));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);

			tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(releaseAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(releaseAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(5));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);
			
			tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(pgAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(pgAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(6));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);
			
			tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(eventRegFeeAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(eventRegFeeAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(8));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);			
			
			tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(restAucMoneyAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(restAucMoneyAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(9));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);
			
			tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(restSecfeesAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(restSecfeesAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(11));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);
			
			tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(releaseSecfeesAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(releaseSecfeesAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(12));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);
			
			tblTransactionTypeAccountMapping=new TblTransactionTypeAccountMapping();    			
			tblTransactionTypeAccountMapping.setTblClient(new TblClient(clientId));
			tblTransactionTypeAccountMapping.setTblDepartment(new TblDepartment(deptId));
			tblTransactionTypeAccountMapping.setDebitAccountType(commissionAccTypeFrom);
			tblTransactionTypeAccountMapping.setCreditAccountType(commissionAccTypeTo);
			tblTransactionTypeAccountMapping.setIsActive(1);
			tblTransactionTypeAccountMapping.setTblTransactionType(new TblTransactionType(13));
			lstTransactionTypeAccountMapp.add(tblTransactionTypeAccountMapping);
			
			retMsg = neftService.addUpdateTransactionTypeAccountMapping(lstTransactionTypeAccountMapp,clientId);
		return retMsg;
    }
    
   @RequestMapping(value="/admin/beneConfiguration/{clientId}/{flag}/{enc}", method=RequestMethod.GET)
   public String beneConfigurations(@PathVariable("clientId") int clientId,@PathVariable("flag") int flag,ModelMap modelMap,HttpServletRequest request,RedirectAttributes redirectAttributes) {
		String retVal="";
		List<Object[]> list=null;
		try {
			list=neftService.getClientNeftBeneFields(clientId);
			
			if(flag == 1){
				modelMap.addAttribute("clientId", clientId);
				modelMap.addAttribute("domainName", list.get(0)[0].toString());
				modelMap.addAttribute("cNeftStatus",Integer.parseInt(list.get(0)[1].toString()));
				modelMap.addAttribute("cBeneStatus",Integer.parseInt(list.get(0)[2].toString()));
				modelMap.addAttribute("txtBidderCodeRequestFile", list.get(0)[3] != null ? list.get(0)[3].toString() : "");
				modelMap.addAttribute("txtBidderCodeReverseFile", list.get(0)[4] != null ? list.get(0)[4].toString() : "");
				
				retVal="common/admin/BeneConfigurations";
			}else{
				boolean success = false;
				success = neftService.disableBidderCodeAutoDowload(clientId, flag);
				retVal = "common/admin/managepaymentconf/"+clientId+ "/"+TAB_NEFTRTGS;
				redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success  ? "redirect_success_Auto_bidder_disabled" : CommonKeywords.ERROR_MSG_KEY.toString());
				return "redirect:/" +retVal + encryptDecryptUtils.generateRedirect(retVal, request);
			}
			
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		return retVal;
   }
   
   @RequestMapping(value="/admin/addBeneConfigurations", method=RequestMethod.POST)
   public String addBeneConfigurations(RedirectAttributes redirectAttributes, HttpServletRequest request) {
		boolean success = false;
		String retVal = "redirect:/sessionexpired";
		try {
			int clientId = StringUtils.hasLength(request.getParameter("hdClientId")) ? Integer.parseInt(request.getParameter("hdClientId")) : 0;
			String txtBidderCodeRequestFile = StringUtils.hasLength(request.getParameter("txtBidderCodeRequestFile")) ? request.getParameter("txtBidderCodeRequestFile")+"_%s.csv" : "";
			String txtBidderCodeReverseFile = StringUtils.hasLength(request.getParameter("txtBidderCodeReverseFile")) ? request.getParameter("txtBidderCodeReverseFile")+"_" : "";
			
			success = neftService.addUpdateNeftRtgsBeneConfigDetails(clientId, txtBidderCodeRequestFile, txtBidderCodeReverseFile);
			
			retVal = "common/admin/managepaymentconf/"+clientId+ "/"+TAB_NEFTRTGS;
			
		} catch (Exception e) {
			exceptionHandlerService.writeLog(e);
		}
		redirectAttributes.addFlashAttribute(success ? CommonKeywords.SUCCESS_MSG.toString() : CommonKeywords.ERROR_MSG.toString(), success ? "redirect_success_Auto_bidder_enable" : CommonKeywords.ERROR_MSG_KEY.toString());
		return "redirect:/" +retVal + encryptDecryptUtils.generateRedirect(retVal, request);
   }
    
}
