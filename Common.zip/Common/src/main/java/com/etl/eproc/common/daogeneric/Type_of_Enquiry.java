package com.etl.eproc.common.daogeneric;

public enum Type_of_Enquiry {
	


	FOBSell((1),"FOB Sell"),
	DESBuy((2),"DES Buy"),
	FOBSellDESBuy((3),"FOB Sell DES Buy"),
	DESSellDESBuy(4,"DES Sell DES Buy"),
	ShipCharterin(5,"Ship Chartering"),
	DestinationSwa(6,"Destination Swap"),
	RLNGBuy(7,"RLNG Buy"),
	RLNGSell(8,"RLNG Sell"),
	TimeSwap(9,"Time Swap"),
	FOBBuy(10,"FOB Buy"),
	DESSell(11,"DES Sell"),
	DESSellFOBBuy(12,"DES Sell FOB Buy"),
	FOBSellFOBBuy(13,"FOB Sell FOB Buy"),
	LongTermSell(14,"Long Term Sell"),
	LongTermBuy(15,"Long Term Buy"),
	MidTermBuy(16,"Mid Term Buy"),
	MidTermSell(17,"Mid Term Sell"),
	ShortTermSell(18,"Short Term Sell"),
	ShortTermBuy(19,"Short Term Buy");

	private  String TypeOfEnquiry = " ";
	private int TypeOfEnquiryId = 0;
	 Type_of_Enquiry( int TypeOfEnquiryId,String TypeOfEnquiry) {
		this.TypeOfEnquiry = TypeOfEnquiry;
		this.TypeOfEnquiryId = TypeOfEnquiryId;
		
	}
	@Override
	public String toString(){
		return TypeOfEnquiry;
	}
	
	public Object getcode() {
		return TypeOfEnquiryId;
	}
	public String getTypeOfEnquiry() {
		return TypeOfEnquiry;
	}
	public void setTypeOfEnquiry(String typeOfEnquiry) {
		TypeOfEnquiry = typeOfEnquiry;
	}
	public int getTypeOfEnquiryId() {
		return TypeOfEnquiryId;
	}
	public void setTypeOfEnquiryId(int typeOfEnquiryId) {
		TypeOfEnquiryId = typeOfEnquiryId;
	}
	
	  public static String getTypeOfEnquiryId(int id) {
		  String x="";
	 for(Type_of_Enquiry m: Type_of_Enquiry.values()) {
		 if(m.TypeOfEnquiryId==id)
	      x=m.getTypeOfEnquiry();
	 
	  } return x; 
	  // return this.TypeOfEnquiry; }
	  
	 
	  }


}
