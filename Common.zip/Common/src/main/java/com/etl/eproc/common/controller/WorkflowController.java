/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import com.etl.eproc.common.model.TblDocUploadConf;
import com.etl.eproc.common.model.TblEventType;
import com.etl.eproc.common.model.TblLink;
import com.etl.eproc.common.model.TblOnlineContract;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.model.TblWorkflow;
import com.etl.eproc.common.model.TblWorkflowAction;
import com.etl.eproc.common.model.TblWorkflowConfiguration;
import com.etl.eproc.common.model.TblWorkflowConfigurationDetail;
import com.etl.eproc.common.model.TblWorkflowDetail;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.FileUploadService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.services.WorkflowService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.ModelToSelectItem;
import java.net.URL;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;
import com.etl.eproc.common.utility.SessionBean;

/**
 *
 * @author dixit
 */
@Controller
@RequestMapping("/workflow/buyer")
public class WorkflowController {
    
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private ModelToSelectItem modelToSelectItem;
    @Autowired
    private WorkflowService workflowService;
    @Autowired
    private AbcUtility abcUtility; 
    @Autowired
    private FileUploadService fileUploadService; 
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private CommonService commonService;
    @Autowired
    private ClientService clientService;
    @Autowired
    private MailContentUtillity mailContentUtillity;
    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    DynamicFieldService dynamicFieldService;
    @Autowired
    LoginService loginService;
    @Value("#{tenderlinkProperties['notice_and_document_process_in_workflow']?:196}")
    private int noticeAndDocumentsWFLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_view_approval_hisotry']?:197}")
    private int noticeAndDocumentsViewWFLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_cancel_process_in_workflow']?:251}")
    private int noticeAndDocumentsCancelWFLinkId;
    @Value("#{tenderlinkProperties['corrigendum_process_in_workflow']?:179}")
    private int corriProcessWFLinkId;
    @Value("#{indentLinkProperties['indent_process_in_workflow']?:471}")
    private int indentProcessWFLinkId;
    @Value("#{indentLinkProperties['cancel_indent_process_in_workflow']?:471}")
    private int cancelIndentProcessWFLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_process_in_workflow']?:241}")
    private int preBidMeetingWfLinkId;
    @Value("#{tenderlinkProperties['pre_bid_meeting_upload']?:216}")
    private int preBidMeetingUploadDocLinkId;
    @Value("#{tenderlinkProperties['pre_bid_committee_process_in_workflow']?:238}")
    private int preBidcommitteeWfLinkId;
    @Value("#{tenderlinkProperties['bid_opening_process_in_workflow']?:244}")
    private int openingProcessWorkflowLinkId;
    @Value("#{tenderlinkProperties['bid_evaluation_process_in_workflow']?:246}")
    private int evaluationProcessWorkflowLinkId;
    @Value("#{linkProperties['workflow_my_pending_task']?:198}")
    private int workflowmypendingtasksLinkId;
    @Value("#{linkProperties['workflow_my_processed_task']?:732}")
    private int workflowProcessedTasksLinkId;
    @Value("#{linkProperties['workflow_pull_up']?:733}")
    private int workflowPullUpLinkId;
    @Value("#{tenderlinkProperties['notice_and_document_upload']?:175}")
    private int noticeanddocumentuploadLinkId;
    @Value("#{projectProperties['officer.docstatus.approve']?:1}")
    private int officerDocStatusApprove;
    @Value("#{projectProperties['officer.docstatus.pending']?:0}")
    private int officerDocStatusPending;
    @Value("#{linkProperties['workflow_process_report']?:35}")
    private int workflowPendingReportId;
    @Value("#{linkProperties['workflow_processed_report']?:77}")
    private int workflowProcessedReportId;
    @Value("#{linkProperties['workflow_pullup_report']?:78}")
    private int workflowPullUpReportId;
    @Value("#{linkProperties['apo_process_in_workflow']?:882}")
    private int APOProcessWFLinkId;
    @Value("#{linkProperties['po_process_in_workflow']?:886}")
    private int POProcessWFLinkId;
    @Value("#{linkProperties['apo_offline_process_in_workflow']?:883}")
    private int APOOfflineProcessWFLinkId;
    @Value("#{linkProperties['po_offline_process_in_workflow']?:887}")
    private int POOfflineProcessWFLinkId;
    @Value("#{linkProperties['apo_amendment_process_in_workflow']?:884}")
    private int APOAmendmentProcessWFLinkId;
    @Value("#{linkProperties['po_amendment_process_in_workflow']?:888}")
    private int POAmendmentProcessWFLinkId;
    @Value("#{linkProperties['apo_offline_amendment_process_in_workflow']?:885}")
    private int APOOfflineAmendmentProcessWFLinkId;
    @Value("#{linkProperties['po_offline_amendment_process_in_workflow']?:889}")
    private int POOfflineAmendmentProcessWFLinkId;
    @Value("#{adminAuditTrailProperties['getWorkflowProcessMessage']}")
    private String getWorkflowProcessMessage;
    @Value("#{adminAuditTrailProperties['getWorkflowProcessedMessage']}")
    private String getWorkflowProcessedMessage;
    @Value("#{adminAuditTrailProperties['getWorkflowPulUpMessage']}")
    private String getWorkflowPulUpMessage;
    @Value("#{adminAuditTrailProperties['getcreateanytoanyworkflow']}")
    private String getCreateAnytoanyWFRemarks;
    @Value("#{adminAuditTrailProperties['getWorkflowconfigurepage']}")
    private String getWorkflowconfigurepageRemarks;
    @Value("#{adminAuditTrailProperties['getWorkflowconfigureeditpage']}")
    private String getWorkflowconfigurepageeditRemarks;
    @Value("#{adminAuditTrailProperties['postaddanytoanyworkflow']}")
    private String getAnytoanyWFSubmittedRemarks;
    @Value("#{adminAuditTrailProperties['postWorkflowConfiguration']}")
    private String postWorkflowConfigurationRemarks;
    @Value("#{adminAuditTrailProperties['getviewanytoanyworkflowhistory']}")
    private String getAnytoanyWFHistoryRemarks;
    @Value("#{adminAuditTrailProperties['getviewworkflowconfigure']}")
    private String getviewworkflowconfigureRemarks;
    @Value("#{adminAuditTrailProperties['getviewanytoanyspecificuserworkflowhistory']}")
    private String getAnytoanyspecificuserWFHistoryRemarks;
    @Value("#{adminAuditTrailProperties['getviewworkflowprocesseddocs']}")
    private String getAnytoanyWFdocsRemarks; 
    @Value("#{tenderlinkProperties['offline_negotiation_process_in_workflow']?:1148}")
    private int offline_negotiation_process_in_workflowLinkId;
    @Value("#{tenderlinkProperties['bid_opening_process_process_in_workflow']?:1181}")
    private int bid_opening_process_process_in_workflow;
    @Value("#{tenderlinkProperties['negotiation_create_committee_process_in_workflow']?:1184}")
    private int negotiation_create_committee_process_in_workflow;
    @Value("#{tenderlinkProperties['negotiation_close_process_in_workflow']?:1148}")
    private int negotiation_close_process_in_workflow;
    private static final String REDIRECT_SESSION_EXPIRED = "redirect:/sessionexpired";
    @Value("#{linkProperties['apo_reset_workflow']?:1214}")
    private int apoResetWorkflowLinkId;
    @Value("#{linkProperties['apo_amendment_reset_workflow']?:1216}")
    private int apoAmendResetWorkflowLinkId;
    @Value("#{linkProperties['po_reset_workflow']?:1218}")
    private int poResetWorkflowLinkId;
    @Value("#{linkProperties['po_amendment_reset_workflow']?:1220}")
    private int poAmendResetWorkflowLinkId;
    @Value("#{linkProperties['apo_cancel_process_in_workflow']?:1226}")
    private int apoCancelPIWLinkId;
    @Value("#{linkProperties['po_cancel_process_in_workflow']?:1227}")
    private int poCancelPIWLinkId;
    @Value("#{linkProperties['po_cancel_reset_workflow']?:1238}")
    private int poCancelResetWorkflowLinkId;
    @Value("#{linkProperties['apo_cancel_reset_workflow']?:1239}")
    private int apoCancelResetWorkflowLinkId;
    @Value("#{linkProperties['apo_offline_reset_workflow']?:1215}")
    private int apoOfflineResetWorkflowLinkId;
    @Value("#{linkProperties['apo_offline_amendment_reset_workflow']?:1217}")
    private int apoOfflineAmendResetWorkflowLinkId;
    @Value("#{linkProperties['po_offline_reset_workflow']?:1219}")
    private int poOfflineResetWorkflowLinkId;
    @Value("#{linkProperties['po_offline_amendment_reset_workflow']?:1221}")
    private int poOfflineAmendResetWorkflowLinkId;
    @Value("#{linkProperties['apo_offline_cancel_process_in_workflow']?:2262}")
    private int apoOfflineCancelPIWLinkId;
    @Value("#{linkProperties['po_offline_cancel_process_in_workflow']?:2279}")
    private int poOfflineCancelPIWLinkId;
    @Value("#{linkProperties['po_offline_cancel_reset_workflow']?:2285}")
    private int poOfflineCancelResetWorkflowLinkId;
    @Value("#{linkProperties['apo_offline_cancel_reset_workflow']?:2268}")
    private int apoOfflineCancelResetWorkflowLinkId;
    @Value("#{linkProperties['configuredate_process_in_workflow']?:2300}")
    private int ConfiguredateProcessWFLinkId;
    @Value("#{linkProperties['configuredate_reset_workflow']?:2306}")
    private int ConfiguredateResetWFLinkId;
    @Value("#{linkProperties['bid_opening_report_process_in_workflow']?:3302}")
    private int bidOpeningReportProcessWFLinkId;
    @Value("#{linkProperties['bid_evaluation_report_process_in_workflow']?:3310}")
    private int bidEvaluationReportProcessWFLinkId;
    @Value("#{etenderAuditTrailProperties['checkfwdfileaction']}")
    private String checkfwdfileaction;
    @Value("#{etenderAuditTrailProperties['checkrecommendfileaction']}")
    private String checkrecommendfileaction;
    @Value("#{etenderAuditTrailProperties['checkapprovedinwrkaction']}")
    private String checkapprovedinwrkaction;
    @Value("#{projectProperties['idfc_client_id']}")   
    private String idfcClientId;
    @Value("#{projectProperties['idfc_email_cc']}")   
    private String idfcEmailCC;
    @Value("#{tenderlinkProperties['notice_and_document_cancel']?:170}")    
    private int tenderCancelLink;

    @Value("#{linkProperties['online_contract_process_in_workflow']?:4414}")
    private int onlineContractProcessInWorkflowLinkId;
    
    
    /**
     * workflow configuration page for create / Edit / View
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/configureworkflow/{eventTypeId}/{parentlinkId}/{linkId}/{parentId}/{objectId}/{tabId}/{flag}/{enc}", method = RequestMethod.GET)
    public String configureworkflow(@PathVariable("eventTypeId") int eventTypeId,@PathVariable("parentlinkId") int parentlinkId,@PathVariable("linkId") int linkId,
    @PathVariable("parentId") int parentId,@PathVariable("objectId") int objectId,@PathVariable("tabId") int tabId,@PathVariable("flag") boolean flag,
    ModelMap modelMap,HttpServletRequest request) {
        int moduleId = 0;
        String auditTrialRemarks = "";
        int auditTrialObjectId = 0;
        String workflowType = "3";
        String estiMatedValue = "0";
        String strReturn ="common/ConfigureWorkflow";
        String frm = "";
        try {
            int workflowConfigId = 0;
            int clientId = abcUtility.getSessionClientId(request);
            moduleId = commonService.getModuleIdbyEventTypeId(eventTypeId);
            TblWorkflowConfiguration tblWorkflowConfiguration = workflowService.getConfiguredWFData(parentlinkId, objectId);
            if(tblWorkflowConfiguration!=null){
                workflowConfigId = tblWorkflowConfiguration.getWorkflowConfigId();
            }
            if(flag){
                frm = "confwf";
                auditTrialRemarks = getWorkflowconfigurepageRemarks;
                if(workflowConfigId!=0){
                    auditTrialRemarks = getWorkflowconfigurepageeditRemarks;
                    frm = "edit";
                }
            }else{
                auditTrialRemarks = getviewworkflowconfigureRemarks;
                frm = "view";        
            }
            switch(moduleId){
                case 3:
                        commonService.commontenderSummary(parentId, modelMap, clientId);         
                        break;
                case 2:
                        commonService.getIndentSummary(parentId,modelMap);        
                        break;
                case 13:
                    commonService.contractSummary(parentId,modelMap,clientId);        
                    break;        
                default:
                        break;    
            }
            List<Object[]> list = workflowService.getDepDesigUserName(abcUtility.getSessionUserId(request), clientId);
            Object[] object = (list!=null && !list.isEmpty())?list.get(0):null;
            modelMap.addAttribute("userprofile", object);
            modelMap.addAttribute("tblWorkflowConfiguration", tblWorkflowConfiguration);
            modelMap.addAttribute("ReviewersList", workflowService.getReviewers(workflowConfigId,"wfconfiguration"));
            modelMap.addAttribute("eventTypeId", eventTypeId);
            modelMap.addAttribute("moduleId", moduleId);
            modelMap.addAttribute("parentlinkId", parentlinkId);
            modelMap.addAttribute("linkId", linkId);            
            modelMap.addAttribute("parentId", parentId);
            modelMap.addAttribute("mainobjectId", objectId);
            modelMap.addAttribute("workflowConfigId", workflowConfigId);
            modelMap.addAttribute("tabId", tabId);  
            modelMap.addAttribute("frm", frm);  
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally{
            if("confwf".equalsIgnoreCase(frm)){auditTrialObjectId=0;}else{auditTrialObjectId=objectId;}
            if(moduleId == 3){
            	auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialRemarks, parentId,auditTrialObjectId, "");
            }else if(moduleId == 2){
            	auditTrailService.makeIndentAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialRemarks, parentId,auditTrialObjectId, "");
            }else if(moduleId == 13){
            	auditTrailService.makeOnlineContractAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialRemarks, parentId,auditTrialObjectId, "");
            }else{
            	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialRemarks, auditTrialObjectId, parentId,"");
            }
        }
        return strReturn;
    }
    /**
     * submit workflow configuration for create / edit
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/submitconfigureworkflow", method = RequestMethod.POST)
    public String submitconfigureworkflow(HttpServletRequest request,RedirectAttributes redirectAttributes) {
        boolean flag = false;
        int sessionUserId = 0;
        String hdmoduleId = "";
        String hdlinkId = "";
        String hdparentlinkId = "";
        String reviewerUserIds[];
        String reviewerUserDetailIds[];
        String reviewerSortOrders[];        
        String chkEvents = "";
        String hdparentId = "";
        String hdworkflowConfigId = "0";
        String hdtabId = "";
        String returnStr = "";
        TblWorkflowConfiguration tblWorkflowConfiguration =null;
        try {
            String hdworkflowType = StringUtils.hasLength(request.getParameter("hdworkflowType")) ? request.getParameter("hdworkflowType") : "";
            String approverUserId = StringUtils.hasLength(request.getParameter("hdUserId")) ? request.getParameter("hdUserId") : "0";
            String escalationDays = StringUtils.hasLength(request.getParameter("txtdays")) ? request.getParameter("txtdays") : "1";
            String isApplicableForAllEvents = StringUtils.hasLength(request.getParameter("chkEvents")) ? request.getParameter("chkEvents") : "0";
            hdlinkId = StringUtils.hasLength(request.getParameter("hdlinkId")) ? request.getParameter("hdlinkId") : "0";
            hdparentlinkId = StringUtils.hasLength(request.getParameter("hdparentlinkId")) ? request.getParameter("hdparentlinkId") : "0";
            String hdeventTypeId = StringUtils.hasLength(request.getParameter("hdeventTypeId")) ? request.getParameter("hdeventTypeId") : "0";
            hdmoduleId = StringUtils.hasLength(request.getParameter("hdmoduleId")) ? request.getParameter("hdmoduleId") : "0";
            hdparentId = StringUtils.hasLength(request.getParameter("hdparentId")) ? request.getParameter("hdparentId") : "";
            String hdmainobjectId = StringUtils.hasLength(request.getParameter("hdmainobjectId")) ? request.getParameter("hdmainobjectId") : "0";
            hdworkflowConfigId = StringUtils.hasLength(request.getParameter("hdworkflowConfigId")) ? request.getParameter("hdworkflowConfigId") : "";
            hdtabId = StringUtils.hasLength(request.getParameter("hdtabId")) ? request.getParameter("hdtabId") : "";
            reviewerUserIds = request.getParameterValues("hduserId");            
            reviewerUserDetailIds = request.getParameterValues("hduserDetailId");
            reviewerSortOrders = request.getParameterValues("ordercombo");
            sessionUserId = abcUtility.getSessionUserId(request);
            int sessonUserDetailId = abcUtility.getSessionUserDetailId(request);
            if(sessionUserId!=0 && sessonUserDetailId!=0){
                List<TblWorkflowConfigurationDetail> tblWorkflowConfigurationDetaillist = new ArrayList<TblWorkflowConfigurationDetail>();
                tblWorkflowConfiguration = new TblWorkflowConfiguration();
                tblWorkflowConfiguration.setTblLink(new TblLink(Integer.parseInt(hdparentlinkId)));
                tblWorkflowConfiguration.setObjectId(Integer.parseInt(hdmainobjectId));
                tblWorkflowConfiguration.setParentId(Integer.parseInt(hdparentId));
                tblWorkflowConfiguration.setEscalationPeriod(Integer.parseInt(escalationDays));
                tblWorkflowConfiguration.setForAllEvents(Integer.parseInt(isApplicableForAllEvents));
                tblWorkflowConfiguration.setCreatedBy(sessonUserDetailId);
                tblWorkflowConfiguration.setUpdatedBy(sessonUserDetailId);    
                tblWorkflowConfiguration.setUpdatedOn(commonService.getServerDateTime());    
                tblWorkflowConfiguration.setIsActive(1);
                if (reviewerUserIds != null && reviewerUserDetailIds != null && reviewerSortOrders!=null) {
                    for (int i = 0; i <reviewerUserDetailIds.length; i++) {            
                        TblWorkflowConfigurationDetail tblWorkflowConfigurationDetail = new TblWorkflowConfigurationDetail();
                        tblWorkflowConfigurationDetail.setTblWorkflowConfiguration(tblWorkflowConfiguration);
                        tblWorkflowConfigurationDetail.setUserType((reviewerSortOrders[i]!=null && !"".equalsIgnoreCase(reviewerSortOrders[i]))?(reviewerSortOrders[i].toString().equalsIgnoreCase("-1"))?1:(reviewerSortOrders[i].toString().equalsIgnoreCase("-3"))?3:2:0);
                        tblWorkflowConfigurationDetail.setTblUserLogin(new TblUserLogin(Integer.parseInt(reviewerUserIds[i].toString())));
                        tblWorkflowConfigurationDetail.setTblUserDetail(new TblUserDetail(Integer.parseInt(reviewerUserDetailIds[i].toString())));
                        tblWorkflowConfigurationDetail.setSortOrder((reviewerSortOrders[i]!=null && !"".equalsIgnoreCase(reviewerSortOrders[i]))?(reviewerSortOrders[i].toString().equalsIgnoreCase("-1"))?0:(reviewerSortOrders[i].toString().equalsIgnoreCase("-3"))?reviewerSortOrders.length-1:Integer.parseInt(reviewerSortOrders[i].toString()):-1);
                        tblWorkflowConfigurationDetail.setCreatedBy(sessonUserDetailId);
                        tblWorkflowConfigurationDetaillist.add(tblWorkflowConfigurationDetail);
                    }
                }
                flag = workflowService.addWorkflowConfiguration(tblWorkflowConfiguration, tblWorkflowConfigurationDetaillist,Integer.parseInt(hdworkflowConfigId));
                String referenceNo="";
                if(Integer.parseInt(hdmoduleId) == 2)
                {
                	referenceNo=commonService.getField("TblIndent", "indentNo", "indentId", Integer.parseInt(hdparentId));
                }else if(Integer.parseInt(hdmoduleId) == 13)
                {
                    referenceNo=commonService.getField("TblOnlineContract", "contractNo", "contractId", Integer.parseInt(hdparentId));
                }else
                {
                	referenceNo=commonService.getField("TblTender", "tenderNo", "tenderId", Integer.parseInt(hdparentId));
                }

                TblWorkflow tblWorkflow = new TblWorkflow();
                tblWorkflow.setObjectId(Integer.parseInt(hdmainobjectId));
                tblWorkflow.setParentId(Integer.parseInt(hdparentId));
                tblWorkflow.setClientId(abcUtility.getSessionClientId(request));
                tblWorkflow.setTblLink(new TblLink(Integer.parseInt(hdparentlinkId)));
                tblWorkflow.setTblEventType(new TblEventType(Integer.parseInt(hdeventTypeId)));
                tblWorkflow.setWorkflowActionId(9);
                tblWorkflow.setNextUserId(0);
                tblWorkflow.setLastUserId(0);
                tblWorkflow.setNextUserId(0);
                tblWorkflow.setTblUserLogin(new TblUserLogin(Integer.parseInt(reviewerUserIds[0].toString())));
                tblWorkflow.setUserType(1);
                tblWorkflow.setCreatedBy(sessonUserDetailId);                
                tblWorkflow.setEscalatedOn(commonService.getServerDateTime(Integer.parseInt("1")));
                tblWorkflow.setReferenceNo(referenceNo);
                tblWorkflow.setCstatus(0);
                tblWorkflow.setUpdatedOn(commonService.getServerDateTime());
                tblWorkflow.setUpdatedBy(sessonUserDetailId);                
                
                TblWorkflowDetail tblWorkflowDetail = new TblWorkflowDetail();
                tblWorkflowDetail.setTblWorkflow(tblWorkflow);
                tblWorkflowDetail.setFromUserDetailId(Integer.valueOf(reviewerUserDetailIds[0].toString()));
                tblWorkflowDetail.setToUserDetailId(Integer.valueOf(reviewerUserDetailIds[0].toString()));                   
                tblWorkflowDetail.setTblWorkflowAction(new TblWorkflowAction(9));
                tblWorkflowDetail.setRemarks("file have initiator");
                tblWorkflowDetail.setCreatedBy(abcUtility.getSessionUserId(request));
                flag = workflowService.addTblWorkflowForConfigureWorkflow(tblWorkflow, tblWorkflowDetail);

                if(flag){
                    switch(Integer.parseInt(hdmoduleId)){
                        case 3:
                                returnStr = "redirect:/etender/buyer/tenderdashboard/"+hdparentId+"/"+hdtabId+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+hdparentId+"/"+hdtabId, request);
                                break;
                        case 2:
                                returnStr = "redirect:/eindent/buyer/indentdashboard/"+hdparentId+encryptDecryptUtils.generateRedirect("eindent/buyer/indentdashboard/"+hdparentId, request);
                                break;
                        case 13:
                            returnStr = "redirect:/contract/buyer/contractBuyerDashboard/"+hdparentId+"/"+hdtabId+encryptDecryptUtils.generateRedirect("contract/buyer/contractBuyerDashboard/"+hdparentId+"/"+hdtabId, request);        
                        default:
                                break;    
                    }
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"msg_workflow_configured_success");
                }else{
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
                }
            }else{
                return REDIRECT_SESSION_EXPIRED;
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }finally{
        	if(Integer.parseInt(hdmoduleId) == 3){
        		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(hdparentlinkId), postWorkflowConfigurationRemarks,Integer.parseInt(hdparentId),tblWorkflowConfiguration.getWorkflowConfigId(),"");
        	}else if(Integer.parseInt(hdmoduleId) == 2){
        		auditTrailService.makeIndentAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(hdlinkId), postWorkflowConfigurationRemarks,Integer.parseInt(hdparentId),tblWorkflowConfiguration.getWorkflowConfigId(),"");
        	}else if(Integer.parseInt(hdmoduleId) == 13){
            	auditTrailService.makeOnlineContractAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(hdparentlinkId), postWorkflowConfigurationRemarks, Integer.parseInt(hdparentId),tblWorkflowConfiguration.getWorkflowConfigId(), "");
            }else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(hdparentlinkId), postWorkflowConfigurationRemarks,tblWorkflowConfiguration.getWorkflowConfigId(),Integer.parseInt(hdparentId),"");
        	}
        }
        return returnStr;
    }
    
    /**
     * Any to Any workflow / Hierarchy based worflow / Financial Limit based workflow / Hierarchy + Financial Limit based workflow process page
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/processanytoanyworkflow/{eventTypeId}/{parentlinkId}/{linkId}/{parentId}/{objectId}/{tabId}/{flag}/{enc}", method = RequestMethod.GET)
    public String processanytoanyworkflow(@PathVariable("eventTypeId") int eventTypeId,@PathVariable("parentlinkId") int parentlinkId,@PathVariable("linkId") int linkId,
    @PathVariable("parentId") int parentId,@PathVariable("objectId") int objectId,@PathVariable("tabId") int tabId,@PathVariable("flag") boolean flag,
    ModelMap modelMap,HttpServletRequest request) {
        String strReturn =processAnyToAnyWorkflow(eventTypeId,parentlinkId,linkId,parentId,objectId,tabId,flag,modelMap,request,-1);
        return strReturn;
    }
    
    @RequestMapping(value = "/processanytoanyworkflow/{eventTypeId}/{parentlinkId}/{linkId}/{parentId}/{objectId}/{tabId}/{flag}/{validate}/{enc}", method = RequestMethod.GET)
    public String processanytoanyworkflowForServerSideValidate(@PathVariable("eventTypeId") int eventTypeId,@PathVariable("parentlinkId") int parentlinkId,@PathVariable("linkId") int linkId,
    @PathVariable("parentId") int parentId,@PathVariable("objectId") int objectId,@PathVariable("tabId") int tabId,@PathVariable("flag") boolean flag,@PathVariable("validate") int validate,
    ModelMap modelMap,HttpServletRequest request) {
        String strReturn =processAnyToAnyWorkflow(eventTypeId,parentlinkId,linkId,parentId,objectId,tabId,flag,modelMap,request,validate);
        return strReturn;
    }
    
    private String processAnyToAnyWorkflow(int eventTypeId,int parentlinkId,int linkId,
    	    int parentId,int objectId,int tabId,boolean flag,
    	    ModelMap modelMap,HttpServletRequest request,int serverSideValidate){
        int eventId = 0;
        int wrkflId = 0;
        int lastUserId = 0;
        int lastSelectedActionId = 0;
        int assignUserId = 0;
        int moduleId = 0;
        String frm = "";
        String auditTrialRemarks = "";
        String workflowType = "3";
        int auditTrialObjectId = 0;
	String strReturn ="/common/ProcessAnyToAnyWorkFlow";
        try {
            boolean currentStack = false;
            boolean uploadDownloadbool = true;
            int currentUserId = 0;
            List<Object[]> reviewrsList = null;
            List<Object[]> processHistorylist = null;
            int userId = abcUtility.getSessionUserId(request);
            int clientId = abcUtility.getSessionClientId(request);
            moduleId = commonService.getModuleIdbyEventTypeId(eventTypeId);
            List<Object[]> eventIdlist = commonService.getEventIdFromLinkId(linkId);
            TblWorkflowConfigurationDetail tblWorkflowConfigurationDetail=null;
            if(eventIdlist!=null && !eventIdlist.isEmpty()){
                eventId = Integer.parseInt(eventIdlist.get(0)[1].toString());
            }
            switch(moduleId){
                case 3:
                        commonService.commontenderSummary(parentId, modelMap, clientId);
                        workflowType = commonService.getField("TblTender", "workflowTypeId", "tenderId", parentId);                        
                        break;
                case 2:
                        commonService.getIndentSummary(parentId,modelMap);
                        workflowType = commonService.getField("TblIndent", "workflowTypeId", "indentId", parentId);
                        break;
                case 13:
                		commonService.contractSummary(parentId,modelMap,abcUtility.getSessionClientId(request));
                		workflowType = commonService.getField("TblOnlineContract", "workflowTypeId", "contractId", parentId);
                		break;
                default:
                        break;    
            }
            if(workflowType.equals("0")){
            	 modelMap.addAttribute(CommonKeywords.ERROR_MSG.toString(),"msg_workflow_select_workflowType");
	        }else{
	            processHistorylist = workflowService.getLatestHistoryDetail(objectId,WebUtils.getCookie(request, "locale").getValue(),parentlinkId);
	            if("2".equalsIgnoreCase(workflowType) || "4".equalsIgnoreCase(workflowType) || "5".equalsIgnoreCase(workflowType)){
	                int MainEventLinkId = 0;
	                switch(moduleId){
	                    case 3:
	                            MainEventLinkId = noticeAndDocumentsWFLinkId;
	                            break;
	                    case 2:
	                            MainEventLinkId = indentProcessWFLinkId;
	                            break;
	                    case 13:
                            	MainEventLinkId = onlineContractProcessInWorkflowLinkId;
                            	break;        
	                    default:
	                            MainEventLinkId = 0;
	                            break;    
	                }
	                TblWorkflowConfiguration tblWorkflowConfiguration = null;
	                TblWorkflowConfiguration tblWorkflowMainEventConfiguration = workflowService.getConfiguredWFData(MainEventLinkId, objectId);
	                if(tblWorkflowMainEventConfiguration!=null && tblWorkflowMainEventConfiguration.getForAllEvents()==1){
	                    tblWorkflowConfiguration = tblWorkflowMainEventConfiguration;
	                }else{
	                    tblWorkflowConfiguration = workflowService.getConfiguredWFData(parentlinkId, objectId);
	                }
	                if(tblWorkflowConfiguration!=null){
	                    currentUserId = (processHistorylist!=null && !processHistorylist.isEmpty() && processHistorylist.get(0)!=null)?Integer.parseInt(processHistorylist.get(0)[10].toString()):0;
	                    reviewrsList = workflowService.getReviewers(tblWorkflowConfiguration.getWorkflowConfigId(),"pfiwf");
	                    modelMap.addAttribute("tblWorkflowConfiguration", tblWorkflowConfiguration);
	                    modelMap.addAttribute("FileOnHand",currentUserId);
	                    modelMap.addAttribute("ReviewersList", reviewrsList);
	                    List<TblWorkflowConfigurationDetail> lstTblWorkflowConfigurationDetail=workflowService.getTblWorkflowConfigurationDetail(tblWorkflowConfiguration.getWorkflowConfigId(), userId);
	                    if(lstTblWorkflowConfigurationDetail!=null && !lstTblWorkflowConfigurationDetail.isEmpty()){
	                    	tblWorkflowConfigurationDetail=lstTblWorkflowConfigurationDetail.get(0);
	                    	modelMap.addAttribute("userType", tblWorkflowConfigurationDetail.getUserType());
	                    }
	                }
	            }
	            if(flag){
	                auditTrialRemarks = getCreateAnytoanyWFRemarks;
	                List<TblWorkflowAction> dblist = workflowService.getWorkflowActionList();
	                List<TblWorkflowAction> list = new ArrayList<TblWorkflowAction>();
	                if(processHistorylist!=null && !processHistorylist.isEmpty() && processHistorylist.get(0)!=null){
	                    wrkflId = Integer.parseInt(processHistorylist.get(0)[8].toString());
	                    lastUserId = Integer.parseInt(processHistorylist.get(0)[9].toString());
	                    lastSelectedActionId = Integer.parseInt(processHistorylist.get(0)[0].toString());
	                    if(Integer.parseInt(processHistorylist.get(0)[9].toString())==userId && Integer.parseInt(processHistorylist.get(0)[9].toString())!=Integer.parseInt(processHistorylist.get(0)[10].toString())){
	                        uploadDownloadbool = false;
	                        frm = "callback";
	                        list = getWFActionList(dblist, frm, 0,Integer.parseInt(workflowType),reviewrsList,currentUserId);
	                        if("2".equalsIgnoreCase(workflowType) || "4".equalsIgnoreCase(workflowType) || "5".equalsIgnoreCase(workflowType)){
	                            if(reviewrsList!=null && !reviewrsList.isEmpty()){
	                            	int callbackLastUserId=0;
	                            	for (Object[] obj : reviewrsList) {
	                                    if(userId==Integer.parseInt(obj[7].toString())){
	                                        modelMap.addAttribute("callbackUserType", Integer.parseInt(obj[6].toString())!=0?Integer.parseInt(obj[6].toString()):0);                                       
	                                        break;
	                                    }else{
	                                    	callbackLastUserId=Integer.parseInt(obj[7].toString())!=0?Integer.parseInt(obj[7].toString()):0;
	                                    }
	                                }                            	
	                            	modelMap.addAttribute("callbackLastUserId", callbackLastUserId!=0?callbackLastUserId:userId);
	                            }
	                        }
	                    }else if(Integer.parseInt(processHistorylist.get(0)[11].toString())==userId && Integer.parseInt(processHistorylist.get(0)[0].toString())!=8){
	                        uploadDownloadbool = false;
	                        frm = "pullfile";
	                        list = getWFActionList(dblist, frm, 0,Integer.parseInt(workflowType),reviewrsList,currentUserId);
	                        if(reviewrsList!=null && !reviewrsList.isEmpty()){
	                            int i = 0;
	                            for (Object[] obj : reviewrsList) {
	                                if(userId==Integer.parseInt(obj[7].toString())){
	                                    modelMap.addAttribute("pullbackUserType", Integer.parseInt(obj[6].toString())!=0?Integer.parseInt(obj[6].toString()):0);      
	                                    if(i<reviewrsList.size()-1){
	                                        modelMap.addAttribute("pullbackNextUserId", reviewrsList.get(i+1)[7]!=null?Integer.parseInt(reviewrsList.get(i+1)[7].toString()):0);      
	                                    }else{
	                                        modelMap.addAttribute("pullbackNextUserId", 0);      
	                                    }
	                                }
	                                i++;
	                            }
	                        }
	                    }else{
	                    	List<Object[]> userDetailIdlist = workflowService.getAsignUserIdUserDetailId(String.valueOf(parentId),clientId);
	                        if(userDetailIdlist!=null && !userDetailIdlist.isEmpty()){
	                            Object[] userDetailIdarray = userDetailIdlist.get(0);
	                            assignUserId = Integer.parseInt(userDetailIdarray[0].toString());
	                        }
	                        if(assignUserId!=0 && assignUserId==userId && ((processHistorylist.size()==0 && "3".equalsIgnoreCase(workflowType)) || (processHistorylist.size()>=1 && !"3".equalsIgnoreCase(workflowType)))){
	                            frm = "pfiwf";
	                            currentStack = true;
	                            list = getWFActionList(dblist, frm, 0,Integer.parseInt(workflowType),reviewrsList,currentUserId);
	                        }else{
	                            frm = "prces";
	                            
	                            //list = getWFActionList(dblist, frm, Integer.parseInt(processHistorylist.get(0)[0].toString()),Integer.parseInt(workflowType),reviewrsList,currentUserId);
	                            int currentUser = (processHistorylist!=null && !processHistorylist.isEmpty() && processHistorylist.get(0)!=null)?Integer.parseInt(processHistorylist.get(0)[10].toString()):0;
	                            int createdByUserDetailId =  (processHistorylist!=null && !processHistorylist.isEmpty() && processHistorylist.get(0)!=null)?Integer.parseInt(processHistorylist.get(0)[12].toString()):0;
	                            TblUserDetail tblUserDetail = commonService.getTblUserDetailById(createdByUserDetailId);
	                            int createdBy = 0;
	                            if(tblUserDetail != null){
	                            	createdBy = tblUserDetail.getTblUserLogin().getUserId();
	                            }
	                            list = getWFActionList(dblist, frm, Integer.parseInt(processHistorylist.get(0)[0].toString()),Integer.parseInt(workflowType),reviewrsList,currentUserId,currentUser,createdBy);
	                            modelMap.addAttribute("LatestHistoryDetail", processHistorylist.get(0));
	                            modelMap.addAttribute("latestHistryflag", "true");
	                            modelMap.addAttribute("objectId",processHistorylist.get(0)[7]);
	                            modelMap.addAttribute("isReadOnly", "Y");
	                            if("3".equalsIgnoreCase(workflowType)){
	                            	modelMap.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(parentlinkId, clientId, 0));
	                            	modelMap.addAttribute("clientId",clientId);
	                            }else if(tblWorkflowConfigurationDetail!=null && tblWorkflowConfigurationDetail.getUserType()!=1){
	                            	
	                            	modelMap.addAttribute("dynFieldMap", dynamicFieldService.setDynamicField(parentlinkId, clientId, 0));
	                            	modelMap.addAttribute("clientId",clientId);
	                            }
	                        }
	                    }    
	                }else{
	                    frm = "pfiwf";
	                    list = getWFActionList(dblist, frm, 0,Integer.parseInt(workflowType),reviewrsList,currentUserId);
	                }
	                if(list!=null && !list.isEmpty()){
	                    modelMap.addAttribute("tblWorActionItemList", modelToSelectItem.convertListIntoSelectItemList(list, "workflowActionId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
	                }
	                if(uploadDownloadbool){
	                    List<TblDocUploadConf> lstDocUploadConf = commonService.getDocUploadConf(eventId, clientId);
	                    int allowedSize = 0;
	                    StringBuilder allowedExt = new StringBuilder();
	                    if (lstDocUploadConf != null && !lstDocUploadConf.isEmpty()) {
	                        allowedSize = lstDocUploadConf.get(0).getMaxSize();
	                        allowedExt.append(lstDocUploadConf.get(0).getType());
	                        modelMap.addAttribute("tblDocUploadConfig", lstDocUploadConf.get(0));
	                    }
	                    int index = allowedExt.toString().indexOf(",");
	                    allowedExt.insert(index + 1, "*.");
	                    while (index >= 0) {
	                        index = allowedExt.toString().indexOf(",", index + ",".length());
	                        allowedExt.insert(index + 1, "*.");
	                    }
	                    modelMap.addAttribute("allowedExt", allowedExt);
	                    modelMap.addAttribute("allowedSize", allowedSize/1024);
	                    modelMap.addAttribute("cStatusDoc", 5);
	                    modelMap.addAttribute("allowFileExist","Y");
	                }
	            }else{
	                if(objectId!=0){
	                    auditTrialRemarks = getAnytoanyWFHistoryRemarks;
	                    modelMap.addAttribute("processHistorylist", workflowService.getProcessHistory(objectId,WebUtils.getCookie(request, "locale").getValue(),parentlinkId));
	                    modelMap.addAttribute("latestHistryflag", true);
	                    modelMap.addAttribute("MultiUserHistDetail",true);
	                    frm = "histry";
	                }
	            }
	            if(APOAmendmentProcessWFLinkId == parentlinkId || POAmendmentProcessWFLinkId == parentlinkId || APOOfflineAmendmentProcessWFLinkId == parentlinkId || POOfflineAmendmentProcessWFLinkId == parentlinkId ){
	            	modelMap.addAttribute("apoPoId",workflowService.getCorrigendumField(objectId,"objectId"));
                }
	            if(frm.equalsIgnoreCase("prces") || frm.equalsIgnoreCase("histry")){
	                if(linkId==noticeAndDocumentsWFLinkId || linkId==noticeAndDocumentsViewWFLinkId || linkId==noticeAndDocumentsCancelWFLinkId){
	                    List<Object[]> wfRulelist = null;
	                    wfRulelist = commonService.getClientConfiguration(clientId);
	                    if(wfRulelist!=null && !wfRulelist.isEmpty()){
	                        for (Object[] objects : wfRulelist) {
	                            if(objects[2]!=null && Integer.parseInt(objects[2].toString())==1){
	                                modelMap.addAttribute("IsTOCPublishWithTender", true);   
	                            }
	                            if(objects[3]!=null && Integer.parseInt(objects[3].toString())==1){
	                                modelMap.addAttribute("IsTECPublishWithTender", true);    
	                            }
	                            if(objects[4]!=null && Integer.parseInt(objects[4].toString())==1){
	                                modelMap.addAttribute("IsBiddingFormPublishWithTender", true); 
	                            }
	                            if(objects[1]!=null && Integer.parseInt(objects[1].toString())==1){
	                                modelMap.addAttribute("IsPreBidPublishWithTender", true);  
	                                modelMap.addAttribute("committeeId", workflowService.getcommitteeIdbyTenderId(Integer.toString(parentId)));    
	                            }
	                        }
	                        int rebateId = 0;
	                        int isRebateForm = 0;
	                        List<Object[]> rebateList = workflowService.getrebateIdbyTenderId(Integer.toString(parentId));
	                        if(rebateList!=null && !rebateList.isEmpty()){
	                              rebateId = Integer.parseInt(rebateList.get(0)[0].toString());  
	                              isRebateForm = Integer.parseInt(rebateList.get(0)[1].toString());  
	                              modelMap.addAttribute("IsRebateApplicable", true);    
	                              modelMap.addAttribute("rebateId", rebateId);    
	                              modelMap.addAttribute("isRebateForm", isRebateForm);    
	                        }
	                    }
	                }
	                URL url = new URL(request.getRequestURL().toString()); 
	                StringBuffer verifyUrlPrefix = new StringBuffer();
	                verifyUrlPrefix.append(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "https").append("://").append(url.getHost());
	                if ((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) {
	                     verifyUrlPrefix.append(":").append(url.getPort());
	                }
	                modelMap.addAttribute("verifyUrlPrefix", verifyUrlPrefix+request.getContextPath()); 
	            }
	        }
            if((APOProcessWFLinkId == parentlinkId)  || (APOOfflineProcessWFLinkId == parentlinkId ) || (apoOfflineCancelPIWLinkId == parentlinkId ) || (apoCancelPIWLinkId == parentlinkId )){
	            List<Object[]> apoList =  commonService.getContractFields(objectId,"apoId,tblDynReport.reportId","TblAdvancePurchaseOrder");
	            if(!apoList.isEmpty()){
	            	modelMap.addAttribute("reportId", apoList.get(0)[0]!=null ? Integer.parseInt(apoList.get(0)[1].toString()):0);
	            }
            }
            if((POProcessWFLinkId == parentlinkId) || (POOfflineProcessWFLinkId == parentlinkId )){
            	List<Object[]> poList =  commonService.getContractFields(objectId,"poId,tblDynReport.reportId","TblPurchaseOrder");
                if(!poList.isEmpty()){
                	modelMap.addAttribute("reportId", poList.get(0)[0]!=null ? Integer.parseInt(poList.get(0)[1].toString()) : 0);
                }
            }
	            modelMap.addAttribute("workflowType", workflowType);
	            modelMap.addAttribute("currentStack", currentStack);
	            modelMap.addAttribute("eventTypeId", eventTypeId);
	            modelMap.addAttribute("moduleId", moduleId);
	            modelMap.addAttribute("linkId", linkId);
	            modelMap.addAttribute("parentlinkId", parentlinkId);
	            modelMap.addAttribute("EventId", eventId);
	            modelMap.addAttribute("parentId", parentId);
	            modelMap.addAttribute("tenderId", parentId);
	            modelMap.addAttribute("mainobjectId", objectId);
	            modelMap.addAttribute("wrkflId", wrkflId);
	            modelMap.addAttribute("lastUserId", lastUserId);
	            modelMap.addAttribute("lastSelectedActionId", lastSelectedActionId);
	            modelMap.addAttribute("frm", frm);
	            modelMap.addAttribute("tabId", tabId);  
	            modelMap.addAttribute("objectIdNew",0);
	            modelMap.addAttribute("cStatusDocView", officerDocStatusApprove);      
	            modelMap.addAttribute("dbcurrentUserId", (processHistorylist!=null && !processHistorylist.isEmpty() && processHistorylist.get(0)!=null)?Integer.parseInt(processHistorylist.get(0)[10].toString()):0);
	            modelMap.addAttribute("serverSideValidate",serverSideValidate);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally{
            if("pfiwf".equalsIgnoreCase(frm)){auditTrialObjectId=0;}else{auditTrialObjectId=parentId;}
            if(moduleId == 3){
            	auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialRemarks, parentId,auditTrialObjectId, "");
            }else if(moduleId == 2){
            	auditTrailService.makeIndentAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialRemarks, parentId,auditTrialObjectId, "");
            }else if(moduleId == 13){
            	auditTrailService.makeOnlineContractAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialRemarks, parentId,auditTrialObjectId, "");
            }else{
            	auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialRemarks, auditTrialObjectId, parentId,"");
            }
        }
        return strReturn;
    }
    /**
     * get Any to Any workflow process History
     * @param mainobjectId
     * @param wrkflId
     * @param parentId
     * @param parentlinkId
     * @param linkId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/ajax/wrkflwhistry", method = RequestMethod.POST)
    public String getwrkflwhistry(@RequestParam("txtmainobjectId") int mainobjectId,@RequestParam("txtwrkflId") int wrkflId,@RequestParam("txtparentId") int parentId,@RequestParam("txtparentlinkId") int parentlinkId,@RequestParam("txtlinkId") int linkId,@RequestParam("txtmoduleId") int moduleId,HttpServletRequest request,ModelMap modelMap) {
        String returnStr=REDIRECT_SESSION_EXPIRED;
        try {
            if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                if(wrkflId!=0){
                    List<Object[]> processHistorylist = workflowService.getProcessHistory(mainobjectId,WebUtils.getCookie(request, "locale").getValue(),parentlinkId);
                    if(processHistorylist!=null && !processHistorylist.isEmpty()){
                        modelMap.addAttribute("processHistorylist", processHistorylist);
                        modelMap.addAttribute("MultiUserHistDetail",true);
                        modelMap.addAttribute("removeGoback", "removeGoback");
                        modelMap.addAttribute("wrkflId", wrkflId);
                        modelMap.addAttribute("parentId", parentId);
                        modelMap.addAttribute("parentlinkId", parentlinkId);
                        modelMap.addAttribute("linkId", linkId);
                        modelMap.addAttribute("moduleId", moduleId);
                        returnStr = "/common/ProcessAnytoAnyWFHistory";
                    }
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } 
        finally {
        	if(moduleId == 3){
        		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getAnytoanyWFHistoryRemarks, parentId,wrkflId, "");
        	}else if(moduleId == 2){
        		auditTrailService.makeIndentAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getAnytoanyWFHistoryRemarks, parentId,wrkflId, "");
        	}else if(moduleId == 13){
            	auditTrailService.makeOnlineContractAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getAnytoanyWFHistoryRemarks, parentId,wrkflId, "");
            }else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getAnytoanyWFHistoryRemarks, wrkflId, parentId,"");
        	}
        }
        return returnStr;
    }
    /**
     * get detailed information/remarks/documents given by officer in Any to Any workflow process
     * @param wrkfdetailId
     * @param wrkflId
     * @param parentId
     * @param parentlinkId
     * @param linkId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/ajax/getwrkflwDetail", method = RequestMethod.POST)
    public String getwrkflwDetail(@RequestParam("txtwrkfdetailId") int wrkfdetailId,@RequestParam("txtwrkflId") int wrkflId,@RequestParam("txtparentId") int parentId,@RequestParam("txtparentlinkId") int parentlinkId,@RequestParam("txtlinkId") int linkId,@RequestParam("txtmoduleId") int moduleId,HttpServletRequest request,ModelMap modelMap) {
        String returnStr=REDIRECT_SESSION_EXPIRED;
        try {
            if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                if(wrkfdetailId!=0){
                    List<Object[]> singleuserHistorylist = workflowService.getSingleUserHistoryDetail(wrkfdetailId,WebUtils.getCookie(request, "locale").getValue());
                    if(singleuserHistorylist!=null && !singleuserHistorylist.isEmpty()){
                        modelMap.addAttribute("singleuserHistorylist",singleuserHistorylist.get(0));
                        modelMap.addAttribute("MultiUserHistDetail",false);
                        modelMap.addAttribute("SingleUserHistDetail",true);
                        modelMap.addAttribute("objectId",wrkfdetailId);
                        modelMap.addAttribute("isReadOnly", "Y");
                        modelMap.addAttribute("linkId", linkId);
                        modelMap.addAttribute("moduleId", moduleId);
                        modelMap.addAttribute("cStatusDoc", officerDocStatusApprove);
                        modelMap.addAttribute("cStatusDocView", officerDocStatusApprove);
                        modelMap.addAttribute("isDynamicTableId", "getSingleWFUserDocs");
                        List<Object[]> singleUserDocumentDetails =fileUploadService.getOfficerDocs(wrkfdetailId, abcUtility.getSessionClientId(request), parentlinkId,officerDocStatusApprove);
                        if(singleUserDocumentDetails!=null && !singleUserDocumentDetails.isEmpty()){
                            modelMap.addAttribute("singleUserDocumentDetails", singleUserDocumentDetails);
                        }
                        modelMap.addAttribute("dynFieldValueMap",dynamicFieldService.getDynFieldNameValListForView(parentlinkId, abcUtility.getSessionClientId(request), wrkfdetailId));
                        returnStr = "/common/ProcessAnytoAnyWFHistory";
                    }
                }
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        } 
        finally {
        	if(moduleId == 3){
        		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getAnytoanyspecificuserWFHistoryRemarks, parentId,wrkfdetailId,"");
        	}else if(moduleId == 2){
        		auditTrailService.makeIndentAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getAnytoanyspecificuserWFHistoryRemarks, parentId,wrkfdetailId, "");
        	}else if(moduleId == 13){
            	auditTrailService.makeOnlineContractAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getAnytoanyspecificuserWFHistoryRemarks, parentId,wrkfdetailId, "");
            }else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, getAnytoanyspecificuserWFHistoryRemarks, wrkfdetailId, parentId,"");
        	}
        }
        return returnStr;
    }
    /**
     * submit Any to Any workflow process
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/submitanytoanyworkflow", method = RequestMethod.POST)
    public String submitanytoanyworkflow(HttpServletRequest request,RedirectAttributes redirectAttributes) {
        TblWorkflowDetail tblWorkflowDetail = null;
        String returnStr = "";
        String hdparentId = "";
        String hdtabId = "";
        String hdlinkId = "";
        String hdparentlinkId = "";
        String hdmoduleId = "";
        String hdcurrentStack = "";
        String selWrkflwAction = "";
        String msg = "msg_workflow_already_proceed";
        try {
            boolean flag = false;
            boolean sendmailbool = false;
            int userId = 0;
            int assignUserId = 0;
            int userDetailIdAsPerAssignUserId = 0;
            int fileCloseWorkflowDetailId=0;
            String hdworkflowType = StringUtils.hasLength(request.getParameter("hdworkflowType")) ? request.getParameter("hdworkflowType") : "";
            String rtfComments = StringUtils.hasLength(request.getParameter("rtfComments")) ? request.getParameter("rtfComments") : "";
            selWrkflwAction = StringUtils.hasLength(request.getParameter("selWrkflwAction")) ? request.getParameter("selWrkflwAction") : "";
            String compoSearchUserid = StringUtils.hasLength(request.getParameter("hduserId")) ? request.getParameter("hduserId") : "0";
            String compoSearchUserDetailId = StringUtils.hasLength(request.getParameter("hduserDetailId")) ? request.getParameter("hduserDetailId") : "0";
            String hdnexttonextuserId = StringUtils.hasLength(request.getParameter("hdnexttonextuserId")) ? request.getParameter("hdnexttonextuserId") : "0";
            String hdeventTypeId = StringUtils.hasLength(request.getParameter("hdeventTypeId")) ? request.getParameter("hdeventTypeId") : "0";
            hdmoduleId = StringUtils.hasLength(request.getParameter("hdmoduleId")) ? request.getParameter("hdmoduleId") : "0";
            hdlinkId = StringUtils.hasLength(request.getParameter("hdlinkId")) ? request.getParameter("hdlinkId") : "0";
            hdparentlinkId = StringUtils.hasLength(request.getParameter("hdparentlinkId")) ? request.getParameter("hdparentlinkId") : "0";
            hdparentId = StringUtils.hasLength(request.getParameter("hdparentId")) ? request.getParameter("hdparentId") : "";
            String hdmainobjectId = StringUtils.hasLength(request.getParameter("hdmainobjectId")) ? request.getParameter("hdmainobjectId") : "0";
            hdtabId = StringUtils.hasLength(request.getParameter("hdtabId")) ? request.getParameter("hdtabId") : "";
            String hdfrm = StringUtils.hasLength(request.getParameter("hdfrm")) ? request.getParameter("hdfrm") : "";
            String workflowId = StringUtils.hasLength(request.getParameter("hdwrkflId")) ? request.getParameter("hdwrkflId") : "0";
            String txtHidDocIds = StringUtils.hasLength(request.getParameter("txtHidDocIdss")) ? request.getParameter("txtHidDocIdss") : "";
            hdcurrentStack = StringUtils.hasLength(request.getParameter("hdcurrentStack")) ? request.getParameter("hdcurrentStack") : "";
            String hdreferenceNo = StringUtils.hasLength(request.getParameter("hdreferenceNo")) ? request.getParameter("hdreferenceNo") : "";
            String hdUserType = StringUtils.hasLength(request.getParameter("hdUserType")) ? request.getParameter("hdUserType") : "0";
            String hdEscalationPeriod = StringUtils.hasLength(request.getParameter("hdEscalationPeriod")) ? request.getParameter("hdEscalationPeriod") : "0";            
            String hddbcurrentUserId = StringUtils.hasLength(request.getParameter("hddbcurrentUserId")) ? request.getParameter("hddbcurrentUserId") : "0";            
            String hdpullbackNextUserId = StringUtils.hasLength(request.getParameter("hdpullbackNextUserId")) ? request.getParameter("hdpullbackNextUserId") : "0";            
            String hdpullbackUserType = StringUtils.hasLength(request.getParameter("hdpullbackUserType")) ? request.getParameter("hdpullbackUserType") : "0";            
            String hdcallbackUserType = StringUtils.hasLength(request.getParameter("hdcallbackUserType")) ? request.getParameter("hdcallbackUserType") : "0";            
            String hdcallbackLastUserId = StringUtils.hasLength(request.getParameter("hdcallbackLastUserId")) ? request.getParameter("hdcallbackLastUserId") : "0";
            int clientId = abcUtility.getSessionClientId(request);
            userId = abcUtility.getSessionUserId(request);
            int sessonUserDetailId = 0;
            
//            String hdserverSideValidate = StringUtils.hasLength(request.getParameter("hdserverSideValidate")) ? request.getParameter("hdserverSideValidate") : "";
            
            SessionBean sessionBean = (SessionBean) request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString());
            
            /*Changes done for Bug #46917*/
            if(abcUtility.getSessionUserTypeId(request)==1){//Admin user
            	sessonUserDetailId = Integer.parseInt(loginService.getUserDetailId(userId)[0].toString());
            }else{//Officer
            	sessonUserDetailId = Integer.parseInt(loginService.getUserDetailIdByUserIdAndClientId(userId,clientId)[0].toString());
            }
            if(userId!=0 && sessonUserDetailId!=0){
                TblWorkflow tblWorkflow = new TblWorkflow();
                tblWorkflow.setObjectId(Integer.parseInt(hdmainobjectId));
                tblWorkflow.setParentId(Integer.parseInt(hdparentId));
                tblWorkflow.setClientId(clientId);
                tblWorkflow.setTblLink(new TblLink(Integer.parseInt(hdlinkId)));
                tblWorkflow.setTblEventType(new TblEventType(Integer.parseInt(hdeventTypeId)));
                TblWorkflowConfiguration tblWorkflowConfiguration = workflowService.getConfiguredWFData(Integer.parseInt(hdparentlinkId), Integer.parseInt(hdmainobjectId));
                if(Integer.parseInt(selWrkflwAction)==4 || Integer.parseInt(selWrkflwAction)==5 || Integer.parseInt(selWrkflwAction)==6){
                    if(Integer.parseInt(hdworkflowType)==2 || Integer.parseInt(hdworkflowType)==4 || Integer.parseInt(hdworkflowType)==5){
                        
                        if(tblWorkflowConfiguration!=null){                            
                            List<Object[]> reviewrsList = workflowService.getReviewers(tblWorkflowConfiguration.getWorkflowConfigId(),"pfiwf");
                            if(reviewrsList!=null && !reviewrsList.isEmpty()){
                                for (Object[] obj : reviewrsList) {
                                    if(Integer.parseInt(obj[6].toString())==1){
                                        assignUserId = Integer.parseInt(obj[7].toString());
                                        userDetailIdAsPerAssignUserId = Integer.parseInt(obj[9].toString());                                        
                                    }
                                }
                            }
                        }
                    }else{
                        if(Integer.parseInt(hdmoduleId)==3){
                        		// #31753 - Creator send File to Map Officer or Map Officer  send File to  Creator for Action 4,5,6
                        	List<Object[]> userDetailIdlist=null;
                        	if(Integer.parseInt(hdworkflowType)==3 && Integer.parseInt(selWrkflwAction)==6){
                        		 userDetailIdlist=workflowService.getUserIdForActionReturnFile(Integer.parseInt(workflowId),sessionBean.getUserDetailId());
                        		 if(userDetailIdlist!=null && !userDetailIdlist.isEmpty()){
     								assignUserId = (Integer) (userDetailIdlist.get(0) != null ? userDetailIdlist.get(0)[0] : 0);
     								userDetailIdAsPerAssignUserId = (Integer) (userDetailIdlist.get(0) != null ? userDetailIdlist.get(0)[1] : 0);
     								fileCloseWorkflowDetailId=(Integer) (userDetailIdlist.get(0) != null ? userDetailIdlist.get(0)[3] : 0);
     							}
                        	}else{
                        		userDetailIdlist = workflowService.getWorkflowCreatorUserId(hdparentId, hdlinkId);
                        		if(userDetailIdlist!=null && !userDetailIdlist.isEmpty()){
    								assignUserId = (Integer) (userDetailIdlist.get(0) != null ? userDetailIdlist.get(0)[0] : 0);
    								userDetailIdAsPerAssignUserId = (Integer) (userDetailIdlist.get(0) != null ? userDetailIdlist.get(0)[1] : 0);
    							}
							}
                        	
                        }
                        if(Integer.parseInt(hdmoduleId)==2){
                           List<Object[]> userDetailIdlist = workflowService.getIndentAsignUserIdUserDetailId(hdparentId,clientId);
                            if(userDetailIdlist!=null && !userDetailIdlist.isEmpty()){
                                Object[] userDetailIdarray = userDetailIdlist.get(0);
                                assignUserId = Integer.parseInt(userDetailIdarray[0].toString());
                                userDetailIdAsPerAssignUserId = Integer.parseInt(userDetailIdarray[1].toString());
                            }
                        }
                        if(Integer.parseInt(hdmoduleId)==13){
                    		// #31753 - Creator send File to Map Officer or Map Officer  send File to  Creator for Action 4,5,6
	                    	List<Object[]> userDetailIdlist=null;
	                    	if(Integer.parseInt(hdworkflowType)==3 && Integer.parseInt(selWrkflwAction)==6){
	                    		 userDetailIdlist=workflowService.getUserIdForActionReturnFile(Integer.parseInt(workflowId),sessionBean.getUserDetailId());
	                    		 if(userDetailIdlist!=null && !userDetailIdlist.isEmpty()){
	 								assignUserId = (Integer) (userDetailIdlist.get(0) != null ? userDetailIdlist.get(0)[0] : 0);
	 								userDetailIdAsPerAssignUserId = (Integer) (userDetailIdlist.get(0) != null ? userDetailIdlist.get(0)[1] : 0);
	 								fileCloseWorkflowDetailId=(Integer) (userDetailIdlist.get(0) != null ? userDetailIdlist.get(0)[3] : 0);
	 							}
	                    	}else{
	                    		userDetailIdlist = workflowService.getWorkflowCreatorUserId(hdparentId, hdlinkId);
	                    		if(userDetailIdlist!=null && !userDetailIdlist.isEmpty()){
									assignUserId = (Integer) (userDetailIdlist.get(0) != null ? userDetailIdlist.get(0)[0] : 0);
									userDetailIdAsPerAssignUserId = (Integer) (userDetailIdlist.get(0) != null ? userDetailIdlist.get(0)[1] : 0);
								}
							}
                    	
                        }
                        
                    }
                    tblWorkflow.setTblUserLogin(new TblUserLogin(assignUserId));
                    tblWorkflow.setUserType(1);   
                    tblWorkflow.setLastUserId(0);
                    if(Integer.parseInt(selWrkflwAction)==4 || Integer.parseInt(selWrkflwAction)==6){
                         tblWorkflow.setNextUserId(0);
                    }
                    else{
                         tblWorkflow.setNextUserId(Integer.parseInt(hdnexttonextuserId));
                    }
                }else{
                    if("callback".equalsIgnoreCase(hdfrm) || "pullfile".equalsIgnoreCase(hdfrm)){
                        tblWorkflow.setTblUserLogin(new TblUserLogin(userId));   
                        /*tblWorkflow.setLastUserId(Integer.parseInt(hddbcurrentUserId));*/
                        if("callback".equalsIgnoreCase(hdfrm)){
                            if(Integer.parseInt(hdworkflowType)==3){
                                tblWorkflow.setNextUserId(Integer.parseInt(hdnexttonextuserId)); //hdnexttonextuserId as a 0 
                                tblWorkflow.setUserType(Integer.parseInt(hdUserType));
                                tblWorkflow.setLastUserId(Integer.parseInt(hdcallbackLastUserId));
                            }else if(Integer.parseInt(hdworkflowType)==2 || Integer.parseInt(hdworkflowType)==4 || Integer.parseInt(hdworkflowType)==5){
                                tblWorkflow.setNextUserId(Integer.parseInt(hddbcurrentUserId));
                                tblWorkflow.setUserType(Integer.parseInt(hdcallbackUserType));
                                tblWorkflow.setLastUserId(Integer.parseInt(hdcallbackLastUserId));
                            }
                        }
                        if("pullfile".equalsIgnoreCase(hdfrm)){
                            tblWorkflow.setNextUserId(Integer.parseInt(hdpullbackNextUserId));
                            tblWorkflow.setUserType(Integer.parseInt(hdpullbackUserType));
                            tblWorkflow.setLastUserId(Integer.parseInt(hddbcurrentUserId));
                        }
                    }else{
                        tblWorkflow.setTblUserLogin(new TblUserLogin(Integer.parseInt(compoSearchUserid)));    
                        tblWorkflow.setLastUserId(userId);
                        tblWorkflow.setNextUserId(Integer.parseInt(hdnexttonextuserId)); //hdnexttonextuserId as a 0 or original value                       
                        int nextUserType=1;
                        
                        if(Integer.parseInt(hdworkflowType)!=3){
                        	List<TblWorkflowConfigurationDetail> tblWorkflowConfigurationDetail=workflowService.getTblWorkflowConfigurationDetail(tblWorkflowConfiguration.getWorkflowConfigId(),Integer.parseInt(compoSearchUserid));
                        	nextUserType=(tblWorkflowConfigurationDetail!=null && !tblWorkflowConfigurationDetail.isEmpty() && tblWorkflowConfigurationDetail.get(0)!=null)?tblWorkflowConfigurationDetail.get(0).getUserType():1;
                        }
                        
                        tblWorkflow.setUserType(nextUserType);
                    }
                }
                tblWorkflow.setWorkflowActionId(Integer.parseInt(selWrkflwAction));
                tblWorkflow.setCreatedBy(sessonUserDetailId);                
                tblWorkflow.setEscalatedOn(commonService.getServerDateTime(Integer.parseInt(hdEscalationPeriod)));
                tblWorkflow.setReferenceNo(hdreferenceNo);
                tblWorkflow.setCstatus(0);
                tblWorkflow.setUpdatedOn(commonService.getServerDateTime());
                tblWorkflow.setUpdatedBy(sessonUserDetailId);

                tblWorkflowDetail = new TblWorkflowDetail();
                tblWorkflowDetail.setTblWorkflow(tblWorkflow);
                tblWorkflowDetail.setFromUserDetailId(sessonUserDetailId);
                if(Integer.parseInt(selWrkflwAction)==4 || Integer.parseInt(selWrkflwAction)==5 || Integer.parseInt(selWrkflwAction)==6){
                    tblWorkflowDetail.setToUserDetailId(userDetailIdAsPerAssignUserId);
                    if(((Integer.parseInt(selWrkflwAction)==6 && fileCloseWorkflowDetailId != 0) || (Integer.parseInt(selWrkflwAction)==4)) && Integer.parseInt(hdworkflowType)==3){
                    	tblWorkflowDetail.setFileClosed(1);
                    }
                }else{
                    if("callback".equalsIgnoreCase(hdfrm) || "pullfile".equalsIgnoreCase(hdfrm)){
                        tblWorkflowDetail.setToUserDetailId(sessonUserDetailId);
                        if(Integer.parseInt(selWrkflwAction)==7 && Integer.parseInt(hdworkflowType)==3){
                        	List<TblWorkflowDetail> listTblWorkflowDetail=workflowService.checkUserFileNotClose( Integer.parseInt(workflowId), sessonUserDetailId);
                        	if(listTblWorkflowDetail!=null && !listTblWorkflowDetail.isEmpty()){
                        		fileCloseWorkflowDetailId=listTblWorkflowDetail.get(0).getWorkflowDetailId();
                        		tblWorkflowDetail.setFileClosed(1);
                    		}
                        }
                    }else{
                        tblWorkflowDetail.setToUserDetailId(Integer.parseInt(compoSearchUserDetailId));
                    }
                }
                tblWorkflowDetail.setTblWorkflowAction(new TblWorkflowAction(tblWorkflow.getWorkflowActionId()));
                tblWorkflowDetail.setRemarks(rtfComments);
                tblWorkflowDetail.setCreatedBy(userId);
                int switchId = 0;
                if(Integer.parseInt(selWrkflwAction)==5){
                    if(preBidcommitteeWfLinkId == Integer.parseInt(hdlinkId) || openingProcessWorkflowLinkId == Integer.parseInt(hdlinkId) || evaluationProcessWorkflowLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 1;
                    }else if(preBidMeetingWfLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 2;
                    }else if(noticeAndDocumentsWFLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 3;
                    }else if(noticeAndDocumentsCancelWFLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 4;
                    }else if(corriProcessWFLinkId == Integer.parseInt(hdlinkId) || APOAmendmentProcessWFLinkId == Integer.parseInt(hdlinkId) || POAmendmentProcessWFLinkId == Integer.parseInt(hdlinkId) || APOOfflineAmendmentProcessWFLinkId == Integer.parseInt(hdlinkId)  || POOfflineAmendmentProcessWFLinkId == Integer.parseInt(hdlinkId) ){
                        switchId = 5;
                    }else if(indentProcessWFLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 6;
                    }else if(cancelIndentProcessWFLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 7;
                    }else if(offline_negotiation_process_in_workflowLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 8;
					}else if(APOProcessWFLinkId == Integer.parseInt(hdlinkId) || APOOfflineProcessWFLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 9;
                    }else if(POProcessWFLinkId == Integer.parseInt(hdlinkId) || POOfflineProcessWFLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 10;
                    }else if(negotiation_create_committee_process_in_workflow == Integer.parseInt(hdlinkId)){
                    	switchId = 11;
                    }else if(apoCancelPIWLinkId == Integer.parseInt(hdlinkId)){
                    	switchId = 12;
                    }else if(poCancelPIWLinkId == Integer.parseInt(hdlinkId)){
                    	switchId = 13;
                    }else if(apoOfflineCancelPIWLinkId == Integer.parseInt(hdlinkId)){
                    	switchId = 14;
                    }else if(poOfflineCancelPIWLinkId == Integer.parseInt(hdlinkId)){
                    	switchId = 15;
                    }else if(ConfiguredateProcessWFLinkId == Integer.parseInt(hdlinkId)){ // Foe Configure Date Workflow #31144
                        switchId = 16;
					}else if(bidOpeningReportProcessWFLinkId == Integer.parseInt(hdlinkId)){ 
                        switchId = 17;
					}else if(bidEvaluationReportProcessWFLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 18;
					}else if(onlineContractProcessInWorkflowLinkId == Integer.parseInt(hdlinkId)){
                        switchId = 19;
					}
                    
                }
                int newModuleId = Integer.parseInt(hdmoduleId);
                int reportId = 0;
                int companyId = 0;
                List<Object[]> lst = null;
                int contractId = Integer.parseInt(hdmainobjectId);
                int linkId = Integer.parseInt(hdlinkId);
                
                boolean isValidatedFromServerSide = true;
                if(isValidatedFromServerSide){
	                //Online Apo & PO
	                if(POProcessWFLinkId == linkId || APOProcessWFLinkId == linkId || APOAmendmentProcessWFLinkId == linkId || POAmendmentProcessWFLinkId == linkId || ("callback".equalsIgnoreCase(hdfrm) && (POProcessWFLinkId == Integer.parseInt(hdparentlinkId) || APOProcessWFLinkId == Integer.parseInt(hdparentlinkId) || APOAmendmentProcessWFLinkId == Integer.parseInt(hdparentlinkId) || POAmendmentProcessWFLinkId == Integer.parseInt(hdparentlinkId))) || apoCancelPIWLinkId == Integer.parseInt(hdparentlinkId) || poCancelPIWLinkId == Integer.parseInt(hdparentlinkId)){
	                    newModuleId = 6;
	                    if(APOProcessWFLinkId == linkId || APOProcessWFLinkId == Integer.parseInt(hdparentlinkId) || apoCancelPIWLinkId == Integer.parseInt(hdparentlinkId)){
	                    	reportId = commonService.getTblAdvancePurchaseOrderByObject(Integer.parseInt(hdparentId)).getTblDynReport().getReportId();
	                    	companyId = commonService.getTblAdvancePurchaseOrderById(Integer.parseInt(hdmainobjectId)).getTblCompany().getCompanyId();
	                    }else if(APOAmendmentProcessWFLinkId == linkId || APOAmendmentProcessWFLinkId == Integer.parseInt(hdparentlinkId)){
	                    	lst = commonService.getTblCorrigendumById(Integer.parseInt(hdmainobjectId),6);
	                    	contractId = Integer.parseInt(lst.get(0)[1].toString());
		                   	 if(lst!=null && !lst.isEmpty()){
		                   		 companyId = commonService.getTblAdvancePurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblCompany().getCompanyId();
		                   		 reportId = commonService.getTblAdvancePurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblDynReport().getReportId();
		                   	 }
	                    }else if(POProcessWFLinkId == linkId || POProcessWFLinkId == Integer.parseInt(hdparentlinkId) || poCancelPIWLinkId == Integer.parseInt(hdparentlinkId)){
	                    	reportId = commonService.getTblPurchaseOrderByObject(Integer.parseInt(hdparentId)).getTblDynReport().getReportId();
	                    	companyId = commonService.getTblPurchaseOrderById(Integer.parseInt(hdmainobjectId)).getTblCompany().getCompanyId();
	                    }else if(POAmendmentProcessWFLinkId == linkId || POAmendmentProcessWFLinkId == Integer.parseInt(hdparentlinkId)){
	                    	lst = commonService.getTblCorrigendumById(Integer.parseInt(hdmainobjectId),7);
	                    	contractId = Integer.parseInt(lst.get(0)[1].toString());
		                   	 if(lst!=null && !lst.isEmpty()){
		                   		 companyId = commonService.getTblPurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblCompany().getCompanyId();
		                   		 reportId = commonService.getTblPurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblDynReport().getReportId();
		                   	 }
	                    }
	                }
	                
	                //Offline Apo & PO
	                if(POOfflineProcessWFLinkId == linkId || APOOfflineProcessWFLinkId == linkId || APOOfflineAmendmentProcessWFLinkId == linkId || POOfflineAmendmentProcessWFLinkId == linkId || ("callback".equalsIgnoreCase(hdfrm) && (POOfflineProcessWFLinkId == Integer.parseInt(hdparentlinkId) || APOOfflineProcessWFLinkId == Integer.parseInt(hdparentlinkId) || APOOfflineAmendmentProcessWFLinkId == Integer.parseInt(hdparentlinkId) || POOfflineAmendmentProcessWFLinkId == Integer.parseInt(hdparentlinkId))) || apoOfflineCancelPIWLinkId == Integer.parseInt(hdparentlinkId) || poOfflineCancelPIWLinkId == Integer.parseInt(hdparentlinkId)){
	                    newModuleId = 6;
	                    if(APOOfflineProcessWFLinkId == linkId || APOOfflineProcessWFLinkId == Integer.parseInt(hdparentlinkId) || apoOfflineCancelPIWLinkId == Integer.parseInt(hdparentlinkId)){
	                    	reportId = commonService.getTblAdvancePurchaseOrderByObject(Integer.parseInt(hdparentId)).getTblDynReport().getReportId();
	                    	companyId = commonService.getTblAdvancePurchaseOrderById(Integer.parseInt(hdmainobjectId)).getTblCompany().getCompanyId();
	                    }else if(APOOfflineAmendmentProcessWFLinkId == linkId || APOOfflineAmendmentProcessWFLinkId == Integer.parseInt(hdparentlinkId)){
	                    	lst = commonService.getTblCorrigendumById(Integer.parseInt(hdmainobjectId),6);
	                    	contractId = Integer.parseInt(lst.get(0)[1].toString());
		                   	 if(lst!=null && !lst.isEmpty()){
		                   		 companyId = commonService.getTblAdvancePurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblCompany().getCompanyId();
		                   		 reportId = commonService.getTblAdvancePurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblDynReport().getReportId();
		                   	 }
	                    }else if(POOfflineProcessWFLinkId == linkId || POOfflineProcessWFLinkId == Integer.parseInt(hdparentlinkId) || poOfflineCancelPIWLinkId == Integer.parseInt(hdparentlinkId)){
	                    	reportId = commonService.getTblPurchaseOrderByObject(Integer.parseInt(hdparentId)).getTblDynReport().getReportId();
	                    	companyId = commonService.getTblPurchaseOrderById(Integer.parseInt(hdmainobjectId)).getTblCompany().getCompanyId();
	                    }else if(POOfflineAmendmentProcessWFLinkId == linkId || POOfflineAmendmentProcessWFLinkId == Integer.parseInt(hdparentlinkId)){
	                    	lst = commonService.getTblCorrigendumById(Integer.parseInt(hdmainobjectId),7);
	                    	contractId = Integer.parseInt(lst.get(0)[1].toString());
		                   	 if(lst!=null && !lst.isEmpty()){
		                   		 companyId = commonService.getTblPurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblCompany().getCompanyId();
		                   		 reportId = commonService.getTblPurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblDynReport().getReportId();
		                   	 }
	                    }
	                }
	                String message = "";
	                if(workflowService.getWorkflowData(Integer.parseInt(hdmainobjectId),linkId)){ //Server Side Validation Fire when WorkFlow Entry null and lastUserId=0  Changes Bug Id:#30885
		                if(newModuleId==3){
		                	/* Changes Apply for ConfigureDate Workflow through Validate Contract Rule #31144 */
		                	if(Integer.parseInt(hdparentlinkId)==ConfiguredateProcessWFLinkId || Integer.parseInt(hdparentlinkId)== bidOpeningReportProcessWFLinkId || Integer.parseInt(hdparentlinkId)==bidEvaluationReportProcessWFLinkId ){
			                	message = commonService.getMessageFromValidateContractRule(abcUtility.getSessionClientId(request),Integer.parseInt(hdparentId),Integer.parseInt(hdeventTypeId),abcUtility.getSessionUserId(request),reportId,linkId,companyId,contractId);
			                	if(Integer.parseInt(hdparentlinkId)== bidOpeningReportProcessWFLinkId || Integer.parseInt(hdparentlinkId)==bidEvaluationReportProcessWFLinkId){
									if(!message.equals("Success")){
										msg = message;
									}
			                	}
		                	}else{
		                		message = commonService.getMessageFromValidateTenderRule(abcUtility.getSessionClientId(request),Integer.parseInt(hdparentId),abcUtility.getSessionUserId(request),linkId);
		                	}
		                }else if(newModuleId==6){
		                	message = commonService.getMessageFromValidateContractRule(abcUtility.getSessionClientId(request),Integer.parseInt(hdparentId),Integer.parseInt(hdeventTypeId),abcUtility.getSessionUserId(request),reportId,linkId,companyId,contractId);
		                	msg = message;
		                }else if(newModuleId==2){
		                	message = commonService.getMessageFromValidateIndentRule(abcUtility.getSessionClientId(request),Integer.parseInt(hdparentId),abcUtility.getSessionUserId(request),linkId);
		                }else if(newModuleId==13){
		                	message = commonService.getMessageFromValidateOnlineContractRule(abcUtility.getSessionClientId(request),Integer.parseInt(hdparentId),abcUtility.getSessionUserId(request),linkId);
		                }
		                if(!message.equals("Success")){
		        			isValidatedFromServerSide = false;
		            	}
	                }else if(newModuleId==3)   {
	                	if(Integer.parseInt(hdparentlinkId)==noticeAndDocumentsWFLinkId || Integer.parseInt(hdparentlinkId)== corriProcessWFLinkId){
	                		message = commonService.getMessageFromValidateTenderRule(abcUtility.getSessionClientId(request),Integer.parseInt(hdparentId),abcUtility.getSessionUserId(request),linkId);
		                	if(!message.equals("Success")){
			        			isValidatedFromServerSide = false;
			        			msg = message;
			            	}
	                	}
	                }
	                
                }
                if(isValidatedFromServerSide){
	                if("prces".equalsIgnoreCase(hdfrm) || "callback".equalsIgnoreCase(hdfrm) || "pullfile".equalsIgnoreCase(hdfrm) || "true".equalsIgnoreCase(hdcurrentStack)){
	                    tblWorkflow.setWorkflowId(Integer.parseInt(workflowId));
	                    tblWorkflowDetail.setTblWorkflow(tblWorkflow);
	                    //Rekmove if because this condition is stoping creator to approve workflow #28769
	                   // if(!workflowService.checkDuplicationData(tblWorkflow.getWorkflowId(),tblWorkflow.getTblUserLogin().getUserId())){
	                    
	                    boolean isWorkFlowExists=workflowService.getWorkflowExistOrNot(Integer.parseInt(hdmainobjectId), Integer.parseInt(hdparentId));
	                    if(isWorkFlowExists && ((Integer.parseInt(hddbcurrentUserId) == userId && ("prces".equalsIgnoreCase(hdfrm) || "pfiwf".equalsIgnoreCase(hdfrm))) ||  ((Integer.parseInt(hddbcurrentUserId) != userId && "callback".equalsIgnoreCase(hdfrm))) || ("pullfile".equalsIgnoreCase(hdfrm))))
	                        flag = workflowService.updatecurrentUserId(tblWorkflow,tblWorkflowDetail,switchId,fileCloseWorkflowDetailId,Integer.parseInt(hdworkflowType)); // Server side validation while One officer reset workflow and other same time approve workflow #31004
	                    
	                    if(!isWorkFlowExists){
	                    	msg = "msg_file_not_processed"; /*Changes Bug Id:#32246*/
	                    }
	                    //}
	                }else{
	                	if(workflowService.checkEntryTblWorkflow(Integer.parseInt(hdeventTypeId),Integer.parseInt(hdmainobjectId),Integer.parseInt(hdlinkId),Integer.parseInt(hdparentId))==0){
	                        flag = workflowService.addTblWorkflow(tblWorkflow, tblWorkflowDetail);
	                    }else{
	                    	tblWorkflow.setWorkflowId(Integer.parseInt(workflowId));
	                        tblWorkflowDetail.setTblWorkflow(tblWorkflow);
	                        if(Integer.parseInt(workflowId) != 0){
	                        	flag = workflowService.updatecurrentUserId(tblWorkflow,tblWorkflowDetail,switchId,fileCloseWorkflowDetailId,Integer.parseInt(hdworkflowType));
	                        }else{
	                        	flag = false;
	                        }
	                    }
	                }
                }
                if(flag){
                	 if((Integer.parseInt(selWrkflwAction)!=7 || Integer.parseInt(selWrkflwAction)!=8) && "prces".equalsIgnoreCase(hdfrm) && assignUserId!=userId && (Integer.parseInt(hdworkflowType)==3 || hdUserType!="1")){
                		  boolean success = dynamicFieldService.addDynamicFieldValueProcess(dynamicFieldService.dynFieldSetUp(request.getParameterMap(), request),clientId,Integer.parseInt(hdlinkId),tblWorkflowDetail.getWorkflowDetailId(),userId);
                	 }                		 
                    if(txtHidDocIds!=null && !"".equalsIgnoreCase(txtHidDocIds)){
                        fileUploadService.updateOfficerDocsObjectId(txtHidDocIds, tblWorkflowDetail.getWorkflowDetailId());
                    }
                    Map<String, Object> paramMap =  new HashMap<String, Object>();
                    paramMap.put("EventId", hdparentId);
                    paramMap.put("EventType", commonService.getEventType(Integer.parseInt(hdeventTypeId)).get(0).toString());
                    paramMap.put("SubDomainName", clientService.getClientNameById(clientId));
                    if(Integer.parseInt(selWrkflwAction)==4 || Integer.parseInt(selWrkflwAction)==5 || Integer.parseInt(selWrkflwAction)==6){
                        compoSearchUserid = String.valueOf(assignUserId);
                    }
                    if(Integer.parseInt(selWrkflwAction)==4 || Integer.parseInt(selWrkflwAction)==5){
                        sendmailbool = true;
                        paramMap.put("ApprovedOrRejected", "rejected");
                        
                        String encryptUrlStr = encryptDecryptUtils.encrypt("workflow/buyer/processanytoanyworkflow/"+hdeventTypeId+"/"+hdlinkId+"/"+hdlinkId+"/"+hdparentId+"/"+hdmainobjectId+"/"+hdtabId+"/false");
                        String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                        paramMap.put("link", hrefStr);
                        
                        if(Integer.parseInt(selWrkflwAction)==5){
                            paramMap.put("ApprovedOrRejected", "approved");
                            /*
                             * To send Mail to bidders for Tender cancelled
                             * 
                             * */
                            if(switchId == 4){
                            	   Object[] tenderDetails = workflowService.getTenderDetails(Integer.parseInt(hdparentId),tenderCancelLink);
                                   if(tenderDetails!=null){
                            	   Map<String, Object> cancelTenderMap = new HashMap<String, Object>();
                                   cancelTenderMap.put("EventId", hdparentId);
                                   cancelTenderMap.put("ReferenceNo",tenderDetails[0]);
                                   cancelTenderMap.put("EventType", commonService.getEventType(Integer.parseInt(hdeventTypeId)).get(0).toString());
                                   cancelTenderMap.put("EventBrief", tenderDetails[1]);
                                   cancelTenderMap.put("DepartmentName", tenderDetails[3]);
                                   cancelTenderMap.put("CancellationRemarks",tenderDetails[4]);
    							   
                                   if(Integer.parseInt(idfcClientId) == clientId){
                                       StringBuilder ccEmailIds = new StringBuilder();
                                       String deptOfficerLogin = "";
                                       List<TblUserLogin> list = commonService.getUserLoginById(Integer.parseInt(tenderDetails[2].toString()));
                                       if(list!=null && !list.isEmpty()){
                                       	deptOfficerLogin = list.get(0).getLoginId();
                                       }
                                       ccEmailIds.append(idfcEmailCC).append(",").append(deptOfficerLogin);
                                       cancelTenderMap.put("cc", ccEmailIds);
                                   }
                                   encryptUrlStr = encryptDecryptUtils.encrypt("etender/buyer/viewtender/"+hdparentId);
                                   hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                                   cancelTenderMap.put("link", hrefStr);
                                   cancelTenderMap.put("SubDomainName",clientService.getClientNameByClientId(abcUtility.getSessionClientId(request)));
                                   mailContentUtillity.dynamicMailGeneration("53", ""+userId, String.valueOf(hdparentId), cancelTenderMap, "");	
                            }
                           }
                        }
                    }
                    paramMap.put("OfficerName",sessionBean.getFullName());
                    
                    switch(Integer.parseInt(hdmoduleId)){
                        case 3:
                                if(sendmailbool){ // Approve/Reject
                                	   		                         
                                    mailContentUtillity.dynamicMailGeneration("37", String.valueOf(compoSearchUserid), String.valueOf(hdparentId),paramMap,hdlinkId);
                                }else if(Integer.parseInt(selWrkflwAction)==7){ // callback
                                	
                                	 mailContentUtillity.dynamicMailGeneration("159", String.valueOf(hddbcurrentUserId), String.valueOf(hdparentId),paramMap,hdlinkId);
                                }
                                else if(Integer.parseInt(selWrkflwAction)==8){ // pull file
                                	
                               	 mailContentUtillity.dynamicMailGeneration("161", String.valueOf(hddbcurrentUserId), String.valueOf(hdparentId),paramMap,hdlinkId);
                               }
                                else{ // Process in workflow
                                	
                                	 String encryptUrlStr = encryptDecryptUtils.encrypt("workflow/buyer/processanytoanyworkflow/"+hdeventTypeId+"/"+hdlinkId+"/"+hdlinkId+"/"+hdparentId+"/"+hdmainobjectId+"/"+hdtabId+"/true");
    		                         String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
    		                         paramMap.put("link", hrefStr);
    		                         
                                    mailContentUtillity.dynamicMailGeneration("36", String.valueOf(compoSearchUserid), String.valueOf(hdparentId),paramMap,hdlinkId);
                                }
                                break;
                        case 2:
                                if(sendmailbool){
                                	
                                    mailContentUtillity.dynamicMailGeneration("144", String.valueOf(compoSearchUserid), String.valueOf(hdparentId),paramMap,hdlinkId);
                                    
                                }else if(Integer.parseInt(selWrkflwAction)==7){ // callback
                                	
                               	 mailContentUtillity.dynamicMailGeneration("160", String.valueOf(hddbcurrentUserId), String.valueOf(hdparentId),paramMap,hdlinkId);
                                }
                                else if(Integer.parseInt(selWrkflwAction)==8){// pull file 
                                	
                                  	 mailContentUtillity.dynamicMailGeneration("162", String.valueOf(hddbcurrentUserId), String.valueOf(hdparentId),paramMap,hdlinkId);
                                }else{
                            	   
                            	   String encryptUrlStr = encryptDecryptUtils.encrypt("workflow/buyer/processanytoanyworkflow/"+hdeventTypeId+"/"+hdlinkId+"/"+hdlinkId+"/"+hdparentId+"/"+hdmainobjectId+"/"+hdtabId+"/true");
                            	   String hrefStr = "<a href=\"javascript:void(0);\" onClick=\"viewMailLinkDetails(' " + encryptUrlStr + " ');\">click here</a>"; 
                            	   paramMap.put("link", hrefStr);
                                    mailContentUtillity.dynamicMailGeneration("143", String.valueOf(compoSearchUserid), String.valueOf(hdparentId),paramMap,hdlinkId);
                                }
                                break;
                        case 13:         
                        	commonService.contractSummary(contractId, paramMap, clientId);
                            if(sendmailbool){ // Approve/Reject
                            	String to=commonService.getEmailByUserId(Integer.parseInt(compoSearchUserid));
                            	paramMap.put("to",to);
                                mailContentUtillity.dynamicMailGeneration("340", String.valueOf(compoSearchUserid), String.valueOf(hdparentId),paramMap,hdlinkId);
                            }else if(Integer.parseInt(selWrkflwAction)==7){ // callback      
                             	String to=commonService.getEmailByUserId(Integer.parseInt(hddbcurrentUserId));
                             	paramMap.put("to", to);
                            	 mailContentUtillity.dynamicMailGeneration("342", String.valueOf(hddbcurrentUserId), String.valueOf(hdparentId),paramMap,hdlinkId);
                            }
                            else{ // Process in workflow
                            	String to=commonService.getEmailByUserId(Integer.parseInt(compoSearchUserid));
                            	paramMap.put("to",to);
                                mailContentUtillity.dynamicMailGeneration("341", String.valueOf(compoSearchUserid), String.valueOf(hdparentId),paramMap,hdlinkId);
                            }
                            break;
                        default:
                                break;    
                    }
                    if(Integer.parseInt(hdtabId)==0){
                        returnStr = "redirect:/workflow/buyer/workflowprocess"+encryptDecryptUtils.generateRedirect("workflow/buyer/workflowprocess", request);
                    }else{
                        switch(Integer.parseInt(hdmoduleId)){
                            case 3:
                                    returnStr = "redirect:/etender/buyer/tenderdashboard/"+hdparentId+"/"+hdtabId+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+hdparentId+"/"+hdtabId, request);
                                    break;
                            case 2:
                                    returnStr = "redirect:/eindent/buyer/indentdashboard/"+hdparentId+encryptDecryptUtils.generateRedirect("eindent/buyer/indentdashboard/"+hdparentId, request);
                                    break;
                            case 13:
                                returnStr = "redirect:/contract/buyer/contractBuyerDashboard/"+hdparentId+"/"+hdtabId+encryptDecryptUtils.generateRedirect("contract/buyer/contractBuyerDashboard/"+hdparentId+"/"+hdtabId, request);
                                break;       
                            default:
                                    break;    
                        }
                    }
                    msg = "msg_create_workflow_success";
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),msg);
                }else{
                    if(Integer.parseInt(hdtabId)==0){
                        returnStr = "redirect:/workflow/buyer/workflowprocess"+encryptDecryptUtils.generateRedirect("workflow/buyer/workflowprocess", request);
                    }else{                        
                      switch(Integer.parseInt(hdmoduleId)){
                        case 3:
                                returnStr = "redirect:/etender/buyer/tenderdashboard/"+hdparentId+"/"+hdtabId+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+hdparentId+"/"+hdtabId, request);
                                break;
                        case 2:
                                returnStr = "redirect:/eindent/buyer/indentdashboard/"+hdparentId+encryptDecryptUtils.generateRedirect("eindent/buyer/indentdashboard/"+hdparentId, request);
                                break;
                        case 13:
	                            returnStr = "redirect:/contract/buyer/contractBuyerDashboard/"+hdparentId+"/"+hdtabId+encryptDecryptUtils.generateRedirect("contract/buyer/contractBuyerDashboard/"+hdparentId+"/"+hdtabId, request);
	                            break;            
                        default:
                                break;    
                    }
                    }
                    
                    if(msg.equals("")){
                    	msg = "msg_workflow_already_proceed";
                    }
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),msg);
                }
            }else{
                return REDIRECT_SESSION_EXPIRED;
            }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally{
        	if(Integer.parseInt(hdmoduleId) == 3){
        		String remarks = selWrkflwAction.equals("1") ? checkrecommendfileaction : selWrkflwAction.equals("2") ? checkfwdfileaction : selWrkflwAction.equals("3") ? checkapprovedinwrkaction : getAnytoanyWFSubmittedRemarks;
        		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(hdlinkId), remarks,Integer.parseInt(hdparentId),tblWorkflowDetail.getTblWorkflow().getWorkflowId(),"");
        	}else if(Integer.parseInt(hdmoduleId) == 2){
        		auditTrailService.makeIndentAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(hdlinkId), getAnytoanyWFSubmittedRemarks,Integer.parseInt(hdparentId),tblWorkflowDetail.getTblWorkflow().getWorkflowId(),"");
        	}else if(Integer.parseInt(hdmoduleId) == 13){
        		String remarks = selWrkflwAction.equals("1") ? checkrecommendfileaction : selWrkflwAction.equals("2") ? checkfwdfileaction : selWrkflwAction.equals("3") ? checkapprovedinwrkaction : getAnytoanyWFSubmittedRemarks;
        		auditTrailService.makeOnlineContractAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(hdlinkId), remarks,Integer.parseInt(hdparentId),tblWorkflowDetail.getTblWorkflow().getWorkflowId(),"");
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), Integer.parseInt(hdlinkId), getAnytoanyWFSubmittedRemarks,tblWorkflowDetail.getTblWorkflow().getWorkflowId(),Integer.parseInt(hdparentId),"");
        	}
        }
        return returnStr;
    }

    /** get pending and processed tab for Any to Any workflow process Report
     * @author darshan.shah
     * @param modelMap
     * @param request
     * @return
     */
    @RequestMapping(value = "/workflowprocess/{enc}", method = RequestMethod.GET)
    public String workFlowProcess(ModelMap modelMap, HttpServletRequest request) {
    	 int clientId = abcUtility.getSessionClientId(request);
    	 int userId = abcUtility.getSessionUserId(request);
    	 
        try {
            modelMap.addAttribute("reportId", workflowPendingReportId);
            reportGeneratorService.getReportConfigDetails(workflowPendingReportId, modelMap);
           List<Object[]> pendingtaskcount = reportGeneratorService.myPendingTask(userId,clientId);
           modelMap.addAttribute("pendingtaskcount", pendingtaskcount);
           List<Object[]> processtaskcount = reportGeneratorService.myProcessedTask(userId,clientId);
           modelMap.addAttribute("processtaskcount", processtaskcount);
        } catch (Exception ex) {
            return exceptionHandlerService.writeLog(ex);
        } finally {
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),workflowmypendingtasksLinkId, getWorkflowProcessMessage, 0, 0);
        }
        return "common/WorkflowProcess";
    }
    
    /*
     * author : heeral.soni
     * used to get workflow processed task
     */
    @RequestMapping(value = "/processedworkflowprocess/{enc}", method = RequestMethod.GET)
    public String processedWorkflowProcess(ModelMap modelMap, HttpServletRequest request) {
    	 int clientId = abcUtility.getSessionClientId(request);
    	 int userId = abcUtility.getSessionUserId(request);
        try {
                modelMap.addAttribute("reportId", workflowProcessedReportId);
                reportGeneratorService.getReportConfigDetails(workflowProcessedReportId, modelMap);
                List<Object[]> pendingtaskcount = reportGeneratorService.myPendingTask(userId,clientId);
                modelMap.addAttribute("pendingtaskcount", pendingtaskcount);
                List<Object[]> processtaskcount = reportGeneratorService.myProcessedTask(userId,clientId);
                modelMap.addAttribute("processtaskcount", processtaskcount);
        } catch (Exception ex) {
                return exceptionHandlerService.writeLog(ex);
        } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),workflowProcessedTasksLinkId, getWorkflowProcessedMessage, 0, 0);
        }
        return "common/ManageProcessedWorkflow";
    }
    
    /*
     * author : heeral.soni
     * used to get workflow pullup task
     */
    @RequestMapping(value = "/pullupworkflowprocess/{enc}", method = RequestMethod.GET)
    public String pullUpWorkflowProcess(ModelMap modelMap, HttpServletRequest request) {
        try {
                modelMap.addAttribute("reportId", workflowPullUpReportId);
                reportGeneratorService.getReportConfigDetails(workflowPullUpReportId, modelMap);
        } catch (Exception ex) {
                return exceptionHandlerService.writeLog(ex);
        } finally {
                auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()),workflowPullUpLinkId, getWorkflowPulUpMessage, 0, 0);
        }
        return "common/ManagePullUpWorkflow";
    }
    
    /**
     * view controller for pre-bid committee and NIT Documents for Processed Workflow File
     * @param mainobjectId
     * @param parentId
     * @param request
     * @param modelMap
     * @return 
     */
    @RequestMapping(value = "/viewPreBidCommitteeDoc/{parentId}/{mainobjectId}/{linkId}/{moduleId}/{vapphistLinkId}/{enc}", method = RequestMethod.GET)
    public String getPreBidCommitteeDoc(@PathVariable("parentId") int parentId,@PathVariable("mainobjectId") int mainobjectId,@PathVariable("linkId") int linkId,@PathVariable("moduleId") int moduleId,@PathVariable("vapphistLinkId") int vapphistLinkId,HttpServletRequest request,ModelMap modelMap) {
        int doclinkId = 0;
        int docstatus = 0;
        try {
            if(linkId==preBidMeetingWfLinkId){
                doclinkId = preBidMeetingUploadDocLinkId;
                docstatus = officerDocStatusApprove;
            }else if(linkId==noticeAndDocumentsWFLinkId){
                doclinkId = noticeanddocumentuploadLinkId;
                docstatus = -1; //officerDocStatusPending;
            }
            List<Object[]> singleUserDocumentDetails =fileUploadService.getOfficerDocs(parentId, abcUtility.getSessionClientId(request), doclinkId,docstatus);
            if(singleUserDocumentDetails!=null && !singleUserDocumentDetails.isEmpty()){
                modelMap.addAttribute("singleUserDocumentDetails", singleUserDocumentDetails);
            }
            modelMap.addAttribute("MultiUserHistDetail",false);
            modelMap.addAttribute("SingleUserHistDetail",false);
            modelMap.addAttribute("objectId",mainobjectId);
            modelMap.addAttribute("linkId",linkId);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally {
            switch(moduleId){
                case 3:
                        auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), vapphistLinkId, getAnytoanyWFdocsRemarks, parentId,mainobjectId, "");
                        break;
                default:
                        auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), vapphistLinkId, getAnytoanyWFdocsRemarks, mainobjectId, parentId,"");
                        break;    
            }
        }
        return "/common/ProcessAnytoAnyWFHistory";
    }
    
    private List<TblWorkflowAction> getWFActionList(List<TblWorkflowAction> list,String from,int lastdbActionId,int workflowType,List<Object[]> reviewrsList,int currentUserId){
    	List<TblWorkflowAction> lstWorkflowActions  = new ArrayList<TblWorkflowAction>();
        boolean isApprover = false;
        boolean isReviewrExist = false;
        String lastReviewerId=null;
        boolean isLastReviewr = false;
        if(workflowType==2 || workflowType==4 || workflowType==5) {
            if(reviewrsList!=null && !reviewrsList.isEmpty()){
                for (Object[] obj : reviewrsList) {
                    if("2".equalsIgnoreCase(obj[6].toString())){
                        isReviewrExist = true;
                        lastReviewerId=obj[7].toString();
                    }
                    if("3".equalsIgnoreCase(obj[6].toString()) && String.valueOf(currentUserId).equalsIgnoreCase(obj[7].toString())){
                        isApprover = true;
                    }                                    
                }
                if(isReviewrExist && lastReviewerId.equalsIgnoreCase(String.valueOf(currentUserId)))
                {
                	isLastReviewr=true;
                }
            }          
        }        
        for (TblWorkflowAction tblWorkflowAction : list) {
            if("pfiwf".equalsIgnoreCase(from)){
            	
            	if(workflowType==2 || workflowType==4 || workflowType==5){
            		
            		if(isReviewrExist){
            			 if(isApprover){
                             if(tblWorkflowAction.getWorkflowActionId()==4 || tblWorkflowAction.getWorkflowActionId()==5 || tblWorkflowAction.getWorkflowActionId()==6){
                                 lstWorkflowActions.add(tblWorkflowAction);
                             }
                         }else if(isLastReviewr){
                         	 if(tblWorkflowAction.getWorkflowActionId()==1){
                                  lstWorkflowActions.add(tblWorkflowAction);
                              }
                         }else{
			            	if(tblWorkflowAction.getWorkflowActionId()==2){
			                    lstWorkflowActions.add(tblWorkflowAction);
			                }
                         }
            		}
            		else{
            			 if(isApprover){
                             if(tblWorkflowAction.getWorkflowActionId()==4 || tblWorkflowAction.getWorkflowActionId()==5 || tblWorkflowAction.getWorkflowActionId()==6){
                                 lstWorkflowActions.add(tblWorkflowAction);
                             }
                         }else{
	            			if(tblWorkflowAction.getWorkflowActionId()==1){
			                    lstWorkflowActions.add(tblWorkflowAction);
			                }
                         }
            		}
	            }
            	else{
            		if(tblWorkflowAction.getWorkflowActionId()==1 || tblWorkflowAction.getWorkflowActionId()==2){
                        lstWorkflowActions.add(tblWorkflowAction);
                    }
            	}
            }else if("prces".equalsIgnoreCase(from)){
                if(workflowType==3){
                    if(lastdbActionId!=0){
                        if(lastdbActionId==2){
                            if(tblWorkflowAction.getWorkflowActionId()==2 || tblWorkflowAction.getWorkflowActionId()==6){
                                lstWorkflowActions.add(tblWorkflowAction);
                            }
                        }else if(lastdbActionId==1){
                        	/*Bug #25012 For removed condition getWorkflowActionId=1 and 2  */
                        	if(tblWorkflowAction.getWorkflowActionId()==4 || tblWorkflowAction.getWorkflowActionId()==5 || tblWorkflowAction.getWorkflowActionId()==6){
                                lstWorkflowActions.add(tblWorkflowAction);
                            }
                        }else{
                        	if(tblWorkflowAction.getWorkflowActionId()==1 || tblWorkflowAction.getWorkflowActionId()==2){
                                lstWorkflowActions.add(tblWorkflowAction);
                            }
                        }
                    }
                }else if(workflowType==2 || workflowType==4 || workflowType==5){
                	 if(lastdbActionId==9){
                		 if(isReviewrExist){
                			 if(tblWorkflowAction.getWorkflowActionId()==2){
                                 lstWorkflowActions.add(tblWorkflowAction);
                             }
                		 }else{
                			 if(tblWorkflowAction.getWorkflowActionId()==1){
                                 lstWorkflowActions.add(tblWorkflowAction);
                             }
                		 }                     	
                     }else  if(lastdbActionId!=0){
                        if(lastdbActionId==1 || lastdbActionId==2 || lastdbActionId==7 || lastdbActionId==8){
                            if(isReviewrExist){
                                if(isApprover){
                                    if(tblWorkflowAction.getWorkflowActionId()==4 || tblWorkflowAction.getWorkflowActionId()==5 || tblWorkflowAction.getWorkflowActionId()==6){
                                        lstWorkflowActions.add(tblWorkflowAction);
                                    }
                                }else if(isLastReviewr){
                                	 if(tblWorkflowAction.getWorkflowActionId()==1){
                                         lstWorkflowActions.add(tblWorkflowAction);
                                     }
                                }else{
                                    if(tblWorkflowAction.getWorkflowActionId()==2){
                                        lstWorkflowActions.add(tblWorkflowAction);
                                    }
                                }
                            }else{
                            	 if(isApprover){
                                     if(tblWorkflowAction.getWorkflowActionId()==4 || tblWorkflowAction.getWorkflowActionId()==5 || tblWorkflowAction.getWorkflowActionId()==6){
                                         lstWorkflowActions.add(tblWorkflowAction);
                                     }
                                 }else {
                                    if(tblWorkflowAction.getWorkflowActionId()==1){
                                        lstWorkflowActions.add(tblWorkflowAction);
                                    }
                                }
                            }
                        }else if(lastdbActionId==4 || lastdbActionId==6){
                        	if(isReviewrExist){
	                        	if(tblWorkflowAction.getWorkflowActionId()==2){
	                                lstWorkflowActions.add(tblWorkflowAction);
	                            }
                        	}
                        	else{
                        		if(tblWorkflowAction.getWorkflowActionId()==1){
	                                lstWorkflowActions.add(tblWorkflowAction);
	                            }
                        	}
                        }
                    }
                }
            }else if("pullfile".equalsIgnoreCase(from)){
                if(tblWorkflowAction.getWorkflowActionId()==8){
                    lstWorkflowActions.add(tblWorkflowAction);
                }
            }else{ //callback
                if(tblWorkflowAction.getWorkflowActionId()==7){
                    lstWorkflowActions.add(tblWorkflowAction);
                }
            }
        }
        return lstWorkflowActions;
    }
    
    private List<TblWorkflowAction> getWFActionList(List<TblWorkflowAction> list,String from,int lastdbActionId,int workflowType,List<Object[]> reviewrsList,int currentUserId,int currentUser,int createdBy){
    	List<TblWorkflowAction> lstWorkflowActions  = new ArrayList<TblWorkflowAction>();
        boolean isApprover = false;
        boolean isReviewrExist = false;
        String lastReviewerId=null;
        boolean isLastReviewr = false;
        if(workflowType==2 || workflowType==4 || workflowType==5) {
            if(reviewrsList!=null && !reviewrsList.isEmpty()){
                for (Object[] obj : reviewrsList) {
                    if("2".equalsIgnoreCase(obj[6].toString())){
                        isReviewrExist = true;
                        lastReviewerId=obj[7].toString();
                    }
                    if("3".equalsIgnoreCase(obj[6].toString()) && String.valueOf(currentUserId).equalsIgnoreCase(obj[7].toString())){
                        isApprover = true;
                    }                                    
                }
                if(isReviewrExist && lastReviewerId.equalsIgnoreCase(String.valueOf(currentUserId)))
                {
                	isLastReviewr=true;
                }
            }          
        }        
        for (TblWorkflowAction tblWorkflowAction : list) {
            if("pfiwf".equalsIgnoreCase(from)){
            	
            	if(workflowType==2 || workflowType==4 || workflowType==5){
            		
            		if(isReviewrExist){
            			 if(isApprover){
                             if(tblWorkflowAction.getWorkflowActionId()==4 || tblWorkflowAction.getWorkflowActionId()==5 || tblWorkflowAction.getWorkflowActionId()==6){
                                 lstWorkflowActions.add(tblWorkflowAction);
                             }
                         }else if(isLastReviewr){
                         	 if(tblWorkflowAction.getWorkflowActionId()==1){
                                  lstWorkflowActions.add(tblWorkflowAction);
                              }
                         }else{
			            	if(tblWorkflowAction.getWorkflowActionId()==2){
			                    lstWorkflowActions.add(tblWorkflowAction);
			                }
                         }
            		}
            		else{
            			 if(isApprover){
                             if(tblWorkflowAction.getWorkflowActionId()==4 || tblWorkflowAction.getWorkflowActionId()==5 || tblWorkflowAction.getWorkflowActionId()==6){
                                 lstWorkflowActions.add(tblWorkflowAction);
                             }
                         }else{
	            			if(tblWorkflowAction.getWorkflowActionId()==1){
			                    lstWorkflowActions.add(tblWorkflowAction);
			                }
                         }
            		}
	            }
            	else{
            		if(tblWorkflowAction.getWorkflowActionId()==1 || tblWorkflowAction.getWorkflowActionId()==2){
                        lstWorkflowActions.add(tblWorkflowAction);
                    }
            	}
            }else if("prces".equalsIgnoreCase(from)){
                if(workflowType==3){
                    if(lastdbActionId!=0){
                       if(lastdbActionId==1 || lastdbActionId==2 || lastdbActionId==3  || (lastdbActionId == 7 && currentUser != createdBy) || (lastdbActionId == 6 && currentUser != createdBy)){
                        	if(tblWorkflowAction.getWorkflowActionId()==1 || tblWorkflowAction.getWorkflowActionId()==2 || tblWorkflowAction.getWorkflowActionId()==3 || tblWorkflowAction.getWorkflowActionId()==4 || tblWorkflowAction.getWorkflowActionId()==5 || tblWorkflowAction.getWorkflowActionId()==6){
                                lstWorkflowActions.add(tblWorkflowAction);
                            }
                        }else{
                        	if(tblWorkflowAction.getWorkflowActionId()==1 || tblWorkflowAction.getWorkflowActionId()==2){
                                lstWorkflowActions.add(tblWorkflowAction);
                            }
                        }
                    }
                }else if(workflowType==2 || workflowType==4 || workflowType==5){
                	 if(lastdbActionId==9){
                		 if(isReviewrExist){
                			 if(tblWorkflowAction.getWorkflowActionId()==2){
                                 lstWorkflowActions.add(tblWorkflowAction);
                             }
                		 }else{
                			 if(tblWorkflowAction.getWorkflowActionId()==1){
                                 lstWorkflowActions.add(tblWorkflowAction);
                             }
                		 }                     	
                     }else  if(lastdbActionId!=0){
                        if(lastdbActionId==1 || lastdbActionId==2 || lastdbActionId==7 || lastdbActionId==8){
                            if(isReviewrExist){
                                if(isApprover){
                                    if(tblWorkflowAction.getWorkflowActionId()==4 || tblWorkflowAction.getWorkflowActionId()==5 || tblWorkflowAction.getWorkflowActionId()==6){
                                        lstWorkflowActions.add(tblWorkflowAction);
                                    }
                                }else if(isLastReviewr){
                                	 if(tblWorkflowAction.getWorkflowActionId()==1){
                                         lstWorkflowActions.add(tblWorkflowAction);
                                     }
                                }else{
                                    if(tblWorkflowAction.getWorkflowActionId()==2){
                                        lstWorkflowActions.add(tblWorkflowAction);
                                    }
                                }
                            }else{
                            	 if(isApprover){
                                     if(tblWorkflowAction.getWorkflowActionId()==4 || tblWorkflowAction.getWorkflowActionId()==5 || tblWorkflowAction.getWorkflowActionId()==6){
                                         lstWorkflowActions.add(tblWorkflowAction);
                                     }
                                 }else {
                                    if(tblWorkflowAction.getWorkflowActionId()==1){
                                        lstWorkflowActions.add(tblWorkflowAction);
                                    }
                                }
                            }
                        }else if(lastdbActionId==4 || lastdbActionId==6){
                        	if(isReviewrExist){
	                        	if(tblWorkflowAction.getWorkflowActionId()==2){
	                                lstWorkflowActions.add(tblWorkflowAction);
	                            }
                        	}
                        	else{
                        		if(tblWorkflowAction.getWorkflowActionId()==1){
	                                lstWorkflowActions.add(tblWorkflowAction);
	                            }
                        	}
                        }
                    }
                }
            }else if("pullfile".equalsIgnoreCase(from)){
                if(tblWorkflowAction.getWorkflowActionId()==8){
                    lstWorkflowActions.add(tblWorkflowAction);
                }
            }else{ //callback
                if(tblWorkflowAction.getWorkflowActionId()==7){
                    lstWorkflowActions.add(tblWorkflowAction);
                }
            }
        }
        return lstWorkflowActions;
    }
    
    /**
     * @author manoj.gadhavi
     * @param request
     * @param redirectAttributes
     * @return
     */
    @RequestMapping(value = "/resetworkflow", method = RequestMethod.POST)
    public String resetWorkflow(HttpServletRequest request,RedirectAttributes redirectAttributes) {
    	
    	String returnStr = "";
    	int eventTypeId = 0;
    	int parentlinkId = 0;
    	int linkId = 0;
    	int parentId = 0;
    	int objectId = 0;
    	int tabId = 0;
    	int userId = 0;
    	int moduleId = 0;
    	String msg = "";
    	String eventName = "";
        try {
        	linkId = Integer.parseInt(StringUtils.hasLength(request.getParameter("txtLinkId")) ? request.getParameter("txtLinkId") : "0");
        	List<Object[]> list = commonService.getEventIdFromLinkId(linkId);
        	eventName = list.get(0)[2].toString();
        	eventTypeId = Integer.parseInt(StringUtils.hasLength(request.getParameter("txtEventTypeId")) ? request.getParameter("txtEventTypeId") : "0");
        	parentlinkId = Integer.parseInt(StringUtils.hasLength(request.getParameter("txtParentlinkId")) ? request.getParameter("txtParentlinkId") : "0");
        	parentId = Integer.parseInt(StringUtils.hasLength(request.getParameter("txtParentId")) ? request.getParameter("txtParentId") : "0");
        	objectId = Integer.parseInt(StringUtils.hasLength(request.getParameter("txtObjectId")) ? request.getParameter("txtObjectId") : "0");
        	tabId = Integer.parseInt(StringUtils.hasLength(request.getParameter("txtTabId")) ? request.getParameter("txtTabId") : "0");
        	moduleId = Integer.parseInt(StringUtils.hasLength(request.getParameter("txtModuleId")) ? request.getParameter("txtModuleId") : "0");
        	
            
            int sessonUserDetailId = abcUtility.getSessionUserDetailId(request);
            userId = abcUtility.getSessionUserId(request);
            if(userId!=0 && sessonUserDetailId!=0){
                 boolean isValidatedFromServerSide = true;
                 // For server side validataion
                 int reportId = 0;
                 int companyId = 0;
                 List<Object[]> lst = null;
                 int contractId = objectId;
                 
                 //Online Apo & PO
                 if(apoResetWorkflowLinkId == linkId || apoAmendResetWorkflowLinkId == linkId || poResetWorkflowLinkId == linkId || poAmendResetWorkflowLinkId == linkId || apoCancelResetWorkflowLinkId == linkId || poCancelResetWorkflowLinkId == linkId){
                     if(apoResetWorkflowLinkId == linkId || apoCancelResetWorkflowLinkId == linkId){
                     	reportId = commonService.getTblAdvancePurchaseOrderByObject(parentId).getTblDynReport().getReportId();
                     	companyId = commonService.getTblAdvancePurchaseOrderById(objectId).getTblCompany().getCompanyId();
                     }else if(apoAmendResetWorkflowLinkId == linkId){
                    	 lst = commonService.getTblCorrigendumById(objectId,6);
                    	 contractId = Integer.parseInt(lst.get(0)[1].toString());
                    	 if(lst!=null && !lst.isEmpty()){
                    		 companyId = commonService.getTblAdvancePurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblCompany().getCompanyId();
                    		 reportId = commonService.getTblAdvancePurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblDynReport().getReportId();
                    	 }
                      }else if(poResetWorkflowLinkId == linkId || poCancelResetWorkflowLinkId == linkId){
                     	reportId = commonService.getTblPurchaseOrderByObject(parentId).getTblDynReport().getReportId();
                     	companyId = commonService.getTblPurchaseOrderById(objectId).getTblCompany().getCompanyId();
                     }else if (poAmendResetWorkflowLinkId == linkId){
                    	 lst = commonService.getTblCorrigendumById(objectId,7);
                    	 contractId = Integer.parseInt(lst.get(0)[1].toString());
                    	 if(lst!=null && !lst.isEmpty()){
                    		 companyId = commonService.getTblPurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblCompany().getCompanyId();
                    		 reportId = commonService.getTblPurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblDynReport().getReportId();
                    	 }
                     }
                 }
                 
                 //Offline Apo & Po
                 if(apoOfflineResetWorkflowLinkId == linkId || apoOfflineAmendResetWorkflowLinkId == linkId || poOfflineResetWorkflowLinkId == linkId || poOfflineAmendResetWorkflowLinkId == linkId || apoOfflineCancelResetWorkflowLinkId == linkId || poOfflineCancelResetWorkflowLinkId == linkId){
                     if(apoOfflineResetWorkflowLinkId == linkId || apoOfflineCancelResetWorkflowLinkId == linkId){
                     	reportId = commonService.getTblAdvancePurchaseOrderByObject(parentId).getTblDynReport().getReportId();
                     	companyId = commonService.getTblAdvancePurchaseOrderById(objectId).getTblCompany().getCompanyId();
                     }else if(apoOfflineAmendResetWorkflowLinkId == linkId){
                    	 lst = commonService.getTblCorrigendumById(objectId,6);
                    	 contractId = Integer.parseInt(lst.get(0)[1].toString());
                    	 if(lst!=null && !lst.isEmpty()){
                    		 companyId = commonService.getTblAdvancePurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblCompany().getCompanyId();
                    		 reportId = commonService.getTblAdvancePurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblDynReport().getReportId();
                    	 }
                      }else if(poOfflineResetWorkflowLinkId == linkId || poOfflineCancelResetWorkflowLinkId == linkId){
                     	reportId = commonService.getTblPurchaseOrderByObject(parentId).getTblDynReport().getReportId();
                     	companyId = commonService.getTblPurchaseOrderById(objectId).getTblCompany().getCompanyId();
                     }else if (poOfflineAmendResetWorkflowLinkId == linkId){
                    	 lst = commonService.getTblCorrigendumById(objectId,7);
                    	 contractId = Integer.parseInt(lst.get(0)[1].toString());
                    	 if(lst!=null && !lst.isEmpty()){
                    		 companyId = commonService.getTblPurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblCompany().getCompanyId();
                    		 reportId = commonService.getTblPurchaseOrderById(Integer.parseInt(lst.get(0)[1].toString())).getTblDynReport().getReportId();
                    	 }
                     }
                 }
//                 if(hdserverSideValidate.trim().equals("1")){ // For server side validataion
                 String message = "";
                 if(moduleId==3){
                	if(parentlinkId==ConfiguredateProcessWFLinkId || parentlinkId==bidOpeningReportProcessWFLinkId || parentlinkId==bidEvaluationReportProcessWFLinkId ){ 
                		message = commonService.getMessageFromValidateContractRule(abcUtility.getSessionClientId(request),parentId,eventTypeId,abcUtility.getSessionUserId(request),reportId,linkId,companyId,contractId);
                	}else{
                		message = commonService.getMessageFromValidateTenderRule(abcUtility.getSessionClientId(request),parentId,abcUtility.getSessionUserId(request),linkId);
                	}
                 }else if(moduleId==6){
                 	message = commonService.getMessageFromValidateContractRule(abcUtility.getSessionClientId(request),parentId,eventTypeId,abcUtility.getSessionUserId(request),reportId,linkId,companyId,contractId);
                 }else if(moduleId==2){
                 	message = commonService.getMessageFromValidateIndentRule(abcUtility.getSessionClientId(request),parentId,abcUtility.getSessionUserId(request),linkId);
                 }else if(moduleId==13){
                	 message = commonService.getMessageFromValidateOnlineContractRule(abcUtility.getSessionClientId(request),parentId,abcUtility.getSessionUserId(request),linkId);
                 }
                 
        		if(!message.equals("Success")){
        			isValidatedFromServerSide = false;
        			msg = "msg_workflow_complete";
            	}
            	if(isValidatedFromServerSide){
            		List<TblWorkflow> tblWorkflows = workflowService.getWorkflowData(eventTypeId, objectId, parentlinkId, parentId);
            		workflowService.insertWorkflowHistory(eventTypeId, objectId, parentlinkId, parentId);
            		for (TblWorkflow tblWorkflow : tblWorkflows) {
						workflowService.insertWorkflowDetailHistory(tblWorkflow.getWorkflowId());
					}
            		workflowService.deleteAllWorkflow(tblWorkflows);
            		msg = "msg_reset_workflow_success";
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),msg);
	            }else{
	            	 redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),msg);
	            }
	            if(tabId==0){
	                returnStr = "redirect:/workflow/buyer/workflowprocess"+encryptDecryptUtils.generateRedirect("workflow/buyer/workflowprocess", request);
	            }else{                        
	              switch(moduleId){
	                case 3:
	                case 6:
	                        returnStr = "redirect:/etender/buyer/tenderdashboard/"+parentId+"/"+tabId+encryptDecryptUtils.generateRedirect("etender/buyer/tenderdashboard/"+parentId+"/"+tabId, request);
	                        break;
	                case 2:
	                        returnStr = "redirect:/eindent/buyer/indentdashboard/"+parentId+encryptDecryptUtils.generateRedirect("eindent/buyer/indentdashboard/"+parentId, request);
	                        break;
	                case 13:
	                	 returnStr = "redirect:/contract/buyer/contractBuyerDashboard/"+parentId+"/"+tabId+encryptDecryptUtils.generateRedirect("contract/buyer/contractBuyerDashboard/"+parentId+"/"+tabId, request);
	                	 break;
	                default:
	                        break;    
	            }  
	        }
	        }else{
	            return REDIRECT_SESSION_EXPIRED;
	        }
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        finally{
        	//Create Messages for AuditTrial
        	
        	String auditTrialMsg = "Workflow has been reset for "+eventName;
        	if(moduleId == 3){
        		auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMsg,parentId,objectId,"");
        	}else if(moduleId == 2){
        		auditTrailService.makeIndentAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMsg,parentId,objectId,"");
        	}else if(moduleId == 13){
        		auditTrailService.makeOnlineContractAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMsg,parentId,objectId,"");
        	}else{
        		auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditTrialMsg,parentId,objectId,"");
        	}
        }
        return returnStr;
    }
    
    
    @RequestMapping(value = "/ajax/checkUserFileNotClose", method = RequestMethod.POST)
    @ResponseBody
    public String checkUserFileNotClose(@RequestParam("hdmainobjectId") int mainobjectId,@RequestParam("hdwrkflId") int wrkflId,@RequestParam("hdparentId") int parentId,@RequestParam("hdparentlinkId") int parentlinkId,@RequestParam("hdlinkId") int linkId,@RequestParam("hdmoduleId") int moduleId,@RequestParam("hduserId") int userId,@RequestParam("hduserDetailId") int userDetailId,@RequestParam("txtselWrkflwAction") int txtselWrkflwAction,HttpServletRequest request,ModelMap modelMap) {
        String entryExists=REDIRECT_SESSION_EXPIRED;
        String auditMsg="";
        if(txtselWrkflwAction==1){
        	auditMsg=checkrecommendfileaction;
        }else if(txtselWrkflwAction==2){
        	auditMsg=checkfwdfileaction;
        }else if(txtselWrkflwAction==3){
        	auditMsg=checkapprovedinwrkaction;
        }
        try {
            if(request.getSession().getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null) {
                if(wrkflId!=0){
                	List<TblWorkflowDetail> listTblWorkflowDetail=workflowService.checkUserFileNotClose(wrkflId, userDetailId);
                	if(listTblWorkflowDetail!=null && !listTblWorkflowDetail.isEmpty()){
                		entryExists="0";
            		}else{
            			entryExists="1";
            		}
                }
            }
        } catch (Exception e) {
        	return  exceptionHandlerService.writeLog(e);
        }finally {
        	
//            auditTrailService.makeTenderAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), linkId, auditMsg, parentId,wrkflId, "");
        }
        return entryExists;
    }
}