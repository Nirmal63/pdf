/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblReportControlMasterDao;
import com.etl.eproc.common.model.TblReportControlMaster;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author dipal
 */

@Repository @Transactional    /*StackUpdate*/
public class TblReportControlMasterImpl extends AbcAbstractClass<TblReportControlMaster> implements TblReportControlMasterDao {

    @Override
    public void addTblReportControlMaster(TblReportControlMaster tblReportControlMaster){
        super.addEntity(tblReportControlMaster);
    }

    @Override
    public void deleteTblReportControlMaster(TblReportControlMaster tblReportControlMaster) {
        super.deleteEntity(tblReportControlMaster);
    }

    @Override
    public void updateTblReportControlMaster(TblReportControlMaster tblReportControlMaster) {
        super.updateEntity(tblReportControlMaster);
    }

    @Override
    public List<TblReportControlMaster> getAllTblReportControlMaster() {
        return super.getAllEntity();
    }

    @Override
    public List<TblReportControlMaster> findTblReportControlMaster(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblReportControlMasterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblReportControlMaster> findByCountTblReportControlMaster(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblReportControlMaster(List<TblReportControlMaster> tblReportControlMasters){
        super.updateAll(tblReportControlMasters);
    }
}

