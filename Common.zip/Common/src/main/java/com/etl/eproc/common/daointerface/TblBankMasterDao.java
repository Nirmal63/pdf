package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBankMaster;

public interface TblBankMasterDao  {

    public void addTblBankMaster(TblBankMaster tblBankMaster);

    public void deleteTblBankMaster(TblBankMaster tblBankMaster);

    public void updateTblBankMaster(TblBankMaster tblBankMaster);

    public List<TblBankMaster> getAllTblBankMaster();

    public List<TblBankMaster> findTblBankMaster(Object... values) throws Exception;

    public List<TblBankMaster> findByCountTblBankMaster(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBankMasterCount();

    public void saveUpdateAllTblBankMaster(List<TblBankMaster> tblBankMasters);
}