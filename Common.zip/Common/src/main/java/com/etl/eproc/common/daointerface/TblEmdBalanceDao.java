/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;


import com.etl.eproc.eauction.model.TblEmdBalance;
import java.util.List;

/**
 *
 * @author shreyansh
 */
public interface TblEmdBalanceDao  {

    public void addTblEmdBalance(TblEmdBalance tblEmdBalance);

    public void deleteTblEmdBalance(TblEmdBalance tblEmdBalance);

    public void updateTblEmdBalance(TblEmdBalance tblEmdBalance);

    public List<TblEmdBalance> getAllTblEmdBalance();

    public List<TblEmdBalance> findTblEmdBalance(Object... values) throws Exception;

    public List<TblEmdBalance> findByCountTblEmdBalance(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEmdBalanceCount();

    public void saveUpdateAllTblEmdBalance(List<TblEmdBalance> tblEmdBalances);

	public void saveOrUpdateTblEmdBalance(TblEmdBalance tblEmdBalance);
}
