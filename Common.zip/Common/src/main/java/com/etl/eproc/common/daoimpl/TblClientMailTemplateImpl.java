/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

import com.etl.eproc.common.daointerface.TblClientMailTemplateDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.eauction.model.TblClientMailTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author rajnikant
 */
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


@Repository @Transactional    /*StackUpdate*/
public class TblClientMailTemplateImpl extends AbcAbstractClass<TblClientMailTemplate> implements TblClientMailTemplateDao {

    @Override
    public void addTblClientMailTemplate(TblClientMailTemplate tblClientMailTemplate){
        super.addEntity(tblClientMailTemplate);
    }

    @Override
    public void deleteTblClientMailTemplate(TblClientMailTemplate tblClientMailTemplate) {
        super.deleteEntity(tblClientMailTemplate);
    }

    @Override
    public void updateTblClientMailTemplate(TblClientMailTemplate tblClientMailTemplate) {
        super.updateEntity(tblClientMailTemplate);
    }

    @Override
    public List<TblClientMailTemplate> getAllTblClientMailTemplate() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientMailTemplate> findTblClientMailTemplate(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientMailTemplateCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientMailTemplate> findByCountTblClientMailTemplate(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientMailTemplate(List<TblClientMailTemplate> tblClientMailTemplates){
        super.updateAll(tblClientMailTemplates);
    }
}
