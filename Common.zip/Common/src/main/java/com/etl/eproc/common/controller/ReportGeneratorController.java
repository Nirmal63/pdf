/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.HtmlUtils;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.model.TblReportControlDetail;
import com.etl.eproc.common.model.TblReportDetail;
import com.etl.eproc.common.model.TblReportLinkDetail;
import com.etl.eproc.common.model.TblReportMst;
import com.etl.eproc.common.model.TblReportSearchColumnDetail;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.ManageBidderService;
import com.etl.eproc.common.services.ReportGeneratorService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.ClientBean;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonUtility;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.HandleSpecialChar;
import com.etl.eproc.common.utility.SessionBean;

/**
 *
 * @author dipal.shah
 */
@Controller
public class ReportGeneratorController {

    @Autowired
    private ReportGeneratorService reportGeneratorService;
    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private HandleSpecialChar handleSpecialChar;
    @Autowired
    private MessageSource messageSource;
    @Autowired
    private AbcUtility abcUtility;
    @Autowired
    private CommonService commonService;
    @Autowired
    private ClientService clientService;
    @Autowired
	private ManageBidderService manageBidderService;
    @Autowired
    private DepartmentUserService departmentUserService;
    private static final String REPORTID="txtReportId";
    private static final String IS_PDF="isPDF";
    private static final String IS_PRINT="isPrint";
    private static final String YES="yes"; 
    private static final String SELOP_="selop_";
    private static final String FIELD_VALUE="FieldValue";
    @Value("#{projectProperties['auction_Admin_userId']?:0}")
    private int superAdmin;
    @Value("#{projectProperties['without_session_reportIds']}")
    private String noSessionReportIds;
    @Value("#{projectProperties['sector_auction_listing_reportIds']}")
    private String sectorAucReportIds;
    @Value("#{projectProperties['sector_tender_listing_reportIds']}")
    private String sectorTenReportIds;
    @Value("#{projectProperties['vehicle_sector']}")
    private int vehicleSectorId;
    @Value("#{projectProperties['property_sector']}")
    private int propertySectorId;
    @Value("#{auclinkProperties['manage_auction_attribute_selection_add']?:766}")
    private int aucAttrSelLinkId;
    @Value("#{linkProperties['link_statics_report_home_page']?:88}")
    private int linkStaticsReportId;
    @Value("#{projectProperties['viewAuctionNoticeCountClientId']}")
    private int viewAuctionNoticeCountClientId;
    @Value("#{projectProperties['agriGoldAucListRepId']}")
    private int agriGoldAucListRepId;
    
    @Value("#{linkProperties['report_home_property_auction_listing']?:113}")
    private int linkPropertySectorHomeReportId;
    @Value("#{linkProperties['report_bidder_property_auction_listing']?:112}")
    private int linkPropertySectorBidderReportId;
    @Value("#{linkProperties['report_officer_property_auction_listing']?:111}")
    private int linkPropertySectorOfficerReportId;
    @Value("#{linkProperties['report_master_form_library']?:52}")
    private int linkMasterFormLibraryReportId;
    
    @Value("#{projectProperties['drt_sector']}")
    private int drtSectorId;
    @Value("#{projectProperties['bank_sector']}")
    private int bankSectorId;
    @Value("#{projectProperties['GMRTemplateId']}")
    private String GMRTemplateId;
    
    @RequestMapping("/common/reportgenerator/ReportGenerator")
    public String reportGenerator(HttpServletRequest req, ModelMap map) {
        try {
            int reportId = 0;
            if (req.getParameter(REPORTID) != null) {
                reportId = Integer.parseInt(req.getParameter(REPORTID));
            }
            if (req.getParameter(IS_PDF) != null && req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
                map.addAttribute(IS_PDF, YES);
                StringBuilder tableDetail = getReportDataFromSP(req,null);
                map.addAttribute("tableDetail", tableDetail);
            }

            reportGeneratorService.getReportConfigDetails(reportId, map);
        } catch (Exception e) {
            return exceptionHandlerService.writeLog(e);
        }
        return "common/ReportGenerator";
    }

    @RequestMapping(value = {"/common/reportgenerator/GetReportDetails","/reportgenerator/GetReportDetails"}, method = RequestMethod.POST)
    @SuppressWarnings("ResultOfObjectAllocationIgnored")
    public void getReportDetails(HttpServletRequest req, HttpServletResponse res) {
        try {
                StringBuilder message = getReportDataFromSP(req,null);
                res.getWriter().write(message.toString());
        } catch (Exception e) {
            exceptionHandlerService.writeLog(e);
        }
    }

   /**
     * Method use to get Report detail by executing stored procedure and generate html code for report detail.
     * @param req
     * @return String detail containing report details
     * @throws Exception 
     */
    public StringBuilder getReportDataFromSP(HttpServletRequest req,ModelMap mv) throws Exception
    {
        int reportId=0;       
         StringBuilder message=new StringBuilder("");
        if(req.getParameter(REPORTID)!= null)
        {
        	reportId=Integer.parseInt(req.getParameter(REPORTID));
        }  
        HttpSession hs=req.getSession(true);
        boolean sessionCheck=true;
        String reportIdArr[]=noSessionReportIds.split(",");
        for(int i=0;i<reportIdArr.length;i++)
        {
            if(reportIdArr[i].equalsIgnoreCase(req.getParameter(REPORTID)))
            {
                sessionCheck = false;
                break;
            }
        }
        if (!sessionCheck || (hs !=null && hs.getAttribute(CommonKeywords.SESSION_OBJ.toString()) != null && hs.getAttribute(CommonKeywords.CLIENT_OBJ.toString()) != null)) 
        {
            int selTabId=0;
            int userTypeId=0;
            int userId=0;
            int designationId=0;
            String userTimeZoneOffSet=null;
            if(hs != null && hs.getAttribute(CommonKeywords.SESSION_OBJ.toString()) !=null)
            {
                SessionBean sessionBean=(SessionBean)hs.getAttribute(CommonKeywords.SESSION_OBJ.toString());
                userTypeId=sessionBean.getUserTypeId();
                designationId=sessionBean.getDesignationId();
                userId=sessionBean.getUserId();
                userTimeZoneOffSet=sessionBean.getTimeZoneOffset();
            }
            if(userTimeZoneOffSet == null && hs!=null && hs.getAttribute(CommonKeywords.CLIENT_OBJ.toString()) !=null) /* user does not logged into system. */
            {
                ClientBean clientBean=(ClientBean)hs.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
                userTimeZoneOffSet=clientBean.getTimeZone();
            }
            
            int dateFormatConvertionValue=0;
            Cookie[] cookies = req.getCookies();
            if (cookies != null) {
                for (Cookie cookie : cookies) {
                    if ("conversionValue".equals(cookie.getName())) {
                        dateFormatConvertionValue = Integer.parseInt(cookie.getValue());
                    }
                }
            }
            int pageNo=0;
            if(req.getParameter("txtpageNo")!=null && !req.getParameter("txtpageNo").trim().equalsIgnoreCase(""))
            {
            	pageNo = Integer.parseInt(req.getParameter("txtpageNo").trim());
            }
            int recordOffset=0;
            if(req.getParameter("txtsize")!=null && !req.getParameter("txtsize").trim().equalsIgnoreCase(""))
            {
            	recordOffset = Integer.parseInt(req.getParameter("txtsize").trim());
            }
            String str="",searchValue="",searchValueTo="";
            
            int reportListingStyle = 0;
            for (Cookie cookie : cookies) {
            	if ("listingStyle".equals(cookie.getName())) {
            		reportListingStyle = Integer.parseInt(cookie.getValue());
            		break;
            	}
			}

            List<TblReportLinkDetail> lstLinkDetail=null;
            List<TblReportDetail> lstTblReportDetail=reportGeneratorService.getReportDetail(reportId);
            if(superAdmin != userId &&  userTypeId != 2) // User is not bidder and useris not super admin then check for link rights?
            {
               lstLinkDetail =reportGeneratorService.getReportLinkRDetails(reportId, designationId);
            }
            else
            {
                lstLinkDetail=reportGeneratorService.getReportLinkDetail(reportId);
            }
            List<TblReportSearchColumnDetail> lstReportSearchColumnDetails=reportGeneratorService.getReportSearchColumnDetail(reportId);
            List<Object[]> searchControlDtl=reportGeneratorService.getReportSearchColumnControlDetail(reportId);
            TblReportMst tblReportMst = reportGeneratorService.getReportMasterDetail(reportId);
            StringBuilder searchCondition=new StringBuilder("");
            StringBuilder searchCriteria = new StringBuilder("");
            String tabValue = "";
            StringBuilder bidderList  = new StringBuilder();
            if(req.getParameter("txtTab")!= null && !req.getParameter("txtTab").equalsIgnoreCase("") && req.getParameter("txtparam10").equals(""))
            {
                selTabId=Integer.parseInt(req.getParameter("txtTab"));
                List<TblReportControlDetail> lstReportControlDetails = reportGeneratorService.getReportControlDetailslist(Integer.parseInt(req.getParameter("txtTab")));
                if(lstReportControlDetails !=null && !lstReportControlDetails.isEmpty())
                {
                    searchCondition.append(" and ").append(lstReportControlDetails.get(0).getCondition());
                    searchCondition.append(" and -1!=0 ");
                    tabValue = lstReportControlDetails.get(0).getControlValue();
                }
             // Bug #2954 start
                if(Integer.parseInt(req.getParameter("txtTab")) == 8 || Integer.parseInt(req.getParameter("txtTab")) == 10 && reportId == 5) {
                	List<Object[]> bidderListForUpdateStatus = manageBidderService.checkBBlackListidderStatus();
                	if(!bidderListForUpdateStatus.isEmpty()) {
                	bidderList.append(bidderListForUpdateStatus.toString().replace("[","").replace("]",""));
                	manageBidderService.updateBlacklistStatus(bidderList.toString());
                }
                }
             // Bug #2954 start
             // PT #3743 start
                if(reportId == 4 && Integer.parseInt(req.getParameter("txtTab")) == 5) {
                	lstTblReportDetail.get(0).setColumnDetails("Email ID:5:L:19%:0 ~ User details:2:L:15%:0  ~ Status:16:C:7%:1 ~ Registration date:19:C:20%:0  ~ Reason for disable:31:C:20%:0 ~ Action:17:C:20%:0");	
                	lstTblReportDetail.get(0).setLang1("Email ID:5:L:19%:0 ~ User details:2:L:15%:0  ~ Status:16:C:7%:1 ~ Registration date:19:C:20%:0 ~ Reason for disable:31:C:20%:0 ~ Action:17:C:20%:0");
                }
             // PT #3743 end
            }
            String comboCondition="";
            if(lstReportSearchColumnDetails!=null && !lstReportSearchColumnDetails.isEmpty())
            {
            	ClientBean clientBean=(ClientBean)hs.getAttribute(CommonKeywords.CLIENT_OBJ.toString());
            	List<Object> lstClientSector = clientService.getClientSector(clientBean.getClientId()); 
                int sectorId = lstClientSector.size() > 0 ? (Integer)lstClientSector.get(0) : 0;
//            	int sectorId = (Integer)clientService.getClientSector(clientBean.getClientId()).get(0);
                for(TblReportSearchColumnDetail ob:lstReportSearchColumnDetails)
                {
                    if(req.getParameter("txt_"+ob.getColumnId())!= null && !req.getParameter("txt_"+ob.getColumnId()).trim().equalsIgnoreCase(""))
                    {
                        comboCondition="";
                        boolean flag = true;
                        String comboCondition1 = "(";
                        for(Object [] obarr:searchControlDtl)
                        {
                        	if((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1 && req.getParameter("txt_"+ob.getColumnId()).contains("$")){
                        		String[] auctionStatusChecked = req.getParameter("txt_"+ob.getColumnId()).split(",");
                        		for (String auctionStatus : auctionStatusChecked) {
                        			if(ob.getColumnId() == Integer.parseInt(obarr[0]+"") && ((obarr[2]+"").split("::")[1]).equalsIgnoreCase(auctionStatus.replace("$", "")))
    	                            {
    	                                if(flag){
    	                                	comboCondition1+=obarr[3]+" ";
    	                                	flag = false;
    	                                }else{
    	                                	comboCondition1+="OR "+obarr[3]+"";
    	                                }
    	                            }
								}
                        	}else{
	                            if(ob.getColumnId() == Integer.parseInt(obarr[0]+"") && ((obarr[2]+"").split("::")[1]).equalsIgnoreCase(req.getParameter("txt_"+ob.getColumnId())))
	                            {
	                                comboCondition=obarr[3]+"";
	                                break;
	                            }
                        	}
                        }
                        comboCondition1 += ")";
                        if((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1 && comboCondition1.length() > 2){
                        	comboCondition = comboCondition1;
                        }
                        if(!comboCondition.equalsIgnoreCase(""))
                        {
                            searchCondition.append(" and ").append(comboCondition).append(" ");

                            if(searchCriteria.length()> 0)
                            {
                                searchCriteria.append(" , ");
                            }
                            searchCriteria.append(ob.getColumnName()).append(": ");
                            searchCriteria.append(comboCondition);
                        }
                        else
                        {
                                if(ob.getDatatype().equalsIgnoreCase("date"))
                                {
                                     searchValue=" convert(date,'" + req.getParameter("txt_" + ob.getColumnId()) + "',"+dateFormatConvertionValue+")";
                                    if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("bt"))
                                    {
                                            searchValueTo=" convert(date,'" + req.getParameter("txt_" + ob.getColumnId()+"_to") + "',"+dateFormatConvertionValue+")";
                                    }

                                    searchCondition.append(" and convert(date,").append(ob.getSelectFieldName()).append(","+dateFormatConvertionValue+") ");
                                }
                                else if(ob.getDatatype().equalsIgnoreCase("datetime"))
                                {
                                    // searchValue = " convert(datetime,'" + req.getParameter("txt_" + ob.getColumnId()) + "',103)";
                                     searchValue = " convert(datetime,'" +  CommonUtility.convertUtcTimezone(req.getParameter("txt_" + ob.getColumnId())) + "',101)";
                                    if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("bt"))
                                    {
                                            //searchValueTo=" convert(datetime,'" + req.getParameter("txt_" + ob.getColumnId()+"_to") + "',103)";
                                            searchValueTo = " convert(datetime,'" +  CommonUtility.convertUtcTimezone(req.getParameter("txt_" + ob.getColumnId()+"_to")) + "',101)";
                                    }
                                     //searchCondition.append(" and convert(datetime,appmaster.F_ToDateTime( ").append(ob.getSelectFieldName()).append(" , '").append(userTimeZoneOffSet).append("',103),103) ");    
                                    searchCondition.append(" and CONVERT(datetime,CONVERT(varchar(16),").append(ob.getSelectFieldName()).append(",120),101) ");
                                }
                                else if(ob.getDatatype().equalsIgnoreCase("numeric"))
                                {
                                	if((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1 && req.getParameter("txt_" + ob.getColumnId()).contains("-")){
                                		String[] budgetParameterArr = req.getParameter("txt_" + ob.getColumnId()).split("-");
                                		if(!budgetParameterArr[1].trim().equals("0")){
                                			searchCondition.append(" and ").append(ob.getSelectFieldName());
                                			searchValue = " convert(numeric,'"+budgetParameterArr[0]+"')";
                                    		searchValueTo= " convert(numeric,'"+budgetParameterArr[1]+"')";
                                			searchCriteria.append(" between ");
                                			searchCondition.append(" between ").append(searchValue).append(" and  ").append(searchValueTo);
                                		}
                                	}else{
                                		searchValue = " convert(numeric,'" + req.getParameter("txt_" + ob.getColumnId()) + "')";
                                        if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("bt"))
                                        {
                                                searchValueTo= " convert(numeric,'" + req.getParameter("txt_" + ob.getColumnId() + "_to")+"')";
                                        }

                                        searchCondition.append(" and ").append(ob.getSelectFieldName());	
                                	}
                                }
                                else
                                {
                                	searchValue = req.getParameter("txt_" + ob.getColumnId());
                                	if(ob.getDatatype().equalsIgnoreCase("text") && ob.getSearchCriteria() != 1){
                                		searchCondition.append(" and ( ").append(ob.getSelectFieldName()); //Changes Bug Id :#32692,#32682,#32552
                                	}else{
                                		searchCondition.append(" and ").append(ob.getSelectFieldName());
                                	}
                                }

                                if(searchCriteria.length()> 0)
                                {
                                    searchCriteria.append(" , ");
                                }
                                searchCriteria.append(ob.getColumnName()).append(":");


                                if(ob.getDatatype().equalsIgnoreCase("text") && ob.getSearchCriteria() == 1)
                                {
                                    searchCriteria.append(" equals ");
                                    searchCondition.append(" = '").append(req.getParameter("txt_"+ob.getColumnId())).append("' ");
                                }
                                else if(ob.getDatatype().equalsIgnoreCase("text") && ob.getSearchCriteria() != 1)
                                {
                                	// PT : #36402 By Jitendra. Search for budget field value lies between min. & max. budget. For Bidder Profile Report Only. 
                                	if(reportId == 124 && ob.getColumnId() == 522){
                                		searchCriteria.append(" between ");
                                		searchCondition.append(" = 1 AND ").append("'"+req.getParameter("txt_"+ob.getColumnId())+"'").append(" between ").append("A.minBudget").append(" and ").append("A.maxBudget").append(" ) ");
                                	}else{
                                		searchCriteria.append(" contains ");
                                        searchCondition.append(" like '%").append(req.getParameter("txt_"+ob.getColumnId())).append("%' ");
                                        //start Changes Bug Id :#32692,#32682,#32552
                                        searchCondition.append(" or ").append(ob.getSelectFieldName());
                                        searchCondition.append(" like '%").append(AbcUtility.reverseReplaceSpecialChars(req.getParameter("txt_"+ob.getColumnId()))).append("%' ) ");
                                        //End Changes Bug Id :#32692,#32682,#32552
                                	}
                                }
                                else
                                {

                                    if(req.getParameter(SELOP_+ob.getColumnId())!= null && req.getParameter(SELOP_+ob.getColumnId()).equalsIgnoreCase("eq"))
                                    {
                                        searchCriteria.append(" equal ");
                                        if(ob.getDatatype().equalsIgnoreCase("date") || ob.getDatatype().equalsIgnoreCase("datetime"))
                                        {
                                                searchCondition.append(" = ").append(searchValue).append(" ");
                                        }
                                        else
                                        {
                                                searchCondition.append(" = '").append(req.getParameter("txt_"+ob.getColumnId())).append("' ");
                                        }


                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("ne"))
                                    {
                                        searchCriteria.append(" not equal ");
                                        if(ob.getDatatype().equalsIgnoreCase("date") || ob.getDatatype().equalsIgnoreCase("datetime"))
                                        {
                                                searchCondition.append(" != ").append(searchValue).append(" ");
                                        }
                                        else
                                        {
                                                searchCondition.append(" != '").append(req.getParameter("txt_"+ob.getColumnId())).append("' ");
                                        }
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("bw"))
                                    {
                                        searchCriteria.append(" begin with ");
                                        searchCondition.append(" like '").append(req.getParameter("txt_"+ob.getColumnId())).append("%' ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("bn"))
                                    {
                                        searchCriteria.append(" does not begin with ");
                                        searchCondition.append(" not like '").append(req.getParameter("txt_"+ob.getColumnId())).append("%' ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("in"))
                                    {
                                        searchCriteria.append(" is in ");
                                        str="('"+req.getParameter("txt_"+ob.getColumnId()).replace(",", "','")+"')";
                                        searchCondition.append(" in ").append(str).append(" ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("ni"))
                                    {
                                        searchCriteria.append(" is not in ");
                                        str="('"+req.getParameter("txt_"+ob.getColumnId()).replace(",", "','")+"')";
                                        searchCondition.append(" not in ").append(str).append(" ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("ew"))
                                    {
                                        searchCriteria.append(" ends with ");
                                        searchCondition.append(" like '%").append(req.getParameter("txt_"+ob.getColumnId())).append("' ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("en"))
                                    {
                                        searchCriteria.append(" does not ends with ");
                                        searchCondition.append(" not like '%").append(req.getParameter("txt_"+ob.getColumnId())).append("' ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("cn"))
                                    {
                                        searchCriteria.append(" contains ");
                                        searchCondition.append(" like '%").append(req.getParameter("txt_"+ob.getColumnId())).append("%' ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("nc"))
                                    {
                                        searchCriteria.append(" does not contain ");
                                        searchCondition.append(" not like '%").append(req.getParameter("txt_"+ob.getColumnId())).append("%' ");
                                    }
                                    else if(req.getParameter(SELOP_+ ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("lt"))
                                    {
                                        searchCriteria.append(" less ");
                                        searchCondition.append(" < ").append(searchValue).append(" ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("le"))
                                    {
                                        searchCriteria.append(" less or equal ");
                                        searchCondition.append(" <= ").append(searchValue).append(" ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("gt"))
                                    {
                                        searchCriteria.append(" greater ");
                                        searchCondition.append(" > ").append(searchValue).append(" ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("ge"))
                                    {
                                        searchCriteria.append(" greater or equal ");
                                        searchCondition.append(" >= ").append(searchValue).append(" ");
                                    }
                                    else if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("bt"))
                                    {
                                        searchCriteria.append(" between ");
                                        searchCondition.append(" between ").append(searchValue).append(" and  ").append(searchValueTo);
                                    }
                                }
                                searchCriteria.append("&quot;").append(req.getParameter("txt_"+ob.getColumnId())).append("&quot;");	
                                		
                                if(req.getParameter(SELOP_ + ob.getColumnId()) != null && req.getParameter(SELOP_ + ob.getColumnId()).equalsIgnoreCase("bt"))
                                {
                                    searchCriteria.append(" and &quot;").append(req.getParameter("txt_"+ob.getColumnId()+"_to")).append("&quot;");
                                }
                        }
                    }
                }
            }
           // System.out.println(" search criteria ="+searchCondition.toString()+"...");
           // Special Client (Sector)  search condition building - start
            ClientBean clientBean =(ClientBean) req.getSession().getAttribute(CommonKeywords.CLIENT_OBJ.toString());
    	    if(clientBean != null && !"".equalsIgnoreCase(clientBean.getSectorTableName())) {
        	   String searchFieldValue="";
        	   int linkId = getLinkIdForSectorListing(req);
	           List<Object[]> lstSectorSearchFields = reportGeneratorService.getSectorSearchFields(abcUtility.getSessionClientId(req), linkId);
	           if(lstSectorSearchFields!=null && !lstSectorSearchFields.isEmpty()) {
	        	  String andOr=" and ("; 
	        	  boolean isClosingBracReq = false;
	        	  int sectorId = (Integer)clientService.getClientSector(clientBean.getClientId()).get(0);
	        	  for(Object[] lstSectorSearchField : lstSectorSearchFields) {
	        		  searchFieldValue=req.getParameter("txts_"+lstSectorSearchField[0]);
	        		  if(searchFieldValue!=null && !"".equalsIgnoreCase(searchFieldValue)) { // for field value
	        			  isClosingBracReq = true; // Bug #29474	
	        			   if((Integer)lstSectorSearchField[3]!=8) {
	        				   if((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1 && req.getParameter("txts_"+lstSectorSearchField[0]).contains("$")){
	        					   searchCondition.append(andOr).append("(LTRIM(RTRIM").append("(CASE WHEN A.").append(lstSectorSearchField[2]).append(" IS NULL OR A.").append(lstSectorSearchField[2]).append(" = '' THEN '' ELSE A.").append(lstSectorSearchField[2]).append(" END)))");
	        				   }else{
	        					   searchCondition.append(andOr).append("(CASE WHEN A.").append(lstSectorSearchField[2]).append(" IS NULL OR A.").append(lstSectorSearchField[2]).append(" = '' THEN '' ELSE A.").append(lstSectorSearchField[2]).append(" END)");
	        				   }
	        			   }
	        			   else {
	        				   searchCondition.append(andOr).append(" convert(decimal(20,5), (CASE WHEN A.").append(lstSectorSearchField[2]).append(" IS NULL OR A.").append(lstSectorSearchField[2]).append(" = '' THEN 0 ELSE A.").append(lstSectorSearchField[2]).append(" END))");
	        			   }
			        		switch ((Integer)lstSectorSearchField[3]) {
							case 1: /* text field*/
								searchCondition.append(" like '%").append(req.getParameter("txts_"+lstSectorSearchField[0])).append("%' ");
								break;
							case 4: /* drop down*/
								if((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1 && req.getParameter("txts_"+lstSectorSearchField[0]).contains("$")){
									searchCondition.append(" IN(").append(req.getParameter("txts_"+lstSectorSearchField[0]).replace("$", "'")).append(") ");
								}else{
									searchCondition.append(" like '%").append(req.getParameter("txts_"+lstSectorSearchField[0])).append("%' ");
								}
								break;
							case 6: /* date field*/
								 String searchVal=" convert(date,'" + req.getParameter("txts_" + lstSectorSearchField[0]) + "',"+dateFormatConvertionValue+")";
								 if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("eq")) {
									 searchCondition.append(" = ").append(searchVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("ne")) {
									 searchCondition.append(" != ").append(searchVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("lt")) {
									 searchCondition.append(" < ").append(searchVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("le")) {
									 searchCondition.append(" <= ").append(searchVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("gt")) {
									 searchCondition.append(" > ").append(searchVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("ge")) {
									 searchCondition.append(" >= ").append(searchVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("bt")) {
									 searchValueTo = " convert(datetime,'" +  CommonUtility.convertUtcTimezone(req.getParameter("txt_" + lstSectorSearchField[0]+"_to")) + "',101)";
									 searchCondition.append(" between ").append(searchVal).append(" and  ").append(searchValueTo);
								 }
								break;
							case 8: /* textfield with comparision (numeric)*/
								int searchNumVal= StringUtils.hasLength(searchFieldValue) ? Integer.parseInt(searchFieldValue) : 0; //" convert(decimal(20,5),'" + req.getParameter("txts_" + lstSectorSearchField[0]) + "')";
								 if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("eq")) {
									 searchCondition.append(" = ").append(searchNumVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("ne")) {
									 searchCondition.append(" != ").append(searchNumVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("lt")) {
									 searchCondition.append(" < ").append(searchNumVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("le")) {
									 searchCondition.append(" <= ").append(searchNumVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("gt")) {
									 searchCondition.append(" > ").append(searchNumVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("ge")) {
									 searchCondition.append(" >= ").append(searchNumVal).append(" ");
								 }
								 else if(req.getParameter(SELOP_+lstSectorSearchField[0])!= null && req.getParameter(SELOP_+lstSectorSearchField[0]).equalsIgnoreCase("bt")) {
									 searchValueTo =  req.getParameter("txt_" + lstSectorSearchField[0]+"_to");//" convert(decimal(20,5),'" +  CommonUtility.convertUtcTimezone(req.getParameter("txt_" + lstSectorSearchField[0]+"_to")) + "',101)";
									 searchCondition.append(" between ").append(searchNumVal).append(" and  ").append(searchValueTo);
								 }
								break;
							}
			        		//For all sector, "and" used for multiple attribute search (PT #32800) 
			        		//if(sectorId == propertySectorId){
			        			andOr=" and ";
			        		/*}else{
			        			andOr=" or ";
			        		}*/
	        		  }
	        	  }
	        	  if(isClosingBracReq){
	        		  searchCondition.append(")");
	        	  }
	           }
           }
           // Special Client (Sector)  search condition building - end
           boolean isSearchPerformed=false;
           if(!searchCondition.toString().trim().endsWith("-1!=0") && searchCondition.toString().trim().indexOf("-1!=0")!= -1) // Searching Performed
           {   
               isSearchPerformed=true;
               String strTemp=searchCondition.toString().trim().substring(searchCondition.toString().trim().indexOf("-1!=0")+5);
               searchCondition=new StringBuilder();
               searchCondition.append(strTemp);
           }
           
           if(searchCondition.toString().trim().equals("") && req.getParameter("txtparam10") != null && !req.getParameter("txtparam10").equals("")) {
        	   searchCondition.append(" and -1!=0");
           }
           
            //System.out.println(" search criteria ="+searchCondition.toString()+"...");
            
            String headerString="";
            String arrHeading[]=null;

            if(lstTblReportDetail != null && lstTblReportDetail.size()> 0)
            {
                headerString=lstTblReportDetail.get(0).getColumnDetails();
                arrHeading=headerString.split("~");
            }

            
            String sortOrder = req.getParameter("txtsortOrder");
            String sortColumn = req.getParameter("txtsortColumn");

           Integer totalPages = 0 ;
           
           Map<String,Object> spOutput=null;
           List<LinkedHashMap<String, Object>> listdata = null;
           if(req.getParameter(IS_PDF)!=null && req.getParameter(IS_PDF).equalsIgnoreCase(YES))
           {
        	   spOutput = reportGeneratorService.getReportData(reportId,0,0,sortColumn,sortOrder,req.getParameter("txtparam1"),req.getParameter("txtparam2"),req.getParameter("txtparam3"),req.getParameter("txtparam4"),req.getParameter("txtparam5"),(reportId==4)?Integer.toString(userTypeId):req.getParameter("txtparam6"),req.getParameter("txtparam7"),req.getParameter("txtparam8"),req.getParameter("txtparam9"),req.getParameter("txtparam10"),searchCondition.toString(),1);
           }
           else
           {
        	   spOutput = reportGeneratorService.getReportData(reportId,recordOffset,pageNo,sortColumn,sortOrder,req.getParameter("txtparam1"),req.getParameter("txtparam2"),req.getParameter("txtparam3"),req.getParameter("txtparam4"),req.getParameter("txtparam5"),(reportId==4)?Integer.toString(userTypeId):req.getParameter("txtparam6"),req.getParameter("txtparam7"),req.getParameter("txtparam8"),req.getParameter("txtparam9"),req.getParameter("txtparam10"),searchCondition.toString(),0);
           }
           
           if(spOutput != null)
           {
               listdata=(ArrayList<LinkedHashMap<String, Object>>) spOutput.get("#result-set-1");
           }
           
           int i = 0;
           int fieldIndex=0;
           int clienId = abcUtility.getSessionClientId(req);
           List<Object> lstClientSector = clientService.getClientSector(clienId); 
           int sectorId = lstClientSector.size() > 0 ? (Integer)lstClientSector.get(0) : 0;
           if(listdata != null && listdata.size()>0)
           { 
               
        	   /*List<Object> lstClientSector = clientService.getClientSector(clienId); 
               int sectorId = lstClientSector.size() > 0 ? (Integer)lstClientSector.get(0) : 0;*/
                 for ( i = 0; i < listdata.size(); i++)
                 {
                    if((tblReportMst.getReportType()!=null && tblReportMst.getReportType().equalsIgnoreCase("V")) || (tblReportMst.getReportType()!=null && tblReportMst.getReportType().equalsIgnoreCase("H")) || (tblReportMst.getReportType()!=null && tblReportMst.getReportType().equalsIgnoreCase("L") && reportListingStyle==0))  // Report Type = Vertical view
                    {
                        message.append("<tr ");
                        if(i%2!=0)
                        {
                            //message.append(" style='background:#F2F2F2;'" );
                            //message.append(" style='background:#fcfcfc;'" );
                        }
                        message.append(" class=\"line-height v-a-middle padding1\">");
                        message.append("<td class=\"v-a-middle padding1\" style='text-align:center;'>");
                        if(req.getParameter(IS_PDF)!=null && req.getParameter(IS_PDF).equalsIgnoreCase(YES))
                        {
                            message.append((i + 1));
                        }
                        else
                        {
                            message.append(((pageNo - 1) * recordOffset + (i + 1)));
                        }
                        
                        message.append("</td>");
                        boolean flink=false;
                        boolean showColumn=true;
                        String tmpStr=arrHeading[arrHeading.length-1];
                        String isAction=tmpStr.split(":")[0].trim();
                        for(int j=0;j<arrHeading.length;j++)
                        {
                            fieldIndex=Integer.parseInt(arrHeading[j].split(":")[1].trim());
                            flink=false;
                            showColumn=true;
                            if(!isSearchPerformed && arrHeading[j].split(":").length >= 5 && arrHeading[j].split(":")[4]!= null && arrHeading[j].split(":")[4].trim().equalsIgnoreCase("1")) 
                            {
                                showColumn=false;
                            }
                            
                            if((clienId == viewAuctionNoticeCountClientId) && reportId == agriGoldAucListRepId && (fieldIndex == 4 || fieldIndex == 6 || fieldIndex == 2))
                            {
                            	showColumn=false;
                            }
                            if(sectorId == propertySectorId && reportId == linkPropertySectorHomeReportId && (fieldIndex == 4 || fieldIndex == 6 || fieldIndex == 2 || fieldIndex == 7 || fieldIndex == 3)){
                            	showColumn = false;
                            }
                            if(sectorId == propertySectorId && (reportId == linkPropertySectorBidderReportId || reportId == linkPropertySectorOfficerReportId) && (fieldIndex == 8 || fieldIndex == 9 || fieldIndex == 2 || fieldIndex == 7 )){
                            	showColumn = false;
                            }
                            if(arrHeading[j].split(":").length > 2 && arrHeading[j].split(":")[2]!= null && arrHeading[j].split(":")[2].trim().equalsIgnoreCase("l"))
                            {
                            	if(isAction.equalsIgnoreCase("Action") && arrHeading[j].split(":")[0].toString().trim().equalsIgnoreCase("Action")){
                            		message.append("<td class=\"v-a-middle padding1 removedata white-space-nowrap \" ");
                            	}else{
                            		message.append("<td class=\"v-a-middle padding1 "+ (showColumn ? "" :" pdfdisplay " ) +" \" ");
                            	}
                                    if(showColumn)
                                    {
                                        message.append(" style='text-align:left;' >");
                                    }
                                    else
                                    {
                                        message.append(" style='text-align:left; display:none;' >");
                                    }
                            }
                            else if(arrHeading[j].split(":").length > 2 &&  arrHeading[j].split(":")[2]!= null && arrHeading[j].split(":")[2].trim().equalsIgnoreCase("r"))
                            {
                                    if(isAction.equalsIgnoreCase("Action") && arrHeading[j].split(":")[0].toString().equalsIgnoreCase(" Action")){
                            		message.append("<td class='t-align-right wordBreak v-a-middle padding1 removedata white-space-nowrap'");
                                    }else{
                                    	message.append("<td class='t-align-right wordBreak v-a-middle padding1 "+ (showColumn ? "" :" pdfdisplay " ) +" '");
                                    }
                                    
                                    if(showColumn)
                                    {
                                        message.append(" style='text-align:right;' >");
                                    }
                                    else
                                    {
                                        message.append(" style='text-align:right; display:none;' >");
                                    }
                            }
                            else
                            {
                            	if(isAction.equalsIgnoreCase("Action") && arrHeading[j].split(":")[0].toString().equalsIgnoreCase(" Action")){
                            		message.append("<td class='wordBreak v-a-middle padding1 removedata white-space-nowrap' ");
                            	}else{
                            		message.append("<td class='wordBreak v-a-middle padding1"+ (showColumn ? "" :" pdfdisplay " ) +"'");
                            	}
                                    if(showColumn)
                                    {
                                        message.append(" style='text-align:center;' >");
                                    }
                                    else
                                    {
                                        message.append(" style='text-align:center; display:none;' >");
                                    }
                            }
                            boolean isPipeReq = false;
                            if(lstLinkDetail!= null && lstLinkDetail.size() > 0 && (req.getParameter(IS_PDF)== null || req.getParameter(IS_PDF).equalsIgnoreCase("no")))
                            {
                                String link="",temp="";
                                for(TblReportLinkDetail linkDetail:lstLinkDetail)
                                {
                                    if(fieldIndex == linkDetail.getDispalyColumnId())
                                    {
                                        // Check link show/hide satisfied?
                                    	// Bug #36256 By Jitendra. Show cancelled status link (reportlinkId : 439) only when tender status is cancelled.  
                                        if((linkDetail.getShowField() == 0) || (listdata.get(i).get(FIELD_VALUE+linkDetail.getShowField())!= null && Integer.parseInt(listdata.get(i).get(FIELD_VALUE+linkDetail.getShowField())+"")== 1 && linkDetail.getReportLinkId() != 439) || (linkDetail.getReportLinkId() == 439 && listdata.get(i).get(FIELD_VALUE+linkDetail.getShowField())!= null && Integer.parseInt(listdata.get(i).get(FIELD_VALUE+linkDetail.getShowField())+"")== 0)) 
                                        {
                                                temp=linkDetail.getUrl();
                                                link=linkDetail.getUrl();

                                                for(String t: linkDetail.getUrl().split("::"))
                                                {
                                                    //System.out.println("t=="+t);
                                                    temp=t.substring(0,(t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
                                                   // System.out.println("temp="+temp);
                                                    if(temp.matches("\\d+") && listdata.get(i).get(FIELD_VALUE+temp) != null)
                                                    {
                                                        link=link.replaceFirst("::\\d+",listdata.get(i).get(FIELD_VALUE+temp).toString());                                                    	
                                                       // System.out.println("link="+link);
                                                    }
                                                    else if(temp.matches("param\\d+") && req.getParameter("txt"+temp) != null)
                                                    {
                                                        link=link.replaceFirst("::param\\d+",req.getParameter("txt"+temp));
                                                       // System.out.println("link="+link);
                                                    }

                                                }
                                                if(flink)
                                                {
                                                   // message.append(" | ");
                                                }
                                                if(linkDetail.getLinkCaption() != null)
                                                {
                                                    message.append("<a href='");

                                                    if(req.getParameter(IS_PDF)==null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES))
                                                    {
                                                        //System.out.println("original Link====>"+link);

                                                        String secString="";
                                                        if(link.startsWith("/"))
                                                        {
                                                            secString=link.substring(1,link.length());
                                                        }
                                                        if(!link.equalsIgnoreCase("javascript:void(0)")){                                            
                                                            secString=encryptDecryptUtils.generateRedirect(secString,req);
                                                            link=req.getServletContext().getContextPath()+link;
                                                        }                                            
                                                       // System.out.println("context path link="+link);
                                                        //System.out.println("link="+link+secString);
                                                        message.append(link).append(secString);
                                                    }
                                                    else
                                                    {                                              
                                                            message.append(handleSpecialChar.handleSpecialChar(link));
                                                    }

                                                    if(linkDetail.getAttribute() !=null)
                                                    {
                                                        String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
                                                        if(t.contains("::"))
                                                        {
                                                            
                                                            String finalAttri="";
                                                            //System.out.println(linkDetail.getAttribute());
                                                             for(String t1 : linkDetail.getAttribute().split("\'"))
                                                                {
                                                                    if(t1.contains("::") && t1.contains("_encrypt"))
                                                                    {
                                                                        temp=t1.replace("::", "");
                                                                        temp=temp.replace("_encrypt", "");
                                                                       // System.out.println("temp="+temp);
                                                                        if(temp.matches("^[0-9*]{1,2}") && listdata.get(i).get(FIELD_VALUE+temp) != null)
                                                                        {
                                                                            finalAttri+=encryptDecryptUtils.encrypt(listdata.get(i).get(FIELD_VALUE+temp).toString())+"'";
                                                                        }
                                                                        // System.out.println(finalAttri);
                                                                    }
                                                                    else if(t1.contains("::"))
                                                                    {
                                                                        temp=t1.replace("::", "");
                                                                        temp=temp.replace("_encrypt", "");
                                                                       /// System.out.println("temp="+temp);
                                                                        if(temp.matches("^[0-9*]{1,2}") && listdata.get(i).get(FIELD_VALUE+temp) != null)
                                                                        {
                                                                            finalAttri+=AbcUtility.reverseReplaceSpecialChars(listdata.get(i).get(FIELD_VALUE+temp).toString())+"'";
                                                                        }
                                                                        else
                                                                        {
                                                                        	finalAttri+="'";
                                                                        }
                                                                        // System.out.println(finalAttri);
                                                                    }
                                                                    else
                                                                    {
                                                                        finalAttri +=t1+"'";
                                                                    }

                                                                }
                                                             finalAttri= finalAttri.substring(0,finalAttri.length()-1);
                                                             //System.out.println(finalAttri);
                                                             message.append("' ").append(finalAttri).append(" ");
                                                        }
                                                        else{
                                                            message.append("' ").append(linkDetail.getAttribute()).append(" ");
                                                        }                                                                                                                           
                                                    }
                                                    else
                                                    {
                                                        message.append("' ");
                                                    }
                                                   
                                                    String tempString="";
                                                    if(req.getParameter(IS_PDF)==null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES))
                                                    {
                                                    	tempString=linkDetail.getLinkCaption();
                                                    }
                                                    else
                                                    {
                                                    	tempString = handleSpecialChar.handleSpecialChar(linkDetail.getLinkCaption());
                                                    }
                                                    if(tempString.contains("</A> |") || tempString.contains("</A>|") || tempString.contains("</a>|") || tempString.contains("</a> |")){
                                                    	tempString = tempString.substring(0,tempString.indexOf("<"));
                                                    	isPipeReq = true;
                                                    }
                                                    message.append(" title='").append(tempString).append("'");
                                                    message.append(" >").append(tempString);
                                                    
                                                    message.append("</a> ");
                                                    if(isPipeReq || reportId == linkMasterFormLibraryReportId) { 
                                                    	message.append(" | ");
                                                    	isPipeReq = false;
                                                    }
                                                }
                                                else
                                                {
                                                    message.append("<a title='").append(messageSource.getMessage("tooltip_viewdetails", null, LocaleContextHolder.getLocale())).append("' href='");

                                                    if(req.getParameter(IS_PDF)==null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES))
                                                    {
                                                            //System.out.println("original Link====>"+link);

                                                            String secString="";
                                                            if(link.startsWith("/"))
                                                            {
                                                                secString=link.substring(1,link.length());
                                                            }                                                
                                                            if(!link.equalsIgnoreCase("javascript:void(0)")){
                                                                secString=encryptDecryptUtils.generateRedirect(secString,req);
                                                                link=req.getServletContext().getContextPath()+link;
                                                            }
                                                            //System.out.println("context path link="+link);
                                                            //System.out.println("link="+link+secString);
                                                            message.append(link).append(secString);
                                                    }
                                                    else
                                                    {
                                                            message.append(handleSpecialChar.handleSpecialChar(link));
                                                    }

                                                    if(linkDetail.getAttribute() !=null)
                                                    {
                                                        String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
                                                        if(t.contains("_encrypt")){
                                                            t = t.substring(t.indexOf("('::")+4,t.indexOf("_encrypt')"));                                                
                                                            Object valdata = listdata.get(i).get(FIELD_VALUE+t);
                                                            if(t.matches("[0-9*]") &&  valdata!= null)
                                                            {                                                    
                                                                valdata = encryptDecryptUtils.encrypt(valdata.toString());
                                                                message.append("' ").append(linkDetail.getAttribute().replace("::"+t,valdata.toString()).replace("_encrypt", "")).append(" ");
                                                            }
                                                        }else{
                                                            message.append("' ").append(linkDetail.getAttribute()).append(" ");
                                                        }                                                                                                                                                                       
                                                    }
                                                    else
                                                    {
                                                        message.append("' ");
                                                    }
                                                    message.append(">");

                                                    message.append(listdata.get(i).get(FIELD_VALUE + fieldIndex));
                                                    message.append("</a> ");
                                                }

                                                flink=true;
                                             
                                        }
                                    }
                                }
                            }
                            if(!flink)
                            {
                                if(listdata.get(i)!=null && listdata.get(i).get(FIELD_VALUE+fieldIndex) !=null)
                                {
                                     if(req.getParameter(IS_PDF)==null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES))
                                     {
                                             message.append(HtmlUtils.htmlUnescape((listdata.get(i).get(FIELD_VALUE + fieldIndex)).toString()));
                                     }
                                     else
                                     {
                                    	 	 message.append((listdata.get(i).get(FIELD_VALUE + fieldIndex)).toString());
                                     }
                                }
                                else
                                {
                                   message.append(" - ");
                                }
                            }

                            message.append("</td>");
                        }
                        message.append("</tr>");

                    }
                   else /*if((tblReportMst.getReportType()!=null && tblReportMst.getReportType().equalsIgnoreCase("L") && reportListingStyle==1))*/ { // Report Type = New Listing view
					if(req.getParameter("txtModuleName").equals("Auction")){ // Report Type = New Listing view
						   boolean isSpecialClient = false;
						   if(clientBean != null && !"".equalsIgnoreCase(clientBean.getSectorTableName())) {
							   isSpecialClient=true;
	                	   }
						   
						   if((((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1 && clientBean.getListingStyle() == 2)) && !(GMRTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1]))){
							   getNewAuctionListingStyle(sectorId,message,req,listdata,userTypeId,i,lstLinkDetail,userId,clientBean.getListingStyle());
						   }else if(clientBean.getListingStyle() == 2 && (sectorId != drtSectorId || sectorId != bankSectorId) && !(GMRTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1]))){
							   getNewAuctionListingStyle(sectorId,message,req,listdata,userTypeId,i,lstLinkDetail,userId,clientBean.getListingStyle());
						   }else{
							   message.append("<tr><td colspan='2' class='a-right'><span>");
		                	   if(isSpecialClient) {
		                		   message.append("<b>").append(messageSource.getMessage("fields_auc_department", null, LocaleContextHolder.getLocale())).append(":</b> ");
		                	   }
		                	   if(clientBean.getIsDIYClient()==0){
		                	   message.append("<b>"); message.append(getFieldValue(listdata,i, 5, req.getParameter(IS_PDF))); message.append("</b>");
		                	   }
		                	   if(isSpecialClient) {
		                		   
		                           if(sectorId != drtSectorId && sectorId != bankSectorId){
			                    	   message.append(" | <b>").append(messageSource.getMessage("fields_auc_auctionfor", null, LocaleContextHolder.getLocale())).append(":</b> ");
				                       message.append(getFieldValue(listdata,i, 7, req.getParameter(IS_PDF)));
		                           }
		                       }
		                	   if(clientBean.getIsDIYClient()==0){
		                		   message.append(" | ");
		                	   }
		                	   message.append("<b>").append(messageSource.getMessage("fields_auc_auctionno", null, LocaleContextHolder.getLocale())).append(":</b> ");
		                       message.append(getFieldValue(listdata,i, 2, req.getParameter(IS_PDF)));
		                       
		                       message.append("</span></td></tr>");
		                	   message.append("<tr><td class='a-center' width='5%'>");	
		                       /*if(i%2!=0)
		                       {
		                           message.append(" style='background:#F2F2F2;'" );
		                           //message.append(" style='background:#fcfcfc;'" );
		                       }*/
		                       //message.append(" width=\"100%\" cellpadding=\"5\" cellspacing=\"5\" border=\"0\"><tr><td valign=\"top\" class=\"srNo\" width=\"16\">");
		                       message.append("<b>").append(((pageNo - 1) * recordOffset + (i + 1))).append(".</b> ");
		                       message.append("</td>");
		                       message.append("<td>");
		                       message.append("<div class=\"details-box\"><p>");
		                       //message.append("<b>").append(messageSource.getMessage("fields_auc_department", null, LocaleContextHolder.getLocale())).append(":</b> ");
		                       //message.append(getFieldValue(listdata,i, 5, req.getParameter(IS_PDF)));
		                       
		                       if(clientBean.getIsDIYClient()!=1 && lstLinkDetail !=null && !lstLinkDetail.isEmpty())
		                       {
		                    	   for(TblReportLinkDetail linkDetail : lstLinkDetail){
		                    		   if(linkDetail.getSortOrder() == 1) {
		                    			   boolean showLink = (linkDetail.getShowField()==0) || (userId != superAdmin && linkDetail.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetail.getShowField(), req.getParameter(IS_PDF))) == 1);
		                    			   /*if(userTypeId!=0 && userTypeId!=2) {
		                    				   showLink = CommonUtility.showLink(String.valueOf(linkDetail.getReportLinkId()));
		                    			   }*/
		                    			   if(showLink) {
		                    				   message.append("<a href=\"");
		                    				   String temp = linkDetail.getUrl();
		                    				   String link = linkDetail.getUrl();
		                    				   for (String t : linkDetail.getUrl().split("::")) {
		                    					   //System.out.println("t=="+t);
		                    					   temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
		                    					   // System.out.println("temp="+temp);
		                    					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
		                    						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
		                    						   // System.out.println("link="+link);
		                    					   }
		                    					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
		                    					   {
		                    						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
		                    						   // System.out.println("link="+link);
		                    					   }
	
		                    				   }
		                    				   if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
		                    					   //System.out.println("original Link====>"+link);
	
		                    					   String secString = "";
		                    					   if (link.startsWith("/")) {
		                    						   secString = link.substring(1, link.length());
		                    					   }
		                    					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
		                    						   secString = encryptDecryptUtils.generateRedirect(secString, req);
		                    						   link = req.getServletContext().getContextPath() + link;
		                    					   }
		                    					   //System.out.println("context path link="+link);
		                    					   //System.out.println("link="+link+secString);
		                    					   message.append(link).append(secString);
		                    				   } else {
		                    					   message.append(handleSpecialChar.handleSpecialChar(link));
		                    				   }
		                    				   if (linkDetail.getAttribute() != null) {
	                                               String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
	                                               if (t.contains("_encrypt")) {
	                                                       t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
	                                                       Object valdata = listdata.get(i).get(FIELD_VALUE + t);
	                                                       if (t.matches("[0-9*]") && valdata != null) {
	                                                               valdata = encryptDecryptUtils.encrypt(valdata.toString());
	                                                               message.append("\" ").append(linkDetail.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
	                                                       }
	                                               } else {
	                                                       //message.append("' ").append(linkDetails.getAttribute()).append(" ");
	                                               	//commented above because href start with ".
	                                            	   message.append("\" ").append(linkDetail.getAttribute()).append(" ");
	                                               }
	                                               message.append(">").append(listdata.get(i).get(FIELD_VALUE + 3).toString().replace("<p>", "").replace("</p>",""));
		                    				   }else{
		                    					   message.append("\">").append(listdata.get(i).get(FIELD_VALUE + 3).toString().replace("<p>", "").replace("</p>",""));
		                    				   }
		                    				   message.append("</a>");
		                    				   break;
		                    			   }
		                    		   }
		                    	   }
		                       }else {
		                    	   message.append(listdata.get(i).get(FIELD_VALUE + 3).toString().replace("<p>", "").replace("</p>",""));
		                       }
		                       
		                       message.append(" | <b>").append(messageSource.getMessage("fields_startdateandtime", null, LocaleContextHolder.getLocale())).append(":</b> ");
		                       message.append(getFieldValue(listdata,i, 4, req.getParameter(IS_PDF)));
		                       
		                       message.append(" | <b>").append(messageSource.getMessage("fields_enddateandtime", null, LocaleContextHolder.getLocale())).append(":</b> ");
		                       message.append(getFieldValue(listdata,i, 6, req.getParameter(IS_PDF)));
		                       
		                       //Event type for auction(English,clock,yankee)
		                       if(userTypeId == 0){
		                    	   message.append(" | <b>").append(messageSource.getMessage("lbl_event_type", null, LocaleContextHolder.getLocale())).append(":</b> ");
			                       message.append(getFieldValue(listdata,i, 9, req.getParameter(IS_PDF)));
		                       }else if(userTypeId != 2){
		                    	   message.append(" | <b>").append(messageSource.getMessage("lbl_event_type", null, LocaleContextHolder.getLocale())).append(":</b> ");
			                       message.append(getFieldValue(listdata,i, 14, req.getParameter(IS_PDF)));
		                       }else{
		                    	   message.append(" | <b>").append(messageSource.getMessage("lbl_event_type", null, LocaleContextHolder.getLocale())).append(":</b> ");
			                       message.append(getFieldValue(listdata,i, 26, req.getParameter(IS_PDF)));
		                       }
		                       
		                       if(isSpecialClient == true){ //check sectorid for drt and bank
	
		                    	   if(sectorId == bankSectorId || sectorId == drtSectorId){
		                            String budgetVal = userTypeId == 2 ? getFieldValue(listdata,i, 20, req.getParameter(IS_PDF)) : getFieldValue(listdata,i, 13, req.getParameter(IS_PDF));
	
		                            if(budgetVal != null && !"".equalsIgnoreCase(budgetVal) &&  !"-".equalsIgnoreCase(budgetVal)){
	
		                                  BigDecimal budget = new BigDecimal(budgetVal);
		                                  budget = budget.setScale(2, BigDecimal.ROUND_HALF_UP);
	
		                                  if(budget != null && budget.compareTo(BigDecimal.ZERO) == 1){
		                                         message.append(" | <b style='font-weight: bold;'>").append(messageSource.getMessage("msg_reserve_price", null, LocaleContextHolder.getLocale())).append(":</b> ");
		                                         message.append(budget);
		                                  }
		                            }
	
		                         }
		                       }
		                       
		                       message.append(" | <b>").append(messageSource.getMessage("fields_aucid", null, LocaleContextHolder.getLocale())).append(":</b> ");
		                       message.append(getFieldValue(listdata,i, 1, req.getParameter(IS_PDF)));
		                       
		                       if(userTypeId!=2){
			                       String l1h1Amt = getFieldValue(listdata,i, 12, req.getParameter(IS_PDF));
			                       if(l1h1Amt!=null && !"".equalsIgnoreCase(l1h1Amt) &&  !"-".equalsIgnoreCase(l1h1Amt) &&  Double.parseDouble(l1h1Amt)==-1.00){
			                    	   message.append(" | <b>").append(messageSource.getMessage("fields_auc_l1h1_amt", null, LocaleContextHolder.getLocale())).append(":</b> ");
				                       message.append("No bid received");
			                       }
			                       else if(l1h1Amt!=null && !"".equalsIgnoreCase(l1h1Amt) &&  !"-".equalsIgnoreCase(l1h1Amt) &&  Double.parseDouble(l1h1Amt)!=0.00){
				                       message.append(" | <b>").append(messageSource.getMessage("fields_auc_l1h1_amt", null, LocaleContextHolder.getLocale())).append(":</b> ");
				                       message.append(l1h1Amt);
			                       }
		                       }
		                       message.append("<br/>");	
		                       
		                       if(isSpecialClient && (sectorId == vehicleSectorId || sectorId == propertySectorId)) { // No. vehicle 
		                    	   if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
			                       {
		                    		   int cnt = Integer.parseInt(listdata.get(i).get(FIELD_VALUE + 8).toString());
		                    		   if(cnt!=0) {
				                    	   for(TblReportLinkDetail linkDetail : lstLinkDetail){
				                    		   if(linkDetail.getSortOrder() == 9) {
				                    			   boolean showLink = (linkDetail.getShowField()==0) || (userId != superAdmin && linkDetail.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetail.getShowField(), req.getParameter(IS_PDF))) == 1);
				                    			   /*if(userTypeId!=0 && userTypeId!=2) {
				                    				   showLink = CommonUtility.showLink(String.valueOf(linkDetail.getReportLinkId()));
				                    			   }*/
				                    			   if(showLink) {
				                    				   message.append("<a href=\"");
				                    				   String temp = linkDetail.getUrl();
				                    				   String link = linkDetail.getUrl();
				                    				   for (String t : linkDetail.getUrl().split("::")) {
				                    					   //System.out.println("t=="+t);
				                    					   temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
				                    					   // System.out.println("temp="+temp);
				                    					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
				                    						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
				                    						   // System.out.println("link="+link);
				                    					   }
				                    					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
				                    					   {
				                    						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
				                    						   // System.out.println("link="+link);
				                    					   }
		
				                    				   }
				                    				   if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
				                    					   //System.out.println("original Link====>"+link);
		
				                    					   String secString = "";
				                    					   if (link.startsWith("/")) {
				                    						   secString = link.substring(1, link.length());
				                    					   }
				                    					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
				                    						   secString = encryptDecryptUtils.generateRedirect(secString, req);
				                    						   link = req.getServletContext().getContextPath() + link;
				                    					   }
				                    					   //System.out.println("context path link="+link);
				                    					   //System.out.println("link="+link+secString);
				                    					   message.append(link).append(secString);
				                    				   } else {
				                    					   message.append(handleSpecialChar.handleSpecialChar(link));
				                    				   }
				                    				   if (linkDetail.getAttribute() != null) {
			                                               String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
			                                               if (t.contains("_encrypt")) {
			                                                       t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
			                                                       Object valdata = listdata.get(i).get(FIELD_VALUE + t);
			                                                       if (t.matches("[0-9*]") && valdata != null) {
			                                                               valdata = encryptDecryptUtils.encrypt(valdata.toString());
			                                                               message.append("\" ").append(linkDetail.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
			                                                       }
			                                               } else {
			                                                       //message.append("' ").append(linkDetails.getAttribute()).append(" ");
			                                               	message.append("\" ").append(linkDetail.getAttribute()).append(" ");
			                                               }
			                                               message.append(">");
				                    				   }else{
				                    					   message.append("\">");
				                    				   }
				                    				   if(sectorId == vehicleSectorId){
				                    					  message.append(messageSource.getMessage("fields_auc_no_of_vehicle", null, LocaleContextHolder.getLocale())).append(": ");
				                    				   }else if(sectorId == propertySectorId){
				                    					   message.append(messageSource.getMessage("fields_auc_no_of_property", null, LocaleContextHolder.getLocale())).append(": ");
				                    				   }
				                    				   message.append(listdata.get(i).get(FIELD_VALUE + 8).toString().replace("<p>", "").replace("</p>",""));
				                    				   message.append("</a> | ");
				                    				   break;
				                    			   }
				                    		   }
				                    	   }
		                    		   }
		                    		   else {
		                    			   if(sectorId == vehicleSectorId){
		                    				   message.append("<b>").append(messageSource.getMessage("fields_auc_no_of_vehicle", null, LocaleContextHolder.getLocale())).append(":</b> ");
		                    			   }else if(sectorId == propertySectorId){
		                    				   message.append("<b>").append(messageSource.getMessage("fields_auc_no_of_property", null, LocaleContextHolder.getLocale())).append(":</b> ");
		                    			   }
		                    			   message.append("0 | "); 
		                    		   }
			                       }
		                       }
		                       if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
		                       {
		                        for(TblReportLinkDetail linkDetails : lstLinkDetail){
		                            if(linkDetails.getSelectFieldId()==0 && "R".equalsIgnoreCase(linkDetails.getFlag())) {
		                                    boolean showLink = (linkDetails.getShowField()==0) || (userId == superAdmin) || (linkDetails.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetails.getShowField(), req.getParameter(IS_PDF))) == 1);
		                                    /*if(userTypeId!=0 && userTypeId!=2) {
		                                            showLink = CommonUtility.showLink(String.valueOf(linkDetails.getReportLinkId()));
		                                    }*/
		                                    if(showLink) {
		                                            String temp = linkDetails.getUrl();
		                                            String link = linkDetails.getUrl();
	
		                                            for (String t : linkDetails.getUrl().split("::")) {
		                                                    //System.out.println("t=="+t);
		                                                    temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
		                                                    // System.out.println("temp="+temp);
		                                                    if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
		                                                            link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
		                                                            // System.out.println("link="+link);
		                                                    }
		                                                    else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
		                                                    {
		                                                            link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
		                                                            // System.out.println("link="+link);
		                                                    }
	
		                                            }
	
		                                            message.append("<a href=\"");
		                                            if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
		                                                    //System.out.println("original Link====>"+link);
	
		                                                    String secString = "";
		                                                    String CSPhash = "#";
		                                                    if (link.startsWith("/")) {
		                                                            secString = link.substring(1, link.length());
		                                                    }
		                                                    if (!link.equalsIgnoreCase("javascript:void(0)")) {
		                                                            secString = encryptDecryptUtils.generateRedirect(secString, req);
		                                                            link = req.getServletContext().getContextPath() + link;
		                                                    }
		                                                    // System.out.println("context path link="+link);
		                                                    //System.out.println("link="+link+secString);
		                                                    /* CSP BEFORE LOGIN */
		                                                    if(linkDetails.getReportLinkId() == 551 || linkDetails.getReportLinkId() == 555) {
		                                                    	message.append(CSPhash);
	                                                    	}else {
		                                                    message.append(link).append(secString);
	                                                    	}
		                                            } else {
		                                                    message.append(handleSpecialChar.handleSpecialChar(link));
		                                            }
		                                            if (linkDetails.getAttribute() != null) {
		                                                    String t = linkDetails.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
		                                                    if (t.contains("_encrypt")) {
		                                                            t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
		                                                            Object valdata = listdata.get(i).get(FIELD_VALUE + t);
		                                                            if (t.matches("[0-9*]") && valdata != null) {
		                                                                    valdata = encryptDecryptUtils.encrypt(valdata.toString());
		                                                                    message.append("\" ").append(linkDetails.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
		                                                            }
		                                                    } else {
		                                                            //message.append("' ").append(linkDetails.getAttribute()).append(" ");
		                                                    	//commented above because href start with ".
//		                                                    	message.append("\" ").append(linkDetails.getAttribute()).append(" ");
		                                                    	message.append("\" ").append(linkDetails.getAttribute().replace("::" + 1, listdata.get(i).get(FIELD_VALUE+ 1).toString()));
		                                                    }
		                                                    if (linkDetails.getLinkCaption() != null && linkDetails.getLinkCaption() != "")
			                                            	{
			                                                    message.append("\"");
			                                        			message.append(" title=\"").append("").append(linkDetails.getLinkCaption()).append("\"");
			                                            	}
		                                                    message.append(">");
		                                            }else{
		                                            	if (linkDetails.getLinkCaption() != null && linkDetails.getLinkCaption() != "")
		                                            	{
			                                            	message.append("\"");
			                                				message.append(" title=\"").append("").append(linkDetails.getLinkCaption());
		                                            	}
		                                            	message.append("\">");
		                                            }
		                                            
		                                            if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
		                                                    message.append(linkDetails.getLinkCaption());
		                                            } else {
		                                                    message.append(handleSpecialChar.handleSpecialChar(linkDetails.getLinkCaption()));
		                                            }
		                                        	
		                                            message.append("</a> | ");
		                                    }
		                            }
		                        }
		                    }
		                      message.delete(message.length()-3, message.length());
		                      
		                      if(userTypeId==0){
		                    	String cancelledStatus  = getFieldValue(listdata,i, 14, req.getParameter(IS_PDF));
		                    	if(!cancelledStatus.equals("") && !cancelledStatus.equals("-")){
		                    		message.append(" | ").append("<b>").append(messageSource.getMessage("fields_auc_docstatus", null, LocaleContextHolder.getLocale())).append(": ").append("<font style='font-weight:bold' color='red'>").append(getFieldValue(listdata,i, 14, req.getParameter(IS_PDF))).append("</font>").append("</b>");
		                    	}
		                      }
		                       //message.append("</td></tr></table>");
		                       message.append("</div>");
	                       //message.append("</td></tr>");
	                   }// end - if(req.getParameter("txtModuleName").equals("Auction"))
					}
                   else if(req.getParameter("txtModuleName").equals("Tender")){/* This is for module Tender. For Next Module add else if(req.getParameter("txtModuleName").equals("NextModuleName"))   */
                	   /*
                	    * For Tender Module
                	    */
                	   if((((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1 && clientBean.getListingStyle() == 2)) && !(GMRTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1]))){
						   getNewTenderListingStyle(sectorId,message,req,listdata,userTypeId,i,lstLinkDetail,userId,clientBean.getListingStyle(),tabValue,isSearchPerformed);
                	   }else if(clientBean.getListingStyle() == 2 && (sectorId != drtSectorId || sectorId != bankSectorId) && !(GMRTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1]))){
                		   getNewTenderListingStyle(sectorId,message,req,listdata,userTypeId,i,lstLinkDetail,userId,clientBean.getListingStyle(),tabValue,isSearchPerformed);
                	   }else{
	                		   
	                	   message.append("<tr><td colspan='2' class='a-right'><span>");
	                	   //message.append("<b>").append(messageSource.getMessage("fields_ten_department", null, LocaleContextHolder.getLocale())).append(":</b> ");
	                	   message.append("<b>"); message.append(getFieldValue(listdata,i, 4, req.getParameter(IS_PDF))); message.append("</b>");
	                       
	                	   message.append(" | <b>").append(messageSource.getMessage("fields_ten_refno", null, LocaleContextHolder.getLocale())).append(":</b> ");
	                       String tempString=getFieldValue(listdata,i, 2, req.getParameter(IS_PDF));
	                       message.append(StringUtils.hasLength(tempString) && tempString.length() > 30 ? tempString.substring(0,30) : tempString);
	                       message.append("</span></td></tr>");
	                	   message.append("<tr><td class='a-center' width='5%'>");
	                	   message.append(((pageNo - 1) * recordOffset + (i + 1)));
	                	   message.append(".</b></td>");
	                       message.append("<td>");
	                	   message.append("<div class=\"details-box\"><p>");
	                       if(i%2!=0)
	                       {
	                           //message.append(" style='background:#F2F2F2;'" );
	                           //message.append(" style='background:#fcfcfc;'" );
	                       }
	                       //message.append(" width=\"100%\" cellpadding=\"5\" cellspacing=\"5\" border=\"0\"><tr><td valign=\"top\" class=\"srNo\" width=\"16\">");
	                       //message.append(".</td>");
	                       
	                       // start - Event Brief link
	                       if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
	                       {
	                    	   for(TblReportLinkDetail linkDetail : lstLinkDetail){
	                    		   if(linkDetail.getSortOrder() == 1) {
	                    			   boolean showLink = (linkDetail.getShowField()==0) || (userId != superAdmin && linkDetail.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetail.getShowField(), req.getParameter(IS_PDF))) == 1);
	                    			   /*if(userTypeId!=0 && userTypeId!=2) {
	                    				   showLink = CommonUtility.showLink(String.valueOf(linkDetail.getReportLinkId()));
	                    			   if(userTypeId!=0 && userTypeId!=2 && linkDetail.getLinkId() != 0) {
	                    				   showLink = CommonUtility.showLink(String.valueOf(linkDetail.getLinkId()));
	
	                    			   }*/
	                    			   if(showLink) {
	                    				   message.append("<a href=\"");
	                    				   String temp = linkDetail.getUrl();
	                    				   String link = linkDetail.getUrl();
	                    				   for (String t : linkDetail.getUrl().split("::")) {
	                    					   //System.out.println("t=="+t);
	                    					   temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
	                    					   // System.out.println("temp="+temp);
	                    					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
	                    						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
	                    						   // System.out.println("link="+link);
	                    					   }
	                    					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
	                    					   {
	                    						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
	                    						   // System.out.println("link="+link);
	                    					   }
	
	                    				   }
	                    				   if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
	                    					   //System.out.println("original Link====>"+link);
	
	                    					   String secString = "";
	                    					   if (link.startsWith("/")) {
	                    						   secString = link.substring(1, link.length());
	                    					   }
	                    					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
	                    						   secString = encryptDecryptUtils.generateRedirect(secString, req);
	                    						   link = req.getServletContext().getContextPath() + link;
	                    					   }
	                    					   //System.out.println("context path link="+link);
	                    					   //System.out.println("link="+link+secString);
	                    					   message.append(link).append(secString);
	                    				   } else {
	                    					   message.append(handleSpecialChar.handleSpecialChar(link));
	                    				   }
	                    				   if (linkDetail.getAttribute() != null) {
	                                           String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
	                                           if (t.contains("_encrypt")){
	                                               t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
	                                               Object valdata = listdata.get(i).get(FIELD_VALUE + t);
	                                               if (t.matches("[0-9*]") && valdata != null) {
	                                                       valdata = encryptDecryptUtils.encrypt(valdata.toString());
	                                                       message.append("\" ").append(linkDetail.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
	                                               }
	                                           }else{
	                                                   //message.append("' ").append(linkDetails.getAttribute()).append(" ");
	                                        	 //commented above because href start with ".
	                                        	   message.append("\" ").append(linkDetail.getAttribute()).append(" ");
	                                           }
	                                           message.append(">").append(listdata.get(i).get(FIELD_VALUE + 7));
		                                   }else{
		                                	   message.append("\">").append(listdata.get(i).get(FIELD_VALUE + 7));
		                                   }
	
	                    				   message.append("</a>");
	                    				   break;
	                    			   }
	                    		   }
	                    	   }
	                       }
	                    // End - Event Brief link
	                       
	                       message.append(" | <b>").append(messageSource.getMessage("fields_duedateandtime", null, LocaleContextHolder.getLocale())).append(":</b> ");
	                       message.append(getFieldValue(listdata,i, 5, req.getParameter(IS_PDF))); 
	                       
	                       message.append(" | <b>").append(messageSource.getMessage("fields_eventid", null, LocaleContextHolder.getLocale())).append(":</b> ");
	                       message.append(getFieldValue(listdata,i, 1, req.getParameter(IS_PDF)));
	                       
	                       message.append("<br/>");
	                       
	                    // start - Action:10
	                       if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
	                       {
	                        for(TblReportLinkDetail linkDetails : lstLinkDetail){
	                            if(linkDetails.getSortOrder() > 2) {
	                                    boolean showLink = (linkDetails.getShowField()==0) || (userId != superAdmin && linkDetails.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetails.getShowField(), req.getParameter(IS_PDF))) == 1);                                   
	                                   /* if(userTypeId!=0 && userTypeId!=2) {
	
	                                            showLink = CommonUtility.showLink(String.valueOf(linkDetails.getReportLinkId()));
	                                    if(userTypeId!=0 && userTypeId!=2  && linkDetails.getLinkId() != 0) {
	                                            showLink = CommonUtility.showLink(String.valueOf(linkDetails.getLinkId()));
	
	                                    }*/
	                                    if(userTypeId==2 && linkDetails.getSortOrder()==3) { /*Bidder side 'Download document' link*/
	                                    	showLink = false;
	                                    	String docStDate=getFieldValue(listdata,i, 24, req.getParameter(IS_PDF));
	                                    	String docEnDate=getFieldValue(listdata,i, 25, req.getParameter(IS_PDF));
	                                    	if(docStDate!=null && !"-".equalsIgnoreCase(docStDate) && docEnDate!=null && !"-".equalsIgnoreCase(docEnDate)) {
	                                    		showLink = true;
	                                    	}
	                                    }
	                                    if(showLink) {
	                                            String temp = linkDetails.getUrl();
	                                            String link = linkDetails.getUrl();
	
	                                            for (String t : linkDetails.getUrl().split("::")) {
	                                                    //System.out.println("t=="+t);
	                                                    temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
	                                                    // System.out.println("temp="+temp);
	                                                    if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
	                                                            link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
	                                                            // System.out.println("link="+link);
	                                                    }
	                                                    else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
	                                                    {
	                                                            link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
	                                                            // System.out.println("link="+link);
	                                                    }
	
	                                            }
	
	                                            message.append("<a href=\"");
	                                            if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
	                                                    //System.out.println("original Link====>"+link);
	
	                                                    String secString = "";
	                                                    String CSPhash = "#";
	                                                    if (link.startsWith("/")) {
	                                                            secString = link.substring(1, link.length());
	                                                    }
	                                                    if (!link.equalsIgnoreCase("javascript:void(0)")) {
	                                                            secString = encryptDecryptUtils.generateRedirect(secString, req);
	                                                            link = req.getServletContext().getContextPath() + link;
	                                                    }
	                                                    // System.out.println("context path link="+link);
	                                                    //System.out.println("link="+link+secString);
	                                                    /* CSP BEFORE LOGIN */
	                                                    if(linkDetails.getReportLinkId() == 553) {
	                                                    	message.append(CSPhash);
	                                                    }
	                                                    else {
	                                                    message.append(link).append(secString);
	                                                    }
	                                            } else {
	                                                    message.append(handleSpecialChar.handleSpecialChar(link));
	                                            }
	                                            if (linkDetails.getAttribute() != null) {
	                                                    String t = linkDetails.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
	                                                    if (t.contains("_encrypt")) {
	                                                            t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
	                                                            Object valdata = listdata.get(i).get(FIELD_VALUE + t);
	                                                            if (t.matches("[0-9*]") && valdata != null) {
	                                                                    valdata = encryptDecryptUtils.encrypt(valdata.toString());
	                                                                    message.append("\" ").append(linkDetails.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
	                                                            }
	                                                    } else {
	                                                            //message.append("' ").append(linkDetails.getAttribute()).append(" ");
	                                                    	//commented above because href start with ".	
	                                                    	//message.append("\" ").append(linkDetails.getAttribute()).append(" ");
	                                                    	message.append("\" ").append(linkDetails.getAttribute().replace("::" + 1, listdata.get(i).get(FIELD_VALUE+ 1).toString()));
	                                                    }
	                                                    if (linkDetails.getLinkCaption() != null && linkDetails.getLinkCaption() != "")
		                                            	{
		                                                    message.append("\"");
			                                    			message.append(" title=\"").append("").append(linkDetails.getLinkCaption()).append("\"");
		                                            	}
	                                                    message.append(">");
	                                            }else{
	                                            	if (linkDetails.getLinkCaption() != null && linkDetails.getLinkCaption() != "")
	                                            	{
		                                            	message.append("\"");
		                                    			message.append(" title=\"").append("").append(linkDetails.getLinkCaption());
	                                            	}
	                                            	message.append("\">");
	                                            }
	
	                                            if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
	                                                    message.append(linkDetails.getLinkCaption());
	                                            } else {
	                                                    message.append(handleSpecialChar.handleSpecialChar(linkDetails.getLinkCaption()));
	                                            }
	                                            message.append("</a> | ");
	                                    }
	                            }
	                        }
	                    }
	                    //End - Action:10
	
	                       message.append("<b>").append(messageSource.getMessage("fields_eventtype", null, LocaleContextHolder.getLocale())).append(":</b> ");
	                       message.append(getFieldValue(listdata,i, 3, req.getParameter(IS_PDF)));
	                       
	                       // start - corrigendum:6(count hyper link)
	                       short corgndmCount = (Short) listdata.get(i).get(FIELD_VALUE + 6);
	                       message.append(" | <b>").append(messageSource.getMessage("fields_corrigendum_count", null, LocaleContextHolder.getLocale())).append(":</b>&nbsp");
	                       if(corgndmCount!=0){ /* corrigendum is not zero so Show link*/
		                       if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
		                       {
		                    	   for(TblReportLinkDetail linkDetail : lstLinkDetail){
		                    		   
		                    		   if(linkDetail.getSortOrder() == 2) {
		                    			   boolean showLink = (linkDetail.getShowField()==21) || (userId != superAdmin && linkDetail.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetail.getShowField(), req.getParameter(IS_PDF))) == 1);
	
		                    			  /* if(userTypeId!=0 && userTypeId!=2) {
		                    				   showLink = CommonUtility.showLink(String.valueOf(linkDetail.getReportLinkId()));
		                    			   }*/
		                    			   if(showLink) {
		                    				   message.append("<a href=\"");
		                    				   String temp = linkDetail.getUrl();
		                    				   String link = linkDetail.getUrl();
		                    				   for (String t : linkDetail.getUrl().split("::")) {
		                    					   //System.out.println("t=="+t);
		                    					   temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
		                    					   // System.out.println("temp="+temp);
		                    					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
		                    						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
		                    						   // System.out.println("link="+link);
		                    					   }
		                    					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
		                    					   {
		                    						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
		                    						   // System.out.println("link="+link);
		                    					   }
		
		                    				   }
		                    				   if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
		                    					   //System.out.println("original Link====>"+link);
		
		                    					   String secString = "";
		                    					   if (link.startsWith("/")) {
		                    						   secString = link.substring(1, link.length());
		                    					   }
		                    					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
		                    						   secString = encryptDecryptUtils.generateRedirect(secString, req);
		                    						   link = req.getServletContext().getContextPath() + link;
		                    					   }
		                    					   //System.out.println("context path link="+link);
		                    					   //System.out.println("link="+link+secString);
		                    					   message.append(link).append(secString);
		                    				   } else {
		                    					   message.append(handleSpecialChar.handleSpecialChar(link));
		                    				   }
		                    				   if (linkDetail.getAttribute() != null) {
	                                               String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
	                                               if (t.contains("_encrypt")) {
	                                                       t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
	                                                       Object valdata = listdata.get(i).get(FIELD_VALUE + t);
	                                                       if (t.matches("[0-9*]") && valdata != null) {
	                                                               valdata = encryptDecryptUtils.encrypt(valdata.toString());
	                                                               message.append("\" ").append(linkDetail.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
	                                                       }
	                                               } else {
	                                                       //message.append("' ").append(linkDetails.getAttribute()).append(" ");
	                                            	 //commented above because href start with ".	
	                                            	   message.append("\" ").append(linkDetail.getAttribute()).append(" ");
	                                               	}
	                                               message.append(">").append(listdata.get(i).get(FIELD_VALUE + 6));
		                                       }else{
		                                    	   message.append("\">").append(listdata.get(i).get(FIELD_VALUE + 6));
		                                       }
		                    				   message.append("</a>  <i id='txtblnk' class='red'> Updated </i> | ");
		                    				  // message.append(")");
		                    				   break;
		                    			   }
		                    		   }
		                    	   }
		                       }
	                       }
	                       else{ /* corrigendum is zero, so don't show link just display 0*/
	                    	   message.append(getFieldValue(listdata,i, 6, req.getParameter(IS_PDF))).append(" | ");
	                       }
	
	                       // end - corrigendum:6(count hyper link)
	                       
	                       // PT : 33589 By Jitendra. Show tender status in tender listing when event is searched & in All tab. And in home page listing.
	                       if(userTypeId != 0){
	                    	   if(tabValue.equals("All") || !req.getParameter("txtparam10").equals("") || isSearchPerformed){
	                    		   message.append("<b>").append(messageSource.getMessage("fields_eventstatus", null, LocaleContextHolder.getLocale())).append(":</b> ");
	                               message.append(getFieldValue(listdata,i, 10, req.getParameter(IS_PDF)));
	                    	   }
	                       }else{ 
	                    	   message.append("<b>").append(messageSource.getMessage("fields_eventstatus", null, LocaleContextHolder.getLocale())).append(":</b> ");
	                    	   int isLiveEvent = (Integer) listdata.get(i).get(FIELD_VALUE + 8);
	                    	   // Bug #33959 by Jitendra. Show status in link only if tender status is cancelled else in label. Also Bug 34061.
	                    	   if(isLiveEvent == 0){
	                    		   if(lstLinkDetail !=null && !lstLinkDetail.isEmpty()){
	                    			   for(TblReportLinkDetail linkDetail : lstLinkDetail){
	                    				   if(linkDetail.getSortOrder() == 0) {
	                    					   boolean showLink = (linkDetail.getShowField()==8);
	                    					   if(showLink){
	                    						   message.append("<a href=\"");
	    	                    				   String temp = linkDetail.getUrl();
	    	                    				   String link = linkDetail.getUrl();
	    	                    				   for (String t : linkDetail.getUrl().split("::")) {
	    	                    					   //System.out.println("t=="+t);
	    	                    					   temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
	    	                    					   // System.out.println("temp="+temp);
	    	                    					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
	    	                    						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
	    	                    						   // System.out.println("link="+link);
	    	                    					   }
	    	                    					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
	    	                    					   {
	    	                    						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
	    	                    						   // System.out.println("link="+link);
	    	                    					   }
	    	
	    	                    				   }
	    	                    				   if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
	    	                    					   String secString = "";
	    	                    					   if (link.startsWith("/")) {
	    	                    						   secString = link.substring(1, link.length());
	    	                    					   }
	    	                    					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
	    	                    						   secString = encryptDecryptUtils.generateRedirect(secString, req);
	    	                    						   link = req.getServletContext().getContextPath() + link;
	    	                    					   }
	    	                    					   message.append(link).append(secString);
	    	                    				   } else {
	    	                    					   message.append(handleSpecialChar.handleSpecialChar(link));
	    	                    				   }
	    	                    				   if (linkDetail.getAttribute() != null) {
	                                                   String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
	                                                   if (t.contains("_encrypt")) {
	                                                           t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
	                                                           Object valdata = listdata.get(i).get(FIELD_VALUE + t);
	                                                           if (t.matches("[0-9*]") && valdata != null) {
	                                                        	   valdata = encryptDecryptUtils.encrypt(valdata.toString());
	                                                               message.append("\" ").append(linkDetail.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
	                                                           }
	                                                   } else {
	                                                	   message.append("\" ").append(linkDetail.getAttribute()).append(" ");
	                                                   	}
	                                                   message.append(">").append(listdata.get(i).get(FIELD_VALUE + 9));
	    	                                       }else{
	    	                                    	   message.append("\">").append(listdata.get(i).get(FIELD_VALUE + 9));
	    	                                       }
	    	                    				   message.append("</a>");
	    	                    				   break;
	                    					   }
	                    				   }
	    	                    	   }
	    	                       }
	                    	   }else{
	                    		   message.append(getFieldValue(listdata,i, 9, req.getParameter(IS_PDF)));
	                    	   }   
	                       }
	                	   
	                       message.append("</div>");
	                       //message.append("</td></tr>");
                	   }
                   }/*End - else for  if(req.getParameter("txtModuleName").equals("Auction"))*/
                   else if(req.getParameter("txtModuleName").equals("statistics")) //PT: 20745
                   {
                	   /* This is for module Tender. For Next Module add else if(req.getParameter("txtModuleName").equals("NextModuleName"))   */
                	   /*
                	    * For Tender Module
                	    */
                	   
                	   message.append("<tr><td colspan='2' class='a-right'><span class='black'>");
                	   //message.append("<b>").append(messageSource.getMessage("fields_ten_department", null, LocaleContextHolder.getLocale())).append(":</b> ");
                	   //message.append(" <b>").append(messageSource.getMessage("fields_categoryName", null, LocaleContextHolder.getLocale())).append(":</b> ");
                       message.append(getFieldValue(listdata,i, 2, req.getParameter(IS_PDF)));
                       message.append("</span></td></tr>");
                	   message.append("<tr><td class='a-center' width='5%'>");
                	   message.append(((pageNo - 1) * recordOffset + (i + 1)));
                	   message.append(".</b></td>");
                       message.append("<td>");
                	   message.append("<div class=\"details-box\"><p>");
                	   message.append(" <b>").append(messageSource.getMessage("fields_noofevents_catattr", null, LocaleContextHolder.getLocale())).append(":</b> ");
                       message.append(getFieldValue(listdata,i, 3, req.getParameter(IS_PDF)));
                       message.append(" | <b>").append(messageSource.getMessage("fields_procurementvalue_catattr", null, LocaleContextHolder.getLocale())).append(":</b> ");
                       message.append(getFieldValue(listdata,i, 6, req.getParameter(IS_PDF)));
                       message.append(" | <b>").append(messageSource.getMessage("fields_savings_catattr", null, LocaleContextHolder.getLocale())).append(":</b> ");
                       message.append(getFieldValue(listdata,i, 7, req.getParameter(IS_PDF)));
                       message.append("<br/>");
                       message.append(" <b>").append(messageSource.getMessage("fields_uniquesupplier_catattr", null, LocaleContextHolder.getLocale())).append(":</b> ");
                       message.append(getFieldValue(listdata,i, 5, req.getParameter(IS_PDF)));
                       message.append(" | <b>").append(messageSource.getMessage("fields_uniquebuyers_catattr", null, LocaleContextHolder.getLocale())).append(":</b> ");
                       message.append(getFieldValue(listdata,i, 4, req.getParameter(IS_PDF)));
                       message.append("</p>");
                       if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
                       {
                    	   message.append("<div class='a-right v-a-top'>");
	                        for(TblReportLinkDetail linkDetails : lstLinkDetail){
	                        	
	                        	
	                        	String attr = linkDetails.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
                                if(attr != null && attr.contains("::"))
                                {
                                    
                                	String finalAttri="";
                                    String temp = "";
                                    //System.out.println(linkDetail.getAttribute());
                                     for(String t1 : linkDetails.getAttribute().split("\'"))
                                        {
                                            if(t1.contains("::") && t1.contains("_encrypt"))
                                            {
                                                temp=t1.replace("::", "");
                                                temp=temp.replace("_encrypt", "");
                                               // System.out.println("temp="+temp);
                                                if(temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE+temp) != null)
                                                {
                                                    finalAttri+=encryptDecryptUtils.encrypt(listdata.get(i).get(FIELD_VALUE+temp).toString())+"'";
                                                }
                                                // System.out.println(finalAttri);
                                            }
                                            else if(t1.contains("::"))
                                            {
                                                temp=t1.replace("::", "");
                                                temp=temp.replace("_encrypt", "");
                                               /// System.out.println("temp="+temp);
                                                if(temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE+temp) != null)
                                                {
                                                    finalAttri+=listdata.get(i).get(FIELD_VALUE+temp).toString()+"'";
                                                }
                                                // System.out.println(finalAttri);
                                            }
                                            else
                                            {
                                                finalAttri +=t1+"'";
                                            }

                                        }
                                     attr = finalAttri= finalAttri.substring(0,finalAttri.length()-1);
                                }else{
                                	attr = linkDetails.getAttribute();
                                }
                                 
	                        	
	                        	
	                        	if(linkDetails.getSortOrder() == 1){
	                        		 message.append("<b><a href=\""+linkDetails.getUrl()+"\" "+attr+"  >"+linkDetails.getLinkCaption()+"</a></b>");
	                        	}else if(linkDetails.getSortOrder() == 2){
	                        		message.append(" | <b><a href=\""+linkDetails.getUrl()+"\" "+attr+"  >"+linkDetails.getLinkCaption()+"</a></b>");
	                        	}else if(linkDetails.getSortOrder() == 3){
	                        		if(hs.getAttribute(CommonKeywords.SESSION_OBJ.toString()) == null){
	                        			message.append(" | <b><a onclick='loginWindow();' href='javascript:void(0)'>"+linkDetails.getLinkCaption()+"</a></b>");
	                        		}else{
	                        			String temp = linkDetails.getUrl();
	                        			String link = linkDetails.getUrl();
	                        			if(userTypeId == 2)
	                        			{
	                        				temp  = "/common/bidder/viewbidderprofile/"+userId;
	                        				link = "/common/bidder/viewbidderprofile/"+userId;
	                        			}else {
	                        			
	                        			 for (String t : linkDetails.getUrl().split("::")) {
	                    					   //System.out.println("t=="+t);
	                    					   temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
	                    					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
	                    						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
	                    						   // System.out.println("link="+link);
	                    					   }
	                    					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
	                    					   {
	                    						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
	                    						   // System.out.println("link="+link);
	                    					   }
	
	                    				   }
	                        			}
	                        			   String secString = "";
	                  					   if (link.startsWith("/")) {
	                  						   secString = link.substring(1, link.length());
	                  					   }
	                  					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
	                  						   secString = encryptDecryptUtils.generateRedirect(secString, req);
	                  						   link = req.getServletContext().getContextPath() + link;
	                  					   }
	                        			//message.append(" | <b><a href=\""+linkDetails.getUrl()+"\">"+linkDetails.getLinkCaption()+"</a></b>");
	                  					 message.append(" | <b><a href=\"").append(link).append(secString).append("\">"+linkDetails.getLinkCaption()+"</a></b>");
	                        		}
	                        	}
	                        }
                        message.append("</div></div>");
                    }
                   }  else if(req.getParameter("txtModuleName").equals("Advertise")) //PT: 20745
                   {
                	   message.append("<tr><td class='a-center' width='5%'><span>");
                	   message.append(((pageNo - 1) * recordOffset + (i + 1)));
                	   message.append(".</b></td>");
                	   message.append("<td>");
                	   message.append("<div class=\"details-box\"><p>");
                	   message.append("<b>").append(messageSource.getMessage("fields_advertise_no", null, LocaleContextHolder.getLocale())).append(":</b> ");
                	   if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
                       {
                    	   for(TblReportLinkDetail linkDetail : lstLinkDetail){
                    		   if(linkDetail.getSortOrder() ==2) {
                    			   boolean showLink = (linkDetail.getShowField()==1) || (userId != superAdmin && linkDetail.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetail.getShowField(), req.getParameter(IS_PDF))) == 1);
                    			   if(showLink) {
                    				   message.append("<a href=\"");
                    				   String temp = linkDetail.getUrl();
                    				   String link = linkDetail.getUrl();
                    				   for (String t : linkDetail.getUrl().split("::")) {
                    					  temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
                    					  System.out.println("temp="+temp);
                    					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
                    						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
                    						}
                    					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
                    					   {
                    						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
                    					   }
                    				   }
                    				   if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
                    					   String secString = "";
                    					   if (link.startsWith("/")) {
                    						   secString = link.substring(1, link.length());
                    					   }
                    					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
                    						   secString = encryptDecryptUtils.generateRedirect(secString, req);
                    						   link = req.getServletContext().getContextPath() + link;
                    					   }
                    					   message.append(link).append(secString);
                    				   } else {
                    					   message.append(handleSpecialChar.handleSpecialChar(link));
                    				   }
                    				   message.append("\">").append(listdata.get(i).get(FIELD_VALUE + 1));
                    				   message.append("</a>");
                    				   break;
                    			   }
                    		   }
                    	   }
                       }
                	   message.append(" | <b>").append(messageSource.getMessage("fields_paper_advertise_no", null, LocaleContextHolder.getLocale())).append(":</b> ");
                	   message.append(getFieldValue(listdata,i, 2, req.getParameter(IS_PDF)));
                	   message.append(" | <b>").append(messageSource.getMessage("fields_duedateandtime", null, LocaleContextHolder.getLocale())).append(":</b> ");
                	   message.append(getFieldValue(listdata,i, 3, req.getParameter(IS_PDF))); 
                	}
               }
                if (tblReportMst!= null && tblReportMst.getPaggingExist().equalsIgnoreCase(YES) && (req.getParameter(IS_PDF)==null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) )
                {
                    totalPages = Integer.parseInt(spOutput.get("@v_totalPages").toString());
                    if (totalPages == 0)
                    {
                        totalPages = 1;
                    }
                }
                if((req.getParameter(IS_PDF)==null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) && !req.getRequestURI().contains("excel") )
                {
	                message.append("<input type=\"hidden\" id=\"cntTenBrief\" value=\"");
	                message.append(i);
	                message.append("\">");
	                message.append("<input type=\"hidden\" id=\"totalPages\" value=\"");
	                message.append(totalPages);
	                message.append( "\">");
	                message.append("<input type=\"hidden\" name=\"totalRecords\" id=\"totalRecords\" value=\"");
	                message.append(spOutput.get("@v_totalRecords"));
	                message.append("\">");
                    message.append("<input type=\"hidden\" name=\"tabCountsDetails\" id=\"tabCountsDetails\" value=\"");
	                message.append(spOutput.get("@v_tabCountDetails"));
	                message.append("\">");
                }
                
                if(mv!=null)
                {
                    mv.addAttribute("totalRecords", spOutput.get("@v_totalRecords"));
                    mv.addAttribute("searchCriteria", searchCriteria.toString());
                }
                
                //System.message.appendln("Total Records::::::::::::::::::::::::::::"+listdata.get(0).get("TotalRecords"));
            }
           }
            else
            {
            	//message.append("<tr><td colspan='").append(arrHeading.length + 1).append("'>&nbsp;</td></tr>");
            	
                if((((sectorId == drtSectorId || sectorId == bankSectorId) && clientBean.getIsHomePageRequire() == 1 && clientBean.getListingStyle() == 2 && (req.getParameter("txtModuleName") != null ? (req.getParameter("txtModuleName").equals("Auction") || req.getParameter("txtModuleName").equals("Tender")) : false))) && (!GMRTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1]))){
            		message.append("<div class='listing'>");
				    message.append("<div class='no-data-found' id='noRecordFound' value='noRecordFound'><img src='"+req.getContextPath()+"/resources/property/images/NoDataFound.png' alt='NoDataFound.png'/></div>");
				    message.append("</div>");
            	}else if((sectorId != drtSectorId || sectorId != bankSectorId) && clientBean.getListingStyle() == 2 && (req.getParameter("txtModuleName") != null ? (req.getParameter("txtModuleName").equals("Auction") || req.getParameter("txtModuleName").equals("Tender")) : false) && !(GMRTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1]))){
            		message.append("<div class='listing'>");
				    message.append("<div class='no-data-found' id='noRecordFound' value='noRecordFound'><img src='"+req.getContextPath()+"/resources/property/images/NoDataFound.png' alt='NoDataFound.png'/></div>");
				    message.append("</div>");
            	}else{
            		if(GMRTemplateId.equals(WebUtils.getCookie(req, "theme").getValue().toString().split("-")[1]) && ((req.getParameter("txtModuleName") != null ? (req.getParameter("txtModuleName").equals("Auction") || req.getParameter("txtModuleName").equals("Tender")) : false))){
            			message.append("<div class='listing'>");
    				    message.append("<div class='no-data-found' id='noRecordFound' value='noRecordFound'><img src='"+req.getContextPath()+"/resources/template/template3/images/NoDataFound.png' alt='NoDataFound.png'/></div>");
    				    message.append("</div>");
            		}else{
            			message.append("<tr>");
            			message.append("<td colspan='").append(arrHeading.length + 1).append("' id='noRecordFound' value='noRecordFound' height='30' class='t-align-center v-a-middle'>").append(messageSource.getMessage("empty_record", null, LocaleContextHolder.getLocale())).append("</td>");
            			message.append("</tr>");
            		}
            	}
                if((req.getParameter(IS_PDF)==null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) && !req.getRequestURI().contains("excel") )
                {
	                message.append("<input type=\"hidden\" id=\"cntTenBrief\" value=\"0\">");
	                message.append("<input type=\"hidden\" id=\"totalPages\" value=\"0\">");
	                message.append("<input type=\"hidden\" id=\"totalRecords\" value=\"0\">");
                    message.append("<input type=\"hidden\" id=\"tabCountsDetails\" value=\"0\">");
                }
            }
           if((req.getParameter(IS_PDF)==null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) && !req.getRequestURI().contains("excel") )
           {
        	   message.append("<input type=\"hidden\" name=\"searchCriteria\" id=\"searchCriteria\" value=\"").append(searchCriteria.toString()).append("\">");
           }
           if((((sectorId != drtSectorId || sectorId != bankSectorId) && clientBean.getIsHomePageRequire() != 1 )) || clientBean.getListingStyle() != 2){
        	   message.append("</td></tr>");	
           }
        } // End of session check
        else
        {
                message.append("sessionexpired");
        }
        return message;
    }
    
    private void getNewTenderListingStyle(int sectorId, StringBuilder message, HttpServletRequest req,
		List<LinkedHashMap<String, Object>> listdata, int userTypeId, int i, List<TblReportLinkDetail> lstLinkDetail,
		int userId, int listingStyle, String tabValue, boolean isSearchPerformed) {
    	message.append("<div class='new-listing'>");
	   	message.append("<table>");
	   	
	   	message.append("<tr>");	
   	    message.append("<td colspan='2' class='listing-subtitle'>");
   	    message.append(" Event Information ");	
   	    message.append("</td>");	
   	    message.append("</tr>");
	   	
   	    message.append("<tr>");	
   		message.append("<th>");	
   		message.append("Brief scope of work :");
   		message.append("</th>");
   	    message.append("<td>");
   	// start - Event Brief link
	   	    if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
	           {
	        	   for(TblReportLinkDetail linkDetail : lstLinkDetail){
	        		   if(linkDetail.getSortOrder() == 1) {
	        			   boolean showLink = (linkDetail.getShowField()==0) || (userId != superAdmin && linkDetail.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetail.getShowField(), req.getParameter(IS_PDF))) == 1);
	        			   /*if(userTypeId!=0 && userTypeId!=2) {
	        				   showLink = CommonUtility.showLink(String.valueOf(linkDetail.getReportLinkId()));
	        			   if(userTypeId!=0 && userTypeId!=2 && linkDetail.getLinkId() != 0) {
	        				   showLink = CommonUtility.showLink(String.valueOf(linkDetail.getLinkId()));

	        			   }*/
	        			   if(showLink) {
	        				   message.append("<a href=\"");
	        				   String temp = linkDetail.getUrl();
	        				   String link = linkDetail.getUrl();
	        				   for (String t : linkDetail.getUrl().split("::")) {
	        					   //System.out.println("t=="+t);
	        					   temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
	        					   // System.out.println("temp="+temp);
	        					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
	        						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
	        						   // System.out.println("link="+link);
	        					   }
	        					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
	        					   {
	        						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
	        						   // System.out.println("link="+link);
	        					   }

	        				   }
	        				   if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
	        					   //System.out.println("original Link====>"+link);

	        					   String secString = "";
	        					   if (link.startsWith("/")) {
	        						   secString = link.substring(1, link.length());
	        					   }
	        					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
	        						   secString = encryptDecryptUtils.generateRedirect(secString, req);
	        						   link = req.getServletContext().getContextPath() + link;
	        					   }
	        					   //System.out.println("context path link="+link);
	        					   //System.out.println("link="+link+secString);
	        					   message.append(link).append(secString);
	        				   } else {
	        					   message.append(handleSpecialChar.handleSpecialChar(link));
	        				   }
	        				   if (linkDetail.getAttribute() != null) {
	                               String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
	                               if (t.contains("_encrypt")){
	                                   t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
	                                   Object valdata = listdata.get(i).get(FIELD_VALUE + t);
	                                   if (t.matches("[0-9*]") && valdata != null) {
	                                           valdata = encryptDecryptUtils.encrypt(valdata.toString());
	                                           message.append("\" ").append(linkDetail.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
	                                   }
	                               }else{
	                                       //message.append("' ").append(linkDetails.getAttribute()).append(" ");
	                            	 //commented above because href start with ".
	                            	   message.append("\" ").append(linkDetail.getAttribute()).append(" ");
	                               }
	                               message.append(">").append(listdata.get(i).get(FIELD_VALUE + 7));
	                           }else{
	                        	   message.append("\">").append(listdata.get(i).get(FIELD_VALUE + 7));
	                           }

	        				   message.append("</a> ");
	        				   break;
	        			   }
	        		   }
	        	   }
	           }
	        // End - Event Brief link
	   	    
	   	    message.append("</td>");
	   		message.append("</tr>");
	   		
	   		message.append("<tr>");	
	   	    message.append("<th>");	
			message.append("Department :");
			message.append("</th>");
	   	    message.append("<td>");
	   	    message.append(getFieldValue(listdata,i, 4, req.getParameter(IS_PDF)));	
	   	    message.append("</td>");	
	   	    message.append("</tr>");
	   		
	   	    message.append("<tr>");
	   		message.append("<th>");
	   		message.append(messageSource.getMessage("fields_eventtype", null, LocaleContextHolder.getLocale())).append(" :");
	   		message.append("</th>");
	   		message.append("<td>");
	   		message.append(getFieldValue(listdata,i, 3, req.getParameter(IS_PDF)));
	   		message.append("</td>");
	   		message.append("</tr>");
	   		
	   		
	   		
	   		// start - corrigendum:6(count hyper link)
	           short corgndmCount = (Short) listdata.get(i).get(FIELD_VALUE + 6);
	           message.append("<tr>");
		   	   message.append("<th>");
	           message.append(messageSource.getMessage("fields_corrigendum_count", null, LocaleContextHolder.getLocale())).append(" :");
	           message.append("</th>");
	           message.append("<td>");
	           if(corgndmCount!=0){ /* corrigendum is not zero so Show link*/
	               if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
	               {
	            	   for(TblReportLinkDetail linkDetail : lstLinkDetail){
	            		   
	            		   if(linkDetail.getSortOrder() == 2) {
	            			   boolean showLink = (linkDetail.getShowField()==21) || (userId != superAdmin && linkDetail.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetail.getShowField(), req.getParameter(IS_PDF))) == 1);

	            			  /* if(userTypeId!=0 && userTypeId!=2) {
	            				   showLink = CommonUtility.showLink(String.valueOf(linkDetail.getReportLinkId()));
	            			   }*/
	            			   if(showLink) {
	            				   message.append("<a href=\"");
	            				   String temp = linkDetail.getUrl();
	            				   String link = linkDetail.getUrl();
	            				   for (String t : linkDetail.getUrl().split("::")) {
	            					   //System.out.println("t=="+t);
	            					   temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
	            					   // System.out.println("temp="+temp);
	            					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
	            						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
	            						   // System.out.println("link="+link);
	            					   }
	            					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
	            					   {
	            						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
	            						   // System.out.println("link="+link);
	            					   }

	            				   }
	            				   if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
	            					   //System.out.println("original Link====>"+link);

	            					   String secString = "";
	            					   if (link.startsWith("/")) {
	            						   secString = link.substring(1, link.length());
	            					   }
	            					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
	            						   secString = encryptDecryptUtils.generateRedirect(secString, req);
	            						   link = req.getServletContext().getContextPath() + link;
	            					   }
	            					   //System.out.println("context path link="+link);
	            					   //System.out.println("link="+link+secString);
	            					   message.append(link).append(secString);
	            				   } else {
	            					   message.append(handleSpecialChar.handleSpecialChar(link));
	            				   }
	            				   if (linkDetail.getAttribute() != null) {
	                                   String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
	                                   if (t.contains("_encrypt")) {
	                                           t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
	                                           Object valdata = listdata.get(i).get(FIELD_VALUE + t);
	                                           if (t.matches("[0-9*]") && valdata != null) {
	                                                   valdata = encryptDecryptUtils.encrypt(valdata.toString());
	                                                   message.append("\" ").append(linkDetail.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
	                                           }
	                                   } else {
	                                           //message.append("' ").append(linkDetails.getAttribute()).append(" ");
	                                	 //commented above because href start with ".	
	                                	   message.append("\" ").append(linkDetail.getAttribute()).append(" ");
	                                   	}
	                                   message.append(">").append(listdata.get(i).get(FIELD_VALUE + 6));
	                               }else{
	                            	   message.append("\">").append(listdata.get(i).get(FIELD_VALUE + 6));
	                               }
	            				   message.append("</a>  <i id='txtblnk' class='red'> Updated </i> ");
	            				  // message.append(")");
	            				   break;
	            			   }
	            		   }
	            	   }
	               }
	           }
	           else{ /* corrigendum is zero, so don't show link just display 0*/
	        	   message.append(getFieldValue(listdata,i, 6, req.getParameter(IS_PDF)));
	           }
	           message.append("</td>");
	           message.append("</tr>");
	           // end - corrigendum:6(count hyper link)
	           message.append("<tr>");	
		   	    message.append("<td colspan='2' class='listing-subtitle'>");
		   	    message.append(" Detail schedule ");	
		   	    message.append("</td>");	
		   	    message.append("</tr>");
		   	    
			   	message.append("<tr>");	
		   		message.append("<th>");	
		   		message.append(messageSource.getMessage("fields_ten_refno", null, LocaleContextHolder.getLocale())).append(" :");
		   		message.append("</th>");
		   	    message.append("<td>");
		   	    String tempString=getFieldValue(listdata,i, 2, req.getParameter(IS_PDF));
		        message.append(StringUtils.hasLength(tempString) && tempString.length() > 30 ? tempString.substring(0,30) : tempString);
		   	    message.append("</td>");
		   	    message.append("</tr>");
		   	    	
		   	    message.append("<tr>");
		   		message.append("<th>");
		   		message.append(messageSource.getMessage("fields_eventid", null, LocaleContextHolder.getLocale())).append(" :");
		   		message.append("</th>");
		   		message.append("<td>");
		   		message.append(getFieldValue(listdata,i, 1, req.getParameter(IS_PDF)));
		   		message.append("</td>"); 
		   		message.append("</tr>");
		   	    
		   		message.append("<tr>");
		   		message.append("<th>");
		   		message.append(messageSource.getMessage("fields_duedateandtime", null, LocaleContextHolder.getLocale())).append(" :");
		   		message.append("</th>");
		   		message.append("<td>");
		   		message.append(getFieldValue(listdata,i, 5, req.getParameter(IS_PDF)));
		   		message.append("</td>");
		   		message.append("</tr>");
	        
		   		message.append("<tr>");
		   		if(userTypeId != 0){
	        	   if(tabValue.equals("All") || !req.getParameter("txtparam10").equals("") || isSearchPerformed){
	        		   message.append("<th>").append(messageSource.getMessage("fields_eventstatus", null, LocaleContextHolder.getLocale())).append(" :</th> ");
	        		   message.append("<td>").append(getFieldValue(listdata,i, 10, req.getParameter(IS_PDF))).append("</td>");
	        	   }
		   		}else{ 
	        	   message.append("<th>").append(messageSource.getMessage("fields_eventstatus", null, LocaleContextHolder.getLocale())).append(" :</th> ");
	        	   int isLiveEvent = (Integer) listdata.get(i).get(FIELD_VALUE + 8);
	        	   // Bug #33959 by Jitendra. Show status in link only if tender status is cancelled else in label. Also Bug 34061.
	        	   message.append("<td>");
	        	   if(isLiveEvent == 0){
	        		   if(lstLinkDetail !=null && !lstLinkDetail.isEmpty()){
	        			   for(TblReportLinkDetail linkDetail : lstLinkDetail){
	        				   if(linkDetail.getSortOrder() == 0) {
	        					   boolean showLink = (linkDetail.getShowField()==8);
	        					   if(showLink){
	        						   message.append("<a class='btn btn-raised btn-default' style='padding:6px 12px 4px;' href=\"");
	                				   String temp = linkDetail.getUrl();
	                				   String link = linkDetail.getUrl();
	                				   for (String t : linkDetail.getUrl().split("::")) {
	                					   //System.out.println("t=="+t);
	                					   temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
	                					   // System.out.println("temp="+temp);
	                					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
	                						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
	                						   // System.out.println("link="+link);
	                					   }
	                					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
	                					   {
	                						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
	                						   // System.out.println("link="+link);
	                					   }

	                				   }
	                				   if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
	                					   String secString = "";
	                					   if (link.startsWith("/")) {
	                						   secString = link.substring(1, link.length());
	                					   }
	                					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
	                						   secString = encryptDecryptUtils.generateRedirect(secString, req);
	                						   link = req.getServletContext().getContextPath() + link;
	                					   }
	                					   message.append(link).append(secString);
	                				   } else {
	                					   message.append(handleSpecialChar.handleSpecialChar(link));
	                				   }
	                				   if (linkDetail.getAttribute() != null) {
	                                       String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
	                                       if (t.contains("_encrypt")) {
	                                               t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
	                                               Object valdata = listdata.get(i).get(FIELD_VALUE + t);
	                                               if (t.matches("[0-9*]") && valdata != null) {
	                                            	   valdata = encryptDecryptUtils.encrypt(valdata.toString());
	                                                   message.append("\" ").append(linkDetail.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
	                                               }
	                                       } else {
	                                    	   message.append("\" ").append(linkDetail.getAttribute()).append(" ");
	                                       	}
	                                       message.append(">").append(listdata.get(i).get(FIELD_VALUE + 9));
	                                   }else{
	                                	   message.append("\">").append(listdata.get(i).get(FIELD_VALUE + 9));
	                                   }
	                				   message.append("</a> ");
	                				   break;
	        					   }
	        				   }
	                	   }
	                   }
	        	   }else{
	        		   message.append(getFieldValue(listdata,i, 9, req.getParameter(IS_PDF)));
	        	   }   
	        	   message.append("</td>");
	           }
	   		message.append("</tr>");
	   		
	   		message.append("<tr><th>&nbsp;</th><td>");
	   	// start - Action:10
            if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
            {
             for(TblReportLinkDetail linkDetails : lstLinkDetail){
                 if(linkDetails.getSortOrder() > 2) {
                         boolean showLink = (linkDetails.getShowField()==0) || (userId != superAdmin && linkDetails.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetails.getShowField(), req.getParameter(IS_PDF))) == 1);                                   
                        /* if(userTypeId!=0 && userTypeId!=2) {

                                 showLink = CommonUtility.showLink(String.valueOf(linkDetails.getReportLinkId()));
                         if(userTypeId!=0 && userTypeId!=2  && linkDetails.getLinkId() != 0) {
                                 showLink = CommonUtility.showLink(String.valueOf(linkDetails.getLinkId()));

                         }*/
                         if(userTypeId==2 && linkDetails.getSortOrder()==3) { /*Bidder side 'Download document' link*/
                         	showLink = false;
                         	String docStDate=getFieldValue(listdata,i, 24, req.getParameter(IS_PDF));
                         	String docEnDate=getFieldValue(listdata,i, 25, req.getParameter(IS_PDF));
                         	if(docStDate!=null && !"-".equalsIgnoreCase(docStDate) && docEnDate!=null && !"-".equalsIgnoreCase(docEnDate)) {
                         		showLink = true;
                         	}
                         }
                         if(showLink) {
                                 String temp = linkDetails.getUrl();
                                 String link = linkDetails.getUrl();

                                 for (String t : linkDetails.getUrl().split("::")) {
                                         //System.out.println("t=="+t);
                                         temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
                                         // System.out.println("temp="+temp);
                                         if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
                                                 link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
                                                 // System.out.println("link="+link);
                                         }
                                         else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
                                         {
                                                 link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
                                                 // System.out.println("link="+link);
                                         }

                                 }
                                 	
                                 message.append("<a class='btn btn-raised btn-default' style='padding:6px 12px 4px;' href=\"");
                                 if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
                                         //System.out.println("original Link====>"+link);

                                         String secString = "";
                                         if (link.startsWith("/")) {
                                                 secString = link.substring(1, link.length());
                                         }
                                         if (!link.equalsIgnoreCase("javascript:void(0)")) {
                                                 secString = encryptDecryptUtils.generateRedirect(secString, req);
                                                 link = req.getServletContext().getContextPath() + link;
                                         }
                                         // System.out.println("context path link="+link);
                                         //System.out.println("link="+link+secString);
                                         message.append(link).append(secString);
                                 } else {
                                         message.append(handleSpecialChar.handleSpecialChar(link));
                                 }
                                 if (linkDetails.getAttribute() != null) {
                                         String t = linkDetails.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
                                         if (t.contains("_encrypt")) {
                                                 t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
                                                 Object valdata = listdata.get(i).get(FIELD_VALUE + t);
                                                 if (t.matches("[0-9*]") && valdata != null) {
                                                         valdata = encryptDecryptUtils.encrypt(valdata.toString());
                                                         message.append("\" ").append(linkDetails.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
                                                 }
                                         } else {
                                                 //message.append("' ").append(linkDetails.getAttribute()).append(" ");
                                         	//commented above because href start with ".	
                                         	message.append("\" ").append(linkDetails.getAttribute()).append(" ");
                                         }
                                         message.append(">");
                                 }else{
                                 	message.append("\">");
                                 }

                                 if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
                                         message.append(linkDetails.getLinkCaption());
                                 } else {
                                         message.append(handleSpecialChar.handleSpecialChar(linkDetails.getLinkCaption()));
                                 }
                                 message.append("</a> ");
                         }
                 }
             }
         }
            
         // start - corrigendum:6(count hyper link)
           if(corgndmCount!=0){ /* corrigendum is not zero so Show link*/
               if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
               {
            	   for(TblReportLinkDetail linkDetail : lstLinkDetail){
            		   
            		   if(linkDetail.getSortOrder() == 2) {
            			   boolean showLink = (linkDetail.getShowField()==21) || (userId != superAdmin && linkDetail.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetail.getShowField(), req.getParameter(IS_PDF))) == 1);

            			  /* if(userTypeId!=0 && userTypeId!=2) {
            				   showLink = CommonUtility.showLink(String.valueOf(linkDetail.getReportLinkId()));
            			   }*/
            			   if(showLink) {
            				   message.append("<a class='btn btn-raised btn-default' style='padding:6px 12px 4px;' href=\"");
            				   String temp = linkDetail.getUrl();
            				   String link = linkDetail.getUrl();
            				   for (String t : linkDetail.getUrl().split("::")) {
            					   //System.out.println("t=="+t);
            					   temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
            					   // System.out.println("temp="+temp);
            					   if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
            						   link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
            						   // System.out.println("link="+link);
            					   }
            					   else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
            					   {
            						   link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
            						   // System.out.println("link="+link);
            					   }

            				   }
            				   if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
            					   //System.out.println("original Link====>"+link);

            					   String secString = "";
            					   if (link.startsWith("/")) {
            						   secString = link.substring(1, link.length());
            					   }
            					   if (!link.equalsIgnoreCase("javascript:void(0)")) {
            						   secString = encryptDecryptUtils.generateRedirect(secString, req);
            						   link = req.getServletContext().getContextPath() + link;
            					   }
            					   //System.out.println("context path link="+link);
            					   //System.out.println("link="+link+secString);
            					   message.append(link).append(secString);
            				   } else {
            					   message.append(handleSpecialChar.handleSpecialChar(link));
            				   }
            				   if (linkDetail.getAttribute() != null) {
                                   String t = linkDetail.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
                                   if (t.contains("_encrypt")) {
                                           t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
                                           Object valdata = listdata.get(i).get(FIELD_VALUE + t);
                                           if (t.matches("[0-9*]") && valdata != null) {
                                                   valdata = encryptDecryptUtils.encrypt(valdata.toString());
                                                   message.append("\" ").append(linkDetail.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
                                           }
                                   } else {
                                           //message.append("' ").append(linkDetails.getAttribute()).append(" ");
                                	 //commented above because href start with ".	
                                	   message.append("\" ").append(linkDetail.getAttribute()).append(" ");
                                   	}
                                   message.append(">").append("View ").append(messageSource.getMessage("fields_corrigendum_count", null, LocaleContextHolder.getLocale()));
                               }else{
                            	   message.append("\">").append("View ").append(messageSource.getMessage("fields_corrigendum_count", null, LocaleContextHolder.getLocale()));
                               }
            				   message.append("</a>");
            				  // message.append(")");
            				   break;
            			   }
            		   }
            	   }
               }
           }
//           else{ /* corrigendum is zero, so don't show link just display 0*/
//        	   message.append(getFieldValue(listdata,i, 6, req.getParameter(IS_PDF)));
//           }
           // end - corrigendum:6(count hyper link)
         //End - Action:10
            message.append("</td>");
            message.append("</tr>");
            
	   		message.append("</table>");		
	   		message.append("</div>");
}

	private void getNewAuctionListingStyle(int sectorId, StringBuilder message, HttpServletRequest req, List<LinkedHashMap<String,Object>> listdata, int userTypeId, int i, List<TblReportLinkDetail> lstLinkDetail, int userId, int listingStyle) {
    	message.append("<div class='new-listing'>");
	       message.append("<table>");	
		   String budgetVal = userTypeId == 2 ? getFieldValue(listdata,i, 20, req.getParameter(IS_PDF)) : getFieldValue(listdata,i, 13, req.getParameter(IS_PDF));
		   if((sectorId == drtSectorId || sectorId == bankSectorId)){
			   if(budgetVal != null && !"".equalsIgnoreCase(budgetVal) &&  !"-".equalsIgnoreCase(budgetVal)){
				   BigDecimal budget = new BigDecimal(budgetVal);
				   budget = budget.setScale(2, BigDecimal.ROUND_HALF_UP);
				   if(budget.compareTo(BigDecimal.ZERO) > 0){
					   message.append("<tr><td colspan='2' class='new-listing-title'>");
					   message.append(messageSource.getMessage("msg_reserve_price", null, LocaleContextHolder.getLocale()));
					   message.append(" " + budget+" ");
					   message.append("</td></tr>");
				   }
			   }
		   }
		   if((sectorId == drtSectorId || sectorId == bankSectorId) && listingStyle == 2){
			   message.append("<tr><td colspan='2' class='new-listing-subtitle'>");
			   message.append(" Property Details ");
			   message.append("</td></tr>");
			   
			   message.append("<tr><th>");
			   message.append("Property description :");
			   message.append("</th><td>");
			   message.append(getFieldValue(listdata,i, 3, req.getParameter(IS_PDF)));
			   message.append("</td></tr>");
			   
			   message.append("<tr><th><b>");
			   message.append(messageSource.getMessage("fields_auc_client", null, LocaleContextHolder.getLocale()));
			   message.append(" :</b></th><td>");
			   message.append(getFieldValue(listdata,i, 5, req.getParameter(IS_PDF)));
			   message.append("</td></tr>");
		   }else if(listingStyle == 2 && (sectorId != drtSectorId || sectorId != bankSectorId)){
			   message.append("<tr><td colspan='2' class='new-listing-subtitle'>");
			   message.append(" Event Information ");
			   message.append("</td></tr>");
			   
			   message.append("<tr><th>");
			   message.append("Event description :");
			   message.append("</th><td>");
			   message.append(getFieldValue(listdata,i, 3, req.getParameter(IS_PDF)));
			   message.append("</td></tr>");
			   
			   message.append("<tr><th>");
			   message.append(messageSource.getMessage("fields_auc_department", null, LocaleContextHolder.getLocale()));
			   message.append(" :</th><td>");
			   message.append(getFieldValue(listdata,i, 5, req.getParameter(IS_PDF)));
			   message.append("</td></tr>");
		   }
		   
		   if((sectorId == drtSectorId || sectorId == bankSectorId) && listingStyle == 2){
			   message.append("<tr><td class='new-listing-subtitle' colspan='2'>Auction Details</td></tr>");
		   }else if(listingStyle == 2 && (sectorId != drtSectorId || sectorId != bankSectorId)){
			   message.append("<tr><td class='new-listing-subtitle' colspan='2'>Detail schedule</td></tr>");
		   }
		   
		   message.append("<tr><th>");
		   message.append(messageSource.getMessage("fields_auc_auctionno", null, LocaleContextHolder.getLocale()));
		   message.append(" :</th><td>");
		   message.append(getFieldValue(listdata,i, 2, req.getParameter(IS_PDF)));
		   message.append("</td></tr>");

		   message.append("<tr><th>");
		   message.append(messageSource.getMessage("fields_aucid", null, LocaleContextHolder.getLocale()));
		   message.append(" :</th>");
		   message.append("<td>");
		   message.append(getFieldValue(listdata,i, 1, req.getParameter(IS_PDF)));	
		   message.append("</td></tr>");

		   message.append("<tr><th>");
		   message.append(messageSource.getMessage("fields_startdateandtime", null, LocaleContextHolder.getLocale()));
		   message.append(" :</th><td>");
		   message.append(getFieldValue(listdata,i, 4, req.getParameter(IS_PDF)));
		   message.append("</td></tr>");

		   message.append("<tr><th>");
		   message.append(messageSource.getMessage("fields_enddateandtime", null, LocaleContextHolder.getLocale()));
		   message.append(" :</th><td>");
		   message.append(getFieldValue(listdata,i, 6, req.getParameter(IS_PDF)));
		   message.append("</td></tr>");

		   message.append("<tr><th>&nbsp;</th><td>");
//		   message.append("<a href='#' class='btn btn-raised btn-default'>View Details</a>");
//		   message.append("<a href='#' class='btn btn-raised btn-primary'>Download Document</a>");
		   if(lstLinkDetail !=null && !lstLinkDetail.isEmpty())
	        {
	         for(TblReportLinkDetail linkDetails : lstLinkDetail){
	             if(linkDetails.getSelectFieldId()==0 && "R".equalsIgnoreCase(linkDetails.getFlag())) {
	                     boolean showLink = (linkDetails.getShowField()==0) || (userId == superAdmin) || (linkDetails.getShowField()!=0 && Integer.parseInt(getFieldValue(listdata,i, linkDetails.getShowField(), req.getParameter(IS_PDF))) == 1);
	                     /*if(userTypeId!=0 && userTypeId!=2) {
	                             showLink = CommonUtility.showLink(String.valueOf(linkDetails.getReportLinkId()));
	                     }*/
	                     if(showLink) {
	                             String temp = linkDetails.getUrl();
	                             String link = linkDetails.getUrl();
	
	                             for (String t : linkDetails.getUrl().split("::")) {
	                                     //System.out.println("t=="+t);
	                                     temp = t.substring(0, (t.indexOf('/') != -1 ? t.indexOf('/') : t.length()));
	                                     // System.out.println("temp="+temp);
	                                     if (temp.matches("[0-9*]") && listdata.get(i).get(FIELD_VALUE + temp) != null) {
	                                             link = link.replaceFirst("::[0-9*]", listdata.get(i).get(FIELD_VALUE + temp).toString());
	                                             // System.out.println("link="+link);
	                                     }
	                                     else if(temp.matches("param[0-9*]") && req.getParameter("txt"+temp) != null)
	                                     {
	                                             link=link.replaceFirst("::param[0-9*]",req.getParameter("txt"+temp));
	                                             // System.out.println("link="+link);
	                                     }
	
	                             }
	
	                             message.append("<a class='btn btn-raised btn-default' style='padding:6px 12px 4px;' href=\"");
	                             if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
	                                     //System.out.println("original Link====>"+link);
	
	                                     String secString = "";
	                                     if (link.startsWith("/")) {
	                                             secString = link.substring(1, link.length());
	                                     }
	                                     if (!link.equalsIgnoreCase("javascript:void(0)")) {
	                                             secString = encryptDecryptUtils.generateRedirect(secString, req);
	                                             link = req.getServletContext().getContextPath() + link;
	                                     }
	                                     // System.out.println("context path link="+link);
	                                     //System.out.println("link="+link+secString);
	                                     message.append(link).append(secString);
	                             } else {
	                                     message.append(handleSpecialChar.handleSpecialChar(link));
	                             }
	                             if (linkDetails.getAttribute() != null) {
	                                     String t = linkDetails.getAttribute();//"onclick=\"submitForm('::3_encrypt')\"";
	                                     if (t.contains("_encrypt")) {
	                                             t = t.substring(t.indexOf("('::") + 4, t.indexOf("_encrypt')"));
	                                             Object valdata = listdata.get(i).get(FIELD_VALUE + t);
	                                             if (t.matches("[0-9*]") && valdata != null) {
	                                                     valdata = encryptDecryptUtils.encrypt(valdata.toString());
	                                                     message.append("\" ").append(linkDetails.getAttribute().replace("::" + t, valdata.toString()).replace("_encrypt", "")).append(" ");
	                                             }
	                                     } else {
	                                             //message.append("' ").append(linkDetails.getAttribute()).append(" ");
	                                     	//commented above because href start with ".
//	                                     	message.append("\" ").append(linkDetails.getAttribute()).append(" ");
	                                    	 message.append("\" ").append(linkDetails.getAttribute().replace("::" + 1, listdata.get(i).get(FIELD_VALUE+ 1).toString()));
	                                     }
	                                     message.append(">");
	                             }else{
	                             	message.append("\">");
	                             }
	                             
	                             if (req.getParameter(IS_PDF) == null || !req.getParameter(IS_PDF).equalsIgnoreCase(YES)) {
	                                     message.append(linkDetails.getLinkCaption());
	                             } else {
	                                     message.append(handleSpecialChar.handleSpecialChar(linkDetails.getLinkCaption()));
	                             }
	
	                             message.append("</a> ");
	                     	}
	             	}
	         	}
	        }
		   
		   message.append("</td></tr>");   
		   message.append("</table></div>");
    }

	private String getFieldValue(List<LinkedHashMap<String, Object>> listdata, int i, int fieldIndex, String isPdf) {
    	String result = "-";
    	if (listdata.get(i) != null && listdata.get(i).get(FIELD_VALUE + fieldIndex) != null) {
            if (isPdf == null || !isPdf.equalsIgnoreCase(YES)) {
                result = HtmlUtils.htmlUnescape((listdata.get(i).get(FIELD_VALUE + fieldIndex)).toString());
            } else {
                result = handleSpecialChar.handleSpecialChar((listdata.get(i).get(FIELD_VALUE + fieldIndex)).toString());
            }
        }
    	return result;
    }
    
     @RequestMapping(value = "/common/reportgenerator/ReportConfigure")
    public ModelAndView reportConfigure(HttpServletRequest req, HttpServletResponse res) {
        ModelAndView mov=new ModelAndView("appconfig/ReportConfigure");
    	int reportId=0;
    	try
    	{
            if(req.getParameter(REPORTID)!= null)
            {
                reportId = Integer.parseInt(req.getParameter(REPORTID));
                mov.addObject("tblReportMst",reportGeneratorService.getReportMasterDetail(reportId));
                mov.addObject("lstTblReportDetail",reportGeneratorService.getReportDetail(reportId));
                mov.addObject("lstTblReportLinkDetail",reportGeneratorService.getReportLinkDetail(reportId));
                mov.addObject("lstTblReportSearchSortDetails",reportGeneratorService.getReportSearchSortColumnDetail(reportId));
            }
    	}
    	catch(Exception ex)
    	{
            exceptionHandlerService.writeLog(ex);
    	}
        return mov;
    }

     @RequestMapping(value = "/common/reportgenerator/SubmitReportConfigure")
    public String submitReportConfigure(HttpServletRequest req, HttpServletResponse res)
     {        
         int reportId=0;
         boolean sucesss=false;
         try
         {
            TblReportMst tblReportMst=new TblReportMst();
            TblReportDetail tblReportDetail=new TblReportDetail();
            List<TblReportLinkDetail> lstTblReportLinkDetails=null;
            List<TblReportSearchColumnDetail> lstTblReportSearchColumnDetails=null;


            if(req.getParameter("action")!=null && req.getParameter("action").equalsIgnoreCase("edit"))
            {
                if(req.getParameter(REPORTID)!= null)
                {
                	reportId=Integer.parseInt(req.getParameter(REPORTID));
                }
                tblReportMst.setReportId(reportId);
                tblReportDetail.setReportDetailId(Integer.parseInt(req.getParameter("reportDetailId")));
            }

            /***** Set value in Report Master *****/
            if(req.getParameter("txtReportHeading")!=null)
            {
            	tblReportMst.setReportHeading(req.getParameter("txtReportHeading").trim());
            }
            if(req.getParameter("rptPaginationReq")!=null)
            {
            	tblReportMst.setPaggingExist(req.getParameter("rptPaginationReq"));
            }
            if(req.getParameter("txtRecordPerPage")!=null)
            {
            	tblReportMst.setRecordPerPage(Integer.parseInt(req.getParameter("txtRecordPerPage").trim()));
            }

            /***** Set value in Report Detail *****/
            if(req.getParameter("txtSelectQuery")!=null)
            {
            	tblReportDetail.setSelectQuery(req.getParameter("txtSelectQuery").trim());
            }
            if(req.getParameter("txtOrderBy")!=null)
            {
            	tblReportDetail.setOrderBy("order by "+req.getParameter("txtOrderBy").trim()+" "+req.getParameter("optOrderBy"));
            }
            if(req.getParameter("txtWhereClause")!=null)
            {
            	tblReportDetail.setWhereCondition(req.getParameter("txtWhereClause").trim());
            }
            StringBuilder strColumnDetail=new StringBuilder("");
            if(req.getParameter("txtRptColHead")!=null && req.getParameterValues("txtRptColHead").length>0)
            {
                for(int i=0;i < req.getParameterValues("txtRptColHead").length;i++)
                {
                    strColumnDetail.append(req.getParameterValues("txtRptColHead")[i].trim());
                    strColumnDetail.append(":");
                    strColumnDetail.append(req.getParameterValues("txtRptFieldIndex")[i].trim());
                    strColumnDetail.append(":");
                    strColumnDetail.append(req.getParameterValues("cmbAlign")[i].trim());
                    strColumnDetail.append(" ~ ");
                }
            }

            //System.out.println("Column Details================="+strColumnDetail.toString());
            if(strColumnDetail!= null && strColumnDetail.toString().trim().endsWith("~"))
            {
                tblReportDetail.setColumnDetails(strColumnDetail.substring(0, strColumnDetail.length() - 2));
            }
            else
            {
                tblReportDetail.setColumnDetails(strColumnDetail.toString());
            }

            /***** Set value for Report Link Detail *****/
            if(req.getParameter("txtUrl")!=null && req.getParameterValues("txtUrl").length>0)
            {
                lstTblReportLinkDetails=new ArrayList<TblReportLinkDetail>();
                for(int i=0;i < req.getParameterValues("txtUrl").length;i++)
                {
                    if(req.getParameterValues("txtUrl")[i] != null && !req.getParameterValues("txtUrl")[i].trim().equalsIgnoreCase(""))
                    {
                        TblReportLinkDetail tblReportLinkDetail=new TblReportLinkDetail();
                        tblReportLinkDetail.setUrl(req.getParameterValues("txtUrl")[i].trim());
                        if(req.getParameterValues("txtLinkCap")[i]!=null && !req.getParameterValues("txtLinkCap")[i].trim().equalsIgnoreCase(""))
                        {
                        	tblReportLinkDetail.setLinkCaption(req.getParameterValues("txtLinkCap")[i].trim());
                        }
                        else
                        {
                        	tblReportLinkDetail.setLinkCaption(null);
                        }
                        if(req.getParameterValues("txtLinkSelIndex")[i]!=null && !req.getParameterValues("txtLinkSelIndex")[i].trim().equalsIgnoreCase(""))
                        {
                        	tblReportLinkDetail.setSelectFieldId(Integer.parseInt(req.getParameterValues("txtLinkSelIndex")[i]));
                        }
                        else
                        {
                        	tblReportLinkDetail.setSelectFieldId(0);
                        }
                        tblReportLinkDetail.setDispalyColumnId(Integer.parseInt(req.getParameterValues("txtLinkDispalyIndex")[i]));
                        lstTblReportLinkDetails.add(tblReportLinkDetail);
                    }
                }
            }

            /***** Set value for Report Search and Sort Detail *****/
            if(req.getParameter("txtSearchSortSelectFiled")!=null && req.getParameterValues("txtSearchSortSelectFiled").length>0)
            {
                lstTblReportSearchColumnDetails=new ArrayList<TblReportSearchColumnDetail>();
                for(int i=0;(i < req.getParameterValues("txtSearchSortSelectFiled").length && !req.getParameterValues("txtSearchSortSelectFiled")[i].equalsIgnoreCase(""));i++)
                {
                    TblReportSearchColumnDetail tblReportSearchColumnDetail=new TblReportSearchColumnDetail();
                    tblReportSearchColumnDetail.setSelectFieldName(req.getParameterValues("txtSearchSortSelectFiled")[i]);
                    if(req.getParameterValues("txtSearchCol")[i]!= null && !req.getParameterValues("txtSearchCol")[i].trim().equalsIgnoreCase(""))
                    {
                        tblReportSearchColumnDetail.setColumnName(req.getParameterValues("txtSearchCol")[i].trim());
                        tblReportSearchColumnDetail.setDatatype(req.getParameterValues("cmbSearchDataType")[i]);
                        tblReportSearchColumnDetail.setSearchType(req.getParameterValues("cmbSearchType")[i]);
                        tblReportSearchColumnDetail.setSearchRequired(YES);
                    }
                    else
                    {
                        tblReportSearchColumnDetail.setColumnName(null);
                        tblReportSearchColumnDetail.setDatatype(null);
                        tblReportSearchColumnDetail.setSearchRequired(null);
                        tblReportSearchColumnDetail.setSearchType(req.getParameterValues("cmbSearchType")[i]);
                    }
                    if(req.getParameterValues("txtSortColIndex")[i]!= null && !req.getParameterValues("txtSortColIndex")[i].trim().equalsIgnoreCase(""))
                    {
                    	tblReportSearchColumnDetail.setSortColHeadingId(Integer.parseInt(req.getParameterValues("txtSortColIndex")[i]));
                    }
                    else
                    {
                    	tblReportSearchColumnDetail.setSortColHeadingId(0);
                    }
                       
                    lstTblReportSearchColumnDetails.add(tblReportSearchColumnDetail);
                }
            }
            

            sucesss=reportGeneratorService.addEditReportConfigureDetails(tblReportMst,tblReportDetail,lstTblReportLinkDetails,lstTblReportSearchColumnDetails);
            reportId=tblReportMst.getReportId();
            
            
            
	 }
	 catch(Exception x)
	 {
		exceptionHandlerService.writeLog(x);
	 }
	
        if(sucesss)
	{
             return "redirect:/common/reportgenerator/ReportConfigure?message=success&reportId="+reportId;
	}
	else
	{
             return "redirect:/common/reportgenerator/ReportConfigure?message=fail";
	}
         
       
        
    }

    @RequestMapping("/common/reportgenerator/excelGenerator")
    public String excelGenerator(HttpServletRequest req, ModelMap map,HttpSession session, RedirectAttributes redirectAttributes)
    {
    	String retVal="common/ExcelGenerator";
        try
        {
            int reportId=0;
            if(req.getParameter(REPORTID)!= null)
            {
            	reportId=Integer.parseInt(req.getParameter(REPORTID));
            }
           
            if(req.getParameter(IS_PDF)!=null)
            {
                map.addAttribute(IS_PDF,YES);
                StringBuilder tableDetail=getReportDataFromSP(req,map);
                map.addAttribute("tableDetail",tableDetail);
                redirectAttributes.addFlashAttribute("printData", tableDetail);
            }
           
            reportGeneratorService.getReportConfigDetails(reportId,map);
            TblReportMst tblReportMst=reportGeneratorService.getReportMasterDetail(reportId);
            String userId="";
            if (session.getAttribute("sessionObject") != null) {
                userId=((SessionBean) session.getAttribute("sessionObject")).getUserId()+"";
            }
            map.addAttribute("fname",tblReportMst.getReportHeading().replaceAll(" ", "")+userId);
            if(req.getParameter(IS_PRINT)!=null && req.getParameter(IS_PRINT).equalsIgnoreCase(YES)){
            	map.put("isPrint", true);
//            	map.put("redirectUrl", getRedirectUrl(reportId, req));
            }
            map.put("redirectUrl", getRedirectUrl(reportId, req));
            map.addAttribute("reportHeader", req.getParameter("reportHeading"));
            map.addAttribute("fname", req.getParameter("reportHeading").replace("/", " ").replaceAll(" ", ""));
            int clientId=abcUtility.getSessionClientId(req);
            String moduleId=req.getParameter("modId")!=null?req.getParameter("modId"):"0";
            int eventId=req.getParameter("eventId")!=null?Integer.parseInt(req.getParameter("eventId")):0;
            map.addAttribute("moduleId", moduleId);
            if(moduleId.equals("5")){
            	commonService.commonauctionSummary(eventId, map, clientId);
            }else if(moduleId.equals("3")){
            	commonService.commontenderSummary(eventId, map, clientId);
            }
            
        }
        catch (Exception e)
        {
           // new AbcException(e,exceptionHandlerService);
            return exceptionHandlerService.writeLog(e);
        }
        return retVal;
    }
    
    private String getRedirectUrl(int reportId, HttpServletRequest request){
    	String redirectUrl = "";
    	String eventId=request.getParameter("eventId")!=null && !"".equals(request.getParameter("eventId")) ? request.getParameter("eventId"):"0";
    	switch (reportId) {
    	case 22:
			redirectUrl="/eauction/auctioneer/getauctionhistory/"+eventId+encryptDecryptUtils.generateRedirect("eauction/auctioneer/getauctionhistory/"+eventId, request);
			break;
    	case 24:
			redirectUrl="/common/managedcreport"+encryptDecryptUtils.generateRedirect("common/managedcreport", request);
			break;
		case 28:
			redirectUrl="/common/manageusermanagementhistory"+encryptDecryptUtils.generateRedirect("common/manageusermanagementhistory", request);
			break;
		case 29:
			redirectUrl="/common/manageloginreport"+encryptDecryptUtils.generateRedirect("common/manageloginreport", request);
			break;
		case 30:
			redirectUrl="/common/managedcrenewalreport/2"+encryptDecryptUtils.generateRedirect("common/managedcrenewalreport/2", request);
			break;
		case 31:
			redirectUrl="/common/managedcrenewalreport/1"+encryptDecryptUtils.generateRedirect("common/managedcrenewalreport/1", request);
			break;
		case 32:
			redirectUrl="/common/manageaudittrailreport"+encryptDecryptUtils.generateRedirect("common/manageaudittrailreport", request);
			break;
		case 49:
			redirectUrl="/eauction/auctioneer/reviveauctionhistoryreport"+encryptDecryptUtils.generateRedirect("eauction/auctioneer/reviveauctionhistoryreport", request);
			break;
		case 67:
			redirectUrl="/etender/buyer/getTenderHistory/"+eventId+encryptDecryptUtils.generateRedirect("etender/buyer/getTenderHistory/"+eventId, request);
			break;
		}
    	return redirectUrl;
    }
    
    /**
     * To get linkId for sector listing 
     * @param request
     * @return
     */
    private int getLinkIdForSectorListing(HttpServletRequest request) {
    	 int linkId=0;
  	     boolean isLinkIdFound = false;
         String aucReportIdsArr[]=sectorAucReportIds.split(",");
         for(int i=0;i<aucReportIdsArr.length;i++)
         {
             if(aucReportIdsArr[i].equalsIgnoreCase(request.getParameter(REPORTID)))
             {
                 linkId=aucAttrSelLinkId;
                 isLinkIdFound = true;
                 break;
             }
         }
         if(!isLinkIdFound) { 
        	/* String tenReportIdsArr[]=sectorTenReportIds.split(",");
             for(int i=0;i<tenReportIdsArr.length;i++)
             {
                 if(tenReportIdsArr[i].equalsIgnoreCase(request.getParameter(REPORTID)))
                 {
                     linkId=tenAttrSelLinkId;
                     isLinkIdFound = true;
                     break;
                 }
             } */
         }
         return linkId;
    }
}
