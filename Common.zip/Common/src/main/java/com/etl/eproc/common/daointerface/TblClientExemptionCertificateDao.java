package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientExemptionCertificate;
import java.util.List;

public interface TblClientExemptionCertificateDao  {

    public void addTblClientExemptionCertificate(TblClientExemptionCertificate tblClientExemptionCertificate);

    public void deleteTblClientExemptionCertificate(TblClientExemptionCertificate tblClientExemptionCertificate);

    public void updateTblClientExemptionCertificate(TblClientExemptionCertificate tblClientExemptionCertificate);

    public List<TblClientExemptionCertificate> getAllTblClientExemptionCertificate();

    public List<TblClientExemptionCertificate> findTblClientExemptionCertificate(Object... values) throws Exception;

    public List<TblClientExemptionCertificate> findByCountTblClientExemptionCertificate(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientExemptionCertificateCount();

    public void saveUpdateAllTblClientExemptionCertificate(List<TblClientExemptionCertificate> tblClientExemptionCertificates);
}