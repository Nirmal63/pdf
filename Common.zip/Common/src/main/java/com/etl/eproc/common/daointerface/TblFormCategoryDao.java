package com.etl.eproc.common.daointerface;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblFormCategory;
import java.util.List;

public interface TblFormCategoryDao  {

    public void addTblFormCategory(TblFormCategory tblFormCategory);

    public void deleteTblFormCategory(TblFormCategory tblFormCategory);

    public void updateTblFormCategory(TblFormCategory tblFormCategory);

    public List<TblFormCategory> getAllTblFormCategory();

    public List<TblFormCategory> findTblFormCategory(Object... values) throws Exception;

    public List<TblFormCategory> findByCountTblFormCategory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFormCategoryCount();

    public void saveUpdateAllTblFormCategory(List<TblFormCategory> tblFormCategorys);
}