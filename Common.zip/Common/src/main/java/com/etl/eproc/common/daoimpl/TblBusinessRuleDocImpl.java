/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daoimpl;

import com.etl.eproc.common.model.TblBusinessRuleDoc;
import com.etl.eproc.common.daointerface.TblBusinessRuleDocDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author Nirav M. Raval
 */
@Repository @Transactional    /*StackUpdate*/
public class TblBusinessRuleDocImpl extends AbcAbstractClass<TblBusinessRuleDoc> implements TblBusinessRuleDocDao {

    @Override
    public void addTblBusinessRuleDoc(TblBusinessRuleDoc tblBusinessRuleDoc) {
        super.addEntity(tblBusinessRuleDoc);
    }

    @Override
    public void deleteTblBusinessRuleDoc(TblBusinessRuleDoc tblBusinessRuleDoc) {
        super.deleteEntity(tblBusinessRuleDoc);
    }

    @Override
    public void updateTblBusinessRuleDoc(TblBusinessRuleDoc tblBusinessRuleDoc) {
        super.updateEntity(tblBusinessRuleDoc);
    }

    @Override
    public List<TblBusinessRuleDoc> getAllTblBusinessRuleDoc() {
        return super.getAllEntity();
    }

    @Override
    public List<TblBusinessRuleDoc> findTblBusinessRuleDoc(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblBusinessRuleDocCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblBusinessRuleDoc> findByCountTblBusinessRuleDoc(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblBusinessRuleDoc(List<TblBusinessRuleDoc> tblBusinessRuleDocs) {
        super.updateAll(tblBusinessRuleDocs);
    }
}
