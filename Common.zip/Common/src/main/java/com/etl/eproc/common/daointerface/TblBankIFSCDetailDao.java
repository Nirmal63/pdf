package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBankIFSCDetail;

public interface TblBankIFSCDetailDao  {

    public void addTblBankIFSCDetail(TblBankIFSCDetail tblBankIFSCDetail);

    public void deleteTblBankIFSCDetail(TblBankIFSCDetail tblBankIFSCDetail);

    public void updateTblBankIFSCDetail(TblBankIFSCDetail tblBankIFSCDetail);

    public List<TblBankIFSCDetail> getAllTblBankIFSCDetail();

    public List<TblBankIFSCDetail> findTblBankIFSCDetail(Object... values) throws Exception;

    public List<TblBankIFSCDetail> findByCountTblBankIFSCDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBankIFSCDetailCount();

    public void saveUpdateAllTblBankIFSCDetail(List<TblBankIFSCDetail> tblBankIFSCDetails);
}