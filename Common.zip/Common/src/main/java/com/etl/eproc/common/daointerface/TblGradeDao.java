package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblGrade;
import java.util.List;

public interface TblGradeDao  {

    public void addTblGrade(TblGrade tblGrade);

    public void deleteTblGrade(TblGrade tblGrade);

    public void updateTblGrade(TblGrade tblGrade);

    public List<TblGrade> getAllTblGrade();

    public List<TblGrade> findTblGrade(Object... values) throws Exception;

    public List<TblGrade> findByCountTblGrade(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblGradeCount();

    public void saveUpdateAllTblGrade(List<TblGrade> tblGrades);
}