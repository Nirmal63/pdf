package com.etl.eproc.common.daoimpl;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblRuleDao;
import com.etl.eproc.common.model.TblRule;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblRuleImpl extends AbcAbstractClass<TblRule> implements TblRuleDao {


    @Override
    public void addTblRule(TblRule tblRule){
        super.addEntity(tblRule);
    }

    @Override
    public void deleteTblRule(TblRule tblRule) {
        super.deleteEntity(tblRule);
    }

    @Override
    public void updateTblRule(TblRule tblRule) {
        super.updateEntity(tblRule);
    }

    @Override
    public List<TblRule> getAllTblRule() {
        return super.getAllEntity();
    }

    @Override
    public List<TblRule> findTblRule(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblRuleCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblRule> findByCountTblRule(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblRule(List<TblRule> tblRules){
        super.updateAll(tblRules);
    }
}
