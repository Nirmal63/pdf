package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblAlertHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblAlertHistory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblAlertHistoryImpl extends AbcAbstractClass<TblAlertHistory> implements TblAlertHistoryDao {

    @Override
    public void addTblAlertHistory(TblAlertHistory tblAlertHistory){
        super.addEntity(tblAlertHistory);
    }

    @Override
    public void deleteTblAlertHistory(TblAlertHistory tblAlertHistory) {
        super.deleteEntity(tblAlertHistory);
    }

    @Override
    public void updateTblAlertHistory(TblAlertHistory tblAlertHistory) {
        super.updateEntity(tblAlertHistory);
    }

    @Override
    public List<TblAlertHistory> getAllTblAlertHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAlertHistory> findTblAlertHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAlertHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAlertHistory> findByCountTblAlertHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAlertHistory(List<TblAlertHistory> tblAlertHistorys){
        super.updateAll(tblAlertHistorys);
    }
}
