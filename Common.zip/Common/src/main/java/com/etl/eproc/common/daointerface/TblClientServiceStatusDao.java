package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientServiceStatus;
import java.util.List;

public interface TblClientServiceStatusDao  {

    public void addTblClientServiceStatus(TblClientServiceStatus tblClientServiceStatus);

    public void deleteTblClientServiceStatus(TblClientServiceStatus tblClientServiceStatus);

    public void updateTblClientServiceStatus(TblClientServiceStatus tblClientServiceStatus);

    public List<TblClientServiceStatus> getAllTblClientServiceStatus();

    public List<TblClientServiceStatus> findTblClientServiceStatus(Object... values) throws Exception;

    public List<TblClientServiceStatus> findByCountTblClientServiceStatus(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientServiceStatusCount();

    public void saveUpdateAllTblClientServiceStatus(List<TblClientServiceStatus> tblClientServiceStatuss);
}