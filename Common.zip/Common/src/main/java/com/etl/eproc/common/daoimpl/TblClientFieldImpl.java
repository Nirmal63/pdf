package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblClientFieldDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblClientField;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientFieldImpl extends AbcAbstractClass<TblClientField> implements TblClientFieldDao {

    @Override
    public void addTblClientField(TblClientField tblClientField){
        super.addEntity(tblClientField);
    }

    @Override
    public void deleteTblClientField(TblClientField tblClientField) {
        super.deleteEntity(tblClientField);
    }

    @Override
    public void updateTblClientField(TblClientField tblClientField) {
        super.updateEntity(tblClientField);
    }

    @Override
    public List<TblClientField> getAllTblClientField() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientField> findTblClientField(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientFieldCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientField> findByCountTblClientField(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientField(List<TblClientField> tblClientFields){
        super.updateAll(tblClientFields);
    }

	@Override
	public void saveOrUpdateTblClientField(TblClientField tblClientField) {
		super.saveOrUpdateEntity(tblClientField);
	}
}
