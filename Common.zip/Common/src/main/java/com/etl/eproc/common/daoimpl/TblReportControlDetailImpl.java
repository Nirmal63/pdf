package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblReportControlDetailDao;
import com.etl.eproc.common.model.TblReportControlDetail;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author dipal
 */
@Repository @Transactional    /*StackUpdate*/
public class TblReportControlDetailImpl extends AbcAbstractClass<TblReportControlDetail> implements TblReportControlDetailDao {

    @Override
    public void addTblReportControlDetail(TblReportControlDetail tblReportControlDetail){
        super.addEntity(tblReportControlDetail);
    }

    @Override
    public void deleteTblReportControlDetail(TblReportControlDetail tblReportControlDetail) {
        super.deleteEntity(tblReportControlDetail);
    }

    @Override
    public void updateTblReportControlDetail(TblReportControlDetail tblReportControlDetail) {
        super.updateEntity(tblReportControlDetail);
    }

    @Override
    public List<TblReportControlDetail> getAllTblReportControlDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblReportControlDetail> findTblReportControlDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblReportControlDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblReportControlDetail> findByCountTblReportControlDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblReportControlDetail(List<TblReportControlDetail> tblReportControlDetails){
        super.updateAll(tblReportControlDetails);
    }
}

