package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblFormMaster;
import java.util.List;

public interface TblFormMasterDao  {

    public void addTblFormMaster(TblFormMaster tblFormMaster);

    public void deleteTblFormMaster(TblFormMaster tblFormMaster);

    public void updateTblFormMaster(TblFormMaster tblFormMaster);

    public List<TblFormMaster> getAllTblFormMaster();

    public List<TblFormMaster> findTblFormMaster(Object... values) throws Exception;

    public List<TblFormMaster> findByCountTblFormMaster(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFormMasterCount();

    public void saveUpdateAllTblFormMaster(List<TblFormMaster> tblFormMasters);

	public void saveOrUpdateTblFormMaster(TblFormMaster tblFormMaster);
}