package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblQueAnsOfficerDao;
import com.etl.eproc.common.model.TblQueAnsOfficer;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblQueAnsOfficerImpl extends AbcAbstractClass<TblQueAnsOfficer> implements TblQueAnsOfficerDao {

    @Override
    public void addTblQueAnsOfficer(TblQueAnsOfficer tblQueAnsOfficer){
        super.addEntity(tblQueAnsOfficer);
    }

    @Override
    public void deleteTblQueAnsOfficer(TblQueAnsOfficer tblQueAnsOfficer) {
        super.deleteEntity(tblQueAnsOfficer);
    }

    @Override
    public void updateTblQueAnsOfficer(TblQueAnsOfficer tblQueAnsOfficer) {
        super.updateEntity(tblQueAnsOfficer);
    }

    @Override
    public List<TblQueAnsOfficer> getAllTblQueAnsOfficer() {
        return super.getAllEntity();
    }

    @Override
    public List<TblQueAnsOfficer> findTblQueAnsOfficer(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblQueAnsOfficerCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblQueAnsOfficer> findByCountTblQueAnsOfficer(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblQueAnsOfficer(List<TblQueAnsOfficer> tblQueAnsOfficers){
        super.updateAll(tblQueAnsOfficers);
    }
}
