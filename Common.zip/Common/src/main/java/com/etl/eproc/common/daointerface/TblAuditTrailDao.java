package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblAuditTrail;

public interface TblAuditTrailDao  {

    public void addTblAuditTrail(TblAuditTrail tblAuditTrail);

    public void deleteTblAuditTrail(TblAuditTrail tblAuditTrail);

    public void updateTblAuditTrail(TblAuditTrail tblAuditTrail);

    public List<TblAuditTrail> getAllTblAuditTrail();

    public List<TblAuditTrail> findTblAuditTrail(Object... values) throws Exception;

    public List<TblAuditTrail> findByCountTblAuditTrail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAuditTrailCount();

    public void saveUpdateAllTblAuditTrail(List<TblAuditTrail> tblAuditTrails);
}