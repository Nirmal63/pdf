package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblModuleDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblModuleImpl extends AbcAbstractClass<TblModule> implements TblModuleDao {

    @Override
    public void addTblModule(TblModule tblModule){
        super.addEntity(tblModule);
    }

    @Override
    public void deleteTblModule(TblModule tblModule) {
        super.deleteEntity(tblModule);
    }

    @Override
    public void updateTblModule(TblModule tblModule) {
        super.updateEntity(tblModule);
    }

    @Override
    public List<TblModule> getAllTblModule() {
        return super.getAllEntity();
    }

    @Override
    public List<TblModule> findTblModule(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblModuleCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblModule> findByCountTblModule(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblModule(List<TblModule> tblModules){
        super.updateAll(tblModules);
    }
}
