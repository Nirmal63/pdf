package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblLastTransactionDetail;
import com.etl.eproc.common.daointerface.TblLastTransactionDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author sharmila
 */
@Repository @Transactional    /*StackUpdate*/
public class TblLastTransactionDetailImpl extends AbcAbstractClass<TblLastTransactionDetail> implements TblLastTransactionDetailDao {

    @Override
    public void addTblLastTransactionDetail(TblLastTransactionDetail tblLastTransactionDetail){
        super.addEntity(tblLastTransactionDetail);
    }

    @Override
    public void deleteTblLastTransactionDetail(TblLastTransactionDetail tblLastTransactionDetail) {
        super.deleteEntity(tblLastTransactionDetail);
    }

    @Override
    public void updateTblLastTransactionDetail(TblLastTransactionDetail tblLastTransactionDetail) {
        super.updateEntity(tblLastTransactionDetail);
    }

    @Override
    public List<TblLastTransactionDetail> getAllTblLastTransactionDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblLastTransactionDetail> findTblLastTransactionDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblLastTransactionDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblLastTransactionDetail> findByCountTblLastTransactionDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblLastTransactionDetail(List<TblLastTransactionDetail> tblLastTransactionDetails){
        super.updateAll(tblLastTransactionDetails);
    }

	@Override
	public void saveOrUpdateTblLastTransactionDetail(TblLastTransactionDetail tblLastTransactionDetail) {
		super.saveOrUpdateEntity(tblLastTransactionDetail);
	}
}
