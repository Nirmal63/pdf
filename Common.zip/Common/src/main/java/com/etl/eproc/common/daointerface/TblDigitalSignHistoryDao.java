package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDigitalSignHistory;
import java.util.List;

public interface TblDigitalSignHistoryDao  {

    public void addTblDigitalSignHistory(TblDigitalSignHistory tblDigitalSignHistory);

    public void deleteTblDigitalSignHistory(TblDigitalSignHistory tblDigitalSignHistory);

    public void updateTblDigitalSignHistory(TblDigitalSignHistory tblDigitalSignHistory);

    public List<TblDigitalSignHistory> getAllTblDigitalSignHistory();

    public List<TblDigitalSignHistory> findTblDigitalSignHistory(Object... values) throws Exception;

    public List<TblDigitalSignHistory> findByCountTblDigitalSignHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDigitalSignHistoryCount();

    public void saveUpdateAllTblDigitalSignHistory(List<TblDigitalSignHistory> tblDigitalSignHistorys);
}