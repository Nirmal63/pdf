package com.etl.eproc.common.daoimpl;


import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblReportMstDao;
import com.etl.eproc.common.model.TblReportMst;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository @Transactional    /*StackUpdate*/
public class TblReportMstImpl extends AbcAbstractClass<TblReportMst> implements TblReportMstDao {

	@Override 
	public void addTblReportMst(TblReportMst master){
		super.addEntity(master);
	}
	@Override 
	public void deleteTblReportMst(TblReportMst master) {
		super.deleteEntity(master);
	}
	@Override 
	public void updateTblReportMst(TblReportMst master) {
		super.updateEntity(master);
	}
	@Override 
	public List<TblReportMst> getAllTblReportMst() {
		return super.getAllEntity();
	}
	@Override 
	public List<TblReportMst> findTblReportMst(Object... values) throws Exception {
		return super.findEntity(values);
	}
	@Override 
	public long getTblReportMstCount() {
		return super.getEntityCount();
	}
	@Override 
	public List<TblReportMst> findByCountTblReportMst(int firstResult, int maxResult, Object... values) throws Exception {
		return super.findByCountEntity(firstResult, maxResult, values);
	}
	@Override 
	public void updateOrSaveTblReportMst(List<TblReportMst> tblObj) {
		super.updateAll(tblObj);
	}
}