package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblMessageInboxDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblMessageInbox;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMessageInboxImpl extends AbcAbstractClass<TblMessageInbox> implements TblMessageInboxDao {

    @Override
    public void addTblMessageInbox(TblMessageInbox tblMessageInbox){
        super.addEntity(tblMessageInbox);
    }

    @Override
    public void deleteTblMessageInbox(TblMessageInbox tblMessageInbox) {
        super.deleteEntity(tblMessageInbox);
    }

    @Override
    public void updateTblMessageInbox(TblMessageInbox tblMessageInbox) {
        super.updateEntity(tblMessageInbox);
    }

    @Override
    public List<TblMessageInbox> getAllTblMessageInbox() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMessageInbox> findTblMessageInbox(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMessageInboxCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMessageInbox> findByCountTblMessageInbox(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMessageInbox(List<TblMessageInbox> tblMessageInboxs){
        super.updateAll(tblMessageInboxs);
    }
}
