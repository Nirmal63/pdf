package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblClientDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientImpl extends AbcAbstractClass<TblClient> implements TblClientDao {

    @Override
    public void addTblClient(TblClient tblClient){
        super.addEntity(tblClient);
    }

    @Override
    public void deleteTblClient(TblClient tblClient) {
        super.deleteEntity(tblClient);
    }

    @Override
    public void updateTblClient(TblClient tblClient) {
        super.updateEntity(tblClient);
    }

    @Override
    public List<TblClient> getAllTblClient() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClient> findTblClient(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClient> findByCountTblClient(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClient(List<TblClient> tblClients){
        super.updateAll(tblClients);
    }

	@Override
	public void saveOrUpdateTblClient(TblClient tblClient) {
		super.saveOrUpdateEntity(tblClient);
		
	}
}
