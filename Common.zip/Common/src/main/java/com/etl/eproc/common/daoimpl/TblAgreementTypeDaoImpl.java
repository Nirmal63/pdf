package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblAgreementTypeDao;
import com.etl.eproc.common.model.TblAgreementType;
import com.etl.eproc.common.model.TblAnnexureType;

/**
 *
 * @author Hema
 */
@Repository @Transactional    /*StackUpdate*/
public class TblAgreementTypeDaoImpl extends AbcAbstractClass<TblAgreementType> implements TblAgreementTypeDao {
	
    @Override
    public void addTblAgreementType(TblAgreementType tblAgreementType){
        super.addEntity(tblAgreementType);
    }

    @Override
    public void deleteTblAgreementType(TblAgreementType tblAgreementType) {
        super.deleteEntity(tblAgreementType);
    }

    @Override
    public void updateTblAgreementType(TblAgreementType tblAgreementType) {
        super.updateEntity(tblAgreementType);
    }

    @Override
    public List<TblAgreementType> getAllTblAgreementType() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAgreementType> findTblAgreementType(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAgreementTypeCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAgreementType> findByCountTblAgreementType(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }
}
