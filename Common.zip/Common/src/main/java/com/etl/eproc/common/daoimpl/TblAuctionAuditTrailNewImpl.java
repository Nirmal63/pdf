package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblAuctionAuditTrailNewDao;
import com.etl.eproc.eauction.model.TblAuctionAuditTrailNew;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblAuctionAuditTrailNewImpl extends AbcAbstractClass<TblAuctionAuditTrailNew> implements TblAuctionAuditTrailNewDao {

    @Override
    public void addTblAuctionAuditTrailNew(TblAuctionAuditTrailNew tblAuctionAuditTrailNew){
        super.addEntity(tblAuctionAuditTrailNew);
    }

    @Override
    public void deleteTblAuctionAuditTrailNew(TblAuctionAuditTrailNew tblAuctionAuditTrailNew) {
        super.deleteEntity(tblAuctionAuditTrailNew);
    }

    @Override
    public void updateTblAuctionAuditTrailNew(TblAuctionAuditTrailNew tblAuctionAuditTrailNew) {
        super.updateEntity(tblAuctionAuditTrailNew);
    }

    @Override
    public List<TblAuctionAuditTrailNew> getAllTblAuctionAuditTrailNew() {
        return super.getAllEntity();
    }

    @Override
    public List<TblAuctionAuditTrailNew> findTblAuctionAuditTrailNew(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblAuctionAuditTrailNewCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblAuctionAuditTrailNew> findByCountTblAuctionAuditTrailNew(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblAuctionAuditTrailNew(List<TblAuctionAuditTrailNew> tblAuctionAuditTrailNews){
        super.updateAll(tblAuctionAuditTrailNews);
    }
}
