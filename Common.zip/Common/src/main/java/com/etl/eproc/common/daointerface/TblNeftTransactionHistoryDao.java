package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblNeftTransactionHistory;
import java.util.List;

public interface TblNeftTransactionHistoryDao  {

    public void addTblNeftTransactionHistory(TblNeftTransactionHistory tblNeftTransactionHistory);

    public void deleteTblNeftTransactionHistory(TblNeftTransactionHistory tblNeftTransactionHistory);

    public void updateTblNeftTransactionHistory(TblNeftTransactionHistory tblNeftTransactionHistory);

    public List<TblNeftTransactionHistory> getAllTblNeftTransactionHistory();

    public List<TblNeftTransactionHistory> findTblNeftTransactionHistory(Object... values) throws Exception;

    public List<TblNeftTransactionHistory> findByCountTblNeftTransactionHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblNeftTransactionHistoryCount();

    public void saveUpdateAllTblNeftTransactionHistory(List<TblNeftTransactionHistory> tblNeftTransactionHistorys);
}