package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblContentManagementDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblContentManagement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblContentManagementImpl extends AbcAbstractClass<TblContentManagement> implements TblContentManagementDao {

    @Override
    public void addTblContentManagement(TblContentManagement tblContentManagement){
        super.saveOrUpdateEntity(tblContentManagement);
    }

    @Override
    public void deleteTblContentManagement(TblContentManagement tblContentManagement) {
        super.deleteEntity(tblContentManagement);
    }

    @Override
    public void updateTblContentManagement(TblContentManagement tblContentManagement) {
        super.updateEntity(tblContentManagement);
    }

    @Override
    public List<TblContentManagement> getAllTblContentManagement() {
        return super.getAllEntity();
    }

    @Override
    public List<TblContentManagement> findTblContentManagement(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblContentManagementCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblContentManagement> findByCountTblContentManagement(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblContentManagement(List<TblContentManagement> tblContentManagements){
        super.updateAll(tblContentManagements);
    }
}
