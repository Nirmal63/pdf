package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDownloadDocHistory;
import java.util.List;

public interface TblDownloadDocHistoryDao  {

    public void addTblDownloadDocHistory(TblDownloadDocHistory tblDownloadDocHistory);

    public void deleteTblDownloadDocHistory(TblDownloadDocHistory tblDownloadDocHistory);

    public void updateTblDownloadDocHistory(TblDownloadDocHistory tblDownloadDocHistory);

    public List<TblDownloadDocHistory> getAllTblDownloadDocHistory();

    public List<TblDownloadDocHistory> findTblDownloadDocHistory(Object... values) throws Exception;

    public List<TblDownloadDocHistory> findByCountTblDownloadDocHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDownloadDocHistoryCount();

    public void saveUpdateAllTblDownloadDocHistory(List<TblDownloadDocHistory> tblDownloadDocHistorys);
}