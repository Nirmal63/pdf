package com.etl.eproc.common.daoimpl;


import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblDocUploadConfigDao;

import com.etl.eproc.common.model.TblDocUploadConfig;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository @Transactional    /*StackUpdate*/
public class TblDocUploadConfigImpl extends AbcAbstractClass<TblDocUploadConfig> implements TblDocUploadConfigDao {

	@Override 
	public void addTblDocUploadConfig(TblDocUploadConfig master){
		super.addEntity(master);
	}
	@Override 
	public void deleteTblDocUploadConfig(TblDocUploadConfig master) {
		super.deleteEntity(master);
	}
	@Override 
	public void updateTblDocUploadConfig(TblDocUploadConfig master) {
		super.updateEntity(master);
	}
	@Override 
	public List<TblDocUploadConfig> getAllTblDocUploadConfig() {
		return super.getAllEntity();
	}
	@Override 
	public List<TblDocUploadConfig> findTblDocUploadConfig(Object... values) throws Exception {
		return super.findEntity(values);
	}
	@Override 
	public long getTblDocUploadConfigCount() {
		return super.getEntityCount();
	}
	@Override 
	public List<TblDocUploadConfig> findByCountTblDocUploadConfig(int firstResult, int maxResult, Object... values) throws Exception {
		return super.findByCountEntity(firstResult, maxResult, values);
	}
	@Override 
	public void updateOrSaveTblDocUploadConfig(List<TblDocUploadConfig> tblObj) {
		super.updateAll(tblObj);
	}
}