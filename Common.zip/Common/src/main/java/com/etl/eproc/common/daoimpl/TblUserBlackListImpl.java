package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblUserBlackListDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblUserBlackList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserBlackListImpl extends AbcAbstractClass<TblUserBlackList> implements TblUserBlackListDao {

    @Override
    public void addTblUserBlackList(TblUserBlackList tblUserBlackList){
        super.addEntity(tblUserBlackList);
    }

    @Override
    public void deleteTblUserBlackList(TblUserBlackList tblUserBlackList) {
        super.deleteEntity(tblUserBlackList);
    }

    @Override
    public void updateTblUserBlackList(TblUserBlackList tblUserBlackList) {
        super.updateEntity(tblUserBlackList);
    }

    @Override
    public List<TblUserBlackList> getAllTblUserBlackList() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserBlackList> findTblUserBlackList(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserBlackListCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserBlackList> findByCountTblUserBlackList(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserBlackList(List<TblUserBlackList> tblUserBlackLists){
        super.updateAll(tblUserBlackLists);
    }

	@Override
	public void saveOrUpdateTblUserBlackList(TblUserBlackList tblUserBlackList) {
		super.saveOrUpdateEntity(tblUserBlackList);
	}
}
