/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;


import com.etl.eproc.common.model.TblFormRule;
import java.util.List;

public interface TblFormRuleDao  {

    public void addTblFormRule(TblFormRule tblFormRule);

    public void deleteTblFormRule(TblFormRule tblFormRule);

    public void updateTblFormRule(TblFormRule tblFormRule);

    public List<TblFormRule> getAllTblFormRule();

    public List<TblFormRule> findTblFormRule(Object... values) throws Exception;

    public List<TblFormRule> findByCountTblFormRule(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFormRuleCount();

    public void saveUpdateAllTblFormRule(List<TblFormRule> tblFormRules);
}
