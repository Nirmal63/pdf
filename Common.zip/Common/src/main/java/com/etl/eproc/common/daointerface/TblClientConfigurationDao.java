package com.etl.eproc.common.daointerface;


/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientConfiguration;
import java.util.List;


public interface TblClientConfigurationDao  {

    public void addTblClientConfiguration(TblClientConfiguration tblClientConfiguration);

    public void deleteTblClientConfiguration(TblClientConfiguration tblClientConfiguration);

    public void updateTblClientConfiguration(TblClientConfiguration tblClientConfiguration);

    public List<TblClientConfiguration> getAllTblClientConfiguration();

    public List<TblClientConfiguration> findTblClientConfiguration(Object... values) throws Exception;

    public List<TblClientConfiguration> findByCountTblClientConfiguration(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientConfigurationCount();

    public void saveUpdateAllTblClientConfiguration(List<TblClientConfiguration> tblClientConfigurations);
}