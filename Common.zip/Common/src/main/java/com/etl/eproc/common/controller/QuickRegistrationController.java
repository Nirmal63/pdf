package com.etl.eproc.common.controller;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.WebUtils;

import com.etl.eproc.common.databean.OfficerRegistrationDatabean;
import com.etl.eproc.common.model.TblClient;
import com.etl.eproc.common.model.TblCountry;
import com.etl.eproc.common.model.TblDepartment;
import com.etl.eproc.common.model.TblDesignation;
import com.etl.eproc.common.model.TblHintQuestion;
import com.etl.eproc.common.model.TblOfficer;
import com.etl.eproc.common.model.TblPasswordHistory;
import com.etl.eproc.common.model.TblState;
import com.etl.eproc.common.model.TblTimeZone;
import com.etl.eproc.common.model.TblUserDetail;
import com.etl.eproc.common.model.TblUserHistory;
import com.etl.eproc.common.model.TblUserLogin;
import com.etl.eproc.common.services.AuditTrailService;
import com.etl.eproc.common.services.ClientService;
import com.etl.eproc.common.services.CommonService;
import com.etl.eproc.common.services.DepartmentService;
import com.etl.eproc.common.services.DepartmentUserService;
import com.etl.eproc.common.services.DynamicFieldService;
import com.etl.eproc.common.services.ExceptionHandlerService;
import com.etl.eproc.common.services.LoginService;
import com.etl.eproc.common.services.ManageContentService;
import com.etl.eproc.common.services.QuickDepartmentUserService;
import com.etl.eproc.common.services.WSCheckAvailService;
import com.etl.eproc.common.utility.AbcUtility;
import com.etl.eproc.common.utility.CommonKeywords;
import com.etl.eproc.common.utility.CommonValidators;
import com.etl.eproc.common.utility.CustomAuthenticationFilter;
import com.etl.eproc.common.utility.EncryptDecryptUtils;
import com.etl.eproc.common.utility.MailContentUtillity;
import com.etl.eproc.common.utility.ModelToSelectItem;
import com.etl.eproc.common.utility.SHA1HashEncryption;
import com.etl.eproc.common.utility.SHA256HashEncryption;
import com.etl.eproc.common.utility.SelectItem;
import com.etl.eproc.common.utility.SessionBean;
import com.etl.eproc.common.utility.WSCheckAvail;
import com.etl.eproc.common.webservice.DataObject;
import com.etl.eproc.factory.AbcCaptchaFactory;

@Controller
public class QuickRegistrationController {


    @Autowired
    private ExceptionHandlerService exceptionHandlerService;
    @Autowired
    private DepartmentUserService departmentUserService;
    @Autowired
    private QuickDepartmentUserService quickDepartmentUserService;
    @Autowired
    private CommonService commonService;
    @Autowired
    private SHA256HashEncryption sha256HashEncryption;
    @Autowired
    private SHA1HashEncryption sha1HashEncryption;
    @Autowired
    private EncryptDecryptUtils encryptDecryptUtils;
    @Autowired
    private LoginService loginService;
    @Autowired
    private ModelToSelectItem modelToSelectItem;
    @Autowired
    private CommonValidators commonValidators;
    @Autowired
    private ClientService clientService;
    @Autowired
    private DepartmentService departmentService;
    @Autowired
    private AuditTrailService auditTrailService;
    @Autowired
    private WSCheckAvailService wSCheckAvailService;
    @Autowired
    private ManageContentService manageContentService;
    @Autowired
    private DynamicFieldService dynamicFieldService;
    @Value("#{projectProperties['userhistory.actiontype.enabled']}")
    private int actionTypeenabled;
    @Value("#{projectProperties['reset.passwordupdatedfrom']}")
    private int passwordUpdatedFrom;
    @Value("#{projectProperties['auction_Admin_userId']}")
    private String auctionAdminuserId;
    @Value("#{projectProperties['eproc_clientId']}")
    private String eprocClientId;
    @Value("#{projectProperties['block_user_mail_to']}")
	private String block_user_mail_Id;
    @Value("#{projectProperties['phone_no']}")
	private String contact_phoneno;
	@Value("#{projectProperties['email']}")
	private String contact_emailId;
    @Autowired
    private static final String DEPT_USER_GRID_URL = "";
    @Autowired
    private AbcUtility abcUtility; 
    @Autowired
    private MailContentUtillity mailContentUtillity;
    

    @Value("#{linkProperties['manage_user_field_value']?:786}")
	private int manageUserFieldValueId;
    @Value("#{projectProperties['officer.status.approved']?:1}")
    private int officerStatusApproved;
    @Value("#{projectProperties['officer.status.pending']?:0}")
    private int cstatusPending;
    @Value("#{projectProperties['userhistory.actiontype.create']?:1}")
    private int actiontypecreate;
    @Value("#{linkProperties['manage_department_user_create_department_user']?:13}")
    private int createDeptUserLinkId;
    @Value("#{projectProperties['default_rights']}")
    private String defaultRights;
	
    @Autowired
    CustomAuthenticationFilter customAuthenticationFilter;
    private final static String XFORWARDEDFOR = "X-FORWARDED-FOR";
    
     
    
    /**
     * @author nirav.prajapati
     * Department user creation handler - which serves the dept. user creation request for page display purpose
     * create dept user
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "/createdeptuser", method = RequestMethod.GET)
    public String createDeptUser(ModelMap modelMap,HttpServletRequest request,OfficerRegistrationDatabean officerRegistrationDatabean) {
        try {
        	modelMap.put("captchaHtml",AbcCaptchaFactory.newAbcCaptcha(0));
        	setDeptUserModelmap(modelMap, request, "create", 0, officerRegistrationDatabean);
        	List<Object[]> contentManagement = manageContentService.getClientRegTerms(abcUtility.getSessionClientId(request), 8, Integer.parseInt(WebUtils.getCookie(request, "locale").getValue()));
			modelMap.put("contentManagementId",contentManagement != null && !contentManagement.isEmpty()?contentManagement.get(0)[1]:0);
			
        } catch (Exception e) {
        	
            return exceptionHandlerService.writeLog(e);
        }finally{
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createDeptUserLinkId,getDeptUserCreateRemark, 0,0,"");
        }
        return "/common/admin/CreateQuickDeptUser";
    }
	
    
    /**
     * @author nirav.prajapati
     * @param officerRegistrationDatabean
     * @param result
     * @param request
     * @param session
     * @param redirectAttributes
     * @param modelMap
     * @return
     */
	@RequestMapping(value = "/addQuickDeptUser", method = RequestMethod.POST)
    public String addDeptUser(@ModelAttribute OfficerRegistrationDatabean officerRegistrationDatabean, BindingResult result, HttpServletRequest request, HttpSession session, RedirectAttributes redirectAttributes,ModelMap modelMap) {
        boolean success = false;
        boolean isProfile = false;
        String auditstr = null;
        String returnStr = "redirect:/loginfailed";
        int officerverificationby = 0;            
        int parentId = 0;
        int actionType = 0;
        int officerId = 0;
        int bidderId = 0;
        int LinkId = 0;
        TblUserLogin tblUserLogin =null;
        TblOfficer  tblOfficer = null;
        TblDepartment tblDepartment = null;
        TblDesignation tblDesignation = null;
        TblUserDetail  tblUserDetail = null;                        
        TblUserHistory  tblUserHistory = null;
        TblPasswordHistory tblPasswordHistory = new TblPasswordHistory();
        try{
        	
        	officerRegistrationDatabean.setTxtPhoneNo("8989898989");//set default phone number only to satisfy existing validation   
            officerRegistrationDatabean.setCommonValidators(commonValidators);
            officerRegistrationDatabean.validate(result);
            officerRegistrationDatabean.setTxtPhoneNo("");//set default phone number 
            int clientId = abcUtility.getSessionClientId(request);    
          
            if(officerRegistrationDatabean.getHdfrom()!=null && !"".equals(officerRegistrationDatabean.getHdfrom()) && "profile".equalsIgnoreCase(officerRegistrationDatabean.getHdfrom())){
                isProfile = true;
            }
            
            	List<LinkedHashMap<String, Object>> list = commonService.checkValidUserInClient(clientId, officerRegistrationDatabean.getTxtEmailId(), 3); 
            	Map<String, Object> map  = list.get(0);
                if(list != null && !list.isEmpty()) {
                    if(map.get("actionType") != null) {
                        actionType = Integer.parseInt(map.get("actionType").toString());
                        officerId = Integer.parseInt(map.get("officerId").toString());
                        bidderId = Integer.parseInt(map.get("bidderId").toString());
                        if(actionType==2 && officerId>0) {
                            result.rejectValue("txtEmailId", "msg_js_registration_officerexists", "Email ID already registered as department user on this domain.");
                        }else if(actionType==2 && bidderId>0) {
                            result.rejectValue("txtEmailId", "msg_js_registration_bidderexists", "Email ID already registered as bidder on this domain.");
                        }
                    }
                }
                boolean isUserNotValid = clientService.isUserNotBlock(officerRegistrationDatabean.getTxtEmailId(),officerRegistrationDatabean.getTxtMobileNo()!=null?officerRegistrationDatabean.getTxtMobileNo():"0",1);
                if(result.hasErrors()) {                        
                    returnStr = "redirect:/createdeptuser"; //"redirect:/common/admin/createdeptuser" + encryptDecryptUtils.generateRedirect("common/admin/createdeptuser", request);
                    auditstr = "";
                    redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(),CommonKeywords.ERROR_MSG_KEY.toString());
            	}else if(isUserNotValid){
            		String ipAddress = request.getHeader(XFORWARDEDFOR) != null ? request.getHeader(XFORWARDEDFOR) : request.getRemoteAddr();
            		Map<String, Object> mailParamsEmail = new HashMap<String, Object>();
					mailParamsEmail.put("ClientName", clientService.getClientNameById(clientId));
					mailParamsEmail.put("to", block_user_mail_Id);
					mailParamsEmail.put("emailId", officerRegistrationDatabean.getTxtEmailId());
					mailParamsEmail.put("mobileNo", officerRegistrationDatabean.getTxtMobileNo());
					mailParamsEmail.put("ipAddress", ipAddress);
					mailContentUtillity.dynamicMailGeneration("360",String.valueOf(abcUtility.getSessionUserId(request)),String.valueOf(clientId), mailParamsEmail, "");
					 returnStr = "redirect:/"; //"redirect:/common/admin/createdeptuser" + encryptDecryptUtils.generateRedirect("common/admin/createdeptuser", request);
	                    auditstr = "";
	                    redirectAttributes.addFlashAttribute("phoneno", contact_phoneno);
						redirectAttributes.addFlashAttribute("emailId", contact_emailId);
					 redirectAttributes.addFlashAttribute(CommonKeywords.ERROR_MSG.toString(), "redirect_registration_not_allow_contact");
            	}else{
            	int userId = abcUtility.getSessionUserId(request);
                Date serverdateime= commonService.getServerDateTime();
                
                /*step 1 : prepare department databean*/
               tblDepartment = _toTblDepartment(clientId, userId, officerRegistrationDatabean, serverdateime);

               /*step 2 : prepare designation databean*/
               tblDesignation = _toTblDesignation(clientId, userId, officerRegistrationDatabean, serverdateime);
               
               /*step 3 : prepare default assign rights */
               List<String> defaultRightslst = Arrays.asList(defaultRights.split("\\s*,\\s*"));
               
               /*step 4 : prepare databeans for userdetail,tblofficer,tbluserlogin according to actiontype */
               officerverificationby =  clientService.getOfficerRegistrationVerifiedBy(clientId);
                    int cStatus = 0;
                    int isFistLogin = 0;
                    int isEmailVerified = 0;
                    
                  //only for autologin in case of user is already buyer or bidder on other domain
                    String existUserPassword ="";
                    String existUserEmailId ="";
                    
                    if(officerverificationby == 0){
                        cStatus = officerStatusApproved;
                        isEmailVerified=1;
                    } else if(actionType==3 && officerId>0) {
                    	List<TblUserLogin> tblUserLogins = commonService.getUserLoginById(officerId);
                    	if(tblUserLogins != null && !tblUserLogins.isEmpty()) {
                    		if(tblUserLogins.get(0).getIsEmailVerified()==1) {
                    			cStatus = officerStatusApproved;
                    			isEmailVerified=1;
                    		}
                    	}
                    } else {
                        cStatus = cstatusPending;
                    }
                    
                    boolean flag = true;
                    if(officerRegistrationDatabean.getTxtactionType().equalsIgnoreCase("6")){                   ////////dumping from sso
                        DataObject dataObject =  WSCheckAvail.getSSOLoginMastreDetailasObject(officerRegistrationDatabean.getTxtEmailId());
                        tblUserLogin = _toTblUserLogin(serverdateime,userId,clientId,"0",commonService,dataObject,officerRegistrationDatabean);
                        tblUserLogin.setIsFirstLogin(isFistLogin);
                        tblUserLogin.setIsEmailVerified(1);
                        tblUserDetail = _toTblUserDetail(clientId,userId,dataObject, officerRegistrationDatabean);
                        tblUserDetail.setTblUserLogin(tblUserLogin);
                        tblOfficer = _toTblOfficer(serverdateime,userId,clientId,cStatus,dataObject,officerRegistrationDatabean);
                        tblOfficer.setTblUserLogin(tblUserLogin);
                        tblUserHistory = officerRegistrationDatabean._toTblUserHistory(clientId,userId,actiontypecreate);
                        tblUserHistory.setTblUserLogin(tblUserLogin);                            
                    }else if(actionType == 3){
                        tblUserDetail = _toTblUserDetail(clientId,userId,null, officerRegistrationDatabean);
                        tblUserDetail.setTblUserLogin(new TblUserLogin(officerId));
                        List<Object[]> list1 = departmentUserService.getUserNamePhoneNo(officerId);
                        tblUserDetail.setUserName(list1.get(0)[1]!=null?list1.get(0)[1].toString():"");
                        tblOfficer = _toTblOfficer(serverdateime,userId,clientId,cStatus,null,officerRegistrationDatabean);
                        tblOfficer.setTblUserLogin(new TblUserLogin(officerId));
                        tblOfficer.setPhoneNo(list1.get(0)[0]!=null?list1.get(0)[0].toString():"");
                        tblUserHistory = officerRegistrationDatabean._toTblUserHistory(clientId,userId,actiontypecreate);
                        tblUserHistory.setTblUserLogin(new TblUserLogin(officerId));
                        existUserPassword=loginService.getUserLoginById(officerId).getPassword();
                        parentId = officerId;
                        flag = false;
                    }else if(actionType == 4){
                        tblUserDetail = _toTblUserDetail(clientId,userId,null, officerRegistrationDatabean);
                        tblUserDetail.setTblUserLogin(new TblUserLogin(bidderId));
                        List<Object> list2 = departmentUserService.getUserName(bidderId);
                        tblUserDetail.setUserName(list2.get(0)!=null?list2.get(0).toString():"");
                        tblOfficer = _toTblOfficer(serverdateime,userId,clientId,cStatus,null,officerRegistrationDatabean);
                        tblOfficer.setTblUserLogin(new TblUserLogin(bidderId));
                        tblUserHistory = officerRegistrationDatabean._toTblUserHistory(clientId,userId,actiontypecreate);
                        tblUserHistory.setTblUserLogin(new TblUserLogin(bidderId));
                        existUserPassword=loginService.getUserLoginById(bidderId).getPassword();
                        parentId = bidderId;
                        flag = false;
                    }else if(actionType ==1){
                        String verificationCode = "0";
                        if(officerverificationby == 1){
                            verificationCode = UUID.randomUUID().toString().replaceAll("-", "").substring(0,10);
                        }
                        tblUserLogin = _toTblUserLogin(serverdateime,userId,clientId,"0",commonService,null,officerRegistrationDatabean);;
                        tblUserLogin.setPassword(sha256HashEncryption.encodeStringSHA256(officerRegistrationDatabean.getTxtPassword()));
                        tblUserLogin.setIsFirstLogin(isFistLogin);
                        tblUserLogin.setIsEmailVerified(isEmailVerified);
                        tblUserDetail = _toTblUserDetail(clientId,userId,null, officerRegistrationDatabean);
                        tblUserDetail.setTblUserLogin(tblUserLogin);
                        tblOfficer = _toTblOfficer(serverdateime,userId,clientId,cStatus,null,officerRegistrationDatabean);
                        tblOfficer.setTblUserLogin(tblUserLogin);
                        tblUserHistory = officerRegistrationDatabean._toTblUserHistory(clientId,userId,actiontypecreate);
                        tblUserHistory.setTblUserLogin(tblUserLogin);   
                    }
                    if(flag){
                        tblPasswordHistory.setCreatedBy(abcUtility.getSessionUserId(request));
                        tblPasswordHistory.setCreatedOn(serverdateime);
                        tblPasswordHistory.setOldPassword(tblUserLogin.getPassword());
                        tblPasswordHistory.setPasswordUpdatedFrom(5);
                    }
                    
                    success = quickDepartmentUserService.addDeptUser(tblDepartment,tblDesignation,defaultRightslst, tblUserLogin, tblUserDetail, tblOfficer, tblUserHistory,tblPasswordHistory,flag);
                   
                    if(success)
                    {
                    	if(officerRegistrationDatabean.getTxtactionType().equalsIgnoreCase("1")){
                             boolean isRegister = wSCheckAvailService.registerSSA(null,officerRegistrationDatabean, tblUserLogin.getUserId(), 3, clientId,true);
                             if(isRegister){
         						loginService.updateLoginSSOStatus(userId);//Is bidder register in SSO,change SSO-status 0 to 1 in TblUserLogin
         					}
                        }
                    	
                    }	
                    String randomNo ="";
                    if(request.getSession().getAttribute("TEMP_RNDNO") == null)
                    {
                    	randomNo = UUID.randomUUID().toString();
                    	request.getSession().setAttribute("TEMP_RNDNO",randomNo);
                    } else {
                    	randomNo = request.getSession().getAttribute("TEMP_RNDNO").toString();
                    }	
                    String passwordForRedirect = officerRegistrationDatabean.getTxtPassword()!=null?officerRegistrationDatabean.getTxtPassword():existUserPassword;
                    String shaStr = sha256HashEncryption.encodeStringSHA256(sha256HashEncryption.encodeStringSHA256(passwordForRedirect)+randomNo)+"@@"+sha256HashEncryption.encodeStringSHA256(sha1HashEncryption.encodeStringSHA1(passwordForRedirect)+randomNo);
                    doAutoLogin(officerRegistrationDatabean.getTxtEmailId(), shaStr, request);
                    returnStr = "redirect:/";   // For bug #31761 By Jitendra
                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_create_deptuserprofile");
//                    returnStr = "redirect:/submitLogin"; 
//                    redirectAttributes.addFlashAttribute(CommonKeywords.SUCCESS_MSG.toString(),"redirect_success_create_quickauctioneerprofile");
                    	
            	}
            }
        catch(Exception ex){ 
            return exceptionHandlerService.writeLog(ex);
        }finally{
            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), LinkId, auditstr, 0, parentId,"");
        }
        return returnStr;
    }	
	
	
	 /**
     * @author nirav.prajapati
     * Department user creation handler - which serves the dept. user creation request for page display purpose
     * create dept user
     * @param enc
     * @param modelMap
     * @return to view
     */
    @RequestMapping(value = "common/admin/emailverificationpopup/{enc}", method = RequestMethod.GET)
    public String emailVerification(ModelMap modelMap,HttpServletRequest request,OfficerRegistrationDatabean officerRegistrationDatabean) {
        try {
        	modelMap.put("captchaHtml",AbcCaptchaFactory.newAbcCaptcha(0));
        	setDeptUserModelmap(modelMap, request, "create", 0, officerRegistrationDatabean);
        	List<Object[]> contentManagement = manageContentService.getClientRegTerms(abcUtility.getSessionClientId(request), 8, Integer.parseInt(WebUtils.getCookie(request, "locale").getValue()));
			modelMap.put("contentManagementId",contentManagement != null && !contentManagement.isEmpty()?contentManagement.get(0)[1]:0);
			
        } catch (Exception e) {
        	
            return exceptionHandlerService.writeLog(e);
        }finally{
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createDeptUserLinkId,getDeptUserCreateRemark, 0,0,"");
        }
        return "/common/admin/EmailVerificationPopUp";
    }
	
    
    /**
     * @author nirav.prajapati
     * Department user creation handler - which serves the dept. user creation request for page display purpose
     * create dept user
     * @param enc
     * @param modelMap
     * @return to view
     */
    @ResponseBody
    @RequestMapping(value = "common/emailverification", method = RequestMethod.POST)
    public String emailVerificationByOfficer(@RequestParam("txtUserType") String txtUserType,ModelMap modelMap,HttpServletRequest request,OfficerRegistrationDatabean officerRegistrationDatabean) {
    	String retVal ="";
    	try {
        	int userType = request.getParameter("txtUserType")!=null?Integer.parseInt(request.getParameter("txtUserType")):0;
        	int userId = abcUtility.getSessionUserId(request);
        	int clientId = abcUtility.getSessionClientId(request);
        	TblOfficer tblOfficer1 = quickDepartmentUserService.getTblOfficerByUserId(userId);
        	TblUserLogin tblUserLogin = loginService.getUserLoginById(userId);
        	
        	if(userType == 3)
        	{
        		int actionType = 1;
        		URL url = new URL(request.getRequestURL().toString());
                StringBuilder verifyUrlPrefix = new StringBuilder();
                verifyUrlPrefix.append(((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) ? "http" : "https").append("://").append(url.getHost());
                if ((url.getPort() != 80) && (url.getPort() != 443) && (url.getPort() != -1)) {
                     verifyUrlPrefix.append(":").append(url.getPort());
                }
                verifyUrlPrefix.append(url.getPath().substring(url.getPath().indexOf("/"), url.getPath().lastIndexOf("/"))); 
                	Map<String, Object> paramMap =  new HashMap<String, Object>();
                    paramMap.put("subdomainname", url.getHost());
                    paramMap.put("to",tblUserLogin.getLoginId());
                    paramMap.put("loginId", tblUserLogin.getLoginId());                           
                    switch(actionType){
                        case 1:
                                paramMap.put("password", tblUserLogin.getPassword());
                                switch (1) {
                                     case 1:
                                             paramMap.put("link1", "<a href=\"/authbiddermail/"+encryptDecryptUtils.encrypt(tblUserLogin.getLoginId()+"@@"+3+"_"+tblOfficer1.getOfficerId())+"/"+encryptDecryptUtils.encrypt(tblUserLogin.getVerificationCode())+"\">Email Verification Link</a>");
                                             mailContentUtillity.dynamicMailGeneration("1", String.valueOf(userId), String.valueOf(clientId),paramMap);
                                             break;
                                     default:
                                             break;
                                }
                        default:
                               break;    
                }
                   retVal ="true";
        	}	
        	else if(userType == 2)
        	{
        		int actionTypeforBidder = 1;
        		Map<String, Object> mailParams = new HashMap<String, Object>();
				mailParams.put("UsersRegisteredEmailId", tblUserLogin.getLoginId());
				mailParams.put("to",tblUserLogin.getLoginId());
				mailParams.put("Url", clientService.getClientNameById(clientId));
				switch (actionTypeforBidder) {
				case 1:
						mailContentUtillity.dynamicMailGeneration("1",String.valueOf(userId),String.valueOf(clientId), mailParams, "");
					break;
				default:
					break;
				}
				retVal = "true";
        	}	
        } catch (Exception e) {
        	retVal = "false";
            return exceptionHandlerService.writeLog(e);
        }finally{
//            auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createDeptUserLinkId,getDeptUserCreateRemark, 0,0,"");
        }
        return retVal;
    }
	
    
    
    
    /**
     * 
     * @param txtUserId
     * @param request
     * @return
     */
    @RequestMapping(value="/ajax/checkuseremailverified", method=RequestMethod.POST)
    @ResponseBody
    public String checkUniqueDepartmentName(@RequestParam("txtUserId") String txtUserId,HttpServletRequest request){
    	boolean isExist = false;
    	String emailId ="";
    	try{
    		if(abcUtility.getSessionUserId(request)!=0){
    			SessionBean sessionBean=request.getSession()!= null && request.getSession().getAttribute("sessionObject") != null ? (SessionBean)request.getSession().getAttribute("sessionObject") : null;
    			int isEmailVeriReq = sessionBean.getUserTypeId() == 2 ? clientService.getBidderRegistrationVerifiedBy(abcUtility.getSessionClientId(request)):sessionBean.getUserTypeId() == 3 ? clientService.getOfficerRegistrationVerifiedBy(abcUtility.getSessionClientId(request)):0;
    			TblUserLogin tblUserLogin = loginService.getUserLoginById(Integer.parseInt(txtUserId));
    			if(tblUserLogin.getIsEmailVerified() == 0 && isEmailVeriReq == 1){
    				isExist = true;
    			}else{
    				isExist = false;
    			}	
    			emailId = tblUserLogin.getLoginId();
    		}else{
    			return "sessionexpired";
    		}
    		
    	} catch (Exception e) {
    		exceptionHandlerService.writeLog(e);
    	} 
    	finally {
//             auditTrailService.makeAuditTrail(request.getAttribute(CommonKeywords.AUDIT_BEAN.toString()), createDeptLinkId, ajaxCheckUniqueDeptNameAuditMsg, 0, deptId);
        }
    	return isExist+"@@"+emailId;
    } 
    
    
    
    
	/**
	 * @author nirav.prajapati
	 * @param clientId
	 * @param userId
	 * @param dataObject
	 * @param currentTime
	 * @return
	 * @throws Exception
	 */
	private TblDepartment _toTblDepartment(int clientId,int userId,OfficerRegistrationDatabean dataObject,Date currentTime) throws Exception{
		List<Object[]> lstClientDtls = clientService.getClientParentDeptNameByClientId(clientId);
        TblDepartment tblDepartment = new TblDepartment();
        tblDepartment.setDeptName(dataObject.getTxtDeptname());
        tblDepartment.setAddress("");
        tblDepartment.setCity("");
        tblDepartment.setCreatedBy(userId);
        tblDepartment.setCstatus(1);
        tblDepartment.setPhoneNo("");
        tblDepartment.setCreatedOn(currentTime);
        tblDepartment.setTblClient(new TblClient(clientId));
        tblDepartment.setTblCountry(new TblCountry(105));// india default country
        tblDepartment.setTblState(new TblState(1281));//gujarat default country
        if(lstClientDtls!=null && !lstClientDtls.isEmpty())
        {
        	tblDepartment.setParentDeptId((Integer)lstClientDtls.get(0)[2]);
        }	
        return tblDepartment;  
    }
	

	/**
	 * @author nirav.prajapati
	 * @param clientId
	 * @param userId
	 * @param dataObject
	 * @param currentTime
	 * @return
	 * @throws Exception
	 */
	private TblDesignation _toTblDesignation(int clientId,int userId,OfficerRegistrationDatabean dataObject,Date currentTime) throws Exception{
		TblDesignation tblDesignation = new TblDesignation();
		tblDesignation.setDesignationName("Buyer");//set default designation to Buyer
		tblDesignation.setCstatus(1);
		tblDesignation.setCreatedBy(userId);
		tblDesignation.setCreatedOn(currentTime);
		tblDesignation.setGradeId(0);
		tblDesignation.setParentDesignationId(0);
		
		return tblDesignation;
	}
	
	 /**
	  * @author nirav.prajapati
     * set the all request parameter in TblUserLogin persistent object for Department user creation and edition
     * @param date
     * @param userId
     * @param verificationCode
     * @return 
     */
    private  TblUserLogin _toTblUserLogin(Date date,int userId,int clientId,String verificationCode,CommonService commonService,DataObject dataObject,OfficerRegistrationDatabean officerRegistrationDatabean){
        TblUserLogin tblUserLogin = new TblUserLogin();
        tblUserLogin.setFailedLoginAttempt(0);
        tblUserLogin.setLoginId(officerRegistrationDatabean.getTxtEmailId());
        String mobileNo = "";
        String password = "";
        if(dataObject!=null && dataObject.getData12()!=null){
            mobileNo = dataObject.getData12().toString();
        }else{
            if(officerRegistrationDatabean.getTxtMobileNo()!=null && !"".equalsIgnoreCase(officerRegistrationDatabean.getTxtMobileNo())){
                mobileNo = officerRegistrationDatabean.getTxtMobileNo();
            }
        }
        if(dataObject!=null && dataObject.getData25()!=null && !"".equalsIgnoreCase(dataObject.getData25().toString())){
            password = dataObject.getData25().toString();
        }else{
            if(officerRegistrationDatabean.getTxtPassword()!=null && !"".equalsIgnoreCase(officerRegistrationDatabean.getTxtPassword())){
                password = officerRegistrationDatabean.getTxtPassword();
            }
        }
        tblUserLogin.setMobileNo(mobileNo);
        tblUserLogin.setPassword(password);
        try {
            tblUserLogin.setTblHintQuestion(new TblHintQuestion((dataObject!=null && dataObject.getData4()!=null && !"".equalsIgnoreCase(dataObject.getData4().toString()))?commonService.getHintQuestionIdByQuestion(dataObject.getData4().toString()).getHintQuestionId():1));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        tblUserLogin.setHintAnswer((dataObject!=null && dataObject.getData5()!=null && !"".equalsIgnoreCase(dataObject.getData5().toString()))?dataObject.getData5().toString():"abcd");
        tblUserLogin.setUserName((dataObject!=null && dataObject.getData7()!=null && !"".equalsIgnoreCase(dataObject.getData7().toString()))?dataObject.getData7().toString():officerRegistrationDatabean.getTxtFullName());
        tblUserLogin.setPasswordUpdatedOn(date);
        tblUserLogin.setCreatedBy(userId);
        tblUserLogin.setVerificationCode(verificationCode);
        try {
            tblUserLogin.setTblTimeZone(new TblTimeZone(42));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        tblUserLogin.setTblClient(new TblClient(clientId));
        return tblUserLogin;  
    }
   
    
    
    /**
     * @author nirav.prajapati
     * set the all request parameter in TblUserDetail persistent object for Department user creation and edition
     * @param clientId
     * @param userId
     * @return 
     */
    private TblUserDetail _toTblUserDetail(int clientId,int userId,DataObject dataObject,OfficerRegistrationDatabean officerRegistrationDatabean){
        TblUserDetail tblUserDetail = new TblUserDetail();
        tblUserDetail.setCreatedBy(userId);
        tblUserDetail.setDeptName(officerRegistrationDatabean.getTxtDeptname());
        tblUserDetail.setDesignation("Buyer");//set default designation to Buyer in userdetail
        tblUserDetail.setLoginId(officerRegistrationDatabean.getTxtEmailId());
        tblUserDetail.setClientId((officerRegistrationDatabean.getRduserrole()!=null && !"".equalsIgnoreCase(officerRegistrationDatabean.getRduserrole()) && Integer.parseInt(officerRegistrationDatabean.getRduserrole())==1)?0:clientId);
        tblUserDetail.setUserName((dataObject!=null && dataObject.getData7()!=null && !"".equalsIgnoreCase(dataObject.getData7().toString()))?dataObject.getData7().toString():officerRegistrationDatabean.getTxtFullName());
        tblUserDetail.setCompanyName((dataObject!=null && dataObject.getData6()!=null && !"".equalsIgnoreCase(dataObject.getData6().toString()))?dataObject.getData6().toString():"");
        return tblUserDetail;  
    }
	
    
    /**
     * @author nirav.prajapati
     * set the all request parameter in TblOfficer persistent object for Department user creation and edition
     * @param date
     * @param userId
     * @param clientId
     * @return 
     */
    private TblOfficer _toTblOfficer(Date date,int userId,int clientId,int cStatus,DataObject dataObject,OfficerRegistrationDatabean officerRegistrationDatabean){
        TblOfficer tblOfficer = new TblOfficer();
        tblOfficer.setCstatus(cStatus);
        if(officerRegistrationDatabean.getRduserrole()!=null && !"".equalsIgnoreCase(officerRegistrationDatabean.getRduserrole())){
            tblOfficer.setIsAbcUser(Integer.parseInt(officerRegistrationDatabean.getRduserrole()));
        }else{
            tblOfficer.setIsAbcUser(0);
        }
        tblOfficer.setLowerLimit(officerRegistrationDatabean.getTxtMinFinLimit()!=null ? Long.parseLong(officerRegistrationDatabean.getTxtMinFinLimit()) : 0);
        tblOfficer.setPhoneNo("");//set default phone number blank for Buyer
        tblOfficer.setTblClient(new TblClient(clientId));
        tblOfficer.setTblDepartment(new TblDepartment(officerRegistrationDatabean.gettxtDept()!=null ? Integer.parseInt(officerRegistrationDatabean.gettxtDept()):0));
        tblOfficer.setTblDesignation(new TblDesignation(officerRegistrationDatabean.getTxtParentDesig() !=null ? Integer.parseInt(officerRegistrationDatabean.getTxtParentDesig()):0));
        tblOfficer.setUpperLimit(officerRegistrationDatabean.getTxtMaxFinLimit()!=null ? Long.parseLong(officerRegistrationDatabean.getTxtMaxFinLimit()) : 0);
        tblOfficer.setCreatedBy(userId);
        tblOfficer.setUpdatedOn(date);
        return tblOfficer;  
    }
    
    
	/**
	 * @author nirav.prajapati
     * setting the common modal map for create and edit case of department user creation
     * create/edit dept user set common model map
     * @param modelMap
     * @param session
     * @return void
     */
    private void setDeptUserModelmap(ModelMap modelMap,HttpServletRequest request,String operType,int DeptUserId,OfficerRegistrationDatabean officerRegistrationDatabean) throws Exception{   	
        List<SelectItem> timezonelist = new ArrayList<SelectItem>();
        List<SelectItem> userRoleRadio = new ArrayList<SelectItem>();
        List<TblTimeZone> tblTimeZonelist = commonService.getTimeZoneList();
        if(tblTimeZonelist!=null && !tblTimeZonelist.isEmpty()){
            timezonelist = modelToSelectItem.convertListIntoSelectItemList(tblTimeZonelist, "timeZoneId", "lang"+WebUtils.getCookie(request, "locale").getValue());
        }   
        
        int userId = abcUtility.getSessionUserId(request); 
        boolean isAbcUser = commonService.checkAbcUser(Integer.toString(DeptUserId))>0?true:false;
        int clientId = abcUtility.getSessionClientId(request); 
        if(userId!=0){
            if(userId == Integer.parseInt(auctionAdminuserId) && clientId==Integer.parseInt(eprocClientId)){
                userRoleRadio.add(new SelectItem("Admin User", 1));
                userRoleRadio.add(new SelectItem("Department User", 0));
                modelMap.addAttribute("userRoles", userRoleRadio);
            }
        }        
        if("create".equalsIgnoreCase((operType))){
        	modelMap.addAttribute("objectId", 0);
            List<Object[]> timezoneIdlist = commonService.getClientCountryStateTimezone(clientId);
            if(timezoneIdlist.get(0)[0]!=null){
                officerRegistrationDatabean.setselTimeZone(timezoneIdlist.get(0)[0].toString());          
            }            
        }else{
        	
        }
        
    	String langId=WebUtils.getCookie(request, "locale").getValue();
        modelMap.put("countryList",modelToSelectItem.convertListIntoSelectItemList(commonService.getCountryList(langId), "countryId", "lang"+langId));
        modelMap.put("clientId",clientId);
        List<Object[]> dataList=departmentService.getStateIdByClientId(clientId);
        
        if(dataList!=null && !dataList.isEmpty()){
        	Object[] obj=dataList.get(0);
        	modelMap.put("stateList", modelToSelectItem.convertListIntoSelectItemList(commonService.getStateBycountryId((Integer)obj[1]), "stateId", "lang"+WebUtils.getCookie(request, "locale").getValue()));
        	modelMap.put("stateId",obj[0]);
        	modelMap.put("countryId",obj[1]);
        }
        modelMap.addAttribute("timezonelist", timezonelist);
        modelMap.addAttribute("operType", operType);
        modelMap.addAttribute("officerRegistrationDatabean", officerRegistrationDatabean);
        modelMap.addAttribute("clientId", clientId);
        modelMap.addAttribute("linkId", manageUserFieldValueId);
        modelMap.put("lstClientMarquee", clientService.getClientMarqueeBylocation((int) abcUtility.getSessionClientId(request),3));/* For After Loging Marque */
    }
    
    private void doAutoLogin(String username, String password, HttpServletRequest request) {

        try {
            // Must be called from request filtered by Spring Security, otherwise SecurityContextHolder is not updated
            UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(username, password,getAuthorities("Officer"));
            token.setDetails(new WebAuthenticationDetails(request));
            Authentication authentication = customAuthenticationFilter.authenticate(token);
            SecurityContextHolder.getContext().setAuthentication(authentication);
        } catch (Exception e) {
            SecurityContextHolder.getContext().setAuthentication(null);
        }

    }
    
    
    private Collection<GrantedAuthority> getAuthorities(String access) {
        List<GrantedAuthority> authList = new ArrayList<GrantedAuthority>();

        if (access.equals("Bidder")) {
            authList.add(new GrantedAuthorityImpl("ROLE_BIDDER"));
        }
        if (access.equals("Officer")) {
            authList.add(new GrantedAuthorityImpl("ROLE_OFFICER"));
        }
        if (access.equals("Abcuser")) {
            authList.add(new GrantedAuthorityImpl("ROLE_ABCUSER"));
        }
        return authList;
    }
    
}
