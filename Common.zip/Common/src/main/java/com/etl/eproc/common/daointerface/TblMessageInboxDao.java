package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMessageInbox;
import java.util.List;

public interface TblMessageInboxDao  {

    public void addTblMessageInbox(TblMessageInbox tblMessageInbox);

    public void deleteTblMessageInbox(TblMessageInbox tblMessageInbox);

    public void updateTblMessageInbox(TblMessageInbox tblMessageInbox);

    public List<TblMessageInbox> getAllTblMessageInbox();

    public List<TblMessageInbox> findTblMessageInbox(Object... values) throws Exception;

    public List<TblMessageInbox> findByCountTblMessageInbox(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblMessageInboxCount();

    public void saveUpdateAllTblMessageInbox(List<TblMessageInbox> tblMessageInboxs);
}