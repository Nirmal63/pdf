package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.eauction.model.TblAuctionAuditTrailNew;

public interface TblAuctionAuditTrailNewDao  {

    public void addTblAuctionAuditTrailNew(TblAuctionAuditTrailNew tblAuctionAuditTrailNew);

    public void deleteTblAuctionAuditTrailNew(TblAuctionAuditTrailNew tblAuctionAuditTrailNew);

    public void updateTblAuctionAuditTrailNew(TblAuctionAuditTrailNew tblAuctionAuditTrailNew);

    public List<TblAuctionAuditTrailNew> getAllTblAuctionAuditTrailNew();

    public List<TblAuctionAuditTrailNew> findTblAuctionAuditTrailNew(Object... values) throws Exception;

    public List<TblAuctionAuditTrailNew> findByCountTblAuctionAuditTrailNew(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAuctionAuditTrailNewCount();

    public void saveUpdateAllTblAuctionAuditTrailNew(List<TblAuctionAuditTrailNew> tblAuctionAuditTrailNews);
}