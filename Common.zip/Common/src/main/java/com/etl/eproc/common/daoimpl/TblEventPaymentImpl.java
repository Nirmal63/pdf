package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblEventPayment;
import com.etl.eproc.common.daointerface.TblEventPaymentDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblEventPaymentImpl extends AbcAbstractClass<TblEventPayment> implements TblEventPaymentDao {

    @Override
    public void addTblEventPayment(TblEventPayment tblEventPayment){
        super.addEntity(tblEventPayment);
    }

    @Override
    public void deleteTblEventPayment(TblEventPayment tblEventPayment) {
        super.deleteEntity(tblEventPayment);
    }

    @Override
    public void updateTblEventPayment(TblEventPayment tblEventPayment) {
        super.updateEntity(tblEventPayment);
    }

    @Override
    public List<TblEventPayment> getAllTblEventPayment() {
        return super.getAllEntity();
    }

    @Override
    public List<TblEventPayment> findTblEventPayment(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblEventPaymentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblEventPayment> findByCountTblEventPayment(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblEventPayment(List<TblEventPayment> tblEventPayments){
        super.updateAll(tblEventPayments);
    }
}
