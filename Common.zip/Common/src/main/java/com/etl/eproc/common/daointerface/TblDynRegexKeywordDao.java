package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDynRegexKeyword;
import java.util.List;

public interface TblDynRegexKeywordDao  {

    public void addTblDynRegexKeyword(TblDynRegexKeyword tblDynRegexKeyword);

    public void deleteTblDynRegexKeyword(TblDynRegexKeyword tblDynRegexKeyword);

    public void updateTblDynRegexKeyword(TblDynRegexKeyword tblDynRegexKeyword);

    public List<TblDynRegexKeyword> getAllTblDynRegexKeyword();

    public List<TblDynRegexKeyword> findTblDynRegexKeyword(Object... values) throws Exception;

    public List<TblDynRegexKeyword> findByCountTblDynRegexKeyword(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynRegexKeywordCount();

    public void saveUpdateAllTblDynRegexKeyword(List<TblDynRegexKeyword> tblDynRegexKeywords);
}