/**
 *
 * @author hiral
 */

package com.etl.eproc.advertise.model;

import com.etl.eproc.common.model.TblClient;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.core.style.ToStringCreator;

@Entity
@Table(name="Tbl_Advertise",schema="appadvertise")
public class TblAdvertise  implements java.io.Serializable {

        private   int advertiseId;
        private   String advertiseNo;
        private   int advertiseType;
        private   String corrigendumText;
        private   int createdBy;
        private   Date createdOn;
        private   int cstatus;
        private   Date documentEndDate;
        private   Date documentStartDate;
        private   int isExtended;
        private   Date openingDate;
        private   int publishedBy;
        private   Date publishedOn;
        private  Date submissionStartDate;
        private   Date submissionEndDate;
        private   TblClient tblClient;
        private   int updatedBy;
        private   Date updatedOn;

        private Set<TblAdvertiseDetail> tblAdvertiseDetail = new HashSet<TblAdvertiseDetail>();

        @OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="tblAdvertise")
        public Set<TblAdvertiseDetail> getTblAdvertiseDetail()
        {
            return tblAdvertiseDetail;
        }
        public void setTblAdvertiseDetail(Set<TblAdvertiseDetail> tblAdvertiseDetail)
        {
            this.tblAdvertiseDetail = tblAdvertiseDetail;
        }

        private Set<TblAdvertiseTenderMap> tblAdvertiseTenderMap = new HashSet<TblAdvertiseTenderMap>();

        @OneToMany(cascade=CascadeType.ALL, fetch=FetchType.LAZY, mappedBy="tblAdvertise")
        public Set<TblAdvertiseTenderMap> getTblAdvertiseTenderMap()
        {
            return tblAdvertiseTenderMap;
        }
        public void setTblAdvertiseTenderMap(Set<TblAdvertiseTenderMap> tblAdvertiseTenderMap)
        {
            this.tblAdvertiseTenderMap = tblAdvertiseTenderMap;
        }


        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        @Column(name="advertiseId",unique=true,nullable=false)
        public int getAdvertiseId() {
            return this.advertiseId;
        }

        public void setAdvertiseId(int advertiseId) {
            this.advertiseId = advertiseId;
        }
        public TblAdvertise(int advertiseId){
            this.advertiseId = advertiseId;
        }
        @Column(name="advertiseNo",nullable=false, length=100)
        public String getAdvertiseNo() {
            return this.advertiseNo;
        }

        public void setAdvertiseNo(String advertiseNo) {
            this.advertiseNo = advertiseNo;
        }
        @Column(name="advertiseType",nullable=false)
        public int getAdvertiseType() {
            return this.advertiseType;
        }

        public void setAdvertiseType(int advertiseType) {
            this.advertiseType = advertiseType;
        }
        @Column(name="corrigendumText",nullable=false, length=0)
        public String getCorrigendumText() {
            return this.corrigendumText;
        }

        public void setCorrigendumText(String corrigendumText) {
            this.corrigendumText = corrigendumText;
        }
        @Column(name="createdBy",nullable=false)
        public int getCreatedBy() {
            return this.createdBy;
        }

        public void setCreatedBy(int createdBy) {
            this.createdBy = createdBy;
        }
        @Temporal(TemporalType.TIMESTAMP)
        @Column(name="createdOn",nullable=false,updatable=false,insertable=false)
        public Date getCreatedOn() {
            return this.createdOn;
        }

        public void setCreatedOn(Date createdOn) {
            this.createdOn = createdOn;
        }
        @Column(name="cstatus",nullable=false)
        public int getCstatus() {
            return this.cstatus;
        }

        public void setCstatus(int cstatus) {
            this.cstatus = cstatus;
        }
        @Temporal(TemporalType.TIMESTAMP)
        @Column(name="documentEndDate",nullable=false)
        public Date getDocumentEndDate() {
            return this.documentEndDate;
        }

        public void setDocumentEndDate(Date documentEndDate) {
            this.documentEndDate = documentEndDate;
        }
        @Temporal(TemporalType.TIMESTAMP)
        @Column(name="documentStartDate",nullable=true)
        public Date getDocumentStartDate() {
            return this.documentStartDate;
        }

        public void setDocumentStartDate(Date documentStartDate) {
            this.documentStartDate = documentStartDate;
        }
        @Column(name="isExtended",nullable=false)
        public int getIsExtended() {
            return this.isExtended;
        }

        public void setIsExtended(int isExtended) {
            this.isExtended = isExtended;
        }
        @Temporal(TemporalType.TIMESTAMP)
        @Column(name="openingDate",nullable=false)
        public Date getOpeningDate() {
            return this.openingDate;
        }

        public void setOpeningDate(Date openingDate) {
            this.openingDate = openingDate;
        }
        @Column(name="publishedBy",nullable=true)
        public int getPublishedBy() {
            return this.publishedBy;
        }

        public void setPublishedBy(int publishedBy) {
            this.publishedBy = publishedBy;
        }
        @Temporal(TemporalType.TIMESTAMP)
        @Column(name="publishedOn",nullable=true)
        public Date getPublishedOn() {
            return this.publishedOn;
        }

        public void setPublishedOn(Date publishedOn) {
            this.publishedOn = publishedOn;
        }
        @Temporal(TemporalType.TIMESTAMP)
        @Column(name="submissionStartDate",nullable=true)
        public Date getSubmissionStartDate() {
			return submissionStartDate;
		}
		public void setSubmissionStartDate(Date submissionStartDate) {
			this.submissionStartDate = submissionStartDate;
		}
		@Temporal(TemporalType.TIMESTAMP)
        @Column(name="submissionEndDate",nullable=false)
        public Date getSubmissionEndDate() {
            return this.submissionEndDate;
        }

        public void setSubmissionEndDate(Date submissionEndDate) {
            this.submissionEndDate = submissionEndDate;
        }
        @ManyToOne(fetch=FetchType.LAZY)
        @JoinColumn(name="clientid")
        public TblClient getTblClient() {
            return this.tblClient;
        }

        public void setTblClient(TblClient tblClient) {
            this.tblClient = tblClient;
        }
        @Column(name="updatedBy",nullable=false)
        public int getUpdatedBy() {
            return this.updatedBy;
        }

        public void setUpdatedBy(int updatedBy) {
            this.updatedBy = updatedBy;
        }
        @Temporal(TemporalType.TIMESTAMP)
        @Column(name="updatedOn",nullable=false)
        public Date getUpdatedOn() {
            return this.updatedOn;
        }

        public void setUpdatedOn(Date updatedOn) {
            this.updatedOn = updatedOn;
        }
        public TblAdvertise(){
        }
        @Override
	public String toString() {
		return new ToStringCreator(this)
.append("advertiseId", this.getAdvertiseId())
.append("advertiseNo", this.getAdvertiseNo())
.append("advertiseType", this.getAdvertiseType())
.append("corrigendumText", this.getCorrigendumText())
.append("createdBy", this.getCreatedBy())
.append("createdOn", this.getCreatedOn())
.append("cstatus", this.getCstatus())
.append("documentEndDate", this.getDocumentEndDate())
.append("documentStartDate", this.getDocumentStartDate())
.append("isExtended", this.getIsExtended())
.append("openingDate", this.getOpeningDate())
.append("publishedBy", this.getPublishedBy())
.append("publishedOn", this.getPublishedOn())
.append("submissionEndDate", this.getSubmissionEndDate())
.append("submissionStartDate", this.getSubmissionStartDate())

.append("updatedBy", this.getUpdatedBy())
.append("updatedOn", this.getUpdatedOn())
		.toString();

	}
}
