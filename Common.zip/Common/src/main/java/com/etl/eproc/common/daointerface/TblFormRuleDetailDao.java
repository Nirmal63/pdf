/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.etl.eproc.common.daointerface;

/**
 *
 * @author taher.tinwala
 */

import com.etl.eproc.common.model.TblFormRuleDetail;
import java.util.List;

public interface TblFormRuleDetailDao  {

    public void addTblFormRuleDetail(TblFormRuleDetail tblFormRuleDetail);

    public void deleteTblFormRuleDetail(TblFormRuleDetail tblFormRuleDetail);

    public void updateTblFormRuleDetail(TblFormRuleDetail tblFormRuleDetail);

    public List<TblFormRuleDetail> getAllTblFormRuleDetail();

    public List<TblFormRuleDetail> findTblFormRuleDetail(Object... values) throws Exception;

    public List<TblFormRuleDetail> findByCountTblFormRuleDetail(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFormRuleDetailCount();

    public void saveUpdateAllTblFormRuleDetail(List<TblFormRuleDetail> tblFormRuleDetails);
}
