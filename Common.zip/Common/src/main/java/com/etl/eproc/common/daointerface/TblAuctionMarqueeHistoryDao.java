package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblAuctionMarqueeHistory;

public interface TblAuctionMarqueeHistoryDao  {

    public void addTblAuctionMarqueeHistory(TblAuctionMarqueeHistory tblAuctionMarqueeHistory);

    public void deleteTblAuctionMarqueeHistory(TblAuctionMarqueeHistory tblAuctionMarqueeHistory);

    public void updateTblAuctionMarqueeHistory(TblAuctionMarqueeHistory tblAuctionMarqueeHistory);

    public List<TblAuctionMarqueeHistory> getAllTblAuctionMarqueeHistory();

    public List<TblAuctionMarqueeHistory> findTblAuctionMarqueeHistory(Object... values) throws Exception;

    public List<TblAuctionMarqueeHistory> findByCountTblAuctionMarqueeHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblAuctionMarqueeHistoryCount();

    public void saveUpdateAllTblAuctionMarqueeHistory(List<TblAuctionMarqueeHistory> tblAuctionMarqueeHistorys);
}