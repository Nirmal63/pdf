package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblCommitteeUserDetail;
import com.etl.eproc.common.daointerface.TblCommitteeUserDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblCommitteeUserDetailImpl extends AbcAbstractClass<TblCommitteeUserDetail> implements TblCommitteeUserDetailDao {

    @Override
    public void addTblCommitteeUserDetail(TblCommitteeUserDetail tblCommitteeUserDetail){
        super.addEntity(tblCommitteeUserDetail);
    }

    @Override
    public void deleteTblCommitteeUserDetail(TblCommitteeUserDetail tblCommitteeUserDetail) {
        super.deleteEntity(tblCommitteeUserDetail);
    }

    @Override
    public void updateTblCommitteeUserDetail(TblCommitteeUserDetail tblCommitteeUserDetail) {
        super.updateEntity(tblCommitteeUserDetail);
    }

    @Override
    public List<TblCommitteeUserDetail> getAllTblCommitteeUserDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblCommitteeUserDetail> findTblCommitteeUserDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblCommitteeUserDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblCommitteeUserDetail> findByCountTblCommitteeUserDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblCommitteeUserDetail(List<TblCommitteeUserDetail> tblCommitteeUserDetails){
        super.updateAll(tblCommitteeUserDetails);
    }
}
