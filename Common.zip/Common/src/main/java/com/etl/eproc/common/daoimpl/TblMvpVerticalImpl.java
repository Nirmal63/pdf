package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblMvpVertical;
import com.etl.eproc.common.daointerface.TblMvpVerticalDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblMvpVerticalImpl extends AbcAbstractClass<TblMvpVertical> implements TblMvpVerticalDao {

    @Override
    public void addTblMvpVertical(TblMvpVertical tblMvpVertical){
        super.addEntity(tblMvpVertical);
    }

    @Override
    public void deleteTblMvpVertical(TblMvpVertical tblMvpVertical) {
        super.deleteEntity(tblMvpVertical);
    }

    @Override
    public void updateTblMvpVertical(TblMvpVertical tblMvpVertical) {
        super.updateEntity(tblMvpVertical);
    }

    @Override
    public List<TblMvpVertical> getAllTblMvpVertical() {
        return super.getAllEntity();
    }

    @Override
    public List<TblMvpVertical> findTblMvpVertical(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblMvpVerticalCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblMvpVertical> findByCountTblMvpVertical(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblMvpVertical(List<TblMvpVertical> tblMvpVerticals){
        super.updateAll(tblMvpVerticals);
    }
}
