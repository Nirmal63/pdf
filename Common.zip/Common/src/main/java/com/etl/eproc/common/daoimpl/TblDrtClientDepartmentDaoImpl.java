package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblDrtClientDepartmentDao;
import com.etl.eproc.common.model.TblDrtClientDepartment;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDrtClientDepartmentDaoImpl extends AbcAbstractClass<TblDrtClientDepartment> implements TblDrtClientDepartmentDao {
	
	

    @Override
    public void addTblDrtClientDepartment(TblDrtClientDepartment TblDrtClientDepartment){
        super.addEntity(TblDrtClientDepartment);
    }

    @Override
    public void deleteTblDrtClientDepartment(TblDrtClientDepartment TblDrtClientDepartment) {
        super.deleteEntity(TblDrtClientDepartment);
    }

    @Override
    public void updateTblDrtClientDepartment(TblDrtClientDepartment TblDrtClientDepartment) {
        super.updateEntity(TblDrtClientDepartment);
    }

    @Override
    public List<TblDrtClientDepartment> getAllTblDrtClientDepartment() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDrtClientDepartment> findTblDrtClientDepartment(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDrtClientDepartmentCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDrtClientDepartment> findByCountTblDrtClientDepartment(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

	@Override
	public void saveUpdateAllTblDrtClientDepartment(List<TblDrtClientDepartment> TblDrtClientDepartments) {
		super.updateAll(TblDrtClientDepartments);
	}

	@Override
	public void saveOrUpdateTblDrtClientDepartment(TblDrtClientDepartment TblDrtClientDepartments) {
		super.saveOrUpdateEntity(TblDrtClientDepartments);
	}
}
