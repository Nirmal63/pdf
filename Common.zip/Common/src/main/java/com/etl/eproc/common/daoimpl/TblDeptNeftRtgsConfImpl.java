package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblDeptNeftRtgsConf;
import com.etl.eproc.common.daointerface.TblDeptNeftRtgsConfDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author sharmila
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDeptNeftRtgsConfImpl extends AbcAbstractClass<TblDeptNeftRtgsConf> implements TblDeptNeftRtgsConfDao {

    @Override
    public void addTblDeptNeftRtgsConf(TblDeptNeftRtgsConf tblDeptNeftRtgsConf){
        super.addEntity(tblDeptNeftRtgsConf);
    }

    @Override
    public void deleteTblDeptNeftRtgsConf(TblDeptNeftRtgsConf tblDeptNeftRtgsConf) {
        super.deleteEntity(tblDeptNeftRtgsConf);
    }

    @Override
    public void updateTblDeptNeftRtgsConf(TblDeptNeftRtgsConf tblDeptNeftRtgsConf) {
        super.updateEntity(tblDeptNeftRtgsConf);
    }

    @Override
    public List<TblDeptNeftRtgsConf> getAllTblDeptNeftRtgsConf() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDeptNeftRtgsConf> findTblDeptNeftRtgsConf(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDeptNeftRtgsConfCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDeptNeftRtgsConf> findByCountTblDeptNeftRtgsConf(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDeptNeftRtgsConf(List<TblDeptNeftRtgsConf> tblDeptNeftRtgsConfs){
        super.updateAll(tblDeptNeftRtgsConfs);
    }

	@Override
	public void saveOrUpdateTblDeptNeftRtgsConf(TblDeptNeftRtgsConf tblDeptNeftRtgsConf) {
		super.saveOrUpdateEntity(tblDeptNeftRtgsConf);
	}
}
