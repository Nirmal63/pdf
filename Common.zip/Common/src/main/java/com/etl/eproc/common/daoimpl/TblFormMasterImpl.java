package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblFormMaster;
import com.etl.eproc.common.daointerface.TblFormMasterDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblFormMasterImpl extends AbcAbstractClass<TblFormMaster> implements TblFormMasterDao {

    @Override
    public void addTblFormMaster(TblFormMaster tblFormMaster){
        super.addEntity(tblFormMaster);
    }

    @Override
    public void deleteTblFormMaster(TblFormMaster tblFormMaster) {
        super.deleteEntity(tblFormMaster);
    }

    @Override
    public void updateTblFormMaster(TblFormMaster tblFormMaster) {
        super.updateEntity(tblFormMaster);
    }

    @Override
    public List<TblFormMaster> getAllTblFormMaster() {
        return super.getAllEntity();
    }

    @Override
    public List<TblFormMaster> findTblFormMaster(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblFormMasterCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblFormMaster> findByCountTblFormMaster(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblFormMaster(List<TblFormMaster> tblFormMasters){
        super.updateAll(tblFormMasters);
    }

	@Override
	public void saveOrUpdateTblFormMaster(TblFormMaster tblFormMaster) {
		super.saveOrUpdateEntity(tblFormMaster);
	}
}
