package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientAlertConf;
import java.util.List;

public interface TblClientAlertConfDao  {

    public void addTblClientAlertConf(TblClientAlertConf tblClientAlertConf);

    public void deleteTblClientAlertConf(TblClientAlertConf tblClientAlertConf);

    public void updateTblClientAlertConf(TblClientAlertConf tblClientAlertConf);

    public List<TblClientAlertConf> getAllTblClientAlertConf();

    public List<TblClientAlertConf> findTblClientAlertConf(Object... values) throws Exception;

    public List<TblClientAlertConf> findByCountTblClientAlertConf(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientAlertConfCount();

    public void saveUpdateAllTblClientAlertConf(List<TblClientAlertConf> tblClientAlertConfs);
}