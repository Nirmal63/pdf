package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import com.etl.eproc.common.model.TblEventMaster;
import java.util.List;

public interface TblEventMasterDao  {

    public void addTblEventMaster(TblEventMaster tblEventMaster);

    public void deleteTblEventMaster(TblEventMaster tblEventMaster);

    public void updateTblEventMaster(TblEventMaster tblEventMaster);

    public List<TblEventMaster> getAllTblEventMaster();

    public List<TblEventMaster> findTblEventMaster(Object... values) throws Exception;

    public List<TblEventMaster> findByCountTblEventMaster(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblEventMasterCount();
}