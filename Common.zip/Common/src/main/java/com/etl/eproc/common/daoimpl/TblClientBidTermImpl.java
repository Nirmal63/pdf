package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.daointerface.TblClientBidTermDao;
import com.etl.eproc.common.model.TblClientBidTerm;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblClientBidTermImpl extends AbcAbstractClass<TblClientBidTerm> implements TblClientBidTermDao {

    @Override
    public void addTblClientBidTerm(TblClientBidTerm tblClientBidTerm){
        super.addEntity(tblClientBidTerm);
    }

    @Override
    public void deleteTblClientBidTerm(TblClientBidTerm tblClientBidTerm) {
        super.deleteEntity(tblClientBidTerm);
    }

    @Override
    public void updateTblClientBidTerm(TblClientBidTerm tblClientBidTerm) {
        super.updateEntity(tblClientBidTerm);
    }

    @Override
    public List<TblClientBidTerm> getAllTblClientBidTerm() {
        return super.getAllEntity();
    }

    @Override
    public List<TblClientBidTerm> findTblClientBidTerm(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblClientBidTermCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblClientBidTerm> findByCountTblClientBidTerm(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblClientBidTerm(List<TblClientBidTerm> tblClientBidTerms){
        super.updateAll(tblClientBidTerms);
    }
}
