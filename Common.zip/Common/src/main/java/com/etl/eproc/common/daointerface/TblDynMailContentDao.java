package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDynMailContent;
import java.util.List;

public interface TblDynMailContentDao  {

    public void addTblDynMailContent(TblDynMailContent tblDynMailContent);

    public void deleteTblDynMailContent(TblDynMailContent tblDynMailContent);

    public void updateTblDynMailContent(TblDynMailContent tblDynMailContent);

    public List<TblDynMailContent> getAllTblDynMailContent();

    public List<TblDynMailContent> findTblDynMailContent(Object... values) throws Exception;

    public List<TblDynMailContent> findByCountTblDynMailContent(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynMailContentCount();

    public void saveUpdateAllTblDynMailContent(List<TblDynMailContent> tblDynMailContents);
}