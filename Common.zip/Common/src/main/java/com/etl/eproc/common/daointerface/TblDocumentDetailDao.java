package com.etl.eproc.common.daointerface;


import com.etl.eproc.common.model.TblDocumentDetail;
import java.util.List;

	public interface TblDocumentDetailDao  {

	public void addTblDocumentDetail(TblDocumentDetail tblObj);

	public void deleteTblDocumentDetail(TblDocumentDetail tblObj);

	public void updateTblDocumentDetail(TblDocumentDetail tblObj);

	public List<TblDocumentDetail> getAllTblDocumentDetail();

	public List<TblDocumentDetail> findTblDocumentDetail(Object... values) throws Exception;

	public List<TblDocumentDetail> findByCountTblDocumentDetail(int firstResult,int maxResult,Object... values) throws Exception;

	public long getTblDocumentDetailCount();

	public void updateOrSaveTblDocumentDetail(List<TblDocumentDetail> tblObj);
}