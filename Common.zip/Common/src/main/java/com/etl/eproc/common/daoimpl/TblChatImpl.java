package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblChat;
import com.etl.eproc.common.daointerface.TblChatDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblChatImpl extends AbcAbstractClass<TblChat> implements TblChatDao {

    @Override
    public void addTblChat(TblChat tblChat){
        super.addEntity(tblChat);
    }

    @Override
    public void deleteTblChat(TblChat tblChat) {
        super.deleteEntity(tblChat);
    }

    @Override
    public void updateTblChat(TblChat tblChat) {
        super.updateEntity(tblChat);
    }

    @Override
    public List<TblChat> getAllTblChat() {
        return super.getAllEntity();
    }

    @Override
    public List<TblChat> findTblChat(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblChatCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblChat> findByCountTblChat(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblChat(List<TblChat> tblChats){
        super.updateAll(tblChats);
    }
}

