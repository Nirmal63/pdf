package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.daointerface.TblUserCertificateDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import com.etl.eproc.common.model.TblUserCertificate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblUserCertificateImpl extends AbcAbstractClass<TblUserCertificate> implements TblUserCertificateDao {

    @Override
    public void addTblUserCertificate(TblUserCertificate tblUserCertificate){
        super.addEntity(tblUserCertificate);
    }

    @Override
    public void deleteTblUserCertificate(TblUserCertificate tblUserCertificate) {
        super.deleteEntity(tblUserCertificate);
    }

    @Override
    public void updateTblUserCertificate(TblUserCertificate tblUserCertificate) {
        super.updateEntity(tblUserCertificate);
    }

    @Override
    public List<TblUserCertificate> getAllTblUserCertificate() {
        return super.getAllEntity();
    }

    @Override
    public List<TblUserCertificate> findTblUserCertificate(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblUserCertificateCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblUserCertificate> findByCountTblUserCertificate(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblUserCertificate(List<TblUserCertificate> tblUserCertificates){
        super.updateAll(tblUserCertificates);
    }
}
