package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblFormBusinessType;
import java.util.List;

public interface TblFormBusinessTypeDao  {

    public void addTblFormBusinessType(TblFormBusinessType tblFormBusinessType);

    public void deleteTblFormBusinessType(TblFormBusinessType tblFormBusinessType);

    public void updateTblFormBusinessType(TblFormBusinessType tblFormBusinessType);

    public List<TblFormBusinessType> getAllTblFormBusinessType();

    public List<TblFormBusinessType> findTblFormBusinessType(Object... values) throws Exception;

    public List<TblFormBusinessType> findByCountTblFormBusinessType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblFormBusinessTypeCount();

    public void saveUpdateAllTblFormBusinessType(List<TblFormBusinessType> tblFormBusinessTypes);
}