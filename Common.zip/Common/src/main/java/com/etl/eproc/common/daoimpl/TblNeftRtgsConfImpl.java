package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblNeftRtgsConf;
import com.etl.eproc.common.daointerface.TblNeftRtgsConfDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author sharmila
 */
@Repository @Transactional    /*StackUpdate*/
public class TblNeftRtgsConfImpl extends AbcAbstractClass<TblNeftRtgsConf> implements TblNeftRtgsConfDao {


    @Override
    public void addTblNeftRtgsConf(TblNeftRtgsConf tblNeftRtgsConf){
        super.addEntity(tblNeftRtgsConf);
    }

    @Override
    public void deleteTblNeftRtgsConf(TblNeftRtgsConf tblNeftRtgsConf) {
        super.deleteEntity(tblNeftRtgsConf);
    }

    @Override
    public void updateTblNeftRtgsConf(TblNeftRtgsConf tblNeftRtgsConf) {
        super.updateEntity(tblNeftRtgsConf);
    }

    @Override
    public List<TblNeftRtgsConf> getAllTblNeftRtgsConf() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNeftRtgsConf> findTblNeftRtgsConf(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNeftRtgsConfCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNeftRtgsConf> findByCountTblNeftRtgsConf(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNeftRtgsConf(List<TblNeftRtgsConf> tblNeftRtgsConfs){
        super.updateAll(tblNeftRtgsConfs);
    }

	@Override
	public void saveOrUpdateTblNeftRtgsConf(TblNeftRtgsConf tblNeftRtgsConf) {
		super.saveOrUpdateEntity(tblNeftRtgsConf);
	}
}
