package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblClientFeature;
import java.util.List;

public interface TblClientFeatureDao  {

    public void addTblClientFeature(TblClientFeature tblClientFeature);

    public void deleteTblClientFeature(TblClientFeature tblClientFeature);

    public void updateTblClientFeature(TblClientFeature tblClientFeature);

    public List<TblClientFeature> getAllTblClientFeature();

    public List<TblClientFeature> findTblClientFeature(Object... values) throws Exception;

    public List<TblClientFeature> findByCountTblClientFeature(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblClientFeatureCount();

    public void saveUpdateAllTblClientFeature(List<TblClientFeature> tblClientFeatures);
}