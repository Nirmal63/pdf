package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblNegotiationBidDetail;
import com.etl.eproc.common.daointerface.TblNegotiationBidDetailDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblNegotiationBidDetailImpl extends AbcAbstractClass<TblNegotiationBidDetail> implements TblNegotiationBidDetailDao {

    @Override
    public void addTblNegotiationBidDetail(TblNegotiationBidDetail tblNegotiationBidDetail){
        super.addEntity(tblNegotiationBidDetail);
    }

    @Override
    public void deleteTblNegotiationBidDetail(TblNegotiationBidDetail tblNegotiationBidDetail) {
        super.deleteEntity(tblNegotiationBidDetail);
    }

    @Override
    public void updateTblNegotiationBidDetail(TblNegotiationBidDetail tblNegotiationBidDetail) {
        super.updateEntity(tblNegotiationBidDetail);
    }

    @Override
    public List<TblNegotiationBidDetail> getAllTblNegotiationBidDetail() {
        return super.getAllEntity();
    }

    @Override
    public List<TblNegotiationBidDetail> findTblNegotiationBidDetail(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblNegotiationBidDetailCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblNegotiationBidDetail> findByCountTblNegotiationBidDetail(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblNegotiationBidDetail(List<TblNegotiationBidDetail> tblNegotiationBidDetails){
        super.updateAll(tblNegotiationBidDetails);
    }
}

