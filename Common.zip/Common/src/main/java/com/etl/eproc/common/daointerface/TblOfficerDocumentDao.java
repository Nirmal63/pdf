package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblOfficerDocument;
import java.util.List;

public interface TblOfficerDocumentDao  {

    public void addTblOfficerDocument(TblOfficerDocument tblOfficerDocument);

    public void deleteTblOfficerDocument(TblOfficerDocument tblOfficerDocument);

    public void updateTblOfficerDocument(TblOfficerDocument tblOfficerDocument);

    public List<TblOfficerDocument> getAllTblOfficerDocument();

    public List<TblOfficerDocument> findTblOfficerDocument(Object... values) throws Exception;

    public List<TblOfficerDocument> findByCountTblOfficerDocument(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblOfficerDocumentCount();

    public void saveUpdateAllTblOfficerDocument(List<TblOfficerDocument> tblOfficerDocuments);

	public void saveOrUpdateTblOfficerDocument(TblOfficerDocument tblOfficerDocument);
}