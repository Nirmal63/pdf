package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblDynFieldGroupMapping;
import java.util.List;

public interface TblDynFieldGroupMappingDao  {

    public void addTblDynFieldGroupMapping(TblDynFieldGroupMapping tblDynFieldGroupMapping);

    public void deleteTblDynFieldGroupMapping(TblDynFieldGroupMapping tblDynFieldGroupMapping);

    public void updateTblDynFieldGroupMapping(TblDynFieldGroupMapping tblDynFieldGroupMapping);

    public List<TblDynFieldGroupMapping> getAllTblDynFieldGroupMapping();

    public List<TblDynFieldGroupMapping> findTblDynFieldGroupMapping(Object... values) throws Exception;

    public List<TblDynFieldGroupMapping> findByCountTblDynFieldGroupMapping(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblDynFieldGroupMappingCount();

    public void saveUpdateAllTblDynFieldGroupMapping(List<TblDynFieldGroupMapping> tblDynFieldGroupMappings);
}