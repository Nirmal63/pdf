package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblMobileBidderStatus;


import java.util.List;

public interface TblMobileBidderStatusDao  {

    public void addTblmobilebidderstatus(TblMobileBidderStatus tblmobilebidderstatus);

    public void deleteTblmobilebidderstatus(TblMobileBidderStatus tblmobilebidderstatus);

    public void updateTblmobilebidderstatus(TblMobileBidderStatus tblmobilebidderstatus);

    public List<TblMobileBidderStatus> getAllTblmobilebidderstatus();

    public List<TblMobileBidderStatus> findTblmobilebidderstatus(Object... values) throws Exception;

    public List<TblMobileBidderStatus> findByCountTblmobilebidderstatus(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblmobilebidderstatusCount();

    public void saveUpdateAllTblmobilebidderstatus(List<TblMobileBidderStatus> tblmobilebidderstatuss);

	public void saveOrUpdateTblMobileBidderStatus(TblMobileBidderStatus tblmobilebidderstatus);
}