package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCustomParameter;
import java.util.List;

public interface TblCustomParameterDao  {

    public void addTblCustomParameter(TblCustomParameter tblCustomParameter);

    public void deleteTblCustomParameter(TblCustomParameter tblCustomParameter);

    public void updateTblCustomParameter(TblCustomParameter tblCustomParameter);

    public List<TblCustomParameter> getAllTblCustomParameter();

    public List<TblCustomParameter> findTblCustomParameter(Object... values) throws Exception;

    public List<TblCustomParameter> findByCountTblCustomParameter(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCustomParameterCount();

    public void saveUpdateAllTblCustomParameter(List<TblCustomParameter> tblCustomParameters);
}