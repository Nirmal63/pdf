package com.etl.eproc.common.daointerface;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import com.etl.eproc.common.model.TblCertUnMapHistory;
import java.util.List;

public interface TblCertUnMapHistoryDao  {

    public void addTblCertUnMapHistory(TblCertUnMapHistory tblCertUnMapHistory);

    public void deleteTblCertUnMapHistory(TblCertUnMapHistory tblCertUnMapHistory);

    public void updateTblCertUnMapHistory(TblCertUnMapHistory tblCertUnMapHistory);

    public List<TblCertUnMapHistory> getAllTblCertUnMapHistory();

    public List<TblCertUnMapHistory> findTblCertUnMapHistory(Object... values) throws Exception;

    public List<TblCertUnMapHistory> findByCountTblCertUnMapHistory(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblCertUnMapHistoryCount();

    public void saveUpdateAllTblCertUnMapHistory(List<TblCertUnMapHistory> tblCertUnMapHistorys);
}