package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblDCDetachHistory;
import com.etl.eproc.common.daointerface.TblDCDetachHistoryDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblDCDetachHistoryImpl extends AbcAbstractClass<TblDCDetachHistory> implements TblDCDetachHistoryDao {


    @Override
    public void addTblDCDetachHistory(TblDCDetachHistory tblDCDetachHistory){
        super.addEntity(tblDCDetachHistory);
    }

    @Override
    public void deleteTblDCDetachHistory(TblDCDetachHistory tblDCDetachHistory) {
        super.deleteEntity(tblDCDetachHistory);
    }

    @Override
    public void updateTblDCDetachHistory(TblDCDetachHistory tblDCDetachHistory) {
        super.updateEntity(tblDCDetachHistory);
    }

    @Override
    public List<TblDCDetachHistory> getAllTblDCDetachHistory() {
        return super.getAllEntity();
    }

    @Override
    public List<TblDCDetachHistory> findTblDCDetachHistory(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblDCDetachHistoryCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblDCDetachHistory> findByCountTblDCDetachHistory(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblDCDetachHistory(List<TblDCDetachHistory> tblDCDetachHistorys){
        super.updateAll(tblDCDetachHistorys);
    }
}
