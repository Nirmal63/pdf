package com.etl.eproc.common.daointerface;

import java.util.List;

import com.etl.eproc.common.model.TblBusinessType;

public interface TblBusinessTypeDao {

    public void addTblBusinessType(TblBusinessType tblBusinessType);

    public void deleteTblBusinessType(TblBusinessType tblBusinessType);

    public void updateTblBusinessType(TblBusinessType tblBusinessType);

    public List<TblBusinessType> getAllTblBusinessType();

    public List<TblBusinessType> findTblBusinessType(Object... values) throws Exception;

    public List<TblBusinessType> findByCountTblBusinessType(int firstResult,int maxResult,Object... values) throws Exception;

    public long getTblBusinessTypeCount();

    public void saveUpdateAllTblBusinessType(List<TblBusinessType> tblBusinessTypes);
}