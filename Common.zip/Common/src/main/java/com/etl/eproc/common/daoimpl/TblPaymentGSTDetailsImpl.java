package com.etl.eproc.common.daoimpl;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import com.etl.eproc.common.model.TblPaymentGSTDetails;
import com.etl.eproc.common.daointerface.TblPaymentGSTDetailsDao;
import com.etl.eproc.common.daogeneric.AbcAbstractClass;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.hibernate.SessionFactory;
import java.util.List;

/**
 *
 * @author taher
 */
@Repository @Transactional    /*StackUpdate*/
public class TblPaymentGSTDetailsImpl extends AbcAbstractClass<TblPaymentGSTDetails> implements TblPaymentGSTDetailsDao {

    @Override
    public void addTblPaymentGSTDetails(TblPaymentGSTDetails tblPaymentGSTDetails){
        super.addEntity(tblPaymentGSTDetails);
    }

    @Override
    public void deleteTblPaymentGSTDetails(TblPaymentGSTDetails tblPaymentGSTDetails) {
        super.deleteEntity(tblPaymentGSTDetails);
    }

    @Override
    public void updateTblPaymentGSTDetails(TblPaymentGSTDetails tblPaymentGSTDetails) {
        super.updateEntity(tblPaymentGSTDetails);
    }

    @Override
    public List<TblPaymentGSTDetails> getAllTblPaymentGSTDetails() {
        return super.getAllEntity();
    }

    @Override
    public List<TblPaymentGSTDetails> findTblPaymentGSTDetails(Object... values) throws Exception {
        return super.findEntity(values);
    }

    @Override
    public long getTblPaymentGSTDetailsCount() {
        return super.getEntityCount();
    }

    @Override
    public List<TblPaymentGSTDetails> findByCountTblPaymentGSTDetails(int firstResult, int maxResult, Object... values) throws Exception {
        return super.findByCountEntity(firstResult, maxResult, values);
    }

    @Override
    public void saveUpdateAllTblPaymentGSTDetails(List<TblPaymentGSTDetails> tblPaymentGSTDetailss){
        super.updateAll(tblPaymentGSTDetailss);
    }

	@Override
	public void saveOrUpdateAllTblPaymentGSTDetails(TblPaymentGSTDetails tblPaymentGSTDetails) {
		super.saveOrUpdateEntity(tblPaymentGSTDetails);
	}
}
